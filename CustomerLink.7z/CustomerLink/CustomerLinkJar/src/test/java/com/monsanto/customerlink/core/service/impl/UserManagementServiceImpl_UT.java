package com.monsanto.customerlink.core.service.impl;

import com.monsanto.PeoplePicker.PersonInfo;
import com.monsanto.customerlink.core.service.UserManagementService;
import com.monsanto.customerlink.core.service.UserManagementServiceHelper;
import com.monsanto.customerlink.core.service.dto.*;
import com.monsanto.customerlink.core.service.dto.SubRegionDTO;
import com.monsanto.customerlink.core.service.exception.AssignedUserException;
import com.monsanto.customerlink.core.service.exception.InvalidUserException;
import com.monsanto.customerlink.core.service.exception.InvalidUserParametersException;
import com.monsanto.customerlink.core.service.exception.UserNotAvailableForRemoveException;
import com.monsanto.customerlink.core.service.util.Mapper;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class UserManagementServiceImpl_UT {

    @Mock
    private Mapper mapper;

    @Mock
    private UserRepository userRepository;

    @Mock
    private RoleRepository roleRepository;

    @Mock
    private UserManagementService unit;

    @Mock
    private BrandRepository brandRepository;

    @Mock
    private SalesOrganizationRepository salesOrganizationRepository;

    @Mock
    private SalesDivisionRepository salesDivisionRepository;

    @Mock
    private DistributionChannelRepository distributionChannelRepository;

    @Mock
    private SubRegionRepository subRegionRepository;

    @Mock
    private UserDistributorRepository userDistributorRepository;

    @Mock
    private DistributorRepository distributorRepository;

    @Mock
    private DistributorProfileRepository distributorProfileRepository;

    @Mock
    private UserManagementServiceHelper helper;

    @Before
    public void before() {
        reset(userRepository, mapper, roleRepository, brandRepository,
                salesOrganizationRepository,salesDivisionRepository,distributionChannelRepository,subRegionRepository,
                userDistributorRepository,distributorRepository,helper);
        unit = new UserManagementServiceImpl(userRepository, mapper, roleRepository, brandRepository,
                salesOrganizationRepository,salesDivisionRepository,distributionChannelRepository,subRegionRepository,
                userDistributorRepository,distributorRepository,distributorProfileRepository,helper);
    }

    @Test
    public void exceptionOnCreateWorkFlowApprovalWhenInputParametersNotValid(){
        unit.getListOfUsersByRole("MRKT");
    }

    @Test
    public void getListOfUsersByRole_WhenListOfUsersByRoleIsEmpty() throws Exception {
        List<GridUserRoleDTO> users = unit.getListOfUsersByRole("MRKT");
        assertTrue(users.isEmpty());
    }

    @Test
    public void getListOfUsersByRole_WhenListOfUsersByRoleIsNotEmpty() throws Exception {

        UserVO u = new UserVO();

        List<UserVO> listOfUsersByRoleFromRepository = Arrays.asList(new UserVO[]{u});
        when(userRepository.findByRoleCode(anyString())).thenReturn(listOfUsersByRoleFromRepository);

        GridUserRoleDTO gridUserRoleDTO = new GridUserRoleDTO();

        List<GridUserRoleDTO> listOfUsersByRoleFromMapper = Arrays.asList(new GridUserRoleDTO[]{gridUserRoleDTO});
        when(mapper.mapList(eq(GridUserRoleDTO.class),anyList())).thenReturn(listOfUsersByRoleFromMapper);

        List<GridUserRoleDTO> distributors = unit.getListOfUsersByRole("MRKT");
        assertTrue(!distributors.isEmpty());
    }

    @Test(expected = IllegalArgumentException.class)
    public void createUpdateUserRole_WhenUserRoleIsNull() throws Exception {
        unit.createUpdateUserRole(null);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_WhenRoleIsNull() throws Exception {
        UserRoleDTO userRoleDTO = new UserRoleDTO();
        unit.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_WhenRoleIdIsNull() throws Exception {

        RoleDTO roleDTO = new RoleDTO();

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);

        unit.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_WhenRoleIsNotValid() throws Exception {

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode("WRONG_CODE");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);

        when(roleRepository.findByCode(eq("WRONG_CODE"))).thenReturn(null); // return null, not exist
        unit.createUpdateUserRole(userRoleDTO);

    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_UserNameIsNull() throws Exception {

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.PLANNING.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.PLANNING.getCode());

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        unit.createUpdateUserRole(userRoleDTO);

    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_UserNameIsEmpty() throws Exception {

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.PLANNING.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.PLANNING.getCode());

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        unit.createUpdateUserRole(userRoleDTO);

    }

    @Test(expected = InvalidUserException.class)
    public void createUpdateUserRole_UserNameIsNotValid() throws Exception {

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.PLANNING.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("MONSANTO_NOT_VALID_NAME");

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.PLANNING.getCode());

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        unit.createUpdateUserRole(userRoleDTO);

    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_Planning_Insert_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.PLANNING.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.PLANNING.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()});
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test
    public void createUpdateUserRole_Planning_Insert_WhenNotExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.PLANNING.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.PLANNING.getCode());

        List<UserVO> users = new ArrayList<UserVO>();
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_Planning_Update_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.PLANNING.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(1L); // is not new user.

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.PLANNING.getCode());

        // user exist to update
        UserVO userVO = new UserVO();
        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()});
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

    }

    @Test
    public void createUpdateUserRole_Planning_Update_WhenNotExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.PLANNING.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(1L); // is not new user.

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.PLANNING.getCode());

        // user exist to update
        UserVO userVO = new UserVO();
        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);

        List<UserVO> users = new ArrayList<UserVO>();
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_Pricing_Insert_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.PRICING.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.PRICING.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()});
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test
    public void createUpdateUserRole_Pricing_Insert_WhenNotExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.PRICING.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.PRICING.getCode());

        List<UserVO> users = new ArrayList<UserVO>();
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_Pricing_Update_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.PRICING.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(1L); // is not new user.

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.PRICING.getCode());

        // user exist to update
        UserVO userVO = new UserVO();
        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()});
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

    }

    @Test
    public void createUpdateUserRole_Pricing_Update_WhenNotExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.PRICING.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(1L); // is not new user.

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.PRICING.getCode());

        // user exist to update
        UserVO userVO = new UserVO();
        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);

        List<UserVO> users = new ArrayList<UserVO>();
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_Marketing_Insert_WhenBrandIsNull() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.MARKETING.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.MARKETING.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()});
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_Marketing_Insert_WhenBrandIdIsNull() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.MARKETING.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode(null); // brand code is null

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.MARKETING.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()});
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_Marketing_Insert_WhenBrandIsNotValid() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.MARKETING.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("INVALID_BRAND");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.MARKETING.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()});
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = null; // when brand is not valid
        when(brandRepository.findOne(eq("INVALID_BRAND"))).thenReturn(brandVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_Marketing_Insert_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.MARKETING.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.MARKETING.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test
    public void createUpdateUserRole_Marketing_Insert_WhenNotExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.MARKETING.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.MARKETING.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{}); // not exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_Marketing_Update_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.MARKETING.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(1L); // is update user
        userRoleDTO.setBrandDTO(brandDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.MARKETING.getCode());

        // user exist to update
        UserVO userVO = new UserVO();
        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test
    public void createUpdateUserRole_Marketing_Update_WhenNotExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.MARKETING.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(1L); // is update user
        userRoleDTO.setBrandDTO(brandDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.MARKETING.getCode());

        // user exist to update
        UserVO userVO = new UserVO();
        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);

        List<UserVO> users = Arrays.asList(new UserVO[]{}); // not exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_RCD_Insert_WhenKeyIsNull() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(null); // key is null

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_RCD_Insert_WhenSalesOrgIsNull() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode(null); // sales org is null

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_RCD_Insert_WhenSalesOrgIsNotValid() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("NOT_VALID_SALES_ORG"); // sales org is not valid

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = null; // when sales org is not valid
        when(salesOrganizationRepository.findOne("NOT_VALID_SALES_ORG")).thenReturn(salesOrganizationVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_RCD_Insert_WhenSalesDivIsNull() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode(null);// when sales division is null

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_RCD_Insert_WhenSalesDivIsNotValid() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("SALES_DIVISION_NOT_VALID");// when sales division IS NOT VALID

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = null; // when sales division is not valid
        when(salesDivisionRepository.findOne("SALES_DIVISION_NOT_VALID")).thenReturn(salesDivisionVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_RCD_Insert_WhenDistributionChannelIsNull() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode(null); // when distribution channel is null

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_RCD_Insert_WhenDistributionChannelIsNotValid() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode("DISTRIBUTION_CHANNEL_NOT_VALID"); // when distribution channel is NOT VALID

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        DistributionChannelVO distributionChannelVO = null;
        when(distributionChannelRepository.findByDistributionChannelCode("DISTRIBUTION_CHANNEL_NOT_VALID")).thenReturn(distributionChannelVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_RCD_Insert_WhenSubRegionIsNull() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode("80");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);
        userRoleDTO.setSubRegionDTO(null); //when Sub Region is null

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        when(distributionChannelRepository.findByDistributionChannelCode("80")).thenReturn(distributionChannelVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_RCD_Insert_WhenSubRegionCodeIsNull() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode("80");

        SubRegionDTO subRegionDTO = new SubRegionDTO();
        subRegionDTO.setSubRegionCode(null); // when subregion code is null


        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);
        userRoleDTO.setSubRegionDTO(subRegionDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        when(distributionChannelRepository.findByDistributionChannelCode("80")).thenReturn(distributionChannelVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = InvalidUserParametersException.class)
    public void createUpdateUserRole_RCD_Insert_WhenSubRegionCodeIsInvalid() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode("80");

        SubRegionDTO subRegionDTO = new SubRegionDTO();
        subRegionDTO.setSubRegionCode("INVALID_SUB_REGION_CODE"); // when sub region code is invalid


        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);
        userRoleDTO.setSubRegionDTO(subRegionDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        when(distributionChannelRepository.findByDistributionChannelCode("80")).thenReturn(distributionChannelVO);

        SubRegionVO subRegionVO = null; // when sub region code is invalid
        when(subRegionRepository.findBySubRegionCode("INVALID_SUB_REGION_CODE")).thenReturn(subRegionVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_RCD_Insert_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode("80");

        SubRegionDTO subRegionDTO = new SubRegionDTO();
        subRegionDTO.setSubRegionCode("AMXBAJ");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);
        userRoleDTO.setSubRegionDTO(subRegionDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        when(distributionChannelRepository.findByDistributionChannelCode("80")).thenReturn(distributionChannelVO);

        SubRegionVO subRegionVO = new SubRegionVO();
        when(subRegionRepository.findBySubRegionCode("AMXBAJ")).thenReturn(subRegionVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test
    public void createUpdateUserRole_RCD_Insert_WhenNotExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode("80");

        SubRegionDTO subRegionDTO = new SubRegionDTO();
        subRegionDTO.setSubRegionCode("AMXBAJ");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);
        userRoleDTO.setSubRegionDTO(subRegionDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{}); // not exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        when(distributionChannelRepository.findByDistributionChannelCode("80")).thenReturn(distributionChannelVO);

        SubRegionVO subRegionVO = new SubRegionVO();
        when(subRegionRepository.findBySubRegionCode("AMXBAJ")).thenReturn(subRegionVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_RCD_Update_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode("80");

        SubRegionDTO subRegionDTO = new SubRegionDTO();
        subRegionDTO.setSubRegionCode("AMXBAJ");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(1L); // update user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);
        userRoleDTO.setSubRegionDTO(subRegionDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        when(distributionChannelRepository.findByDistributionChannelCode("80")).thenReturn(distributionChannelVO);

        SubRegionVO subRegionVO = new SubRegionVO();
        when(subRegionRepository.findBySubRegionCode("AMXBAJ")).thenReturn(subRegionVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test
    public void createUpdateUserRole_RCD_Update_WhenNotExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RCD.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode("80");

        SubRegionDTO subRegionDTO = new SubRegionDTO();
        subRegionDTO.setSubRegionCode("AMXBAJ");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(1L); // update user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);
        userRoleDTO.setSubRegionDTO(subRegionDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{}); // not exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        when(distributionChannelRepository.findByDistributionChannelCode("80")).thenReturn(distributionChannelVO);

        SubRegionVO subRegionVO = new SubRegionVO();
        when(subRegionRepository.findBySubRegionCode("AMXBAJ")).thenReturn(subRegionVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_RBM_Insert_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RBM.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode("80");

        SubRegionDTO subRegionDTO = new SubRegionDTO();
        subRegionDTO.setSubRegionCode("AMXBAJ");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);
        userRoleDTO.setSubRegionDTO(subRegionDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RBM.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        when(distributionChannelRepository.findByDistributionChannelCode("80")).thenReturn(distributionChannelVO);

        SubRegionVO subRegionVO = new SubRegionVO();
        when(subRegionRepository.findBySubRegionCode("AMXBAJ")).thenReturn(subRegionVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test
    public void createUpdateUserRole_RBM_Insert_WhenNotExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RBM.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode("80");

        SubRegionDTO subRegionDTO = new SubRegionDTO();
        subRegionDTO.setSubRegionCode("AMXBAJ");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);
        userRoleDTO.setSubRegionDTO(subRegionDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RBM.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{}); // not exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        when(distributionChannelRepository.findByDistributionChannelCode("80")).thenReturn(distributionChannelVO);

        SubRegionVO subRegionVO = new SubRegionVO();
        when(subRegionRepository.findBySubRegionCode("AMXBAJ")).thenReturn(subRegionVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_RBM_Update_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RBM.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode("80");

        SubRegionDTO subRegionDTO = new SubRegionDTO();
        subRegionDTO.setSubRegionCode("AMXBAJ");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(1L); // update user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);
        userRoleDTO.setSubRegionDTO(subRegionDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RBM.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()}); // exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        when(distributionChannelRepository.findByDistributionChannelCode("80")).thenReturn(distributionChannelVO);

        SubRegionVO subRegionVO = new SubRegionVO();
        when(subRegionRepository.findBySubRegionCode("AMXBAJ")).thenReturn(subRegionVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test
    public void createUpdateUserRole_RBM_Update_WhenNotExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.RBM.getCode());

        BrandDTO brandDTO = new BrandDTO();
        brandDTO.setBrandCode("DK");

        KeyDTO keyDTO =  new KeyDTO();
        keyDTO.setSalesOrgCode("MX20");
        keyDTO.setSalesDivCode("17");
        keyDTO.setDistChannelCode("80");

        SubRegionDTO subRegionDTO = new SubRegionDTO();
        subRegionDTO.setSubRegionCode("AMXBAJ");

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(1L); // update user
        userRoleDTO.setBrandDTO(brandDTO);
        userRoleDTO.setKeyDTO(keyDTO);
        userRoleDTO.setSubRegionDTO(subRegionDTO);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RBM.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{}); // not exist other user same profile
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        BrandVO brandVO = new BrandVO(); // when brand is not valid
        when(brandRepository.findOne(eq("DK"))).thenReturn(brandVO);

        SalesOrganizationVO salesOrganizationVO = new SalesOrganizationVO();
        when(salesOrganizationRepository.findOne("MX20")).thenReturn(salesOrganizationVO);

        SalesDivisionVO salesDivisionVO = new SalesDivisionVO();
        when(salesDivisionRepository.findOne("17")).thenReturn(salesDivisionVO);

        DistributionChannelVO distributionChannelVO = new DistributionChannelVO();
        when(distributionChannelRepository.findByDistributionChannelCode("80")).thenReturn(distributionChannelVO);

        SubRegionVO subRegionVO = new SubRegionVO();
        when(subRegionRepository.findBySubRegionCode("AMXBAJ")).thenReturn(subRegionVO);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_CSR_Insert_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.CSR.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.CSR.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()});
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_APPROVER_Insert_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.APPROVER.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.APPROVER.getCode());

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()});
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);
    }

    @Test(expected = AssignedUserException.class)
     public void createUpdateUserRole_CSR_Update_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.CSR.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(1L); // is not new user.

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.CSR.getCode());

        // user exist to update
        UserVO userVO = new UserVO();
        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()});
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

    }

    @Test(expected = AssignedUserException.class)
    public void createUpdateUserRole_APPROVER_Update_WhenExistOtherUserSameProfile() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.APPROVER.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(1L); // is not new user.

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.APPROVER.getCode());

        // user exist to update
        UserVO userVO = new UserVO();
        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);

        List<UserVO> users = Arrays.asList(new UserVO[]{ new UserVO()});
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

    }

    @Test
    public void createUpdateUserRole_CSR_Insert_WhenNotExistPreviousDistributorsForDelete() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.CSR.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.CSR.getCode());

        List<UserVO> users = new ArrayList<UserVO>();
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        UserVO savedUser = new UserVO();
        savedUser.setUserID(1L);
        when(userRepository.save(Matchers.any(UserVO.class))).thenReturn(savedUser);

        List<UserDistributorVO> distributors =  Arrays.asList(new UserDistributorVO[]{}); // when not exist previous distributors for delete
        when(userDistributorRepository.findByUser(anyLong())).thenReturn(distributors);
        when(helper.isCsrOrApprover(eq(RoleEnum.CSR))).thenReturn(true);
        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
    }

    @Test
    public void createUpdateUserRole_APPROVER_Insert_WhenNotExistPreviousDistributorsForDelete() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.APPROVER.getCode());

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.APPROVER.getCode());

        List<UserVO> users = new ArrayList<UserVO>();
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        UserVO savedUser = new UserVO();
        savedUser.setUserID(1L);
        when(userRepository.save(Matchers.any(UserVO.class))).thenReturn(savedUser);

        List<UserDistributorVO> distributors =  Arrays.asList(new UserDistributorVO[]{}); // when not exist previous distributors for delete
        when(userDistributorRepository.findByUser(anyLong())).thenReturn(distributors);
        when(helper.isCsrOrApprover(eq(RoleEnum.APPROVER))).thenReturn(true);
        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
    }

    @Test
    public void createUpdateUserRole_CSR_Insert_WhenExistPreviousDistributorsForDelete_AndListOfNewDistributorsIsNull() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.CSR.getCode());

        List<DistributorDTO> listOfDistributors = null; // when list of distributors is null

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setListOfDistributors(listOfDistributors);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.CSR.getCode());

        List<UserVO> users = new ArrayList<UserVO>();
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        UserVO savedUser = new UserVO();
        savedUser.setUserID(1L);
        when(userRepository.save(Matchers.any(UserVO.class))).thenReturn(savedUser);

        UserDistributorVO userDistributorForDelete = new UserDistributorVO();
        List<UserDistributorVO> distributors =  Arrays.asList(new UserDistributorVO[]{userDistributorForDelete}); // when exist previous distributors for delete
        when(userDistributorRepository.findByUser(anyLong())).thenReturn(distributors);
        when(helper.isCsrOrApprover(eq(RoleEnum.CSR))).thenReturn(true);
        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
        verify(userDistributorRepository).delete(anyListOf(UserDistributorVO.class));
        verify(userDistributorRepository).flush();
    }

    @Test
    public void createUpdateUserRole_APPROVER_Insert_WhenExistPreviousDistributorsForDelete_AndListOfNewDistributorsIsNull() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.APPROVER.getCode());

        List<DistributorDTO> listOfDistributors = null; // when list of distributors is null

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setListOfDistributors(listOfDistributors);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.APPROVER.getCode());

        List<UserVO> users = new ArrayList<UserVO>();
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        UserVO savedUser = new UserVO();
        savedUser.setUserID(1L);
        when(userRepository.save(Matchers.any(UserVO.class))).thenReturn(savedUser);

        UserDistributorVO userDistributorForDelete = new UserDistributorVO();
        List<UserDistributorVO> distributors =  Arrays.asList(new UserDistributorVO[]{userDistributorForDelete}); // when exist previous distributors for delete
        when(userDistributorRepository.findByUser(anyLong())).thenReturn(distributors);
        when(helper.isCsrOrApprover(eq(RoleEnum.APPROVER))).thenReturn(true);
        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
        verify(userDistributorRepository).delete(anyListOf(UserDistributorVO.class));
        verify(userDistributorRepository).flush();
    }

    @Test
    public void createUpdateUserRole_CSR_Insert_WhenExistPreviousDistributorsForDelete_AndListOfNewDistributorsIsEmpty() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.CSR.getCode());

        List<DistributorDTO> listOfDistributors = Arrays.asList(new DistributorDTO[]{}); // is empty

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setListOfDistributors(listOfDistributors);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.CSR.getCode());

        List<UserVO> users = new ArrayList<UserVO>();
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        UserVO savedUser = new UserVO();
        savedUser.setUserID(1L);
        when(userRepository.save(Matchers.any(UserVO.class))).thenReturn(savedUser);

        UserDistributorVO userDistributorForDelete = new UserDistributorVO();
        List<UserDistributorVO> distributors =  Arrays.asList(new UserDistributorVO[]{userDistributorForDelete}); // when exist previous distributors for delete
        when(userDistributorRepository.findByUser(anyLong())).thenReturn(distributors);
        when(helper.isCsrOrApprover(eq(RoleEnum.CSR))).thenReturn(true);
        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
        verify(userDistributorRepository).delete(anyListOf(UserDistributorVO.class));
        verify(userDistributorRepository).flush();
    }

    @Test
    public void createUpdateUserRole_APPROVER_Insert_WhenExistPreviousDistributorsForDelete_AndListOfNewDistributorsIsEmpty() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.APPROVER.getCode());

        List<DistributorDTO> listOfDistributors = Arrays.asList(new DistributorDTO[]{}); // is empty

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setListOfDistributors(listOfDistributors);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.APPROVER.getCode());

        List<UserVO> users = new ArrayList<UserVO>();
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        UserVO savedUser = new UserVO();
        savedUser.setUserID(1L);
        when(userRepository.save(Matchers.any(UserVO.class))).thenReturn(savedUser);

        UserDistributorVO userDistributorForDelete = new UserDistributorVO();
        List<UserDistributorVO> distributors =  Arrays.asList(new UserDistributorVO[]{userDistributorForDelete}); // when exist previous distributors for delete
        when(userDistributorRepository.findByUser(anyLong())).thenReturn(distributors);
        when(helper.isCsrOrApprover(eq(RoleEnum.APPROVER))).thenReturn(true);
        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
        verify(userDistributorRepository).delete(anyListOf(UserDistributorVO.class));
        verify(userDistributorRepository).flush();
    }

    @Test
    public void createUpdateUserRole_CSR_Insert_WhenExistPreviousDistributorsForDelete_AndListOfNewDistributorsIsNotEmpty() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.CSR.getCode());

        List<DistributorDTO> listOfDistributors = Arrays.asList(new DistributorDTO[]{new DistributorDTO()}); // is not empty

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setListOfDistributors(listOfDistributors);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.CSR.getCode());

        List<UserVO> users = new ArrayList<UserVO>();
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        UserVO savedUser = new UserVO();
        savedUser.setUserID(1L);
        when(userRepository.save(Matchers.any(UserVO.class))).thenReturn(savedUser);

        UserDistributorVO userDistributorForDelete = new UserDistributorVO();
        List<UserDistributorVO> distributors =  Arrays.asList(new UserDistributorVO[]{userDistributorForDelete}); // when exist previous distributors for delete
        when(userDistributorRepository.findByUser(anyLong())).thenReturn(distributors);
        when(helper.isCsrOrApprover(eq(RoleEnum.CSR))).thenReturn(true);
        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
        verify(userDistributorRepository).delete(anyListOf(UserDistributorVO.class));
        verify(userDistributorRepository).flush();
        verify(distributorRepository).findByDistributorCode(anyString());
        verify(userDistributorRepository).save(anyListOf(UserDistributorVO.class));
    }

    @Test
    public void createUpdateUserRole_APPROVER_Insert_WhenExistPreviousDistributorsForDelete_AndListOfNewDistributorsIsNotEmpty() throws Exception {
        PersonInfo personInfo = new PersonInfo();
        personInfo.setUserId("JCABRER");

        PersonInfo[] listOfPersons = {personInfo};

        UserManagementServiceImpl aSpy = (UserManagementServiceImpl) Mockito.spy(unit);
        Mockito.doReturn(listOfPersons).when(aSpy).getPeople(Matchers.<String>any());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setCode(RoleEnum.APPROVER.getCode());

        List<DistributorDTO> listOfDistributors = Arrays.asList(new DistributorDTO[]{new DistributorDTO()}); // is not empty

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setRoleDTO(roleDTO);
        userRoleDTO.setUserName("JCABRER");
        userRoleDTO.setIdUser(null); // is new user
        userRoleDTO.setListOfDistributors(listOfDistributors);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.APPROVER.getCode());

        List<UserVO> users = new ArrayList<UserVO>();
        when(userRepository.findByParametersWithOutUserId( Matchers.any(UserVO.class), anyLong(),anyString())).thenReturn(users);

        UserVO savedUser = new UserVO();
        savedUser.setUserID(1L);
        when(userRepository.save(Matchers.any(UserVO.class))).thenReturn(savedUser);

        UserDistributorVO userDistributorForDelete = new UserDistributorVO();
        List<UserDistributorVO> distributors =  Arrays.asList(new UserDistributorVO[]{userDistributorForDelete}); // when exist previous distributors for delete
        when(userDistributorRepository.findByUser(anyLong())).thenReturn(distributors);
        when(helper.isCsrOrApprover(eq(RoleEnum.APPROVER))).thenReturn(true);
        when(roleRepository.findByCode(anyString())).thenReturn(roleVO); // return null, not exist
        aSpy.createUpdateUserRole(userRoleDTO);

        verify(userRepository).save(Matchers.any(UserVO.class));
        verify(userDistributorRepository).delete(anyListOf(UserDistributorVO.class));
        verify(userDistributorRepository).flush();
        verify(distributorRepository).findByDistributorCode(anyString());
        verify(userDistributorRepository).save(anyListOf(UserDistributorVO.class));
    }

    @Test
    public void removeUserRole_WhenUserInputIsNull() throws Exception {
        assertFalse(unit.removeUserRole(null));
    }

    @Test
    public void removeUserRole_WhenUserNotFound() throws Exception {

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setIdUser(1L);

        // user exist to update
        UserVO userVO = null;
        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);

        assertFalse(unit.removeUserRole(userRoleDTO));
    }

    @Test
    public void removeUserRole_Marketing() throws Exception {

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setIdUser(1L);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.MARKETING.getCode());

        UserVO userVO = new UserVO();
        userVO.setRoleVO(roleVO);
        userVO.setWfApprovalMemberVOs(new ArrayList<WFApprovalMemberVO>());
        userVO.setUserDistributorVOs(new HashSet<UserDistributorVO>());


        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);
        assertTrue(unit.removeUserRole(userRoleDTO));

        verify(userRepository).delete(Matchers.any(UserVO.class));
        verify(userRepository).flush();

    }

    @Test
    public void removeUserRole_CSR() throws Exception {

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setIdUser(1L);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.CSR.getCode());

        UserVO userVO = new UserVO();
        userVO.setRoleVO(roleVO);

        userVO.setWfApprovalMemberVOs(new ArrayList<WFApprovalMemberVO>());
        userVO.setUserDistributorVOs(new HashSet<UserDistributorVO>());
        when(helper.isCsrOrApprover(eq(RoleEnum.CSR))).thenReturn(true);
        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);
        assertTrue(unit.removeUserRole(userRoleDTO));

        verify(userRepository).delete(Matchers.any(UserVO.class));
        verify(userRepository).flush();
    }

    @Test
    public void removeUserRole_APPROVER() throws Exception {

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setIdUser(1L);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.APPROVER.getCode());

        UserVO userVO = new UserVO();
        userVO.setRoleVO(roleVO);

        userVO.setWfApprovalMemberVOs(new ArrayList<WFApprovalMemberVO>());
        userVO.setUserDistributorVOs(new HashSet<UserDistributorVO>());
        when(helper.isCsrOrApprover(eq(RoleEnum.APPROVER))).thenReturn(true);
        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);
        assertTrue(unit.removeUserRole(userRoleDTO));

        verify(userRepository).delete(Matchers.any(UserVO.class));
        verify(userRepository).flush();
    }

    @Test
    public void removeUserRole_RCD() throws Exception {

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setIdUser(1L);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RCD.getCode());

        UserVO userVO = new UserVO();
        userVO.setRoleVO(roleVO);

        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);
        assertFalse(unit.removeUserRole(userRoleDTO));
    }

    @Test
    public void removeUserRole_RBM() throws Exception {

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setIdUser(1L);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.RBM.getCode());

        UserVO userVO = new UserVO();
        userVO.setRoleVO(roleVO);

        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);
        assertFalse(unit.removeUserRole(userRoleDTO));
    }

    @Test(expected = UserNotAvailableForRemoveException.class)
    public void exception_removeUserRole_RBM_WhenExistMembersAssigned() throws Exception {

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setIdUser(1L);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.CSR.getCode());

        UserVO userVO = new UserVO();
        userVO.setRoleVO(roleVO);

        List<WFApprovalMemberVO> members = new ArrayList<WFApprovalMemberVO>();
        members.add(new WFApprovalMemberVO());
        userVO.setWfApprovalMemberVOs(members);
        userVO.setUserDistributorVOs(new HashSet<UserDistributorVO>());

        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);
        assertFalse(unit.removeUserRole(userRoleDTO));
    }

    @Test(expected = UserNotAvailableForRemoveException.class)
    public void exception_removeUserRole_CSR_WhenExistUserDistributorsAssigned() throws Exception {

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setIdUser(1L);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.CSR.getCode());

        UserVO userVO = new UserVO();
        userVO.setRoleVO(roleVO);

        Set<UserDistributorVO> userDistributors = new HashSet<UserDistributorVO>();
        userDistributors.add(new UserDistributorVO());
        userVO.setUserDistributorVOs(userDistributors);

        Collection<WFApprovalMemberVO> members = new ArrayList<WFApprovalMemberVO>();
        userVO.setWfApprovalMemberVOs(members);

        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);
        assertFalse(unit.removeUserRole(userRoleDTO));
    }

    @Test(expected = UserNotAvailableForRemoveException.class)
    public void exception_removeUserRole_APPROVER_WhenExistUserDistributorsAssigned() throws Exception {

        UserRoleDTO userRoleDTO = new UserRoleDTO();
        userRoleDTO.setIdUser(1L);

        RoleVO roleVO = new RoleVO();
        roleVO.setCode(RoleEnum.APPROVER.getCode());

        UserVO userVO = new UserVO();
        userVO.setRoleVO(roleVO);

        Set<UserDistributorVO> userDistributors = new HashSet<UserDistributorVO>();
        userDistributors.add(new UserDistributorVO());
        userVO.setUserDistributorVOs(userDistributors);

        Collection<WFApprovalMemberVO> members = new ArrayList<WFApprovalMemberVO>();
        userVO.setWfApprovalMemberVOs(members);

        when(userRepository.findByUserID(anyLong())).thenReturn(userVO);
        assertFalse(unit.removeUserRole(userRoleDTO));
    }

    @Test
    public void getListOfUserRoleByDistributorProfileId_WhenCommonRolesListIsNotEmpty_AndDistributorProfileIsNotNull() {

        List<UserVO> roles = new ArrayList<UserVO>();

        List<UserVO> commonRoles = Arrays.asList( new UserVO[]{new UserVO()});
        when(userRepository.findByRoleCodes(anyList())).thenReturn(commonRoles);

        roles.addAll(commonRoles);

        String distributorCode = "123456213";
        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setDistributorCode(distributorCode);
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);
        when(distributorProfileRepository.findOne(anyLong())).thenReturn(distributorProfileVO);

        UserVO userVO = new UserVO();
        when(mapper.map(distributorProfileVO, UserVO.class)).thenReturn(userVO);

        List<UserVO> rcdRoles = Arrays.asList( new UserVO[]{new UserVO()});
        when(userRepository.findByParametersWithOutUserId(userVO,null,distributorCode)).thenReturn(rcdRoles);

        roles.addAll(rcdRoles);

        List<UserVO> list = unit.getListOfUserByDistributorProfileId(1L);
        assertTrue(!list.isEmpty());
    }

}