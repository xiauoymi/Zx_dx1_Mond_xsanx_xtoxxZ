package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.service.UserService;
import com.monsanto.customerlink.core.service.exception.RCDNotFoundException;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.RoleVO;
import com.monsanto.customerlink.persistence.entities.UserVO;
import com.monsanto.customerlink.persistence.repositories.UserRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceImpl_UT {

    private UserService userService;

    @Mock
    UserRepository userRepository;

    List<UserVO> userVOList = new ArrayList<UserVO>();

    @Before
    public void setup() {
        userService = new UserServiceImpl(userRepository);
        for (int i = 0; i < 5; i++) {
            UserVO userVO = new UserVO();
            RoleVO roleVO = new RoleVO();
            userVO.setRoleVO(roleVO);
            userVOList.add(userVO);
        }
    }

    @Test
    public void userListIsReturnedWhenExistUsersInRepositoryForSpecificRoleAndSubregion() {

        reset(userRepository);
        when(userRepository.findByParameters(Matchers.<UserVO>any(), anyString())).thenReturn(userVOList);

        Assert.assertNotNull(userService.findUserBySubregionAndRole("", 1l));
    }

    @Test
    public void roleIsReturnedWhenExistAnUserInRepositoryByUserCode() {
        reset(userRepository);
        when(userRepository.findByParameters(Matchers.<UserVO>any(), anyString())).thenReturn(userVOList);
        Assert.assertNotNull(userService.findRoleByUserCode("1l"));
    }

    @Test
    public void roleIsReturnedWhenExistAnUserInRepositoryByUserName() {
        reset(userRepository);
        when(userRepository.findByParameters(Matchers.<UserVO>any(), anyString())).thenReturn(userVOList);

        Assert.assertNotNull(userService.findRoleByUserName("1"));
    }

    /*
    @Test
    public void nullIsReturnedForRoleWhenNotExistAnUserInRepository() {
        reset(userRepository);
        when(userRepository.findByParameters(Matchers.<UserVO>any())).thenReturn(new ArrayList<UserVO>());
        Assert.assertNull(userService.findRoleByUser(1l));
    }  */

    @Test(expected = IllegalArgumentException.class)
    public void throwsIllegalArgumentExceptionWhenMissingUserCodeParameter() {
        UserVO userVO = new UserVO();
        reset(userRepository);
        userService.saveUser(userVO, "", 1l);
    }

    @Test(expected = IllegalArgumentException.class)
    public void throwsIllegalArgumentExceptionWhenMissingSubregionCodeParameter() {
        UserVO userVO = new UserVO();
        userVO.setSapId("1l");
        reset(userRepository);
        userService.saveUser(userVO, null, 1l);
    }

    @Test(expected = IllegalArgumentException.class)
    public void throwsIllegalArgumentExceptionWhenMissingRoleCodeParameter() {
        UserVO userVO = new UserVO();
        userVO.setSapId("1l");
        reset(userRepository);
        userService.saveUser(userVO, "SREGCODE", null);
    }

    @Test
    public void saveUserWhenNotExistSimilarConfigurationInRepository() {
        UserVO userVO = new UserVO();
        userVO.setSapId("1l");
        reset(userRepository);
        when(userRepository.findByParameters(Matchers.<UserVO>any(), anyString())).thenReturn(new ArrayList<UserVO>());
        userService.saveUser(userVO, "SREGCODE", 1l);
    }

    @Test
    public void saveUserWhenExistSimilarConfigurationInRepository() {
        UserVO userVO = new UserVO();
        userVO.setSapId("1l");
        reset(userRepository);
        when(userRepository.findByParameters(Matchers.<UserVO>any(), anyString())).thenReturn(userVOList);
        userService.saveUser(userVO, "SREGCODE", 1l);
    }

    @Test(expected = RCDNotFoundException.class)
    public void throwsRCDNotFoundExceptionWhenTheRCDIsNotFoundInTheRepository() throws Exception {
        when(userRepository.findByParameters(Matchers.<UserVO>any(), anyString())).thenReturn(new ArrayList<UserVO>());

        DistributorConfigDTO distributorProfile = new DistributorConfigDTO();
        distributorProfile.setSalesOrgCode("MX20");
        distributorProfile.setDistChCode("80");
        distributorProfile.setSalesDivCode("17");
        distributorProfile.setSubRegionCode("AMXSUR");
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");
        distributorProfile.setDistributor(distributorDTO);

        userService.retrieveRCD("0003376712", distributorProfile);
    }

    @Test
    public void retrievesTheRCDFromTheRepositoryWhoseParametersMatches() throws Exception {
        final UserVO userVO = new UserVO();

        final List<UserVO> userVOs = new ArrayList<UserVO>();
        userVOs.add(userVO);
        when(userRepository.findByParameters(Matchers.<UserVO>any(), anyString())).thenReturn(userVOs);

        DistributorConfigDTO distributorProfile = new DistributorConfigDTO();
        distributorProfile.setSalesOrgCode("MX20");
        distributorProfile.setDistChCode("80");
        distributorProfile.setSalesDivCode("17");
        distributorProfile.setSubRegionCode("AMXSUR");
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");
        distributorProfile.setDistributor(distributorDTO);

        final UserVO rcdVO = userService.retrieveRCD("0003376712", distributorProfile);
        assertThat(rcdVO, is(notNullValue()));
    }

    @Test
    public void retrieveAllRCDs() throws Exception {
        when(userRepository.findByParameters(Matchers.<UserVO>any(),anyString())).thenReturn(new ArrayList<UserVO>());
        DistributorConfigDTO config = new DistributorConfigDTO();
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");
        config.setDistributor(distributorDTO);
        List<UserVO> representatives = userService.retrieveRCDs(config);
        assertThat(representatives, is(notNullValue()));
        assertThat(representatives.isEmpty(), is(Boolean.TRUE));
    }

    @Test
    public void retrieveRCDsByDistributorProfile() throws Exception {
        when(userRepository.findByParameters(Matchers.<UserVO>any(), anyString())).thenReturn(new ArrayList<UserVO>());

        final DistributorConfigDTO distributorProfile = new DistributorConfigDTO();
        distributorProfile.setSalesOrgCode("MX20");
        distributorProfile.setDistChCode("80");
        distributorProfile.setSalesDivCode("17");
        distributorProfile.setSubRegionCode("AMXSUR");
        DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("DISTRIBUTOR_CODE");
        distributorProfile.setDistributor(distributorDTO);
        List<UserVO> representatives = userService.retrieveRCDs(distributorProfile);
        assertThat(representatives, is(notNullValue()));
        assertThat(representatives.isEmpty(), is(Boolean.TRUE));
    }

    @Test
    public void retrieveCSRsByDistributor_NullListWhenIdDistributorIsNull() throws Exception {
        List<UserVO> users =  userService.retrieveUsersByDistributorAndRole(null, null);
        assertThat(users, is(nullValue()));
    }

    @Test
    public void retrieveCSRsByDistributor_NullListWhenIdDistributorIsNotNullAndRoleIsNull() throws Exception {
        List<UserVO> users =  userService.retrieveUsersByDistributorAndRole("DISTRIBUTOR_CODE",null);
        assertThat(users, is(nullValue()));
    }

    @Test
    public void retrieveCSRsByDistributor_NullListWhenIdDistributorIsEmpty() throws Exception {
        List<UserVO> users =  userService.retrieveUsersByDistributorAndRole("DISTRIBUTOR_CODE",RoleEnum.CSR);
        assertThat(users.isEmpty(),is(true));
    }

    @Test
    public void retrieveCSRsByDistributor_NonEmptyList() throws Exception {
        String idDistributor = "ID_DISTRIBUTOR";
        List<UserVO> usersFromRepository = new ArrayList<UserVO>();
        usersFromRepository.add(new UserVO());
        when(userRepository.findByRoleAndDistributorCode(Matchers.eq(RoleEnum.CSR.getCode()), Matchers.eq(idDistributor))).thenReturn(usersFromRepository);
        List<UserVO> users =  userService.retrieveUsersByDistributorAndRole(idDistributor,RoleEnum.CSR);
        assertThat(users, is(notNullValue()));
    }
}