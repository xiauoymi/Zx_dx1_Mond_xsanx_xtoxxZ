package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.dto.messages.WFSpecialOrderMessageVO;
import com.monsanto.customerlink.core.service.util.CustomerLinkCoreConstants;
import com.monsanto.customerlink.persistence.entities.RoleVO;
import com.monsanto.customerlink.persistence.entities.UserVO;
import com.monsanto.customerlink.persistence.repositories.UserRepository;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class WFApprovalServiceHelper_UT {

    @Mock
    private UserRepository userRepository;

    @Mock
    private WFApprovalServiceHelperImpl unit;

    @Before
    public void before() {
        reset(userRepository);
        unit = new WFApprovalServiceHelperImpl(userRepository);
    }

    @Test(expected = RuntimeException.class)
    public void exception_WhenMessageMapNotFound() {
        Map<String, Object> map = new HashMap<String, Object>();
        unit.getMessageMapFromFinalMap(map);
    }

    @Test
    public void getMessageMapFromFinalMap() {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(CustomerLinkCoreConstants.DISTRIBUTOR_CONFIG_KEY_MAP_MESSAGE,new HashMap<String, Object>());
        assertThat(unit.getMessageMapFromFinalMap(map), is(notNullValue()));
    }

    @Test(expected = RuntimeException.class)
    public void exception_WhenDistributorConfigNotFound() {
        Map<String, Object> map = new HashMap<String, Object>();
        unit.getDistributorConfigFromFinalMap(map);
    }

    @Test
    public void getDistributorConfigFromFinalMap() {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(CustomerLinkCoreConstants.DISTRIBUTOR_CONFIG_KEY_MESSAGE,new DistributorConfigDTO());
        assertThat(unit.getDistributorConfigFromFinalMap(map), is(notNullValue()));
    }

    @Test
    public void notUpdate_WhenUserIsNull() {

        WFSpecialOrderMessageVO msg = new WFSpecialOrderMessageVO();
        Map<String, Object> messageMap = new HashMap<String, Object>();
        messageMap.put(CustomerLinkCoreConstants.NOTIFICATION_KEY_MESSAGE,msg);

        Map<String, Object> map = new HashMap<String, Object>();
        map.put(CustomerLinkCoreConstants.DISTRIBUTOR_CONFIG_KEY_MAP_MESSAGE,messageMap);

        Long userId = null;
        unit.updateFinalMapWithUser(userId,map);

        assertThat(msg.getUserName(), is(nullValue()));
        assertThat(msg.getUserRole(),is(nullValue()));
    }

    @Test(expected = RuntimeException.class)
    public void exception_WhenUserIsNotNull_AndUserNotFound() {

        WFSpecialOrderMessageVO msg = new WFSpecialOrderMessageVO();
        Map<String, Object> messageMap = new HashMap<String, Object>();
        messageMap.put(CustomerLinkCoreConstants.NOTIFICATION_KEY_MESSAGE,msg);

        Map<String, Object> map = new HashMap<String, Object>();
        map.put(CustomerLinkCoreConstants.DISTRIBUTOR_CONFIG_KEY_MAP_MESSAGE,messageMap);

        UserVO user = null;
        when(userRepository.findByUserID(anyLong())).thenReturn(user);

        Long userId = 12345L;
        unit.updateFinalMapWithUser(userId,map);
    }

    @Test
    public void updateFinalMapWithUser() {

        WFSpecialOrderMessageVO msg = new WFSpecialOrderMessageVO();
        Map<String, Object> messageMap = new HashMap<String, Object>();
        messageMap.put(CustomerLinkCoreConstants.NOTIFICATION_KEY_MESSAGE,msg);

        Map<String, Object> map = new HashMap<String, Object>();
        map.put(CustomerLinkCoreConstants.DISTRIBUTOR_CONFIG_KEY_MAP_MESSAGE,messageMap);

        UserVO user = new UserVO();
        user.setUserName("USER_NAME");
        RoleVO roleVO = new RoleVO();
        roleVO.setDescription("ROLE_DESCRIPTION");
        user.setRoleVO(roleVO);
        when(userRepository.findByUserID(anyLong())).thenReturn(user);

        Long userId = 12345L;
        unit.updateFinalMapWithUser(userId,map);

        assertThat(msg.getUserName(), is(notNullValue()));
        assertThat(msg.getUserRole(),is(notNullValue()));
    }
}