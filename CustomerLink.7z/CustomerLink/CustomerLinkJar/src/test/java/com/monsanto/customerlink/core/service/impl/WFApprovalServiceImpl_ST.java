package com.monsanto.customerlink.core.service.impl;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Collection;

@ContextConfiguration(locations={"classpath:applicationContext-core-test.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("junit")
@Ignore
public class WFApprovalServiceImpl_ST {

    @Autowired
    private WFApprovalSpecialOrderServiceImpl wfApprovalSpecialOrderService;

    @Test
    @Ignore
    public void createWorkFlowApproval() throws Exception {
        Long businessEntityId = 254L;
        wfApprovalSpecialOrderService.createWorkFlowApproval(businessEntityId);
    }

    @Test
    @Ignore
    public void obtainListOfBusinessEntityId() throws Exception {
        Long userId = 2L;
        Collection<Long> listOfBusinessEntityId = wfApprovalSpecialOrderService.obtainApprovalsPendingBusinessByUser(userId);
        System.out.println(listOfBusinessEntityId);
    }

    @Test
    @Ignore
    public void approveWorkflowByUser() throws Exception {
        Long businessEntityId = 254L;
        Long userId = 12L;
        boolean approved = wfApprovalSpecialOrderService.approveWorkflowByUser(businessEntityId, userId);
        System.out.println(approved);
    }

    @Test
    @Ignore
    public void rejectWorkflowByUser() throws Exception {
        Long businessEntityId = 254L;
        Long userId = 18L;
        boolean rejected = wfApprovalSpecialOrderService.rejectWorkflowByUser(businessEntityId, userId);
        System.out.println(rejected);
    }
}