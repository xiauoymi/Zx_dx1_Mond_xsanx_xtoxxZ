package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.service.UserManagementService;
import com.monsanto.customerlink.core.service.WFApprovalServiceHelper;
import com.monsanto.customerlink.core.service.exception.WFApprovalAlreadyExistException;
import com.monsanto.customerlink.core.service.exception.WFApprovalMissingConfigurationException;
import com.monsanto.customerlink.core.service.exception.WFApprovalMissingUsersMembersConfigurationException;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.core.service.util.WFApprovalStatusEnum;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.*;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@ContextConfiguration(locations={"classpath:WFApprovalServiceImpl_UT.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class WFApprovalServiceImpl_UT {

    @Autowired
    private WFApprovalRepository wfApprovalRepository;

    @Autowired
    private WFApprovalTypeRepository wfApprovalTypeRepository;

    @Autowired
    private WFApprovalMemberRepository wfApprovalMemberRepository;

    @Autowired
    private NotificationSender emailNotificationSender;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private WFApprovalSpecialOrderServiceImpl unit;

    @Autowired
    private SubRegionRepository subRegionRepository;

    @Autowired
    private UserManagementService userManagementService;

    @Autowired
    private OrderDetailRepository orderDetailRepository;

    @Autowired
    private WFApprovalServiceHelper helper;

    @Before
    public void before() {
        reset(wfApprovalRepository,wfApprovalTypeRepository,wfApprovalMemberRepository,emailNotificationSender,orderRepository,subRegionRepository,userManagementService,orderDetailRepository,helper);
        unit = new WFApprovalSpecialOrderServiceImpl(wfApprovalRepository,wfApprovalTypeRepository,wfApprovalMemberRepository,emailNotificationSender, orderRepository,subRegionRepository,userManagementService,orderDetailRepository,helper);
    }

    @Test
    public void exceptionOnCreateWorkFlowApprovalWhenInputParametersNotValid(){
        try{
            unit.createWorkFlowApproval(null);
        }catch (Exception e){
            assertTrue(e instanceof IllegalArgumentException);
        }
    }

    @Test(expected = WFApprovalMissingConfigurationException.class)
    public void exceptionOnOnCreateWorkFlowApprovalWhen_AlreadyExistApprovalWorkFlow_NullList() throws Exception{
        when(wfApprovalRepository.findByBusinessEntityIdAndStatusAndType(anyLong(), anyList(),anyInt())).thenReturn(null);
        unit.createWorkFlowApproval(999L);
    }

    @Test(expected = WFApprovalAlreadyExistException.class)
    public void exceptionOnOnCreateWorkFlowApprovalWhen_AlreadyExistApprovalWorkFlow_EmptyList() throws Exception{
        List<WFApprovalVO> lisOfApprovalNotEmpty = Arrays.asList(new WFApprovalVO[]{new WFApprovalVO()});
        when(wfApprovalRepository.findByBusinessEntityIdAndStatusAndType(anyLong(), anyList(),anyInt())).thenReturn(lisOfApprovalNotEmpty);
        unit.createWorkFlowApproval(999L);
    }

    @Test(expected = WFApprovalMissingConfigurationException.class)
    public void exceptionOnOnCreateWorkFlowApprovalWhen_ApprovalMissingConfiguration_TypeIsNull() throws Exception{

        when(wfApprovalRepository.findByBusinessEntityIdAndStatusAndType(anyLong(), anyList(),anyInt())).thenReturn(new ArrayList<WFApprovalVO>());
        when(wfApprovalTypeRepository.findOne(Matchers.<Integer>any())).thenReturn(null);

        unit.createWorkFlowApproval(999L);
    }

    @Test(expected = WFApprovalMissingConfigurationException.class)
    public void exceptionOnOnCreateWorkFlowApprovalWhen_ApprovalMissingConfiguration_ApprovalHierarchyIsNull() throws Exception{

        WFApprovalTypeVO approvalTypeVO = new WFApprovalTypeVO();
        approvalTypeVO.setWfApprovalHierarchyVOs(null);

        when(wfApprovalRepository.findByBusinessEntityIdAndStatusAndType(anyLong(), anyList(), anyInt())).thenReturn(null);
        when(wfApprovalTypeRepository.findOne(Matchers.<Integer>any())).thenReturn(approvalTypeVO);

        unit.createWorkFlowApproval(999L);
    }

    @Test(expected = WFApprovalMissingConfigurationException.class)
    public void exceptionOnOnCreateWorkFlowApprovalWhen_ApprovalMissingConfiguration_ApprovalHierarchyIsEmpty() throws Exception{

        WFApprovalTypeVO approvalTypeVO = new WFApprovalTypeVO();
        approvalTypeVO.setWfApprovalHierarchyVOs(new HashSet<WFApprovalHierarchyVO>());

        when(wfApprovalRepository.findByBusinessEntityIdAndStatusAndType(anyLong(), anyList(),anyInt())).thenReturn(new ArrayList<WFApprovalVO>());
        when(wfApprovalTypeRepository.findOne(Matchers.<Integer>any())).thenReturn(approvalTypeVO);

        unit.createWorkFlowApproval(999L);
    }

    @Test(expected = WFApprovalMissingUsersMembersConfigurationException.class)
    public void exceptionOnOnCreateWorkFlowApprovalWhen_MissingUsersMembersConfiguration_NullList() throws Exception{

        WFApprovalTypeVO approvalTypeVO = new WFApprovalTypeVO();
        approvalTypeVO.setWfApprovalHierarchyVOs(this.getSetOfHierarchy());

        when(wfApprovalRepository.findByBusinessEntityIdAndStatusAndType(anyLong(), anyList(),anyInt())).thenReturn(null);
        when(wfApprovalTypeRepository.findOne(Matchers.<Integer>any())).thenReturn(approvalTypeVO);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(null);

        unit.createWorkFlowApproval(999L);
    }

    @Test(expected = WFApprovalMissingUsersMembersConfigurationException.class)
    public void exceptionOnOnCreateWorkFlowApprovalWhen_MissingUsersMembersConfiguration_EmptyList() throws Exception{

        WFApprovalTypeVO approvalTypeVO = new WFApprovalTypeVO();
        approvalTypeVO.setWfApprovalHierarchyVOs(this.getSetOfHierarchy());

        when(wfApprovalRepository.findByBusinessEntityIdAndStatusAndType(anyLong(), anyList(),anyInt())).thenReturn(null);
        when(wfApprovalTypeRepository.findOne(Matchers.<Integer>any())).thenReturn(approvalTypeVO);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(new ArrayList<UserVO>());

        unit.createWorkFlowApproval(999L);
    }

    @Test(expected = WFApprovalMissingUsersMembersConfigurationException.class)
    public void exceptionOnOnCreateWorkFlowApproval_WhenListOfUsersIsEmpty() throws Exception{

        WFApprovalTypeVO approvalTypeVO = new WFApprovalTypeVO();
        approvalTypeVO.setWfApprovalHierarchyVOs(this.getSetOfHierarchy());

        when(wfApprovalRepository.findByBusinessEntityIdAndStatusAndType(anyLong(), anyList(),anyInt())).thenReturn(null);
        when(wfApprovalTypeRepository.findOne(Matchers.<Integer>any())).thenReturn(approvalTypeVO);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(null);
        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(new ArrayList<UserVO>());

        assertTrue(unit.createWorkFlowApproval(999L));
        verify(wfApprovalRepository).save(any(WFApprovalVO.class));
    }

    @Test(expected = WFApprovalMissingUsersMembersConfigurationException.class)
    public void exceptionOnOnCreateWorkFlowApproval_WhenListOfUsersIsNotEmpty_AndNotContainAllRolesNested() throws Exception{

        WFApprovalTypeVO approvalTypeVO = new WFApprovalTypeVO();
        approvalTypeVO.setWfApprovalHierarchyVOs(this.getSetOfHierarchy());

        when(wfApprovalRepository.findByBusinessEntityIdAndStatusAndType(anyLong(), anyList(),anyInt())).thenReturn(null);
        when(wfApprovalTypeRepository.findOne(Matchers.<Integer>any())).thenReturn(approvalTypeVO);

        RoleVO r1 = new RoleVO();
        r1.setCode(RoleEnum.UNDEFINED_ROLE.getCode()); // role not found

        UserVO u1 = new UserVO();
        u1.setRoleVO(r1);

        List<UserVO> listOfUsersFromRepository = new ArrayList<UserVO>();
        listOfUsersFromRepository.add(u1);


        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setDistributorCode("0123456789");

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);
        distributorProfileVO.setDistributorProfileId(1L);

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(listOfUsersFromRepository);

        assertTrue(unit.createWorkFlowApproval(999L));
        verify(wfApprovalRepository).save(any(WFApprovalVO.class));
    }

    @Test
    public void exceptionOnOnCreateWorkFlowApproval_WhenListOfUsersIsNotEmpty_AndContainAllRoles() throws Exception{

        WFApprovalTypeVO approvalTypeVO = new WFApprovalTypeVO();
        approvalTypeVO.setWfApprovalHierarchyVOs(this.getSetOfHierarchy());

        when(wfApprovalRepository.findByBusinessEntityIdAndStatusAndType(anyLong(), anyList(),anyInt())).thenReturn(null);
        when(wfApprovalTypeRepository.findOne(Matchers.<Integer>any())).thenReturn(approvalTypeVO);

        RoleVO r1 = new RoleVO();
        r1.setCode(RoleEnum.UNDEFINED_ROLE.getCode()); // role not found

        UserVO u1 = new UserVO();
        u1.setRoleVO(r1);

        List<UserVO> listOfUsersFromRepository = new ArrayList<UserVO>();
        listOfUsersFromRepository.add(u1);

        RoleVO r2 = new RoleVO();
        r2.setCode(RoleEnum.CSR.getCode()); // role not found

        UserVO u2 = new UserVO();
        u2.setRoleVO(r2);
        listOfUsersFromRepository.add(u2);

        DistributorVO distributorVO = new DistributorVO();
        distributorVO.setDistributorCode("0123456789");

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);
        distributorProfileVO.setDistributorProfileId(1L);

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(listOfUsersFromRepository);

        assertTrue(unit.createWorkFlowApproval(999L));
        verify(wfApprovalRepository).save(any(WFApprovalVO.class));
    }

    @Test
    public void obtainApprovalsPendingBusinessByUserWhen_InputParametersNotValid() throws Exception{

        Collection<Long> list = unit.obtainApprovalsPendingBusinessByUser(null);
        assertTrue(list.isEmpty());

        list = unit.obtainApprovalsPendingBusinessByUser(null);
        assertTrue(list.isEmpty());

        list = unit.obtainApprovalsPendingBusinessByUser(1L);
        assertTrue(list.isEmpty());
    }

    @Test
    public void obtainApprovalsPendingBusinessByUserWhen_ApprovalListIsEmpty() throws Exception{
        when(wfApprovalRepository.findBusinessIdsByParameters(Matchers.<Integer>any(), anyList(), anyInt(),anyLong())).thenReturn(new ArrayList<Long>());
        Collection<Long> list = unit.obtainApprovalsPendingBusinessByUser(1L);
        assertTrue(list.isEmpty());
    }

    @Test
    public void obtainApprovalsPendingBusinessByUserWhen_ApprovalListNotEmpty() throws Exception{
        List<Long> approvals =  Arrays.asList(new Long[]{539L,812L});
        when(wfApprovalRepository.findBusinessIdsByParameters(Matchers.<Integer>any(), anyList(), anyInt(),anyLong())).thenReturn(approvals);
        Collection<Long> list = unit.obtainApprovalsPendingBusinessByUser(1L);
        assertTrue(!list.isEmpty());
    }

    @Test
    public void approveWorkflowByUser_InputParametersNotValid() throws Exception{
        assertFalse(unit.approveWorkflowByUser(null, null));
        assertFalse(unit.approveWorkflowByUser(null, 1L));
        assertFalse(unit.approveWorkflowByUser(1L,null));
    }

    @Test
    public void approveWorkflowByUserWhen_ApprovalListIsEmpty() throws Exception{
        List<Long> approvals =  Arrays.asList(new Long[]{});
        when(wfApprovalRepository.findBusinessIdsByParameters(anyInt(),anyList(),anyInt(),anyLong())).thenReturn(approvals);
        assertFalse(unit.approveWorkflowByUser(1L,1L));
    }

    @Test
    public void approveWorkflowByUserWhen_NotAllMembersApproved() throws Exception{

        WFApprovalHierarchyVO h1 = new WFApprovalHierarchyVO();
        h1.setHierarchyOrder(2);
        WFApprovalTypeVO wft1 = new WFApprovalTypeVO();

        Set<WFApprovalHierarchyVO> set = new HashSet<WFApprovalHierarchyVO>();
        set.add(h1);

        wft1.setWfApprovalHierarchyVOs(set);

        WFApprovalVO ap1 = new WFApprovalVO();
        ap1.setWfApprovalTypeVO(wft1);
        ap1.setStatus(WFApprovalStatusEnum.PENDING_APPROVAL.id());
        ap1.setBusinessEntityId(539L);
        ap1.setWfApprovalMemberVOs(this.getMembersOfWfApprovalNotAllApproved());
        List<WFApprovalVO> approvals =  Arrays.asList(new WFApprovalVO[]{ap1});

        when(wfApprovalRepository.findByParameters(anyLong(), anyList(), anyInt(), anyInt(), anyLong())).thenReturn(approvals);
        assertTrue(unit.approveWorkflowByUser(1L,1L));
        verify(wfApprovalMemberRepository).save(anyListOf(WFApprovalMemberVO.class));
        verify(wfApprovalRepository).save(any(WFApprovalVO.class));
    }

    @Test
    public void approveWorkflowByUserWhen_NotAllMembersApproved_WhenIdMessageApproveIsNotNull() throws Exception{

        WFApprovalHierarchyVO h1 = new WFApprovalHierarchyVO();
        h1.setHierarchyOrder(1);
        h1.setIdApprovalMessage(1);
        WFApprovalTypeVO wft1 = new WFApprovalTypeVO();

        Set<WFApprovalHierarchyVO> set = new HashSet<WFApprovalHierarchyVO>();
        set.add(h1);

        wft1.setWfApprovalHierarchyVOs(set);

        WFApprovalVO ap1 = new WFApprovalVO();
        ap1.setWfApprovalTypeVO(wft1);
        ap1.setStatus(WFApprovalStatusEnum.PENDING_APPROVAL.id());
        ap1.setBusinessEntityId(539L);
        ap1.setWfApprovalMemberVOs(this.getMembersOfWfApprovalNotAllApproved());
        List<WFApprovalVO> approvals =  Arrays.asList(new WFApprovalVO[]{ap1});

        when(wfApprovalRepository.findByParameters(anyLong(), anyList(), anyInt(), anyInt(), anyLong())).thenReturn(approvals);

        WFApprovalSpecialOrderServiceImpl aSpy = Mockito.spy(unit);
        Mockito.doReturn(null).when((WFApprovalSpecialOrderServiceImpl)aSpy).buildNotificationOfApproval( Arrays.asList(new String[]{"user@monsanto.com"}), 1, new HashMap<String, Object>());

        assertTrue(aSpy.approveWorkflowByUser(1L, 1L));
        verify(wfApprovalMemberRepository).save(anyListOf(WFApprovalMemberVO.class));
        verify(wfApprovalRepository).save(any(WFApprovalVO.class));
    }

    @Test
    public void approveWorkflowByUserWhen_AllMembersApproved() throws Exception{
        WFApprovalVO ap1 = new WFApprovalVO();
        ap1.setStatus(WFApprovalStatusEnum.PENDING_APPROVAL.id());
        ap1.setBusinessEntityId(539L);
        ap1.setWfApprovalMemberVOs(this.getMembersOfWfApprovalAllApproved());
        List<WFApprovalVO> approvals =  Arrays.asList(new WFApprovalVO[]{ap1});

        when(wfApprovalRepository.findByParameters(anyLong(), anyList(), anyInt(), anyInt(), anyLong())).thenReturn(approvals);
        assertTrue(unit.approveWorkflowByUser(1L,1L));
        verify(wfApprovalMemberRepository).save(anyListOf(WFApprovalMemberVO.class));
        verify(wfApprovalRepository).save(any(WFApprovalVO.class));
    }

    @Test
    public void rejectWorkflowByUserWhen_InputParametersNotValid() throws Exception{
        assertFalse(unit.rejectWorkflowByUser(null,null));
        assertFalse(unit.rejectWorkflowByUser(null, 1L));
        assertFalse(unit.rejectWorkflowByUser(1L,null));
    }

    @Test
    public void rejectWorkflowByUserWhen_ApprovalListIsEmpty() throws Exception{
        List<Long> approvals =  Arrays.asList(new Long[]{});
        when(wfApprovalRepository.findBusinessIdsByParameters(anyInt(),anyList(),anyInt(),anyLong())).thenReturn(approvals);
        assertFalse(unit.rejectWorkflowByUser(1L,1L));
    }

    @Test
    public void rejectWorkflowByUserWhen_NotAllMembersApproved() throws Exception{

        WFApprovalHierarchyVO h1 = new WFApprovalHierarchyVO();
        h1.setHierarchyOrder(1);

        Set<WFApprovalHierarchyVO> set = new HashSet<WFApprovalHierarchyVO>();
        set.add(h1);

        WFApprovalTypeVO wft1 = new WFApprovalTypeVO();
        wft1.setWfApprovalHierarchyVOs(set);

        WFApprovalVO ap1 = new WFApprovalVO();

        ap1.setWfApprovalTypeVO(wft1);

        ap1.setStatus(WFApprovalStatusEnum.PENDING_APPROVAL.id());
        ap1.setBusinessEntityId(539L);
        ap1.setWfApprovalMemberVOs(this.getMembersOfWfApprovalNotAllApproved());
        List<WFApprovalVO> approvals =  Arrays.asList(new WFApprovalVO[]{ap1});

        when(wfApprovalRepository.findByParameters(anyLong(), anyList(), anyInt(), anyInt(), anyLong())).thenReturn(approvals);
        assertTrue(unit.rejectWorkflowByUser(1L,1L));
        verify(wfApprovalMemberRepository).save(any(WFApprovalMemberVO.class));
        verify(wfApprovalRepository).save(any(WFApprovalVO.class));
    }

    @Test
    public void rejectWorkflowByUserWhen_NotAllMembers_WhenIdMessageIsNull() throws Exception{

        WFApprovalHierarchyVO h1 = new WFApprovalHierarchyVO();
        h1.setHierarchyOrder(1);

        Set<WFApprovalHierarchyVO> set = new HashSet<WFApprovalHierarchyVO>();
        set.add(h1);

        WFApprovalTypeVO wft1 = new WFApprovalTypeVO();
        wft1.setWfApprovalHierarchyVOs(set);

        WFApprovalVO ap1 = new WFApprovalVO();

        ap1.setWfApprovalTypeVO(wft1);

        ap1.setStatus(WFApprovalStatusEnum.PENDING_APPROVAL.id());
        ap1.setBusinessEntityId(539L);
        ap1.setWfApprovalMemberVOs(this.getMembersOfWfApprovalNotAllApproved());
        List<WFApprovalVO> approvals =  Arrays.asList(new WFApprovalVO[]{ap1});

        when(wfApprovalRepository.findByParameters(anyLong(), anyList(), anyInt(), anyInt(), anyLong())).thenReturn(approvals);
        assertTrue(unit.rejectWorkflowByUser(1L,1L));
        verify(wfApprovalMemberRepository).save(any(WFApprovalMemberVO.class));
        verify(wfApprovalRepository).save(any(WFApprovalVO.class));
    }

    @Test
    public void rejectWorkflowByUserWhen_NotAllMembers_WhenIdMessageIsNotNull() throws Exception{

        WFApprovalHierarchyVO h1 = new WFApprovalHierarchyVO();
        h1.setHierarchyOrder(1);
        h1.setIdRejectionMessage(2); //

        Set<WFApprovalHierarchyVO> set = new HashSet<WFApprovalHierarchyVO>();
        set.add(h1);

        WFApprovalTypeVO wft1 = new WFApprovalTypeVO();
        wft1.setWfApprovalHierarchyVOs(set);

        WFApprovalVO ap1 = new WFApprovalVO();

        ap1.setWfApprovalTypeVO(wft1);

        ap1.setStatus(WFApprovalStatusEnum.PENDING_APPROVAL.id());
        ap1.setBusinessEntityId(539L);
        ap1.setWfApprovalMemberVOs(this.getMembersOfWfApprovalNotAllApproved());
        List<WFApprovalVO> approvals =  Arrays.asList(new WFApprovalVO[]{ap1});

        when(wfApprovalRepository.findByParameters(anyLong(), anyList(), anyInt(), anyInt(), anyLong())).thenReturn(approvals);
        assertTrue(unit.rejectWorkflowByUser(1L,1L));
        verify(wfApprovalMemberRepository).save(any(WFApprovalMemberVO.class));
        verify(wfApprovalRepository).save(any(WFApprovalVO.class));
    }


    private Collection<WFApprovalMemberVO> getMembersOfWfApprovalNotAllApproved() {


        WFApprovalMemberVO m1 = new WFApprovalMemberVO();
        m1.setStatus(WFApprovalStatusEnum.PENDING_APPROVAL.id());
        m1.setHierarchyOrder(1);
        m1.setUserVO(getUsers().get(0));


        WFApprovalMemberVO m2 = new WFApprovalMemberVO();
        m2.setStatus(WFApprovalStatusEnum.PENDING_PREVIOUS_APPROVAL.id());
        m2.setHierarchyOrder(2);
        m2.setUserVO(getUsers().get(1));

        WFApprovalMemberVO m3 = new WFApprovalMemberVO();
        m3.setStatus(WFApprovalStatusEnum.PENDING_PREVIOUS_APPROVAL.id());
        m3.setHierarchyOrder(3);
        m3.setUserVO(getUsers().get(2));

        Collection<WFApprovalMemberVO> members = Arrays.asList(new WFApprovalMemberVO[]{m1,m2,m3});
        return members;
    }

    private Collection<WFApprovalMemberVO> getMembersOfWfApprovalAllApproved() {

        UserVO u1 = new UserVO();
        u1.setEmail("user1@monsanto.com");

        UserVO u2 = new UserVO();
        u2.setEmail("user1@monsanto.com");

        UserVO u3 = new UserVO();
        u3.setEmail("user1@monsanto.com");


        WFApprovalMemberVO m1 = new WFApprovalMemberVO();
        m1.setStatus(WFApprovalStatusEnum.APPROVED.id());
        m1.setHierarchyOrder(1);
        m1.setUserVO(u1);

        WFApprovalMemberVO m2 = new WFApprovalMemberVO();
        m2.setStatus(WFApprovalStatusEnum.APPROVED.id());
        m2.setHierarchyOrder(2);
        m2.setUserVO(u2);

        WFApprovalMemberVO m3 = new WFApprovalMemberVO();
        m3.setStatus(WFApprovalStatusEnum.PENDING_APPROVAL.id());
        m3.setHierarchyOrder(3);
        m3.setUserVO(u3);

        Collection<WFApprovalMemberVO> members = Arrays.asList(new WFApprovalMemberVO[]{m1,m2,m3});
        return members;
    }

    private List<UserVO> getUsers() {
        UserVO u1 = new UserVO();
        u1.setEmail("u1@email.com");
        UserVO u2 = new UserVO();
        u2.setEmail("u1@email.com");
        UserVO u3 = new UserVO();
        u3.setEmail("u1@email.com");
        List<UserVO> users =  Arrays.asList(new UserVO[]{u1,u2,u3});
        return users;
    }

    private Set<WFApprovalHierarchyVO> getSetOfHierarchy() {

        Set<WFApprovalHierarchyVO> approvalHierarchyVOSet = new HashSet<WFApprovalHierarchyVO>();
        RoleVO r1 = new RoleVO();
        r1.setCode(RoleEnum.CSR.getCode());

        WFApprovalHierarchyVO h1 = new WFApprovalHierarchyVO();
        h1.setRoleHierarchy(r1);
        h1.setHierarchyOrder(1);

        RoleVO r2 = new RoleVO();
        r2.setCode(RoleEnum.UNDEFINED_ROLE.getCode());

        WFApprovalHierarchyVO h2 = new WFApprovalHierarchyVO();
        h2.setRoleHierarchy(r2);
        h2.setHierarchyOrder(2);

        approvalHierarchyVOSet.add(h1);
        approvalHierarchyVOSet.add(h2);

        return approvalHierarchyVOSet;
    }
}