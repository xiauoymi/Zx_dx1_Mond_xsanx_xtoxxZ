package com.monsanto.customerlink.core.service.impl;

import com.monsanto.customerlink.core.email.NotificationSender;
import com.monsanto.customerlink.core.service.UserManagementService;
import com.monsanto.customerlink.core.service.WFApprovalServiceHelper;
import com.monsanto.customerlink.core.service.util.BrandEnum;
import com.monsanto.customerlink.core.service.util.RoleEnum;
import com.monsanto.customerlink.persistence.entities.*;
import com.monsanto.customerlink.persistence.repositories.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class WFApprovalSpecialOrderServiceImpl_UT {

    @Mock
    private WFApprovalRepository wfApprovalRepository;

    @Mock
    private WFApprovalTypeRepository wfApprovalTypeRepository;

    @Mock
    private WFApprovalMemberRepository wfApprovalMemberRepository;

    @Mock
    private NotificationSender notificationSender;

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private WFApprovalSpecialOrderServiceImpl unit;

    @Mock
    private SubRegionRepository subRegionRepository;

    @Mock
    private UserManagementService userManagementService;

    @Mock
    private OrderDetailRepository orderDetailRepository;

    @Mock
    private WFApprovalServiceHelper helper;

    @Before
    public void before() {
        reset(wfApprovalRepository,wfApprovalTypeRepository,wfApprovalMemberRepository,notificationSender,orderRepository,subRegionRepository,userManagementService,orderDetailRepository,helper);
        unit = new WFApprovalSpecialOrderServiceImpl(wfApprovalRepository,wfApprovalTypeRepository,wfApprovalMemberRepository,notificationSender, orderRepository,subRegionRepository,userManagementService,orderDetailRepository,helper);
    }

    @Test
    public void buildNotificationOfApproval_OrderIsNull()  {
        when(orderRepository.findByOrderId(anyLong())).thenReturn(null);
        assertTrue( (unit.buildObjectMessageNotificationOfApproval(999L)).isEmpty() );
    }

    @Test
    public void buildNotificationOfApproval_OrderNotNullAndDistributorProfileIsNull()  {
        when(orderRepository.findByOrderId(anyLong())).thenReturn(new OrderVO());
        assertTrue( (unit.buildObjectMessageNotificationOfApproval(999L)).isEmpty() );
    }

    @Test
    public void buildNotificationOfApproval_OrderNotNullAndDistributorVOIsNull()  {

        DistributorVO distributorVO = null;

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);;

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);
        assertTrue( (unit.buildObjectMessageNotificationOfApproval(999L)).isEmpty() );
    }

    @Test
    public void buildNotificationOfApproval_WhenSubRegionIsNull()  {

        DistributorVO distributorVO = new DistributorVO();

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);;

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);
        assertTrue(!(unit.buildObjectMessageNotificationOfApproval(999L)).isEmpty() );
        verify(subRegionRepository).findBySubRegionCode(anyString());
    }


    @Test
    public void buildNotificationOfApproval_WhenSubRegionIsNotNull()  {

        DistributorVO distributorVO = new DistributorVO();

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);;

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);

        SubRegionVO subRegionVO = new SubRegionVO();
        subRegionVO.setDescription("SUB_REGION_DESCRIPTION");

        when(subRegionRepository.findBySubRegionCode(anyString())).thenReturn(subRegionVO);
        assertTrue(!(unit.buildObjectMessageNotificationOfApproval(999L)).isEmpty());
        verify(subRegionRepository).findBySubRegionCode(anyString());
    }

    @Test
    public void buildObjectMessageNotificationOfRejection_WhenValidationsFail()  {
        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(null);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);
        assertTrue((unit.buildObjectMessageNotificationOfRejection(999L)).isEmpty());
    }

    @Test
    public void buildObjectMessageNotificationOfRejection_WhenValidationsSuccess()  {

        DistributorVO distributorVO = new DistributorVO();

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);
        assertTrue(!(unit.buildObjectMessageNotificationOfRejection(999L)).isEmpty());
    }

    @Test
    public void obtainUsersByBusinessEntity_WhenOrderNotFound()  {
        when(orderRepository.findByOrderId(anyLong())).thenReturn(null);
        assertTrue((unit.obtainUsersByBusinessEntity(1L)).isEmpty());
    }

    @Test
    public void obtainUsersByBusinessEntity_WhenOrderExist()  {

        DistributorVO distributorVO = new DistributorVO();

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);

        UserVO u = new UserVO();
        RoleVO role = new RoleVO();
        role.setCode(RoleEnum.CSR.getCode());
        u.setRoleVO(role);

        List<UserVO> users = new ArrayList<UserVO>();
        users.add(u);
        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(users);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);
        assertTrue(!(unit.obtainUsersByBusinessEntity(1L)).isEmpty());
    }

    @Test
    public void obtainUsersByBusinessEntity_WhenOrderExist_AndRoleIsNotRCD_OR_MKT()  {

        DistributorVO distributorVO = new DistributorVO();

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);

        UserVO u = new UserVO();
        RoleVO role = new RoleVO();
        role.setCode(RoleEnum.CSR.getCode());
        u.setRoleVO(role);

        List<UserVO> users = new ArrayList<UserVO>();
        users.add(u);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(users);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);
        assertTrue(!(unit.obtainUsersByBusinessEntity(1L)).isEmpty());
    }

    @Test
    public void obtainUsersByBusinessEntity_WhenOrderExist_AndRoleIsRCD()  {

        DistributorVO distributorVO = new DistributorVO();

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);
        orderVO.setRcdSAPCode("123456"); // RCD_SAP_ID expected

        UserVO rcd1 = new UserVO();
        RoleVO role1 = new RoleVO();
        role1.setCode(RoleEnum.RCD.getCode());
        rcd1.setRoleVO(role1);
        rcd1.setSapId("987654");

        UserVO rcd2 = new UserVO();
        RoleVO role2 = new RoleVO();
        role2.setCode(RoleEnum.RCD.getCode());
        rcd2.setRoleVO(role2);
        rcd2.setSapId("123456");

        List<UserVO> users = new ArrayList<UserVO>();
        users.add(rcd1);
        users.add(rcd2);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(users);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);
        assertTrue(!(unit.obtainUsersByBusinessEntity(1L)).isEmpty());
    }

    @Test
    public void obtainUsersByBusinessEntity_WhenOrderExist_AndRoleIsMKT_AndBrandCodeInNullOrEmpty_AndNoBrandMKTIsConfigured()  {

        DistributorVO distributorVO = new DistributorVO();

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);

        OrderDetailVO detail = new OrderDetailVO();
        detail.setProductCode("DETAIL_PRODUCT_CODE");
        List<OrderDetailVO> details = new ArrayList<OrderDetailVO>();
        details.add(detail);

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);
        orderVO.setRcdSAPCode("123456"); // RCD_SAP_ID expected
        orderVO.setOrderDetailsByOrderId(details);

        UserVO mkt1 = new UserVO();
        RoleVO role1 = new RoleVO();
        role1.setCode(RoleEnum.MARKETING.getCode());
        mkt1.setRoleVO(role1);
        mkt1.setSapId("987654");
        BrandVO brandVO = new BrandVO();
        brandVO.setBrandCode(BrandEnum.NO_BRAND.getId());
        mkt1.setBrandVO(brandVO);

        List<UserVO> users = new ArrayList<UserVO>();
        users.add(mkt1);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(users);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);
        when(orderDetailRepository.findByOrderId(anyLong())).thenReturn(details);
        assertTrue(!unit.obtainUsersByBusinessEntity(1L).isEmpty());
    }

    @Test
    public void obtainUsersByBusinessEntity_WhenOrderExist_AndRoleIsMKT_AndBrandCodeInNullOrEmpty_AndNoBrandMKTIsNotConfigured()  {

        DistributorVO distributorVO = new DistributorVO();

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);

        OrderDetailVO detail = new OrderDetailVO();
        detail.setProductCode("DETAIL_PRODUCT_CODE");
        List<OrderDetailVO> details = new ArrayList<OrderDetailVO>();
        details.add(detail);

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);
        orderVO.setRcdSAPCode("123456"); // RCD_SAP_ID expected
        orderVO.setOrderDetailsByOrderId(details);

        UserVO mkt1 = new UserVO();
        RoleVO role1 = new RoleVO();
        role1.setCode(RoleEnum.MARKETING.getCode());
        mkt1.setRoleVO(role1);
        mkt1.setSapId("987654");
        BrandVO brandVO = new BrandVO();
        brandVO.setBrandCode(BrandEnum.ASGROW.getId());
        mkt1.setBrandVO(brandVO);

        List<UserVO> users = new ArrayList<UserVO>();
        users.add(mkt1);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(users);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);
        when(orderDetailRepository.findByOrderId(anyLong())).thenReturn(details);
        assertTrue(unit.obtainUsersByBusinessEntity(1L).isEmpty());
    }

    @Test
    public void obtainUsersByBusinessEntity_WhenOrderExist_AndRoleIsMKT_AndValidProductCode_AndBrandCodeNotEqual()  {

        DistributorVO distributorVO = new DistributorVO();

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);

        String productCode = "DETAIL_PRODUCT_CODE";
        OrderDetailVO detail = new OrderDetailVO();
        detail.setProductCode(productCode);
        Collection<OrderDetailVO> details = new ArrayList<OrderDetailVO>();
        details.add(detail);

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);
        orderVO.setRcdSAPCode("123456"); // RCD_SAP_ID expected
        orderVO.setOrderDetailsByOrderId(details);

        UserVO mkt1 = new UserVO();
        RoleVO role1 = new RoleVO();
        role1.setCode(RoleEnum.MARKETING.getCode());
        mkt1.setRoleVO(role1);
        mkt1.setSapId("987654");
        BrandVO brandVO = new BrandVO();
        brandVO.setBrandCode(BrandEnum.ASGROW.getId());
        mkt1.setBrandVO(brandVO);

        List<UserVO> users = new ArrayList<UserVO>();
        users.add(mkt1);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(users);

        OrderDetailVO orderDetailVO = new OrderDetailVO();
        orderDetailVO.setBrandCode(BrandEnum.DEKALB.getId());
        List<OrderDetailVO> orderDetails = new ArrayList<OrderDetailVO>();
        orderDetails.add(orderDetailVO);
        when(orderDetailRepository.findByOrderId(anyLong())).thenReturn(orderDetails);

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);
        assertTrue(unit.obtainUsersByBusinessEntity(1L).isEmpty());
    }

    @Test
    public void obtainUsersByBusinessEntity_WhenOrderExist_AndRoleIsMKT_AndValidProductCode_AndBrandCodeIsEqual()  {

        DistributorVO distributorVO = new DistributorVO();

        DistributorProfileVO distributorProfileVO = new DistributorProfileVO();
        distributorProfileVO.setDistributorByDistributorCode(distributorVO);

        String productCode = "DETAIL_PRODUCT_CODE";
        OrderDetailVO detail = new OrderDetailVO();
        detail.setProductCode(productCode);
        Collection<OrderDetailVO> details = new ArrayList<OrderDetailVO>();
        details.add(detail);

        OrderVO orderVO = new OrderVO();
        orderVO.setDistributorProfileByDistributorProfileId(distributorProfileVO);
        orderVO.setRcdSAPCode("123456"); // RCD_SAP_ID expected
        orderVO.setOrderDetailsByOrderId(details);

        UserVO mkt1 = new UserVO();
        RoleVO role1 = new RoleVO();
        role1.setCode(RoleEnum.MARKETING.getCode());
        mkt1.setRoleVO(role1);
        mkt1.setSapId("987654");
        BrandVO brandVO = new BrandVO();
        brandVO.setBrandCode(BrandEnum.ASGROW.getId());
        mkt1.setBrandVO(brandVO);

        List<UserVO> users = new ArrayList<UserVO>();
        users.add(mkt1);

        when(userManagementService.getListOfUserByDistributorProfileId(anyLong())).thenReturn(users);

        ProductVO p = new ProductVO();
        p.setProductCode(productCode);
        p.setBrandCode(BrandEnum.ASGROW.getId());

        when(orderRepository.findByOrderId(anyLong())).thenReturn(orderVO);

        OrderDetailVO orderDetailVO = new OrderDetailVO();
        orderDetailVO.setBrandCode(BrandEnum.ASGROW.getId());
        List<OrderDetailVO> orderDetails = new ArrayList<OrderDetailVO>();
        orderDetails.add(orderDetailVO);
        when(orderDetailRepository.findByOrderId(anyLong())).thenReturn(orderDetails);

        assertTrue(!(unit.obtainUsersByBusinessEntity(1L).isEmpty()));
    }

}