package com.monsanto.customerlink.core.service.util;

import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.text.SimpleDateFormat;
import java.util.Date;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class CustomerLinkUtils_UT {

    @Test(expected = IllegalArgumentException.class)
    public void throwsIllegalArgumentExceptionIfTheParameterObjectIsNull() throws Exception {
        CustomerLinkUtils.isValidParameter(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void throwsIllegalArgumentExceptionIfTheParameterIsStringInstanceAndIsEmpty() throws Exception {
        final String parameter = new String("");
        CustomerLinkUtils.isValidParameter(parameter);
    }

    @Test
    public void isValidParameter() throws Exception {
        final String parameter = new String("parameter");
        CustomerLinkUtils.isValidParameter(parameter);
    }

    @Test
    public void obtainFiscalyear() {
        Date today = new Date();

        CustomerLinkUtils.getFiscalYear(today);
    }

    @Test
    public void testBuildHybrid() {

        ProductDTO dto = new ProductDTO();
        dto.setProductCode("hybrid");
        dto.setTreatmentCode("treatment");
        CustomerLinkUtils.getHybridName(dto);

        ProductDTO dto1 = new ProductDTO();
        dto1.setProductCode("hybrid");
        dto1.setTreatmentCode("0");
        CustomerLinkUtils.getHybridName(dto1);
    }

    @Test
    public void retrievesTrueWhenTheDateIsInTheRange1() throws Exception {
        final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy hh:mm:ss");
        final Date date = sdf.parse("18-03-13 08:59:59");
        final Date startDate = sdf.parse("18-03-13 09:59:59");
        final Date endDate = sdf.parse("18-09-13 09:59:59");
        final boolean isDateInRange = CustomerLinkUtils.isDateInRange(date, startDate, endDate);
        assertThat(isDateInRange, is(Boolean.TRUE));
    }

    @Test
    public void retrievesTrueWhenTheDateIsInTheRange2() throws Exception {
        final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy hh:mm:ss");
        final Date date = sdf.parse("18-03-13 10:59:59");
        final Date startDate = sdf.parse("18-03-13 09:59:59");
        final Date endDate = sdf.parse("18-09-13 09:59:59");
        final boolean isDateInRange = CustomerLinkUtils.isDateInRange(date, startDate, endDate);
        assertThat(isDateInRange, is(Boolean.TRUE));
    }

    @Test
    public void retrievesTrueWhenTheDateIsInTheRange3() throws Exception {
        final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy hh:mm:ss");
        final Date date = sdf.parse("18-09-13 08:59:59");
        final Date startDate = sdf.parse("18-03-13 09:59:59");
        final Date endDate = sdf.parse("18-09-13 09:59:59");
        final boolean isDateInRange = CustomerLinkUtils.isDateInRange(date, startDate, endDate);
        assertThat(isDateInRange, is(Boolean.TRUE));
    }

    @Test
    public void retrievesTrueWhenTheDateIsInTheRange4() throws Exception {
        final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy hh:mm:ss");
        final Date date = sdf.parse("18-09-13 10:59:59");
        final Date startDate = sdf.parse("18-03-13 09:59:59");
        final Date endDate = sdf.parse("18-09-13 09:59:59");
        final boolean isDateInRange = CustomerLinkUtils.isDateInRange(date, startDate, endDate);
        assertThat(isDateInRange, is(Boolean.TRUE));
    }

    @Test
    public void retrievesTrueWhenTheDateIsInTheRange5() throws Exception {
        final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy hh:mm:ss");
        final Date date = sdf.parse("18-07-13 10:59:59");
        final Date startDate = sdf.parse("18-03-13 09:59:59");
        final Date endDate = sdf.parse("18-09-13 09:59:59");
        final boolean isDateInRange = CustomerLinkUtils.isDateInRange(date, startDate, endDate);
        assertThat(isDateInRange, is(Boolean.TRUE));
    }

    @Test
    public void retrievesFalseWhenTheDateIsNotInTheRange1() throws Exception {
        final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy hh:mm:ss");
        final Date date = sdf.parse("12-01-12 09:59:59");
        final Date startDate = sdf.parse("18-03-13 09:59:59");
        final Date endDate = sdf.parse("18-09-13 09:59:59");
        final boolean isDateInRange = CustomerLinkUtils.isDateInRange(date, startDate, endDate);
        assertThat(isDateInRange, is(Boolean.FALSE));
    }

    @Test
    public void retrievesFalseWhenTheDateIsNotInTheRange2() throws Exception {
        final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy hh:mm:ss");
        final Date date = sdf.parse("19-09-13 09:59:59");
        final Date startDate = sdf.parse("18-03-13 09:59:59");
        final Date endDate = sdf.parse("18-09-13 09:59:59");
        final boolean isDateInRange = CustomerLinkUtils.isDateInRange(date, startDate, endDate);
        assertThat(isDateInRange, is(Boolean.FALSE));
    }


    @Test
    public void testSafeNullReturnsNotNullValue() {
        //static <T> T safeNull(T testValue, T replacementValue) {
        // return testValue != null ? testValue : replacementValue;
        String nullValue = null;
        String value = "test";
        String evaluation = CustomerLinkUtils.safeNull(null, value);
        String evaluation2 = CustomerLinkUtils.safeNull(value, value);

        assertThat(evaluation, is(value));
        assertThat(evaluation2, is(value));
    }

    @Test
    public void testPriceConditionreturnsCorrectValuesForEachCropCode() {

        String corn = CustomerLinkUtils.getPriceCondition(SeedsCropCodeEnum.CORN.getCode());
        String sorghum = CustomerLinkUtils.getPriceCondition(SeedsCropCodeEnum.SORGHUM.getCode());
        String cotton = CustomerLinkUtils.getPriceCondition(SeedsCropCodeEnum.COTTON.getCode());
        String soybean = CustomerLinkUtils.getPriceCondition(SeedsCropCodeEnum.SOYBEAN.getCode());
        String regularAgrochemical = CustomerLinkUtils.getPriceCondition(SeedsCropCodeEnum.REGULAR_AGROCHEMICALS.getCode());
        String other = CustomerLinkUtils.getPriceCondition("OTHER");

        assertThat(corn, is(PriceConditionsEnum.ZL01.getCode()));
        assertThat(sorghum, is(PriceConditionsEnum.ZL01.getCode()));
        assertThat(cotton, is(PriceConditionsEnum.ZR38.getCode()));
        assertThat(soybean, is(PriceConditionsEnum.ZR38.getCode()));
        assertThat(regularAgrochemical, is(PriceConditionsEnum.ZR11.getCode()));
        assertTrue(other == null);
    }

    @Test
    public void testThatChannel80IsFiltered() {
        String channel80 = "80";
        String channel00 = "00";

        String channelFiltered = CustomerLinkUtils.filterChannels(channel80);
        String channelFiltered_ = CustomerLinkUtils.filterChannels(channel00);

        Assert.assertNotEquals(channelFiltered, channel80);
        Assert.assertNotEquals(channelFiltered_, channel80);
    }

    @Test
    public void testThatDateIsformatted() {
        String datestring = CustomerLinkUtils.formatSapDate(new Date());
        Assert.assertNotNull(datestring);
    }

    @Test
    public void testToCheckDistributorProfileArgument() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode("MX20");
        distributorProfileDTO.setDistChCode("3R");
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setSubRegionCode("AMXBAJ");
        distributorProfileDTO.setDistributor(distributorDTO);

        CustomerLinkUtils.checkDistributorProfileArgument(distributorProfileDTO);
    }

    @Test
    public void testToCheckDistributorArgument() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        CustomerLinkUtils.checkDistributorArgument(distributorDTO);
    }
}
