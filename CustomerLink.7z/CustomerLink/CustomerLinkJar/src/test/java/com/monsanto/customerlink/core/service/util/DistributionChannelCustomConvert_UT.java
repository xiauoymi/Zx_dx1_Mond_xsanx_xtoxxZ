package com.monsanto.customerlink.core.service.util;

import com.monsanto.customerlink.persistence.entities.DistributionChannelMappingVO;
import com.monsanto.customerlink.persistence.repositories.DistributionChannelMappingRepository;
import org.dozer.MappingException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DistributionChannelCustomConvert_UT {

    private DistributionChannelCustomConvert unit;
    private DistributionChannelMappingRepository mappingRepository;
    private DistributionChannelMappingRepository distributionChannelMappingRepository;

    @Before
    public void before() {
        unit = Mockito.spy(new DistributionChannelCustomConvert());
        mappingRepository = Mockito.mock(DistributionChannelMappingRepository.class);
        distributionChannelMappingRepository = Mockito.mock(DistributionChannelMappingRepository.class);
    }

    @Test(expected = MappingException.class)
    public void exceptionWhen_MappingRepositoryNotFound() throws Exception{
        String destination = null, source = null;
        doReturn(null).when(unit).obtainRepository();
        unit.setParameter("entity-to-dto");
        unit.convert(destination,source,Integer.class,String.class);
    }

    @Test()
    public void returnNullWhenSourceIsNull() throws Exception{
        String destination = null, source = null;
        doReturn(distributionChannelMappingRepository).when(unit).obtainRepository();
        unit.setParameter("entity-to-dto");
        destination = (String)unit.convert(destination, source, Integer.class, String.class);
        assertThat(destination, is(nullValue()));
    }

    @Test(expected = MappingException.class)
    public void exceptionWhenSourceIsDifferentType() throws Exception{
        String destination = new String();
        Integer source = new Integer("1");
        doReturn(distributionChannelMappingRepository).when(unit).obtainRepository();
        unit.setParameter("entity-to-dto");
        destination = (String)unit.convert(destination, source, Integer.class, String.class);
        assertThat(destination, is(nullValue()));
    }

    @Test
    public void obtainNullWhenSourceIsBlank() throws Exception{
        String destination = new String();
        String source = new String();
        doReturn(distributionChannelMappingRepository).when(unit).obtainRepository();
        unit.setParameter("entity-to-dto");
        destination = (String)unit.convert(destination, source, Integer.class, String.class);
        assertThat(destination, is(nullValue()));
    }

    @Test
    public void obtainNullWhen_RepositoryReturnNull() throws Exception{
        String destination = new String();
        String source = new String(DistributionChannelEnum.DEFAULT.getId());
        doReturn(distributionChannelMappingRepository).when(unit).obtainRepository();
        when(distributionChannelMappingRepository.findByClCode(anyString())).thenReturn(null);
        unit.setParameter("entity-to-dto");
        destination = (String)unit.convert(destination, source, Integer.class, String.class);
        assertThat(destination, is(nullValue()));
    }

    @Test
    public void obtainNotNullWhen_RepositoryReturnNotNull() throws Exception{
        String destination = new String();
        String source = new String(DistributionChannelEnum.DEFAULT.getId());

        doReturn(distributionChannelMappingRepository).when(unit).obtainRepository();

        DistributionChannelMappingVO mappingVO = new DistributionChannelMappingVO();
        mappingVO.setSapCode(DistributionChannelEnum.DIRECT_SALES.getId());
        when(distributionChannelMappingRepository.findByClCode(anyString())).thenReturn(mappingVO);

        unit.setParameter("entity-to-dto");
        destination = (String)unit.convert(destination, source, Integer.class, String.class);
        assertThat(destination, is(notNullValue()));
    }

    @Test
    public void obtainNullWhen_RepositoryReturnNull_DtoToEntity() throws Exception{
        String destination = new String();
        String source = new String(DistributionChannelEnum.DEFAULT.getId());

        doReturn(distributionChannelMappingRepository).when(unit).obtainRepository();

        DistributionChannelMappingVO mappingVO = new DistributionChannelMappingVO();
        mappingVO.setSapCode(DistributionChannelEnum.DIRECT_SALES.getId());
        when(distributionChannelMappingRepository.findBySapCodeOrderBySapCodePriorityAsc(anyString())).thenReturn(null);

        unit.setParameter("");
        destination = (String)unit.convert(destination, source, Integer.class, String.class);
        assertThat(destination, is(nullValue()));
    }

    @Test
    public void obtainNotNullWhen_RepositoryReturnNotNull_DtoToEntity() throws Exception{
        String destination = new String();
        String source = new String(DistributionChannelEnum.DEFAULT.getId());
        doReturn(distributionChannelMappingRepository).when(unit).obtainRepository();
        DistributionChannelMappingVO mappingVO = new DistributionChannelMappingVO();
        mappingVO.setClCode(DistributionChannelEnum.DIRECT_SALES.getId());
        List<DistributionChannelMappingVO> mappings = new ArrayList<DistributionChannelMappingVO>();
        mappings.add(mappingVO);
        when(distributionChannelMappingRepository.findBySapCodeOrderBySapCodePriorityAsc(anyString())).thenReturn(mappings);
        unit.setParameter("");
        destination = (String)unit.convert(destination, source, Integer.class, String.class);
        assertThat(destination, is(notNullValue()));
    }

    @Test
    public void obtainNotNullWhen_ParameterIsNull() throws Exception{
        String destination = new String();
        String source = new String(DistributionChannelEnum.DEFAULT.getId());
        doReturn(distributionChannelMappingRepository).when(unit).obtainRepository();
        DistributionChannelMappingVO mappingVO = new DistributionChannelMappingVO();
        mappingVO.setClCode(DistributionChannelEnum.DIRECT_SALES.getId());
        List<DistributionChannelMappingVO> mappings = new ArrayList<DistributionChannelMappingVO>();
        mappings.add(mappingVO);
        when(distributionChannelMappingRepository.findBySapCodeOrderBySapCodePriorityAsc(anyString())).thenReturn(mappings);
        unit.setParameter(null);
        destination = (String)unit.convert(destination, source, Integer.class, String.class);
        assertThat(destination, is(nullValue()));
    }

}
