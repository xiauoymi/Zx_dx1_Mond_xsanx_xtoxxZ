package com.monsanto.customerlink.core.service.util;

import com.monsanto.customerlink.persistence.entities.DeliveryVO;
import com.monsanto.customerlink.web.services.autogen.delivery.TemporalSavedDeliveryDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class Mapper_UT {

    private Mapper unit = new Mapper();

    @Test
    public void getNullListMapped_When_InputListIsNull() throws Exception {
        List<TemporalSavedDeliveryDTO> list = unit.mapList(TemporalSavedDeliveryDTO.class, null);
        assertTrue(list==null);
    }

    @Test
    public void getEmptyListMapped_When_InputListIsEmpty() throws Exception {
        List<TemporalSavedDeliveryDTO> list = unit.mapList(TemporalSavedDeliveryDTO.class, new ArrayList<DeliveryVO>());
        assertTrue(list!=null);
        assertTrue(list.isEmpty());
        assertThat(list, is(notNullValue()));
    }

    @Test
    public void getNonEmptyListMapped_When_InputListContainsValues() throws Exception {

        List<DeliveryVO> listContainsValues = new ArrayList<DeliveryVO>();

        DeliveryVO d1 = new DeliveryVO();
        d1.setOrderIdSap("1");
        listContainsValues.add(d1);

        DeliveryVO d2 = new DeliveryVO();
        d2.setOrderIdSap("2");
        listContainsValues.add(d2);

        List<TemporalSavedDeliveryDTO> list = unit.mapList(TemporalSavedDeliveryDTO.class, listContainsValues);
        assertTrue(list!=null);
        assertTrue(!list.isEmpty());
        assertThat(list, is(notNullValue()));
    }

}