package com.monsanto.customerlink.core.service.util;

import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class RepresentativeUtils_UT {

    @Test
    public void isAvailableRCD_WhenRepresentativeIsNull() throws Exception {
        assertFalse(RepresentativeUtils.isAvailableRCD(null));
    }

    @Test
    public void isAvailableRCD_WhenRepresentativeIsNotNull_AndSapUserIdIsNull() throws Exception {
        RepresentativeDTO representativeDTO = new RepresentativeDTO();
        assertFalse(RepresentativeUtils.isAvailableRCD(representativeDTO));
    }

    @Test
    public void isAvailableRCD_WhenRepresentativeIsNotNull_AndSapUserIdIsEmpty() throws Exception {
        RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("");
        assertFalse(RepresentativeUtils.isAvailableRCD(representativeDTO));
    }

    @Test
    public void isAvailableRCD_WhenRepresentativeIsNotNull_AndSapUserIdIsNotEmpty() throws Exception {
        RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("USER_SAP_ID");
        assertTrue(RepresentativeUtils.isAvailableRCD(representativeDTO));
    }
}
