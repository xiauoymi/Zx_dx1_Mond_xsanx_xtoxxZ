package com.monsanto.customerlink.webservices;

import com.monsanto.customerlink.core.webservices.ClientHeaderHandler;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.xml.soap.*;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ClientHeaderHandler_UT {

    ClientHeaderHandler clientHeaderHandler;

    @Mock
    SOAPMessageContext smc;
    @Mock
    SOAPFactory soapFactory;
    @Mock
    SOAPMessage soapMessage;
    @Mock
    SOAPPart soapPart;
    @Mock
    SOAPEnvelope soapEnvelope;
    @Mock
    SOAPElement wsSecHeaderElm;
    @Mock
    SOAPElement userNameTokenElm;
    @Mock
    SOAPElement userNameElm;

    @Mock
    SOAPElement passwdElm;
    @Mock
    SOAPHeader sh;

    @Before
    public void setup() {
        clientHeaderHandler = new ClientHeaderHandler();
    }

    private static final String AUTH_NS = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";//"http://schemas.xmlsoap.org/ws/2002/12/secext";
    private static final String AUTH_PREFIX = "nl";

    @Test
    public void handleSuccesFullyMessageAndHeadersAreCorrectlySetted() throws Exception {
        when(smc.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY)).thenReturn(true);
        when(smc.get(BindingProvider.USERNAME_PROPERTY)).thenReturn("userName");
        when(smc.get(BindingProvider.PASSWORD_PROPERTY)).thenReturn("password");
        when(smc.getMessage()).thenReturn(soapMessage);
        when(soapMessage.getSOAPPart()).thenReturn(soapPart);
        when(soapPart.getEnvelope()).thenReturn(soapEnvelope);

        when(soapFactory.createElement("Security", AUTH_PREFIX, AUTH_NS)).thenReturn(wsSecHeaderElm);
        when(soapFactory.createElement("UsernameToken", AUTH_PREFIX, AUTH_NS)).thenReturn(userNameTokenElm);
        when(soapFactory.createElement("Username", AUTH_PREFIX, AUTH_NS)).thenReturn(userNameElm);
        when(soapFactory.createElement("Password", AUTH_PREFIX, AUTH_NS)).thenReturn(passwdElm);
        when(soapEnvelope.addHeader()).thenReturn(sh);

        ClientHeaderHandler aSpy = Mockito.spy(clientHeaderHandler);
        Mockito.doReturn(soapFactory).when(aSpy).getSOAPFactory();

        Assert.assertTrue(aSpy.handleMessage(smc));
    }

    @Test
    public void throwsExceptionWhenSomeElementInHeaderCanNotBeCreated() throws Exception {
        reset(smc);
        reset(soapFactory);
        reset(soapEnvelope);

        when(smc.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY)).thenReturn(true);
        when(smc.get(BindingProvider.USERNAME_PROPERTY)).thenReturn("userName");
        when(smc.get(BindingProvider.PASSWORD_PROPERTY)).thenReturn("password");
        when(smc.getMessage()).thenReturn(soapMessage);
        when(soapMessage.getSOAPPart()).thenReturn(soapPart);
        when(soapPart.getEnvelope()).thenReturn(soapEnvelope);

        when(soapFactory.createElement("Security", AUTH_PREFIX, AUTH_NS)).thenThrow(SOAPException.class);
        when(soapFactory.createElement("UsernameToken", AUTH_PREFIX, AUTH_NS)).thenReturn(userNameTokenElm);
        when(soapFactory.createElement("Username", AUTH_PREFIX, AUTH_NS)).thenReturn(userNameElm);
        when(soapFactory.createElement("Password", AUTH_PREFIX, AUTH_NS)).thenReturn(passwdElm);
        when(soapEnvelope.addHeader()).thenReturn(sh);

        ClientHeaderHandler aSpy = Mockito.spy(clientHeaderHandler);
        Mockito.doReturn(soapFactory).when(aSpy).getSOAPFactory();

        aSpy.handleMessage(smc);
    }

    @Test
    public void testMessageIsNotProccesedBecauseIsAnIncomingMessage() throws Exception {
        reset(smc);

        when(smc.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY)).thenReturn(false);
        when(smc.get(BindingProvider.USERNAME_PROPERTY)).thenReturn("userName");
        when(smc.get(BindingProvider.PASSWORD_PROPERTY)).thenReturn("password");

        Assert.assertTrue(clientHeaderHandler.handleMessage(smc));
    }

    @Test
    public void handleFault() {
        Assert.assertTrue(clientHeaderHandler.handleFault(smc));
    }

    @Test
    public void handleClose() {
        clientHeaderHandler.close(smc);
    }

    @Test
    public void obtainNullheaders() {
        clientHeaderHandler.getHeaders();
    }

}
