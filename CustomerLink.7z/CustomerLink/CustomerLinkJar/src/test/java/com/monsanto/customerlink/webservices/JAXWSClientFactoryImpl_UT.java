package com.monsanto.customerlink.webservices;


import com.monsanto.customerlink.core.webservices.JAXWSClientFactory;
import com.monsanto.customerlink.core.webservices.JAXWSClientFactoryImpl;
import com.monsanto.customerlink.core.webservices.ServiceClient;
import com.monsanto.customerlink.web.services.autogen.agreement.AgreementServicePortType;
import com.monsanto.customerlink.web.services.autogen.backorder.BackorderServicePortType;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.InventoryAtpPortType;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.YESSDSACRECHANSALESORD;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YESSDSAYSDSALAN01RFC;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.YESSDSASENDINVENTORY;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YESSDSASENDCONDITIONS;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendsalesorddetail.YESSDSASENDSODETAIL;
import com.monsanto.customerlink.web.services.autogen.client.sap.validateskuprice.YESSDSAVALIDATESKU;
import com.monsanto.customerlink.web.services.autogen.delivery.DeliveryServicePortType;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorServicePortType;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderServicePortType;
import com.monsanto.customerlink.web.services.autogen.product.ProductServicePortType;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.PurchaseOrderServicePortType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.xml.namespace.QName;
import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import java.net.URL;
import java.util.HashMap;

import static junit.framework.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class JAXWSClientFactoryImpl_UT {

    @Mock
    InventoryAtpPortType inventoryAtpPortType;
    @Mock
    YESSDSASENDINVENTORY sendInventoryPortType;
    @Mock
    public YESSDSACRECHANSALESORD creChanSalesOrdPortType;
    @Mock
    public YESSDSAVALIDATESKU validationSkuPricePortType;
    @Mock
    public YESSDSASENDSODETAIL sendSalesOrdDetailPortType;
    @Mock
    public OrderServicePortType orderServicePortType;
    @Mock
    public AgreementServicePortType agreementServicePortType;
    @Mock
    public BackorderServicePortType backorderServicePortType;
    @Mock
    public DeliveryServicePortType deliveryServicePortType;
    @Mock
    public DistributorServicePortType distributorServicePortType;
    @Mock
    public ProductServicePortType productServicePortType;
    @Mock
    public PurchaseOrderServicePortType purchaseOrderServicePortType;
    @Mock
    public BindingProvider bindingProvider;
    @Mock
    Binding binding;
    @Mock
    YESSDSASENDCONDITIONS yessdsasendconditions;
    @Mock
    YESSDSAYSDSALAN01RFC interfaceCreateUpdateSalesOrderYsdsalan;


    @Mock
    ServiceClient serviceClient;

    @InjectMocks
    private JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();

    @Before
    public void setup() {
        System.setProperty("lsi.function", "dev");
    }

    @Test
    public void getInstance_returnsNotNull() {
        assertNotNull(JAXWSClientFactoryImpl.getInstance());
    }

    @Test
    public void getInventoryAtpPortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(InventoryAtpPortType.class)).thenReturn(inventoryAtpPortType);
        assertNotNull(aSpy.getInventoryAtpPortType());
        assertNotNull(aSpy.getInventoryAtpPortType());
    }

    @Test
    public void getSendInventoryPortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(YESSDSASENDINVENTORY.class)).thenReturn(sendInventoryPortType);
        assertNotNull(aSpy.getSendInventoryPortType());
        assertNotNull(aSpy.getSendInventoryPortType());
//assertNotNull(JAXWSClientFactoryImpl.getInstance().getSendInventoryPortType());
    }

    @Test
    public void getCreChanSalesOrdPortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(YESSDSACRECHANSALESORD.class)).thenReturn(creChanSalesOrdPortType);
        assertNotNull(aSpy.getCreChanSalesOrdPortType());
        assertNotNull(aSpy.getCreChanSalesOrdPortType());
    }

    @Test
    public void getValidationSkuPricePortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(YESSDSAVALIDATESKU.class)).thenReturn(validationSkuPricePortType);
        assertNotNull(aSpy.getValidationSkuPricePortType());
        assertNotNull(aSpy.getValidationSkuPricePortType());
    }


    @Test
    public void getSendSalesOrdDetailPortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(YESSDSASENDSODETAIL.class)).thenReturn(sendSalesOrdDetailPortType);
        assertNotNull(aSpy.getSendSalesOrdDetailPortType());
        assertNotNull(aSpy.getSendSalesOrdDetailPortType());
    }

    @Test
    public void getOrderServicePortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(OrderServicePortType.class)).thenReturn(orderServicePortType);
        assertNotNull(aSpy.getOrderServicePortType());
        assertNotNull(aSpy.getOrderServicePortType());
    }

    @Test
    public void getAgreementServicePortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(AgreementServicePortType.class)).thenReturn(agreementServicePortType);
        assertNotNull(aSpy.getAgreementServicePortType());
        assertNotNull(aSpy.getAgreementServicePortType());
    }

    @Test
    public void getBackorderServicePortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(BackorderServicePortType.class)).thenReturn(backorderServicePortType);
        assertNotNull(aSpy.getBackorderServicePortType());
        assertNotNull(aSpy.getBackorderServicePortType());
    }


    @Test
    public void getDeliveryServicePortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(DeliveryServicePortType.class)).thenReturn(deliveryServicePortType);
        assertNotNull(aSpy.getDeliveryServicePortType());
        assertNotNull(aSpy.getDeliveryServicePortType());
    }

    @Test
    public void getDistributorServicePortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(DistributorServicePortType.class)).thenReturn(distributorServicePortType);
        assertNotNull(aSpy.getDistributorServicePortType());
        assertNotNull(aSpy.getDistributorServicePortType());
    }

    @Test
    public void getProductServicePortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(ProductServicePortType.class)).thenReturn(productServicePortType);
        assertNotNull(aSpy.getProductServicePortType());
        assertNotNull(aSpy.getProductServicePortType());
    }

    @Test
    public void getPurchaseOrderServicePortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(PurchaseOrderServicePortType.class)).thenReturn(purchaseOrderServicePortType);
        assertNotNull(aSpy.getPurchaseOrderServicePortType());
        assertNotNull(aSpy.getPurchaseOrderServicePortType());
    }

    @Test
    public void testCredntialAreSettedWhenExistABindingProvider() {
        Mockito.when(bindingProvider.getRequestContext()).thenReturn(new HashMap<String, Object>());
        Mockito.when(bindingProvider.getBinding()).thenReturn(binding);

        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        ((JAXWSClientFactoryImpl) factory).setCredentials(bindingProvider);
    }


    @Test
    public void getSendPricesServicePortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(YESSDSASENDCONDITIONS.class)).thenReturn(yessdsasendconditions);
        assertNotNull(aSpy.getSendPricesServicePortType());
        assertNotNull(aSpy.getSendPricesServicePortType());
    }

    @Test
    public void getCreChanSalesOrdWithAlgorithmPortType_returnsNotNull() {
        JAXWSClientFactory factory = JAXWSClientFactoryImpl.getInstance();
        JAXWSClientFactory aSpy = Mockito.spy(factory);
        Mockito.doReturn(serviceClient).when((JAXWSClientFactoryImpl) aSpy).getServiceClient(Matchers.<URL>any(), Matchers.<QName>any());
        Mockito.when(serviceClient.getPort(YESSDSAYSDSALAN01RFC.class)).thenReturn(interfaceCreateUpdateSalesOrderYsdsalan);
        assertNotNull(aSpy.getCreChanSalesOrdWithAlgorithmPortType());
        assertNotNull(aSpy.getCreChanSalesOrdWithAlgorithmPortType());
    }

}
