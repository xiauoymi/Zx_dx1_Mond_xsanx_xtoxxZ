package com.monsanto.customerlink.webservices;

import com.monsanto.customerlink.core.webservices.JAXWSClient;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class JAXWSClient_UT {

    @Mock
    private JAXWSRequestBuilder jaxwsRequestBuilder;

    @Mock
    private JAXWSResponseProcessor jaxwsResponseProcessor;

    @Test
    public void execute_callsProcessInResponseProcessor() throws Exception{

        new JAXWSClient(jaxwsRequestBuilder, jaxwsResponseProcessor){
            @Override
            public Object callWebService(Object request) throws Exception {
                return null;
            }
        }.execute();

        verify(jaxwsResponseProcessor, times(1)).process(any());
    }

    @Test
    public void execute_callsBuildInRequestBuilder() throws Exception{

        new JAXWSClient(jaxwsRequestBuilder, jaxwsResponseProcessor){
            @Override
            public Object callWebService(Object request) throws Exception {
                return null;
            }
        }.execute();

        verify(jaxwsRequestBuilder, times(1)).build();
    }

    @Test(expected = Exception.class)
    public void execute_returnsNullWhenProcessThrowsException() throws  Exception{
        when(jaxwsResponseProcessor.process(any())).thenThrow(Exception.class);

        Object obj = new JAXWSClient(jaxwsRequestBuilder, jaxwsResponseProcessor){
            @Override
            public Object callWebService(Object request) throws Exception {
                return null;
            }
        }.execute();

        //assertNull(obj);
    }

}
