package com.monsanto.customerlink.webservices;

import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import org.apache.commons.lang.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class JAXWSRequestBuilder_UT {


    @Test
    public void getSuccessMessageReturnsValidString(){

        String message = new JAXWSRequestBuilder<String>(){
             @Override
             public String build() throws Exception {
                 return null;
             }
         }.getSuccessMessage();

        assertEquals("Successful", message);
    }

    @Test
    public void getDescriptionReturnsEmptyString(){

        String message = new JAXWSRequestBuilder<String>(){
             @Override
             public String build() throws Exception {
                 return null;
             }
         }.getDescription();

        assertTrue(StringUtils.isEmpty(message));
    }


}
