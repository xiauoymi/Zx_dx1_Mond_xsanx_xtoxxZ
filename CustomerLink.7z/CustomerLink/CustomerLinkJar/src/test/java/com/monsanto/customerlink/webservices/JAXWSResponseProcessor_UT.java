package com.monsanto.customerlink.webservices;

import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class JAXWSResponseProcessor_UT {

    @Test
    public void getSuccessMessageReturnsValidString() {

        String message = new JAXWSResponseProcessor<String>() {
            @Override
            public String process(String response) throws Exception {
                return "";
            }
        }.getSuccessMessage();

        assertEquals("Successful", message);
    }

    @Test
    public void getDescriptionReturnsEmptyString() {

        String message = new JAXWSResponseProcessor<String>() {
            @Override
            public String process(String response) throws Exception {
                return "";
            }
        }.getDescription();

        assertTrue(StringUtils.isEmpty(message));
    }
}
