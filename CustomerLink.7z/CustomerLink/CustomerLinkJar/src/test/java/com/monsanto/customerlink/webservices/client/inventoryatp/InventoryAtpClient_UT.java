package com.monsanto.customerlink.webservices.client.inventoryatp;

import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.inventoryatp.InventoryAtpClient;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.InventoryAtpPortType;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.Result;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class InventoryAtpClient_UT {

    @Mock
    JAXWSRequestBuilder jaxwsRequestBuilder;

    @Mock
    JAXWSResponseProcessor<Map<String, Result>> jaxwsResponseProcessor;
    @Mock
    InventoryAtpPortType inventoryAtpPortType;

    InventoryAtpClient inventoryAtpClient;
    //InventoryAtpClient {

    List<Object[]> parameters = new ArrayList<Object[]>();

    @Before
    public void setup() {
        for (int i = 0; i < 2; i++) {
            parameters.add(new Object[]{"", 1, true});
        }

    }

    @Test
    public void returnNotEmptyList() throws Exception {
        reset(inventoryAtpPortType);
        inventoryAtpPortType.obtainAtp("", 1, true, "2012-08-09", "2012-08-09");
        //when(inventoryAtpPortType.obtainAtp(Matchers.<String>any(), Matchers.<Integer>any(), Matchers.<Boolean>any())).thenReturn(new Result());
        when(inventoryAtpPortType.obtainAtp("", 1, true, "2012-08-09", "2012-08-09")).thenReturn(new Result());

        List<Object[]> list = new ArrayList<Object[]>();
        list.add(new Object[]{"", 1, true, "2012-08-09", "2012-08-09"});
        when(jaxwsRequestBuilder.build()).thenReturn(list);

        inventoryAtpClient = new InventoryAtpClient(jaxwsRequestBuilder, jaxwsResponseProcessor, inventoryAtpPortType);

        inventoryAtpClient.execute();

    }
}
