package com.monsanto.customerlink.webservices.client.inventoryatp;

import com.monsanto.customerlink.core.webservices.client.inventoryatp.InventoryAtpRequestBuilder;
import com.monsanto.customerlink.persistence.entities.SeasonVO;
import com.monsanto.customerlink.web.services.autogen.purchaseorder.SubRegionDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.sql.Timestamp;
import java.util.*;

@RunWith(MockitoJUnitRunner.class)
public class InventoryAtpRequestBuilder_UT {

    private Map<SubRegionDTO, SeasonVO> subRegionDTOList = new HashMap<SubRegionDTO, SeasonVO>();
    private Integer fiscalYear = 2013;
    private Boolean queryListAtp = false;

    InventoryAtpRequestBuilder builder;

    @Before
    public void setUp() {
        builder = new InventoryAtpRequestBuilder(subRegionDTOList, fiscalYear, queryListAtp);
    }

    @Test
    public void buildParametersEmptyList() throws Exception {
        subRegionDTOList = new HashMap<SubRegionDTO, SeasonVO>();
        Assert.assertEquals(builder.build().size(), 0);
    }

    @Test
    public void buildParametersNotEmptyList() throws Exception {
        subRegionDTOList = new HashMap<SubRegionDTO, SeasonVO>();
        for (int i = 0; i < 2; i++) {
            SubRegionDTO subRegionDTO = new SubRegionDTO();
            subRegionDTO.setSubRegionCode("AMXNTE");
            SeasonVO seasonVO= new SeasonVO();
            seasonVO.setSeasonEndDate(new Timestamp(new Date().getTime()));
            seasonVO.setSeasonStartDate(new Timestamp(new Date().getTime()));
            subRegionDTOList.put(subRegionDTO, seasonVO);
        }
         builder = new InventoryAtpRequestBuilder(subRegionDTOList, fiscalYear, queryListAtp);
        Assert.assertTrue(builder.build().size() > 0);
    }
}
