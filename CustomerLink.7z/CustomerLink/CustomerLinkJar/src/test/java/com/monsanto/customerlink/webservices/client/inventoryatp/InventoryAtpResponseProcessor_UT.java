package com.monsanto.customerlink.webservices.client.inventoryatp;

import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.core.webservices.client.inventoryatp.InventoryAtpResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.Result;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.Result.Header;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.Result.SalesDivision;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.Result.SalesDivision.Distributor;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.Result.SalesDivision.Distributor.SalesOrg;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.Result.SalesDivision.Distributor.SalesOrg.DistributionChannel;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.Result.SalesDivision.Distributor.SalesOrg.DistributionChannel.Brand;
import com.monsanto.customerlink.web.services.autogen.client.inventoryatp.Result.SalesDivision.Distributor.SalesOrg.DistributionChannel.Brand.Hybrid;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class InventoryAtpResponseProcessor_UT {

    private InventoryAtpResponseProcessor processor = new InventoryAtpResponseProcessor();

    @Test
    public void processResponseWithAlgorithm() throws Exception {
        final List<OrderDTO> orderDTOList = processor.process(generateResponse());
        assertThat(orderDTOList, is(notNullValue()));
        assertThat(orderDTOList.isEmpty(), is(Boolean.FALSE));
        assertThat(orderDTOList.size(), is(6));
    }

    private Map<String, Result> generateResponse() {
        final Map<String, Result> subRegions = new HashMap<String, Result>();
        subRegions.put("AMXSUR", generateResult());
        subRegions.put("AMXBAJ", new Result());
        return subRegions;
    }

    private Result generateResult() {
        final Result result = new Result();
        result.setHeader(generateHeader());
        result.setSalesDivision(generateSalesDivision());
        return result;
    }

    private Header generateHeader() {
        final Header header = new Header();
        header.setDate(null);
        header.setFiscalYear(2014);
        header.setSubregionBwId("AMXSUR");
        return header;
    }

    private SalesDivision generateSalesDivision() {
        final SalesDivision salesDivision = new SalesDivision();
        salesDivision.setSalesDivisionBwId("17");
        salesDivision.getDistributor().add(generateDistributor("3101380", "DISTRIBUIDORA AGROQUIMICA", "1765907", "ALEJANDRO DUHART"));
        //salesDivision.getDistributor().add(generateDistributor("3101380", "DISTRIBUIDORA AGROQUIMICA", "1765907", "ALEJANDRO DUHART"));
        salesDivision.getDistributor().add(generateDistributor("3101380", "DISTRIBUIDORA AGROQUIMICA", "1765908", "JOSE LUIS ENCARNACION"));
        return salesDivision;
    }

    private Distributor generateDistributor(String distributorBwId, String distributorName, String rcdBwId, String rcdName) {
        final Distributor distributor = new Distributor();
        distributor.setDistributorBwId(distributorBwId);
        distributor.setDistributorName(distributorName);
        distributor.setRcdBwId(rcdBwId);
        distributor.setRcdName(rcdName);
        distributor.getSalesOrg().add(generateSalesOrg("MX20", generateDistributionChannel("3R", generateTestHybridsByBrandWithAlgorithm())));
        distributor.getSalesOrg().add(generateSalesOrg("MX01", generateDistributionChannel("3R", generateTestHybridsByBrandWithoutAlgorithm())));
        return distributor;
    }

    private SalesOrg generateSalesOrg(String salesOrgBwId, DistributionChannel distributionChannel) {
        final SalesOrg salesOrg = new SalesOrg();
        salesOrg.setSalesOrgBwId(salesOrgBwId);
        salesOrg.getDistributionChannel().add(distributionChannel);
        return salesOrg;
    }

    private DistributionChannel generateDistributionChannel(String distributionChannelBwId, Map<String, List<Object[]>> hybridsByBrand) {
        final DistributionChannel distributionChannel = new DistributionChannel();
        distributionChannel.setDistributionChannelBwId(distributionChannelBwId);
        for (String brand : hybridsByBrand.keySet()) {
            distributionChannel.getBrand().add(generateBrand(brand, hybridsByBrand.get(brand)));
        }
        return distributionChannel;
    }

    private Brand generateBrand(String brandBwId, List<Object[]> hybrids) {
        final Brand brand = new Brand();
        brand.setBrandBwId(brandBwId);
        for (Object[] hybridInArray : hybrids) {
            brand.getHybrid().add(generateHybrid(hybridInArray));
        }
        return brand;
    }

    private Hybrid generateHybrid(Object[] hybridInArray) {
        final Hybrid hybrid = new Hybrid();
        hybrid.setHybridBwId((String) hybridInArray[0]);
        hybrid.setTreatmentBwId((String) hybridInArray[1]);
        hybrid.setCropCode((String) hybridInArray[2]);
        hybrid.setAtp((BigDecimal) hybridInArray[3]);
        return hybrid;
    }

    private Map<String, List<Object[]>> generateTestHybridsByBrandWithAlgorithm() {
        final Object[] hybrid1 = {"C AC AG7088PRO2 SAH", "CR", SeedsCropCodeEnum.CORN.getCode(), BigDecimal.valueOf(20)};
        final Object[] hybrid2 = {"C DK DKB390PRO2 SAH", "CR", SeedsCropCodeEnum.SORGHUM.getCode(), BigDecimal.valueOf(10)};
        final Object[] hybrid3 = {"C CB HS-8 P17 60M CO", "", SeedsCropCodeEnum.CORN.getCode(), BigDecimal.valueOf(15)};

        final List<Object[]> hybrids1 = new ArrayList<Object[]>();
        hybrids1.add(hybrid1);

        final List<Object[]> hybrids2 = new ArrayList<Object[]>();
        hybrids2.add(hybrid2);

        final List<Object[]> hybrids3 = new ArrayList<Object[]>();
        hybrids3.add(hybrid3);

        final Map<String, List<Object[]>> hybridsByBrand = new HashMap<String, List<Object[]>>();
        hybridsByBrand.put("AC", hybrids1);
        hybridsByBrand.put("DK", hybrids2);
        hybridsByBrand.put("CB", hybrids3);

        return hybridsByBrand;
    }

    private Map<String, List<Object[]>> generateTestHybridsByBrandWithoutAlgorithm() {
        final Object[] hybrid1 = {"T DP DP90B BT S1 200", "AV", SeedsCropCodeEnum.COTTON.getCode(), BigDecimal.valueOf(20)};
        final Object[] hybrid2 = {"T DP DP90B BT S1 200", "AV", SeedsCropCodeEnum.SOYBEAN.getCode(), BigDecimal.valueOf(20)};

        final List<Object[]> hybrids1 = new ArrayList<Object[]>();
        hybrids1.add(hybrid1);

        final List<Object[]> hybrids2 = new ArrayList<Object[]>();
        hybrids2.add(hybrid2);

        final Map<String, List<Object[]>> hybridsByBrand = new HashMap<String, List<Object[]>>();
        hybridsByBrand.put("DP", hybrids1);
        hybridsByBrand.put("DK", hybrids2);

        return hybridsByBrand;
    }

    /*InventoryAtpResponseProcessor processor;
    Map<String, Result> results = new HashMap<String, Result>();

    //<Map<String, Result>, List<OrderDTO>>
    @Before
    public void setUp() {
        processor = new InventoryAtpResponseProcessor();

        Result result = new Result();

        Result.SalesDivision salesDivision = new Result.SalesDivision();

        salesDivision.setSalesDivisionBwId("BwId");

        Result.SalesDivision.Distributor distributor = new Result.SalesDivision.Distributor();

        distributor.setDistributorBwId("DistributorBwId");

        Result.SalesDivision.Distributor.SalesOrg salesOrg = new Result.SalesDivision.Distributor.SalesOrg();

        salesOrg.setSalesOrgBwId("SalesOrgBwId");

        Result.SalesDivision.Distributor.SalesOrg.DistributionChannel distributionChannel = new Result.SalesDivision.Distributor.SalesOrg.DistributionChannel();

        distributionChannel.setDistributionChannelBwId("DistributionChannelBwId");

        Result.SalesDivision.Distributor.SalesOrg.DistributionChannel.Brand brand = new Result.SalesDivision.Distributor.SalesOrg.DistributionChannel.Brand();

        brand.setBrandBwId("BrandBwId");

        Result.SalesDivision.Distributor.SalesOrg.DistributionChannel.Brand.Hybrid hybrid = new Result.SalesDivision.Distributor.SalesOrg.DistributionChannel.Brand.Hybrid();
        hybrid.setAtp(BigDecimal.TEN);
        hybrid.setHybridBwId("HybridBwId");
        hybrid.setTreatmentBwId("TreatmentBwId");

        brand.getHybrid().add(hybrid);

        distributionChannel.getBrand().add(brand);

        salesOrg.getDistributionChannel().add(distributionChannel);

        distributor.getSalesOrg().add(salesOrg);

        salesDivision.getDistributor().add(distributor);

        result.setSalesDivision(salesDivision);

        results.put("sr", result);
    }

    @Test
    public void testProcess() throws Exception {
        Assert.assertNotNull(processor.process(results));
    }

    @Test
    public void testIsEmptyWhenSalesDivisionIsNull() throws Exception {

        Map<String, Result> results_ = new HashMap<String, Result>();

        Result result_ = new Result();
        results_.put("", result_);

        Assert.assertNotNull(processor.process(results_));
    }


    @Test
    public void testIsEmptyWhenDistributorIsNull() throws Exception {

        Map<String, Result> results_ = new HashMap<String, Result>();

        Result result_ = new Result();

        Result.SalesDivision salesDivision = new Result.SalesDivision();
        result_.setSalesDivision(salesDivision);
        results_.put("", result_);

        Assert.assertNotNull(processor.process(results_));
    }*/
}
