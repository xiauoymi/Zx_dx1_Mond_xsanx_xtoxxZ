package com.monsanto.customerlink.webservices.client.sap.create_update_order_with_algorithm;

import com.monsanto.customerlink.core.service.facade.impl.InventoryFacadeImpl;
import com.monsanto.customerlink.core.service.util.TransactionTypeOrder;
import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.create_update_order_with_algorithm.CreateSalesOrdWithAlgorithmClient;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.*;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.YSdsaSendInventory;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ListRequestCreateUpdateOrderWithAlgorithm;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.RequestCreateUpdateOrderWithAlgorithm;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ResponseCreateUpdateOrderWithAlgorithm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.xml.ws.Holder;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.any;

@RunWith(MockitoJUnitRunner.class)
public class CreateSalesOrdWithAlgorithmClient_UT {

    @Mock
    private JAXWSRequestBuilder<ListRequestCreateUpdateOrderWithAlgorithm> jaxwsRequestBuilder;

    @Mock
    private JAXWSResponseProcessor<List<ResponseCreateUpdateOrderWithAlgorithm>> jaxwsResponseProcessor;

    @Mock
    private YESSDSAYSDSALAN01RFC createSalesOrdPortType;

    private CreateSalesOrdWithAlgorithmClient unit;


    @Before
    public void setup() {
        unit = new CreateSalesOrdWithAlgorithmClient(jaxwsRequestBuilder, jaxwsResponseProcessor, createSalesOrdPortType);
    }


    @Test
    public void createAndOrderAndUpdatetheSameorderWithAnotherHybridsForAnotherPlants() throws Exception {

        final ListRequestCreateUpdateOrderWithAlgorithm request = new ListRequestCreateUpdateOrderWithAlgorithm();

        List<RequestCreateUpdateOrderWithAlgorithm> requestCreateUpdateOrderWithAlgorithms = new ArrayList<RequestCreateUpdateOrderWithAlgorithm>();
        //if (req.getTranType().equals(TransactionTypeOrder.INSERT.getCode()))
        for (int i = 0; i < 10; i++) {
            RequestCreateUpdateOrderWithAlgorithm requestUpdate = new RequestCreateUpdateOrderWithAlgorithm();
            if(i==0){
            requestUpdate.setTranType(TransactionTypeOrder.INSERT.getCode());
            }
            else{
                requestUpdate.setTranType(TransactionTypeOrder.UPDATE.getCode());
            }
            requestCreateUpdateOrderWithAlgorithms.add(requestUpdate);

        }
        request.setRequestCreateUpdateOrderWithAlgorithms(requestCreateUpdateOrderWithAlgorithms);

        CreateSalesOrdWithAlgorithmClient aSpy = Mockito.spy(unit);
        Mockito.doReturn("1111").when(aSpy).getSalesOrder(Matchers.<Holder<YsdsaExpSlsHeader>>any());


        final Object object = aSpy.callWebService(request);
        assertThat(object, is(instanceOf(List.class)));
        //final  List<ResponseCreateUpdateOrderWithAlgorithm> responseCreateUpdateOrderWithAlgorithm = ( List<ResponseCreateUpdateOrderWithAlgorithm>) object;
        //assertThat(responseCreateUpdateOrderWithAlgorithm, is(notNullValue()));
    }

    @Test(expected = Exception.class)
    public void tryToInvokeServiceButExceptionIsThrowed() throws Exception {

        final ListRequestCreateUpdateOrderWithAlgorithm request = new ListRequestCreateUpdateOrderWithAlgorithm();

        List<RequestCreateUpdateOrderWithAlgorithm> requestCreateUpdateOrderWithAlgorithms = new ArrayList<RequestCreateUpdateOrderWithAlgorithm>();
        for (int i = 0; i < 2; i++) {
            RequestCreateUpdateOrderWithAlgorithm requestUpdate = new RequestCreateUpdateOrderWithAlgorithm();
            requestUpdate.setTranType(TransactionTypeOrder.INSERT.getCode());
            requestCreateUpdateOrderWithAlgorithms.add(requestUpdate);
        }
        request.setRequestCreateUpdateOrderWithAlgorithms(requestCreateUpdateOrderWithAlgorithms);

        final Object object = unit.callWebService(request);

        Mockito.doThrow(new Exception("Exception intentionally sended to test")).when(createSalesOrdPortType)
                .ySdsaYsdsalan01Rfc(Matchers.<YsdsaSlsHeader>any(),
                        Matchers.<YttSdsaSlsItem>any(), Matchers.<String>any(), Matchers.<String>any(),
                        Matchers.<Holder<YttSdsaSlsErrors>>any(), Matchers.<Holder<YsdsaExpSlsHeader>>any(),
                        Matchers.<Holder<YttSdsaSlsItemOut>>any());
    }


}