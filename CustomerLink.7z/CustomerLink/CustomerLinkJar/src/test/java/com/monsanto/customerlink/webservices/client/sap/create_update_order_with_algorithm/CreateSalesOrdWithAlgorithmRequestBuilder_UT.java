package com.monsanto.customerlink.webservices.client.sap.create_update_order_with_algorithm;

import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.core.webservices.client.sap.create_update_order_with_algorithm.CreateSalesOrdWithAlgorithmRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.*;
import com.monsanto.customerlink.web.services.autogen.product.PlantDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ListRequestCreateUpdateOrderWithAlgorithm;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class CreateSalesOrdWithAlgorithmRequestBuilder_UT {

    private CreateSalesOrdWithAlgorithmRequestBuilder createSalesOrdWithAlgorithm;

    @Test
    public void createSAPOrderWhenRepresentativeObjectIsNull() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setPlant("plant");
        plantDTO.setUnrestqty(10);
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setRoute("route");
        plantDTO.setFormPref("formpref");
        plantDTO.setSizePref1("size1");
        plantDTO.setSizePref2("size2");
        plantDTO.setPref1("pref1");
        plantDTO.setPref2("pref2");
        plantDTO.setPref3("pref3");
        plantDTO.setPref4("pref4");

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setPriceGroupCode("MU CHEMMX Bllgrd BC. N");

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(OrderReasonTypeEnum.SBT.toString());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setTransactionType(TransactionTypeOrder.INSERT.getCode());
        orderDTO.setPriceGroup(priceGroupDTO);

        createSalesOrdWithAlgorithm = new CreateSalesOrdWithAlgorithmRequestBuilder(orderDTO);

        final ListRequestCreateUpdateOrderWithAlgorithm requestCreateUpdateOrderWithAlgorithm = createSalesOrdWithAlgorithm.build();
        assertThat(requestCreateUpdateOrderWithAlgorithm, is(notNullValue()));

    }

    @Test
    public void createSAPOrderWhenRepresentativeSAPCodeIsEmpty() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setPlant("plant");
        plantDTO.setUnrestqty(10);
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setRoute("route");
        plantDTO.setFormPref("formpref");
        plantDTO.setSizePref1("size1");
        plantDTO.setSizePref2("size2");
        plantDTO.setPref1("pref1");
        plantDTO.setPref2("pref2");
        plantDTO.setPref3("pref3");
        plantDTO.setPref4("pref4");

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setPriceGroupCode("MU CHEMMX Bllgrd BC. N");

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(OrderReasonTypeEnum.SBT.toString());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setTransactionType(TransactionTypeOrder.INSERT.getCode());
        orderDTO.setPriceGroup(priceGroupDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);

        createSalesOrdWithAlgorithm = new CreateSalesOrdWithAlgorithmRequestBuilder(orderDTO);

        final ListRequestCreateUpdateOrderWithAlgorithm requestCreateUpdateOrderWithAlgorithm = createSalesOrdWithAlgorithm.build();
        assertThat(requestCreateUpdateOrderWithAlgorithm, is(notNullValue()));

    }

    @Test
    public void createSAPOrderWhenRepresentativeSAPCodeIsNotEmpty() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setPlant("plant");
        plantDTO.setUnrestqty(10);
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setRoute("route");
        plantDTO.setFormPref("formpref");
        plantDTO.setSizePref1("size1");
        plantDTO.setSizePref2("size2");
        plantDTO.setPref1("pref1");
        plantDTO.setPref2("pref2");
        plantDTO.setPref3("pref3");
        plantDTO.setPref4("pref4");

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setPriceGroupCode("MU CHEMMX Bllgrd BC. N");

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(OrderReasonTypeEnum.SBT.toString());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("1234567890");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.CORN.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setTransactionType(TransactionTypeOrder.INSERT.getCode());
        orderDTO.setPriceGroup(priceGroupDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);

        createSalesOrdWithAlgorithm = new CreateSalesOrdWithAlgorithmRequestBuilder(orderDTO);

        final ListRequestCreateUpdateOrderWithAlgorithm requestCreateUpdateOrderWithAlgorithm = createSalesOrdWithAlgorithm.build();
        assertThat(requestCreateUpdateOrderWithAlgorithm, is(notNullValue()));

    }
}
