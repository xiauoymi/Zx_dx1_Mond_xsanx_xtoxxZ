package com.monsanto.customerlink.webservices.client.sap.create_update_order_with_algorithm;

import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.webservices.client.sap.create_update_order_with_algorithm.SalesOrdWithAlgorithmResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.*;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ResponseCreateUpdateOrderWithAlgorithm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class SalesOrdWithAlgorithmResponseProcessor_UT {

    private SalesOrdWithAlgorithmResponseProcessor responseProcessor;

    @Before
    public void setup() {
        responseProcessor = new SalesOrdWithAlgorithmResponseProcessor();
    }

    @Test
    public void transformYSdsaCreChanSalesOrdResponseTypeToSAPOrderDTOWhenResponsePropertiesAreNull() throws Exception {

        YsdsaExpSlsHeader outputSlsHeader = null;
        YttSdsaSlsItemOut outputSlsItemWrapper = null;
        YttSdsaSlsErrors outputErrorWrapper = null;

        final List<ResponseCreateUpdateOrderWithAlgorithm> responseCreateUpdateOrderWithAlgorithm = new ArrayList<ResponseCreateUpdateOrderWithAlgorithm>();
        ResponseCreateUpdateOrderWithAlgorithm response = new ResponseCreateUpdateOrderWithAlgorithm();
        response.setYsdsaExpSlsHeader(outputSlsHeader);
        response.setYttSdsaSlsItemOut(outputSlsItemWrapper);
        response.setYttSdsaSlsErrors(outputErrorWrapper);

        responseCreateUpdateOrderWithAlgorithm.add(response);

        final Object object = responseProcessor.process(responseCreateUpdateOrderWithAlgorithm);
        assertThat(object, is(notNullValue()));
        assertThat(object, is(instanceOf(SAPOrderDTO.class)));
    }

    @Test
    public void transformYSdsaCreChanSalesOrdResponseTypeToSAPOrderDTO() throws Exception {

        final YsdsaExpSlsHeader outputSlsHeader = new YsdsaExpSlsHeader();

        final YsdsaSlsItemOut ysdsaSlsitemout1 = new YsdsaSlsItemOut();
        ysdsaSlsitemout1.setYyitmNumber("10");
        //ysdsaSlsitemout1.setyysetHybrid("CORN");
        ysdsaSlsitemout1.setYymaterial("1");

        final YsdsaSlsItemOut ysdsaSlsitemout2 = new YsdsaSlsItemOut();
        ysdsaSlsitemout2.setYyitmNumber("20");
        //ysdsaSlsitemout2.setHybrid("CORN");
        ysdsaSlsitemout2.setYymaterial("2");

        final YsdsaSlsItemOut ysdsaSlsitemout3 = new YsdsaSlsItemOut();
        ysdsaSlsitemout3.setYyitmNumber("30");
        //ysdsaSlsitemout3.setHybrid("CORN");
        ysdsaSlsitemout3.setYymaterial("1");

        final YsdsaSlsItemOut ysdsaSlsitemout4 = new YsdsaSlsItemOut();
        ysdsaSlsitemout4.setYyitmNumber("40");
        //ysdsaSlsitemout4.setHybrid("CORN");
        ysdsaSlsitemout4.setYymaterial("2");

        final YttSdsaSlsItemOut yttSdsaSlsitemout = new YttSdsaSlsItemOut();
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout1);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout2);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout3);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout4);

        final YsdsaSlsErrors ysdsaErrors1 = new YsdsaSlsErrors();
        ysdsaErrors1.setYyid("1");
        ysdsaErrors1.setYymessage("Error Uno");
        ysdsaErrors1.setYynumber("1");
        ysdsaErrors1.setYytype("CODE1");

        final YsdsaSlsErrors ysdsaErrors2 = new YsdsaSlsErrors();
        ysdsaErrors2.setYyid("2");
        ysdsaErrors2.setYymessage("Error Dos");
        ysdsaErrors2.setYynumber("2");
        ysdsaErrors2.setYytype("CODE2");

        final YttSdsaSlsErrors yttSdsaErrors = new YttSdsaSlsErrors();
        yttSdsaErrors.getItem().add(ysdsaErrors1);
        yttSdsaErrors.getItem().add(ysdsaErrors2);

        final List<ResponseCreateUpdateOrderWithAlgorithm> responseCreateUpdateOrderWithAlgorithm = new ArrayList<ResponseCreateUpdateOrderWithAlgorithm>();
        ResponseCreateUpdateOrderWithAlgorithm response = new ResponseCreateUpdateOrderWithAlgorithm();
        response.setYsdsaExpSlsHeader(outputSlsHeader);
        response.setYttSdsaSlsItemOut(yttSdsaSlsitemout);
        response.setYttSdsaSlsErrors(yttSdsaErrors);

        responseCreateUpdateOrderWithAlgorithm.add(response);

        final Object object = responseProcessor.process(responseCreateUpdateOrderWithAlgorithm);
        assertThat(object, is(notNullValue()));
        assertThat(object, is(instanceOf(SAPOrderDTO.class)));
    }
}
