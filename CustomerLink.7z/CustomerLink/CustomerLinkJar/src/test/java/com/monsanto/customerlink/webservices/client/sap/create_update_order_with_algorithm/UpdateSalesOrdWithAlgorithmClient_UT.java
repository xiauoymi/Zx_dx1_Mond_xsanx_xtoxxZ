package com.monsanto.customerlink.webservices.client.sap.create_update_order_with_algorithm;

import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.create_update_order_with_algorithm.UpdateSalesOrdWithAlgorithmClient;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesordys.YESSDSAYSDSALAN01RFC;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ListRequestCreateUpdateOrderWithAlgorithm;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.RequestCreateUpdateOrderWithAlgorithm;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ResponseCreateUpdateOrderWithAlgorithm;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class UpdateSalesOrdWithAlgorithmClient_UT {

    @Mock
    private JAXWSRequestBuilder<ListRequestCreateUpdateOrderWithAlgorithm> jaxwsRequestBuilder;

    @Mock
    private JAXWSResponseProcessor<List<ResponseCreateUpdateOrderWithAlgorithm>> jaxwsResponseProcessor;

    @Mock
    private YESSDSAYSDSALAN01RFC updateSalesOrdPortType;

    private UpdateSalesOrdWithAlgorithmClient unit;


    @Before
    public void setup() {
        unit = new UpdateSalesOrdWithAlgorithmClient(jaxwsRequestBuilder, jaxwsResponseProcessor, updateSalesOrdPortType);
    }

    @Test//(expected = Exception.class)
    public void throwsExceptionWhenInputParameterIsNull() throws Exception {
        // unit.callWebService(null);
    }

    @Test
    public void retrievesYSdsaCreChanSalesOrdResponseType() throws Exception {
        //when(updateSalesOrdPortType.ySdsaYsdsalan01Rfc( (YsdsaSlsHeader) anyObject(), (YttSdsaSlsItem) anyObject(),(String) anyObject(),
        //      (String) anyObject(),(Holder<YttSdsaSlsErrors>) anyObject(),
        //    (Holder< YsdsaExpSlsHeader>) anyObject(), (Holder<YttSdsaSlsItemOut>) anyObject()));//.thenReturn(new ResponseCreateUpdateOrderWithAlgorithm());

        final ListRequestCreateUpdateOrderWithAlgorithm requestCreateUpdateOrderWithAlgorithm = new ListRequestCreateUpdateOrderWithAlgorithm();
        List<RequestCreateUpdateOrderWithAlgorithm> lis = new ArrayList<RequestCreateUpdateOrderWithAlgorithm>();
        for (int i = 0; i < 2; i++) {
            lis.add(new RequestCreateUpdateOrderWithAlgorithm());
        }

        requestCreateUpdateOrderWithAlgorithm.setRequestCreateUpdateOrderWithAlgorithms(lis);
        final Object object = unit.callWebService(requestCreateUpdateOrderWithAlgorithm);


        assertThat(object, is(instanceOf(List.class)));
        //final SAPOrderDTO responseCreateUpdateOrderWithAlgorithm = (SAPOrderDTO) object;
        //assertThat(responseCreateUpdateOrderWithAlgorithm, is(notNullValue()));
    }
}
