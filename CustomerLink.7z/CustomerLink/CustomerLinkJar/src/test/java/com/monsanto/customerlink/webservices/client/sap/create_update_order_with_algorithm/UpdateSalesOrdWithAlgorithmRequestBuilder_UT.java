package com.monsanto.customerlink.webservices.client.sap.create_update_order_with_algorithm;

import com.monsanto.customerlink.core.service.util.OrderReasonTypeEnum;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.core.service.util.SeedsSalesOrganizationEnum;
import com.monsanto.customerlink.core.service.util.TransactionTypeMaterial;
import com.monsanto.customerlink.core.webservices.client.sap.create_update_order_with_algorithm.UpdateSalesOrdWithAlgorithmRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.*;
import com.monsanto.customerlink.web.services.autogen.product.PlantDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import com.monsanto.customerlink.web.services.sap.dto.fds.four.ListRequestCreateUpdateOrderWithAlgorithm;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class UpdateSalesOrdWithAlgorithmRequestBuilder_UT {

    private UpdateSalesOrdWithAlgorithmRequestBuilder updateSalesOrdWithoutAlgorithm;

    @Test
    public void createSAPOrderWhenRepresentativeObjectIsNull() throws Exception {
        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        DistributorDTO distributorDTO=new DistributorDTO();
        distributorDTO.setDistributorCode("111");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setPlant("plant");
        plantDTO.setUnrestqty(10);
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setRoute("route");
        plantDTO.setFormPref("formpref");
        plantDTO.setSizePref1("size1");
        plantDTO.setSizePref2("size2");
        plantDTO.setPref1("pref1");
        plantDTO.setPref2("pref2");
        plantDTO.setPref3("pref3");
        plantDTO.setPref4("pref4");

        final PlantDTO plantDTO1 = new PlantDTO();
        plantDTO1.setPlant("plant");
        plantDTO1.setUnrestqty(5);
        plantDTO1.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO1.setRoute("route");
        plantDTO1.setFormPref("formpref");
        plantDTO1.setSizePref1("size1");
        plantDTO1.setSizePref2("size2");
        plantDTO1.setPref1("pref1");
        plantDTO1.setPref2("pref2");
        plantDTO1.setPref3("pref3");
        plantDTO1.setPref4("pref4");

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);
        productDTO.getListOfPlants().add(plantDTO1);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(10d);

        final OrderDetailDTO orderDetailDTO1 = new OrderDetailDTO();
        orderDetailDTO1.setProductDTO(productDTO);
        orderDetailDTO1.setQuantity(10d);

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(OrderReasonTypeEnum.SBT.toString());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.getDetail().add(orderDetailDTO1);
        orderDTO.setOrderIdSAP("12345678");

        PriceGroupDTO priceGroupDTO= new PriceGroupDTO ();
        orderDTO.setPriceGroup(priceGroupDTO);
        updateSalesOrdWithoutAlgorithm = new UpdateSalesOrdWithAlgorithmRequestBuilder(orderDTO);

        final ListRequestCreateUpdateOrderWithAlgorithm requestCreateUpdateOrderWithAlgorithm = updateSalesOrdWithoutAlgorithm.build();

        assertThat(requestCreateUpdateOrderWithAlgorithm, is(notNullValue()));
    }

    @Test
    public void createSAPOrderWhenRepresentativeSAPCodeIsEmpty() throws Exception {
        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        DistributorDTO distributorDTO=new DistributorDTO();
        distributorDTO.setDistributorCode("111");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setPlant("plant");
        plantDTO.setUnrestqty(10);
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setRoute("route");
        plantDTO.setFormPref("formpref");
        plantDTO.setSizePref1("size1");
        plantDTO.setSizePref2("size2");
        plantDTO.setPref1("pref1");
        plantDTO.setPref2("pref2");
        plantDTO.setPref3("pref3");
        plantDTO.setPref4("pref4");

        final PlantDTO plantDTO1 = new PlantDTO();
        plantDTO1.setPlant("plant");
        plantDTO1.setUnrestqty(5);
        plantDTO1.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO1.setRoute("route");
        plantDTO1.setFormPref("formpref");
        plantDTO1.setSizePref1("size1");
        plantDTO1.setSizePref2("size2");
        plantDTO1.setPref1("pref1");
        plantDTO1.setPref2("pref2");
        plantDTO1.setPref3("pref3");
        plantDTO1.setPref4("pref4");

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);
        productDTO.getListOfPlants().add(plantDTO1);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(10d);

        final OrderDetailDTO orderDetailDTO1 = new OrderDetailDTO();
        orderDetailDTO1.setProductDTO(productDTO);
        orderDetailDTO1.setQuantity(10d);

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(OrderReasonTypeEnum.SBT.toString());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.getDetail().add(orderDetailDTO1);
        orderDTO.setOrderIdSAP("12345678");
        orderDTO.setRepresentativeDTO(representativeDTO);

        PriceGroupDTO priceGroupDTO= new PriceGroupDTO ();
        orderDTO.setPriceGroup(priceGroupDTO);
        updateSalesOrdWithoutAlgorithm = new UpdateSalesOrdWithAlgorithmRequestBuilder(orderDTO);

        final ListRequestCreateUpdateOrderWithAlgorithm requestCreateUpdateOrderWithAlgorithm = updateSalesOrdWithoutAlgorithm.build();

        assertThat(requestCreateUpdateOrderWithAlgorithm, is(notNullValue()));
    }

    @Test
    public void createSAPOrderWhenRepresentativeSAPCodeIsNotEmpty() throws Exception {
        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        DistributorDTO distributorDTO=new DistributorDTO();
        distributorDTO.setDistributorCode("111");
        distributorProfileDTO.setDistributor(distributorDTO);

        final PlantDTO plantDTO = new PlantDTO();
        plantDTO.setPlant("plant");
        plantDTO.setUnrestqty(10);
        plantDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO.setRoute("route");
        plantDTO.setFormPref("formpref");
        plantDTO.setSizePref1("size1");
        plantDTO.setSizePref2("size2");
        plantDTO.setPref1("pref1");
        plantDTO.setPref2("pref2");
        plantDTO.setPref3("pref3");
        plantDTO.setPref4("pref4");

        final PlantDTO plantDTO1 = new PlantDTO();
        plantDTO1.setPlant("plant");
        plantDTO1.setUnrestqty(5);
        plantDTO1.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        plantDTO1.setRoute("route");
        plantDTO1.setFormPref("formpref");
        plantDTO1.setSizePref1("size1");
        plantDTO1.setSizePref2("size2");
        plantDTO1.setPref1("pref1");
        plantDTO1.setPref2("pref2");
        plantDTO1.setPref3("pref3");
        plantDTO1.setPref4("pref4");

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("CORN");
        productDTO.getListOfPlants().add(plantDTO);
        productDTO.getListOfPlants().add(plantDTO1);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);
        orderDetailDTO.setQuantity(10d);

        final OrderDetailDTO orderDetailDTO1 = new OrderDetailDTO();
        orderDetailDTO1.setProductDTO(productDTO);
        orderDetailDTO1.setQuantity(10d);

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(OrderReasonTypeEnum.SBT.toString());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("1234567890");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.getDetail().add(orderDetailDTO1);
        orderDTO.setOrderIdSAP("12345678");
        orderDTO.setRepresentativeDTO(representativeDTO);

        PriceGroupDTO priceGroupDTO= new PriceGroupDTO ();
        orderDTO.setPriceGroup(priceGroupDTO);
        updateSalesOrdWithoutAlgorithm = new UpdateSalesOrdWithAlgorithmRequestBuilder(orderDTO);

        final ListRequestCreateUpdateOrderWithAlgorithm requestCreateUpdateOrderWithAlgorithm = updateSalesOrdWithoutAlgorithm.build();

        assertThat(requestCreateUpdateOrderWithAlgorithm, is(notNullValue()));
    }
}
