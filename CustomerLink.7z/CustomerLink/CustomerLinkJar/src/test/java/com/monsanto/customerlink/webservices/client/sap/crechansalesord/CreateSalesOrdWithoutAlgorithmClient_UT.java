package com.monsanto.customerlink.webservices.client.sap.crechansalesord;

import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.crechansalesord.CreateSalesOrdWithoutAlgorithmClient;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CreateSalesOrdWithoutAlgorithmClient_UT {

    @Mock
    private JAXWSRequestBuilder<YSdsaCreChanSalesOrd> jaxwsRequestBuilder;

    @Mock
    private JAXWSResponseProcessor<Object[]> jaxwsResponseProcessor;

    @Mock
    private YESSDSACRECHANSALESORD createSalesOrdPortType;

    private CreateSalesOrdWithoutAlgorithmClient unit;

    @Before
    public void setup() {
        unit = new CreateSalesOrdWithoutAlgorithmClient(jaxwsRequestBuilder, jaxwsResponseProcessor, createSalesOrdPortType);
    }

    @Test(expected = Exception.class)
    public void throwsExceptionWhenInputParameterIsNull() throws Exception {
        unit.callWebService(null);
    }

    @Test
    public void retrievesYSdsaCreChanSalesOrdResponseType() throws Exception {
       /* when(createSalesOrdPortType.ySdsaCreChanSalesOrd((YsdsaImpParam) anyObject(), (YttSdsaSlsheader) anyObject(), (YttSdsaSlsitem) anyObject())).thenReturn(new YSdsaCreChanSalesOrdResponseType());

        final YSdsaCreChanSalesOrd ySdsaCreChanSalesOrd = new YSdsaCreChanSalesOrd();
        final Object object = unit.callWebService(ySdsaCreChanSalesOrd);
        assertThat(object, is(instanceOf(YSdsaCreChanSalesOrdResponseType.class)));
        final YSdsaCreChanSalesOrdResponseType ySdsaCreChanSalesOrdResponseType = (YSdsaCreChanSalesOrdResponseType) object;
        assertThat(ySdsaCreChanSalesOrdResponseType, is(notNullValue()));     */
    }

}
