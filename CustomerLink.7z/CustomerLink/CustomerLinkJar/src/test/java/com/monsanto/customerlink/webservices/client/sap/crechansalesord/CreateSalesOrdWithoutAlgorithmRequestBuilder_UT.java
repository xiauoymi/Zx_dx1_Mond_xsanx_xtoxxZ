package com.monsanto.customerlink.webservices.client.sap.crechansalesord;

import com.monsanto.customerlink.core.service.util.*;
import com.monsanto.customerlink.core.webservices.client.sap.crechansalesord.CreateSalesOrdWithoutAlgorithmRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.YSdsaCreChanSalesOrd;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.*;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class CreateSalesOrdWithoutAlgorithmRequestBuilder_UT {

    private CreateSalesOrdWithoutAlgorithmRequestBuilder createSalesOrdWithoutAlgorithm;

    @Test
    public void createSAPOrderWhenRepresentativeObjectIsNull() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setItemNumber(10);
        materialSkuDTO.setMaterial("COTTON 1");
        materialSkuDTO.setPlant("5528");
        materialSkuDTO.setStoragelocation("CWM1");
        materialSkuDTO.setBatch("45");
        materialSkuDTO.setUnrestqty(100);
        materialSkuDTO.setRoute("0000");
        materialSkuDTO.setPoItmNo(null);
        materialSkuDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setPriceGroupCode("MU CHEMMX Bllgrd BC. N");

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(OrderReasonTypeEnum.SBT.toString());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setTransactionType(TransactionTypeOrder.INSERT.getCode());
        orderDTO.setPriceGroup(priceGroupDTO);

        createSalesOrdWithoutAlgorithm = new CreateSalesOrdWithoutAlgorithmRequestBuilder(orderDTO);

        final YSdsaCreChanSalesOrd ySdsaCreChanSalesOrd = createSalesOrdWithoutAlgorithm.build();
        assertThat(ySdsaCreChanSalesOrd, is(notNullValue()));
    }

    @Test
    public void createSAPOrderWhenRepresentativeSAPCodeIsEmpty() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setItemNumber(10);
        materialSkuDTO.setMaterial("COTTON 1");
        materialSkuDTO.setPlant("5528");
        materialSkuDTO.setStoragelocation("CWM1");
        materialSkuDTO.setBatch("45");
        materialSkuDTO.setUnrestqty(100);
        materialSkuDTO.setRoute("0000");
        materialSkuDTO.setPoItmNo(null);
        materialSkuDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setPriceGroupCode("MU CHEMMX Bllgrd BC. N");

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(OrderReasonTypeEnum.SBT.toString());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setTransactionType(TransactionTypeOrder.INSERT.getCode());
        orderDTO.setPriceGroup(priceGroupDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);

        createSalesOrdWithoutAlgorithm = new CreateSalesOrdWithoutAlgorithmRequestBuilder(orderDTO);

        final YSdsaCreChanSalesOrd ySdsaCreChanSalesOrd = createSalesOrdWithoutAlgorithm.build();
        assertThat(ySdsaCreChanSalesOrd, is(notNullValue()));
    }

    @Test
    public void createSAPOrderWhenRepresentativeSAPCodeIsNotEmpty() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();
        distributorDTO.setDistributorCode("1111");

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");
        distributorProfileDTO.setSubRegionCode("AMXNTE");
        distributorProfileDTO.setDistributor(distributorDTO);

        final MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();
        materialSkuDTO.setItemNumber(10);
        materialSkuDTO.setMaterial("COTTON 1");
        materialSkuDTO.setPlant("5528");
        materialSkuDTO.setStoragelocation("CWM1");
        materialSkuDTO.setBatch("45");
        materialSkuDTO.setUnrestqty(100);
        materialSkuDTO.setRoute("0000");
        materialSkuDTO.setPoItmNo(null);
        materialSkuDTO.setTransactionType(TransactionTypeMaterial.INSERT.getCode());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTO);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setPriceGroupCode("MU CHEMMX Bllgrd BC. N");

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(OrderReasonTypeEnum.SBT.toString());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("1234567890");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setTransactionType(TransactionTypeOrder.INSERT.getCode());
        orderDTO.setPriceGroup(priceGroupDTO);
        orderDTO.setRepresentativeDTO(representativeDTO);

        createSalesOrdWithoutAlgorithm = new CreateSalesOrdWithoutAlgorithmRequestBuilder(orderDTO);

        final YSdsaCreChanSalesOrd ySdsaCreChanSalesOrd = createSalesOrdWithoutAlgorithm.build();
        assertThat(ySdsaCreChanSalesOrd, is(notNullValue()));
    }
}
