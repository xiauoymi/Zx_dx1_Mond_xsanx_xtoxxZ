package com.monsanto.customerlink.webservices.client.sap.crechansalesord;

import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.webservices.client.sap.crechansalesord.SalesOrdWithoutAlgorithmResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class SalesOrdWithoutAlgorithmResponseProcessor_UT {

    private SalesOrdWithoutAlgorithmResponseProcessor responseProcessor;

    @Before
    public void setup() {
        responseProcessor = new SalesOrdWithoutAlgorithmResponseProcessor();
    }

    @Test
    public void transformYSdsaCreChanSalesOrdResponseTypeToSAPOrderDTOWhenResponsePropertiesAreNull() throws Exception {
        final YsdsaExpParam ysdsaExpParam = null;

        final YttSdsaSlsitemout yttSdsaSlsitemout = null;

        final YttSdsaErrors yttSdsaErrors = null;

        //final YSdsaCreChanSalesOrdResponseType ySdsaCreChanSalesOrdResponseType = new YSdsaCreChanSalesOrdResponseType();
        //ySdsaCreChanSalesOrdResponseType.setExpParam(ysdsaExpParam);
        //ySdsaCreChanSalesOrdResponseType.setSlsitemout(yttSdsaSlsitemout);
        //ySdsaCreChanSalesOrdResponseType.setErrors(yttSdsaErrors);

        Object[] params = new Object[]{yttSdsaErrors, ysdsaExpParam, yttSdsaSlsitemout};
        final Object object = responseProcessor.process(params);
        assertThat(object, is(notNullValue()));
        assertThat(object, is(instanceOf(SAPOrderDTO.class)));
    }

    @Test
    public void transformYSdsaCreChanSalesOrdResponseTypeToSAPOrderDTO() throws Exception {
        final YsdsaExpParam ysdsaExpParam = new YsdsaExpParam();

        final YsdsaSlsitemout ysdsaSlsitemout1 = new YsdsaSlsitemout();
        ysdsaSlsitemout1.setYyitmNumber("10");
        ysdsaSlsitemout1.setYyhybrid("COTTON");
        ysdsaSlsitemout1.setYymaterial("1");

        final YsdsaSlsitemout ysdsaSlsitemout2 = new YsdsaSlsitemout();
        ysdsaSlsitemout2.setYyitmNumber("20");
        ysdsaSlsitemout2.setYyhybrid("COTTON");
        ysdsaSlsitemout2.setYymaterial("2");

        final YsdsaSlsitemout ysdsaSlsitemout3 = new YsdsaSlsitemout();
        ysdsaSlsitemout3.setYyitmNumber("30");
        ysdsaSlsitemout3.setYyhybrid("SOYA");
        ysdsaSlsitemout3.setYymaterial("1");

        final YsdsaSlsitemout ysdsaSlsitemout4 = new YsdsaSlsitemout();
        ysdsaSlsitemout4.setYyitmNumber("40");
        ysdsaSlsitemout4.setYyhybrid("SOYA");
        ysdsaSlsitemout4.setYymaterial("2");

        final YttSdsaSlsitemout yttSdsaSlsitemout = new YttSdsaSlsitemout();
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout1);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout2);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout3);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout4);

        final YsdsaErrors ysdsaErrors1 = new YsdsaErrors();
        ysdsaErrors1.setYyid("1");
        ysdsaErrors1.setYymessage("Error Uno");
        ysdsaErrors1.setYynumber("1");
        ysdsaErrors1.setYytype("CODE1");

        final YsdsaErrors ysdsaErrors2 = new YsdsaErrors();
        ysdsaErrors2.setYyid("2");
        ysdsaErrors2.setYymessage("Error Dos");
        ysdsaErrors2.setYynumber("2");
        ysdsaErrors2.setYytype("CODE2");

        final YttSdsaErrors yttSdsaErrors = new YttSdsaErrors();
        yttSdsaErrors.getItem().add(ysdsaErrors1);
        yttSdsaErrors.getItem().add(ysdsaErrors2);

        //final YSdsaCreChanSalesOrdResponseType ySdsaCreChanSalesOrdResponseType = new YSdsaCreChanSalesOrdResponseType();
        //ySdsaCreChanSalesOrdResponseType.setExpParam(ysdsaExpParam);
        //ySdsaCreChanSalesOrdResponseType.setSlsitemout(yttSdsaSlsitemout);
        //ySdsaCreChanSalesOrdResponseType.setErrors(yttSdsaErrors);
        Object[] ySdsaCreChanSalesOrdResponseType = new Object[]{yttSdsaErrors, ysdsaExpParam, yttSdsaSlsitemout};

        final Object object = responseProcessor.process(ySdsaCreChanSalesOrdResponseType);
        assertThat(object, is(notNullValue()));
        assertThat(object, is(instanceOf(SAPOrderDTO.class)));
    }
}
