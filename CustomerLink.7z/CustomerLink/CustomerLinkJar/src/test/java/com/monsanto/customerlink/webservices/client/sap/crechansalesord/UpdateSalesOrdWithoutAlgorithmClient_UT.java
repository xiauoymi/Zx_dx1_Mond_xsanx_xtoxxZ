package com.monsanto.customerlink.webservices.client.sap.crechansalesord;

import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.crechansalesord.UpdateSalesOrdWithoutAlgorithmClient;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.jws.WebParam;
import javax.xml.ws.Holder;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UpdateSalesOrdWithoutAlgorithmClient_UT {

    @Mock
    private JAXWSRequestBuilder<YSdsaCreChanSalesOrd> jaxwsRequestBuilder;

    @Mock
    private JAXWSResponseProcessor<Object[]> jaxwsResponseProcessor;

    @Mock
    private YESSDSACRECHANSALESORD updateSalesOrdPortType;

    private UpdateSalesOrdWithoutAlgorithmClient unit;

    @Before
    public void setup() {
        unit = new UpdateSalesOrdWithoutAlgorithmClient(jaxwsRequestBuilder, jaxwsResponseProcessor, updateSalesOrdPortType);
    }

    @Test(expected = Exception.class)
    public void throwsExceptionWhenInputParameterIsNull() throws Exception {
        unit.callWebService(null);
    }

    @Test
    public void retrievesYSdsaCreChanSalesOrdResponseType() throws Exception {
        //when(updateSalesOrdPortType.ySdsaCreChanSalesOrd((YsdsaImpParam) anyObject(), (YttSdsaSlsheader) anyObject(), (YttSdsaSlsitem) anyObject(),
                //(Holder<YttSdsaErrors>) anyObject(), (Holder<YsdsaExpParam>)anyObject(),( Holder<YttSdsaSlsitemout>)anyObject()));

        final YSdsaCreChanSalesOrd ySdsaCreChanSalesOrd = new YSdsaCreChanSalesOrd();
        final Object object = unit.callWebService(ySdsaCreChanSalesOrd);
        //assertThat(object, is(instanceOf(Object[]));
        //final YSdsaCreChanSalesOrdResponseType ySdsaCreChanSalesOrdResponseType = (YSdsaCreChanSalesOrdResponseType) object;
        //assertThat(ySdsaCreChanSalesOrdResponseType, is(notNullValue()));


    }
}
