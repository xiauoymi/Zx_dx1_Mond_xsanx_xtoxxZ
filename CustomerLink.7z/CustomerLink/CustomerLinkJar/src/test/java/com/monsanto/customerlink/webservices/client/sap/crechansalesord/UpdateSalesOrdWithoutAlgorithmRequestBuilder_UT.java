package com.monsanto.customerlink.webservices.client.sap.crechansalesord;

import com.monsanto.customerlink.core.service.util.OrderReasonTypeEnum;
import com.monsanto.customerlink.core.service.util.SeedsCropCodeEnum;
import com.monsanto.customerlink.core.service.util.SeedsSalesOrganizationEnum;
import com.monsanto.customerlink.core.service.util.TransactionTypeMaterial;
import com.monsanto.customerlink.core.webservices.client.sap.crechansalesord.UpdateSalesOrdWithoutAlgorithmRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.client.sap.crechansalesord.YSdsaCreChanSalesOrd;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SAPOrderReasonTypeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SAPOrderTypeDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class UpdateSalesOrdWithoutAlgorithmRequestBuilder_UT {

    private UpdateSalesOrdWithoutAlgorithmRequestBuilder updateSalesOrdWithoutAlgorithm;

    @Before
    public void setup() {
        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setSalesOrgCode(SeedsSalesOrganizationEnum.COTTON_OR_SOYBEAN.getCode());
        distributorProfileDTO.setSalesDivCode("17");
        distributorProfileDTO.setDistChCode("80");

        final MaterialSkuDTO materialSkuDTOI = new MaterialSkuDTO();
        materialSkuDTOI.setItemNumber(30);
        materialSkuDTOI.setTransactionType(TransactionTypeMaterial.INSERT.getCode());
        materialSkuDTOI.setMaterial("COTTON 1");
        materialSkuDTOI.setPlant("5528");
        materialSkuDTOI.setStoragelocation("CWM1");
        materialSkuDTOI.setBatch("45");
        materialSkuDTOI.setUnrestqty(100);

        final MaterialSkuDTO materialSkuDTOU = new MaterialSkuDTO();
        materialSkuDTOU.setItemNumber(10);
        materialSkuDTOU.setTransactionType(TransactionTypeMaterial.UPDATE.getCode());
        materialSkuDTOU.setUnrestqty(100);

        final MaterialSkuDTO materialSkuDTOD = new MaterialSkuDTO();
        materialSkuDTOD.setItemNumber(20);
        materialSkuDTOD.setTransactionType(TransactionTypeMaterial.DELETE.getCode());

        final ProductDTO productDTO = new ProductDTO();
        productDTO.setProductCode("COTTON");
        productDTO.getListOfSku().add(materialSkuDTOI);
        productDTO.getListOfSku().add(materialSkuDTOU);
        productDTO.getListOfSku().add(materialSkuDTOD);

        final OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
        orderDetailDTO.setProductDTO(productDTO);

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(OrderReasonTypeEnum.SBT.toString());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setCropCode(SeedsCropCodeEnum.COTTON.getCode());
        orderDTO.getDetail().add(orderDetailDTO);
        orderDTO.setOrderIdSAP("12345678");

        updateSalesOrdWithoutAlgorithm = new UpdateSalesOrdWithoutAlgorithmRequestBuilder(orderDTO);
    }

    @Test
    public void createSAPOrder() throws Exception {
        final YSdsaCreChanSalesOrd ySdsaCreChanSalesOrd = updateSalesOrdWithoutAlgorithm.build();
        assertThat(ySdsaCreChanSalesOrd, is(notNullValue()));
    }
}
