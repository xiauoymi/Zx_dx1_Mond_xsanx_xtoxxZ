package com.monsanto.customerlink.webservices.client.sap.sendinventory;

import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.sendinventory.SendInventoryClient;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.YESSDSASENDINVENTORY;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.YSdsaSendInventory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SendInventoryClient_UT {

    @Mock
    private JAXWSRequestBuilder<YSdsaSendInventory> jaxwsRequestBuilder;

    @Mock
    private JAXWSResponseProcessor<Object[]> jaxwsResponseProcessor;

    @Mock
    private YESSDSASENDINVENTORY sendInventoryPortType;

    private SendInventoryClient unit;

    @Before
    public void setup() {
        unit = new SendInventoryClient(jaxwsRequestBuilder, jaxwsResponseProcessor, sendInventoryPortType);
    }

    @Test(expected = Exception.class)
    public void throwsExceptionWhenInputParameterIsNull() throws Exception {
        unit.callWebService(null);
    }

    @Test
    public void retrievesYSdsaCreChanSalesOrdResponseType() throws Exception {
        /*
      when(sendInventoryPortType.ySdsaSendInventory((YttSdsaInhybrids)anyObject(),(YttSdsaSdorgSpec)anyObject(),(YttSdsaSpeciesAlg)anyObject())).thenReturn(new YSdsaSendInventoryResponseType());

      final YSdsaSendInventory ySdsaSendInventory = new YSdsaSendInventory();
      final Object object = unit.callWebService(ySdsaSendInventory);
      assertThat(object, is(instanceOf(YSdsaSendInventoryResponseType.class)));
      final YSdsaSendInventoryResponseType responseType = (YSdsaSendInventoryResponseType) object;
      assertThat(responseType, is(notNullValue())); */
    }

}
