package com.monsanto.customerlink.webservices.client.sap.sendinventory;

import com.monsanto.customerlink.core.webservices.client.sap.sendinventory.SendInventoryRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendinventory.YSdsaSendInventory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class SendInventoryRequestBuilder_UT {

    @Mock
    private YSdsaSendInventory ySdsaSendInventory;

    private SendInventoryRequestBuilder unit;

    @Before
    public void setup() {
        unit = new SendInventoryRequestBuilder(ySdsaSendInventory);
    }

    @Test
    public void retrievesTheSameInstanceWithInicializeTheConstructor() throws Exception {
        final YSdsaSendInventory ySdsaSendInventory = unit.build();
        assertThat(ySdsaSendInventory, is(sameInstance(ySdsaSendInventory)));
    }
}
