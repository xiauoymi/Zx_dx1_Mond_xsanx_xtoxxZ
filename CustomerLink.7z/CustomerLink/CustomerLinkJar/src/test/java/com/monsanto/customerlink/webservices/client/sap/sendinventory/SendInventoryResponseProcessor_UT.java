package com.monsanto.customerlink.webservices.client.sap.sendinventory;

import com.monsanto.customerlink.core.webservices.client.sap.sendinventory.SendInventoryResponseProcessor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SendInventoryResponseProcessor_UT {

    private SendInventoryResponseProcessor unit = new SendInventoryResponseProcessor();

    @Test
    public void retrievesTheSameInstanceAtTheInputParameter() throws Exception {

        //final YSdsaSendInventoryResponseType ySdsaSendInventoryResponseType = new YSdsaSendInventoryResponseType();
        final Object[] ySdsaSendInventoryResponseType = new Object[]{};
        final Object object = unit.process(ySdsaSendInventoryResponseType);
        //assertThat(object, is(instanceOf(YSdsaSendInventoryResponseType.class)));

        //final YSdsaSendInventoryResponseType responseType = (YSdsaSendInventoryResponseType) object;
        //assertThat(responseType, is(notNullValue()));
        //assertThat(responseType, is(sameInstance(ySdsaSendInventoryResponseType)));

    }

}