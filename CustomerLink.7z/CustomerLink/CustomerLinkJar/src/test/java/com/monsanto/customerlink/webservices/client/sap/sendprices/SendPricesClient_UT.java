package com.monsanto.customerlink.webservices.client.sap.sendprices;

import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.sendprices.SendPricesClient;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YESSDSASENDCONDITIONS;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YttSdsaCondin;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)

public class SendPricesClient_UT {

    @Mock
    private YESSDSASENDCONDITIONS yessdsasendconditions;
    @Mock
    JAXWSRequestBuilder<YttSdsaCondin> jaxwsRequestBuilder;
    @Mock
    JAXWSResponseProcessor<Object[]> jaxwsResponseProcessor;
    SendPricesClient client;

    @Before
    public void setup() {

        client = new SendPricesClient(jaxwsRequestBuilder, jaxwsResponseProcessor, yessdsasendconditions);
    }

    @Test
    public void testThatClientInvokesService() throws Exception {
        when(jaxwsRequestBuilder.build()).thenReturn(new YttSdsaCondin());
        when(jaxwsResponseProcessor.process(Matchers.<Object[]>any())).thenReturn(new ArrayList<MaterialSkuDTO>());
        Assert.assertNotNull(client.execute());
    }


    @Test(expected = Exception.class)
    public void testThatservicethrowsException() throws Exception {
        when(jaxwsRequestBuilder.build()).thenReturn(new YttSdsaCondin());
        when(jaxwsResponseProcessor.process(Matchers.<Object[]>any())).thenThrow(new Exception());

        client.execute();
    }

}
