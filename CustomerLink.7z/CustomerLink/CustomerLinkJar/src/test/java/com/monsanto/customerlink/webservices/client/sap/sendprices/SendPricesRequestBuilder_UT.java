package com.monsanto.customerlink.webservices.client.sap.sendprices;

import com.monsanto.customerlink.core.webservices.client.sap.sendprices.SendPricesRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.PriceGroupDTO;
import com.monsanto.customerlink.web.services.autogen.product.MaterialSkuDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SendPricesRequestBuilder_UT {

    SendPricesRequestBuilder requestBuilder;

    OrderDTO orderDTO;

    @Before
    public void setup() {
        orderDTO = new OrderDTO();
        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        configDTO.setDistChCode("DistChCode");
        configDTO.setSalesOrgCode("SalesOrgCode");

        DistributorDTO distributorDTO = new DistributorDTO();
        configDTO.setDistributor(distributorDTO);

        orderDTO.setDistributorConfigDTO(configDTO);
        PriceGroupDTO priceGroupDTO= new PriceGroupDTO();
        orderDTO.setPriceGroup(priceGroupDTO);


        for (int i = 0; i < 10; i++) {
            OrderDetailDTO orderDetailDTO = new OrderDetailDTO();
            ProductDTO productDTO = new ProductDTO();

            for (int j = 0; j < 10; j++) {
                MaterialSkuDTO materialSkuDTO = new MaterialSkuDTO();

                productDTO.getListOfSku().add(materialSkuDTO);
            }

            orderDetailDTO.setProductDTO(productDTO);
            orderDTO.getDetail().add(orderDetailDTO);
        }

        requestBuilder = new SendPricesRequestBuilder(orderDTO);
    }

    @Test
    public void test() throws Exception {
        requestBuilder.build();
    }
}
