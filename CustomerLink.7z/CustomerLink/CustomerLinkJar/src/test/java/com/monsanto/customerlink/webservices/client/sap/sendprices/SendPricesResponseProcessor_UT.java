package com.monsanto.customerlink.webservices.client.sap.sendprices;

import com.monsanto.customerlink.core.webservices.client.sap.sendprices.SendPricesResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YsdsaCondout;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YsdsaErrors;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YttSdsaCondout;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendprices.YttSdsaErrors;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SendPricesResponseProcessor_UT {

    SendPricesResponseProcessor processor;

    Object[] responseType;

    @Before
    public void setup() {
        YttSdsaCondout condout = new YttSdsaCondout();

        for (int i = 0; i < 10; i++) {
            YsdsaCondout ysdsaCondout = new YsdsaCondout();
            condout.getItem().add(ysdsaCondout);
        }

        responseType = new Object[]{null, condout};
        processor = new SendPricesResponseProcessor();
    }

    @Test
    public void testThatListOfMaterialsIsMadeAndReturnedCorrectly() throws Exception {
        processor.process(responseType);
    }

    @Test
    public void testThatListOfErrorIsMadeAndReturnedCorrectly() throws Exception {
        YttSdsaErrors yttSdsaErrors = new YttSdsaErrors();

        for (int i = 0; i < 10; i++) {
            YsdsaErrors error = new YsdsaErrors();

            error.setYyid("id" + i);
            error.setYymessage("message" + i);
            error.setYynumber("" + i);
            error.setYytype("type" + i);
            yttSdsaErrors.getItem().add(error);
        }

        responseType = new Object[]{yttSdsaErrors, null};

         processor.process(responseType);
    }
}
