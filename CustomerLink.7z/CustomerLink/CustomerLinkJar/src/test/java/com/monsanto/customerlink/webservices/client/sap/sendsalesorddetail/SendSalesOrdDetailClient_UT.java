package com.monsanto.customerlink.webservices.client.sap.sendsalesorddetail;

import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.sendsalesorddetail.SendSalesOrdDetailClient;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendsalesorddetail.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SendSalesOrdDetailClient_UT {

    @Mock
    private JAXWSRequestBuilder<YSdsaSendSoDetail> jaxwsRequestBuilder;

    @Mock
    private JAXWSResponseProcessor<Object[]> jaxwsResponseProcessor;

    @Mock
    private YESSDSASENDSODETAIL sendSalesOrdDetailPortType;

    private SendSalesOrdDetailClient unit;

    @Before
    public void setup() {
        unit = new SendSalesOrdDetailClient(jaxwsRequestBuilder, jaxwsResponseProcessor, sendSalesOrdDetailPortType);
    }

    @Test(expected = Exception.class)
    public void throwsExceptionWhenInputParameterIsNull() throws Exception {
        unit.callWebService(null);
    }

    @Test
    public void retrievesYSdsaCreChanSalesOrdResponseType() throws Exception {
        /*
        when(sendSalesOrdDetailPortType.ySdsaSendSoDetail((String) anyObject(), (YttSdsaSlshead) anyObject(), (YttSdsaSlsordtyp) anyObject())).thenReturn(new YSdsaSendSoDetailResponseType());

        final YSdsaSendSoDetail ySdsaSendSoDetail = new YSdsaSendSoDetail();
        final Object object = unit.callWebService(ySdsaSendSoDetail);
        assertThat(object, is(instanceOf(YSdsaSendSoDetailResponseType.class)));
        final YSdsaSendSoDetailResponseType ySdsaSendSoDetailResponseType = (YSdsaSendSoDetailResponseType) object;
        assertThat(ySdsaSendSoDetailResponseType, is(notNullValue()));
        */
    }
}
