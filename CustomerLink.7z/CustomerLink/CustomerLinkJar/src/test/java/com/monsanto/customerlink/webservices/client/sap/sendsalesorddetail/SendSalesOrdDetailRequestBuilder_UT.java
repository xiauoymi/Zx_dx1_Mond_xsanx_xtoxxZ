package com.monsanto.customerlink.webservices.client.sap.sendsalesorddetail;

import com.monsanto.customerlink.core.service.util.CLOrderTypeEnum;
import com.monsanto.customerlink.core.webservices.client.sap.sendsalesorddetail.SendSalesOrdDetailRequestBuilder;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendsalesorddetail.YSdsaSendSoDetail;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.RepresentativeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SAPOrderReasonTypeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SAPOrderTypeDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SearchPeriodDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class SendSalesOrdDetailRequestBuilder_UT {

    private SendSalesOrdDetailRequestBuilder requestBuilder;

    @Test
    public void retrievesYSdsaSalesOrdDetailWhenDistributorProfileIsNull() throws Exception {
        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setSearchPeriodDTO(new SearchPeriodDTO());

        requestBuilder = new SendSalesOrdDetailRequestBuilder(orderDTO);

        final YSdsaSendSoDetail ySdsaSendSoDetail = requestBuilder.build();
        assertThat(ySdsaSendSoDetail, is(notNullValue()));
    }

    @Test
    public void retrievesYSdsaSalesOrdDetailWhenDistributorProfileIsNotNull() throws Exception {
        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setSearchPeriodDTO(new SearchPeriodDTO());
        requestBuilder = new SendSalesOrdDetailRequestBuilder(orderDTO);

        final YSdsaSendSoDetail ySdsaSendSoDetail = requestBuilder.build();
        assertThat(ySdsaSendSoDetail, is(notNullValue()));
    }

    @Test
    public void retrievesYSdsaSalesOrdDetailWhenDistributorProfileAndDistributorAreNotNull() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setDistributor(distributorDTO);

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setSearchPeriodDTO(new SearchPeriodDTO());
        requestBuilder = new SendSalesOrdDetailRequestBuilder(orderDTO);

        final YSdsaSendSoDetail ySdsaSendSoDetail = requestBuilder.build();
        assertThat(ySdsaSendSoDetail, is(notNullValue()));
    }

    @Test
    public void retrievesYSdsaSalesOrdDetailWhenRepresentativeSAPCodeIsEmpty() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setDistributor(distributorDTO);

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setSearchPeriodDTO(new SearchPeriodDTO());
        orderDTO.setRepresentativeDTO(representativeDTO);

        requestBuilder = new SendSalesOrdDetailRequestBuilder(orderDTO);

        final YSdsaSendSoDetail ySdsaSendSoDetail = requestBuilder.build();
        assertThat(ySdsaSendSoDetail, is(notNullValue()));
    }

    @Test
    public void retrievesYSdsaSalesOrdDetailWhenRepresentativeSAPCodeIsNotEmpty() throws Exception {
        final DistributorDTO distributorDTO = new DistributorDTO();

        final DistributorConfigDTO distributorProfileDTO = new DistributorConfigDTO();
        distributorProfileDTO.setDistributor(distributorDTO);

        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode(CLOrderTypeEnum.WITH_ALGORITHM.code());

        final SAPOrderTypeDTO sapOrderTypeDTO = new SAPOrderTypeDTO();
        sapOrderTypeDTO.setOrderTypeCode("ZPM9");

        final RepresentativeDTO representativeDTO = new RepresentativeDTO();
        representativeDTO.setSapUserId("1234567890");

        final OrderDTO orderDTO = new OrderDTO();
        orderDTO.setDistributorConfigDTO(distributorProfileDTO);
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);
        orderDTO.setSapOrderTypeDTO(sapOrderTypeDTO);
        orderDTO.setSearchPeriodDTO(new SearchPeriodDTO());
        orderDTO.setRepresentativeDTO(representativeDTO);

        requestBuilder = new SendSalesOrdDetailRequestBuilder(orderDTO);

        final YSdsaSendSoDetail ySdsaSendSoDetail = requestBuilder.build();
        assertThat(ySdsaSendSoDetail, is(notNullValue()));
    }
}
