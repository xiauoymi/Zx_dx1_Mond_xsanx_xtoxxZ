package com.monsanto.customerlink.webservices.client.sap.sendsalesorddetail;

import com.monsanto.customerlink.core.service.facade.dto.SAPOrderDTO;
import com.monsanto.customerlink.core.webservices.client.sap.sendsalesorddetail.SendSalesOrdDetailResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendsalesorddetail.YsdsaSlsheadout;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendsalesorddetail.YsdsaSlsitemout2;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendsalesorddetail.YttSdsaSlsheadout;
import com.monsanto.customerlink.web.services.autogen.client.sap.sendsalesorddetail.YttSdsaSlsitemout2;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class SendSalesOrdDetailResponseProcessor_UT {

    private SendSalesOrdDetailResponseProcessor responseProcessor;

    @Before
    public void setup() {
        responseProcessor = new SendSalesOrdDetailResponseProcessor();
    }

    @Test
    public void retrievesEmptySAPOrderListWhenResponseIsNull() throws Exception {
        final Object object = responseProcessor.process(null);
        assertThat(object, is(notNullValue()));
        assertThat(object, is(instanceOf(List.class)));
        final List<SAPOrderDTO> sapOrderDTOList = (List<SAPOrderDTO>) object;
        assertThat(sapOrderDTOList.isEmpty(), is(Boolean.TRUE));
    }

    @Test
    public void retrievesEmptySAPOrderListWhenResponseHeaderTableIsNull() throws Exception {
        //final YSdsaSendSoDetailResponseType ySdsaSendSoDetailResponseType = new YSdsaSendSoDetailResponseType();

        final Object object = responseProcessor.process(new Object[]{null, null, null});
        assertThat(object, is(notNullValue()));
        assertThat(object, is(instanceOf(List.class)));
        final List<SAPOrderDTO> sapOrderDTOList = (List<SAPOrderDTO>) object;
        assertThat(sapOrderDTOList.isEmpty(), is(Boolean.TRUE));
    }

    @Test
    public void retrievesEmptySAPOrderListWhenResponseHeaderTableIsEmpty() throws Exception {
        final YttSdsaSlsheadout yttSdsaSlsheadout = new YttSdsaSlsheadout();

        // final YSdsaSendSoDetailResponseType ySdsaSendSoDetailResponseType = new YSdsaSendSoDetailResponseType();

        // ySdsaSendSoDetailResponseType.setSlsheadout(yttSdsaSlsheadout);

        final Object object = responseProcessor.process(new Object[]{null, yttSdsaSlsheadout, null});
        assertThat(object, is(notNullValue()));
        assertThat(object, is(instanceOf(List.class)));
        final List<SAPOrderDTO> sapOrderDTOList = (List<SAPOrderDTO>) object;
        assertThat(sapOrderDTOList.isEmpty(), is(Boolean.TRUE));
    }

    @Test
    public void retrievesSAPOrderListWithHybridsListEmptyAndErrorListWithAErrorWhenResponseHeaderTableIsNotEmptyAndResponseDetailTableIsNull() throws Exception {
        final YsdsaSlsheadout ysdsaSlsheadout1 = new YsdsaSlsheadout();
        ysdsaSlsheadout1.setYysalesorder("1");
        ysdsaSlsheadout1.setYyrecDate("2013-08-09");

        final YsdsaSlsheadout ysdsaSlsheadout2 = new YsdsaSlsheadout();
        ysdsaSlsheadout2.setYysalesorder("2");
        ysdsaSlsheadout2.setYyrecDate("2013-08-09");

        final YttSdsaSlsheadout yttSdsaSlsheadout = new YttSdsaSlsheadout();
        yttSdsaSlsheadout.getItem().add(ysdsaSlsheadout1);
        yttSdsaSlsheadout.getItem().add(ysdsaSlsheadout2);

        //final YSdsaSendSoDetailResponseType ySdsaSendSoDetailResponseType = new YSdsaSendSoDetailResponseType();

        //ySdsaSendSoDetailResponseType.setSlsheadout(new Object[]{});

        final Object object = responseProcessor.process(new Object[]{null, yttSdsaSlsheadout, null});
        assertThat(object, is(notNullValue()));
        assertThat(object, is(instanceOf(List.class)));
        final List<SAPOrderDTO> sapOrderDTOList = (List<SAPOrderDTO>) object;
        assertThat(sapOrderDTOList.isEmpty(), is(Boolean.FALSE));
        assertThat(sapOrderDTOList.size(), is(2));
        for (final SAPOrderDTO sapOrderDTO : sapOrderDTOList) {
            assertThat(sapOrderDTO.getHybrids().isEmpty(), is(Boolean.TRUE));
            assertThat(sapOrderDTO.getErrors().isEmpty(), is(Boolean.FALSE));
            assertThat(sapOrderDTO.getErrors().size(), is(1));
            assertThat(sapOrderDTO.getErrors().get(0).getMessage(), is("The order is incomplete"));
        }
    }

    @Test
    public void retrievesSAPOrderListWithHybridsListEmptyAndErrorListWithAErrorWhenResponseHeaderTableIsNotEmptyAndResponseDetailTableIsEmpty() throws Exception {
        final YsdsaSlsheadout ysdsaSlsheadout1 = new YsdsaSlsheadout();
        ysdsaSlsheadout1.setYysalesorder("1");
        ysdsaSlsheadout1.setYyrecDate("2013-08-09");

        final YsdsaSlsheadout ysdsaSlsheadout2 = new YsdsaSlsheadout();
        ysdsaSlsheadout2.setYysalesorder("2");
        ysdsaSlsheadout2.setYyrecDate("2013-08-09");

        final YttSdsaSlsheadout yttSdsaSlsheadout = new YttSdsaSlsheadout();
        yttSdsaSlsheadout.getItem().add(ysdsaSlsheadout1);
        yttSdsaSlsheadout.getItem().add(ysdsaSlsheadout2);

        final YttSdsaSlsitemout2 yttSdsaSlsitemout = new YttSdsaSlsitemout2();

        // final YSdsaSendSoDetailResponseType ySdsaSendSoDetailResponseType = new YSdsaSendSoDetailResponseType();
        //ySdsaSendSoDetailResponseType.setSlsheadout(yttSdsaSlsheadout);
        //ySdsaSendSoDetailResponseType.setSlsitemout(yttSdsaSlsitemout);

        final Object object = responseProcessor.process(new Object[]{null, yttSdsaSlsheadout, yttSdsaSlsitemout});
        assertThat(object, is(notNullValue()));
        assertThat(object, is(instanceOf(List.class)));
        final List<SAPOrderDTO> sapOrderDTOList = (List<SAPOrderDTO>) object;
        assertThat(sapOrderDTOList.isEmpty(), is(Boolean.FALSE));
        assertThat(sapOrderDTOList.size(), is(2));
        for (final SAPOrderDTO sapOrderDTO : sapOrderDTOList) {
            assertThat(sapOrderDTO.getHybrids().isEmpty(), is(Boolean.TRUE));
            assertThat(sapOrderDTO.getErrors().isEmpty(), is(Boolean.FALSE));
            assertThat(sapOrderDTO.getErrors().size(), is(1));
            assertThat(sapOrderDTO.getErrors().get(0).getMessage(), is("The order is incomplete"));
        }
    }

    @Test
    public void retrievesSAPOrderListWhenAnyOutputParameterIsNullOrEmpty() throws Exception {
        final YsdsaSlsheadout ysdsaSlsheadout1 = new YsdsaSlsheadout();
        ysdsaSlsheadout1.setYysalesorder("1");
        ysdsaSlsheadout1.setYyrecDate("2013-08-09");

        final YsdsaSlsheadout ysdsaSlsheadout2 = new YsdsaSlsheadout();
        ysdsaSlsheadout2.setYysalesorder("2");
        ysdsaSlsheadout2.setYyrecDate("2013-08-09");

        final YsdsaSlsheadout ysdsaSlsheadout3 = new YsdsaSlsheadout();
        ysdsaSlsheadout3.setYysalesorder("3");
        ysdsaSlsheadout3.setYyrecDate("2013-08-09");

        final YsdsaSlsheadout ysdsaSlsheadout4 = new YsdsaSlsheadout();
        ysdsaSlsheadout4.setYysalesorder("4");
        ysdsaSlsheadout4.setYyrecDate("2013-08-09");

        final YttSdsaSlsheadout yttSdsaSlsheadout = new YttSdsaSlsheadout();
        yttSdsaSlsheadout.getItem().add(ysdsaSlsheadout1);
        yttSdsaSlsheadout.getItem().add(ysdsaSlsheadout2);
        yttSdsaSlsheadout.getItem().add(ysdsaSlsheadout3);
        yttSdsaSlsheadout.getItem().add(ysdsaSlsheadout4);

        final YsdsaSlsitemout2 ysdsaSlsitemout1 = new YsdsaSlsitemout2();
        ysdsaSlsitemout1.setYyitmNumber("10");
        ysdsaSlsitemout1.setYysalesorder("1");
        ysdsaSlsitemout1.setYyhybrid("CANGURO");
        ysdsaSlsitemout1.setYymaterial("MATERIAL 1");
        ysdsaSlsitemout1.setYyreqQty(BigDecimal.valueOf(10));
        ysdsaSlsitemout1.setYydelQty(BigDecimal.valueOf(10));

        final YsdsaSlsitemout2 ysdsaSlsitemout2 = new YsdsaSlsitemout2();
        ysdsaSlsitemout2.setYyitmNumber("10");
        ysdsaSlsitemout2.setYysalesorder("2");
        ysdsaSlsitemout2.setYyhybrid("PONCHO");
        ysdsaSlsitemout2.setYymaterial("MATERIAL 1");
        ysdsaSlsitemout2.setYyreqQty(BigDecimal.valueOf(20));
        ysdsaSlsitemout2.setYydelQty(BigDecimal.valueOf(10));

        final YsdsaSlsitemout2 ysdsaSlsitemout3 = new YsdsaSlsitemout2();
        ysdsaSlsitemout3.setYyitmNumber("20");
        ysdsaSlsitemout3.setYysalesorder("2");
        ysdsaSlsitemout3.setYyhybrid("PONCHO");
        ysdsaSlsitemout3.setYymaterial("MATERIAL 1");
        ysdsaSlsitemout3.setYyreqQty(BigDecimal.valueOf(30));
        ysdsaSlsitemout3.setYydelQty(BigDecimal.valueOf(10));

        final YsdsaSlsitemout2 ysdsaSlsitemout4 = new YsdsaSlsitemout2();
        ysdsaSlsitemout4.setYyitmNumber("10");
        ysdsaSlsitemout4.setYysalesorder("3");
        ysdsaSlsitemout4.setYyhybrid("CANGURO");
        ysdsaSlsitemout4.setYymaterial("MATERIAL 1");
        ysdsaSlsitemout4.setYyreqQty(BigDecimal.valueOf(10));
        ysdsaSlsitemout4.setYydelQty(BigDecimal.valueOf(10));

        final YsdsaSlsitemout2 ysdsaSlsitemout5 = new YsdsaSlsitemout2();
        ysdsaSlsitemout5.setYyitmNumber("20");
        ysdsaSlsitemout5.setYysalesorder("3");
        ysdsaSlsitemout5.setYyhybrid("PONCHO");
        ysdsaSlsitemout5.setYymaterial("MATERIAL 1");
        ysdsaSlsitemout5.setYyreqQty(BigDecimal.valueOf(20));
        ysdsaSlsitemout5.setYydelQty(BigDecimal.valueOf(10));

        final YsdsaSlsitemout2 ysdsaSlsitemout6 = new YsdsaSlsitemout2();
        ysdsaSlsitemout6.setYyitmNumber("30");
        ysdsaSlsitemout6.setYysalesorder("3");
        ysdsaSlsitemout6.setYyhybrid("PONCHO");
        ysdsaSlsitemout6.setYymaterial("MATERIAL 1");
        ysdsaSlsitemout6.setYyreqQty(BigDecimal.valueOf(30));
        ysdsaSlsitemout6.setYydelQty(BigDecimal.valueOf(10));

        final YsdsaSlsitemout2 ysdsaSlsitemout7 = new YsdsaSlsitemout2();
        ysdsaSlsitemout7.setYyitmNumber("40");
        ysdsaSlsitemout7.setYysalesorder("3");
        ysdsaSlsitemout7.setYyhybrid("CANGURO");
        ysdsaSlsitemout7.setYymaterial("MATERIAL 2");
        ysdsaSlsitemout7.setYyreqQty(BigDecimal.valueOf(40));
        ysdsaSlsitemout7.setYydelQty(BigDecimal.valueOf(10));

        final YsdsaSlsitemout2 ysdsaSlsitemout8 = new YsdsaSlsitemout2();
        ysdsaSlsitemout8.setYyitmNumber("50");
        ysdsaSlsitemout8.setYysalesorder("3");
        ysdsaSlsitemout8.setYyhybrid("ASGRO");
        ysdsaSlsitemout8.setYymaterial("MATERIAL 2");
        ysdsaSlsitemout8.setYyreqQty(BigDecimal.valueOf(50));
        ysdsaSlsitemout8.setYydelQty(BigDecimal.valueOf(10));

        final YttSdsaSlsitemout2 yttSdsaSlsitemout = new YttSdsaSlsitemout2();
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout1);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout2);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout3);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout4);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout5);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout6);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout7);
        yttSdsaSlsitemout.getItem().add(ysdsaSlsitemout8);

        //final YSdsaSendSoDetailResponseType ySdsaSendSoDetailResponseType = new YSdsaSendSoDetailResponseType();
        //ySdsaSendSoDetailResponseType.setSlsheadout(yttSdsaSlsheadout);
        //ySdsaSendSoDetailResponseType.setSlsitemout(yttSdsaSlsitemout);

        final Object object = responseProcessor.process(new Object[]{null, yttSdsaSlsheadout, yttSdsaSlsitemout});
        assertThat(object, is(notNullValue()));
        assertThat(object, is(instanceOf(List.class)));
        final List<SAPOrderDTO> sapOrderDTOList = (List<SAPOrderDTO>) object;
        assertThat(sapOrderDTOList.isEmpty(), is(Boolean.FALSE));
        assertThat(sapOrderDTOList.size(), is(4));

        final SAPOrderDTO sapOrderDTO1 = sapOrderDTOList.get(0);
        assertThat(sapOrderDTO1.getHybrids().isEmpty(), is(Boolean.FALSE));
        assertThat(sapOrderDTO1.getHybrids().size(), is(1));
        assertThat(sapOrderDTO1.getHybrids().get(0).getSkus().isEmpty(), is(Boolean.FALSE));
        assertThat(sapOrderDTO1.getHybrids().get(0).getSkus().size(), is(1));
        assertThat(sapOrderDTO1.getErrors().isEmpty(), is(Boolean.TRUE));

        final SAPOrderDTO sapOrderDTO2 = sapOrderDTOList.get(1);
        assertThat(sapOrderDTO2.getHybrids().isEmpty(), is(Boolean.FALSE));
        assertThat(sapOrderDTO2.getHybrids().size(), is(1));
        assertThat(sapOrderDTO2.getHybrids().get(0).getSkus().isEmpty(), is(Boolean.FALSE));
        assertThat(sapOrderDTO2.getHybrids().get(0).getSkus().size(), is(2));
        assertThat(sapOrderDTO2.getErrors().isEmpty(), is(Boolean.TRUE));

        final SAPOrderDTO sapOrderDTO3 = sapOrderDTOList.get(2);
        assertThat(sapOrderDTO3.getHybrids().isEmpty(), is(Boolean.FALSE));
        assertThat(sapOrderDTO3.getHybrids().size(), is(3));
        assertThat(sapOrderDTO3.getHybrids().get(0).getSkus().isEmpty(), is(Boolean.FALSE));
        assertThat(sapOrderDTO3.getHybrids().get(0).getSkus().size(), is(2));
        assertThat(sapOrderDTO3.getHybrids().get(1).getSkus().isEmpty(), is(Boolean.FALSE));
        assertThat(sapOrderDTO3.getHybrids().get(1).getSkus().size(), is(2));
        assertThat(sapOrderDTO3.getHybrids().get(2).getSkus().isEmpty(), is(Boolean.FALSE));
        assertThat(sapOrderDTO3.getHybrids().get(2).getSkus().size(), is(1));
        assertThat(sapOrderDTO3.getErrors().isEmpty(), is(Boolean.TRUE));

        final SAPOrderDTO sapOrderDTO4 = sapOrderDTOList.get(3);
        assertThat(sapOrderDTO4.getHybrids().isEmpty(), is(Boolean.TRUE));
        assertThat(sapOrderDTO4.getErrors().isEmpty(), is(Boolean.FALSE));
        assertThat(sapOrderDTO4.getErrors().size(), is(1));
        assertThat(sapOrderDTO4.getErrors().get(0).getMessage(), is("The order is incomplete"));
    }
}
