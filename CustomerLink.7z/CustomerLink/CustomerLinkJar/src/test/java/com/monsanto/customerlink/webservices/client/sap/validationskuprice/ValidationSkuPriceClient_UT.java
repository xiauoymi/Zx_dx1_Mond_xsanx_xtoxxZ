package com.monsanto.customerlink.webservices.client.sap.validationskuprice;

import com.monsanto.customerlink.core.webservices.JAXWSRequestBuilder;
import com.monsanto.customerlink.core.webservices.JAXWSResponseProcessor;
import com.monsanto.customerlink.core.webservices.client.sap.dto.ValidationSkuPriceDTO;
import com.monsanto.customerlink.core.webservices.client.sap.validationskuprice.ValidationSkuPriceClient;
import com.monsanto.customerlink.web.services.autogen.client.sap.validateskuprice.YESSDSAVALIDATESKU;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ValidationSkuPriceClient_UT {
    @Mock
    private JAXWSRequestBuilder<ValidationSkuPriceDTO> jaxwsRequestBuilder;
    @Mock
    private JAXWSResponseProcessor<ValidationSkuPriceDTO> jaxwsResponseProcessor;
    @Mock
    private YESSDSAVALIDATESKU validationSkuPricePortType;


    ValidationSkuPriceClient client;

    @Before
    public void setup() {
        client = new ValidationSkuPriceClient(jaxwsRequestBuilder, jaxwsResponseProcessor, validationSkuPricePortType);
    }

    @Test
    public void testReturnSameValidationDTOWhenBuilderAndProcessorRunsCorrectly() throws Exception {
        ValidationSkuPriceDTO validationSkuPriceDTO = new ValidationSkuPriceDTO();
        when(jaxwsRequestBuilder.build()).thenReturn(validationSkuPriceDTO);
        when(jaxwsResponseProcessor.process(Matchers.<ValidationSkuPriceDTO>any())).thenReturn(validationSkuPriceDTO);
        Assert.assertNotNull(client.execute());
    }



}
