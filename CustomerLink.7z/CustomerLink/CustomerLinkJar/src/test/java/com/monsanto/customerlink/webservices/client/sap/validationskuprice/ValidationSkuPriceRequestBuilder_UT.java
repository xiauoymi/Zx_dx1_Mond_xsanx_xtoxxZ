package com.monsanto.customerlink.webservices.client.sap.validationskuprice;


import com.monsanto.customerlink.core.service.util.OrderReasonTypeEnum;
import com.monsanto.customerlink.core.webservices.client.sap.validationskuprice.ValidationSkuPriceRequestBuilder;
import com.monsanto.customerlink.persistence.entities.CropVO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.PriceGroupDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SAPOrderReasonTypeDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class ValidationSkuPriceRequestBuilder_UT {

    ValidationSkuPriceRequestBuilder validationSkuPriceRequestBuilder;

    //List<OrderDTO> orderDTOList = new ArrayList<OrderDTO>();
    OrderDTO orderDTO = new OrderDTO();
    List<CropVO> cropVOList = new ArrayList<CropVO>();

    @Before
    public void setup() {

        //for (int i = 0; i < 5; i++) {
        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode("reasonCode" + 1);

        orderDTO = new OrderDTO();
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);


        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        configDTO.setDistChCode("DistChCode");
        configDTO.setSalesDivCode("SalesDivCode");
        configDTO.setSalesOrgCode("SalesOrgCode");
        configDTO.setSubRegionCode("SubRegionCode");

        DistributorDTO distributorDTO = new DistributorDTO();

        distributorDTO.setDistributorCode("DistributorCode");
        configDTO.setDistributor(distributorDTO);


        PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setBrandCode("BrandCode");
        priceGroupDTO.setPriceGroupCode("PriceGroupCode");


        List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();

        for (int j = 0; j < 5; j++) {
            OrderDetailDTO detailDTO = new OrderDetailDTO();
            ProductDTO productDTO = new ProductDTO();
            productDTO.setProductCode("ProductCode");
            productDTO.setCropCode("CropCode");
            productDTO.setBrandCode("BrandCode");
            productDTO.setSalesDivisionCode("SalesDivisionCode");
            productDTO.setSubDivisionCode("SubDivisionCode");
            productDTO.setTreatmentCode("TreatmentCode");
            detailDTO.setProductDTO(productDTO);
            orderDetailDTOList.add(detailDTO);
        }

        orderDTO.setDetail(orderDetailDTOList);
        orderDTO.setPriceGroup(priceGroupDTO);
        orderDTO.setDistributorConfigDTO(configDTO);

        //orderDTOList.add(dto);

        CropVO cropVO = new CropVO();
        cropVO.setCropCode("CropCode");
        cropVO.setSalesDivisionCode("SalesDivisionCode");
        cropVO.setSpecieAlg(true);
        cropVO.setSpecieCode("SpecieCode");
        cropVO.setSpecieClass("SpecieClass");
        cropVOList.add(cropVO);
        //}

        validationSkuPriceRequestBuilder =
                new ValidationSkuPriceRequestBuilder(orderDTO, cropVOList);
    }

    @Test
    public void testThatIsContructedObjectQithParametersReceived() throws Exception {
        Assert.assertNotNull(validationSkuPriceRequestBuilder.build());
    }
}
