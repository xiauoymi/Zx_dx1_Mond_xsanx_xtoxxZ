package com.monsanto.customerlink.webservices.client.sap.validationskuprice;

import com.monsanto.customerlink.core.webservices.client.sap.dto.ValidationSkuPriceDTO;
import com.monsanto.customerlink.core.webservices.client.sap.validationskuprice.ValidationSkuPriceResponseProcessor;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorConfigDTO;
import com.monsanto.customerlink.web.services.autogen.distributor.DistributorDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.OrderDetailDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.PriceGroupDTO;
import com.monsanto.customerlink.web.services.autogen.dummyorder.SAPOrderReasonTypeDTO;
import com.monsanto.customerlink.web.services.autogen.product.ProductDTO;
import com.monsanto.customerlink.web.services.autogen.client.sap.validateskuprice.YsdsaErrref;
import com.monsanto.customerlink.web.services.autogen.client.sap.validateskuprice.YttSdsaErrref;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class ValidationSkuPriceResponseProcessor_UT {

    ValidationSkuPriceResponseProcessor validationSkuPriceResponseProcessor;
    OrderDTO orderDTO = new OrderDTO();
    ValidationSkuPriceDTO validationSkuPriceDTO = new ValidationSkuPriceDTO();


    @Before
    public void setup() {
        final SAPOrderReasonTypeDTO sapOrderReasonTypeDTO = new SAPOrderReasonTypeDTO();
        sapOrderReasonTypeDTO.setOrderReasonTypeCode("reasonCode" + 1);
        orderDTO.setSapOrderReasonTypeDTO(sapOrderReasonTypeDTO);


        DistributorConfigDTO configDTO = new DistributorConfigDTO();
        configDTO.setDistChCode("DistChCode");
        configDTO.setSalesDivCode("SalesDivCode");
        configDTO.setSalesOrgCode("SalesOrgCode");
        configDTO.setSubRegionCode("SubRegionCode");

        DistributorDTO distributorDTO = new DistributorDTO();

        distributorDTO.setDistributorCode("DistributorCode");
        configDTO.setDistributor(distributorDTO);


        PriceGroupDTO priceGroupDTO = new PriceGroupDTO();
        priceGroupDTO.setBrandCode("BrandCode");
        priceGroupDTO.setPriceGroupCode("PriceGroupCode");


        List<OrderDetailDTO> orderDetailDTOList = new ArrayList<OrderDetailDTO>();

        for (int j = 0; j < 5; j++) {
            OrderDetailDTO detailDTO = new OrderDetailDTO();
            ProductDTO productDTO = new ProductDTO();
            productDTO.setProductCode("ProductCode");
            productDTO.setBrandCode("BrandCode");
            productDTO.setSalesDivisionCode("SalesDivisionCode");
            productDTO.setSubDivisionCode("SubDivisionCode");
            productDTO.setTreatmentCode("TreatmentCode");
            detailDTO.setProductDTO(productDTO);
            orderDetailDTOList.add(detailDTO);
        }

        orderDTO.setDetail(orderDetailDTOList);
        orderDTO.setPriceGroup(priceGroupDTO);
        orderDTO.setDistributorConfigDTO(configDTO);
        validationSkuPriceDTO.setOrderDTO(orderDTO);

        YttSdsaErrref yttSdsaErrref = new YttSdsaErrref();

        for (int i = 0; i < 3; i++) {
            YsdsaErrref errref = new YsdsaErrref();
            errref.setYyerrcode("yerrcode");
            errref.setYyhybrid("ProductCode"+i);
            errref.setYymaterial("ymaterial");
            yttSdsaErrref.getItem().add(errref);
        }

        validationSkuPriceDTO.setYttSdsaErrref(yttSdsaErrref);
        validationSkuPriceResponseProcessor = new ValidationSkuPriceResponseProcessor();
    }

    @Test
    public void test() throws Exception {

        validationSkuPriceResponseProcessor.process(validationSkuPriceDTO);
    }
}
