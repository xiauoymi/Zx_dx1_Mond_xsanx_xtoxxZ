package com.monsanto.customerlink.webservices.util;


import com.monsanto.customerlink.core.service.util.TreatmentEnum;
import com.monsanto.customerlink.core.webservices.util.ClientUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ClientUtils_UT {

    @Test
    public void returnPonchoP5WhenReceivesPonchoCP() {
        Assert.assertEquals(ClientUtils.filterTreatment(TreatmentEnum.ST_PONCHO_CP.getCode()),
                TreatmentEnum.ST_PONCHO_P5.getCode());
    }

    @Test
    public void returnPonchoP5WhenReceivesPoncho() {
        Assert.assertEquals(ClientUtils.filterTreatment(TreatmentEnum.ST_PONCHO.getCode()),
                TreatmentEnum.ST_PONCHO_P5.getCode());
    }

    @Test
    public void returnPonchoP5WhenReceivesPonchoPM() {
        Assert.assertEquals(ClientUtils.filterTreatment(TreatmentEnum.ST_PONCHO_PM.getCode()),
                TreatmentEnum.ST_PONCHO_P5.getCode());
    }

    @Test
    public void returnSameTreatmentWhenReceivesAnytreatmentDifferentOfPonchoP5AndpPonchoPM() {
        Assert.assertEquals(ClientUtils.filterTreatment(TreatmentEnum.ST_PONCHO_P5.getCode()),
                TreatmentEnum.ST_PONCHO_P5.getCode());

        Assert.assertEquals(ClientUtils.filterTreatment(TreatmentEnum.ST_APRON.getCode()),
                TreatmentEnum.ST_APRON.getCode());

        Assert.assertEquals(ClientUtils.filterTreatment(TreatmentEnum.ST_PONCHO_BAYTAN.getCode()),
                TreatmentEnum.ST_PONCHO_BAYTAN.getCode());

        Assert.assertEquals(ClientUtils.filterTreatment(TreatmentEnum.STANDARD.getCode()),
                TreatmentEnum.STANDARD.getCode());
    }

    @Test
    public void createClassWithConstructor() {
         ClientUtils utils= new  ClientUtils();
        Assert.assertNotNull(utils);
    }

}
