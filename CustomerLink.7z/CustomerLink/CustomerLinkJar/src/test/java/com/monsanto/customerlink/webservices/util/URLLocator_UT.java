package com.monsanto.customerlink.webservices.util;

import com.monsanto.customerlink.core.webservices.util.URLLocator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.fail;

@RunWith(MockitoJUnitRunner.class)
public class URLLocator_UT {

    private URLLocator locator;

    @Before
    public void setup(){
        locator = new URLLocator("customerlink-webservices-urls");
        System.setProperty("lsi.function", "dev");
    }

    @Test
    public void getEnvironmentReturnsNotNull(){
        assertNotNull(locator.getEnvironment());
    }

    @Test
    public void getWSDLURLReturnsNotNull(){
         assertNotNull(locator.getWSDLURL("atp"));
    }

    @Test(expected = RuntimeException.class)
    public void getWSDLURLThrowsMUE(){
        locator.getWSDLURL("malformed");
    }

}
