package com.monsanto.enterprise.customerlink.services;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AuditableRestUserInterceptor extends AbstractPhaseInterceptor<Message> {

    @Autowired
    private ApplicationContext applicationContext;

    public AuditableRestUserInterceptor() {
        super(Phase.RECEIVE);
    }

    @Override
    public void handleMessage(Message message) throws Fault {
        Map headerProperties = (Map) message.get(Message.PROTOCOL_HEADERS);
        if (headerProperties.containsKey("userName")) {
            String userName = ((ArrayList<String>) headerProperties.get("userName")).get(0);
            HashMap<String, String> userMap = (HashMap) applicationContext.getBean("userMap");
            userMap.put("user", userName);
        }
    }
}
