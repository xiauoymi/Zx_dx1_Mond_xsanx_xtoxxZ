package com.monsanto.enterprise.customerlink.services;

import com.monsanto.customerlink.core.service.exception.CustomerLinkBusinessException;
import com.monsanto.enterprise.customerlink.services.dto.ResponseDTO;

import javax.ws.rs.core.Response;

public class BaseWrapper {

    public Response buildSuccessResponse(Object obj){
        return Response.status(Response.Status.OK).entity(new ResponseDTO(true, Response.Status.OK, obj)).build();
    }

    public Response buildErrorResponse(Exception ex){

        ex.printStackTrace();

        if(ex instanceof CustomerLinkBusinessException) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity(ex.getMessage())
                    .build();
        }else {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity(ex.getMessage())
                    .build();
        }

    }

}
