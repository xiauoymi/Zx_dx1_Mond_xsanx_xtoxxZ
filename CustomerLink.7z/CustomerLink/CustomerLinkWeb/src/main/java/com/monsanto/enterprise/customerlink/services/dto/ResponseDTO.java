package com.monsanto.enterprise.customerlink.services.dto;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import javax.ws.rs.core.Response;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseDTO {

    @JsonProperty
    private List<ErrorDTO> errors;

    @JsonProperty
    private boolean status;

    @JsonProperty
    private int httpStatusCode;

    @JsonProperty
    private String httpStatusReason;

    @JsonProperty
    private Object data;


    public ResponseDTO(boolean status, Response.Status httpStatus, Object data) {
        this.status = status;
        this.httpStatusCode = httpStatus.getStatusCode();
        this.httpStatusReason = httpStatus.getReasonPhrase();
        this.data = data;
    }

    public ResponseDTO(List<ErrorDTO> errors, Response.Status httpStatus) {
        this.errors = errors;
        this.httpStatusCode = httpStatus.getStatusCode();
        this.httpStatusReason = httpStatus.getReasonPhrase();
    }

    public List<ErrorDTO> getErrors() {
        return errors;
    }

    public void setErrors(List<ErrorDTO> errors) {
        this.errors = errors;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(int httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    public String getHttpStatusReason() {
        return httpStatusReason;
    }

    public void setHttpStatusReason(String httpStatusReason) {
        this.httpStatusReason = httpStatusReason;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
