package com.monsanto.enterprise.customerlink.services.rest.exception;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.xml.ws.WebServiceException;

public class WebServiceExceptionHandler implements ExceptionMapper<WebServiceException> {

    @Override
    public Response toResponse(WebServiceException e) {
        return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
    }
}
