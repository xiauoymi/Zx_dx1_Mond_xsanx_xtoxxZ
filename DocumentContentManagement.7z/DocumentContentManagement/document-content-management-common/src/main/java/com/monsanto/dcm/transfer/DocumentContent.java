package com.monsanto.dcm.transfer;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlMimeType;
import javax.activation.DataHandler;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@XmlType(name = "documentContent")
public class DocumentContent {
    private Reference reference;
    private DataHandler contents;

    @XmlTransient
    public Reference getReference() {
        return reference;
    }

    public void setReference(Reference reference) {
        this.reference = reference;
    }

    @XmlMimeType("application/octet-stream")
    public DataHandler getContents() {
        return contents;
    }

    public void setContents(DataHandler contents) {
        this.contents = contents;
    }

    @XmlAttribute(name = "documentId")
    public String getDocumentId() {
        return reference.getDocumentId();
    }

    @XmlAttribute(name = "version")
    public String getVersion() {
        return reference.getVersion();
    }
}
