package com.monsanto.dcm.transfer;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@XmlType(name = "documentDetail")
public class DocumentDetail {
    private Reference reference;
    private FieldTypeValues fieldTypeValues;

    @XmlTransient
    public Reference getReference() {
        return reference;
    }

    public void setReference(Reference reference) {
        this.reference = reference;
    }

    @XmlElement(name = "fields")
    public FieldTypeValues getFieldTypeValues() {
        return fieldTypeValues;
    }

    public void setFieldTypeValues(FieldTypeValues fieldTypeValues) {
        this.fieldTypeValues = fieldTypeValues;
    }

    @XmlAttribute(name = "documentId")
    public String getDocumentId() {
        return reference.getDocumentId();
    }

    @XmlAttribute(name = "version")
    public String getVersion() {
        return reference.getVersion();
    }
}
