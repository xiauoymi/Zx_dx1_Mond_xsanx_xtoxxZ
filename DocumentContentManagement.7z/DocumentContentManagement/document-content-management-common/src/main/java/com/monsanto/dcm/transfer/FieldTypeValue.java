package com.monsanto.dcm.transfer;

import javax.xml.bind.annotation.XmlAttribute;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
public class FieldTypeValue {
    private Field field = new Field();

    @XmlAttribute(name = "value")
    public String getValue() {
        return field.getValue();
    }

    public void setValue(String value) {
        field.setValue(value);
    }

    @XmlAttribute(name = "name")
    public String getName() {
        return field.getName();
    }

    public void setName(String name) {
        field.setName(name);
    }

    @XmlAttribute(name = "type")
    public String getType() {
        return field.getType();
    }

    public void setType(String type) {
        field.setType(type);
    }
}