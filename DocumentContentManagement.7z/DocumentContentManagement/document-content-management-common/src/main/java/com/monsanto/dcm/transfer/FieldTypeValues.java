package com.monsanto.dcm.transfer;

import javax.xml.bind.annotation.XmlElement;
import java.util.Collection;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
public class FieldTypeValues {
    private Collection<FieldTypeValue> fieldTypeValues;

    @XmlElement(name = "field")
    public Collection<FieldTypeValue> getFieldTypeValues() {
        return fieldTypeValues;
    }

    public void setFieldTypeValues(Collection<FieldTypeValue> fieldTypeValues) {
        this.fieldTypeValues = fieldTypeValues;
    }
}