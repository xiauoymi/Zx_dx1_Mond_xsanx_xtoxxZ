package com.monsanto.dcm.transfer;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@XmlType(name = "fieldValue")
public class FieldValue {
    private Field field = new Field();

    public FieldValue() {
    }

    public FieldValue(String name, String value) {
        setFieldName(name);
        setFieldValue(value);
    }

    @XmlAttribute(name = "value")
    public String getFieldValue() {
        return field.getValue();
    }

    public void setFieldValue(String value) {
        field.setValue(value);
    }

    @XmlAttribute(name = "name")
    public String getFieldName() {
        return field.getName();
    }

    public void setFieldName(String name) {
        field.setName(name);
    }
}
