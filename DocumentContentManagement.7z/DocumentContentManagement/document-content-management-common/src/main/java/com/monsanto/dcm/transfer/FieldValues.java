package com.monsanto.dcm.transfer;

import javax.xml.bind.annotation.XmlElement;
import java.util.Collection;
import java.util.ArrayList;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
public class FieldValues {
    private Collection<FieldValue> fieldValues = new ArrayList<FieldValue>();

    @XmlElement(name = "field")
    public Collection<FieldValue> getFieldValues() {
        return fieldValues;
    }

    public void setFieldValues(Collection<FieldValue> fieldValues) {
        this.fieldValues = fieldValues;
    }

    public boolean addFieldValue(FieldValue fieldValue) {
        return fieldValues.add(fieldValue);
    }
}
