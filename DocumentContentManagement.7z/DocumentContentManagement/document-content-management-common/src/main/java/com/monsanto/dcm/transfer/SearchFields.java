package com.monsanto.dcm.transfer;

import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlElement;
import java.util.Collection;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@XmlType(name = "searchFields")
public class SearchFields {
    private Collection<SearchField> searchFields;

    @XmlElement(name = "field")
    public Collection<SearchField> getSearchFields() {
        return searchFields;
    }

    public void setSearchFields(Collection<SearchField> searchFields) {
        this.searchFields = searchFields;
    }
}
