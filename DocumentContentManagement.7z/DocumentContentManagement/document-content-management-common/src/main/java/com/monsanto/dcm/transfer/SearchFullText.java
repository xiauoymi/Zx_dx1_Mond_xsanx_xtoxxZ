package com.monsanto.dcm.transfer;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@XmlType(name = "searchFullText")
public class SearchFullText {
    private SearchOperator operator;
    private String searchText;

    @XmlTransient
    public SearchOperator getOperator() {
        return operator;
    }

    public void setOperator(SearchOperator operator) {
        this.operator = operator;
    }

    @XmlElement(name = "text")
    public String getSearchText() {
        return searchText;
    }

    public void setSearchText(String searchText) {
        this.searchText = searchText;
    }

    @XmlAttribute(name = "operator")
    public String getOperatorName() {
        return operator.getName();
    }

    public void setOperatorName(String name) {
        operator = SearchOperator.valueOf(name);
    }
}
