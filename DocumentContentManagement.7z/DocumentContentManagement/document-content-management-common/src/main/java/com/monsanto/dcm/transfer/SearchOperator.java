package com.monsanto.dcm.transfer;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
public enum SearchOperator {
    EQUALS("equals");

    private String name;

    SearchOperator(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
