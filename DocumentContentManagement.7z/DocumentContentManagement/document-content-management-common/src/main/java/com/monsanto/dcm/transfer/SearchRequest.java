package com.monsanto.dcm.transfer;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@XmlType(name = "searchRequest")
public class SearchRequest {
    private String location; 
    private SearchFullText searchFullText;
    private SearchFields searchFields;
    private boolean searchLatestVersion;
    private ViewFields viewFields;

    @XmlElement(name = "fullText")
    public SearchFullText getSearchFullText() {
        return searchFullText;
    }

    public void setSearchFullText(SearchFullText searchFullText) {
        this.searchFullText = searchFullText;
    }

    @XmlElement(name = "searchFields")
    public SearchFields getSearchFields() {
        return searchFields;
    }

    public void setSearchFields(SearchFields searchFields) {
        this.searchFields = searchFields;
    }

    public boolean isSearchLatestVersion() {
        return searchLatestVersion;
    }

    @XmlAttribute(name = "searchLatestVersion")
    public void setSearchLatestVersion(boolean searchLatestVersion) {
        this.searchLatestVersion = searchLatestVersion;
    }

    @XmlElement(name = "viewFields")
    public ViewFields getViewFields() {
        return viewFields;
    }

    public void setViewFields(ViewFields viewFields) {
        this.viewFields = viewFields;
    }

   @XmlElement(name = "location")
   public String getLocation() {
      return location;
   }

   public void setLocation(String location) {
      this.location = location;
   }
}
