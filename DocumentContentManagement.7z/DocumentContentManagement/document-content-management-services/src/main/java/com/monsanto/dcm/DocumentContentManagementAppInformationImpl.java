package com.monsanto.dcm;

import com.monsanto.tps.aop.metric.ApplicationInformation;

/**
 * rlcasw - May 24, 2010 1:05:38 PM
 */
public class DocumentContentManagementAppInformationImpl implements ApplicationInformation
{
   private final String name;
   private final String version;

   public DocumentContentManagementAppInformationImpl(String name, String version){
      this.name=name;
      this.version=version;
   }
   @Override
   public String getVersion() {
      return version;
   }

   @Override
   public String getName() {
      return name;
   }
}
