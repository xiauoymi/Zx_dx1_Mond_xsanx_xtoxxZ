package com.monsanto.dcm.business;

import com.monsanto.dcm.exception.FatalException;
import com.monsanto.dcm.exception.RequestException;
import com.monsanto.dcm.transfer.Document;
import com.monsanto.dcm.transfer.DocumentContent;
import com.monsanto.dcm.transfer.DocumentDetail;
import com.monsanto.dcm.transfer.FieldValues;
import com.monsanto.dcm.transfer.Reference;
import com.monsanto.dcm.transfer.SearchRequest;
import com.monsanto.dcm.transfer.SearchResult;
import com.monsanto.dcm.transfer.ViewFields;

import javax.activation.DataHandler;
import java.util.Collection;

/**
 * rlcasw - May 14, 2010 9:21:03 AM
 */
public interface DocumentContentManagementBusiness
{
    public Reference create(String location, boolean versioningEnabled, DataHandler contents, FieldValues fieldValues) throws RequestException, FatalException;
    public DocumentContent retrieveContent(Reference reference) throws RequestException, FatalException;
    public Reference delete( Reference reference)  throws RequestException, FatalException;
    public Collection<Document> retrieve(Collection<Reference> references,ViewFields viewFields)  throws RequestException, FatalException;
    public Collection<DocumentDetail> retrieveDetails( Collection<Reference> references,
                                                      ViewFields viewFields)  throws RequestException, FatalException;
    public SearchResult search(SearchRequest searchRequest)throws RequestException, FatalException;

    public Reference update( Reference reference,
                      DataHandler dataHandler,
                     FieldValues fieldValues) throws RequestException, FatalException;


     public Reference update(String documentId,
                      boolean majorVersion,
                      DataHandler dataHandler,
                       FieldValues fieldValues)throws RequestException, FatalException;

}
