package com.monsanto.dcm.business.impl;

import com.monsanto.POSClient.MultiPartFormAttachment;
import com.monsanto.POSClient.POSMIMEConstants;
import com.monsanto.POSClient.XMLPOSConnection;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.dcm.business.DocumentContentManagementBusiness;
import com.monsanto.dcm.exception.NotFoundException;
import com.monsanto.dcm.exception.RequestException;
import com.monsanto.dcm.transfer.DocumentContent;
import com.monsanto.dcm.transfer.DocumentDetail;
import com.monsanto.dcm.transfer.FieldTypeValue;
import com.monsanto.dcm.transfer.FieldTypeValues;
import com.monsanto.dcm.transfer.FieldValue;
import com.monsanto.dcm.transfer.FieldValues;
import com.monsanto.dcm.transfer.Reference;
import com.monsanto.dcm.transfer.SearchField;
import com.monsanto.dcm.transfer.SearchFullText;
import com.monsanto.dcm.transfer.SearchOperator;
import com.monsanto.dcm.transfer.SearchRequest;
import com.monsanto.dcm.transfer.SearchResult;
import com.monsanto.dcm.transfer.ViewField;
import com.monsanto.dcm.transfer.ViewFields;
import org.apache.cxf.attachment.ByteDataSource;
import org.apache.log4j.Logger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.context.Context;
import org.apache.xerces.impl.dv.util.Base64;
import org.apache.xpath.XPathAPI;
import org.apache.xpath.objects.XObject;
import org.w3c.dom.Document;

import javax.activation.DataHandler;
import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * rlcasw - May 14, 2010 9:23:52 AM
 */
public class DocumentContentManagementBusinessDocumentumImpl
   implements DocumentContentManagementBusiness
{
   private final Logger log = Logger.getLogger(this.getClass());

   private final VelocityEngine velocityEngine;
   private final DocumentumPOSConnectionFactory posConnectionFactory;
   private static final String INSERT_DOCUMENT_REQUEST = "insertDocument";
   private static final String RETRIEVE_DOCUMENT_REQUEST = "retrieveDocument";
   private static final String DELETE_DOCUMENT_REQUEST = "deleteDocument";
   private static final String UPDATE_DOCUMENT_REQUEST = "updateDocument";
   private static final String SEARCH_DOCUMENTS_REQUEST = "searchDocuments";

   private static final String REQUEST_TEMPLATE_PATH = "com/monsanto/dcm/business/impl/requestTemplate.xml";


   private static final List<String> MIME_CONSTANTS = Arrays.asList(POSMIMEConstants.MIME_TYPE_TEXT,
      POSMIMEConstants.MIME_TYPE_MSWORD,
      POSMIMEConstants.MIME_TYPE_MSEXCEL,
      POSMIMEConstants.MIME_TYPE_MSPOWERPOINT,
      POSMIMEConstants.MIME_TYPE_MSWORDXML,
      POSMIMEConstants.MIME_TYPE_MSEXCELXML,
      POSMIMEConstants.MIME_TYPE_MSPOWERPOINTXML,
      POSMIMEConstants.MIME_TYPE_JPEG,
      POSMIMEConstants.MIME_TYPE_GIF,
      POSMIMEConstants.MIME_TYPE_BMP,
      POSMIMEConstants.MIME_TYPE_ZIP,
      POSMIMEConstants.MIME_TYPE_PDF,
      POSMIMEConstants.MIME_TYPE_EXE,
      POSMIMEConstants.MIME_TYPE_XML,
      POSMIMEConstants.MIME_TYPE_HTML,
      POSMIMEConstants.MIME_TYPE_RTF,
      POSMIMEConstants.MIME_TYPE_TIFF,
      POSMIMEConstants.MIME_TYPE_MSVISIO,
      POSMIMEConstants.MIME_TYPE_MSPROJECT,
      POSMIMEConstants.MIME_TYPE_OCTET_STREAM);
   public static final String DOES_NOT_EXIST = "does not exist";
   private static final String FILE_NAME = "name";
   private static final String DOCUMENTUM_REQUEST = "documentumRequest";
   private static final String INSERT_DOCUMENT_SERVICE = "InsertDocumentService";
   private static final String FULL_TEXT = "full_text";
   private static final String SEARCH_DOCUMENTS_SERVICE = "SearchDocumentsService";
   private static final String RETRIEVE_DOCUMENT_SERVICE = "RetrieveDocumentService";
   private static final String DELETE_DOCUMENT_SERVICE = "DeleteDocumentService";
   private static final String OBJECT_ID = "objectId";
   private static final String UPDATE_DOCUMENT_SERVICE = "UpdateDocumentService";


   public DocumentContentManagementBusinessDocumentumImpl(VelocityEngine velocityEngine, DocumentumPOSConnectionFactory posConnectionFactory) {
      this.velocityEngine = velocityEngine;
      this.posConnectionFactory = posConnectionFactory;
   }

   @Override
   public Reference create(String location, boolean versioningEnabled, DataHandler contents, FieldValues fieldValues) {
      try {
         XMLPOSConnection documentumPOSConnection = posConnectionFactory.buildXMLPOSConnection();
         String filename = parseFileName(location);
         DocumentumRequest request = buildCreateRequest(location, fieldValues, filename);

         Document requestDocument = buildDocumentumRequest(request);
         File tmpFile = copyToFile(contents, filename);
         try {
            MultiPartFormAttachment multipartFormAttachment = new MultiPartFormAttachment(tmpFile.getPath(), getExistingMimeType(contents));
            documentumPOSConnection.addAttachment(multipartFormAttachment);
            Document posResult = DOMUtil.newDocument(documentumPOSConnection.callService(INSERT_DOCUMENT_SERVICE, requestDocument).getInputStream());
            String version = XPathAPI.eval(posResult, "//attribute[name='version']/value").toString();
            String objectId = XPathAPI.eval(posResult, "//attribute[name='objectId']/value").toString();
            return buildReference(version, objectId, request.getFolder());
         }
         finally {
            //noinspection ResultOfMethodCallIgnored
            tmpFile.delete();
         }
      }
      catch (Throwable t) {
         log.error(t.getMessage(), t);
         throw new RequestException(t);
      }

   }

   private Reference buildReference(String version, String objectId, String folder) {
      Reference reference = new Reference();
      reference.setDocumentId(folder + "/" + objectId);
      reference.setVersion(version);
      return reference;
   }

   private Document buildDocumentumRequest(DocumentumRequest request)
      throws Exception
   {
      Template template = velocityEngine.getTemplate(REQUEST_TEMPLATE_PATH);
      Context context = new VelocityContext();

      context.put(DOCUMENTUM_REQUEST, request);
      StringWriter stringWriter = new StringWriter();
      template.merge(context, stringWriter);
      String documentString = stringWriter.toString();
      return DOMUtil.stringToXML(documentString);
   }

   private DocumentumRequest buildCreateRequest(String location, FieldValues fieldValues, String filename) {
      String folder = parseFolder(location);
      String directoryStructure = parseDirectoryStructureWithName(location);
      DocumentumRequest request = new DocumentumRequest();
      request.setFolder(folder);
      request.setDirectoryStructure(directoryStructure.toString());
      request.setRequestType(INSERT_DOCUMENT_REQUEST);
      request.setAttributes(buildAttributesMapForCreate(fieldValues, filename));
      return request;
   }

   private Map<String, String> buildAttributesMapForCreate(FieldValues fieldValues, String filename) {
      Map<String, String> attributesMap = new HashMap<String, String>();
      attributesMap.put(FILE_NAME, filename);
      if (fieldValues != null && fieldValues.getFieldValues() != null) {
         for (FieldValue fieldValue : fieldValues.getFieldValues()) {
            attributesMap.put(fieldValue.getFieldName(), fieldValue.getFieldValue());
         }
      }
      return attributesMap;
   }

   private String getExistingMimeType(DataHandler contents) {
      String contentType = contents.getContentType();
      if (!MIME_CONSTANTS.contains(contentType)) {
         contentType = POSMIMEConstants.MIME_TYPE_OCTET_STREAM;
      }
      return contentType;
   }

   private File copyToFile(DataHandler contents, String name)
      throws IOException
   {
      InputStream inputStream = contents.getInputStream();
      int i;
      int nameLength = name.length();
      File file = File.createTempFile("dcms", "." + name.substring(nameLength - 3));
      FileOutputStream outputStream = new FileOutputStream(file);
      byte[] buffer = new byte[100];
      while ((i = inputStream.read(buffer)) != -1) {
         outputStream.write(buffer, 0, i);
      }
      inputStream.close();
      outputStream.flush();
      outputStream.close();
      return file;
   }

   private String parseDirectoryStructure(String location) {
      int partsIndex = 0;
      String[] locationParts = location.split("/");
      if (locationParts[partsIndex].isEmpty()) {
         partsIndex++;
      }
      partsIndex++;

      StringBuilder directoryStructure = new StringBuilder("");

      while (partsIndex < (locationParts.length)) {
         directoryStructure.append(locationParts[partsIndex]);
         partsIndex++;
         if (partsIndex < locationParts.length) {
            directoryStructure.append("/");
         }

      }
      return directoryStructure.toString();
   }


   private String parseDirectoryStructureWithName(String location) {
      int partsIndex = 0;
      String[] locationParts = location.split("/");
      if (locationParts[partsIndex].isEmpty()) {
         partsIndex++;
      }
      partsIndex++;

      StringBuilder directoryStructure = new StringBuilder("");

      int pathlength = locationParts.length - 1;
      while (partsIndex < pathlength) {
         directoryStructure.append(locationParts[partsIndex]);
         partsIndex++;
         if (partsIndex < pathlength) {
            directoryStructure.append("/");
         }

      }
      return directoryStructure.toString();
   }

   private String parseFileName(String location) {
      String[] locationParts = location.split("/");
      return locationParts[locationParts.length - 1];
   }

   private String parseFolder(String location) {
      String[] locationParts = location.split("/");
      int partsIndex = 0;
      String documentumFolder = "";
      if (locationParts.length > partsIndex) {
         if (locationParts[partsIndex].isEmpty()) {
            partsIndex++;
         }
         if (locationParts.length > partsIndex) {
            documentumFolder = locationParts[partsIndex++];
         }
      }
      return documentumFolder;
   }

   @Override
   public Collection<com.monsanto.dcm.transfer.Document> retrieve(Collection<Reference> references,
                                                                  ViewFields viewFields)
   {
      List<com.monsanto.dcm.transfer.Document> documents = new ArrayList<com.monsanto.dcm.transfer.Document>(references.size());
      for (Reference reference : references) {
         documents.add(retrieve(reference, viewFields));
      }
      return documents;
   }

   @Override
   public SearchResult search(SearchRequest searchRequest) {
      try {
         XMLPOSConnection documentumPOSConnection = posConnectionFactory.buildXMLPOSConnection();
         String location = searchRequest.getLocation();
         String folder = parseFolder(location);
         ViewFields viewFields = searchRequest.getViewFields();
         DocumentumRequest request = buildSearchDocumentRequest(searchRequest, location, folder, viewFields);
         Document requestDocument = buildDocumentumRequest(request);
         Document posResult = DOMUtil.newDocument(documentumPOSConnection.callService(SEARCH_DOCUMENTS_SERVICE, requestDocument).getInputStream());
         return parseSearchResult(folder, viewFields, posResult);
      }
      catch (Throwable t) {
         log.error(t.getMessage(), t);
         throw new RequestException(t);
      }

   }

   private SearchResult parseSearchResult(String folder, ViewFields viewFields, Document posResult)
      throws TransformerException
   {
      SearchResult searchResult = new SearchResult();
      Collection<DocumentDetail> documentDetails = new ArrayList<DocumentDetail>();
      for (int documentIndex = 1;
           XPathAPI.selectSingleNode(posResult, "/documentManagerResponse/searchDocuments/documentDetails[" + documentIndex + "]") != null;
           documentIndex++) {
         DocumentDetail documentDetail = new DocumentDetail();
         String detailLocatorString = "/documentManagerResponse/searchDocuments/documentDetails[" + documentIndex + "]";
         List<FieldTypeValue> fieldTypeValuesCollection = new ArrayList<FieldTypeValue>();

         String version = XPathAPI.eval(posResult, detailLocatorString + "/attribute[name='version']/value").toString();
         String objectId = XPathAPI.eval(posResult, detailLocatorString + "/attribute[name='objectId']/value").toString();
         Reference reference = buildReference(version, objectId, folder);
         documentDetail.setReference(reference);
         for (ViewField viewField : viewFields.getViewFields()) {
            FieldTypeValue value = new FieldTypeValue();
            value.setName(viewField.getName());
            value.setValue(XPathAPI.eval(posResult, detailLocatorString + "/attribute[name='" + viewField.getName() + "']/value").toString());
            fieldTypeValuesCollection.add(value);
         }
         FieldTypeValues fieldTypeValues = new FieldTypeValues();
         fieldTypeValues.setFieldTypeValues(fieldTypeValuesCollection);
         documentDetail.setFieldTypeValues(fieldTypeValues);
         documentDetails.add(documentDetail);

      }
      searchResult.setDocumentDetails(documentDetails);
      return searchResult;
   }

   private DocumentumRequest buildSearchDocumentRequest(SearchRequest searchRequest, String location, String folder, ViewFields viewFields) {
      String directoryStructure = parseDirectoryStructure(location);
      DocumentumRequest request = new DocumentumRequest();
      request.setFolder(folder);
      request.setDirectoryStructure(directoryStructure.toString());
      request.setRequestType(SEARCH_DOCUMENTS_REQUEST);
      request.setSearchAllVersions(searchRequest.isSearchLatestVersion() ? "false" : "true");
      List<SearchField> searchFields = new ArrayList<SearchField>();
      SearchFullText searchFullText = searchRequest.getSearchFullText();
      if (searchFullText != null) {
         SearchField searchField = new SearchField();
         SearchOperator operator = searchFullText.getOperator();
         if (operator == null) {
            operator = SearchOperator.EQUALS;
         }
         searchField.setOperator(operator);
         searchField.setName(FULL_TEXT);
         searchField.setValue(searchFullText.getSearchText());
         searchFields.add(searchField);
      }
      if ((searchRequest.getSearchFields() != null) && (searchRequest.getSearchFields().getSearchFields() != null)) {
         searchFields.addAll(searchRequest.getSearchFields().getSearchFields());
      }
      request.setSearchFields(searchFields);
      assignViewFieldsToRequest(viewFields, request);
      return request;
   }

   private void assignViewFieldsToRequest(ViewFields viewFields, DocumentumRequest request) {
      if (viewFields != null) {
         List<String> requiredAttributes = new ArrayList<String>();
         for (ViewField viewField : viewFields.getViewFields()) {
            requiredAttributes.add(viewField.getName());
         }
         request.setRequiredAttributes(requiredAttributes);
      }
   }

   @Override
   public Collection<DocumentDetail> retrieveDetails(Collection<Reference> references, ViewFields viewFields) {
      List<DocumentDetail> documentDetails = new ArrayList<DocumentDetail>(references.size());
      for (Reference reference : references) {
         documentDetails.add(retrieveDetails(reference, viewFields));
      }
      return documentDetails;
   }

   private DocumentDetail retrieveDetails(Reference reference, ViewFields viewFields) {
      try {

         XMLPOSConnection documentumPOSConnection = posConnectionFactory.buildXMLPOSConnection();
         String[] idSplit = reference.getDocumentId().split("/");
         String folder = idSplit[0];
         String objectId = idSplit[1];

         DocumentumRequest request = buildRetrieveDocumentumRequest(reference, viewFields, folder, objectId);
         Document requestDocument = buildDocumentumRequest(request);
         Document posResult = DOMUtil.newDocument(documentumPOSConnection.callService(RETRIEVE_DOCUMENT_SERVICE, requestDocument).getInputStream());
         String version = XPathAPI.eval(posResult, "//attribute[name='version']/value").toString();
         FieldTypeValues fieldTypeValues = parseFieldTypeValues(viewFields, posResult);
         Reference outReference = buildReference(version, objectId, folder);
         return buildDocumentDetail(fieldTypeValues, outReference);
      }
      catch (Throwable t) {
         log.error(t.getMessage(), t);
         String message = t.getMessage();
         if (message != null && (message.endsWith(DOES_NOT_EXIST))) {
            throw new NotFoundException(reference);
         }
         throw new RequestException(t);
      }
   }

   private DocumentDetail buildDocumentDetail(FieldTypeValues fieldTypeValues, Reference outReference) {
      DocumentDetail content = new DocumentDetail();
      content.setReference(outReference);
      content.setFieldTypeValues(fieldTypeValues);
      content.setReference(outReference);
      return content;
   }

   private com.monsanto.dcm.transfer.Document retrieve(Reference reference,
                                                       ViewFields viewFields)
   {
      try {
         XMLPOSConnection documentumPOSConnection = posConnectionFactory.buildXMLPOSConnection();
         String[] idSplit = reference.getDocumentId().split("/");
         String folder = idSplit[0];
         String objectId = idSplit[1];

         DocumentumRequest request = buildRetrieveDocumentumRequest(reference, viewFields, folder, objectId);
         Document requestDocument = buildDocumentumRequest(request);
         Document posResult = DOMUtil.newDocument(documentumPOSConnection.callService(RETRIEVE_DOCUMENT_SERVICE, requestDocument).getInputStream());
         String base64Contents = XPathAPI.eval(posResult, "//attribute[name='contents']/value").toString();
         String version = XPathAPI.eval(posResult, "//attribute[name='version']/value").toString();
         String name = XPathAPI.eval(posResult, "//attribute[name='name']/value").toString();
         FieldTypeValues fieldTypeValues = parseFieldTypeValues(viewFields, posResult);

         Reference outReference = buildReference(version, objectId, folder);

         com.monsanto.dcm.transfer.Document content = new com.monsanto.dcm.transfer.Document();
         content.setReference(outReference);
         content.setContents(createDocumentAttachment(base64Contents, name));
         content.setFieldTypeValues(fieldTypeValues);
         content.setReference(outReference);
         return content;
      }
      catch (Throwable t) {
         log.error(t.getMessage(), t);
         String message = t.getMessage();
         if (message != null && (message.endsWith(DOES_NOT_EXIST))) {
            throw new NotFoundException(reference);
         }
         throw new RequestException(t);
      }
   }

   private FieldTypeValues parseFieldTypeValues(ViewFields viewFields, Document posResult)
      throws TransformerException
   {
      List<FieldTypeValue> fieldTypeValuesCollection = new ArrayList<FieldTypeValue>();
      if ((viewFields != null) && (viewFields.getViewFields() != null)) {
         for (ViewField viewField : viewFields.getViewFields()) {
            FieldTypeValue value = new FieldTypeValue();
            value.setName(viewField.getName());
            XObject xobject = XPathAPI.eval(posResult, "//attribute[name='" + viewField.getName() + "']/value");
            if (xobject != null) {
               value.setValue(xobject.toString());
            }
            fieldTypeValuesCollection.add(value);
         }
      }
      FieldTypeValues fieldTypeValues = new FieldTypeValues();
      fieldTypeValues.setFieldTypeValues(fieldTypeValuesCollection);
      return fieldTypeValues;
   }

   private DataHandler createDocumentAttachment(String base64Contents, String name) {
      ByteDataSource dataSource = new ByteDataSource(Base64.decode(base64Contents));
      dataSource.setContentType(POSMIMEConstants.MIME_TYPE_OCTET_STREAM);
      dataSource.setName(name);
      return new DataHandler(dataSource);
   }

   private DocumentumRequest buildRetrieveDocumentumRequest(Reference reference, ViewFields viewFields, String folder, String objectId) {
      DocumentumRequest request = new DocumentumRequest();
      request.setFolder(folder);
      request.setRequestType(RETRIEVE_DOCUMENT_REQUEST);
      QueryAttributes queryAttributes = new QueryAttributes();
      queryAttributes.setObjectId(objectId);
      queryAttributes.setVersion(reference.getVersion());
      request.setQueryAttributes(queryAttributes);
      assignViewFieldsToRequest(viewFields, request);
      return request;
   }

   @Override
   public DocumentContent retrieveContent(Reference reference) {
      com.monsanto.dcm.transfer.Document document = retrieve(reference, new ViewFields());
      DocumentContent content = new DocumentContent();
      content.setReference(document.getReference());
      content.setContents(document.getContents());
      return content;
   }

   @Override
   public Reference delete(Reference reference) {

      try {
         XMLPOSConnection documentumPOSConnection = posConnectionFactory.buildXMLPOSConnection();
         String[] idSplit = reference.getDocumentId().split("/");
         String folder = idSplit[0];
         String objectId = idSplit[1];

         DocumentumRequest request = new DocumentumRequest();
         request.setFolder(folder);
         request.setRequestType(DELETE_DOCUMENT_REQUEST);
         QueryAttributes queryAttributes = new QueryAttributes();
         queryAttributes.setObjectId(objectId);
         queryAttributes.setVersion(reference.getVersion());
         request.setQueryAttributes(queryAttributes);
         Document requestDocument = buildDocumentumRequest(request);
         DOMUtil.newDocument(documentumPOSConnection.callService(DELETE_DOCUMENT_SERVICE, requestDocument).getInputStream());

         return reference;
      }
      catch (Throwable t) {
         log.error(t.getMessage(), t);
         String message = t.getMessage();
         if (message != null && (message.endsWith(DOES_NOT_EXIST))) {
            throw new NotFoundException(reference);
         }
         throw new RequestException(t);
      }
   }

   public Reference update(String documentId,
                           boolean majorVersion,
                           DataHandler contents,
                           FieldValues fieldValues)
   {
      try {
         XMLPOSConnection documentumPOSConnection = posConnectionFactory.buildXMLPOSConnection();
         String[] idSplit = documentId.split("/");
         String folder = idSplit[0];
         String objectId = idSplit[1];
         DocumentumRequest request = buildUpdateDocumentRequest(majorVersion, fieldValues, folder, objectId);
         Document requestDocument = buildDocumentumRequest(request);
         String fileName = retrieveFileNameForDocument(documentId);
         File tmpFile = copyToFile(contents, fileName);
         try {
            MultiPartFormAttachment multipartFormAttachment = new MultiPartFormAttachment(tmpFile.getPath(), getExistingMimeType(contents));
            documentumPOSConnection.addAttachment(multipartFormAttachment);
            Document posResult = DOMUtil.newDocument(documentumPOSConnection.callService(UPDATE_DOCUMENT_SERVICE, requestDocument).getInputStream());
            String resultVersion = XPathAPI.eval(posResult, "//attribute[name='version']/value").toString();
            String resultObjectId = XPathAPI.eval(posResult, "//attribute[name='objectId']/value").toString();
            return buildReference(resultVersion, resultObjectId, folder);
         }
         finally {

            //noinspection ResultOfMethodCallIgnored
            tmpFile.delete();
         }
      }
      catch (Throwable t) {
         log.error(t.getMessage(), t);
         String message = t.getMessage();
         if (message != null && (message.endsWith(DOES_NOT_EXIST))) {
            Reference reference = new Reference();
            reference.setDocumentId(documentId);
            throw new NotFoundException(reference);
         }
         else {
            throw new RequestException(t);
         }
      }
   }

   private DocumentumRequest buildUpdateDocumentRequest(boolean majorVersion, FieldValues fieldValues, String folder, String objectId) {
      DocumentumRequest request = new DocumentumRequest();
      request.setFolder(folder);
      request.setRequestType(UPDATE_DOCUMENT_REQUEST);
      request.setAttributes(buildUpdatesAttributesMap(majorVersion, fieldValues, objectId));
      return request;
   }

   private Map<String, String> buildUpdatesAttributesMap(boolean majorVersion, FieldValues fieldValues, String objectId) {
      Map<String, String> attributesMap = new HashMap<String, String>();
      attributesMap.put(OBJECT_ID, objectId);
      if (majorVersion) {
         attributesMap.put("updateVersion", "nextMajor");
      }
      if ((fieldValues != null) && (fieldValues.getFieldValues() != null)) {
         for (FieldValue fieldValue : fieldValues.getFieldValues()) {
            attributesMap.put(fieldValue.getFieldName(), fieldValue.getFieldValue());
         }
      }
      return attributesMap;
   }

   private String retrieveFileNameForDocument(String documentId) {
      Reference reference = new Reference();
      reference.setDocumentId(documentId);
      ViewFields detailFields = new ViewFields();
      ViewField nameField = new ViewField();
      nameField.setName(FILE_NAME);
      detailFields.getViewFields().add(nameField);
      DocumentDetail documentDetail = retrieveDetails(reference, detailFields);
      String fileName = "tmpfile.bin";
      for (FieldTypeValue fieldTypeValue : documentDetail.getFieldTypeValues().getFieldTypeValues()) {
         if (fieldTypeValue.getName().equals(FILE_NAME)) {
            fileName = fieldTypeValue.getValue();
         }
      }
      return fileName;
   }

   public Reference update(Reference reference,
                           DataHandler contents,
                           FieldValues fieldValues)
   {
      return update(reference.getDocumentId(), false, contents, fieldValues);
   }
}
