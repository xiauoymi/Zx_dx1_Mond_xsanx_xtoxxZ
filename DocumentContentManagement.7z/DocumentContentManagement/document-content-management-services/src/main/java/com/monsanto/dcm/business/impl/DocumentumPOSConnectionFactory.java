package com.monsanto.dcm.business.impl;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.POSClient.XMLPOSConnection;
import com.monsanto.securityinterfaces.ClientSecurityProxy;
import com.monsanto.securityinterfaces.SystemSecurityProxy;

/**
 * rlcasw - May 14, 2010 10:59:08 AM
 */
public class DocumentumPOSConnectionFactory
{
   private  final SystemSecurityProxy systemSecurityProxy;

   public DocumentumPOSConnectionFactory(SystemSecurityProxy systemSecurityProxy){
      this.systemSecurityProxy=systemSecurityProxy;
   }

   public XMLPOSConnection buildXMLPOSConnection()
      throws Exception
   {
        System.setProperty("user.name","rlcasw");
        SystemSecurityProxy systemProxy = systemSecurityProxy;
        ClientSecurityProxy clientProxy = new KerberosSPNEGOClient(new OSBasedGSSManagerFactory());
         
      return new SecureXMLPOSConnection(clientProxy, systemProxy);
   }
}
