package com.monsanto.dcm.business.impl;

import com.monsanto.dcm.transfer.SearchField;

import java.util.List;
import java.util.Map;

/**
 * rlcasw - May 14, 2010 2:08:42 PM
 */
public class DocumentumRequest
{
   private String requestType;
   private String folder;
   private String objectId;
   private String version;
   private String directoryStructure;
   private QueryAttributes queryAttributes;
   private List<String> requiredAttributes;
   private List<SearchField> searchFields;
   private String searchAllVersions;
   

   private Map<String,String> attributes;

   public Map<String, String> getAttributes() {
      return attributes;
   }

   public void setAttributes(Map<String, String> attributes) {
      this.attributes = attributes;
   }

   public String getDirectoryStructure() {
      return directoryStructure;
   }

   public void setDirectoryStructure(String directoryStructure) {
      this.directoryStructure = directoryStructure;
   }

   public String getFolder() {
      return folder;
   }

   public void setFolder(String folder) {
      this.folder = folder;
   }

   public String getRequestType() {
      return requestType;
   }

   public void setRequestType(String requestType) {
      this.requestType = requestType;
   }

   public void setObjectId(String objectId) {
      this.objectId=objectId;
   }

   public String getObjectId() {
      return objectId;
   }

   public String getVersion() {
      return version;
   }

   public void setVersion(String version) {
      this.version = version;
   }

   public QueryAttributes getQueryAttributes() {
      return queryAttributes;
   }

   public void setQueryAttributes(QueryAttributes queryAttributes) {
      this.queryAttributes = queryAttributes;
   }

   public List<String> getRequiredAttributes() {
      return requiredAttributes;
   }

   public void setRequiredAttributes(List<String> requiredAttributes) {
      this.requiredAttributes = requiredAttributes;
   }

   public List<SearchField> getSearchFields() {
      return searchFields;
   }

   public void setSearchFields(List<SearchField> searchFields) {
      this.searchFields = searchFields;
   }

   public String getSearchAllVersions() {
      return searchAllVersions;
   }

   public void setSearchAllVersions(String searchAllVersions) {
      this.searchAllVersions = searchAllVersions;
   }
}
