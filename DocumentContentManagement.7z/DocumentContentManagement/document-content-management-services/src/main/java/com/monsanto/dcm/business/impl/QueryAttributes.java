package com.monsanto.dcm.business.impl;

/**
 * rlcasw - May 17, 2010 10:28:54 AM
 */
public class QueryAttributes
{
    private String objectId;
    private String version;

   public String getObjectId() {
      return objectId;
   }

   public void setObjectId(String objectId) {
      this.objectId = objectId;
   }

   public String getVersion() {
      return version;
   }

   public void setVersion(String version) {
      this.version = version;
   }
}
