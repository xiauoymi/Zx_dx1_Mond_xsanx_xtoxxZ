package com.monsanto.dcm.security;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.dcm.security.kerberos.ServerGSSCredentialBuilder;
import org.springframework.beans.factory.FactoryBean;
/**
 * Created by IntelliJ IDEA.
 * User: eehoch
 * Date: Apr 29, 2008
 * Time: 9:02:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class SystemSecurityProxyFactory implements FactoryBean
{

    private static final String SECURITY_PROXY_STRATEGY = "documentum.system.security.proxy";

    private static final String KERBEROS_SERVER_CREDENTIALS = "kerberos.server.credentials";
    private static final String KERBEROS_STANDARD_CREDENTIALS = "kerberos.standard.credentials";

    public Object getObject() throws Exception {
        SystemSecurityProxy securityProxy = null;

        String strategy = System.getProperty(SECURITY_PROXY_STRATEGY);
        if (strategy == null) {
            strategy = KERBEROS_SERVER_CREDENTIALS;
        }

        if (strategy.equals(KERBEROS_SERVER_CREDENTIALS)) {
            securityProxy = createFakeServerCredential();
        } if (strategy.equals(KERBEROS_STANDARD_CREDENTIALS)) {
            securityProxy = createStandardCredential();
        }
        return securityProxy;
    }

    protected SystemSecurityProxy createFakeServerCredential() throws Exception {
        ServerGSSCredentialBuilder credentialBuilder = new ServerGSSCredentialBuilder();
        return new KerberosStandaloneCredential(credentialBuilder.build());
    }

    protected SystemSecurityProxy createStandardCredential() throws Exception {
        return new KerberosStandaloneCredential();
    }

    public Class getObjectType() {
        return SystemSecurityProxy.class;
    }

    public boolean isSingleton() {
        return false;
    }
}
