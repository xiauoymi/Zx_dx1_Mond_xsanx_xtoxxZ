package com.monsanto.dcm.security.kerberos;

import org.apache.log4j.Logger;
import org.ietf.jgss.GSSCredential;
import com.monsanto.securityinterfaces.ClientSecurityProxy;
import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;

import javax.security.auth.Subject;
import javax.security.auth.login.LoginException;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: EEHOCH
 * Date: Apr 29, 2008
 * Time: 8:35:08 PM
 */
public class ServerGSSCredentialBuilder {
    private final Logger logger = Logger.getLogger(getClass());
    public static final String MONSANTO_PRINCIPAL_UPN = "monsanto.principal.upn";

    public GSSCredential build() {
        String spn = System.getProperty(MONSANTO_PRINCIPAL_UPN);
        if (spn == null) {
            throw new IllegalStateException("System property monsanto.principal.upn not defined.");
        }
        System.setProperty("sun.security.krb5.principal", spn);
        ClientSecurityProxy clientProxy = new KerberosSPNEGOClient("LoginClientWithKeytab");
        Subject subject = null;
        try {
            subject = clientProxy.getCurrentUser();
        } catch (LoginException e) {
            logger.error(e);
            throw new IllegalStateException("Unable to get user from client proxy");
        }

        // todo: crude-way, but I just need credentials for now
        Iterator<Object> iterator = subject.getPrivateCredentials().iterator();
        return (GSSCredential) iterator.next();
    }
}
