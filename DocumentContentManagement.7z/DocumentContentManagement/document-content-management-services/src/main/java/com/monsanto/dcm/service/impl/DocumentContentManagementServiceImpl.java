package com.monsanto.dcm.service.impl;

import com.monsanto.dcm.business.DocumentContentManagementBusiness;
import com.monsanto.dcm.exception.FatalException;
import com.monsanto.dcm.exception.RequestException;
import com.monsanto.dcm.service.DocumentContentManagementService;
import com.monsanto.dcm.transfer.Document;
import com.monsanto.dcm.transfer.DocumentContent;
import com.monsanto.dcm.transfer.DocumentDetail;
import com.monsanto.dcm.transfer.FieldValues;
import com.monsanto.dcm.transfer.Reference;
import com.monsanto.dcm.transfer.SearchRequest;
import com.monsanto.dcm.transfer.SearchResult;
import com.monsanto.dcm.transfer.ViewFields;
import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.aop.metric.PerformanceMetric;

import javax.activation.DataHandler;
import java.util.Collection;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
public class DocumentContentManagementServiceImpl implements DocumentContentManagementService
{

    private final DocumentContentManagementBusiness documentContentManagementBusiness;
    private final DataPointHolder dataPointHolder;
    public DocumentContentManagementServiceImpl(DocumentContentManagementBusiness documentContentManagementBusiness, DataPointHolder dataPointHolder){

       this.documentContentManagementBusiness=documentContentManagementBusiness;
       this.dataPointHolder = dataPointHolder;
    }

   @PerformanceMetric(task = "DocumentContentManagementService.retrieve", comment = "")
    public Collection<Document> retrieve(Collection<Reference> references, ViewFields viewFields)
            throws RequestException, FatalException {
        dataPointHolder.add("referenceCount",references.size());
        return documentContentManagementBusiness.retrieve(references,viewFields);
    }
    @PerformanceMetric(task = "DocumentContentManagementService.retrieveDetails", comment = "")
    public Collection<DocumentDetail> retrieveDetails(Collection<Reference> references, ViewFields viewFields)
            throws RequestException, FatalException {
       dataPointHolder.add("referenceCount",references.size());
       return documentContentManagementBusiness.retrieveDetails(references,viewFields);
    }

   @PerformanceMetric(task = "DocumentContentManagementService.retrieveContent", comment = "")
    public DocumentContent retrieveContent(Reference reference) throws RequestException, FatalException {
        dataPointHolder.add("documentId",reference.getDocumentId());
        return documentContentManagementBusiness.retrieveContent(reference);
    }

    @PerformanceMetric(task = "DocumentContentManagementService.search", comment = "")
    public SearchResult search(SearchRequest searchRequest) throws RequestException, FatalException {
       return documentContentManagementBusiness.search(searchRequest);
    }

    public void deleteAll(String documentId) throws RequestException, FatalException {
    }

   @PerformanceMetric(task = "DocumentContentManagementService.delete", comment = "")
    public Reference delete(Reference reference) throws RequestException, FatalException {
       dataPointHolder.add("documentId",reference.getDocumentId());
       if(reference.getVersion()!=null){
            dataPointHolder.add("version",reference.getVersion());
       }
       return documentContentManagementBusiness.delete(reference);
    }

    public void deleteLatest(String documentId) throws RequestException, FatalException {
    }

    @PerformanceMetric(task = "DocumentContentManagementService.update", comment = "")
    public Reference update(Reference reference, DataHandler contents, FieldValues fieldValues)
            throws RequestException, FatalException {
        dataPointHolder.add("documentId",reference.getDocumentId());
        if(reference.getVersion()!=null){
             dataPointHolder.add("version",reference.getVersion());
        }
        return documentContentManagementBusiness.update(reference,contents,fieldValues);
    }

    @PerformanceMetric(task = "DocumentContentManagementService.update", comment = "")
    public Reference update(String documentId, boolean majorVersion, DataHandler contents, FieldValues fieldValues)
            throws RequestException, FatalException {
        dataPointHolder.add("documentId",documentId);
        dataPointHolder.add("majorVersion",majorVersion?"true":"false");
        return documentContentManagementBusiness.update(documentId,majorVersion,contents,fieldValues);
    }
   
    @PerformanceMetric(task = "DocumentContentManagementService.create", comment = "")
    public Reference create(String location, boolean versioningEnabled, DataHandler contents, FieldValues fieldValues)
            throws RequestException, FatalException {
       dataPointHolder.add("location",location);
       return documentContentManagementBusiness.create(location,versioningEnabled,contents,fieldValues);
    }

}
