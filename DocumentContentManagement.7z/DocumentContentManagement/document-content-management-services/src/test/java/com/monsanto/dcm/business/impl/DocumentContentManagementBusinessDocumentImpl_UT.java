package com.monsanto.dcm.business.impl;

import com.monsanto.POSClient.MultiPartFormAttachment;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSConnection;
import com.monsanto.POSClient.POSException;
import com.monsanto.POSClient.POSMIMEConstants;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.XMLPOSConnection;
import com.monsanto.dcm.exception.NotFoundException;
import com.monsanto.dcm.transfer.DocumentContent;
import com.monsanto.dcm.transfer.DocumentDetail;
import com.monsanto.dcm.transfer.FieldTypeValue;
import com.monsanto.dcm.transfer.FieldValue;
import com.monsanto.dcm.transfer.FieldValues;
import com.monsanto.dcm.transfer.Reference;
import com.monsanto.dcm.transfer.SearchField;
import com.monsanto.dcm.transfer.SearchFields;
import com.monsanto.dcm.transfer.SearchFullText;
import com.monsanto.dcm.transfer.SearchOperator;
import com.monsanto.dcm.transfer.SearchRequest;
import com.monsanto.dcm.transfer.SearchResult;
import com.monsanto.dcm.transfer.ViewField;
import com.monsanto.dcm.transfer.ViewFields;
import static junit.framework.Assert.assertEquals;
import org.apache.velocity.app.VelocityEngine;
import org.apache.xerces.impl.dv.util.Base64;
import static org.custommonkey.xmlunit.XMLAssert.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import static org.mockito.Mockito.*;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;

import javax.activation.DataHandler;
import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * rlcasw - May 14, 2010 9:46:18 AM
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
   
	"classpath:/com/monsanto/dcm/contexts/services-context.xml"
})
public class DocumentContentManagementBusinessDocumentImpl_UT
{

    @Before
    public void setup(){
        System.setProperty("documentum.system.security.proxy", "kerberos.standard.credentials");
    }
    @Resource
    VelocityEngine velocityEngine;


    @Test
    public void testCreate() throws Exception{
       String folder = "folder";
       String path = "path";
       String fileName = "fileName.txt";
       String  location = "/"+folder+"/"+path+"/"+fileName;
       DataHandler contents = mock(DataHandler.class);
       InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
       when(contents.getInputStream()).thenReturn(contentsInput);
       String mimeType = "mimeType";
       when(contents.getContentType()).thenReturn(mimeType);


       when(contents.getName()).thenReturn(fileName);

      FieldValue fieldValue = new FieldValue();
      String fieldName = "fieldName";
      fieldValue.setFieldName(fieldName);
      String fieldValueValue = "fieldValue";
      fieldValue.setFieldValue(fieldValueValue);

      FieldValues fieldValues= new FieldValues();
      fieldValues.addFieldValue(fieldValue);

       XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
       DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
       when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);
       DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);
       ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
       ArgumentCaptor<MultiPartFormAttachment> multipartCaptor  = ArgumentCaptor.forClass(MultiPartFormAttachment.class);
       POSResult posResult= mock(POSResult.class);
       when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((getResponse().getBytes())));
       when(posConnection.callService(anyString(),any(Document.class))).thenReturn(posResult);
       


       Reference reference = business.create(location,true,contents,fieldValues);
       verify(posConnection).addAttachment(multipartCaptor.capture());
       verify(posConnection).callService(eq("InsertDocumentService"),documentCaptor.capture());


       Assert.assertTrue(multipartCaptor.getValue().getFileName().startsWith(System.getProperty("java.io.tmpdir")));

       File file = new File(multipartCaptor.getValue().getFileName());
       Assert.assertFalse(file.exists());
       assertEquals(multipartCaptor.getValue().getContentType(), POSMIMEConstants.MIME_TYPE_OCTET_STREAM);
       Document document = documentCaptor.getValue();

       assertXpathExists("/insertDocumentRequest",document);
       assertXpathEvaluatesTo("fieldValue","/insertDocumentRequest/requestDetails/insertDocument/documentAttributes/attribute[name='fieldName']/value",document);
       assertXpathEvaluatesTo("fileName.txt","/insertDocumentRequest/requestDetails/insertDocument/documentAttributes/attribute[name='name']/value",document);
       assertXpathEvaluatesTo(folder,"/insertDocumentRequest/folder",document);
       assertXpathEvaluatesTo(path,"/insertDocumentRequest/directoryStructure",document);
       assertEquals(folder+"/ObjectId",reference.getDocumentId());
       assertEquals("1.0",reference.getVersion());
    }

   public String getResponse() throws Exception{
      String document =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
         "<documentManagerResponse>\n" +
         "      <insertDocument>\n" +
         "\t<documentDetails>\n" +
         "            \t<attribute>\n" +
         "\t            \t<name>objectId</name>\t\t\t\n" +
         "\t\t\t<value>ObjectId</value>\n" +
         "\t\t</attribute>\n" +
         "<attribute>\n" +
         "\t            \t<name>version</name>\t\t\t\n" +
         "\t\t\t<value>1.0</value>\n" +
         "\t\t</attribute>\n" +
         "\t</documentDetails>\n" +
         "      </insertDocument>\n" +
         "</documentManagerResponse>";
      return document;
   }
   @Test
   public void testRetrieveContent() throws Exception{
      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";
      reference.setDocumentId(folder +"/" + objectId);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);

      String fileContents = "The quick brown fox jumps over the lazy dog.";
      String version = "25.3";
      reference.setVersion(version);

      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);
      String mimeType = POSMIMEConstants.MIME_TYPE_MSVISIO;

      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      String response = buildRetrieveDocumentResponse(fileContents,objectId,version);
      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((response.getBytes())));


      when(posConnection.callService(eq("RetrieveDocumentService"),any(Document.class) )).thenReturn(posResult);

      DocumentContent content = business.retrieveContent(reference);

      verify(posConnection).callService(eq("RetrieveDocumentService"),documentCaptor.capture());
      Document requestDocument = documentCaptor.getValue();

      assertXpathEvaluatesTo(folder,"/retrieveDocumentRequest/folder",requestDocument);
      assertXpathEvaluatesTo(objectId,"/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute[name='objectId']/value",requestDocument);
      assertXpathEvaluatesTo(version,"/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute[name='version']/value",requestDocument);

      assertEquals(POSMIMEConstants.MIME_TYPE_OCTET_STREAM,content.getContents().getContentType());
      byte[] readContents = new byte[content.getContents().getInputStream().available()];
      content.getContents().getInputStream().read(readContents);

      Assert.assertArrayEquals(fileContents.getBytes(),readContents);
      assertEquals(version,content.getVersion());
      assertEquals(reference.getDocumentId(),content.getReference().getDocumentId());
      assertEquals(reference.getVersion(),version);
   }
   @Test
   public void testRetrieveContent_ThrowsNotFoundException() throws Exception{
      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";
      reference.setDocumentId(folder +"/" + objectId);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);

      String fileContents = "The quick brown fox jumps over the lazy dog.";
      String version = "25.3";
      reference.setVersion(version);

      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);
      String mimeType = POSMIMEConstants.MIME_TYPE_MSVISIO;

      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      String response = buildRetrieveDocumentResponse(fileContents,objectId,version);
      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((response.getBytes())));


      when(posConnection.callService(eq("RetrieveDocumentService"),any(Document.class) )).thenThrow(new RuntimeException(DocumentContentManagementBusinessDocumentumImpl.DOES_NOT_EXIST));

      try {
         DocumentContent content = business.retrieveContent(reference);
         fail();
      }
      catch (NotFoundException nfe){
         assertSame(reference,nfe.getReference());
      }
   }

   @Test
   public void testRetrieve() throws Exception{
      ViewField viewField1 = new ViewField();
      viewField1.setName("viewField1");
      ViewField viewField2 = new ViewField();
      viewField2.setName("viewField2");
      ViewFields viewFields = new ViewFields();
      viewFields.setViewFields(Arrays.asList(viewField1,viewField2));
      

      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";
      reference.setDocumentId(folder +"/" + objectId);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);

      String fileContents = "The quick brown fox jumps over the lazy dog.";
      String version = "25.3";
      reference.setVersion(version);

      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);
    

      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      String response = buildRetrieveDocumentWithAttributesResponse(fileContents,objectId,version,viewFields);
      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((response.getBytes())));


      when(posConnection.callService(eq("RetrieveDocumentService"),any(Document.class) )).thenReturn(posResult);

      Collection<com.monsanto.dcm.transfer.Document> contents = business.retrieve(Arrays.asList(reference),viewFields);

      assertEquals(1,contents.size());
      com.monsanto.dcm.transfer.Document content = contents.iterator().next();
      assertEquals(2,content.getFieldTypeValues().getFieldTypeValues().size());
      Iterator valuesIter = content.getFieldTypeValues().getFieldTypeValues().iterator();
      FieldTypeValue value1 = (FieldTypeValue)valuesIter.next();
      FieldTypeValue value2 = (FieldTypeValue)valuesIter.next();
      assertEquals("viewField1",value1.getName());
      assertEquals("viewField1value",value1.getValue());
      assertEquals("viewField2",value2.getName());
      assertEquals("viewField2value",value2.getValue());

      verify(posConnection).callService(eq("RetrieveDocumentService"),documentCaptor.capture());
      Document requestDocument = documentCaptor.getValue();

      assertXpathEvaluatesTo(folder,"/retrieveDocumentRequest/folder",requestDocument);
      assertXpathEvaluatesTo(objectId,"/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute[name='objectId']/value",requestDocument);
      assertXpathEvaluatesTo(version,"/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute[name='version']/value",requestDocument);
      assertXpathEvaluatesTo("viewField1","/retrieveDocumentRequest/requestDetails/retrieveDocument/requiredAttributes/attribute[1]",requestDocument);
      assertXpathEvaluatesTo("viewField2","/retrieveDocumentRequest/requestDetails/retrieveDocument/requiredAttributes/attribute[2]",requestDocument);      

      assertEquals(POSMIMEConstants.MIME_TYPE_OCTET_STREAM,content.getContents().getContentType());
      byte[] readContents = new byte[content.getContents().getInputStream().available()];
      content.getContents().getInputStream().read(readContents);

      Assert.assertArrayEquals(fileContents.getBytes(),readContents);
      assertEquals(version,content.getVersion());
      assertEquals(reference.getDocumentId(),content.getReference().getDocumentId());
      assertEquals(reference.getVersion(),version);
   }
   @Test
   public void testRetrieve_ThrowsNotFoundException() throws Exception{
      ViewField viewField1 = new ViewField();
      viewField1.setName("viewField1");
      ViewField viewField2 = new ViewField();
      viewField2.setName("viewField2");
      ViewFields viewFields = new ViewFields();
      viewFields.setViewFields(Arrays.asList(viewField1,viewField2));


      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";
      reference.setDocumentId(folder +"/" + objectId);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);

      String fileContents = "The quick brown fox jumps over the lazy dog.";
      String version = "25.3";
      reference.setVersion(version);

      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);


      
      String response = buildRetrieveDocumentWithAttributesResponse(fileContents,objectId,version,viewFields);
      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((response.getBytes())));


      when(posConnection.callService(eq("RetrieveDocumentService"),any(Document.class) )).thenThrow(new RuntimeException(DocumentContentManagementBusinessDocumentumImpl.DOES_NOT_EXIST));

      try {
        Collection<com.monsanto.dcm.transfer.Document> contents = business.retrieve(Arrays.asList(reference),viewFields);
         fail();
      }
      catch(NotFoundException nfe){
         assertSame(reference,nfe.getReference());
      }
   }

   @Test
   public void testRetrieveDetails_ThrowsNotFoundException() throws Exception{
      ViewField viewField1 = new ViewField();
      viewField1.setName("viewField1");
      ViewField viewField2 = new ViewField();
      viewField2.setName("viewField2");
      ViewFields viewFields = new ViewFields();
      viewFields.setViewFields(Arrays.asList(viewField1,viewField2));


      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";
      reference.setDocumentId(folder +"/" + objectId);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);

      String fileContents = "The quick brown fox jumps over the lazy dog.";
      String version = "25.3";
      reference.setVersion(version);

      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);


     
      String response = buildRetrieveDocumentWithAttributesResponse(fileContents,objectId,version,viewFields);
      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((response.getBytes())));


      when(posConnection.callService(eq("RetrieveDocumentService"),any(Document.class) )).thenThrow(new RuntimeException(DocumentContentManagementBusinessDocumentumImpl.DOES_NOT_EXIST));
      try {
         Collection<com.monsanto.dcm.transfer.Document> contents = business.retrieve(Arrays.asList(reference),viewFields);
         fail();
      }
      catch (NotFoundException nfe){
         assertSame(reference,nfe.getReference());
      }
   }

   @Test
   public void testSearchReturnsSingleResultWithAllFieldsSet() throws Exception{
       String folder = "folder";
       String path = "path";
       String  location = "/"+folder+"/"+path;

      ViewField viewField1 = new ViewField();
      viewField1.setName("viewField1");
      ViewField viewField2 = new ViewField();
      viewField2.setName("viewField2");
      ViewFields viewFields = new ViewFields();
      viewFields.setReturnAll(true);
      viewFields.setViewFields(Arrays.asList(viewField1,viewField2));

      SearchFullText searchFullText = new SearchFullText();
      searchFullText.setOperator(SearchOperator.EQUALS);
      searchFullText.setSearchText("searchFullText");

      List<SearchField> searchFieldsList = new ArrayList<SearchField>();
      SearchField searchField = new SearchField();
      searchField.setName("searchFieldName");
      searchField.setOperator(SearchOperator.EQUALS);
      searchField.setValue("searchFieldText");
      searchFieldsList.add(searchField);
      SearchFields searchFields =new SearchFields();
      searchFields.setSearchFields(searchFieldsList);
      SearchRequest searchRequest = new SearchRequest();
      searchRequest.setSearchFullText(searchFullText);
      searchRequest.setSearchFields(searchFields);
      searchRequest.setViewFields(viewFields);
      searchRequest.setSearchLatestVersion(true);
      searchRequest.setLocation(location);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);


      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((buildSearchResults().getBytes())));
      when(posConnection.callService(eq("SearchDocumentsService"),any(Document.class) )).thenReturn(posResult);
      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);

      SearchResult searchResult =  business.search(searchRequest);

      Collection<DocumentDetail> contents = searchResult.getDocumentDetails();
      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      verify(posConnection).callService(eq("SearchDocumentsService"),documentCaptor.capture());
      
      Document requestDocument = documentCaptor.getValue();

      assertXpathEvaluatesTo(folder,"/searchDocumentsRequest/folder",requestDocument);
      assertXpathEvaluatesTo(path,"/searchDocumentsRequest/directoryStructure",requestDocument);
      assertXpathEvaluatesTo("false","/searchDocumentsRequest/requestDetails/searchDocuments/searchAllVersions",requestDocument);
      assertXpathEvaluatesTo("searchFieldText","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='searchFieldName']/value",requestDocument);
      assertXpathEvaluatesTo("equals","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='searchFieldName']/operator",requestDocument);
      assertXpathEvaluatesTo("searchFullText","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='full_text']/value",requestDocument);
      assertXpathEvaluatesTo("equals","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='full_text']/operator",requestDocument);
      assertXpathEvaluatesTo("viewField1","/searchDocumentsRequest/requestDetails/searchDocuments/requiredAttributes/attribute[1]",requestDocument);
      assertXpathEvaluatesTo("viewField2","/searchDocumentsRequest/requestDetails/searchDocuments/requiredAttributes/attribute[2]",requestDocument);

      assertEquals(1,contents.size());
      DocumentDetail content = contents.iterator().next();
      assertEquals("folder/ObjectId",content.getDocumentId());
      assertEquals("1.0",content.getVersion());
      assertEquals(2,content.getFieldTypeValues().getFieldTypeValues().size());
      Iterator valuesIter = content.getFieldTypeValues().getFieldTypeValues().iterator();
      FieldTypeValue value1 = (FieldTypeValue)valuesIter.next();
      FieldTypeValue value2 = (FieldTypeValue)valuesIter.next();
      assertEquals("viewField1",value1.getName());
      assertEquals("viewField1value",value1.getValue());
      assertEquals("viewField2",value2.getName());
      assertEquals("viewField2value",value2.getValue());
   }

   @Test
   public void testSearchReturnsSingleResultSearchFullTextOperatorIsNull() throws Exception{
       String folder = "folder";
       String path = "path";
       String  location = "/"+folder+"/"+path;

      ViewField viewField1 = new ViewField();
      viewField1.setName("viewField1");
      ViewField viewField2 = new ViewField();
      viewField2.setName("viewField2");
      ViewFields viewFields = new ViewFields();
      viewFields.setReturnAll(true);
      viewFields.setViewFields(Arrays.asList(viewField1,viewField2));

      SearchFullText searchFullText = new SearchFullText();
      searchFullText.setOperator(null);
      searchFullText.setSearchText("searchFullText");

      List<SearchField> searchFieldsList = new ArrayList<SearchField>();
      SearchField searchField = new SearchField();
      searchField.setName("searchFieldName");
      searchField.setOperator(SearchOperator.EQUALS);
      searchField.setValue("searchFieldText");
      searchFieldsList.add(searchField);
      SearchFields searchFields =new SearchFields();
      searchFields.setSearchFields(searchFieldsList);
      SearchRequest searchRequest = new SearchRequest();
      searchRequest.setSearchFullText(searchFullText);
      searchRequest.setSearchFields(searchFields);
      searchRequest.setViewFields(viewFields);
      searchRequest.setSearchLatestVersion(true);
      searchRequest.setLocation(location);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);


      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((buildSearchResults().getBytes())));
      when(posConnection.callService(eq("SearchDocumentsService"),any(Document.class) )).thenReturn(posResult);
      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);

      SearchResult searchResult =  business.search(searchRequest);

      Collection<DocumentDetail> contents = searchResult.getDocumentDetails();
      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      verify(posConnection).callService(eq("SearchDocumentsService"),documentCaptor.capture());

      Document requestDocument = documentCaptor.getValue();

      assertXpathEvaluatesTo(folder,"/searchDocumentsRequest/folder",requestDocument);
      assertXpathEvaluatesTo(path,"/searchDocumentsRequest/directoryStructure",requestDocument);
      assertXpathEvaluatesTo("false","/searchDocumentsRequest/requestDetails/searchDocuments/searchAllVersions",requestDocument);
      assertXpathEvaluatesTo("searchFieldText","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='searchFieldName']/value",requestDocument);
      assertXpathEvaluatesTo("equals","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='searchFieldName']/operator",requestDocument);
      assertXpathEvaluatesTo("searchFullText","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='full_text']/value",requestDocument);
      assertXpathEvaluatesTo("equals","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='full_text']/operator",requestDocument);
      assertXpathEvaluatesTo("viewField1","/searchDocumentsRequest/requestDetails/searchDocuments/requiredAttributes/attribute[1]",requestDocument);
      assertXpathEvaluatesTo("viewField2","/searchDocumentsRequest/requestDetails/searchDocuments/requiredAttributes/attribute[2]",requestDocument);

      assertEquals(1,contents.size());
      DocumentDetail content = contents.iterator().next();
      assertEquals("folder/ObjectId",content.getDocumentId());
      assertEquals("1.0",content.getVersion());
      assertEquals(2,content.getFieldTypeValues().getFieldTypeValues().size());
      Iterator valuesIter = content.getFieldTypeValues().getFieldTypeValues().iterator();
      FieldTypeValue value1 = (FieldTypeValue)valuesIter.next();
      FieldTypeValue value2 = (FieldTypeValue)valuesIter.next();
      assertEquals("viewField1",value1.getName());
      assertEquals("viewField1value",value1.getValue());
      assertEquals("viewField2",value2.getName());
      assertEquals("viewField2value",value2.getValue());
   }
   @Test
   public void testSearchReturnsSingleResultSearchFullTextNotSet() throws Exception{
       String folder = "folder";
       String path = "path";
       String  location = "/"+folder+"/"+path;

      ViewField viewField1 = new ViewField();
      viewField1.setName("viewField1");
      ViewField viewField2 = new ViewField();
      viewField2.setName("viewField2");
      ViewFields viewFields = new ViewFields();
      viewFields.setReturnAll(true);
      viewFields.setViewFields(Arrays.asList(viewField1,viewField2));



      List<SearchField> searchFieldsList = new ArrayList<SearchField>();
      SearchField searchField = new SearchField();
      searchField.setName("searchFieldName");
      searchField.setOperator(SearchOperator.EQUALS);
      searchField.setValue("searchFieldText");
      searchFieldsList.add(searchField);
      SearchFields searchFields =new SearchFields();
      searchFields.setSearchFields(searchFieldsList);
      SearchRequest searchRequest = new SearchRequest();
      searchRequest.setSearchFullText(null);
      searchRequest.setSearchFields(searchFields);
      searchRequest.setViewFields(viewFields);
      searchRequest.setSearchLatestVersion(true);
      searchRequest.setLocation(location);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);


      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((buildSearchResults().getBytes())));
      when(posConnection.callService(eq("SearchDocumentsService"),any(Document.class) )).thenReturn(posResult);
      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);

      SearchResult searchResult =  business.search(searchRequest);

      Collection<DocumentDetail> contents = searchResult.getDocumentDetails();
      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      verify(posConnection).callService(eq("SearchDocumentsService"),documentCaptor.capture());

      Document requestDocument = documentCaptor.getValue();

      assertXpathEvaluatesTo(folder,"/searchDocumentsRequest/folder",requestDocument);
      assertXpathEvaluatesTo(path,"/searchDocumentsRequest/directoryStructure",requestDocument);
      assertXpathEvaluatesTo("false","/searchDocumentsRequest/requestDetails/searchDocuments/searchAllVersions",requestDocument);
      assertXpathEvaluatesTo("searchFieldText","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='searchFieldName']/value",requestDocument);
      assertXpathEvaluatesTo("equals","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='searchFieldName']/operator",requestDocument);
      assertXpathNotExists("/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='full_text']",requestDocument);
      assertXpathEvaluatesTo("viewField1","/searchDocumentsRequest/requestDetails/searchDocuments/requiredAttributes/attribute[1]",requestDocument);
      assertXpathEvaluatesTo("viewField2","/searchDocumentsRequest/requestDetails/searchDocuments/requiredAttributes/attribute[2]",requestDocument);

      assertEquals(1,contents.size());
      DocumentDetail content = contents.iterator().next();
      assertEquals("folder/ObjectId",content.getDocumentId());
      assertEquals("1.0",content.getVersion());
      assertEquals(2,content.getFieldTypeValues().getFieldTypeValues().size());
      Iterator valuesIter = content.getFieldTypeValues().getFieldTypeValues().iterator();
      FieldTypeValue value1 = (FieldTypeValue)valuesIter.next();
      FieldTypeValue value2 = (FieldTypeValue)valuesIter.next();
      assertEquals("viewField1",value1.getName());
      assertEquals("viewField1value",value1.getValue());
      assertEquals("viewField2",value2.getName());
      assertEquals("viewField2value",value2.getValue());
   }

   @Test
   public void testSearchReturnsSingleResultSearchLatestVersionFalse() throws Exception{
       String folder = "folder";
       String path = "path";
       String  location = "/"+folder+"/"+path;

      ViewField viewField1 = new ViewField();
      viewField1.setName("viewField1");
      ViewField viewField2 = new ViewField();
      viewField2.setName("viewField2");
      ViewFields viewFields = new ViewFields();
      viewFields.setReturnAll(true);
      viewFields.setViewFields(Arrays.asList(viewField1,viewField2));

      SearchFullText searchFullText = new SearchFullText();
      searchFullText.setOperator(SearchOperator.EQUALS);
      searchFullText.setSearchText("searchFullText");

      List<SearchField> searchFieldsList = new ArrayList<SearchField>();
      SearchField searchField = new SearchField();
      searchField.setName("searchFieldName");
      searchField.setOperator(SearchOperator.EQUALS);
      searchField.setValue("searchFieldText");
      searchFieldsList.add(searchField);
      SearchFields searchFields =new SearchFields();
      searchFields.setSearchFields(searchFieldsList);
      SearchRequest searchRequest = new SearchRequest();
      searchRequest.setSearchFullText(searchFullText);
      searchRequest.setSearchFields(searchFields);
      searchRequest.setViewFields(viewFields);
      searchRequest.setSearchLatestVersion(false);
      searchRequest.setLocation(location);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);


      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((buildSearchResults().getBytes())));
      when(posConnection.callService(eq("SearchDocumentsService"),any(Document.class) )).thenReturn(posResult);
      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);

      SearchResult searchResult =  business.search(searchRequest);

      Collection<DocumentDetail> contents = searchResult.getDocumentDetails();
      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      verify(posConnection).callService(eq("SearchDocumentsService"),documentCaptor.capture());

      Document requestDocument = documentCaptor.getValue();

      assertXpathEvaluatesTo(folder,"/searchDocumentsRequest/folder",requestDocument);
      assertXpathEvaluatesTo(path,"/searchDocumentsRequest/directoryStructure",requestDocument);
      assertXpathEvaluatesTo("true","/searchDocumentsRequest/requestDetails/searchDocuments/searchAllVersions",requestDocument);
      assertXpathEvaluatesTo("searchFieldText","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='searchFieldName']/value",requestDocument);
      assertXpathEvaluatesTo("equals","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='searchFieldName']/operator",requestDocument);
      assertXpathEvaluatesTo("searchFullText","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='full_text']/value",requestDocument);
      assertXpathEvaluatesTo("equals","/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute[name='full_text']/operator",requestDocument);
      assertXpathEvaluatesTo("viewField1","/searchDocumentsRequest/requestDetails/searchDocuments/requiredAttributes/attribute[1]",requestDocument);
      assertXpathEvaluatesTo("viewField2","/searchDocumentsRequest/requestDetails/searchDocuments/requiredAttributes/attribute[2]",requestDocument);

      assertEquals(1,contents.size());
      DocumentDetail content = contents.iterator().next();
      assertEquals("folder/ObjectId",content.getDocumentId());
      assertEquals("1.0",content.getVersion());
      assertEquals(2,content.getFieldTypeValues().getFieldTypeValues().size());
      Iterator valuesIter = content.getFieldTypeValues().getFieldTypeValues().iterator();
      FieldTypeValue value1 = (FieldTypeValue)valuesIter.next();
      FieldTypeValue value2 = (FieldTypeValue)valuesIter.next();
      assertEquals("viewField1",value1.getName());
      assertEquals("viewField1value",value1.getValue());
      assertEquals("viewField2",value2.getName());
      assertEquals("viewField2value",value2.getValue());
   }

   public String buildSearchResults(){
      return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
         "<documentManagerResponse>\n" +
         "  <searchDocuments>\n" +
         "    <documentDetails>\n" +
         "      <attribute>\n" +
         "        <name>objectId</name>\n" +
         "        <value>ObjectId</value>\n" +
         "      </attribute>\n" +
         "      <attribute>\n" +
         "        <name>version</name>\n" +
         "        <value>1.0</value>\n" +
         "      </attribute>\n" +
         "      <attribute>\n" +
         "        <name>viewField1</name>\n" +
         "        <value>viewField1value</value>\n" +
         "      </attribute>\n" +
         "      <attribute>\n" +
         "        <name>viewField2</name>\n" +
         "        <value>viewField2value</value>\n" +
         "      </attribute>\n" +
         "    </documentDetails>\n" +
         "  </searchDocuments>\n" +
         "</documentManagerResponse>";
   }
   @Test
   public void testRetrieveDetails() throws Exception{
      ViewField viewField1 = new ViewField();
      viewField1.setName("viewField1");
      ViewField viewField2 = new ViewField();
      viewField2.setName("viewField2");
      ViewFields viewFields = new ViewFields();
      viewFields.setReturnAll(true);
      viewFields.setViewFields(Arrays.asList(viewField1,viewField2));

      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";
      reference.setDocumentId(folder +"/" + objectId);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);

      String fileContents = "The quick brown fox jumps over the lazy dog.";
      String version = "25.3";
      reference.setVersion(version);

      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);
      String mimeType = POSMIMEConstants.MIME_TYPE_MSVISIO;

      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      String response = buildRetrieveDocumentWithAttributesResponse(fileContents,objectId,version,viewFields);
      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((response.getBytes())));


      when(posConnection.callService(eq("RetrieveDocumentService"),any(Document.class) )).thenReturn(posResult);

      Collection<DocumentDetail> contents = business.retrieveDetails(Arrays.asList(reference),viewFields);

      assertEquals(1,contents.size());
      DocumentDetail content = contents.iterator().next();
      assertEquals(2,content.getFieldTypeValues().getFieldTypeValues().size());
      Iterator valuesIter = content.getFieldTypeValues().getFieldTypeValues().iterator();
      FieldTypeValue value1 = (FieldTypeValue)valuesIter.next();
      FieldTypeValue value2 = (FieldTypeValue)valuesIter.next();
      assertEquals("viewField1",value1.getName());
      assertEquals("viewField1value",value1.getValue());
      assertEquals("viewField2",value2.getName());
      assertEquals("viewField2value",value2.getValue());

      verify(posConnection).callService(eq("RetrieveDocumentService"),documentCaptor.capture());
      Document requestDocument = documentCaptor.getValue();

      assertXpathEvaluatesTo(folder,"/retrieveDocumentRequest/folder",requestDocument);
      assertXpathEvaluatesTo(objectId,"/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute[name='objectId']/value",requestDocument);
      assertXpathEvaluatesTo(version,"/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute[name='version']/value",requestDocument);
      assertXpathEvaluatesTo("viewField1","/retrieveDocumentRequest/requestDetails/retrieveDocument/requiredAttributes/attribute[1]",requestDocument);
      assertXpathEvaluatesTo("viewField2","/retrieveDocumentRequest/requestDetails/retrieveDocument/requiredAttributes/attribute[2]",requestDocument);
      assertEquals(version,content.getVersion());
      assertEquals(reference.getDocumentId(),content.getReference().getDocumentId());
      assertEquals(reference.getVersion(),version);

   }


   public String buildRetrieveDocumentWithAttributesResponse(String contents,String objectId,String version, ViewFields viewFields){
      StringBuilder retval = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
         "<documentManagerResponse>\n" +
         "  <retrieveDocument>\n" +
         "    <documentDetails>\n" +
         "      <attribute>\n" +
         "        <name>contents</name>\n" +
         "        <value>" +
                  Base64.encode(contents.getBytes()) +
         "        </value>\n" +
         "      </attribute>\n" +
         "      <attribute>\n" +
         "        <name>objectId</name>\n" +
         "        <value>" +
                  objectId +
         "</value>\n" +
         "      </attribute>\n" +
         "      <attribute>\n" +
         "<name>version</name>\n" +
         "<value>" +
          version+
         "</value>\n" +
         "      </attribute>\n" +
         "      <attribute>\n" +
         "        <name>name</name>\n" +
         "        <value>apptestFile.txt</value>\n" +
         "      </attribute>\n" );
      for(ViewField viewField: viewFields.getViewFields()){
         retval.append(" <attribute><name>"+viewField.getName()+"</name><value>"+viewField.getName()+"value</value></attribute>\n");
      }
      retval.append("    </documentDetails>\n" +
         "  </retrieveDocument>\n" +
         "</documentManagerResponse>");
      return retval.toString();
   }

   public String buildRetrieveDocumentResponse(String contents,String objectId,String version ){
      String retval = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
         "<documentManagerResponse>\n" +
         "  <retrieveDocument>\n" +
         "    <documentDetails>\n" +
         "      <attribute>\n" +
         "        <name>contents</name>\n" +
         "        <value>" +
                  Base64.encode(contents.getBytes()) +
         "        </value>\n" +
         "      </attribute>\n" +
         "      <attribute>\n" +
         "        <name>objectId</name>\n" +
         "        <value>" +
                  objectId +
         "</value>\n" +
         "      </attribute>\n" +
         "      <attribute>\n" +
         "<name>version</name>\n" +
         "<value>" +
          version+
         "</value>\n" +
         "      </attribute>\n" +
         "      <attribute>\n" +
         "        <name>name</name>\n" +
         "        <value>apptestFile.txt</value>\n" +
         "      </attribute>\n" +
         "    </documentDetails>\n" +
         "  </retrieveDocument>\n" +
         "</documentManagerResponse>";
      return retval;
   }

   @Test
   public void testDeleteDocument() throws Exception{
      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";
      String version = "25.3";
      reference.setDocumentId(folder +"/" + objectId);
      
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);

      reference.setVersion(version);

      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);
      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      String response = buildDeleteDocumentResponse(objectId,version);
      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((response.getBytes())));
      when(posConnection.callService(eq("DeleteDocumentService"),any(Document.class) )).thenReturn(posResult);
      business.delete(reference);
      verify(posConnection).callService(eq("DeleteDocumentService"),documentCaptor.capture());
      Document requestDocument = documentCaptor.getValue();

      assertXpathEvaluatesTo(folder,"/deleteDocumentRequest/folder",requestDocument);
      assertXpathEvaluatesTo(objectId,"/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute[name='objectId']/value",requestDocument);
      assertXpathEvaluatesTo(version,"/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute[name='version']/value",requestDocument);
   }

   @Test
   public void testDeleteDocument_ThrowsNotFoundException() throws Exception{
      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";
      String version = "25.3";
      reference.setDocumentId(folder +"/" + objectId);

      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);

      reference.setVersion(version);

      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);
      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      String response = buildDeleteDocumentResponse(objectId,version);
      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((response.getBytes())));
      when(posConnection.callService(eq("DeleteDocumentService"),any(Document.class) )).thenThrow(new RuntimeException(DocumentContentManagementBusinessDocumentumImpl.DOES_NOT_EXIST));
      try{
         business.delete(reference);
         fail();
      }
      catch (NotFoundException nfe){
         assertSame(reference,nfe.getReference());
      }
   }

   public String buildDeleteDocumentResponse(String objectId, String version){
      return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
         "<documentManagerResponse>\n" +
         "  <documentDeletedSuccessfully>\n" +
         "    <documentDetails>\n" +
         "      <attribute>\n" +
         "        <name>objectId</name>\n" +
         "        <value>" +
          objectId+
         "</value>\n" +
         "      </attribute>\n" +
         "      <attribute>\n" +
         "        <name>version</name>\n" +
         "        <value>" +
         version+
         "</value>\n" +
         "      </attribute>\n" +
         "    </documentDetails>\n" +
         "  </documentDeletedSuccessfully>\n" +
         "</documentManagerResponse>";
   }

   @Test
   public void testUpdate() throws Exception{
      String folder = "folder";
      String objectId = "ObjectId";
      String version = "1.0";

      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";
      when(contents.getContentType()).thenReturn(mimeType);

      String fileName = "fileName";
      when(contents.getName()).thenReturn(fileName);

     FieldValue fieldValue = new FieldValue();
     String fieldName = "fieldName";
     fieldValue.setFieldName(fieldName);
     String fieldValueValue = "fieldValue";
     fieldValue.setFieldValue(fieldValueValue);

     FieldValues fieldValues= new FieldValues();
     fieldValues.addFieldValue(fieldValue);





      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      ArgumentCaptor<MultiPartFormAttachment> multipartCaptor  = ArgumentCaptor.forClass(MultiPartFormAttachment.class);
      POSResult posResult= mock(POSResult.class);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((buildDocumentUpdatedResponse(objectId,version).getBytes())));
      when(posConnection.callService(anyString(),any(Document.class))).thenReturn(posResult);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);
      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);

      Reference reference = new Reference();
      reference.setDocumentId(folder + "/" + objectId);

      reference.setVersion(version);
      setFileNameRetrieval(posConnection);
      Reference returnedReference = business.update(reference, contents,fieldValues);

      verify(posConnection).addAttachment(multipartCaptor.capture());
      verify(posConnection).callService(eq("UpdateDocumentService"),documentCaptor.capture());

      Assert.assertTrue(multipartCaptor.getValue().getFileName().startsWith(System.getProperty("java.io.tmpdir")));
      File file = new File(multipartCaptor.getValue().getFileName());
      Assert.assertFalse(file.exists());
      assertEquals(multipartCaptor.getValue().getContentType(), POSMIMEConstants.MIME_TYPE_OCTET_STREAM);
      Document document = documentCaptor.getValue();


      assertXpathEvaluatesTo(objectId,"/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute[name='objectId']/value",document);
      assertXpathNotExists("/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute[name='updateVersion']",document);
      assertXpathEvaluatesTo(folder,"/updateDocumentRequest/folder",document);

      assertEquals(folder+ "/" + objectId, returnedReference.getDocumentId());
      assertEquals("1.0", returnedReference.getVersion());

   }
   @Test
   public void testUpdate_ThrowsNotFoundException() throws Exception{
      String folder = "folder";
      String objectId = "ObjectId";
      String version = "1.0";

      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";
      when(contents.getContentType()).thenReturn(mimeType);

      String fileName = "fileName";
      when(contents.getName()).thenReturn(fileName);

     FieldValue fieldValue = new FieldValue();
     String fieldName = "fieldName";
     fieldValue.setFieldName(fieldName);
     String fieldValueValue = "fieldValue";
     fieldValue.setFieldValue(fieldValueValue);

     FieldValues fieldValues= new FieldValues();
     fieldValues.addFieldValue(fieldValue);

      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      ArgumentCaptor<MultiPartFormAttachment> multipartCaptor  = ArgumentCaptor.forClass(MultiPartFormAttachment.class);
      POSResult posResult= mock(POSResult.class);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((buildDocumentUpdatedResponse(objectId,version).getBytes())));
      when(posConnection.callService(anyString(),any(Document.class))).thenReturn(posResult);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);
      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);

      Reference reference = new Reference();
      reference.setDocumentId(folder + "/" + objectId);

      reference.setVersion(version);
      when(posConnection.callService(eq("UpdateDocumentService"),any(Document.class))).thenThrow(new RuntimeException(DocumentContentManagementBusinessDocumentumImpl.DOES_NOT_EXIST));
      setFileNameRetrieval(posConnection);
      try {
         Reference returnedReference = business.update(reference, contents,fieldValues);
         fail();
      }
      catch (NotFoundException nfe){
         assertEquals(reference.getDocumentId(),nfe.getReference().getDocumentId());
      }
   }

   public String buildDocumentUpdatedResponse(String objectId,String version){
      return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
         "<documentManagerResponse>\n" +
         "  <documentUpdatedSuccessfully>\n" +
         "    <documentDetails>\n" +
         "      <attribute>\n" +
         "        <name>objectId</name>\n" +
         "        <value>" +
         objectId+
         "</value>\n" +
         "      </attribute>\n" +
         "      <attribute>\n" +
         "        <name>version</name>\n" +
         "        <value>"+
         version +
         "</value>\n" +
         "      </attribute>\n" +
         "    </documentDetails>\n" +
         "  </documentUpdatedSuccessfully>\n" +
         "</documentManagerResponse>";
   }
   @Test
   public void testUpdateWithNextMajorTrue() throws Exception{
      String folder = "folder";
      String objectId = "ObjectId";
      String version = "1.0";

      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";
      when(contents.getContentType()).thenReturn(mimeType);

      String fileName = "fileName";
      when(contents.getName()).thenReturn(fileName);

     FieldValue fieldValue = new FieldValue();
     String fieldName = "fieldName";
     fieldValue.setFieldName(fieldName);
     String fieldValueValue = "fieldValue";
     fieldValue.setFieldValue(fieldValueValue);

     FieldValues fieldValues= new FieldValues();
     fieldValues.addFieldValue(fieldValue);





      ArgumentCaptor<Document> documentCaptor = ArgumentCaptor.forClass(Document.class);
      ArgumentCaptor<MultiPartFormAttachment> multipartCaptor  = ArgumentCaptor.forClass(MultiPartFormAttachment.class);
      POSResult posResult= mock(POSResult.class);
      XMLPOSConnection posConnection = mock(XMLPOSConnection.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((buildDocumentUpdatedResponse(objectId,version).getBytes())));
      when(posConnection.callService(anyString(),any(Document.class))).thenReturn(posResult);
      DocumentumPOSConnectionFactory connectionFactory =  mock(DocumentumPOSConnectionFactory.class);
      when(connectionFactory.buildXMLPOSConnection()).thenReturn(posConnection);
      DocumentContentManagementBusinessDocumentumImpl business = new DocumentContentManagementBusinessDocumentumImpl(velocityEngine,connectionFactory);

      Reference reference = new Reference();
      reference.setDocumentId(folder + "/" + objectId);

      reference.setVersion(version);
      setFileNameRetrieval(posConnection);
      Reference returnedReference = business.update(reference.getDocumentId(),true, contents,fieldValues);

      verify(posConnection).addAttachment(multipartCaptor.capture());
      verify(posConnection).callService(eq("UpdateDocumentService"),documentCaptor.capture());

      Assert.assertTrue(multipartCaptor.getValue().getFileName().startsWith(System.getProperty("java.io.tmpdir")));
      File file = new File(multipartCaptor.getValue().getFileName());
      Assert.assertFalse(file.exists());
      assertEquals(multipartCaptor.getValue().getContentType(), POSMIMEConstants.MIME_TYPE_OCTET_STREAM);
      Document document = documentCaptor.getValue();
      

      assertXpathEvaluatesTo(objectId,"/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute[name='objectId']/value",document);
      assertXpathEvaluatesTo("nextMajor","/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute[name='updateVersion']/value",document);
      assertXpathEvaluatesTo(folder,"/updateDocumentRequest/folder",document);

      assertEquals(folder+ "/" + objectId, returnedReference.getDocumentId());
      assertEquals("1.0", returnedReference.getVersion());

   }

   private void setFileNameRetrieval(POSConnection mockPosConnection)
      throws POSException, POSCommunicationException
   {
      ViewField viewField1 = new ViewField();
      viewField1.setName("name");

      ViewFields viewFields = new ViewFields();
      viewFields.setReturnAll(true);
      viewFields.setViewFields(Arrays.asList(viewField1));


      String response = buildRetrieveDocumentWithAttributesResponse("stuff","objectId","1.0",viewFields);
      POSResult posResult= mock(POSResult.class);
      when(posResult.getInputStream()).thenReturn(new ByteArrayInputStream((response.getBytes())));


      when(mockPosConnection.callService(eq("RetrieveDocumentService"),any(Document.class) )).thenReturn(posResult);
   }
}
