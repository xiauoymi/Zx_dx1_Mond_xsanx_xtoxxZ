package com.monsanto.dcm.security;

import com.monsanto.securityinterfaces.SystemSecurityProxy;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: EEHOCH
 * Date: May 6, 2008
 * Time: 9:55:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class SystemSecurityProxyFactory_UT extends TestCase
{

    public static boolean CreatedFakeServerCredential = false;
    public static boolean CreatedStandardCredential = false;

    public void testIsSingleton() {
        SystemSecurityProxyFactory factory = new SystemSecurityProxyFactory();
        assertFalse(factory.isSingleton());
    }

    public void testGetClass() {
        SystemSecurityProxyFactory factory = new SystemSecurityProxyFactory();
        assertEquals(SystemSecurityProxy.class, factory.getObjectType());
    }

    public void testCreateDefaultsFakeCredential() throws Exception {



        String dssp = System.getProperty("documentum.system.security.proxy");
        System.clearProperty("documentum.system.security.proxy");
        CreatedFakeServerCredential = false;
        SystemSecurityProxyFactory factory = new MockSystemSecurityProxyFactory();
        factory.getObject();
        System.setProperty("documentum.system.security.proxy",dssp);
        assertTrue(CreatedFakeServerCredential);

    }

    public void testCreateFakeCredential() throws Exception {
         System.setProperty("documentum.system.security.proxy","kerberos.server.credentials");
        CreatedFakeServerCredential = false;
        SystemSecurityProxyFactory factory = new MockSystemSecurityProxyFactory();
        factory.getObject();
        assertTrue(CreatedFakeServerCredential);
    }

    public void testCreateStandardCredential() throws Exception {
        System.setProperty("documentum.system.security.proxy","kerberos.standard.credentials");
        SystemSecurityProxyFactory factory = new MockSystemSecurityProxyFactory();
        factory.getObject();
        assertTrue(CreatedStandardCredential);
    }

    public class MockSystemSecurityProxyFactory extends SystemSecurityProxyFactory {

         protected SystemSecurityProxy createFakeServerCredential() throws Exception {
            CreatedFakeServerCredential = true;
            return null;
        }

        protected SystemSecurityProxy createStandardCredential() throws Exception {
            CreatedStandardCredential = true;
            return null;
        }
    }
}