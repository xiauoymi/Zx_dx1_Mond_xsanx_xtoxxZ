package com.monsanto.dcm.security.kerberos;

import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: EEHOCH
 * Date: May 27, 2008
 * Time: 9:41:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class ServerGSSCredentialBuilder_UT extends TestCase
{

    public void testExceptionThrownIfUpnNotSet() {
        ServerGSSCredentialBuilder builder = new ServerGSSCredentialBuilder();
        try {
            builder.build();
            fail("Exceptiocdn not thrown!");
        } catch (Exception ex) {
        }
    }

    public void testLoginFileNotFound() {
        ServerGSSCredentialBuilder builder = new ServerGSSCredentialBuilder();
        System.setProperty(ServerGSSCredentialBuilder.MONSANTO_PRINCIPAL_UPN, "FakeUpn");
        try {
            builder.build();
            fail("Exception not thrown!");
        } catch (Exception ex) {
        }
    }

}
