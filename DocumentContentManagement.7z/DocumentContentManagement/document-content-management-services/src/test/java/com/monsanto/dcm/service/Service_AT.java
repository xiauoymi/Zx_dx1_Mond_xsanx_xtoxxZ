package com.monsanto.dcm.service;

import com.monsanto.dcm.transfer.FieldValue;
import com.monsanto.dcm.transfer.FieldValues;
import com.monsanto.dcm.transfer.Reference;
import org.apache.cxf.attachment.ByteDataSource;
import org.apache.cxf.bus.extension.ExtensionManagerBus;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

import javax.activation.DataHandler;
import java.io.IOException;
import java.net.ConnectException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class Service_AT {
    private static final String LOCAL_SERVICE_URL =
            "http://localhost:7001/document-content-management/services/DocumentContentManagementService";

    @Test
    public void service() throws Exception {
        if (ifServerNotStarted()) {
            return;
        }

        DocumentContentManagementService service = createServiceClient();

        FieldValues fieldValues = new FieldValues();
        fieldValues.addFieldValue(new FieldValue("name", "value"));

//        DataHandler dataHandler = new DataHandler(new FileDataSource("C:\\downloads\\apache-cxf-2.2.7.zip"));
        DataHandler dataHandler = new DataHandler(new ByteDataSource(new byte[]{1, 2, 3, 4}));

        Reference reference = service.create("location", true, dataHandler, fieldValues);

        System.out.println(reference.getDocumentId());
        System.out.println(reference.getVersion());
    }

    private DocumentContentManagementService createServiceClient() {
        ExtensionManagerBus bus = new ExtensionManagerBus();

        Map<String, Object> props = new HashMap<String, Object>();
        props.put("mtom-enabled", Boolean.TRUE);

        JaxWsProxyFactoryBean bean = new JaxWsProxyFactoryBean();
        bean.setAddress(LOCAL_SERVICE_URL);
        bean.setServiceClass(DocumentContentManagementService.class);
        bean.setBus(bus);
        bean.setProperties(props);
        return (DocumentContentManagementService) bean.create();
    }

    private boolean ifServerNotStarted() throws IOException {
        try {
            URL url = new URL(LOCAL_SERVICE_URL);
            URLConnection urlConnection = url.openConnection();
            urlConnection.connect();
        } catch (ConnectException e) {
            return true;
        }
        return false;
    }
}
