package com.monsanto.tcc.dcm.exception;

import javax.xml.ws.WebFault;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@WebFault(name = "fatal")
public class FatalException extends RuntimeException {
    public FatalException() {
    }

    public FatalException(Throwable cause) {
        super(cause);
    }

    public FatalException(String message) {
        super(message);
    }

    public FatalException(String message, Throwable cause) {
        super(message, cause);
    }
}
