package com.monsanto.tcc.dcm.exception;


import com.monsanto.tcc.dcm.transfer.Reference;

import javax.xml.ws.WebFault;

/**
 * rlcasw - May 20, 2010 4:57:31 PM
 */
@WebFault(name = "notFound")
public class NotFoundException extends RequestException {
    private final Reference reference;

    public NotFoundException(Reference reference) {
        this.reference = reference;
    }

    public Reference getReference() {
        return reference;
    }
}
