package com.monsanto.tcc.dcm.exception;

import javax.xml.ws.WebFault;
import java.io.IOException;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@WebFault(name = "request")
public class RequestException extends RuntimeException {
    public RequestException() {
    }

    public RequestException(Throwable cause) {
        super(cause);
    }

    public RequestException(String message) {
        super(message);
    }

    public RequestException(String message, Throwable cause) {
        super(message, cause);
    }
}
