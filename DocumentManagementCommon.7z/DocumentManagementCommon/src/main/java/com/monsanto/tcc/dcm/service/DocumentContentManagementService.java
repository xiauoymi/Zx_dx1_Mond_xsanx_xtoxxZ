package com.monsanto.tcc.dcm.service;

import com.monsanto.tcc.dcm.transfer.Document;
import com.monsanto.tcc.dcm.transfer.Reference;
import com.monsanto.tcc.dcm.transfer.ViewFields;
import com.monsanto.tcc.dcm.transfer.DocumentDetail;
import com.monsanto.tcc.dcm.transfer.DocumentContent;
import com.monsanto.tcc.dcm.transfer.SearchResult;
import com.monsanto.tcc.dcm.transfer.SearchRequest;
import com.monsanto.tcc.dcm.transfer.FieldValues;
import com.monsanto.tcc.dcm.exception.RequestException;
import com.monsanto.tcc.dcm.exception.FatalException;

import javax.activation.DataHandler;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlMimeType;
import java.util.Collection;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@WebService
public interface DocumentContentManagementService {
    @WebMethod(operationName = "retrieve")
    @WebResult(name = "documents")
    Collection<Document> retrieve(@WebParam(name = "references") Collection<Reference> references,
                                  @WebParam(name = "viewFields") ViewFields viewFields)
            throws RequestException, FatalException;

    @WebMethod(operationName = "retrieveDetails")
    @WebResult(name = "documentDetails")
    Collection<DocumentDetail> retrieveDetails(@WebParam(name = "references") Collection<Reference> references,
                                               @WebParam(name = "viewFields") ViewFields viewFields)
            throws RequestException, FatalException;

    @WebMethod(operationName = "retrieveContent")
    @WebResult(name = "documentContent")
    DocumentContent retrieveContent(@WebParam(name = "reference") Reference reference)
            throws RequestException, FatalException;

    @WebMethod(operationName = "search")
    @WebResult(name = "searchResult")
    SearchResult search(@WebParam(name = "searchRequest") SearchRequest searchRequest)
            throws RequestException, FatalException;

    @WebMethod(operationName = "deleteAll")
    void deleteAll(@WebParam(name = "documentId") String documentId) throws RequestException, FatalException;

    @WebMethod(operationName = "delete")
    void delete(@WebParam(name = "reference") Reference reference) throws RequestException, FatalException;

    @WebMethod(operationName = "deleteLatest")
    void deleteLatest(@WebParam(name = "documentId") String documentId) throws RequestException, FatalException;

    @WebMethod(operationName = "update")
    @WebResult(name = "reference")
    Reference update(@WebParam(name = "reference") Reference reference,
                     @WebParam(name = "contents") @XmlMimeType("application/octet-stream") DataHandler dataHandler,
                     @WebParam(name = "fields") FieldValues fieldValues) throws RequestException, FatalException;

    @WebMethod(operationName = "updateNewVersion")
    @WebResult(name = "reference")
    Reference update(@WebParam(name = "documentId") String documentId,
                     @WebParam(name = "majorVersion") boolean majorVersion,
                     @WebParam(name = "contents") @XmlMimeType("application/octet-stream") DataHandler dataHandler,
                     @WebParam(name = "fields") FieldValues fieldValues)
            throws RequestException, FatalException;

    @WebMethod(operationName = "create")
    @WebResult(name = "reference")
    Reference create(@WebParam(name = "location") String location,
                     @WebParam(name = "versioningEnabled") boolean versioningEnabled,
                     @WebParam(name = "contents") @XmlMimeType("application/octet-stream") DataHandler dataHandler,
                     @WebParam(name = "fields") FieldValues fieldValues)
            throws RequestException, FatalException;
}
