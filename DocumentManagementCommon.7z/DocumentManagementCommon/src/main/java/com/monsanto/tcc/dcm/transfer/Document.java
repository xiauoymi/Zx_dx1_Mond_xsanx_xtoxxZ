package com.monsanto.tcc.dcm.transfer;

import javax.xml.bind.annotation.*;
import javax.activation.DataHandler;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@XmlType(name = "document")
public class Document {
    private Reference reference;
    private FieldTypeValues fieldTypeValues;
    private DataHandler contents;

     @XmlElement(name = "reference")
    public Reference getReference() {
        return reference;
    }

    public void setReference(Reference reference) {
        this.reference = reference;
    }

    @XmlMimeType("application/octet-stream")
    public DataHandler getContents() {
        return contents;
    }

    public void setContents(DataHandler contents) {
        this.contents = contents;
    }

    @XmlElement(name = "fields")
    public FieldTypeValues getFieldTypeValues() {
        return fieldTypeValues;
    }

    public void setFieldTypeValues(FieldTypeValues fieldTypeValues) {
        this.fieldTypeValues = fieldTypeValues;
    }


    public String getDocumentId() {
        return reference.getDocumentId();
    }


    public String getVersion() {
        return reference.getVersion();
    }
}
