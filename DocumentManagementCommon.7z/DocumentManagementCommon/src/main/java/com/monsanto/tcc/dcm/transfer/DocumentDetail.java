package com.monsanto.tcc.dcm.transfer;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@XmlType(name = "documentDetail")
public class DocumentDetail {
    private Reference reference;
    private FieldTypeValues fieldTypeValues;

    @XmlElement(name = "reference")
    public Reference getReference() {
        return reference;
    }

    public void setReference(Reference reference) {
        this.reference = reference;
    }

    @XmlElement(name = "fields")
    public FieldTypeValues getFieldTypeValues() {
        return fieldTypeValues;
    }

    public void setFieldTypeValues(FieldTypeValues fieldTypeValues) {
        this.fieldTypeValues = fieldTypeValues;
    }

    
    public String getDocumentId() {
        return reference.getDocumentId();
    }


    public String getVersion() {
        return reference.getVersion();
    }
}
