package com.monsanto.tcc.dcm.transfer;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlTransient;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
public class SearchField {
    private Field field = new Field();
    private SearchOperator operator = SearchOperator.EQUALS;

    @XmlTransient
    public SearchOperator getOperator() {
        return operator;
    }

    public void setOperator(SearchOperator operator) {
        this.operator = operator;
    }

    @XmlAttribute(name = "value")
    public String getValue() {
        return field.getValue();
    }

    public void setValue(String value) {
        field.setValue(value);
    }

    @XmlAttribute(name = "name")
    public String getName() {
        return field.getName();
    }

    public void setName(String name) {
        field.setName(name);
    }

    @XmlAttribute(name = "operator")
    public String getOperatorName() {
        return operator.getName();
    }

    public void setOperatorName(String name) {
        operator = SearchOperator.valueOfName(name);
    }
}
