package com.monsanto.tcc.dcm.transfer;

import java.util.Map;
import java.util.Collections;
import java.util.HashMap;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
public enum SearchOperator {

    EQUALS("equals");
   
    private static class NameMap {
       private static final Map<String,SearchOperator>  nameMap = Collections.synchronizedMap(new HashMap<String,SearchOperator>());
    }
   
    private String name;

   public static SearchOperator valueOfName(String name){
      return NameMap.nameMap.get(name);
   }

    SearchOperator(String name) {
        this.name = name;
        NameMap.nameMap.put(name,this);
    }

    public String getName() {
        return name;
    }
}
