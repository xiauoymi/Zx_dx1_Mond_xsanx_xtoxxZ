package com.monsanto.tcc.dcm.transfer;

import javax.xml.bind.annotation.XmlType;
import java.util.Collection;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@XmlType(name = "searchResult")
public class SearchResult {
    private Collection<DocumentDetail> documentDetails;

    public Collection<DocumentDetail> getDocumentDetails() {
        return documentDetails;
    }

    public void setDocumentDetails(Collection<DocumentDetail> documentDetails) {
        this.documentDetails = documentDetails;
    }
}
