package com.monsanto.tcc.dcm.transfer;

import javax.xml.bind.annotation.XmlAttribute;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
public class ViewField {
    private Field field = new Field();

    @XmlAttribute(name = "name")
    public String getName() {
        return field.getName();
    }

    public void setName(String name) {
        field.setName(name);
    }
}