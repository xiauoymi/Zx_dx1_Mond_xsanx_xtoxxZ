package com.monsanto.tcc.dcm.transfer;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@XmlType(name = "viewFields")
public class ViewFields {
    private Boolean returnAll;
    private Collection<ViewField> viewFields = new ArrayList<ViewField>();

    @XmlAttribute(name = "returnAll", required = false)
    public Boolean isReturnAll() {
        return returnAll;
    }

    public void setReturnAll(Boolean returnAll) {
        this.returnAll = returnAll;
    }

    @XmlElement(name = "field")
    public Collection<ViewField> getViewFields() {
        return viewFields;
    }

    public void setViewFields(Collection<ViewField> viewFields) {
        this.viewFields = viewFields;
    }
}
