package com.monsanto.tcc.dcm.exception;

import com.monsanto.tcc.dcm.transfer.Reference;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@SuppressWarnings({"ThrowableInstanceNeverThrown"})
@RunWith(JUnit4ClassRunner.class)
public class Exceptions_UT {
    private static final String MESSAGE = "message";
    private static final Throwable CAUSE = new RuntimeException();

    @Test
    public void fatal() {
        FatalException exception1 = new FatalException();
        FatalException exception2 = new FatalException(CAUSE);
        FatalException exception3 = new FatalException(MESSAGE);
        FatalException exception4 = new FatalException(MESSAGE, CAUSE);

        assertThat(exception1.getCause(), nullValue());
        assertThat(exception1.getMessage(), nullValue());

        assertThat(exception2.getCause(), sameInstance(CAUSE));
        assertThat(exception2.getMessage(), is(CAUSE.getClass().getName()));

        assertThat(exception3.getCause(), nullValue());
        assertThat(exception3.getMessage(), is(MESSAGE));

        assertThat(exception4.getCause(), sameInstance(CAUSE));
        assertThat(exception4.getMessage(), is(MESSAGE));
    }

    @Test
    public void notFound() {
        Reference reference = new Reference();
        NotFoundException exception = new NotFoundException(reference);

        assertThat(exception.getCause(), nullValue());
        assertThat(exception.getMessage(), nullValue());
        assertThat(exception.getReference(), sameInstance(reference));
    }

    @Test
    public void request() {
        RequestException exception1 = new RequestException();
        RequestException exception2 = new RequestException(CAUSE);
        RequestException exception3 = new RequestException(MESSAGE);
        RequestException exception4 = new RequestException(MESSAGE, CAUSE);

        assertThat(exception1.getCause(), nullValue());
        assertThat(exception1.getMessage(), nullValue());

        assertThat(exception2.getCause(), sameInstance(CAUSE));
        assertThat(exception2.getMessage(), is(CAUSE.getClass().getName()));

        assertThat(exception3.getCause(), nullValue());
        assertThat(exception3.getMessage(), is(MESSAGE));

        assertThat(exception4.getCause(), sameInstance(CAUSE));
        assertThat(exception4.getMessage(), is(MESSAGE));
    }
}
