package com.monsanto.tcc.dcm.transfer;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class DocumentDetail_UT {
    private FieldTypeValues fieldTypeValues;
    private Reference reference;

    @Before
    public void setUp() throws Exception {
        fieldTypeValues = new FieldTypeValues();
        reference = new Reference();
        reference.setDocumentId("document id");
        reference.setVersion("version");
    }

    @Test
    public void coverage() {
        DocumentDetail documentDetail = new DocumentDetail();
        documentDetail.setFieldTypeValues(fieldTypeValues);
        documentDetail.setReference(reference);

        assertThat(documentDetail.getFieldTypeValues(), sameInstance(fieldTypeValues));
        assertThat(documentDetail.getReference(), sameInstance(reference));
        assertThat(documentDetail.getDocumentId(), is(reference.getDocumentId()));
        assertThat(documentDetail.getVersion(), is(reference.getVersion()));
    }
}