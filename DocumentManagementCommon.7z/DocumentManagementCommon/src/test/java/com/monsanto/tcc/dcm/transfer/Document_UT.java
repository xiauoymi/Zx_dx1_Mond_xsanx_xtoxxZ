package com.monsanto.tcc.dcm.transfer;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;
import static org.mockito.Mockito.mock;

import javax.activation.DataHandler;
import javax.activation.DataSource;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class Document_UT {
    private DataHandler contents;
    private FieldTypeValues fieldTypeValues;
    private Reference reference;

    @Before
    public void setUp() throws Exception {
        contents = new DataHandler(mock(DataSource.class));
        fieldTypeValues = new FieldTypeValues();
        reference = new Reference();
        reference.setDocumentId("document id");
        reference.setVersion("version");
    }

    @Test
    public void coverage() {
        Document document = new Document();
        document.setContents(contents);
        document.setFieldTypeValues(fieldTypeValues);
        document.setReference(reference);

        assertThat(document.getContents(), sameInstance(contents));
        assertThat(document.getFieldTypeValues(), sameInstance(fieldTypeValues));
        assertThat(document.getReference(), sameInstance(reference));
        assertThat(document.getDocumentId(), is(reference.getDocumentId()));
        assertThat(document.getVersion(), is(reference.getVersion()));
    }
}
