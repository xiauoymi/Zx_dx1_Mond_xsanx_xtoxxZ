package com.monsanto.tcc.dcm.transfer;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class FieldValue_UT {
    private static final String NAME = "name";
    private static final String VALUE = "value";

    @Test
    public void coverage() {
        FieldValue fieldValue = new FieldValue();
        fieldValue.setFieldName(NAME);
        fieldValue.setFieldValue(VALUE);

        assertThat(fieldValue.getFieldName(), is(NAME));
        assertThat(fieldValue.getFieldValue(), is(VALUE));

        fieldValue = new FieldValue(NAME, VALUE);

        assertThat(fieldValue.getFieldName(), is(NAME));
        assertThat(fieldValue.getFieldValue(), is(VALUE));
    }
}