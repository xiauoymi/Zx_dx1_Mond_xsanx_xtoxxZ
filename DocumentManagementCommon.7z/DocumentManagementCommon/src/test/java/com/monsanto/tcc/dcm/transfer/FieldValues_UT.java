package com.monsanto.tcc.dcm.transfer;

import static org.hamcrest.CoreMatchers.sameInstance;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import static org.junit.matchers.IsCollectionContaining.hasItem;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class FieldValues_UT {
    private Collection<FieldValue> collection;
    private FieldValue fieldValue;

    @Before
    public void setUp() throws Exception {
        collection = new ArrayList<FieldValue>();
        fieldValue = new FieldValue();
    }

    @Test
    public void coverage() {
        FieldValues fieldValues = new FieldValues();
        fieldValues.setFieldValues(collection);
        assertThat(fieldValues.getFieldValues(), sameInstance(collection));

        fieldValues.addFieldValue(fieldValue);

        assertThat(collection, hasItem(fieldValue));
    }
}