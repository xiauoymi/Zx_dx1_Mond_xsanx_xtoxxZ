package com.monsanto.tcc.dcm.transfer;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class SearchField_UT {
    private static final String NAME = "name";
    private static final String VALUE = "value";
    private static final SearchOperator SEARCH_OPERATOR = SearchOperator.EQUALS;
    private static final String OPERATOR_NAME = SEARCH_OPERATOR.getName();

    @Test
    public void coverage() {
        SearchField searchField = new SearchField();
        searchField.setName(NAME);
        searchField.setOperator(SEARCH_OPERATOR);
        searchField.setOperatorName(OPERATOR_NAME);
        searchField.setValue(VALUE);

        assertThat(searchField.getName(), is(NAME));
        assertThat(searchField.getOperatorName(), is(SEARCH_OPERATOR.getName()));
        assertThat(searchField.getOperator(), is(SEARCH_OPERATOR));
        assertThat(searchField.getValue(), is(VALUE));
    }
}