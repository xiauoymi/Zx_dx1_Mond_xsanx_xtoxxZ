package com.monsanto.tcc.dcm.transfer;

import static org.hamcrest.CoreMatchers.sameInstance;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

import java.util.Collection;
import java.util.Collections;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class SearchFields_UT {
    private Collection<SearchField> collection;

    @Before
    public void setUp() throws Exception {
        collection = Collections.emptyList();
    }

    @Test
    public void coverage() {
        SearchFields searchFields = new SearchFields();
        searchFields.setSearchFields(collection);
        assertThat(searchFields.getSearchFields(), sameInstance(collection));
    }
}