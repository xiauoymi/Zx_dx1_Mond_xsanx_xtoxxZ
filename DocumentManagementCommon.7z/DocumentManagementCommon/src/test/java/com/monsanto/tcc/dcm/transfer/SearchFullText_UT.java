package com.monsanto.tcc.dcm.transfer;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class SearchFullText_UT {
    private static final String SEARCH_TEXT = "search text";
    private static final SearchOperator SEARCH_OPERATOR = SearchOperator.EQUALS;
    private static final String OPERATOR_NAME = SEARCH_OPERATOR.name();

    @Test
    public void coverage() {
        SearchFullText searchFullText = new SearchFullText();
        searchFullText.setSearchText(SEARCH_TEXT);
        searchFullText.setOperator(SEARCH_OPERATOR);
        searchFullText.setOperatorName(OPERATOR_NAME);

        assertThat(searchFullText.getSearchText(), is(SEARCH_TEXT));
        assertThat(searchFullText.getOperatorName(), is(SEARCH_OPERATOR.getName()));
        assertThat(searchFullText.getOperator(), is(SEARCH_OPERATOR));
    }
}