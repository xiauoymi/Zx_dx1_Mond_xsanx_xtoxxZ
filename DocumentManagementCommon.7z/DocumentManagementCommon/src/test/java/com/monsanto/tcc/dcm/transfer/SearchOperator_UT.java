package com.monsanto.tcc.dcm.transfer;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * rlcasw - Jun 11, 2010 2:32:42 PM
 */
public class SearchOperator_UT
{
   @Test
   public void testValueOfName(){
      assertEquals(SearchOperator.EQUALS,SearchOperator.valueOfName(SearchOperator.EQUALS.getName()));
   }
}
