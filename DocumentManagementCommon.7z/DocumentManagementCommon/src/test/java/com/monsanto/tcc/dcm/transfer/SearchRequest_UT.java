package com.monsanto.tcc.dcm.transfer;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class SearchRequest_UT {
    private static final String LOCATION = "location";
    private static final SearchFields SEARCH_FIELDS = new SearchFields();
    private static final SearchFullText SEARCH_FULL_TEXT = new SearchFullText();
    private static final boolean SEARCH_LATEST_VERSION = true;
    private static final ViewFields VIEW_FIELDS = new ViewFields();

    @Test
    public void coverage() {
        SearchRequest searchRequest = new SearchRequest();
        searchRequest.setLocation(LOCATION);
        searchRequest.setSearchFields(SEARCH_FIELDS);
        searchRequest.setSearchFullText(SEARCH_FULL_TEXT);
        searchRequest.setSearchLatestVersion(SEARCH_LATEST_VERSION);
        searchRequest.setViewFields(VIEW_FIELDS);

        assertThat(searchRequest.getLocation(), is(LOCATION));
        assertThat(searchRequest.getSearchFields(), sameInstance(SEARCH_FIELDS));
        assertThat(searchRequest.getSearchFullText(), sameInstance(SEARCH_FULL_TEXT));
        assertThat(searchRequest.isSearchLatestVersion(), is(SEARCH_LATEST_VERSION));
        assertThat(searchRequest.getViewFields(), sameInstance(VIEW_FIELDS));
    }
}