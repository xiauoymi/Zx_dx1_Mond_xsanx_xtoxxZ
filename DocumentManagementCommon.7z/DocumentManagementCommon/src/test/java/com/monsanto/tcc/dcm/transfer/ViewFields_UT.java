package com.monsanto.tcc.dcm.transfer;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

import java.util.Collection;
import java.util.Collections;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class ViewFields_UT {
    private Collection<ViewField> collection;
    private static final Boolean RETURN_ALL = Boolean.TRUE;

    @Before
    public void setUp() throws Exception {
        collection = Collections.emptyList();
    }

    @Test
    public void coverage() {
        ViewFields viewFields = new ViewFields();
        viewFields.setViewFields(collection);
        viewFields.setReturnAll(RETURN_ALL);

        assertThat(viewFields.getViewFields(), sameInstance(collection));
        assertThat(viewFields.isReturnAll(), is(RETURN_ALL));
    }
}