package com.monsanto.tcc.dcm;

import com.monsanto.tps.aop.metric.ApplicationInformation;

/**
 * rlcasw - May 28, 2010 2:34:12 PM
 */
public class DocumentContentManagementAppInformationImpl implements ApplicationInformation
{
   private final String name;
   private final String version;

   public DocumentContentManagementAppInformationImpl(String name, String version){
      this.name=name;
      this.version=version;
   }

   public String getVersion() {
      return version;
   }

   
   public String getName() {
      return name;
   }

}
