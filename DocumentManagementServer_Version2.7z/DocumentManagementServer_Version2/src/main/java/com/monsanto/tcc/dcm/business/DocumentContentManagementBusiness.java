package com.monsanto.tcc.dcm.business;

import com.monsanto.tcc.dcm.exception.FatalException;
import com.monsanto.tcc.dcm.exception.RequestException;
import com.monsanto.tcc.dcm.transfer.Document;
import com.monsanto.tcc.dcm.transfer.DocumentContent;
import com.monsanto.tcc.dcm.transfer.DocumentDetail;
import com.monsanto.tcc.dcm.transfer.FieldValues;
import com.monsanto.tcc.dcm.transfer.Reference;
import com.monsanto.tcc.dcm.transfer.SearchRequest;
import com.monsanto.tcc.dcm.transfer.SearchResult;
import com.monsanto.tcc.dcm.transfer.ViewFields;

import javax.activation.DataHandler;
import java.util.Collection;

/**
 * rlcasw - May 26, 2010 10:55:01 AM
 */
public interface DocumentContentManagementBusiness
{
      public Reference create(String location, boolean versioningEnabled, DataHandler contents, FieldValues fieldValues) throws RequestException, FatalException;
      public Collection<Document> retrieve(Collection<Reference> references, ViewFields viewFields)throws RequestException, FatalException;
      public void delete(Reference reference) throws RequestException ;
      void deleteLatest(String documentId) throws RequestException, FatalException;   
      public void deleteAll(String documentId) throws RequestException, FatalException;
      public DocumentContent retrieveContent(Reference reference) throws RequestException ;
      public Collection<DocumentDetail> retrieveDetails(Collection<Reference> references, ViewFields viewFields)throws RequestException ;
      public SearchResult search(SearchRequest searchRequest) throws RequestException;
      public Reference update( Reference reference,
                      DataHandler dataHandler,
                     FieldValues fieldValues) throws RequestException, FatalException;
      public Reference update(String documentId,
                           boolean majorVersion,
                           DataHandler contents,
                           FieldValues fieldValues) throws RequestException;

}
