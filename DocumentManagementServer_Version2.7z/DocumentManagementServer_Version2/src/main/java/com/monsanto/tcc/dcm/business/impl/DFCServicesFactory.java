package com.monsanto.tcc.dcm.business.impl;

import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.DFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;

public class DFCServicesFactory
{
   private final ServiceLookup serviceLookup;

   public DFCServicesFactory(ServiceLookup serviceLookup) {
      this.serviceLookup=serviceLookup;
   }

   public  IDFCServices buildDFCServices(String folder)
      throws ServiceConfigException, EncryptorException, AttributeListParseException
   {
      ConnectionInfo connectionInfo = getConnectionInfo(folder);
      return new DFCServices(connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_DOCBROKER),
         connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_USERNAME),
         connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_PASSWORD),
         connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_DOCBASE),
         connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_CABINET),
         connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_OBJECT_TYPE));
   }

   public ConnectionInfo getConnectionInfo(String folder)
      throws ServiceConfigException, EncryptorException
   {
      ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails(folder, System.getProperty("lsi.function"));
      return connectionInfo;
   }
}