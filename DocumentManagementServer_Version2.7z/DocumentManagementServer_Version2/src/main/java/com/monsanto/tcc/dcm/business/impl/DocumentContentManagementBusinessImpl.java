package com.monsanto.tcc.dcm.business.impl;

import com.documentum.fc.client.DfServiceCriticalException;
import com.monsanto.tcc.dcm.business.DocumentContentManagementBusiness;
import com.monsanto.tcc.dcm.exception.FatalException;
import com.monsanto.tcc.dcm.exception.NotFoundException;
import com.monsanto.tcc.dcm.exception.RequestException;
import com.monsanto.tcc.dcm.transfer.DocumentContent;
import com.monsanto.tcc.dcm.transfer.DocumentDetail;
import com.monsanto.tcc.dcm.transfer.FieldTypeValue;
import com.monsanto.tcc.dcm.transfer.FieldTypeValues;
import com.monsanto.tcc.dcm.transfer.FieldValue;
import com.monsanto.tcc.dcm.transfer.FieldValues;
import com.monsanto.tcc.dcm.transfer.Reference;
import com.monsanto.tcc.dcm.transfer.SearchField;
import com.monsanto.tcc.dcm.transfer.SearchRequest;
import com.monsanto.tcc.dcm.transfer.SearchResult;
import com.monsanto.tcc.dcm.transfer.ViewField;
import com.monsanto.tcc.dcm.transfer.ViewFields;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.ISharePointServices;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.queryBuilder.SharePointQueryBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointAttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.entity.DeleteSharePointResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.entity.InsertSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity.SearchSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity.SearchSharePointResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updateSharePointDoc.entity.UpdateSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.deleteDocumentumDocs.entity.DeleteDocumentumResponseEntity;
//import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.DocumentumQueryBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumRequestEntity;
import com.monsanto.Util.StringUtils;
import org.apache.cxf.jaxrs.ext.multipart.InputStreamDataSource;
import org.apache.log4j.Logger;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * rlcasw - May 26, 2010 2:37:44 PM
 */

public class DocumentContentManagementBusinessImpl implements DocumentContentManagementBusiness
{
   public static final String DOES_NOT_EXIST = "does not exist";
   private final Logger log = Logger.getLogger(this.getClass());
   
   private DFCServicesFactory dfcServicesFactory;
   private DocumentumQueryBuilder documentumQueryBuilder;
   

   /* by Vishal */
   private SPServicesFactory spServicesFactory;
   private SharePointQueryBuilder sharepointQueryBuilder;

   public static List transformationList = new SharePointAttributeTransformer().getTransformationList();
    
   public static final String VERSION_MISSING_ON_DELETE = "Version Missing on delete";

   public DocumentContentManagementBusinessImpl(DFCServicesFactory dfcServicesFactory,DocumentumQueryBuilder documentumQueryBuilder){
      this.dfcServicesFactory=dfcServicesFactory;
      this.documentumQueryBuilder=documentumQueryBuilder;
   }

    /* by Vishal */
    public DocumentContentManagementBusinessImpl(SPServicesFactory spServicesFactory,SharePointQueryBuilder sharepointQueryBuilder){
      this.spServicesFactory=spServicesFactory;
      this.sharepointQueryBuilder=sharepointQueryBuilder;
   }

    public Reference create(String location, boolean versioningEnabled, DataHandler contents, FieldValues fieldValues)
      throws RequestException, FatalException
   {

      System.out.println("Inside create");
      File tmpFile = null;

      DocumentLocation documentLocation = parseDocumentLocation(location);
      ISharePointServices service = connectToService(documentLocation.getFolder());
      try {
          InsertSharePointRequestEntity insertSPRequestEntity = buildInsertSharePointRequestEntity(fieldValues, documentLocation);
         tmpFile = copyToFile(contents,documentLocation.getFilename());
         RetrievedDocument retrievedDocument = service.saveDocument(insertSPRequestEntity, documentLocation.getDirectoryStructure(), tmpFile.getPath());
         return buildReferenceFromDocumentAttributes(documentLocation.getFolder(),retrievedDocument);
      }
      catch (Throwable t) {
         throw  handleException(service, t);
      }
      finally {
         closeService(service);
         deleteTmpFile(tmpFile);
      }
   }

   /* Documentum Create */
   /*
   public Reference create(String location, boolean versioningEnabled, DataHandler contents, FieldValues fieldValues)
      throws RequestException, FatalException
   {


      File tmpFile = null;

      DocumentLocation documentLocation = parseDocumentLocation(location);
      IDFCServices service = connectToService(documentLocation.getFolder());
      try {
         service.beginTransaction();
         InsertDocumentumRequestEntity insertDctmRequestEntity = buildInsertDocumentumRequestEntity(fieldValues, documentLocation);

         tmpFile = copyToFile(contents,documentLocation.getFilename());
         RetrievedDocument retrievedDocument = service.saveDocument(insertDctmRequestEntity, documentLocation.getDirectoryStructure(), tmpFile.getPath());
         service.commitTransaction();
         return buildReferenceFromDocumentAttributes(documentLocation.getFolder(),retrievedDocument);
      }
      catch (Throwable t) {
         throw  handleException(service, t);
      }
      finally {
         closeService(service);
         deleteTmpFile(tmpFile);
      }
   }
   */
   private DocumentLocation parseDocumentLocation(String location) {
      DocumentLocation documentLocation = new DocumentLocation();
      try{
         documentLocation.setFolder(parseFolder(location));
         documentLocation.setFilename(parseFileName(location));
         documentLocation.setDirectoryStructure(parseDirectoryStructure(location));
      }
      catch (Throwable t){
         log.error(t.getMessage(),t);
         throw new RequestException(t.getMessage(),t);
      }
      return documentLocation;
   }

   /*private FatalException handleException(IDFCServices service, Throwable t) throws RequestException {
      log.error(t.getMessage(),t);
      rollbackTransaction(service);
      return new  FatalException(t.getMessage(),t);
   } */
   private FatalException handleException(ISharePointServices service, Throwable t) throws RequestException {
       log.error(t.getMessage(),t);
       //rollbackTransaction(service);
       return new  FatalException(t.getMessage(),t);
    }

   private Reference buildReference(String folder, String objectId, String version) {
      return buildReference(folder + "/" + objectId, version);
   }

    /*
   private InsertDocumentumRequestEntity buildInsertDocumentumRequestEntity(FieldValues fieldValues,DocumentLocation documentLocation) {
      InsertDocumentumRequestEntity insertDctmRequestEntity = new InsertDocumentumRequestEntity();
      insertDctmRequestEntity.setFolderName(documentLocation.getFolder());
      insertDctmRequestEntity.setDirectoryStructure(documentLocation.getDirectoryStructure());
      insertDctmRequestEntity.setRequestPDFRendition(documentLocation.getFilename().endsWith(".pdf"));
      insertDctmRequestEntity.setSearchAllVersions(false);

      DocumentAttributes documentAttributes = insertDctmRequestEntity.getDocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_NAME,documentLocation.getFilename(),DocumentManagerConstants.OPERATOR_EQUALS);
      populateAttributes(fieldValues, documentAttributes);
      return insertDctmRequestEntity;
   }*/
   private InsertSharePointRequestEntity buildInsertSharePointRequestEntity(FieldValues fieldValues,DocumentLocation documentLocation) {
      InsertSharePointRequestEntity insertSPRequestEntity = new InsertSharePointRequestEntity();
      insertSPRequestEntity.setFolderName(documentLocation.getFolder());
      insertSPRequestEntity.setDirectoryStructure(documentLocation.getDirectoryStructure());
      insertSPRequestEntity.setRequestPDFRendition(documentLocation.getFilename().endsWith(".pdf"));
      insertSPRequestEntity.setSearchAllVersions(false);

      DocumentAttributes documentAttributes = insertSPRequestEntity.getDocumentAttributes();
      // use DCTM_ATTR_STR_NAME becasue saveDocument needs that. Pl. change it when you have time.
      documentAttributes.addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_NAME,documentLocation.getFilename(),DocumentManagerConstants.OPERATOR_EQUALS);
      populateAttributes(fieldValues, documentAttributes);
      return insertSPRequestEntity;
   }
   private void populateAttributes(FieldValues fieldValues, DocumentAttributes documentAttributes) {
      if((fieldValues!=null)&&(fieldValues.getFieldValues()!=null)){
            for(FieldValue fieldValue: fieldValues.getFieldValues()){
            documentAttributes.addAttribute(fieldValue.getFieldName(),fieldValue.getFieldValue(), DocumentManagerConstants.OPERATOR_EQUALS);
         }
      }
   }

   private String parseDirectoryStructureNoFilenameInArg(String location) {
      String[] locationParts = location.split("/");
      int partsIndex = locateBeginningOfDirectoryStructure(locationParts);
      int pathlength = locationParts.length ;
      return buildDirectoryStructure(partsIndex, locationParts, pathlength);
   }

   private int locateBeginningOfDirectoryStructure(String[] locationParts) {
      int partsIndex = 0;
      if (locationParts[partsIndex].isEmpty()) {
         partsIndex++;
      }
      partsIndex++;
      return partsIndex;
   }

   private String parseDirectoryStructure(String location) {
      String[] locationParts = location.split("/");
      int partsIndex = locateBeginningOfDirectoryStructure(locationParts);
      int pathlength = locationParts.length - 1;
      return buildDirectoryStructure(partsIndex, locationParts, pathlength);
   }

   private String buildDirectoryStructure(int partsIndex, String[] locationParts, int pathlength) {
      StringBuilder directoryStructure = new StringBuilder("");
      while (partsIndex < pathlength) {
         directoryStructure.append(locationParts[partsIndex]);
         partsIndex++;
         if (partsIndex < pathlength) {
            directoryStructure.append("/");
         }
      }
      return directoryStructure.toString();
   }

   private String parseFileName(String location) {
      String[] locationParts = location.split("/");
      return locationParts[locationParts.length - 1];
   }

   private String parseFolder(String location) {
      String[] locationParts = location.split("/");
      int partsIndex = 0;
      String documentumFolder = "";
      if (locationParts.length > partsIndex) {
         if (locationParts[partsIndex].isEmpty()) {
            partsIndex++;
         }
         if (locationParts.length > partsIndex) {
            documentumFolder = locationParts[partsIndex++];
         }
      }
      return documentumFolder;
   }   
   private File copyToFile(DataHandler contents, String name)
      throws IOException
   {
      InputStream inputStream = contents.getInputStream();
      int bytesRead;
      int nameLength = name.length();
      File file = File.createTempFile("dcms", "." + name.substring(nameLength - 3));
      FileOutputStream outputStream = new FileOutputStream(file);
      byte[] buffer = new byte[100];
      while ((bytesRead = inputStream.read(buffer)) != -1) {
         outputStream.write(buffer, 0, bytesRead);
      }
      inputStream.close();
      outputStream.flush();
      outputStream.close();
      return file;
   }

  /*
    public void deleteAll(String documentId)
        throws RequestException, FatalException
     {

        DocumentId docId = parseDocumentId(documentId);
        IDFCServices service = connectToService(docId.getFolder());
        try{
           service.beginTransaction();
           service.deleteAllVersionsById(docId.getObjectId());
           service.commitTransaction();
           return ;
        }
        catch (Throwable t) {
           Reference reference = new Reference();
           reference.setDocumentId(documentId);
           throw handleException(reference, service, t);
        }
        finally{
           closeService(service);
        }
     }
   */

   public void deleteAll(String documentId)
      throws RequestException, FatalException
   {

      DocumentId docId = parseDocumentId(documentId);
      ISharePointServices service = connectToService(docId.getFolder());
      try{
         service.deleteAllVersionsById(docId.getObjectId());
         return ;
      }
      catch (Throwable t) {
         Reference reference = new Reference();
         reference.setDocumentId(documentId);
         throw handleException(reference, service, t);
      }
      finally{
         closeService(service);
      }
   }

   /*private void closeService(IDFCServices service) {
      if(service!=null){
            try{
               service.close();
            }
            catch (Throwable t){
            log.error(t.getMessage(),t);
         }
      }
   }*/
   private void closeService(ISharePointServices service) {
      if(service!=null){
            try{
               return; // Nothing to close when it is Sharepoint service
            }
            catch (Throwable t){
            log.error(t.getMessage(),t);
         }
      }
   }
   /*
   public void delete(Reference reference) throws RequestException {


      if(StringUtils.isNullOrEmpty(reference.getVersion())){
         throw new RequestException(VERSION_MISSING_ON_DELETE);
      }


      DocumentId documentId = parseDocumentId(reference);
      IDFCServices service = connectToService(documentId.getFolder());
      try{
         service.beginTransaction();
         DocumentAttributes documentAttributes = new DocumentAttributes();
         ResponseEntity responseEntity = new DeleteDocumentumResponseEntity();
         documentAttributes.addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_VERSION,reference.getVersion(),DocumentManagerConstants.OPERATOR_EQUALS);
         service.delete(documentId.getObjectId(),documentAttributes,responseEntity);
         service.commitTransaction();
         return ;
      }
      catch (Throwable t) {
         throw handleException(reference, service, t);
      }
      finally{
         closeService(service);
      }
   }*/
    public void delete(Reference reference) throws RequestException {
      if(StringUtils.isNullOrEmpty(reference.getVersion())){
         throw new RequestException(VERSION_MISSING_ON_DELETE);
      }
      DocumentId documentId = parseDocumentId(reference);
      ISharePointServices service = connectToService(documentId.getFolder());
      try{
         DocumentAttributes documentAttributes = new DocumentAttributes();
         ResponseEntity responseEntity = new DeleteSharePointResponseEntity();
         documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,reference.getVersion(),DocumentManagerConstants.OPERATOR_EQUALS);
         // Vishal : Delete Latest version is not supported by sharepoint. Everybody knows that but nobody mentioned during design. Oops ! we didnt have design.
         // Call service.deleteAll here and dont use document attribute list or do some trick 1. restore previous version 2. delete second version 3. some how update latest verion number
         service.delete(documentId.getObjectId(),documentAttributes,responseEntity);
         return ;
      }
      catch (Throwable t) {
         throw handleException(reference, service, t);
      }
      finally{
         closeService(service);
      }
   }
   private DocumentId parseDocumentId(Reference reference) {

      return parseDocumentId(reference.getDocumentId());
   }

   private DocumentId parseDocumentId(String documentId) {
      DocumentId docId = new DocumentId();
      try{
         int slashIndex = documentId.lastIndexOf("/"); 
         docId.setFolder(documentId.substring(0,slashIndex));
         docId.setObjectId(documentId.substring(slashIndex+1));

      }
      catch (Throwable t){
         log.error(t.getMessage(),t);
         throw new RequestException(t.getMessage(),t);
      }
      return docId;
   }
     private RuntimeException handleException(Reference reference, ISharePointServices service, Throwable t) {
      log.error(t.getMessage(),t);
      String message = t.getMessage();
      if (message != null && (message.endsWith(DOES_NOT_EXIST))) {
         throw new NotFoundException(reference);
      }
      throw new FatalException(t.getMessage(),t);
   }
   /*
   private RuntimeException handleException(Reference reference, IDFCServices service, Throwable t) {
      log.error(t.getMessage(),t);
      rollbackTransaction(service);
      String message = t.getMessage();
      if (message != null && (message.endsWith(DOES_NOT_EXIST))) {
         throw new NotFoundException(reference);
      }
      throw new FatalException(t.getMessage(),t);
   } */

    /*
   private void rollbackTransaction(IDFCServices service) {
      try {
         if(service!=null){
              service.rollbackTransaction();
         }
      }
      catch (DfServiceCriticalException e){
         //Ignore this, we are in an unknown state at this point and the causing exception has already been logged.
      }
      catch (DocumentManagerException e) {
         //Ignore this, we are in an unknown state at this point and the causing exception has already been logged.
      }
   }  */


   public Collection<com.monsanto.tcc.dcm.transfer.Document> retrieve(Collection<Reference> references,
                                                                  ViewFields viewFields)
   {
      List<com.monsanto.tcc.dcm.transfer.Document> documents = new ArrayList<com.monsanto.tcc.dcm.transfer.Document>(references.size());
      for (Reference reference : references) {
         documents.add(retrieve(reference, viewFields));
      }
      return documents;
   }
  /*
   private com.monsanto.tcc.dcm.transfer.Document retrieve(Reference reference,
                                                       ViewFields viewFields)
   {


      DocumentId documentId  = parseDocumentId(reference);
      IDFCServices service = connectToService(documentId.getFolder());
      try {
         RetrievedDocument retrievedDocument = retrieveDocument(reference, viewFields, documentId, service);

         FieldTypeValues fieldTypeValues = buildFieldTypeValues(viewFields, retrievedDocument);
         DataHandler contents = buildDataHandler( retrievedDocument);

         Reference returnedReference = buildReferenceFromDocumentAttributes(reference, retrievedDocument);

         return  buildDocument(fieldTypeValues, contents, returnedReference);
      }
      catch (Throwable t) {
         throw handleException(reference, service, t);
      }
      finally {
         closeService(service);
      }

   }*/
   private com.monsanto.tcc.dcm.transfer.Document retrieve(Reference reference,
                                                       ViewFields viewFields)
   {


      DocumentId documentId  = parseDocumentId(reference);
      ISharePointServices service = connectToService(documentId.getFolder());
      try {
         RetrievedDocument retrievedDocument = retrieveDocument(reference, viewFields, documentId, service);

         FieldTypeValues fieldTypeValues = buildFieldTypeValues(viewFields, retrievedDocument);
         DataHandler contents = buildDataHandler( retrievedDocument);

         Reference returnedReference = buildReferenceFromDocumentAttributes(reference, retrievedDocument);

         return  buildDocument(fieldTypeValues, contents, returnedReference);
      }
      catch (Throwable t) {
         throw handleException(reference, service, t);
      }
      finally {
         closeService(service);
      }

   }
   private Reference buildReferenceFromDocumentAttributes(Reference reference, RetrievedDocument retrievedDocument)
      throws AttributeListParseException
   {
      String version = retrievedDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_VERSION);
      return  buildReference(reference.getDocumentId(), version);
   }

   private com.monsanto.tcc.dcm.transfer.Document buildDocument(FieldTypeValues fieldTypeValues, DataHandler contents, Reference returnedReference) {
      com.monsanto.tcc.dcm.transfer.Document content = new com.monsanto.tcc.dcm.transfer.Document();
      content.setReference(returnedReference);
      content.setContents(contents);
      content.setFieldTypeValues(fieldTypeValues);
      return content;
   }

   private FieldTypeValues buildFieldTypeValues(ViewFields viewFields, RetrievedDocument retrievedDocument)
      throws AttributeListParseException
   {
      FieldTypeValues fieldTypeValues = new FieldTypeValues();
      List<FieldTypeValue> fieldTypeValuesCollection = new ArrayList<FieldTypeValue>();
      if((viewFields!=null)&&(viewFields.getViewFields()!=null)){
            for(ViewField viewField: viewFields.getViewFields()){
            FieldTypeValue value = new FieldTypeValue();
            value.setName(viewField.getName());
            value.setValue(retrievedDocument.getDocumentAttributes().getAttrValue(viewField.getName()));
            fieldTypeValuesCollection.add(value);
         }
      }
      fieldTypeValues.setFieldTypeValues(fieldTypeValuesCollection);
      return fieldTypeValues;
   }

   private DocumentAttributes buildDocumentAttributes(Reference reference, String objectId) {
      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID ,objectId,DocumentManagerConstants.OPERATOR_EQUALS);
      if(!StringUtils.isNullOrEmpty(reference.getVersion())){
            documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,
                                            reference.getVersion(),
                                            DocumentManagerConstants.OPERATOR_EQUALS);
         }
      return documentAttributes;
   }


   public DocumentContent retrieveContent(Reference reference) {
      com.monsanto.tcc.dcm.transfer.Document document = retrieve(reference, new ViewFields());
      DocumentContent content = new DocumentContent();
      content.setReference(document.getReference());
      content.setContents(document.getContents());
      return content;
   }



   public Collection<DocumentDetail> retrieveDetails(Collection<Reference> references, ViewFields viewFields) {
      List<DocumentDetail> documentDetails = new ArrayList<DocumentDetail>(references.size());
      for (Reference reference : references) {
         documentDetails.add(retrieveDetails(reference, viewFields));
      }
      return documentDetails;
   }

  /*
  private DocumentDetail retrieveDetails(Reference reference, ViewFields viewFields) {

      DocumentId documentId =  parseDocumentId(reference);
      IDFCServices service =  connectToService(documentId.getFolder());
      try {
         RetrievedDocument retrievedDocument = retrieveDocument(reference, viewFields, documentId, service);

         String fileLocation = retrievedDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_CONTENTS);
         deleteTmpFile(fileLocation);

         FieldTypeValues fieldTypeValues = buildFieldTypeValues(viewFields, retrievedDocument);

         Reference returnedReference = buildReferenceFromDocumentAttributes(reference, retrievedDocument);

         DocumentDetail documentDetail = new DocumentDetail();
         documentDetail.setFieldTypeValues(fieldTypeValues);
         documentDetail.setReference(returnedReference);

         return documentDetail;
      }
      catch (Throwable t) {
         throw handleException(reference, service, t);
      }
      finally {
         closeService(service);
      }
   }*/

    private DocumentDetail retrieveDetails(Reference reference, ViewFields viewFields) {

      DocumentId documentId =  parseDocumentId(reference);
      ISharePointServices service =  connectToService(documentId.getFolder());
      try {
         RetrievedDocument retrievedDocument = retrieveDocument(reference, viewFields, documentId, service);

         String fileLocation = retrievedDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_CONTENTS);
         deleteTmpFile(fileLocation);

         FieldTypeValues fieldTypeValues = buildFieldTypeValues(viewFields, retrievedDocument);

         Reference returnedReference = buildReferenceFromDocumentAttributes(reference, retrievedDocument);

         DocumentDetail documentDetail = new DocumentDetail();
         documentDetail.setFieldTypeValues(fieldTypeValues);
         documentDetail.setReference(returnedReference);

         return documentDetail;
      }
      catch (Throwable t) {
         throw handleException(reference, service, t);
      }
      finally {
         closeService(service);
      }
   }

/*   private RetrievedDocument retrieveDocument(Reference reference, ViewFields viewFields, DocumentId documentId, IDFCServices service)
      throws AttributeListParseException, DocumentManagerException
   {
      DocumentAttributes documentAttributes = buildDocumentAttributes(reference, documentId.getObjectId());
      List<String> requiredAttributes = buildRequiredAttributes(viewFields);
      return  service.retrieveDocumentObjectWithAttributes(documentAttributes,requiredAttributes);
   }
  */
    private RetrievedDocument retrieveDocument(Reference reference, ViewFields viewFields, DocumentId documentId, ISharePointServices service)
      throws AttributeListParseException, DocumentManagerException
   {
      DocumentAttributes documentAttributes = buildDocumentAttributes(reference, documentId.getObjectId());
      List<String> requiredAttributes = buildRequiredAttributes(viewFields);
      return  service.retrieveDocumentObjectWithAttributes(documentAttributes,requiredAttributes);
   }

    private ISharePointServices connectToService(String folder) {
       try{
          ISharePointServices service = spServicesFactory.buildSPServices(folder);
          return service;
       }
       catch(Throwable t){
          log.error(t.getMessage(),t);
          throw new FatalException(t.getMessage(),t);
       }
    }

   /*
   private IDFCServices connectToService(String folder) {
      try{
         IDFCServices service = dfcServicesFactory.buildDFCServices(folder);
         service.connect();
         return service;
      }
      catch(Throwable t){
         log.error(t.getMessage(),t);
         throw new FatalException(t.getMessage(),t);
      }
   }
   */

   private void deleteTmpFile(String fileLocation) {
      if(fileLocation!=null){
         File file = new File(fileLocation);
         deleteTmpFile(file);
      }
   }

   private Reference buildReference(String documentId, String version) {
      Reference returnedReference = new Reference();
      returnedReference.setDocumentId(documentId);
      returnedReference.setVersion(version);
      return returnedReference;
   }

   private DataHandler buildDataHandler(RetrievedDocument retrievedDocument)
      throws AttributeListParseException, IOException
   {
      String fileLocation = retrievedDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_CONTENTS);
      File file = new File(fileLocation);
      DataSource dataSource = new InputStreamDataSource(new TemporaryFileInputStream(file),"application/octet-stream");
      return new DataHandler(dataSource);
   }

   private List<String> buildRequiredAttributes(ViewFields viewFields) {
      List <String> requiredAttributes = new ArrayList<String>();
      if((viewFields!=null)&&(viewFields.getViewFields()!=null)){
            for(ViewField viewField: viewFields.getViewFields()){
            requiredAttributes.add(viewField.getName());
         }
      }
      return requiredAttributes;
   }


 /*
   public SearchResult search(SearchRequest searchRequest)
      throws RequestException
   {


      ConnectionInfo connectionInfo = null;
      DocumentLocation location = parseLocation(searchRequest);
      IDFCServices service =  connectToService(location.getFolder());
      try {
         connectionInfo =  dfcServicesFactory.getConnectionInfo(location.getFolder());
         SearchDocumentumRequestEntity searchDocumentumRequestEntity = buildSearchDocumentumRequestEntity(searchRequest, location.getFolder(),location.getDirectoryStructure(), connectionInfo);


        if(isViewFieldsPopulated(searchRequest)){
              for(ViewField viewField: searchRequest.getViewFields().getViewFields()){
                   searchDocumentumRequestEntity.getRequiredAttributes().add(viewField.getName());
              }
        }
         SearchDocumentumResponseEntity responseEntity  = new SearchDocumentumResponseEntity();
         String  queryString = documentumQueryBuilder.buildSearchQueryForDocumentId(searchDocumentumRequestEntity, service);
         System.out.println("****************Search Query Passed******************");
         System.out.println(queryString);
         System.out.println("****************Search Query Ends******************");

         service.search(queryString,searchDocumentumRequestEntity,responseEntity);
         List<RetrievedDocument> retrievedDocuments = (List<RetrievedDocument>)responseEntity.getRetrievedDocumentList();

         return buildSearchResult(searchRequest, location.getFolder(), retrievedDocuments);
      }
      catch (Throwable t) {
         throw handleException(service, t);
      }
      finally {
         closeService(service);
      }
   }*/

    public SearchResult search(SearchRequest searchRequest)
      throws RequestException
   {


      ConnectionInfo connectionInfo = null;
      DocumentLocation location = parseLocation(searchRequest);
      ISharePointServices service =  connectToService(location.getFolder());
      try {
         connectionInfo =  spServicesFactory.getConnectionInfo(location.getFolder());
         SearchSharePointRequestEntity searchSPRequestEntity = buildSearchSharePointRequestEntity(searchRequest, location.getFolder(),location.getDirectoryStructure(), connectionInfo);


        if(isViewFieldsPopulated(searchRequest)){
              for(ViewField viewField: searchRequest.getViewFields().getViewFields()){
                   searchSPRequestEntity.getRequiredAttributes().add(viewField.getName());
              }
        }
         SearchSharePointResponseEntity responseEntity  = new SearchSharePointResponseEntity();
         String  queryString = sharepointQueryBuilder.buildSearchQueryForDocumentId(searchSPRequestEntity, service);
         System.out.println("****************Search Query Passed******************");
         System.out.println(queryString);
         System.out.println("****************Search Query Ends******************");

         service.search(queryString,searchSPRequestEntity,responseEntity);
         List<RetrievedDocument> retrievedDocuments = (List<RetrievedDocument>)responseEntity.getRetrievedDocumentList();

         return buildSearchResult(searchRequest, location.getFolder(), retrievedDocuments);
      }
      catch (Throwable t) {
         throw handleException(service, t);
      }
      finally {
         closeService(service);
      }
   }

   private DocumentLocation parseLocation(SearchRequest searchRequest) {
      DocumentLocation documentLocation = new DocumentLocation();
      try{
         String location = searchRequest.getLocation();
         documentLocation.setFolder(parseFolder(location));
         documentLocation.setDirectoryStructure(parseDirectoryStructureNoFilenameInArg(location));
      }
      catch (Throwable t){
         log.error(t.getMessage(),t);
         throw new RequestException(t.getMessage(),t);
      }
      return documentLocation;
   }

   /*private SearchDocumentumRequestEntity buildSearchDocumentumRequestEntity(SearchRequest searchRequest, String folder, String directoryStructure, ConnectionInfo connectionInfo) {
      SearchDocumentumRequestEntity searchDocumentumRequestEntity1 = new SearchDocumentumRequestEntity();
      searchDocumentumRequestEntity1.setFolderName(folder);
      searchDocumentumRequestEntity1.setDirectoryStructure(directoryStructure);
      searchDocumentumRequestEntity1.setSearchAllVersions(!searchRequest.isSearchLatestVersion());
      searchDocumentumRequestEntity1.setConnectionInfo(connectionInfo);
      if((searchRequest.getSearchFullText()!=null)&&
             !StringUtils.isNullOrEmpty(searchRequest.getSearchFullText().getSearchText())){
             searchDocumentumRequestEntity1.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_FULL_TEXT,
                                                                               searchRequest.getSearchFullText().getSearchText(),
                                                                               DocumentManagerConstants.OPERATOR_EQUALS);
         }

      if((searchRequest.getSearchFields()!=null)&&(searchRequest.getSearchFields().getSearchFields()!=null)){
            for(SearchField searchField: searchRequest.getSearchFields().getSearchFields()){
         searchDocumentumRequestEntity1.getDocumentAttributes().addAttribute(searchField.getName(),
                                                                           searchField.getValue(),
                                                                           DocumentManagerConstants.OPERATOR_EQUALS);

      }
   }
      return searchDocumentumRequestEntity1;
   } */

    private SearchSharePointRequestEntity buildSearchSharePointRequestEntity(SearchRequest searchRequest, String folder, String directoryStructure, ConnectionInfo connectionInfo) throws DocumentManagerException, AttributeListParseException {
      SearchSharePointRequestEntity searchSPRequestEntity = new SearchSharePointRequestEntity();
      searchSPRequestEntity.setFolderName(folder);
      searchSPRequestEntity.setDirectoryStructure(directoryStructure);
      searchSPRequestEntity.setSearchAllVersions(!searchRequest.isSearchLatestVersion());
      searchSPRequestEntity.setConnectionInfo(connectionInfo);
      String searchFieldName = null;
      String searchFieldValue = null;

      if((searchRequest.getSearchFullText()!=null)&&
             !StringUtils.isNullOrEmpty(searchRequest.getSearchFullText().getSearchText())){
             searchSPRequestEntity.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_FULL_TEXT,
                                                                               searchRequest.getSearchFullText().getSearchText(),
                                                                               DocumentManagerConstants.OPERATOR_EQUALS);
         }



      if((searchRequest.getSearchFields()!=null)&&(searchRequest.getSearchFields().getSearchFields()!=null)){
            for(SearchField searchField: searchRequest.getSearchFields().getSearchFields()){
            searchFieldName = searchField.getName();
            searchFieldValue = searchField.getValue();

            /*if (searchFieldName.equalsIgnoreCase(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID))
                 searchFieldName = DocumentManagerConstants.SHAREPOINT_ATTR_ID;
            else if (searchFieldName.equalsIgnoreCase(DocumentManagerConstants.ATTR_STR_NAME))
                 searchFieldName = DocumentManagerConstants.SHAREPOINT_ATTR_STR_OBJNAME;
            */
         searchSPRequestEntity.getDocumentAttributes().addAttribute(searchFieldName,
                                                                           searchFieldValue,
                                                                           DocumentManagerConstants.OPERATOR_EQUALS);

      }
   }
      //searchSPRequestEntity.transformAttrNamesToServiceSpecificAttrNames(transformationList);
      return searchSPRequestEntity;
   }

   private SearchResult buildSearchResult(SearchRequest searchRequest, String folder, List<RetrievedDocument> retrievedDocuments)
      throws AttributeListParseException
   {
      SearchResult searchResult = new SearchResult();
      List<DocumentDetail>  documentDetails = new ArrayList<DocumentDetail>();
      for(RetrievedDocument retrieveDocument: retrievedDocuments){
         DocumentDetail documentDetail = new DocumentDetail();
         documentDetail.setReference(buildReference(folder, retrieveDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID), retrieveDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_VERSION)));
         documentDetail.setFieldTypeValues(buildFieldTypeValues(searchRequest.getViewFields(), retrieveDocument));
         documentDetails.add(documentDetail);
      }
      searchResult.setDocumentDetails(documentDetails);
      return searchResult;
   }

   private boolean isViewFieldsPopulated(SearchRequest searchRequest) {
      return (searchRequest.getViewFields()!=null)&&(searchRequest.getViewFields().getViewFields()!=null);
   }
   /*
   public Reference update(String documentId,
                           boolean majorVersion,
                           DataHandler contents,
                           FieldValues fieldValues) throws RequestException
   {
      String filename = null;


      DocumentId docId = parseDocumentId(documentId);
      filename = retrieveFileNameForDocument(documentId);
      IDFCServices service = connectToService(docId.getFolder());
      File tmpFile = null;
      try {

         UpdateDocumentumRequestEntity updateDctmRequestEntity = buildUpdateDocumentumRequestEntity(majorVersion, fieldValues, filename, docId.getFolder(),docId.getObjectId());
         tmpFile = copyToFile(contents,filename);
         RetrievedDocument retrievedDocument = service.update(updateDctmRequestEntity,  tmpFile.getPath());
         return buildReferenceFromDocumentAttributes(docId.getFolder(), retrievedDocument);
      }
      catch (Throwable t) {
         Reference reference = new Reference();
         reference.setDocumentId(documentId);
         throw handleException(reference,service, t);
      }
      finally {
         deleteTmpFile(tmpFile);
         closeService(service);
      }      
   }*/

    public Reference update(String documentId,
                           boolean majorVersion,
                           DataHandler contents,
                           FieldValues fieldValues) throws RequestException
   {
      String filename = null;


      DocumentId docId = parseDocumentId(documentId);
      filename = retrieveFileNameForDocument(documentId);
      ISharePointServices service = connectToService(docId.getFolder());
      File tmpFile = null;
      try {

         UpdateSharePointRequestEntity updateSPRequestEntity = buildUpdateSharePointRequestEntity(majorVersion, fieldValues, filename, docId.getFolder(),docId.getObjectId());
         tmpFile = copyToFile(contents,filename);
         RetrievedDocument retrievedDocument = service.update(updateSPRequestEntity,  tmpFile.getPath());
         return buildReferenceFromDocumentAttributes(docId.getFolder(), retrievedDocument);
      }
      catch (Throwable t) {
         Reference reference = new Reference();
         reference.setDocumentId(documentId);
         throw handleException(reference,service, t);
      }
      finally {
         deleteTmpFile(tmpFile);
         closeService(service);
      }
   }

   private Reference buildReferenceFromDocumentAttributes(String folder, RetrievedDocument retrievedDocument)
      throws AttributeListParseException
   {
      String updatedObjectId = retrievedDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
      String updatedVersion = retrievedDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_VERSION);
      return  buildReference(folder, updatedObjectId, updatedVersion);
   }

   private void deleteTmpFile(File tmpFile) {
      if((tmpFile!=null)&&(tmpFile.exists())){
         //noinspection ResultOfMethodCallIgnored
         tmpFile.delete();
         }
   }

  /* private UpdateDocumentumRequestEntity buildUpdateDocumentumRequestEntity(boolean majorVersion, FieldValues fieldValues, String filename, String folder, String objectId) {
      UpdateDocumentumRequestEntity updateDctmRequestEntity = new UpdateDocumentumRequestEntity();
      updateDctmRequestEntity.setFolderName(folder);

      updateDctmRequestEntity.setRequestPDFRendition(filename.endsWith(".pdf"));
      updateDctmRequestEntity.setSearchAllVersions(false);

      DocumentAttributes documentAttributes = updateDctmRequestEntity.getDocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID,objectId,DocumentManagerConstants.OPERATOR_EQUALS);
      if(majorVersion){
            documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UPDATE_VERSION,DocumentManagerConstants.NEXT_MAJOR_VERSION,DocumentManagerConstants.OPERATOR_EQUALS);
         }
         else {
         documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UPDATE_VERSION,DocumentManagerConstants.NEXT_MINOR_VERSION,DocumentManagerConstants.OPERATOR_EQUALS);
      }

      populateAttributes(fieldValues, documentAttributes);
      return updateDctmRequestEntity;
   }*/
   private UpdateSharePointRequestEntity buildUpdateSharePointRequestEntity(boolean majorVersion, FieldValues fieldValues, String filename, String folder, String objectId) {
      UpdateSharePointRequestEntity updateSPRequestEntity = new UpdateSharePointRequestEntity();
      updateSPRequestEntity.setFolderName(folder);

      updateSPRequestEntity.setRequestPDFRendition(filename.endsWith(".pdf"));
      updateSPRequestEntity.setSearchAllVersions(false);

      DocumentAttributes documentAttributes = updateSPRequestEntity.getDocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID,objectId,DocumentManagerConstants.OPERATOR_EQUALS);
      if(majorVersion){
            documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UPDATE_VERSION,DocumentManagerConstants.NEXT_MAJOR_VERSION,DocumentManagerConstants.OPERATOR_EQUALS);
         }
         else {
         documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UPDATE_VERSION,DocumentManagerConstants.NEXT_MINOR_VERSION,DocumentManagerConstants.OPERATOR_EQUALS);
      }

      populateAttributes(fieldValues, documentAttributes);
      return updateSPRequestEntity;
   }
   private String retrieveFileNameForDocument(String documentId) {
      Reference reference = new Reference();
      reference.setDocumentId(documentId);
      ViewFields detailFields = new ViewFields();
      ViewField nameField = new ViewField();
      nameField.setName(DocumentManagerConstants.ATTR_STR_NAME);
      detailFields.getViewFields().add(nameField);
      DocumentDetail documentDetail = retrieveDetails(reference, detailFields);
      String fileName = "tmpfile.bin";
      for (FieldTypeValue fieldTypeValue : documentDetail.getFieldTypeValues().getFieldTypeValues()) {
         if (fieldTypeValue.getName().equals(DocumentManagerConstants.ATTR_STR_NAME)) {
            fileName = fieldTypeValue.getValue();
         }
      }
      return fileName;
   }

   
   public Reference update(Reference reference,
                           DataHandler contents,
                           FieldValues fieldValues) throws RequestException
   {
      return update(reference.getDocumentId(), true, contents, fieldValues);
   }

   public void deleteLatest(String documentId)
      throws RequestException, FatalException
   {
      ViewFields viewFields = new ViewFields();
      Reference lookupReference = new Reference();
      lookupReference.setDocumentId(documentId);
      Collection<DocumentDetail> details = retrieveDetails(Arrays.asList(lookupReference),viewFields);
      DocumentDetail detail = details.iterator().next();
      delete(detail.getReference());
   }
}
