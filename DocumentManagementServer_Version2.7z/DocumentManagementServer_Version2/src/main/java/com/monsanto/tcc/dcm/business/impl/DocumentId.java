package com.monsanto.tcc.dcm.business.impl;

/**
 * rlcasw - Jun 10, 2010 3:04:13 PM
 */
public class DocumentId
{
     private String folder;
     private String objectId;

   public String getFolder() {
      return folder;
   }

   public void setFolder(String folder) {
      this.folder = folder;
   }

   public String getObjectId() {
      return objectId;
   }

   public void setObjectId(String objectId) {
      this.objectId = objectId;
   }
}
