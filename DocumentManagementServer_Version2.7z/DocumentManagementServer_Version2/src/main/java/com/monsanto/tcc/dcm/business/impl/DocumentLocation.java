package com.monsanto.tcc.dcm.business.impl;

/**
 * rlcasw - Jun 10, 2010 2:38:15 PM
 */
public class DocumentLocation
{
     private String filename ;
     private String folder;
     private String directoryStructure;

   public String getDirectoryStructure() {
      return directoryStructure;
   }

   public void setDirectoryStructure(String directoryStructure) {
      this.directoryStructure = directoryStructure;
   }

   public String getFilename() {
      return filename;
   }

   public void setFilename(String filename) {
      this.filename = filename;
   }

   public String getFolder() {
      return folder;
   }

   public void setFolder(String folder) {
      this.folder = folder;
   }
}
