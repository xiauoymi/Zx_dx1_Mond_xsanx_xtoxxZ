package com.monsanto.tcc.dcm.business.impl;

import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.ISharePointServices;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.SharePointServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;

/**
 * Created by IntelliJ IDEA.
 * User: vvgosw
 * Date: Nov 17, 2010
 * Time: 11:46:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class SPServicesFactory {
    private final ServiceLookup serviceLookup;

   public SPServicesFactory(ServiceLookup serviceLookup) {
      this.serviceLookup=serviceLookup;
   }

   public ISharePointServices buildSPServices(String folder)
      throws ServiceConfigException, EncryptorException, AttributeListParseException
   {
      ConnectionInfo connectionInfo = getConnectionInfo(folder);
      return new SharePointServices(connectionInfo.getConnectionParameterValue(DocumentManagerConstants.SP_CI_SITE_NAME),
         connectionInfo.getConnectionParameterValue(DocumentManagerConstants.SP_CI_DOC_LIB_NAME));
   }

   public ConnectionInfo getConnectionInfo(String folder)
      throws ServiceConfigException, EncryptorException
   {
      ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails(folder, System.getProperty("lsi.function"));
      return connectionInfo;
   }
}
