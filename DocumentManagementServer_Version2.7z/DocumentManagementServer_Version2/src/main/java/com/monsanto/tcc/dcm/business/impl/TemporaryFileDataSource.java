package com.monsanto.tcc.dcm.business.impl;

import javax.activation.FileDataSource;
import java.io.File;
import java.io.InputStream;
import java.io.IOException;

/**
 * rlcasw - Jun 11, 2010 4:12:32 PM
 */
public class TemporaryFileDataSource extends FileDataSource
{
   private final String contentType;
   public TemporaryFileDataSource(File file,String contentType) {
      super(file);
      this.contentType=contentType;
   }

   @Override
   public InputStream getInputStream()
      throws IOException
   {
      return new TemporaryFileInputStream(getFile());
   }

   @Override
   public String getContentType() {
      return contentType;
   }
}
