package com.monsanto.tcc.dcm.business.impl;

import java.io.FileInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * RLCASW - May 31, 2010 1:05:34 PM
 */
public class TemporaryFileInputStream extends FileInputStream
{
   private final File tmpFile;
     public TemporaryFileInputStream(File file) throws FileNotFoundException {
        super(file);
        tmpFile= file;
     }

   @Override
   public void close()
      throws IOException
   {
      super.close();
      tmpFile.delete();
   }
}
