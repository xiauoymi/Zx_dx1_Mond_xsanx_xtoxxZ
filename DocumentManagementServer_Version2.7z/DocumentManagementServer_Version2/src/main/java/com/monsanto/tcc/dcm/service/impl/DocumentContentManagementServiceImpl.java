package com.monsanto.tcc.dcm.service.impl;


import com.monsanto.tcc.dcm.business.DocumentContentManagementBusiness;
import com.monsanto.tcc.dcm.exception.FatalException;
import com.monsanto.tcc.dcm.exception.RequestException;
import com.monsanto.tcc.dcm.service.DocumentContentManagementService;
import com.monsanto.tcc.dcm.transfer.Document;
import com.monsanto.tcc.dcm.transfer.DocumentContent;
import com.monsanto.tcc.dcm.transfer.DocumentDetail;
import com.monsanto.tcc.dcm.transfer.FieldValues;
import com.monsanto.tcc.dcm.transfer.Reference;
import com.monsanto.tcc.dcm.transfer.SearchRequest;
import com.monsanto.tcc.dcm.transfer.SearchResult;
import com.monsanto.tcc.dcm.transfer.ViewFields;

import javax.activation.DataHandler;
import java.util.Collection;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
public class DocumentContentManagementServiceImpl implements DocumentContentManagementService
{

    private final DocumentContentManagementBusiness documentContentManagementBusiness;
    //private final DataPointHolder dataPointHolder;
    public DocumentContentManagementServiceImpl(DocumentContentManagementBusiness documentContentManagementBusiness/*, DataPointHolder dataPointHolder*/){

       this.documentContentManagementBusiness=documentContentManagementBusiness;
     //  this.dataPointHolder = dataPointHolder;
    }

   //PerformanceMetric(task = "DocumentContentManagementService.retrieve", comment = "")
    public Collection<Document> retrieve(Collection<Reference> references, ViewFields viewFields)
            throws RequestException, FatalException
   {
       // dataPointHolder.add("referenceCount",references.size());
        return documentContentManagementBusiness.retrieve(references,viewFields);
    }
    //PerformanceMetric(task = "DocumentContentManagementService.retrieveDetails", comment = "")
    public Collection<DocumentDetail> retrieveDetails(Collection<Reference> references, ViewFields viewFields)
            throws RequestException, FatalException {
       //dataPointHolder.add("referenceCount",references.size());
       return documentContentManagementBusiness.retrieveDetails(references,viewFields);
    }

   //PerformanceMetric(task = "DocumentContentManagementService.retrieveContent", comment = "")
    public DocumentContent retrieveContent(Reference reference) throws RequestException, FatalException {
       // dataPointHolder.add("documentId",reference.getDocumentId());
        return documentContentManagementBusiness.retrieveContent(reference);
    }

    //PerformanceMetric(task = "DocumentContentManagementService.search", comment = "")
    public SearchResult search(SearchRequest searchRequest) throws RequestException, FatalException {
       return documentContentManagementBusiness.search(searchRequest);
    }

    //PerformanceMetric(task = "DocumentContentManagementService.deleteAll", comment = "")
    public void deleteAll(String documentId) throws RequestException, FatalException {
       //dataPointHolder.add("documentId",documentId);
       documentContentManagementBusiness.deleteAll(documentId);
    }

   //PerformanceMetric(task = "DocumentContentManagementService.delete", comment = "")
    public void delete(Reference reference) throws RequestException, FatalException {
       //dataPointHolder.add("documentId",reference.getDocumentId());
//       if(reference.getVersion()!=null){
//            dataPointHolder.add("version",reference.getVersion());
//       }
       documentContentManagementBusiness.delete(reference);
    }

    //PerformanceMetric(task = "DocumentContentManagementService.deleteLatest", comment = "")
    public void deleteLatest(String documentId) throws RequestException, FatalException {
       //dataPointHolder.add("documentId",documentId);
       documentContentManagementBusiness.deleteLatest(documentId);
    }

    //PerformanceMetric(task = "DocumentContentManagementService.update", comment = "")
    public Reference update(Reference reference, DataHandler contents, FieldValues fieldValues)
            throws RequestException, FatalException {
//        dataPointHolder.add("documentId",reference.getDocumentId());
//        if(reference.getVersion()!=null){
//             dataPointHolder.add("version",reference.getVersion());
//        }
        return documentContentManagementBusiness.update(reference,contents,fieldValues);
    }

    //PerformanceMetric(task = "DocumentContentManagementService.update", comment = "")
    public Reference update(String documentId, boolean majorVersion, DataHandler contents, FieldValues fieldValues)
            throws RequestException, FatalException {
//        dataPointHolder.add("documentId",documentId);
//        dataPointHolder.add("majorVersion",majorVersion?"true":"false");
        return documentContentManagementBusiness.update(documentId,majorVersion,contents,fieldValues);
    }
   
    //PerformanceMetric(task = "DocumentContentManagementService.create", comment = "")
    public Reference create(String location, boolean versioningEnabled, DataHandler contents, FieldValues fieldValues)
            throws RequestException, FatalException {
       //dataPointHolder.add("location",location);
       return documentContentManagementBusiness.create(location,versioningEnabled,contents,fieldValues);
    }


}
