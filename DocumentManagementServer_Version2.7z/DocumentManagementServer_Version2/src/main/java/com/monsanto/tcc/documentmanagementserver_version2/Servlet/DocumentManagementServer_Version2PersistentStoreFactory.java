package com.monsanto.tcc.documentmanagementserver_version2.Servlet;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType2;
import com.monsanto.Util.Exceptions.WrappingException;

import java.util.ResourceBundle;

/**
 *
 * <p>Title: DocumentManagementServer_Version2PersistentStoreFactory</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code  Generator 2.3
 * @version $Id: DocumentManagementServer_Version2PersistentStoreFactory.java,v 1.4 2006-03-30 23:47:49 rgeorge Exp $
 */
public class DocumentManagementServer_Version2PersistentStoreFactory
{
  /**
       * Returns a Persistent Store.
       *
       * @param cstrResourceBundleName The name of the resource bundle that points
       *                               to the correct database.
       * @return A PersistentStore object.
       * @throws WrappingException
       */
      public static PersistentStore getStore(String cstrResourceBundleName) throws WrappingException {
         Logger.traceEntry();


         ResourceBundle bundle = ResourceBundle.getBundle(cstrResourceBundleName);


         PersistentStore RetVal = new PersistentStoreOracleCachedType2(bundle);


         return (PersistentStore) Logger.traceExit(RetVal);
      }
  }
