package com.monsanto.tcc.documentmanagementserver_version2.Servlet;


import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCServletHelper;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.Util.Exceptions.WrappingException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;



/**
 *
 * <p>Title: DocumentManagementServer_Version2Servlet</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code  Generator 2.3
 * @version $Id: DocumentManagementServer_Version2Servlet.java,v 1.5 2006-03-30 23:47:49 rgeorge Exp $
 */
public class DocumentManagementServer_Version2Servlet extends GatewayServlet
{
   public static final String s_cstrResourceBundle = "com.monsanto.tcc.documentmanagementserver_version2.Servlet.DocumentManagementServer_Version2";

   public DocumentManagementServer_Version2Servlet()
   {
      super(600);  // Set the session timeout values in seconds. (600)
   }

   public void init(ServletConfig servletConfig) throws ServletException
   {
      super.init(servletConfig);

      Logger.traceEntry();

      try {
         DocumentManagementServer_Version2LoggerFactory loggerFactory = new DocumentManagementServer_Version2LoggerFactory();
         loggerFactory.setupLogging();
      }
      catch (LogRegistrationException lre) {
         throw new ServletException(lre.toString());
      }
      catch (IOException ioe) {
         throw new ServletException(ioe.toString());
      }

      Logger.traceExit();
   }

   public void destroy()
   {
      Logger.traceEntry();

      try {
         PersistentStore.registerInstance(null);
      }
      catch (WrappingException e) {
      }

      super.destroy();

      Logger.traceExit();
   }

   /**
    * This static method will create an instance of the desired PersistentStore based on
    * data within a property file.
    * @param request - The HttpServlet Request from the servlet container
    * @param response - The HttpServletResponse to be sent back to the servlet container.
    * @throws java.io.IOException
    * @throws javax.servlet.ServletException
    */
   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
   {
      Logger.traceEntry();

      UCCHelper helper = new UCCServletHelper(getServletConfig(), request, response);

      try {

         /*  Register the persistent store with this servlet instance.  */
         PersistentStore ps = DocumentManagementServer_Version2PersistentStoreFactory.getStore(s_cstrResourceBundle);
         PersistentStore.registerInstance(ps);

         /*  Pass the doGet along.  */
         //response.reset();
         // response.resetBuffer();
         super.doGet(request, response);
      }
      catch (WrappingException we) {
         helper.reportError("Error accessing database.  Please notify your technical support contact or try again later.\n" + we.toString());
         helper.closeSession();
      }

      Logger.traceExit();
   }
}