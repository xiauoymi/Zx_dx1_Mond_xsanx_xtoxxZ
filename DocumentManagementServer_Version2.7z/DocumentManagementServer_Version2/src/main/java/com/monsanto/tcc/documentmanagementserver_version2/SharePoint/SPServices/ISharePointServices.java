/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices;

import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.entity.InsertSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity.SearchSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updateSharePointDoc.entity.UpdateSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author lakench
 * @version $Revision$
 */
public interface ISharePointServices {
  /**
   * Connect to Documentum
   *
   * @exception DocumentManagerException
   */

  /**
   * Insert w/o support for versioning (throws an exception if the document already exists.) Also adds PDF rendition
   * capability to the inserted document object.
   *
   * @param insertDctmRequestEntity
   * @param directoryStructure
   * @param atttachmentLocation
   *
   * @return RetrievedDocument details
   *
   * @exception DocumentManagerException
   * @exception com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException
   *
   */
  RetrievedDocument saveDocument(InsertSharePointRequestEntity insertDctmRequestEntity, String directoryStructure,
                                 String atttachmentLocation) throws DocumentManagerException,
      AttributeListParseException, DfException;

  /**
   * Find the Documentum object id for the given name and context
   *
   * @param name Documentum object name
   *
   * @return a list of the object ids found, return an empty list if no objects found
   *
   * @exception DocumentManagerException
   */
  List findIdByName(String name, String directoryStructure) throws DocumentManagerException;

  /**
   * Delete the given Documentum by fileName.
   *
   * @param fileName
   *
   * @exception DocumentManagerException
   */
  void deleteByName(String fileName, String directoryStructure) throws DocumentManagerException, IOException, ParserException;

  /**
   * Delete the given Documentum object id
   *
   * @param objectId the Documentum object id
   *
   * @exception DocumentManagerException
   */
  boolean deleteById(String objectId, String typeOfID, String fileLocation) throws IOException, ParserException,
      ParserConfigurationException,
      DocumentManagerException;

  /**
   * Delete all versions of the given Documentum object id
   *
   * @param objectId the Documentum object id
   *
   * @exception DocumentManagerException
   */
  boolean deleteAllVersionsById(String objectId) throws DocumentManagerException, IOException, ParserException,
      ParserConfigurationException;

  /**
   * Retrieve a given Document from Documentum using the objectId(documentId)
   *
   * @param documentAttributes
   * @param requiredAttributes List
   *
   * @return Map containing the retrieved file attributes
   *
   * @exception AttributeListParseException
   * @exception DocumentManagerException
   */
  RetrievedDocument retrieveDocumentObjectWithAttributes_NoCopyService(DocumentAttributes documentAttributes,
                                                         List requiredAttributes) throws AttributeListParseException,
      DocumentManagerException;


  RetrievedDocument retrieveDocumentObjectWithAttributes(DocumentAttributes documentAttributes,
                                                         List requiredAttributes) throws AttributeListParseException,
      DocumentManagerException;

  /**
   * Checks whether the given Documentum folder name exists in Documentum
   *
   * @param name   Documentum folder name
   * @param parent Documentum context info
   *
   * @return true if the Documentum folder already exists. Return false if no such folder exists
   *
   * @exception DocumentManagerException
   */
  boolean existFolderByName(String name, String parent) throws DocumentManagerException;

  /**
   * Create a Documentum folder
   *
   * @param folderName the folder name to create
   * @param parent     the context
   *
   * @exception DocumentManagerException
   * @see #createFolder(String, String)
   */
  void createFolder(String folderName, String parent) throws DocumentManagerException;

  void search(String queryString, SearchSharePointRequestEntity searchSharePointRequestEntity,
              ResponseEntity responseEntity) throws DocumentManagerException;

  /**
   * Returns an integer constant, stating the type of the attribute. Defaults to String, if attribute not found (Dctm
   * behavior).
   *
   * @param attributeName
   * @param sysObj
   *
   * @return
   *
   * @exception DfException
   */
  int lookupAttributeType(String attributeName, IDfSysObject sysObj) throws DfException;

  /**
   * Returns true if attribute is repeating, false if it is single.
   *
   * @param attributeName
   * @param sysObj
   *
   * @return
   *
   * @exception DfException
   */
  boolean isAttributeRepeating(String attributeName, IDfSysObject sysObj) throws DfException;

  void delete(String objectId, DocumentAttributes documentAttributes, ResponseEntity responseEntity) throws
      DocumentManagerException, AttributeListParseException, DfException;

  IDfSysObject instantiateSysObject() throws DocumentManagerException;

  /**
   * Updates the document with new/modified contents/attributes as new version
   *
   * @param updateDctmRequestEntity
   * @param newContentsLocation
   *
   * @return RetrievedDocument
   */
  RetrievedDocument update(UpdateSharePointRequestEntity updateDctmRequestEntity, String newContentsLocation) throws
      AttributeListParseException, DocumentManagerException, DfException;

  /**
   * In case the update fails...
   *
   * @exception DfException
   * @exception DocumentManagerException
   */
  void cancelCheckoutDocument() throws DfException, DocumentManagerException;
}