/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices;

import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.microsoft.schemas.sharepoint.soap.*;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.FileUtil;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.httpcommunication.HttpWebRequest;
import com.monsanto.httpcommunication.WebRequest;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.entity.InsertSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity.SearchResultEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity.SearchSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updateSharePointDoc.entity.UpdateSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NTCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.util.URIUtil;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.xpath.XPathAPI;
import org.apache.xpath.objects.XObject;
import org.w3c.dom.*;
import sun.misc.BASE64Encoder;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Detail;
import javax.xml.soap.SOAPFault;
import javax.xml.transform.TransformerException;
import javax.xml.ws.Holder;
import javax.xml.ws.soap.SOAPFaultException;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;



/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author lakench
 * @version $Revision$
 */
public class SharePointServices implements ISharePointServices {
  private static final String CONTENT_TYPE = "Content Type";
  private static final String FILE_TYPE = "File Type";
  private static final String TYPE = "Type";
  private static final String CR_LF = "\r\n";
  private static final String  SEMI_COLON = ";";

  //	private static final String DOT = ".";
  private String siteName;
  private String documentLibraryName;
  private String chronicleId;
  private String fileName;
  private static final String EXCEPTION_TEXT_BAD_FILENAME = "No File.";
  private static final String EXCEPTION_TEXT_INVALID_SEARCH_RESULTS = "More than 1 item was found.";

  public SharePointServices(String siteName, String documentLibraryName) {
    this.siteName = siteName;
    this.documentLibraryName = documentLibraryName;
  }

  /**
   * Connect to Documentum
   *
   * @exception DocumentManagerException
   *
   */
  /**
   * Insert w/o support for versioning (throws an exception if the document already exists.) Also adds PDF rendition
   * capability to the inserted document object.
   *
   * @param insertSharePointRequestEntity
   * @param directoryStructure
   * @param atttachmentLocation
   *
   * @return RetrievedDocument details
   *
   * @exception DocumentManagerException
   * @exception AttributeListParseException
   */
  public RetrievedDocument saveDocument(InsertSharePointRequestEntity insertSharePointRequestEntity,
                                        String directoryStructure, String atttachmentLocation) throws
      DocumentManagerException, AttributeListParseException, DfException {
    System.out.println("SharePointServices.saveDocument");
    System.out.println("insertSharePointRequestEntity = " + insertSharePointRequestEntity);
    System.out.println("directoryStructure = " + directoryStructure);
    System.out.println("atttachmentLocation = " + atttachmentLocation);
    DocumentAttributes documentAttributes = insertSharePointRequestEntity.getDocumentAttributes();
    if (documentAttributes == null || documentAttributes.getLength() == 0) {
      throw new DocumentManagerException("Required Attributes Missing.");
    }
    RetrievedDocument retrievedDocument = new RetrievedDocument();
    //ToDo: work out how to insert with a folder path; creation of the missing folders is complete & working; what's left is actually creating the file in the created folders
    //it doesn't, so we still have to parse the path & make multiple calls; see http://ronaldlemmen.blogspot.com/2010/04/create-folder-in-sharepoint-using-web.html for more details
    String completeParentFolderPath = null;
    createDirectoryStructure(directoryStructure);

    
    String fileName = documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_NAME);

    if (fileName == null || fileName.length() == 0) {
      Logger.log(new LoggableError("Assigning document name from file location information."));
      fileName = assignNameFromFileLocation(atttachmentLocation, true);
    }
    String sharePointLinkToFile;
    sharePointLinkToFile = siteName + "/" + documentLibraryName + "/" + directoryStructure + "/" + fileName;
    if (!existsOtherDocumentWithSameName(directoryStructure,fileName)) {
      String chronicleId = addNewDocument(retrievedDocument, documentAttributes,
          atttachmentLocation,
          fileName, insertSharePointRequestEntity.getRequestPDFRendition(),directoryStructure);
      try {
          //String chronicleId = getSPId(directoryStructure,fileName);
          //SearchResultEntity searchResult = getSearchResultEntityList(chronicleId, DocumentManagerConstants.SHAREPOINT_ATTR_ID, directoryStructure, false).get(0);
          SearchResultEntity searchResult = getSearchResultEntityList(fileName, DocumentManagerConstants.SHAREPOINT_ATTR_STR_OBJNAME, directoryStructure, false).get(0);
          return retrieveDocumentAttributesNoDownload(searchResult, new ArrayList());
        //return createRetrievedDocumentWithObjectIdAndVersion(retrievedDocument, chronicleId,
        //    getVersion(directoryStructure,fileName));
      } catch (DocumentManagerException e) {
        throw new DocumentManagerException(
            "Exception while executing. SharePointServices.saveDocument" + e.getMessage(), e);
      } 

    } else {
      throw new DocumentManagerException(String.format("Document already present in the specified path (%s).",
          sharePointLinkToFile));
    }
  }

  private String getSPId(String directoryStructure, String fileName) throws IOException, ParserException {
    ListsSoap listsSoap = setupListsService();
    if (directoryStructure!=null && !directoryStructure.isEmpty())
        directoryStructure += "/";
      
    String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
        "<Query>" +
        "<Where>" +
        "<Contains>" +
        "<FieldRef Name='FileRef' />" +
        "<Value Type='Text'>" + documentLibraryName + "/" + directoryStructure + fileName + "</Value>" +
        "</Contains>" +
        "</Where>" + "</Query>";
    Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
    GetListItems.Query query = new GetListItems.Query();
    List<Object> content = query.getContent();
    content.add(queryDoc.getDocumentElement());
    GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
        .getListItems(documentLibraryName, "", query, null, null, generateQueryOptions("", true), "");
    Element listResult = (Element) scannedImagesResult.getContent().get(0);
    NodeList list = listResult.getElementsByTagName("z:row");
    int length = list.getLength();
    NamedNodeMap attributes = list.item(0).getAttributes();
    DOMUtil.outputXML(listResult);
    String spID = attributes.getNamedItem("ows_i_chronicle_id").getNodeValue();
    return spID;
  }

  /**
   * Find the SharePoint document id for the given name and context
   *
   * @param fileName SharePoint file name
   *
   * @return a list of the object ids found, return an empty list if no objects found
   *
   * @exception DocumentManagerException
   */
  /*public List findIdByName(String fileName) throws
      DocumentManagerException {
    System.out.println("SharePointServices.findIdByName");
    System.out.println("fileName = " + fileName);
    try {
      ListsSoap listsSoap = setupListsService();
      String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
          "<Query>" +
          "<Where>" +
          "<Contains>" +
          "<FieldRef Name='FileRef' />" +
          "<Value Type='Text'>" + documentLibraryName + "/" + fileName + "</Value>" +
          "</Contains>" +
          "</Where>" + "</Query>";
      Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
      GetListItems.Query query = new GetListItems.Query();
      List<Object> content = query.getContent();
      content.add(queryDoc.getDocumentElement());
      GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
          .getListItems(documentLibraryName, "", query, null, null, generateQueryOptionsToSearchSubfolders(), "");
      Element listResult = (Element) scannedImagesResult.getContent().get(0);
      DOMUtil.outputXML(listResult);
      NodeList list = listResult.getElementsByTagName("z:row");
      int length = list.getLength();
      List IDs = new ArrayList(length);
      for (int i = 0; i < length; i++) {
        String spID = list.item(i).getAttributes().getNamedItem("ows_i_chronicle_id").getNodeValue();
        //System.out.println(String.format("Index: %d\t ID = %s", i, spID));
        IDs.add(spID);
      }
      return IDs;
    } catch (IOException e) {
      throw new DocumentManagerException("Problem querying Document Library" + e.getMessage(), e);
    } catch (ParserException e) {
      throw new DocumentManagerException("Problem querying Document Library" + e.getMessage(), e);

    }
  }*/
  public List findIdByName(String directoryStructure, String fileName) throws
      DocumentManagerException {
    System.out.println("SharePointServices.findIdByName");
    System.out.println("fileName = " + fileName);
    try {
      if (directoryStructure != null && !directoryStructure.isEmpty())
            directoryStructure += "/";
      ListsSoap listsSoap = setupListsService();
      String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
          "<Query>" +
          "<Where>" +
          "<Contains>" +
          "<FieldRef Name='object_name' />" +
          "<Value Type='Text'>" + documentLibraryName + "/" + directoryStructure + fileName + "</Value>" +
          "</Contains>" +
          "</Where>" + "</Query>";
      Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
      GetListItems.Query query = new GetListItems.Query();
      List<Object> content = query.getContent();
      content.add(queryDoc.getDocumentElement());
      GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
          .getListItems(documentLibraryName, "", query, null, null, generateQueryOptions("", true), "");
      Element listResult = (Element) scannedImagesResult.getContent().get(0);
      //System.out.println("SharePointServices.findIdByName");
      DOMUtil.outputXML(listResult);
      NodeList list = listResult.getElementsByTagName("z:row");
      int length = list.getLength();
      List IDs = new ArrayList(length);
      for (int i = 0; i < length; i++) {
        String spID = list.item(i).getAttributes().getNamedItem("ows_i_chronicle_id").getNodeValue();
        //System.out.println(String.format("Index: %d\t ID = %s", i, spID));
        IDs.add(spID);
      }
      return IDs;
    } catch (IOException e) {
      throw new DocumentManagerException("Problem querying Document Library" + e.getMessage(), e);
    } catch (ParserException e) {
      throw new DocumentManagerException("Problem querying Document Library" + e.getMessage(), e);

    }
  }
  /**
   * Delete the given Document by fileName.
   *
   * @param fileName
   *
   * @exception DocumentManagerException
   */
  public void deleteByName(String fileName, String directoryStructure) throws DocumentManagerException, IOException, ParserException {
    try {
      System.out.println("SharePointServices.deleteByName");
      System.out.println("fileName = " + fileName);
       if (directoryStructure !=null && !directoryStructure.isEmpty())
            directoryStructure += "/";
        
      List existingDoc = findListItemIdByName(fileName);
      //System.out.println("existingDoc = " + existingDoc);
      //System.out.println("existingDoc.size() = " + existingDoc.size());
      if (existingDoc.size() > 0) {
        for (Object anExistingDoc : existingDoc) {
          String objectId = (String) anExistingDoc;
          deleteById(objectId, "ID",directoryStructure);
        }
      }
    } catch (DocumentManagerException e) {
      throw new DocumentManagerException("Exception while deleting document by name. " + e.getMessage(), e);
    } catch (ParserConfigurationException e) {
      throw new DocumentManagerException("Exception while deleting document by name. " + e.getMessage(), e);
    }
  }

  private List findListItemIdByName(String fileName) throws DocumentManagerException {
    System.out.println("SharePointServices.findIdByName = " + fileName);
    try {

      ListsSoap listsSoap = setupListsService();
      String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
          "<Query>" +
          "<Where>" +
          "<Contains>" +
          "<FieldRef Name='FileRef' />" +
          "<Value Type='Text'>" + fileName + "</Value>" +
          "</Contains>" +
          "</Where>" + "</Query>";
      Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
      GetListItems.Query query = new GetListItems.Query();
      List<Object> content = query.getContent();
      content.add(queryDoc.getDocumentElement());
      GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
          .getListItems(documentLibraryName, "", query, null, null, generateQueryOptions("", true), "");
      Element listResult = (Element) scannedImagesResult.getContent().get(0);
      //System.out.println("SharePointServices.findIdByName");
      DOMUtil.outputXML(listResult);
      NodeList list = listResult.getElementsByTagName("z:row");
      int length = list.getLength();
      List IDs = new ArrayList(length);
      for (int i = 0; i < length; i++) {
        String spID = list.item(i).getAttributes().getNamedItem("ows_ID").getNodeValue();
        //System.out.println(String.format("Index: %d\t ID = %s", i, spID));
        IDs.add(spID);
      }
      return IDs;
    } catch (IOException e) {
      throw new DocumentManagerException("Problem querying Document Library" + e.getMessage(), e);
    } catch (ParserException e) {
      throw new DocumentManagerException("Problem querying Document Library" + e.getMessage(), e);

    }
  }

  /**
   * Delete the given Document ID
   *
   * @param ListItemID the SharePoint Document id
   *
   * @exception DocumentManagerException
   */
  public boolean deleteById(String ListItemID, String typeOfID, String fileLocation) throws ParserException, ParserConfigurationException,
      DocumentManagerException, IOException {
    System.out.println("SharePointServices.deleteById " + ListItemID + ":" + fileLocation);
    boolean success = true;
    String listID = null;
    String strBatch = null;
   
    if (typeOfID.equals("ID")) {
        listID = ListItemID;
    } else {
        String fileName = getFileName(ListItemID, typeOfID,"");
        listID = (String) findListItemIdByName(fileName).get(0);
    }
      strBatch = "<?xml version='1.0' encoding='UTF-8'?><Batch><Method ID='1' Cmd='Delete'>" +
              "<Field Name='ID'>" + listID + "</Field>" +
              "<Field Name='FileRef'>" + fileLocation +
              "</Field>" +
              "</Method></Batch>";

      System.out.println("SharePointServices.deleteById: strBatch = " + strBatch);
    success = deleteWithBatchCommandScript(strBatch);
    return success;
  }

  public boolean deleteByIdAndVersion(String objectId, String versionToBeDeleted) throws DocumentManagerException {
    boolean success = true;
    String fileUrl = null;
    try {
      fileUrl = getFileLocation(objectId, "i_chronicle_id", "");
      System.out.println("SharePointServices.deleteByIdAndVersion: fileUrl/versionToBeDeleted = " + fileUrl + "/" + versionToBeDeleted);
      VersionsSoap service = createVersionsService(siteName + "/_vti_bin/Versions.asmx?WSDL");
      GetVersionsResponse.GetVersionsResult getVersionsResult = service.getVersions(fileUrl);
      List<Object> versions = getVersionsResult.getContent();
      Element resultElement = (Element) versions.get(0);
      NodeList list = resultElement.getElementsByTagName("result");
      verifyVersionOfDocumentToDelete(list, versionToBeDeleted);
      if (list.getLength() < 2) {
        success = deleteById(objectId, "i_chronicle_id",fileUrl);
      } else {
        DeleteVersionResponse.DeleteVersionResult result = service.deleteVersion(fileUrl, versionToBeDeleted);
        List<Object> resultList = result.getContent();
        Element deletedElement = (Element) resultList.get(0);
        NodeList deletedList = deletedElement.getElementsByTagName("result");
        verifyDeletedResult(deletedList);
      }
    } catch (IOException e) {
      success = false;
      e.printStackTrace();
    } catch (ParserException e) {
      success = false;
      e.printStackTrace();
    } catch (ParserConfigurationException e) {
      success = false;
      e.printStackTrace();
    }
    return success;
  }

  private String createDirectoryStructure(String directoryStructure) throws DocumentManagerException {
    String completeParentFolderPath = documentLibraryName;
    if (directoryStructure != null && directoryStructure.length() > 0) {
      createDirectoryStructure(documentLibraryName, directoryStructure);
      completeParentFolderPath = completeParentFolderPath + "/" + directoryStructure;
    }
    return completeParentFolderPath;
  }


  private void createDirectoryStructure(String docLib, String directoryStructure) throws DocumentManagerException {
    if (isSubdirectoryPresent(directoryStructure)) {
      String[] directoryList = createSubdirectoryList(directoryStructure, documentLibraryName);
      for (int i = 0; i < directoryList.length - 1; i++) {

        String substructure = buildSubdirectory(directoryList, i);
        String nextPathToBuild = directoryList[i + 1];
        createFolder(substructure, nextPathToBuild);
      }
    } else {
      createDirectory(directoryStructure);
    }
  }

  private void createDirectory(String SingleDirectoryName) throws DocumentManagerException {
    Lists service = null;    ListsSoap listsSoap = null;
    try {
       listsSoap = setupListsService();
    } catch (MalformedURLException e) {
      throw new DocumentManagerException(
          "Something bad happened during the creation of the directory(" + SingleDirectoryName + "): \"" +
              e.getMessage() + "\"", e);
    }
    String strBatch = "<Batch OnError=\"Continue\" PreCalc=\"TRUE\">\n" +
        "   <Method ID=\"1\" Cmd=\"New\">\n" +
        "      <Field Name=\"ID\">New</Field>\n" +
        "      <Field Name=\"FSObjType\">1</Field>\n" +
        "      <Field Name=\"BaseName\">" + SingleDirectoryName + "</Field>\n" +
        "   </Method>\n" +
        "</Batch>";
    Document document = null;
    try {
      document = DOMUtil.newDocumentFromXML(strBatch);
    } catch (IOException e) {
      throw new DocumentManagerException(
          "Something bad happened during the creation of the directory(" + SingleDirectoryName + "): \"" +
              e.getMessage() + "\"", e);
    } catch (ParserException e) {
      throw new DocumentManagerException(
          "Something bad happened during the creation of the directory(" + SingleDirectoryName + "): \"" +
              e.getMessage() + "\"", e);
    }
      catch (Exception e) {
      throw new DocumentManagerException(
          "***DEBUG Something bad happened during the creation of the directory(" + SingleDirectoryName + "): \"" +
              e.getMessage() + "\"", e);
    }
    UpdateListItems.Updates updates = new UpdateListItems.Updates();
    List<Object> content = updates.getContent();
    content.add(document.getDocumentElement());
    UpdateListItemsResponse.UpdateListItemsResult listItemsResult = null;
    try {
      listItemsResult = listsSoap.updateListItems(documentLibraryName, updates);
      parseResult(listItemsResult);
    } catch (SOAPFaultException e) {
      SOAPFault fault = e.getFault();
      StringBuilder fullErrorMessage = new StringBuilder();
      String errorMessageLineOne =
          "SharepointServices_AT.testUploadDocument_ThenDeleteSameDocument: e.getMessage() = " + e.getMessage() + "\n";
      System.out.print(
          errorMessageLineOne);
      Detail detail = fault.getDetail();
      String errorMessageLineTwo =
          "SharepointServices_AT.testUploadDocument_ThenDeleteSameDocument: detail.toString() = " + detail.toString() +
              "\n";
      System.out.print(
          errorMessageLineTwo);
      String errorMessageLineThree =
          "SharepointServices_AT.testUploadDocument_ThenDeleteSameDocument: detail.getValue() = " + detail.getValue() +
              "\n";
      System.out.print(
          errorMessageLineThree);
      fullErrorMessage = fullErrorMessage.append(errorMessageLineOne).append(errorMessageLineTwo)
          .append(errorMessageLineThree);
      Iterator entries = detail.getDetailEntries();
      while (entries.hasNext()) {
        Object o = entries.next();
        String soapFaultDetailMessage =
            "fault detail entry.toString() = " + o.toString() + "\n";
        fullErrorMessage = fullErrorMessage.append(soapFaultDetailMessage);
        System.out
            .print(soapFaultDetailMessage);
      }
      String faultActorMessage =
          "fault.getFaultActor() = " +
              fault.getFaultActor() + "\n";
      System.out.print(faultActorMessage);
      String faultCodeMessage =
          "fault.getFaultCode() = " +
              fault.getFaultCode() + "\n";
      System.out.print(faultCodeMessage);
      String faultStringMessage =
          "fault.getFaultString() = " +
              fault.getFaultString() + "\n";
      System.out.print(faultStringMessage);
      String exceptionMessage = "e.getMessage() = " + e.getMessage() + "\n";
      System.out
          .print(exceptionMessage);
      fullErrorMessage = fullErrorMessage.append(faultActorMessage).append(faultCodeMessage).append(faultStringMessage);
      throw new DocumentManagerException(
          "something went bad while creating directory " + SingleDirectoryName + ":" + fullErrorMessage, e);
    }
  }

  private String buildSubdirectory(String[] directoryList, int end) {
    StringBuffer out = new StringBuffer();
    for (int idx = 1; idx <= end; idx++) {
      out.append(directoryList[idx]);
      if (idx != end) {
        out.append("/");
      }
    }
    return out.toString();
  }


  private boolean isSubdirectoryPresent(String directory) {
    return (-1 != directory.indexOf("/"));
  }

  private String[] createSubdirectoryList(String directoryStructure, String docRoot) {
    String[] directoryList = directoryStructure.split("/");
    int directoryListLength = directoryList.length;
    String[] parentDirectoryList = new String[directoryListLength + 1];
    parentDirectoryList[0] = docRoot;
    System.arraycopy(directoryList, 0, parentDirectoryList, 1, directoryList.length);
    return parentDirectoryList;
  }


  private String assignNameFromFileLocation(String attachmentLocation, boolean removePath) {
    System.out.println("SharePointServices.assignNameFromFileLocation");
    System.out.println("attachmentLocation = " + attachmentLocation);
    System.out.println("removePath = " + removePath);
    String fileName = attachmentLocation;
    if (removePath) {   //**remove the path info
      int lastIndex = attachmentLocation.lastIndexOf("\\");
      if (lastIndex == -1) {
        lastIndex = attachmentLocation.lastIndexOf("/");
      }
      if (lastIndex != -1) {
        fileName = attachmentLocation.substring(lastIndex + 1);
      }
    }
    return fileName;
  }

  /*private boolean existsOtherDocumentWithSameName(String fileName) throws DocumentManagerException {
    return findIdByName(fileName).size() != 0;
  }*/
   private boolean existsOtherDocumentWithSameName(String directoryStructure, String fileName) throws DocumentManagerException {
    List results = getSearchResultEntityList(fileName, DocumentManagerConstants.SHAREPOINT_ATTR_STR_OBJNAME, directoryStructure, false);

    return results.size() != 0;
  }
  /**
   * Adds new document to the repository...
   *
   * @param documentAttributes
   * @param attachmentLocation
   * @param fileName
   * @param addPDFRenditionCapability
   *
   * @return String: object-id of document saved into the repository
   *
   * @exception DocumentManagerException
   */

  private String addNewDocument(RetrievedDocument retrievedDocument,
                                                            DocumentAttributes documentAttributes,
                                                            String attachmentLocation, String fileName,
                                                            boolean addPDFRenditionCapability,
                                                            String directoryStructure)
      throws DocumentManagerException, AttributeListParseException {
    System.out.println("SharePointServices.addNewDocument");
    System.out.println("retrievedDocument = " + retrievedDocument);
    System.out.println("documentAttributes = " + documentAttributes);
    System.out.println("attachmentLocation = " + attachmentLocation);
    System.out.println("parentFolderPath = " + fileName);
    System.out.println("addPDFRenditionCapability = " + addPDFRenditionCapability);

    CopySoap copySoap = null;
    try {
      System.out.println("before entering createCopyService...");
      copySoap = createCopyService(siteName + "/_vti_bin/Copy.asmx?WSDL");
        System.out.println("after exiting createCopyService...");
    } catch (MalformedURLException e) {
      throw new DocumentManagerException(String.format(
          "something went wrong while inserting your new document: I caught a \"%s\" exception with a message of : \"%s\"",
          e.getClass().getName(), e.getMessage()), e);
    }
    if (directoryStructure != null && !directoryStructure.isEmpty())
        directoryStructure += "/";
    DestinationUrlCollection destUrls = setupDestinationUrls(siteName + "/" + documentLibraryName + "/" + directoryStructure, fileName);
    byte[] stream = new byte[0];
    try {
      //stream = FileUtil
      //    .fileToByteArray(attachmentLocation);
        stream = readFileInChunks(attachmentLocation);
    } catch (IOException e) {
      throw new DocumentManagerException(String.format(
          "something went wrong while inserting your new document: I caught a \"%s\" exception with a message of : \"%s\"",
          e.getClass().getName(), e.getMessage()), e);
    }
    FieldInformationCollection fields = new FieldInformationCollection();
    List<FieldInformation> fieldInformationList = fields.getFieldInformation();
    //ToDo: figure out how to apply all of the passed attributes; the below line adds one hardcoded attribute name and value; likely need to implement a loop that loops through the attributes in the request and stores them via call to addFieldToList;a method called something like setDocumentInfo seems like a good place for that loop
    String chronicleId = UUID.randomUUID().toString();
    documentAttributes.addAttribute("i_chronicle_id", chronicleId, DocumentManagerConstants.OPERATOR_EQUALS);
    setDocumentInfo(fieldInformationList, documentAttributes);

    // addFieldToList(fieldInformationList, "Publisher", "TestPublisherValue");
    Holder<Long> result = new Holder<Long>();
    Holder<CopyResultCollection> results = new Holder<CopyResultCollection>();
    copySoap.copyIntoItems(destUrls.getString().get(0), destUrls, fields, stream, result, results);
    List<CopyResult> copyResults = results.value.getCopyResult();

    System.out.println("SharePointServices.addNewDocument: result = " + result.value.toString());

    //ToDo: Need to handle this copyResults List - if there are any errors, may want to translate to a DocumentManagerException

    for (int i = 0; i < copyResults.size(); i++) {
      CopyResult copyResult = copyResults.get(i);
      String copyResultErrorCode = copyResult.getErrorCode().value();
      String copyErrorMessage = copyResult.getErrorMessage();
      System.out
          .println("SharePointServices.addNewDocument: copyResult.getErrorMessage() = " + copyErrorMessage);
      if (!copyResultErrorCode.equalsIgnoreCase("Success") && !StringUtils.isNullOrEmpty(copyErrorMessage)) {
        throw new DocumentManagerException(
            "something happened while creating your new Document.  Copy Service returned an error of: \"" +
                copyErrorMessage + "\"");
      }
    }
    if (addPDFRenditionCapability) {

     //ToDo: Once we get Adlib up, figure out how to integrate pdf rendition generation/retrieval; this is the only line that uses retrievedDocument so please don't remove it in the meantime while we figure out how to go about the renditions
     //          IDfId queueId = applyPDFRenditionCapability(sysObj);
     //          createRetrievedDocumentWithPDFRenditionResponse(retrievedDocument,queueId);
    }
    return chronicleId;
  }
    private byte[] readFileInChunks(String filename) throws IOException {
        ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
        FileInputStream inputStream = new FileInputStream(filename);
        byte[] stream = null;
        try{
            int byteStreamLength = 8192;
            int bytesRead = 0;
            byte [] bytearray = new byte[byteStreamLength];
            while ((bytesRead = inputStream.read(bytearray, 0, byteStreamLength)) > -1) {
                byteArray.write(bytearray, 0, bytesRead);
            }
            stream = byteArray.toByteArray();
        }catch (IOException ex){
            System.out.println(ex.getMessage() + ex.getStackTrace());
            throw new IOException(ex);
        }finally {
            byteArray.close();
            inputStream.close();
        }
        return stream;
    }

  private void setDocumentInfo(List<FieldInformation> fieldInformationList,
                               DocumentAttributes documentAttributes) throws
      AttributeListParseException {
    documentAttributes.addAllAttributesToSPFields(fieldInformationList);
  }

  private DestinationUrlCollection setupDestinationUrls(String scannedImagesUrl, String fileName) {
    DestinationUrlCollection destUrls = new DestinationUrlCollection();
    List<String> urlList = destUrls.getString();
    String documentDestinationUrl = scannedImagesUrl + fileName;
    urlList.add(documentDestinationUrl);
    return destUrls;
  }

  private RetrievedDocument createRetrievedDocumentWithObjectIdAndVersion(RetrievedDocument retrievedDocument,
                                                                          String objectId, String version) {
    retrievedDocument.getDocumentAttributes()
        .addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, objectId, null);
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION, version, null);
    return retrievedDocument;
  }

 private void verifyDeletedResult (NodeList list) throws
      DocumentManagerException
 {
       if ((list== null) || (list!= null && list.getLength()< 1) )
           throw new DocumentManagerException("No documents for deletion by Version.");
 }
  private void verifyVersionOfDocumentToDelete(NodeList list, String versionToBeDeleted) throws
      DocumentManagerException {
    System.out.println("SharePointServices.verifyVersionOfDocumentToDelete: versionToBeDeleted = " + versionToBeDeleted);
    boolean found = false;
    for (int i = 0; i < list.getLength(); i++) {
      Node node = list.item(i);
      NamedNodeMap map = node.getAttributes();
      String versionInSP = map.getNamedItem("version").getNodeValue();
      System.out.println("SharePointServices.verifyVersionOfDocumentToDelete: versionInSP = " + versionInSP);
      if (versionInSP.startsWith("@")) {
        versionInSP = versionInSP.substring(1);
      }
      System.out.println(
          "SharePointServices.verifyVersionOfDocumentToDelete: versionInSP (AFTER POSSIBLE MOD) = " + versionInSP);
      if (versionToBeDeleted.equals(versionInSP)) {
        found = true;
        break;
      }
    }
    if (!found) {
      throw new DocumentManagerException("version label = '" + versionToBeDeleted + "' does not exist");
    }
  }

  private boolean deleteWithBatchCommandScript(String strBatch) {
    boolean success = true;
    UpdateListItemsResponse.UpdateListItemsResult listItemsResult = null;
    ListsSoap listsSoap = null;
    UpdateListItems.Updates updates = null;
    try {
      Lists service = new Lists(new URL(siteName + "/_vti_bin/Lists.asmx?WSDL"));
      listsSoap = service.getListsSoap();
      Document document = DOMUtil.newDocumentFromXML(strBatch);
      updates = new UpdateListItems.Updates();
      List<Object> content = updates.getContent();
      content.add(document.getDocumentElement());
    } catch (IOException e) {
      e.printStackTrace();
      success = false;
    } catch (ParserException e) {
      e.printStackTrace();
      success = false;
    }
    try {
      listItemsResult = listsSoap.updateListItems(documentLibraryName, updates);
      parseResult(listItemsResult);
    } catch (SOAPFaultException e) {
      success = reportDeleteError(e);
    }
    return success;
  }

  private boolean reportDeleteError(SOAPFaultException e) {
    boolean success;//ToDo: Figure out the real error message stuff
    SOAPFault fault = e.getFault();
    System.out.println(
        "SharepointServices.testUploadDocument_ThenDeleteSameDocument: e.getMessage() = " + e.getMessage());
    Detail detail = fault.getDetail();
    System.out.println(
        "SharepointServices.testUploadDocument_ThenDeleteSameDocument: detail.toString() = " + detail.toString());
    System.out.println(
        "SharepointServices.testUploadDocument_ThenDeleteSameDocument: detail.getValue() = " + detail.getValue());
    Iterator entries = detail.getDetailEntries();
    while (entries.hasNext()) {
      Object o = entries.next();
      System.out
          .println("SharepointServices.testUploadDocument_ThenDeleteSameDocument: o.toString() = " + o.toString());
    }
    System.out.println("SharepointServices.testUploadDocument_ThenDeleteSameDocument: fault.getFaultActor() = " +
        fault.getFaultActor());
    System.out.println("SharepointServices.testUploadDocument_ThenDeleteSameDocument: fault.getFaultCode() = " +
        fault.getFaultCode());
    System.out.println("SharepointServices.testUploadDocument_ThenDeleteSameDocument: fault.getFaultString() = " +
        fault.getFaultString());
    System.out
        .println("SharepointServices.testUploadDocument_ThenDeleteSameDocument: e.toString() = " + e.toString());
    success = false;
    return success;
  }

  /**
   * Delete all versions of the given Documentum object id
   *
   * @param objectId the Documentum object id
   *
   * @exception DocumentManagerException
   */
  public boolean deleteAllVersionsById(String objectId) throws DocumentManagerException, IOException, ParserException,
      ParserConfigurationException {

      List<SearchResultEntity> list = getSearchResultEntityList(objectId, DocumentManagerConstants.SHAREPOINT_ATTR_ID, "", true);
      SearchResultEntity searchResultEntity = list.get(0);
      //String fileUrl = getFileLocation(objectId, "i_chronicle_id","");
      //List listItemIds = findListItemIdByName(fileUrl.substring(siteName.length()+1));
      // Added by ffbrac


      return deleteById(searchResultEntity.getId(), "ID", searchResultEntity.getFileRef());
  }

    /**
     * This method is added by ffbrac to fix the document download on search
     *
     * **/
    public RetrievedDocument retrieveDocumentAttributesNoDownload(SearchResultEntity searchResult,
                                                                  List requiredAttributes) throws
        AttributeListParseException, DocumentManagerException {
        RetrievedDocument retrievedDocument = new RetrievedDocument();

        retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_NAME, searchResult.getFileRef().substring(searchResult.getFileRef().lastIndexOf("/") + 1), null);
        retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, searchResult.getChronicleId(), null);
        setAttributeOnRetrievedDocument(retrievedDocument, false, DocumentManagerConstants.SHAREPOINT_ATTR_STR_TITLE, DocumentManagerConstants.ATTR_STR_TITLE, searchResult.getTitle(), requiredAttributes);
        setAttributeOnRetrievedDocument(retrievedDocument, true, DocumentManagerConstants.SHAREPOINT_ATTR_STR_KEYWORDS, DocumentManagerConstants.ATTR_STR_KEYWORDS, searchResult.getKeywords(), requiredAttributes);
        setAttributeOnRetrievedDocument(retrievedDocument, false, DocumentManagerConstants.SHAREPOINT_ATTR_DATE_CREATED, DocumentManagerConstants.ATTR_STR_DATE_CREATED, searchResult.getCreatedDate(), requiredAttributes);
        setAttributeOnRetrievedDocument(retrievedDocument, false, DocumentManagerConstants.SHAREPOINT_ATTR_DATE_MODIFIED, DocumentManagerConstants.ATTR_STR_DATE_MODIFIED, searchResult.getModifiedDate(), requiredAttributes);
        setAttributeOnRetrievedDocument(retrievedDocument, false, DocumentManagerConstants.SHAREPOINT_ATTR_STR_CREATOR, DocumentManagerConstants.ATTR_STR_CREATOR, searchResult.getCreator(), requiredAttributes);
        setAttributeOnRetrievedDocument(retrievedDocument, false, DocumentManagerConstants.SHAREPOINT_ATTR_STR_MODIFIER, DocumentManagerConstants.ATTR_STR_MODIFIER, searchResult.getEditor(), requiredAttributes);
        setAttributeOnRetrievedDocument(retrievedDocument, false, DocumentManagerConstants.SHAREPOINT_ATTR_STR_AUTHOR, DocumentManagerConstants.ATTR_STR_AUTHORS, searchResult.getAuthors(), requiredAttributes);
        setAttributeOnRetrievedDocument(retrievedDocument, false, DocumentManagerConstants.SHAREPOINT_ATTR_STR_SUBJECT, DocumentManagerConstants.ATTR_STR_SUBJECT, searchResult.getSubject(), requiredAttributes);
        setAttributeOnRetrievedDocument(retrievedDocument, false, DocumentManagerConstants.SHAREPOINT_ATTR_STR_OWNER, DocumentManagerConstants.ATTR_STR_OWNER, searchResult.getOwner(), requiredAttributes);
        setAttributeOnRetrievedDocument(retrievedDocument, false, DocumentManagerConstants.SHAREPOINT_ATTR_STR_SIZE, DocumentManagerConstants.ATTR_STR_SIZE, searchResult.getFileSize(), requiredAttributes);
        retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION, searchResult.getCurrVersion(), null);

      return retrievedDocument;
    }


    /**
     * Retrieve a given Document from Documentum using the objectId(documentId)
     *
     * @param documentAttributes
     * @param requiredAttributes List
     *
     * @return Map containing the retrieved file attributes
     *
     * @exception AttributeListParseException
     * @exception DocumentManagerException
     */
    public RetrievedDocument retrieveDocumentObjectWithAttributes_NoCopyService(DocumentAttributes documentAttributes,
                                                                  List requiredAttributes) throws
        AttributeListParseException, DocumentManagerException {
      String objectId = documentAttributes.getAttrValue(DocumentManagerConstants.SHAREPOINT_ATTR_STR_UNIQUE_DOCUMENT_ID);
      System.out.println("SharePointServices.retrieveDocumentObjectWithAttributes: objectId = " + objectId);
      SearchResultEntity searchResultEntity;
      String fileName = null;
      String fullPathURL = null;
      try {
        searchResultEntity = getSearchResultEntityList(objectId, "i_chronicle_id", "", true).get(0);
        fileName = searchResultEntity.getFileRef().substring(searchResultEntity.getFileRef().lastIndexOf("/") + 1);
        URL siteUrl = new URL(siteName);
        String portIfSpecified = siteUrl.getPort() != -1 ? new Integer(siteUrl.getPort()).toString() : "";
        fullPathURL = siteUrl.getProtocol() + "://" + siteUrl.getHost() + ":" + portIfSpecified + "/" + searchResultEntity.getFileRef();
        //copySoap = createCopyService(siteName + "/_vti_bin/Copy.asmx?WSDL");
      } catch (MalformedURLException e) {
        throw new DocumentManagerException(e);
      } catch (IOException e) {
        if (!StringUtils.isNullOrEmpty(fullPathURL)) {
          System.out.println("fullPathURL = " + fullPathURL);
        } else {
          System.out.println("Figure What's going wrong in getFullPathURL()");
        }
        throw new DocumentManagerException(e);
      } //catch (ParserException e) {
        //throw new DocumentManagerException(e);      }
      //catch (ParserConfigurationException e) {
      //  throw new DocumentManagerException(e);
      //}
      System.out.println("fileName = " + fileName);
      System.out.println("fullPathURL = " + fullPathURL);
      String absoluteTempFilePath;
        System.out.println("No Specific Version Requested");
          try{
              absoluteTempFilePath = copySharepointDocumentToDiskWithNoWebservice(fileName, fullPathURL.replaceAll(" ", "%20"));
              System.out.print("absoluteTempFilePath: " + absoluteTempFilePath);
          }catch (IOException e)
          {
              throw new DocumentManagerException("IOException occurred during copying file to temp location on server." + e.getMessage());
          }
      RetrievedDocument retrievedDocument = retrieveDocumentAttributesNoDownload(searchResultEntity, requiredAttributes);
      retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS, absoluteTempFilePath, null);
      return retrievedDocument;
    }
    /**
     * Retrieve a given Document from Documentum using the objectId(documentId)
     *
     * @param documentAttributes
     * @param requiredAttributes List
     *
     * @return Map containing the retrieved file attributes
     *
     * @exception AttributeListParseException
     * @exception DocumentManagerException
     */
    public RetrievedDocument retrieveDocumentObjectWithAttributes(DocumentAttributes documentAttributes,
                                                                  List requiredAttributes) throws
        AttributeListParseException, DocumentManagerException {
      String objectId = documentAttributes.getAttrValue(DocumentManagerConstants.SHAREPOINT_ATTR_STR_UNIQUE_DOCUMENT_ID);
      System.out.println("SharePointServices.retrieveDocumentObjectWithAttributes: objectId = " + objectId);
      CopySoap copySoap = null;
      String fileName = null;
      String fullPathURL = null;
      try {
        URL siteUrl = new URL(siteName);
        SearchResultEntity searchResultEntity = getSearchResultEntityList(objectId, DocumentManagerConstants.SHAREPOINT_ATTR_ID,"", true).get(0);
        fileName = searchResultEntity.getFileRef().substring(searchResultEntity.getFileRef().lastIndexOf("/") + 1);
        fullPathURL = getFullPathUrl(siteUrl, searchResultEntity);
        fileName = getFileName(objectId, "i_chronicle_id","");
        //System.out.println("fileName = " + fileName);
        //fullPathURL = getFullPathURL(objectId);
        copySoap = createCopyService(siteName + "/_vti_bin/Copy.asmx?WSDL");
      } catch (MalformedURLException e) {
        throw new DocumentManagerException(e);
      } catch (IOException e) {
        if (!StringUtils.isNullOrEmpty(fullPathURL)) {
          System.out.println("fullPathURL = " + fullPathURL);
        } else {
          System.out.println("Figure What's going wrong in getFullPathURL()");
        }
        throw new DocumentManagerException(e);
      } catch (ParserException e) {
        throw new DocumentManagerException(e);
      } catch (ParserConfigurationException e) {
        throw new DocumentManagerException(e);
      }
      //ToDo: Figure out how to support retrieval by version

      //Todo: ALL OF THIS WILL BE REPLACED BY A CALL TO VISHAL's CUSTOM WEB SERVICE
      //ToDo: The Versions service WILL NOT return meta-data for old versions
      System.out.println("CHECKING FOR VERSION");
      RetrievedDocument retrievedDocument = null;
      String absoluteTempFilePath = null;
      if (documentAttributes.containsAttribute(DocumentManagerConstants.SHAREPOINT_ATTR_VERSION)) {
        String versionRequested = documentAttributes.getAttrValue(DocumentManagerConstants.SHAREPOINT_ATTR_VERSION);
        System.out.println("Requesting version: " + versionRequested);
          VersionsSoap versionsSoap =null;
          try{
              versionsSoap = createVersionsService(siteName + "/_vti_bin/versions.asmx?WSDL");
          }catch (MalformedURLException e) {
              throw new DocumentManagerException(e);
          }
        String getVersionsParam = fullPathURL;
        System.out.println("getVersionsParam = " + getVersionsParam);
        GetVersionsResponse.GetVersionsResult getVersionsResult = versionsSoap
            .getVersions(getVersionsParam);
        List<Object> versions = getVersionsResult.getContent();
        Element version = (Element) versions.get(0);
        //ToDo: Do an XPath to get the "result" node with "version" = myVersion or @myVersion
        try {
          String xmlString = DOMUtil.XMLToString(version);
          xmlString = xmlString.replace("xmlns=\"http://schemas.microsoft.com/sharepoint/soap/\"", "");
          System.out.println("SharePointServices.retrieveDocumentObjectWithAttributes: xmlString = " + xmlString);
          Document document = DOMUtil.stringToXML(xmlString);
          System.out.println("begin SP retrivieresults.SharePointServices.retrieveDocumentObjectWithAttributes");
          DOMUtil.outputXML(document);
          System.out.println("end SP retrivieresults.SharePointServices.retrieveDocumentObjectWithAttributes");
          String xpathString = "/results/result[@version[string(\"" + versionRequested + "\")]]/@url";
          System.out.println("SharePointServices.retrieveDocumentObjectWithAttributes: xpathString = " + xpathString);
          String urlValue = XPathAPI.eval(document, xpathString).toString();

          System.out.println("SharePointServices.retrieveDocumentObjectWithAttributes: urlValue = " + urlValue);

          String encodedPathUrl = URIUtil.encodePath(urlValue);
          System.out.println("encodedPathUrl = " + encodedPathUrl);
          URI uri = new URI(encodedPathUrl);
          System.out.println("uri = " + uri);
          URL url = uri.toURL();
          System.out.println("url = " + url);
          URLConnection uc = url.openConnection();
          InputStream str = uc.getInputStream();

          //ToDo: Is this an OK way to do it?
          absoluteTempFilePath = writeFileToTempLocation(fileName, getResultFromStream(uc), fullPathURL);
          System.out.println(
              "SharePointServices.retrieveDocumentObjectWithAttributes: absoluteTempFilePath = " + absoluteTempFilePath);
          retrievedDocument = setAttributesFromDocument(requiredAttributes, document, versionRequested);
        } catch (TransformerException e) {
          throw new DocumentManagerException(e);
        } catch (ParserException e) {
          throw new DocumentManagerException(e);
        } catch (URISyntaxException e) {
          throw new DocumentManagerException(e);
        } catch (IOException e) {
            throw new DocumentManagerException(e);
        }

      } else {
        System.out.println("No Specific Version Requested");
        Holder<FieldInformationCollection> heldFields = new Holder<FieldInformationCollection>();
          try{
              absoluteTempFilePath = copySharepointDocumentToDisk(copySoap, fileName, heldFields, fullPathURL);
              System.out.print("absoluteTempFilePath: " + absoluteTempFilePath);
          }catch (IOException e)
          {
              throw new DocumentManagerException("IOException occurred during copying file to temp location on server." + e.getMessage());
          }
        retrievedDocument = setAttributesFromHeldInformation(requiredAttributes, heldFields);

      }
      retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_NAME, fileName, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS, absoluteTempFilePath, null);

      return retrievedDocument;
    }

    private String getFullPathUrl(URL siteUrl, SearchResultEntity searchResultEntity) {
        String fullPathURL;
        String portIfSpecified = siteUrl.getPort() != -1 ? new Integer(siteUrl.getPort()).toString() : "";
        fullPathURL = siteUrl.getProtocol() + "://" + siteUrl.getHost() + ":" + portIfSpecified + "/" + searchResultEntity.getFileRef();
        return fullPathURL;
    }

    /*private String getFullPathURL(String objectId) throws IOException, ParserException, ParserConfigurationException {
    ListsSoap listsSoap = setupListsService();
    String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
        "<Query>" +
        "<Where>" +
        "<Contains>" +
        "<FieldRef Name='i_chronicle_id' />" +
        "<Value Type='Text'>" + objectId + "</Value>" +
        "</Contains>" +
        "</Where>" +
        "</Query>";
    System.out.println("SharePointServices.getFullPathURL strQuery = " + strQuery);
    Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
    System.out.println("queryDoc.begin.SharePointServices.getFullPathURL");
    DOMUtil.outputXML(queryDoc);
    System.out.println("queryDoc.end.SharePointServices.getFullPathURL");
    GetListItems.Query query = new GetListItems.Query();
    List<Object> content = query.getContent();
    content.add(queryDoc.getDocumentElement());
    GetListItems.QueryOptions queryOptions = generateQueryOptions("", true);
    GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
        .getListItems(documentLibraryName, "", query, null, null, queryOptions, "");
    Element listResult = (Element) scannedImagesResult.getContent().get(0);
    System.out.println("listResult.begin.SharePointServices.getFullPathURL");
    DOMUtil.outputXML(listResult);
    System.out.println("listResult.end.SharePointServices.getFullPathURL");
    NodeList list = listResult.getElementsByTagName("z:row");
    if (list == null || list.item(0) == null) {
//      DOMUtil.outputXML(listResult);
      throw new IOException(
          "getFullPathURL(" + objectId + ")" + DOMUtil.dumpToString(queryDoc) + 
              DOMUtil.dumpToString(DOMUtil.newDocument(listResult)));
    }
    NamedNodeMap attributes = list.item(0).getAttributes();
    String owsFileRef = attributes.getNamedItem("ows_FileRef").getNodeValue();
    System.out.println("SharePointServices.getFullPathURL");
    System.out.println("owsFileRef = \"" + owsFileRef + "\"");
    URL siteUrl = new URL(siteName);
    String textToGetToTheRightOf = ";#";
    String FullPathPlusFileOnly = owsFileRef
        .substring(owsFileRef.lastIndexOf(textToGetToTheRightOf) + textToGetToTheRightOf.length());
    String portIfSpecified = siteUrl.getPort() != -1 ? new Integer(siteUrl.getPort()).toString() : "";
    String completeFullPath =
        siteUrl.getProtocol() + "://" + siteUrl.getHost() + ":" + portIfSpecified + "/" + FullPathPlusFileOnly;
    System.out.println("completeFullPath = " + completeFullPath);
    return completeFullPath;
  }*/

  private RetrievedDocument setAttributesFromDocument(List requiredAttributes, Document document,
                                                      String versionRequested) throws TransformerException {

    //ToDo: WILL GO AWAY ONCE WE SWITCH TO VISHAL's CUSTOM WEB SERVICE
    RetrievedDocument retrievedDocument = new RetrievedDocument();
    XObject xObject = XPathAPI.eval(document, "/results/result[@version=" + versionRequested + "]");
    NodeList nodeList = xObject.nodelist();
    System.out.println("SharePointServices.setAttributesFromDocument: nodeList.getLength() = " + nodeList.getLength());
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      NamedNodeMap atts = node.getAttributes();
      for (int j = 0; j < atts.getLength(); j++) {
        Node attNode = atts.item(j);
        if (attNode == null) {
          System.out.println("NODE IS NULL");
        } else {
          System.out.println("GOT A GOOD ATTRIBUTE");
        }
      }
      setAttributeOnRetrievedDocumentFromVersionedResult(retrievedDocument, atts,
          DocumentManagerConstants.SHAREPOINT_ATTR_ID,
          DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
      setAttributeOnRetrievedDocumentFromVersionedResult(retrievedDocument, atts,
          DocumentManagerConstants.SHAREPOINT_ATTR_VERSION,
          DocumentManagerConstants.ATTR_STR_VERSION);

      setMappedRequiredAttributeFromVersionedResult(requiredAttributes, retrievedDocument, atts,
          DocumentManagerConstants.ATTR_STR_KEYWORDS,
          DocumentManagerConstants.SHAREPOINT_ATTR_STR_KEYWORDS);
      setMappedRequiredAttributeFromVersionedResult(requiredAttributes, retrievedDocument, atts,
          DocumentManagerConstants.ATTR_STR_SUBJECT,
          DocumentManagerConstants.SHAREPOINT_ATTR_SUBJECT);
      setMappedRequiredAttributeFromVersionedResult(requiredAttributes, retrievedDocument, atts,
          DocumentManagerConstants.ATTR_STR_SIZE,
          DocumentManagerConstants.SHAREPOINT_ATTR_STR_SIZE);
      setMappedRequiredAttributeFromVersionedResult(requiredAttributes, retrievedDocument, atts,
          DocumentManagerConstants.ATTR_STR_CREATOR,
          DocumentManagerConstants.SHAREPOINT_ATTR_STR_CREATOR);

        // Added by Vishal
        setMappedRequiredAttributeFromVersionedResult(requiredAttributes, retrievedDocument, atts,
            DocumentManagerConstants.ATTR_STR_DATE_CREATED,
            DocumentManagerConstants.SHAREPOINT_ATTR_DATE_CREATED);
        setMappedRequiredAttributeFromVersionedResult(requiredAttributes, retrievedDocument, atts,
            DocumentManagerConstants.ATTR_STR_DATE_MODIFIED,
            DocumentManagerConstants.SHAREPOINT_ATTR_DATE_MODIFIED);
        setMappedRequiredAttributeFromVersionedResult(requiredAttributes, retrievedDocument, atts,
            DocumentManagerConstants.ATTR_STR_MODIFIER,
            DocumentManagerConstants.SHAREPOINT_ATTR_STR_MODIFIER);
        // Added by Vishal

    }
    return retrievedDocument;
  }

  private void setMappedRequiredAttributeFromVersionedResult(List requiredAttributes,
                                                             RetrievedDocument retrievedDocument,
                                                             NamedNodeMap atts, String requiredAttribute,
                                                             String sharepointAttrName) {
    if (requiredAttributes.contains(sharepointAttrName)) {
      setAttributeOnRetrievedDocumentFromVersionedResult(retrievedDocument, atts, sharepointAttrName,
          requiredAttribute);
    }
  }

  private void setAttributeOnRetrievedDocumentFromVersionedResult(RetrievedDocument retrievedDocument,
                                                                  NamedNodeMap atts,
                                                                  String sharepointAttrName,
                                                                  String retrievedDocumentAttributeName) {
    Node node = atts.getNamedItem(sharepointAttrName);
    if (node == null) System.out.println("Node is NULL for attribute: " + sharepointAttrName);
    if (node != null && node.getNodeName().equalsIgnoreCase(sharepointAttrName)) {
      System.out.println(
          "(Versioned) SETTING ATTR " + retrievedDocumentAttributeName + " from SP Attr Name: " + sharepointAttrName);
      String value = node.getNodeValue();
      value = stripCreatorIfNeeded(retrievedDocumentAttributeName, value);
      retrievedDocument.getDocumentAttributes().addAttribute(retrievedDocumentAttributeName, value, null);
    }
  }

  private byte[] getResultFromStream(URLConnection uc) throws IOException {
    int contentLength = uc.getContentLength();
    InputStream rawStream = uc.getInputStream();
    InputStream in = new BufferedInputStream(rawStream);
    byte[] data = new byte[contentLength];
    int bytesRead = 0;
    int offset = 0;
    while (offset < contentLength) {
      bytesRead = in.read(data, offset, data.length - offset);
      if (bytesRead == -1)
        break;
      offset += bytesRead;
    }
    in.close();
    return data;
  }


  private void readStreamIntoStringBuffer(InputStream in, StringBuffer strBuffer) throws IOException {
    int len = 0;
    byte[] read = new byte[8192];
    while ((len = in.read(read)) != -1) {
      strBuffer.append(new String(read, 0, len));
    }
    in.close();
  }

  /**
   * Checks whether the given Documentum folder name exists in Documentum
   *
   * @param name   Documentum folder name
   * @param parent Documentum context info
   *
   * @return true if the Documentum folder already exists. Return false if no such folder exists
   *
   * @exception DocumentManagerException
   */
  public boolean existFolderByName(String name, String parent) throws DocumentManagerException {
    return false;
  }

  /**
   * Create a Documentum folder
   *
   * @param root      the folder name to create
   * @param directory the context
   *
   * @exception DocumentManagerException
   * @see #createFolder(String, String)
   */

  public void createFolder(String root, String directory) throws DocumentManagerException {

    //ToDo: parse error response better see http://ronaldlemmen.blogspot.com/2010/04/sharepoint-error-message-0x8107026f.html for error code definitions
    Lists service = null;  ListsSoap listsSoap = null;
    try {
        listsSoap = setupListsService();
    } catch (MalformedURLException e) {
      throw new DocumentManagerException(
          String.format("There was a problem creating a folder: I caught a %s exception with a message of \"%s\"",
              e.getClass().getName(), e.getMessage()), e);
    }
      String strBatch = "<Batch OnError=\"Continue\" PreCalc=\"TRUE\">\n" +
        "   <Method ID=\"1\" Cmd=\"New\">\n" +
        "      <Field Name=\"ID\">New</Field>\n" +
        "      <Field Name=\"FSObjType\">1</Field>\n" +
        "      <Field Name=\"BaseName\">" + root + "/" + directory + "</Field>\n" +
        "   </Method>\n" +
        "</Batch>";
    System.out.println("createFolder strBatch = " + strBatch);
    Document document = null;
    try {
      document = DOMUtil.newDocumentFromXML(strBatch);
    } catch (IOException e) {
      throw new DocumentManagerException(
          String.format("There was a problem creating a folder: I caught a %s exception with a message of \"%s\"",
              e.getClass().getName(), e.getMessage()), e);
    } catch (ParserException e) {
      e.printStackTrace();
    }
    UpdateListItems.Updates updates = new UpdateListItems.Updates();
    List<Object> content = updates.getContent();
    content.add(document.getDocumentElement());
    UpdateListItemsResponse.UpdateListItemsResult listItemsResult = null;
    try {
        // EXCEPTION HERE
      listItemsResult = listsSoap.updateListItems(documentLibraryName, updates);
        // EXCEPTION HERE
      try {
        String resultCode = getErrorCodeFromListsResult(listItemsResult);
        System.out.println("resultCode = " + resultCode);
        if (!resultCode.equals("0x00000000")) {
          if (resultCode.equals("0x81020073")) {
            throw new DocumentManagerException(
                "The folder you are trying to create, \"" + directory + "\" contains invalid characters");
          } else {
            if (resultCode.equals("0x8107090d")) {
            } else {

              throw new DocumentManagerException(
                  "There was a problem creating a folder. The updateLists service returned a result code of: " +
                      resultCode);
            }

          }
        }
      }
      catch (DocumentManagerException
          e) {
        throw new DocumentManagerException(
            String.format("There was a problem creating a folder: I caught a %s exception with a message of \"%s\"",
                e.getClass().getName(), e.getMessage()), e);
      }
      parseResult(listItemsResult);
    } catch (SOAPFaultException e) {
      SOAPFault fault = e.getFault();
      System.out.println(
          "SharepointServices_AT.testUploadDocument_ThenDeleteSameDocument: e.getMessage() = " + e.getMessage());
      Detail detail = fault.getDetail();
      System.out.println(
          "SharepointServices_AT.testUploadDocument_ThenDeleteSameDocument: detail.toString() = " +
              detail.toString());
      System.out.println(
          "SharepointServices_AT.testUploadDocument_ThenDeleteSameDocument: detail.getValue() = " +
              detail.getValue());
      Iterator entries = detail.getDetailEntries();
      while (entries.hasNext()) {
        Object o = entries.next();
        System.out
            .println(
                "SharepointServices_AT.testUploadDocument_ThenDeleteSameDocument: o.toString() = " + o.toString());
      }
      System.out.println("SharepointServices_AT.testUploadDocument_ThenDeleteSameDocument: fault.getFaultActor() = " +
          fault.getFaultActor());
      System.out.println("SharepointServices_AT.testUploadDocument_ThenDeleteSameDocument: fault.getFaultCode() = " +
          fault.getFaultCode());
      System.out
          .println("SharepointServices_AT.testUploadDocument_ThenDeleteSameDocument: fault.getFaultString() = " +
              fault.getFaultString());
      System.out
          .println("SharepointServices_AT.testUploadDocument_ThenDeleteSameDocument: e.toString() = " + e.toString());
    }
  }

  private String getErrorCodeFromListsResult(UpdateListItemsResponse.UpdateListItemsResult listItemsResult) throws
      DocumentManagerException {
    Element result = (Element) listItemsResult.getContent().get(0);
    NodeList list = result.getElementsByTagName("Result");
    System.out.println("SharepointServices.parseResult: list.getLength() = " + list.getLength());
    for (int j = 0; j < list.getLength(); j++) {
      Node node = list.item(j);
      System.out.println("SharepointServices.parseResult: node.getNodeName() = " + node.getNodeName());
      if (node.getNodeName().equals("Result")) {
        String errorCode = null;
        try {
          errorCode = getAttributeValueFromUpdateListsResultChildrenList(node.getChildNodes(), "ErrorCode");
        } catch (DocumentManagerException e) {
          throw new DocumentManagerException(
              "Error creating folders: Result from Lists service is in an unexpected format.: " + e.getMessage(), e);
        }
        return errorCode;
      }
    }
    throw new DocumentManagerException("Error creating folders: Result from Lists service is in an unexpected format.");
  }

  private String getAttributeValueFromUpdateListsResultChildrenList(NodeList nodeList, String nodeNameToFind) throws
      DocumentManagerException {
    String foundValue = null;
    for (int k = 0; k < nodeList.getLength(); k++) {
      Node node = nodeList.item(k);
      String nodeName = node.getNodeName();
      DOMUtil.outputXML(node);
      if (nodeName.equals(nodeNameToFind)) {
        foundValue = node.getTextContent();
        break;
      }
    }
    if (!StringUtils.isNullOrEmpty(foundValue)) {
      return foundValue;
    } else {
      throw new DocumentManagerException("Node name " + nodeNameToFind + " not found.");
    }
  }

  // null pointer exception - fixed by Vishal.
  public void search(String queryString, SearchSharePointRequestEntity requestEntity,
                     ResponseEntity responseEntity) throws DocumentManagerException {
    System.out.println("SharePointServices.search");
    System.out.println("requestEntity/directoryStructure = " + requestEntity +">>>>" + requestEntity.getDirectoryStructure());
    try {
      ListsSoap service = setupListsService();
      GetListItems.Query query = new GetListItems.Query();
      List<Object> content = query.getContent();
      if (!StringUtils.isNullOrEmpty(queryString)) {
        Document queryDoc = DOMUtil.newDocumentFromXML(queryString);
        content.add(queryDoc.getDocumentElement());
        System.out.println("SharePointServices.search: documentLibraryName = " + documentLibraryName);
        DOMUtil.outputXML(queryDoc);
      }
      GetListItemsResponse.GetListItemsResult result = service
          .getListItems(documentLibraryName, "", query, null, null, generateQueryOptions(requestEntity.getDirectoryStructure(), true), "");
      System.out.println("SUCCESSFUL CALL TO GetListItems Service for SEARCH");
      Element listResult = (Element) result.getContent().get(0);
      DOMUtil.outputXML(listResult);
      NodeList list = listResult.getElementsByTagName("z:row");
      int length = list.getLength();
      System.out.println("NodeList.gtLength() = " + length);
      for (int i = 0; i < length; i++) {
          SearchResultEntity searchResult = SetupSearchResultEntity(list.item(i));
        RetrievedDocument retrievedDocument = retrieveDocumentAttributesNoDownload(searchResult, requestEntity.getRequiredAttributes());
        responseEntity.getRetrievedDocumentList().add(retrievedDocument);
      }
    } catch (Throwable e) {
      handleSearchException(e);
    }
  }

    private SearchResultEntity SetupSearchResultEntity(Node node) {
        NamedNodeMap attributes = node.getAttributes();
        SearchResultEntity searchResult = new SearchResultEntity(
                getAttributeValue(attributes.getNamedItem("ows_ID")),
                getAttributeValue(attributes.getNamedItem("ows_i_chronicle_id")),
                getAttributeValue(attributes.getNamedItem("ows_FileRef")),
                getAttributeValue(attributes.getNamedItem("ows_Title")),
                getAttributeValue(attributes.getNamedItem("ows_object_name")),
                getAttributeValue(attributes.getNamedItem("ows_r_object_type")),
                getAttributeValue(attributes.getNamedItem("ows_r_object_id")),
                getAttributeValue(attributes.getNamedItem("ows_Keywords")),
                getAttributeValue(attributes.getNamedItem("ows_r_version_label")),
                getAttributeValue(attributes.getNamedItem("ows_Created_x0020_Date")),
                getAttributeValue(attributes.getNamedItem("ows_Modified")),
                getAttributeValue(attributes.getNamedItem("ows_Editor")),
                getAttributeValue(attributes.getNamedItem("ows_Editor")),
                getAttributeValue(attributes.getNamedItem("ows_FileSizeDisplay")),
                getAttributeValue(attributes.getNamedItem("ows__UIVersionString")),
                getAttributeValue(attributes.getNamedItem("ows_Authors")),
                getAttributeValue(attributes.getNamedItem("ows_subject")),
                getAttributeValue(attributes.getNamedItem("ows_Owner")));
        return searchResult;
    }

    private String getAttributeValue(Node attr) {
        if(attr != null){
            String value = attr.getNodeValue();
            if(value.contains(";#")) value = value.substring(value.indexOf(";#") + 2);
            return value;
        }

        return "";
    }

    private void handleSearchException(Throwable e) throws DocumentManagerException {
    System.out.println("SharePointServices.handleSearchException: e.toString() = " + e.toString());
    e.printStackTrace();
    throw new DocumentManagerException(e);
  }


  /**
   * Returns an integer constant, stating the type of the attribute. Defaults to String, if attribute not found (Dctm
   * behavior).
   *
   * @param attributeName
   * @param sysObj
   *
   * @return
   *
   * @exception com.documentum.fc.common.DfException
   *
   */
  //ToDo: Work out mechanism to retrieve and assign types for SharePointAttributes; the closest approximation to a SysObject we have in SP is the FieldInformationCollection
  public int lookupAttributeType(String attributeName, IDfSysObject sysObj) throws DfException {
    return 0;
  }

  /**
   * Returns true if attribute is repeating, false if it is single.
   *
   * @param attributeName
   * @param sysObj
   *
   * @return
   *
   * @exception com.documentum.fc.common.DfException
   *
   */
  //ToDo: figure out if we can continue the conceopt of reapeating valued attributes in SP - YES - it goes into an SP FieldType.NOTE field
  //ToDo: [lakench; 6-7-10]: I hope this doesn't cause issues as the multiple line of text column type is not a 1-D array like a repeating-valued attribute is in Documentum
  public boolean isAttributeRepeating(String attributeName, IDfSysObject sysObj) throws DfException {
    return false;
  }

  public void delete(String objectId, DocumentAttributes documentAttributes, ResponseEntity responseEntity) throws
      DocumentManagerException {
    String versionToBeDeleted;
    boolean deletedSuccessfully;
    try {
      if (documentAttributes.containsAttribute(DocumentManagerConstants.ATTR_STR_VERSION)) {
        versionToBeDeleted = documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_VERSION);
        deletedSuccessfully = deleteByIdAndVersion(objectId, versionToBeDeleted);
      } else {
        versionToBeDeleted = DocumentManagerConstants.RESP_CONST_ALL_VERSIONS_DELETED;
        deletedSuccessfully = deleteAllVersionsById(objectId);
      }
      if (deletedSuccessfully) {
        addDeletedDocumentDetailsToResponse(objectId, versionToBeDeleted, responseEntity);
      } else {
        throw new DocumentManagerException();
      }
    } catch (Exception e) {
      System.out.println("SharePointServices.delete: returned exception = " + e.getMessage());
      throw new DocumentManagerException(e);
    }
  }

  public IDfSysObject instantiateSysObject() throws DocumentManagerException {
    return null;
  }

  /**
   * Updates the document with new/modified contents/attributes as new version
   *
   * @param updateSharePointRequestEntity
   * @param newContentsLocation
   *
   * @return RetrievedDocument
   */
  public RetrievedDocument update(UpdateSharePointRequestEntity updateSharePointRequestEntity,

                                  String newContentsLocation) throws AttributeListParseException,
      DocumentManagerException {
    DocumentAttributes documentAttributes = updateSharePointRequestEntity.getDocumentAttributes();
    RetrievedDocument retrievedDocument = new RetrievedDocument();
    String chronicleId = getChronicleIdFromRequest(documentAttributes);
    ListsSoap listsSoap = null;
    String fileUrl =null;
    try {
      listsSoap = setupListsService();
      fileUrl = getFileLocation(chronicleId,"i_chronicle_id",updateSharePointRequestEntity.getDirectoryStructure());
       if (!StringUtils.isNullOrEmpty(newContentsLocation)) {
          performCheckout(chronicleId, fileUrl, listsSoap);
          List IDs = getFileID(chronicleId,"i_chronicle_id");
          String strUpdateBatch = getUpdateBatchStr(updateSharePointRequestEntity, IDs.get(0).toString());
          applyNewContentAndUpdate(newContentsLocation, fileUrl, strUpdateBatch, listsSoap);
          performCheckin(updateSharePointRequestEntity, fileUrl, listsSoap);
       }
      } catch (MalformedURLException e) {
        throw new DocumentManagerException("Error in update rolling back: " + e.toString());
      } catch (IOException e) {
        throw new DocumentManagerException("Error in update rolling back: " + e.toString());
      } catch (ParserException e) {
        throw new DocumentManagerException("Error in update rolling back: " + e.toString());
      } catch(ParserConfigurationException e){
      throw new DocumentManagerException("Error in update rolling back: " + e.toString());
    }
     String updatedVersion = null;
    try {
      updatedVersion = getVersion(fileUrl);
    } catch (IOException e) {
      throw new DocumentManagerException("Error getting new version after update: " + e.toString());
    }catch (ParserException e) {
      throw new DocumentManagerException("Error getting new version after update: " + e.toString());
    }
    return createRetrievedDocumentWithObjectIdAndVersion(retrievedDocument, chronicleId, updatedVersion);
  }

  // by Vishal.
  private void applyNewContentAndUpdate(String newContentsLocation, String fileUrl, String strUpdateBatch, ListsSoap listsSoap)
          throws AttributeListParseException, IOException, ParserException {
    String nullUrl = "http://null";
    String fileNameInSP = fileUrl.substring(fileUrl.lastIndexOf("/")+1);
    System.out.println("SharePointTestUtil.updateDocument: fileNameInSP = " + fileNameInSP);
    CopySoap copySoap = createCopyService(siteName + "/_vti_bin/Copy.asmx?WSDL");

    DestinationUrlCollection destUrls = setupDestinationUrls(fileUrl, "");
    //byte[] stream = FileUtil.fileToByteArray(newContentsLocation);
    byte[] stream = readFileInChunks(newContentsLocation);
    FieldInformationCollection fields = new FieldInformationCollection();
    List<FieldInformation> fieldInformationList = fields.getFieldInformation();
    Holder<Long> result = new Holder<Long>();
    Holder<CopyResultCollection> results = new Holder<CopyResultCollection>();
    copySoap.copyIntoItems(nullUrl, destUrls, fields, stream, result, results);
    parseCopyResult(results);
    runListUpdate(listsSoap, strUpdateBatch);
  }
  private void updateAttributes(UpdateSharePointRequestEntity requestEntity, String ID,
                                ListsSoap listsSoap) throws AttributeListParseException, IOException, ParserException {
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    Iterator iterator = documentAttributes.getAttrIterator();
    String strBatch = "<?xml version='1.0' encoding='UTF-8'?><Batch>" +
        "<Method ID='1' Cmd='Update'>" +
        "<Field Name='ID'>" + ID + "</Field>";
    boolean gotOne = false;
    while (iterator.hasNext()) {
      String key = (String) iterator.next();
      System.out.println("SharePointServices.updateAttributes: key = " + key);
      String value = "";
      if (documentAttributes.hasMultipleValues(key)) {
        List list = documentAttributes.getAttrValues(key);
        for (Object aList : list) {
          String attr = (String) aList;
          System.out.println("SharePointServices.updateAttributes: attr = " + attr);
          if (value.length() == 0) {
            value = attr;
          } else {
            value = value + CR_LF + attr;
          }
        }
        System.out.println("SharePointServices.updateAttributes: valueString = " + value);
      } else {
        value = documentAttributes.getAttrValue(key);
      }
      System.out.println("SharePointServices.updateAttributes: value = " + value);

      System.out.println("SharePointServices.updateAttributes: strBatch = " + strBatch);

      if (!key.equals(DocumentManagerConstants.SHAREPOINT_ATTR_STR_UNIQUE_DOCUMENT_ID) &&
          !key.equals(DocumentManagerConstants.ATTR_STR_UPDATE_VERSION)) {
        gotOne = true;
        strBatch = strBatch + "<Field Name='" + key + "'>" + value + "</Field>";
      }
    }
    if (gotOne) {
      strBatch = strBatch + "</Method></Batch>";
      runListUpdate(listsSoap, strBatch);
    }
  }

  private String getUpdateBatchStr(UpdateSharePointRequestEntity requestEntity, String ID)
          throws AttributeListParseException, IOException, ParserException
  {
     DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    Iterator iterator = documentAttributes.getAttrIterator();
    String strBatch = "<?xml version='1.0' encoding='UTF-8'?><Batch>" +
        "<Method ID='1' Cmd='Update'>" +
        "<Field Name='ID'>" + ID + "</Field>";
    boolean gotOne = false;
    while (iterator.hasNext()) {
      String key = (String) iterator.next();
      String value = "";
      if (documentAttributes.hasMultipleValues(key)) {
        List list = documentAttributes.getAttrValues(key);
        for (Object aList : list) {
          String attr = (String) aList;
          System.out.println("SharePointServices.updateAttributes: attr = " + attr);
          if (value.length() == 0) {
            value = attr;
          } else {
            value = value + SEMI_COLON + attr;
          }
        }
      } else {
        value = documentAttributes.getAttrValue(key);
      }
      if (!key.equals(DocumentManagerConstants.SHAREPOINT_ATTR_STR_UNIQUE_DOCUMENT_ID) &&
          !key.equals(DocumentManagerConstants.ATTR_STR_UPDATE_VERSION)) {
        gotOne = true;
        strBatch = strBatch + "<Field Name='" + getSPMappedKeys(key) + "'>" + value + "</Field>";
      }
    }
    //if (gotOne) {
      strBatch = strBatch + "</Method></Batch>";
    //}
    return strBatch;
  }


  private String getSPMappedKeys(String requestedKey)
  {
      String SPAttribute = null;
      if (requestedKey.equals(DocumentManagerConstants.ATTR_STR_AUTHORS))
            SPAttribute = DocumentManagerConstants.SHAREPOINT_ATTR_STR_AUTHOR;
      else if (requestedKey.equals(DocumentManagerConstants.ATTR_STR_KEYWORDS))
           SPAttribute = DocumentManagerConstants.SHAREPOINT_ATTR_STR_KEYWORDS;
      else if (requestedKey.equals(DocumentManagerConstants.ATTR_STR_SUBJECT))
           SPAttribute = DocumentManagerConstants.SHAREPOINT_ATTR_STR_SUBJECT;
      else
           SPAttribute =  requestedKey;
      return SPAttribute;
  }
  
  private String getVersion(String fileUrl) throws IOException, ParserException {
    VersionsSoap versionsSoap = createVersionsService(siteName + "/_vti_bin/versions.asmx?WSDL");
    GetVersionsResponse.GetVersionsResult getVersionsResult = versionsSoap
        .getVersions(fileUrl);
    List<Object> versions = getVersionsResult.getContent();
    System.out.println("SharepointServices_AT.testUploadDocument: versions.size() = " + versions.size());
    Element element = (Element) versions.get(0);
    DOMUtil.outputXML(element);
    NodeList list = element.getElementsByTagName("result");
    System.out.println("SharepointServices_AT.testUploadDocument: list.getLength() = " + list.getLength());
    Node node = list.item(0);
    NamedNodeMap map = node.getAttributes();
    String answerVersion = "";
    for (int k = 0; k < map.getLength(); k++) {
      Node attrNode = map.item(k);
      if (attrNode.getNodeName().equals("version")) {
        answerVersion = attrNode.getNodeValue();
      }
    }
    if (answerVersion.startsWith("@")) {
      answerVersion = answerVersion.substring(1);
    }
    return answerVersion;
  }
  private String getVersion(String directoryStructure,String fileName) throws IOException, ParserException {
    if (directoryStructure !=null && !directoryStructure.isEmpty())
        directoryStructure += "/";
    VersionsSoap versionsSoap = createVersionsService(siteName + "/_vti_bin/versions.asmx?WSDL");
    GetVersionsResponse.GetVersionsResult getVersionsResult = versionsSoap
        .getVersions(siteName + "/" + documentLibraryName + "/" + directoryStructure + fileName);
    List<Object> versions = getVersionsResult.getContent();
    System.out.println("SharepointServices_AT.testUploadDocument: versions.size() = " + versions.size());
    Element element = (Element) versions.get(0);
    DOMUtil.outputXML(element);
    NodeList list = element.getElementsByTagName("result");
    System.out.println("SharepointServices_AT.testUploadDocument: list.getLength() = " + list.getLength());
    Node node = list.item(0);
    NamedNodeMap map = node.getAttributes();
    String answerVersion = "";
    for (int k = 0; k < map.getLength(); k++) {
      Node attrNode = map.item(k);
      if (attrNode.getNodeName().equals("version")) {
        answerVersion = attrNode.getNodeValue();
      }
    }
    if (answerVersion.startsWith("@")) {
      answerVersion = answerVersion.substring(1);
    }
    return answerVersion;
  }
  private void performCheckin(UpdateSharePointRequestEntity requestEntity, String fileUrl, ListsSoap listsSoap)
      throws AttributeListParseException, DocumentManagerException {
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    String versionUpdateType = null;
    if (documentAttributes.containsAttribute(DocumentManagerConstants.ATTR_STR_UPDATE_VERSION))
        versionUpdateType = documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_UPDATE_VERSION);

    System.out.println("SharePointServices.performCheckin: versionUpdateType = " + versionUpdateType);
    String checkInType = "";
    if (versionUpdateType == null || (versionUpdateType!=null && versionUpdateType.isEmpty()))
    {
       System.out.println("No attribute updateVersion requested..defaulting to Major");
       checkInType = "1";
    }
    else if (versionUpdateType.equals(DocumentManagerConstants.NEXT_MINOR_VERSION)) {
      System.out.println("Switching to Minor");
      checkInType = "0";
    } else if (versionUpdateType.equals(DocumentManagerConstants.NEXT_MAJOR_VERSION)) {
      checkInType = "1";
    } else if (versionUpdateType.equals(DocumentManagerConstants.SAME_VERSION)) {
      System.out.println("CHECKING IN WITH SAME VERSION");
      checkInType = "2";
    } else {
      throw new DocumentManagerException("Invalid Version update type specified in request: " + versionUpdateType);
    }
    System.out.println("SharePointServices.performCheckin: checkInType = " + checkInType);
    listsSoap.checkInFile(fileUrl, "", checkInType);
  }

  /*private void applyNewContent(String newContentsLocation, String fileUrl, ListsSoap listsSoap)
      throws AttributeListParseException, IOException, ParserException {
    String fileNameInSP = fileUrl.substring(fileUrl.lastIndexOf("/")+1);
    System.out.println("SharePointTestUtil.updateDocument: fileNameInSP = " + fileNameInSP);
    CopySoap copySoap = createCopyService(siteName + "/_vti_bin/Copy.asmx?WSDL");
    boolean success = listsSoap.checkOutFile(fileUrl, "true", null);
    System.out.println("TestUtil.testUploadDocument_WithNewVersion: success = " + success);
    DestinationUrlCollection destUrls = setupDestinationUrls(fileUrl, "");
    byte[] stream = FileUtil.fileToByteArray(newContentsLocation);
    FieldInformationCollection fields = new FieldInformationCollection();
    List<FieldInformation> fieldInformationList = fields.getFieldInformation();
    //ToDo: Do in loop over the attributes - try this one again later instead of the separate updateAttributes method
    //ToDo: The problem is that the old Documentum stuff expected the attributes to be a separate step and also, when
    //ToDo: we do that, we get an extra version in Sharepoint - either way, something goes wrong
//		addFieldToList(fieldInformationList, "Publisher", "TestPublisherValue");
//		setContentTypeForDocument(fieldInformationList, contentType);
    Holder<Long> result = new Holder<Long>();
    Holder<CopyResultCollection> results = new Holder<CopyResultCollection>();
    //ToDo: HERE IS THE SUPER-SECRET TRICK FROM THE BOTTOM OF THIS URL:
    //ToDo:  http://www.sharepointdev.net/sharepoint--development-programming/web-service-to-add-new-version-to-document-44572.shtml
    //ToDo: To Update to a new version with new content, ONLY USE THE FILE NAME AS THE URL, NOT THE FULL URL LIKE YOU DID
    //ToDo: ON THE INSERT.
    copySoap.copyIntoItems(fileNameInSP, destUrls, fields, stream, result, results);
    parseCopyResult(results);
  }  */


  private void runListUpdate(ListsSoap listsSoap, String strBatch) throws IOException, ParserException {
    UpdateListItemsResponse.UpdateListItemsResult listItemsResult;
    Document document = DOMUtil.newDocumentFromXML(strBatch);
    UpdateListItems.Updates updates = new UpdateListItems.Updates();
    List<Object> content = updates.getContent();
    content.add(document.getDocumentElement());
    try {
      listItemsResult = listsSoap.updateListItems(documentLibraryName, updates);
      parseResult(listItemsResult);
    } catch (SOAPFaultException e) {
      SOAPFault fault = e.getFault();
      System.out.println("SharePointServices.runListUpdate: e.getMessage() = " + e.getMessage());
      Detail detail = fault.getDetail();
      System.out.println("SharePointServices.runListUpdate: detail.toString() = " + detail.toString());
      System.out.println("SharePointServices.runListUpdate: detail.getValue() = " + detail.getValue());
      Iterator entries = detail.getDetailEntries();
      while (entries.hasNext()) {
        Object o = entries.next();
        System.out.println("SharePointServices.runListUpdate: o.toString() = " + o.toString());
      }
      System.out.println("SharePointServices.runListUpdate: fault.getFaultActor() = " + fault.getFaultActor());
      System.out.println("SharePointServices.runListUpdate: fault.getFaultCode() = " + fault.getFaultCode());
      System.out.println("SharePointServices.runListUpdate: fault.getFaultString() = " + fault.getFaultString());
      System.out.println("TestUtil.runListUpdate: e.toString() = " + e.toString());
    }
  }

  private static void parseCopyResult(Holder<CopyResultCollection> results) throws IOException{
    List<CopyResult> resultsList = results.value.getCopyResult();
    for (CopyResult copyResult : resultsList) {
      System.out.println(
          "SharePointTestUtil.parseCopyResult: copyResult.getDestinationUrl() = " + copyResult.getDestinationUrl());
      System.out.println(
          "SharePointTestUtil.parseCopyResult: copyResult.getErrorMessage() = " + copyResult.getErrorMessage());
      System.out.println("SharePointTestUtil.parseCopyResult: copyResult.getErrorCode().value() = " +
          copyResult.getErrorCode().value());
       if (!copyResult.getErrorCode().value().equalsIgnoreCase("Success") && !StringUtils.isNullOrEmpty(copyResult.getErrorMessage())) {
        throw new IOException(
            "Update Failed:  Copy Service returned an error of: \"" +
                copyResult.getErrorMessage() + "\"");
      }

    }
  }

  private static void setContentTypeForDocument(List<FieldInformation> fieldInformationList, String value) {
    //ToDo <FieldInformation Type=�Choice� DisplayName=�Content Type� InternalName=�ContentType� Value=�Word� />
    FieldInformation fieldInformation = new FieldInformation();
    fieldInformation.setType(FieldType.CHOICE);
    fieldInformation.setDisplayName(CONTENT_TYPE);
    fieldInformation.setInternalName("ContentType");
    fieldInformation.setValue(value);
    fieldInformationList.add(fieldInformation);

    fieldInformation = new FieldInformation();
    fieldInformation.setType(FieldType.TEXT);
    fieldInformation.setDisplayName(FILE_TYPE);
    fieldInformation.setInternalName(FILE_TYPE);
    fieldInformation.setValue(value);
    fieldInformationList.add(fieldInformation);

    fieldInformation = new FieldInformation();
    fieldInformation.setType(FieldType.COMPUTED);
    fieldInformation.setDisplayName(TYPE);
    fieldInformation.setInternalName(TYPE);
    fieldInformation.setValue(value);
    fieldInformationList.add(fieldInformation);
  }

  /**
   * In case the update fails...
   *
   * @exception com.documentum.fc.common.DfException
   *
   * @exception DocumentManagerException
   */
  public void cancelCheckoutDocument() throws DfException, DocumentManagerException {
  }

  private void performCheckout(String objectId, String fileUrl, ListsSoap listsSoap) throws DocumentManagerException,
      AttributeListParseException, IOException, ParserException {
    System.out.println("SharePointServices.performCheckout: fileNameInSP = " + fileUrl);
    boolean success = listsSoap.checkOutFile(fileUrl, "true", "");
    System.out.println("SharePointServices.performCheckout:success = " + success);
    if (!success) {
      throw new DocumentManagerException("performCheckout Failed");
    }
  }

  private RetrievedDocument setAttributesFromHeldInformation(List requiredAttributes,
                                                             Holder<FieldInformationCollection> heldFields) {
    RetrievedDocument retrievedDocument = new RetrievedDocument();
    FieldInformationCollection fieldInfoCollection = heldFields.value;
    List<FieldInformation> fieldList = fieldInfoCollection.getFieldInformation();
    Collections.sort(requiredAttributes);
    for (FieldInformation info : fieldList) {
      setAttributeOnRetrievedDocument(retrievedDocument, info, DocumentManagerConstants.SHAREPOINT_ATTR_ID,
          DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
      setAttributeOnRetrievedDocument(retrievedDocument, info, DocumentManagerConstants.SHAREPOINT_ATTR_VERSION,
          DocumentManagerConstants.ATTR_STR_VERSION);
      if (requiredAttributes.contains(info.getDisplayName().toLowerCase())) {
        setAttributeOnRetrievedDocument(retrievedDocument, info, info.getDisplayName().toLowerCase(), info.getDisplayName().toLowerCase());
      }
      setMappedRequiredAttribute(requiredAttributes, retrievedDocument, info,
          DocumentManagerConstants.ATTR_STR_TITLE,
          DocumentManagerConstants.SHAREPOINT_ATTR_STR_TITLE);
      setMappedRequiredAttribute(requiredAttributes, retrievedDocument, info,
          DocumentManagerConstants.ATTR_STR_KEYWORDS,
          DocumentManagerConstants.SHAREPOINT_ATTR_STR_KEYWORDS);
      setMappedRequiredAttribute(requiredAttributes, retrievedDocument, info, DocumentManagerConstants.ATTR_STR_SUBJECT,
          DocumentManagerConstants.SHAREPOINT_ATTR_SUBJECT);
      setMappedRequiredAttribute(requiredAttributes, retrievedDocument, info, DocumentManagerConstants.ATTR_STR_SIZE,
          DocumentManagerConstants.SHAREPOINT_ATTR_STR_SIZE);
      setMappedRequiredAttribute(requiredAttributes, retrievedDocument, info, DocumentManagerConstants.ATTR_STR_CREATOR,
          DocumentManagerConstants.SHAREPOINT_ATTR_STR_CREATOR);

        // Added By Vishal
        setMappedRequiredAttribute(requiredAttributes, retrievedDocument, info, DocumentManagerConstants.ATTR_STR_DATE_CREATED,
            DocumentManagerConstants.SHAREPOINT_ATTR_DATE_CREATED);
        setMappedRequiredAttribute(requiredAttributes, retrievedDocument, info, DocumentManagerConstants.ATTR_STR_DATE_MODIFIED,
            DocumentManagerConstants.SHAREPOINT_ATTR_DATE_MODIFIED);
        setMappedRequiredAttribute(requiredAttributes, retrievedDocument, info, DocumentManagerConstants.ATTR_STR_MODIFIER,
            DocumentManagerConstants.SHAREPOINT_ATTR_STR_MODIFIER);
        // Added By Vishal
    }
    return retrievedDocument;
  }

  private String getChronicleIdFromRequest(DocumentAttributes documentAttributes) throws AttributeListParseException,
      DocumentManagerException {
    String chronicleId = documentAttributes
        .getAttrValue(DocumentManagerConstants.SHAREPOINT_ATTR_STR_UNIQUE_DOCUMENT_ID);
    if (!StringUtils.isNullOrEmpty(chronicleId)) {
      return chronicleId;
    } else {
      throw new DocumentManagerException("Request for Update does not contain 'objectId' attribute");
    }
  }

  private void setMappedRequiredAttribute(List requiredAttributes, RetrievedDocument retrievedDocument,
                                          FieldInformation info, String requiredAttribute, String sharepointAttrName) {
    if (requiredAttributes.contains(sharepointAttrName)) {
      System.out.println("SharePointServices.setMappedRequiredAttribute: sharepointAttrName = " + sharepointAttrName);
      setAttributeOnRetrievedDocument(retrievedDocument, info, sharepointAttrName, requiredAttribute);
    }
  }
  /*
  //   Added by ffbrac
  */
    private void setAttributeOnRetrievedDocument(RetrievedDocument retrievedDocument, boolean bNoteType,
                                                 String sharepointAttrName, String retrievedDocumentAttributeName,
                                                 String value, List requiredAttributes) {
        System.out.println(value + ":" + sharepointAttrName +":"+retrievedDocumentAttributeName);
        if (!requiredAttributes.contains(sharepointAttrName) && !requiredAttributes.contains(sharepointAttrName.toLowerCase())) return; 
        System.out
            .println("SETTING ATTR " + retrievedDocumentAttributeName + " from SP Attr Name: " + sharepointAttrName);
        System.out.println("value = " + value);
        if (bNoteType) {
          List valueList = collectValuesIntoList(value);
          retrievedDocument.getDocumentAttributes().addAttribute(retrievedDocumentAttributeName, valueList, null);
        } else {
          value = stripCreatorIfNeeded(retrievedDocumentAttributeName, value);
          retrievedDocument.getDocumentAttributes().addAttribute(retrievedDocumentAttributeName, value, null);
        }
    }

  //
  private void setAttributeOnRetrievedDocument(RetrievedDocument retrievedDocument, FieldInformation info,
                                               String sharepointAttrName, String retrievedDocumentAttributeName) {
    if (info.getDisplayName().equalsIgnoreCase(sharepointAttrName)) {
      System.out
          .println("SETTING ATTR " + retrievedDocumentAttributeName + " from SP Attr Name: " + sharepointAttrName);
      String value = info.getValue();
      FieldType fieldtype = info.getType();
      System.out.println("fieldtype = " + fieldtype);
      System.out.println("value = " + value);
      if (fieldtype.equals(FieldType.NOTE)) {
        List valueList = collectValuesIntoList(value);
        retrievedDocument.getDocumentAttributes().addAttribute(retrievedDocumentAttributeName, valueList, null);
      } else {
        value = stripCreatorIfNeeded(retrievedDocumentAttributeName, value);
        retrievedDocument.getDocumentAttributes().addAttribute(retrievedDocumentAttributeName, value, null);
      }
    }
  }

  private List collectValuesIntoList(String data) {
    List list = null;
    if (data != null) {
      String[] dataArray = data.split("\r\n");
      if (dataArray != null) {
        list = Arrays.asList(dataArray);
      }
    }
    return list;
  }

  private String stripCreatorIfNeeded(String retrievedDocumentAttributeName, String value) {
    String current = value;
    System.out.println(value);
    if (retrievedDocumentAttributeName.equals(DocumentManagerConstants.ATTR_STR_CREATOR) || retrievedDocumentAttributeName.equals(DocumentManagerConstants.ATTR_STR_MODIFIER)) {
        current = value.substring(value.indexOf("\\") + 1);
    }else if(retrievedDocumentAttributeName.equals(DocumentManagerConstants.ATTR_STR_DATE_CREATED) ||
            retrievedDocumentAttributeName.equals(DocumentManagerConstants.ATTR_STR_DATE_MODIFIED)){
        current = ParseDate(value);
    }

    return current;
  }

    private String ParseDate(String value) {
        String current;
        SimpleDateFormat formatFromString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat formatToString = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        try{
            Date date = formatFromString.parse(value);
            current = formatToString.format(date);
            return current;
        }catch(Exception ex){
            System.out.println(ex.getMessage() + ex.getStackTrace());
        }
        return value; 
    }
    // Added by ffbrac to fix the memory spikes that the copy.getItem causes


  private String copySharepointDocumentToDiskWithNoWebservice(String fileName, String fullPathURL)
      throws IOException, DocumentManagerException {
    System.out.println("SharePointServices.copySharepointDocumentToDisk");
      URL url;
      if (!StringUtils.isNullOrEmpty(fullPathURL)) {
        url = new URL(fullPathURL);
      } else {
        url = new URL(siteName + "/" + documentLibraryName + "/" + fileName);
      }
      System.out.println("url: " + url);
      System.out.println("fullPath: " + fullPathURL);
      System.out.println("fileName: " + fileName);
      String absoluteTempFilePath = System.getProperty(DocumentManagerConstants.TEMP_DIRECTORY) + "\\" + UUID.randomUUID() +"_"+ fileName;
      System.out.println("fileName = " + fileName);

      System.out.println("Connecting to service: ");
      URLConnection urlConnection =  createUrlConnection(url);
      urlConnection.setReadTimeout(300000);
      urlConnection.setConnectTimeout(300000);
      urlConnection.connect();
      System.out.println("Getting connection timeout : " + urlConnection.getConnectTimeout());
      if(urlConnection.getPermission() != null)      System.out.println("Getting connection timeout : " + urlConnection.getPermission().getActions());
      InputStream inputStream = urlConnection.getInputStream();
      //BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));

      System.out.println("writing file to disk: ");

      FileOutputStream file = new FileOutputStream(absoluteTempFilePath);
      try{
          int byteStreamLength = 8096;
          int bytesRead = 0;
          byte [] bytearray = new byte[byteStreamLength];
          while ((bytesRead = inputStream.read(bytearray, 0, byteStreamLength)) > -1) {
              //System.out.println("bytes read: " + bytesRead);
              file.write(bytearray, 0, bytesRead);
          }
          System.out.println("Exit While bytes read: " + bytesRead);
      }catch (Exception ex){
          System.out.println(ex.getMessage() + ex.getStackTrace());
      }finally {
          file.flush();
          file.close();
          inputStream.close();
      }

    return absoluteTempFilePath;
  }

  private String copySharepointDocumentToDisk(CopySoap copySoap, String fileName,
                                              Holder<FieldInformationCollection> heldFields, String fullPathURL)
      throws IOException, DocumentManagerException {
    System.out.println("SharePointServices.copySharepointDocumentToDisk");
    System.out.println("fileName = " + fileName);
    Holder<byte[]> byteStream = new Holder<byte[]>();



    Holder<Long> getItemResult = new Holder<Long>();
    if (!StringUtils.isNullOrEmpty(fullPathURL)) {
      //copySoap.getItem();
      copySoap.getItem(fullPathURL, getItemResult, heldFields, byteStream);
    } else {
      copySoap.getItem(siteName + "/" + documentLibraryName + "/" + fileName, getItemResult, heldFields, byteStream);
    }
    return writeFileToTempLocation(fileName, byteStream.value, fullPathURL);
  }

  private String writeFileToTempLocation(String fileName, byte[] byteStream, String fullPathUrl) throws IOException,
      DocumentManagerException {
    if (byteStream == null) {
      throw new DocumentManagerException(
          "Not able to find \"" + fileName + "\" in \"" + siteName + "/" + documentLibraryName +
              "\"; Was given this path to it:\"" + fullPathUrl + "\"");
    }
    String absoluteTempFilePath = System.getProperty(DocumentManagerConstants.TEMP_DIRECTORY) + "\\" + UUID.randomUUID() +"_"+ fileName;
    FileOutputStream out = new FileOutputStream(absoluteTempFilePath);
    out.write(byteStream);
    out.flush();
    out.close();
    return absoluteTempFilePath;
  }

  private void listAttributes(Node node) {
    NamedNodeMap map = node.getAttributes();
    System.out.println("SharepointServices.listAttributes: map.getLength() = " + map.getLength());
    for (int k = 0; k < map.getLength(); k++) {
      Node attrNode = map.item(k);
    }
  }

  private void addDeletedDocumentDetailsToResponse(String objectId, String versionDeleted,
                                                   ResponseEntity responseEntity) {
    RetrievedDocument retrievedDocument = new RetrievedDocument();
    retrievedDocument.getDocumentAttributes()
        .addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, objectId, null);
    retrievedDocument.getDocumentAttributes()
        .addAttribute(DocumentManagerConstants.ATTR_STR_VERSION, versionDeleted, null);
    responseEntity.getRetrievedDocumentList().add(retrievedDocument);
  }

  private ListsSoap setupListsService() throws MalformedURLException {
    prepJcifsAndRegister();
//		JaxWsProxyFactoryBean proxyFactory = new JaxWsProxyFactoryBean();
//		proxyFactory.setServiceClass(com.microsoft.schemas.sharepoint.soap.Lists.class);
//		proxyFactory.setAddress(siteName + "/_vti_bin/Lists.asmx?WSDL");
//		Lists service = (Lists) proxyFactory.create();
    com.microsoft.schemas.sharepoint.soap.Lists service = new com.microsoft.schemas.sharepoint.soap.Lists(
        new URL(siteName + "/_vti_bin/Lists.asmx?WSDL"));
    ListsSoap listsSoap = service.getListsSoap();
    finishTurningOffChunkingForNTLM(listsSoap);
//		com.microsoft.schemas.sharepoint.soap.Lists service = new com.microsoft.schemas.sharepoint.soap.Lists(
//			new URL(siteName + "/_vti_bin/Lists.asmx?WSDL"));
    //		turnOffChunkingForNTLM(listsSoap);
    return listsSoap;
  }

  private URLConnection createUrlConnection(URL url) throws
      MalformedURLException, IOException {

      prepJcifsAndRegister();
      HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
    return urlConnection;
  }

  private VersionsSoap createVersionsService(String wsdlLocation) throws
      MalformedURLException {
    prepJcifsAndRegister();
    com.microsoft.schemas.sharepoint.soap.Versions service = new com.microsoft.schemas.sharepoint.soap.Versions(
        new URL(wsdlLocation));
    com.microsoft.schemas.sharepoint.soap.VersionsSoap versionsSoap = service.getVersionsSoap();

//		JaxWsProxyFactoryBean proxyFactory = new JaxWsProxyFactoryBean();
//		proxyFactory.setServiceClass(com.microsoft.schemas.sharepoint.soap.Versions.class);
//		proxyFactory.setAddress(wsdlLocation);
//		Versions service = (Versions) proxyFactory.create();

    finishTurningOffChunkingForNTLM(versionsSoap);
//		turnOffChunkingForNTLM(versionsSoap);
//		return versionsSoap;
    return versionsSoap;
  }

  private CopySoap createCopyService(String wsdlLocation) throws
      MalformedURLException {

    prepJcifsAndRegister();

    com.microsoft.schemas.sharepoint.soap.Copy service = new com.microsoft.schemas.sharepoint.soap.Copy(
        new URL(wsdlLocation));

    com.microsoft.schemas.sharepoint.soap.CopySoap copySoap = service.getCopySoap();
//		JaxWsProxyFactoryBean proxyFactory = new JaxWsProxyFactoryBean();
//		proxyFactory.setServiceClass(com.microsoft.schemas.sharepoint.soap.Copy.class);
//		proxyFactory.setAddress(wsdlLocation);
//		Copy service = (Copy) proxyFactory.create();
    finishTurningOffChunkingForNTLM(copySoap);
//		turnOffChunkingForNTLM(copySoap);
//		return copySoap;
    return copySoap;
  }

  private Element parseResult(UpdateListItemsResponse.UpdateListItemsResult listItemsResult) {
    Element result = (Element) listItemsResult.getContent().get(0);
    NodeList list = result.getElementsByTagName("Result");
    System.out.println("SharepointServices.parseResult: list.getLength() = " + list.getLength());
    for (int j = 0; j < list.getLength(); j++) {
      Node node = list.item(j);
      //System.out.println("SharepointServices.parseResult: node.getNodeName() = " + node.getNodeName());
      listAttributes(node);
      NodeList children = node.getChildNodes();
      for (int k = 0; k < children.getLength(); k++) {
        listValue(children.item(k));
        listAttributes(children.item(k));
      }
    }
    return result;
  }

  private void listValue(Node node) {
    System.out.println("SharepointServices.listValue: node.getNodeName() = " + node.getNodeName());
    System.out.println("SharepointServices.listValue: node.getNodeValue() = " + node.getTextContent());
  }

  private List<SearchResultEntity> getSearchResultEntityList(String searchValue, String sharePointSearchField, String directoryStructure, boolean bRecursiveSearch) throws DocumentManagerException{
      List<SearchResultEntity> searchResultList = new ArrayList<SearchResultEntity>();
      try{
        ListsSoap listsSoap = setupListsService();
         GetListItems.Query query = getCAMLQuery(searchValue, sharePointSearchField);
        GetListItems.QueryOptions queryOptions = generateQueryOptions(directoryStructure, bRecursiveSearch);
        GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
            .getListItems(documentLibraryName, "", query, null, null, queryOptions, "");
        Element listResult = (Element) scannedImagesResult.getContent().get(0);
        NodeList nodeList = listResult.getElementsByTagName("z:row");

        if (nodeList == null) return null;

        for(int i = 0; i < nodeList.getLength(); i++) searchResultList.add(SetupSearchResultEntity(nodeList.item(0)));
    }catch(Exception ex){
          System.out.println("getSearchResultEntityList: " + ex.getMessage() + ex.getStackTrace());
          throw new DocumentManagerException(ex);
      }
    return searchResultList;
  }

    private GetListItems.Query getCAMLQuery(String id, String sharePointSearchField) throws IOException, ParserException {
        System.out.println("SharePointServices.getFileName");
        System.out.println("search criteria = " + id);
        System.out.println("sharePointSearchField = " + sharePointSearchField);
        System.out.println("sharePointSearchField = " + sharePointSearchField);
        String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<Query>" +
            "<Where>" +
            "<Eq>" +
            "<FieldRef Name='" + sharePointSearchField + "' />" +
            "<Value Type='Text'>" + id.trim() + "</Value>" +
            "</Eq>" +
            "</Where>" +
            "</Query>";
        Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
        GetListItems.Query query = new GetListItems.Query();
        List<Object> content = query.getContent();
        content.add(queryDoc.getDocumentElement());
        return query;
    }

    private String getFileName(String id, String sharePointSearchField,String directoryStructure) throws IOException, ParserException,
      ParserConfigurationException {
    System.out.println("SharePointServices.getFileName");
    System.out.println("id = " + id);
    System.out.println("sharePointSearchField = " + sharePointSearchField);
    ListsSoap listsSoap = setupListsService();
    System.out.println("sharePointSearchField = " + sharePointSearchField);
    String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
        "<Query>" +
        "<Where>" +
        "<Contains>" +
        "<FieldRef Name='" + sharePointSearchField + "' />" +
        "<Value Type='Text'>" + id + "</Value>" +
        "</Contains>" +
        "</Where>" +
        "</Query>";
    Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
    GetListItems.Query query = new GetListItems.Query();
    List<Object> content = query.getContent();
    content.add(queryDoc.getDocumentElement());
    GetListItems.QueryOptions queryOptions = generateQueryOptions(directoryStructure, true);
    GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
        .getListItems(documentLibraryName, "", query, null, null, queryOptions, "");
    Element listResult = (Element) scannedImagesResult.getContent().get(0);
    NodeList list = listResult.getElementsByTagName("z:row");
    if (list == null || list.item(0) == null) {
      throw new IOException("getFileName(" + id + ")" + DOMUtil.dumpToString(queryDoc) + EXCEPTION_TEXT_BAD_FILENAME +
          DOMUtil.dumpToString(DOMUtil.newDocument(listResult)));
    }
    NamedNodeMap attributes = list.item(0).getAttributes();
    String owsFileRef = attributes.getNamedItem("ows_FileRef").getNodeValue();
    System.out.println("***DEBUG >>> Inside getFileName >> return owsFileRef = " + owsFileRef);
    return owsFileRef.substring(owsFileRef.lastIndexOf("/") + 1);
  }
    private String getFileLocation(String id, String sharePointSearchField, String directoryStructure) throws IOException, ParserException,
          ParserConfigurationException {
        System.out.println("SharePointServices.getFileLocation");
        System.out.println("id = " + id);
        System.out.println("sharePointSearchField = " + sharePointSearchField);
        ListsSoap listsSoap = setupListsService();
        System.out.println("sharePointSearchField = " + sharePointSearchField);
        String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
            "<Query>" +
            "<Where>" +
            "<Contains>" +
            "<FieldRef Name='" + sharePointSearchField + "' />" +
            "<Value Type='Text'>" + id + "</Value>" +
            "</Contains>" +
            "</Where>" +
            "</Query>";
        Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
        GetListItems.Query query = new GetListItems.Query();
        List<Object> content = query.getContent();
        content.add(queryDoc.getDocumentElement());
        GetListItems.QueryOptions queryOptions = generateQueryOptions(directoryStructure, true);
        GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
            .getListItems(documentLibraryName, "", query, null, null, queryOptions, "");
        Element listResult = (Element) scannedImagesResult.getContent().get(0);
        NodeList list = listResult.getElementsByTagName("z:row");
        if (list == null || list.item(0) == null) {
          throw new IOException("getFileName(" + id + ")" + DOMUtil.dumpToString(queryDoc) + EXCEPTION_TEXT_BAD_FILENAME +
              DOMUtil.dumpToString(DOMUtil.newDocument(listResult)));
        }
        NamedNodeMap attributes = list.item(0).getAttributes();
        String owsFileRef = attributes.getNamedItem("ows_FileRef").getNodeValue();
        String fileLocation = getLocation(owsFileRef);
        String fileUrl = siteName + "/" + documentLibraryName + "/" + fileLocation;
        System.out.println("***DEBUG >>> Inside getFileLocation >> return owsFileRef = " + fileUrl);
        return fileUrl;
      }
      private String getLocation (String owsFileRef)
      {
          //ows_FileRef="3110;#private/COVAR/COVAR Library/test/test-folder/filename.txt
          String siteLibLocation = owsFileRef.substring(owsFileRef.indexOf("/") + 1);
          String libLocation = siteLibLocation.substring(siteLibLocation.indexOf("/")+1);
          String location =  libLocation.substring(libLocation.indexOf("/")+1);
          return location;
      }
    private List getFileID(String id, String sharePointSearchField) throws IOException, ParserException,
      ParserConfigurationException {
    System.out.println("SharePointServices.getFileID");
    System.out.println("id = " + id);
    System.out.println("sharePointSearchField = " + sharePointSearchField);
    ListsSoap listsSoap = setupListsService();
    System.out.println("sharePointSearchField = " + sharePointSearchField);
    String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
        "<Query>" +
        "<Where>" +
        "<Contains>" +
        "<FieldRef Name='" + sharePointSearchField + "' />" +
        "<Value Type='Text'>" + id + "</Value>" +
        "</Contains>" +
        "</Where>" +
        "</Query>";
    Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
    GetListItems.Query query = new GetListItems.Query();
    List<Object> content = query.getContent();
    content.add(queryDoc.getDocumentElement());
    GetListItems.QueryOptions queryOptions = generateQueryOptions("", true);
    GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
        .getListItems(documentLibraryName, "", query, null, null, queryOptions, "");
    Element listResult = (Element) scannedImagesResult.getContent().get(0);
    NodeList list = listResult.getElementsByTagName("z:row");
    if (list == null || list.item(0) == null) {
      throw new IOException("getFileID(" + id + ")" + DOMUtil.dumpToString(queryDoc) + EXCEPTION_TEXT_BAD_FILENAME +
          DOMUtil.dumpToString(DOMUtil.newDocument(listResult)));
    }
      int length = list.getLength();
      List IDs = new ArrayList(length);
      for (int i = 0; i < length; i++) {
        String spID = list.item(i).getAttributes().getNamedItem("ows_ID").getNodeValue();
        System.out.println(String.format("Index: %d\t ID = %s", i, spID));
        IDs.add(spID);
      }
      return IDs;
  }
    private GetListItems.QueryOptions generateQueryOptions(String directoryStructure, boolean bRecursiveSearch) throws IOException, ParserException {

       System.out.println("Inside generateQueryOptions : directoryStructure =  " + directoryStructure);
       String folderOption = "<Folder>" + documentLibraryName + "/" + directoryStructure + "</Folder>";
       String recursiveOption = "Recursive";
       if(!bRecursiveSearch) recursiveOption = "FilesOnly";

       String strOptions = "<?xml version='1.0' encoding='UTF-8'?>" + "<QueryOptions>" + "<ViewAttributes Scope='"+recursiveOption+"'/>" +
                    folderOption +
                "</QueryOptions>";

       Document optionsDoc = DOMUtil.newDocumentFromXML((strOptions));
       DOMUtil.outputXML(optionsDoc);
       GetListItems.QueryOptions queryOptions = new GetListItems.QueryOptions();
       List<Object> optionsContent = queryOptions.getContent();
       optionsContent.add(optionsDoc.getDocumentElement());

       return queryOptions;
     }

  private void finishTurningOffChunkingForNTLM(Object port) {
//		Client client = proxyFactory.getClientFactoryBean().getClient();
    Client client = ClientProxy.getClient(port);
    HTTPConduit http = (HTTPConduit) client.getConduit();
    HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
    httpClientPolicy.setConnectionTimeout(36000);
    httpClientPolicy.setAllowChunking(false);
    http.setClient(httpClientPolicy);
  }

  private void prepJcifsAndRegister() {
    jcifs.Config.setProperty("jcifs.smb.client.domain", "na.ds.monsanto.com");
    jcifs.Config.setProperty("jcifs.netbios.wins", "10.30.55.150");
    jcifs.Config.setProperty("jcifs.smb.client.soTimeout", "300000"); //5 minutes
    jcifs.Config.setProperty("jcifs.netbios.cachePolicy", "1200"); //20 minutes
    jcifs.Config.registerSmbURLHandler();
  }



}