/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.queryBuilder;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.ISharePointServices;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity.SearchSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;

import java.util.Iterator;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author lakench
 * @version $Revision$
 */
public class SharePointQueryBuilder {
	private static final String TEXT = "Text";
	private static final String NOTE = "Note";
	private static final String BOOLEAN = "Boolean";
	private static final String DATE_TIME = "DateTime";
	private static final String KEYWORDS = "keywords";
	private static final String A_IS_SIGNED = "a_is_signed";
	private static final String A_EFFECTIVE_DATE = "a_effective_date";
	private static final String EQ_END = "</Eq>";
	private static final String EQ_START = "<Eq>";
	private static final String CONTAINS_START = "<Contains>";
	private static final String CONTAINS_END = "</Contains>";
//	private static final String COLON = ":";
//	private static final String DOUBLE_QUOTE = "\"";
//	private static final String BLANK = " ";

	public String buildSearchQueryForDocumentId(SearchSharePointRequestEntity requestEntity,
																							ISharePointServices service) throws AttributeListParseException,
		DocumentManagerException {
		DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
		String queryXml = "<?xml version='1.0' encoding='UTF-8'?><Query><Where>";
		Iterator iterator = documentAttributes.getAttrIterator();
		int count = documentAttributes.getLength();
		if (count > 0) {

			queryXml = addTagIfMorethanOne(queryXml, count, "<And>");
			while (iterator.hasNext()) {
				String key = (String) iterator.next();
				String value = documentAttributes.getAttrValue(key);
				System.out.println("SharePointQueryBuilder.buildSearchQueryForDocumentId: key / value = " + key + " / " + value);
				String fieldType = getFieldType(key);
				queryXml = queryXml + getAppropriateOperatorStart(fieldType);
				queryXml = queryXml + "<FieldRef Name='" + getSPMappedKeys(key) + "' /><Value Type='" + fieldType + "'>" + 
                           getValue(fieldType, value) + "</Value>";
//			queryXml = queryXml + "<FieldRef Name='"+key+"' /><Value Type='Text'>"+value+"</Value>";
				queryXml = queryXml + getAppropriateOperatorEnd(fieldType);
			}
			queryXml = addTagIfMorethanOne(queryXml, count, "</And>");
			queryXml = queryXml + "</Where></Query>";
		} else {
			queryXml = null;
		}

//		String queryXml = "<QueryPacket xmlns=\"urn:Microsoft.Search.Query\" Revision=\"1000\"><Query><SupportedFormats><Format>urn:Microsoft.Search.Response.Document.Document</Format></SupportedFormats><Context><QueryText language=\"en-US\" type=\"STRING\">";
//		DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
//		Iterator iterator = documentAttributes.getAttrIterator();
//		boolean firstTime = true;
//		while (iterator.hasNext()) {
//			String key = (String) iterator.next();
//			String value = documentAttributes.getAttrValue(key);
//			System.out.println("SharePointQueryBuilder.buildSearchQueryForDocumentId: key / value = " + key + " / " + value);
//			queryXml = queryXml + blankIfNeeded(firstTime) + key + COLON + DOUBLE_QUOTE + value + DOUBLE_QUOTE;
//			firstTime = false;
//		}
//		queryXml = queryXml + "</QueryText></Context></Query></QueryPacket>";
//		System.out.println("SharePointQueryBuilder.buildSearchQueryForDocumentId: queryXml = " + queryXml);


		return queryXml;
	}

  private String getSPMappedKeys(String requestedKey)
  {
      String SPAttribute = null;
      if (requestedKey.equals(DocumentManagerConstants.ATTR_STR_AUTHORS))
            SPAttribute = DocumentManagerConstants.SHAREPOINT_ATTR_STR_AUTHOR;
      else if (requestedKey.equals(DocumentManagerConstants.ATTR_STR_KEYWORDS))
           SPAttribute = DocumentManagerConstants.SHAREPOINT_ATTR_STR_KEYWORDS;
      else if (requestedKey.equals(DocumentManagerConstants.ATTR_STR_SUBJECT))
           SPAttribute = DocumentManagerConstants.SHAREPOINT_ATTR_STR_SUBJECT;
      else if (requestedKey.equals(DocumentManagerConstants.ATTR_STR_NAME))
            SPAttribute = DocumentManagerConstants.SHAREPOINT_ATTR_STR_OBJNAME;
      else if (requestedKey.equals(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID))
            SPAttribute = DocumentManagerConstants.SHAREPOINT_ATTR_ID;
      else
           SPAttribute =  requestedKey;
      return SPAttribute;
  }
	private String getAppropriateOperatorEnd(String fieldType) {
		if (fieldType.equalsIgnoreCase(NOTE)) {
			return CONTAINS_END;
		}
		return EQ_END;
	}

	private String getAppropriateOperatorStart(String fieldType) {
		if (fieldType.equalsIgnoreCase(NOTE)) {
			return CONTAINS_START;
		}
		return EQ_START;
	}

	private String getValue(String fieldType, String value) {
		if (fieldType.equalsIgnoreCase(BOOLEAN)) {
			if (value.equalsIgnoreCase("false")) {
				value = "0";
			} else if (value.equalsIgnoreCase("true")) {
				value = "1";
			}
		}
		return value;
	}

	private String getFieldType(String key) {
		String type = TEXT;
		if (key.equalsIgnoreCase(KEYWORDS)) {
			type = NOTE;
		} else if (key.equalsIgnoreCase(A_IS_SIGNED)) {
			type = BOOLEAN;
		} else if (key.equalsIgnoreCase(A_EFFECTIVE_DATE)) {
			type = DATE_TIME;
		}
		return type;
	}

	private String addTagIfMorethanOne(String queryXml, int count, String tag) {
		if (count > 1) {
			queryXml = queryXml + tag;
		}
		return queryXml;
	}

//	private String blankIfNeeded(boolean firstTime) {
//		if (firstTime) {
//			return "";
//		}
//		return BLANK;
//	}
}