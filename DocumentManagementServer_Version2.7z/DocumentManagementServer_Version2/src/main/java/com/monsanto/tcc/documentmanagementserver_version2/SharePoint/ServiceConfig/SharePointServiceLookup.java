/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.ServiceConfig;

import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author lakench
 * @version $Revision$
 */
public class SharePointServiceLookup extends ServiceLookup {
  public SharePointServiceLookup(String serviceConfigFileName) throws ServiceConfigException {
    super(serviceConfigFileName);

  }

  public SharePointServiceLookup() throws ServiceConfigException {
    super();
  }

  @Override
  public ConnectionInfo getConnectionDetails(String folderName, String lsiEnvironment) throws ServiceConfigException,
      EncryptorException {
    Node folderNode = getSpecificFolderNode(folderName);

    Node connectionDetailsNode = DOMUtil
        .getChild(folderNode, DocumentManagerConstants.SERVICE_CONFIG_STR_CONNECTION_DETAILS);
    Node[] environmentNodeList = getAllEnvironmentNodes(connectionDetailsNode);
    Node specificEnvironmentNode = getSpecificChildNode(environmentNodeList,
        DocumentManagerConstants.SERVICE_CONFIG_STR_FOLDER_NAME_ATTRIBUTE, lsiEnvironment);
    return this.getConnectionParams(specificEnvironmentNode, folderName);
  }

  @Override
  protected ConnectionInfo getConnectionParams(Node specificEnvironmentNode, String folderName) throws
      EncryptorException {
    ConnectionInfo connectionInfo = new ConnectionInfo();
    NodeList childList = specificEnvironmentNode.getChildNodes();
    int listLen = childList.getLength();
    for (int i = 0; i < listLen; i++) {
      Node childNode = childList.item(i);
      String attributeName = childNode.getNodeName();
      if (attributeName.equalsIgnoreCase(DocumentManagerConstants.SERVICE_CONFIG_STR_GROUPS)) {
        List groupNameList = addGroupInformation(childNode);
        if (groupNameList.size() > 0) {
          connectionInfo.addConnectionParameter(attributeName, groupNameList);
          connectionInfo.setFolderSecured(true);
        }
      } else {
        String attributeValue = DOMUtil.getTextValue(childNode);
        connectionInfo.addConnectionParameter(attributeName, attributeValue);
      }
    }
    return connectionInfo;
  }

  private Node getSpecificFolderNode(String folderName) throws ServiceConfigException {
    Node[] folderNodeList = getAllFolderNodes(getServiceConfigDom().getDocumentElement());
    try {
      return getSpecificChildNode(folderNodeList, DocumentManagerConstants.SERVICE_CONFIG_STR_FOLDER_NAME_ATTRIBUTE,
          folderName);
    } catch (ServiceConfigException e) {
      throw new ServiceConfigException("No service found for specified folder: \"" + folderName + "\"");
    }
  }

  private Node[] getAllEnvironmentNodes(Node parentNode) {
    return DOMUtil.getChildren(parentNode, DocumentManagerConstants.SERVICE_CONFIG_STR_ENVIRONMENT);
  }

  private Node getSpecificChildNode(Node[] nodeList, String attributeName, String attributeValue) throws
      ServiceConfigException {
    int numberOfNodes = nodeList.length;
    for (int i = 0; i < numberOfNodes; i++) {
      if (nodeHasRequiredAttrValue(nodeList[i], attributeName, attributeValue)) {
        return nodeList[i];
      }
    }
    System.out.println(
        "SPabout to throw the ServiceConfig exception about no node defined having the specified attribute value: \"" +
            attributeValue + "\"");
    throw new ServiceConfigException("No node defined having specified attribute value: \"" + attributeValue + "\"");
  }

  private Node[] getAllFolderNodes(Node parentNode) {
    return DOMUtil.getChildren(parentNode, DocumentManagerConstants.SERVICE_CONFIG_STR_FOLDER);
  }

  private boolean nodeHasRequiredAttrValue(Node node, String attributeName, String requiredAttributeValue) {
    String nodeAttributeValue = DOMUtil.getAttribute((Element) node, attributeName);
    return nodeAttributeValue.equalsIgnoreCase(requiredAttributeValue);
  }

}