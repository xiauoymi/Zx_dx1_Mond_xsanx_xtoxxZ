/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.SharePoint;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.AttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.TransformationObject;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author lakench
 * @version $Revision$
 */
public class SharePointAttributeTransformer implements AttributeTransformer {
  private static List transformationList;

  //Note: Core Attributes "subject", "keywords" and "authors" have same identifer, so do not need a transformation.
  static {
    transformationList = new ArrayList();
    transformationList.add(
        new TransformationObject(DocumentManagerConstants.ATTR_STR_VERSION,
            DocumentManagerConstants.SHAREPOINT_ATTR_VERSION));
    transformationList.add(
        new TransformationObject(DocumentManagerConstants.ATTR_STR_NAME, DocumentManagerConstants.DCTM_ATTR_STR_NAME));
    transformationList.add(
        new TransformationObject(DocumentManagerConstants.ATTR_STR_KEYWORDS,
            DocumentManagerConstants.SHAREPOINT_ATTR_STR_KEYWORDS));
    transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_SUBJECT,
        DocumentManagerConstants.SHAREPOINT_ATTR_STR_SUBJECT));
    transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_TITLE,
        DocumentManagerConstants.SHAREPOINT_ATTR_STR_TITLE));
    //transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID,
    //    DocumentManagerConstants.SHAREPOINT_ATTR_STR_UNIQUE_DOCUMENT_ID));

    transformationList.add(
        new TransformationObject(DocumentManagerConstants.ATTR_STR_SIZE,
            DocumentManagerConstants.SHAREPOINT_ATTR_STR_SIZE));
    transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_CREATOR,
        DocumentManagerConstants.SHAREPOINT_ATTR_STR_CREATOR));
    //transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_DATE_CREATED,
    //    DocumentManagerConstants.DCTM_ATTR_STR_DATE_CREATED));
    transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_DATE_CREATED,
          DocumentManagerConstants.SHAREPOINT_ATTR_DATE_CREATED));

    //transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_MODIFIER,
        //DocumentManagerConstants.DCTM_ATTR_STR_MODIFIER));
    transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_MODIFIER,
        DocumentManagerConstants.SHAREPOINT_ATTR_STR_MODIFIER));

    //transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_DATE_MODIFIED,
        //DocumentManagerConstants.DCTM_ATTR_STR_DATE_MODIFIED));
      transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_DATE_MODIFIED,
          DocumentManagerConstants.SHAREPOINT_ATTR_DATE_MODIFIED));

    transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_VERSION,
        DocumentManagerConstants.DCTM_ATTR_STR_VERSION));
    transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_DATE_LOCKED,
        DocumentManagerConstants.DCTM_ATTR_STR_DATE_LOCKED));
    transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_LOCK_OWNER,
        DocumentManagerConstants.DCTM_ATTR_STR_LOCK_OWNER));
    transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_PAGE_COUNT,
        DocumentManagerConstants.DCTM_ATTR_STR_PAGE_COUNT));
    transformationList.add(new TransformationObject(DocumentManagerConstants.ATTR_STR_DATE_LAST_ACCESSED,
        DocumentManagerConstants.DCTM_ATTR_STR_DATE_LAST_ACCESSED));
  }

  public List getTransformationList() {
    return transformationList;
  }
}