/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.SharePoint;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author lakench
 * @version $Revision$
 */
public abstract class SharePointBuilder extends DocBuilder {
  public void buildDocumentService(RequestEntity requestEntity) throws AttributeListParseException {
    System.out.println("SharePointBuilder.buildDocumentService");
    SharePointRequestEntity spReqEntity = (SharePointRequestEntity) requestEntity;
    ConnectionInfo connectionInfo = spReqEntity.getConnectionInfo();
    System.out.println(
        "connectionInfo.getConnectionParameterValue(\n        DocumentManagerConstants.SP_CI_SITE_NAME) = " +
            connectionInfo.getConnectionParameterValue(
                DocumentManagerConstants.SP_CI_SITE_NAME));
    System.out.println(
        "connectionInfo.getConnectionParameterValue(\n        DocumentManagerConstants.SP_CI_DOC_LIB_NAME) = " +
            connectionInfo.getConnectionParameterValue(
                DocumentManagerConstants.SP_CI_DOC_LIB_NAME));
    setDocumentService(new SharePointService(connectionInfo));
  }

  public void buildAttributeTransformer() {
    setAttributeTransformer(new SharePointAttributeTransformer());
  }

  public abstract void buildParser();

  public abstract void buildRequestEntity();
}