/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.SharePoint;

import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.ServiceConfig.SharePointServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import org.w3c.dom.Node;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author lakench
 * @version $Revision$
 */
public abstract class SharePointRequestParser extends RequestParser {
  public void parseServiceSpecificRequest(Node requestNode, RequestEntity requestEntity, String folderName) throws
      ServiceConfigException, EnvironmentHelperException, AttributeListParseException, DocumentManagerException,
      EncryptorException {
    DOMUtil.outputXML(requestNode);
    SharePointRequestEntity sharePointRequestEntity = (SharePointRequestEntity) requestEntity;
    parseOperationSpecificRequest(requestNode, sharePointRequestEntity);
    parseServiceConfigDetails(folderName, sharePointRequestEntity);
  }

  public abstract void parseOperationSpecificRequest(Node requestNode,
                                                     SharePointRequestEntity sharePointRequestEntity) throws
      AttributeListParseException, DocumentManagerException;

  private void parseServiceConfigDetails(String folderName, SharePointRequestEntity sharePointRequestEntity) throws
      ServiceConfigException, EnvironmentHelperException, EncryptorException {
    SharePointServiceLookup lookup = (SharePointServiceLookup) getServiceConfigLookupInstance();
    String lsiEnvironment = getLsiEnvironmentVariable();
    ConnectionInfo connectionInfo = lookup.getConnectionDetails(folderName, lsiEnvironment);

    saveConnectionDetails(connectionInfo, sharePointRequestEntity);
  }

  private void saveConnectionDetails(ConnectionInfo connectionInfo, SharePointRequestEntity sharePointRequestEntity) {
    sharePointRequestEntity.setConnectionInfo(connectionInfo);
  }

  protected String getLsiEnvironmentVariable() throws EnvironmentHelperException {
    String lsiFunction = System.getProperty("lsi.function");
    if (lsiFunction != null && lsiFunction.length() > 0) {
      return lsiFunction;
    }
    throw new EnvironmentHelperException("Bad value for lsi.function");
  }

  protected IServiceLookup getServiceConfigLookupInstance() throws ServiceConfigException {
    return new SharePointServiceLookup();
  }
}