/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.SharePoint;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.ISharePointServices;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.SharePointServices;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.queryBuilder.SharePointQueryBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.entity.DeleteSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.entity.InsertSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.entity.RetrieveSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity.SearchSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updateSharePointDoc.entity.UpdateSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.*;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.InvalidDctmAttrValueException;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author lakench
 * @version $Revision$
 */
public class SharePointService extends DocumentService {
  private ISharePointServices service;

  public SharePointService(ConnectionInfo connectionInfo) throws AttributeListParseException {
    String documentLibraryName = connectionInfo
        .getConnectionParameterValue(DocumentManagerConstants.SP_CI_DOC_LIB_NAME);
    System.out.println("documentLibraryName = " + documentLibraryName);
    service = (ISharePointServices) new SharePointServices(connectionInfo.getConnectionParameterValue(
        DocumentManagerConstants.SP_CI_SITE_NAME),
        documentLibraryName);
  }

  public void insert(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper helper) throws
      DocumentManagerException {
    System.out.println("WWWSharePointService.insert");
    try {
      RetrievedDocument retrievedDocument = insertIntoSP(requestEntity, getAttachmentLocation(helper));
      addRetrievedDocumentToResponseEntity(responseEntity, retrievedDocument);
    } catch (DocumentManagerException e) {
      throw new DocumentManagerException(
          String.format(
              "%s", e.getMessage()), e);
    }
  }

  public void update(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper helper) throws
      DocumentManagerException {
    try {
      String newContentsLocation = getLocationOfNewContentsForUpdate(helper);
      RetrievedDocument retrievedDocument = updateSP(requestEntity, newContentsLocation);
      addRetrievedDocumentToResponseEntity(responseEntity, retrievedDocument);
    } catch (DocumentManagerException e) {
      throw new DocumentManagerException(
          String.format("There was a problem updating your document: I caught a %s exception with a message of \"%s\"",
              e.getClass().getName(), e.getMessage()), e);
    }
  }

  private RetrievedDocument updateSP(RequestEntity requestEntity, String newContentsLocation) throws
      DocumentManagerException {
    RetrievedDocument retrievedDocument;
    UpdateSharePointRequestEntity updateDctmRequestEntity = (UpdateSharePointRequestEntity) requestEntity;
    try {
      retrievedDocument = service.update(updateDctmRequestEntity, newContentsLocation);
    } catch (Exception e) {
//      performCancelCheckOut();
      throw new DocumentManagerException(
          String.format("There was a problem updating your document: I caught a %s exception with a message of \"%s\"",
              e.getClass().getName(), e.getMessage()), e);
    } finally {
//      closeService();
    }
    return retrievedDocument;
  }

  /*private void performCancelCheckOut() throws DocumentManagerException {
    try {
      service.checkSessionOpen();
      setupService();
      service.cancelCheckoutDocument();
      commitTX();
    } catch (DfException e) {
      rollbackTX(e);
      System.out.println("Rolledback cancelCheckout operation, exception ignored: " + e.getMessage());
    }
    finally{
      closeService();
    }
  }*/

  public void retrieve(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper helper) throws
      DocumentManagerException {
    try {
      System.out.println("SharePointService.retrieve");
      RetrievedDocument retrievedDocument = retrieveFromSP(requestEntity);
      addRetrievedDocumentToResponseEntity(responseEntity, retrievedDocument);
    } catch (DocumentManagerException e) {
      throw new DocumentManagerException(e);
    }
  }

  public void search(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper mockHelper) throws
      DocumentManagerException {
    SearchSharePointRequestEntity searchSharePointRequestEntity = (SearchSharePointRequestEntity) requestEntity;
    searchFromSP(searchSharePointRequestEntity, responseEntity);
  }

  public void delete(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper mockHelper) throws
      DocumentManagerException, AttributeListParseException {
    DeleteSharePointRequestEntity deleteSharePointRequestEntity = (DeleteSharePointRequestEntity) requestEntity;
    DocumentAttributes documentAttributes = deleteSharePointRequestEntity.getDocumentAttributes();
    String objectId = documentAttributes.getAttrValue(DocumentManagerConstants.SHAREPOINT_ATTR_STR_UNIQUE_DOCUMENT_ID);
    deleteFromSP(objectId, documentAttributes, responseEntity);
  }

  private void deleteFromSP(String objectId, DocumentAttributes documentAttributes,
                            ResponseEntity responseEntity) throws DocumentManagerException {
    try {
      service.delete(objectId, documentAttributes, responseEntity);
    } catch (Exception e) {
      throw new DocumentManagerException(
          String.format("There was a problem deleting your document: I caught a %s exception with a message of \"%s\"",
              e.getClass().getName(), e.getMessage()), e);
    } finally {
    }
  }

  private void searchFromSP(SearchSharePointRequestEntity searchSharePointRequestEntity,
                            ResponseEntity responseEntity) throws DocumentManagerException {
    try {
      String queryString = getSearchQuery(searchSharePointRequestEntity);
			System.out.println("SharePointService.searchFromSP: queryString = " + queryString);
			service.search(queryString, searchSharePointRequestEntity, responseEntity);
    } catch (Exception e) {
      throw new DocumentManagerException(e);
    } finally {
    }
  }

  private RetrievedDocument retrieveFromSP(RequestEntity requestEntity) throws DocumentManagerException {
    System.out.println("SharePointService.retrieveFromSP");
    RetrieveSharePointRequestEntity retrieveEntity = (RetrieveSharePointRequestEntity) requestEntity;
    RetrievedDocument retrievedDocument;
    try {
//      service.connect();
      //retrievedDocument = service.retrieveDocumentObjectWithAttributes(retrieveEntity.getDocumentAttributes(),
      //    retrieveEntity.getRequiredAttributes());
      retrievedDocument = service.retrieveDocumentObjectWithAttributes_NoCopyService(retrieveEntity.getDocumentAttributes(),
          retrieveEntity.getRequiredAttributes());
    } catch (Exception e) {
      throw new DocumentManagerException(e);
    } finally {
//      closeService();
    }
    return retrievedDocument;
  }

  private String getSearchQuery(SearchSharePointRequestEntity searchSharePointRequestEntity) throws
      DocumentManagerException, IllegalAccessException,
      InvalidDctmAttrValueException, InstantiationException {
    SharePointQueryBuilder sharePointQueryBuilder = new SharePointQueryBuilder();
    String queryString;
    try {
      queryString = sharePointQueryBuilder.buildSearchQueryForDocumentId(searchSharePointRequestEntity, service);
    } catch (AttributeListParseException e) {
      throw new DocumentManagerException("Exception building query: " + e.getMessage(), e);
    } catch (DocumentManagerException e) {
      throw new DocumentManagerException("Exception building query: " + e.getMessage(), e);
    }
    return queryString;
  }

  private void addRetrievedDocumentToResponseEntity(ResponseEntity responseEntity,
                                                    RetrievedDocument retrievedDocument) {
    responseEntity.getRetrievedDocumentList().add(retrievedDocument);
  }

  private String getAttachmentLocation(UCCHelper helper) throws DocumentManagerException {
    //**Expecting only one attachment at a time, refactor this  method if this requirement changes.
    String attachmentLocation;
    try {
      List uploadedFileList = helper.getClientFiles();
      if (uploadedFileList != null && uploadedFileList.size() > 1) {
        attachmentLocation = (String) uploadedFileList.get(1);
      } else {
        throw new DocumentManagerException("Attachment not found.");
      }
    } catch (IOException e) {
      throw new DocumentManagerException("Exception while getting attachment from server scratch folder.", e);
    }
    return attachmentLocation;
  }

  private String getLocationOfNewContentsForUpdate(UCCHelper helper) throws DocumentManagerException {
    String attachmentLocation = null;
    try {
      List uploadedFileList = helper.getClientFiles();
      if (uploadedFileList != null && uploadedFileList.size() > 1) {
        attachmentLocation = (String) uploadedFileList.get(1);
      }
    } catch (IOException e) {
      throw new DocumentManagerException("Exception while getting attachment from server scratch folder.", e);
    }
    return attachmentLocation;
  }

  private RetrievedDocument insertIntoSP(RequestEntity requestEntity, String atttachmentLocation) throws
      DocumentManagerException {
    System.out.println("SharePointService.insertIntoSP");
    System.out.println("requestEntity = " + requestEntity);
    System.out.println("atttachmentLocation = " + atttachmentLocation);
    RetrievedDocument retrievedDocument;
    InsertSharePointRequestEntity insertSharePointRequestEntity = (InsertSharePointRequestEntity) requestEntity;
    try {
//      setupService();
      retrievedDocument = service
          .saveDocument(insertSharePointRequestEntity, insertSharePointRequestEntity.getDirectoryStructure(),
              atttachmentLocation);

//      commitTX();
      return retrievedDocument;
    } catch (Exception e) {
//      rollbackTX(e);
      throw new DocumentManagerException(String.format(
          "%s",
          e.getMessage()), e);
    } finally {
//      closeService();
    }
  }

}