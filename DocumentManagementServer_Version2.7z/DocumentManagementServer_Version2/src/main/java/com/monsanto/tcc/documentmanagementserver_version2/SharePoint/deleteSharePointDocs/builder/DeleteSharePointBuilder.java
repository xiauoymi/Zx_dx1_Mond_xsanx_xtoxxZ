package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.builder;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.entity.DeleteSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.entity.DeleteSharePointResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.parser.DeleteSharePointRequestParser;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 11, 2006
 * Time: 5:12:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteSharePointBuilder extends SharePointBuilder {

  public void buildParser() {
    setRequestParser(new DeleteSharePointRequestParser());
  }

  public void buildRequestEntity() {
    setRequestEntity(new DeleteSharePointRequestEntity());
  }

  public void buildResponseEntity() {
    setResponseEntity(new DeleteSharePointResponseEntity());
  }
}