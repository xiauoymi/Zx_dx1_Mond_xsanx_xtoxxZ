package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.entity;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 11, 2006
 * Time: 5:24:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteSharePointResponseEntity extends SharePointResponseEntity {

  protected String getServiceSpecificNodeName() {
    return DocumentManagerConstants.TAG_DELETE_DOCUMENT_SUCCESS_MESSAGE;
  }
}