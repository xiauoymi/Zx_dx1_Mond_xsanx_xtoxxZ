/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.entity;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author lakench
 * @version $Revision$
 */
public class InsertSharePointResponseEntity extends SharePointResponseEntity {
  @Override
  protected String getServiceSpecificNodeName() {
    return DocumentManagerConstants.TAG_INSERT_DOCUMENT_NODE_STR;
  }
}