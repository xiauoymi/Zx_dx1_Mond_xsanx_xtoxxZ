/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.parser;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.entity.InsertSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import org.w3c.dom.Node;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author lakench
 * @version $Revision$
 */
public class InsertSharePointRequestParser extends SharePointRequestParser {
  /* public void parseServiceSpecificRequest(Node node, SharePointRequestEntity requestEntity, String folderName) throws
      ServiceConfigException, EnvironmentHelperException, AttributeListParseException, DocumentManagerException,
      EncryptorException {
    super.parseServiceSpecificRequest(node, requestEntity, folderName);
    System.out.println("InsertSharePointRequestParser.parseServiceSpecificRequest");
    DOMUtil.outputXML(node);
  }*/

  public void parseOperationSpecificRequest(Node requestNode, SharePointRequestEntity sharePointRequestEntity) throws
      AttributeListParseException, DocumentManagerException {
    InsertSharePointRequestEntity insertSharePointRequestEntity = (InsertSharePointRequestEntity) sharePointRequestEntity;
    Node insertDocumentNode = DOMUtil.getChild(requestNode, DocumentManagerConstants.TAG_INSERT_DOCUMENT_NODE_STR);
    System.out.println("InsertSharePointRequestParser.parseOperationSpecificRequest");
    System.out.println("sharePointRequestEntity.getFolderName() = " + sharePointRequestEntity.getFolderName());
    DOMUtil.outputXML(insertDocumentNode);
    parseAttributes(insertDocumentNode, insertSharePointRequestEntity);
    parsePDFRendition(insertDocumentNode, insertSharePointRequestEntity);
  }

  private void parsePDFRendition(Node insertDocumentNode, InsertSharePointRequestEntity sharePointRequestEntity) {
    System.out.println("InsertSharePointRequestParser.parsePDFRendition");
    String childValue = DOMUtil.getChildValue(insertDocumentNode, DocumentManagerConstants.TAG_PDFRENDITION_STR);
    sharePointRequestEntity.setRequestPDFRendition((childValue == null || "false".equals(childValue)) ? false : true);
  }

  private void parseAttributes(Node insertDocumentNode,
                               InsertSharePointRequestEntity insertSharePointRequestEntity) throws
      DocumentManagerException {
    Node docAttributesNode = DOMUtil
        .getChild(insertDocumentNode, DocumentManagerConstants.TAG_NAME_DOCUMENT_ATTRIBUTES);
    parseAttributeList(docAttributesNode, insertSharePointRequestEntity);
  }
}