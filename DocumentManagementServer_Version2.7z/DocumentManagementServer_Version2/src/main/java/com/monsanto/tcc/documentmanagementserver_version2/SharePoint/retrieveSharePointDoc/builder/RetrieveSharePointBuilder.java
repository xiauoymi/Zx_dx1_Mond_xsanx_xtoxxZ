package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.builder;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.entity.RetrieveSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.entity.RetrieveSharePointResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.parser.RetrieveSharePointRequestParser;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 29, 2006
 * Time: 1:13:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveSharePointBuilder extends SharePointBuilder {

  public void buildParser() {
    setRequestParser(new RetrieveSharePointRequestParser());
  }

  public void buildRequestEntity() {
    setRequestEntity(new RetrieveSharePointRequestEntity());
  }

  public void buildResponseEntity() {
    setResponseEntity(new RetrieveSharePointResponseEntity());
  }
}