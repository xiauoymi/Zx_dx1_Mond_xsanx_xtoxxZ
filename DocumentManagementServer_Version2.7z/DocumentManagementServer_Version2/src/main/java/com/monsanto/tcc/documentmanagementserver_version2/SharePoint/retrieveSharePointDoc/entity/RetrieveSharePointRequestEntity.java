/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.entity;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointRequestEntity;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author lakench
 * @version $Revision$
 */
public class RetrieveSharePointRequestEntity extends SharePointRequestEntity {
  public RetrieveSharePointRequestEntity() {
  }
}