package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.entity;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.ResponseStreamWriter;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 3, 2006
 * Time: 1:16:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveSharePointResponseEntity extends SharePointResponseEntity {

  private ResponseStreamWriter responseStreamWriter;

  public RetrieveSharePointResponseEntity() {
    this.responseStreamWriter = new ResponseStreamWriter();
  }

  public void sendResponse(UCCHelper helper) throws AttributeListParseException, IOException {
    RetrievedDocument retrievedDocument = (RetrievedDocument) getRetrievedDocumentList().get(0);
    responseStreamWriter.writeSuccessfulRetrieveDocumentResponseToStream(retrievedDocument, helper);
  }

  protected String getServiceSpecificNodeName() {
    return null;
  }
}