package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.parser;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import org.w3c.dom.Node;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 29, 2006
 * Time: 10:28:05 AM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveSharePointRequestParser extends SharePointRequestParser {

  public void parseOperationSpecificRequest(Node requestDetailsNode, SharePointRequestEntity sharePointRequestEntity) throws DocumentManagerException {
    Node docAttributesNode = getAttributesNode(requestDetailsNode, DocumentManagerConstants.TAG_NAME_QUERY_ATTRIBUTES);
    parseAttributeList(docAttributesNode, sharePointRequestEntity);
    Node requiredAttributesNode = getAttributesNode(requestDetailsNode, DocumentManagerConstants.TAG_NAME_REQUIRED_ATTRIBUTES);
    if (customAttributesRequired(requiredAttributesNode)) {
      parseRequiredAttributeList(requiredAttributesNode, sharePointRequestEntity);
    }
  }

  private boolean customAttributesRequired(Node requiredAttributesNode) {
    return requiredAttributesNode != null;
  }

  private Node getAttributesNode(Node requestDetailsNode, String parentNodeName) {
    Node retrieveDocumentNode = DOMUtil.getChild(requestDetailsNode, getServiceNodeNameForParsingRequest());
    return DOMUtil.getChild(retrieveDocumentNode, parentNodeName);
  }

  protected String getServiceNodeNameForParsingRequest() {
    return DocumentManagerConstants.TAG_RETRIEVE_DOCUMENT_NODE_STR;
  }
}