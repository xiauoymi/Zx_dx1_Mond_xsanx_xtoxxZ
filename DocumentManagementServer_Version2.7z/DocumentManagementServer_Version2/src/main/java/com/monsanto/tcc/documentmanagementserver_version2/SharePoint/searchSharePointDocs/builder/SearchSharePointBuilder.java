package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.builder;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity.SearchSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity.SearchSharePointResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.parser.SearchSharePointRequestParser;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Jun 14, 2010
 * Time: 1:26:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class SearchSharePointBuilder extends SharePointBuilder {
	public void buildParser() {
		setRequestParser(new SearchSharePointRequestParser());
	}

	public void buildRequestEntity() {
		setRequestEntity(new SearchSharePointRequestEntity());
	}

	public void buildResponseEntity() {
		setResponseEntity(new SearchSharePointResponseEntity());
	}
}
