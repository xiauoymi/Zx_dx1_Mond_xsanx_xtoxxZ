package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity;

/**
 * Created by IntelliJ IDEA.
 * User: ffbrac
 * Date: Jan 28, 2011
 * Time: 10:53:35 AM
 * To change this template use File | Settings | File Templates.
 */
public class SearchResultEntity {
    private String id;
    private String chronicleId;
    private String fileRef;
    private String title;
    private String objectName;
    private String keywords;
    private String versionLabel;
    private String createdDate;
    private String modifiedDate;
    private String creator;
    private String editor;
    private String fileSize;
    private String currVersion;
    // deprecated attributes
    private String objectType;
    private String objectId;
    private String authors;
    private String subject;
    private String owner;

    public SearchResultEntity(String id, String chronicleId, String fileRef, String title, String objectName, String objectType, String objectId,
                              String keywords, String versionLabel, String createdDate, String modifiedDate,
                              String creator, String editor, String fileSize, String currVersion,
                              String authors, String subject, String owner) {
        this.chronicleId = chronicleId;
        this.fileRef = fileRef;
        this.title = title;
        this.objectName = objectName;
        this.objectType = objectType;
        this.objectId = objectId;
        this.keywords = keywords;
        this.versionLabel = versionLabel;
        this.createdDate = createdDate;
        this.modifiedDate = modifiedDate;
        this.creator = creator;
        this.editor = editor;
        this.fileSize = fileSize;
        this.currVersion = currVersion;
        this.authors = authors;
        this.subject = subject;
        this.owner = owner;
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public String getChronicleId() {
        return chronicleId;
    }

    public String getFileRef() {
        return fileRef;
    }

    public String getTitle() {
        return title;
    }

    public String getObjectName() {
        return objectName;
    }

    public String getObjectType() {
        return objectType;
    }

    public String getObjectId() {
        return objectId;
    }

    public String getKeywords() {
        return keywords;
    }

    public String getVersionLabel() {
        return versionLabel;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public String getCreator() {
        return creator;
    }

    public String getEditor() {
        return editor;
    }

    public String getFileSize() {
        return fileSize;
    }

    public String getCurrVersion() {
        return currVersion;
    }

    public String getAuthors() {
        return authors;
    }

    public String getSubject() {
        return subject;
    }

    public String getOwner() {
        return owner;
    }
}
