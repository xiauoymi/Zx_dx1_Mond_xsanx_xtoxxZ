package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;

/**
 * Created by IntelliJ IDEA.
 * User: MECORU
 * Date: Jun 15, 2010
 * Time: 7:46:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class SearchSharePointResponseEntity extends SharePointResponseEntity {

	protected String getServiceSpecificNodeName() {
		return DocumentManagerConstants.TAG_SEARCH_DOCUMENT_NODE_STR;
	}
}
