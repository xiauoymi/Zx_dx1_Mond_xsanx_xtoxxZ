package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.parser;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity.SearchSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import org.w3c.dom.Node;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 10, 2006
 * Time: 11:25:57 AM
 * To change this template use File | Settings | File Templates.
 */
public class SearchSharePointRequestParser extends SharePointRequestParser {

  public void parseOperationSpecificRequest(Node requestDetailsNode, SharePointRequestEntity sharepointRequestEntity) throws DocumentManagerException {
    SearchSharePointRequestEntity searchDocumentumRequestEntity = (SearchSharePointRequestEntity)sharepointRequestEntity;
    Node searchAllVersionsNode = getAttributesNode(requestDetailsNode, DocumentManagerConstants.TAG_NAME_SEARCH_ALL_VERSIONS);
    if (queryAttributesSpecified(searchAllVersionsNode)) {
      parseSearchAllVersionValue(searchAllVersionsNode, searchDocumentumRequestEntity);
    }
    Node docAttributesNode = getAttributesNode(requestDetailsNode, DocumentManagerConstants.TAG_NAME_QUERY_ATTRIBUTES);
    if (queryAttributesSpecified(docAttributesNode)) {
        //fix for search by ID -Vishal
        //parseAttributeList(docAttributesNode, searchDocumentumRequestEntity);
        parseAttributeList(docAttributesNode, searchDocumentumRequestEntity, DocumentManagerConstants.TAG_SEARCH_DOCUMENT_NODE_STR);
        //fix for search by ID -Vishal
    }
    Node requiredAttributesNode = getAttributesNode(requestDetailsNode, DocumentManagerConstants.TAG_NAME_REQUIRED_ATTRIBUTES);
    if (customAttributesRequired(requiredAttributesNode)) {
      parseRequiredAttributeList(requiredAttributesNode, searchDocumentumRequestEntity);
    }
  }

  private void parseSearchAllVersionValue(Node searchAllVersionsNode, SearchSharePointRequestEntity searchDocumentumRequestEntity) {
    String searchAllVersionsValue = DOMUtil.getTextValue(searchAllVersionsNode);
    if(searchAllVersionsValue.equalsIgnoreCase("true")){
      searchDocumentumRequestEntity.setSearchAllVersions(true);
    }
  }

  private boolean queryAttributesSpecified(Node docAttributesNode) {
    return docAttributesNode != null;
  }

  private boolean customAttributesRequired(Node requiredAttributesNode) {
    return requiredAttributesNode != null;
  }

  private Node getAttributesNode(Node requestDetailsNode, String parentNodeName) {
    Node retrieveDocumentNode = DOMUtil.getChild(requestDetailsNode, getServiceNodeNameForParsingRequest());
    return DOMUtil.getChild(retrieveDocumentNode, parentNodeName);
  }

  protected String getServiceNodeNameForParsingRequest() {
    return DocumentManagerConstants.TAG_SEARCH_DOCUMENT_NODE_STR;
  }
}