package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updateSharePointDoc.parser;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updateSharePointDoc.entity.UpdateSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.entity.DeleteSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumRequestEntity;
import org.w3c.dom.Node;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 11, 2006
 * Time: 5:23:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class UpdateSharePointRequestParser extends SharePointRequestParser {

 public void parseOperationSpecificRequest(Node requestDetailsNode, SharePointRequestEntity sharePointRequestEntity) throws DocumentManagerException {
    UpdateSharePointRequestEntity updateSharePointRequestEntity = (UpdateSharePointRequestEntity)sharePointRequestEntity;
    Node updateDocumentNode = DOMUtil
        .getChild(requestDetailsNode, DocumentManagerConstants.TAG_UPDATE_DOCUMENT_NODE_STR);
    Node docAttributesNode = getAttributesNode(requestDetailsNode, DocumentManagerConstants.TAG_NAME_DOCUMENT_ATTRIBUTES);
    parseAttributeList(docAttributesNode, updateSharePointRequestEntity);
    parsePDFRendition(updateDocumentNode, updateSharePointRequestEntity);
  }

  private Node getAttributesNode(Node requestDetailsNode, String parentNodeName) {
    Node retrieveDocumentNode = DOMUtil.getChild(requestDetailsNode, getServiceNodeNameForParsingRequest());
    return DOMUtil.getChild(retrieveDocumentNode, parentNodeName);
  }

  protected String getServiceNodeNameForParsingRequest() {
    return DocumentManagerConstants.TAG_UPDATE_DOCUMENT_NODE_STR;
  }
    private void parsePDFRendition(Node updateDocumentNode, UpdateSharePointRequestEntity documentumRequestEntity) {
    String childValue = DOMUtil.getChildValue(updateDocumentNode, DocumentManagerConstants.TAG_PDFRENDITION_STR);
    documentumRequestEntity.setRequestPDFRendition((childValue == null || "false".equals(childValue)) ? false : true);
  }
}