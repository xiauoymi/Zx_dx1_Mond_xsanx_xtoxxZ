package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.builder.InsertSharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.insertService.InsertDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.builder.InsertDocumentumBuilder;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 24, 2006 Time: 9:05:39 AM To change this template use File |
 * Settings | File Templates.
 */
public class MockInsertDocPOSForAppTest extends InsertDocumentPOS {
  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";

  protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
    return new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
  }

	protected DocBuilder getRepositorySpecificBuilder(String repositoryName) throws ServiceConfigException {
		System.out.println("MockInsertDocPOSForAppTest.getRepositorySpecificBuilder: "+repositoryName);
		if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.DOCUMENTUM_REPOSITORY_ID)) {
			return new MockDocBuilderForInsert();
		} else if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.SHAREPOINT_REPOSITORY_ID)) {
			return new MockInsertSharePointBuilderForInsert();
		}
		throw new ServiceConfigException();
  }

  class MockDocBuilderForInsert extends InsertDocumentumBuilder {
    public void buildParser() {
			System.out.println("MockInsertDocPOSForAppTest$MockDocBuilderForInsert.buildParser");
			setRequestParser(new MockInsertDocumentumRequestParser());
    }
  }

	class MockInsertSharePointBuilderForInsert extends InsertSharePointBuilder {
		public void buildParser() {
			System.out.println("MockInsertDocPOSForAppTest$MockInsertSharePointBuilderForInsert.buildParser");
			setRequestParser(new MockInsertSharePointRequestParser());
		}
	}

}