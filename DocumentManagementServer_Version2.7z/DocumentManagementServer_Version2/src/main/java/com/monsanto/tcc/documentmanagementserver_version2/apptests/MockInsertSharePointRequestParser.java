package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.ServiceConfig.SharePointServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.parser.InsertSharePointRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 24, 2006 Time: 5:12:05 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockInsertSharePointRequestParser extends InsertSharePointRequestParser {

  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";

  protected IServiceLookup getServiceConfigLookupInstance() throws ServiceConfigException {
    return new SharePointServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
  }
}