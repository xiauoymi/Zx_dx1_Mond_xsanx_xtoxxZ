package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.retrieveService.RetrieveDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.builder.RetrieveDocumentumBuilder;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Apr 17, 2006 Time: 5:59:12 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockRetrieveDocPOSForAppTest extends RetrieveDocumentPOS {

  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";

  protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
    return new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
  }

  public DocBuilder getRepositorySpecificBuilder(String repositoryName) throws ServiceConfigException {
		System.out.println("MockRetrieveDocPOSForAppTest.getRepositorySpecificBuilder: "+repositoryName);
		if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.DOCUMENTUM_REPOSITORY_ID)) {
			return new MockDocBuilderForRetrieve();
		} else if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.SHAREPOINT_REPOSITORY_ID)) {
			return new MockRetrieveSharePointBuilder();
		}
		throw new ServiceConfigException();
  }

  class MockDocBuilderForRetrieve extends RetrieveDocumentumBuilder {

    public void buildParser() {
			System.out.println("MockRetrieveDocPOSForAppTest$MockDocBuilderForRetrieve.buildParser");
			setRequestParser(new MockRetrieveDocumentumRequestParser());
    }
  }
}