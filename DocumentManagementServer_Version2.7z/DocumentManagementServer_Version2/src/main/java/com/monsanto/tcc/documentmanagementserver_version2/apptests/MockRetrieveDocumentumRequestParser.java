package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.parser.RetrieveDocumentumRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Mar 29, 2006 Time: 10:30:34 AM To change this template use File |
 * Settings | File Templates.
 */
public class MockRetrieveDocumentumRequestParser extends RetrieveDocumentumRequestParser {

  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";

  protected IServiceLookup getServiceConfigLookupInstance() throws ServiceConfigException {
    return new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
  }
}
