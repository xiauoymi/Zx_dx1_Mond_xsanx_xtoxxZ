package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.builder.RetrieveSharePointBuilder;

/**
 * Created by IntelliJ IDEA.
* User: mecoru
* Date: May 21, 2010
* Time: 1:10:10 PM
* To change this template use File | Settings | File Templates.
*/
public class MockRetrieveSharePointBuilder extends RetrieveSharePointBuilder {
public void buildParser() {
	setRequestParser(new MockRetrieveSharePointRequestParser());
}
}