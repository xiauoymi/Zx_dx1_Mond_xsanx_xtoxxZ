package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.ServiceConfig.SharePointServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.parser.RetrieveSharePointRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;

/**
 * Created by IntelliJ IDEA. User: mecoru Date: May 21, 2010 Time: 1:07:33 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockRetrieveSharePointRequestParser extends RetrieveSharePointRequestParser {
  protected IServiceLookup getServiceConfigLookupInstance() throws ServiceConfigException {
    return new SharePointServiceLookup(DocumentManagerConstants.TEST_SERVICE_CONFIG_FILE_NAME);
  }
}