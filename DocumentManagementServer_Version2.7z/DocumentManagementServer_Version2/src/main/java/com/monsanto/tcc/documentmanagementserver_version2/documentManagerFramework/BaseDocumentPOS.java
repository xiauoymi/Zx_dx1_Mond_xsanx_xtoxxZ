package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework;

import com.monsanto.POSServlet.BasePOSController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.security.LoginBrief;
import com.monsanto.security.LogonFailedException;
import com.monsanto.security.NoLogonInformationException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.response.ResponseHelper;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.AttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 22, 2006 Time: 1:36:01 PM To change this template use File |
 * Settings | File Templates.
 */
public abstract class BaseDocumentPOS extends BasePOSController {

  protected LoginBrief authorizeUser(UCCHelper helper, Document inputDocument) throws LogonFailedException,
      NoLogonInformationException {
    return null;
  }

  protected void runImplementation(UCCHelper helper, Document inputDocument) throws IOException {
    try {
      DocBuilder builder = getBuilder(inputDocument);
      builder.buildParser();
      builder.buildRequestEntity();
      builder.buildResponseEntity();
      builder.getRequestParser().parseInputXML(inputDocument, builder.getRequestEntity());
      try {
        authorizeUser(builder.getRequestEntity(), helper);
      } catch (DocumentManagerException e) {
        sendPOSErrorResponse(new Exception("User is not authorized to access this location"), helper);
        return;
      }
      builder.buildAttributeTransformer();
      transformToSystemSpecificAttributeNames(builder.getAttributeTransformer(), builder.getRequestEntity());
      builder.buildDocumentService(builder.getRequestEntity());
      System.out.println("BaseDocumentPOS.runImplementation: builder.getClass(); = " + builder.getClass().getName());
      performOperation(builder.getRequestEntity(), builder.getDocumentService(), builder.getResponseEntity(), helper);
      builder.getResponseEntity().sendResponseToClient(helper);
    } catch (ServiceConfigException e) {
      sendPOSErrorResponse(
          new ServiceConfigException("Service implementation for specified folder not found " + e.getMessage()),
          helper);
    } catch (EnvironmentHelperException e) {
      sendPOSErrorResponse(new EnvironmentHelperException("lsi environment variable not set:" + e.getMessage()),
          helper);
    } catch (AttributeListParseException e) {
      sendPOSErrorResponse(new AttributeListParseException(
          "Transformation of attribute names to service specific names failed: " + e.getMessage()), helper);
    } catch (DocumentManagerException e) {
      sendPOSErrorResponse(
          new Exception("Document Manager Exception while performing requested operation: " + e.getMessage()), helper);
    } catch (EncryptorException e) {
      sendPOSErrorResponse(
          new Exception("Exception in reading encrypted password for requested location: " + e.getMessage()), helper);
    }
  }

  private void authorizeUser(RequestEntity requestEntity, UCCHelper helper) throws AttributeListParseException,
      DocumentManagerException {
    ConnectionInfo connectionInfo = requestEntity.getConnectionInfo();
    if (connectionInfo.isFolderSecured()) {
      List userSecurityGroups = connectionInfo
          .getConnectionParameterValues(DocumentManagerConstants.SERVICE_CONFIG_STR_GROUPS);
      boolean userAuthorized = false;
      int i = 0;
      while (i < userSecurityGroups.size()) {
        String group = (String) userSecurityGroups.get(i);
        if (helper.isUserInRole(group)) {
          userAuthorized = true;
          break;
        }
        i++;
      }
      if (!userAuthorized) {
        throw new DocumentManagerException();
      }
    }
  }

  public abstract void performOperation(RequestEntity requestEntity, DocumentService service,
                                        ResponseEntity responseEntity, UCCHelper helper) throws
      DocumentManagerException;

  public DocBuilder getBuilder(Document inputDocument) throws ServiceConfigException {
    String repositoryName = null;
    try {
      IServiceLookup serviceLookup = instantiateServiceLookup();
      String folderName = RequestParser.parseFolderName(inputDocument);
      System.out.println("BaseDocumentPOS.getBuilder: folderName = " + folderName);
      repositoryName = serviceLookup.lookupRepositoryName(folderName);
      System.out.println("BaseDocumentPOS.getBuilder: repositoryName = " + repositoryName);
      return getRepositorySpecificBuilder(repositoryName);
    } catch (ServiceConfigException e) {
      throw new ServiceConfigException("No service found for specified folder: \"" + repositoryName + "\"");
    }
  }

  protected void sendPOSErrorResponse(Throwable e, UCCHelper helper) {
    ResponseHelper responseHelper = new ResponseHelper();
    Document errorDOM = responseHelper.sendPOSErrorResponse(e);
    helper.writeXMLDocument(errorDOM);
  }

  protected int getMaxImportFileSize() {
    return DocumentManagerConstants.CUSTOM_IMPORT_SIZE_LIMIT;
  }

  protected abstract DocBuilder getRepositorySpecificBuilder(String repositoryName) throws ServiceConfigException;

  protected abstract String getXMLSchemaRelativeToServletContext();

  protected void displayAndLogToError(final Throwable e, final UCCHelper helper) {
    sendPOSErrorResponse(e, helper);
  }

  protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
    return new ServiceLookup();
  }

  private void transformToSystemSpecificAttributeNames(AttributeTransformer attributeTransformer,
                                                       RequestEntity requestEntity) throws AttributeListParseException,
      DocumentManagerException {
    List transformationList = attributeTransformer.getTransformationList();
    requestEntity.transformAttrNamesToServiceSpecificAttrNames(transformationList);
  }
}