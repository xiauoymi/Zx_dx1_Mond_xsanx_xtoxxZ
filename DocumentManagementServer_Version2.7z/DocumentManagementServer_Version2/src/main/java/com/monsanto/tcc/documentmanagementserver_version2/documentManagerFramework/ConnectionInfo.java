package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;

import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 27, 2006 Time: 1:44:52 PM To change this template use File |
 * Settings | File Templates.
 */
public class ConnectionInfo {

  /**
   * Whether a folder/location configuration has security AD group(s)/role(s) (for kerberos authentication) assigned to
   * it.
   */
  private boolean folderSecured = false;
  private DocumentAttributes connectionParameters;

  public ConnectionInfo() {
    this.connectionParameters = new DocumentAttributes();
  }

  public boolean isFolderSecured() {
    return folderSecured;
  }

  public void setFolderSecured(boolean folderSecured) {
    this.folderSecured = folderSecured;
  }

  public void addConnectionParameter(String attributeName, String attributeValue) {
    connectionParameters.addAttribute(attributeName, attributeValue, null);
  }

  public void addConnectionParameter(String attributeName, List attributeValues) {
    connectionParameters.addAttribute(attributeName, attributeValues, null);
  }

  public String getConnectionParameterValue(String attributeName) throws AttributeListParseException {
    return connectionParameters.getAttrValue(attributeName);
  }

  public List getConnectionParameterValues(String attributeName) throws AttributeListParseException {
    return connectionParameters.getAttrValues(attributeName);
  }

  public Iterator getConnectionParameters() {
    return connectionParameters.getAttrIterator();
  }

  public boolean containsParameter(String parameterName) {
    return connectionParameters.containsAttribute(parameterName);
  }
}