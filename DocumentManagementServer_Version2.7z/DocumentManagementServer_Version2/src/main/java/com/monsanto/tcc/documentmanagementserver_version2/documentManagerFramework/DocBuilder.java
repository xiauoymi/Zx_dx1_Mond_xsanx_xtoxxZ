package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.AttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Feb 22, 2006
 * Time: 2:34:34 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class DocBuilder {

  private DocumentService documentService;
  private RequestParser requestParser;
  private RequestEntity requestEntity;
  private ResponseEntity responseEntity;
  private AttributeTransformer attributeTransformer;

  public DocumentService getDocumentService() {
    return documentService;
  }

  public void setDocumentService(DocumentService documentService) {
    this.documentService = documentService;
  }

  public RequestParser getRequestParser() {
    return requestParser;
  }

  public void setRequestParser(RequestParser requestParser) {
    this.requestParser = requestParser;
  }

  public RequestEntity getRequestEntity() {
    return requestEntity;
  }

  public void setRequestEntity(RequestEntity requestEntity) {
    this.requestEntity = requestEntity;
  }

  public ResponseEntity getResponseEntity() {
    return responseEntity;
  }

  public void setResponseEntity(ResponseEntity responseEntity) {
    this.responseEntity = responseEntity;
  }

  public AttributeTransformer getAttributeTransformer() {
    return attributeTransformer;
  }

  public void setAttributeTransformer(AttributeTransformer attributeTransformer) {
    this.attributeTransformer = attributeTransformer;
  }

  public abstract void buildParser();

  public abstract void buildDocumentService(RequestEntity requestEntity) throws AttributeListParseException;

  public abstract void buildRequestEntity();

  public abstract void buildAttributeTransformer();

  public abstract void buildResponseEntity();
}
