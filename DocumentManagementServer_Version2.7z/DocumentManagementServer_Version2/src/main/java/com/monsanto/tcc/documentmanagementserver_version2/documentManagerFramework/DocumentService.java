package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.RetrieveDocumentumRequestEntity;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Feb 24, 2006
 * Time: 1:50:14 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class DocumentService {

  public abstract void insert(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper helper) throws DocumentManagerException;

  public abstract void retrieve(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper helper) throws DocumentManagerException;

  public abstract void search(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper mockHelper) throws DocumentManagerException;

  public abstract void delete(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper mockHelper) throws DocumentManagerException, AttributeListParseException;

  public abstract void update(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper helper) throws DocumentManagerException;
}
