package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.TransformationObject;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 24, 2006 Time: 1:48:16 PM To change this template use File |
 * Settings | File Templates.
 */
public class RequestEntity {

  private String folderName = null;
  private String directoryStructure = null;
  private DocumentAttributes documentAttributes = new DocumentAttributes();
  private List requiredAttributes = new ArrayList();
  private boolean searchAllVersions = false;
  private ConnectionInfo connectionInfo;

  public ConnectionInfo getConnectionInfo() {
    return connectionInfo;
  }

  public void setConnectionInfo(ConnectionInfo connectionInfo) {
    this.connectionInfo = connectionInfo;
  }

  public List getRequiredAttributes() {
    return requiredAttributes;
  }

  public String getFolderName() {
    return folderName;
  }

  public String getDirectoryStructure() {
    return directoryStructure;
  }

  public void setFolderName(String folderName) {
    this.folderName = folderName;
  }

  public void setDirectoryStructure(String directoryStructure) {
    this.directoryStructure = directoryStructure;
  }

  public DocumentAttributes getDocumentAttributes() {
    return documentAttributes;
  }

  public boolean isSearchAllVersions() {
    return searchAllVersions;
  }

  public void setSearchAllVersions(boolean searchAllVersions) {
    this.searchAllVersions = searchAllVersions;
  }

  public void transformAttrNamesToServiceSpecificAttrNames(List transformationList) throws AttributeListParseException,
      DocumentManagerException {
    TransformationObject transformationObject;
    String coreAttrName;
    String serviceSpecificAttrName;
    for (Object aTransformationList : transformationList) {
      transformationObject = (TransformationObject) aTransformationList;
      coreAttrName = transformationObject.getCoreAttrName();
      serviceSpecificAttrName = transformationObject.getServiceSpecificAttrName();
      if (!requestContainsServiceSpecificAttributeName(serviceSpecificAttrName)) {
        documentAttributes.transformAttributeName(coreAttrName, serviceSpecificAttrName);
        transformRequiredAttributeName(coreAttrName, serviceSpecificAttrName);
      } else {
        throw new DocumentManagerException(
            "Service-specific attribute name \"" + serviceSpecificAttrName + "\" found in the request,"
                + " Please use the attribute name \"" + coreAttrName + "\" in your request");
      }
    }
  }

  private boolean requestContainsServiceSpecificAttributeName(String serviceSpecificAttrName) {
    return documentAttributes.containsAttribute(serviceSpecificAttrName) ||
        requiredAttributes.contains(serviceSpecificAttrName);
  }

  private void transformRequiredAttributeName(String actualAttrName, String transformedAttrName) {
    if (requiredAttributes.contains(actualAttrName)) {
      int indexOfActualAttribute = requiredAttributes.indexOf(actualAttrName);
      requiredAttributes.set(indexOfActualAttribute, transformedAttrName);
    }
  }
}