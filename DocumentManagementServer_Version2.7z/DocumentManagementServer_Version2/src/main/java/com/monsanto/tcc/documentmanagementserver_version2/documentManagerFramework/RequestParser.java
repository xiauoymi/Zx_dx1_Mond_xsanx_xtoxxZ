package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.Util.StringUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Feb 23, 2006
 * Time: 3:33:48 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class RequestParser {

  public static String parseFolderName(Document inputDocument) {
    return getRootChildValue(inputDocument, "folder");
  }

  public void parseInputXML(Document inputDocument, RequestEntity requestEntity) throws ServiceConfigException, EnvironmentHelperException, AttributeListParseException, DocumentManagerException, EncryptorException {
    String folderName = parseFolderName(inputDocument);
    Node requestNode = DOMUtil.getChild(inputDocument.getDocumentElement(), "requestDetails");
    parseServiceSpecificRequest(requestNode, requestEntity, folderName);
    parseRequest(inputDocument, requestEntity, folderName);
  }

  public abstract void parseServiceSpecificRequest(Node node, RequestEntity requestEntity, String folderName) throws ServiceConfigException, EnvironmentHelperException, AttributeListParseException, DocumentManagerException, EncryptorException;

  private void parseRequest(Document inputDocument, RequestEntity requestEntity, String folderName) {
    requestEntity.setFolderName(folderName);
    requestEntity.setDirectoryStructure(parseDirctoryStructure(inputDocument));
  }

  private static String getRootChildValue(Document inputDocument, String elementName) {
    Node node = DOMUtil.getChild(inputDocument.getDocumentElement(), elementName);
    if (node != null) {
      return DOMUtil.getTextValue(node);
    }
    return "";
  }

  private String parseDirctoryStructure(Document inputDocument) {
    return getRootChildValue(inputDocument, "directoryStructure");
  }

  protected void parseAttributeList(Node docAttributesNode, RequestEntity requestEntity) throws DocumentManagerException {
    Node[] attributeList = DOMUtil.getChildren(docAttributesNode, DocumentManagerConstants.TAG_ATTRIBUTE_NODE_STR);
    int numberOfAttributes = attributeList.length;
    for (int i = 0; i < numberOfAttributes; i++) {
      Node attrNode = attributeList[i];
      parseAtrributeNode(attrNode, requestEntity);
    }
  }
  protected void parseAttributeList(Node docAttributesNode, RequestEntity requestEntity, String opsType) throws DocumentManagerException {
    Node[] attributeList = DOMUtil.getChildren(docAttributesNode, DocumentManagerConstants.TAG_ATTRIBUTE_NODE_STR);
    int numberOfAttributes = attributeList.length;
    for (int i = 0; i < numberOfAttributes; i++) {
      Node attrNode = attributeList[i];
      parseAtrributeNode(attrNode, requestEntity, opsType);
    }
  }
  private void parseAtrributeNode(Node attrNode, RequestEntity requestEntity, String opsType) {
    String attributeName = DOMUtil.getChildValue(attrNode, DocumentManagerConstants.TAG_NAME_NODE_STR);
    if (opsType.equals(DocumentManagerConstants.TAG_SEARCH_DOCUMENT_NODE_STR) && attributeName.equals(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID))
             attributeName= DocumentManagerConstants.DCTM_ATTR_STR_CHRONICLE_ID;
    List attrValues = parseAttributeValues(attrNode);
    String operatorValue = parseOperatorValue(attrNode);
    if (attrValues.size() > 1) {
        requestEntity.getDocumentAttributes().addAttribute(attributeName, attrValues, operatorValue);
    }
    else{
      requestEntity.getDocumentAttributes().addAttribute(attributeName, (String) attrValues.get(0), operatorValue);
    }
  }
  private void parseAtrributeNode(Node attrNode, RequestEntity requestEntity) {
    String attributeName = DOMUtil.getChildValue(attrNode, DocumentManagerConstants.TAG_NAME_NODE_STR);
    List attrValues = parseAttributeValues(attrNode);
    String operatorValue = parseOperatorValue(attrNode);
    if (attrValues.size() > 1) {
        requestEntity.getDocumentAttributes().addAttribute(attributeName, attrValues, operatorValue);
    }
    else{
      requestEntity.getDocumentAttributes().addAttribute(attributeName, (String) attrValues.get(0), operatorValue);
    }
  }

  protected void parseRequiredAttributeList(Node requiredAttributesNode, RequestEntity requestEntity) {
    Node[] attributeList = DOMUtil.getChildren(requiredAttributesNode, DocumentManagerConstants.TAG_ATTRIBUTE_NODE_STR);
    int numberOfAttributes = attributeList.length;
    for (int i = 0; i < numberOfAttributes; i++) {
      Node attrNode = attributeList[i];
      String attributeName = DOMUtil.getTextValue(attrNode);
      requestEntity.getRequiredAttributes().add(attributeName);
    }
  }

  private List parseAttributeValues(Node attrNode) {
    List attrValues = new ArrayList();
    Node[] valueNodeList = DOMUtil.getChildren(attrNode, DocumentManagerConstants.TAG_VALUE_NODE_STR);
    int valueListLength = valueNodeList.length;
    for (int i = 0; i < valueListLength; i++) {
      attrValues.add(DOMUtil.getTextValue(valueNodeList[i]));
    }
    return attrValues;
  }

  private String parseOperatorValue(Node attrNode) {
    String operator = null;
    Node operatorNode = DOMUtil.getChild(attrNode, DocumentManagerConstants.TAG_OPERATOR_NODE_STR);
    if (operatorNode != null) {
      operator = DOMUtil.getTextValue(operatorNode);
    }
    return operator;
  }
}