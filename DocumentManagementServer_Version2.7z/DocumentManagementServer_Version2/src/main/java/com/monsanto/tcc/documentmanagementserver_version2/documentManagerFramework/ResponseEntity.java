package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.AttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.response.ResponseHelper;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 3, 2006 Time: 1:07:38 PM To change this template use File |
 * Settings | File Templates.
 */
public abstract class ResponseEntity {

  private List retrievedDocumentList;

  protected ResponseEntity() {
    this.retrievedDocumentList = new ArrayList();
  }

  public List getRetrievedDocumentList() {
    return retrievedDocumentList;
  }

  public void sendResponseToClient(UCCHelper helper) throws AttributeListParseException, IOException {
    backTransformCoreAttributeNames();
    sendResponse(helper);
  }

  protected void sendResponse(UCCHelper helper) throws AttributeListParseException, IOException {
    Document outputDocument = DOMUtil.newDocument();
    Node serviceSpecificNode = buildHeaderNodes(outputDocument);
    addAllRetrievedDocumentsToResponse(serviceSpecificNode);
    writeResponseAsXMLToHelper(helper, outputDocument);
  }

  private void addAllRetrievedDocumentsToResponse(Node serviceSpecificNode) throws AttributeListParseException {
    DOMUtil.outputXML(serviceSpecificNode);
    for (int i = 0; i < retrievedDocumentList.size(); i++) {
      Node documentDetailsNode = buildDocumentDetailsNode(serviceSpecificNode);
      DocumentAttributes documentAttributes = ((RetrievedDocument) retrievedDocumentList.get(i))
          .getDocumentAttributes();
      documentAttributes.addAllDocumentAttributesToXMLResponse(documentDetailsNode);
    }
  }

  private Node buildDocumentDetailsNode(Node serviceSpecificNode) {
    return DOMUtil.addChildElement(serviceSpecificNode, DocumentManagerConstants.TAG_DOCUMENT_DETAILS_NODE_STR);
  }

  private void writeResponseAsXMLToHelper(UCCHelper helper, Document outputDocument) {
    helper.writeXMLDocument(outputDocument, "UTF-16");
  }

  private Node buildHeaderNodes(Document outputDocument) {
    System.out.println("ResponseEntity.buildHeaderNodes");
    ResponseHelper responseHelper = new ResponseHelper();
    return responseHelper.buildSuccessResponseHeader(outputDocument, getServiceSpecificNodeName());
  }

  protected abstract String getServiceSpecificNodeName();

  public void backTransformCoreAttributeNames() throws AttributeListParseException {
    RetrievedDocument retrievedDocument;
    for (int i = 0; i < retrievedDocumentList.size(); i++) {
      retrievedDocument = (RetrievedDocument) retrievedDocumentList.get(i);
      AttributeTransformer AttributeTransformer = buildAttributeTransformer();
      if (retrievedDocument == null) {
        System.out.println("@@@Gotcha!! the retrievedDocument is obviously null here for some unknown reason :(");
      }
      retrievedDocument.getDocumentAttributes().backTransformAttrNamesToServiceSpecificAttrNames(
          AttributeTransformer.getTransformationList());
    }
  }

  protected abstract AttributeTransformer buildAttributeTransformer();
}