package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 30, 2006
 * Time: 10:04:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class RetrievedDocument {

  private DocumentAttributes documentAttributes  = new DocumentAttributes();

  public DocumentAttributes getDocumentAttributes() {
    return documentAttributes;
  }
}