package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Apr 19, 2006
 * Time: 1:22:39 PM
 * To change this template use File | Settings | File Templates.
 */
public interface AttributeTransformer {

  List getTransformationList();
}