package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Apr 28, 2006
 * Time: 10:57:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class TransformationObject {

  private String coreAttrName;
  private String serviceSpecificAttrName;

  public TransformationObject(String coreAttrName, String serviceSpecificAttrName) {
    this.coreAttrName = coreAttrName;
    this.serviceSpecificAttrName = serviceSpecificAttrName;
  }

  public String getCoreAttrName() {
    return coreAttrName;
  }

  public String getServiceSpecificAttrName() {
    return serviceSpecificAttrName;
  }
}