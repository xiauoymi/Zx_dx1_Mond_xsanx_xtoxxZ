package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 23, 2006 Time: 3:48:30 PM To change this template use File |
 * Settings | File Templates.
 */
public class DocumentManagerConstants {

  public static final String OPERATOR_EQUALS = "equals";
  public static Map operatorMap;

  static {
    operatorMap = new HashMap();
    operatorMap.put(OPERATOR_EQUALS, " = ");
  }

  public static final String ATTR_STR_UPDATE_VERSION = "updateVersion";
  public static final String NEXT_MAJOR_VERSION = "nextMajor";
  public static final String NEXT_MINOR_VERSION = "nextMinor";
  public static final String SAME_VERSION = "same";
  public static Map updateVersionValueList;

  static {
    updateVersionValueList = new HashMap();
    updateVersionValueList.put(NEXT_MAJOR_VERSION, "0");
    updateVersionValueList.put(NEXT_MINOR_VERSION, "1");
    updateVersionValueList.put(SAME_VERSION, "2");
  }
  //(values correspond to Dctm constants present in interface IDfCheckinOperation)

  public static final String CONTEXT_NAME = "entdocumentservice";
  public static final String SERVICE_CONFIG_FILE_NAME = "ServiceConfig.xml";
  public static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";

  public static final int CUSTOM_IMPORT_SIZE_LIMIT = 300 * 1024 * 1024;

  public static final String SCHEMA_INSERT_DOC_POS = "com/monsanto/tcc/documentmanagementserver_version2/xmlSchemas/InsertDocumentRequest.xsd";
  public static final String SCHEMA_SEARCH_DOC_POS = "com/monsanto/tcc/documentmanagementserver_version2/xmlSchemas/SearchDocumentsRequest.xsd";
  public static final String SCHEMA_DELETE_DOC_POS = "com/monsanto/tcc/documentmanagementserver_version2/xmlSchemas/DeleteDocumentRequest.xsd";
  public static final String SCHEMA_RETRIEVE_DOC_POS = "com/monsanto/tcc/documentmanagementserver_version2/xmlSchemas/RetrieveDocumentRequest.xsd";
  public static final String SCHEMA_UPDATE_DOC_POS = "com/monsanto/tcc/documentmanagementserver_version2/xmlSchemas/UpdateDocumentRequest.xsd";

  public static final String DOCUMENTUM_REPOSITORY_ID = "Dctm";
  public static final String SHAREPOINT_REPOSITORY_ID = "SharePoint";
  public static final String SP_CI_SITE_NAME = "site";
  public static final String SP_CI_DOC_LIB_NAME = "documentLibrary";
  public static final String STRING_DOCBROKER = "docBroker";
  public static final String STRING_USERNAME = "userName";
  public static final String STRING_PASSWORD = "password";
  public static final String STRING_DOCBASE = "docBase";
  public static final String STRING_CABINET = "cabinet";
  public static final String STRING_OBJECT_TYPE = "objectType";
  public static final String STRING_MTS = "dm_mediaserver";
  public static final String STRING_DTS = "dm_autorender_win31";

  public static final String TEMP_DIRECTORY = "java.io.tmpdir";


  public static final String ATTR_STR_TITLE = "title";
  public static final String ATTR_STR_CONTENTS = "contents";
  public static final String ATTR_STR_FULL_TEXT = "full_text";

  //**General Name for Core Attributes
  public static final String ATTR_STR_NAME = "name";
  public static final String ATTR_STR_UNIQUE_DOCUMENT_ID = "objectId";
  public static final String ATTR_STR_SIZE = "size";
  public static final String ATTR_STR_CREATOR = "creator";
  public static final String ATTR_STR_DATE_CREATED = "dateCreated";
  public static final String ATTR_STR_MODIFIER = "modifier";
  public static final String ATTR_STR_DATE_MODIFIED = "dateModified";
  public static final String ATTR_STR_VERSION = "version";
  public static final String ATTR_STR_DATE_LOCKED = "dateLocked";
  public static final String ATTR_STR_LOCK_OWNER = "lockOwner";
  public static final String ATTR_STR_SUBJECT = "subject";
  public static final String ATTR_STR_KEYWORDS = "keywords";
  public static final String ATTR_STR_PAGE_COUNT = "pageCount";
  public static final String ATTR_STR_DATE_LAST_ACCESSED = "dateLastAccessed";
    public static final String ATTR_STR_AUTHORS = "authors";
    public static final String ATTR_STR_OWNER = "owner";

  public static final String DCTM_ATTR_STR_FORMAT = "format";
  public static final String DCTM_ATTR_STR_CHRONICLE_ID = "i_chronicle_id";

  //**Sharepoint Specific Attribute Names...
  public static final String SHAREPOINT_ATTR_ID = "i_chronicle_id";
  public static final String SHAREPOINT_ATTR_VERSION = "Version";
  public static final String SHAREPOINT_ATTR_STR_SIZE = "File Size";
  public static final String SHAREPOINT_ATTR_SUBJECT = "Subject";

  public static final String SHAREPOINT_ATTR_STR_UNIQUE_DOCUMENT_ID = "objectId";
  public static final String SHAREPOINT_ATTR_STR_TITLE = "Title";

  public static final String SHAREPOINT_ATTR_STR_SUBJECT = "Subject";
  public static final String SHAREPOINT_ATTR_STR_KEYWORDS = "Keywords";
  public static final String SHAREPOINT_ATTR_STR_NAME = "POSName";

  public static final String SHAREPOINT_ATTR_DATE_CREATED = "Created";
  public static final String SHAREPOINT_ATTR_DATE_MODIFIED = "Modified";
  public static final String SHAREPOINT_ATTR_STR_MODIFIER = "Modified By";
  public static final String SHAREPOINT_ATTR_STR_CREATOR = "Created By";
    public static final String SHAREPOINT_ATTR_STR_AUTHOR = "Authors";
    public static final String SHAREPOINT_ATTR_STR_OWNER = "Owner";
   public static final String SHAREPOINT_ATTR_STR_OBJNAME = "object_name";
  //public static final String SHAREPOINT_ATTR_STR_CREATOR = "Document Created By";

  //**Dctm Specific Attribute Names...
  public static final String DCTM_ATTR_STR_NAME = "object_name";
  public static final String DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID = "r_object_id";
  public static final String DCTM_ATTR_STR_SIZE = "r_content_size";
  public static final String DCTM_ATTR_STR_CREATOR = "owner_name";
  public static final String DCTM_ATTR_STR_DATE_CREATED = "r_creation_date";
  public static final String DCTM_ATTR_STR_MODIFIER = "r_modifier";
  public static final String DCTM_ATTR_STR_DATE_MODIFIED = "r_modify_date";
  public static final String DCTM_ATTR_STR_VERSION = "r_version_label";
  public static final String DCTM_ATTR_STR_DATE_LOCKED = "r_lock_date";
  public static final String DCTM_ATTR_STR_LOCK_OWNER = "r_lock_owner";
  public static final String DCTM_ATTR_STR_SUBJECT = "subject";
  public static final String DCTM_ATTR_STR_KEYWORDS = "keywords";
  public static final String DCTM_ATTR_STR_PAGE_COUNT = "r_page_cnt";

  public static final String DCTM_ATTR_STR_DATE_LAST_ACCESSED = "r_access_date";
  public static final String DCTM_ATTR_STR_AUTHORS = "authors";
  //**Tag Names for building response...
  public static final String TAG_INSERT_DOCUMENT_NODE_STR = "insertDocument";
  public static final String TAG_RETRIEVE_DOCUMENT_NODE_STR = "retrieveDocument";
  public static final String TAG_SEARCH_DOCUMENT_NODE_STR = "searchDocuments";
  public static final String TAG_DELETE_DOCUMENT_NODE_STR = "deleteDocument";
  public static final String TAG_UPDATE_DOCUMENT_NODE_STR = "updateDocument";
  public static final String TAG_DELETE_DOCUMENT_SUCCESS_MESSAGE = "documentDeletedSuccessfully";
  public static final String TAG_UPDATE_DOCUMENT_SUCCESS_MESSAGE = "documentUpdatedSuccessfully";
  public static final String TAG_NAME_DOCUMENT_ATTRIBUTES = "documentAttributes";
  public static final String TAG_NAME_QUERY_ATTRIBUTES = "queryAttributes";
  public static final String TAG_NAME_REQUIRED_ATTRIBUTES = "requiredAttributes";
  public static final String TAG_NAME_SEARCH_ALL_VERSIONS = "searchAllVersions";
  public static final String TAG_DOCUMENT_MANAGER_RESPONSE_NODE_STR = "documentManagerResponse";
  public static final String TAG_DOCUMENT_DETAILS_NODE_STR = "documentDetails";
  public static final String TAG_ATTRIBUTE_NODE_STR = "attribute";
  public static final String TAG_NAME_NODE_STR = "name";
  public static final String TAG_OPERATOR_NODE_STR = "operator";
  public static final String TAG_VALUE_NODE_STR = "value";
  //**Query Strings...
  public static final String SPACE_SEPERATOR = " ";
  public static final String COMMA_SEPERATOR = ",";
  public static final String QUERY_PARAM_SELECT_STR = "SELECT ";
  public static final String QUERY_PARAM_FROM_STR = "FROM ";
  public static final String QUERY_PARAM_WHERE_STR = "WHERE ";
  public static final String QUERY_PARAM_AND_STR = "AND ";
  public static final String QUERY_PARAM_SEARCH_STR = "SEARCH DOCUMENT CONTAINS ";
  public static final String QUERY_PARAM_FOLDER_STR = "FOLDER";
  public static final String QUERY_PARAM_ANY_STR = "ANY ";
  public static final String QUERY_PARAM_DATE_STR = "DATE";

  public static final String QUERY_PARAM_DESCEND_STR = "DESCEND";
  public static final String QUERY_PARAM_ALL_VERSIONS_STR = "(ALL)";
  //**Dctm Data Types (values correspond to Dctm constants present in interface IdfType)
  public static final int DCTM_TYPE_BOOLEAN = 0;
  public static final int DCTM_TYPE_INT = 1;
  public static final int DCTM_TYPE_STRING = 2;
  public static final int DCTM_TYPE_ID = 3;
  public static final int DCTM_TYPE_DATE_TIME = 4;

  public static final int DCTM_TYPE_DOUBLE = 5;
  public static final int DCTM_TYPE_UNDEFINED = 6;
  //**Service Config tag/element/attr name constant strings
  public static final String SERVICE_CONFIG_STR_GROUPS = "groups";
  public static final String SERVICE_CONFIG_STR_CONNECTION_DETAILS = "connectionDetails";
  public static final String SERVICE_CONFIG_STR_GROUP = "group";
  public static final String SERVICE_CONFIG_STR_REPOSITORY = "repository";
  public static final String SERVICE_CONFIG_STR_FOLDER = "folder";
  public static final String SERVICE_CONFIG_STR_ENVIRONMENT = "environment";
  public static final String SERVICE_CONFIG_STR_FOLDER_NAME_ATTRIBUTE = "name";
  public static final String ENV_VARIABLE_MONCRYPTJV = "MONCRYPTJV";

  public static final String FILE_ENCRYPTED_PWD_VALUE = "CipherValue.hex";

  public static final String FILE_ENCRYPTED_PWD_KEY = "KeyValue.hex";
  public static final String LABEL_CURRENT_VERSION_DCTM = "CURRENT";
  public static final String RESP_CONST_ALL_VERSIONS_DELETED = "allVersions";
  public static final String TAG_PDFRENDITION_STR = "requestPDFRendition";
  public static final String DCTM_ATTR_STR_QUEUE_MESSAGE = "message";

  public static final String DCTM_ATTR_STR_QUEUE_EVENT = "event";
  public static final String DCTM_ATTR_STR_QUEUE_OWNER_NAME = "queueOwner";

  public static final String TEXT_DOC_FILETYPE = "txt";
  public static final String WORD_DOC_FILETYPE = "doc";
}