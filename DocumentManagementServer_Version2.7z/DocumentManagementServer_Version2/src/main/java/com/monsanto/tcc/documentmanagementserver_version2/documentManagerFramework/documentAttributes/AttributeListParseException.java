package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Mar 28, 2006
 * Time: 6:50:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class AttributeListParseException extends Exception{

  public AttributeListParseException(String message) {
    super(message);
    logMessage(message);
  }

  private void logMessage(String message) {
    logMessage();
    Logger.log(new LoggableError("Message: " + message));
  }

  private void logMessage() {
    Logger.log(new LoggableError("Attribute List Parse Exception..."));
  }

//  public AttributeListParseException() {
//  }

//  public AttributeListParseException(Throwable cause) {
//    super(cause.getMessage(), cause);
//    logMessage(cause.getMessage());
//    logTrace(cause);
//  }

//  public AttributeListParseException(String message, Throwable cause) {
//    super(message, cause);
//    logMessage(message);
//    logTrace(cause);
//  }


//  private void logTrace(Throwable cause) {
//    Logger.log(new LoggableError("Stack Trace: " + cause));
//  }
}
