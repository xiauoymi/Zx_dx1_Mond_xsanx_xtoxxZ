package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Mar 28, 2006
 * Time: 6:30:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class AttributeValue {

  private boolean multipleValued = false;
  private String attrValue = null;
  private List attrValues = new ArrayList();
  private String operator = null;

  public AttributeValue(String attrValue, String operator) {
    this.multipleValued = false;
    this.attrValue = attrValue;
    this.operator = operator;
  }

  public AttributeValue(List attrValues, String operator) {
    this.multipleValued = true;
    this.attrValues = attrValues;
    this.operator = operator;
  }

  public boolean isMultipleValued() {
    return multipleValued;
  }

  public String getAttrValue() {
    return attrValue;
  }

  public List getAttrValues() {
    return attrValues;
  }

  public String getOperator() {
    return operator;
  }
}