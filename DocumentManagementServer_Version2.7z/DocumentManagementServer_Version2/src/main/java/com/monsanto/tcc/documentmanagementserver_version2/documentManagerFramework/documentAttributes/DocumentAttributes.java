package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes;


import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.microsoft.schemas.sharepoint.soap.FieldInformation;
import com.microsoft.schemas.sharepoint.soap.FieldType;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.TransformationObject;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import org.w3c.dom.Node;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Mar 24, 2006 Time: 1:12:16 PM To change this template use File |
 * Settings | File Templates.
 */

public class DocumentAttributes {
	private static final String CR_LF = "\r\n";
  private Map attributeMap = new HashMap();
  private AttributeValue currentAttributeValue = null;

  public void addAttribute(String attributeName, String attributeValue, String operator) {
    if (!StringUtils.isNullOrEmpty(attributeName) && !StringUtils.isNullOrEmpty(attributeValue)) {
      attributeMap.put(attributeName, new AttributeValue(attributeValue, operator));
    }
  }

  public void addAttribute(String attributeName, List attrValues, String operator) {
    int numberOfAttrValues;
    if (!StringUtils.isNullOrEmpty(attributeName) && attrValues != null) {
      numberOfAttrValues = attrValues.size();
      if (numberOfAttrValues > 0) {
        attributeMap.put(attributeName, new AttributeValue(attrValues, operator));
      }
    }
  }

  public String getAttrValue(String attributeName) throws AttributeListParseException {
    if (attributePresent(attributeName)) {
      if (!currentAttributeValue.isMultipleValued()) {
        return currentAttributeValue.getAttrValue();
      } else {
        throw new AttributeListParseException("The Attribute \"" + attributeName + "\" has multiple values.");
      }
    }
    throw new AttributeListParseException("The Attribute \"" + attributeName + "\" not present.");
  }

  public List getAttrValues(String attributeName) throws AttributeListParseException {
    if (attributePresent(attributeName)) {
      if (currentAttributeValue.isMultipleValued()) {
        return currentAttributeValue.getAttrValues();
      } else {
        throw new AttributeListParseException("The Attribute \"" + attributeName + "\" has single value.");
      }
    }
    throw new AttributeListParseException("The Attribute \"" + attributeName + "\" not present.");
  }

  /**
   * Operator is an optional property and thus the method below can return null, if operator not present.
   *
   * @param attributeName
   *
   * @return
   *
   * @exception AttributeListParseException
   */
  public String getOperator(String attributeName) throws AttributeListParseException {
    if (attributePresent(attributeName)) {
      return currentAttributeValue.getOperator();
    }
    throw new AttributeListParseException("The Attribute \"" + attributeName + "\" not present.");
  }

  public boolean hasMultipleValues(String attributeName) throws AttributeListParseException {
    if (attributePresent(attributeName)) {
      return currentAttributeValue.isMultipleValued();
    }
    throw new AttributeListParseException("The Attribute \"" + attributeName + "\" not present.");
  }

  public int getLength() {
    return attributeMap.size();
  }

  public Iterator getAttrIterator() {
    return attributeMap.keySet().iterator();
  }

  public void removeAttr(String attributeName) {
    if (attributeMap.containsKey(attributeName)) {
      attributeMap.remove(attributeName);
    }
  }

  public boolean containsAttribute(String attributeName) {
    return attributeMap.containsKey(attributeName);
  }

  public void addAllAttributesToDFCSysObject(IDfSysObject sysObj) throws AttributeListParseException, DfException {
    Iterator attributeIterator = getAttrIterator();
    while (attributeIterator.hasNext()) {
      String attributeName = (String) attributeIterator.next();
      if (hasMultipleValues(attributeName)) {
        addMultipleAttrValuesToDFCSysObject(sysObj, attributeName);
        continue;
      }
      addSingleAttrValueToDFCSysObject(sysObj, attributeName);
    }
  }

  public void addAllDocumentAttributesToXMLResponse(Node documentDetailsNode) throws AttributeListParseException {
    Iterator documentAttrIt = getAttrIterator();
    while (documentAttrIt.hasNext()) {
      Node attributeNode = buildAttributeNode(documentDetailsNode);
      String attrName = (String) documentAttrIt.next();
      buildNameNode(attributeNode, attrName);
      if (hasMultipleValues(attrName)) {
        addMultipleAttrValuesToXMLResponse(attrName, attributeNode);
        continue;
      }
      addSingleAttrValueToXMLResponse(attrName, attributeNode);
    }
  }

  public void backTransformAttrNamesToServiceSpecificAttrNames(List transformationList) throws
      AttributeListParseException {
    TransformationObject transformationObject;
    String coreAttrName;
    String serviceSpecificAttrName;
    Iterator transformationListIterator = transformationList.iterator();
    while (transformationListIterator.hasNext()) {
      transformationObject = (TransformationObject) transformationListIterator.next();
      coreAttrName = transformationObject.getCoreAttrName();
      serviceSpecificAttrName = transformationObject.getServiceSpecificAttrName();
      transformAttributeName(serviceSpecificAttrName, coreAttrName);
    }
  }

  public void transformAttributeName(String actualAttrName, String transformedAttrName) throws
      AttributeListParseException {
    if (attributeMap.containsKey(actualAttrName)) {
      if (!hasMultipleValues(actualAttrName)) {
        addAttribute(transformedAttrName, getAttrValue(actualAttrName), getOperator(actualAttrName));
        removeAttr(actualAttrName);
      } else {
        addAttribute(transformedAttrName, getAttrValues(actualAttrName), getOperator(actualAttrName));
        removeAttr(actualAttrName);
      }
    }
  }

  private boolean attributePresent(String attributeName) {
    if (attributeMap.containsKey(attributeName)) {
      currentAttributeValue = (AttributeValue) attributeMap.get(attributeName);
      return true;
    }
    return false;
  }

  private void addSingleAttrValueToDFCSysObject(IDfSysObject sysObj, String attributeName) throws DfException,
      AttributeListParseException {
    sysObj.setString(attributeName, getAttrValue(
        attributeName));   //Note: Even if attrName is a repeating attribute, this will set the value at index 0.
  }

  private void addMultipleAttrValuesToDFCSysObject(IDfSysObject sysObj, String attributeName) throws
      AttributeListParseException, DfException {
    List multipleValues = getAttrValues(attributeName);
    for (int i = 0; i < multipleValues.size(); i++) {
      String attrValue = (String) multipleValues.get(i);
      sysObj.setRepeatingString(attributeName, i, attrValue);
    }
  }

  private void addSingleAttrValueToXMLResponse(String attrName, Node attributeNode) throws AttributeListParseException {
    buildValueNode(attributeNode, getAttrValue(attrName));
  }

  private void addMultipleAttrValuesToXMLResponse(String attrName, Node attributeNode) throws
      AttributeListParseException {
    List attrValueList = getAttrValues(attrName);
    for (int i = 0; i < attrValueList.size(); i++) {
      buildValueNode(attributeNode, (String) attrValueList.get(i));
    }
  }

  private void buildValueNode(Node attributeNode, String attributeValue) {
    DOMUtil.addChildElement(attributeNode, DocumentManagerConstants.TAG_VALUE_NODE_STR, attributeValue);
  }

  private void buildNameNode(Node attributeNode, String attributeName) {
    DOMUtil.addChildElement(attributeNode, DocumentManagerConstants.TAG_NAME_NODE_STR, attributeName);
  }

  private Node buildAttributeNode(Node documentDetailsNode) {
    return DOMUtil.addChildElement(documentDetailsNode, DocumentManagerConstants.TAG_ATTRIBUTE_NODE_STR);
  }

  public void addAllAttributesToSPFields(List<FieldInformation> fieldInformationList) throws
      AttributeListParseException {
    Iterator attributeIterator = getAttrIterator();
    while (attributeIterator.hasNext()) {
      String attributeName = (String) attributeIterator.next();
			System.out.println("DocumentAttributes.addAllAttributesToSPFields: attributeName = " + attributeName);
			if (hasMultipleValues(attributeName)) {
        addMultipleAttrValuesToSPFields(fieldInformationList, attributeName);
        continue;
      }
			addSingleAttrValueToSPFields(fieldInformationList, attributeName);
    }
  }

  private void addSingleAttrValueToSPFields(List<FieldInformation> fieldInformationList, String attributeName) throws
      AttributeListParseException {
    addFieldToList(fieldInformationList, attributeName, getAttrValue(
        attributeName));   //Note: Even if attrName is a repeating attribute, this will set the value at index 0.
  }

  private void addMultipleAttrValuesToSPFields(List<FieldInformation> fieldInformationList, String attributeName) throws
      AttributeListParseException {
        System.out.println("DocumentAttributes.addMultipleAttrValuesToSPFields: attrName MULTIPLE = " + attributeName);
        List list = getAttrValues(attributeName);
        String valueString = "";
        for (Object aList : list) {
          String attr = (String) aList;
          System.out.println("DocumentAttributes.addMultipleAttrValuesToSPFields: attr = " + attr);
          if (valueString.length() == 0) {
            valueString = attr;
          } else {
            valueString = valueString + CR_LF + attr;
          }
        }
        System.out.println("SharePointTestUtil.insertTestDocument: valueString = " + valueString);
        addMultiValuedFieldToList(fieldInformationList, attributeName, valueString);
//    List multipleValues = getAttrValues(attributeName);
//    for (int i = 0; i < multipleValues.size(); i++) {
//      String attrValue = (String) multipleValues.get(i);
//			addMultivaluedFieldToList(fieldInformationList, attributeName, i, attrValue);
//    }
  }

  private void addMultiValuedFieldToList(List<FieldInformation> fieldInformationList, String name,
                                                String value) {
    FieldInformation fieldInformation = new FieldInformation();
    fieldInformation.setDisplayName(name);
    fieldInformation.setValue(value);
    fieldInformation.setInternalName(name);
    fieldInformation.setType(FieldType.NOTE);
    fieldInformationList.add(fieldInformation);
  }

	//ToDo: figure out how/if to introduce the concept of a value index to a field
//  private void addMultivaluedFieldToList(List<FieldInformation> fieldInformationList, String attributeName, int i,
//                                         String attrValue) {
//    addFieldToList(fieldInformationList, attributeName, attrValue);
//  }

  private void addFieldToList(List<FieldInformation> fieldInformationList, String name, String value) {
    FieldInformation fieldInformation = new FieldInformation();
    fieldInformation.setDisplayName(name);
    fieldInformation.setValue(value);
    fieldInformation.setInternalName(name);
    fieldInformation.setType(FieldType.TEXT);
    fieldInformationList.add(fieldInformation);
  }
}