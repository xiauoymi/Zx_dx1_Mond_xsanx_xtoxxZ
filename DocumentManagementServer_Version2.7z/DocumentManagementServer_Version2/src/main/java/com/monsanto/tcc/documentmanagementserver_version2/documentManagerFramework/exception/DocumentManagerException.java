package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Feb 22, 2006
 * Time: 3:49:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentManagerException extends Exception{

  public DocumentManagerException() {
  }

  public DocumentManagerException(String message) {
    super(message);
    logMessage(message);
  }

  public DocumentManagerException(Throwable cause) {
    super(cause.getMessage(), cause);
    logMessage(cause.getMessage());
    logTrace(cause);
  }

  public DocumentManagerException(String message, Throwable cause) {
    super(message, cause);
    logMessage(message);
    logTrace(cause);
  }

  private void logMessage(String message) {
    logMessage();
    Logger.log(new LoggableError("Message: " + message));
  }

  private void logMessage() {
    Logger.log(new LoggableError("Document Manager Error..."));
  }

  private void logTrace(Throwable cause) {
    Logger.log(new LoggableError("Stack Trace: " + cause));
  }
}