package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.response;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.POSServlet.POSErrorResponse;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Mar 1, 2006
 * Time: 8:26:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class ResponseHelper {

    protected Document responseDOM;

    public Document sendPOSErrorResponse(Throwable e){
      POSErrorResponse errorResponse = new POSErrorResponse(e, -1);
      responseDOM = errorResponse.toXML();
      return responseDOM;
    }

    public Node buildSuccessResponseHeader(Document outputDocument, String serviceSpecificNodeName) {
        Node documentManagerResponseNode = generateRootElement(outputDocument);
        return addRequestSpecificResponseElement(documentManagerResponseNode, serviceSpecificNodeName);
    }

    protected Node generateRootElement(Document outputDoc) {
        return DOMUtil.addChildElement(outputDoc, DocumentManagerConstants.TAG_DOCUMENT_MANAGER_RESPONSE_NODE_STR);
    }

    protected Node addRequestSpecificResponseElement(Node responseNode, String serviceSpecificNodeName) {
        return DOMUtil.addChildElement(responseNode, serviceSpecificNodeName);
    }
}