package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 22, 2006 Time: 2:54:42 PM To change this template use File |
 * Settings | File Templates.
 */
public class ServiceLookup implements IServiceLookup {

  public Document getServiceConfigDom() {
    return serviceConfigDom;
  }

  public void setServiceConfigDom(Document serviceConfigDom) {
    this.serviceConfigDom = serviceConfigDom;
  }

  private Document serviceConfigDom;

  public InputStream getServiceConfigInputStream() {
    return serviceConfigInputStream;
  }

  public void setServiceConfigInputStream(InputStream serviceConfigInputStream) {
    this.serviceConfigInputStream = serviceConfigInputStream;
  }

  private InputStream serviceConfigInputStream;

  public ServiceLookup(String serviceConfigFileName) throws ServiceConfigException {
    setServiceConfigInputStream(this.getClass().getClassLoader().getResourceAsStream(serviceConfigFileName));
    loadDocument();
  }

  public ServiceLookup() throws ServiceConfigException {
    String serviceConfigFileName = getServiceConfigFilePath();
    if (getServiceConfigInputStream() == null) {
      try {
        setServiceConfigInputStream(new FileInputStream(new File(serviceConfigFileName)));
      } catch (FileNotFoundException e) {
        throw new ServiceConfigException("ServiceConfig File not found at specified location: " + serviceConfigFileName,
            e);
      }
    }
    loadDocument();
  }

  private String getServiceConfigFilePath() throws ServiceConfigException {
    String moncryptjvProperty = getMONCRYPTJVProperty();
    return moncryptjvProperty + File.separator + DocumentManagerConstants.CONTEXT_NAME
        + File.separator + DocumentManagerConstants.SERVICE_CONFIG_FILE_NAME;
  }

  private String getMONCRYPTJVProperty() throws ServiceConfigException {
    String moncryptjvProperty = System.getProperty(DocumentManagerConstants.ENV_VARIABLE_MONCRYPTJV);
    if (moncryptjvProperty == null || moncryptjvProperty.length() == 0) {
      throw new ServiceConfigException("System Property not set correctly, MONCRYPTJV = " + moncryptjvProperty);
    }
    return moncryptjvProperty;
  }

  private void loadDocument() throws ServiceConfigException {
    try {
      setServiceConfigDom(DOMUtil.newDocument(getServiceConfigInputStream()));
    } catch (IOException e) {
      throw new ServiceConfigException("IOException while loading service-config xml file", e);
    } catch (SAXException e) {
      throw new ServiceConfigException("SAXException while loading service-config xml file", e);
    }
  }

  public String lookupRepositoryName(String folderName) throws ServiceConfigException {
    Node folderNode = getSpecificFolderNode(folderName);
    return lookupRepositoryNameForCurrentNode(folderNode);
  }

  public ConnectionInfo getConnectionDetails(String folderName, String lsiEnvironment) throws ServiceConfigException,
      EncryptorException {
    Node folderNode = getSpecificFolderNode(folderName);
    Node connectionDetailsNode = DOMUtil
        .getChild(folderNode, DocumentManagerConstants.SERVICE_CONFIG_STR_CONNECTION_DETAILS);
    Node[] environmentNodeList = getAllEnvironmentNodes(connectionDetailsNode);
    Node specificEnvironmentNode = getSpecificChildNode(environmentNodeList,
        DocumentManagerConstants.SERVICE_CONFIG_STR_FOLDER_NAME_ATTRIBUTE, lsiEnvironment);
    return getConnectionParams(specificEnvironmentNode, folderName);
  }

  protected ConnectionInfo getConnectionParams(Node specificEnvironmentNode, String folderName) throws
      EncryptorException {
    ConnectionInfo connectionInfo = new ConnectionInfo();
    NodeList childList = specificEnvironmentNode.getChildNodes();
    int listLen = childList.getLength();
    for (int i = 0; i < listLen; i++) {
      Node childNode = childList.item(i);
      String attributeName = childNode.getNodeName();
      if (attributeName.equalsIgnoreCase(DocumentManagerConstants.SERVICE_CONFIG_STR_GROUPS)) {
        List groupNameList = addGroupInformation(childNode);
        if (groupNameList.size() > 0) {
          connectionInfo.addConnectionParameter(attributeName, groupNameList);
          connectionInfo.setFolderSecured(true);
        }
      } else {
        String attributeValue = DOMUtil.getTextValue(childNode);
        connectionInfo.addConnectionParameter(attributeName, attributeValue);
      }
    }
    readDecryptedPassword(folderName, connectionInfo);
    return connectionInfo;
  }

  private void readDecryptedPassword(String folderName, ConnectionInfo connectionInfo) throws EncryptorException {
    //ToDo: figure out how to not call this at all when a SP-based folder ID is in play
    // Added by Vishal
    if (connectionInfo.containsParameter(DocumentManagerConstants.SP_CI_SITE_NAME) && connectionInfo.containsParameter(DocumentManagerConstants.SP_CI_DOC_LIB_NAME))
        return;
    // Added by Vishal
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_PASSWORD,
        EncryptionUtils.GetDecryptedStringFromExternalStorage(
            DocumentManagerConstants.ENV_VARIABLE_MONCRYPTJV,
            DocumentManagerConstants.CONTEXT_NAME,
            folderName + "_" + DocumentManagerConstants.FILE_ENCRYPTED_PWD_VALUE,
            folderName + "_" + DocumentManagerConstants.FILE_ENCRYPTED_PWD_KEY));
  }

  protected List addGroupInformation(Node groupListNode) {
    Node[] groups = DOMUtil.getChildren(groupListNode, DocumentManagerConstants.SERVICE_CONFIG_STR_GROUP);
    List groupNameList = new ArrayList();
    int numberOfGroups = groups.length;
    for (int i = 0; i < numberOfGroups; i++) {
      Node groupNode = groups[i];
      String groupName = DOMUtil.getTextValue(groupNode);
      groupNameList.add(groupName);
    }
    return groupNameList;
  }

  private Node getSpecificFolderNode(String folderName) throws ServiceConfigException {
    Node[] folderNodeList = getAllFolderNodes(getServiceConfigDom().getDocumentElement());
    try {
      return getSpecificChildNode(folderNodeList, DocumentManagerConstants.SERVICE_CONFIG_STR_FOLDER_NAME_ATTRIBUTE,
          folderName);
    } catch (ServiceConfigException e) {
      throw new ServiceConfigException("No service found for specified folder: \"" + folderName + "\"");
    }
  }

  private String lookupRepositoryNameForCurrentNode(Node folderNode) {
    return DOMUtil.getChildValue(folderNode, DocumentManagerConstants.SERVICE_CONFIG_STR_REPOSITORY);
  }

  private Node getSpecificChildNode(Node[] nodeList, String attributeName, String attributeValue) throws
      ServiceConfigException {
    int numberOfNodes = nodeList.length;

    for (int i = 0; i < numberOfNodes; i++) {

      if (nodeHasRequiredAttrValue(nodeList[i], attributeName, attributeValue)) {
        return nodeList[i];
      }
    }
    System.out.println(
        "about to throw the ServiceConfig exception about no node defined having the specified attribute value: \"" +
            attributeValue + "\"");
    throw new ServiceConfigException("No node defined having specified attribute value: \"" + attributeValue + "\"");
  }

  private Node[] getAllFolderNodes(Node parentNode) {
    return DOMUtil.getChildren(parentNode, DocumentManagerConstants.SERVICE_CONFIG_STR_FOLDER);
  }

  private Node[] getAllEnvironmentNodes(Node parentNode) {
    return DOMUtil.getChildren(parentNode, DocumentManagerConstants.SERVICE_CONFIG_STR_ENVIRONMENT);
  }

  private boolean nodeHasRequiredAttrValue(Node node, String attributeName, String requiredAttributeValue) {
    String nodeAttributeValue = DOMUtil.getAttribute((Element) node, attributeName);
    return nodeAttributeValue.equalsIgnoreCase(requiredAttributeValue);
  }
}