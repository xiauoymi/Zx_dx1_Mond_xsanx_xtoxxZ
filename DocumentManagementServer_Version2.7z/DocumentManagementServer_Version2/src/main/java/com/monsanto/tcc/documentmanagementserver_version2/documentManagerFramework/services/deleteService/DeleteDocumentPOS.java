package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.builder.DeleteSharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.BaseDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocumentService;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.deleteDocumentumDocs.builder.DeleteDocumentumBuilder;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 11, 2006
 * Time: 11:18:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteDocumentPOS extends BaseDocumentPOS {

  public void performOperation(RequestEntity requestEntity, DocumentService service, ResponseEntity responseEntity, UCCHelper helper) throws DocumentManagerException {
    try {
      service.delete(requestEntity, responseEntity, helper);
    } catch (AttributeListParseException e) {
      throw new DocumentManagerException(e);
    }
  }

  protected String getXMLSchemaRelativeToServletContext() {
    return DocumentManagerConstants.SCHEMA_DELETE_DOC_POS;
  }

  protected DocBuilder getRepositorySpecificBuilder(String repositoryName) throws ServiceConfigException {
    if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.SHAREPOINT_REPOSITORY_ID)) {
      return new DeleteSharePointBuilder();
    }
		if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.DOCUMENTUM_REPOSITORY_ID)) {
      return new DeleteDocumentumBuilder();
    }
		throw new ServiceConfigException();
  }
}