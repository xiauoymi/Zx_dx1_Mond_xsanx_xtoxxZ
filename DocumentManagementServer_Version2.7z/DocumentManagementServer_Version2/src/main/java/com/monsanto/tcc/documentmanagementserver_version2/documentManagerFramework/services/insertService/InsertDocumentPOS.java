package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.insertService;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.builder.InsertSharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.*;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.builder.InsertDocumentumBuilder;


/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 22, 2006 Time: 2:46:20 PM To change this template use File |
 * Settings | File Templates.
 */
public class InsertDocumentPOS extends BaseDocumentPOS {

  public void performOperation(RequestEntity requestEntity, DocumentService service, ResponseEntity responseEntity,
                               UCCHelper helper) throws DocumentManagerException {
    service.insert(requestEntity, responseEntity, helper);
  }

  protected String getXMLSchemaRelativeToServletContext() {
    return DocumentManagerConstants.SCHEMA_INSERT_DOC_POS;
  }

  protected DocBuilder getRepositorySpecificBuilder(String repositoryName) throws ServiceConfigException {
    if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.DOCUMENTUM_REPOSITORY_ID)) {
      return new InsertDocumentumBuilder();
    } else if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.SHAREPOINT_REPOSITORY_ID)) {
      return new InsertSharePointBuilder();
    }
    throw new ServiceConfigException();
  }
}