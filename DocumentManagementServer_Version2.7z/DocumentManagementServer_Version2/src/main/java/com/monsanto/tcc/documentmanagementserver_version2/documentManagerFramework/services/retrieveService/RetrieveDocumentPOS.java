package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.retrieveService;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.builder.RetrieveSharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.BaseDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocumentService;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.builder.RetrieveDocumentumBuilder;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 29, 2006
 * Time: 1:39:47 PM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveDocumentPOS extends BaseDocumentPOS {

  public void performOperation(RequestEntity requestEntity, DocumentService service, ResponseEntity responseEntity, UCCHelper helper) throws DocumentManagerException {
    service.retrieve(requestEntity,responseEntity, helper);
  }

  public String getXMLSchemaRelativeToServletContext() {
    return DocumentManagerConstants.SCHEMA_RETRIEVE_DOC_POS;
  }

  public DocBuilder getRepositorySpecificBuilder(String repositoryName) throws ServiceConfigException {
		if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.SHAREPOINT_REPOSITORY_ID)) {
      return new RetrieveSharePointBuilder();
    }
		if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.DOCUMENTUM_REPOSITORY_ID)) {
      return new RetrieveDocumentumBuilder();
    }
    throw new ServiceConfigException();
  }

  protected void displayAndLogToError(final Throwable e, final UCCHelper helper) {
    sendPOSErrorResponse(e, helper);
  }
}