package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.searchService;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.builder.SearchSharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.BaseDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocumentService;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.builder.SearchDocumentumBuilder;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 10, 2006
 * Time: 9:13:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class SearchDocumentsPOS extends BaseDocumentPOS {

  public void performOperation(RequestEntity requestEntity, DocumentService service, ResponseEntity responseEntity, UCCHelper helper) throws DocumentManagerException {
    service.search(requestEntity,responseEntity, helper);
  }

  protected String getXMLSchemaRelativeToServletContext() {
    return DocumentManagerConstants.SCHEMA_SEARCH_DOC_POS;
  }

  protected DocBuilder getRepositorySpecificBuilder(String repositoryName) throws ServiceConfigException {
		if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.SHAREPOINT_REPOSITORY_ID)) {
      return new SearchSharePointBuilder();
    }
		if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.DOCUMENTUM_REPOSITORY_ID)) {
      return new SearchDocumentumBuilder();
    }
    throw new ServiceConfigException();
  }
}