package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.updateService;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.*;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.builder.UpdateDocumentumBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updateSharePointDoc.builder.UpdateSharePointBuilder;
import com.monsanto.ServletFramework.UCCHelper;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jun 2, 2006
 * Time: 11:24:03 AM
 * To change this template use File | Settings | File Templates.
 */
public class UpdateDocumentPOS extends BaseDocumentPOS {

  protected String getXMLSchemaRelativeToServletContext() {
    return DocumentManagerConstants.SCHEMA_UPDATE_DOC_POS;
  }

  protected DocBuilder getRepositorySpecificBuilder(String repositoryName) throws ServiceConfigException {
		if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.SHAREPOINT_REPOSITORY_ID)) {
      return new UpdateSharePointBuilder();
    }
		if (repositoryName.equalsIgnoreCase(DocumentManagerConstants.DOCUMENTUM_REPOSITORY_ID)) {
      return new UpdateDocumentumBuilder();
    }
    throw new ServiceConfigException();
  }

  public void performOperation(RequestEntity requestEntity, DocumentService service, ResponseEntity responseEntity, UCCHelper helper) throws DocumentManagerException {
    service.update(requestEntity, responseEntity, helper);  
  }
}