package com.monsanto.tcc.documentmanagementserver_version2.documentum;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Feb 22, 2006
 * Time: 2:35:38 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class DocumentumBuilder extends DocBuilder {

  public void buildDocumentService(RequestEntity requestEntity) throws AttributeListParseException {
    DocumentumRequestEntity dctmReqEntity = (DocumentumRequestEntity) requestEntity;
    setDocumentService(new DocumentumService(dctmReqEntity.getConnectionInfo()));
  }

  public void buildAttributeTransformer() {
    setAttributeTransformer(new DocumentumAttributeTransformer());
  }

  public abstract void buildParser();

  public abstract void buildRequestEntity();
}
