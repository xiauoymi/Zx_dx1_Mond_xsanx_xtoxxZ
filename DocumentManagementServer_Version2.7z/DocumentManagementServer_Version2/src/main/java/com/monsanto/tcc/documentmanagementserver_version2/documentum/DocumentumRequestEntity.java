package com.monsanto.tcc.documentmanagementserver_version2.documentum;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Feb 24, 2006
 * Time: 1:52:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentumRequestEntity extends RequestEntity {
}
