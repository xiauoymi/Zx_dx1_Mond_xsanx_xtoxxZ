package com.monsanto.tcc.documentmanagementserver_version2.documentum;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import org.w3c.dom.Node;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 24, 2006 Time: 1:51:52 PM To change this template use File |
 * Settings | File Templates.
 */
public abstract class DocumentumRequestParser extends RequestParser {

  public void parseServiceSpecificRequest(Node requestNode, RequestEntity requestEntity, String folderName) throws
      ServiceConfigException, EnvironmentHelperException, AttributeListParseException, DocumentManagerException,
      EncryptorException {
    DocumentumRequestEntity documentumRequestEntity = (DocumentumRequestEntity) requestEntity;
    parseOperationSpecificRequest(requestNode, documentumRequestEntity);
    parseServiceConfigDetails(folderName, documentumRequestEntity);
  }

  public abstract void parseOperationSpecificRequest(Node requestNode,
                                                     DocumentumRequestEntity documentumRequestEntity) throws
      AttributeListParseException, DocumentManagerException;

  private void parseServiceConfigDetails(String folderName, DocumentumRequestEntity documentumRequestEntity) throws
      ServiceConfigException, EnvironmentHelperException, EncryptorException {
    IServiceLookup lookup = getServiceConfigLookupInstance();
    String lsiEnvironment = getLsiEnvironmentVariable();
    ConnectionInfo connectionInfo = lookup.getConnectionDetails(folderName, lsiEnvironment);
    saveConnectionDetails(connectionInfo, documentumRequestEntity);
  }

  private void saveConnectionDetails(ConnectionInfo connectionInfo, DocumentumRequestEntity documentumRequestEntity) {
    documentumRequestEntity.setConnectionInfo(connectionInfo);
  }

  protected String getLsiEnvironmentVariable() throws EnvironmentHelperException {
    String lsiFunction = System.getProperty("lsi.function");
    if (lsiFunction != null && lsiFunction.length() > 0) {
      return lsiFunction;
    }
    throw new EnvironmentHelperException("Bad value for lsi.function");
  }

  protected IServiceLookup getServiceConfigLookupInstance() throws ServiceConfigException {
    return new ServiceLookup();
  }
}