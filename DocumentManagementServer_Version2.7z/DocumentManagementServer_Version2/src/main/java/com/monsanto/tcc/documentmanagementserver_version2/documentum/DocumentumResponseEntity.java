package com.monsanto.tcc.documentmanagementserver_version2.documentum;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.AttributeTransformer;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 3, 2006 Time: 1:09:10 PM To change this template use File |
 * Settings | File Templates.
 */
public abstract class DocumentumResponseEntity extends ResponseEntity {
  protected AttributeTransformer buildAttributeTransformer() {
    return new DocumentumAttributeTransformer();
  }
}