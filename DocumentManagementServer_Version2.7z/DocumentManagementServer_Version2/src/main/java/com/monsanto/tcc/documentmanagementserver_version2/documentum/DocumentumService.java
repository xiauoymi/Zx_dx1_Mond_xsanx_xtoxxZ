package com.monsanto.tcc.documentmanagementserver_version2.documentum;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.*;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.DFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.DocumentumQueryBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.InvalidDctmAttrValueException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.RetrieveDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.deleteDocumentumDocs.entity.DeleteDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumRequestEntity;
import com.documentum.fc.common.DfException;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Feb 24, 2006
 * Time: 1:52:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentumService extends DocumentService {

  private IDFCServices service;

  public DocumentumService(ConnectionInfo connectionInfo) throws AttributeListParseException {
    service = new DFCServices(connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_DOCBROKER),
            connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_USERNAME),
            connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_PASSWORD),
            connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_DOCBASE),
            connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_CABINET),
            connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_OBJECT_TYPE));
  }

  public void insert(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper helper) throws DocumentManagerException {
    try {
      RetrievedDocument retrievedDocument = insertIntoDctm(requestEntity, getAttachmentLocation(helper));
      addRetrievedDocumentToResponseEntity(responseEntity, retrievedDocument);
    } catch (DocumentManagerException e) {
      throw new DocumentManagerException(e);
    }
  }

  public void update(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper helper) throws DocumentManagerException {
    try {
      String newContentsLocation = getLocationOfNewContentsForUpdate(helper);
      RetrievedDocument retrievedDocument = updateDctm(requestEntity, newContentsLocation);
      addRetrievedDocumentToResponseEntity(responseEntity, retrievedDocument);
    } catch (DocumentManagerException e) {
      throw new DocumentManagerException(e);
    }
  }

  private RetrievedDocument updateDctm(RequestEntity requestEntity, String newContentsLocation) throws DocumentManagerException{
    RetrievedDocument retrievedDocument;
    UpdateDocumentumRequestEntity updateDctmRequestEntity = (UpdateDocumentumRequestEntity)requestEntity;
    try {
      service.connect();
      retrievedDocument = service.update(updateDctmRequestEntity, newContentsLocation);
    } catch (Exception e) {
      performCancelCheckOut();
      throw new DocumentManagerException(e);
    } finally{
      closeService();
    }
    return retrievedDocument;
  }

  private void performCancelCheckOut() throws DocumentManagerException {
    try {
      service.checkSessionOpen();
      setupService();
      service.cancelCheckoutDocument();
      commitTX();
    } catch (DfException e) {
      rollbackTX(e);
      System.out.println("Rolledback cancelCheckout operation, exception ignored: " + e.getMessage());
    }
    finally{
      closeService();
    }
  }

  public void retrieve(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper helper) throws DocumentManagerException {
    try {
      RetrievedDocument retrievedDocument = retrieveFromDctm(requestEntity);
      addRetrievedDocumentToResponseEntity(responseEntity, retrievedDocument);
    } catch (DocumentManagerException e) {
      throw new DocumentManagerException(e);
    }
  }

  public void search(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper mockHelper) throws DocumentManagerException {
    SearchDocumentumRequestEntity searchDocumentumRequestEntity = (SearchDocumentumRequestEntity)requestEntity;
    searchFromDctm(searchDocumentumRequestEntity, responseEntity);
  }

  public void delete(RequestEntity requestEntity, ResponseEntity responseEntity, UCCHelper mockHelper) throws DocumentManagerException, AttributeListParseException {
    DeleteDocumentumRequestEntity deleteDocumentumRequestEntity = (DeleteDocumentumRequestEntity)requestEntity;
    DocumentAttributes documentAttributes = deleteDocumentumRequestEntity.getDocumentAttributes();
    String objectId = documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID);
    deleteFromDctm(objectId, documentAttributes, responseEntity);
  }

  private void deleteFromDctm(String objectId, DocumentAttributes documentAttributes, ResponseEntity responseEntity) throws DocumentManagerException {
    try {
      setupService();
      service.delete(objectId, documentAttributes, responseEntity);
      commitTX();
    } catch (Exception e) {
      rollbackTX(e);
      throw new DocumentManagerException(e);
    } finally{
      closeService();
    }
  }

  private void searchFromDctm(SearchDocumentumRequestEntity searchDocumentumRequestEntity, ResponseEntity responseEntity) throws DocumentManagerException {
    try {
      service.connect();
      String queryString = getSearchQuery(searchDocumentumRequestEntity, service);
      service.search(queryString, searchDocumentumRequestEntity, responseEntity);
    } catch (Exception e) {
      throw new DocumentManagerException(e);
    } finally{
      closeService();
    }
  }

  private RetrievedDocument retrieveFromDctm(RequestEntity requestEntity) throws DocumentManagerException {
    RetrieveDocumentumRequestEntity retrieveEntity = (RetrieveDocumentumRequestEntity)requestEntity;
    RetrievedDocument retrievedDocument;
    try {
      service.connect();
      retrievedDocument = service.retrieveDocumentObjectWithAttributes(retrieveEntity.getDocumentAttributes(),
              retrieveEntity.getRequiredAttributes());
    } catch (Exception e) {
      throw new DocumentManagerException(e);
    } finally{
      closeService();
    }
    return retrievedDocument;
  }

  private String getSearchQuery(SearchDocumentumRequestEntity searchDocumentumRequestEntity, IDFCServices service) throws DocumentManagerException, IllegalAccessException, InvalidDctmAttrValueException, InstantiationException {
    DocumentumQueryBuilder documentumQueryBuilder = new DocumentumQueryBuilder();
    String queryString;
    try {
      queryString = documentumQueryBuilder.buildSearchQueryForDocumentId(searchDocumentumRequestEntity, service);
    } catch (AttributeListParseException e) {
      throw new DocumentManagerException("Exception building query: " + e.getMessage(), e);
    } catch (DocumentManagerException e) {
      throw new DocumentManagerException("Exception building query: " + e.getMessage(), e);
    } catch (DfException e) {
      throw new DocumentManagerException("Exception building query: " + e.getMessage(), e);
    }
    return queryString;
  }

  private void addRetrievedDocumentToResponseEntity(ResponseEntity responseEntity, RetrievedDocument retrievedDocument) {
    responseEntity.getRetrievedDocumentList().add(retrievedDocument);
  }

  private String getAttachmentLocation(UCCHelper helper) throws DocumentManagerException {
    //**Expecting only one attachment at a time, refactor this  method if this requirement changes.
    String attachmentLocation;
    try {
      List uploadedFileList = helper.getClientFiles();
      if(uploadedFileList != null && uploadedFileList.size() > 1){
        attachmentLocation = (String) uploadedFileList.get(1);
      }
      else{
        throw new DocumentManagerException("Attachment not found.");
      }
    } catch (IOException e) {
      throw new DocumentManagerException("Exception while getting attachment from server scratch folder.", e);
    }
    return attachmentLocation;
  }

  private String getLocationOfNewContentsForUpdate(UCCHelper helper) throws DocumentManagerException {
    String attachmentLocation = null;
    try {
      List uploadedFileList = helper.getClientFiles();
      if(uploadedFileList != null && uploadedFileList.size() > 1){
        attachmentLocation = (String) uploadedFileList.get(1);
      }
    } catch (IOException e) {
      throw new DocumentManagerException("Exception while getting attachment from server scratch folder.", e);
    }
    return attachmentLocation;
  }

  private RetrievedDocument insertIntoDctm(RequestEntity requestEntity, String atttachmentLocation) throws DocumentManagerException {
    RetrievedDocument retrievedDocument;
    InsertDocumentumRequestEntity insertDctmRequestEntity = (InsertDocumentumRequestEntity)requestEntity;
    try {
      setupService();
      retrievedDocument = service.saveDocument(insertDctmRequestEntity, insertDctmRequestEntity.getDirectoryStructure(), atttachmentLocation);
      commitTX();
      return retrievedDocument;
    } catch (Exception e) {
      rollbackTX(e);
      throw new DocumentManagerException(e);
    } finally{
      closeService();
    }
  }

  private void closeService() {
    service.close();
  }

  private void rollbackTX(Exception e) throws DocumentManagerException {
    Logger.log(new LoggableError("Rolling back the tranasction."));
    Logger.log(new LoggableError(e));
    service.rollbackTransaction();
  }

  private void commitTX() throws DocumentManagerException {
    Logger.log(new LoggableError("Committing the tranasction."));
    service.commitTransaction();
  }

  private void setupService() throws DocumentManagerException {
    service.connect();
    service.beginTransaction();
  }
}