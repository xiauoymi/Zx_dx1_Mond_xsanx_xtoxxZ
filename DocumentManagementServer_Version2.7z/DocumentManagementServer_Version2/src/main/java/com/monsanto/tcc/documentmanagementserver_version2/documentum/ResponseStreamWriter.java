package com.monsanto.tcc.documentmanagementserver_version2.documentum;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.ServletFramework.UCCHelper;

import java.io.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Apr 24, 2006
 * Time: 4:21:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class ResponseStreamWriter {
  public static final String ATTRIBUTE_TAG_STR = "attribute";
  public static final String NAME_TAG_STR = "name";
  public static final String VALUE_TAG_STR = "value";

  public void writeSuccessfulRetrieveDocumentResponseToStream(RetrievedDocument retrievedDocument, UCCHelper helper) throws IOException, AttributeListParseException {
    OutputStream out = helper.getBinaryStream();
    writeHeader(out);
    writeBody(retrievedDocument, out);
    writeFooter(out);
    out.flush();
    out.close();
  }

  private void writeHeader(OutputStream out) throws IOException {
    writeDataToStream(out, buildStartTagElement(DocumentManagerConstants.TAG_DOCUMENT_MANAGER_RESPONSE_NODE_STR) + "\n");
    writeDataToStream(out, buildStartTagElement(DocumentManagerConstants.TAG_RETRIEVE_DOCUMENT_NODE_STR) + "\n");
    writeDataToStream(out, buildStartTagElement(DocumentManagerConstants.TAG_DOCUMENT_DETAILS_NODE_STR) + "\n");
  }

  private void writeBody(RetrievedDocument retrievedDocument, OutputStream out) throws IOException, AttributeListParseException {
    DocumentAttributes documentAttributes = retrievedDocument.getDocumentAttributes();
    Iterator attributeIterator = documentAttributes.getAttrIterator();
    while(attributeIterator.hasNext()){
      String attrName = (String) attributeIterator.next();
      List attrValues = new ArrayList();
      if (documentAttributes.hasMultipleValues(attrName)) {
        attrValues = documentAttributes.getAttrValues(attrName);
      }
      else{
        attrValues.add(documentAttributes.getAttrValue(attrName));
      }
      addAttribute(attrName, attrValues, out);
    }
  }

  private void writeDataTag(String nodeName, List nodeValues, OutputStream out) throws IOException {
    writeStartTagElement(ATTRIBUTE_TAG_STR, out);
    writeStartTagElement(NAME_TAG_STR, out);
    writeDataToStream(out, nodeName);
    writeEndTagElement(NAME_TAG_STR, out);
    writeValueTag(nodeValues, nodeName, out);
    writeEndTagElement(ATTRIBUTE_TAG_STR, out);
  }

  private void writeValueTag(List nodeValues, String attrName, OutputStream out) throws IOException {
    for (int i = 0; i < nodeValues.size(); i++) {
      writeStartTagElement(VALUE_TAG_STR, out);
      if (attrName.equalsIgnoreCase(DocumentManagerConstants.ATTR_STR_CONTENTS)) {
        String filePath = (String) nodeValues.get(0);
        FileInputStream fileInputStream = new FileInputStream(new File(filePath));
        new sun.misc.BASE64Encoder().encode(fileInputStream, out);
        // This statement was added by ffbrac. It closes the file stream and release and system resources
        fileInputStream.close();
        System.out.println("File has been closed");
      } else {
        writeDataToStream(out, (String) nodeValues.get(i));
      }
      writeEndTagElement(VALUE_TAG_STR, out);
    }
  }

  private void addAttribute(String attributeName, List attributeValues, OutputStream out) throws IOException {
    writeDataTag(attributeName, attributeValues, out);
  }

  private void writeFooter(OutputStream out) throws IOException {
    writeDataToStream(out, buildEndTagElement(DocumentManagerConstants.TAG_DOCUMENT_DETAILS_NODE_STR));
    writeDataToStream(out, buildEndTagElement(DocumentManagerConstants.TAG_RETRIEVE_DOCUMENT_NODE_STR));
    writeDataToStream(out, buildEndTagElement(DocumentManagerConstants.TAG_DOCUMENT_MANAGER_RESPONSE_NODE_STR));
  }

  private void writeDataToStream(OutputStream out, String nodeValue) throws IOException {
    out.write(nodeValue.getBytes());
  }

  private String buildStartTagElement(String tagName) {
    return "<" + tagName + ">";
  }

  private void writeStartTagElement(String tagName, OutputStream out) throws IOException {
    String nodeValue = "<" + tagName + ">";
    out.write(nodeValue.getBytes());
  }

  private String buildEndTagElement(String tagName) {
    return "</" + tagName + ">\n";
  }

  private void writeEndTagElement(String tagName, OutputStream out) throws IOException {
    String nodeValue = "</" + tagName + ">\n";
    out.write(nodeValue.getBytes());
  }
}