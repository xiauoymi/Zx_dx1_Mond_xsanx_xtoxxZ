package com.monsanto.tcc.documentmanagementserver_version2.documentum.deleteDocumentumDocs.builder;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.deleteDocumentumDocs.entity.DeleteDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.deleteDocumentumDocs.entity.DeleteDocumentumResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.deleteDocumentumDocs.parser.DeleteDocumentumRequestParser;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 11, 2006
 * Time: 5:12:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteDocumentumBuilder extends DocumentumBuilder {

  public void buildParser() {
    setRequestParser(new DeleteDocumentumRequestParser());
  }

  public void buildRequestEntity() {
    setRequestEntity(new DeleteDocumentumRequestEntity());
  }

  public void buildResponseEntity() {
    setResponseEntity(new DeleteDocumentumResponseEntity());
  }
}