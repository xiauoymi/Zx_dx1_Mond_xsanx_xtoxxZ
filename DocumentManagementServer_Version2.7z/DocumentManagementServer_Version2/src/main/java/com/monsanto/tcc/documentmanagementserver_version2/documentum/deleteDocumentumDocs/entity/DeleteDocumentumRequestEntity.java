package com.monsanto.tcc.documentmanagementserver_version2.documentum.deleteDocumentumDocs.entity;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 11, 2006
 * Time: 5:23:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteDocumentumRequestEntity extends DocumentumRequestEntity {

  public DeleteDocumentumRequestEntity() {
  }
}