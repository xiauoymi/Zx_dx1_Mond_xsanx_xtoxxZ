package com.monsanto.tcc.documentmanagementserver_version2.documentum.deleteDocumentumDocs.entity;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumResponseEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 11, 2006
 * Time: 5:24:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteDocumentumResponseEntity extends DocumentumResponseEntity {

  protected String getServiceSpecificNodeName() {
    return DocumentManagerConstants.TAG_DELETE_DOCUMENT_SUCCESS_MESSAGE;
  }
}