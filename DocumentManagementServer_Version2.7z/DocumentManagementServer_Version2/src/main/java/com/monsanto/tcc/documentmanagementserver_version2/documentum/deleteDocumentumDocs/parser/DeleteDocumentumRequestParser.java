package com.monsanto.tcc.documentmanagementserver_version2.documentum.deleteDocumentumDocs.parser;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.deleteDocumentumDocs.entity.DeleteDocumentumRequestEntity;
import org.w3c.dom.Node;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 11, 2006
 * Time: 5:23:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteDocumentumRequestParser extends DocumentumRequestParser {

  public void parseOperationSpecificRequest(Node requestDetailsNode, DocumentumRequestEntity documentumRequestEntity) throws DocumentManagerException {
    DeleteDocumentumRequestEntity deleteDocumentumRequestEntity = (DeleteDocumentumRequestEntity)documentumRequestEntity;
    Node docAttributesNode = getAttributesNode(requestDetailsNode, DocumentManagerConstants.TAG_NAME_QUERY_ATTRIBUTES);
    parseAttributeList(docAttributesNode, deleteDocumentumRequestEntity);
  }

  private Node getAttributesNode(Node requestDetailsNode, String parentNodeName) {
    Node retrieveDocumentNode = DOMUtil.getChild(requestDetailsNode, getServiceNodeNameForParsingRequest());
    return DOMUtil.getChild(retrieveDocumentNode, parentNodeName);
  }

  protected String getServiceNodeNameForParsingRequest() {
    return DocumentManagerConstants.TAG_DELETE_DOCUMENT_NODE_STR;
  }
}