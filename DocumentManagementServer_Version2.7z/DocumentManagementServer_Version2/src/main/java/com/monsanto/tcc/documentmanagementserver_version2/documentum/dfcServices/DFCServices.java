package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.operations.*;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumRequestEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Service class to communicate with Documentum
 *
 * @author WWZHOU
 */
public class DFCServices implements IDFCServices {

  private String docBroker;
  private String userName;
  private String password;
  private String docBase;
  private String cabinet;
  private String objectType;
  private IDfSession sess = null;
  private IDfSessionManager sessionMgr;
  private String checkoutFilePath;
  private String checkoutFileFormat;
  private String chronicleId;
  private String event;
  private String queueOwner;
//  private RetrievedDocument retrievedDocument;

  public DFCServices(String docBrokerHost, String userName, String pwd, String docBaseName, String cabinet, String objectType) {
    this.docBroker = docBrokerHost;
    this.userName = userName;
    this.password = pwd;
    this.docBase  = docBaseName;
    this.cabinet = cabinet;
    this.objectType = objectType;
    //    this.retrievedDocument = new RetrievedDocument();
  }

  /**
   * Connect to Documentum
   *
   *
   * @throws com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException
   */
  public void connect() throws DocumentManagerException {
    try{
      if ((sess == null) || !(sess.isConnected())) {
        this.sess = getSession();
      }
    }catch (DocumentManagerException dfe) {
        throw new DocumentManagerException("Exception in connect(): Connection already exists " + dfe.getMessage(),dfe);
    }   
 }
  private IDfSession getSession() throws DocumentManagerException{
    IDfSession newSession = null;
    DfClientX dfClientX = null;
    IDfClient iDfClient = null;
      try{
          //get the connection
          dfClientX = new DfClientX();
          iDfClient = dfClientX.getLocalClient();
          sessionMgr = iDfClient.newSessionManager();
          if(iDfClient != null) {
            IDfLoginInfo li =  dfClientX.getLoginInfo();
            li.setUser(userName);
            li.setPassword(password);
            sessionMgr.setIdentity(docBase, li);
            newSession = sessionMgr.getSession(docBase);//newSession(docBase);//.getSession(docBase);
        }
        return newSession;
      }catch (DfServiceException  dse) {
       Logger.log(new LoggableError(dse));
       throw new DocumentManagerException("Exception in connect() DfServiceException  " + dse.getMessage(),dse);
      }
      catch (DfException dfe) {
       Logger.log(new LoggableError(dfe));
       throw new DocumentManagerException("Exception in connect() " + dfe.getMessage(),dfe);
      }
      catch (RuntimeException e){
        Logger.log(new LoggableError(e));
        throw new DocumentManagerException("Problem with get Session "+ e.getMessage(),e);
      }
  }

  /**
   * Close the current Documentum connection
   */
  public void close() {
    if ((sess != null) && sess.isConnected()){
      IDfSessionManager sessionMgrNew =  sess.getSessionManager();
      //sessionMgrNew.release(sess);
      //sessionMgrNew.clearIdentity(docBase);
      sessionMgr.release(sess);
      sessionMgr.clearIdentity(docBase);

    }
  }

  /**
   * Start the transaction
   */
  public void beginTransaction() throws DocumentManagerException {
    try {
      sessionMgr.beginTransaction();
    } catch (DfException e) {
//      throw new DocumentManagerException(e.getMessage());
      throw new DocumentManagerException(e.getMessage(),e);
    }
  }

  /**
   * Commit all the changes from last call to <code>beginTransaction()</code>
   */
  public void commitTransaction() throws DocumentManagerException {
    try {
      sessionMgr.commitTransaction();
    } catch (DfException e) {
      throw new DocumentManagerException(e.getMessage(),e);
    }
  }

  /**
   * Roll back all the changes for current transaction
   */
  public void rollbackTransaction() throws DocumentManagerException {
    try {
      if (null != sess)  {
        sessionMgr.abortTransaction();
      }
    } catch (DfException e) {
      throw new DocumentManagerException(e.getMessage(),e);
    }
  }

  /**
   * Set the Documentum session. This method is provided for flexibility.
   *
   * @param session the Documentum session to use
   */
//  public void setSession(IDfSession session) {
//    this.sess = session;
//  }

  /**
   * Check if the connection to Documentum is still open
   */
  public void checkSessionOpen() throws IllegalStateException {
    if (sess == null || !sess.isConnected()) {
      throw new IllegalStateException("Not connected to Documentum yet");
    }
  }

  /**
   * Insert w/o support for versioning (throws an exception if the document already exists.)
   * Also adds PDF rendition capability to the inserted document object.
   * @param insertDctmRequestEntity
   * @param directoryStructure
   * @param atttachmentLocation
   * @return String - objectId of the inserted document.
   * @throws DocumentManagerException
   * @throws AttributeListParseException
   */
  public RetrievedDocument saveDocument(InsertDocumentumRequestEntity insertDctmRequestEntity, String directoryStructure, String atttachmentLocation) throws DocumentManagerException, AttributeListParseException, DfException {
    DocumentAttributes documentAttributes = insertDctmRequestEntity.getDocumentAttributes();
    if (documentAttributes == null || documentAttributes.getLength() == 0) {
      throw new DocumentManagerException("Required Attributes Missing.");
    }
    RetrievedDocument retrievedDocument = new RetrievedDocument();
    String completeParentFolderPath = createDirectoryStructure(directoryStructure);
    String fileName = documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_NAME);
    if(fileName == null || fileName.length() == 0){
      Logger.log(new LoggableError("Assigning document name from file location information."));
      fileName = assignNameFromFileLocation(fileName, true);
    }
    if (!existsOtherDocumentWithSameName(fileName, completeParentFolderPath)){
      IDfSysObject sysObj = addNewDocument(retrievedDocument,documentAttributes, atttachmentLocation, completeParentFolderPath, insertDctmRequestEntity.getRequestPDFRendition());
      return createRetrievedDocumentWithObjectIdAndVersion(retrievedDocument,getObjectId(sysObj), getVersion(sysObj));
    }
    else{
      throw new DocumentManagerException("Document already present in the specified cabinet.");
    }
  }

  public RetrievedDocument update(UpdateDocumentumRequestEntity updateDctmRequestEntity, String newContentsLocation) throws AttributeListParseException, DocumentManagerException, DfException {
    DocumentAttributes documentAttributes = updateDctmRequestEntity.getDocumentAttributes();
    RetrievedDocument retrievedDocument = new RetrievedDocument();
    chronicleId = getChronicleIdFromRequest(documentAttributes);
    IDfSysObject sysObj = performCheckout();
    performCheckin(newContentsLocation, documentAttributes, sysObj);
    sysObj = performSetAttributeToNewVersion(documentAttributes);
    if (updateDctmRequestEntity.getRequestPDFRendition()) {
        IDfId queueId = applyPDFRenditionCapability(sysObj);
        createRetrievedDocumentWithPDFRenditionResponse(retrievedDocument,queueId);
    }
    return createRetrievedDocumentWithObjectIdAndVersion(retrievedDocument,getChronicleId(sysObj), getVersion(sysObj));
  }

  private IDfSysObject performSetAttributeToNewVersion(DocumentAttributes documentAttributes) throws DocumentManagerException {
    IDfSysObject sysObj;
    try {
      checkSessionOpen();
      beginTransaction();
      sysObj = getSysObjectOfCurrentVersionByChronicleId(chronicleId);
      setAttributesToNewVersion(documentAttributes, sysObj);
      sysObj.save();
      commitTransaction();
    } catch (Exception e) {
      rollbackTransaction();
      throw new DocumentManagerException("Set Attribute operation rolledback due to exception: " + e.getMessage(),e);
    }
    return sysObj;
  }

  private void performCheckin(String newContentsLocation, DocumentAttributes documentAttributes, IDfSysObject sysObj) throws DocumentManagerException {
    try {
      checkSessionOpen();
      beginTransaction();
      checkInDocument(newContentsLocation, documentAttributes, sysObj);
      commitTransaction();
    } catch (Exception e) {
      rollbackTransaction();
      throw new DocumentManagerException("Checkin operation rolledback due to exception: " + e.getMessage(),e);
    }
  }

  private IDfSysObject performCheckout() throws DocumentManagerException {
    try {
      checkSessionOpen();
      beginTransaction();
      IDfSysObject sysObj = checkOutDocument(chronicleId);
      commitTransaction();
      return sysObj;
    } catch (Exception e) {
      rollbackTransaction();
      throw new DocumentManagerException("Checkout operation rolledback due to exception: " + e.getMessage(),e);
    }
  }

  public void cancelCheckoutDocument() throws DfException, DocumentManagerException {
    if (!StringUtils.isNullOrEmpty(chronicleId)) {
      IDfClientX clientx = new DfClientX();
      IDfCancelCheckoutOperation operation = clientx.getCancelCheckoutOperation();
      operation.setKeepLocalFile(false);
      IDfSysObject sysObj = getSysObjectOfCurrentVersionByChronicleId(chronicleId);
      if( sysObj == null ) {
        System.out.println("Document with ChronicleId '" + chronicleId + "' can not be found.");
        return;
      }
      if (!sysObj.isCheckedOut()) {
        System.out.println("Document with ChronicleId '" + chronicleId + "' is not checked out.");
        return;
      }
      addCancelCheckoutNode(sysObj, operation);
      executeOperation(operation);
    }
  }

  private void addCancelCheckoutNode(IDfSysObject sysObj, IDfCancelCheckoutOperation operation) throws DfException {
    IDfCancelCheckoutNode node;
    if( sysObj.isVirtualDocument() ) {
      IDfVirtualDocument vDoc = sysObj.asVirtualDocument(DocumentManagerConstants.LABEL_CURRENT_VERSION_DCTM, false);
      node = (IDfCancelCheckoutNode)operation.add(vDoc);
    } else {
      node = (IDfCancelCheckoutNode)operation.add(sysObj);
    }
  }

  private void setAttributesToNewVersion(DocumentAttributes documentAttributes, IDfSysObject sysObj) throws AttributeListParseException, DfException {
    documentAttributes.removeAttr(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID);
    documentAttributes.removeAttr(DocumentManagerConstants.ATTR_STR_UPDATE_VERSION);
    documentAttributes.addAllAttributesToDFCSysObject(sysObj);
  }

  private IDfSysObject checkOutDocument(String chronicleId) throws DfException, DocumentManagerException {
    IDfClientX clientx = new DfClientX();
    IDfCheckoutOperation operation = clientx.getCheckoutOperation();
    IDfSysObject sysObj = getSysObjectOfCurrentVersionByChronicleId(chronicleId);
    if (sysObj.isCheckedOut()) {
      throw new DocumentManagerException("Update Checkout Error: The Document to be updated is already checked-out");
    }
    IDfCheckoutNode node = addCheckoutNode(sysObj, operation);
    executeOperation(operation);
    checkoutFilePath = node.getFilePath();
    checkoutFileFormat = node.getFormat();
    return sysObj;
  }

  private IDfCheckoutNode addCheckoutNode(IDfSysObject sysObj, IDfCheckoutOperation operation) throws DfException {
    IDfCheckoutNode node;
    if(sysObj.isVirtualDocument()) {
      IDfVirtualDocument vDoc = sysObj.asVirtualDocument(DocumentManagerConstants.LABEL_CURRENT_VERSION_DCTM, false);
      node = (IDfCheckoutNode)operation.add(vDoc);
    } else {
      node = (IDfCheckoutNode)operation.add(sysObj);
    }
    return node;
  }

  public static void executeOperation(IDfOperation operation) throws DfException, DocumentManagerException {
    boolean executeFlag = operation.execute();
    if(!executeFlag) {
      IDfList errorList = operation.getErrors();
      String message = "";
      IDfOperationError error;
      for(int i = 0 ; i < errorList.getCount() ; i++) {
        error = (IDfOperationError) errorList.get(i);
        message += error.getMessage();
      }
      throw new DocumentManagerException("Update Error: Exception while executing checkin/checkout operation: " + message);
    }
  }

  /**
   * Always returns the current version of the object...
   * @param chronicleId
   * @return
   * @throws DfException
   * @throws DocumentManagerException
   */
  private IDfSysObject getSysObjectOfCurrentVersionByChronicleId(String chronicleId) throws DfException, DocumentManagerException {
    String qualification = "dm_sysobject where " + DocumentManagerConstants.DCTM_ATTR_STR_CHRONICLE_ID + " ='" + chronicleId + "'";
    IDfSysObject sysObj =  (IDfSysObject) sess.getObjectByQualification(qualification);
    if(sysObj != null) {
      return sysObj;
    } else {
      throw new DocumentManagerException("Documentum object with objectId '" + chronicleId + "' does not exist");
    }
  }

  private IDfSysObject getSysObjectByChronicleIdAndVersion(String chronicleId, String version) throws DocumentManagerException, DfException {
    String qualification = "dm_sysobject " + DocumentManagerConstants.QUERY_PARAM_ALL_VERSIONS_STR + " where " + DocumentManagerConstants.DCTM_ATTR_STR_CHRONICLE_ID + " ='" + chronicleId + "' " +
            "AND " + DocumentManagerConstants.QUERY_PARAM_ANY_STR + DocumentManagerConstants.DCTM_ATTR_STR_VERSION + " = '" + version + "'";
    IDfSysObject sysObj;
    sysObj = (IDfSysObject) sess.getObjectByQualification(qualification);
    if (sysObj != null) {
      return sysObj;
    } else {
      throw new DocumentManagerException("Documentum object with objectId '" + chronicleId + "' " +
              "and version label = '" + version + "' does not exist");
    }
  }

  private IDfSysObject checkInDocument(String newContentsLocation, DocumentAttributes documentAttributes, IDfSysObject sysObj) throws DfException, DocumentManagerException, AttributeListParseException {
    IDfClientX clientx = new DfClientX();
    IDfCheckinOperation operation = clientx.getCheckinOperation();
    if (!sysObj.isCheckedOut()) {
      throw new DocumentManagerException("Update Checkin Error: The Document to be updated is not checked-out");
    }
    IDfCheckinNode node = addCheckinNode(sysObj, operation);
    int versionToCheckinWith = getRequestedVersionToCheckinWith(documentAttributes);
    operation.setCheckinVersion(versionToCheckinWith);
    setAppropriateContent(newContentsLocation, node);
    node.setVersionLabels(DocumentManagerConstants.LABEL_CURRENT_VERSION_DCTM);
    executeOperation(operation);
    return sysObj;
  }

  private IDfCheckinNode addCheckinNode(IDfSysObject sysObj, IDfCheckinOperation operation) throws DfException {
    IDfCheckinNode node;
    if( sysObj.isVirtualDocument() ) {
      IDfVirtualDocument vDoc = sysObj.asVirtualDocument(DocumentManagerConstants.LABEL_CURRENT_VERSION_DCTM, false);
      node = (IDfCheckinNode)operation.add(vDoc);
    } else {
      node = (IDfCheckinNode)operation.add(sysObj);
    }
    return node;
  }

  private void setAppropriateContent(String newContentsLocation, IDfCheckinNode node) throws DfException, DocumentManagerException {
    boolean newContentsPresent = checkContentsUpdated(newContentsLocation);
    if (!newContentsPresent) {
      node.setFormat(checkoutFileFormat);
      node.setFilePath(checkoutFilePath);
    } else {
      node.setFormat(getDocumentumContentType(newContentsLocation));
      node.setFilePath(newContentsLocation);
    }
  }

  private int getRequestedVersionToCheckinWith(DocumentAttributes documentAttributes) throws AttributeListParseException, DocumentManagerException {
    Map allowableValues = DocumentManagerConstants.updateVersionValueList;
    if (documentAttributes.containsAttribute(DocumentManagerConstants.ATTR_STR_UPDATE_VERSION)) {
      String updateVersionValue = documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_UPDATE_VERSION);
      if (allowableValues.containsKey(updateVersionValue)) {
        return Integer.parseInt((String) allowableValues.get(updateVersionValue));
      } else {
        throw new DocumentManagerException(
                "The attribute 'updateVersion' contains invalid value '"+ updateVersionValue +"'. " +
                        "Allowable values are 'nextMajor', 'nextMinor', 'same'");
      }
    }
    return Integer.parseInt((String) allowableValues.get(DocumentManagerConstants.NEXT_MINOR_VERSION));
  }

  private boolean checkContentsUpdated(String newContentsLocation) {
    return !StringUtils.isNullOrEmpty(newContentsLocation);
  }

  private String getChronicleIdFromRequest(DocumentAttributes documentAttributes) throws AttributeListParseException, DocumentManagerException {
    String chronicleId = documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID);
    if (!StringUtils.isNullOrEmpty(chronicleId)) {
      return chronicleId;
    } else{
      throw new DocumentManagerException("Request for Update does not contain 'objectId' attribute");
    }
  }

  private String getVersion(IDfSysObject sysObj) throws DfException {
    return sysObj.getImplicitVersionLabel();
  }

  private String getObjectId(IDfSysObject sysObj) throws DfException {
    return sysObj.getObjectId().getId();
  }

  private String getChronicleId(IDfSysObject sysObj) throws DfException {
    return sysObj.getChronicleId().getId();
  }

  private RetrievedDocument createRetrievedDocumentWithObjectIdAndVersion(RetrievedDocument retrievedDocument,String objectId, String version) {
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, objectId, null);
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION, version, null);
    return retrievedDocument;
  }
  private RetrievedDocument createRetrievedDocumentWithPDFRenditionResponse(RetrievedDocument retrievedDocument, IDfId queueItemId) throws DfException {
    IDfQueueItem queueItem = (IDfQueueItem) sess.getObject(queueItemId);
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME, queueItem.getName(), null);
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_EVENT, queueItem.getEvent(), null);
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_MESSAGE, queueItem.getMessage(), null);
    return retrievedDocument;
  }

  private boolean existsOtherDocumentWithSameName(String fileName, String completeParentFolderPath) throws DocumentManagerException {
    return findIdByName(fileName, completeParentFolderPath, false, objectType).size() != 0;
  }

  private String createDirectoryStructure(String directoryStructure) throws DocumentManagerException {
    String completeParentFolderPath = cabinet;
    if (directoryStructure != null && directoryStructure.length() > 0) {
      createDirectoryStructure(directoryStructure, cabinet);
      completeParentFolderPath = completeParentFolderPath + "/" + directoryStructure;
    }
    return completeParentFolderPath;
  }

  private void createDirectoryStructure(String directoryStructure, String cabinet) throws DocumentManagerException {
    if (isSubdirectoryPresent(directoryStructure)){
      String[] directoryList = createSubdirectoryList(directoryStructure, cabinet);
      for(int i = 0; i < directoryList.length - 1; i++){
        createDirectory(buildSubdirectory(directoryList, i), directoryList[i+1]);
      }
    } else {
      createDirectory(cabinet, directoryStructure);
    }
  }

  private String buildSubdirectory(String[] directoryList, int end)  {
    StringBuffer out = new StringBuffer();
    for (int idx = 0; idx <= end; idx++) {
      out.append(directoryList[idx]);
      if (idx != end)  {
        out.append("/");
      }
    }
    return out.toString();
  }

  private void createDirectory(String root, String directory) throws DocumentManagerException {
    if (!existFolderByName(directory, root))  {
      createFolder(directory, root);
    }
  }

  private String[] createSubdirectoryList(String directoryStructure, String docRoot) {
    String[] directoryList = directoryStructure.split("/");
    int directoryListLength = directoryList.length;
    String[] parentDirectoryList = new String[directoryListLength + 1];
    parentDirectoryList[0] = docRoot;
    System.arraycopy(directoryList, 0, parentDirectoryList, 1, directoryList.length);
    return parentDirectoryList;
  }

  private boolean isSubdirectoryPresent(String directory)  {
    return (-1 != directory.indexOf("/"));
  }

  public void deleteByName(String fileName, String objectType) throws DocumentManagerException {
    try {
      checkSessionOpen();
      List existingDoc = findIdByName(fileName, cabinet, true, objectType);
      if (existingDoc.size() != 0){
        for (int i = 0; i < existingDoc.size(); i++) {
          String objectId =  (String) existingDoc.get(i);
          deleteById(objectId);
        }
      }
    } catch (DocumentManagerException e) {
      throw new DocumentManagerException("Exception while deleting document by name. " + e.getMessage(),e);
    }
  }

  /**
   * Delete the given Documentum object id
   *
   * @param objectId the Documentum object id
   * @throws DocumentManagerException
   */
  public boolean deleteById(String objectId) throws DocumentManagerException {
    try {
      checkSessionOpen();
      IDfSysObject sysObj = (IDfSysObject) sess.getObject(new DfId(objectId));
      sysObj.destroy();
      return true;
    } catch (DfException dfe) {
      throw new DocumentManagerException("Exception while deleting document by id. " + dfe.getMessage(),dfe);
    }
  }

  /**
   * Delete all versions of the given Documentum object id
   *
   * @param objectId the Documentum object id
   * @throws DocumentManagerException
   */
  public boolean deleteAllVersionsById(String objectId) throws DocumentManagerException {
    try {
      checkSessionOpen();
      IDfSysObject sysObj = (IDfSysObject) sess.getObject(new DfId(objectId));
      sysObj.destroyAllVersions();
      return true;
    } catch (DfException dfe) {
      throw new DocumentManagerException("Exception while deleting all versions of document by id. " + dfe.getMessage(),dfe);
    }
  }

  /**
   * Find the Documentum object id for the given name and context
   *
   * @param name      Documentum object name
   * @param parent    Documentum folder info
   * @param recursive whether to search the sub folder under parent
   * @param objectType
   * @return a list of the object ids found, return an empty list if no objects found
   * @throws DocumentManagerException
   */
  public List findIdByName(String name, String parent, boolean recursive, String objectType)
          throws DocumentManagerException {
    if(StringUtils.isNullOrEmpty(objectType)){
      objectType = "dm_document";
    }
    List result = new ArrayList();
    IDfCollection queryResult = null;
    String queryString;
    try {
      if (recursive) {
        queryString = "select r_object_id from " + objectType + " where folder " +
                "('" + parent + "',DESCEND) AND object_name='" + name + "'";
        queryResult = execQuery(queryString);
      } else {
        queryString = "select r_object_id from " + objectType + " where folder " +
                "('" + parent + "') AND object_name='" + name + "'";
        queryResult = execQuery(queryString);
      }
      if (queryResult != null) {
        while (queryResult.next()) {
          IDfAttr attr = queryResult.getAttr(0);
          String id = queryResult.getId(attr.getName()).toString();
          result.add(id);
        }
      }
    } catch (DfException dfe) {
      throw new DocumentManagerException("Exception in findIdByName() " + dfe.getMessage(),dfe);
    } finally{
      if(queryResult != null){
        try {
          queryResult.close();    //**Must close the collection because it is a limited resource
        } catch (DfException e) {
          Logger.log(new LoggableError("Exception in findIdByName() while closing queryResult"));
        }
      }
    }
    return result;
  }

  /**
   * Execute the query
   *
   * @param queryString
   * @return a collection of the Documentum objects found
   * @throws DocumentManagerException if anything wrong happens
   */
  private IDfCollection execQuery(String queryString) throws DocumentManagerException {
    IDfCollection col;
    try {
      checkSessionOpen();
      IDfQuery q = new DfQuery();   //**Create the query object then set the query string.
      q.setDQL(queryString);
      col = q.execute(sess, DfQuery.DF_READ_QUERY);   //**Synchronously execute the query.
    } catch (DfException dfe) {
      throw new DocumentManagerException("Exception while querying docBase: " + dfe.getMessage(), dfe);
    }
    return col;
  }

  /**
   * Adds new document to the repository...
   * @param documentAttributes
   * @param attachmentLocation
   * @param parentFolderPath
   * @param addPDFRenditionCapability
   * @return String: object-id of document saved into the repository
   * @throws DocumentManagerException
   */
  private IDfSysObject addNewDocument(RetrievedDocument retrievedDocument, DocumentAttributes documentAttributes, String attachmentLocation, String parentFolderPath, boolean addPDFRenditionCapability)
          throws DocumentManagerException, AttributeListParseException {
    try {
      checkSessionOpen();
      IDfSysObject sysObj = instantiateSysObject();
      setDocumentumObjectInfo(sysObj, documentAttributes, attachmentLocation);
      sysObj.setFile(attachmentLocation);
      sysObj.link(parentFolderPath);
      sysObj.save();
      if (addPDFRenditionCapability) {
        IDfId queueId = applyPDFRenditionCapability(sysObj);
        createRetrievedDocumentWithPDFRenditionResponse(retrievedDocument,queueId);
      }
      return sysObj;
    } catch (DfException dfe) {
      throw new DocumentManagerException("Exception in addNewDocument() " + dfe.getMessage(),dfe);
    }
  }

  private IDfId applyPDFRenditionCapability(IDfSysObject sysObj) throws DfException,DocumentManagerException {
   String objFormat = sysObj.getFormat().getDOSExtension();
   if (checkMediaFormat(objFormat)) {
        queueOwner = DocumentManagerConstants.STRING_MTS;
   } else {
        queueOwner = DocumentManagerConstants.STRING_DTS;
   }
    return triggerEventByPlacingSysObjectOnQueue(queueOwner, "rendition", 0, false, null,
         "rendition_req_ps_pdf", sysObj);
  }

  private boolean checkMediaFormat(String objFormat) throws DocumentManagerException{
    boolean mediaFormat = false;
    String queryString = "select dos_extension from dm_format where richmedia_enabled = 1";
    IDfCollection queryResult = execQuery(queryString);
    try {
      if (queryResult != null) {
        while (queryResult.next()) {
          if (objFormat.equals(queryResult.getString("dos_extension"))){
          mediaFormat = true;
          }
        }
        queryResult.close();    //Note: must close the collection because it is a limited resource
      }
    } catch (DfException e) {
      throw new DocumentManagerException("Exception while iterating over query result for search: " + e.getMessage(), e);
    }
    return mediaFormat;
  }
  /**
   * Adds pdf rendition capability to the inserted document object
   * @param queueOwner- identifies the queue where you want to place the object. Specify the Documentum username of the queue's owner
   * @param event - provides information to be interpreted by the application about the specified object
   * @param priority - defines an application- or user-interpreted priority level for the queued item
   * @param sendMail - directs the server to send an electronic message to the queue's owner notifying the owner that
   *                   an item has been placed on his or her queue. The notification includes the text of the message
   *                   argument
   * @param dueDate- a date for the completion of the work represented by the queued object
   * @param message - defines a message to the owner of the queue on which you are placing the task
   * @param sysObj - the object which is to be placed on the specified queue.
   * @return IDFId
   * @throws DfException
   */
  private IDfId triggerEventByPlacingSysObjectOnQueue(String queueOwner, String event, int priority, boolean sendMail,
                                                      IDfTime dueDate, String message, IDfSysObject sysObj) throws DfException {
    return sysObj.queue(queueOwner, event, priority, sendMail, dueDate, message);
  }

  private IDfSysObject setDocumentumObjectInfo(IDfSysObject sysObj, DocumentAttributes documentAttributes, String attachmentLocation)
          throws DocumentManagerException, DfException, AttributeListParseException {
    sysObj.setString(DocumentManagerConstants.DCTM_ATTR_STR_NAME, documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_NAME));
    documentAttributes.addAllAttributesToDFCSysObject(sysObj);
    sysObj.setContentType(getDocumentumContentType(attachmentLocation));
    return sysObj;
  }

  private String getDocumentumContentType(String attachmentLocation) throws DocumentManagerException{
    String documentumType;
    try {
      IDfClientX client = new DfClientX();
      IDfFormatRecognizer formatRecognizer = client.getFormatRecognizer(sess, attachmentLocation, null);
      documentumType = formatRecognizer.getDefaultSuggestedFileFormat();
    } catch (DfException e) {
      throw new DocumentManagerException("Exception while looking up documentum format." + e.getMessage(), e);
    }
    if(documentumType == null){
      throw new DocumentManagerException("Document content type not allowed.");
    }
    return documentumType;
  }

  private String assignNameFromFileLocation(String attachmentLocation, boolean removePath) {
    String fileName = attachmentLocation;
    if (removePath) {   //**remove the path info
      int lastIndex = attachmentLocation.lastIndexOf("\\");
      if (lastIndex == -1) {
        lastIndex = attachmentLocation.lastIndexOf("/");
      }
      if (lastIndex != -1) {
        fileName = attachmentLocation.substring(lastIndex + 1);
      }
    }
    return fileName;
  }

  public IDfSysObject instantiateSysObject() throws DocumentManagerException{
    try {
      return (IDfSysObject) sess.newObject(objectType);
    } catch (DfException e) {
      throw new DocumentManagerException("Object-type name \"" + this.objectType + "\" is not a valid type" + e.getMessage(),e);
    }
  }

  /**
   * Retrieve a document from Documentum based on certain attributes passed in (Currently uses the object Id)
   * @param documentAttributes
   * @return Map containing the Retrieved File attributes
   * @throws com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException
   * @throws DocumentManagerException
   */
  public RetrievedDocument retrieveDocumentObjectWithAttributes(DocumentAttributes documentAttributes,
                                                                List requiredAttributes) throws AttributeListParseException, DocumentManagerException {
    IDfSysObject sysObj;
    String absoluteTempFilePath;
    String documentId = documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID);
    try {
      sysObj = getSysObjectOfRequiredVersion(documentId, documentAttributes);
      absoluteTempFilePath = retrieveContentsToTemporaryLocation(documentAttributes, sysObj);
      RetrievedDocument retrievedDocument = getRetrievedObjectWithAttributesBasedOnSpecifiedDocumentId(requiredAttributes, sysObj);
      addFileContentsIntoRetrievedObject(absoluteTempFilePath, retrievedDocument);
//      deleteTempFile(absoluteTempFilePath);
      return retrievedDocument;
    } catch (DfException dfe) {
      throw new DocumentManagerException("Exception while retrieving Document " + dfe.getMessage(),dfe);
    }
  }

  private IDfSysObject getSysObjectOfRequiredVersion(String chronicleId, DocumentAttributes documentAttributes) throws DfException, DocumentManagerException, AttributeListParseException {
    if (documentAttributes.containsAttribute(DocumentManagerConstants.DCTM_ATTR_STR_VERSION)) {
      return getSysObjectByChronicleIdAndVersion(chronicleId,
              documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_VERSION));
    }
    return getSysObjectOfCurrentVersionByChronicleId(chronicleId);
  }

  public void search(String queryString, SearchDocumentumRequestEntity searchDocumentumRequestEntity, ResponseEntity responseEntity) throws DocumentManagerException {
    RetrievedDocument retrievedDocument;
    List retrievedDocumentIds = getListOfDocumentIdsBasedOnQuery(queryString);
    for (int i = 0; i < retrievedDocumentIds.size(); i++) {
      String documentId = (String) retrievedDocumentIds.get(i);
      IDfSysObject sysObject = getSysObject(documentId);
      retrievedDocument = getRetrievedObjectWithAttributesBasedOnSpecifiedDocumentId(searchDocumentumRequestEntity.getRequiredAttributes(), sysObject);
      responseEntity.getRetrievedDocumentList().add(retrievedDocument);
    }
  }

  private List getListOfDocumentIdsBasedOnQuery(String queryString) throws DocumentManagerException {
    List retrievedDocumentIds = new ArrayList();
    IDfCollection queryResult = execQuery(queryString);
    try {
      if (queryResult != null) {
        while (queryResult.next()) {
          IDfAttr idAttr = queryResult.getAttr(0);
          String documentId = queryResult.getId(idAttr.getName()).toString();
          retrievedDocumentIds.add(documentId);
        }
        queryResult.close();    //Note: must close the collection because it is a limited resource
      }
    } catch (DfException e) {
      throw new DocumentManagerException("Exception while iterating over query result for search: " + e.getMessage(), e);
    }
    return retrievedDocumentIds;
  }

  /**
   * Returns an interger constant, stating the type of the attribute.
   * @param attributeName
   * @param sysObj
   * @return
   * @throws DfException
   */
  public int lookupAttributeType(String attributeName, IDfSysObject sysObj) throws DfException {
    int attrDataType;
    IDfType idfType = sysObj.getType();
    attrDataType = idfType.getTypeAttrDataType(attributeName);
    return attrDataType;
  }

  /**
   * Returns true if attribute is repeating, false if it is single.
   * @param attributeName
   * @param sysObj
   * @return
   * @throws DfException
   */
  public boolean isAttributeRepeating(String attributeName, IDfSysObject sysObj) throws DfException {
    IDfType idfType = sysObj.getType();
    return idfType.isTypeAttrRepeating(attributeName);
  }

  private IDfSysObject getSysObject(String documentId) throws DocumentManagerException {
    IDfSysObject sysObj;
    try {
      sysObj = (IDfSysObject) sess.getObject(new DfId(documentId));
    } catch (DfException e) {
      throw new DocumentManagerException(e);
    }
    return sysObj;
  }

  /**
   * Builds the RetrievedDocument object with attributes (default + custom) based on specified objectId.
   * @param requiredAttributes
   * @param sysObj
   * @return
   * @throws DocumentManagerException
   */
  private RetrievedDocument getRetrievedObjectWithAttributesBasedOnSpecifiedDocumentId(List requiredAttributes, IDfSysObject sysObj) throws DocumentManagerException {
    RetrievedDocument retrievedDocument = new RetrievedDocument();
    try {
      addDefaultAttributesIntoRetrievedObject(retrievedDocument, sysObj, sysObj.getString(DocumentManagerConstants.DCTM_ATTR_STR_NAME));
      if(customAttributesRequired(requiredAttributes)){
        addCustomRequestAttributesIntoRetrievedObject(sysObj, retrievedDocument, requiredAttributes);
      }
      return retrievedDocument;
    } catch (DfException e) {
      throw new DocumentManagerException("Exception while looking up attributes for specified documentId: " + e.getMessage(), e);
    }
  }

  private void addCustomRequestAttributesIntoRetrievedObject(IDfSysObject sysObj, RetrievedDocument retrievedDocument, List requiredAttributes) throws DfException {
    for (int i = 0; i < requiredAttributes.size(); i++) {
      String requiredAttr = (String) requiredAttributes.get(i);
      if (sysObj.isAttrRepeating(requiredAttr)) {
        addMultipleValuedAttribute(sysObj, requiredAttr, retrievedDocument);
      }
      else{
        addSingleValuedAttribute(sysObj, requiredAttr, retrievedDocument);
      }
    }
  }

  private void addSingleValuedAttribute(IDfSysObject sysObj, String requiredAttr, RetrievedDocument retrievedDocument) throws DfException {
    String attrValue = sysObj.getString(requiredAttr);
    retrievedDocument.getDocumentAttributes().addAttribute(requiredAttr, attrValue, null);
  }

  private void addMultipleValuedAttribute(IDfSysObject sysObj, String requiredAttr, RetrievedDocument retrievedDocument) throws DfException {
    int valueCount = sysObj.getValueCount(requiredAttr);
    List valueList = new ArrayList();
    for (int i = 0; i < valueCount; i++) {
      valueList.add(sysObj.getRepeatingString(requiredAttr, i));
    }
    retrievedDocument.getDocumentAttributes().addAttribute(requiredAttr, valueList, null);
  }

  private boolean customAttributesRequired(List requiredAttributes) {
    return (requiredAttributes != null && requiredAttributes.size() > 0);
  }

  private String retrieveContentsToTemporaryLocation(DocumentAttributes documentAttributes, IDfSysObject sysObj) throws DfException, AttributeListParseException {
    String absoluteTempFilePath = System.getProperty(DocumentManagerConstants.TEMP_DIRECTORY) +
            sysObj.getString(DocumentManagerConstants.DCTM_ATTR_STR_NAME);
    String requestedFormat;
    if (documentAttributes.containsAttribute(DocumentManagerConstants.DCTM_ATTR_STR_FORMAT) &&
            !StringUtils.isNullOrEmpty(documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_FORMAT))) {
      requestedFormat = documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_FORMAT);
    } else {
      requestedFormat = sysObj.getContentType();
    }
    retrieveContentsInExpectedFormat(sysObj, absoluteTempFilePath, requestedFormat, 0, "", false);
    return absoluteTempFilePath;
  }

  private void retrieveContentsInExpectedFormat(IDfSysObject sysObj, String absoluteTempFilePath, String contentType, int positionOfContent, String pageModifier, boolean getResourceForMacSystems) throws DfException {
    try {
      sysObj.getFileEx2 (absoluteTempFilePath, contentType, positionOfContent, pageModifier, getResourceForMacSystems);
    } catch (DfException e) {
      retrieveContentsInDefaultFormatIncaseOfException(sysObj, absoluteTempFilePath, positionOfContent, pageModifier, getResourceForMacSystems);
    }
  }

  private void retrieveContentsInDefaultFormatIncaseOfException(IDfSysObject sysObj, String absoluteTempFilePath, int positionOfContent, String pageModifier, boolean getResourceForMacSystems) throws DfException {
    sysObj.getFileEx2 (absoluteTempFilePath, sysObj.getContentType(), positionOfContent, pageModifier, getResourceForMacSystems);
  }

  private void addDefaultAttributesIntoRetrievedObject(RetrievedDocument retrievedDocument, IDfSysObject sysObj, String fileName) throws DfException {
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, getChronicleId(sysObj), null);
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION, getVersion(sysObj), null);
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_NAME, fileName, null);
  }

  private void addFileContentsIntoRetrievedObject(String absoluteTempFilePath, RetrievedDocument retrievedDocument) {
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS,
            absoluteTempFilePath, null);
  }

  public boolean existFolderByName(String name, String parent) throws DocumentManagerException {
    boolean exist = false;
    try {
      IDfCollection queryResult = execQuery("select r_object_id from dm_folder where folder " +
              "('" + parent + "') AND object_name='" + name + "'");
      if (queryResult != null) {
        if (queryResult.next()) {
          exist = true;
        }
        queryResult.close();
      }
      return exist;
    } catch (DfException dfe) {
      throw new DocumentManagerException("Exception in findIdByDocumentName() " +
              dfe.getMessage(),dfe);
    }
  }

  public void createFolder(String folderName, String parent) throws DocumentManagerException {
    try {
      checkSessionOpen();
      IDfSysObject sysObj = (IDfSysObject) sess.newObject("dm_folder");
      sysObj.setObjectName(folderName);
      sysObj.link(parent);
      sysObj.save();
    } catch (DfException dfe) {
      throw new DocumentManagerException("Exception in createFolder():" + dfe.getMessage(),dfe);
    }
  }

  public void delete(String objectId, DocumentAttributes documentAttributes, ResponseEntity responseEntity) throws DocumentManagerException, AttributeListParseException, DfException {
    String versionToBeDeleted;
    boolean deletedSuccessfully;
    if (documentAttributes.containsAttribute(DocumentManagerConstants.DCTM_ATTR_STR_VERSION)) {
      versionToBeDeleted = documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_VERSION);
      deletedSuccessfully = deleteSpecificVersion(objectId, versionToBeDeleted);
    } else {
      versionToBeDeleted = DocumentManagerConstants.RESP_CONST_ALL_VERSIONS_DELETED;
      deletedSuccessfully = deleteAllVersionsById(objectId);
    }
    if(deletedSuccessfully){
      addDeletedDocumentDetailsToResponse(objectId, versionToBeDeleted, responseEntity);
    }
  }

  private boolean deleteSpecificVersion(String objectId, String versionToBeDeleted) throws DocumentManagerException, DfException {
    boolean deletedSuccessfully;
    IDfSysObject sysObj = getSysObjectByChronicleIdAndVersion(objectId, versionToBeDeleted);
    sysObj.destroy();
    deletedSuccessfully = true;
    return deletedSuccessfully;
  }

  private void addDeletedDocumentDetailsToResponse(String objectId, String versionDeleted, ResponseEntity responseEntity) {
    RetrievedDocument retrievedDocument = new RetrievedDocument();
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, objectId, null);
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION, versionDeleted, null);
    responseEntity.getRetrievedDocumentList().add(retrievedDocument);
  }
}