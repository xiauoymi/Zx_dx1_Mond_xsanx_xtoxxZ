package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumRequestEntity;
import com.documentum.fc.common.DfException;
import com.documentum.fc.client.IDfSysObject;

import java.util.List;

/**
 * Service class to communicate with Documentum
 *
 * @author WWZHOU
 */
public interface IDFCServices {

  /**
   * Connect to Documentum
   *
   *
   * @throws DocumentManagerException
   */
  void connect() throws DocumentManagerException;

  /**
   * Close the current Documentum connection
   */
  void close();

  /**
   * Start the transaction
   */
  void beginTransaction() throws DocumentManagerException ;

  /**
   * Commit all the changes from last call to <code>beginTransaction()</code>
   */
  void commitTransaction() throws DocumentManagerException ;

  /**
   * Roll back all the changes for current transaction
   */
  void rollbackTransaction() throws DocumentManagerException ;

  /**
   * Checks if session is open, else throws an exception.
   * @throws IllegalStateException
   */
  void checkSessionOpen() throws IllegalStateException;

  /**
   * Insert w/o support for versioning (throws an exception if the document already exists.)
   * Also adds PDF rendition capability to the inserted document object.
   * @param insertDctmRequestEntity
   * @param directoryStructure
   * @param atttachmentLocation
   * @return RetrievedDocument details
   * @throws DocumentManagerException
   * @throws AttributeListParseException
   */
  RetrievedDocument saveDocument(InsertDocumentumRequestEntity insertDctmRequestEntity, String directoryStructure, String atttachmentLocation) throws DocumentManagerException, AttributeListParseException, DfException;

  /**
   * Find the Documentum object id for the given name and context
   *
   * @param name      Documentum object name
   * @param parent    Documentum folder info
   * @param recursive whether to search the sub folder under parent
   * @param objectType
   * @return a list of the object ids found, return an empty list if no objects found
   * @throws DocumentManagerException
   */
  List findIdByName(String name, String parent, boolean recursive, String objectType) throws DocumentManagerException;

  /**
   * Delete the given Documentum by fileName.
   * @param fileName
   * @param objectType
   * @throws DocumentManagerException
   */
  void deleteByName(String fileName, String objectType) throws DocumentManagerException;

  /**
   * Delete the given Documentum object id
   *
   * @param objectId the Documentum object id
   * @throws DocumentManagerException
   */
  boolean deleteById(String objectId) throws DocumentManagerException;

  /**
   * Delete all versions of the given Documentum object id
   *
   * @param objectId the Documentum object id
   * @throws DocumentManagerException
   */
  boolean deleteAllVersionsById(String objectId) throws DocumentManagerException;

  /**
   * Retrieve a given Document from Documentum using the objectId(documentId)
   *
   * @param documentAttributes
   * @param requiredAttributes List
   * @return Map containing the retrieved file attributes
   * @throws AttributeListParseException
   * @throws DocumentManagerException
   */
  RetrievedDocument retrieveDocumentObjectWithAttributes(DocumentAttributes documentAttributes,
                                                         List requiredAttributes) throws AttributeListParseException, DocumentManagerException;
  /**
   * Checks whether the given Documentum folder name exists in Documentum
   *
   * @param name   Documentum folder name
   * @param parent Documentum context info
   * @return true if the Documentum folder already exists. Return false if no such
   *         folder exists
   * @throws DocumentManagerException
   */
  boolean existFolderByName(String name, String parent) throws DocumentManagerException;

  /**
   * Create a Documentum folder
   *
   * @param folderName the folder name to create
   * @param parent     the context
   * @throws DocumentManagerException
   * @see #createFolder(String, String)
   */
  void createFolder(String folderName, String parent) throws DocumentManagerException;

  void search(String queryString, SearchDocumentumRequestEntity searchDocumentumRequestEntity, ResponseEntity responseEntity) throws DocumentManagerException;

  /**
   * Returns an integer constant, stating the type of the attribute.
   * Defaults to String, if attribute not found (Dctm behavior).
   * @param attributeName
   * @param sysObj
   * @return
   * @throws DfException
   */
  int lookupAttributeType(String attributeName, IDfSysObject sysObj) throws DfException;

  /**
   * Returns true if attribute is repeating, false if it is single.
   * @param attributeName
   * @param sysObj
   * @return
   * @throws DfException
   */
  boolean isAttributeRepeating(String attributeName, IDfSysObject sysObj) throws DfException;

  void delete(String objectId, DocumentAttributes documentAttributes, ResponseEntity responseEntity) throws DocumentManagerException, AttributeListParseException, DfException;

  IDfSysObject instantiateSysObject() throws DocumentManagerException;

  /**
   * Updates the document with new/modified contents/attributes as new version
   * @param updateDctmRequestEntity
   * @param newContentsLocation
   * @return RetrievedDocument
   */
  RetrievedDocument update(UpdateDocumentumRequestEntity updateDctmRequestEntity, String newContentsLocation) throws AttributeListParseException, DocumentManagerException, DfException;

  /**
   * In case the update fails...
   * @throws DfException
   * @throws DocumentManagerException
   */
  void cancelCheckoutDocument() throws DfException, DocumentManagerException;
}