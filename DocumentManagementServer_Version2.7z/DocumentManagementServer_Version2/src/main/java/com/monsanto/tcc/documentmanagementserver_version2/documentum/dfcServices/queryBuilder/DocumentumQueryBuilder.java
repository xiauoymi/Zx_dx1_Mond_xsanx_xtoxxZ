package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.DocumentumAttributeTypeFactory;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.InvalidDctmAttrValueException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.DocumentumAttributeType;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;
import com.monsanto.Util.StringUtils;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;

import java.util.Iterator;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 5, 2006
 * Time: 4:12:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentumQueryBuilder {

  public String buildSearchQueryForDocumentId(RequestEntity requestEntity, IDFCServices service) throws AttributeListParseException, DocumentManagerException, IllegalAccessException, InvalidDctmAttrValueException, InstantiationException, DfException {
    SearchDocumentumRequestEntity searchDocumentumRequestEntity = (SearchDocumentumRequestEntity)requestEntity;
    DocumentAttributes documentAttributes = searchDocumentumRequestEntity.getDocumentAttributes();
    ConnectionInfo connectionInfo = searchDocumentumRequestEntity.getConnectionInfo();
    String queryString = "";
    queryString += buildSelectQueryStringForDocumentId();
    queryString += buildFromQueryString(connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_OBJECT_TYPE), searchDocumentumRequestEntity);
    queryString += buildSearchQueryString(documentAttributes);
    queryString += buildWhereQueryString(documentAttributes, connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_CABINET), searchDocumentumRequestEntity.getDirectoryStructure(), service);
    return queryString;
  }

  private String buildSearchQueryString(DocumentAttributes documentAttributes) throws AttributeListParseException {
    String searchQueryString = "";
    if(documentAttributes.containsAttribute(DocumentManagerConstants.ATTR_STR_FULL_TEXT)){
      String fullTextString = documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_FULL_TEXT);
      String[] listOfWords = fullTextString.trim().split("\\s+");
      searchQueryString += DocumentManagerConstants.QUERY_PARAM_SEARCH_STR;
      int numberOfWords = listOfWords.length;
      for (int i = 0; i < numberOfWords; i++) {
        String word = listOfWords[i];
        searchQueryString += "'" + word + "' ";
        if(i < numberOfWords - 1){
          searchQueryString += DocumentManagerConstants.QUERY_PARAM_AND_STR;
        }
      }
      documentAttributes.removeAttr(DocumentManagerConstants.ATTR_STR_FULL_TEXT);
    }
    return searchQueryString;
  }

  private String buildQueryAttributeString(DocumentAttributes documentAttributes, IDFCServices service) throws AttributeListParseException, IllegalAccessException, InstantiationException, InvalidDctmAttrValueException, DocumentManagerException, DfException {
    IDfSysObject sysObj = service.instantiateSysObject();
    Iterator queryAttrIt = documentAttributes.getAttrIterator();
    String queryAttrString = "";
    while (queryAttrIt.hasNext()) {
      String queryAttrName = (String) queryAttrIt.next();
      DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(service.lookupAttributeType(queryAttrName, sysObj));
      String baseQueryAttrValue = documentAttributes.getAttrValue(queryAttrName);
      queryAttrString += buildQueryAttrNameBasedOnType(queryAttrName, service.isAttributeRepeating(queryAttrName, sysObj)) +
              getDQLOperator(documentAttributes, queryAttrName) +
              documentumAttributeType.buildQueryAttributeValue(baseQueryAttrValue) +
              DocumentManagerConstants.SPACE_SEPERATOR;
      queryAttrString += DocumentManagerConstants.QUERY_PARAM_AND_STR;
    }
    return queryAttrString;
  }

  private String getDQLOperator(DocumentAttributes documentAttributes, String queryAttrName) throws AttributeListParseException, DocumentManagerException {
    String operator = null;
    Map operatorMap = DocumentManagerConstants.operatorMap;
    if (operatorMap.containsKey(documentAttributes.getOperator(queryAttrName))) {
      operator = (String) operatorMap.get(documentAttributes.getOperator(queryAttrName));
      return operator;
    } else {
      throw new DocumentManagerException("Dctm Query Builder Exception: " +
              "invalid operator \"" + operator + "\" specified in request for attribute \"" + queryAttrName + "\"");
    }
  }

  private String buildQueryAttrNameBasedOnType(String queryAttrName, boolean queryAttrMultipleValued) {
    if(queryAttrMultipleValued){
      return DocumentManagerConstants.QUERY_PARAM_ANY_STR + queryAttrName;
    }
    return queryAttrName;
  }

  private String buildWhereQueryString(DocumentAttributes documentAttributes, String cabinet, String directoryStructure, IDFCServices service) throws AttributeListParseException, IllegalAccessException, InvalidDctmAttrValueException, InstantiationException, DfException, DocumentManagerException {
    String folderPath = buildFolderPath(cabinet, directoryStructure);
    return DocumentManagerConstants.QUERY_PARAM_WHERE_STR +
            buildQueryAttributeString(documentAttributes, service) +
            buildFolderClause(folderPath);
  }

  private String buildFolderPath(String cabinet, String directoryStructure) {
    if (StringUtils.isNullOrEmpty(directoryStructure)) {
      return cabinet;
    } else {
      return cabinet + "/" + directoryStructure;
    }
  }

  private String buildFolderClause(String folderPath) {
    return DocumentManagerConstants.QUERY_PARAM_FOLDER_STR +
            "('" + folderPath + "', "+ DocumentManagerConstants.QUERY_PARAM_DESCEND_STR + ")" +
            DocumentManagerConstants.SPACE_SEPERATOR;
  }

  private String buildFromQueryString(String objectType, RequestEntity requestEntity) {
    String fromQueryString = DocumentManagerConstants.QUERY_PARAM_FROM_STR + objectType + DocumentManagerConstants.SPACE_SEPERATOR;
    if(requestEntity.isSearchAllVersions()){
      fromQueryString += DocumentManagerConstants.QUERY_PARAM_ALL_VERSIONS_STR + DocumentManagerConstants.SPACE_SEPERATOR;
    }
    return fromQueryString;
  }

  private String buildSelectQueryStringForDocumentId() {
    return DocumentManagerConstants.QUERY_PARAM_SELECT_STR + DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID
            + DocumentManagerConstants.SPACE_SEPERATOR;
  }
}