package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 25, 2006
 * Time: 2:49:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class BooleanAttributeType extends DocumentumAttributeType {

  protected void validateQueryAttributeValue(String baseAttributeValue) throws InvalidDctmAttrValueException {
    if(!baseAttributeValue.equalsIgnoreCase("true")
            && !baseAttributeValue.equalsIgnoreCase("false")
            ){
      throw new InvalidDctmAttrValueException("Documentum Attribute of type \"boolean\" does not have value in expected format");
    }
  }

  protected String buildTypeSpecificQueryAttributeValue(String baseAttributeValue) {
    return baseAttributeValue;
  }
}