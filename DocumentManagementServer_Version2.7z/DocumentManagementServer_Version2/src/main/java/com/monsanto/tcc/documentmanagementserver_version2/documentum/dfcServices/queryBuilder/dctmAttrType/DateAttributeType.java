package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 25, 2006
 * Time: 12:00:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class DateAttributeType extends DocumentumAttributeType {

  protected void validateQueryAttributeValue(String baseAttributeValue) throws InvalidDctmAttrValueException {
  }

  protected String buildTypeSpecificQueryAttributeValue(String baseAttributeValue) {
    return DocumentManagerConstants.QUERY_PARAM_DATE_STR + "('" + baseAttributeValue + "')";
  }
}