package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 25, 2006
 * Time: 11:14:05 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class DocumentumAttributeType {

  private static List invalidCharacterList;

  static{
    invalidCharacterList = new ArrayList();
    invalidCharacterList.add("'");                //**Add list of invalid characters...
  }

  public String buildQueryAttributeValue(String baseAttributeValue) throws InvalidDctmAttrValueException {
    try {
      validateNoSpecialCharactersExists(baseAttributeValue);
      validateQueryAttributeValue(baseAttributeValue);
      return buildTypeSpecificQueryAttributeValue(baseAttributeValue);
    } catch(InvalidDctmAttrValueException e) {
      throw new InvalidDctmAttrValueException(e);
    }
  }

  protected abstract void validateQueryAttributeValue(String baseAttributeValue) throws InvalidDctmAttrValueException;

  protected abstract String buildTypeSpecificQueryAttributeValue(String baseAttributeValue);

  private void validateNoSpecialCharactersExists(String baseAttributeValue) throws InvalidDctmAttrValueException {
    if(containsInvalidCharacters(baseAttributeValue)){
      throw new InvalidDctmAttrValueException("Unsupported special characters are present in the request attribute values.");
    }
  }

  private boolean containsInvalidCharacters(String baseAttributeValue) {
    for (int i = 0; i < invalidCharacterList.size(); i++) {
      String invalidChar = (String) invalidCharacterList.get(i);
      if(containsChar(baseAttributeValue, invalidChar)){
        return true;
      }
    }
    return false;
  }

  private boolean containsChar(String baseAttributeValue, String invalidChar) {
    return baseAttributeValue.indexOf(invalidChar) != -1;
  }
}