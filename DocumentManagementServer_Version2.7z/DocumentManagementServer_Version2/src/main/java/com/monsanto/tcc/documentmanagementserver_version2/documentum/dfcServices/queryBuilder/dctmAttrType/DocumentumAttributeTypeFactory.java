package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 25, 2006
 * Time: 11:26:17 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class DocumentumAttributeTypeFactory {

  private static Map queryAttributeTypeMap;

  static{
    queryAttributeTypeMap = new HashMap();
    queryAttributeTypeMap.put(new Integer(DocumentManagerConstants.DCTM_TYPE_BOOLEAN), BooleanAttributeType.class);
    queryAttributeTypeMap.put(new Integer(DocumentManagerConstants.DCTM_TYPE_INT), IntegerAttributeType.class);
    queryAttributeTypeMap.put(new Integer(DocumentManagerConstants.DCTM_TYPE_STRING), StringAttributeType.class);
    queryAttributeTypeMap.put(new Integer(DocumentManagerConstants.DCTM_TYPE_ID), IDAttributeType.class);
    queryAttributeTypeMap.put(new Integer(DocumentManagerConstants.DCTM_TYPE_DATE_TIME), DateAttributeType.class);
    queryAttributeTypeMap.put(new Integer(DocumentManagerConstants.DCTM_TYPE_DOUBLE), DoubleAttributeType.class);
    queryAttributeTypeMap.put(new Integer(DocumentManagerConstants.DCTM_TYPE_UNDEFINED), StringAttributeType.class);
  }

  public static DocumentumAttributeType getQueryAttributeType(int attributeType) throws IllegalAccessException, InstantiationException {
    Class attributeTypeClass = (Class) queryAttributeTypeMap.get(new Integer(attributeType));
    if (attributeTypeClass != null){
      Object queryAttributeTypebject = attributeTypeClass.newInstance();
      if (queryAttributeTypebject instanceof DocumentumAttributeType) {
        return (DocumentumAttributeType) queryAttributeTypebject;
      }
    }
    return (DocumentumAttributeType) IDAttributeType.class.newInstance();   //Default Implementation
  }
}