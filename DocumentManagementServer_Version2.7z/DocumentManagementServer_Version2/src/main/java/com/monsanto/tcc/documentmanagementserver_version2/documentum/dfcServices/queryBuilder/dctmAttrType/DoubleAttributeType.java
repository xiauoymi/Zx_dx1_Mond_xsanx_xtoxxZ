package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.DocumentumAttributeType;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.InvalidDctmAttrValueException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 25, 2006
 * Time: 2:49:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class DoubleAttributeType extends DocumentumAttributeType {

  protected void validateQueryAttributeValue(String baseAttributeValue) throws InvalidDctmAttrValueException {
    if(!isValidDouble(baseAttributeValue)){
      throw new InvalidDctmAttrValueException("Documentum Attribute of type \"double\" does not have value in expected format");
    }
  }

  private boolean isValidDouble(String baseAttributeValue) {
    try {
      Double.parseDouble(baseAttributeValue);
      return true;
    } catch(NumberFormatException nfe){
      return false;
    }
  }

  protected String buildTypeSpecificQueryAttributeValue(String baseAttributeValue) {
    return baseAttributeValue;
  }
}