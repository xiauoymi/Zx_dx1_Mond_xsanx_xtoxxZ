package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.DocumentumAttributeType;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.InvalidDctmAttrValueException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 25, 2006
 * Time: 12:01:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class IDAttributeType extends DocumentumAttributeType {

  protected void validateQueryAttributeValue(String baseAttributeValue) throws InvalidDctmAttrValueException {
  }

  protected String buildTypeSpecificQueryAttributeValue(String baseAttributeValue) {
    return "'" + baseAttributeValue + "'";
  }
}