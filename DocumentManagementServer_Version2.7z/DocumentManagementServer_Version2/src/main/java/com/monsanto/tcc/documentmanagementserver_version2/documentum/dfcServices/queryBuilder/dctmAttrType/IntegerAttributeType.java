package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 25, 2006
 * Time: 11:31:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class IntegerAttributeType extends DocumentumAttributeType {

  protected void validateQueryAttributeValue(String baseAttributeValue) throws InvalidDctmAttrValueException {
    if(!isValidInteger(baseAttributeValue)){
      throw new InvalidDctmAttrValueException("Documentum Attribute of type \"int\" does not have value in expected format");
    }
  }

  private boolean isValidInteger(String baseAttributeValue) {
    try {
      Integer.parseInt(baseAttributeValue);
      return true;
    } catch(NumberFormatException nfe) {
      return false;
    }
  }

  protected String buildTypeSpecificQueryAttributeValue(String baseAttributeValue) {
    return baseAttributeValue;
  }
}