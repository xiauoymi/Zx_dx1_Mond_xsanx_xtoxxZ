package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 25, 2006
 * Time: 11:18:09 AM
 * To change this template use File | Settings | File Templates.
 */
public class InvalidDctmAttrValueException extends Exception {

  public InvalidDctmAttrValueException(InvalidDctmAttrValueException cause) {
    super(cause);
    logTrace(cause);
  }

  public InvalidDctmAttrValueException(String message) {
    super(message);
    logMessage(message);
  }

  private void logMessage(String message) {
    logMessage();
    Logger.log(new LoggableError("Message: " + message));
  }

  private void logMessage() {
    Logger.log(new LoggableError("Invalid Dctm Attr Value Exception..."));
  }

  private void logTrace(Throwable cause) {
    Logger.log(new LoggableError("Stack Trace: " + cause));
  }
}