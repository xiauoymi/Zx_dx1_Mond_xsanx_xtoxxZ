package com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.builder;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.parser.InsertDocumentumRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumResponseEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Feb 22, 2006
 * Time: 2:37:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class InsertDocumentumBuilder extends DocumentumBuilder {

  public void buildParser() {
    setRequestParser(new InsertDocumentumRequestParser());
  }

  public void buildRequestEntity() {
    setRequestEntity(new InsertDocumentumRequestEntity());
  }

  public void buildResponseEntity() {
    setResponseEntity(new InsertDocumentumResponseEntity());
  }
}
