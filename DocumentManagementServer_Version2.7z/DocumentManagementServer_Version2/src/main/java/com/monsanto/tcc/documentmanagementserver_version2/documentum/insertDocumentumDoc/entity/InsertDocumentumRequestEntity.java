package com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Feb 24, 2006
 * Time: 1:56:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class InsertDocumentumRequestEntity extends DocumentumRequestEntity {
    private boolean requestPDFRendition = false;
  
  public InsertDocumentumRequestEntity() {
  }
  public boolean getRequestPDFRendition() {
    return requestPDFRendition;
  }
  public void setRequestPDFRendition(boolean requestPDFRendition) {
    this.requestPDFRendition = requestPDFRendition;
  }
}