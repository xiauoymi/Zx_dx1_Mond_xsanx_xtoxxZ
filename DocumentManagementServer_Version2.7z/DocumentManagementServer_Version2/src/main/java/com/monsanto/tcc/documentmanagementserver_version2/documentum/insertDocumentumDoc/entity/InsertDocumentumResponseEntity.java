package com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumResponseEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 3, 2006
 * Time: 1:15:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class InsertDocumentumResponseEntity extends DocumentumResponseEntity {

  protected String getServiceSpecificNodeName() {
    return DocumentManagerConstants.TAG_INSERT_DOCUMENT_NODE_STR;
  }
}