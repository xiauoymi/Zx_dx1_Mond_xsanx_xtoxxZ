package com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.parser;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import org.w3c.dom.Node;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 24, 2006 Time: 1:53:50 PM To change this template use File |
 * Settings | File Templates.
 */
public class InsertDocumentumRequestParser extends DocumentumRequestParser {

  public void parseOperationSpecificRequest(Node requestDetailsNode,
                                            DocumentumRequestEntity documentumRequestEntity) throws
      AttributeListParseException, DocumentManagerException {
    InsertDocumentumRequestEntity insertDctmRequestEntity = (InsertDocumentumRequestEntity) documentumRequestEntity;
    Node insertDocumentNode = DOMUtil
        .getChild(requestDetailsNode, DocumentManagerConstants.TAG_INSERT_DOCUMENT_NODE_STR);
    parseAttributes(insertDocumentNode, insertDctmRequestEntity);
    parsePDFRendition(insertDocumentNode, insertDctmRequestEntity);
  }

  private void parsePDFRendition(Node insertDocumentNode, InsertDocumentumRequestEntity documentumRequestEntity) {
    String childValue = DOMUtil.getChildValue(insertDocumentNode, DocumentManagerConstants.TAG_PDFRENDITION_STR);
    documentumRequestEntity.setRequestPDFRendition((childValue == null || "false".equals(childValue)) ? false : true);
  }

  private void parseAttributes(Node insertDocumentNode, InsertDocumentumRequestEntity insertDctmRequestEntity) throws
      DocumentManagerException {
    Node docAttributesNode = DOMUtil.getChild(insertDocumentNode, DocumentManagerConstants.TAG_NAME_DOCUMENT_ATTRIBUTES);
    parseAttributeList(docAttributesNode, insertDctmRequestEntity);
  }

}