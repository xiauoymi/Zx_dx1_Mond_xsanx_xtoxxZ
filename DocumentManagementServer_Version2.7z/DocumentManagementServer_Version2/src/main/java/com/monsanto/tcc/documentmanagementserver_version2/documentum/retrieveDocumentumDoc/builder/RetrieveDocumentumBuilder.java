package com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.builder;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.RetrieveDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.RetrieveDocumentumResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.parser.RetrieveDocumentumRequestParser;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 29, 2006
 * Time: 1:13:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveDocumentumBuilder extends DocumentumBuilder {

  public void buildParser() {
    setRequestParser(new RetrieveDocumentumRequestParser());
  }

  public void buildRequestEntity() {
    setRequestEntity(new RetrieveDocumentumRequestEntity());
  }

  public void buildResponseEntity() {
    setResponseEntity(new RetrieveDocumentumResponseEntity());
  }
}
