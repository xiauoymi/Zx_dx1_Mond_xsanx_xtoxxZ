package com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 29, 2006
 * Time: 10:34:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveDocumentumRequestEntity extends DocumentumRequestEntity {

  public RetrieveDocumentumRequestEntity() {
  }
}