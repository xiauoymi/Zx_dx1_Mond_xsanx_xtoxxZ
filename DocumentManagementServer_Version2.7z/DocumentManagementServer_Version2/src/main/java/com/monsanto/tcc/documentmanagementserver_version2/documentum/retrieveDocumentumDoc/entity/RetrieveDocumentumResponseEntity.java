package com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.ResponseStreamWriter;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 3, 2006
 * Time: 1:16:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveDocumentumResponseEntity extends DocumentumResponseEntity {

  private ResponseStreamWriter responseStreamWriter;

  public RetrieveDocumentumResponseEntity() {
    this.responseStreamWriter = new ResponseStreamWriter();
  }

  public void sendResponse(UCCHelper helper) throws AttributeListParseException, IOException {
    RetrievedDocument retrievedDocument = (RetrievedDocument) getRetrievedDocumentList().get(0);
    responseStreamWriter.writeSuccessfulRetrieveDocumentResponseToStream(retrievedDocument, helper);
  }

  protected String getServiceSpecificNodeName() {
    return null;
  }
}