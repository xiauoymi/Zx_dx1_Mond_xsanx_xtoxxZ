package com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.builder;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.parser.SearchDocumentumRequestParser;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 10, 2006
 * Time: 11:20:46 AM
 * To change this template use File | Settings | File Templates.
 */
public class SearchDocumentumBuilder extends DocumentumBuilder {

  public void buildParser() {
    setRequestParser(new SearchDocumentumRequestParser());
  }

  public void buildRequestEntity() {
    setRequestEntity(new SearchDocumentumRequestEntity());
  }

  public void buildResponseEntity() {
    setResponseEntity(new SearchDocumentumResponseEntity());
  }
}