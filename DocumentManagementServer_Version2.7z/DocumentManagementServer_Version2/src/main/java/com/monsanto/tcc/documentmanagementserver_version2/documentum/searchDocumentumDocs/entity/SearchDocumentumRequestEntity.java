package com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 10, 2006
 * Time: 11:37:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class SearchDocumentumRequestEntity extends DocumentumRequestEntity {

  public SearchDocumentumRequestEntity() {
  }
}