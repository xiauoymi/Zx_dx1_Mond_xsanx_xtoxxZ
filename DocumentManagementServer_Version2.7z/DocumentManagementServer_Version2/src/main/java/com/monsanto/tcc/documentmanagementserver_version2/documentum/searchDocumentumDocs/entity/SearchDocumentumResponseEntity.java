package com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumResponseEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 10, 2006
 * Time: 11:33:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class SearchDocumentumResponseEntity extends DocumentumResponseEntity {

  protected String getServiceSpecificNodeName() {
    return DocumentManagerConstants.TAG_SEARCH_DOCUMENT_NODE_STR;
  }
}