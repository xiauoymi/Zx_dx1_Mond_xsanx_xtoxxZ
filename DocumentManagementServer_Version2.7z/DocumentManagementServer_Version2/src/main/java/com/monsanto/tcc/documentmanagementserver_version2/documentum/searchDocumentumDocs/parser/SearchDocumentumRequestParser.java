package com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.parser;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumRequestEntity;
import org.w3c.dom.Node;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 10, 2006
 * Time: 11:25:57 AM
 * To change this template use File | Settings | File Templates.
 */
public class SearchDocumentumRequestParser extends DocumentumRequestParser {

  public void parseOperationSpecificRequest(Node requestDetailsNode, DocumentumRequestEntity documentumRequestEntity) throws DocumentManagerException {
    SearchDocumentumRequestEntity searchDocumentumRequestEntity = (SearchDocumentumRequestEntity)documentumRequestEntity;
    Node searchAllVersionsNode = getAttributesNode(requestDetailsNode, DocumentManagerConstants.TAG_NAME_SEARCH_ALL_VERSIONS);
    if (queryAttributesSpecified(searchAllVersionsNode)) {
      parseSearchAllVersionValue(searchAllVersionsNode, searchDocumentumRequestEntity);
    }
    Node docAttributesNode = getAttributesNode(requestDetailsNode, DocumentManagerConstants.TAG_NAME_QUERY_ATTRIBUTES);
    if (queryAttributesSpecified(docAttributesNode)) {
      parseAttributeList(docAttributesNode, searchDocumentumRequestEntity);
    }
    Node requiredAttributesNode = getAttributesNode(requestDetailsNode, DocumentManagerConstants.TAG_NAME_REQUIRED_ATTRIBUTES);
    if (customAttributesRequired(requiredAttributesNode)) {
      parseRequiredAttributeList(requiredAttributesNode, searchDocumentumRequestEntity);
    }
  }

  private void parseSearchAllVersionValue(Node searchAllVersionsNode, SearchDocumentumRequestEntity searchDocumentumRequestEntity) {
    String searchAllVersionsValue = DOMUtil.getTextValue(searchAllVersionsNode);
    if(searchAllVersionsValue.equalsIgnoreCase("true")){
      searchDocumentumRequestEntity.setSearchAllVersions(true);
    }
  }

  private boolean queryAttributesSpecified(Node docAttributesNode) {
    return docAttributesNode != null;
  }

  private boolean customAttributesRequired(Node requiredAttributesNode) {
    return requiredAttributesNode != null;
  }

  private Node getAttributesNode(Node requestDetailsNode, String parentNodeName) {
    Node retrieveDocumentNode = DOMUtil.getChild(requestDetailsNode, getServiceNodeNameForParsingRequest());
    return DOMUtil.getChild(retrieveDocumentNode, parentNodeName);
  }

  protected String getServiceNodeNameForParsingRequest() {
    return DocumentManagerConstants.TAG_SEARCH_DOCUMENT_NODE_STR;
  }
}