package com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.builder;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.parser.UpdateDocumentumRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumResposeEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jun 2, 2006
 * Time: 3:29:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class UpdateDocumentumBuilder extends DocumentumBuilder {

  public void buildParser() {
    setRequestParser(new UpdateDocumentumRequestParser());
  }

  public void buildRequestEntity() {
    setRequestEntity(new UpdateDocumentumRequestEntity());
  }

  public void buildResponseEntity() {
    setResponseEntity(new UpdateDocumentumResposeEntity());
  }
}