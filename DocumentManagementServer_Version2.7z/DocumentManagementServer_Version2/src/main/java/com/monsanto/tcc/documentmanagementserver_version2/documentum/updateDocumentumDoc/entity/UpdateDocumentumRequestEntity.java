package com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity;

import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jun 2, 2006
 * Time: 3:29:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class UpdateDocumentumRequestEntity extends DocumentumRequestEntity {
  private boolean requestPDFRendition = false;

  public UpdateDocumentumRequestEntity() {
  }
  public boolean getRequestPDFRendition() {
    return requestPDFRendition;
  }
  public void setRequestPDFRendition(boolean requestPDFRendition) {
    this.requestPDFRendition = requestPDFRendition;
  }
}