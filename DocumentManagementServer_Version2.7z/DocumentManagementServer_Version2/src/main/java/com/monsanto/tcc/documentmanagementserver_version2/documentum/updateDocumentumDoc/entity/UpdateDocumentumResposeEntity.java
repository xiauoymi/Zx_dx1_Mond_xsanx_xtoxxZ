package com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.AttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumAttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumResponseEntity;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jun 2, 2006 Time: 3:30:20 PM To change this template use File |
 * Settings | File Templates.
 */
public class UpdateDocumentumResposeEntity extends DocumentumResponseEntity {

  protected String getServiceSpecificNodeName() {
    return DocumentManagerConstants.TAG_UPDATE_DOCUMENT_SUCCESS_MESSAGE;
  }

  protected AttributeTransformer buildAttributeTransformer() {
    return new DocumentumAttributeTransformer();
  }
}