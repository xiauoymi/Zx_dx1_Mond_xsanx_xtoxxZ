package com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.parser;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumRequestEntity;
import org.w3c.dom.Node;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jun 2, 2006
 * Time: 3:31:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class UpdateDocumentumRequestParser extends DocumentumRequestParser {

  public void parseOperationSpecificRequest(Node requestDetailsNode, DocumentumRequestEntity documentumRequestEntity) throws DocumentManagerException {
    UpdateDocumentumRequestEntity updateDocumentumRequestEntity = (UpdateDocumentumRequestEntity)documentumRequestEntity;
    Node updateDocumentNode = DOMUtil
        .getChild(requestDetailsNode, DocumentManagerConstants.TAG_UPDATE_DOCUMENT_NODE_STR);
    Node docAttributesNode = getAttributesNode(requestDetailsNode, DocumentManagerConstants.TAG_NAME_DOCUMENT_ATTRIBUTES);
    parseAttributeList(docAttributesNode, updateDocumentumRequestEntity);
    parsePDFRendition(updateDocumentNode, updateDocumentumRequestEntity);
  }

  private Node getAttributesNode(Node requestDetailsNode, String parentNodeName) {
    Node retrieveDocumentNode = DOMUtil.getChild(requestDetailsNode, getServiceNodeNameForParsingRequest());
    return DOMUtil.getChild(retrieveDocumentNode, parentNodeName);
  }

  protected String getServiceNodeNameForParsingRequest() {
    return DocumentManagerConstants.TAG_UPDATE_DOCUMENT_NODE_STR;
  }
    private void parsePDFRendition(Node updateDocumentNode, UpdateDocumentumRequestEntity documentumRequestEntity) {
    String childValue = DOMUtil.getChildValue(updateDocumentNode, DocumentManagerConstants.TAG_PDFRENDITION_STR);
    documentumRequestEntity.setRequestPDFRendition((childValue == null || "false".equals(childValue)) ? false : true);
  }
}