package com.monsanto.tcc.documentmanagementserver_version2.exampleCode;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.POSClient.XMLPOSConnection;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jun 16, 2006
 * Time: 10:22:04 AM
 * To change this template use File | Settings | File Templates.
 */
public class TestForLargeFileRetrieval {

  private static final String POS_RETRIEVE_SERVICE_NAME = "RetrieveDocumentService";
  private static final String OBJECT_ID = "09001abe800b8f69";
  private static final String SAVE_AS_FILE_NAME = "C:/largePDF_MCN01009801BOOK.pdf";

  public static void main(String[] args) throws Exception {
    retrieveLargePDFFileAndSaveContentsToDisk();
  }

  /**
   * This is a 14mb file (MCN01009801BOOK.pdf) present in /POS Test/LargeFileTestFolder. Before running  this test
   * make sure it actually exists, if required change the objectID and please do not delete it from docBase.
   * Also please make sure to delete the largePDF_MCN01009801BOOK.pdf (local_filename) from your local system
   * @throws Exception
   */
  private static void retrieveLargePDFFileAndSaveContentsToDisk() throws Exception {
    retrieveLargeDocument(OBJECT_ID, SAVE_AS_FILE_NAME);
  }

  private static void retrieveLargeDocument(String objectId, String saveAsFileName) throws Exception {
    Document inputDocument = buildRetrieveRequestForATestLargeDocument(objectId);
    XMLPOSConnection posConn = new SecureXMLPOSConnection(new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    long timeBeforeCallToRetrieveService = System.currentTimeMillis();
    POSResult result = posConn.callService(POS_RETRIEVE_SERVICE_NAME, inputDocument);
    long timeAfterCallToRetrieveService = System.currentTimeMillis();
    System.out.println("Time taken to call the Retrieve Service: "
            + (timeAfterCallToRetrieveService - timeBeforeCallToRetrieveService) + " mSecs");
    parseContentsUsingSAXParser(result, saveAsFileName);
  }

  private static void parseContentsUsingSAXParser(POSResult result, String saveAsFileName) throws ParserConfigurationException, SAXException, IOException {
    SAXParserFactory factory = SAXParserFactory.newInstance();
    SAXParser saxParser = factory.newSAXParser();
    saxParser.parse(result.getInputStream(), new TestSAXEventHandler(saveAsFileName));
  }

  private static Document buildRetrieveRequestForATestLargeDocument(String objectId) {
    Document retrieveReqDoc = DOMUtil.newDocument();
    Node rootNode = DOMUtil.addChildElementWithNS("www.monsanto.com/pos", retrieveReqDoc, "retrieveDocumentRequest");
    DOMUtil.addChildElement(rootNode, "folder", "posTestFolder");
    DOMUtil.addChildElement(rootNode, "directoryStructure", "LargeFileTestFolder");
    Node requestDetailsNode = DOMUtil.addChildElement(rootNode, "requestDetails");
    Node retrieveDocNode = DOMUtil.addChildElement(requestDetailsNode, "retrieveDocument");
    addDocumentAttributesNode(retrieveDocNode, objectId);
    return retrieveReqDoc;
  }

  private static void addDocumentAttributesNode(Node retrieveDocNode, String objectId) {
    Node docAttrName = DOMUtil.addChildElement(retrieveDocNode, "queryAttributes");
    Node attrName = DOMUtil.addChildElement(docAttrName, "attribute");
    DOMUtil.addChildElement(attrName, "name", "objectId");
    DOMUtil.addChildElement(attrName, "value", objectId);
  }
}