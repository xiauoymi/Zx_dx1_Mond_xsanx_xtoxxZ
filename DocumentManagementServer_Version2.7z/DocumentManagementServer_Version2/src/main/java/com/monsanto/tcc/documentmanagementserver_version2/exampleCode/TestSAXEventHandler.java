package com.monsanto.tcc.documentmanagementserver_version2.exampleCode;

import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;
import org.apache.xerces.impl.dv.util.Base64;

import java.io.FileOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jun 19, 2006
 * Time: 3:25:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class TestSAXEventHandler extends DefaultHandler {

  private StringBuffer encodedStringBuffer = new StringBuffer();
  private FileOutputStream foStream = null;
  private String fileName = null;
  private Locator locator = null;

  private boolean nextNodeContainsFileContents = false;
  private boolean currentNodeContainsFileContents = false;

  private long timeBeforeParsing;

  public TestSAXEventHandler(String fileName) {
    this.fileName = fileName;
  }

  public void setDocumentLocator(Locator locator)  {
    this.locator = locator;
  }

  public void startDocument() throws SAXException {
  }

  public void endDocument() throws SAXException {
  }

  public void startElement(String namespaceURI, String localName, String qName, Attributes atts)throws SAXException{
    if (nextNodeContainsFileContents) {
      currentNodeContainsFileContents = true;
      try {
        foStream = new FileOutputStream(new File(fileName));
      } catch (FileNotFoundException e) {
        System.out.println("Filestream creation error = " + e.getMessage());
      }
      System.out.println("Writing Contents...");
      timeBeforeParsing = System.currentTimeMillis();
    }
  }

  public void characters(char[] ch, int start, int length) throws SAXException {
    StringBuffer elementValue = new StringBuffer();
    elementValue.append(ch, start, length);
    if(currentNodeContainsFileContents){
      try {
        performEncodingAndWriting(ch, start, length);
      } catch (IOException e) {
        System.out.println("Write/Encoding error: " + e.getMessage());
      }
    }
    if(elementValue.toString().equalsIgnoreCase("contents")){
      nextNodeContainsFileContents = true;
    }
  }

  private void performEncodingAndWriting(char[] ch, int start, int length) throws IOException {
    encodedStringBuffer.append(ch, start, length);
    byte decodedByte[] = Base64.decode(encodedStringBuffer.toString());
    if (decodedByte != null) {
      foStream.write(decodedByte, 0, decodedByte.length);
      foStream.flush();
      encodedStringBuffer = new StringBuffer();
    }
  }

  public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
    if (currentNodeContainsFileContents) {
      nextNodeContainsFileContents = false;
      try {
        foStream.close();
      } catch (IOException e) {
        System.out.println("Filestream error = " + e.getMessage());
      }
      long timeAfterParsing = System.currentTimeMillis();
      System.out.println("Done writing, time taken to write contents: " + (timeAfterParsing - timeBeforeParsing) + " mSecs");
    }
    currentNodeContainsFileContents = false;
  }

  public void warning(SAXParseException e) throws SAXException {
    System.err.println("Warning at locator-line-# = " + locator.getLineNumber());
  }

  public void error(SAXParseException e) throws SAXException {
    System.err.println("Error at locator-line-# = " + locator.getLineNumber());
  }

  public void fatalError(SAXParseException e) throws SAXException {
    System.err.println("Fatal Error at locator-line-# = " + locator.getLineNumber());
  }
}