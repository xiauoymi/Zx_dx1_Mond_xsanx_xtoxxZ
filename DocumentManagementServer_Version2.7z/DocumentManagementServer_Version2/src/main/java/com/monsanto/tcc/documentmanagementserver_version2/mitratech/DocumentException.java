/*
 DocumentException was created on Sep 21, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.documentmanagementserver_version2.mitratech;

/**
 * Filename:    $RCSfile: DocumentException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2006-09-22 04:34:11 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class DocumentException extends Exception{
    public DocumentException() {
        super();
    }

    public DocumentException(String message) {
        super(message);
    }

    public DocumentException(Throwable cause) {
        super(cause);
    }

    public DocumentException(String message, Throwable cause) {
        super(message, cause);
    }
}