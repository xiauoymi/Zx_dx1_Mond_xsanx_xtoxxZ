/*
 MitratechAdapterImpl was created on Sep 21, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.documentmanagementserver_version2.mitratech;

import org.w3c.dom.Document;

import javax.servlet.http.HttpSession;
import java.io.InputStream;

/**
 * Filename:    $RCSfile: MitratechAdapter.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2006-11-10 04:52:23 $
 *
 * @author vrbethi
 * @version $Revision: 1.5 $
 */
public interface MitratechAdapter {
    public static final String SYSTEM_SECURITY_PROXY = "SYSTEM_SECURITY_PROXY";

    /**
     * Method upoalds documents to Documentum
     * @param inputDocument Document containing the attributes of the files to be inserted (refer documentaion for exact details)
     * @param filePath Path of the file to be inserted
     * @param httpSession
     * @return
     * @throws DocumentException
     */ 
    InputStream upload(Document inputDocument, String filePath, HttpSession httpSession) throws DocumentException;

    /**
     * Method downloads documents from Documentum
     * @param inputDocument Document containing file requested (refer documentaion for exact details)
     * @param httpSession
     * @return
     * @throws DocumentException
     */
    InputStream download(Document inputDocument, HttpSession httpSession) throws DocumentException;

    /**
     * Method that deletes documents from Documentum
     * @param inputDocumentDelete Input document containing details of the document to be deleted (refer documentaion for exact details)
     * @param httpSession
     * @return
     * @throws DocumentException
     */
    InputStream delete(Document inputDocumentDelete, HttpSession httpSession) throws DocumentException;

     /**
     * Method updates document with the same object id in documentum
     * @param inputUpdateDocument Document containing the attributes of the files to be update (refer documentaion for exact details)
     * @param filePath Path of the file to be updated
     * @param httpSession
     * @return
     * @throws DocumentException
     */
    InputStream update(Document inputUpdateDocument,String filePath,HttpSession httpSession)throws DocumentException;
}