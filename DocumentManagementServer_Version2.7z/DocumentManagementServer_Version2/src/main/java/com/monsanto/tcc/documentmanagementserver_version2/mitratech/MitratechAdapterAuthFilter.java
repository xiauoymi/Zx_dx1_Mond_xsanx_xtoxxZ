/*
 MonsantoAuthFilter was created on Dec 12, 2005 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.documentmanagementserver_version2.mitratech;

import com.monsanto.KerberosServletSecurity.KerberosSecurity;
import com.monsanto.servletsecurity.ServletSystemSecurityProxy;
import com.monsanto.securityinterfaces.SystemSecurityProxy;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Filename:    $RCSfile: MitratechAdapterAuthFilter.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2006-11-09 22:43:49 $
 *
 * @author SRKARNA
 * @version $Revision: 1.2 $
 */
public class MitratechAdapterAuthFilter implements Filter {

  public MitratechAdapterAuthFilter(){
    super();
  }

    public void init(FilterConfig filterConfig) throws ServletException {
    }

    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        SystemSecurityProxy kerberosSecurity = createSystemSecurityProxy(servletRequest);
        System.out.println("Created system security proxy.");
        ((HttpServletRequest)servletRequest).getSession().
                setAttribute(MitratechAdapter.SYSTEM_SECURITY_PROXY,kerberosSecurity);
        System.out.println("Added system security proxy to session.");
        filterChain.doFilter(servletRequest, servletResponse);
    }

    protected SystemSecurityProxy createSystemSecurityProxy(ServletRequest servletRequest) {
        ServletSystemSecurityProxy kerberosSecurity = new KerberosSecurity();
        kerberosSecurity.init((HttpServletRequest) servletRequest);
        return kerberosSecurity;
    }

    public void destroy() {
    }
}

/*
* Revision Log
* $Log: not supported by cvs2svn $
* Revision 1.1  2006/09/22 19:10:16  vrbethi
* Added classes for mitratech
*
* Revision 1.3  2006/01/14 07:09:13  mecoru
* Handle idm.ad.site parameter
*
* Revision 1.2  2005/12/16 06:01:11  srkarna
* added idm.realm to read either from -D param, or from web.xml
*
* Revision 1.1  2005/12/14 17:01:12  srkarna
* Added MonsantoAuthFilter to KerberosSecurity project
* to read idm.princ and idm.keytab from external sources
*
* Revision 1.1  2005/12/13 06:18:19  srkarna
* experimental AuthFilter to read init-params from external sources
*
*/