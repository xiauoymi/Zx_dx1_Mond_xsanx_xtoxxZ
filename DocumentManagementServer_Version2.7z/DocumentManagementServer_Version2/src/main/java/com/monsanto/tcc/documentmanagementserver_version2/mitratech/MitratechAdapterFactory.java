/*
 MitratechAdapterFactory was created on Sep 28, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.documentmanagementserver_version2.mitratech;

import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.tcc.documentmanagementserver_version2.Servlet.DocumentManagementServer_Version2LoggerFactory;

import java.io.IOException;

/**
 * Filename:    $RCSfile: MitratechAdapterFactory.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2006-09-28 22:41:00 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class MitratechAdapterFactory {
  public static MitratechAdapter getMitratechAdapter() {
    initializeLogging();
    return new MitratechAdapterImpl();
  }

  private static void initializeLogging() {
    try {
       DocumentManagementServer_Version2LoggerFactory loggerFactory = new DocumentManagementServer_Version2LoggerFactory();
       loggerFactory.setupLogging();
    }
    catch (LogRegistrationException lre) {
      System.out.println(lre);
    }
    catch (IOException ioe) {
      System.out.println(ioe);
    }
  }
}