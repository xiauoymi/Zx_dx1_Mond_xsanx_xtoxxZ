/*
MitratechAdapter was created on Sep 7, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.documentmanagementserver_version2.mitratech;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.FatalEvent;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;

import javax.servlet.http.HttpSession;
import java.io.InputStream;

/**
 * Filename:    $RCSfile: MitratechAdapterImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2006-11-20 16:42:52 $
 *
 * @author vrbethi
 * @version $Revision: 1.7 $
 */
public class MitratechAdapterImpl implements MitratechAdapter {


    public InputStream upload(Document inputDocument, String filePath, HttpSession httpSession) throws DocumentException {
        MultipartAttachmentList multipartAttachmentList = new MultipartAttachmentList();
        MultiPartFormAttachment multiPartFormAttachment = null;
        POSResult result=null;
        try {
            multiPartFormAttachment = new MultiPartFormAttachment(filePath,POSMIMEConstants.MIME_TYPE_TEXT);
            multipartAttachmentList.addAttachment(multiPartFormAttachment);
            SecureXMLPOSConnection posConn = new SecureXMLPOSConnection
                (new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), getSystemSecurityProxyFromSession(httpSession));
            posConn.addAttachment(multiPartFormAttachment);
            result = posConn.callService("InsertDocumentService", inputDocument);
        } catch (InvalidMimeTypeException e) {
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Invalid Mime Type",e);
        } catch (POSCommunicationException e) {
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Communication Exception",e);
        } catch (POSException e) {
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Error during insertion of Document",e);
        }catch(Exception e){
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Unhandled Exception during insertion of Document",e);
        }
        return result.getInputStream();
    }

    public InputStream download(Document inputDocument, HttpSession httpSession) throws DocumentException {
        SecureXMLPOSConnection posConn = null;
        POSResult result=null;
        try {
            posConn = new SecureXMLPOSConnection(new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()),
                getSystemSecurityProxyFromSession(httpSession));
            result = posConn.callService("RetrieveDocumentService", inputDocument);
        } catch (POSCommunicationException e) {
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Error during retrievel of Document",e);
        } catch (POSException e) {
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Error during retrievel of Document",e);
        }catch(Exception e){
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Error during retrievel of Document",e);
        }
        return result.getInputStream();
    }

    public InputStream delete(Document inputDocumentDelete, HttpSession httpSession) throws DocumentException {
        SecureXMLPOSConnection posConn = null;
        POSResult posResult=null;
        try {
            posConn = new SecureXMLPOSConnection(new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()),
                getSystemSecurityProxyFromSession(httpSession));
            posResult = posConn.callService("DeleteDocumentService", inputDocumentDelete);
        } catch (POSCommunicationException e) {
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Error during deletion of Document",e);
        } catch (POSException e) {
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Error during deletion of Document",e);
        }catch (Exception e){
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Error during deletion of Document",e);
        }
        return posResult.getInputStream();
    }

    public InputStream update(Document inputUpdateDocument, String filePath, HttpSession httpSession) throws DocumentException {
        MultipartAttachmentList multipartAttachmentList = new MultipartAttachmentList();
        MultiPartFormAttachment multiPartFormAttachment = null;
        POSResult result=null;
        try {
            multiPartFormAttachment = new MultiPartFormAttachment(filePath,POSMIMEConstants.MIME_TYPE_TEXT);
            multipartAttachmentList.addAttachment(multiPartFormAttachment);
            SecureXMLPOSConnection posConn = new SecureXMLPOSConnection
                (new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), getSystemSecurityProxyFromSession(httpSession));
            posConn.addAttachment(multiPartFormAttachment);
            DOMUtil.outputXML(inputUpdateDocument);
            result = posConn.callService("UpdateDocumentService", inputUpdateDocument);
        } catch (InvalidMimeTypeException e) {
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Invalid Mime Type",e);
        } catch (POSCommunicationException e) {
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Communication Exception",e);
        } catch (POSException e) {
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Error during insertion of Document",e);
        }catch(Exception e){
            Logger.log(new FatalEvent(e));
            throw new DocumentException("Unhandled Exception during insertion of Document",e);
        }
        return result.getInputStream();
    }

    private SystemSecurityProxy getSystemSecurityProxyFromSession(HttpSession httpSession) {
        return (SystemSecurityProxy) httpSession.getAttribute(MitratechAdapter.SYSTEM_SECURITY_PROXY);
    }

}