package com.monsanto.tcc.documentmanagementserver_version2.testController;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.ServletFramework.UCCHelper;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Feb 22, 2006
 * Time: 10:55:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class DocManager2TestController implements UseCaseController {

    public void run(UCCHelper helper) throws IOException {
        helper.forward("/jsp/testJsp.jsp");
    }
}
