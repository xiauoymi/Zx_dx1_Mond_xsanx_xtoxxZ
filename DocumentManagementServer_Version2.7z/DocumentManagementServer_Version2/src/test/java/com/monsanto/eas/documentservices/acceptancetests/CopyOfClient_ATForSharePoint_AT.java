/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.documentservices.acceptancetests;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.Util.FileUtil;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import org.apache.abdera.model.DateTime;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.xerces.impl.dv.util.Base64;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.transform.TransformerException;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;
import java.util.regex.Pattern;

//This is suitable to run against dev to test the
/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Mar 1, 2006 Time: 1:04:11 PM To change this template use File |
 * Settings | File Templates.
 */
public class CopyOfClient_ATForSharePoint_AT extends XMLTestCase {
  private static final String POS_INSERT_SERVICE_NAME = "InsertDocumentService";
  private static final String INSERT_REQUEST_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/insertReq_AppClient_AT.xml";
  private static final String SEARCH_REQUEST_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/searchReq_AppClient_AT.xml";
  //	private static final String SEARCH_REQUEST_TECH_TEXT_FILE_AT = "com/monsanto/tcc/documentmanagementserver_version2/apptests/searchReq_TechDoc_AT.xml";
  //private static final String TEST_TEXT_FILE_1 = "com/monsanto/eas/documentservices/acceptancetests/testFile1.txt";
  //private static final String TEST_TEXT_FILE_1 = "com/monsanto/eas/documentservices/acceptancetests/2011-1343PRdispositionTableCbi.xlsx";
  //private static final String TEST_LARGE_TEXT_FILE_1 = "com/monsanto/eas/documentservices/acceptancetests/testLargeFile3.txt";
  private static final String TEST_TEXT_FILE_3 = "com/monsanto/eas/documentservices/acceptancetests/testFile3.txt";
  //private static final String TEST_TEXT_FILE_3 = "com/monsanto/eas/documentservices/acceptancetests/testFile3.txt";
  //private static final String TEST_TEXT_FILE_3 = "com/monsanto/eas/documentservices/acceptancetests/2010-1595PRAB-Full pkt.pdf";
    //private static final String TEST_TEXT_FILE_3 = "com/monsanto/eas/documentservices/acceptancetests/testLargeFinal.txt";
    //private static final String TEST_TEXT_FILE_3 = "com/monsanto/eas/documentservices/acceptancetests/testLargeFinal2.txt";
    //private static final String TEST_TEXT_FILE_3 = "com/monsanto/eas/documentservices/acceptancetests/10MB.docx";

  private static final String POS_DELETE_SERVICE_NAME = "DeleteDocumentService";
  private static final String POS_SEARCH_SERVICE = "SearchDocumentsService";
  private static final String POS_UPDATE_SERVICE = "UpdateDocumentService";    
  private static final String POS_RETRIEVE_SERVICE = "RetrieveDocumentService";

    private static final String FILIP_TEST_INSERT_REQUEST_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/FilipTest_insertReq_AppClient_AT.xml";
    private static final String FILIP_TEST_SEARCH_REQUEST_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/FilipTest_searchReq_AppClient_AT.xml";
    private static final String FILIP_TEST_SEARCH_REQUEST_OTHER_ATTRIBUTES_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/FilipTest_searchReq_OtherAttributes_AppClient_AT.xml";
    private static final String FILIP_TEST_RETRIEVE_REQUEST_XML = "com/monsanto/eas/documentservices/acceptancetests/FilipTest_retrieveRequest.xml";
    private static final String FILIP_TEST_UPDATE_REQUEST_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/FilipTest_updateRequest_AT.xml";



  //TPS data setup
  private static final String TPS_INSERT_REQUEST_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/TPS_insertReq_AppClient_AT.xml";
  private static final String TPS_SEARCH_REQUEST_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/TPS_searchReq_AppClient_AT.xml";
  private static final String TPS_SEARCH_REQUEST_TEXT_FILE_AT_2 = "com/monsanto/eas/documentservices/acceptancetests/TPS_searchReq_AppClient_AT_2.xml";
  private static final String TPS_UPDATE_REQUEST_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/TPS_updateRequest.xml";

  public static String TPS_INS_OBJECT_ID=null;



  public void testNothing() throws Exception {
    assertTrue(true);
  }
       //ToDo: all X-tested out to make build work for now

    //All TPS test cases
    public void test_TPS_Insert_Service_TC() throws Exception {
         TPS_testInsert_Service();
    }
    public void test_TPS_Delete_Service_TC() throws Exception {
        TPS_INS_OBJECT_ID = "5ae1ffe7-7b4c-4e3d-9c3d-8c882a20031e";
        TPS_testDelete_Service();
    }
    public void test_TPS_RetrieveExistingDocs_TC() throws Exception {
          retrieveExistingDocByName();
    }
    public void test_TPS_InsertAndDelete_Services_TC() throws Exception {
        TPS_testInsert_Service();
        TPS_testDelete_Service();
    }
    public void test_TPS_SearchExistingDocsByName_TC() throws Exception {
         TPS_testSearchExistingDocsByName();
    }
    public void test_TPS_SearchExistingDocsByOtherAttr_TC() throws Exception {
         TPS_testSearchExistingDocsByOtherAttr();
    }
    public void test_TPS_UpdateExistingDocs_TC() throws Exception {
          TPS_testUpdateExistingDocs();
    }

  public void TPS_testUpdateExistingDocs() throws Exception {
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    posConn.addAttachment(
        new MultiPartFormAttachment(CopyOfClient_ATForSharePoint_AT.TEST_TEXT_FILE_3, POSMIMEConstants.MIME_TYPE_TEXT));
    POSResult posResult = posConn.callService(CopyOfClient_ATForSharePoint_AT.POS_UPDATE_SERVICE,
        DOMUtil.newDocument(FILIP_TEST_UPDATE_REQUEST_TEXT_FILE_AT));
    Document outputDocument = DOMUtil.newDocument(posResult.getInputStream());
    System.out.println("begin outputDocument.CopyOfClient_ATForSharePoint_AT.TPS_testUpdateExistingDocs");
    DOMUtil.outputXML(outputDocument);
    System.out.println("end outputDocument.CopyOfClient_ATForSharePoint_AT.TPS_testUpdateExistingDocs");
    String objectId = XPathAPI
        .eval(outputDocument, "/documentManagerResponse/insertDocument/documentDetails/attribute/value").toString();
    assertNotNull(objectId);
    }
 public void TPS_testInsert_Service() throws Exception {
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());

     posConn.addAttachment(
        new MultiPartFormAttachment(CopyOfClient_ATForSharePoint_AT.TEST_TEXT_FILE_3, POSMIMEConstants.MIME_TYPE_TEXT));

     POSResult posResult = posConn.callService(CopyOfClient_ATForSharePoint_AT.POS_INSERT_SERVICE_NAME,
        DOMUtil.newDocument(FILIP_TEST_INSERT_REQUEST_TEXT_FILE_AT));

    Document outputDocument = DOMUtil.newDocument(posResult.getInputStream());
    System.out.println("begin outputDocument.CopyOfClient_ATForSharePoint_AT.TPS_testInsert_Service");
    DOMUtil.outputXML(outputDocument);
    System.out.println("end outputDocument.CopyOfClient_ATForSharePoint_AT.TPS_testInsert_Service");
    String objectId = XPathAPI
        .eval(outputDocument, "/documentManagerResponse/insertDocument/documentDetails/attribute/value").toString();
    assertNotNull(objectId);
     TPS_INS_OBJECT_ID =  objectId;

     //byte[] stream = FileUtil.fileToByteArray(CopyOfClient_ATForSharePoint_AT.TEST_TEXT_FILE_3);
     //System.out.println(stream.length);
     //String filename = CopyOfClient_ATForSharePoint_AT.TEST_TEXT_FILE_3;
     //byte[] stream = readFileInChunks(filename);
     //System.out.println(stream.length);
    }

    private byte[] readFileInChunks(String filename) throws IOException {
        ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
        FileInputStream inputStream = new FileInputStream(filename);
        byte[] stream = null;
        try{
            int byteStreamLength = 8192;
            int bytesRead = 0;
            byte [] bytearray = new byte[byteStreamLength];
            while ((bytesRead = inputStream.read(bytearray, 0, byteStreamLength)) > -1) {
                byteArray.write(bytearray, 0, bytesRead);
            }
            stream = byteArray.toByteArray();
        }catch (Exception ex){
            System.out.println(ex.getMessage() + ex.getStackTrace());
            throw new IOException(ex.getMessage());
        }finally {
            byteArray.close();
            inputStream.close();
        }
        return stream;
    }

    public void TPS_testDelete_Service() throws Exception {
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    posConn.addAttachment(
        new MultiPartFormAttachment(CopyOfClient_ATForSharePoint_AT.TEST_TEXT_FILE_3, POSMIMEConstants.MIME_TYPE_TEXT));
    
    Document inputDocumentDelete = TPS_createTestDeleteRequestXML(TPS_INS_OBJECT_ID);
    DOMUtil.outputXML(inputDocumentDelete);
    POSResult posResultDelete = posConn
        .callService(CopyOfClient_ATForSharePoint_AT.POS_DELETE_SERVICE_NAME, inputDocumentDelete);
    Document outputDeleteDocument = DOMUtil.newDocument(posResultDelete.getInputStream());
    System.out.println("begin outputDocumentafter delete.CopyOfClient_ATForSharePoint_AT.TPS_testDelete_Service");
    DOMUtil.outputXML(outputDeleteDocument);
    System.out.println("end outputDocumentafter delete.CopyOfClient_ATForSharePoint_AT.TPS_testDelete_Service");
    String deletedDocumentObjectId = XPathAPI.eval(outputDeleteDocument,
        "/documentManagerResponse/documentDeletedSuccessfully/documentDetails/attribute/value").toString();
    assertNotNull(deletedDocumentObjectId);
     TPS_INS_OBJECT_ID=null;
    }

  public void TPS_testSearchExistingDocsByOtherAttr() throws Exception {
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    POSResult posResult = posConn.callService(CopyOfClient_ATForSharePoint_AT.POS_SEARCH_SERVICE,
        DOMUtil.newDocument(FILIP_TEST_SEARCH_REQUEST_OTHER_ATTRIBUTES_TEXT_FILE_AT));
    Document outputDocument = DOMUtil.newDocument(posResult.getInputStream());
    System.out.println("begin outputDocument.CopyOfClient_ATForSharePoint_AT.TPS_testSearchExistingDocsByOtherAttr");
    DOMUtil.outputXML(outputDocument);
    System.out.println("end outputDocument.CopyOfClient_ATForSharePoint_AT.TPS_testSearchExistingDocsByOtherAttr");
    String objectId = XPathAPI
        .eval(outputDocument,
            "/documentManagerResponse/searchDocuments/documentDetails/attribute[name=\"objectId\"]/value").toString();
    assertNotNull(objectId);
    System.out.println("objectId = \"" + objectId + "\"");
    assertTrue("object id should contain something", objectId.length() > 0);
  }

  public void TPS_testSearchExistingDocsByName() throws Exception {
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    POSResult posResult = posConn.callService(CopyOfClient_ATForSharePoint_AT.POS_SEARCH_SERVICE,
        DOMUtil.newDocument(FILIP_TEST_SEARCH_REQUEST_TEXT_FILE_AT));
    Document outputDocument = DOMUtil.newDocument(posResult.getInputStream());
    System.out.println("begin outputDocument.CopyOfClient_ATForSharePoint_AT.TPS_testSearchExistingDocsByOtherAttr");
    DOMUtil.outputXML(outputDocument);
    System.out.println("end outputDocument.CopyOfClient_ATForSharePoint_AT.TPS_testSearchExistingDocsByOtherAttr");
    String objectId = XPathAPI
        .eval(outputDocument,
            "/documentManagerResponse/searchDocuments/documentDetails/attribute[name=\"objectId\"]/value").toString();
    assertNotNull(objectId);
    System.out.println("objectId = \"" + objectId + "\"");
    assertTrue("object id should contain something", objectId.length() > 0);
  }
   private Document TPS_createTestDeleteRequestXML(String objectId) throws ParserException, TransformerException {
    Document deleteRequestDoc = DOMUtil
        .newDocument("com/monsanto/eas/documentservices/acceptancetests/FilipTest_deleteRequest.xml");
    Node objectIdValueNode = XPathAPI
        .eval(deleteRequestDoc, "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    System.out.println("objectId = " + objectId);
    DOMUtil.outputXML(deleteRequestDoc);
    return deleteRequestDoc;
  }

// Added by ffbrac
    private void retrieveExistingDocByName() throws Exception {
        String outputFileName = "c:/myfiles/testFile3-filip.txt";
        String outputFileName2 = "c:/myfiles/testFile3-filip2.txt";


        InputStream inputStream = GetStreams();

        System.out.println("writing file to disk: ");
        FileOutputStream file = new FileOutputStream(outputFileName);
        //new sun.misc.BASE64Decoder().decodeBuffer(inputStream, file);
        try{
            int byteStreamLength = 1024;
            int bytesRead = 0;
            byte [] bytearray = new byte[byteStreamLength];
            System.out.println("bytes available: " + inputStream.available());
            while ((bytesRead = inputStream.read(bytearray, 0, byteStreamLength)) > -1) {
                System.out.println("bytes read: " + bytesRead);
                file.write(bytearray, 0, bytesRead);
            }
            System.out.println("Exit While bytes read: " + bytesRead);
        }catch (Exception ex){
            System.out.println(ex.getMessage() + ex.getStackTrace());
        }finally {
            file.flush();
            file.close();
            inputStream.close();
        }

    }

    private InputStream GetStreams() throws GSSException, ParserException, TransformerException, POSException, POSCommunicationException {
        SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
            new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
        Document retrieveRequestInput = DOMUtil.newDocument(FILIP_TEST_RETRIEVE_REQUEST_XML);
        System.out.println("begin retrieveRequestInput.SharePointInsertRetrieveDoc_AT.testRetrieveExistingDocByName");
        System.out.println("*****Following is the Retrieve Request XML*****");
        System.out.println("*****Retrieve Request XML Ends*****");
        Node objectIdValueNode = XPathAPI.selectSingleNode(retrieveRequestInput,
            "/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute[name='objectId']/value");
        String objectIdRequested = objectIdValueNode.getChildNodes().item(0).getNodeValue();
        POSResult retrieveResult = posConn.callService(POS_RETRIEVE_SERVICE, retrieveRequestInput);
        InputStream inputStream = retrieveResult.getInputStream();
        return inputStream;
    }

    private void saveAsXMLFile(Document deleteRequestDoc, String deleteRequestFilenamePath) throws
          IOException {
        FileOutputStream file = new FileOutputStream(new File(deleteRequestFilenamePath));
        DOMUtil.outputXML(deleteRequestDoc, file);
        file.close();
      }
}