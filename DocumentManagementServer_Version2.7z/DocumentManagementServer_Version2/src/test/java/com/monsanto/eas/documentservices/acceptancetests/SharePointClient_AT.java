/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.documentservices.acceptancetests;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.MultiPartFormAttachment;
import com.monsanto.POSClient.POSMIMEConstants;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockXMLPOSConnectionForInsert;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;

//Please Note: to run sucessfully, the real ServiceConfig.xml these tests will use needs a folderID of posTestFolder-SP defined
/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Mar 1, 2006 Time: 1:04:11 PM To change this template use File |
 * Settings | File Templates.
 */
public class SharePointClient_AT extends XMLTestCase {
  private static final String POS_INSERT_SERVICE_NAME = "InsertDocumentService";
  private static final String INSERT_REQUEST_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/insertReq_AppClient_AT.xml";
  private static final String SEARCH_REQUEST_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/searchReq_AppClient_AT.xml";
  private static final String SEARCH_REQUEST_TECH_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/searchReq_TechDoc_AT.xml";
  private static final String TEST_TEXT_FILE_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private static final String POS_DELETE_SERVICE_NAME = "DeleteDocumentService";
  private static final String POS_SEARCH_SERVICE = "SearchDocumentsService";
  private static final String INSERT_REQUEST_TEXT_FILE_AT_BASIC = "com/monsanto/eas/documentservices/acceptancetests/insertReq_AppClient_AT_basic.xml";

  public void testNothing() throws Exception {
    assertTrue(true);
  }

  //ToDo: All X'd out for now - till later release in July
  public void testUpload_Retrieve_Delete_And_Update_Services() throws Exception {
    SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    posConn.addAttachment(
        new MultiPartFormAttachment(TEST_TEXT_FILE_1, POSMIMEConstants.MIME_TYPE_TEXT));
    POSResult posResult = posConn
        .callService(POS_INSERT_SERVICE_NAME, DOMUtil.newDocument(INSERT_REQUEST_TEXT_FILE_AT));
    Document outputDocument = DOMUtil.newDocument(posResult.getInputStream());
    DOMUtil.outputXML(outputDocument);
    String objectId = XPathAPI
        .eval(outputDocument, "/documentManagerResponse/insertDocument/documentDetails/attribute/value").toString();
    assertNotNull(objectId);
    Document inputDocumentDelete = createTestDeleteRequestXML(objectId);
    POSResult posResultDelete = posConn.callService(POS_DELETE_SERVICE_NAME, inputDocumentDelete);
    Document outputDeleteDocument = DOMUtil.newDocument(posResultDelete.getInputStream());
    DOMUtil.outputXML(outputDeleteDocument);
    String deletedDocumentObjectId = XPathAPI.eval(outputDeleteDocument,
        "/documentManagerResponse/documentDeletedSuccessfully/documentDetails/attribute/value").toString();
    assertNotNull(deletedDocumentObjectId);
  }

  public void testUpload_Retrieve_Delete_And_Update_Services_basic() throws Exception {
    SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    posConn.addAttachment(
        new MultiPartFormAttachment(TEST_TEXT_FILE_1, POSMIMEConstants.MIME_TYPE_TEXT));
    POSResult posResult = posConn
        .callService(POS_INSERT_SERVICE_NAME, DOMUtil.newDocument(INSERT_REQUEST_TEXT_FILE_AT_BASIC));
    Document outputDocument = DOMUtil.newDocument(posResult.getInputStream());
    DOMUtil.outputXML(outputDocument);
    String objectId = XPathAPI
        .eval(outputDocument, "/documentManagerResponse/insertDocument/documentDetails/attribute/value").toString();
    assertNotNull(objectId);
    Document inputDocumentDelete = createTestDeleteRequestXMLBasic(objectId);
    POSResult posResultDelete = posConn.callService(POS_DELETE_SERVICE_NAME, inputDocumentDelete);
    Document outputDeleteDocument = DOMUtil.newDocument(posResultDelete.getInputStream());
    DOMUtil.outputXML(outputDeleteDocument);
    String deletedDocumentObjectId = XPathAPI.eval(outputDeleteDocument,
        "/documentManagerResponse/documentDeletedSuccessfully/documentDetails/attribute/value").toString();
    assertNotNull(deletedDocumentObjectId);
  }

  private Document createTestDeleteRequestXMLBasic(String objectId) throws ParserException, TransformerException {
    Document deleteRequestDoc = DOMUtil
        .newDocument("com/monsanto/eas/documentservices/acceptancetests/deleteRequest_basic.xml");
    Node objectIdValueNode = XPathAPI
        .eval(deleteRequestDoc, "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    return deleteRequestDoc;
  }

  public void XtestSearchExistingDocs() throws Exception {
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    POSResult posResult = posConn
        .callService(POS_SEARCH_SERVICE, DOMUtil.newDocument(SEARCH_REQUEST_TEXT_FILE_AT));
    Document outputDocument = DOMUtil.newDocument(posResult.getInputStream());
    DOMUtil.outputXML(outputDocument);
    String objectId = XPathAPI
        .eval(outputDocument, "/documentManagerResponse/insertDocument/documentDetails/attribute/value").toString();
    assertNotNull(objectId);
  }

  public void XtestSearchExistingTechDocs() throws Exception {
    System.setProperty("lsi.function", "prod");
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    POSResult posResult = posConn
        .callService(POS_SEARCH_SERVICE, DOMUtil.newDocument(SEARCH_REQUEST_TECH_TEXT_FILE_AT));
    Document outputDocument = DOMUtil.newDocument(posResult.getInputStream());
    DOMUtil.outputXML(outputDocument);
    String objectId = XPathAPI
        .eval(outputDocument, "/documentManagerResponse/insertDocument/documentDetails/attribute/value").toString();
    assertNotNull(objectId);
  }

  private Document createTestDeleteRequestXML(String objectId) throws ParserException, TransformerException {
    Document deleteRequestDoc = DOMUtil
        .newDocument("com/monsanto/eas/documentservices/acceptancetests/deleteRequest.xml");
    Node objectIdValueNode = XPathAPI
        .eval(deleteRequestDoc, "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    return deleteRequestDoc;
  }

}