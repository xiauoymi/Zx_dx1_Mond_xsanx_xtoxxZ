package com.monsanto.eas.documentservices.acceptancetests;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockXMLPOSConnectionForInsert;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.SharePointTestUtil;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

//Please Note: to run sucessfully, the real ServiceConfig.xml these tests will use needs a folderID of posTestFolder-SP defined
/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 16, 2006 Time: 9:50:05 AM To change this template use File |
 * Settings | File Templates.
 */
public class SharePointDeleteService_AT extends XMLTestCase {
  private static final String DELETE_REQUEST_TEMPLATE = "com/monsanto/eas/documentservices/acceptancetests/deleteRequest.xml";
  private static final String ATTACHMENT_1 = "com/monsanto/eas/documentservices/acceptancetests/testFile1.txt";
  private static final String INSERT_XML_1 = "com/monsanto/eas/documentservices/acceptancetests/insertReq1.xml";
  private static final String DELETE_REQUEST_XML = "C:/deleteRequestDoc.xml";
  private static final String DELETE_REQUEST_WITH_VERSION_1_TEMPLATE = "com/monsanto/eas/documentservices/acceptancetests/deleteRequestWithVersion1.xml";
  private static final String DELETE_REQUEST_WITH_VERSION_2_TEMPLATE = "com/monsanto/eas/documentservices/acceptancetests/deleteRequestWithVersion2.xml";
  private static final String XPATH_BEGIN_STR = "/documentManagerResponse/documentDeletedSuccessfully/documentDetails/attribute[name = '";
  private static final String XPATH_END_STR = "']/value";
//  private static final String POS_INSERT_SERVICE_NAME = "InsertDocumentService";
  private static final String POS_DELETE_SERVICE_NAME = "DeleteDocumentService";
  private static final String UPDATED_CONTENTS = "com/monsanto/eas/documentservices/acceptancetests/test.doc";
  private static final String UPDATE_REQUEST_TEMPLATE = "com/monsanto/eas/documentservices/acceptancetests/updateRequest.xml";
  private String objectId1;

  protected void setUp() throws Exception {
		objectId1 = SharePointTestUtil.insertTestDocument(ATTACHMENT_1, INSERT_XML_1);
		System.out.println("SharePointDeleteService_AT.setUp: objectId1 = " + objectId1);
		String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document updateReq = SharePointTestUtil.transformRequestXML(UPDATE_REQUEST_TEMPLATE, objectId1, updateTransformationXPathString, 0);
    SharePointTestUtil.updateDocument(UPDATED_CONTENTS, updateReq, DocumentManagerConstants.WORD_DOC_FILETYPE);
  }

  protected void tearDown() throws Exception {
    deleteTemporaryXMLDocument();
		try {
			SharePointTestUtil.deleteAllVersionsOfInsertedDocument(objectId1);
		} catch (Exception e) {
			//Ignore
		}
	}

  public void testDelete_WithoutVersionSpecification_DeletesAllVersions() throws Exception {
    deleteWithVersioning(DELETE_REQUEST_TEMPLATE, DocumentManagerConstants.RESP_CONST_ALL_VERSIONS_DELETED);
  }

  public void testDelete_WithVersion_DeletesSpecificVersion() throws Exception {
    deleteWithVersioning(DELETE_REQUEST_WITH_VERSION_1_TEMPLATE, "1.0");
    deleteWithVersioning(DELETE_REQUEST_WITH_VERSION_2_TEMPLATE, "0.1");
  }

  private void deleteWithVersioning(String deleteRequestTemplate, String versionsDeleted) throws ParserException,
      TransformerException, GSSException, POSException, POSCommunicationException, IOException, SAXException {
		createTestDeleteRequestXML(DELETE_REQUEST_XML, objectId1, deleteRequestTemplate);
		Document inputDoc = DOMUtil.newDocument(DELETE_REQUEST_XML);
		//ToDo: Runs against War file running in local Tomcat (based on the mock - MockXMLPOSConnectionForInsert)
		SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    POSResult result = posConn.callService(POS_DELETE_SERVICE_NAME, inputDoc);
    Document deleteResponseDoc = DOMUtil.newDocument(result.getInputStream());
    validateResponse(deleteResponseDoc, objectId1, versionsDeleted);
  }

  private void deleteTemporaryXMLDocument() {
    new File(DELETE_REQUEST_XML).delete();
  }

  private void createTestDeleteRequestXML(String deleteRequestFilenamePath, String objectId,
                                          String deleteRequestTemplate) throws FileNotFoundException, ParserException,
      TransformerException {
    Document deleteRequestDoc = DOMUtil.newDocument(deleteRequestTemplate);
    Node objectIdValueNode = XPathAPI
        .eval(deleteRequestDoc, "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    saveAsXMLFile(deleteRequestDoc, deleteRequestFilenamePath);
  }

  private void saveAsXMLFile(Document deleteRequestDoc, String deleteRequestFilenamePath) throws FileNotFoundException {
    DOMUtil.outputXML(deleteRequestDoc, new FileOutputStream(new File(deleteRequestFilenamePath)));
  }

  private void validateResponse(Document deleteReponseDoc, String deletedObjectId, String versionsDeleted) throws
      TransformerException {
    assertXpathEvaluatesTo(deletedObjectId,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR,
        deleteReponseDoc);
    assertXpathEvaluatesTo(versionsDeleted, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_VERSION + XPATH_END_STR,
        deleteReponseDoc);
  }
}