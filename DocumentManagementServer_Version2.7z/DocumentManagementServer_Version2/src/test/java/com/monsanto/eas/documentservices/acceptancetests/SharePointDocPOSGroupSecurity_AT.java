package com.monsanto.eas.documentservices.acceptancetests;
//Please Note: to run sucessfully, the real ServiceConfig.xml these tests will use needs a folder IDs of posTestFolder-SP,securedTestFolderNotAccessibleToTestRoles-SP, and securedTestFolderAccessibleToAllDomainUsers-SP  defined; see the comments in the below request xml files for details on how those folder IDs should be defined

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockXMLPOSConnectionForRetrieve;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 18, 2006 Time: 2:43:42 PM To change this template use File |
 * Settings | File Templates.
 */
public class SharePointDocPOSGroupSecurity_AT extends XMLTestCase {
  private static final String POS_SEARCH_SERVICE_NAME = "SearchDocumentsService";
  private static final String SEARCH_REQUEST_TO_AUTHORIZED_SECURED_FOLDER = "com/monsanto/eas/documentservices/acceptancetests/searchRequest.xml";
  private static final String SEARCH_REQUEST_TO_NON_AUTHORIZED_SECURED_FOLDER = "com/monsanto/eas/documentservices/acceptancetests/searchRequestToNonAuthorizedSecuredFolder.xml";

  public void testSearchFunctionalityRequestTo_Authorized_SecuredFolder_Passes() throws Exception {
    Document searchResponseDoc = searchUsingSecuredClientConnection(SEARCH_REQUEST_TO_AUTHORIZED_SECURED_FOLDER);
    validateSearchResponse(searchResponseDoc);
  }

  public void testSearchFunctionalityRequestTo_NonAuthorized_SecuredFolder_Fails() throws Exception {
    try {
      searchUsingSecuredClientConnection(SEARCH_REQUEST_TO_NON_AUTHORIZED_SECURED_FOLDER);
      fail("Non Authorized Client was able to access the location");
    } catch (Exception e) {
			System.out.println("Expected path: reqd error msg = " + e.getMessage());
    }
  }

  private void validateSearchResponse(Document responseDoc) throws TransformerException {
    assertXpathExists("/documentManagerResponse/searchDocuments", responseDoc);
  }

  private Document searchUsingSecuredClientConnection(String requestXmlDocument) throws IOException, SAXException,
      POSCommunicationException, POSException, ParserException, GSSException {
    Document inputDoc = DOMUtil.newDocument(requestXmlDocument);
    SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForRetrieve(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    POSResult result = posConn.callService(POS_SEARCH_SERVICE_NAME, inputDoc);
    return DOMUtil.newDocument(result.getInputStream());
  }
}