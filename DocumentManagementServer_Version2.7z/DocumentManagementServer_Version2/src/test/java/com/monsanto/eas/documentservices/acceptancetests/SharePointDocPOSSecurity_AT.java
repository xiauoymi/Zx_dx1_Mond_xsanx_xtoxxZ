package com.monsanto.eas.documentservices.acceptancetests;
//Please Note: to run sucessfully, the real ServiceConfig.xml these tests will use needs a folderID of posTestFolder-SP defined

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockXMLPOSConnectionForRetrieve;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 17, 2006 Time: 4:52:14 PM To change this template use File |
 * Settings | File Templates.
 */
public class SharePointDocPOSSecurity_AT extends XMLTestCase {
  private static final String POS_SEARCH_SERVICE_NAME = "SearchDocumentsService";
  private static final String SEARCH_REQUEST_XML = "com/monsanto/eas/documentservices/acceptancetests/searchRequest.xml";

  public void testSearchFunctionalityWithoutSecureClientConnection_Fails() throws Exception {
    try {
      searchUsingUnsecuredClientConnection(SEARCH_REQUEST_XML);
      fail("Unsecured Client was able to access the server");
    } catch (Exception e) {
      //expected path
    }
  }

  public void testSearchFunctionalityWithSecureClientConnection_Passes() throws Exception {
    Document searchResponseDoc = searchUsingSecuredClientConnection(SEARCH_REQUEST_XML);
    validateSearchResponse(searchResponseDoc);
  }

  private void validateSearchResponse(Document responseDoc) throws TransformerException {
    assertXpathExists("/documentManagerResponse/searchDocuments", responseDoc);
  }

  private Document searchUsingUnsecuredClientConnection(String requestXmlDocument) throws IOException, SAXException,
      POSCommunicationException, POSException, ParserException {
    Document inputDoc = DOMUtil.newDocument(requestXmlDocument);
    XMLPOSConnection posConn = new XMLPOSConnection();
    POSResult result = posConn.callService(POS_SEARCH_SERVICE_NAME, inputDoc);
    return DOMUtil.newDocument(result.getInputStream());
  }

  private Document searchUsingSecuredClientConnection(String requestXmlDocument) throws IOException, SAXException,
      POSCommunicationException, POSException, ParserException, GSSException {
    Document inputDoc = DOMUtil.newDocument(requestXmlDocument);
    SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForRetrieve(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    POSResult result = posConn.callService(POS_SEARCH_SERVICE_NAME, inputDoc);
    return DOMUtil.newDocument(result.getInputStream());
  }
}