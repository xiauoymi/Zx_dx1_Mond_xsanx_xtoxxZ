package com.monsanto.eas.documentservices.acceptancetests;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.Util.FileUtil;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.DocumentManagerTestUtils;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.SharePointTestUtil;
import org.apache.xerces.impl.dv.util.Base64;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Mar 1, 2006 Time: 1:04:11 PM To change this template use File |
 * Settings | File Templates.
 */
public class SharePointInsertRetrieveDoc_AT extends XMLTestCase {
  private static final String POS_INSERT_SERVICE_NAME = "InsertDocumentService";
  private static final String POS_RETRIEVE_SERVICE_NAME = "RetrieveDocumentService";
  private static final String INSERT_REQUEST_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/insertReq_AppTest.xml";
  private static final String INSERT_REQUEST_BINARY_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/insertReq_BinaryFile_AppTest.xml";
  private static final String INSERT_REQUEST_MON_DOCS_FILE = "com/monsanto/eas/documentservices/acceptancetests/insertReq_mon_docs.xml";
  private static final String INSERT_REQUEST_NON_EXISTING_DOC_LIB_FILE = "com/monsanto/eas/documentservices/acceptancetests/insertReq_non_existing_doc_lib_file.xml";
  private static final String TEST_TEXT_FILE_1 = "com/monsanto/eas/documentservices/acceptancetests/testFile1.txt";
  private static final String TEST_TEXT_FILE_2 = "com/monsanto/eas/documentservices/acceptancetests/testFile2.txt";
  private static final String TEST_TEXT_FILE_3 = "com/monsanto/eas/documentservices/acceptancetests/testFile3.txt";
  private static final String TEST_DOC_FILE_1 = "com/monsanto/eas/documentservices/acceptancetests/testSP.doc";
  private static final String TEST_INPUT_REQUEST_XML_4 = "com/monsanto/eas/documentservices/acceptancetests/TestInsertDocRequest4.xml";
  private static final String NAME_SPECIFIED_IN_REQUEST_1 = "apptestFile.txt";
  private static final String NAME_SPECIFIED_IN_REQUEST_2 = "appTestBinaryFile.doc";
  private static final String NAME_SPECIFIED_IN_REQUEST_3 = "appTestMonDocs.txt";
  private static final String ATTR_STR_PUBLISHER = "publisher";
  private static final String XPATH_START_STRING_ATTR_MATCH = "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name = '";
  private static final String XPATH_END_STRING_ATTR_MATCH = "']/value";
  private static final String KEYWORD_ATTRIBUTE_VALUE_1 = "monsanto";
  private static final String KEYWORD_ATTRIBUTE_VALUE_2 = "agriculture";
  private static final String KEYWORD_ATTRIBUTE_VALUE_3 = "crops";
  private static final String POS_DELETE_SERVICE_NAME = "DeleteDocumentService";
  private static final String TEST_DELETE_REQUEST_XML = "com/monsanto/eas/documentservices/acceptancetests/deleteRequest.xml";
  private static final String TEST_RETRIEVE_REQUEST_XML = "com/monsanto/eas/documentservices/acceptancetests/retrieveRequest.xml";
  private static final String DELETE_REQUEST_XML = "C:/deleteRequestDoc.xml";
  private static final String RETRIEVE_REQUEST_XML = "C:/retrieveRequestDoc.xml";
  private static List keywords;
  private String objectId;
  private static final String TEST_SEARCH_EXISTING_BY_NAME = "com/monsanto/eas/documentservices/acceptancetests/searchReq_AppClient_AT.xml";
  private static final String POS_SEARCH_SERVICE_NAME = "SearchDocumentsService";

  // added by ffbrac
    private static final String FILIP_TEST_SEARCH_REQUEST_OTHER_ATTRIBUTES_TEXT_FILE_AT = "com/monsanto/eas/documentservices/acceptancetests/FilipTest_searchReq_OtherAttributes_AppClient_AT.xml";


  static {
    keywords = new ArrayList();
    keywords.add(KEYWORD_ATTRIBUTE_VALUE_1);
    keywords.add(KEYWORD_ATTRIBUTE_VALUE_2);
    keywords.add(KEYWORD_ATTRIBUTE_VALUE_3);
  }

  protected void tearDown() throws Exception {
    if (objectId != null && objectId.length() > 0) {
      deleteInsertedDocument(objectId);
    }
  }

  public void testRetrieveExistingDocByName() throws Exception {
    //This test should be  the typical way a client would "retrieve by name" and relies on a document with an object_name of "Test UI Created doc" to be in the ScannedImages Library on na1000spdev60/teamsite
    //I specifically wanted to test the retrieval of a document not created by the insert service
    Document inputDocument = DOMUtil.newDocument(FILIP_TEST_SEARCH_REQUEST_OTHER_ATTRIBUTES_TEXT_FILE_AT);

    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    POSResult result = posConn.callService(POS_SEARCH_SERVICE_NAME, inputDocument);
    Document searchResult = DOMUtil.newDocument(result.getInputStream());
    System.out.println("*****Following is Request XML*****");
    DOMUtil.outputXML(inputDocument);
    System.out.println("*****Request XML Ends*****");
    System.out.println("*****Following is the search Result*****");
    DOMUtil.outputXML(searchResult);
    System.out.println("*****Search Result Ends*****");
    String searchObjectId = XPathAPI.eval(searchResult,
        "/documentManagerResponse/searchDocuments/documentDetails/attribute[name = '" +
            DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value").toString();
    String searchVersion = XPathAPI.eval(searchResult,
        "/documentManagerResponse/searchDocuments/documentDetails/attribute[name = '" +
            DocumentManagerConstants.ATTR_STR_VERSION + "']/value").toString();
    assertNotNull(searchVersion);
    System.out.println("searchVersion = " + searchVersion);
    System.out.println("searchVersion = \"" + searchVersion + "\"");
    assertTrue("search did not return a proper result - version was missing ", searchVersion.length() > 0);
    assertTrue("search did not return a proper result - objectid was missing", searchObjectId.length() > 0);
    System.out.println("searchObjectId = " + searchObjectId);
    System.out.println("searchVersion = " + searchVersion);
    Document retrieveRequestInput = patchRetrieveRequest(RETRIEVE_REQUEST_XML, searchObjectId, searchVersion);

      //Document retrieveRequestInput = DOMUtil.newDocument(RETRIEVE_REQUEST_XML);

      System.out.println("begin retrieveRequestInput.SharePointInsertRetrieveDoc_AT.testRetrieveExistingDocByName");
    System.out.println("*****Following is the Retrieve Request XML*****");
    DOMUtil.outputXML(retrieveRequestInput);
    System.out.println("*****Retrieve Request XML Ends*****");
    System.out.println("end retrieveRequestInput.SharePointInsertRetrieveDoc_AT.testRetrieveExistingDocByName");
    POSResult retrieveResult = posConn.callService(POS_RETRIEVE_SERVICE_NAME, retrieveRequestInput);
    Document retrieveResponseDoc = DOMUtil.newDocument(retrieveResult.getInputStream());
    DOMUtil.outputXML(retrieveResponseDoc);
    saveAsXMLFile(retrieveResponseDoc, "c:/retrieveresponse.xml");
    String retrievedContentPath = validateRetrievedDocumentContents(retrieveResponseDoc);
    System.out.println("retrievedContentPath = " + retrievedContentPath);


  }

   
  private Document patchRetrieveRequest(String retrieveRequestFilenamePath, String searchObjectId,
                                        String version) throws
      ParserException, TransformerException, FileNotFoundException {
    Document retrieveRequestDoc = DOMUtil.newDocument(TEST_RETRIEVE_REQUEST_XML);
    Node objectIdValueNode = XPathAPI.eval(retrieveRequestDoc,
        "/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute[name = '" +
            DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = retrieveRequestDoc.createTextNode(searchObjectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    if (!StringUtils.isNullOrEmpty(version)) {
      Node versionValueNode = XPathAPI.eval(retrieveRequestDoc,
          "/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute[name = '" +
              DocumentManagerConstants.ATTR_STR_VERSION + "']/value")
          .nodelist().item(0);
      Node newVersionValueNode = retrieveRequestDoc.createTextNode(version);
      versionValueNode.replaceChild(newVersionValueNode, versionValueNode.getFirstChild());
    }
    saveAsXMLFile(retrieveRequestDoc, retrieveRequestFilenamePath);
    return retrieveRequestDoc;
  }

  public void testInsertDocWithSchemaValidationError_throwsException() throws Exception {
    try {
      Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_4);
      SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
          new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
      POSResult result = posConn.callService(POS_INSERT_SERVICE_NAME, inputDocument);
      DOMUtil.newDocument(result.getInputStream());
      fail("Schema Validation Exception not thrown.");
    } catch (POSException e) {
      //expected path
    }
  }

  public void testInsertRetrieveOfTextDocument() throws Exception {
    validateAttachmentSentAndReceived(TEST_TEXT_FILE_1, POSMIMEConstants.MIME_TYPE_TEXT,
        INSERT_REQUEST_TEXT_FILE_AT, NAME_SPECIFIED_IN_REQUEST_1, null);
  }

  public void testInsertRetrieveOfBinaryDocument() throws Exception {
    validateAttachmentSentAndReceived(TEST_DOC_FILE_1, POSMIMEConstants.MIME_TYPE_MSWORD,
        INSERT_REQUEST_BINARY_FILE_AT, NAME_SPECIFIED_IN_REQUEST_2, null);
  }

  public void testInsertRetrieveWithAttributes_CustomObjectTypeDoc_HavingCustomAttribute_PreviouslyDefinedInDctm()
      throws Exception {
    List requiredAttributes = new ArrayList();
    requiredAttributes.add(DocumentManagerConstants.ATTR_STR_TITLE);
    requiredAttributes.add(ATTR_STR_PUBLISHER);
    requiredAttributes.add(DocumentManagerConstants.ATTR_STR_KEYWORDS);
    requiredAttributes.add(DocumentManagerConstants.ATTR_STR_SIZE);
    Document retrievedDocument = validateAttachmentSentAndReceived(TEST_TEXT_FILE_2,
        POSMIMEConstants.MIME_TYPE_TEXT,
        INSERT_REQUEST_MON_DOCS_FILE,
        NAME_SPECIFIED_IN_REQUEST_3, requiredAttributes);
    assertXpathEvaluatesTo("monDocTitle",
        XPATH_START_STRING_ATTR_MATCH + DocumentManagerConstants.ATTR_STR_TITLE +
            XPATH_END_STRING_ATTR_MATCH,
        retrievedDocument);
    assertXpathEvaluatesTo("monDocsOperatingUnit",
        XPATH_START_STRING_ATTR_MATCH + ATTR_STR_PUBLISHER + XPATH_END_STRING_ATTR_MATCH,
        retrievedDocument);
    assertXpathEvaluatesTo("23",
        XPATH_START_STRING_ATTR_MATCH + DocumentManagerConstants.ATTR_STR_SIZE +
            XPATH_END_STRING_ATTR_MATCH,
        retrievedDocument);
    for (int i = 0; i < keywords.size(); i++) {
      String keyword = (String) keywords.get(i);
      assertXpathEvaluatesTo(keyword,
          XPATH_START_STRING_ATTR_MATCH + DocumentManagerConstants.ATTR_STR_KEYWORDS +
              "']/value[" + (i + 1) + "]", retrievedDocument);
    }
  }

  public void testInsertRetrieveWithAttr_thowsException_WhenServiceSpecificAttrNameSentInRequest() throws Exception {
    try {
      String serviceSpecificAttrName = DocumentManagerConstants.DCTM_ATTR_STR_SIZE;
      List requiredAttributes = new ArrayList();
      requiredAttributes.add(serviceSpecificAttrName);
      validateAttachmentSentAndReceived(TEST_TEXT_FILE_2,
          POSMIMEConstants.MIME_TYPE_TEXT, INSERT_REQUEST_MON_DOCS_FILE,
          NAME_SPECIFIED_IN_REQUEST_3, requiredAttributes);
    } catch (POSException e) {
      //expected path
    }
  }

  public void testInsertRetrieveForDocumentOfDocLibNotDefinedInSP_throwsException() throws
      Exception {
    try {
      validateAttachmentSentAndReceived(TEST_TEXT_FILE_3, POSMIMEConstants.MIME_TYPE_TEXT,
          INSERT_REQUEST_NON_EXISTING_DOC_LIB_FILE, NAME_SPECIFIED_IN_REQUEST_1,
          null);
    } catch (POSException e) {
      //expected path
    }
  }

  private void deleteInsertedDocument(String objectId) throws ParserException, POSCommunicationException,
      POSException, FileNotFoundException,
      TransformerException, GSSException {
    createTestDeleteRequestXML(DELETE_REQUEST_XML, objectId);
    Document inputDoc = DOMUtil.newDocument(DELETE_REQUEST_XML);
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    posConn.callService(POS_DELETE_SERVICE_NAME, inputDoc);
  }

  private void createTestDeleteRequestXML(String deleteRequestFilenamePath, String objectId) throws
      FileNotFoundException,
      ParserException,
      TransformerException {
    Document deleteRequestDoc = DOMUtil.newDocument(TEST_DELETE_REQUEST_XML);
    Node objectIdValueNode = XPathAPI.eval(deleteRequestDoc,
        "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    saveAsXMLFile(deleteRequestDoc, deleteRequestFilenamePath);
  }

  private void saveAsXMLFile(Document deleteRequestDoc, String deleteRequestFilenamePath) throws
      FileNotFoundException {
    DOMUtil.outputXML(deleteRequestDoc, new FileOutputStream(new File(deleteRequestFilenamePath)));
  }

  private Document validateAttachmentSentAndReceived(String fileName, String mimeType,
                                                     String requestXmlDocument, String fileNameSpecifiedInRequest,
                                                     List requiredAttributes) throws
      Exception {
    MultipartAttachmentList attachmentList = new MultipartAttachmentList();
    addAttachment(attachmentList, fileName, mimeType);
    Document responseDoc = insertDocument(attachmentList, requestXmlDocument);
    objectId = validateVersionAndGetObjectIdOfInsertedDocument(responseDoc);
    Document retrievedDocument = retrieveDocument(objectId, requiredAttributes);
    String pathToRetrievedFile = validateRetrievedDocumentContents(retrievedDocument);
    assertTrue("Files do not match :(", FileUtil.compareFiles(fileName, pathToRetrievedFile));
    validateRetrievedFileAttributes(objectId, retrievedDocument, fileNameSpecifiedInRequest);
    return retrievedDocument;
  }

  private void validateRetrievedFileAttributes(String objecId, Document retrievedDocument,
                                               String fileNameSpecifiedInRequest) throws
      TransformerException {
    assertXpathEvaluatesTo(objecId,
        XPATH_START_STRING_ATTR_MATCH + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID +
            XPATH_END_STRING_ATTR_MATCH,
        retrievedDocument);
    assertXpathEvaluatesTo(fileNameSpecifiedInRequest, XPATH_START_STRING_ATTR_MATCH + DocumentManagerConstants
        .ATTR_STR_NAME + XPATH_END_STRING_ATTR_MATCH, retrievedDocument);
  }

  private Document retrieveDocument(String objectId, List requiredAttr) throws Exception {
    Document inputDocument = buildRetrieveRequest(objectId, requiredAttr);

    DOMUtil.outputXML(inputDocument);

    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    POSResult result = posConn.callService(POS_RETRIEVE_SERVICE_NAME, inputDocument);
    return DOMUtil.newDocument(result.getInputStream());
  }

  private String validateRetrievedDocumentContents(Document retrieveResponseDoc) throws IOException,
      TransformerException {
    String encodedContentString = XPathAPI.eval(retrieveResponseDoc,
        XPATH_START_STRING_ATTR_MATCH + DocumentManagerConstants
            .ATTR_STR_CONTENTS + XPATH_END_STRING_ATTR_MATCH)
        .toString();

    System.out.println("SharePointInsertRetrieveDoc_AT.validateRetrievedDocumentContents: encodedContentString = " +
        encodedContentString);

    //ToDo

    byte decodedByte[] = Base64.decode(encodedContentString);


    String filePath =
        System.getProperty(DocumentManagerConstants.TEMP_DIRECTORY) + XPathAPI.eval(retrieveResponseDoc,
            XPATH_START_STRING_ATTR_MATCH +
                DocumentManagerConstants
                    .ATTR_STR_NAME +
                XPATH_END_STRING_ATTR_MATCH)
            .toString();
    FileOutputStream foStream = new FileOutputStream(filePath);
    foStream.write(decodedByte, 0, decodedByte.length);
    foStream.flush();
    foStream.close();
    return filePath;
  }

  private Document buildRetrieveRequest(String objectId, List requiredAttributes) {
    Document retrieveReqDoc = DOMUtil.newDocument();
    Node rootNode = DOMUtil
        .addChildElementWithNS("www.monsanto.com/pos", retrieveReqDoc, "retrieveDocumentRequest");
    DOMUtil.addChildElement(rootNode, "folder", "posTestFolder-SP");
    DOMUtil.addChildElement(rootNode, "directoryStructure", "test/folder1/folder2");
    Node requestDetailsNode = DOMUtil.addChildElement(rootNode, "requestDetails");
    Node retrieveDocNode = DOMUtil.addChildElement(requestDetailsNode, "retrieveDocument");
    addDocumentAttributesNode(retrieveDocNode, objectId);
    if (requiredAttributes != null && requiredAttributes.size() > 0) {
      addRequiredAttributesNode(retrieveDocNode, requiredAttributes);
    }
    return retrieveReqDoc;
  }

  private void addRequiredAttributesNode(Node retrieveDocNode, List requiredAttributes) {
    Node requiredAttrNode = DOMUtil.addChildElement(retrieveDocNode, "requiredAttributes");
    for (Object requiredAttribute : requiredAttributes) {
      String requiredAttr = (String) requiredAttribute;
      DOMUtil.addChildElement(requiredAttrNode, "attribute", requiredAttr);
    }
  }

  private void addDocumentAttributesNode(Node retrieveDocNode, String objectId) {
    Node docAttrName = DOMUtil.addChildElement(retrieveDocNode, "queryAttributes");
    Node attrName = DOMUtil.addChildElement(docAttrName, "attribute");
    DOMUtil.addChildElement(attrName, "name", "objectId");
    DOMUtil.addChildElement(attrName, "value", objectId);
  }

  private void addAttachment(MultipartAttachmentList attachmentList, String fileName, String mimeType) throws
      InvalidMimeTypeException {
    MultiPartFormAttachment attachment = new MultiPartFormAttachment(fileName, mimeType);
    attachmentList.addAttachment(attachment);
  }

  private Document insertDocument(MultipartAttachmentList attachmentList, String requestXmlDocument) throws Exception {
    SharePointTestUtil.deleteDocumentByName(DocumentManagerTestUtils.getNameFromInsertRequest(requestXmlDocument));
    Document inputDoc = DOMUtil.newDocument(requestXmlDocument);
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    addAttachmentToConnection(attachmentList, posConn);
    POSResult result = null;
    result = posConn.callService(POS_INSERT_SERVICE_NAME, inputDoc);
    return DOMUtil.newDocument(result.getInputStream());
  }

  private void addAttachmentToConnection(MultipartAttachmentList attachmentList, XMLPOSConnection posConn) {
    int numberOfAttachments = attachmentList.getLength();
    for (int i = 0; i < numberOfAttachments; i++) {
      MultiPartFormAttachment attachment = attachmentList.getAttachment(i);
      posConn.addAttachment(attachment);
    }
  }

  private String validateVersionAndGetObjectIdOfInsertedDocument(Document responseDoc) throws TransformerException {

    DOMUtil.outputXML(responseDoc);

    assertXpathEvaluatesTo("0.1", "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" +
        DocumentManagerConstants.ATTR_STR_VERSION + "']/value", responseDoc);
    String expression = "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" +
        DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value";
    Object objId = XPathAPI.eval(responseDoc, expression);
    return objId.toString();
  }

}