package com.monsanto.eas.documentservices.acceptancetests;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.DocumentManagerTestUtils;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.SharePointTestUtil;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.TestUtil;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 9, 2006 Time: 5:00:14 PM To change this template use File |
 * Settings | File Templates.
 */
public class SharepointSearchService_AT extends XMLTestCase {
	private static final String SEARCH_REQUEST_XML = "com/monsanto/eas/documentservices/acceptancetests/searchRequest.xml";
	private static final String SEARCH_REQUEST_XML_WITHOUT_QUERY_ATTR = "com/monsanto/eas/documentservices/acceptancetests/searchRequestWithoutQueryAttr-SP.xml";
//	private static final String SEARCH_REQUEST_XML_WITH_MULTIPLE_QUERY_ATTRS = "com/monsanto/eas/documentservices/acceptancetests/searchRequestWithMultipleQueryAttrs-SP.xml";
//  private static final String SEARCH_REQUEST_XML_ALL_VERSIONS = "com/monsanto/eas/documentservices/acceptancetests/searchReqForAllVersions.xml";
  private static final String ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private static final String ATTACHMENT_2 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile2.txt";
  private static final String ATTACHMENT_3 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile3.txt";
	private static final String INSERT_XML_1 = "com/monsanto/eas/documentservices/acceptancetests/insertReq1-SP.xml";
  private static final String INSERT_XML_2 = "com/monsanto/eas/documentservices/acceptancetests/insertReq2-SP.xml";
  private static final String INSERT_XML_3 = "com/monsanto/eas/documentservices/acceptancetests/insertReq3-SP.xml";
	private static final String UPDATE_XML_3_TEMPLATE = "com/monsanto/eas/documentservices/acceptancetests/updateReq3-SP.xml";
	private static final String XPATH_BEGIN_STR = "/documentManagerResponse/searchDocuments/documentDetails[attribute/value='";
  private static final String XPATH_MID_STR = "']/attribute[name = '";
  private static final String XPATH_END_STR = "']/value";
  private String objectId1;
  private String objectId2;
  private String objectId3;
  private static final String TEST_DOC_NAME_1 = "attachment1";
  private static final String TEST_DOC_SUBJECT_1 = "farm resource";
  private static final String TEST_DOC_TITLE_1 = "monsanto search docs";
  private static final String TEST_DOC_SIZE_1 = "9";
  private static final List TEST_KEYWORDS_1 = new ArrayList();

  static {
    TEST_KEYWORDS_1.add("field");
    TEST_KEYWORDS_1.add("farm");
  }

  private static final String TEST_DOC_NAME_2 = "attachment2";
  private static final String TEST_DOC_SUBJECT_2 = "crop details";
  private static final String TEST_DOC_TITLE_2 = "search docs";
  private static final String TEST_DOC_SIZE_2 = "11";
  private static final List TEST_KEYWORDS_2 = new ArrayList();

  static {
    TEST_KEYWORDS_2.add("crop");
    TEST_KEYWORDS_2.add("manure");
    TEST_KEYWORDS_2.add("pesticide");
  }

  private static final String TEST_DOC_NAME_3 = "attachment3";
  private static final String TEST_DOC_SUBJECT_3 = "farm resource";
  private static final String TEST_DOC_TITLE_3 = "monsanto search docs";
  private static final String TEST_DOC_SIZE_3 = "19";
  private static final List TEST_KEYWORDS_3 = new ArrayList();
	private String expectedCreator = "xyz";

	static {
    TEST_KEYWORDS_3.add("manure");
    TEST_KEYWORDS_3.add("farm");
  }

//  private static final String INSERT_VERSION = "1.0";
  private static final String UPDATE_MINOR_VERSION = "1.1";

  protected void setUp() throws Exception {
		objectId1 = insertTestDocument(ATTACHMENT_1, INSERT_XML_1);
    objectId2 = insertTestDocument(ATTACHMENT_2, INSERT_XML_2);
    objectId3 = insertTestDocument(ATTACHMENT_3, INSERT_XML_3);
    String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document updateReq = TestUtil.transformRequestXML(UPDATE_XML_3_TEMPLATE, objectId3, updateTransformationXPathString, 0);
		SharePointTestUtil.updateDocument(ATTACHMENT_3, updateReq, DocumentManagerConstants.WORD_DOC_FILETYPE);
		expectedCreator = System.getProperty("user.name").toLowerCase();
		System.out.println("SharepointSearchService_AT.setUp: expectedCreator = " + expectedCreator);
	}

  protected void tearDown() throws Exception {
    deleteAllVersionsOfInsertDocuments();
  }

  public void testSearchFunctionalityForSingleValuedQueryAttributeOfTypeString_TITLE() throws Exception {
		Document searchResponseDoc = DocumentManagerTestUtils.search(DOMUtil.newDocument(SEARCH_REQUEST_XML));
		validateNumberOfDocumentsReturned(searchResponseDoc, 2);
    validateSearchResponse(objectId1, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_1, "updatedSubject", TEST_DOC_NAME_1,
        TEST_DOC_TITLE_1, expectedCreator, TEST_DOC_SIZE_1, TEST_KEYWORDS_1, searchResponseDoc
    );
    validateSearchResponse(objectId3, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_3, "updatedSubject", TEST_DOC_NAME_3,
        TEST_DOC_TITLE_3, expectedCreator, TEST_DOC_SIZE_3, TEST_KEYWORDS_3, searchResponseDoc
    );
  }

  public void testSearchFunctionality_WithoutAnyQueryAttribute_ReturnsAllDocuments() throws Exception {
    Document searchResponseDoc = DocumentManagerTestUtils.search(DOMUtil.newDocument(SEARCH_REQUEST_XML_WITHOUT_QUERY_ATTR));
    validateNumberOfDocumentsReturned(searchResponseDoc, 3);
    validateSearchResponse(objectId1, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_1, "updatedSubject", TEST_DOC_NAME_1,
        TEST_DOC_TITLE_1, expectedCreator, TEST_DOC_SIZE_1, TEST_KEYWORDS_1, searchResponseDoc
    );
    validateSearchResponse(objectId2, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_2, "updatedSubject", TEST_DOC_NAME_2,
        TEST_DOC_TITLE_2, expectedCreator, TEST_DOC_SIZE_2, TEST_KEYWORDS_2, searchResponseDoc
    );
    validateSearchResponse(objectId3, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_3, "updatedSubject", TEST_DOC_NAME_3,
        TEST_DOC_TITLE_3, expectedCreator, TEST_DOC_SIZE_3, TEST_KEYWORDS_3, searchResponseDoc
    );
  }

	//ToDo: Not supported yet for Sharepoint - needs SPSearch SErvice
//	public void testSearchFunctionality_WithMultipleQueryAttributes_WithinCurrentVersions() throws Exception {
//		System.out.println("1");
//    Document searchResponseDoc = DocumentManagerTestUtils.search(
//        DOMUtil.newDocument(SEARCH_REQUEST_XML_WITH_MULTIPLE_QUERY_ATTRS));
//		System.out.println("2");
//		validateNumberOfDocumentsReturned(searchResponseDoc, 2);
//		System.out.println("3");
//		validateSearchResponse(objectId2, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_2, "updatedSubject", TEST_DOC_NAME_2,
//        TEST_DOC_TITLE_2, expectedCreator, TEST_DOC_SIZE_2, TEST_KEYWORDS_2, searchResponseDoc
//    );
//    validateSearchResponse(objectId3, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_3, "updatedSubject", TEST_DOC_NAME_3,
//        TEST_DOC_TITLE_3, expectedCreator, TEST_DOC_SIZE_3, TEST_KEYWORDS_3, searchResponseDoc
//    );
//  }

	//ToDo: Not supported yet for Sharepoint - needs SPSearch Service
//	public void testSearchFunctionality_WithMultipleQueryAttributes_WithinAllVersions() throws Exception {
//    Document searchResponseDoc = DocumentManagerTestUtils
//        .search(DOMUtil.newDocument(SEARCH_REQUEST_XML_ALL_VERSIONS));
//    validateNumberOfDocumentsReturned(searchResponseDoc, 3);
//    validateSearchResponse(objectId2, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_2, "", TEST_DOC_NAME_2,
//        TEST_DOC_TITLE_2, TEST_DOC_CREATOR_2, TEST_DOC_SIZE_2, TEST_KEYWORDS_2, searchResponseDoc
//    );
//    validateSearchResponse(objectId3, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_3, "updatedSubject", TEST_DOC_NAME_3,
//        TEST_DOC_TITLE_3, TEST_DOC_CREATOR_3, TEST_DOC_SIZE_3, TEST_KEYWORDS_3, searchResponseDoc
//    );
//  }
	
	private void deleteAllVersionsOfInsertDocuments() throws Exception {
		SharePointTestUtil.deleteAllVersionsOfInsertedDocument(objectId1);
		SharePointTestUtil.deleteAllVersionsOfInsertedDocument(objectId2);
		SharePointTestUtil.deleteAllVersionsOfInsertedDocument(objectId3);
  }

  private void validateSearchResponse(String objectId, String newVersion, String subject, String updatedSubject,
                                      String docName, String title, String creator, String size, List keywords,
                                      Document searchReponseDoc
  ) throws TransformerException {
    assertXpathEvaluatesTo(docName, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
        + DocumentManagerConstants.ATTR_STR_NAME + XPATH_END_STR,
        searchReponseDoc);
    String documentVersion = XPathAPI.eval(searchReponseDoc, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
        + DocumentManagerConstants.ATTR_STR_VERSION +
        XPATH_END_STR).toString();
    if (documentVersion.equalsIgnoreCase(newVersion)) {
      assertXpathEvaluatesTo(updatedSubject, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
          + DocumentManagerConstants.ATTR_STR_SUBJECT + XPATH_END_STR,
          searchReponseDoc);
    } else {
      assertXpathEvaluatesTo(subject, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
          + DocumentManagerConstants.ATTR_STR_SUBJECT + XPATH_END_STR,
          searchReponseDoc);
    }
    assertXpathEvaluatesTo(title, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
        + DocumentManagerConstants.ATTR_STR_TITLE + XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(creator, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
        + DocumentManagerConstants.ATTR_STR_CREATOR + XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(size, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
        + DocumentManagerConstants.ATTR_STR_SIZE + XPATH_END_STR,
        searchReponseDoc);
    for (int i = 0; i < keywords.size(); i++) {
      String expectedKeyword = (String) keywords.get(i);
      assertXpathEvaluatesTo(expectedKeyword, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
          + DocumentManagerConstants.ATTR_STR_KEYWORDS
          + XPATH_END_STR + "[" + (i + 1) + "]", searchReponseDoc);
    }
  }

  private void validateNumberOfDocumentsReturned(Document searchResponseDoc, int expectedNumberOfNodes) throws
      TransformerException {
    int numberOfNodes = XPathAPI.eval(searchResponseDoc, "/documentManagerResponse/searchDocuments/documentDetails")
        .nodelist().getLength();
    assertTrue(numberOfNodes >= expectedNumberOfNodes);
  }

  private String insertTestDocument(String fileAttachment, String insertRequestXml) throws Exception {
		System.out.println("1.1");
		String docName = DocumentManagerTestUtils.getNameFromInsertRequest(insertRequestXml);
		System.out.println("1.2");
		try {
			SharePointTestUtil.deleteDocumentByName(docName);
		} catch (Exception e) {
			//Ignore Exception
		}
		System.out.println("1.3");
		String objectId = SharePointTestUtil.insertTestDocument(fileAttachment, insertRequestXml);
		System.out.println("SharepointSearchService_AT.insertTestDocument: objectId = " + objectId);
		return objectId;
  }

}