package com.monsanto.eas.documentservices.acceptancetests;

//import com.microsoft.schemas.sharepoint.soap.GetListCollectionResponse;
//import com.microsoft.schemas.sharepoint.soap.GetListResponse;
//import com.microsoft.schemas.sharepoint.soap.Lists;
//import com.microsoft.schemas.sharepoint.soap.ListsSoap;

import com.microsoft.schemas.sharepoint.soap.*;
import com.microsoft.schemas.sharepoint.soap.dws.Dws;
import com.microsoft.schemas.sharepoint.soap.dws.DwsSoap;
import com.monsanto.Util.FileUtil;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import junit.framework.TestCase;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.interceptor.StaxInInterceptor;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.xerces.dom.ElementNSImpl;
import org.w3c.dom.*;

import javax.xml.soap.Detail;
import javax.xml.soap.SOAPFault;
import javax.xml.ws.Holder;
import javax.xml.ws.soap.SOAPFaultException;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: ARDHARN Date: May 15, 2008 Time: 4:06:33 PM To change this template use File |
 * Settings | File Templates.
 */
public class
    SharepointServices_SPIKE extends TestCase {
  private static final String SITE_NAME = "http://na1000spdev60/teamsite";
  private static final String DOCUMENT_LIBRARY_NAME = "ScannedImages";
  public String fileName = "apptestFile.doc";
  public String destUrl = SITE_NAME + "/" + DOCUMENT_LIBRARY_NAME + "/";
  private String directoryStructure = "test Folder";

  public void testfiddlewithURLClass() throws Exception {
    URL testUrl = new URL(SITE_NAME);
    System.out.println("testUrl.getPath() = " + testUrl.getPath());
    System.out.println("testUrl.getFile() = " + testUrl.getFile());
    System.out.println("testUrl.getProtocol() = " + testUrl.getProtocol());
    System.out.println("testUrl.getHost() = " + testUrl.getHost());
    System.out.println("testUrl.getPort() = " + testUrl.getPort());
  }

  public void testUploadDocument_ThenGetID() throws Exception {
    deleteDocumentOrFolder(destUrl, fileName);
    CopySoap copySoap = createCopyService(SITE_NAME + "/_vti_bin/Copy.asmx?WSDL");
    DestinationUrlCollection destUrls = setupDestinationUrls(SITE_NAME + "/" + DOCUMENT_LIBRARY_NAME + "/", fileName);
    byte[] stream = FileUtil
        .fileToByteArray("com/monsanto/tcc/documentmanagementserver_version2/apptests/apptestfile.doc");
    FieldInformationCollection fields = new FieldInformationCollection();
    List<FieldInformation> fieldInformationList = fields.getFieldInformation();
    addFieldToList(fieldInformationList, "Publisher", "TestPublisherValue");
    String chronID = java.util.UUID.randomUUID().toString();
    System.out.println("chronID = " + chronID);
    addFieldToList(fieldInformationList, "i_chronicle_id", chronID);
    Holder<Long> result = new Holder<Long>();
    Holder<CopyResultCollection> results = new Holder<CopyResultCollection>();
    copySoap.copyIntoItems(destUrls.getString().get(0), destUrls, fields, stream, result, results);
    List<CopyResult> copyResults = results.value.getCopyResult();
    assertEquals("Ensure that the document wasn't already in Sharepoint", "Success",
        copyResults.get(0).getErrorCode().value());
    String id = getID(fileName);
    assertNotNull(id);
    System.out.println("SharepointServices_SPIKE.testUploadDocument: id = " + id);
    assertEquals("didn't actually get the UUID that I set; got list ID instead", chronID, id);
  }

  public void testIdentifyCurrentVersion() throws Exception {
    listOutDocumentVersions("001DaysSinceLastUnplannedOuttage.doc");
  }

  public void testTryToGetAListItemAsTheResultOfAnInsert() throws Exception {
    //This actually proved to be collosally useless; I guess we're stuck with just the FieldInfoCollection; apparently the listItemResult is just an execution resultcode(sucess appears to returnn 0 anyway)
    deleteDocumentOrFolder(destUrl, fileName);
    CopySoap copySoap = createCopyService(SITE_NAME + "/_vti_bin/Copy.asmx?WSDL");
    DestinationUrlCollection destUrls = setupDestinationUrls(SITE_NAME + "/" + DOCUMENT_LIBRARY_NAME + "/", fileName);
    byte[] stream = FileUtil
        .fileToByteArray("com/monsanto/tcc/documentmanagementserver_version2/apptests/apptestfile.doc");
    FieldInformationCollection fields = new FieldInformationCollection();
    List<FieldInformation> fieldInformationList = fields.getFieldInformation();
    addFieldToList(fieldInformationList, "Publisher", "TestPublisherValue");
    Holder<Long> result = new Holder<Long>();
    Holder<CopyResultCollection> results = new Holder<CopyResultCollection>();
    copySoap.copyIntoItems(destUrls.getString().get(0), destUrls, fields, stream, result, results);
    List<CopyResult> copyResults = results.value.getCopyResult();
    assertEquals("Ensure that the document wasn't already in Sharepoint", "Success",
        copyResults.get(0).getErrorCode().value());
    String id = getID(fileName);
    Holder<FieldInformationCollection> heldFields = new Holder<FieldInformationCollection>();
    Holder<byte[]> byteStream = new Holder<byte[]>();
    Holder<Long> getItemResult = new Holder<Long>();
    copySoap.getItem(destUrl + "/" + fileName, getItemResult, heldFields, byteStream);
    FieldInformationCollection heldFieldsValue = heldFields.value;
    System.out.println("getItemResult = " + getItemResult);
    Object itemresult = getItemResult.value;
    System.out.println("itemresult = " + itemresult);
    System.out.println("SharepointServices_SPIKE.testUploadDocument: id = " + id);
    assertNotNull(id);

  }

  public void testCreateADirectory() throws Exception {
    directoryStructure = "testFolder";
    createFolder("", directoryStructure);
    deleteDocumentOrFolder(destUrl, directoryStructure);
  }

  public void testcreateADirectoryStructure() throws Exception {
    directoryStructure = "testFolder/test SubFolder/a third level";
    createDirectoryStructure(DOCUMENT_LIBRARY_NAME, directoryStructure);
    deleteDocumentOrFolder(destUrl, directoryStructure);
    deleteDocumentOrFolder(destUrl, "testFolder");
  }


  public void testUploadDocument_WithNewVersion() throws Exception {
    deleteDocumentOrFolder(destUrl, fileName);
    CopySoap copySoap = uploadDocumentToSharepoint(destUrl, fileName,
        "com/monsanto/tcc/documentmanagementserver_version2/apptests/apptestfile.doc");
    uploadDocumentWithCheckout_SubsequentVersion(destUrl, fileName, copySoap);
    listOutDocumentVersions(fileName);
  }

  public void testUploadDocument_ThenRetrieveSameDocument() throws Exception {
    deleteDocumentOrFolder(destUrl, fileName);
    String fileOnDisk = "C:/apptestfile2.doc";
    File fileToDelete = new File(fileOnDisk);
    fileToDelete.delete();
    CopySoap copySoap = uploadDocumentToSharepoint(destUrl, fileName,
        "com/monsanto/tcc/documentmanagementserver_version2/apptests/apptestfile.doc");
    Holder<Long> getItemResult = new Holder<Long>();
    Holder<FieldInformationCollection> heldFields = new Holder<FieldInformationCollection>();
    Holder<byte[]> byteStream = new Holder<byte[]>();
    copySoap.getItem(destUrl + fileName, getItemResult, heldFields, byteStream);
    FileUtil.write(fileOnDisk, new String(byteStream.value));
    assertTrue(FileUtil.doesFileExist(fileOnDisk));
  }

  public void testUploadDocument_ThenDeleteSameDocument() throws Exception {
    deleteDocumentOrFolder(destUrl, fileName);
    uploadDocumentToSharepoint(destUrl, fileName,
        "com/monsanto/tcc/documentmanagementserver_version2/apptests/apptestfile.doc");
    deleteDocumentOrFolder(destUrl, fileName);
  }

  public void testUploadDocument_ThenDeleteSameDocument_ByDocumentID() throws Exception {
    deleteDocumentOrFolder(destUrl, fileName);
    uploadDocumentToSharepoint(destUrl, fileName,
        "com/monsanto/tcc/documentmanagementserver_version2/apptests/apptestfile.doc");
    String id = getID(fileName);
    System.out.println("SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument_ByDocumentID: id = " + id);
    deleteDocumentByID(id);
  }

  public void testGetListItems() throws Exception {
    deleteDocumentOrFolder(destUrl, fileName);
    uploadDocumentToSharepoint(destUrl, fileName,
        "com/monsanto/tcc/documentmanagementserver_version2/apptests/apptestfile.doc");
    ListsSoap listsSoap = setupListsService();
    ArrayList<String> listColumnNames = getColumnNameList();
    GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
        .getListItems(DOCUMENT_LIBRARY_NAME, "", null, null, null, null, "");
    Object listResult = scannedImagesResult.getContent().get(0);
    parseAndDisplayListItems(listColumnNames, listResult);
  }

  public void testWhatHappensIfThereAreMultipleFilesOfSameNameInLibrary() throws Exception {
    //Given the documents I added by hand, I would expect multiple results, are we just picking up the first one and if so, can we get the rest, and return a list?
    List idList = findIdByName("appTestFile");
    System.out.println("idList = " + idList);
    for (Object anIdList : idList) {
      String id = (String) anIdList;
      String fileName = getFileName(id);
      System.out.println("fileName = " + fileName);
    }
  }

  private void createFolder(String root, String directory) throws IOException, ParserException {

    //ToDo: parse error response better see http://ronaldlemmen.blogspot.com/2010/04/sharepoint-error-message-0x8107026f.html for error code definitions
    Lists service = new Lists(new URL(SITE_NAME + "/_vti_bin/Lists.asmx?WSDL"));
    ListsSoap listsSoap = service.getListsSoap();
    String strBatch = "<Batch OnError=\"Continue\" PreCalc=\"TRUE\" \n" +
        "ListVersion=\"0\" rootFolder=\"" + root + "\">\n" +
        "   <Method ID=\"1\" Cmd=\"New\">\n" +
        "      <Field Name=\"ID\">New</Field>\n" +
        "      <Field Name=\"FSObjType\">1</Field>\n" +
        "      <Field Name=\"BaseName\">" + root + "/" + directory + "</Field>\n" +
        "   </Method>\n" +
        "</Batch>";
    System.out.println("strBatch = " + strBatch);
    Document document = DOMUtil.newDocumentFromXML(strBatch);
    UpdateListItems.Updates updates = new UpdateListItems.Updates();
    List<Object> content = updates.getContent();
    content.add(document.getDocumentElement());
    UpdateListItemsResponse.UpdateListItemsResult listItemsResult = null;
    try {
      listItemsResult = listsSoap.updateListItems("ScannedImages", updates);
      parseResult(listItemsResult);
    } catch (SOAPFaultException e) {
      SOAPFault fault = e.getFault();
      System.out.println(
          "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: e.getMessage() = " + e.getMessage());
      Detail detail = fault.getDetail();
      System.out.println(
          "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: detail.toString() = " +
              detail.toString());
      System.out.println(
          "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: detail.getValue() = " +
              detail.getValue());
      Iterator entries = detail.getDetailEntries();
      while (entries.hasNext()) {
        Object o = entries.next();
        System.out
            .println(
                "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: o.toString() = " + o.toString());
      }
      System.out
          .println("SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: fault.getFaultActor() = " +
              fault.getFaultActor());
      System.out.println("SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: fault.getFaultCode() = " +
          fault.getFaultCode());
      System.out
          .println("SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: fault.getFaultString() = " +
              fault.getFaultString());
      System.out
          .println(
              "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: e.toString() = " + e.toString());
    }
  }
/*  private String createDirectoryStructure(String directoryStructure) throws DocumentManagerException {
    String completeParentFolderPath = documentLibraryName;
    if (directoryStructure != null && directoryStructure.length() > 0) {
      createDirectoryStructure(documentLibraryName, directoryStructure);
      completeParentFolderPath = completeParentFolderPath + "/" + directoryStructure;
    }
    return completeParentFolderPath;
  }*/

  private void createDirectoryStructure(String docLib, String directoryStructure) throws DocumentManagerException {
    System.out.println("SharepointServices_SPIKE.createDirectoryStructure:");
    System.out.println("docLib = " + docLib);
    System.out.println("directoryStructure = " + directoryStructure);
    if (isSubdirectoryPresent(directoryStructure)) {
      String[] directoryList = createSubdirectoryList(directoryStructure, docLib);
      for (int i = 0; i < directoryList.length - 1; i++) {

        String substructure = buildSubdirectory(directoryList, i);
        String nextPathToBuild = directoryList[i + 1];
//          nextPathToBuild = nextPathToBuild.replace(docLib, "");
        System.out.println("substructure = " + substructure);
        System.out.println("nextPathToBuild = " + nextPathToBuild);
        try {
          createFolder(substructure, nextPathToBuild);
        } catch (IOException e) {
          throw new DocumentManagerException(
              "Something bad happened during the creation of the directory(" + directoryStructure + "): \"" +
                  e.getMessage() + "\"", e);
        } catch (ParserException e) {
          e.printStackTrace();
        }
      }
    } else {
      createDirectory(directoryStructure);
    }
  }

  private String buildSubdirectory(String[] directoryList, int end) {
    StringBuffer out = new StringBuffer();
    for (int idx = 1; idx <= end; idx++) {
      out.append(directoryList[idx]);
      if (idx != end) {
        out.append("/");
      }
    }
    return out.toString();
  }

  private void createDirectory(String SingleDirectoryName) throws DocumentManagerException {

    //ToDo: parse error response better see http://ronaldlemmen.blogspot.com/2010/04/sharepoint-error-message-0x8107026f.html for error code definitions
    Lists service = null;
    try {
      service = new Lists(new URL(SITE_NAME + "/_vti_bin/Lists.asmx?WSDL"));
    } catch (MalformedURLException e) {
      throw new DocumentManagerException(
          "Something bad happened during the creation of the directory(" + SingleDirectoryName + "): \"" +
              e.getMessage() + "\"", e);
    }
    ListsSoap listsSoap = service.getListsSoap();
    System.out.println("baseName = " + SingleDirectoryName);
    String strBatch = "<Batch OnError=\"Continue\" PreCalc=\"TRUE\" \n" +
        "ListVersion=\"0\" \n" +
        "ViewName=\"\">\n" +
        "   <Method ID=\"1\" Cmd=\"New\">\n" +
        "      <Field Name=\"ID\">New</Field>\n" +
        "      <Field Name=\"FSObjType\">1</Field>\n" +
        "      <Field Name=\"BaseName\">" + SingleDirectoryName + "</Field>\n" +
        "   </Method>\n" +
        "</Batch>";
    Document document = null;
    try {
      document = DOMUtil.newDocumentFromXML(strBatch);
    } catch (IOException e) {
      throw new DocumentManagerException(
          "Something bad happened during the creation of the directory(" + SingleDirectoryName + "): \"" +
              e.getMessage() + "\"", e);
    } catch (ParserException e) {
      throw new DocumentManagerException(
          "Something bad happened during the creation of the directory(" + SingleDirectoryName + "): \"" +
              e.getMessage() + "\"", e);
    }
    UpdateListItems.Updates updates = new UpdateListItems.Updates();
    List<Object> content = updates.getContent();
    content.add(document.getDocumentElement());
    UpdateListItemsResponse.UpdateListItemsResult listItemsResult = null;
    try {
      listItemsResult = listsSoap.updateListItems("ScannedImages", updates);
      parseResult(listItemsResult);
    } catch (SOAPFaultException e) {
      SOAPFault fault = e.getFault();
      StringBuilder fullErrorMessage = new StringBuilder();
      String errorMessageLineOne =
          "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: e.getMessage() = " + e.getMessage() +
              "\n";
      System.out.print(
          errorMessageLineOne);
      Detail detail = fault.getDetail();
      String errorMessageLineTwo =
          "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: detail.toString() = " +
              detail.toString() +
              "\n";
      System.out.print(
          errorMessageLineTwo);
      String errorMessageLineThree =
          "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: detail.getValue() = " +
              detail.getValue() +
              "\n";
      System.out.print(
          errorMessageLineThree);
      fullErrorMessage = fullErrorMessage.append(errorMessageLineOne).append(errorMessageLineTwo)
          .append(errorMessageLineThree);
      Iterator entries = detail.getDetailEntries();
      while (entries.hasNext()) {
        Object o = entries.next();
        String soapFaultDetailMessage =
            "fault detail entry.toString() = " + o.toString() + "\n";
        fullErrorMessage = fullErrorMessage.append(soapFaultDetailMessage);
        System.out
            .print(soapFaultDetailMessage);
      }
      String faultActorMessage =
          "fault.getFaultActor() = " +
              fault.getFaultActor() + "\n";
      System.out.print(faultActorMessage);
      String faultCodeMessage =
          "fault.getFaultCode() = " +
              fault.getFaultCode() + "\n";
      System.out.print(faultCodeMessage);
      String faultStringMessage =
          "fault.getFaultString() = " +
              fault.getFaultString() + "\n";
      System.out.print(faultStringMessage);
      String exceptionMessage = "e.getMessage() = " + e.getMessage() + "\n";
      System.out
          .print(exceptionMessage);
      fullErrorMessage = fullErrorMessage.append(faultActorMessage).append(faultCodeMessage).append(faultStringMessage);
      System.out.println("fullErrorMessage = " + fullErrorMessage);
      throw new DocumentManagerException(
          "something went bad while creating directory " + SingleDirectoryName + ":" + fullErrorMessage, e);
    }
  }

  private boolean isSubdirectoryPresent(String directory) {
    return (-1 != directory.indexOf("/"));
  }

  private String[] createSubdirectoryList(String directoryStructure, String docRoot) {
    String[] directoryList = directoryStructure.split("/");
    int directoryListLength = directoryList.length;
    String[] parentDirectoryList = new String[directoryListLength + 1];
//    parentDirectoryList[0] = docRoot;
    System.arraycopy(directoryList, 0, parentDirectoryList, 1, directoryList.length);
    return parentDirectoryList;
  }


  private void uploadDocumentWithCheckout_SubsequentVersion(String destUrl, String fileName, CopySoap copySoap) throws
      IOException {
    ListsSoap listsSoap = setupListsService();
    boolean success = listsSoap.checkOutFile(destUrl + fileName, "true", null);
    System.out.println("SharepointServices_SPIKE.testUploadDocument_WithNewVersion: success = " + success);
    DestinationUrlCollection destUrls = setupDestinationUrls(SITE_NAME + "/" + DOCUMENT_LIBRARY_NAME + "/",
        "apptestFile.doc");
    byte[] stream = FileUtil
        .fileToByteArray("com/monsanto/tcc/documentmanagementserver_version2/apptests/apptestfile.doc");
    FieldInformationCollection fields = new FieldInformationCollection();
    List<FieldInformation> fieldInformationList = fields.getFieldInformation();
    addFieldToList(fieldInformationList, "Publisher", "TestPublisherValue");
    Holder<Long> result = new Holder<Long>();
    Holder<CopyResultCollection> results = new Holder<CopyResultCollection>();
    copySoap.copyIntoItems(destUrls.getString().get(0), destUrls, fields, stream, result, results);
    parseCopyResult(results);
    boolean checkinSuccess = listsSoap.checkInFile(destUrl + fileName, "the next version", "1");
    System.out
        .println("SharepointServices_SPIKE.testUploadDocument_WithNewVersion: checkinSuccess = " + checkinSuccess);
  }

  private void parseCopyResult(Holder<CopyResultCollection> results) {
    List<CopyResult> resultsList = results.value.getCopyResult();
    for (int i = 0; i < resultsList.size(); i++) {
      CopyResult copyResult = resultsList.get(i);
      System.out.println(
          "SharePointTestUtil.parseCopyResult: copyResult.getDestinationUrl() = " + copyResult.getDestinationUrl());
      System.out.println(
          "SharePointTestUtil.parseCopyResult: copyResult.getErrorMessage() = " + copyResult.getErrorMessage());
      System.out.println("SharePointTestUtil.parseCopyResult: copyResult.getErrorCode().value() = " +
          copyResult.getErrorCode().value());
    }
  }

  private void addFieldToList(List<FieldInformation> fieldInformationList, String name, String value) {
    FieldInformation fieldInformation = new FieldInformation();
    fieldInformation.setDisplayName(name);
    fieldInformation.setValue(value);
    fieldInformation.setInternalName(name);
    fieldInformation.setType(FieldType.TEXT);
    fieldInformationList.add(fieldInformation);
  }

  private void listOutDocumentVersions(String fileName) throws MalformedURLException {
    VersionsSoap versionsSoap = createVersionsService(SITE_NAME + "/_vti_bin/versions.asmx?WSDL");
    String urlToPassToVersionsService = SITE_NAME + "/" + DOCUMENT_LIBRARY_NAME + "/" + fileName;
    System.out.println("urlToPassToVersionsService = " + urlToPassToVersionsService);
    GetVersionsResponse.GetVersionsResult getVersionsResult = versionsSoap
        .getVersions(urlToPassToVersionsService);
    List<Object> versions = getVersionsResult.getContent();
    System.out.println("SharepointServices_SPIKE.testUploadDocument: versions.size() = " + versions.size());
    for (Object version : versions) {
      System.out.println("Next Version in List");
      Element element = (Element) version;
      DOMUtil.outputXML(element);
      NodeList list = element.getElementsByTagName("result");
      System.out.println("SharepointServices_SPIKE.testUploadDocument: list.getLength() = " + list.getLength());
      for (int j = 0; j < list.getLength(); j++) {
        Node node = list.item(j);
        System.out.println("SharepointServices_SPIKE.testUploadDocument: node.getNodeName() = " + node.getNodeName());
        NamedNodeMap map = node.getAttributes();
        for (int k = 0; k < map.getLength(); k++) {
          Node attrNode = map.item(k);
          System.out
              .println(
                  "SharepointServices_SPIKE.testUploadDocument: attrNode.getNodeName() = " + attrNode.getNodeName());
          System.out.println(
              "SharepointServices_SPIKE.testUploadDocument: attrNode.getNodeValue() = " + attrNode.getNodeValue());
        }
      }
    }
  }

  private String getID(String fileName) throws IOException, ParserException {
    ListsSoap listsSoap = setupListsService();
    String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
        "<Query>" +
        "<Where>" +
        "<Contains>" +
        "<FieldRef Name='FileRef' />" +
        "<Value Type='Text'>" + DOCUMENT_LIBRARY_NAME + "/" + fileName + "</Value>" +
        "</Contains>" +
        "</Where>" +
        "</Query>";
    Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
    GetListItems.Query query = new GetListItems.Query();
    List<Object> content = query.getContent();
    content.add(queryDoc.getDocumentElement());
    GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
        .getListItems(DOCUMENT_LIBRARY_NAME, "", query, null, null, null, "");
    Element listResult = (Element) scannedImagesResult.getContent().get(0);
    DOMUtil.outputXML(listResult);
    NodeList list = listResult.getElementsByTagName("z:row");
    int length = list.getLength();
    System.out.println("NodeList.getLength() = " + length);
    NamedNodeMap attributes = list.item(0).getAttributes();
    return attributes.getNamedItem("ows_i_chronicle_id").getNodeValue();
  }

  public void testInvestigateSubfoldersSearch() throws Exception {
    List results = findIdByName("test subfolder doc");
    System.out.println("results = " + results);
//    findIdByNameSubfolders("test UI Created doc");
  }

  public List findIdByName(String name) throws
      DocumentManagerException {
    List IDs = null;
    try {
      ListsSoap listsSoap = setupListsService();

      String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
          "<Query>" +
          "<Where>" +
          "<Contains>" +
          "<FieldRef Name='object_name' />" +
          "<Value Type='Text'>" + name + "</Value>" +
          "</Contains>" +
          "</Where>" +
          "</Query>";
      String strOptions =
          "<?xml version='1.0' encoding='UTF-8'?>" + "<QueryOptions>" + "<ViewAttributes Scope='Recursive'/>" +
              "</QueryOptions>";
      Document queryDoc = null;
      Document optionsDoc = null;
      queryDoc = DOMUtil.newDocumentFromXML(strQuery);
      optionsDoc = DOMUtil.newDocumentFromXML((strOptions));
      GetListItems.Query query = new GetListItems.Query();
      List<Object> content = query.getContent();
      content.add(queryDoc.getDocumentElement());
      GetListItems.QueryOptions queryOptions = new GetListItems.QueryOptions();
      List<Object> optionsContent = queryOptions.getContent();
      optionsContent.add(optionsDoc.getDocumentElement());

      GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
          .getListItems(DOCUMENT_LIBRARY_NAME, "", query, null, null, queryOptions, "");
      Element listResult = (Element) scannedImagesResult.getContent().get(0);
      NodeList list = listResult.getElementsByTagName("z:row");
      int length = list.getLength();
//    System.out.println("NodeList.getLength() = " + length);
//    NamedNodeMap attributes = list.item(0).getAttributes();
      IDs = new ArrayList(length);
      for (int i = 0; i < length; i++) {
        IDs.add(list.item(i).getAttributes().getNamedItem("ows_ID").getNodeValue());
      }
    } catch (IOException e) {
      throw new DocumentManagerException("Problem querying Document Library", e);
    } catch (ParserException e) {
      throw new DocumentManagerException("Problem querying Document Library", e);
    } catch (SOAPFaultException e) {
      String soapfaultmessage = e.getMessage();
      System.out.println("soapfaultmessage = \"" + soapfaultmessage + "\"\nStacktrace:\"");
      e.printStackTrace();
      System.out.println("\n\"");
    }
    return IDs;

  }

  public void testStringParsing() throws Exception {
    String siteName = "http://na1000spdev60/teamsite";
    URL siteUrl = new URL(siteName);
    String owsFileRef = "6399;#teamsite/ScannedImages/apptestFile.txt";
    String textToGetToTheRightOf = ";#";
    String FullPathPlusFileOnly = owsFileRef
        .substring(owsFileRef.lastIndexOf(textToGetToTheRightOf) + textToGetToTheRightOf.length());
    String portIfSpecified = siteUrl.getPort() != -1 ? new Integer(siteUrl.getPort()).toString() : "";
    String completeFullPath =
        siteUrl.getProtocol() + "://" + siteUrl.getHost() + ":" + portIfSpecified + "/" + FullPathPlusFileOnly;
    System.out.println("completeFullPath = " + completeFullPath);
    assertEquals("not quite :(", "http://na1000spdev60:/teamsite/ScannedImages/apptestFile.txt", completeFullPath);
  }

  private String getFileName(String id) throws IOException, ParserException {
    ListsSoap listsSoap = setupListsService();
    String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
        "<Query>" +
        "<Where>" +
        "<Contains>" +
        "<FieldRef Name='ID' />" +
        "<Value Type='counter'>" + id + "</Value>" +
        "</Contains>" +
        "</Where>" +
        "</Query>";
    Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
    GetListItems.Query query = new GetListItems.Query();
    List<Object> content = query.getContent();
    content.add(queryDoc.getDocumentElement());
    GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
        .getListItems(DOCUMENT_LIBRARY_NAME, "", query, null, null, null, "");
    Element listResult = (Element) scannedImagesResult.getContent().get(0);
    NodeList list = listResult.getElementsByTagName("z:row");
    NamedNodeMap attributes = list.item(0).getAttributes();
    String owsFileRef = attributes.getNamedItem("ows_FileRef").getNodeValue();
    return owsFileRef.substring(owsFileRef.lastIndexOf("/") + 1);
  }


  private void deleteDocumentOrFolder(String destUrl, String fileName) throws IOException, ParserException {
    System.out.println("SharepointServices_SPIKE.deleteDocument");
    System.out.println("destUrl = " + destUrl);
    System.out.println("fileName = " + fileName);
    Lists service = new Lists(new URL(SITE_NAME + "/_vti_bin/Lists.asmx?WSDL"));
    ListsSoap listsSoap = service.getListsSoap();
    String fileRef = destUrl + fileName;
    System.out.println("fileRef = " + fileRef);
    String strBatch = "<?xml version='1.0' encoding='UTF-8'?><Batch><Method ID='1' Cmd='Delete'>" +
        "<Field Name='ID' />" +
        "<Field Name='FileRef'>" + fileRef +
        "</Field></Method></Batch>";
    Document document = DOMUtil.newDocumentFromXML(strBatch);
    UpdateListItems.Updates updates = new UpdateListItems.Updates();
    List<Object> content = updates.getContent();
    content.add(document.getDocumentElement());
    UpdateListItemsResponse.UpdateListItemsResult listItemsResult = null;
    try {
      listItemsResult = listsSoap.updateListItems("ScannedImages", updates);
      parseResult(listItemsResult);
    } catch (SOAPFaultException e) {
      SOAPFault fault = e.getFault();
      System.out.println(
          "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: e.getMessage() = " + e.getMessage());
      Detail detail = fault.getDetail();
      System.out.println(
          "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: detail.toString() = " +
              detail.toString());
      System.out.println(
          "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: detail.getValue() = " +
              detail.getValue());
      Iterator entries = detail.getDetailEntries();
      while (entries.hasNext()) {
        Object o = entries.next();
        System.out
            .println(
                "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: o.toString() = " + o.toString());
      }
      System.out
          .println("SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: fault.getFaultActor() = " +
              fault.getFaultActor());
      System.out.println("SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: fault.getFaultCode() = " +
          fault.getFaultCode());
      System.out
          .println("SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: fault.getFaultString() = " +
              fault.getFaultString());
      System.out
          .println(
              "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: e.toString() = " + e.toString());
    }
  }

  private void deleteDocumentByID(String id) throws IOException, ParserException {
    String fileName = getFileName(id);
    System.out.println("SharepointServices_SPIKE.deleteDocumentByID: fileName = " + fileName);
    Lists service = new Lists(new URL(SITE_NAME + "/_vti_bin/Lists.asmx?WSDL"));
    ListsSoap listsSoap = service.getListsSoap();
    String strBatch = "<?xml version='1.0' encoding='UTF-8'?><Batch><Method ID='1' Cmd='Delete'>" +
        "<Field Name='ID'>" + id + "</Field>" +
        "<Field Name='FileRef'>" + destUrl + fileName +
        "</Field>" +
        "</Method></Batch>";
    System.out.println("SharepointServices_SPIKE.deleteDocumentByID: strBatch = " + strBatch);
    Document document = DOMUtil.newDocumentFromXML(strBatch);
    UpdateListItems.Updates updates = new UpdateListItems.Updates();
    List<Object> content = updates.getContent();
    content.add(document.getDocumentElement());
    UpdateListItemsResponse.UpdateListItemsResult listItemsResult = null;
    try {
      listItemsResult = listsSoap.updateListItems("ScannedImages", updates);
      parseResult(listItemsResult);
    } catch (SOAPFaultException e) {
      //ToDo: Figure out the real error message stuff
      SOAPFault fault = e.getFault();
      System.out.println(
          "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: e.getMessage() = " + e.getMessage());
      Detail detail = fault.getDetail();
      System.out.println(
          "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: detail.toString() = " +
              detail.toString());
      System.out.println(
          "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: detail.getValue() = " +
              detail.getValue());
      Iterator entries = detail.getDetailEntries();
      while (entries.hasNext()) {
        Object o = entries.next();
        System.out
            .println(
                "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: o.toString() = " + o.toString());
      }
      System.out
          .println("SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: fault.getFaultActor() = " +
              fault.getFaultActor());
      System.out.println("SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: fault.getFaultCode() = " +
          fault.getFaultCode());
      System.out
          .println("SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: fault.getFaultString() = " +
              fault.getFaultString());
      System.out
          .println(
              "SharepointServices_SPIKE.testUploadDocument_ThenDeleteSameDocument: e.toString() = " + e.toString());
    }
  }

  private Element parseResult(UpdateListItemsResponse.UpdateListItemsResult listItemsResult) {
    Element result = (Element) listItemsResult.getContent().get(0);
    NodeList list = result.getElementsByTagName("Result");
    System.out.println("SharepointServices_SPIKE.parseResult: list.getLength() = " + list.getLength());
    for (int j = 0; j < list.getLength(); j++) {
      Node node = list.item(j);
      System.out.println("SharepointServices_SPIKE.parseResult: node.getNodeName() = " + node.getNodeName());
      listAttributes(node);
      NodeList children = node.getChildNodes();
      for (int k = 0; k < children.getLength(); k++) {
        listValue(children.item(k));
        listAttributes(children.item(k));
      }
    }
    return result;
  }

  private void listValue(Node node) {
    System.out.println("SharepointServices_SPIKE.listValue: node.getNodeName() = " + node.getNodeName());
    System.out.println("SharepointServices_SPIKE.listValue: node.getNodeValue() = " + node.getTextContent());
  }

  private void listAttributes(Node node) {
    NamedNodeMap map = node.getAttributes();
    System.out.println("SharepointServices_SPIKE.listAttributes: map.getLength() = " + map.getLength());
    for (int k = 0; k < map.getLength(); k++) {
      Node attrNode = map.item(k);
      System.out.println("SharepointServices_SPIKE.listAttributes: attrNode.getNodeName() = " + attrNode.getNodeName());
      System.out
          .println("SharepointServices_SPIKE.listAttributes: attrNode.getNodeValue() = " + attrNode.getNodeValue());
    }
  }

  private ListsSoap setupListsService() throws MalformedURLException {
    MyInterceptor interceptor = new MyInterceptor();
    Lists service = new Lists(new URL(SITE_NAME + "/_vti_bin/Lists.asmx?WSDL"));
    ListsSoap listsSoap = service.getListsSoap();
    Client cxfClient = ClientProxy.getClient(listsSoap);
    cxfClient.getInInterceptors().add(interceptor);
    turnOffChunkingForNTLM(listsSoap);
    return listsSoap;
  }

  private CopySoap uploadDocumentToSharepoint(String destUrl, String fileName, String documentToUpload) throws
      IOException {
    CopySoap copySoap = createCopyService(SITE_NAME + "/_vti_bin/Copy.asmx?WSDL");
    DestinationUrlCollection destUrls = setupDestinationUrls(destUrl, fileName);
    FieldInformationCollection fields = new FieldInformationCollection();
    List<FieldInformation> fieldInformationList = fields.getFieldInformation();
    addFieldToList(fieldInformationList, "Publisher", "TestPublisherValue");
    byte[] stream = FileUtil.fileToByteArray(documentToUpload);
    Holder<Long> result = new Holder<Long>();
    Holder<CopyResultCollection> results = new Holder<CopyResultCollection>();
    copySoap.copyIntoItems(destUrls.getString().get(0), destUrls, fields, stream, result, results);
    List<CopyResult> copyResults = results.value.getCopyResult();
    assertEquals("Ensure that the document wasn't already in Sharepoint", "Success",
        copyResults.get(0).getErrorCode().value());
    return copySoap;
  }

  private CopySoap createCopyService(String wsdlLocation) throws MalformedURLException {
    Copy service = new Copy(new URL(wsdlLocation));
    CopySoap copySoap = service.getCopySoap();
    turnOffChunkingForNTLM(copySoap);
    return copySoap;
  }

  private VersionsSoap createVersionsService(String wsdlLocation) throws MalformedURLException {
    Versions service = new Versions(new URL(wsdlLocation));
    VersionsSoap versionsSoap = service.getVersionsSoap();
    turnOffChunkingForNTLM(versionsSoap);
    return versionsSoap;
  }

  public void testPlayWithDWSService() throws Exception {
    //Nevermind, this code does createa a new Document Workspace; the users didn't work & we have no desire to use Document Workspaces; it appears the DWS service is not useful
    Dws service = new Dws(new URL(SITE_NAME + "/_vti_bin/dws.asmx?wsdl"));
    DwsSoap dwsSoap = service.getDwsSoap();
    dwsSoap.createDws("test DWS", "lakench, mecoru, dabrawl", "Test DWS Title", "");
  }

  private DestinationUrlCollection setupDestinationUrls(String scannedImagesUrl, String fileName) {
    DestinationUrlCollection destUrls = new DestinationUrlCollection();
    List<String> urlList = destUrls.getString();
    String documentDestinationUrl = scannedImagesUrl + fileName;
    urlList.add(documentDestinationUrl);
    return destUrls;
  }

  private ArrayList<String> getColumnNameList() {
    ArrayList<String> listColumnNames = new ArrayList<String>();
    listColumnNames.add("Publisher");
//    listColumnNames.add("_CopySource");
    return listColumnNames;
  }

  private void parseAndDisplayListItems(ArrayList<String> listColumnNames, Object listResult) throws Exception {
    if ((listResult != null) && (listResult instanceof ElementNSImpl)) {
      ElementNSImpl node = (ElementNSImpl) listResult;
      Document document = node.getOwnerDocument();
      System.out.println("SharePoint Online Lists Web Service Response:" + DOMUtil.XMLToString(document));
      NodeList list = node.getElementsByTagName("z:row");
      System.out.println("=> " + list.getLength() + " results from SharePoint Online");
      for (int i = 0; i < list.getLength(); i++) {
        NamedNodeMap attributes = list.item(i).getAttributes();
        System.out.println("******** Item ID: " + attributes.getNamedItem("ows_ID").getNodeValue() + " ********");
        for (String columnName : listColumnNames) {
          String internalColumnName = "ows_" + columnName;
          if (attributes.getNamedItem(internalColumnName) != null) {
            System.out.println(columnName + ": " + attributes.getNamedItem(internalColumnName).getNodeValue());
          } else {
            throw new Exception("Couldn't find the '" + columnName + "' column in the list in SharePoint.\n");
          }
        }
      }
    } else {
      throw new Exception(" list response from SharePoint is either null or corrupt\n");
    }
  }

  private void turnOffChunkingForNTLM(Object port) throws MalformedURLException {
    jcifs.Config.setProperty("jcifs.smb.client.domain", "monsanto.com");
    jcifs.Config.setProperty("jcifs.netbios.wins", "xxx.xxx.xxx.xxx");
    jcifs.Config.setProperty("jcifs.smb.client.soTimeout", "300000"); //5 minutes
    jcifs.Config.setProperty("jcifs.netbios.cachePolicy", "1200"); //20 minutes
    jcifs.Config.registerSmbURLHandler();
    Client client = ClientProxy.getClient(port);
    HTTPConduit http = (HTTPConduit) client.getConduit();
    HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
    httpClientPolicy.setConnectionTimeout(36000);
    httpClientPolicy.setAllowChunking(false);
    http.setClient(httpClientPolicy);
  }

  static class MyInterceptor extends AbstractPhaseInterceptor<Message> {

    public MyInterceptor() {
      super(Phase.POST_STREAM);
      System.out.println("SharepointServices_SPIKE$MyInterceptor.MyInterceptor");
      getBefore().add(StaxInInterceptor.class.getName());
      System.out.println("Interceptor Installed");
    }

    public void handleMessage(Message msg) throws org.apache.cxf.interceptor.Fault {
      System.out.println("SharepointServices_SPIKE$MyInterceptor.handleMessage");
      InputStream is = msg.getContent(InputStream.class);
      assert is != null;
      try {
        byte[] byteContent = IOUtils.readBytesFromStream(is);
        msg.setContent(InputStream.class, new ByteArrayInputStream(byteContent));
//				String encoding = (String) msg.get(Message.ENCODING);
//				System.out.println("SharepointServices_SPIKE$MyInterceptor.handleMessage: encoding = " + encoding);
//				String originalXML = new String(byteContent, encoding);
//				System.out.println("SharepointServices_SPIKE$MyInterceptor.handleMessage: originalXML = " + originalXML);


      } catch (Exception e) {
        e.printStackTrace();
      }

    }
  }

}