package com.monsanto.tcc.dcm.business.impl;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import static org.mockito.Mockito.*;

/**
 * rlcasw - May 28, 2010 1:50:50 PM
 */
public class DFCServicesFactory_UT
{
   @Test
   public void testBuildDFCServices() throws Exception{
      ServiceLookup serviceLookup = mock(ServiceLookup.class);
      ConnectionInfo connectionInfo = new ConnectionInfo();
      connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_DOCBROKER,"docbroker");
      connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_USERNAME,"username");
      connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_PASSWORD,"password");
      connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_DOCBASE,"docbase");
      connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_CABINET,"cabinet");
      connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_OBJECT_TYPE,"objectType");


      when(serviceLookup.getConnectionDetails(anyString(),anyString())).thenReturn(connectionInfo);

      DFCServicesFactory factory = new DFCServicesFactory(serviceLookup);

      IDFCServices services = factory.buildDFCServices("folder");
      assertNotNull(services);
   }
}
