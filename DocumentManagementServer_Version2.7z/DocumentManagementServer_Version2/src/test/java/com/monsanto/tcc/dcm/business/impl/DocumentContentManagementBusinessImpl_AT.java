package com.monsanto.tcc.dcm.business.impl;

import com.monsanto.tcc.dcm.transfer.Document;
import com.monsanto.tcc.dcm.transfer.DocumentContent;
import com.monsanto.tcc.dcm.transfer.DocumentDetail;
import com.monsanto.tcc.dcm.transfer.FieldTypeValue;
import com.monsanto.tcc.dcm.transfer.FieldValue;
import com.monsanto.tcc.dcm.transfer.FieldValues;
import com.monsanto.tcc.dcm.transfer.Reference;
import com.monsanto.tcc.dcm.transfer.SearchField;
import com.monsanto.tcc.dcm.transfer.SearchFields;
import com.monsanto.tcc.dcm.transfer.SearchRequest;
import com.monsanto.tcc.dcm.transfer.SearchResult;
import com.monsanto.tcc.dcm.transfer.ViewField;
import com.monsanto.tcc.dcm.transfer.ViewFields;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.DocumentumQueryBuilder;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Collection;

/**
 * rlcasw - May 26, 2010 3:21:19 PM
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {

	"classpath:/com/monsanto/tcc/dcm/contexts/services-context.xml"
})
public class DocumentContentManagementBusinessImpl_AT
{
public static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";
   @Test
   public void testOperations() throws Exception{
      Reference reference = create();
      testSearch(reference);
      Reference latestReference = update(reference);
      testGetLatestInfo(reference,latestReference);
      testDeleteLatest(reference,latestReference);
      updateTakesReference(reference);
      retrieve(reference);
      retrieveContent(reference);
      testRetrieveDetails(reference);

      testDelete(reference);

  
   }

  
     public Reference create() throws Exception{
        ServiceLookup serviceLookup = new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
        DFCServicesFactory servicesFactory = new DFCServicesFactory(serviceLookup);
        DocumentumQueryBuilder queryBuilder = new DocumentumQueryBuilder();
        DocumentContentManagementBusinessImpl business = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

        String suffix = "txt";
        File tmpFile = createTempFile(suffix);
        DataHandler content = createDocumentAttachment(tmpFile);

        FieldValues fieldValues = new FieldValues();
        FieldValue fieldValue = new FieldValue();
        fieldValue.setFieldName("subject");
        fieldValue.setFieldValue("testCXFService subject");
        fieldValues.addFieldValue(fieldValue);
        return  business.create("/COVAR/cxftest/testCXFService3.txt",true,content,fieldValues);

     }



   public Reference update(Reference inReference) throws Exception{
      Reference reference = new Reference();
      reference.setDocumentId(inReference.getDocumentId());
      ServiceLookup serviceLookup = new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
      DFCServicesFactory servicesFactory = new DFCServicesFactory(serviceLookup);
      DocumentumQueryBuilder queryBuilder = new DocumentumQueryBuilder();
      DocumentContentManagementBusinessImpl business = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      String suffix = "txt";
      File tmpFile = createTempFile(suffix,"The quick brown fox jumps over the lazy dog update.");
      DataHandler content = createDocumentAttachment(tmpFile);

      FieldValues fieldValues = new FieldValues();
      FieldValue fieldValue = new FieldValue();
      fieldValue.setFieldName("subject");
      fieldValue.setFieldValue("testCXFService subject update");
      fieldValues.addFieldValue(fieldValue);
      return business.update(reference.getDocumentId(),false,content,fieldValues);

   }




   public void updateTakesReference(Reference inReference) throws Exception{
      Reference reference = new Reference();
      reference.setDocumentId(inReference.getDocumentId());
      ServiceLookup serviceLookup = new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
      DFCServicesFactory servicesFactory = new DFCServicesFactory(serviceLookup);
      DocumentumQueryBuilder queryBuilder = new DocumentumQueryBuilder();
      DocumentContentManagementBusinessImpl business = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      String suffix = "txt";
      File tmpFile = createTempFile(suffix,"The quick brown fox jumps over the lazy dog update2.");
      DataHandler content = createDocumentAttachment(tmpFile);

      FieldValues fieldValues = new FieldValues();
      FieldValue fieldValue = new FieldValue();
      fieldValue.setFieldName("subject");
      fieldValue.setFieldValue("testCXFService subject update");
      fieldValues.addFieldValue(fieldValue);

     business.update(reference,content,fieldValues);

   }


   public void testDelete(Reference inReference) throws Exception{
      ServiceLookup serviceLookup = new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
      DFCServicesFactory servicesFactory = new DFCServicesFactory(serviceLookup);
      DocumentumQueryBuilder queryBuilder = new DocumentumQueryBuilder();
      DocumentContentManagementBusinessImpl business = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      Reference reference = new Reference();
      reference.setDocumentId(inReference.getDocumentId());
      business.deleteAll(inReference.getDocumentId());
      
   }


  
   public String retrieve(Reference inReference) throws Exception{
      Reference reference = new Reference();
      reference.setDocumentId(inReference.getDocumentId());
      ServiceLookup serviceLookup = new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
      DFCServicesFactory servicesFactory = new DFCServicesFactory(serviceLookup);
      DocumentumQueryBuilder queryBuilder = new DocumentumQueryBuilder();
      DocumentContentManagementBusinessImpl business = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);




      ViewFields viewFields = new ViewFields();
      ViewField viewField = new ViewField();
      viewField.setName("subject");
      viewFields.getViewFields().add(viewField);
      Collection<Document> documents =  business.retrieve(Arrays.asList(reference),viewFields);
      Document document = documents.iterator().next();
      FieldTypeValue ftv = document.getFieldTypeValues().getFieldTypeValues().iterator().next();
      assertEquals("subject",ftv.getName());
      assertEquals("testCXFService subject update",ftv.getValue());
      InputStream inputStream=document.getContents().getDataSource().getInputStream();
      byte []bytes = new byte[inputStream.available()];
      inputStream.read(bytes);
      String value = new String(bytes);
      assertEquals("The quick brown fox jumps over the lazy dog update2.",value);
      return value;
   }
   private File createTempFile(String suffix)
      throws IOException
   {
      File tmpFile = File.createTempFile("testAttachment", "." + suffix);

      OutputStream outStream = new FileOutputStream(tmpFile);
      PrintWriter pw = new PrintWriter(outStream);
      pw.write("The quick brown fox jumps over the lazy dog.");
      pw.close();
      tmpFile.deleteOnExit();
      return tmpFile;
   }
   private File createTempFile(String suffix, String text)
      throws IOException
   {
      File tmpFile = File.createTempFile("testAttachment", "." + suffix);

      OutputStream outStream = new FileOutputStream(tmpFile);
      PrintWriter pw = new PrintWriter(outStream);
      pw.write(text);
      pw.close();
      tmpFile.deleteOnExit();
      return tmpFile;
   }
   private DataHandler createDocumentAttachment(File file) {
      FileDataSource dataSource = new FileDataSource(file);
      return new DataHandler(dataSource);
   }

   public void retrieveContent(Reference inReference) throws Exception{
      Reference reference = new Reference();
      reference.setDocumentId(inReference.getDocumentId());
      ServiceLookup serviceLookup = new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
      DFCServicesFactory servicesFactory = new DFCServicesFactory(serviceLookup);
      DocumentumQueryBuilder queryBuilder = new DocumentumQueryBuilder();
      DocumentContentManagementBusinessImpl business = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);




      ViewFields viewFields = new ViewFields();
      ViewField viewField = new ViewField();
      viewField.setName("subject");
      viewFields.getViewFields().add(viewField);
      DocumentContent documentContent=  business.retrieveContent(reference);


      InputStream inputStream=documentContent.getContents().getDataSource().getInputStream();
      byte []bytes = new byte[inputStream.available()];
      inputStream.read(bytes);
      String value = new String(bytes);
      assertEquals("The quick brown fox jumps over the lazy dog update2.",value);
   }


    public void testRetrieveDetails(Reference reference) throws Exception{
      ServiceLookup serviceLookup = new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
      DFCServicesFactory servicesFactory = new DFCServicesFactory(serviceLookup);
      DocumentumQueryBuilder queryBuilder = new DocumentumQueryBuilder();
      DocumentContentManagementBusinessImpl business = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);




      ViewFields viewFields = new ViewFields();
      ViewField viewField = new ViewField();
      viewField.setName("subject");
      viewFields.getViewFields().add(viewField);
      Collection<DocumentDetail> documents =  business.retrieveDetails(Arrays.asList(reference),viewFields);
      DocumentDetail document = documents.iterator().next();
      FieldTypeValue ftv = document.getFieldTypeValues().getFieldTypeValues().iterator().next();
      assertEquals("subject",ftv.getName());
      assertEquals("testCXFService subject",ftv.getValue());

   }


   public void testSearch(Reference inReference) throws Exception{
      ServiceLookup serviceLookup = new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
      DFCServicesFactory servicesFactory = new DFCServicesFactory(serviceLookup);
      DocumentumQueryBuilder queryBuilder = new DocumentumQueryBuilder();
      DocumentContentManagementBusinessImpl business = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);
      SearchRequest searchRequest = new SearchRequest();
      searchRequest.setLocation("/COVAR/cxftest");
      SearchFields searchFields= new SearchFields();
      SearchField searchField = new SearchField();
      searchField.setName("subject");
      searchField.setValue("testCXFService subject");
      searchFields.setSearchFields(Arrays.asList(searchField));
      searchRequest.setSearchFields(searchFields);
      searchRequest.setSearchLatestVersion(true);

      ViewFields viewFields = new ViewFields();
      ViewField viewField = new ViewField();
      viewField.setName("subject");
      viewFields.getViewFields().add(viewField);

      searchRequest.setViewFields(viewFields);
      SearchResult searchResult =  business.search(searchRequest);
      assertEquals(1,searchResult.getDocumentDetails().size());
      assertEquals(inReference.getDocumentId(),searchResult.getDocumentDetails().iterator().next().getReference().getDocumentId());
   }
   public void testGetLatestInfo(Reference inReference,Reference lastReference) throws Exception{

      ServiceLookup serviceLookup = new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
      DFCServicesFactory servicesFactory = new DFCServicesFactory(serviceLookup);
      DocumentumQueryBuilder queryBuilder = new DocumentumQueryBuilder();
      DocumentContentManagementBusinessImpl business = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      ViewFields viewFields = new ViewFields();
      Reference lookupReference = new Reference();
      lookupReference.setDocumentId(inReference.getDocumentId());
      Collection<DocumentDetail> details = business.retrieveDetails(Arrays.asList(lookupReference),viewFields);
      assertEquals(1,details.size());
      assertEquals(lastReference.getDocumentId(),details.iterator().next().getReference().getDocumentId());
      assertEquals(lastReference.getVersion(),details.iterator().next().getReference().getVersion());
   }
    public void testDeleteLatest(Reference inReference,Reference lastReference) throws Exception{
       ServiceLookup serviceLookup = new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
       DFCServicesFactory servicesFactory = new DFCServicesFactory(serviceLookup);
       DocumentumQueryBuilder queryBuilder = new DocumentumQueryBuilder();
       DocumentContentManagementBusinessImpl business = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);
       business.deleteLatest(lastReference.getDocumentId());
       Reference latestReference = findLatestReference(inReference, business);
       assertEquals(inReference.getDocumentId(), latestReference.getDocumentId());
       assertEquals(inReference.getVersion(),latestReference.getVersion());
    }

   private Reference findLatestReference(Reference inReference, DocumentContentManagementBusinessImpl business) {
      ViewFields viewFields = new ViewFields();
      Reference lookupReference = new Reference();
      lookupReference.setDocumentId(inReference.getDocumentId());
      Collection<DocumentDetail> details = business.retrieveDetails(Arrays.asList(lookupReference),viewFields);
      assertEquals(1,details.size());
      Reference lastestReference = details.iterator().next().getReference();
      return lastestReference;
   }


}
