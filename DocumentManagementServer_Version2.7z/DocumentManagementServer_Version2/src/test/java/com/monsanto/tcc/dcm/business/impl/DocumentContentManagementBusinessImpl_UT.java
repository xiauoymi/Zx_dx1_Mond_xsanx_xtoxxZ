package com.monsanto.tcc.dcm.business.impl;

import com.monsanto.tcc.dcm.exception.NotFoundException;
import com.monsanto.tcc.dcm.exception.RequestException;
import com.monsanto.tcc.dcm.exception.FatalException;
import com.monsanto.tcc.dcm.transfer.Document;
import com.monsanto.tcc.dcm.transfer.DocumentContent;
import com.monsanto.tcc.dcm.transfer.DocumentDetail;
import com.monsanto.tcc.dcm.transfer.FieldTypeValue;
import com.monsanto.tcc.dcm.transfer.FieldValue;
import com.monsanto.tcc.dcm.transfer.FieldValues;
import com.monsanto.tcc.dcm.transfer.Reference;
import com.monsanto.tcc.dcm.transfer.SearchField;
import com.monsanto.tcc.dcm.transfer.SearchFields;
import com.monsanto.tcc.dcm.transfer.SearchFullText;
import com.monsanto.tcc.dcm.transfer.SearchOperator;
import com.monsanto.tcc.dcm.transfer.SearchRequest;
import com.monsanto.tcc.dcm.transfer.SearchResult;
import com.monsanto.tcc.dcm.transfer.ViewField;
import com.monsanto.tcc.dcm.transfer.ViewFields;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.DocumentumQueryBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumRequestEntity;
import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.mockito.stubbing.Stubber;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * rlcasw - May 27, 2010 2:20:20 PM
 */
public class DocumentContentManagementBusinessImpl_UT
{
   @Test
   public void testCreate() throws Exception{
      String folder = "folder";
      String path = "path";
      String fileName = "fileName.txt";
      String  location = "/"+folder+"/"+path+"/"+fileName;
      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";
      when(contents.getContentType()).thenReturn(mimeType);
      when(contents.getName()).thenReturn(fileName);

      FieldValue fieldValue = new FieldValue();
      String fieldName = "fieldName";
      fieldValue.setFieldName(fieldName);
      String fieldValueValue = "fieldValue";
      fieldValue.setFieldValue(fieldValueValue);
      FieldValues fieldValues= new FieldValues();
      fieldValues.addFieldValue(fieldValue);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);
      ArgumentCaptor<InsertDocumentumRequestEntity> requestEntityCaptor = ArgumentCaptor.forClass(InsertDocumentumRequestEntity.class);
      ArgumentCaptor<String> directoryStructureCaptor = ArgumentCaptor.forClass(String.class);
      ArgumentCaptor<String> tmpfilePathCaptor = ArgumentCaptor.forClass(String.class);

      RetrievedDocument retrievedDocument = mock(RetrievedDocument.class);

      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID,"objectId",DocumentManagerConstants.OPERATOR_EQUALS);
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,"version",DocumentManagerConstants.OPERATOR_EQUALS);
      when(retrievedDocument.getDocumentAttributes()).thenReturn(documentAttributes);
      when(services.saveDocument(any(InsertDocumentumRequestEntity.class),anyString(),anyString())).thenReturn(retrievedDocument);

      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);


      Reference  reference = businessImpl.create(location,true,contents,fieldValues);

      assertEquals(folder+"/objectId",reference.getDocumentId());
      assertEquals("version",reference.getVersion());
      verify(services).saveDocument(requestEntityCaptor.capture(),directoryStructureCaptor.capture(), tmpfilePathCaptor.capture());
      InsertDocumentumRequestEntity requestEntity =  requestEntityCaptor.getValue();
      assertEquals(fieldValue.getFieldValue(),requestEntity.getDocumentAttributes().getAttrValue(fieldName));
      assertEquals(fileName,requestEntity.getDocumentAttributes().getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_NAME));
      assertEquals(path,requestEntity.getDirectoryStructure());
      assertEquals(false, requestEntity.getRequestPDFRendition());
      assertEquals(folder,requestEntity.getFolderName());
      String tmpfilePath = tmpfilePathCaptor.getValue();
      assertTrue(tmpfilePath.startsWith(System.getProperty("java.io.tmpdir")));
      File file = new File(tmpfilePath);
      assertFalse(file.exists());
   }

   @Test
   public void testCreateThrowsExceptionOnBuildingServices() throws Exception{
      String folder = "folder";
      String path = "path";
      String fileName = "fileName.txt";
      String  location = "/"+folder+"/"+path+"/"+fileName;
      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";
      when(contents.getContentType()).thenReturn(mimeType);
      when(contents.getName()).thenReturn(fileName);

      FieldValue fieldValue = new FieldValue();
      String fieldName = "fieldName";
      fieldValue.setFieldName(fieldName);
      String fieldValueValue = "fieldValue";
      fieldValue.setFieldValue(fieldValueValue);
      FieldValues fieldValues= new FieldValues();
      fieldValues.addFieldValue(fieldValue);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);

      RuntimeException testException = new RuntimeException("test Exception");
      when(servicesFactory.buildDFCServices(anyString())).thenThrow(testException);

      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      try{
         businessImpl.create(location,true,contents,fieldValues);
      }
      catch(FatalException re){

         assertSame(testException,re.getCause());
         assertEquals(testException.getMessage(),re.getMessage());
      }
      verify(services,never()).connect();
   }

   @Test
   public void testCreateThrowsException() throws Exception{
      String folder = "folder";
      String path = "path";
      String fileName = "fileName.txt";
      String  location = "/"+folder+"/"+path+"/"+fileName;
      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";
      when(contents.getContentType()).thenReturn(mimeType);
      when(contents.getName()).thenReturn(fileName);

      FieldValue fieldValue = new FieldValue();
      String fieldName = "fieldName";
      fieldValue.setFieldName(fieldName);
      String fieldValueValue = "fieldValue";
      fieldValue.setFieldValue(fieldValueValue);
      FieldValues fieldValues= new FieldValues();
      fieldValues.addFieldValue(fieldValue);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);
      RuntimeException testException = new RuntimeException("test Exception");
      doThrow(testException).when(services).saveDocument((InsertDocumentumRequestEntity)anyObject(),anyString(),anyString());

      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      try{
         businessImpl.create(location,true,contents,fieldValues);
      }
      catch(FatalException re){

         assertSame(testException,re.getCause());
         assertEquals(testException.getMessage(),re.getMessage());
      }
      verify(services).rollbackTransaction();
   }



   @Test
   public void testCreatePDF() throws Exception{
      String folder = "folder";
      String path = "path";
      String fileName = "fileName.pdf";
      String  location = "/"+folder+"/"+path+"/"+fileName;
      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";
      when(contents.getContentType()).thenReturn(mimeType);
      when(contents.getName()).thenReturn(fileName);

      FieldValue fieldValue = new FieldValue();
      String fieldName = "fieldName";
      fieldValue.setFieldName(fieldName);
      String fieldValueValue = "fieldValue";
      fieldValue.setFieldValue(fieldValueValue);
      FieldValues fieldValues= new FieldValues();
      fieldValues.addFieldValue(fieldValue);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);
      ArgumentCaptor<InsertDocumentumRequestEntity> requestEntityCaptor = ArgumentCaptor.forClass(InsertDocumentumRequestEntity.class);
      ArgumentCaptor<String> directoryStructureCaptor = ArgumentCaptor.forClass(String.class);
      ArgumentCaptor<String> tmpfilePathCaptor = ArgumentCaptor.forClass(String.class);

      RetrievedDocument retrievedDocument = mock(RetrievedDocument.class);

      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID,"objectId",DocumentManagerConstants.OPERATOR_EQUALS);
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,"version",DocumentManagerConstants.OPERATOR_EQUALS);
      when(retrievedDocument.getDocumentAttributes()).thenReturn(documentAttributes);
      when(services.saveDocument(any(InsertDocumentumRequestEntity.class),anyString(),anyString())).thenReturn(retrievedDocument);
      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);


      Reference  reference = businessImpl.create(location,true,contents,fieldValues);

      assertEquals(folder+"/objectId",reference.getDocumentId());
      assertEquals("version",reference.getVersion());
      verify(services).saveDocument(requestEntityCaptor.capture(),directoryStructureCaptor.capture(), tmpfilePathCaptor.capture());
      InsertDocumentumRequestEntity requestEntity =  requestEntityCaptor.getValue();
      assertEquals(fieldValue.getFieldValue(),requestEntity.getDocumentAttributes().getAttrValue(fieldName));
      assertEquals(fileName,requestEntity.getDocumentAttributes().getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_NAME));
      assertEquals(path,requestEntity.getDirectoryStructure());
      assertEquals(true, requestEntity.getRequestPDFRendition());
      assertEquals(folder,requestEntity.getFolderName());
      String tmpfilePath = tmpfilePathCaptor.getValue();
      assertTrue(tmpfilePath.startsWith(System.getProperty("java.io.tmpdir")));
      File file = new File(tmpfilePath);
      assertFalse(file.exists());
   }
   @Test
   public void testCreateEmptyPath() throws Exception{
      String folder = "folder";

      String fileName = "fileName.pdf";
      String  location = "/"+folder+"/"+fileName;
      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";
      when(contents.getContentType()).thenReturn(mimeType);
      when(contents.getName()).thenReturn(fileName);

      FieldValue fieldValue = new FieldValue();
      String fieldName = "fieldName";
      fieldValue.setFieldName(fieldName);
      String fieldValueValue = "fieldValue";
      fieldValue.setFieldValue(fieldValueValue);
      FieldValues fieldValues= new FieldValues();
      fieldValues.addFieldValue(fieldValue);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);
      ArgumentCaptor<InsertDocumentumRequestEntity> requestEntityCaptor = ArgumentCaptor.forClass(InsertDocumentumRequestEntity.class);
      ArgumentCaptor<String> directoryStructureCaptor = ArgumentCaptor.forClass(String.class);
      ArgumentCaptor<String> tmpfilePathCaptor = ArgumentCaptor.forClass(String.class);

      RetrievedDocument retrievedDocument = mock(RetrievedDocument.class);

      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID,"objectId",DocumentManagerConstants.OPERATOR_EQUALS);
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,"version",DocumentManagerConstants.OPERATOR_EQUALS);
      when(retrievedDocument.getDocumentAttributes()).thenReturn(documentAttributes);
      when(services.saveDocument(any(InsertDocumentumRequestEntity.class),anyString(),anyString())).thenReturn(retrievedDocument);
      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);


      Reference  reference = businessImpl.create(location,true,contents,fieldValues);

      assertEquals(folder+"/objectId",reference.getDocumentId());
      assertEquals("version",reference.getVersion());
      verify(services).saveDocument(requestEntityCaptor.capture(),directoryStructureCaptor.capture(), tmpfilePathCaptor.capture());
      InsertDocumentumRequestEntity requestEntity =  requestEntityCaptor.getValue();
      assertEquals(fieldValue.getFieldValue(),requestEntity.getDocumentAttributes().getAttrValue(fieldName));
      assertEquals(fileName,requestEntity.getDocumentAttributes().getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_NAME));
      assertEquals("",requestEntity.getDirectoryStructure());
      assertEquals(true, requestEntity.getRequestPDFRendition());
      assertEquals(folder,requestEntity.getFolderName());
      String tmpfilePath = tmpfilePathCaptor.getValue();
      assertTrue(tmpfilePath.startsWith(System.getProperty("java.io.tmpdir")));
      File file = new File(tmpfilePath);
      assertFalse(file.exists());
   }

      @Test
   public void testDeleteAll() throws Exception{
      String objectId = "idvalue";
      String folder = "folder";



      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);

      ArgumentCaptor<String> objectIdCaptor = ArgumentCaptor.forClass(String.class);
      when(services.deleteAllVersionsById(anyString())).thenReturn(true);

      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      businessImpl.deleteAll(folder +"/" + objectId);

      verify(services).deleteAllVersionsById(objectIdCaptor.capture());
      assertEquals(objectId,objectIdCaptor.getValue());
   }

   @Test
   public void testDeleteAllThrowsException() throws Exception{
      String objectId = "idvalue";
      String folder = "folder";

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);


      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      RuntimeException testException = new RuntimeException("test Exception");
      doThrow(testException).when(services).connect();
      try{
          businessImpl.deleteAll(folder +"/" + objectId);
          fail();
      }
      catch(FatalException re){
         assertSame(testException,re.getCause());
         assertEquals(testException.getMessage(),re.getMessage());
      }
   }

   @Test

   public void testDeleteNoVersion() throws Exception{
      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";

      reference.setDocumentId(folder +"/" + objectId);


      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);


      when(services.deleteAllVersionsById(anyString())).thenReturn(true);

      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      try{
         businessImpl.delete(reference);
         fail();
      }
      catch(RequestException re){
         assertEquals(DocumentContentManagementBusinessImpl.VERSION_MISSING_ON_DELETE,re.getMessage());
      }

   }

   @Test
   public void testDeleteThrowsException() throws Exception{
      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";
      String version = "1.1";
      reference.setDocumentId(folder +"/" + objectId);
      reference.setVersion(version);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);


      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      RuntimeException testException = new RuntimeException("test Exception");
      doThrow(testException).when(services).connect();
      try{
          businessImpl.delete(reference);
          fail();
      }
      catch(FatalException re){
         assertSame(testException,re.getCause());
         assertEquals(testException.getMessage(),re.getMessage());
      }
   }
   @Test
   public void testDeleteThrowsExceptionOnBuildingServices() throws Exception{
      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";
      String version = "1.1";
      reference.setDocumentId(folder +"/" + objectId);
      reference.setVersion(version);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);

      RuntimeException testException = new RuntimeException("test Exception");
      when(servicesFactory.buildDFCServices(anyString())).thenThrow(testException);


      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);


      try{
         businessImpl.delete(reference);
         fail();
      }
      catch(FatalException re){
         assertSame(testException,re.getCause());
         assertEquals(testException.getMessage(),re.getMessage());
      }
   }

   @Test
   public void testDeleteThrowsNotFoundException() throws Exception{
      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";
      String version = "1.1";
      reference.setDocumentId(folder +"/" + objectId);
      reference.setVersion(version);


      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);


      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      RuntimeException testException = new RuntimeException("test Exception "+DocumentContentManagementBusinessImpl.DOES_NOT_EXIST);
      doThrow(testException).when(services).delete(anyString(),(DocumentAttributes)anyObject(),(ResponseEntity)anyObject());
      try{
          businessImpl.delete(reference);
          fail();
      }
      catch(NotFoundException re){
      
         assertSame(reference,re.getReference());
      }
   }

   @Test
   public void testDeleteWithVersion() throws Exception{
      Reference reference = new Reference();
      String objectId = "idvalue";
      String folder = "folder";
      String version = "1.2";
      reference.setDocumentId(folder +"/" + objectId);
      reference.setVersion(version);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);

      ArgumentCaptor<DocumentAttributes> documentAttributesCaptor = ArgumentCaptor.forClass(DocumentAttributes.class);
      ArgumentCaptor<ResponseEntity> responseEntityCaptor = ArgumentCaptor.forClass(ResponseEntity.class);

      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      businessImpl.delete(reference);

      verify(services).delete(eq(objectId), documentAttributesCaptor.capture(),responseEntityCaptor.capture());
      DocumentAttributes documentAttributes = documentAttributesCaptor.getValue();
      assertEquals(version,documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_VERSION));

      assertEquals(version,documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_VERSION) );
      assertNotNull( responseEntityCaptor.getValue());

   }
   @Test
   public void testDeleteNotFound() throws Exception{

      String objectId = "idvalue";
      String folder = "folder";
      String version = "1.1";
      Reference reference = new Reference();
      reference.setDocumentId(folder +"/" + objectId);
      reference.setVersion(version);


      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);


      doThrow(new RuntimeException("stuff and "+DocumentContentManagementBusinessImpl.DOES_NOT_EXIST)).when(services).delete(anyString(), (DocumentAttributes)anyObject(), (ResponseEntity)anyObject());

      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      try {
         businessImpl.delete(reference);
         fail();
      }
      catch (NotFoundException nfe){
         //This is correct behaviour
      }
   }

   @Test
   public void testRetrieve() throws Exception{
      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);


      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
        DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);
        Reference reference = new Reference();
       reference.setDocumentId("folder/objectId");
       reference.setVersion("version");

       ViewFields viewFields = new ViewFields();
       ViewField viewField = new ViewField();
       viewField.setName(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT);
       viewFields.getViewFields().add(viewField);

       RetrievedDocument retrievedDocument = new RetrievedDocument();

       File tmpFile = File.createTempFile("tmp","txt");
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS,
                                                              tmpFile.getPath(),
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT,
                                                              "subject",
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
      retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,
                                                             "version",
                                                             DocumentManagerConstants.OPERATOR_EQUALS);
      

       when(services.retrieveDocumentObjectWithAttributes(any(DocumentAttributes.class),any(List.class))).thenReturn(retrievedDocument);


      Collection<Document> documents = businessImpl.retrieve(Arrays.asList(reference),viewFields);

       ArgumentCaptor<DocumentAttributes> documentAttributesCaptor = ArgumentCaptor.forClass(DocumentAttributes.class);
      ArgumentCaptor<List> requiredAttributes  = ArgumentCaptor.forClass(List.class);
      verify(services).retrieveDocumentObjectWithAttributes(documentAttributesCaptor.capture(),requiredAttributes.capture());

      DocumentAttributes documentAttributes = documentAttributesCaptor.getValue();
      assertEquals("objectId",documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID));
      assertEquals("version",documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_VERSION));
      assertEquals(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT,requiredAttributes.getValue().get(0));

      assertEquals(1,documents.size());
      Document document = documents.iterator().next();

      FieldTypeValue ftv = document.getFieldTypeValues().getFieldTypeValues().iterator().next();
      assertEquals(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT,ftv.getName());
      assertEquals("subject",ftv.getValue());
   }

   @Test
   public void testRetrieveThrowsException() throws Exception{
      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);

      RuntimeException testException = new RuntimeException("test Exception");
      doThrow(testException).when(services).connect();

      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
        DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);
        Reference reference = new Reference();
       reference.setDocumentId("folder/objectId");
       reference.setVersion("version");

       ViewFields viewFields = new ViewFields();
       ViewField viewField = new ViewField();
       viewField.setName(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT);
       viewFields.getViewFields().add(viewField);






      try{
         businessImpl.retrieve(Arrays.asList(reference),viewFields);
         fail();
      }
      catch(FatalException re){
         assertSame(testException,re.getCause());
         assertEquals(testException.getMessage(),re.getMessage());
      }
      
   }

   @Test
   public void testRetrieveThrowsExceptionOnBuildingService() throws Exception{
      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      RuntimeException testException = new RuntimeException("test Exception");
      when(servicesFactory.buildDFCServices(anyString())).thenThrow(testException);



      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
        DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);
        Reference reference = new Reference();
       reference.setDocumentId("folder/objectId");
       reference.setVersion("version");

       ViewFields viewFields = new ViewFields();
       ViewField viewField = new ViewField();
       viewField.setName(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT);
       viewFields.getViewFields().add(viewField);






      try{
          businessImpl.retrieve(Arrays.asList(reference),viewFields);
      }
      catch(FatalException re){
         assertSame(testException,re.getCause());
         assertEquals(testException.getMessage(),re.getMessage());
      }
      verify(services,never()).connect();
   }


   @Test
   public void testRetrieveThrowsNotFoundException() throws Exception{
      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);

      RuntimeException testException = new RuntimeException("test Exception "+DocumentContentManagementBusinessImpl.DOES_NOT_EXIST);
      doThrow(testException).when(services).retrieveDocumentObjectWithAttributes((DocumentAttributes)anyObject(),(List)anyObject());

      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
        DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);
        Reference reference = new Reference();
       reference.setDocumentId("folder/objectId");
       reference.setVersion("version");

       ViewFields viewFields = new ViewFields();
       ViewField viewField = new ViewField();
       viewField.setName(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT);
       viewFields.getViewFields().add(viewField);




      try{
         businessImpl.retrieve(Arrays.asList(reference),viewFields);
      }
      catch(NotFoundException re){
         assertEquals(reference.getDocumentId(),re.getReference().getDocumentId());
         assertEquals(reference.getVersion(),re.getReference().getVersion());
      }
      verify(services).rollbackTransaction();
   }


   @Test
   public void testRetrieveContent() throws Exception{
      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);


       DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
       DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);
       Reference reference = new Reference();
       reference.setDocumentId("folder/objectId");
       reference.setVersion("version");

       ViewFields viewFields = new ViewFields();
       ViewField viewField = new ViewField();
       viewField.setName(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT);
       viewFields.getViewFields().add(viewField);

       RetrievedDocument retrievedDocument = new RetrievedDocument();

       File tmpFile = File.createTempFile("tmp","txt");
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS,
                                                              tmpFile.getPath(),
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT,
                                                              "subject",
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
      retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,
                                                             "version",
                                                             DocumentManagerConstants.OPERATOR_EQUALS);      

       when(services.retrieveDocumentObjectWithAttributes(any(DocumentAttributes.class),any(List.class))).thenReturn(retrievedDocument);


      DocumentContent documentContent = businessImpl.retrieveContent(reference);

       ArgumentCaptor<DocumentAttributes> documentAttributesCaptor = ArgumentCaptor.forClass(DocumentAttributes.class);
      ArgumentCaptor<List> requiredAttributes  = ArgumentCaptor.forClass(List.class);
      verify(services).retrieveDocumentObjectWithAttributes(documentAttributesCaptor.capture(),requiredAttributes.capture());

      DocumentAttributes documentAttributes = documentAttributesCaptor.getValue();
      assertEquals("objectId",documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID));
      assertEquals("version",documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_VERSION));
      assertEquals(0,requiredAttributes.getValue().size());


      assertEquals("folder/objectId",documentContent.getDocumentId());
      assertEquals("version",documentContent.getVersion());
      assertEquals("version",documentContent.getReference().getVersion());
      assertEquals("folder/objectId",documentContent.getReference().getDocumentId());
   }


   @Test
   public void testRetrieveDetails() throws Exception{
      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);



      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);
      Reference reference = new Reference();
       reference.setDocumentId("folder/objectId");
       reference.setVersion("version");

       ViewFields viewFields = new ViewFields();
       ViewField viewField = new ViewField();
       viewField.setName(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT);
       viewFields.getViewFields().add(viewField);

       RetrievedDocument retrievedDocument = new RetrievedDocument();

       File tmpFile = File.createTempFile("tmp","txt");
      


       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS,
                                                              tmpFile.getPath(),
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT,
                                                              "subject",
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,
                                                             "version",
                                                             DocumentManagerConstants.OPERATOR_EQUALS);


       when(services.retrieveDocumentObjectWithAttributes(any(DocumentAttributes.class),any(List.class))).thenReturn(retrievedDocument);

      Collection<DocumentDetail> documents = businessImpl.retrieveDetails(Arrays.asList(reference),viewFields);
      assertFalse(tmpFile.exists());
       ArgumentCaptor<DocumentAttributes> documentAttributesCaptor = ArgumentCaptor.forClass(DocumentAttributes.class);
      ArgumentCaptor<List> requiredAttributes  = ArgumentCaptor.forClass(List.class);

      verify(services).retrieveDocumentObjectWithAttributes(documentAttributesCaptor.capture(),requiredAttributes.capture());

      DocumentAttributes documentAttributes = documentAttributesCaptor.getValue();
      assertEquals("objectId",documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID));
      assertEquals("version",documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_VERSION));
      assertEquals(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT,requiredAttributes.getValue().get(0));

      assertEquals(1,documents.size());
      DocumentDetail document = documents.iterator().next();
      FieldTypeValue ftv = document.getFieldTypeValues().getFieldTypeValues().iterator().next();
      assertEquals(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT,ftv.getName());
      assertEquals("subject",ftv.getValue());
      assertEquals("folder/objectId",document.getDocumentId());
      assertEquals("version",document.getVersion());

   }

   @Test
   public void testRetrieveDetailsThrowsException() throws Exception{
      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);

      RuntimeException testException = new RuntimeException("test exception");
      doThrow(testException).when(services).connect();

      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);
      Reference reference = new Reference();
       reference.setDocumentId("folder/objectId");
       reference.setVersion("version");

       ViewFields viewFields = new ViewFields();
       ViewField viewField = new ViewField();
       viewField.setName(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT);
       viewFields.getViewFields().add(viewField);

      try {
          businessImpl.retrieveDetails(Arrays.asList(reference),viewFields);
         fail();
      }
      catch(FatalException re){
         assertSame(testException,re.getCause());
         assertEquals(testException.getMessage(),re.getMessage());
      }
   }

   @Test
   public void testRetrieveDetailsThrowsExceptionOnBuildingServices() throws Exception{
      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      RuntimeException testException = new RuntimeException("test exception");
      when(servicesFactory.buildDFCServices(anyString())).thenThrow(testException);

      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);
      Reference reference = new Reference();
       reference.setDocumentId("folder/objectId");
       reference.setVersion("version");

       ViewFields viewFields = new ViewFields();
       ViewField viewField = new ViewField();
       viewField.setName(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT);
       viewFields.getViewFields().add(viewField);

      try {
          businessImpl.retrieveDetails(Arrays.asList(reference),viewFields);
      }
      catch(FatalException re){
         assertSame(testException,re.getCause());
         assertEquals(testException.getMessage(),re.getMessage());
      }
      verify(services,never()).connect();
   }


   @Test
   public void testRetrieveDetailsThrowsNotFound() throws Exception{
      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);

      RuntimeException testException = new RuntimeException("test exception "+DocumentContentManagementBusinessImpl.DOES_NOT_EXIST);
      doThrow(testException).when(services).retrieveDocumentObjectWithAttributes((DocumentAttributes)anyObject(),(List)anyObject());

      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);
      Reference reference = new Reference();
       reference.setDocumentId("folder/objectId");
       reference.setVersion("version");

       ViewFields viewFields = new ViewFields();
       ViewField viewField = new ViewField();
       viewField.setName(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT);
       viewFields.getViewFields().add(viewField);

      try {
          businessImpl.retrieveDetails(Arrays.asList(reference),viewFields);
      }
      catch(NotFoundException nfe){
         assertEquals(reference.getDocumentId(),nfe.getReference().getDocumentId());
         assertEquals(reference.getVersion(),nfe.getReference().getVersion());
      }
   }


     @Test
   public void testSearch() throws Exception{
      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      ConnectionInfo connectionInfo = mock(ConnectionInfo.class);
      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);
      when(servicesFactory.getConnectionInfo(anyString())).thenReturn(connectionInfo);
      doAnswer(new Answer() {
        public Object answer(InvocationOnMock invocation) {
            Object[] args = invocation.getArguments();
            ResponseEntity responseEntity = (ResponseEntity)args[2];
           RetrievedDocument retrievedDocument = new RetrievedDocument();
           retrievedDocument.getDocumentAttributes().addAttribute("subject","testCXFService subject",DocumentManagerConstants.OPERATOR_EQUALS);
           retrievedDocument.getDocumentAttributes().addAttribute("objectId","OBJECT_ID",DocumentManagerConstants.OPERATOR_EQUALS);
           retrievedDocument.getDocumentAttributes().addAttribute("name","testCXFService.txt",DocumentManagerConstants.OPERATOR_EQUALS);
           retrievedDocument.getDocumentAttributes().addAttribute("version","VERSION",DocumentManagerConstants.OPERATOR_EQUALS);
           responseEntity.getRetrievedDocumentList().add(retrievedDocument);
            return "answer";
        } }).when(services).search(anyString(), any(SearchDocumentumRequestEntity.class),any(ResponseEntity.class));


      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

      SearchRequest searchRequest = new SearchRequest();
      searchRequest.setLocation("/posTestFolder/cxftest");
      SearchFields searchFields= new SearchFields();
      SearchField searchField = new SearchField();
      searchField.setName("subject");
      searchField.setValue("testCXFService subject");
      searchFields.setSearchFields(Arrays.asList(searchField));
      searchRequest.setSearchFields(searchFields);
      searchRequest.setSearchLatestVersion(true);
      SearchFullText searchFullText = new SearchFullText();
      searchFullText.setSearchText("fox");
      searchFullText.setOperator(SearchOperator.EQUALS);
      searchRequest.setSearchFullText(searchFullText);
      ViewFields viewFields = new ViewFields();
      ViewField viewField = new ViewField();
      viewField.setName("subject");
      viewFields.getViewFields().add(viewField);

      searchRequest.setViewFields(viewFields);        

      SearchResult searchResult = businessImpl.search(searchRequest);

      ArgumentCaptor<SearchDocumentumRequestEntity> requestCaptor = ArgumentCaptor.forClass(SearchDocumentumRequestEntity.class);
      InOrder serviceOrder =  inOrder(services);
      serviceOrder.verify(services).connect();
      serviceOrder.verify(services).search(anyString(), requestCaptor.capture(),any(ResponseEntity.class));

      SearchDocumentumRequestEntity capturedRequest = requestCaptor.getValue();

      assertEquals("fox",capturedRequest.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_FULL_TEXT));
      assertEquals("testCXFService subject",capturedRequest.getDocumentAttributes().getAttrValue("subject"));
      assertEquals("cxftest",capturedRequest.getDirectoryStructure());
      assertSame(connectionInfo,capturedRequest.getConnectionInfo());
      assertEquals(1,capturedRequest.getRequiredAttributes().size());
      String requiredAttribute = (String)capturedRequest.getRequiredAttributes().iterator().next();
      assertEquals("subject",requiredAttribute);
      Collection<DocumentDetail> documentDetails = searchResult.getDocumentDetails();
      assertEquals(1,documentDetails.size());
      DocumentDetail documentDetail = documentDetails.iterator().next();
      assertEquals("posTestFolder/OBJECT_ID",documentDetail.getDocumentId());
      assertEquals("VERSION",documentDetail.getVersion());
      assertEquals(1,documentDetail.getFieldTypeValues().getFieldTypeValues().size());
      FieldTypeValue fieldTypeValue = documentDetail.getFieldTypeValues().getFieldTypeValues().iterator().next();
      assertEquals("subject",fieldTypeValue.getName());
      assertEquals("testCXFService subject",fieldTypeValue.getValue());
   }

   @Test
 public void testSearchThrowsException() throws Exception{
    DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
    IDFCServices services = mock(IDFCServices.class);
    ConnectionInfo connectionInfo = mock(ConnectionInfo.class);
    DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
    when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);
    when(servicesFactory.getConnectionInfo(anyString())).thenReturn(connectionInfo);
    RuntimeException testException = new RuntimeException("Test exception");

    doThrow(testException).when(services).connect();

    DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

    SearchRequest searchRequest = new SearchRequest();
    searchRequest.setLocation("/posTestFolder/cxftest");
    SearchFields searchFields= new SearchFields();
    SearchField searchField = new SearchField();
    searchField.setName("subject");
    searchField.setValue("testCXFService subject");
    searchFields.setSearchFields(Arrays.asList(searchField));
    searchRequest.setSearchFields(searchFields);
    searchRequest.setSearchLatestVersion(true);
    SearchFullText searchFullText = new SearchFullText();
    searchFullText.setSearchText("fox");
    searchFullText.setOperator(SearchOperator.EQUALS);
    searchRequest.setSearchFullText(searchFullText);
    ViewFields viewFields = new ViewFields();
    ViewField viewField = new ViewField();
    viewField.setName("subject");
    viewFields.getViewFields().add(viewField);

    searchRequest.setViewFields(viewFields);

    try {
       businessImpl.search(searchRequest);
       fail();
    }
    catch(FatalException re){
       assertSame(testException,re.getCause());
       assertEquals(testException.getMessage(),re.getMessage());
    }
  
 }

   @Test
 public void testSearchThrowsExceptionOnBuildingServices() throws Exception{
    DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
    IDFCServices services = mock(IDFCServices.class);

    DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);

    RuntimeException testException = new RuntimeException("Test exception");

    when(servicesFactory.buildDFCServices(anyString())).thenThrow(testException);
    DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);

    SearchRequest searchRequest = new SearchRequest();
    searchRequest.setLocation("/posTestFolder/cxftest");
    SearchFields searchFields= new SearchFields();
    SearchField searchField = new SearchField();
    searchField.setName("subject");
    searchField.setValue("testCXFService subject");
    searchFields.setSearchFields(Arrays.asList(searchField));
    searchRequest.setSearchFields(searchFields);
    searchRequest.setSearchLatestVersion(true);
    SearchFullText searchFullText = new SearchFullText();
    searchFullText.setSearchText("fox");
    searchFullText.setOperator(SearchOperator.EQUALS);
    searchRequest.setSearchFullText(searchFullText);
    ViewFields viewFields = new ViewFields();
    ViewField viewField = new ViewField();
    viewField.setName("subject");
    viewFields.getViewFields().add(viewField);

    searchRequest.setViewFields(viewFields);

    try {
       businessImpl.search(searchRequest);
       fail();
    }
    catch(FatalException re){
       assertSame(testException,re.getCause());
       assertEquals(testException.getMessage(),re.getMessage());
    }
    verify(services,never()).connect();
 }


   @Test
   public void testUpdate() throws Exception{
      String folder = "folder";
      String path = "path";
      String fileName = "fileName.txt";
    
      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";
      when(contents.getContentType()).thenReturn(mimeType);
      when(contents.getName()).thenReturn(fileName);

      FieldValue fieldValue = new FieldValue();
      String fieldName = "fieldName";
      fieldValue.setFieldName(fieldName);
      String fieldValueValue = "fieldValue";
      fieldValue.setFieldValue(fieldValueValue);
      FieldValues fieldValues= new FieldValues();
      fieldValues.addFieldValue(fieldValue);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);
      ArgumentCaptor<UpdateDocumentumRequestEntity> requestEntityCaptor = ArgumentCaptor.forClass(UpdateDocumentumRequestEntity.class);

      ArgumentCaptor<String> tmpfilePathCaptor = ArgumentCaptor.forClass(String.class);

      RetrievedDocument retrievedDocument = mock(RetrievedDocument.class);

      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID,"objectId",DocumentManagerConstants.OPERATOR_EQUALS);
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,"version",DocumentManagerConstants.OPERATOR_EQUALS);
      when(retrievedDocument.getDocumentAttributes()).thenReturn(documentAttributes);
      when(services.update(any(UpdateDocumentumRequestEntity.class),anyString())).thenReturn(retrievedDocument);

      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);



       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_NAME,
                                                              fileName,
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,
                                                             "version",
                                                             DocumentManagerConstants.OPERATOR_EQUALS);

       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS,
                                                             "filepath",
                                                              DocumentManagerConstants.OPERATOR_EQUALS);

       when(services.retrieveDocumentObjectWithAttributes(any(DocumentAttributes.class),any(List.class))).thenReturn(retrievedDocument);

      
      Reference  reference = businessImpl.update("folder/inObjectId",true,contents,fieldValues);

      assertEquals(folder+"/objectId",reference.getDocumentId());
      assertEquals("version",reference.getVersion());
      verify(services).update(requestEntityCaptor.capture(), tmpfilePathCaptor.capture());
      UpdateDocumentumRequestEntity requestEntity =  requestEntityCaptor.getValue();
      assertEquals(fieldValue.getFieldValue(),requestEntity.getDocumentAttributes().getAttrValue(fieldName));
      assertEquals(DocumentManagerConstants.NEXT_MAJOR_VERSION,requestEntity.getDocumentAttributes().getAttrValue( DocumentManagerConstants.ATTR_STR_UPDATE_VERSION));
      assertNull(requestEntity.getDirectoryStructure());
      assertEquals(false, requestEntity.getRequestPDFRendition());
      assertEquals(folder,requestEntity.getFolderName());
      String tmpfilePath = tmpfilePathCaptor.getValue();
      assertTrue(tmpfilePath.startsWith(System.getProperty("java.io.tmpdir")));
      File file = new File(tmpfilePath);
      assertFalse(file.exists());
   }

   @Test
   public void testUpdateMinorVersion() throws Exception{
      String folder = "folder";
      String path = "path";
      String fileName = "fileName.txt";

      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";
      when(contents.getContentType()).thenReturn(mimeType);
      when(contents.getName()).thenReturn(fileName);

      FieldValue fieldValue = new FieldValue();
      String fieldName = "fieldName";
      fieldValue.setFieldName(fieldName);
      String fieldValueValue = "fieldValue";
      fieldValue.setFieldValue(fieldValueValue);
      FieldValues fieldValues= new FieldValues();
      fieldValues.addFieldValue(fieldValue);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);
      ArgumentCaptor<UpdateDocumentumRequestEntity> requestEntityCaptor = ArgumentCaptor.forClass(UpdateDocumentumRequestEntity.class);

      ArgumentCaptor<String> tmpfilePathCaptor = ArgumentCaptor.forClass(String.class);

      RetrievedDocument retrievedDocument = mock(RetrievedDocument.class);

      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID,"objectId",DocumentManagerConstants.OPERATOR_EQUALS);
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,"version",DocumentManagerConstants.OPERATOR_EQUALS);
      when(retrievedDocument.getDocumentAttributes()).thenReturn(documentAttributes);
      when(services.update(any(UpdateDocumentumRequestEntity.class),anyString())).thenReturn(retrievedDocument);

      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);



       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_NAME,
                                                              fileName,
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,
                                                             "version",
                                                             DocumentManagerConstants.OPERATOR_EQUALS);

       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS,
                                                             "filepath",
                                                              DocumentManagerConstants.OPERATOR_EQUALS);

       when(services.retrieveDocumentObjectWithAttributes(any(DocumentAttributes.class),any(List.class))).thenReturn(retrievedDocument);


      Reference  reference = businessImpl.update("folder/inObjectId",false,contents,fieldValues);

      assertEquals(folder+"/objectId",reference.getDocumentId());
      assertEquals("version",reference.getVersion());
      verify(services).update(requestEntityCaptor.capture(), tmpfilePathCaptor.capture());
      UpdateDocumentumRequestEntity requestEntity =  requestEntityCaptor.getValue();
      assertEquals(fieldValue.getFieldValue(),requestEntity.getDocumentAttributes().getAttrValue(fieldName));
      assertEquals(DocumentManagerConstants.NEXT_MINOR_VERSION,requestEntity.getDocumentAttributes().getAttrValue( DocumentManagerConstants.ATTR_STR_UPDATE_VERSION));
      assertNull(requestEntity.getDirectoryStructure());
      assertEquals(false, requestEntity.getRequestPDFRendition());
      assertEquals(folder,requestEntity.getFolderName());
      String tmpfilePath = tmpfilePathCaptor.getValue();
      assertTrue(tmpfilePath.startsWith(System.getProperty("java.io.tmpdir")));
      File file = new File(tmpfilePath);
      assertFalse(file.exists());
   }

   @Test
   public void testUpdateTakesReference() throws Exception{
      String folder = "folder";
      String path = "path";
      String fileName = "fileName.txt";

      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";
      when(contents.getContentType()).thenReturn(mimeType);
      when(contents.getName()).thenReturn(fileName);

      FieldValue fieldValue = new FieldValue();
      String fieldName = "fieldName";
      fieldValue.setFieldName(fieldName);
      String fieldValueValue = "fieldValue";
      fieldValue.setFieldValue(fieldValueValue);
      FieldValues fieldValues= new FieldValues();
      fieldValues.addFieldValue(fieldValue);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);
      ArgumentCaptor<UpdateDocumentumRequestEntity> requestEntityCaptor = ArgumentCaptor.forClass(UpdateDocumentumRequestEntity.class);

      ArgumentCaptor<String> tmpfilePathCaptor = ArgumentCaptor.forClass(String.class);

      RetrievedDocument retrievedDocument = mock(RetrievedDocument.class);

      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID,"objectId",DocumentManagerConstants.OPERATOR_EQUALS);
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,"version",DocumentManagerConstants.OPERATOR_EQUALS);
      when(retrievedDocument.getDocumentAttributes()).thenReturn(documentAttributes);
      when(services.update(any(UpdateDocumentumRequestEntity.class),anyString())).thenReturn(retrievedDocument);

      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);



       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_NAME,
                                                              fileName,
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,
                                                             "version",
                                                             DocumentManagerConstants.OPERATOR_EQUALS);

       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS,
                                                             "filepath",
                                                              DocumentManagerConstants.OPERATOR_EQUALS);

       when(services.retrieveDocumentObjectWithAttributes(any(DocumentAttributes.class),any(List.class))).thenReturn(retrievedDocument);


      Reference inReference = new Reference();
      inReference.setDocumentId("folder/inObjectId");
      inReference.setVersion("version");
      Reference  reference = businessImpl.update(inReference,contents,fieldValues);

      assertEquals(folder+"/objectId",reference.getDocumentId());
      assertEquals("version",reference.getVersion());
      verify(services).update(requestEntityCaptor.capture(), tmpfilePathCaptor.capture());
      UpdateDocumentumRequestEntity requestEntity =  requestEntityCaptor.getValue();
      assertEquals(fieldValue.getFieldValue(),requestEntity.getDocumentAttributes().getAttrValue(fieldName));
      assertEquals(DocumentManagerConstants.NEXT_MAJOR_VERSION,requestEntity.getDocumentAttributes().getAttrValue( DocumentManagerConstants.ATTR_STR_UPDATE_VERSION));
      assertNull(requestEntity.getDirectoryStructure());
      assertEquals(false, requestEntity.getRequestPDFRendition());
      assertEquals(folder,requestEntity.getFolderName());
      String tmpfilePath = tmpfilePathCaptor.getValue();
      assertTrue(tmpfilePath.startsWith(System.getProperty("java.io.tmpdir")));
      File file = new File(tmpfilePath);
      assertFalse(file.exists());
   }


   @Test
   public void testUpdateThrowsException() throws Exception{
      String folder = "folder";
      String path = "path";
      String fileName = "fileName.txt";

      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";

      when(contents.getContentType()).thenReturn(mimeType);
      when(contents.getName()).thenReturn(fileName);

      FieldValue fieldValue = new FieldValue();
      String fieldName = "fieldName";
      fieldValue.setFieldName(fieldName);
      String fieldValueValue = "fieldValue";
      fieldValue.setFieldValue(fieldValueValue);
      FieldValues fieldValues= new FieldValues();
      fieldValues.addFieldValue(fieldValue);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);

      RuntimeException testException = new RuntimeException("test exception");
      Stubber stubber = doNothing();
      stubber.when(services).connect();
      stubber.doThrow(testException).when(services).connect();






      RetrievedDocument retrievedDocument = mock(RetrievedDocument.class);

      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID,"objectId",DocumentManagerConstants.OPERATOR_EQUALS);
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,"version",DocumentManagerConstants.OPERATOR_EQUALS);
      when(retrievedDocument.getDocumentAttributes()).thenReturn(documentAttributes);
      when(services.update(any(UpdateDocumentumRequestEntity.class),anyString())).thenReturn(retrievedDocument);

      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);



       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_NAME,
                                                              fileName,
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,
                                                             "version",
                                                             DocumentManagerConstants.OPERATOR_EQUALS);

       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS,
                                                             "filepath",
                                                              DocumentManagerConstants.OPERATOR_EQUALS);

       when(services.retrieveDocumentObjectWithAttributes(any(DocumentAttributes.class),any(List.class))).thenReturn(retrievedDocument);


      try{
         businessImpl.update("folder/inObjectId",true,contents,fieldValues);
         fail();
      }
      catch (FatalException re){
         assertEquals(testException.getMessage(),re.getMessage());
         assertSame(testException,re.getCause());
      }
   }
   @Test
   public void testUpdateThrowsExceptionOnBuildingServices() throws Exception{
      String folder = "folder";
      String path = "path";
      String fileName = "fileName.txt";

      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";

      when(contents.getContentType()).thenReturn(mimeType);
      when(contents.getName()).thenReturn(fileName);

      FieldValue fieldValue = new FieldValue();
      String fieldName = "fieldName";
      fieldValue.setFieldName(fieldName);
      String fieldValueValue = "fieldValue";
      fieldValue.setFieldValue(fieldValueValue);
      FieldValues fieldValues= new FieldValues();
      fieldValues.addFieldValue(fieldValue);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      RuntimeException testException = new RuntimeException("test exception");
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services).thenThrow(testException);





      RetrievedDocument retrievedDocument = mock(RetrievedDocument.class);

      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID,"objectId",DocumentManagerConstants.OPERATOR_EQUALS);
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,"version",DocumentManagerConstants.OPERATOR_EQUALS);
      when(retrievedDocument.getDocumentAttributes()).thenReturn(documentAttributes);
      when(services.update(any(UpdateDocumentumRequestEntity.class),anyString())).thenReturn(retrievedDocument);

      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);



       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_NAME,
                                                              fileName,
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,
                                                             "version",
                                                             DocumentManagerConstants.OPERATOR_EQUALS);

       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS,
                                                             "filepath",
                                                              DocumentManagerConstants.OPERATOR_EQUALS);

       when(services.retrieveDocumentObjectWithAttributes(any(DocumentAttributes.class),any(List.class))).thenReturn(retrievedDocument);


      try{
         businessImpl.update("folder/inObjectId",true,contents,fieldValues);
         fail();
      }
      catch (FatalException re){
         assertEquals(testException.getMessage(),re.getMessage());
         assertSame(testException,re.getCause());
      }
      verify(services,times(1)).connect();
   }

   @Test
   public void testUpdateThrowsNotFoundException() throws Exception{
      String folder = "folder";
      String path = "path";
      String fileName = "fileName.txt";

      DataHandler contents = mock(DataHandler.class);
      InputStream contentsInput = new ByteArrayInputStream("contentsInput".getBytes());
      when(contents.getInputStream()).thenReturn(contentsInput);
      String mimeType = "mimeType";

      when(contents.getContentType()).thenReturn(mimeType);
      when(contents.getName()).thenReturn(fileName);

      FieldValue fieldValue = new FieldValue();
      String fieldName = "fieldName";
      fieldValue.setFieldName(fieldName);
      String fieldValueValue = "fieldValue";
      fieldValue.setFieldValue(fieldValueValue);
      FieldValues fieldValues= new FieldValues();
      fieldValues.addFieldValue(fieldValue);

      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      when(servicesFactory.buildDFCServices(anyString())).thenReturn(services);

      RuntimeException testException = new RuntimeException("test exception "+DocumentContentManagementBusinessImpl.DOES_NOT_EXIST);

      doThrow(testException).when(services).update((UpdateDocumentumRequestEntity)anyObject(),anyString());




      RetrievedDocument retrievedDocument = mock(RetrievedDocument.class);

      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID,"objectId",DocumentManagerConstants.OPERATOR_EQUALS);
      documentAttributes.addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,"version",DocumentManagerConstants.OPERATOR_EQUALS);
      when(retrievedDocument.getDocumentAttributes()).thenReturn(documentAttributes);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);



       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_NAME,
                                                              fileName,
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,
                                                             "version",
                                                             DocumentManagerConstants.OPERATOR_EQUALS);

       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS,
                                                             "filepath",
                                                              DocumentManagerConstants.OPERATOR_EQUALS);

       when(services.retrieveDocumentObjectWithAttributes(any(DocumentAttributes.class),any(List.class))).thenReturn(retrievedDocument);


      try{
         businessImpl.update("folder/inObjectId",true,contents,fieldValues);
      }
      catch (NotFoundException re){
         assertEquals("folder/inObjectId",re.getReference().getDocumentId());
         assertNull(re.getReference().getVersion());
      }
   }

   @Test
   public void testDeleteLatest() throws Exception{
      DFCServicesFactory servicesFactory = mock(DFCServicesFactory.class);
      IDFCServices services = mock(IDFCServices.class);
      String folder = "folder";
      when(servicesFactory.buildDFCServices(folder)).thenReturn(services);



      DocumentumQueryBuilder queryBuilder = mock(DocumentumQueryBuilder.class);
      DocumentContentManagementBusinessImpl businessImpl = new DocumentContentManagementBusinessImpl(servicesFactory,queryBuilder);
      Reference reference = new Reference();
      String objectId = "objectId";

      String documentId = folder + "/" + objectId;
      reference.setDocumentId(documentId);
      String version = "version";
      reference.setVersion(version);

       ViewFields viewFields = new ViewFields();
       ViewField viewField = new ViewField();
       viewField.setName(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT);
       viewFields.getViewFields().add(viewField);

       RetrievedDocument retrievedDocument = new RetrievedDocument();

       File tmpFile = File.createTempFile("tmp","txt");



       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CONTENTS,
                                                              tmpFile.getPath(),
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT,
                                                              "subject",
                                                              DocumentManagerConstants.OPERATOR_EQUALS);
       retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_VERSION,
                                                             "version",
                                                             DocumentManagerConstants.OPERATOR_EQUALS);


       when(services.retrieveDocumentObjectWithAttributes(any(DocumentAttributes.class),any(List.class))).thenReturn(retrievedDocument);

      businessImpl.deleteLatest(documentId);
      ArgumentCaptor<DocumentAttributes> documentAttributesCaptor = ArgumentCaptor.forClass(DocumentAttributes.class);
      ArgumentCaptor<ResponseEntity> responseEntityCaptor = ArgumentCaptor.forClass(ResponseEntity.class);
      ArgumentCaptor<String> objectIdCaptor =  ArgumentCaptor.forClass(String.class);
      verify(services).delete(objectIdCaptor.capture(), documentAttributesCaptor.capture(),responseEntityCaptor.capture());
      DocumentAttributes documentAttributes = documentAttributesCaptor.getValue();
      assertEquals(version,documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_VERSION));
      assertEquals(objectId, objectIdCaptor.getValue());

      assertNotNull( responseEntityCaptor.getValue());
   }
}
