package com.monsanto.tcc.dcm.business.impl;

import static org.junit.Assert.*;
import org.junit.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * rlcasw - Jun 11, 2010 4:20:05 PM
 */
public class TemporaryFileDataSource_AT
{
   @Test
   public void testDeleteOnClose()throws Exception{
      File file = File.createTempFile("tmp",".txt");
      FileOutputStream out = new FileOutputStream(file);
      out.write("The quick brown fox jumps over the lazy dog".getBytes());
      out.close();

      TemporaryFileDataSource dataSource = new TemporaryFileDataSource(file,"application/octet-stream");
      assertTrue(file.exists());
      InputStream in = dataSource.getInputStream();
      in.close();
      assertFalse(file.exists());
   }
   @Test
   public void testContentType()throws Exception{
      File file = File.createTempFile("tmp",".txt");
      file.delete();
      TemporaryFileDataSource dataSource = new TemporaryFileDataSource(file,"contentType");
      assertEquals("contentType",dataSource.getContentType());
   }

}
