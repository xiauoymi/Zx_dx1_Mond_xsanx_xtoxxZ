package com.monsanto.tcc.dcm.business.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

import java.io.File;
import java.io.FileOutputStream;

/**
 * RLCASW - May 31, 2010 5:41:35 PM
 */
public class TemporaryFileInputStream_AT
{
   @Test
   public void testDeleteOnClose()throws Exception{
      File file = File.createTempFile("tmp",".txt");
      FileOutputStream out = new FileOutputStream(file);
      out.write("The quick brown fox jumps over the lazy dog".getBytes());
      out.close();

      TemporaryFileInputStream in = new TemporaryFileInputStream(file);
      assertTrue(file.exists());
      in.close();
      assertFalse(file.exists());
   }
}
