package com.monsanto.tcc.dcm.service.impl;

import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tcc.dcm.business.DocumentContentManagementBusiness;
import com.monsanto.tcc.dcm.transfer.Reference;
import com.monsanto.tcc.dcm.transfer.ViewFields;
import com.monsanto.tcc.dcm.transfer.Document;
import com.monsanto.tcc.dcm.transfer.DocumentDetail;
import com.monsanto.tcc.dcm.transfer.DocumentContent;
import com.monsanto.tcc.dcm.transfer.FieldValues;
import com.monsanto.tcc.dcm.transfer.SearchResult;
import com.monsanto.tcc.dcm.transfer.SearchRequest;
import static org.junit.Assert.assertSame;
import org.junit.Test;
import static org.mockito.Mockito.*;

import javax.activation.DataHandler;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * rlcasw - May 19, 2010 8:56:28 AM
 */
public class DocumentContentManagementServiceImpl_UT
{

     @Test
     public void testRetrieve(){
        DocumentContentManagementBusiness business = mock(DocumentContentManagementBusiness.class);
        DataPointHolder dataPointHolder = mock(DataPointHolder.class);
        DocumentContentManagementServiceImpl service = new DocumentContentManagementServiceImpl(business/*,dataPointHolder*/);

        List<Reference> references = new ArrayList<Reference>();
        ViewFields viewFields = new ViewFields();
        Collection<Document> inDocuments = new ArrayList<Document>();
        when(business.retrieve(any(Collection.class),any(ViewFields.class))).thenReturn(inDocuments);
        Collection<Document> outDocuments = service.retrieve(references,viewFields);
        assertSame(inDocuments,outDocuments);
        verify(business,times(1)).retrieve(references,viewFields);
     }

     @Test
     public void testRetrieveDetails(){
        DocumentContentManagementBusiness business = mock(DocumentContentManagementBusiness.class);
        DataPointHolder dataPointHolder = mock(DataPointHolder.class);
        List<Reference> references = new ArrayList<Reference>();
        ViewFields viewFields = new ViewFields();
        Collection<DocumentDetail> documentDetails = new ArrayList<DocumentDetail>();

        when(business.retrieveDetails(any(Collection.class),any(ViewFields.class))).thenReturn(documentDetails);

        DocumentContentManagementServiceImpl service = new DocumentContentManagementServiceImpl(business/*,dataPointHolder*/);
        Collection<DocumentDetail>  outDetails = service.retrieveDetails(references,viewFields);
        assertSame(documentDetails,outDetails);
        verify(business,times(1)).retrieveDetails(references,viewFields);
     }

     @Test
     public void testRetrieveContent(){
        DocumentContentManagementBusiness business = mock(DocumentContentManagementBusiness.class);
        DataPointHolder dataPointHolder = mock(DataPointHolder.class);
        DocumentContentManagementServiceImpl service = new DocumentContentManagementServiceImpl(business/*,dataPointHolder*/);
        Reference reference = new Reference();
        DocumentContent documentContent = new DocumentContent();
        when(business.retrieveContent(reference)).thenReturn(documentContent);
        DocumentContent outContent=   service.retrieveContent(reference);
        assertSame(documentContent,outContent);
        verify(business,times(1)).retrieveContent(reference);
     }


     @Test
     public void testUpdate(){
        DocumentContentManagementBusiness business = mock(DocumentContentManagementBusiness.class);
        DataPointHolder dataPointHolder = mock(DataPointHolder.class);
        DocumentContentManagementServiceImpl service = new DocumentContentManagementServiceImpl(business/*,dataPointHolder*/);

        Reference reference = new Reference();
        DataHandler dataHandler = mock(DataHandler.class);
        FieldValues fieldValues = new FieldValues();

        Reference referenceToReturn = new Reference();
        when(business.update(reference,dataHandler,fieldValues)).thenReturn(referenceToReturn);
        Reference returnedReference = service.update(reference,dataHandler,fieldValues);
        assertSame(referenceToReturn,returnedReference);
        verify(business,times(1)).update(reference, dataHandler, fieldValues);
        
     }

     @Test
     public void testUpdate2(){
        DocumentContentManagementBusiness business = mock(DocumentContentManagementBusiness.class);
        DataPointHolder dataPointHolder = mock(DataPointHolder.class);
        DocumentContentManagementServiceImpl service = new DocumentContentManagementServiceImpl(business/*,dataPointHolder*/);

        String documentId = "documentId";
        boolean majorVersion = false;
        DataHandler dataHandler = mock(DataHandler.class);
        FieldValues fieldValues = new FieldValues();
        Reference referenceToReturn = new Reference();
        when(business.update(documentId,majorVersion,dataHandler,fieldValues)).thenReturn(referenceToReturn);
        Reference returnedReference = service.update(documentId, majorVersion, dataHandler, fieldValues);
        assertSame(referenceToReturn,returnedReference);
        verify(business,times(1)).update(documentId,majorVersion,dataHandler,fieldValues);
     }

     @Test
     public void testCreate(){
        DocumentContentManagementBusiness business = mock(DocumentContentManagementBusiness.class);
        DataPointHolder dataPointHolder = mock(DataPointHolder.class);
        DocumentContentManagementServiceImpl service = new DocumentContentManagementServiceImpl(business/*,dataPointHolder*/);

        String location = "location";
        boolean versioningEnabled = true;
        DataHandler dataHandler = mock(DataHandler.class);
        FieldValues fieldValues = new FieldValues();
        Reference referenceToReturn = new Reference();
        when(business.create(location, versioningEnabled, dataHandler, fieldValues)).thenReturn(referenceToReturn);
        Reference returnedReference = service.create(location,versioningEnabled,dataHandler,fieldValues);
        assertSame(referenceToReturn,returnedReference);
        verify(business,times(1)).create(location,versioningEnabled,dataHandler,fieldValues);
     }

    @Test
    public void testSearch(){
       DocumentContentManagementBusiness business = mock(DocumentContentManagementBusiness.class);
       DataPointHolder dataPointHolder = mock(DataPointHolder.class);
       DocumentContentManagementServiceImpl service = new DocumentContentManagementServiceImpl(business/*,dataPointHolder*/);

       SearchResult searchResultToReturn = new SearchResult();
       SearchRequest searchRequest = new SearchRequest();
       when(business.search(searchRequest)).thenReturn(searchResultToReturn);
       SearchResult returnedSearchResult = service.search(searchRequest);
       assertSame(searchResultToReturn,returnedSearchResult);
       verify(business,times(1)).search(searchRequest);
    }

    @Test
    public void testDelete(){
       DocumentContentManagementBusiness business = mock(DocumentContentManagementBusiness.class);
       DataPointHolder dataPointHolder = mock(DataPointHolder.class);
       DocumentContentManagementServiceImpl service = new DocumentContentManagementServiceImpl(business/*,dataPointHolder*/);
       Reference reference = new Reference();
       service.delete(reference);
       verify(business,times(1)).delete(reference);
    }
    @Test
    public void testDeleteAll(){
       DocumentContentManagementBusiness business = mock(DocumentContentManagementBusiness.class);
       DataPointHolder dataPointHolder = mock(DataPointHolder.class);
       DocumentContentManagementServiceImpl service = new DocumentContentManagementServiceImpl(business/*,dataPointHolder*/);
       
       String documentId = "documentId";
       service.deleteAll(documentId);
       verify(business,times(1)).deleteAll(documentId);
    }
    @Test
    public void testDeleteLatest(){
       DocumentContentManagementBusiness business = mock(DocumentContentManagementBusiness.class);
       DataPointHolder dataPointHolder = mock(DataPointHolder.class);
       DocumentContentManagementServiceImpl service = new DocumentContentManagementServiceImpl(business/*,dataPointHolder*/);
       
       String documentId = "documentId";
       service.deleteLatest(documentId);
       verify(business,times(1)).deleteLatest(documentId);
    }
}
