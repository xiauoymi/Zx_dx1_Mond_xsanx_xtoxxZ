package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.InsertSharePointDoc.Entity.tests;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.entity.InsertSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.TransformationObject;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Apr 27, 2006 Time: 4:39:06 PM To change this template use File |
 * Settings | File Templates.
 */
public class InsertSharePointRequestEntity_UT extends TestCase {

  RequestEntity requestEntity = new InsertSharePointRequestEntity();

  public void testTransformationOfAttributePerformedSucessfully() throws Exception {
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    List requiredAttributes = requestEntity.getRequiredAttributes();

    addKeywords(documentAttributes, "keywordList");
    documentAttributes.addAttribute("fileName", "testName", null);
    documentAttributes.addAttribute("documentSubject", "testSubject", null);
    requiredAttributes.add("fileName");

    assertEquals(documentAttributes.getAttrValue("fileName"), "testName");
    assertEquals(documentAttributes.getAttrValue("documentSubject"), "testSubject");
    assertEquals(documentAttributes.getAttrValues("keywordList").get(0), "farm");
    assertEquals(documentAttributes.getAttrValues("keywordList").get(1), "crop");
    assertEquals(documentAttributes.getAttrValues("keywordList").get(2), "seed");
    assertEquals(documentAttributes.getAttrValues("keywordList").get(2), "seed");
    assertEquals(requiredAttributes.get(0), "fileName");

    List nameList = new ArrayList();
    nameList.add(new TransformationObject("fileName", "object_name"));
    nameList.add(new TransformationObject("keywordList", "keywords"));
    nameList.add(new TransformationObject("documentSubject", "subject"));

    requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameList);

    assertEquals(documentAttributes.getAttrValue("object_name"), "testName");
    assertEquals(documentAttributes.getAttrValue("subject"), "testSubject");
    assertEquals(documentAttributes.getAttrValues("keywords").get(0), "farm");
    assertEquals(documentAttributes.getAttrValues("keywords").get(1), "crop");
    assertEquals(documentAttributes.getAttrValues("keywords").get(2), "seed");
    assertEquals(requiredAttributes.get(0), "object_name");
  }

  private void addKeywords(DocumentAttributes documentAttributes, String attrName) {
    List keywordList = new ArrayList();
    keywordList.add("farm");
    keywordList.add("crop");
    keywordList.add("seed");
    documentAttributes.addAttribute(attrName, keywordList, null);
  }
}