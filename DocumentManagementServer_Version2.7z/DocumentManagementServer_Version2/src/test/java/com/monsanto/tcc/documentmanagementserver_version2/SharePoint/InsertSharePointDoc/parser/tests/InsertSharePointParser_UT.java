package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.InsertSharePointDoc.parser.tests;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.parser.InsertDocumentumRequestParser;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Mar 28, 2006 Time: 11:27:34 AM To change this template use File |
 * Settings | File Templates.
 */
public class InsertSharePointParser_UT extends XMLTestCase {

  private static final String TEST_INPUT_REQUEST_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/TestInsertDocRequest.xml";

  InsertDocumentumRequestParser insertParser;
  DocumentumRequestEntity requestEntity;

  protected void setUp() throws IOException {
    insertParser = new InsertDocumentumRequestParser();
    requestEntity = new InsertDocumentumRequestEntity();
  }

  public void testParsingOfSingleValuedAttribute() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_1);
    Node requestNode = DOMUtil.getChild(inputDocument.getDocumentElement(), "requestDetails");
    insertParser.parseOperationSpecificRequest(requestNode, requestEntity);
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    assertEquals("apptestFile.doc", documentAttributes.getAttrValue("fileName"));
  }

  public void testParsingOfManySingleValuedAttribute() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_1);
    Node requestNode = DOMUtil.getChild(inputDocument.getDocumentElement(), "requestDetails");
    insertParser.parseOperationSpecificRequest(requestNode, requestEntity);
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    assertEquals("apptestFile.doc", documentAttributes.getAttrValue("fileName"));
    assertEquals("testSubject", documentAttributes.getAttrValue("subject"));
  }
}