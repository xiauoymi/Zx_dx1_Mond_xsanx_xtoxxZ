package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.InsertSharePointDoc.parser.tests;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.entity.InsertSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.parser.InsertSharePointRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockInsertSharePointRequestParser;
import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 24, 2006 Time: 3:10:51 PM To change this template use File |
 * Settings | File Templates.
 */
public class InsertSharePointRequestParser_UT extends TestCase {

  private static final String TEST_INPUT_REQUEST_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/TestInsertDocRequest.xml";
  private static final String TEST_INPUT_REQUEST_XML_2 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/TestInsertDocRequest2.xml";
  private static final String TEST_INPUT_REQUEST_XML_3 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/TestInsertDocRequest3.xml";
  private static final String TEST_INPUT_REQUEST_XML_WITH_PDF_TRUE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/TestInsertDocRequestWithPDFRenditionTrue.xml";
  private static final String TEST_INPUT_REQUEST_XML_WITHOUT_PDF = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/TestInsertDocRequestWithNoPDFRendition.xml";
  private static final String TEST_INPUT_REQUEST_XML_WITH_PDF_FALSE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/TestInsertDocRequestWithPDFRenditionFalse.xml";


  InsertSharePointRequestParser requestParser;
  InsertSharePointRequestEntity requestEntity;
  private static final String ENCRYPTED_PASSWORD = "devl30";

  protected void setUp() throws IOException {
    requestParser = new MockInsertSharePointRequestParser();
    requestEntity = new InsertSharePointRequestEntity();
  }

  public void testFolderNameAndDirectoryStructureParsedCorrectly() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_1);

    requestParser.parseInputXML(inputDocument, requestEntity);
    assertEquals("posTestFolder-SP", requestEntity.getFolderName());
    assertEquals("test/folder1/folder2", requestEntity.getDirectoryStructure());
  }

  public void testRequestPDFRenditionTrue() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_WITH_PDF_TRUE);

    requestParser.parseInputXML(inputDocument, requestEntity);
    assertTrue(requestEntity.getRequestPDFRendition());
  }

  public void testRequestPDFRenditionDefaultsToFalse() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_WITH_PDF_FALSE);
    requestParser.parseInputXML(inputDocument, requestEntity);
    assertFalse(requestEntity.getRequestPDFRendition());

  }

  public void testRequestPDFRenditionFalse() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_WITHOUT_PDF);
    requestParser.parseInputXML(inputDocument, requestEntity);
    assertFalse(requestEntity.getRequestPDFRendition());

  }

  public void testFolderNameAndDirectoryStructureParsedCorrectlyForDifferentRequests() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_2);
    requestParser.parseInputXML(inputDocument, requestEntity);
    assertEquals("MyTestFolder4", requestEntity.getFolderName());
    assertEquals("dir1/testfolder3/testfolder4", requestEntity.getDirectoryStructure());

    inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_3);
    requestParser.parseInputXML(inputDocument, requestEntity);
    assertEquals("posTestFolder-SP", requestEntity.getFolderName());
    assertEquals("", requestEntity.getDirectoryStructure());
  }

  public void testServiceSpecificConfigDetailsParsedCorrectlyForSingleRequest() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_1);
    requestParser.parseInputXML(inputDocument, requestEntity);
    assertEquals("http://na1000spdev60/teamsite", requestEntity.getConnectionInfo().getConnectionParameterValue(
        DocumentManagerConstants.SP_CI_SITE_NAME));
    assertEquals("ScannedImages",
        requestEntity.getConnectionInfo().getConnectionParameterValue(DocumentManagerConstants.SP_CI_DOC_LIB_NAME));
    try {
      assertNull("stddma00.monsanto.com", requestEntity.getConnectionInfo().getConnectionParameterValue("docBroker"));
      fail(
          "there shouldn't be a DocBroker tag in a sharepoint repository folder - make sure you;re using a folder ID with a repository of SharePoint.");
    } catch (AttributeListParseException e) {
      assertEquals("The Attribute \"docBroker\" not present.", e.getMessage());
    }

    try {
      assertNull("aphis", requestEntity.getConnectionInfo().getConnectionParameterValue("userName"));
      fail(
          "there shouldn't be a UserName tag in a sharepoint repository folder - make sure you;re using a folder ID with a repository of SharePoint.");
    } catch (AttributeListParseException e) {
      assertEquals("The Attribute \"userName\" not present.", e.getMessage());
    }
    try {
      assertNull(ENCRYPTED_PASSWORD, requestEntity.getConnectionInfo().getConnectionParameterValue("password"));
      fail(
          "there shouldn't be a password tag in a sharepoint repository folder - make sure you;re using a folder ID with a repository of SharePoint.");
    } catch (AttributeListParseException e) {
      assertEquals("The Attribute \"password\" not present.", e.getMessage());
    }
    try {
      assertNull("aphis_doc", requestEntity.getConnectionInfo().getConnectionParameterValue("objectType"));
      fail(
          "there shouldn't be a objectType tag in a sharepoint repository folder - make sure you;re using a folder ID with a repository of SharePoint.");
    } catch (AttributeListParseException e) {
      assertEquals("The Attribute \"objectType\" not present.", e.getMessage());
    }
  }

  public void testServiceSpecificConfigDetailsParsedCorrectlyForMultipleRequest() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_3);
    requestParser.parseInputXML(inputDocument, requestEntity);
    try {
      assertEquals("/SAR CABINET", requestEntity.getConnectionInfo().getConnectionParameterValue("cabinet"));
      fail(
          "there shouldn't be a cabinet tag in a sharepoint repository folder - make sure you;re using a folder ID with a repository of SharePoint.");
    } catch (AttributeListParseException e) {
      assertEquals("The Attribute \"cabinet\" not present.", e.getMessage());
    }

  }

  public void testParsingOfSingleValuedRequestDetailAttribuTte() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_1);
    Node requestNode = DOMUtil.getChild(inputDocument.getDocumentElement(), "requestDetails");
    requestParser.parseOperationSpecificRequest(requestNode, requestEntity);
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    assertEquals("apptestFile.doc", documentAttributes.getAttrValue("fileName"));
  }

  public void testParsingOfManySingleValuedRequestDetailAttribute() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_1);
    Node requestNode = DOMUtil.getChild(inputDocument.getDocumentElement(), "requestDetails");
    requestParser.parseOperationSpecificRequest(requestNode, requestEntity);
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    assertEquals("apptestFile.doc", documentAttributes.getAttrValue("fileName"));
    assertEquals("testSubject", documentAttributes.getAttrValue("subject"));
  }

  public void testParsingOfMultipleValuedRequestDetailAttribute() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_2);
    Node requestNode = DOMUtil.getChild(inputDocument.getDocumentElement(), "requestDetails");
    requestParser.parseOperationSpecificRequest(requestNode, requestEntity);
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();

    //**Ideal way to access an attribute value...if unsure of its type (single or multi-valued)
    if (!documentAttributes.hasMultipleValues("fileName")) {
      String fileNameValue = documentAttributes.getAttrValue("fileName");
      assertEquals("testFile.html", fileNameValue);
    } else {
      //**retrieve a list using getAttrValues();
    }

    //**Second way of accessing attributes of unknown type (single/multi-valued)
    try {
      String titleValue = documentAttributes.getAttrValue("title");
      assertEquals("testTitle", titleValue);
    } catch (AttributeListParseException e) {
      //**Check error-msg and retrieve a list using getAttrValues();
    }

    List valueList = documentAttributes.getAttrValues("keyword");
    assertEquals("farm", valueList.get(0));
    assertEquals("seed", valueList.get(1));
    assertEquals("corn", valueList.get(2));

    valueList = documentAttributes.getAttrValues("authors");
    assertEquals("name1", valueList.get(0));
    assertEquals("name2", valueList.get(1));
  }
}