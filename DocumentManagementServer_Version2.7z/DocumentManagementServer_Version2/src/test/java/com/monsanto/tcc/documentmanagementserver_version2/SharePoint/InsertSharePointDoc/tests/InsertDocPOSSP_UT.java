package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.InsertSharePointDoc.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.InsertSharePointDoc.builder.MockInsertSharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.ISharePointServices;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.SharePointServices;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.ServiceConfig.SharePointServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.insertService.InsertDocumentPOS;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 23, 2006 Time: 3:18:14 PM To change this template use File |
 * Settings | File Templates.
 */
public class InsertDocPOSSP_UT extends XMLTestCase {
  private static final String DOCUMENT_LIBRARY = "ScannedImages";
  private static final String SITE_NAME = "http://na1000spdev60/teamsite";
  private static final String TEST_INPUT_REQUEST_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/TestInsertDocRequest.xml";
  private static final String TEST_INPUT_REQUEST_XML_2 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/TestInsertDocRequest2.xml";
  private static final String INSERT_DOC_REQUEST_SEC_ENV_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/InsertDocWithSecurityEnvelope1.xml";
  private static final String INSERT_DOC_REQUEST_SEC_ENV_XML_2 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/InsertDocWithSecEnv2.xml";
  private static final String INSERT_DOC_REQUEST_SEC_ENV_XML_3 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/InsertDocWithSecEnv3.xml";
  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";
  private static final String TEST_DOC_ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/test.doc";
  private static final String FILENAME_IN_INSERT_REQUESTS = "testFile.doc";
  InsertDocumentPOS insertDocumentPOS;
  MockUCCHelper mockUCCHelper;
  private static final String INSERT_DOC_REQUEST_WITH_BAD_DIRSTRUCTURE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/TestInsertDocReqInvalidDirectoryStructure.xml";

  protected void setUp() throws IOException {
    insertDocumentPOS = new MockInsertDocPOS();
    mockUCCHelper = new MockUCCHelper(null);
  }

  protected void tearDown() throws Exception {
    ISharePointServices service = new SharePointServices(SITE_NAME, DOCUMENT_LIBRARY);
    try {
      service.deleteByName(FILENAME_IN_INSERT_REQUESTS,"");
      service.deleteByName("folder2","");
      service.deleteByName("folder1","");
      service.deleteByName("some dir","");
    } catch (Exception e) {
      System.out.println("e = " + e);
      System.out.println("e.getMessage() = " + e.getMessage());
    }
  }

  public void testCorrectBuilderInitialized() throws Exception {
    System.out.println("InsertDocPOSSP_UT.testCorrectBuilderInitialized");
    Document inputDoc = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_1);
    DOMUtil.outputXML(inputDoc);
    assertEquals(MockInsertSharePointBuilder.class, insertDocumentPOS.getBuilder(inputDoc).getClass());
  }

  public void testExceptionThrownIfBuilderImplementationNotFound() throws Exception {
    System.out.println("InsertDocPOSSP_UT.testExceptionThrownIfBuilderImplementationNotFound");
    insertDocumentPOS = new MockInsertDocPOSNoOverride();
    try {
      Document inputDoc = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_2);
      DOMUtil.outputXML(inputDoc);
      assertEquals(MockInsertSharePointBuilder.class, insertDocumentPOS.getBuilder(inputDoc).getClass());
      fail("Builder not initailized Exception NOT thrown.");
    } catch (ServiceConfigException e) {
      System.out.println("Required exception thrown: " + e.getMessage());
    }
  }

  public void testErrorResponseGeneratedIfSchemaValidationFails() throws Exception {
    System.out.println("InsertDocPOSSP_UT.testErrorResponseGeneratedIfSchemaValidationFails");
    Document responseDoc = runInsertPOS(INSERT_DOC_REQUEST_SEC_ENV_XML_1);
    DOMUtil.outputXML(responseDoc);
    checkErrorTagCreatedCorrectly(responseDoc);
    assertXpathEvaluatesTo(
        "org.xml.sax.SAXParseException: cvc-complex-type.2.4.a: Invalid content was found starting with element 'directoryStructure'. One of '{\"www.monsanto.com/pos\":folder}' is expected.\r\n",
        "/ERROR/ERROR_MESSAGE", responseDoc);
  }

  public void testInsertDocument() throws Exception {
    System.out.println("InsertDocPOSSP_UT.testInsertDocument");
    Document responseDoc = runInsertPOS(INSERT_DOC_REQUEST_SEC_ENV_XML_2);
    System.out.println("begin responseDoc");
    DOMUtil.outputXML(responseDoc);
    System.out.println("end responseDoc");
    checkNoErrorResponseTag(responseDoc);

  }

  public void testAlreadyExistingDirectoryStructureDoesNotThrowException() throws Exception {
    Document responseDocument = runInsertPOS(INSERT_DOC_REQUEST_SEC_ENV_XML_2);
    checkNoErrorResponseTag(responseDocument);
    ISharePointServices service = new SharePointServices(SITE_NAME, DOCUMENT_LIBRARY);
    service.deleteByName(FILENAME_IN_INSERT_REQUESTS,"");
    System.out.println("I deleted: " + TEST_DOC_ATTACHMENT_1);
    responseDocument = runInsertPOS(INSERT_DOC_REQUEST_SEC_ENV_XML_2);
    checkNoErrorResponseTag(responseDocument);
//    checkErrorTagCreatedCorrectly(responseDocument);
//    String responseErrorMessage = getErrorMessageFromErrorResponse(responseDocument);
//    System.out.println("responseErrorMessage = " + responseErrorMessage);
//    assertTrue("wrong error", responseErrorMessage.contains("already exists"));
  }

  public void testdirectoryStructureWithInvalidCharactersThrowsException() throws Exception {
    Document responseDocument = runInsertPOS(INSERT_DOC_REQUEST_WITH_BAD_DIRSTRUCTURE);
    checkErrorTagCreatedCorrectly(responseDocument);
    String responseErrorMessage = getErrorMessageFromErrorResponse(responseDocument);
    System.out.println("responseErrorMessage = " + responseErrorMessage);
    assertTrue("wrong error", responseErrorMessage.contains("invalid characters"));
  }

  private String getErrorMessageFromErrorResponse(Document responseDocument) throws TransformerException {
    return XPathAPI.eval(responseDocument, "/ERROR/ERROR_MESSAGE").toString();
  }

  public void testErrorResponseSentByBaseDocPOSIfBuilderImplNotFound() throws Exception {
    System.out.println("InsertDocPOSSP_UT.testErrorResponseSentByBaseDocPOSIfBuilderImplNotFound");
    Document responseDoc = runInsertPOS(INSERT_DOC_REQUEST_SEC_ENV_XML_3);
    DOMUtil.outputXML(responseDoc);
    checkErrorTagCreatedCorrectly(responseDoc);
  }

  public void testErrorResponseSentByBaseDocPOSIfLsiEnvironmentVariableNotSet() throws Exception {
    String lsiFunction = System.getProperty("lsi.function");
    System.setProperty("lsi.function", "");
    Document responseDoc = runInsertPOS(INSERT_DOC_REQUEST_SEC_ENV_XML_2);
    checkErrorTagCreatedCorrectly(responseDoc);
    assertXpathEvaluatesTo("lsi environment variable not set:Bad value for lsi.function", "/ERROR/ERROR_MESSAGE",
        responseDoc);
    System.setProperty("lsi.function", lsiFunction);
  }

  private Document runInsertPOS(String inputRequestFilePath) throws IOException {
    mockUCCHelper.addClientFile(inputRequestFilePath);
    mockUCCHelper.addClientFile(TEST_DOC_ATTACHMENT_1);
    insertDocumentPOS.run(mockUCCHelper);
    return mockUCCHelper.getXML();
  }

  private void checkNoErrorResponseTag(Document responseDoc) throws TransformerException {
    String xpathString = "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" +
        DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value";
    assertXpathExists(xpathString, responseDoc);
    String objectId = XPathAPI.eval(responseDoc.getDocumentElement(), xpathString).toString();
    assertNotNull(objectId);
    assertXpathEvaluatesTo("0.1", "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" +
        DocumentManagerConstants.ATTR_STR_VERSION + "']/value", responseDoc);
  }

  private void checkErrorTagCreatedCorrectly(Document responseDoc) throws TransformerException {
    assertXpathExists("/ERROR", responseDoc);
    assertXpathEvaluatesTo("-1", "/ERROR/ERROR_CODE", responseDoc);
    assertXpathExists("/ERROR/ERROR_MESSAGE", responseDoc);
    assertXpathExists("/ERROR/STACK_TRACE", responseDoc);
  }

  class MockInsertDocPOSNoOverride extends InsertDocumentPOS {
    protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
      System.out.println("InsertDocPOSSP_UT$MockInsertDocPOS.instantiateServiceLookup");
      return new SharePointServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    }
  }

  class MockInsertDocPOS extends MockInsertDocPOSNoOverride {
    protected DocBuilder getRepositorySpecificBuilder(String repositoryName) throws ServiceConfigException {
      return new MockInsertSharePointBuilder();
    }
  }
}