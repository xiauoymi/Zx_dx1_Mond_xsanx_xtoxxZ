package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.InsertSharePointDoc.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.ISharePointServices;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SPServices.SharePointServices;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointAttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointService;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.entity.InsertSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.insertSharePointDoc.entity.InsertSharePointResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.AttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import junit.framework.TestCase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Mar 7, 2006 Time: 11:55:51 AM To change this template use File |
 * Settings | File Templates.
 */
public class InsertSharePointService_UT extends TestCase {
  private static final String SP_SITE = "http://na1000spDEV60/teamsite";
  private static final String DOCUMENT_LIBRARY_NAME = "ScannedImages";
  private static final String TEST_INPUT_REQUEST_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/TestInsertDocRequest.xml";
  private static final String TEST_INPUT_REQUEST_XML_2 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/TestInsertDocRequest_withInvalidAttribute.xml";
  private static final String TEST_DOC_ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/test.doc";
  private static final String TEST_DOC_ATTACHMENT_2 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/test2.doc";
  private static final String TEST_TEXT_FILE_1 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/insertSharePointDoc/tests/testFile1.txt";
  private static final String TEST_DOC_FILE_NAME = "test.doc";
  private static final String TEST_2_FILE_NAME = "test2.doc";
  private static final String TEST_1_FILE_NAME = "testFile1.txt";
  InsertSharePointRequestEntity requestEntity;
  SharePointService SharePointService;
  MockUCCHelper mockHelper;
  ConnectionInfo connectionInfo;
  private ResponseEntity responseEntity;

  protected void setUp() throws IOException, DocumentManagerException, AttributeListParseException {
    connectionInfo = getConnectionParams(DOCUMENT_LIBRARY_NAME);
    responseEntity = new InsertSharePointResponseEntity();
    ISharePointServices services = new SharePointServices(SP_SITE, DOCUMENT_LIBRARY_NAME);
    SharePointService = new SharePointService(connectionInfo);
    insertTestDoc(TEST_2_FILE_NAME);
    List sPIDList = services.findIdByName(TEST_2_FILE_NAME,"");
    System.out.println("sPIDList = " + sPIDList);
  }

  protected void tearDown() throws Exception {
    ISharePointServices service = new SharePointServices(SP_SITE, DOCUMENT_LIBRARY_NAME);
    try {
      System.out.println("InsertSharePointService_UT.tearDown");
      service.deleteByName(TEST_1_FILE_NAME,"");
      service.deleteByName("testFolder2","");
      service.deleteByName("testFolder1","");
      service.deleteByName("dir","");
      System.out.println("deleting " + TEST_2_FILE_NAME);
      service.deleteByName(TEST_2_FILE_NAME,"");
      System.out.println("deleting " + TEST_DOC_FILE_NAME);
      service.deleteByName(TEST_DOC_FILE_NAME,"");
    } catch (Exception e) {
      //Ignore
    }
  }

  public void testFileInsertedIntoSP() throws Exception {
    System.out.println("InsertSharePointService_UT.testFileInsertedIntoSP");
    initRequestEntity(TEST_DOC_FILE_NAME, connectionInfo);
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile(TEST_DOC_ATTACHMENT_1);
    transformSPSpecificAttrs();
    insertDocument();
    validateObjectIdAndVersionPresentInResponse(getDocumentAttributesFromResponse());
  }

  private void validateObjectIdAndVersionPresentInResponse(DocumentAttributes documentAttributes) throws
      AttributeListParseException {
    assertNotNull(documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID));
    assertEquals("0.1", documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_VERSION));
  }

  private DocumentAttributes getDocumentAttributesFromResponse() {
    return ((RetrievedDocument) responseEntity.getRetrievedDocumentList().get(0)).getDocumentAttributes();
  }

  private void insertDocument() throws DocumentManagerException, AttributeListParseException, IOException {
    SharePointService.insert(requestEntity, responseEntity, mockHelper);
    responseEntity.sendResponseToClient(mockHelper);
  }

  public void testInsertThrowsExceptionWhenDocumentAlreadyExists() throws Exception {
//    insertTestDoc(TEST_2_FILE_NAME);
    initRequestEntity(TEST_2_FILE_NAME, connectionInfo);
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile(TEST_DOC_ATTACHMENT_1);
    transformSPSpecificAttrs();
    try {
      insertDocument();
      validateObjectIdAndVersionPresentInResponse(getDocumentAttributesFromResponse());
      fail("Document already present in the cabinet, exception not thrown.");
    } catch (Exception e) {
      System.out.println("Catch!!");
      System.out.println("e = " + e);
      System.out.println("e.getMessage() = " + e.getMessage());
      boolean isExceptionAdocumentManagerException = !(e instanceof DocumentManagerException);
      System.out.println("isExceptionAdocumentManagerException = " + isExceptionAdocumentManagerException);
      boolean doesExceptionsMessageStartWithExpectedText = (e.getMessage().startsWith("Document already present."));
      System.out.println("doesExceptionsMessageStartWithExpectedText = " + doesExceptionsMessageStartWithExpectedText);
      if (isExceptionAdocumentManagerException && doesExceptionsMessageStartWithExpectedText) {
        fail("Unknown Exception thrown.");
      }
    }
  }

  public void testFileInsertedWithAttributes() throws Exception {
    //ToDo: while this does pass, it doesn't actually assert what its name implies it should test; it is in the "bells & whistles" category; I got this working, except for multi-valued, but the test still doesn't assert the attributes are there, I only visually inspected them while having the teardown deletes commented out
    initRequestEntity(TEST_1_FILE_NAME, connectionInfo);
    initTestAttr();
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile(TEST_TEXT_FILE_1);
    transformSPSpecificAttrs();
    insertDocument();
    DocumentAttributes documentAttributesFromResponse = getDocumentAttributesFromResponse();
    String DocID = documentAttributesFromResponse.getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
    System.out.println("@@@DocID = " + DocID);
    validateObjectIdAndVersionPresentInResponse(documentAttributesFromResponse);
  }

	//ToDo: MECORU: Unfortunately, Sharepoint happily (and silently) ignores invalid attributes
//  public void testExceptionThrownIfFileInsertedWithInvalidAttributeNotRecognizedBySP() throws Exception {
//    initRequestEntity(TEST_1_FILE_NAME, connectionInfo);
//    initTestAttr();
//    initInvalidAttr();
//    mockHelper = new MockUCCHelper(null);
//    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_2);
//    mockHelper.addClientFile(TEST_TEXT_FILE_1);
//    transformSPSpecificAttrs();
//    try {
//      insertDocument();
//      DocumentAttributes response = getDocumentAttributesFromResponse();
//
//      Iterator attrIterator = response.getAttrIterator();
//      while (attrIterator.hasNext()) {
//        String key = (String) attrIterator.next();
//        String value = response.getAttrValue(key);
//        System.out.println(
//            "InsertSharePointService_UT.testExceptionThrownIfFileInsertedWithInvalidAttributeNotRecognizedBySP: key / value = " +
//                key + " / " + value);
//      }
//
//      validateObjectIdAndVersionPresentInResponse(response);
//      fail("a request with supposed invalid attributes was submitted, but no exception was thrown.");
//    } catch (DocumentManagerException e) {
//      System.out.println("catch!! invalidattrib");
//      System.out.println("e.getClass().getName() = " + e.getClass().getName());
//      System.out.println("e.getMessage() = " + e.getMessage());
//    }
//  }

  public void testFileInsertedWithAttributesIntoSpecifedDirectoryStructure() throws Exception {
    //ToDo: this is not passing and it doesn't really assert what it's name implies.  However, if I comment out the teardown stuff that deletes what this test creates, I do see that the folders are created, but the file is created in the root of the doclib; this is probably not "bells & whhistles" as I'm pretty sure bcfeForms relies on this behavior
    initRequestEntity(TEST_1_FILE_NAME, connectionInfo);
    initTestAttr();
    initDirStructure("dir/testFolder1/testFolder2");
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile(TEST_TEXT_FILE_1);
    transformSPSpecificAttrs();
    insertDocument();
    validateObjectIdAndVersionPresentInResponse(getDocumentAttributesFromResponse());
  }

  private void transformSPSpecificAttrs() throws AttributeListParseException, DocumentManagerException {
    AttributeTransformer attributeTransformer = new SharePointAttributeTransformer();
    List nameTransformationList = attributeTransformer.getTransformationList();
    requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
  }

  private void initDirStructure(String dir) {
    requestEntity.setDirectoryStructure(dir);
  }

  private void initInvalidAttr() {
    requestEntity.getDocumentAttributes().addAttribute("invalid-attribute", "testValue", null);
  }

  private void insertTestDoc(String fileName) throws DocumentManagerException, AttributeListParseException,
      IOException {
    initRequestEntity(fileName, connectionInfo);
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile(TEST_DOC_ATTACHMENT_2);
    transformSPSpecificAttrs();
    insertDocument();
  }

  private ConnectionInfo getConnectionParams(String docLib) {
    connectionInfo = new ConnectionInfo();
    connectionInfo.addConnectionParameter(DocumentManagerConstants.SP_CI_SITE_NAME, SP_SITE);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.SP_CI_DOC_LIB_NAME, docLib);
    return connectionInfo;
  }

  private void initRequestEntity(String fileName, ConnectionInfo connectionInfo) {
    requestEntity = new InsertSharePointRequestEntity();
    requestEntity.getDocumentAttributes().addAttribute("name", fileName, null);
    requestEntity.setConnectionInfo(connectionInfo);
  }

  private void initTestAttr() {
    requestEntity.getDocumentAttributes().addAttribute("subject", "testSubject", null);

    List keywordList = new ArrayList();
    keywordList.add("farm");
    keywordList.add("seed");
    keywordList.add("weed");
    requestEntity.getDocumentAttributes().addAttribute("keywords", keywordList, null);

    List authorList = new ArrayList();
    authorList.add("testAuthor1");
    authorList.add("testAuthor2");
    authorList.add("testAuthor3");
    requestEntity.getDocumentAttributes().addAttribute("authors", authorList, null);

    requestEntity.getDocumentAttributes().addAttribute("title", "testTitle", null);
    requestEntity.setConnectionInfo(connectionInfo);
  }
}