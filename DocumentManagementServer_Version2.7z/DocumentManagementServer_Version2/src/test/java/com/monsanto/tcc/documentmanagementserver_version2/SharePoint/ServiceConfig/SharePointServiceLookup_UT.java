package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.ServiceConfig;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import junit.framework.TestCase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 22, 2006 Time: 4:16:58 PM To change this template use File |
 * Settings | File Templates.
 */
public class SharePointServiceLookup_UT extends TestCase {

  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";
  IServiceLookup serviceLookup;
  private static final String ENCRYPTED_PASSWORD_MYTESTFOLDER1 = "comp03";

  protected void setUp() throws IOException, ServiceConfigException {
    serviceLookup = new SharePointServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
  }

  public void testReadingActualOfServiceConfigFile() throws Exception {
    serviceLookup = new SharePointServiceLookup();
    assertEquals("Dctm", serviceLookup.lookupRepositoryName("securedTestFolderAccessibleToTestRoles"));
  }

  public void testLookupRepositoryName() throws Exception {
    assertEquals("Dctm", serviceLookup.lookupRepositoryName("myTestFolder1"));
  }

  public void testLookupASharePointRepositoryName() throws Exception {
    assertEquals("SharePoint", serviceLookup.lookupRepositoryName("posTestFolder-SP"));
  }

  public void testLookupRepositoryNameForMultipleFolders() throws Exception {
    assertEquals("Dctm", serviceLookup.lookupRepositoryName("myTestFolder1"));
    assertEquals("Domino", serviceLookup.lookupRepositoryName("myTestFolder2"));
    assertEquals("SharePoint", serviceLookup.lookupRepositoryName("myTestFolder3"));
  }

  public void testServiceConfigExceptionIfFilePathIsIncorrect() throws Exception {
    assertEquals("Dctm", serviceLookup.lookupRepositoryName("myTestFolder1"));
    assertEquals("Domino", serviceLookup.lookupRepositoryName("myTestFolder2"));
    assertEquals("SharePoint", serviceLookup.lookupRepositoryName("myTestFolder3"));
  }


  public void testGetConnectionDetailsForASharePointRepository() throws Exception {
    ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails("posTestFolder-SP", "win");
    assertEquals("http://na1000spdev60/teamsite", connectionInfo.getConnectionParameterValue("site"));
    assertEquals("ScannedImages", connectionInfo.getConnectionParameterValue("documentLibrary"));
    assertFalse(connectionInfo.containsParameter("password"));
    assertFalse(connectionInfo.containsParameter("password"));
    assertFalse(connectionInfo.containsParameter("userName"));
    assertFalse(connectionInfo.containsParameter("docBase"));
    assertFalse(connectionInfo.containsParameter("cabinet"));
    assertFalse(connectionInfo.containsParameter("docBroker"));
    assertFalse(connectionInfo.containsParameter("objectType"));
  }

  public void testGetConnectionDetails_ReadsEncryptedPasswordCorrectly() throws Exception {
    ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails("myTestFolder1", "win");
    assertEquals(ENCRYPTED_PASSWORD_MYTESTFOLDER1, connectionInfo.getConnectionParameterValue("password"));
  }

  public void testGetConnectionDetailsForDifferentEnvironment() throws Exception {
    ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails("myTestFolder1", "someEnvironmentName");
    assertEquals("/APHIS CABINET DEV", connectionInfo.getConnectionParameterValue("cabinet"));
    assertEquals("stltst01", connectionInfo.getConnectionParameterValue("docBase"));
    assertEquals("stddma00.dev.monsanto.com", connectionInfo.getConnectionParameterValue("docBroker"));
    assertEquals("aphis", connectionInfo.getConnectionParameterValue("userName"));
    assertEquals("aphis_doc", connectionInfo.getConnectionParameterValue("objectType"));
  }

  public void testConnectionInfoContainsGroupInformation() throws Exception {
    ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails("testFolderWithGroups1", "win");
    assertTrue(connectionInfo.isFolderSecured());
    List expectedRoleList = new ArrayList();
    expectedRoleList.add("testGroup1");
    expectedRoleList.add("testGroup2");
    validateRoleList(connectionInfo, expectedRoleList);
  }

  public void testConnectionInfoContainsGroupInformationForDifferentEnvironment() throws Exception {
    ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails("testFolderWithGroups1", "test");
    assertTrue(connectionInfo.isFolderSecured());
    List expectedRoleList = new ArrayList();
    expectedRoleList.add("testGroup3");
    validateRoleList(connectionInfo, expectedRoleList);
  }

  public void testExceptionThrownIfGroupInfoIsNotPresentAndIsBeingQueried() throws Exception {
    ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails("testFolderWithGroups1", "dev");
    assertFalse(connectionInfo.isFolderSecured());
    try {
      connectionInfo.getConnectionParameterValues(DocumentManagerConstants.SERVICE_CONFIG_STR_GROUPS);
      fail("Exception not thrown");
    } catch (AttributeListParseException e) {
      System.out.println("Expected Path: reqd error msg thrown: " + e.getMessage());
    }
  }

  private void validateRoleList(ConnectionInfo connectionInfo, List expectedGroupList) throws
      AttributeListParseException {
    List roleList = connectionInfo.getConnectionParameterValues(DocumentManagerConstants.SERVICE_CONFIG_STR_GROUPS);
    for (int i = 0; i < expectedGroupList.size(); i++) {
      assertEquals(expectedGroupList.get(i), roleList.get(i));
    }
  }

}