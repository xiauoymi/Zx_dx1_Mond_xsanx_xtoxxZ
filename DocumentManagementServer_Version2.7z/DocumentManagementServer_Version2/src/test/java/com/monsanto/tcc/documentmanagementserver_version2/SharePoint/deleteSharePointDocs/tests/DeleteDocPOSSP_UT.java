package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.ServiceConfig.SharePointServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.DeleteDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.MockDeleteSharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.SharePointTestUtil;
import com.sun.org.apache.xpath.internal.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 16, 2006 Time: 5:34:11 PM To change this template use File |
 * Settings | File Templates.
 */
public class DeleteDocPOSSP_UT extends XMLTestCase {
	private static final String ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/deleteService/tests/testFile1.txt";
	private static final String INSERT_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/deleteSharePointDoc/tests/insertReq1.xml";
	private static final String UPDATE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/deleteSharePointDoc/tests/updateReq1.xml";
	private static final String DELETE_REQUEST_XML = "C:/deleteRequestDoc.xml";
	private static final String DELETE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/deleteSharePointDoc/tests/deleteRequest.xml";
	private static final String DELETE_REQUEST_WITH_VERSION_1_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/DeleteSharePointDoc/tests/deleteRequestWithVersion1.xml";
	private static final String DELETE_REQUEST_WITH_VERSION_2_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/DeleteSharePointDoc/tests/deleteRequestWithVersion2.xml";
	private static final String XPATH_BEGIN_STR = "/documentManagerResponse/documentDeletedSuccessfully/documentDetails/attribute[name = '";
	private static final String XPATH_END_STR = "']/value";
	private String objectId1;

	protected void setUp() throws Exception {
		objectId1 = SharePointTestUtil.insertTestDocument(ATTACHMENT_1, INSERT_XML_1);
		System.out.println("DeleteDocPOS_UT.setUp: objectId1 = " + objectId1);
	}

	protected void tearDown() throws Exception {
		deleteTemporaryXMLDocument();
		try {
			SharePointTestUtil.deleteAllVersionsOfInsertedDocument(objectId1);
		} catch (Exception e) {
			//Ignore
		}
	}

	public void testDelete_WithoutVersionSpecification_DeletesAllVersions() throws Exception {
		updateVersion();
		deleteDocumentWithVersion(DELETE_REQUEST_TEMPLATE, DocumentManagerConstants.RESP_CONST_ALL_VERSIONS_DELETED);
	}

	public void testDelete_WithVersionSpecification_DeletesCorrectVersion() throws Exception {
		updateVersion();
		deleteDocumentWithVersion(DELETE_REQUEST_WITH_VERSION_1_TEMPLATE, "1.0");
		deleteDocumentWithVersion(DELETE_REQUEST_WITH_VERSION_2_TEMPLATE, "0.1");
	}

	private void updateVersion() throws Exception {
		String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
		Document updateReq = SharePointTestUtil
			.transformRequestXML(UPDATE_REQUEST_TEMPLATE, objectId1, updateTransformationXPathString, 0);
		SharePointTestUtil.updateDocument(ATTACHMENT_1, updateReq, DocumentManagerConstants.WORD_DOC_FILETYPE);
	}

	private void deleteDocumentWithVersion(String deleteRequestTemplate, String versionsDeleted) throws ParserException,
		TransformerException, IOException {
		MockUCCHelper mockUCCHelper = runDeleteCommandThruPOSController(deleteRequestTemplate);
		Document deleteReponseDoc = mockUCCHelper.getXML();
		DOMUtil.outputXML(deleteReponseDoc);
		validateResponse(deleteReponseDoc, objectId1, versionsDeleted);
	}

	private MockUCCHelper runDeleteCommandThruPOSController(String deleteRequestTemplate) throws ParserException,
		TransformerException, IOException {
		createTestDeleteRequestXML(DELETE_REQUEST_XML, objectId1, deleteRequestTemplate);
		DeleteDocumentPOS deleteDocumentPOS = new MockDeleteDocPOSWithTestConfig();
		MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
		mockUCCHelper.addClientFile(DELETE_REQUEST_XML);
		deleteDocumentPOS.run(mockUCCHelper);
		return mockUCCHelper;
	}

	private void validateResponse(Document deleteReponseDoc, String deletedObjectId, String versionsDeleted) throws
		TransformerException {
		assertXpathEvaluatesTo(deletedObjectId,
													 XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR,
													 deleteReponseDoc);
		assertXpathEvaluatesTo(versionsDeleted, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_VERSION + XPATH_END_STR,
													 deleteReponseDoc);
	}

	private void createTestDeleteRequestXML(String deleteRequestFilenamePath, String objectId,
																					String deleteRequestTemplate) throws FileNotFoundException, ParserException,
		TransformerException {
		Document deleteRequestDoc = DOMUtil.newDocument(deleteRequestTemplate);
		Node objectIdValueNode = XPathAPI.eval(deleteRequestDoc,
																					 "/inputPos/command/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
			.nodelist().item(0);
		Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
		objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
		saveAsXMLFile(deleteRequestDoc, deleteRequestFilenamePath);
	}

	private void deleteTemporaryXMLDocument() {
		new File(DELETE_REQUEST_XML).delete();
	}

	private void saveAsXMLFile(Document deleteRequestDoc, String deleteRequestFilenamePath) throws FileNotFoundException {
		DOMUtil.outputXML(deleteRequestDoc, new FileOutputStream(new File(deleteRequestFilenamePath)));
	}

	class MockDeleteDocPOSWithTestConfig extends DeleteDocumentPOS {
		protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
			return new SharePointServiceLookup(DocumentManagerConstants.TEST_SERVICE_CONFIG_FILE_NAME);
		}

		public DocBuilder getBuilder(Document inputDocument) throws ServiceConfigException {
			return new MockDeleteSharePointBuilder();
		}
	}

}