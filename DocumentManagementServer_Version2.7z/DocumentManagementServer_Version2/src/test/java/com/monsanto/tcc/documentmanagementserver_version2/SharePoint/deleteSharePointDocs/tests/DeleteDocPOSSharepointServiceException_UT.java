package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.DeleteDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.MockDeleteSharePointBuilder;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 16, 2006 Time: 5:27:19 PM To change this template use File |
 * Settings | File Templates.
 */
public class DeleteDocPOSSharepointServiceException_UT extends XMLTestCase {
  private static final String DELETE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/DeleteSharePointDoc/tests/deleteRequest.xml";
  private static final String DELETE_REQUEST_WITHOUT_OBJECTID_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/DeleteSharePointDoc/tests/deleteRequestWithoutObjectId.xml";
  private static final String DELETE_REQUEST_XML = "C:/deleteRequestDoc.xml";
  private static final String ERROR_MESSAGE_TAG = "/ERROR/ERROR_MESSAGE";

  protected void tearDown() throws Exception {
    deleteTemporaryXMLDocument();
  }

  public void testDeleteServiceThrowsExceptionIfInvalidObjectIdRequestedToBeDeleted() throws Exception {
    createTestDeleteRequestXML(DELETE_REQUEST_XML, "InvalidObjectId", DELETE_REQUEST_TEMPLATE);
    DeleteDocumentPOS deleteDocumentPOS = new MockDelPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(DELETE_REQUEST_XML);
    deleteDocumentPOS.run(mockUCCHelper);
    Document deleteReponseDoc = mockUCCHelper.getXML();
    validateErrorResponseForInvalidObjectId(deleteReponseDoc);
  }

  public void testDeleteWithoutObjectId_ThrowsException() throws Exception {
    createTestDeleteRequestXML(DELETE_REQUEST_XML, "someObjectId", DELETE_REQUEST_WITHOUT_OBJECTID_TEMPLATE);
    DeleteDocumentPOS deleteDocumentPOS = new MockDelPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(DELETE_REQUEST_XML);
    deleteDocumentPOS.run(mockUCCHelper);
    Document deleteReponseDoc = mockUCCHelper.getXML();
    validateErrorResponseForObjectIdNotPresent(deleteReponseDoc);
  }

  private void validateErrorResponseForInvalidObjectId(Document deleteReponseDoc) throws TransformerException {
    String expectedMessage = "Exception while deleting all versions of document by id";
    String actualErrorMessage = XPathAPI.eval(deleteReponseDoc, ERROR_MESSAGE_TAG).toString();
    System.out.println(
        "DeleteDocPOSServiceException_UT.validateErrorResponseForInvalidObjectId: actualErrorMessage = " +
            actualErrorMessage);
    if (actualErrorMessage.indexOf(expectedMessage) == -1) {
      fail("Appropriate error message for invalid object Id not thrown");
    }
  }

  private void validateErrorResponseForObjectIdNotPresent(Document deleteReponseDoc) throws TransformerException {
    String expectedMessage = "The Attribute \"LegacyDocumentID\" not present";
    String actualErrorMessage = XPathAPI.eval(deleteReponseDoc, ERROR_MESSAGE_TAG).toString();
    System.out.println(
        "DeleteDocPOSServiceException_UT.validateErrorResponseForObjectIdNotPresent: actualErrorMessage = " +
            actualErrorMessage);
    if (actualErrorMessage.indexOf(expectedMessage) == -1) {
      fail("Appropriate error message for invalid object Id not thrown");
    }
  }

  private void createTestDeleteRequestXML(String deleteRequestFilenamePath, String objectId,
                                          String deleteRequestTemplate) throws FileNotFoundException, ParserException,
      TransformerException {
    Document deleteRequestDoc = DOMUtil.newDocument(deleteRequestTemplate);
    Node objectIdValueNode = XPathAPI.eval(deleteRequestDoc,
        "/inputPos/command/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    saveAsXMLFile(deleteRequestDoc, deleteRequestFilenamePath);
  }

  private void saveAsXMLFile(Document deleteRequestDoc, String deleteRequestFilenamePath) throws FileNotFoundException {
    DOMUtil.outputXML(deleteRequestDoc, new FileOutputStream(new File(deleteRequestFilenamePath)));
  }

  private void deleteTemporaryXMLDocument() {
    new File(DELETE_REQUEST_XML).delete();
  }

  class MockDelPOS extends DeleteDocumentPOS {
    protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
      return new ServiceLookup(DocumentManagerConstants.TEST_SERVICE_CONFIG_FILE_NAME);
    }

    public DocBuilder getBuilder(Document inputDocument) throws ServiceConfigException {
      return new MockDeleteSharePointBuilder();
    }
  }
}