package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.DeleteDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.MockDeleteSharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.SharePointTestUtil;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jun 13, 2006 Time: 2:48:22 PM To change this template use File |
 * Settings | File Templates.
 */
public class DeletePOSVersionExceptionSP_UT extends XMLTestCase {
  private static final String DELETE_REQUEST_WITH_INVALID_VERSION_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/DeleteSharePointDoc/tests/deleteRequestWithInvalidVersion.xml";
  private static final String DELETE_REQUEST_XML = "C:/deleteRequestDoc.xml";
  private static final String ERROR_MESSAGE_TAG = "/ERROR/ERROR_MESSAGE";
  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";
  private static final String INSERT_REQUEST_XML = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/DeleteSharePointDoc/tests/insertRequest.xml";
  private static final String CONTENTS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private String objectId;

  protected void setUp() throws Exception {
    objectId = SharePointTestUtil.insertTestDocument(CONTENTS, INSERT_REQUEST_XML);
  }

  protected void tearDown() throws Exception {
    SharePointTestUtil.deleteAllVersionsOfInsertedDocument(objectId);
    deleteLocalTempFile();
  }

  public void testDeleteWithInvalidVersion_ThrowsException() throws Exception {
    createTestDeleteRequestXML(DELETE_REQUEST_XML, objectId, DELETE_REQUEST_WITH_INVALID_VERSION_TEMPLATE);
    DeleteDocumentPOS deleteDocumentPOS = new MockDelPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(DELETE_REQUEST_XML);
    deleteDocumentPOS.run(mockUCCHelper);
    Document deleteResponseDoc = mockUCCHelper.getXML();
    validateErrorResponseForObjectIdNotPresent(deleteResponseDoc);
  }

  private void deleteLocalTempFile() {
    new File(DELETE_REQUEST_XML).delete();
  }

  private void validateErrorResponseForObjectIdNotPresent(Document deleteReponseDoc) throws TransformerException {
    String expectedMessage = "version label = 'InvalidVersion' does not exist";
    String actualErrorMessage = XPathAPI.eval(deleteReponseDoc, ERROR_MESSAGE_TAG).toString();
    System.out.println("actualErrorMessage = " + actualErrorMessage);
    if (actualErrorMessage.indexOf(expectedMessage) == -1) {
			System.out.println("ABOUT TO FAIL");
			fail("Appropriate error message for invalid version label not thrown");
    }
  }

  private void createTestDeleteRequestXML(String deleteRequestFilenamePath, String objectId,
                                          String deleteRequestTemplate) throws FileNotFoundException, ParserException,
      TransformerException {
    Document deleteRequestDoc = DOMUtil.newDocument(deleteRequestTemplate);
    Node objectIdValueNode = XPathAPI.eval(deleteRequestDoc,
        "/inputPos/command/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    saveAsXMLFile(deleteRequestDoc, deleteRequestFilenamePath);
  }

  private void saveAsXMLFile(Document deleteRequestDoc, String deleteRequestFilenamePath) throws FileNotFoundException {
    DOMUtil.outputXML(deleteRequestDoc, new FileOutputStream(new File(deleteRequestFilenamePath)));
  }

  class MockDelPOS extends DeleteDocumentPOS {
    protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
      return new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    }

    public DocBuilder getBuilder(Document inputDocument) throws ServiceConfigException {
      return new MockDeleteSharePointBuilder();
    }
  }
}