package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.tests;

import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockRetrieveSharePointRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.parser.RetrieveSharePointRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.entity.RetrieveSharePointRequestEntity;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 29, 2006
 * Time: 10:15:19 AM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveSharePointRequestParser_UT extends TestCase {
  private static final String TEST_CUSTOM_ATTR_RETRIEVE_REQUEST_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/retrieveSharePointDoc/tests/TestCustomAttrRetrieveReq1-SP.xml";
  private static final String TEST_RETRIEVE_REQUEST_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/retrieveSharePointDoc/tests/TestRetrieveDocRequest-SP.xml";
  RetrieveSharePointRequestParser retrieveParser;
  RetrieveSharePointRequestEntity requestEntity;
  private static final String REQUEST_DETAILS = "requestDetails";
  private static final String OBJECT_ID = "objectId";
  private static final String LARRYS_SP_DEV_VM_TEAMSITE = "http://na1000spdev60/teamsite";
  private static final String SCANNEDIMAGES = "ScannedImages";

  public void setUp(){
    retrieveParser = new MockRetrieveSharePointRequestParser();
    requestEntity = new RetrieveSharePointRequestEntity();
  }

  public void testParsingOfFolderAndDirectoryNameWithCorrectStructure() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_RETRIEVE_REQUEST_XML_1);
    retrieveParser.parseInputXML(inputDocument,requestEntity);
    assertEquals("myTestFolder3", requestEntity.getFolderName());
    assertEquals("test/folder1/folder2", requestEntity.getDirectoryStructure());
  }

  public void testServiceSpecificConfigDetailsParsedCorrectlyForRequestingRetrieveDocument() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_RETRIEVE_REQUEST_XML_1);
    retrieveParser.parseInputXML(inputDocument, requestEntity);
		assertEquals(LARRYS_SP_DEV_VM_TEAMSITE, requestEntity.getConnectionInfo().getConnectionParameterValue(DocumentManagerConstants.SP_CI_SITE_NAME));
    assertEquals(SCANNEDIMAGES, requestEntity.getConnectionInfo().getConnectionParameterValue(DocumentManagerConstants.SP_CI_DOC_LIB_NAME));
  }

  public void testParsingOfDocumentAttributesAndCheckingObjectIdValue() throws Exception {
    parseRequestXML(TEST_RETRIEVE_REQUEST_XML_1);
    validateDocumentAttributes("09001abe80089209");
  }

  public void testParsingOfCustomRequiredAttributes() throws Exception {
    parseRequestXML(TEST_CUSTOM_ATTR_RETRIEVE_REQUEST_XML_1);
    validateDocumentAttributes("09001abe80089209");
    validateRequiredAttributes();
  }

  private void parseRequestXML(String requestXML) throws ParserException, DocumentManagerException {
    Document inputDocument = DOMUtil.newDocument(requestXML);
    Node requestNode = DOMUtil.getChild(inputDocument.getDocumentElement(), REQUEST_DETAILS);
    retrieveParser.parseOperationSpecificRequest(requestNode, requestEntity);
  }

  private void validateDocumentAttributes(String objectId) throws AttributeListParseException {
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    assertEquals(1, documentAttributes.getLength());
    assertEquals(objectId, documentAttributes.getAttrValue(OBJECT_ID));
  }

  private void validateRequiredAttributes() {
    List requiredAttributes = requestEntity.getRequiredAttributes();
    assertEquals(3, requiredAttributes.size());
    assertEquals("title", requiredAttributes.get(0));
    assertEquals("subject", requiredAttributes.get(1));
    assertEquals("keywords", requiredAttributes.get(2));
  }
}