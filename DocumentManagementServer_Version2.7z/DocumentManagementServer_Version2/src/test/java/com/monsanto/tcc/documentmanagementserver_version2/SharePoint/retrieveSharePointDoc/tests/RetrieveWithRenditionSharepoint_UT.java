package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.tests;

import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.Util.databasepasswordencryption.Helper.Base64;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.entity.RetrieveSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocumentService;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockRetrieveSharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.retrieveService.RetrieveDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.SharePointTestUtil;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 22, 2006 Time: 4:06:48 PM To change this template use File |
 * Settings | File Templates.
 */
public class RetrieveWithRenditionSharepoint_UT extends XMLTestCase {
  private static final String RETRIEVE_WITH_RENDITION_REQUEST_XML = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/retrieveService/tests/retrieveWithRenditionRequest-SP.xml";
  private static final String XPATH_BEGIN_STR = "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name = '";
  private static final String XPATH_END_STR = "']/value";
  private static final String TEST_DOC_NAME = "attachment1";
  private static final String TEST_DOC_SUBJECT = "farm resource";
  private static final String TEST_DOC_TITLE = "monsanto search docs";
  private static final String TEST_DOC_SIZE = "9";
  private static List TEST_KEYWORDS;
  private String objectId;
  private static final String RETRIEVE_REQUEST_XML = "C:/retrieveRequestDoc.xml";
  private static final String ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private static final String INSERT_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/insertReq1-SP.xml";
	private static final String EXPECTED_CONTENTS = "Test Data";

	static {
    TEST_KEYWORDS = new ArrayList();
		TEST_KEYWORDS.add("field");
		TEST_KEYWORDS.add("farm");
  }

  protected void setUp() throws Exception {
    objectId = SharePointTestUtil.insertTestDocument(ATTACHMENT_1, INSERT_XML_1);
  }

  protected void tearDown() throws Exception {
    if (objectId != null && objectId.length() > 0) {
      deleteTemporaryInsertedAndCreatedFiles();
    }
  }

  public void testRetrieveRequestWithRendition_FormatAttributeParsedCorrectly() throws Exception {
    RetrieveDocumentPOS retrieveDocumentPOS = new MockRetrieveDocPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    createRequestXML(RETRIEVE_REQUEST_XML, objectId);
    mockUCCHelper.addClientFile(RETRIEVE_REQUEST_XML);
    retrieveDocumentPOS.run(mockUCCHelper);
    Document retrieveReponseDoc = DOMUtil.newDocument(mockUCCHelper.getInputStream(""));
    validateResponse(retrieveReponseDoc);
  }

  private void createRequestXML(String filenamePath, String objectId) throws FileNotFoundException, ParserException,
      TransformerException {
    Document requestDoc = DOMUtil.newDocument(RETRIEVE_WITH_RENDITION_REQUEST_XML);
    Node objectIdValueNode = XPathAPI
        .eval(requestDoc, "//retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = requestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    saveAsXMLFile(requestDoc, filenamePath);
  }

  private void saveAsXMLFile(Document deleteRequestDoc, String deleteRequestFilenamePath) throws FileNotFoundException {
    DOMUtil.outputXML(deleteRequestDoc, new FileOutputStream(new File(deleteRequestFilenamePath)));
  }

  private void deleteTemporaryInsertedAndCreatedFiles() throws ParserException, IOException, TransformerException,
      POSException, POSCommunicationException, GSSException, ServiceConfigException, EncryptorException,
      AttributeListParseException {
    deleteFromSharepoint();
    deleteFromFileSystem();
  }

  private void deleteFromSharepoint() throws IOException, ParserException, TransformerException, GSSException, POSException,
      POSCommunicationException, ServiceConfigException, AttributeListParseException, EncryptorException {
    SharePointTestUtil.deleteAllVersionsOfInsertedDocument(objectId);
  }

  private void deleteFromFileSystem() {
    new File(RETRIEVE_REQUEST_XML).delete();
  }

  private void validateResponse(Document retrieveReponseDoc) throws TransformerException {
    DOMUtil.outputXML(retrieveReponseDoc);
    assertXpathEvaluatesTo(objectId,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR,
        retrieveReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_NAME, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_NAME + XPATH_END_STR,
        retrieveReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_SUBJECT,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_SUBJECT + XPATH_END_STR,
        retrieveReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_TITLE, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_TITLE + XPATH_END_STR,
        retrieveReponseDoc);
    assertXpathEvaluatesTo(System.getProperty("user.name").toLowerCase(),
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_CREATOR + XPATH_END_STR,
        retrieveReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_SIZE, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_SIZE + XPATH_END_STR,
        retrieveReponseDoc);
    assertXpathEvaluatesTo(Base64.encode(EXPECTED_CONTENTS.getBytes()), XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_CONTENTS + XPATH_END_STR,
        retrieveReponseDoc);
		for (int i = 0; i < TEST_KEYWORDS.size(); i++) {
      String expectedKeyword = (String) TEST_KEYWORDS.get(i);
      assertXpathEvaluatesTo(expectedKeyword, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_KEYWORDS
          + XPATH_END_STR + "[" + (i + 1) + "]", retrieveReponseDoc);
    }
  }

  class MockRetrieveDocPOS extends RetrieveDocumentPOS {

    protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
      return new ServiceLookup(DocumentManagerConstants.TEST_SERVICE_CONFIG_FILE_NAME);
    }

    public DocBuilder getBuilder(Document inputDocument) throws ServiceConfigException {
      return new MockRetrieveSharePointBuilder();
    }

    public void performOperation(RequestEntity requestEntity, DocumentService service, ResponseEntity responseEntity,
                                 UCCHelper helper) throws DocumentManagerException {
      System.out.println("RetrieveWithRendition_UT$MockRetrieveDocPOS.performOperation");
      try {
        validateConnectionParams(requestEntity);
      } catch (AttributeListParseException e) {
        System.out.println("THROWING EXCEPTION");
        throw new DocumentManagerException(e);
      }

//			try {
//				validateTransformedRequestEntity(requestEntity);
//			} catch (AttributeListParseException e) {
//				fail(e.toString());
//				throw new DocumentManagerException("Required/Query Attr not parsed correctly");
//			}
      System.out.println("ABOUT TO CALL SUPER");
//			RetrievedDocument retrievedDocument = buildMockRetrievedDocument();
//			sendMockResponse(responseEntity, retrievedDocument);
      super.performOperation(requestEntity, service, responseEntity, helper);
    }

//		private RetrievedDocument buildMockRetrievedDocument() {
//			RetrievedDocument retrievedDocument = new RetrievedDocument();
//			retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, objectId, null);
//			retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_NAME, TEST_DOC_NAME, null);
//			retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT, TEST_DOC_SUBJECT, null);
//			retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, TEST_KEYWORDS, null);
//			retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CREATOR, TEST_DOC_CREATOR, null);
//			retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_SIZE, TEST_DOC_SIZE, null);
//			retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TEST_DOC_TITLE, null);
//			return retrievedDocument;
//		}

//		private void validateTransformedRequestEntity(RequestEntity requestEntity) throws DocumentManagerException, AttributeListParseException {
//			RetrieveDocumentumRequestEntity retrieveRequestEntity = (RetrieveDocumentumRequestEntity) requestEntity;
//			List requiredAttributes = retrieveRequestEntity.getRequiredAttributes();
//			if (!requiredAttributes.get(0).equals(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT) ||
//				!requiredAttributes.get(1).equals(DocumentManagerConstants.DCTM_ATTR_STR_KEYWORDS) ||
//				!requiredAttributes.get(2).equals(DocumentManagerConstants.DCTM_ATTR_STR_CREATOR) ||
//				!requiredAttributes.get(3).equals(DocumentManagerConstants.DCTM_ATTR_STR_SIZE) ||
//				!requiredAttributes.get(4).equals(DocumentManagerConstants.ATTR_STR_TITLE)
//				) {
//				throw new DocumentManagerException("Required Attributes not parsed correctly");
//			}
//			if (!retrieveRequestEntity.getDocumentAttributes().getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID).equals(objectId)
//				) {
//				throw new DocumentManagerException("Query Attribute not parsed correctly");
//			}
//			validateFormatAttributePresentInRequest(retrieveRequestEntity);
//		}

//		private void validateFormatAttributePresentInRequest(RetrieveDocumentumRequestEntity retrieveRequestEntity) throws AttributeListParseException, DocumentManagerException {
//			if (!retrieveRequestEntity.getDocumentAttributes().getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_FORMAT).equals(TEST_REQUIRED_FORMAT)
//				) {
//				throw new DocumentManagerException("Format Attribute not parsed correctly");
//			}
//		}

    private void validateConnectionParams(RequestEntity requestEntity) throws DocumentManagerException,
        AttributeListParseException {
      RetrieveSharePointRequestEntity retrieveRequestEntity = (RetrieveSharePointRequestEntity) requestEntity;
      if (!retrieveRequestEntity.getFolderName().equalsIgnoreCase("posTestFolder-SP") ||
          !retrieveRequestEntity.getDirectoryStructure().equalsIgnoreCase("testDir1/testDir2")) {
        System.out.println("THROWING EXCEPTION");
        throw new DocumentManagerException("Connection/Configuration params not parsed correctly");
      }
    }

//		private void sendMockResponse(ResponseEntity responseEntity, RetrievedDocument retrievedDocument) {
//			responseEntity.getRetrievedDocumentList().add(retrievedDocument);
//		}
  }
}