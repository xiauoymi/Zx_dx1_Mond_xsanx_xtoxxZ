package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.retrieveSharePointDoc.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.Util.FileUtil;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockRetrieveSharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.retrieveService.RetrieveDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.SharePointTestUtil;
import org.apache.xerces.impl.dv.util.Base64;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jun 9, 2006 Time: 9:37:03 AM To change this template use File |
 * Settings | File Templates.
 */
public class RetrieveWithVersionSharepoint_UT extends XMLTestCase {
  public static final String INSERT_VERSION = "1.0";
  public static final String UPDATE_VERSION = "2.0";
  private static final String INSERT_REQUEST_XML = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/DeleteSharePointDoc/tests/insertRequest.xml";
  private static final String CONTENTS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private static final String UPDATE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/updateSharePointDoc/tests/updateRequest-SP.xml";
  private static final String UPDATED_CONTENTS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testSP.doc";
  private String objectId;
  public static final String RETRIEVE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/retrieveSharePointDoc/tests/retrieveRequest-SP.xml";
  public static final String RETRIEVE_REQUEST_WITH_VERSION_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/retrieveSharePointDoc/tests/retrieveRequestWithVersion-SP.xml";
  public static final String RETRIEVE_REQUEST_WITH_INVALID_VERSION_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/retrieveSharePointDoc/tests/retrieveRequestWithInvalidVersion-SP.xml";
  public static final String RETRIEVE_REQUEST_XML = "C:/retrieveReq.xml";
  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";
  private static final String DOC_NAME = "RetrieveVersionTestFile";
  private static final String DOC_TITLE = "monsanto search docs";
  private static final String UPDATED_DOC_TITLE = "newTitle";
  private static final String DOC_SUBJECT = "farm resource";
  public static final String RETRIEVE_WITH_VERSION_TEMP_FILE = "C:/testRetrieveWithVersion.doc";

  protected void setUp() throws Exception {
    objectId = SharePointTestUtil.insertTestDocument(CONTENTS, INSERT_REQUEST_XML);
		System.out.println("RetrieveWithVersionSharepoint_UT.setUp: objectId = " + objectId);
		String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document updateReq = SharePointTestUtil.transformRequestXML(UPDATE_REQUEST_TEMPLATE, objectId, updateTransformationXPathString, 0);
    SharePointTestUtil.updateDocument(UPDATED_CONTENTS, updateReq, DocumentManagerConstants.WORD_DOC_FILETYPE);
  }

  protected void tearDown() throws Exception {
    if (objectId != null && objectId.length() > 0) {
      SharePointTestUtil.deleteAllVersionsOfInsertedDocument(objectId);
    }
    deleteTempFileFromLocalSystem(RETRIEVE_REQUEST_XML);
    deleteTempFileFromLocalSystem(RETRIEVE_WITH_VERSION_TEMP_FILE);
  }

  public void testRetrieveRequestWithoutVersion_ReturnsCurrentVersion() throws Exception {
    RetrieveDocumentPOS retrieveDocumentPOS = new MockRetrieveDocumentPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    String xpathString = "/inputPos/command/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute/value";
    Document retrieveReq = SharePointTestUtil.transformRequestXML(RETRIEVE_REQUEST_TEMPLATE, objectId, xpathString, 0);
    saveAsXMLFile(retrieveReq, RETRIEVE_REQUEST_XML);
    mockUCCHelper.addClientFile(RETRIEVE_REQUEST_XML);
    retrieveDocumentPOS.run(mockUCCHelper);
    Document retrieveReponseDoc = DOMUtil.newDocument(mockUCCHelper.getInputStream(""));
    validateContentsOfExpectedVersion(retrieveReponseDoc, UPDATED_CONTENTS);
    validateResponseOfExpectedVersion(retrieveReponseDoc, UPDATED_DOC_TITLE, DOC_SUBJECT, "2.0");
  }

	//toDo: X-test until we get custom Sharepoint service from Vishal
	public void XtestRetrieveRequestWithVersion_ReturnsRequiredVersion() throws Exception {
    RetrieveDocumentPOS retrieveDocumentPOS = new MockRetrieveDocumentPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    String xpathString = "/inputPos/command/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute/value";
    Document retrieveReq = SharePointTestUtil.transformRequestXML(RETRIEVE_REQUEST_WITH_VERSION_TEMPLATE, objectId, xpathString, 0);
    saveAsXMLFile(retrieveReq, RETRIEVE_REQUEST_XML);
    mockUCCHelper.addClientFile(RETRIEVE_REQUEST_XML);
    retrieveDocumentPOS.run(mockUCCHelper);
    Document retrieveReponseDoc = DOMUtil.newDocument(mockUCCHelper.getInputStream(""));
    validateContentsOfExpectedVersion(retrieveReponseDoc, CONTENTS);
    validateResponseOfExpectedVersion(retrieveReponseDoc, DOC_TITLE, DOC_SUBJECT, "1.0");
  }

	//ToDo: Would need a test where I ask for specific version 2.0 and it is the latest - Sharepoint will say @2.0 in the version response

	//ToDo: Need another test where I grab a specific version (previous one) and ask for the "keywords" attribute for multi-value support

	public void testRetrieveRequestWithInvalidVersion_ThrowsException() throws Exception {
    RetrieveDocumentPOS retrieveDocumentPOS = new MockRetrieveDocumentPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    String xpathString = "/inputPos/command/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute/value";
    Document retrieveReq = SharePointTestUtil
        .transformRequestXML(RETRIEVE_REQUEST_WITH_INVALID_VERSION_TEMPLATE, objectId, xpathString, 0);
    saveAsXMLFile(retrieveReq, RETRIEVE_REQUEST_XML);
    mockUCCHelper.addClientFile(RETRIEVE_REQUEST_XML);
    retrieveDocumentPOS.run(mockUCCHelper);
    assertXpathExists("/ERROR/ERROR_MESSAGE", mockUCCHelper.getXML());
  }

  private void validateContentsOfExpectedVersion(Document retrieveReponseDoc, String contentsToCompareWith) throws
      IOException, TransformerException {
    String pathToRetrievedFile = getRetrievedDocumentContents(retrieveReponseDoc);
		System.out.println("RetrieveWithVersionSharepoint_UT.validateContentsOfExpectedVersion: pathToRetrievedFile = " + pathToRetrievedFile);
		//ToDo
		System.out.println("RetrieveWithVersionSharepoint_UT.validateContentsOfExpectedVersion: contentsToCompareWith = " + contentsToCompareWith);
		assertTrue(FileUtil.compareFiles(contentsToCompareWith, pathToRetrievedFile));
  }

  private String getRetrievedDocumentContents(Document retrieveReponseDoc) throws IOException, TransformerException {
    String xpathStr = "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name='" +
        DocumentManagerConstants.ATTR_STR_CONTENTS + "']/value";
    assertXpathExists(xpathStr, retrieveReponseDoc);
    String encodedContents = XPathAPI.eval(retrieveReponseDoc, xpathStr).toString();
		byte decodedByte[] = Base64.decode(encodedContents);
    String filePath = RETRIEVE_WITH_VERSION_TEMP_FILE;
    FileOutputStream foStream = new FileOutputStream(filePath);
    foStream.write(decodedByte, 0, decodedByte.length);
    foStream.flush();
    foStream.close();
    return filePath;
  }

  private void deleteTempFileFromLocalSystem(String fileName) {
    new File(fileName).delete();
  }

  private void validateResponseOfExpectedVersion(Document responseDocument, String titleValue, String subjectValue,
                                                 String versionLabel) throws TransformerException {
    validateAttribute(responseDocument, DocumentManagerConstants.ATTR_STR_NAME, DOC_NAME);
    validateAttribute(responseDocument, DocumentManagerConstants.ATTR_STR_TITLE, titleValue);
    validateAttribute(responseDocument, DocumentManagerConstants.ATTR_STR_SUBJECT, subjectValue);
    validateAttribute(responseDocument, DocumentManagerConstants.ATTR_STR_VERSION, versionLabel);
  }

  private void validateAttribute(Document responseDocument, String attrName, String attrValue) throws
      TransformerException {
    assertXpathEvaluatesTo(attrValue,
        "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name='" + attrName + "']/value",
        responseDocument);
  }

  private void saveAsXMLFile(Document requestDoc, String requestFileName) throws FileNotFoundException {
    DOMUtil.outputXML(requestDoc, new FileOutputStream(new File(requestFileName)));
  }

  class MockRetrieveDocumentPOS extends RetrieveDocumentPOS {

    protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
      return new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    }

		public DocBuilder getRepositorySpecificBuilder(String repositoryName) throws ServiceConfigException {
			return new MockRetrieveSharePointBuilder();
		}
	}
}