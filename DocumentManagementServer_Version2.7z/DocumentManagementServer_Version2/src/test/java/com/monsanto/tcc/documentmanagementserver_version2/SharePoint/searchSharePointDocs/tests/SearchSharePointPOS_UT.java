package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.searchSharePointDocs.entity.SearchSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.*;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.searchService.SearchDocumentsPOS;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.SharePointTestUtil;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 10, 2006 Time: 9:10:29 AM To change this template use File |
 * Settings | File Templates.
 */
public class SearchSharePointPOS_UT extends XMLTestCase {
  private static final String SEARCH_REQUEST_XML = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/searchSharePointDocs/tests/searchRequest-SP.xml";
  private static final String SEARCH_REQUEST_BY_NAME_XML = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/searchSharePointDocs/tests/searchRequestByName-SP.xml";
  //  private static final String SEARCH_REQUEST_ALL_VERSIONS = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/searchSharePointDocs/tests/searchRequestAllVersions-SP.xml";
  public static final String SEARCH_REQUEST_CURRENT_VERSIONS = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/searchSharePointDocs/tests/searchRequestCurrentVersions-SP.xml";
  public static final String SEARCH_REQUEST_CURRENT_VERSIONS2 = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/searchSharePointDocs/tests/searchRequestCurrentVersions2-SP.xml";
  private static final String TEST_DOC_ID = "1234";
  private static final String TEST_DOC_NAME = "testName.doc";
  private static final String TEST_DOC_SUBJECT = "testSubject";
  private static final String TEST_DOC_TITLE = "testTitle";
  private static final String TEST_DOC_CREATOR = "testCreator";
  private static final String TEST_DOC_SIZE = "99";
  private static final String TITLE_ATTR_OPERATOR = "equals";
  private static final String TEST_PAGE_COUNT = "3";
  private static final String PAGE_CNT_ATTR_OPERATOR = "equals";
  private static final String AUTHOR_ATTR_OPERATOR = "equals";
  private static final String TEST_AUTHOR = "admin";
  private static List TEST_KEYWORDS;
  private String objectId1;
  private String objectId2;
  private static final String INSERT_REQUEST_1_XML = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/searchSharePointDocs/tests/insertRequest1-SP.xml";
  private static final String UPDATE_REQUEST_1_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/searchSharePointDocs/tests/updateRequest1-SP.xml";
  private static final String INSERT_REQUEST_2_XML = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/searchSharePointDocs/tests/insertRequest2-SP.xml";
  private static final String UPDATE_REQUEST_2_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/searchSharePointDocs/tests/updateRequest2-SP.xml";
  private int totalNumberOfDocuments = 0;
  private int numberOfCurrentDocuments = 0;

  static {
    TEST_KEYWORDS = new ArrayList();
    TEST_KEYWORDS.add("farm");
    TEST_KEYWORDS.add("crop");
    TEST_KEYWORDS.add("field");
  }

  protected void setUp() throws Exception {
    objectId1 = SharePointTestUtil.deleteExistingDocumentIdAndInsert(INSERT_REQUEST_1_XML, UPDATE_REQUEST_1_TEMPLATE);
    objectId2 = SharePointTestUtil.insertUpdateDocument(INSERT_REQUEST_2_XML, UPDATE_REQUEST_2_TEMPLATE);
  }

  protected void tearDown() throws Exception {
    deleteAllVersions(objectId1);
    deleteAllVersions(objectId2);
  }

  public void testRunImplementationForSearchService() throws Exception {
    SearchDocumentsPOS searchDocumentsPOS = new MockSearchDocumentsPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(SEARCH_REQUEST_XML);
    searchDocumentsPOS.run(mockUCCHelper);
    Document searchReponseDoc1 = mockUCCHelper.getXML();
    validateResponseContainsNoError(searchReponseDoc1);
    validateResponse(searchReponseDoc1);
  }

  public void testSearchService_WithoutSpecifying_SearchAllVersions_ReturnsResultFromCurrentVersions() throws
      Exception {
    Document searchReponseDoc = searchDocument(SEARCH_REQUEST_CURRENT_VERSIONS);
    validateResponseContainsNoError(searchReponseDoc);
    validateResponseWithVersions(searchReponseDoc);
    assertEquals(2, numberOfCurrentDocuments);
    assertEquals(2, totalNumberOfDocuments);
  }

  public void testSearchService_SearchByTitle_ReturnsResultFromCurrentVersions() throws
      Exception {
    Document searchReponseDoc = searchDocument(SEARCH_REQUEST_CURRENT_VERSIONS2);
    validateResponseContainsNoError(searchReponseDoc);
    validateResponseWithVersions(searchReponseDoc);
    assertEquals(1, numberOfCurrentDocuments);
    assertEquals(1, totalNumberOfDocuments);
  }


//ToDo: Can't do across-versions search until we switch to the spsearch service in Sharepoint
//	public void testSearchService_SearchAllVersions_ReturnsResultFromAllVersions() throws Exception {
//    SearchDocumentsPOS searchDocumentsPOS = new SearchDocumentsPOS();
//    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
//    mockUCCHelper.addClientFile(SEARCH_REQUEST_ALL_VERSIONS);
//    searchDocumentsPOS.run(mockUCCHelper);
//    Document searchReponseDoc = mockUCCHelper.getXML();
//    validateResponseContainsNoError(searchReponseDoc);
//    validateResponseWithVersions(searchReponseDoc);
//    assertEquals(2, numberOfCurrentDocuments);
//    assertEquals(4, totalNumberOfDocuments);

  //  }
  public void testSearchByName() throws Exception {
    Document searchReponseDoc = searchDocument(SEARCH_REQUEST_BY_NAME_XML);
    DOMUtil.outputXML(searchReponseDoc);
    validateResponseContainsNoError(searchReponseDoc);
    validateResponseWithVersions(searchReponseDoc);
    assertEquals(1, numberOfCurrentDocuments);
    assertEquals(1, totalNumberOfDocuments);
  }

  private void deleteAllVersions(String objectId) throws Exception {
    if (objectId != null && objectId.length() > 0) {
      SharePointTestUtil.deleteAllVersionsOfInsertedDocument(objectId);
    }
  }

  private void validateResponseContainsNoError(Document searchReponseDoc) throws TransformerException {
    String errorMessage = XPathAPI.eval(searchReponseDoc, "/ERROR/ERROR_MESSAGE").toString();
    assertTrue("POS exception thrown = " + errorMessage, StringUtils.isNullOrEmpty(errorMessage));
  }

  private Document searchDocument(String requestXmlFile) throws IOException {
    SearchDocumentsPOS searchDocumentsPOS = new SearchDocumentsPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(requestXmlFile);
    searchDocumentsPOS.run(mockUCCHelper);
    return mockUCCHelper.getXML();
  }

  private void validateResponse(Document searchReponseDoc) throws TransformerException {
    assertXpathEvaluatesTo(TEST_DOC_ID,
        SharePointTestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID +
            SharePointTestUtil.XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_NAME,
        SharePointTestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_NAME + SharePointTestUtil.XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_SUBJECT,
        SharePointTestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_SUBJECT +
            SharePointTestUtil.XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_TITLE,
        SharePointTestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_TITLE + SharePointTestUtil.XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_CREATOR,
        SharePointTestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_CREATOR +
            SharePointTestUtil.XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_SIZE,
        SharePointTestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_SIZE + SharePointTestUtil.XPATH_END_STR,
        searchReponseDoc);
    for (int i = 0; i < TEST_KEYWORDS.size(); i++) {
      String expestedKeyword = (String) TEST_KEYWORDS.get(i);
      assertXpathEvaluatesTo(expestedKeyword,
          SharePointTestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_KEYWORDS
              + SharePointTestUtil.XPATH_END_STR + "[" + (i + 1) + "]", searchReponseDoc);
    }
  }

  private void validateResponseWithVersions(Document searchReponseDoc) throws TransformerException {
    totalNumberOfDocuments = 0;
    numberOfCurrentDocuments = 0;
    DOMUtil.outputXML(searchReponseDoc);
    NodeList documentDetailsNode = XPathAPI
        .eval(searchReponseDoc, "/documentManagerResponse/searchDocuments/documentDetails").nodelist();
    int length = documentDetailsNode.getLength();
    for (int i = 0; i < length; i++) {
      Node documentNode = documentDetailsNode.item(i);
      String objectId = XPathAPI
          .eval(documentNode, "attribute[name='" + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value")
          .toString();
      String version = XPathAPI
          .eval(documentNode, "attribute[name='" + DocumentManagerConstants.ATTR_STR_VERSION + "']/value").toString();
      String title = XPathAPI
          .eval(documentNode, "attribute[name='" + DocumentManagerConstants.ATTR_STR_TITLE + "']/value").toString();
      if (objectId.equalsIgnoreCase(objectId1)) {
        if (version.equalsIgnoreCase("1.0")) {
          assertEquals("File1_version1", title);
          totalNumberOfDocuments++;
        } else {
          assertEquals("File1_version2", title);
          totalNumberOfDocuments++;
          numberOfCurrentDocuments++;
        }
      }
      if (objectId.equalsIgnoreCase(objectId2)) {
        if (version.equalsIgnoreCase("1.0")) {
          assertEquals("File2_version1", title);
          totalNumberOfDocuments++;
        } else {
          assertEquals("File2_version2", title);
          totalNumberOfDocuments++;
          numberOfCurrentDocuments++;
        }
      }
    }
  }

  class MockSearchDocumentsPOS extends SearchDocumentsPOS {

    public void performOperation(RequestEntity requestEntity, DocumentService service, ResponseEntity responseEntity,
                                 UCCHelper helper) throws DocumentManagerException {
      try {
        validateConnectionParams(requestEntity);
      } catch (AttributeListParseException e) {
        throw new DocumentManagerException(e);
      }
      try {
        validateTransformedRequestEntity(requestEntity);
      } catch (AttributeListParseException e) {
        throw new DocumentManagerException(e);
      }
      RetrievedDocument retrievedDocument = buildMockRetrievedDocument();
      sendMockResponse(responseEntity, retrievedDocument);
    }

    private RetrievedDocument buildMockRetrievedDocument() {
      RetrievedDocument retrievedDocument = new RetrievedDocument();
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, TEST_DOC_ID, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_NAME, TEST_DOC_NAME, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT, TEST_DOC_SUBJECT, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, TEST_KEYWORDS, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_CREATOR, TEST_DOC_CREATOR, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_SIZE, TEST_DOC_SIZE, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TEST_DOC_TITLE, null);
      return retrievedDocument;
    }

    private void validateTransformedRequestEntity(RequestEntity requestEntity) throws DocumentManagerException,
        AttributeListParseException {
      SearchSharePointRequestEntity searchRequestEntity = (SearchSharePointRequestEntity) requestEntity;
      List requiredAttributes = searchRequestEntity.getRequiredAttributes();
      if (!requiredAttributes.get(0).equals(DocumentManagerConstants.SHAREPOINT_ATTR_STR_SUBJECT) ||
          !requiredAttributes.get(1).equals(DocumentManagerConstants.SHAREPOINT_ATTR_STR_KEYWORDS) ||
          !requiredAttributes.get(2).equals(DocumentManagerConstants.SHAREPOINT_ATTR_STR_CREATOR) ||
          !requiredAttributes.get(3).equals(DocumentManagerConstants.SHAREPOINT_ATTR_STR_SIZE) ||
          !requiredAttributes.get(4).equals(DocumentManagerConstants.SHAREPOINT_ATTR_STR_TITLE)
          ) {
        throw new DocumentManagerException("Required Attributes not parsed correctly");
      }
      if (validateQueryAttribute(searchRequestEntity, DocumentManagerConstants.SHAREPOINT_ATTR_STR_TITLE,
          TEST_DOC_TITLE,
          TITLE_ATTR_OPERATOR)
          && validateQueryAttribute(searchRequestEntity, DocumentManagerConstants.ATTR_STR_PAGE_COUNT, TEST_PAGE_COUNT,
          PAGE_CNT_ATTR_OPERATOR)
          && validateQueryAttribute(searchRequestEntity, DocumentManagerConstants.ATTR_STR_AUTHORS, TEST_AUTHOR,
          AUTHOR_ATTR_OPERATOR)
          ) {
        throw new DocumentManagerException("Query Attribute not parsed correctly");
      }
    }

    private boolean validateQueryAttribute(SearchSharePointRequestEntity searchRequestEntity, String attrName,
                                           String attrValue, String attrOperator) throws AttributeListParseException {
      return !searchRequestEntity.getDocumentAttributes().getAttrValue(attrName).equals(attrValue)
          || !searchRequestEntity.getDocumentAttributes().getOperator(attrName).equals(attrOperator);
    }

    private void validateConnectionParams(RequestEntity requestEntity) throws DocumentManagerException,
        AttributeListParseException {
      SearchSharePointRequestEntity searchRequestEntity = (SearchSharePointRequestEntity) requestEntity;
      ConnectionInfo connectionInfo = searchRequestEntity.getConnectionInfo();
      if (!searchRequestEntity.getFolderName().equalsIgnoreCase("posTestFolder-SP") ||
          !searchRequestEntity.getDirectoryStructure().equalsIgnoreCase("testDir1/testDir2") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.SP_CI_SITE_NAME)
              .equalsIgnoreCase("http://na1000spdev60/teamsite") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.SP_CI_DOC_LIB_NAME)
              .equalsIgnoreCase("ScannedImages")
          ) {
        throw new DocumentManagerException("Connection/Configuration params not parsed correctly");
      }
    }

    private void sendMockResponse(ResponseEntity responseEntity, RetrievedDocument retrievedDocument) {
      responseEntity.getRetrievedDocumentList().add(retrievedDocument);
    }
  }
}