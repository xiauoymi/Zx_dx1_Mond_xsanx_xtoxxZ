/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updatesharepointdocs.tests;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updateSharePointDoc.parser.UpdateSharePointRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.ServiceConfig.SharePointServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;

/**
 * Filename:    $RCSfile: MockUpdateDocumentumRequestParser.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: ussing $    	 On:	$Date: 2007-11-15 23:41:00 $
 *
 * @author ussing
 * @version $Revision: 1.1 $
 */
public class MockUpdateSharePointRequestParser extends UpdateSharePointRequestParser {

  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";

  protected IServiceLookup getServiceConfigLookupInstance() throws ServiceConfigException {
    return new SharePointServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
  }
}