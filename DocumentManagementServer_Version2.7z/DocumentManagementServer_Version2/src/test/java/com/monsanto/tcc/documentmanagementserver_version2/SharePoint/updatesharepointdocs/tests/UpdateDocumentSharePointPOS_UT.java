package com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updatesharepointdocs.tests;
//ToDo: Integrate Mike's Update stuff from TestUtil into the update(...) method of SharePointServices

import com.microsoft.schemas.sharepoint.soap.FieldInformation;
import com.microsoft.schemas.sharepoint.soap.FieldInformationCollection;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.ServiceConfig.SharePointServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updateSharePointDoc.entity.UpdateSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocumentService;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.updateService.MockUpdateSharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.updateService.UpdateDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.SharePointTestUtil;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jun 2, 2006 Time: 11:19:13 AM To change this template use File |
 * Settings | File Templates.
 */
public class UpdateDocumentSharePointPOS_UT extends XMLTestCase {
  private static final String UPDATE_REQUEST_XML_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/updateSharePointDoc/tests/updateRequest - SP - fullrequest.xml";
  private static final String UPDATE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/deleteSharePointDoc/tests/updateReq1.xml";
  private static final String UPDATE_REQUEST_WITH_ATTR_AND_CONTENTS_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/updateSharePointDoc/tests/updateRequestWithAttrAndContents-SP.xml";
  private static final String UPDATE_REQUEST_SAME_VERSION_ATTR_AND_CONTENTS_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/updateSharePointDoc/tests/updateRequestSameVersion-SP.xml";
  private static final String UPDATE_REQUEST_WITH_INVALID_VERSION_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/updateSharePointDoc/tests/updateRequestWithInvalidUpdateVersion-SP.xml";
  private static final String UPDATE_REQUEST_WITH_NO_OBJECT_ID = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/updateSharePointDoc/tests/updateRequestWithNoObjectId.xml";
  private static final String UPDATE_REQUEST_XML_WITH_UNDEFINED_REPOSITORY = "com/monsanto/tcc/documentmanagementserver_version2/SharePoint/updateSharePointDoc/tests/updateRequestWithUndefinedRepository-SP.xml";
  private static final String UPDATE_REQUEST_XML = "C:/updateRequest.xml";
  private static final String XPATH_BEGIN_STR = "/documentManagerResponse/documentUpdatedSuccessfully/documentDetails/attribute[name = '";
  private static final String XPATH_END_STR = "']/value";
  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";
  private static final String TEST_DOC_ID = "1234";
  private static final String NEW_MINOR_VERSION = "1.1";
  private static final String NEW_MAJOR_VERSION = "2.0";
  private static final String NEW_CONTENTS = "com/monsanto/eas/documentservices/acceptancetests/testFile2.txt";
  private static final String NEW_CONTENTS_OF_DIFFERENT_FORMAT = "com/monsanto/eas/documentservices/acceptancetests/test.doc";
  private static final String TEST_DOC_TITLE = "testTitle";
  private static final String SAME_VERSION = "1.0";
  private static List TEST_KEYWORDS;

  static {
    TEST_KEYWORDS = new ArrayList();
    TEST_KEYWORDS.add("documents");
    TEST_KEYWORDS.add("files");
  }

  private String objectId;
  private static final String ATTACHMENT_1 = "com/monsanto/eas/documentservices/acceptancetests/testFile1.txt";
  private static final String INSERT_XML_1 = "com/monsanto/eas/documentservices/acceptancetests/insertReq1.xml";
  private static final String DELETE_REQUEST_XML = "C:/deleteRequestDoc.xml";

  protected void setUp() throws Exception {
    objectId = SharePointTestUtil.insertTestDocument(ATTACHMENT_1, INSERT_XML_1);
    System.out.println("objectIdfrom setup = " + objectId);
  }

  protected void tearDown() throws Exception {
    if (!StringUtils.isNullOrEmpty(objectId)) {
      System.out.println("UpdateDocumentSharePointPOS_UT.tearDown:going to go delete everything via testUtil@@@");
      System.out.println("The objectIdfrom teardown: \"" + objectId + "\"");
      SharePointTestUtil.deleteAllVersionsOfInsertedDocument(objectId);
      System.out.println("UpdateDocumentSharePointPOS_UT.tearDown:returned from deleting everything!!!");
    }
    deleteLocalTempFile();
  }

  private void deleteLocalTempFile() {
    new File(DELETE_REQUEST_XML).delete();
    new File(UPDATE_REQUEST_XML).delete();
  }

  public void testUtilsUpdateReturningFieldInfoCollection() throws Exception {
    String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document updateReq = SharePointTestUtil
        .transformRequestXML(UPDATE_REQUEST_TEMPLATE, objectId, updateTransformationXPathString, 0);
    FieldInformationCollection fields = SharePointTestUtil
        .updateDocument(ATTACHMENT_1, updateReq, DocumentManagerConstants.TEXT_DOC_FILETYPE, "");
    System.out.println("begin fields dump");
    List<FieldInformation> information = fields.getFieldInformation();
		for (FieldInformation fieldInformation : information) {
			String name = fieldInformation.getDisplayName();
			System.out.println("name = " + name);
			String value = fieldInformation.getValue();
			System.out.println("value = " + value);
		}
    System.out.println("end fields dump");
  }

  public void testRunImplementationForUpdateService_WithUndefinedRepository_ThrowsException() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML_WITH_UNDEFINED_REPOSITORY);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsError(updateReponseDoc);
  }

  public void testFrameworkSetupForUpdateService() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML_TEMPLATE);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    DOMUtil.outputXML(updateReponseDoc);
    validateResponseContainsNoError(updateReponseDoc);
    validateResponse(updateReponseDoc, TEST_DOC_ID, NEW_MINOR_VERSION);
  }

  public void testUpdateThrowsExceptionIfAlreadyCheckedOut() throws Exception {
		SharePointTestUtil.checkOutFile(INSERT_XML_1);
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockHelper = new MockUCCHelper(null);
    createTestUpdateRequestXML(UPDATE_REQUEST_XML, objectId, UPDATE_REQUEST_XML_TEMPLATE);
    mockHelper.addClientFile(UPDATE_REQUEST_XML);
		mockHelper.addClientFile(NEW_CONTENTS);
    updateDocumentPOS.run(mockHelper);
    Document updateResponseDoc = mockHelper.getXML();

		String errorMessage = extractErrorMessage(updateResponseDoc);
		System.out.println("errorMessage = " + errorMessage);
		validateResponseContainsError(updateResponseDoc);
  }

	public void testUpdateService_MinorVersion_WithNewAttrs_WithoutContents() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    createTestUpdateRequestXML(UPDATE_REQUEST_XML, objectId, UPDATE_REQUEST_XML_TEMPLATE);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    DOMUtil.outputXML(updateReponseDoc);
    validateResponseContainsNoError(updateReponseDoc);
    validateResponse(updateReponseDoc, objectId, NEW_MINOR_VERSION);
  }

  public void testUpdateService_MajorVersion_WithAttrAndContents() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    createTestUpdateRequestXML(UPDATE_REQUEST_XML, objectId, UPDATE_REQUEST_WITH_ATTR_AND_CONTENTS_TEMPLATE);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML);
    mockUCCHelper.addClientFile(NEW_CONTENTS);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsNoError(updateReponseDoc);
    validateResponse(updateReponseDoc, objectId, NEW_MAJOR_VERSION);
  }

	//ToDo: Sharepoint Can't support this through the services.  We are currently updating the attributes through
	//ToDo: the Lists service as a separate state and this causes a new version to be introduced.  We'll try again to
	//ToDo: put the new version attributes in through the Copy service although it didn't work before
	public void XtestUpdateService_SameVersion_WithAttrAndContents() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    createTestUpdateRequestXML(UPDATE_REQUEST_XML, objectId, UPDATE_REQUEST_SAME_VERSION_ATTR_AND_CONTENTS_TEMPLATE);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML);
    mockUCCHelper.addClientFile(NEW_CONTENTS);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsNoError(updateReponseDoc);
    validateResponse(updateReponseDoc, objectId, SAME_VERSION);
  }

  public void testUpdateService_MajorVersion_WithAttr_And_Contents_Of_DifferentFormat() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    createTestUpdateRequestXML(UPDATE_REQUEST_XML, objectId, UPDATE_REQUEST_WITH_ATTR_AND_CONTENTS_TEMPLATE);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML);
    mockUCCHelper.addClientFile(NEW_CONTENTS_OF_DIFFERENT_FORMAT);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsNoError(updateReponseDoc);
    validateResponse(updateReponseDoc, objectId, NEW_MAJOR_VERSION);
  }

  public void testUpdateService_WithInvalidUpdateVersionSpecification_PerformsCancelCheckout_ThrowsException() throws
      Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    createTestUpdateRequestXML(UPDATE_REQUEST_XML, objectId, UPDATE_REQUEST_WITH_INVALID_VERSION_TEMPLATE);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML);
		mockUCCHelper.addClientFile(NEW_CONTENTS);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsError(updateReponseDoc);
  }

  public void testUpdateService_WithInvalidObjectIdSpecification_ThrowsException() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML_TEMPLATE);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    DOMUtil.outputXML(updateReponseDoc);
    validateResponseContainsError(updateReponseDoc);
  }

  public void testUpdateService_WithNoObjectId_ThrowsException() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_WITH_NO_OBJECT_ID);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    DOMUtil.outputXML(updateReponseDoc);
    validateResponseContainsError(updateReponseDoc);
  }

  private void createTestUpdateRequestXML(String updateRequestFilenamePath, String objectId,
                                          String updateRequestTemplate) throws FileNotFoundException, ParserException,
      TransformerException {
    Document updateRequestDoc = DOMUtil.newDocument(updateRequestTemplate);
    Node objectIdValueNode = XPathAPI.eval(updateRequestDoc,
        "/inputPos/command/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = updateRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    saveAsXMLFile(updateRequestDoc, updateRequestFilenamePath);

  }

  private void saveAsXMLFile(Document updateRequestDoc, String deleteRequestFilenamePath) throws FileNotFoundException {
    DOMUtil.outputXML(updateRequestDoc, new FileOutputStream(new File(deleteRequestFilenamePath)));

  }

  private void validateResponseContainsNoError(Document updateResponseDoc) throws TransformerException {
    String errorMessage = XPathAPI.eval(updateResponseDoc, "/ERROR/ERROR_MESSAGE").toString();
    assertTrue("POS exception thrown = begin error message\"" + errorMessage + "\"\n\nend error message",
        StringUtils.isNullOrEmpty(errorMessage));
  }

  private String extractErrorMessage(Document updateResponseDoc) throws TransformerException {
    assertXpathExists("/ERROR/ERROR_MESSAGE", updateResponseDoc);
    return XPathAPI.eval(updateResponseDoc, "/ERROR/ERROR_MESSAGE").toString();
  }

  private void validateResponseContainsError(Document updateResponseDoc) throws TransformerException {
    assertXpathExists("/ERROR/ERROR_MESSAGE", updateResponseDoc);
  }

  private void validateResponse(Document updateReponseDoc, String objectId, String version) throws
      TransformerException {
    assertXpathEvaluatesTo(objectId,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR,
        updateReponseDoc);
    assertXpathEvaluatesTo(version, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_VERSION + XPATH_END_STR,
        updateReponseDoc);
  }

  class MockUpdateDocumentPOSWithTestServiceConfig extends UpdateDocumentPOS {

    protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
      return new SharePointServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    }


    public DocBuilder getBuilder(Document inputDocument) throws ServiceConfigException {
      return new MockUpdateSharePointBuilder();
    }
  }

  class MockUpdateDocumentPOS extends MockUpdateDocumentPOSWithTestServiceConfig {

    public void performOperation(RequestEntity requestEntity, DocumentService service, ResponseEntity responseEntity,
                                 UCCHelper helper) throws DocumentManagerException {
      try {
        validateConnectionParams(requestEntity);
      } catch (AttributeListParseException e) {
        throw new DocumentManagerException(e);
      }
      validateTransformedRequestEntity(requestEntity);
      RetrievedDocument retrievedDocument = buildMockRetrievedDocument();
      sendMockResponse(responseEntity, retrievedDocument);
    }

    private RetrievedDocument buildMockRetrievedDocument() {
      RetrievedDocument retrievedDocument = new RetrievedDocument();
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, TEST_DOC_ID, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_VERSION, NEW_MINOR_VERSION, null);
      return retrievedDocument;
    }

    private void validateTransformedRequestEntity(RequestEntity requestEntity) throws DocumentManagerException {
      UpdateSharePointRequestEntity updateRequestEntity = (UpdateSharePointRequestEntity) requestEntity;
      try {
        if (documentAttributeNotValid(updateRequestEntity,
            DocumentManagerConstants.SHAREPOINT_ATTR_STR_UNIQUE_DOCUMENT_ID,
            TEST_DOC_ID)
            || documentAttributeNotValid(updateRequestEntity, DocumentManagerConstants.ATTR_STR_TITLE, TEST_DOC_TITLE)
            ||
            multipleValuedDocumentAttributeNotValid(updateRequestEntity,
                DocumentManagerConstants.DCTM_ATTR_STR_KEYWORDS,
                TEST_KEYWORDS)
            ) {
          throw new DocumentManagerException("Document Attributes not parsed correctly");
        }
      } catch (AttributeListParseException e) {
        e.printStackTrace();

        throw new DocumentManagerException(
            "Document Attributes not parsed correctly; exception caught inside the if in validateTransformedRequestEntity");

      } catch (DocumentManagerException e) {
        e.printStackTrace();
      }
    }

    private boolean multipleValuedDocumentAttributeNotValid(UpdateSharePointRequestEntity updateRequestEntity,
                                                            String attrName, List expectedAttrValues) throws
        AttributeListParseException {
      System.out.println("expectedAttrValues = " + expectedAttrValues);
      List actualkeywords = null;
      try {
        actualkeywords = updateRequestEntity.getDocumentAttributes().getAttrValues(attrName);
      } catch (AttributeListParseException e) {
        e.printStackTrace();
      }
      if (actualkeywords == null) {
        return true;
      } else {
        for (int i = 0; i < actualkeywords.size(); i++) {
          String keyword = (String) actualkeywords.get(i);
          if (!keyword.equalsIgnoreCase((String) expectedAttrValues.get(i))) {
            return false;
          }
        }
      }
      return false;
    }

    private boolean documentAttributeNotValid(UpdateSharePointRequestEntity updateRequestEntity, String attrName,
                                              String attrValue) throws AttributeListParseException {
      DocumentAttributes documentAttributes = updateRequestEntity.getDocumentAttributes();
      return !documentAttributes.containsAttribute(attrName) ||
          !documentAttributes.getAttrValue(attrName).equals(attrValue);
    }

    private void validateConnectionParams(RequestEntity requestEntity) throws DocumentManagerException,
        AttributeListParseException {
      UpdateSharePointRequestEntity updateRequestEntity = (UpdateSharePointRequestEntity) requestEntity;
      ConnectionInfo connectionInfo = updateRequestEntity.getConnectionInfo();
      if (!updateRequestEntity.getFolderName().equalsIgnoreCase("posTestFolder-SP") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.SP_CI_SITE_NAME)
              .equalsIgnoreCase("http://na1000spdev60/teamsite") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.SP_CI_DOC_LIB_NAME)
              .equalsIgnoreCase("ScannedImages")
          ) {
        throw new DocumentManagerException("Connection/Configuration params not parsed correctly");
      }
    }

    private void sendMockResponse(ResponseEntity responseEntity, RetrievedDocument retrievedDocument) {
      responseEntity.getRetrievedDocumentList().add(retrievedDocument);
    }
  }
}