/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.MultiPartFormAttachment;
import com.monsanto.POSClient.POSMIMEConstants;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Mar 1, 2006 Time: 1:04:11 PM To change this template use File |
 * Settings | File Templates.
 */
public class Client_AT extends XMLTestCase {
  private static final String POS_INSERT_SERVICE_NAME = "InsertDocumentService";
  private static final String INSERT_REQUEST_TEXT_FILE_AT = "com/monsanto/tcc/documentmanagementserver_version2/apptests/insertReq_AppClient_AT.xml";
  private static final String UPDATE_REQUEST_TEXT_FILE_AT = "com/monsanto/tcc/documentmanagementserver_version2/apptests/updateReq_AppClient_AT.xml";
  private static final String SEARCH_REQUEST_TEXT_FILE_AT = "com/monsanto/tcc/documentmanagementserver_version2/apptests/searchReq_AppClient_AT.xml";
  private static final String SEARCH_REQUEST_TECH_TEXT_FILE_AT = "com/monsanto/tcc/documentmanagementserver_version2/apptests/searchReq_TechDoc_AT.xml";
  private static final String TEST_TEXT_FILE_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private static final String TEST_TEXT_FILE_2 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile2.txt";
  private static final String POS_DELETE_SERVICE_NAME = "DeleteDocumentService";
  private static final String POS_SEARCH_SERVICE = "SearchDocumentsService";
  private static final String POS_UPDATE_SERVICE = "UpdateDocumentService";
  private static final String UPDATE_REQUEST_XML = "C:/updateRequestDoc.xml";

  public void testUpload_Retrieve_Delete_And_Update_Services() throws Exception {
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    posConn.addAttachment(new MultiPartFormAttachment(Client_AT.TEST_TEXT_FILE_1, POSMIMEConstants.MIME_TYPE_TEXT));
    POSResult posResult = posConn
        .callService(Client_AT.POS_INSERT_SERVICE_NAME, DOMUtil.newDocument(INSERT_REQUEST_TEXT_FILE_AT));
    Document outputDocument = DOMUtil.newDocument(posResult.getInputStream());
    DOMUtil.outputXML(outputDocument);
    String objectId = XPathAPI
        .eval(outputDocument, "/documentManagerResponse/insertDocument/documentDetails/attribute/value").toString();
    assertNotNull(objectId);
    Document inputDocumentUpdate = patchUpdateRequest(UPDATE_REQUEST_XML, objectId, "");
    DOMUtil.outputXML(inputDocumentUpdate);
    SecureXMLPOSConnection updatePosConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    updatePosConn
        .addAttachment(new MultiPartFormAttachment(Client_AT.TEST_TEXT_FILE_2, POSMIMEConstants.MIME_TYPE_TEXT));
    POSResult posResultUpdate = updatePosConn.callService(Client_AT.POS_UPDATE_SERVICE, inputDocumentUpdate);
    Document outputUpdateDocument = DOMUtil.newDocument(posResultUpdate.getInputStream());
    DOMUtil.outputXML(outputUpdateDocument);
    String updatedDocumentObjectId = XPathAPI.eval(outputUpdateDocument,
        "/documentManagerResponse/documentDeletedSuccessfully/documentDetails/attribute/value").toString();
    assertNotNull(updatedDocumentObjectId);
    System.out.println("updatedDocumentObjectId = " + updatedDocumentObjectId);

    Document inputDocumentDelete = createTestDeleteRequestXML(objectId);
    DOMUtil.outputXML(inputDocumentDelete);
    POSResult posResultDelete = posConn.callService(Client_AT.POS_DELETE_SERVICE_NAME, inputDocumentDelete);
    Document outputDeleteDocument = DOMUtil.newDocument(posResultDelete.getInputStream());
    DOMUtil.outputXML(outputDeleteDocument);
    String deletedDocumentObjectId = XPathAPI.eval(outputDeleteDocument,
        "/documentManagerResponse/documentDeletedSuccessfully/documentDetails/attribute/value").toString();
    assertNotNull(deletedDocumentObjectId);

    System.out.println("deletedDocumentObjectId = " + deletedDocumentObjectId);
  }

  private Document patchUpdateRequest(String updateRequestFilenamePath, String searchObjectId,
                                      String version) throws
      ParserException, TransformerException, FileNotFoundException {
    Document retrieveRequestDoc = DOMUtil.newDocument(UPDATE_REQUEST_TEXT_FILE_AT);
    Node objectIdValueNode = XPathAPI.eval(retrieveRequestDoc,
        "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute[name = '" +
            DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = retrieveRequestDoc.createTextNode(searchObjectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    if (!StringUtils.isNullOrEmpty(version)) {
      Node versionValueNode = XPathAPI.eval(retrieveRequestDoc,
          "/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute[name = '" +
              DocumentManagerConstants.ATTR_STR_VERSION + "']/value")
          .nodelist().item(0);
      Node newVersionValueNode = retrieveRequestDoc.createTextNode(version);
      versionValueNode.replaceChild(newVersionValueNode, versionValueNode.getFirstChild());
    }
    saveAsXMLFile(retrieveRequestDoc, updateRequestFilenamePath);
    return retrieveRequestDoc;
  }

  private void saveAsXMLFile(Document deleteRequestDoc, String deleteRequestFilenamePath) throws
      FileNotFoundException {
    DOMUtil.outputXML(deleteRequestDoc, new FileOutputStream(new File(deleteRequestFilenamePath)));
  }


  public void testSearchExistingDocs() throws Exception {
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    POSResult posResult = posConn
        .callService(Client_AT.POS_SEARCH_SERVICE, DOMUtil.newDocument(SEARCH_REQUEST_TEXT_FILE_AT));
    Document outputDocument = DOMUtil.newDocument(posResult.getInputStream());
    DOMUtil.outputXML(outputDocument);
    String objectId = XPathAPI
        .eval(outputDocument, "/documentManagerResponse/insertDocument/documentDetails/attribute/value").toString();
    assertNotNull(objectId);
    System.out.println("objectId = " + objectId);
  }

  public void testSearchExistingTechDocs() throws Exception {
//    String initialLSIFunc = System.getProperty("lsi.function");
//		System.setProperty("lsi.function", "prod");
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    POSResult posResult = posConn
        .callService(Client_AT.POS_SEARCH_SERVICE, DOMUtil.newDocument(SEARCH_REQUEST_TECH_TEXT_FILE_AT));
    Document outputDocument = DOMUtil.newDocument(posResult.getInputStream());
    DOMUtil.outputXML(outputDocument);
    String objectId = XPathAPI
        .eval(outputDocument, "/documentManagerResponse/insertDocument/documentDetails/attribute/value").toString();
    assertNotNull(objectId);
//    System.setProperty("lsi.function", initialLSIFunc);
  }

  private Document createTestDeleteRequestXML(String objectId) throws ParserException, TransformerException {
    Document deleteRequestDoc = DOMUtil
        .newDocument("com/monsanto/tcc/documentmanagementserver_version2/apptests/deleteRequest.xml");
    Node objectIdValueNode = XPathAPI
        .eval(deleteRequestDoc, "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    return deleteRequestDoc;
  }

}