package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.TestUtil;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 16, 2006 Time: 9:50:05 AM To change this template use File |
 * Settings | File Templates.
 */
public class DeleteService_AT extends XMLTestCase {
  private static final String DELETE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/apptests/deleteRequest.xml";
  private static final String ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private static final String INSERT_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/insertReq1.xml";
  private static final String DELETE_REQUEST_XML = "C:/deleteRequestDoc.xml";
  private static final String DELETE_REQUEST_WITH_VERSION_1_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/apptests/deleteRequestWithVersion1.xml";
  private static final String DELETE_REQUEST_WITH_VERSION_2_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/apptests/deleteRequestWithVersion2.xml";
  private static final String XPATH_BEGIN_STR = "/documentManagerResponse/documentDeletedSuccessfully/documentDetails/attribute[name = '";
  private static final String XPATH_END_STR = "']/value";
  private static final String POS_INSERT_SERVICE_NAME = "InsertDocumentService";
  private static final String POS_DELETE_SERVICE_NAME = "DeleteDocumentService";
  private static final String UPDATED_CONTENTS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/test.doc";
  private static final String UPDATE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/retrieveService/tests/updateRequest.xml";
  private String objectId1;

  protected void setUp() throws Exception {
    objectId1 = insertTestDocument(ATTACHMENT_1, POSMIMEConstants.MIME_TYPE_TEXT, INSERT_XML_1);
    String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document updateReq = TestUtil
        .transformRequestXML(UPDATE_REQUEST_TEMPLATE, objectId1, updateTransformationXPathString, 0);
    TestUtil.updateDocument(UPDATED_CONTENTS, updateReq, POSMIMEConstants.MIME_TYPE_MSWORD);
  }

  protected void tearDown() throws Exception {
    deleteTemporaryXMLDocument();
  }

  public void testDelete_WithoutVersionSpecification_DeletesAllVersions() throws Exception {
    deleteWithVersioning(DELETE_REQUEST_TEMPLATE, DocumentManagerConstants.RESP_CONST_ALL_VERSIONS_DELETED);
  }

  public void testDelete_WithVersion_DeletesSpecificVersion() throws Exception {
    deleteWithVersioning(DELETE_REQUEST_WITH_VERSION_1_TEMPLATE, "1.0");
    deleteWithVersioning(DELETE_REQUEST_WITH_VERSION_2_TEMPLATE, "2.0");
  }

  private void deleteWithVersioning(String deleteRequestTemplate, String versionsDeleted) throws ParserException,
      TransformerException, GSSException, POSException, POSCommunicationException, IOException, SAXException {
    createTestDeleteRequestXML(DELETE_REQUEST_XML, objectId1, deleteRequestTemplate);
    Document inputDoc = DOMUtil.newDocument(DELETE_REQUEST_XML);
    SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    POSResult result = posConn.callService(POS_DELETE_SERVICE_NAME, inputDoc);
    Document deleteResponseDoc = DOMUtil.newDocument(result.getInputStream());
    validateResponse(deleteResponseDoc, objectId1, versionsDeleted);
  }

  private void deleteTemporaryXMLDocument() {
    new File(DELETE_REQUEST_XML).delete();
  }

  private void createTestDeleteRequestXML(String deleteRequestFilenamePath, String objectId,
                                          String deleteRequestTemplate) throws FileNotFoundException, ParserException,
      TransformerException {
    Document deleteRequestDoc = DOMUtil.newDocument(deleteRequestTemplate);
    Node objectIdValueNode = XPathAPI
        .eval(deleteRequestDoc, "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    saveAsXMLFile(deleteRequestDoc, deleteRequestFilenamePath);
  }

  private void saveAsXMLFile(Document deleteRequestDoc, String deleteRequestFilenamePath) throws FileNotFoundException {
    DOMUtil.outputXML(deleteRequestDoc, new FileOutputStream(new File(deleteRequestFilenamePath)));
  }

  private String insertTestDocument(String fileAttachment, String mimeType, String insertRequestXml) throws
      ParserException, IOException, SAXException, POSCommunicationException, POSException, InvalidMimeTypeException,
      TransformerException, GSSException {
    MultipartAttachmentList attachmentList = new MultipartAttachmentList();
    addAttachment(attachmentList, fileAttachment, mimeType);
    Document responseDoc = insertDocument(attachmentList, insertRequestXml);
    return getObjectIdOfInsertedDocument(responseDoc);
  }

  private void addAttachment(MultipartAttachmentList attachmentList, String fileName, String mimeType) throws
      InvalidMimeTypeException {
    MultiPartFormAttachment attachment = new MultiPartFormAttachment(fileName, mimeType);
    attachmentList.addAttachment(attachment);
  }

  private Document insertDocument(MultipartAttachmentList attachmentList, String requestXmlDocument) throws
      ParserException, POSException, POSCommunicationException, IOException, SAXException, GSSException {
    Document inputDoc = DOMUtil.newDocument(requestXmlDocument);
    SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    addAttachmentToConnection(attachmentList, posConn);
    POSResult result = posConn.callService(POS_INSERT_SERVICE_NAME, inputDoc);
    return DOMUtil.newDocument(result.getInputStream());
  }

  private void addAttachmentToConnection(MultipartAttachmentList attachmentList, XMLPOSConnection posConn) {
    int numberOfAttachments = attachmentList.getLength();
    for (int i = 0; i < numberOfAttachments; i++) {
      MultiPartFormAttachment attachment = attachmentList.getAttachment(i);
      posConn.addAttachment(attachment);
    }
  }

  private String getObjectIdOfInsertedDocument(Document responseDoc) throws TransformerException {
    String expression = "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" +
        DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value";
    Object objId = XPathAPI.eval(responseDoc, expression);
    return objId.toString();
  }

  private void validateResponse(Document deleteReponseDoc, String deletedObjectId, String versionsDeleted) throws
      TransformerException {
    assertXpathEvaluatesTo(deletedObjectId,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR,
        deleteReponseDoc);
    assertXpathEvaluatesTo(versionsDeleted, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_VERSION + XPATH_END_STR,
        deleteReponseDoc);
  }
}