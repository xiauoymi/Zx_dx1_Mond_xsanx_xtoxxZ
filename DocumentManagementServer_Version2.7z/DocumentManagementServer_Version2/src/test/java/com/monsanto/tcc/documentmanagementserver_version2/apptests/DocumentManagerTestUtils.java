/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import org.apache.xpath.XPathAPI;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.IOException;

/**
 * Filename:    $RCSfile: DocumentManagerTestUtils.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-04-19 22:17:18 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class DocumentManagerTestUtils {


    private static final String POS_SEARCH_SERVICE_NAME = "SearchDocumentsService";
    private static final String POS_DELETE_SERVICE_NAME = "DeleteDocumentService";
    private static final String DELETE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/apptests/deleteRequest.xml";
    private static final String SEARCH_BY_NAME_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/apptests/searchByNameRequest.xml";

    public static void deleteDocument(String objectId) throws ParserException, TransformerException, POSException,
                                                              POSCommunicationException, GSSException {
        Document inputDoc = createTestDeleteRequestXML(objectId);
        SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
                new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
        posConn.callService(POS_DELETE_SERVICE_NAME, inputDoc);
    }

    public static Document createTestDeleteRequestXML(String objectId) throws ParserException, TransformerException {
        Document deleteRequestDoc = DOMUtil.newDocument(DELETE_REQUEST_TEMPLATE);
        Node objectIdValueNode = XPathAPI.eval(deleteRequestDoc,
                                               "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
                .nodelist().item(0);
        Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
        objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
        return deleteRequestDoc;
    }

    public static void deleteDocumentByName(String documentName) throws IOException, ParserException,
                                                                        TransformerException,
                                                                        POSException, POSCommunicationException,
                                                                        GSSException,
                                                                        SAXException {
        String objectId = getObjectIdByName(documentName);
        if (objectId != null && objectId.length() > 0) {
            deleteDocument(objectId);
        }
    }

    public static String getObjectIdByName(String documentName) throws ParserException, IOException,
                                                                       TransformerException, GSSException, SAXException,
                                                                       POSException, POSCommunicationException {
        Document searchByNameRequestXML = createSearchByNameRequestXML(documentName);
        Document searchResponse = search(searchByNameRequestXML);
        return getObjectIdFromSearchResponse(searchResponse);
    }

    public static Document createSearchByNameRequestXML(String documentName) throws ParserException,
                                                                                    TransformerException {
        Document searchByNameRequestDoc = DOMUtil.newDocument(SEARCH_BY_NAME_REQUEST_TEMPLATE);
        Node objectIdValueNode = XPathAPI.eval(searchByNameRequestDoc,
                                               "/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute/value")
                .nodelist().item(0);
        Node newObjectIdValueNode = searchByNameRequestDoc.createTextNode(documentName);
        objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
        return searchByNameRequestDoc;
    }

    public static String getObjectIdFromSearchResponse(Document responseDoc) throws TransformerException {

        String expression = "/documentManagerResponse/searchDocuments/documentDetails/attribute[name = '" +
                            DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value";
        Object objId = XPathAPI.eval(responseDoc, expression);
        return objId.toString();
    }

    public static Document search(Document inputDoc) throws IOException, SAXException, POSCommunicationException,
                                                            POSException, GSSException {
        SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
                new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
        POSResult result = posConn.callService(POS_SEARCH_SERVICE_NAME, inputDoc);
        return DOMUtil.newDocument(result.getInputStream());
    }

    public static String getNameFromInsertRequest(String insertRequestXml) throws ParserException,
                                                                                  TransformerException {
        Document inputDoc = DOMUtil.newDocument(insertRequestXml);
        String expression =
                "/insertDocumentRequest/requestDetails/insertDocument/documentAttributes/attribute[name = '" +
                DocumentManagerConstants.ATTR_STR_NAME + "']/value";
        return XPathAPI.eval(inputDoc, expression).toString();
    }
}