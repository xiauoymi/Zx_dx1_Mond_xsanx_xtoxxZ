package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.POSClient.URLMap;
import com.monsanto.Util.EnvironmentHelperException;

import java.io.IOException;

import org.xml.sax.SAXException;

import javax.xml.parsers.SAXParserFactory;

/**
 * Created by IntelliJ IDEA.
* User: mecoru
* Date: Apr 11, 2007
* Time: 2:43:10 PM
* To change this template use File | Settings | File Templates.
*/
public class MockURLMapForDocPos extends URLMap {

		public MockURLMapForDocPos() throws IOException, EnvironmentHelperException, SAXException {
		}

		public MockURLMapForDocPos(SAXParserFactory factory) throws EnvironmentHelperException, SAXException,
																																IOException {
				super(factory);
		}

		protected String getConfigFileName() {
				return "com/monsanto/tcc/documentmanagementserver_version2/apptests/TestMappings.xml";
		}
}
