package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.POSClient.URLMap;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.securityinterfaces.ClientSecurityProxy;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import org.xml.sax.SAXException;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Apr 11, 2007
 * Time: 2:44:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockXMLPOSConnectionForRetrieve extends SecureXMLPOSConnection {

	public MockXMLPOSConnectionForRetrieve(ClientSecurityProxy clientProxy, SystemSecurityProxy systemProxy) {
		super(clientProxy, systemProxy);
	}

	protected URLMap getURLMap() throws IOException, SAXException, EnvironmentHelperException {
		return new MockURLMapForDocPos();
	}
}
