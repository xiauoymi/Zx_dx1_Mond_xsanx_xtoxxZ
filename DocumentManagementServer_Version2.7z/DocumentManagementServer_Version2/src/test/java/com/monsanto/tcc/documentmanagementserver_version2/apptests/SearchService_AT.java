package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.TestUtil;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 9, 2006 Time: 5:00:14 PM To change this template use File |
 * Settings | File Templates.
 */
public class SearchService_AT extends XMLTestCase {
  private static final String POS_INSERT_SERVICE_NAME = "InsertDocumentService";
  private static final String SEARCH_REQUEST_XML = "com/monsanto/tcc/documentmanagementserver_version2/apptests/searchRequest.xml";
  private static final String SEARCH_REQUEST_EXTENDED_CHARACTERS_RETURNED = "com/monsanto/tcc/documentmanagementserver_version2/apptests/searchRequestForExtendedCharacters.xml";
  private static final String SEARCH_REQUEST_XML_WITHOUT_QUERY_ATTR = "com/monsanto/tcc/documentmanagementserver_version2/apptests/searchRequestWithoutQueryAttr.xml";
  private static final String SEARCH_REQUEST_XML_WITH_MULTIPLE_QUERY_ATTRS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/searchRequestWithMultipleQueryAttrs.xml";
  private static final String SEARCH_REQUEST_XML_ALL_VERSIONS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/searchReqForAllVersions.xml";
  private static final String ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private static final String ATTACHMENT_2 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile2.txt";
  private static final String ATTACHMENT_3 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile3.txt";
  private static final String INSERT_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/insertReq1.xml";
  private static final String INSERT_XML_2 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/insertReq2.xml";
  private static final String INSERT_XML_3 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/insertReq3.xml";
  private static final String UPDATE_XML_3_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/apptests/updateReq3.xml";
  private static final String XPATH_BEGIN_STR = "/documentManagerResponse/searchDocuments/documentDetails[attribute/value='";
  private static final String XPATH_MID_STR = "']/attribute[name = '";
  private static final String XPATH_END_STR = "']/value";
  private String objectId1;
  private String objectId2;
  private String objectId3;
  private static final String TEST_DOC_NAME_1 = "attachment1";
  private static final String TEST_DOC_SUBJECT_1 = "farm resource";
  private static final String TEST_DOC_TITLE_1 = "monsanto search docs";
  private static final String TEST_DOC_CREATOR_1 = "dctmpos";
  private static final String TEST_DOC_SIZE_1 = "9";
  private static final List TEST_KEYWORDS_1 = new ArrayList();

  static {
    TEST_KEYWORDS_1.add("field");
    TEST_KEYWORDS_1.add("farm");
  }

  private static final String TEST_DOC_NAME_2 = "attachment2";
  private static final String TEST_DOC_SUBJECT_2 = "crop details";
  private static final String TEST_DOC_TITLE_2 = "search docs";
  private static final String TEST_DOC_CREATOR_2 = "dctmpos";
  private static final String TEST_DOC_SIZE_2 = "11";
  private static final List TEST_KEYWORDS_2 = new ArrayList();

  static {
    TEST_KEYWORDS_2.add("crop");
    TEST_KEYWORDS_2.add("manure");
    TEST_KEYWORDS_2.add("pesticide");
  }

  private static final String TEST_DOC_NAME_3 = "attachment3";
  private static final String TEST_DOC_SUBJECT_3 = "farm resource";
  private static final String TEST_DOC_TITLE_3 = "monsanto search docs";
  private static final String TEST_DOC_CREATOR_3 = "dctmpos";
  private static final String TEST_DOC_SIZE_3 = "19";
  private static final List TEST_KEYWORDS_3 = new ArrayList();

  static {
    TEST_KEYWORDS_3.add("manure");
    TEST_KEYWORDS_3.add("farm");
  }

  public static final String INSERT_VERSION = "1.0";
  public static final String UPDATE_MINOR_VERSION = "1.1";

//    private static final String SEARCH_REQUEST_FULL_TEXT_SINGLE_WORD = "com/monsanto/tcc/documentmanagementserver_version2/apptests/searchRequestForFullText.xml";
//    private static final String SEARCH_REQUEST_FULL_TEXT_MULTIPE_WORD = "com/monsanto/tcc/documentmanagementserver_version2/apptests/searchRequestForFullTextMultipleWords.xml";
//    private static final String SEARCH_REQUEST_FULL_TEXT_WORDS_AND_SEARCH_ATTR = "com/monsanto/tcc/documentmanagementserver_version2/apptests/searchRequestForFullTextMultipleWordsAndSearchAttr.xml";

//	private static String FULL_TEXT_SEARCH_FILE_1 = "fullTextFile1.txt";
//	private static String FULL_TEXT_SEARCH_FILE_2 = "fullTextFile2.doc";
//	private static String FULL_TEXT_SEARCH_FILE_3 = "fullTextFile3.txt";
//	private static String FULL_TEXT_SEARCH_FILE_4 = "fullTextFile4.doc";

  private int validExtendedCharacterDocuments;

  protected void setUp() throws Exception {
    objectId1 = insertTestDocument(ATTACHMENT_1, POSMIMEConstants.MIME_TYPE_TEXT, INSERT_XML_1);
    objectId2 = insertTestDocument(ATTACHMENT_2, POSMIMEConstants.MIME_TYPE_TEXT, INSERT_XML_2);
    objectId3 = insertTestDocument(ATTACHMENT_3, POSMIMEConstants.MIME_TYPE_TEXT, INSERT_XML_3);
    String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document updateReq = TestUtil
        .transformRequestXML(UPDATE_XML_3_TEMPLATE, objectId3, updateTransformationXPathString, 0);
    TestUtil.updateDocument(ATTACHMENT_3, updateReq, POSMIMEConstants.MIME_TYPE_MSWORD);
  }

  protected void tearDown() throws Exception {
    deleteAllVersionsOfInsertDocuments();
  }

  public void testSearchFunctionalityForSingleValuedQueryAttributeOfTypeString_TITLE() throws Exception {
    Document searchResponseDoc = DocumentManagerTestUtils.search(DOMUtil.newDocument(SEARCH_REQUEST_XML));
    validateNumberOfDocumentsReturned(searchResponseDoc, 2);
    validateSearchResponse(objectId1, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_1, "updatedSubject", TEST_DOC_NAME_1,
        TEST_DOC_TITLE_1, TEST_DOC_CREATOR_1, TEST_DOC_SIZE_1, TEST_KEYWORDS_1, searchResponseDoc
    );
    validateSearchResponse(objectId3, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_3, "updatedSubject", TEST_DOC_NAME_3,
        TEST_DOC_TITLE_3, TEST_DOC_CREATOR_3, TEST_DOC_SIZE_3, TEST_KEYWORDS_3, searchResponseDoc
    );
  }

  public void testSearchFunctionality_WithoutAnyQueryAttribute_ReturnsAllDocuments() throws Exception {
    Document searchResponseDoc = DocumentManagerTestUtils
        .search(DOMUtil.newDocument(SEARCH_REQUEST_XML_WITHOUT_QUERY_ATTR));
    validateNumberOfDocumentsReturned(searchResponseDoc, 3);
    validateSearchResponse(objectId1, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_1, "updatedSubject", TEST_DOC_NAME_1,
        TEST_DOC_TITLE_1, TEST_DOC_CREATOR_1, TEST_DOC_SIZE_1, TEST_KEYWORDS_1, searchResponseDoc
    );
    validateSearchResponse(objectId2, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_2, "updatedSubject", TEST_DOC_NAME_2,
        TEST_DOC_TITLE_2, TEST_DOC_CREATOR_2, TEST_DOC_SIZE_2, TEST_KEYWORDS_2, searchResponseDoc
    );
    validateSearchResponse(objectId3, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_3, "updatedSubject", TEST_DOC_NAME_3,
        TEST_DOC_TITLE_3, TEST_DOC_CREATOR_3, TEST_DOC_SIZE_3, TEST_KEYWORDS_3, searchResponseDoc
    );
  }

  public void testSearchFunctionality_WithMultipleQueryAttributes_WithinCurrentVersions() throws Exception {
    Document searchResponseDoc = DocumentManagerTestUtils.search(
        DOMUtil.newDocument(SEARCH_REQUEST_XML_WITH_MULTIPLE_QUERY_ATTRS));
    validateNumberOfDocumentsReturned(searchResponseDoc, 2);
    validateSearchResponse(objectId2, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_2, "updatedSubject", TEST_DOC_NAME_2,
        TEST_DOC_TITLE_2, TEST_DOC_CREATOR_2, TEST_DOC_SIZE_2, TEST_KEYWORDS_2, searchResponseDoc
    );
    validateSearchResponse(objectId3, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_3, "updatedSubject", TEST_DOC_NAME_3,
        TEST_DOC_TITLE_3, TEST_DOC_CREATOR_3, TEST_DOC_SIZE_3, TEST_KEYWORDS_3, searchResponseDoc
    );
  }

  public void testSearchFunctionality_WithMultipleQueryAttributes_WithinAllVersions() throws Exception {
    Document searchResponseDoc = DocumentManagerTestUtils
        .search(DOMUtil.newDocument(SEARCH_REQUEST_XML_ALL_VERSIONS));
    validateNumberOfDocumentsReturned(searchResponseDoc, 3);
    validateSearchResponse(objectId2, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_2, "", TEST_DOC_NAME_2,
        TEST_DOC_TITLE_2, TEST_DOC_CREATOR_2, TEST_DOC_SIZE_2, TEST_KEYWORDS_2, searchResponseDoc
    );
    validateSearchResponse(objectId3, UPDATE_MINOR_VERSION, TEST_DOC_SUBJECT_3, "updatedSubject", TEST_DOC_NAME_3,
        TEST_DOC_TITLE_3, TEST_DOC_CREATOR_3, TEST_DOC_SIZE_3, TEST_KEYWORDS_3, searchResponseDoc
    );
  }

  /**
   * Please Note: This test depends upon 4 files pre-existing in docBase /Pos Test/FullTextDocuments (fullTextFile1.txt,
   * fullTextFile2.doc, fullTextFile3.txt and fullTextFile3.doc).
   *
   * @throws Exception
   */
//    public void testFullTextSearchFunctionality_WithSingleWord() throws Exception {
//        validateFullTextSearchFunctionality(SEARCH_REQUEST_FULL_TEXT_SINGLE_WORD, 2);
//        assertEquals(2, validSingleWordDocuments);
//    }

  /**
   * Please Note: This test depends upon 4 files pre-existing in docBase /Pos Test/FullTextDocuments (fullTextFile1.txt,
   * fullTextFile2.doc, fullTextFile3.txt and fullTextFile3.doc).
   *
   * @throws Exception
   */
//    public void testFullTextSearchFunctionality_WithMultipleWords() throws Exception {
//        validateFullTextSearchFunctionality(SEARCH_REQUEST_FULL_TEXT_MULTIPE_WORD, 3);
//        assertEquals(3, validMultipleWordDocuments);
//    }

  /**
   * Please Note: This test depends upon 4 files pre-existing in docBase /Pos Test/FullTextDocuments (fullTextFile1.txt,
   * fullTextFile2.doc, fullTextFile3.txt and fullTextFile3.doc).
   *
   * @throws Exception
   */
//    public void testFullTextSearchFunctionality_WithMultipleWords_AndSearchAttribute_Keyword() throws Exception {
//        validateFullTextSearchFunctionality(SEARCH_REQUEST_FULL_TEXT_WORDS_AND_SEARCH_ATTR, 2);
//        assertEquals(2, validMultipleWordAndKeywordDocuments);
//    }
//	private void validateFullTextSearchFunctionality(String searchRequest, int expectedNumberOfDocuments) throws
//		IOException,
//		SAXException,
//		POSCommunicationException,
//		POSException,
//		ParserException,
//		GSSException,
//		TransformerException {
//		Document searchReponseDoc = DocumentManagerTestUtils.search(DOMUtil.newDocument(searchRequest));
//		DOMUtil.outputXML(searchReponseDoc);
//		validateNumberOfDocumentsReturned(searchReponseDoc, expectedNumberOfDocuments);
//		validateFullTextSearchResponse(searchReponseDoc);
//	}

//	private void validateFullTextSearchResponse(Document searchReponseDoc) throws TransformerException {
//		int validSingleWordDocuments = 0;
//		int validMultipleWordDocuments = 0;
//		int validMultipleWordAndKeywordDocuments = 0;
//		NodeList documentDetailsNode = XPathAPI
//			.eval(searchReponseDoc, "/documentManagerResponse/searchDocuments/documentDetails").nodelist();
//		int length = documentDetailsNode.getLength();
//		for (int i = 0; i < length; i++) {
//			Node documentNode = documentDetailsNode.item(i);
//			String name = XPathAPI
//				.eval(documentNode, "attribute[name='" + DocumentManagerConstants.ATTR_STR_NAME + "']/value")
//				.toString();
//			if (name.equalsIgnoreCase(FULL_TEXT_SEARCH_FILE_1)) {
//				validSingleWordDocuments++;
//				validMultipleWordDocuments++;
//			}
//			if (name.equalsIgnoreCase(FULL_TEXT_SEARCH_FILE_2)) {
//				validMultipleWordDocuments++;
//				validMultipleWordAndKeywordDocuments++;
//			}
//			if (name.equalsIgnoreCase(FULL_TEXT_SEARCH_FILE_3)) {
//				validMultipleWordDocuments++;
//				validMultipleWordAndKeywordDocuments++;
//			}
//			if (name.equalsIgnoreCase(FULL_TEXT_SEARCH_FILE_4)) {
//				validSingleWordDocuments++;
//			}
//		}
//	}


  //ToDo: FIX THIS - DON'T DEPEND ON SOME DOCUMENT STAYING THERE - IT KEEPS DISAPPEARING

  /**
   * Please Note: This test depends upon 1 file pre-existing in docBase /Pos Test/testSearchDir
   * (testextendedcharacters.txt).
   *
   * @exception Exception
   */
  public void testSearchFunctionality_WithExtendedCharacters_Title() throws Exception {
    validateSearchFunctionality(SEARCH_REQUEST_EXTENDED_CHARACTERS_RETURNED, 1);
    assertEquals(1, validExtendedCharacterDocuments);
  }

  private void validateSearchFunctionality(String searchRequest, int expectedNumberOfDocuments) throws
      IOException, SAXException, POSCommunicationException, POSException, ParserException, GSSException,
      TransformerException {
    Document searchReponseDoc = DocumentManagerTestUtils.search(DOMUtil.newDocument(searchRequest));
    DOMUtil.outputXML(searchReponseDoc);
    validateNumberOfDocumentsReturned(searchReponseDoc, expectedNumberOfDocuments);
    validateSearchResponseWithExtendedCharacters(searchReponseDoc);
  }

  private void validateSearchResponseWithExtendedCharacters(Document searchReponseDoc) throws TransformerException {
    validExtendedCharacterDocuments = 0;
    NodeList documentDetailsNode = XPathAPI
        .eval(searchReponseDoc, "/documentManagerResponse/searchDocuments/documentDetails").nodelist();
    int length = documentDetailsNode.getLength();
    for (int i = 0; i < length; i++) {
      Node documentNode = documentDetailsNode.item(i);
      String name = XPathAPI
          .eval(documentNode, "attribute[name='" + DocumentManagerConstants.ATTR_STR_NAME + "']/value")
          .toString();
      if (name.equalsIgnoreCase("testextendedcharacters.txt")) {
        validExtendedCharacterDocuments++;
      }

      assertXpathEvaluatesTo("This is a test �",
          "/documentManagerResponse/searchDocuments/documentDetails/attribute[name='" +
              DocumentManagerConstants.ATTR_STR_TITLE + "']/value", searchReponseDoc);
    }
  }


  private void deleteAllVersionsOfInsertDocuments() throws ParserException, POSCommunicationException, POSException,
      FileNotFoundException, TransformerException, GSSException {
    DocumentManagerTestUtils.deleteDocument(objectId1);
    DocumentManagerTestUtils.deleteDocument(objectId2);
    DocumentManagerTestUtils.deleteDocument(objectId3);
  }

  private void validateSearchResponse(String objectId, String newVersion, String subject, String updatedSubject,
                                      String docName, String title, String creator, String size, List keywords,
                                      Document searchReponseDoc
  ) throws TransformerException {
    assertXpathEvaluatesTo(docName, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
        + DocumentManagerConstants.ATTR_STR_NAME + XPATH_END_STR,
        searchReponseDoc);
    String documentVersion = XPathAPI.eval(searchReponseDoc, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
        + DocumentManagerConstants.ATTR_STR_VERSION +
        XPATH_END_STR).toString();
    if (documentVersion.equalsIgnoreCase(newVersion)) {
      assertXpathEvaluatesTo(updatedSubject, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
          + DocumentManagerConstants.ATTR_STR_SUBJECT + XPATH_END_STR,
          searchReponseDoc);
    } else {
      assertXpathEvaluatesTo(subject, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
          + DocumentManagerConstants.ATTR_STR_SUBJECT + XPATH_END_STR,
          searchReponseDoc);
    }
    assertXpathEvaluatesTo(title, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
        + DocumentManagerConstants.ATTR_STR_TITLE + XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(creator, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
        + DocumentManagerConstants.ATTR_STR_CREATOR + XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(size, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
        + DocumentManagerConstants.ATTR_STR_SIZE + XPATH_END_STR,
        searchReponseDoc);
    for (int i = 0; i < keywords.size(); i++) {
      String expectedKeyword = (String) keywords.get(i);
      assertXpathEvaluatesTo(expectedKeyword, XPATH_BEGIN_STR + objectId + XPATH_MID_STR
          + DocumentManagerConstants.ATTR_STR_KEYWORDS
          + XPATH_END_STR + "[" + (i + 1) + "]", searchReponseDoc);
    }
  }

  private void validateNumberOfDocumentsReturned(Document searchResponseDoc, int expectedNumberOfNodes) throws
      TransformerException {
    int numberOfNodes = XPathAPI.eval(searchResponseDoc, "/documentManagerResponse/searchDocuments/documentDetails")
        .nodelist().getLength();
    assertEquals(expectedNumberOfNodes, numberOfNodes);
  }

  private String insertTestDocument(String fileAttachment, String mimeType, String insertRequestXml) throws
      ParserException,
      IOException,
      SAXException,
      POSCommunicationException,
      POSException,
      InvalidMimeTypeException,
      TransformerException,
      GSSException {
    DocumentManagerTestUtils
        .deleteDocumentByName(DocumentManagerTestUtils.getNameFromInsertRequest(insertRequestXml));
    MultipartAttachmentList attachmentList = new MultipartAttachmentList();
    addAttachment(attachmentList, fileAttachment, mimeType);
    Document responseDoc = insertDocument(attachmentList, insertRequestXml);
    return getObjectIdOfInsertedDocument(responseDoc);
  }

  private String getObjectIdOfInsertedDocument(Document responseDoc) throws TransformerException {
    String expression = "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" +
        DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value";
    Object objId = XPathAPI.eval(responseDoc, expression);
    return objId.toString();
  }

  private void addAttachment(MultipartAttachmentList attachmentList, String fileName, String mimeType) throws
      InvalidMimeTypeException {
    MultiPartFormAttachment attachment = new MultiPartFormAttachment(fileName, mimeType);
    attachmentList.addAttachment(attachment);
  }

  private Document insertDocument(MultipartAttachmentList attachmentList, String requestXmlDocument) throws
      ParserException,
      POSException,
      POSCommunicationException,
      IOException,
      SAXException,
      GSSException {
    Document inputDoc = DOMUtil.newDocument(requestXmlDocument);
    SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    addAttachmentToConnection(attachmentList, posConn);
    POSResult result = posConn.callService(POS_INSERT_SERVICE_NAME, inputDoc);
    return DOMUtil.newDocument(result.getInputStream());
  }

  private void addAttachmentToConnection(MultipartAttachmentList attachmentList, XMLPOSConnection posConn) {
    int numberOfAttachments = attachmentList.getLength();
    for (int i = 0; i < numberOfAttachments; i++) {
      MultiPartFormAttachment attachment = attachmentList.getAttachment(i);
      posConn.addAttachment(attachment);
    }
  }

}