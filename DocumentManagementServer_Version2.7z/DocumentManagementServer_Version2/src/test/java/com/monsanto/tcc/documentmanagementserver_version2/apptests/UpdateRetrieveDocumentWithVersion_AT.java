package com.monsanto.tcc.documentmanagementserver_version2.apptests;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.Util.FileUtil;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.TestUtil;
import org.apache.xerces.impl.dv.util.Base64;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jun 13, 2006 Time: 4:13:24 PM To change this template use File |
 * Settings | File Templates.
 */
public class UpdateRetrieveDocumentWithVersion_AT extends XMLTestCase {
  private String objectId;
  private static final String CONTENTS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private static final String INSERT_REQUEST_XML = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/retrieveService/tests/insertRequest.xml";
  private static final String UPDATED_CONTENTS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/test.doc";
  private static final String UPDATE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/retrieveService/tests/updateRequest.xml";
  private static final String XPATH_BEGIN_STR = "/documentManagerResponse/documentUpdatedSuccessfully/documentDetails/attribute[name = '";
  private static final String XPATH_END_STR = "']/value";
  private static final String NEW_MAJOR_VERSION = "2.0";
  private static final String XPATH_START_STRING_ATTR_MATCH = "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name = '";
  private static final String XPATH_END_STRING_ATTR_MATCH = "']/value";
  private static final String POS_RETRIEVE_SERVICE_NAME = "RetrieveDocumentService";
  private static final String RETRIEVE_REQUEST_VERSION_2_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/apptests/retrieveRequest.xml";
  private static final String RETRIEVE_REQUEST_VERSION_1_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/apptests/retrieveVersion1Request.xml";

  protected void setUp() throws Exception {
    objectId = TestUtil.insertTestDocument(CONTENTS, POSMIMEConstants.MIME_TYPE_TEXT, INSERT_REQUEST_XML);
  }

  protected void tearDown() throws Exception {
    if (objectId != null && objectId.length() > 0) {
      TestUtil.deleteAllVersionsOfInsertedDocument(objectId);
    }
  }

  public void testUpdateService_WithAttrAndContentsOfDifferentFormat_ToMajorVersion() throws Exception {
    String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document updateReq = TestUtil
        .transformRequestXML(UPDATE_REQUEST_TEMPLATE, objectId, updateTransformationXPathString, 0);
    Document updateResponseDoc = TestUtil
        .updateDocument(UPDATED_CONTENTS, updateReq, POSMIMEConstants.MIME_TYPE_MSWORD);
    validateUpdateResponseContainsNoError(updateResponseDoc);
    validateUpdateResponse(updateResponseDoc, objectId, NEW_MAJOR_VERSION);
    Document retrieveResponseDoc = retrieveDocument(RETRIEVE_REQUEST_VERSION_2_TEMPLATE);
    String retrievedFile = retrievedDocumentContents(retrieveResponseDoc);
    assertTrue(FileUtil.compareFiles(UPDATED_CONTENTS, retrievedFile));
    validateAttribute(retrieveResponseDoc, DocumentManagerConstants.ATTR_STR_TITLE, "newTitle");
    validateAttribute(retrieveResponseDoc, DocumentManagerConstants.ATTR_STR_SUBJECT, "farm resource");
  }

  public void testRetrieveService_ReturnsExpectedVersion() throws Exception {
    String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document updateReq = TestUtil
        .transformRequestXML(UPDATE_REQUEST_TEMPLATE, objectId, updateTransformationXPathString, 0);
    Document updateResponseDoc = TestUtil
        .updateDocument(UPDATED_CONTENTS, updateReq, POSMIMEConstants.MIME_TYPE_MSWORD);
    validateUpdateResponseContainsNoError(updateResponseDoc);
    validateUpdateResponse(updateResponseDoc, objectId, NEW_MAJOR_VERSION);
    Document retrieveResponseDoc = retrieveDocument(RETRIEVE_REQUEST_VERSION_1_TEMPLATE);
    String retrievedFile = retrievedDocumentContents(retrieveResponseDoc);
    assertTrue(FileUtil.compareFiles(CONTENTS, retrievedFile));
    validateAttribute(retrieveResponseDoc, DocumentManagerConstants.ATTR_STR_TITLE, "monsanto search docs");
    validateAttribute(retrieveResponseDoc, DocumentManagerConstants.ATTR_STR_SUBJECT, "farm resource");
  }

  private void validateAttribute(Document responseDocument, String attrName, String attrValue) throws
      TransformerException {
    assertXpathEvaluatesTo(attrValue,
        "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name='" + attrName + "']/value",
        responseDocument);
  }

  private Document retrieveDocument(String retrieveRequestTemplate) throws TransformerException, GSSException,
      POSCommunicationException, POSException, ParserException, IOException, SAXException {
    String xpathString = "/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute/value";
    Document retrieveReq = TestUtil.transformRequestXML(retrieveRequestTemplate, objectId, xpathString, 0);
    XMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()),
        new KerberosStandaloneCredential());
    POSResult result = posConn.callService(POS_RETRIEVE_SERVICE_NAME, retrieveReq);
    return DOMUtil.newDocument(result.getInputStream());
  }

  private String retrievedDocumentContents(Document retrieveResponseDoc) throws IOException, TransformerException {
    String encodedContentString = XPathAPI.eval(retrieveResponseDoc,
        XPATH_START_STRING_ATTR_MATCH + DocumentManagerConstants.ATTR_STR_CONTENTS + XPATH_END_STRING_ATTR_MATCH)
        .toString();
    byte decodedByte[] = Base64.decode(encodedContentString);
    String filePath = System.getProperty(DocumentManagerConstants.TEMP_DIRECTORY) + XPathAPI.eval(retrieveResponseDoc,
        XPATH_START_STRING_ATTR_MATCH + DocumentManagerConstants.ATTR_STR_NAME + XPATH_END_STRING_ATTR_MATCH)
        .toString();
    FileOutputStream foStream = new FileOutputStream(filePath);
    foStream.write(decodedByte, 0, decodedByte.length);
    foStream.flush();
    foStream.close();
    return filePath;
  }

  private void validateUpdateResponseContainsNoError(Document updateResponseDoc) throws TransformerException {
    String errorMessage = XPathAPI.eval(updateResponseDoc, "/ERROR/ERROR_MESSAGE").toString();
    assertTrue("POS exception thrown = " + errorMessage, StringUtils.isNullOrEmpty(errorMessage));
  }

  private void validateUpdateResponse(Document updateReponseDoc, String objectId, String version) throws
      TransformerException {
    assertXpathEvaluatesTo(objectId,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR,
        updateReponseDoc);
    assertXpathEvaluatesTo(version, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_VERSION + XPATH_END_STR,
        updateReponseDoc);
  }
}