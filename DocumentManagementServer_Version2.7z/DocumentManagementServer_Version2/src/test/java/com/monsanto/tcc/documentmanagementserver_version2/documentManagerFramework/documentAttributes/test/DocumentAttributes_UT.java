package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.test;

import junit.framework.TestCase;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Apr 5, 2006
 * Time: 10:44:02 AM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentAttributes_UT extends TestCase {

  public void testSingleValuedAttributeAddedCorrectly() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    documentAttributes.addAttribute("name", "testName", null);
    documentAttributes.addAttribute("subject", "testSubject", null);
    assertEquals(documentAttributes.getAttrValue("name"), "testName");
    assertEquals(documentAttributes.getAttrValue("subject"), "testSubject");
  }

  public void testMultiValuedAttributeAddedCorrectly() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    addKeywords(documentAttributes, "keywords");
    assertEquals(documentAttributes.getAttrValues("keywords").get(0), "farm");
    assertEquals(documentAttributes.getAttrValues("keywords").get(1), "crop");
    assertEquals(documentAttributes.getAttrValues("keywords").get(2), "seed");
  }

  public void testAdddingOfMultiValuedAttrWithOneValue() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    List authorList = new ArrayList();
    authorList.add("testAuthor1");
    documentAttributes.addAttribute("authors", authorList, null);
    assertEquals("testAuthor1", documentAttributes.getAttrValues("authors").get(0));
  }

  public void testExceptionThrownIfIncorrectMethodCallIsInvokedToGetAttribute() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    addKeywords(documentAttributes, "keywords");
    documentAttributes.addAttribute("name", "testName", null);
    try {
      documentAttributes.getAttrValue("keywords");
    } catch (AttributeListParseException e) {
      //expected path
    }
    try {
      documentAttributes.getAttrValues("name");
    } catch (AttributeListParseException e) {
      //expected path
    }
  }

  public void testExceptionThrownIfHasMultipleValuesCalledOnANullAttr() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    try {
      documentAttributes.hasMultipleValues("keywords");
    } catch (AttributeListParseException e) {
      //expected path
    }
  }

  public void testCorrectAttributeTypeReturned() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    addKeywords(documentAttributes, "keywords");
    documentAttributes.addAttribute("name", "testName", null);
    assertFalse(documentAttributes.hasMultipleValues("name"));
    assertTrue(documentAttributes.hasMultipleValues("keywords"));
  }

  private void addKeywords(DocumentAttributes documentAttributes, String attrName) {
    List keywordList = new ArrayList();
    keywordList.add("farm");
    keywordList.add("crop");
    keywordList.add("seed");
    documentAttributes.addAttribute(attrName, keywordList, null);
  }

  public void testTotalNumberOfAttributesReturnedCorrectly() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    addKeywords(documentAttributes, "keywords");
    documentAttributes.addAttribute("name", "testName", null);
    documentAttributes.addAttribute("subject", "testSubject", null);
    assertEquals(3, documentAttributes.getLength());
  }

  public void testIterationOverAttributeListSupported() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    addKeywords(documentAttributes, "keywords");
    documentAttributes.addAttribute("name", "testName", null);
    documentAttributes.addAttribute("subject", "testSubject", null);
    Iterator attributeIterator = documentAttributes.getAttrIterator();
    while(attributeIterator.hasNext()){
      String attributeName = (String) attributeIterator.next();
      if(documentAttributes.hasMultipleValues(attributeName)){
        assertEquals("crop", documentAttributes.getAttrValues(attributeName).get(1));
      }
      if(!documentAttributes.hasMultipleValues(attributeName) && attributeName.equalsIgnoreCase("name")){
        assertEquals("testName", documentAttributes.getAttrValue(attributeName));
      }
      if(!documentAttributes.hasMultipleValues(attributeName) && attributeName.equalsIgnoreCase("subject")){
        assertEquals("testSubject", documentAttributes.getAttrValue(attributeName));
      }
    }
  }

  public void testRemoveAttributeSupportedSupported() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    addKeywords(documentAttributes, "keywords");
    documentAttributes.addAttribute("name", "testName", null);
    documentAttributes.addAttribute("subject", "testSubject", null);
    assertEquals(3, documentAttributes.getLength());
    documentAttributes.removeAttr("name");
    assertEquals(2, documentAttributes.getLength());
  }

  public void testExceptionThrownIfGetAttrValueCalledOnNonExistingAttribute() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    try {
      documentAttributes.getAttrValue("nonExistingValue");
    } catch (AttributeListParseException e) {
      //expected path
    }
    try {
      documentAttributes.getAttrValues("nonExistingValueList");
    } catch (AttributeListParseException e) {
      //expected path
    }
  }

  public void testExceptionThrownIfNullAttributesMap() throws Exception {
    DocumentAttributes documentAttributes = null;
    try {
      documentAttributes.getAttrValue("nonExistingValue");
    } catch (NullPointerException e) {
      //expected path
    }
  }

  public void testGetLengthReturnsZeroIfNoAttributesPresent() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    assertEquals(0, documentAttributes.getLength());
  }

  public void testAttributeNotAddedIfMultiValuedAttrIsNullOrHasNoValues() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    documentAttributes.addAttribute("authors", new ArrayList(), null);
    try {
      documentAttributes.getAttrValues("authors");
    } catch (AttributeListParseException e) {
      //expected path
    }
    List someList = null;
    documentAttributes.addAttribute("keywords", someList, null);
    try {
      documentAttributes.getAttrValues("keywords");
    } catch (AttributeListParseException e) {
      //expected path
    }
  }

  public void testAdditionOfAttributeValuesWithOperator() throws Exception {
    DocumentAttributes documentAttributes = new DocumentAttributes();
    documentAttributes.addAttribute("name", "testName", "equals");
    documentAttributes.addAttribute("subject", "testSubject", "unequals");
    addKeywordsWithOperator(documentAttributes, "keywords", "in");
    assertEquals(documentAttributes.getAttrValue("name"), "testName");
    assertEquals(documentAttributes.getOperator("name"), "equals");
    assertEquals(documentAttributes.getAttrValue("subject"), "testSubject");
    assertEquals(documentAttributes.getOperator("subject"), "unequals");
    assertEquals(documentAttributes.getAttrValues("keywords").get(0), "farm");
    assertEquals(documentAttributes.getAttrValues("keywords").get(1), "crop");
    assertEquals(documentAttributes.getAttrValues("keywords").get(2), "seed");
    assertEquals(documentAttributes.getOperator("keywords"), "in");
  }

  public void testAdditionOfAttributeValuesWithNullOperator_throwsException() throws Exception {
    try {
      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute("name", "testName", null);
      documentAttributes.getOperator("name");
    } catch (AttributeListParseException e) {
      System.out.println("Expected path, exception thrown = " + e.getMessage());
    }
  }

  public void testAdditionOfAttributeValuesWithBlankOperator_throwsException() throws Exception {
    try {
      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute("name", "testName", "");
      documentAttributes.getOperator("name");
    } catch (AttributeListParseException e) {
      System.out.println("Expected path, exception thrown = " + e.getMessage());
    }
  }

  public void testRetrievingOperatorOfAttributeWithNoOperatorAdded_throwsException() throws Exception {
    try {
      DocumentAttributes documentAttributes = new DocumentAttributes();
      documentAttributes.addAttribute("name", "testName", null);
      documentAttributes.getOperator("name");
    } catch (AttributeListParseException e) {
      System.out.println("Expected path, exception thrown = " + e.getMessage());
    }
  }

  private void addKeywordsWithOperator(DocumentAttributes documentAttributes, String attrName, String operator) {
    List keywordList = new ArrayList();
    keywordList.add("farm");
    keywordList.add("crop");
    keywordList.add("seed");
    documentAttributes.addAttribute(attrName, keywordList, operator);
  }
}