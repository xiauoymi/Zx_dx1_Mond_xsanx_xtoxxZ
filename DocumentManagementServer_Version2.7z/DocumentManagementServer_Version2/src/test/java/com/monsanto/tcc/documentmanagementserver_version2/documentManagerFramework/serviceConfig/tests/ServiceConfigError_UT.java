package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.tests;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 23, 2006 Time: 1:28:04 PM To change this template use File |
 * Settings | File Templates.
 */
public class ServiceConfigError_UT extends TestCase {

  IServiceLookup serviceLookup;

  public void testExceptionThrownIfFilePathIsInvalid() throws Exception {
    try {
      serviceLookup = new ServiceLookup("/nonExixtingFilePath");
      fail("Service Config Exception NOT thrown when filePath is invalid.");
    } catch (ServiceConfigException e) {
      System.out.println("Required Exception thrown: " + e.getMessage());
    }
  }

  public void testExceptionThrownIfFolderSpecNotFound() throws Exception {
    try {
      serviceLookup = new ServiceLookup(
          "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml");
      serviceLookup.lookupRepositoryName("nonExistingFolderName");
      fail("Service Config Exception NOT thrown when folder specification is not present or invalid.");
    } catch (ServiceConfigException e) {
      System.out.println("Required Exception thrown: " + e.getMessage());
    }
  }
}
