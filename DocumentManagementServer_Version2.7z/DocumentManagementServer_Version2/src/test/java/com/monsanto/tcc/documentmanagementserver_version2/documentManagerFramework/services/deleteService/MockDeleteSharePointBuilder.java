package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.builder.DeleteSharePointBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.MockDeleteSharePointRequestParser;

/**
 * Created by IntelliJ IDEA.
* User: mecoru
* Date: May 21, 2010
* Time: 1:10:10 PM
* To change this template use File | Settings | File Templates.
*/
public class MockDeleteSharePointBuilder extends DeleteSharePointBuilder {
	public void buildParser() {
		setRequestParser(new MockDeleteSharePointRequestParser());
	}
}
