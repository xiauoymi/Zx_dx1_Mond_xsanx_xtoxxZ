package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.tests;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockXMLPOSConnectionForInsert;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.DeleteDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.TestUtil;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 16, 2006 Time: 5:34:11 PM To change this template use File |
 * Settings | File Templates.
 */
public class DeleteDocPOS_UT extends XMLTestCase {

  private static final String ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/deleteService/tests/testFile1.txt";
  private static final String INSERT_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/deleteService/tests/insertReq1.xml";
  private static final String UPDATE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/deleteService/tests/updateReq1.xml";
  private static final String POS_INSERT_SERVICE_NAME = "InsertDocumentService";
  private static final String DELETE_REQUEST_XML = "C:/deleteRequestDoc.xml";
  private static final String DELETE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/deleteService/tests/deleteRequest.xml";
  private static final String DELETE_REQUEST_WITH_VERSION_1_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/deleteService/tests/deleteRequestWithVersion1.xml";
  private static final String DELETE_REQUEST_WITH_VERSION_2_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/deleteService/tests/deleteRequestWithVersion2.xml";
  private static final String XPATH_BEGIN_STR = "/documentManagerResponse/documentDeletedSuccessfully/documentDetails/attribute[name = '";
  private static final String XPATH_END_STR = "']/value";
  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";
  private String objectId1;

  protected void setUp() throws IOException, ParserException, TransformerException, InvalidMimeTypeException,
      SAXException, POSCommunicationException, POSException, GSSException {
    objectId1 = insertTestDocument(ATTACHMENT_1, POSMIMEConstants.MIME_TYPE_TEXT, INSERT_XML_1);
//		objectId1 = "09001abe801ec377";
    System.out.println("DeleteDocPOS_UT.setUp: objectId1 = " + objectId1);
  }

  protected void tearDown() throws Exception {
    deleteTemporaryXMLDocument();
  }

  public void testDelete_WithoutVersionSpecification_DeletesAllVersions() throws Exception {
    updateVersion();
    deleteDocumentWithVersion(DELETE_REQUEST_TEMPLATE, DocumentManagerConstants.RESP_CONST_ALL_VERSIONS_DELETED);
  }

  public void testDelete_WithVersionSpecification_DeletesCorrectVersion() throws Exception {
    updateVersion();
    deleteDocumentWithVersion(DELETE_REQUEST_WITH_VERSION_1_TEMPLATE, "1.0");
    deleteDocumentWithVersion(DELETE_REQUEST_WITH_VERSION_2_TEMPLATE, "2.0");
  }

  private void updateVersion() throws ParserException, TransformerException, InvalidMimeTypeException, GSSException,
      POSCommunicationException, POSException, IOException, SAXException {
    String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document updateReq = TestUtil
        .transformRequestXML(UPDATE_REQUEST_TEMPLATE, objectId1, updateTransformationXPathString, 0);
    TestUtil.updateDocument(ATTACHMENT_1, updateReq, POSMIMEConstants.MIME_TYPE_MSWORD);
  }

  private void deleteDocumentWithVersion(String deleteRequestTemplate, String versionsDeleted) throws ParserException,
      TransformerException, IOException {
    createTestDeleteRequestXML(DELETE_REQUEST_XML, objectId1, deleteRequestTemplate);
    DeleteDocumentPOS deleteDocumentPOS = new MockDeleteDocPOSWithTestConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(DELETE_REQUEST_XML);
    deleteDocumentPOS.run(mockUCCHelper);
    Document deleteReponseDoc = mockUCCHelper.getXML();
    DOMUtil.outputXML(deleteReponseDoc);
    validateResponse(deleteReponseDoc, objectId1, versionsDeleted);
  }

  private void validateResponse(Document deleteReponseDoc, String deletedObjectId, String versionsDeleted) throws
      TransformerException {
    assertXpathEvaluatesTo(deletedObjectId,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR,
        deleteReponseDoc);
    assertXpathEvaluatesTo(versionsDeleted, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_VERSION + XPATH_END_STR,
        deleteReponseDoc);
  }

  private void createTestDeleteRequestXML(String deleteRequestFilenamePath, String objectId,
                                          String deleteRequestTemplate) throws FileNotFoundException, ParserException,
      TransformerException {
    Document deleteRequestDoc = DOMUtil.newDocument(deleteRequestTemplate);
    Node objectIdValueNode = XPathAPI.eval(deleteRequestDoc,
        "/inputPos/command/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    saveAsXMLFile(deleteRequestDoc, deleteRequestFilenamePath);
  }

  private void deleteTemporaryXMLDocument() {
    new File(DELETE_REQUEST_XML).delete();
  }

  private String insertTestDocument(String fileAttachment, String mimeType, String insertRequestXml) throws
      ParserException, IOException, SAXException, POSCommunicationException, POSException, InvalidMimeTypeException,
      TransformerException, GSSException {
    MultipartAttachmentList attachmentList = new MultipartAttachmentList();
    addAttachment(attachmentList, fileAttachment, mimeType);
    Document responseDoc = insertDocument(attachmentList, insertRequestXml);
    return getObjectIdOfInsertedDocument(responseDoc);
  }


  private void saveAsXMLFile(Document deleteRequestDoc, String deleteRequestFilenamePath) throws FileNotFoundException {
    DOMUtil.outputXML(deleteRequestDoc, new FileOutputStream(new File(deleteRequestFilenamePath)));
  }

  private void addAttachment(MultipartAttachmentList attachmentList, String fileName, String mimeType) throws
      InvalidMimeTypeException {
    MultiPartFormAttachment attachment = new MultiPartFormAttachment(fileName, mimeType);
    attachmentList.addAttachment(attachment);
  }

  private Document insertDocument(MultipartAttachmentList attachmentList, String requestXmlDocument) throws
      ParserException, POSException, POSCommunicationException, IOException, SAXException, GSSException {
    Document inputDoc = DOMUtil.newDocument(requestXmlDocument);
    SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    addAttachmentToConnection(attachmentList, posConn);
    POSResult result = posConn.callService(POS_INSERT_SERVICE_NAME, inputDoc);
    return DOMUtil.newDocument(result.getInputStream());
  }

  private void addAttachmentToConnection(MultipartAttachmentList attachmentList, XMLPOSConnection posConn) {
    int numberOfAttachments = attachmentList.getLength();
    for (int i = 0; i < numberOfAttachments; i++) {
      MultiPartFormAttachment attachment = attachmentList.getAttachment(i);
      posConn.addAttachment(attachment);
    }
  }

  private String getObjectIdOfInsertedDocument(Document responseDoc) throws TransformerException {
    String expression = "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" +
        DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value";
    Object objId = XPathAPI.eval(responseDoc, expression);
    return objId.toString();
  }

  class MockDeleteDocPOSWithTestConfig extends DeleteDocumentPOS {

    protected ServiceLookup instantiateServiceLookup() throws ServiceConfigException {
      return new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    }
  }
}