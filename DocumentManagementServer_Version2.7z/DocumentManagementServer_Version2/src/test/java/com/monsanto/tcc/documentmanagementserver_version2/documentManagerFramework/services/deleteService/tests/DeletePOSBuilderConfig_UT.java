package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocumentService;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.DeleteDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.deleteDocumentumDocs.entity.DeleteDocumentumRequestEntity;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.io.File;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 11, 2006 Time: 11:17:20 AM To change this template use File |
 * Settings | File Templates.
 */
public class DeletePOSBuilderConfig_UT extends XMLTestCase {
  private static final String TEST_DELETE_REQUEST_XML = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/deleteService/tests/deleteRequest.xml";
  private static final String TEST_DELETE_REQUEST_XML_WITHOUT_OBJECTID = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/deleteService/tests/deleteRequestWithoutObjectId.xml";
  private static final String TEST_DELETE_REQUEST_XML_WITH_INVALID_LOCATION = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/deleteService/tests/deleteRequestWithInvalidLocation.xml";
  private static final String DELETE_REQUEST_XML = "C:/deleteRequestDoc.xml";
  private static final String TEST_DELETED_OBJECT_ID = "0098abced786";
  private static final String XPATH_BEGIN_STR = "/documentManagerResponse/documentDeletedSuccessfully/documentDetails/attribute[name = '";
  private static final String XPATH_END_STR = "']/value";
  private static final String ERROR_MESSAGE_TAG = "/ERROR/ERROR_MESSAGE";

  protected void tearDown() throws Exception {
    deleteTemporaryXMLDocument();
  }

  public void testRunImplementationForDeleteService() throws Exception {
    DeleteDocumentPOS deleteDocumentPOS = new MockPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(TEST_DELETE_REQUEST_XML);
    deleteDocumentPOS.run(mockUCCHelper);
    Document deleteResponseDoc = mockUCCHelper.getXML();
		
		DOMUtil.outputXML(deleteResponseDoc);

		validateResponse(deleteResponseDoc, TEST_DELETED_OBJECT_ID);
  }

  public void testRunImplementationForDeleteServiceThrowsExceptionIfObjectIdNotSpecifiedInRequest() throws Exception {
    DeleteDocumentPOS deleteDocumentPOS = new MockPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(TEST_DELETE_REQUEST_XML_WITHOUT_OBJECTID);
    deleteDocumentPOS.run(mockUCCHelper);
    Document deleteResponseDoc = mockUCCHelper.getXML();
    validateErrorMessageForMissingObjectIdInRequest(deleteResponseDoc);
  }

  public void testRunImplementationForDeleteServiceThrowsExceptionIfLocationDoesNotMapToAnImplementingService() throws
      Exception {
    DeleteDocumentPOS deleteDocumentPOS = new MockPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(TEST_DELETE_REQUEST_XML_WITH_INVALID_LOCATION);
    deleteDocumentPOS.run(mockUCCHelper);
    Document deleteResponseDoc = mockUCCHelper.getXML();
    validateErrorMessageForInvalidLocation(deleteResponseDoc);
  }

  private void deleteTemporaryXMLDocument() {
    new File(DELETE_REQUEST_XML).delete();
  }

  private void validateErrorMessageForInvalidLocation(Document deleteReponseDoc) throws TransformerException {
    assertXpathExists(ERROR_MESSAGE_TAG, deleteReponseDoc);
    String expectedMessage = "No service found for specified folder: \"UnavailableService\"";
    String actualMessage = XPathAPI.eval(deleteReponseDoc, ERROR_MESSAGE_TAG).toString();
    if (actualMessage.indexOf(expectedMessage) == -1) {
      fail("No error message stating: Location Does Not Map To An Implementing Service");
    }
  }

  private void validateErrorMessageForMissingObjectIdInRequest(Document deleteReponseDoc) throws TransformerException {
    assertXpathEvaluatesTo(
        "Document Manager Exception while performing requested operation: Query Attr not parsed correctly",
        ERROR_MESSAGE_TAG, deleteReponseDoc);
  }

  private void validateResponse(Document deleteReponseDoc, String deletedObjectId) throws TransformerException {
    assertXpathExists(XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR,
        deleteReponseDoc);
    assertXpathEvaluatesTo(deletedObjectId,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR,
        deleteReponseDoc);
  }

  class MockPOS extends DeleteDocumentPOS {
    protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
      return new ServiceLookup(DocumentManagerConstants.TEST_SERVICE_CONFIG_FILE_NAME);
    }

    public void performOperation(RequestEntity requestEntity, DocumentService service, ResponseEntity responseEntity,
                                 UCCHelper helper) throws DocumentManagerException {
      try {
        validateConnectionParams(requestEntity);
      } catch (AttributeListParseException e) {
        throw new DocumentManagerException(e);
      }
      try {
        validateTransformedRequestEntity(requestEntity);
      } catch (AttributeListParseException e) {
        throw new DocumentManagerException("Query Attr not parsed correctly");
      }
      RetrievedDocument retrievedDocument = buildMockRetrievedDocument();
      sendMockResponse(responseEntity, retrievedDocument);
    }

    private void sendMockResponse(ResponseEntity responseEntity, RetrievedDocument retrievedDocument) {
      responseEntity.getRetrievedDocumentList().add(retrievedDocument);
    }

    private RetrievedDocument buildMockRetrievedDocument() {
      RetrievedDocument retrievedDocument = new RetrievedDocument();
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, TEST_DELETED_OBJECT_ID, null);
      return retrievedDocument;
    }

    private void validateConnectionParams(RequestEntity requestEntity) throws DocumentManagerException,
        AttributeListParseException {
      DeleteDocumentumRequestEntity deleteRequestEntity = (DeleteDocumentumRequestEntity) requestEntity;
      if (!deleteRequestEntity.getFolderName().equalsIgnoreCase("posTestFolder")) {
        throw new DocumentManagerException("Connection/Configuration params not parsed correctly");
      }
    }

    private void validateTransformedRequestEntity(RequestEntity requestEntity) throws DocumentManagerException,
        AttributeListParseException {
      DeleteDocumentumRequestEntity deleteRequestEntity = (DeleteDocumentumRequestEntity) requestEntity;
      if (!deleteRequestEntity.getDocumentAttributes()
          .getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID).equals(TEST_DELETED_OBJECT_ID)
          ) {
        fail("Query Attribute not parsed correctly");
      }
    }
  }
}