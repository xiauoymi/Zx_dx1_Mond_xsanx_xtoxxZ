package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.retrieveService.tests;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockXMLPOSConnectionForInsert;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.*;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.retrieveService.RetrieveDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.RetrieveDocumentumRequestEntity;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 22, 2006 Time: 4:06:48 PM To change this template use File |
 * Settings | File Templates.
 */
public class RetrieveWithRendition_UT extends XMLTestCase {

  private static final String RETRIEVE_WITH_RENDITION_REQUEST_XML = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/retrieveService/tests/retrieveWithRenditionRequest.xml";

  private static final String XPATH_BEGIN_STR = "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name = '";
  private static final String XPATH_END_STR = "']/value";

  private static final String TEST_DOC_ID = "1234";
  private static final String TEST_DOC_NAME = "testName.doc";
  private static final String TEST_DOC_SUBJECT = "testSubject";
  private static final String TEST_DOC_TITLE = "testTitle";
  private static final String TEST_DOC_CREATOR = "testCreator";
  private static final String TEST_DOC_SIZE = "99";
  private static final String TEST_REQUIRED_FORMAT = "pdf";

  private static List TEST_KEYWORDS;
  private String objectId;
  private static final String RETRIEVE_REQUEST_XML = "C:/retrieveRequestDoc.xml";
  private static final String DELETE_REQUEST_XML = "C:/deleteRequestDoc.xml";
  private static final String POS_DELETE_SERVICE_NAME = "DeleteDocumentService";

  private static final String ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private static final String INSERT_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/insertReq1.xml";
  private static final String POS_INSERT_SERVICE_NAME = "InsertDocumentService";
  private static final String TEST_DELETE_REQUEST_XML = "com/monsanto/tcc/documentmanagementserver_version2/apptests/deleteRequest.xml";

  static {
    TEST_KEYWORDS = new ArrayList();
    TEST_KEYWORDS.add("farm");
    TEST_KEYWORDS.add("crop");
    TEST_KEYWORDS.add("field");
  }

  protected void setUp() throws IOException, ParserException, GSSException, TransformerException,
      InvalidMimeTypeException, SAXException, POSCommunicationException, POSException {
    objectId = insertTestDocument(ATTACHMENT_1, POSMIMEConstants.MIME_TYPE_TEXT, INSERT_XML_1);
  }

  protected void tearDown() throws Exception {
    if (objectId != null && objectId.length() > 0) {
      deleteTemporaryInsertedAndCreatedFiles();
    }
  }

  public void testRetrieveRequestWithRendition_FormatAttributeParsedCorrectly() throws Exception {
    RetrieveDocumentPOS retrieveDocumentPOS = new MockRetrieveDocPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(RETRIEVE_WITH_RENDITION_REQUEST_XML);
    retrieveDocumentPOS.run(mockUCCHelper);
    Document retrieveReponseDoc = DOMUtil.newDocument(mockUCCHelper.getInputStream(""));
    validateResponse(retrieveReponseDoc);
  }

  private String insertTestDocument(String fileAttachment, String mimeType, String insertRequestXml) throws
      ParserException, IOException, SAXException, POSCommunicationException, POSException, InvalidMimeTypeException,
      TransformerException, GSSException {
    MultipartAttachmentList attachmentList = new MultipartAttachmentList();
    addAttachment(attachmentList, fileAttachment, mimeType);
    Document responseDoc = insertDocument(attachmentList, insertRequestXml);
    return getObjectIdOfInsertedDocument(responseDoc);
  }

  private Document insertDocument(MultipartAttachmentList attachmentList, String requestXmlDocument) throws
      ParserException, POSException, POSCommunicationException, IOException, SAXException, GSSException {
    Document inputDoc = DOMUtil.newDocument(requestXmlDocument);
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    addAttachmentToConnection(attachmentList, posConn);
    POSResult result = posConn.callService(POS_INSERT_SERVICE_NAME, inputDoc);
    return DOMUtil.newDocument(result.getInputStream());
  }

  private void addAttachmentToConnection(MultipartAttachmentList attachmentList, XMLPOSConnection posConn) {
    int numberOfAttachments = attachmentList.getLength();
    for (int i = 0; i < numberOfAttachments; i++) {
      MultiPartFormAttachment attachment = attachmentList.getAttachment(i);
      posConn.addAttachment(attachment);
    }
  }

  private void addAttachment(MultipartAttachmentList attachmentList, String fileName, String mimeType) throws
      InvalidMimeTypeException {
    MultiPartFormAttachment attachment = new MultiPartFormAttachment(fileName, mimeType);
    attachmentList.addAttachment(attachment);
  }

  private String getObjectIdOfInsertedDocument(Document responseDoc) throws TransformerException {
    String expression = "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" +
        DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value";
    Object objId = XPathAPI.eval(responseDoc, expression);
    return objId.toString();
  }

  private void deleteTemporaryInsertedAndCreatedFiles() throws ParserException, FileNotFoundException,
      TransformerException, POSException, POSCommunicationException, GSSException {
    deleteFromDctm();
    deleteFromFileSystem();
  }

  private void deleteFromDctm() throws FileNotFoundException, ParserException, TransformerException, GSSException,
      POSException, POSCommunicationException {
    createTestDeleteRequestXML(DELETE_REQUEST_XML, objectId);
    Document inputDoc = DOMUtil.newDocument(DELETE_REQUEST_XML);
    SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    posConn.callService(POS_DELETE_SERVICE_NAME, inputDoc);
  }

  private void deleteFromFileSystem() {
    new File(RETRIEVE_REQUEST_XML).delete();
    new File(DELETE_REQUEST_XML).delete();
  }

  private void createTestDeleteRequestXML(String deleteRequestFilenamePath, String objectId) throws
      FileNotFoundException, ParserException, TransformerException {
    Document deleteRequestDoc = DOMUtil.newDocument(TEST_DELETE_REQUEST_XML);
    Node objectIdValueNode = XPathAPI
        .eval(deleteRequestDoc, "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    saveAsXMLFile(deleteRequestDoc, deleteRequestFilenamePath);
  }

  private void saveAsXMLFile(Document deleteRequestDoc, String deleteRequestFilenamePath) throws FileNotFoundException {
    DOMUtil.outputXML(deleteRequestDoc, new FileOutputStream(new File(deleteRequestFilenamePath)));
  }

  private void validateResponse(Document retrieveReponseDoc) throws TransformerException {
    assertXpathEvaluatesTo(TEST_DOC_ID,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR,
        retrieveReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_NAME, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_NAME + XPATH_END_STR,
        retrieveReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_SUBJECT,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_SUBJECT + XPATH_END_STR,
        retrieveReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_TITLE, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_TITLE + XPATH_END_STR,
        retrieveReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_CREATOR,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_CREATOR + XPATH_END_STR,
        retrieveReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_SIZE, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_SIZE + XPATH_END_STR,
        retrieveReponseDoc);
    for (int i = 0; i < TEST_KEYWORDS.size(); i++) {
      String expestedKeyword = (String) TEST_KEYWORDS.get(i);
      assertXpathEvaluatesTo(expestedKeyword, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_KEYWORDS
          + XPATH_END_STR + "[" + (i + 1) + "]", retrieveReponseDoc);
    }
  }

  class MockRetrieveDocPOS extends RetrieveDocumentPOS {

    public void performOperation(RequestEntity requestEntity, DocumentService service, ResponseEntity responseEntity,
                                 UCCHelper helper) throws DocumentManagerException {
      try {
        validateConnectionParams(requestEntity);
      } catch (AttributeListParseException e) {
        throw new DocumentManagerException(e);
      }
      try {
        validateTransformedRequestEntity(requestEntity);
      } catch (AttributeListParseException e) {
        throw new DocumentManagerException("Required/Query Attr not parsed correctly");
      }
      RetrievedDocument retrievedDocument = buildMockRetrievedDocument();
      sendMockResponse(responseEntity, retrievedDocument);
    }

    private RetrievedDocument buildMockRetrievedDocument() {
      RetrievedDocument retrievedDocument = new RetrievedDocument();
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, TEST_DOC_ID, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_NAME, TEST_DOC_NAME, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT, TEST_DOC_SUBJECT, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, TEST_KEYWORDS, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_CREATOR, TEST_DOC_CREATOR, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_SIZE, TEST_DOC_SIZE, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TEST_DOC_TITLE, null);
      return retrievedDocument;
    }

    private void validateTransformedRequestEntity(RequestEntity requestEntity) throws DocumentManagerException,
        AttributeListParseException {
      RetrieveDocumentumRequestEntity retrieveRequestEntity = (RetrieveDocumentumRequestEntity) requestEntity;
      List requiredAttributes = retrieveRequestEntity.getRequiredAttributes();
      if (!requiredAttributes.get(0).equals(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT) ||
          !requiredAttributes.get(1).equals(DocumentManagerConstants.DCTM_ATTR_STR_KEYWORDS) ||
          !requiredAttributes.get(2).equals(DocumentManagerConstants.DCTM_ATTR_STR_CREATOR) ||
          !requiredAttributes.get(3).equals(DocumentManagerConstants.DCTM_ATTR_STR_SIZE) ||
          !requiredAttributes.get(4).equals(DocumentManagerConstants.ATTR_STR_TITLE)
          ) {
        throw new DocumentManagerException("Required Attributes not parsed correctly");
      }
      if (!retrieveRequestEntity.getDocumentAttributes()
          .getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID).equals(TEST_DOC_ID)
          ) {
        throw new DocumentManagerException("Query Attribute not parsed correctly");
      }
      validateFormatAttributePresentInRequest(retrieveRequestEntity);
    }

    private void validateFormatAttributePresentInRequest(RetrieveDocumentumRequestEntity retrieveRequestEntity) throws
        AttributeListParseException, DocumentManagerException {
      if (!retrieveRequestEntity.getDocumentAttributes().getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_FORMAT)
          .equals(TEST_REQUIRED_FORMAT)
          ) {
        throw new DocumentManagerException("Format Attribute not parsed correctly");
      }
    }

    private void validateConnectionParams(RequestEntity requestEntity) throws DocumentManagerException,
        AttributeListParseException {
      RetrieveDocumentumRequestEntity retrieveRequestEntity = (RetrieveDocumentumRequestEntity) requestEntity;
      ConnectionInfo connectionInfo = retrieveRequestEntity.getConnectionInfo();
      if (!retrieveRequestEntity.getFolderName().equalsIgnoreCase("posTestFolder") ||
          !retrieveRequestEntity.getDirectoryStructure().equalsIgnoreCase("testDir1/testDir2") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_CABINET)
              .equalsIgnoreCase("/POS Test") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_USERNAME)
              .equalsIgnoreCase("devl30") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_PASSWORD)
              .equalsIgnoreCase("devl30") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_OBJECT_TYPE)
              .equalsIgnoreCase("dm_document")
          ) {
        throw new DocumentManagerException("Connection/Configuration params not parsed correctly");
      }
    }

    private void sendMockResponse(ResponseEntity responseEntity, RetrievedDocument retrievedDocument) {
      responseEntity.getRetrievedDocumentList().add(retrievedDocument);
    }
  }
}