package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.retrieveService.tests;

import com.monsanto.POSClient.InvalidMimeTypeException;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.POSClient.POSMIMEConstants;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.Util.FileUtil;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.retrieveService.RetrieveDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.TestUtil;
import org.apache.xerces.impl.dv.util.Base64;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jun 9, 2006
 * Time: 9:37:03 AM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveWithVersion_UT extends XMLTestCase {
  public static final String INSERT_VERSION = "1.0";
  public static final String UPDATE_VERSION = "2.0";
  private static final String INSERT_REQUEST_XML = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/retrieveService/tests/insertRequest.xml";
  private static final String CONTENTS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private static final String UPDATE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/retrieveService/tests/updateRequest.xml";
  private static final String UPDATED_CONTENTS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/test.doc";
  private String objectId;
  public static final String RETRIEVE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/retrieveService/tests/retrieveRequest.xml";
  public static final String RETRIEVE_REQUEST_WITH_VERSION_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/retrieveService/tests/retrieveRequestWithVersion.xml";
  public static final String RETRIEVE_REQUEST_WITH_INVALID_VERSION_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/retrieveService/tests/retrieveRequestWithInvalidVersion.xml";
  public static final String RETRIEVE_REQUEST_XML = "C:/retrieveReq.xml";
  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";
  private static final String DOC_NAME = "RetrieveVersionTestFile";
  private static final String DOC_TITLE = "monsanto search docs";
  private static final String UPDATED_DOC_TITLE = "newTitle";
  private static final String DOC_SUBJECT = "farm resource";
  public static final String RETRIEVE_WITH_VERSION_TEMP_FILE = "C:/testRetrieveWithVersion.doc";

  protected void setUp() throws IOException, InvalidMimeTypeException, ParserException, GSSException, TransformerException, SAXException, POSCommunicationException, POSException {
    objectId = TestUtil.insertTestDocument(CONTENTS, POSMIMEConstants.MIME_TYPE_TEXT, INSERT_REQUEST_XML);
    String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document updateReq = TestUtil.transformRequestXML(UPDATE_REQUEST_TEMPLATE, objectId, updateTransformationXPathString, 0);
    TestUtil.updateDocument(UPDATED_CONTENTS, updateReq, POSMIMEConstants.MIME_TYPE_MSWORD);
  }

  protected void tearDown() throws Exception {
    if (objectId != null && objectId.length() > 0) {
      TestUtil.deleteAllVersionsOfInsertedDocument(objectId);
    }
    deleteTempFileFromLocalSystem(RETRIEVE_REQUEST_XML);
    deleteTempFileFromLocalSystem(RETRIEVE_WITH_VERSION_TEMP_FILE);
  }

  public void testRetrieveRequestWithoutVersion_ReturnsCurrentVersion() throws Exception {
    RetrieveDocumentPOS retrieveDocumentPOS = new MockRetrieveDocumentPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    String xpathString = "/inputPos/command/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute/value";
    Document retrieveReq = TestUtil.transformRequestXML(RETRIEVE_REQUEST_TEMPLATE, objectId, xpathString, 0);
    saveAsXMLFile(retrieveReq, RETRIEVE_REQUEST_XML);
    mockUCCHelper.addClientFile(RETRIEVE_REQUEST_XML);
    retrieveDocumentPOS.run(mockUCCHelper);
    Document retrieveReponseDoc = DOMUtil.newDocument(mockUCCHelper.getInputStream(""));
    validateContentsOfExpectedVersion(retrieveReponseDoc, UPDATED_CONTENTS);
    validateResponseOfExpectedVersion(retrieveReponseDoc, UPDATED_DOC_TITLE, DOC_SUBJECT, "2.0");
  }

  public void testRetrieveRequestWithVersion_ReturnsRequiredVersion() throws Exception {
    RetrieveDocumentPOS retrieveDocumentPOS = new MockRetrieveDocumentPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    String xpathString = "/inputPos/command/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute/value";
    Document retrieveReq = TestUtil.transformRequestXML(RETRIEVE_REQUEST_WITH_VERSION_TEMPLATE, objectId, xpathString, 0);
    saveAsXMLFile(retrieveReq, RETRIEVE_REQUEST_XML);
    mockUCCHelper.addClientFile(RETRIEVE_REQUEST_XML);
    retrieveDocumentPOS.run(mockUCCHelper);
    Document retrieveReponseDoc = DOMUtil.newDocument(mockUCCHelper.getInputStream(""));
    validateContentsOfExpectedVersion(retrieveReponseDoc, CONTENTS);
    validateResponseOfExpectedVersion(retrieveReponseDoc, DOC_TITLE, DOC_SUBJECT, "1.0");
  }

  public void testRetrieveRequestWithInvalidVersion_ThrowsException() throws Exception {
    RetrieveDocumentPOS retrieveDocumentPOS = new MockRetrieveDocumentPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    String xpathString = "/inputPos/command/retrieveDocumentRequest/requestDetails/retrieveDocument/queryAttributes/attribute/value";
    Document retrieveReq = TestUtil.transformRequestXML(RETRIEVE_REQUEST_WITH_INVALID_VERSION_TEMPLATE, objectId, xpathString, 0);
    saveAsXMLFile(retrieveReq, RETRIEVE_REQUEST_XML);
    mockUCCHelper.addClientFile(RETRIEVE_REQUEST_XML);
    retrieveDocumentPOS.run(mockUCCHelper);
    assertXpathExists("/ERROR/ERROR_MESSAGE", mockUCCHelper.getXML());
  }

  private void validateContentsOfExpectedVersion(Document retrieveReponseDoc, String contentsToCompareWith) throws IOException, TransformerException {
    String pathToRetrievedFile = getRetrievedDocumentContents(retrieveReponseDoc);
    assertTrue(FileUtil.compareFiles(contentsToCompareWith, pathToRetrievedFile));
  }

  private String getRetrievedDocumentContents(Document retrieveReponseDoc) throws IOException, TransformerException {
    String xpathStr = "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name='" + DocumentManagerConstants.ATTR_STR_CONTENTS + "']/value";
    assertXpathExists(xpathStr, retrieveReponseDoc);
    String encodedContents = XPathAPI.eval(retrieveReponseDoc, xpathStr).toString();
    byte decodedByte[] = Base64.decode(encodedContents);
    String filePath = RETRIEVE_WITH_VERSION_TEMP_FILE;
    FileOutputStream foStream = new FileOutputStream(filePath);
    foStream.write(decodedByte, 0, decodedByte.length);
    foStream.flush();
    foStream.close();
    return filePath;
  }

  private void deleteTempFileFromLocalSystem(String fileName) {
    new File(fileName).delete();
  }

  private void validateResponseOfExpectedVersion(Document responseDocument, String titleValue, String subjectValue, String versionLabel) throws TransformerException {
    validateAttribute(responseDocument, DocumentManagerConstants.ATTR_STR_NAME, DOC_NAME);
    validateAttribute(responseDocument, DocumentManagerConstants.ATTR_STR_TITLE, titleValue);
    validateAttribute(responseDocument, DocumentManagerConstants.ATTR_STR_SUBJECT, subjectValue);
    validateAttribute(responseDocument, DocumentManagerConstants.ATTR_STR_VERSION, versionLabel);
  }

  private void validateAttribute(Document responseDocument, String attrName, String attrValue) throws TransformerException {
    assertXpathEvaluatesTo(attrValue, "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name='" + attrName + "']/value", responseDocument);
  }

  private void saveAsXMLFile(Document requestDoc, String requestFileName) throws FileNotFoundException {
    DOMUtil.outputXML(requestDoc, new FileOutputStream(new File(requestFileName)));
  }

  class MockRetrieveDocumentPOS extends RetrieveDocumentPOS {

    protected ServiceLookup instantiateServiceLookup() throws ServiceConfigException {
      return new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    }
  }
}