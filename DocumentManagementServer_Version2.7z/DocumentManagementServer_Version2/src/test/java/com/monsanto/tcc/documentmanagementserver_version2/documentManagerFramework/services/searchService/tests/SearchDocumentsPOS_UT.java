package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.searchService.tests;

import com.monsanto.POSClient.InvalidMimeTypeException;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.*;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.searchService.SearchDocumentsPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.testUtil.TestUtil;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: May 10, 2006 Time: 9:10:29 AM To change this template use File |
 * Settings | File Templates.
 */
public class SearchDocumentsPOS_UT extends XMLTestCase {
  private static final String SEARCH_REQUEST_XML = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/searchService/tests/searchRequest.xml";
  private static final String SEARCH_REQUEST_ALL_VERSIONS = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/searchService/tests/searchRequestAllVersions.xml";
  private static final String TEST_DOC_ID = "1234";
  private static final String TEST_DOC_NAME = "testName.doc";
  private static final String TEST_DOC_SUBJECT = "testSubject";
  private static final String TEST_DOC_TITLE = "testTitle";
  private static final String TEST_DOC_CREATOR = "testCreator";
  private static final String TEST_DOC_SIZE = "99";
  private static final String TITLE_ATTR_OPERATOR = "equals";
  private static final String TEST_PAGE_COUNT = "3";
  private static final String PAGE_CNT_ATTR_OPERATOR = "equals";
  private static final String AUTHOR_ATTR_OPERATOR = "equals";
  private static final String TEST_AUTHOR = "admin";
  private static List TEST_KEYWORDS;

  static {
    TEST_KEYWORDS = new ArrayList();
    TEST_KEYWORDS.add("farm");
    TEST_KEYWORDS.add("crop");
    TEST_KEYWORDS.add("field");
  }

  private String objectId1;
  private String objectId2;
  private static final String INSERT_REQUEST_1_XML = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/searchService/tests/insertRequest1.xml";
  private static final String UPDATE_REQUEST_1_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/searchService/tests/updateRequest1.xml";
  private static final String INSERT_REQUEST_2_XML = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/searchService/tests/insertRequest2.xml";
  private static final String UPDATE_REQUEST_2_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/searchService/tests/updateRequest2.xml";
  private int totalNumberOfDocuments = 0;
  private int numberOfCurrentDocuments = 0;

  protected void setUp() throws IOException, ParserException, TransformerException, GSSException,
      InvalidMimeTypeException, POSCommunicationException, POSException, SAXException {
    objectId1 = TestUtil.deleteExistingDocumentIdAndInsert(INSERT_REQUEST_1_XML, UPDATE_REQUEST_1_TEMPLATE);
    objectId2 = TestUtil.insertUpdateDocument(INSERT_REQUEST_2_XML, UPDATE_REQUEST_2_TEMPLATE);
  }


  protected void tearDown() throws Exception {
    deleteAllVersions(objectId1);
    deleteAllVersions(objectId2);
  }

  public void testRunImplementationForSearchService() throws Exception {
    SearchDocumentsPOS searchDocumentsPOS = new MockSearchDocumentsPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(SEARCH_REQUEST_XML);
    searchDocumentsPOS.run(mockUCCHelper);
    Document searchReponseDoc1 = mockUCCHelper.getXML();
    validateResponseContainsNoError(searchReponseDoc1);
    validateResponse(searchReponseDoc1);
  }


  public void testSearchService_WithoutSpecifying_SearchAllVersions_ReturnsResultFromCurrentVersions() throws
      Exception {
    Document searchReponseDoc = searchDocument();
    validateResponseContainsNoError(searchReponseDoc);
    validateResponseWithVersions(searchReponseDoc);
    assertEquals(2, numberOfCurrentDocuments);
    assertEquals(2, totalNumberOfDocuments);
  }

  private Document searchDocument() throws IOException {
    SearchDocumentsPOS searchDocumentsPOS = new SearchDocumentsPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(TestUtil.SEARCH_REQUEST_CURRENT_VERSIONS);
    searchDocumentsPOS.run(mockUCCHelper);
		return mockUCCHelper.getXML();
  }

  public void testSearchService_SearchAllVersions_ReturnsResultFromAllVersions() throws Exception {
    SearchDocumentsPOS searchDocumentsPOS = new SearchDocumentsPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(SEARCH_REQUEST_ALL_VERSIONS);
    searchDocumentsPOS.run(mockUCCHelper);
    Document searchReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsNoError(searchReponseDoc);
    validateResponseWithVersions(searchReponseDoc);
    assertEquals(2, numberOfCurrentDocuments);
    assertEquals(4, totalNumberOfDocuments);
  }

  private void deleteAllVersions(String objectId) throws ParserException, POSCommunicationException, POSException,
      TransformerException, GSSException {
    if (objectId != null && objectId.length() > 0) {
      TestUtil.deleteAllVersionsOfInsertedDocument(objectId);
    }
  }

  private void validateResponseContainsNoError(Document searchReponseDoc) throws TransformerException {
    String errorMessage = XPathAPI.eval(searchReponseDoc, "/ERROR/ERROR_MESSAGE").toString();
    assertTrue("POS exception thrown = " + errorMessage, StringUtils.isNullOrEmpty(errorMessage));
  }

  private void validateResponse(Document searchReponseDoc) throws TransformerException {
    assertXpathEvaluatesTo(TEST_DOC_ID,
        TestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + TestUtil.XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_NAME, TestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_NAME + TestUtil.XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_SUBJECT,
        TestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_SUBJECT + TestUtil.XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_TITLE, TestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_TITLE + TestUtil.XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_CREATOR,
        TestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_CREATOR + TestUtil.XPATH_END_STR,
        searchReponseDoc);
    assertXpathEvaluatesTo(TEST_DOC_SIZE, TestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_SIZE + TestUtil.XPATH_END_STR,
        searchReponseDoc);
    for (int i = 0; i < TEST_KEYWORDS.size(); i++) {
      String expestedKeyword = (String) TEST_KEYWORDS.get(i);
      assertXpathEvaluatesTo(expestedKeyword, TestUtil.XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_KEYWORDS
          + TestUtil.XPATH_END_STR + "[" + (i + 1) + "]", searchReponseDoc);
    }
  }

  private void validateResponseWithVersions(Document searchReponseDoc) throws TransformerException {
    totalNumberOfDocuments = 0;
    numberOfCurrentDocuments = 0;
    NodeList documentDetailsNode = XPathAPI
        .eval(searchReponseDoc, "/documentManagerResponse/searchDocuments/documentDetails").nodelist();
    int length = documentDetailsNode.getLength();
    for (int i = 0; i < length; i++) {
      Node documentNode = documentDetailsNode.item(i);
      String objectId = XPathAPI
          .eval(documentNode, "attribute[name='" + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value")
          .toString();
      String version = XPathAPI
          .eval(documentNode, "attribute[name='" + DocumentManagerConstants.ATTR_STR_VERSION + "']/value").toString();
      String title = XPathAPI
          .eval(documentNode, "attribute[name='" + DocumentManagerConstants.ATTR_STR_TITLE + "']/value").toString();
      if (objectId.equalsIgnoreCase(objectId1)) {
        if (version.equalsIgnoreCase("1.0")) {
          assertEquals("File1_version1", title);
          totalNumberOfDocuments++;
        } else {
          assertEquals("File1_version2", title);
          totalNumberOfDocuments++;
          numberOfCurrentDocuments++;
        }
      }
      if (objectId.equalsIgnoreCase(objectId2)) {
        if (version.equalsIgnoreCase("1.0")) {
          assertEquals("File2_version1", title);
          totalNumberOfDocuments++;
        } else {
          assertEquals("File2_version2", title);
          totalNumberOfDocuments++;
          numberOfCurrentDocuments++;
        }
      }
    }
  }

  class MockSearchDocumentsPOS extends SearchDocumentsPOS {

    public void performOperation(RequestEntity requestEntity, DocumentService service, ResponseEntity responseEntity,
                                 UCCHelper helper) throws DocumentManagerException {
      try {
        validateConnectionParams(requestEntity);
      } catch (AttributeListParseException e) {
        throw new DocumentManagerException(e);
      }
      try {
        validateTransformedRequestEntity(requestEntity);
      } catch (AttributeListParseException e) {
        throw new DocumentManagerException(e);
      }
      RetrievedDocument retrievedDocument = buildMockRetrievedDocument();
      sendMockResponse(responseEntity, retrievedDocument);
    }

    private RetrievedDocument buildMockRetrievedDocument() {
      RetrievedDocument retrievedDocument = new RetrievedDocument();
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, TEST_DOC_ID, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_NAME, TEST_DOC_NAME, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT, TEST_DOC_SUBJECT, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, TEST_KEYWORDS, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_CREATOR, TEST_DOC_CREATOR, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_SIZE, TEST_DOC_SIZE, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TEST_DOC_TITLE, null);
      return retrievedDocument;
    }

    private void validateTransformedRequestEntity(RequestEntity requestEntity) throws DocumentManagerException,
        AttributeListParseException {
      SearchDocumentumRequestEntity searchRequestEntity = (SearchDocumentumRequestEntity) requestEntity;
      List requiredAttributes = searchRequestEntity.getRequiredAttributes();
      if (!requiredAttributes.get(0).equals(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT) ||
          !requiredAttributes.get(1).equals(DocumentManagerConstants.DCTM_ATTR_STR_KEYWORDS) ||
          !requiredAttributes.get(2).equals(DocumentManagerConstants.DCTM_ATTR_STR_CREATOR) ||
          !requiredAttributes.get(3).equals(DocumentManagerConstants.DCTM_ATTR_STR_SIZE) ||
          !requiredAttributes.get(4).equals(DocumentManagerConstants.ATTR_STR_TITLE)
          ) {
        throw new DocumentManagerException("Required Attributes not parsed correctly");
      }
      if (validateQueryAttribute(searchRequestEntity, DocumentManagerConstants.ATTR_STR_TITLE, TEST_DOC_TITLE,
          TITLE_ATTR_OPERATOR)
          && validateQueryAttribute(searchRequestEntity, DocumentManagerConstants.ATTR_STR_PAGE_COUNT, TEST_PAGE_COUNT,
          PAGE_CNT_ATTR_OPERATOR)
          && validateQueryAttribute(searchRequestEntity, DocumentManagerConstants.ATTR_STR_AUTHORS, TEST_AUTHOR,
          AUTHOR_ATTR_OPERATOR)
          ) {
        throw new DocumentManagerException("Query Attribute not parsed correctly");
      }
    }

    private boolean validateQueryAttribute(SearchDocumentumRequestEntity searchRequestEntity, String attrName,
                                           String attrValue, String attrOperator) throws AttributeListParseException {
      return !searchRequestEntity.getDocumentAttributes().getAttrValue(attrName).equals(attrValue)
          || !searchRequestEntity.getDocumentAttributes().getOperator(attrName).equals(attrOperator);
    }

    private void validateConnectionParams(RequestEntity requestEntity) throws DocumentManagerException,
        AttributeListParseException {
      SearchDocumentumRequestEntity searchRequestEntity = (SearchDocumentumRequestEntity) requestEntity;
      ConnectionInfo connectionInfo = searchRequestEntity.getConnectionInfo();
      if (!searchRequestEntity.getFolderName().equalsIgnoreCase("posTestFolder") ||
          !searchRequestEntity.getDirectoryStructure().equalsIgnoreCase("testDir1/testDir2") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_CABINET)
              .equalsIgnoreCase("/POS Test") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_USERNAME)
              .equalsIgnoreCase("devl30") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_OBJECT_TYPE)
              .equalsIgnoreCase("dm_document")
          ) {
        throw new DocumentManagerException("Connection/Configuration params not parsed correctly");
      }
    }

    private void sendMockResponse(ResponseEntity responseEntity, RetrievedDocument retrievedDocument) {
      responseEntity.getRetrievedDocumentList().add(retrievedDocument);
    }
  }
}