package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.searchService.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.searchService.SearchDocumentsPOS;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.transform.TransformerException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jun 16, 2006
 * Time: 2:23:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class SearchFullText_UT extends XMLTestCase {

  private static final String SEARCH_REQUEST_FULL_TEXT_SINGLE_WORD = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/searchService/tests/searchRequestForFullText.xml";
  private static final String SEARCH_REQUEST_FULL_TEXT_MULTIPE_WORD = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/searchService/tests/searchRequestForFullTextMultipleWords.xml";
  private static final String SEARCH_REQUEST_FULL_TEXT_WORDS_AND_SEARCH_ATTR = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/searchService/tests/searchRequestForFullTextMultipleWordsAndSearchAttr.xml";

  private static String FULL_TEXT_SEARCH_FILE_1 = "fullTextFile1.txt";
  private static String FULL_TEXT_SEARCH_FILE_2 = "fullTextFile2.doc";
  private static String FULL_TEXT_SEARCH_FILE_3 = "fullTextFile3.txt";
  private static String FULL_TEXT_SEARCH_FILE_4 = "fullTextFile4.doc";

  private int validSingleWordDocuments;
  private int validMultipleWordDocuments;
  private int validMultipleWordAndKeywordDocuments;

  public void testFullTextFunctionality_SingleWord() throws Exception {
//    SearchDocumentsPOS searchDocumentsPOS = new SearchDocumentsPOS();
//    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
//    mockUCCHelper.addClientFile(SEARCH_REQUEST_FULL_TEXT_SINGLE_WORD);
//    searchDocumentsPOS.run(mockUCCHelper);
//    Document searchReponseDoc = mockUCCHelper.getXML();
//    validateResponseContainsNoError(searchReponseDoc);
//    assertEquals(2, getNumberOfDocuments(searchReponseDoc));
//    validateResponse(searchReponseDoc);
//    assertEquals(2, validSingleWordDocuments);
      assertTrue(true);
  }

//  public void testFullTextFunctionality_MultipleWords() throws Exception {
//    SearchDocumentsPOS searchDocumentsPOS = new SearchDocumentsPOS();
//    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
//    mockUCCHelper.addClientFile(SEARCH_REQUEST_FULL_TEXT_MULTIPE_WORD);
//    searchDocumentsPOS.run(mockUCCHelper);
//    Document searchReponseDoc = mockUCCHelper.getXML();
//    validateResponseContainsNoError(searchReponseDoc);
//    assertEquals(3, getNumberOfDocuments(searchReponseDoc));
//    validateResponse(searchReponseDoc);
//    assertEquals(3, validMultipleWordDocuments);
//  }

//  public void testFullTextFunctionality_MultipleWords_AndSearchAttribute_Keyword() throws Exception {
//    SearchDocumentsPOS searchDocumentsPOS = new SearchDocumentsPOS();
//    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
//    mockUCCHelper.addClientFile(SEARCH_REQUEST_FULL_TEXT_WORDS_AND_SEARCH_ATTR);
//    searchDocumentsPOS.run(mockUCCHelper);
//    Document searchReponseDoc = mockUCCHelper.getXML();
//    validateResponseContainsNoError(searchReponseDoc);
//    assertEquals(2, getNumberOfDocuments(searchReponseDoc));
//    validateResponse(searchReponseDoc);
//    assertEquals(2, validMultipleWordAndKeywordDocuments);
//  }

  private int getNumberOfDocuments(Document searchReponseDoc) throws TransformerException {
    return XPathAPI.eval(searchReponseDoc, "/documentManagerResponse/searchDocuments/documentDetails").nodelist().getLength();
  }

  private void validateResponseContainsNoError(Document searchReponseDoc) throws TransformerException {
    String errorMessage = XPathAPI.eval(searchReponseDoc, "/ERROR/ERROR_MESSAGE").toString();
    assertTrue("POS exception thrown = " + errorMessage, StringUtils.isNullOrEmpty(errorMessage));
  }

  private void validateResponse(Document searchReponseDoc) throws TransformerException {
    validSingleWordDocuments = 0;
    validMultipleWordDocuments = 0;
    validMultipleWordAndKeywordDocuments = 0;
    NodeList documentDetailsNode = XPathAPI.eval(searchReponseDoc, "/documentManagerResponse/searchDocuments/documentDetails").nodelist();
    int length = documentDetailsNode.getLength();
    for (int i = 0; i < length; i++) {
      Node documentNode = documentDetailsNode.item(i);
      String name = XPathAPI.eval(documentNode, "attribute[name='"+ DocumentManagerConstants.ATTR_STR_NAME + "']/value").toString();
      if(name.equalsIgnoreCase(FULL_TEXT_SEARCH_FILE_1)){
        validSingleWordDocuments++;
        validMultipleWordDocuments++;
      }
      if(name.equalsIgnoreCase(FULL_TEXT_SEARCH_FILE_2)){
        validMultipleWordDocuments++;
        validMultipleWordAndKeywordDocuments++;
      }
      if(name.equalsIgnoreCase(FULL_TEXT_SEARCH_FILE_3)){
        validMultipleWordDocuments++;
        validMultipleWordAndKeywordDocuments++;
      }
      if(name.equalsIgnoreCase(FULL_TEXT_SEARCH_FILE_4)){
        validSingleWordDocuments++;
      }
    }
  }
}