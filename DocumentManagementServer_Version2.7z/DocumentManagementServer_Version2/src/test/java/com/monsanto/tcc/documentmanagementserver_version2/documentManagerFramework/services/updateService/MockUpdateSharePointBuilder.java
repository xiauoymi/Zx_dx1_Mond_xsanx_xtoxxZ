package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.updateService;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updatesharepointdocs.tests.MockUpdateSharePointRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updateSharePointDoc.builder.UpdateSharePointBuilder;

/**
 * Created by IntelliJ IDEA.
* User: mecoru
* Date: May 21, 2010
* Time: 1:10:10 PM
* To change this template use File | Settings | File Templates.
*/
public class MockUpdateSharePointBuilder extends UpdateSharePointBuilder {
	public void buildParser() {
		setRequestParser(new MockUpdateSharePointRequestParser());
	}
}