package com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.updateService.tests;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockXMLPOSConnectionForInsert;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.*;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.updateService.UpdateDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumRequestEntity;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jun 2, 2006 Time: 11:19:13 AM To change this template use File |
 * Settings | File Templates.
 */
public class UpdateDocumentPOS_UT extends XMLTestCase {
  private static final String UPDATE_REQUEST_XML_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/updateService/tests/updateRequest.xml";
  private static final String UPDATE_REQUEST_WITH_ATTR_AND_CONTENTS_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/updateService/tests/updateRequestWithAttrAndContents.xml";
  private static final String UPDATE_REQUEST_SAME_VERSION_ATTR_AND_CONTENTS_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/updateService/tests/updateRequestSameVersion.xml";
  private static final String UPDATE_REQUEST_WITH_INVALID_VERSION_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/updateService/tests/updateRequestWithInvalidUpdateVersion.xml";
  private static final String UPDATE_REQUEST_WITH_NO_OBJECT_ID = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/updateService/tests/updateRequestWithNoObjectId.xml";
  private static final String UPDATE_REQUEST_XML_WITH_UNDEFINED_REPOSITORY = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/updateService/tests/updateRequestWithUndefinedRepository.xml";
  private static final String UPDATE_REQUEST_XML = "C:/updateRequest.xml";
  private static final String XPATH_BEGIN_STR = "/documentManagerResponse/documentUpdatedSuccessfully/documentDetails/attribute[name = '";
  private static final String XPATH_END_STR = "']/value";
  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";
  private static final String TEST_DOC_ID = "1234";
  private static final String NEW_MINOR_VERSION = "1.1";
  private static final String NEW_MAJOR_VERSION = "2.0";
  private static final String NEW_CONTENTS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile2.txt";
  private static final String NEW_CONTENTS_OF_DIFFERENT_FORMAT = "com/monsanto/tcc/documentmanagementserver_version2/apptests/test.doc";
  private static final String TEST_DOC_TITLE = "testTitle";
  private static final String SAME_VERSION = "1.0";
  private static List TEST_KEYWORDS;

  static {
    TEST_KEYWORDS = new ArrayList();
    TEST_KEYWORDS.add("documents");
    TEST_KEYWORDS.add("files");
  }

  private String objectId;
  private static final String ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private static final String INSERT_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/apptests/insertReq1.xml";
  private static final String POS_INSERT_SERVICE_NAME = "InsertDocumentService";

  private static final String POS_DELETE_SERVICE_NAME = "DeleteDocumentService";
  private static final String TEST_DELETE_REQUEST_XML = "com/monsanto/tcc/documentmanagementserver_version2/apptests/deleteRequest.xml";
  private static final String DELETE_REQUEST_XML = "C:/deleteRequestDoc.xml";

  protected void setUp() throws IOException, ParserException, GSSException, TransformerException,
      InvalidMimeTypeException, SAXException, POSCommunicationException, POSException {
    objectId = insertNewDocument(ATTACHMENT_1, POSMIMEConstants.MIME_TYPE_TEXT, INSERT_XML_1);
  }

  protected void tearDown() throws Exception {
    if (!StringUtils.isNullOrEmpty(objectId)) {
      deleteByChronicleId_AllVersions(objectId);
    }
    deleteLocalTempFile();
  }

  private void deleteLocalTempFile() {
    new File(DELETE_REQUEST_XML).delete();
    new File(UPDATE_REQUEST_XML).delete();
  }

  public void testRunImplementationForUpdateService_WithUndefinedRepository_ThrowsException() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML_WITH_UNDEFINED_REPOSITORY);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsError(updateReponseDoc);
  }

  public void testFrameworkSetupForUpdateService() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML_TEMPLATE);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsNoError(updateReponseDoc);
    validateResponse(updateReponseDoc, TEST_DOC_ID, NEW_MINOR_VERSION);
  }

  public void testUpdateService_MinorVersion_WithNewAttrs_WithoutContents() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    createTestUpdateRequestXML(UPDATE_REQUEST_XML, objectId, UPDATE_REQUEST_XML_TEMPLATE);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsNoError(updateReponseDoc);
    validateResponse(updateReponseDoc, objectId, NEW_MINOR_VERSION);
  }

  public void testUpdateService_MajorVersion_WithAttrAndContents() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    createTestUpdateRequestXML(UPDATE_REQUEST_XML, objectId, UPDATE_REQUEST_WITH_ATTR_AND_CONTENTS_TEMPLATE);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML);
    mockUCCHelper.addClientFile(NEW_CONTENTS);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsNoError(updateReponseDoc);
    validateResponse(updateReponseDoc, objectId, NEW_MAJOR_VERSION);
  }

  public void testUpdateService_SameVersion_WithAttrAndContents() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    createTestUpdateRequestXML(UPDATE_REQUEST_XML, objectId, UPDATE_REQUEST_SAME_VERSION_ATTR_AND_CONTENTS_TEMPLATE);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML);
    mockUCCHelper.addClientFile(NEW_CONTENTS);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsNoError(updateReponseDoc);
    validateResponse(updateReponseDoc, objectId, SAME_VERSION);
  }

  public void testUpdateService_MajorVersion_WithAttr_And_Contents_Of_DifferentFormat() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    createTestUpdateRequestXML(UPDATE_REQUEST_XML, objectId, UPDATE_REQUEST_WITH_ATTR_AND_CONTENTS_TEMPLATE);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML);
    mockUCCHelper.addClientFile(NEW_CONTENTS_OF_DIFFERENT_FORMAT);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsNoError(updateReponseDoc);
    validateResponse(updateReponseDoc, objectId, NEW_MAJOR_VERSION);
  }

  public void testUpdateService_WithInvalidUpdateVersionSpecification_PerformsCancelCheckout_ThrowsException() throws
      Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    createTestUpdateRequestXML(UPDATE_REQUEST_XML, objectId, UPDATE_REQUEST_WITH_INVALID_VERSION_TEMPLATE);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    validateResponseContainsError(updateReponseDoc);
  }

  public void testUpdateService_WithInvalidObjectIdSpecification_ThrowsException() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_XML_TEMPLATE);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    DOMUtil.outputXML(updateReponseDoc);
    validateResponseContainsError(updateReponseDoc);
  }

  public void testUpdateService_WithNoObjectId_ThrowsException() throws Exception {
    UpdateDocumentPOS updateDocumentPOS = new MockUpdateDocumentPOSWithTestServiceConfig();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(UPDATE_REQUEST_WITH_NO_OBJECT_ID);
    updateDocumentPOS.run(mockUCCHelper);
    Document updateReponseDoc = mockUCCHelper.getXML();
    DOMUtil.outputXML(updateReponseDoc);
    validateResponseContainsError(updateReponseDoc);
  }

  private void deleteByChronicleId_AllVersions(String objectId) throws ParserException, FileNotFoundException,
      TransformerException, POSCommunicationException, POSException, GSSException {
    createTestDeleteRequestXML(DELETE_REQUEST_XML, objectId);
    Document inputDoc = DOMUtil.newDocument(DELETE_REQUEST_XML);
    SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    posConn.callService(POS_DELETE_SERVICE_NAME, inputDoc);
  }

  private void createTestDeleteRequestXML(String deleteRequestFilenamePath, String objectId) throws
      FileNotFoundException, ParserException, TransformerException {
    Document deleteRequestDoc = DOMUtil.newDocument(TEST_DELETE_REQUEST_XML);
    Node objectIdValueNode = XPathAPI
        .eval(deleteRequestDoc, "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    saveAsXMLFile(deleteRequestDoc, deleteRequestFilenamePath);
  }

  private void createTestUpdateRequestXML(String updateRequestFilenamePath, String objectId,
                                          String updateRequestTemplate) throws FileNotFoundException, ParserException,
      TransformerException {
    Document updateRequestDoc = DOMUtil.newDocument(updateRequestTemplate);
    Node objectIdValueNode = XPathAPI.eval(updateRequestDoc,
        "/inputPos/command/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value")
        .nodelist().item(0);
    Node newObjectIdValueNode = updateRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    saveAsXMLFile(updateRequestDoc, updateRequestFilenamePath);
  }

  private void saveAsXMLFile(Document updateRequestDoc, String deleteRequestFilenamePath) throws FileNotFoundException {
    DOMUtil.outputXML(updateRequestDoc, new FileOutputStream(new File(deleteRequestFilenamePath)));
  }

  private String insertNewDocument(String fileAttachment, String mimeType, String insertRequestXml) throws
      TransformerException, ParserException, GSSException, IOException, SAXException, POSCommunicationException,
      POSException, InvalidMimeTypeException {
    MultipartAttachmentList attachmentList = new MultipartAttachmentList();
    addAttachment(attachmentList, fileAttachment, mimeType);
    Document responseDoc = insertDocument(attachmentList, insertRequestXml);
    return getObjectIdOfInsertedDocument(responseDoc);
  }

  private String getObjectIdOfInsertedDocument(Document responseDoc) throws TransformerException {
    String expression = "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" +
        DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value";
    Object objId = XPathAPI.eval(responseDoc, expression);
    return objId.toString();
  }

  private void addAttachment(MultipartAttachmentList attachmentList, String fileName, String mimeType) throws
      InvalidMimeTypeException {
    MultiPartFormAttachment attachment = new MultiPartFormAttachment(fileName, mimeType);
    attachmentList.addAttachment(attachment);
  }

  private Document insertDocument(MultipartAttachmentList attachmentList, String requestXmlDocument) throws
      ParserException, POSException, POSCommunicationException, IOException, SAXException, GSSException {
    Document inputDoc = DOMUtil.newDocument(requestXmlDocument);
    SecureXMLPOSConnection posConn = new MockXMLPOSConnectionForInsert(
        new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    addAttachmentToConnection(attachmentList, posConn);
    POSResult result = posConn.callService(POS_INSERT_SERVICE_NAME, inputDoc);
    return DOMUtil.newDocument(result.getInputStream());
  }

  private void addAttachmentToConnection(MultipartAttachmentList attachmentList, XMLPOSConnection posConn) {
    int numberOfAttachments = attachmentList.getLength();
    for (int i = 0; i < numberOfAttachments; i++) {
      MultiPartFormAttachment attachment = attachmentList.getAttachment(i);
      posConn.addAttachment(attachment);
    }
  }

  private void validateResponseContainsNoError(Document updateResponseDoc) throws TransformerException {
    String errorMessage = XPathAPI.eval(updateResponseDoc, "/ERROR/ERROR_MESSAGE").toString();
    assertTrue("POS exception thrown = " + errorMessage, StringUtils.isNullOrEmpty(errorMessage));
  }

  private void validateResponseContainsError(Document updateResponseDoc) throws TransformerException {
    assertXpathExists("/ERROR/ERROR_MESSAGE", updateResponseDoc);
  }

  private void validateResponse(Document updateReponseDoc, String objectId, String version) throws
      TransformerException {
    assertXpathEvaluatesTo(objectId,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR,
        updateReponseDoc);
    assertXpathEvaluatesTo(version, XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_VERSION + XPATH_END_STR,
        updateReponseDoc);
  }

  class MockUpdateDocumentPOSWithTestServiceConfig extends UpdateDocumentPOS {

    protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
      return new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    }
  }

  class MockUpdateDocumentPOS extends MockUpdateDocumentPOSWithTestServiceConfig {

    public void performOperation(RequestEntity requestEntity, DocumentService service, ResponseEntity responseEntity,
                                 UCCHelper helper) throws DocumentManagerException {
      try {
        validateConnectionParams(requestEntity);
      } catch (AttributeListParseException e) {
        throw new DocumentManagerException(e);
      }
      try {
        validateTransformedRequestEntity(requestEntity);
      } catch (AttributeListParseException e) {
        throw new DocumentManagerException(e);
      }
      RetrievedDocument retrievedDocument = buildMockRetrievedDocument();
      sendMockResponse(responseEntity, retrievedDocument);
    }

    private RetrievedDocument buildMockRetrievedDocument() {
      RetrievedDocument retrievedDocument = new RetrievedDocument();
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, TEST_DOC_ID, null);
      retrievedDocument.getDocumentAttributes()
          .addAttribute(DocumentManagerConstants.ATTR_STR_VERSION, NEW_MINOR_VERSION, null);
      return retrievedDocument;
    }

    private void validateTransformedRequestEntity(RequestEntity requestEntity) throws DocumentManagerException,
        AttributeListParseException {
      UpdateDocumentumRequestEntity updateRequestEntity = (UpdateDocumentumRequestEntity) requestEntity;
      if (documentAttributeNotValid(updateRequestEntity, DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID,
          TEST_DOC_ID)
          || documentAttributeNotValid(updateRequestEntity, DocumentManagerConstants.ATTR_STR_TITLE, TEST_DOC_TITLE)
          ||
          multipleValuedDocumentAttributeNotValid(updateRequestEntity, DocumentManagerConstants.DCTM_ATTR_STR_KEYWORDS,
              TEST_KEYWORDS)
          ) {
        throw new DocumentManagerException("Document Attributes not parsed correctly");
      }
    }

    private boolean multipleValuedDocumentAttributeNotValid(UpdateDocumentumRequestEntity updateRequestEntity,
                                                            String attrName, List expectedAttrValues) throws
        AttributeListParseException {
      List actualkeywords = updateRequestEntity.getDocumentAttributes().getAttrValues(attrName);
      for (int i = 0; i < actualkeywords.size(); i++) {
        String keyword = (String) actualkeywords.get(i);
        if (!keyword.equalsIgnoreCase((String) expectedAttrValues.get(i))) {
          return false;
        }
      }
      return false;
    }

    private boolean documentAttributeNotValid(UpdateDocumentumRequestEntity updateRequestEntity, String attrName,
                                              String attrValue) throws AttributeListParseException {
      DocumentAttributes documentAttributes = updateRequestEntity.getDocumentAttributes();
      if (documentAttributes.containsAttribute(attrName)) {
        return !documentAttributes.getAttrValue(attrName).equals(attrValue);
      }
      return true;
    }

    private void validateConnectionParams(RequestEntity requestEntity) throws DocumentManagerException,
        AttributeListParseException {
      UpdateDocumentumRequestEntity updateRequestEntity = (UpdateDocumentumRequestEntity) requestEntity;
      ConnectionInfo connectionInfo = updateRequestEntity.getConnectionInfo();
      if (!updateRequestEntity.getFolderName().equalsIgnoreCase("posTestFolder") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_CABINET)
              .equalsIgnoreCase("/POS Test") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_USERNAME)
              .equalsIgnoreCase("devl30") ||
          !connectionInfo.getConnectionParameterValue(DocumentManagerConstants.STRING_OBJECT_TYPE)
              .equalsIgnoreCase("dm_document")
          ) {
        throw new DocumentManagerException("Connection/Configuration params not parsed correctly");
      }
    }

    private void sendMockResponse(ResponseEntity responseEntity, RetrievedDocument retrievedDocument) {
      responseEntity.getRetrievedDocumentList().add(retrievedDocument);
    }
  }
}