package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.tests;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.DocumentumAttributeType;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.DocumentumAttributeTypeFactory;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.InvalidDctmAttrValueException;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 25, 2006
 * Time: 3:15:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class DctmAttrType_UT extends TestCase {

  public void testQueryAttrValueStringForDQL_TypeString() throws Exception {
    int attrTypeConstant = DocumentManagerConstants.DCTM_TYPE_STRING;
    String baseAttrValue = "testValue";
    DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(attrTypeConstant);
    String dctmStringValue = documentumAttributeType.buildQueryAttributeValue(baseAttrValue);
    assertEquals("'testValue'", dctmStringValue);
  }

  public void testQueryAttrValueStringForDQL_WithSpecialCharacters_ThrowsException() throws Exception {
    try {
      int attrTypeConstant = DocumentManagerConstants.DCTM_TYPE_STRING;
      String baseAttrValue = "testValu'e";
      DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(attrTypeConstant);
      documentumAttributeType.buildQueryAttributeValue(baseAttrValue);
      fail("Query Attr Validation exception not thrown, even though invalid character was present in request");
    } catch (InvalidDctmAttrValueException e) {
      System.out.println("Expected Path, exception = " + e.getMessage());
    }
  }

  public void testQueryAttrValueStringForDQL_TypeUndefined_DefaultsToString() throws Exception {
    int attrTypeConstant = DocumentManagerConstants.DCTM_TYPE_UNDEFINED;
    String baseAttrValue = "testValue";
    DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(attrTypeConstant);
    String dctmStringValue = documentumAttributeType.buildQueryAttributeValue(baseAttrValue);
    assertEquals("'testValue'", dctmStringValue);
  }

  public void testQueryAttrValueStringForDQL_UnknownType_DefaultsToString() throws Exception {
    int attrTypeConstant = 100;
    String baseAttrValue = "testValue";
    DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(attrTypeConstant);
    String dctmStringValue = documentumAttributeType.buildQueryAttributeValue(baseAttrValue);
    assertEquals("'testValue'", dctmStringValue);
  }

  public void testQueryAttrValueStringForDQL_TypeID() throws Exception {
    int attrTypeConstant = DocumentManagerConstants.DCTM_TYPE_ID;
    String baseAttrValue = "testValue";
    DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(attrTypeConstant);
    String dctmStringValue = documentumAttributeType.buildQueryAttributeValue(baseAttrValue);
    assertEquals("'testValue'", dctmStringValue);
  }

  public void testQueryAttrValueStringForDQL_TypeDate() throws Exception {
    int attrTypeConstant = DocumentManagerConstants.DCTM_TYPE_DATE_TIME;
    String baseAttrValue = "testValue";
    DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(attrTypeConstant);
    String dctmStringValue = documentumAttributeType.buildQueryAttributeValue(baseAttrValue);
    assertEquals("DATE('testValue')", dctmStringValue);
  }

  public void testQueryAttrValueStringForDQL_TypeDouble() throws Exception {
    int attrTypeConstant = DocumentManagerConstants.DCTM_TYPE_DOUBLE;
    String baseAttrValue = "214748364899.9";
    DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(attrTypeConstant);
    String dctmStringValue = documentumAttributeType.buildQueryAttributeValue(baseAttrValue);
    assertEquals(baseAttrValue, dctmStringValue);
  }

  public void testQueryAttrValueStringForDQL_TypeBoolean() throws Exception {
    int attrTypeConstant = DocumentManagerConstants.DCTM_TYPE_BOOLEAN;
    String baseAttrValue = "false";
    DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(attrTypeConstant);
    String dctmStringValue = documentumAttributeType.buildQueryAttributeValue(baseAttrValue);
    assertEquals(baseAttrValue, dctmStringValue);
  }

  public void testQueryAttrValueStringForDQL_TypeInt() throws Exception {
    int attrTypeConstant = DocumentManagerConstants.DCTM_TYPE_INT;
    String baseAttrValue = "-123345";
    DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(attrTypeConstant);
    String dctmStringValue = documentumAttributeType.buildQueryAttributeValue(baseAttrValue);
    assertEquals(baseAttrValue, dctmStringValue);
  }

  public void testQueryAttrValueStringForDQL_TypeInt_OutOfRange_ThrowsException() throws Exception {
    try {
      int attrTypeConstant = DocumentManagerConstants.DCTM_TYPE_INT;
      String baseAttrValue = "2147483648";
      DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(attrTypeConstant);
      documentumAttributeType.buildQueryAttributeValue(baseAttrValue);
      fail("Query Attr Validation exception not thrown, even though integer value is out of range");
    } catch (InvalidDctmAttrValueException e) {
      System.out.println("Expected Path, exception = " + e.getMessage());
    }
  }

  public void testQueryAttrValueStringForDQL_TypeDouble_InvalidString_ThrowsException() throws Exception {
    try {
      int attrTypeConstant = DocumentManagerConstants.DCTM_TYPE_DOUBLE;
      String baseAttrValue = "invalidText";
      DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(attrTypeConstant);
      documentumAttributeType.buildQueryAttributeValue(baseAttrValue);
      fail("Query Attr Validation exception not thrown, even though double value is invalid");
    } catch (InvalidDctmAttrValueException e) {
      System.out.println("Expected Path, exception = " + e.getMessage());
    }
  }

  public void testQueryAttrValueStringForDQL_TypeBoolean_InvalidString_ThrowsException() throws Exception {
    try {
      int attrTypeConstant = DocumentManagerConstants.DCTM_TYPE_BOOLEAN;
      String baseAttrValue = "invalidText";
      DocumentumAttributeType documentumAttributeType = DocumentumAttributeTypeFactory.getQueryAttributeType(attrTypeConstant);
      documentumAttributeType.buildQueryAttributeValue(baseAttrValue);
      fail("Query Attr Validation exception not thrown, even though boolean value is invalid");
    } catch (InvalidDctmAttrValueException e) {
      System.out.println("Expected Path, exception = " + e.getMessage());
    }
  }
}