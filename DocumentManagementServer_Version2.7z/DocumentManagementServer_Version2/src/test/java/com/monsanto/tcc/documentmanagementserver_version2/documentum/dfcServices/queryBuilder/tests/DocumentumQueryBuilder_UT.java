package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.tests;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumAttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.DFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.DocumentumQueryBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumRequestEntity;
import junit.framework.TestCase;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 5, 2006
 * Time: 1:02:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentumQueryBuilder_UT extends TestCase {

  private SearchDocumentumRequestEntity searchRequestEntity;
  private ConnectionInfo connectionInfo;
  private DocumentumQueryBuilder documentumQueryBuilder;

  private static final String CABINET = "/POS Test";
  private static final String DOC_BASE = "stltst03";
  private static final String DOC_BROKER = "stddma00.monsanto.com";
  private static final String USER_NAME = "devl30";
  private static final String PASSWORD = "devl30";
  private static final String OBJECT_TYPE = "dm_document";

  private static final String TITLE_ATTR_VALUE = "monsanto search docs";
  private static final String DIRECTORY_STRUCTURE = "testSearchDir/testFolder";

  IDFCServices service;

  protected void setUp() throws IOException, AttributeListParseException, DocumentManagerException {
    documentumQueryBuilder = new DocumentumQueryBuilder();
    connectionInfo = getConnectionParams(OBJECT_TYPE);
    initializeRequestEntity();
    addDirStructAndConnInfo();
    service = new DFCServices("stddma00.monsanto.com","devl30", "devl30", "stltst03", "/POS Test", "dm_document");
    service.connect();
  }

  protected void tearDown() throws Exception {
    service.close();
  }

  public void testBasicBuildSearchQuery_OneAttr() throws Exception {
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TITLE_ATTR_VALUE, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE " + DocumentManagerConstants.ATTR_STR_TITLE + " = '" + TITLE_ATTR_VALUE + "' AND " +
                    "FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBasicBuildSearchQuery_OneAttr_AllVersions() throws Exception {
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TITLE_ATTR_VALUE, DocumentManagerConstants.OPERATOR_EQUALS);
    searchRequestEntity.setSearchAllVersions(true);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE + DocumentManagerConstants.SPACE_SEPERATOR + DocumentManagerConstants.QUERY_PARAM_ALL_VERSIONS_STR +
                    " WHERE " + DocumentManagerConstants.ATTR_STR_TITLE + " = '" + TITLE_ATTR_VALUE + "' AND " +
                    "FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBasicBuildSearchQuery_WithNullDirectoryStructure() throws Exception {
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TITLE_ATTR_VALUE, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    searchRequestEntity.setDirectoryStructure(null);
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE " + DocumentManagerConstants.ATTR_STR_TITLE + " = '" + TITLE_ATTR_VALUE + "' AND " +
                    "FOLDER('" + CABINET + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBasicBuildSearchQuery_WithEmptyDirectoryStructure() throws Exception {
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TITLE_ATTR_VALUE, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    searchRequestEntity.setDirectoryStructure("");
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE " + DocumentManagerConstants.ATTR_STR_TITLE + " = '" + TITLE_ATTR_VALUE + "' AND " +
                    "FOLDER('" + CABINET + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBuildSearchQuery_WithoutQueryAttributes() throws Exception {
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBuildSearchQuery_SingleValued_OneAttr_TypeString() throws Exception {
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TITLE_ATTR_VALUE, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE " +
                    DocumentManagerConstants.ATTR_STR_TITLE +  " = '" + TITLE_ATTR_VALUE + "'" + DocumentManagerConstants.SPACE_SEPERATOR
                    + "AND " + "FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBuildSearchQuery_SingleValued_OneAttr_TypeID() throws Exception {
    String attrName1 = "r_folder_id";
    String attrVal1 = "009abcd";
    addQueryAttribute(attrName1, attrVal1, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE " +
                    attrName1 +  " = '" + attrVal1 + "'" + DocumentManagerConstants.SPACE_SEPERATOR
                    + "AND " + "FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBuildSearchQuery_SingleValued_OneAttr_TypeDate() throws Exception {
    String attrName1 = DocumentManagerConstants.ATTR_STR_DATE_CREATED;
    String attrVal1 = "11/11/2006";
    addQueryAttribute(attrName1, attrVal1, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE " +
                    DocumentManagerConstants.DCTM_ATTR_STR_DATE_CREATED +  " = "+ DocumentManagerConstants.QUERY_PARAM_DATE_STR + "('" + attrVal1 + "')" + DocumentManagerConstants.SPACE_SEPERATOR
                    + "AND " + "FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBuildSearchQuery_SingleValued_OneAttr_TypeInt() throws Exception {
    String attrName1 = DocumentManagerConstants.ATTR_STR_PAGE_COUNT;
    String attrVal2 = "100";
    addQueryAttribute(attrName1, attrVal2, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE " + DocumentManagerConstants.DCTM_ATTR_STR_PAGE_COUNT +  " = " + attrVal2 + DocumentManagerConstants.SPACE_SEPERATOR + "AND " +
                    "FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBuildSearchQuery_SingleValued_OneAttr_TypeDouble() throws Exception {
    String attrName1 = "r_full_content_size";
    String attrVal4 = "673653475346";
    addQueryAttribute(attrName1, attrVal4, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE " + attrName1 +  " = " + attrVal4 + DocumentManagerConstants.SPACE_SEPERATOR + "AND " +
                    "FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBuildSearchQuery_SingleValued_OneAttr_TypeBoolean() throws Exception {
    String attrName1 = "a_is_hidden";
    String attrVal3 = "false";
    addQueryAttribute(attrName1, attrVal3, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE " + attrName1 +  " = " + attrVal3 + DocumentManagerConstants.SPACE_SEPERATOR + "AND " +
                    "FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBuildSearchQuery_OneAttr_TypeUnknown_DefaultsToStringTypeQueryFormation() throws Exception {
    String attrName1 = "undefined_attr";
    String attrVal1 = "someValue";
    addQueryAttribute(attrName1, attrVal1, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE " +
                    attrName1 +  " = '" + attrVal1 + "'" + DocumentManagerConstants.SPACE_SEPERATOR
                    + "AND " + "FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBuildSearchQuery_MultipleValued_OneAttr_TypeString() throws Exception {
    String attrName1 = DocumentManagerConstants.ATTR_STR_KEYWORDS;
    String attrVal1 = "farm";
    addQueryAttribute(attrName1, attrVal1, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE "
                    + DocumentManagerConstants.QUERY_PARAM_ANY_STR + DocumentManagerConstants.DCTM_ATTR_STR_KEYWORDS +  " = '" + attrVal1 + "'" + DocumentManagerConstants.SPACE_SEPERATOR
                    + "AND " + "FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) ";
    assertEquals(expectedQuery, searchQuery);
  }

  public void testBuildSearchQuery_WithoutOperator_ThrowsException() throws Exception {
    try {
      String attrName1 = DocumentManagerConstants.ATTR_STR_KEYWORDS;
      String attrVal1 = "farm";
      addQueryAttribute(attrName1, attrVal1, null);
      transformAttrNames();
      documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    } catch (DocumentManagerException e) {
      System.out.println("Expected Path, exception = " + e.getMessage());
    }
  }

  public void testBuildSearchQuery_MultipleAttrs() throws Exception {
    String attrName1 = "a_is_hidden";
    String attrVal1 = "false";
    addQueryAttribute(attrName1, attrVal1, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal2 = "farm";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, attrVal2, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal3 = "11/11/2006";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_DATE_CREATED, attrVal3, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " WHERE ";
    assertTrue(searchQuery.startsWith(expectedQuery));
		assertTrue(searchQuery.contains(attrName1 +  " = " + attrVal1 + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains(DocumentManagerConstants.QUERY_PARAM_ANY_STR + DocumentManagerConstants.DCTM_ATTR_STR_KEYWORDS +  " = '" + attrVal2 + "'" + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains(DocumentManagerConstants.DCTM_ATTR_STR_DATE_CREATED +  " = "+ DocumentManagerConstants.QUERY_PARAM_DATE_STR + "('" + attrVal3 + "')" + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains("FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) "));
	}

  public void testBuildSearchQuery_MultipleAttrs_WithFullTextSearch_ForSingleWord() throws Exception {
    String attrName1 = "a_is_hidden";
    String attrVal1 = "false";
    addQueryAttribute(attrName1, attrVal1, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal2 = "farm";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, attrVal2, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal3 = "11/11/2006";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_DATE_CREATED, attrVal3, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal4 = "test";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_FULL_TEXT, attrVal4, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " SEARCH DOCUMENT CONTAINS 'test'"  +
                    " WHERE ";
		assertTrue(searchQuery.startsWith(expectedQuery));
		assertTrue(searchQuery.contains(attrName1 +  " = " + attrVal1 + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains(DocumentManagerConstants.QUERY_PARAM_ANY_STR + DocumentManagerConstants.DCTM_ATTR_STR_KEYWORDS +  " = '" + attrVal2 + "'" + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains(DocumentManagerConstants.DCTM_ATTR_STR_DATE_CREATED +  " = "+ DocumentManagerConstants.QUERY_PARAM_DATE_STR + "('" + attrVal3 + "')" + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains("FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) "));
  }

  public void testBuildSearchQuery_MultipleAttrs_WithFullTextSearch_ForAListOfWords() throws Exception {
    String attrName1 = "a_is_hidden";
    String attrVal1 = "false";
    addQueryAttribute(attrName1, attrVal1, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal2 = "farm";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, attrVal2, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal3 = "11/11/2006";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_DATE_CREATED, attrVal3, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal4 = "This is a test";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_FULL_TEXT, attrVal4, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " SEARCH DOCUMENT CONTAINS 'This' AND 'is' AND 'a' AND 'test'"  +
                    " WHERE ";
		assertTrue(searchQuery.startsWith(expectedQuery));
		assertTrue(searchQuery.contains(attrName1 +  " = " + attrVal1 + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains(DocumentManagerConstants.QUERY_PARAM_ANY_STR + DocumentManagerConstants.DCTM_ATTR_STR_KEYWORDS +  " = '" + attrVal2 + "'" + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains(DocumentManagerConstants.DCTM_ATTR_STR_DATE_CREATED +  " = "+ DocumentManagerConstants.QUERY_PARAM_DATE_STR + "('" + attrVal3 + "')" + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains("FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) "));
  }

  public void testBuildSearchQuery_MultipleAttrs_WithFullTextSearch_ForAListOfWords_WithImproperSpacing() throws Exception {
    String attrName1 = "a_is_hidden";
    String attrVal1 = "false";
    addQueryAttribute(attrName1, attrVal1, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal2 = "farm";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, attrVal2, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal3 = "11/11/2006";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_DATE_CREATED, attrVal3, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal4 = " This     is  a                      test          ";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_FULL_TEXT, attrVal4, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " SEARCH DOCUMENT CONTAINS 'This' AND 'is' AND 'a' AND 'test'"  +
                    " WHERE ";
		assertTrue(searchQuery.startsWith(expectedQuery));
		assertTrue(searchQuery.contains(attrName1 +  " = " + attrVal1 + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains(DocumentManagerConstants.QUERY_PARAM_ANY_STR + DocumentManagerConstants.DCTM_ATTR_STR_KEYWORDS +  " = '" + attrVal2 + "'" + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains(DocumentManagerConstants.DCTM_ATTR_STR_DATE_CREATED +  " = "+ DocumentManagerConstants.QUERY_PARAM_DATE_STR + "('" + attrVal3 + "')" + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains("FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) "));
  }

  public void testBuildSearchQuery_MultipleAttrs_WithFullTextSearch_ForASingleWords_WithImproperSpacing() throws Exception {
    String attrName1 = "a_is_hidden";
    String attrVal1 = "false";
    addQueryAttribute(attrName1, attrVal1, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal2 = "farm";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, attrVal2, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal3 = "11/11/2006";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_DATE_CREATED, attrVal3, DocumentManagerConstants.OPERATOR_EQUALS);
    String attrVal4 = " test          ";
    addQueryAttribute(DocumentManagerConstants.ATTR_STR_FULL_TEXT, attrVal4, DocumentManagerConstants.OPERATOR_EQUALS);
    transformAttrNames();
    String searchQuery = documentumQueryBuilder.buildSearchQueryForDocumentId(searchRequestEntity, service);
    String expectedQuery =
            "SELECT " +
                    DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID +
                    " FROM " + OBJECT_TYPE +
                    " SEARCH DOCUMENT CONTAINS 'test'"  +
                    " WHERE ";
		assertTrue(searchQuery.startsWith(expectedQuery));
		assertTrue(searchQuery.contains(attrName1 +  " = " + attrVal1 + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains(DocumentManagerConstants.QUERY_PARAM_ANY_STR + DocumentManagerConstants.DCTM_ATTR_STR_KEYWORDS +  " = '" + attrVal2 + "'" + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains(DocumentManagerConstants.DCTM_ATTR_STR_DATE_CREATED +  " = "+ DocumentManagerConstants.QUERY_PARAM_DATE_STR + "('" + attrVal3 + "')" + DocumentManagerConstants.SPACE_SEPERATOR));
		assertTrue(searchQuery.contains("FOLDER('" + CABINET + "/" + DIRECTORY_STRUCTURE + "', DESCEND) "));
  }

  private void initializeRequestEntity() {
    searchRequestEntity = new SearchDocumentumRequestEntity();
  }

  private void transformAttrNames() throws AttributeListParseException, DocumentManagerException {
    searchRequestEntity.transformAttrNamesToServiceSpecificAttrNames(new DocumentumAttributeTransformer().getTransformationList());
  }

  private void addDirStructAndConnInfo() {
    searchRequestEntity.setConnectionInfo(connectionInfo);
    searchRequestEntity.setDirectoryStructure(DIRECTORY_STRUCTURE);
  }

  private void addQueryAttribute(String attrName, String attrValue, String operator) {
    searchRequestEntity.getDocumentAttributes().addAttribute(attrName, attrValue, operator);
  }

  private ConnectionInfo getConnectionParams(String objectType) {
    connectionInfo = new ConnectionInfo();
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_CABINET, CABINET);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_DOCBASE, DOC_BASE);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_DOCBROKER, DOC_BROKER);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_USERNAME, USER_NAME);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_PASSWORD, PASSWORD);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_OBJECT_TYPE, objectType);
    return connectionInfo;
  }
}