package com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.tests;

import com.documentum.fc.client.IDfType;
import com.documentum.fc.common.DfException;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.AttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumAttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.DFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import junit.framework.TestCase;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 11, 2006
 * Time: 9:56:27 AM
 * To change this template use File | Settings | File Templates.
 */
public class DFCServices_UT extends TestCase {

  IDFCServices service;
  private static final String TEST_DOC_ATTACHMENT_1 ="com/monsanto/tcc/documentmanagementserver_version2/documentum/dfcServices/tests/testDFC.doc";
  private static final String TEST_JPEG_ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/testMedia.jpg";
  private static final String TEST_DOC_FILE_NAME = "testDFC.doc";
  private static final String TEST_JPEG_FILE_NAME = "testMedia.jpg";
  private ConnectionInfo connectionInfo;

  private static final String CABINET = "/POS Test";
  private static final String DOC_BASE = "stltst03";
  private static final String DOC_BROKER = "stddma00.monsanto.com";
  private static final String USER_NAME = "devl30";
  private static final String PASSWORD = "devl30";
  private static final String OBJECT_TYPE = "dm_document";
  private static final String INVALID_OBJECT_TYPE = "invalid_document";

  protected void setUp() throws IOException, DocumentManagerException {
    service = new DFCServices("stddma00.monsanto.com","devl30", "devl30", "stltst03", "/POS Test", "dm_document");
    service.connect();
  }
 protected void tearDown() throws Exception {
 //   IDFCServices service = new DFCServices(DOC_BROKER, USER_NAME, PASSWORD, DOC_BASE, CABINET, OBJECT_TYPE);
//    service.connect();
    try {
      service.beginTransaction();
      service.deleteByName("testFolder2", "dm_folder");
      service.commitTransaction();
      service.beginTransaction();
      service.deleteByName("testFolder1", "dm_folder");
      service.commitTransaction();
      service.beginTransaction();
      service.deleteByName("dir", "dm_folder");
      service.commitTransaction();
      service.beginTransaction();
      service.deleteByName(TEST_DOC_FILE_NAME, "dm_document");
      service.commitTransaction();
      service.beginTransaction();
      service.deleteByName(TEST_DOC_FILE_NAME, "dm_document");
      service.commitTransaction();
      service.beginTransaction();
      service.deleteByName(TEST_JPEG_FILE_NAME, "dm_document");
      service.commitTransaction();
      service.beginTransaction();
      service.deleteByName(TEST_JPEG_FILE_NAME, "dm_document");
      service.commitTransaction();
    } catch (Exception e) {
      service.rollbackTransaction();
      fail("Teardown fail");
    } finally{
      service.close();
    }
  }
  public void testLookupAttributeType() throws Exception {
    assertEquals(IDfType.DF_STRING, service.lookupAttributeType(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT, service.instantiateSysObject()));
    assertEquals(IDfType.DF_INTEGER, service.lookupAttributeType(DocumentManagerConstants.DCTM_ATTR_STR_PAGE_COUNT, service.instantiateSysObject()));
    assertEquals(IDfType.DF_TIME, service.lookupAttributeType(DocumentManagerConstants.DCTM_ATTR_STR_DATE_CREATED, service.instantiateSysObject()));
    assertEquals(IDfType.DF_BOOLEAN, service.lookupAttributeType("a_full_text", service.instantiateSysObject()));
    assertEquals(IDfType.DF_ID, service.lookupAttributeType("i_folder_id", service.instantiateSysObject()));
  }

  public void testLookupInvalidAttributeType_ReturnsStringAsDefault() throws Exception {
    assertEquals(IDfType.DF_STRING, service.lookupAttributeType("nonExistingType", service.instantiateSysObject()));
  }

  public void testLookupIfAttributeIsRepeating() throws Exception {
    assertEquals(true, service.isAttributeRepeating(DocumentManagerConstants.DCTM_ATTR_STR_KEYWORDS, service.instantiateSysObject()));
    assertEquals(false, service.isAttributeRepeating(DocumentManagerConstants.DCTM_ATTR_STR_SUBJECT, service.instantiateSysObject()));
    assertEquals(true, service.isAttributeRepeating(DocumentManagerConstants.DCTM_ATTR_STR_AUTHORS, service.instantiateSysObject()));
  }

  public void testLookupForRepeatingPropertyOfInvalidAttribute_ReturnsFalseAsDefault() throws Exception {
    assertEquals(false,  service.isAttributeRepeating("nonExistingType", service.instantiateSysObject()));
  }

  public void testSaveDocument_PDFRenditionInQueue() throws Exception {
    InsertDocumentumRequestEntity requestEntity = new InsertDocumentumRequestEntity();
    requestEntity.setConnectionInfo(connectionInfo);
    AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
    requestEntity.getDocumentAttributes().addAttribute("name", TEST_DOC_FILE_NAME, null);
    List nameTransformationList = attributeTransformer.getTransformationList();
    requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
    requestEntity.setRequestPDFRendition(true);

    RetrievedDocument retrievedDocument = service
        .saveDocument(requestEntity, "test/folder1/folder2", TEST_DOC_ATTACHMENT_1);

    DocumentAttributes documentAttributes = retrievedDocument.getDocumentAttributes();
    String attrValue = documentAttributes
        .getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
    assertNotNull(attrValue);
    assertNotNull(documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
    assertEquals(DocumentManagerConstants.STRING_DTS, documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
    assertEquals("rendition_req_ps_pdf", documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_MESSAGE));
    assertEquals("rendition", documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_EVENT));
  }
  public void testSaveDocument_ExceptionIsThrownIfPDFRenditionNotQueue() throws WrappingException, DocumentManagerException, DfException
{
   try {
     InsertDocumentumRequestEntity requestEntity = new InsertDocumentumRequestEntity();
     requestEntity.setConnectionInfo(connectionInfo);
     AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
     requestEntity.getDocumentAttributes().addAttribute("name", TEST_DOC_FILE_NAME, null);
     List nameTransformationList = attributeTransformer.getTransformationList();
     requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
     requestEntity.setRequestPDFRendition(false);

     RetrievedDocument retrievedDocument = service
         .saveDocument(requestEntity, "test/folder1/folder2", TEST_DOC_ATTACHMENT_1);

     DocumentAttributes documentAttributes = retrievedDocument.getDocumentAttributes();
     String attrValue = documentAttributes
         .getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
     assertNotNull(attrValue);
     assertNotNull(documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
     assertEquals(DocumentManagerConstants.STRING_DTS, documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
   }
   catch (AttributeListParseException alp) {
      assertEquals("The Attribute \"queueOwner\" not present.", alp.getMessage());
   }
}
  public void testSaveDocument_DocFileInsertedIntoDctmAndPDFRenditionInDTSQueue() throws Exception {
    InsertDocumentumRequestEntity requestEntity = new InsertDocumentumRequestEntity();
    requestEntity.setConnectionInfo(connectionInfo);
    AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
    requestEntity.getDocumentAttributes().addAttribute("name", TEST_DOC_FILE_NAME, null);
    List nameTransformationList = attributeTransformer.getTransformationList();
    requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
    requestEntity.setRequestPDFRendition(true);

    RetrievedDocument retrievedDocument = service
        .saveDocument(requestEntity, "test/folder1/folder2", TEST_DOC_ATTACHMENT_1);

    DocumentAttributes documentAttributes = retrievedDocument.getDocumentAttributes();
    String attrValue = documentAttributes
        .getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
    assertNotNull(attrValue);
    assertNotNull(documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
    assertEquals(DocumentManagerConstants.STRING_DTS, documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
    assertEquals("rendition_req_ps_pdf", documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_MESSAGE));
    assertEquals("rendition", documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_EVENT));
  }
  public void testSaveDocument_JPEGFileInsertedIntoDctmAndPDFRenditionTrueInMTSQueue() throws Exception {
    InsertDocumentumRequestEntity requestEntity = new InsertDocumentumRequestEntity();
    requestEntity.setConnectionInfo(connectionInfo);
    AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
    requestEntity.getDocumentAttributes().addAttribute("name", TEST_JPEG_FILE_NAME, null);
    List nameTransformationList = attributeTransformer.getTransformationList();
    requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
    requestEntity.setRequestPDFRendition(true);

    RetrievedDocument retrievedDocument = service
        .saveDocument(requestEntity, "test/folder1/folder2", TEST_JPEG_ATTACHMENT_1);

    DocumentAttributes documentAttributes = retrievedDocument.getDocumentAttributes();
    String attrValue = documentAttributes
        .getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
    assertNotNull(attrValue);
    assertNotNull(documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
    assertNotNull(documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
    assertNotNull(documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_MESSAGE));
    assertNotNull(documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_EVENT));
    assertEquals(DocumentManagerConstants.STRING_MTS, documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
    assertEquals("rendition_req_ps_pdf", documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_MESSAGE));
    assertEquals("rendition", documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_EVENT));
}
  public void testSaveDocument_ExceptionThrownWhenJPEGFileInsertedIntoDctmAndPDFRenditionFalse() throws WrappingException,
                                                                          DocumentManagerException, DfException {
    try {
    InsertDocumentumRequestEntity requestEntity = new InsertDocumentumRequestEntity();
    requestEntity.setConnectionInfo(connectionInfo);
    AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
    requestEntity.getDocumentAttributes().addAttribute("name", TEST_JPEG_FILE_NAME, null);
    List nameTransformationList = attributeTransformer.getTransformationList();
    requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
    requestEntity.setRequestPDFRendition(false);

    RetrievedDocument retrievedDocument = service
        .saveDocument(requestEntity, "test/folder1/folder2", TEST_JPEG_ATTACHMENT_1);

    DocumentAttributes documentAttributes = retrievedDocument.getDocumentAttributes();
    String attrValue = documentAttributes
        .getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
    assertNotNull(attrValue);
    assertNotNull(documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
    fail();
    }
     catch (AttributeListParseException alp) {
         assertEquals("The Attribute \"queueOwner\" not present.", alp.getMessage());
    }
  }

  public void testUpdateDocument_ExceptionIsThrownIfPDFRenditionNotQueue() throws Exception,
      DocumentManagerException, DfException,
      InterruptedException {
    try {
      InsertDocumentumRequestEntity requestEntity = new InsertDocumentumRequestEntity();
      requestEntity.setConnectionInfo(connectionInfo);
      AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
      requestEntity.getDocumentAttributes().addAttribute("name", TEST_DOC_FILE_NAME, null);
      List nameTransformationList = attributeTransformer.getTransformationList();
      requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
      requestEntity.setRequestPDFRendition(false);
      RetrievedDocument retrievedDocument = service
          .saveDocument(requestEntity, "test/folder1/folder2", TEST_DOC_ATTACHMENT_1);
      String objectId = retrievedDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
      UpdateDocumentumRequestEntity updateRequestEntity = new UpdateDocumentumRequestEntity();
      updateRequestEntity.getDocumentAttributes().addAttribute("name", TEST_DOC_FILE_NAME, null);
      List updateNameTransformationList = attributeTransformer.getTransformationList();
      updateRequestEntity.transformAttrNamesToServiceSpecificAttrNames(updateNameTransformationList);
      updateRequestEntity.setRequestPDFRendition(false);
      updateRequestEntity.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID,objectId,null);

      RetrievedDocument retrievedUpdatedDocument = service.update(updateRequestEntity,TEST_DOC_ATTACHMENT_1);

      DocumentAttributes documentAttributes = retrievedUpdatedDocument.getDocumentAttributes();
      assertEquals(DocumentManagerConstants.STRING_DTS, documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
      fail();
    }
    catch (AttributeListParseException alp) {
        assertEquals("The Attribute \"queueOwner\" not present.", alp.getMessage());
    }
  }
  public void testUpdateDocument_ExceptionIsThrownIfPDFRenditionNotQueueForDocumentWithRendition() throws Exception,
      DocumentManagerException, DfException,
      InterruptedException {
    try {
      InsertDocumentumRequestEntity requestEntity = new InsertDocumentumRequestEntity();
      requestEntity.setConnectionInfo(connectionInfo);
      AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
      requestEntity.getDocumentAttributes().addAttribute("name", TEST_DOC_FILE_NAME, null);
      List nameTransformationList = attributeTransformer.getTransformationList();
      requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
      requestEntity.setRequestPDFRendition(true);
      RetrievedDocument retrievedDocument = service
          .saveDocument(requestEntity, "test/folder1/folder2", TEST_DOC_ATTACHMENT_1);
      String objectId = retrievedDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
      UpdateDocumentumRequestEntity updateRequestEntity = new UpdateDocumentumRequestEntity();
      updateRequestEntity.getDocumentAttributes().addAttribute("name", TEST_DOC_FILE_NAME, null);
      List updateNameTransformationList = attributeTransformer.getTransformationList();
      updateRequestEntity.transformAttrNamesToServiceSpecificAttrNames(updateNameTransformationList);
      updateRequestEntity.setRequestPDFRendition(false);
      updateRequestEntity.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID,objectId,null);

      RetrievedDocument retrievedUpdatedDocument = service.update(updateRequestEntity,TEST_DOC_ATTACHMENT_1);

      DocumentAttributes documentAttributes = retrievedUpdatedDocument.getDocumentAttributes();
      assertEquals(DocumentManagerConstants.STRING_DTS, documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
      fail();
    }
    catch (AttributeListParseException alp) {
      assertEquals("The Attribute \"queueOwner\" not present.", alp.getMessage());
    }
  }
  public void testUpdateDocument_PDFRenditionInQueue() throws Exception {
    //tearDown();
    InsertDocumentumRequestEntity requestEntity = new InsertDocumentumRequestEntity();
    requestEntity.setConnectionInfo(connectionInfo);
    AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
    requestEntity.getDocumentAttributes().addAttribute("name", TEST_DOC_FILE_NAME, null);
    List nameTransformationList = attributeTransformer.getTransformationList();
    requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
    requestEntity.setRequestPDFRendition(true);
    RetrievedDocument retrievedDocument = service
        .saveDocument(requestEntity, "test/folder1/folder2", TEST_DOC_ATTACHMENT_1);
    String objectId = retrievedDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
    UpdateDocumentumRequestEntity updateRequestEntity = new UpdateDocumentumRequestEntity();
    updateRequestEntity.getDocumentAttributes().addAttribute("name", TEST_DOC_FILE_NAME, null);
    List updateNameTransformationList = attributeTransformer.getTransformationList();
    updateRequestEntity.transformAttrNamesToServiceSpecificAttrNames(updateNameTransformationList);
    updateRequestEntity.setRequestPDFRendition(true);
    updateRequestEntity.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID,objectId,null);

    RetrievedDocument retrievedUpdatedDocument = service.update(updateRequestEntity,TEST_DOC_ATTACHMENT_1);

    DocumentAttributes documentAttributes = retrievedUpdatedDocument.getDocumentAttributes();
    assertEquals(DocumentManagerConstants.STRING_DTS, documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
    assertEquals("rendition_req_ps_pdf", documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_MESSAGE));
    assertEquals("rendition", documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_EVENT));
  }

  public void testUpdateDocument_DocFileInsertedIntoDctmAndPDFRenditionInDTSQueue() throws Exception {
    InsertDocumentumRequestEntity requestEntity = new InsertDocumentumRequestEntity();
    requestEntity.setConnectionInfo(connectionInfo);
    AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
    requestEntity.getDocumentAttributes().addAttribute("name", TEST_DOC_FILE_NAME, null);
    List nameTransformationList = attributeTransformer.getTransformationList();
    requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
    requestEntity.setRequestPDFRendition(true);
    RetrievedDocument retrievedDocument = service
        .saveDocument(requestEntity, "test/folder1/folder2", TEST_DOC_ATTACHMENT_1);
    String objectId = retrievedDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
    UpdateDocumentumRequestEntity updateRequestEntity = new UpdateDocumentumRequestEntity();
    updateRequestEntity.getDocumentAttributes().addAttribute("name", TEST_DOC_FILE_NAME, null);
    List updateNameTransformationList = attributeTransformer.getTransformationList();
    updateRequestEntity.transformAttrNamesToServiceSpecificAttrNames(updateNameTransformationList);
    updateRequestEntity.setRequestPDFRendition(true);
    updateRequestEntity.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID,objectId,null);

    RetrievedDocument retrievedUpdatedDocument = service.update(updateRequestEntity,TEST_DOC_ATTACHMENT_1);

   DocumentAttributes documentAttributes = retrievedUpdatedDocument.getDocumentAttributes();
   assertEquals(DocumentManagerConstants.STRING_DTS, documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
   assertEquals("rendition_req_ps_pdf", documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_MESSAGE));
   assertEquals("rendition", documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_EVENT));
 }
  public void testUpdateDocument_JPEGFileInsertedIntoDctmAndPDFRenditionTrueInMTSQueue() throws Exception {
    InsertDocumentumRequestEntity requestEntity = new InsertDocumentumRequestEntity();
    requestEntity.setConnectionInfo(connectionInfo);
    AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
    requestEntity.getDocumentAttributes().addAttribute("name", TEST_JPEG_FILE_NAME, null);
    List nameTransformationList = attributeTransformer.getTransformationList();
    requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
    requestEntity.setRequestPDFRendition(true);
    RetrievedDocument retrievedDocument = service
        .saveDocument(requestEntity, "test/folder1/folder2", TEST_JPEG_ATTACHMENT_1);
    String objectId = retrievedDocument.getDocumentAttributes().getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
    UpdateDocumentumRequestEntity updateRequestEntity = new UpdateDocumentumRequestEntity();
    updateRequestEntity.getDocumentAttributes().addAttribute("name", TEST_JPEG_FILE_NAME, null);
    List updateNameTransformationList = attributeTransformer.getTransformationList();
    updateRequestEntity.transformAttrNamesToServiceSpecificAttrNames(updateNameTransformationList);
    updateRequestEntity.setRequestPDFRendition(true);
    updateRequestEntity.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_UNIQUE_DOCUMENT_ID,objectId,null);

    RetrievedDocument retrievedUpdatedDocument = service.update(updateRequestEntity,TEST_JPEG_ATTACHMENT_1);

    DocumentAttributes documentAttributes = retrievedUpdatedDocument.getDocumentAttributes();
    assertEquals(DocumentManagerConstants.STRING_MTS, documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_OWNER_NAME));
    assertEquals("rendition_req_ps_pdf", documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_MESSAGE));
    assertEquals("rendition", documentAttributes.getAttrValue(DocumentManagerConstants.DCTM_ATTR_STR_QUEUE_EVENT));
  }
}