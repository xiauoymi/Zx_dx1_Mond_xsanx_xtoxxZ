package com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumResponseEntity;
import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 4, 2006
 * Time: 1:35:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class InsertDocumentumResponseEntity_UT extends XMLTestCase {

  private static final String TEST_NAME_1 = "file1";
  private static final String TEST_CREATOR_1 = "Admin";
  private static final String TEST_KEYWORD_1 = "farm";
  private static final String TEST_KEYWORD_2 = "seed";
  private static final String TEST_NAME_2 = "file2";
  private static final String TEST_SUBJECT_2 = "audits";
  private static final String TEST_TITLE_2 = "Crop Sales";

  ResponseEntity responseEntity;
  MockUCCHelper mockUCCHelper;

  protected void setUp() throws IOException {
    responseEntity = new InsertDocumentumResponseEntity();
    mockUCCHelper = new MockUCCHelper(null);
  }

  public void testResponseForSingleRetrievedDocument() throws Exception {
    addAttribute1(responseEntity);
    responseEntity.sendResponseToClient(mockUCCHelper);
    Document responseDocument = getResponseDocument(mockUCCHelper);
    validateResponseForRetrievedDocument1(responseDocument, 1);
  }

  public void testResponseForMultipleRetrievedDocument() throws Exception {
    addAttribute1(responseEntity);
    addAttribute2(responseEntity);
    responseEntity.sendResponseToClient(mockUCCHelper);
    Document responseDocument = getResponseDocument(mockUCCHelper);
    validateResponseForRetrievedDocument1(responseDocument, 1);
    validateResponseForRetrievedDocument2(responseDocument, 2);
  }

  private void validateResponseForRetrievedDocument1(Document responseDocument, int documentNumber) throws TransformerException {
    validateAttribute(TEST_NAME_1, DocumentManagerConstants.ATTR_STR_NAME, responseDocument, documentNumber);
    validateAttribute(TEST_CREATOR_1, DocumentManagerConstants.ATTR_STR_CREATOR, responseDocument, documentNumber);
    List expectedKeywords = new ArrayList();
    expectedKeywords.add(TEST_KEYWORD_1);
    expectedKeywords.add(TEST_KEYWORD_2);
    validateMutipleValueAttribute(expectedKeywords, DocumentManagerConstants.ATTR_STR_KEYWORDS, responseDocument, documentNumber);
  }

  private void validateResponseForRetrievedDocument2(Document responseDocument, int documentNumber) throws TransformerException {
    validateAttribute(TEST_NAME_2, DocumentManagerConstants.ATTR_STR_NAME, responseDocument, documentNumber);
    validateAttribute(TEST_SUBJECT_2, DocumentManagerConstants.ATTR_STR_SUBJECT, responseDocument, documentNumber);
    validateAttribute(TEST_TITLE_2, DocumentManagerConstants.ATTR_STR_TITLE, responseDocument, documentNumber);
  }

  private void validateMutipleValueAttribute(List expectedKeywords, String attrName, Document responseDocument, int documentNumber) throws TransformerException {
    for (int i = 0; i < expectedKeywords.size(); i++) {
      String expectedAttrValue = (String) expectedKeywords.get(i);
      assertXpathEvaluatesTo(expectedAttrValue,
            "/documentManagerResponse/insertDocument/documentDetails["+ documentNumber +"]/attribute[name = '" + attrName + "']/value["+ (i+1)  +"]",
            responseDocument);
    }
  }

  private void validateAttribute(String attrValue, String attrName, Document responseDocument, int documentNumber) throws TransformerException {
    assertXpathEvaluatesTo(attrValue,
            "/documentManagerResponse/insertDocument/documentDetails["+ documentNumber +"]/attribute[name = '" + attrName + "']/value",
            responseDocument);
  }

  private Document getResponseDocument(MockUCCHelper mockUCCHelper) {
    return mockUCCHelper.getXML();
  }

  private void addAttribute1(ResponseEntity responseEntity) {
    RetrievedDocument retrievedDocument = new RetrievedDocument();
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_NAME, TEST_NAME_1, null);
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_CREATOR, TEST_CREATOR_1, null);
    List keywords = new ArrayList();
    keywords.add(TEST_KEYWORD_1);
    keywords.add(TEST_KEYWORD_2);
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, keywords, null);
    responseEntity.getRetrievedDocumentList().add(retrievedDocument);
  }

  private void addAttribute2(ResponseEntity responseEntity) {
    RetrievedDocument retrievedDocument = new RetrievedDocument();
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_NAME, TEST_NAME_2, null);
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT, TEST_SUBJECT_2, null);
    retrievedDocument.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TEST_TITLE_2, null);
    responseEntity.getRetrievedDocumentList().add(retrievedDocument);
  }
}