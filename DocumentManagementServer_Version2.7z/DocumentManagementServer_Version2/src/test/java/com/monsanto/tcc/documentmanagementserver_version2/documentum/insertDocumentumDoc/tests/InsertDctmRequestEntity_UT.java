package com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.tests;

import junit.framework.TestCase;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.TransformationObject;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Apr 27, 2006
 * Time: 4:39:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class InsertDctmRequestEntity_UT extends TestCase {

  RequestEntity requestEntity = new InsertDocumentumRequestEntity();

  public void testTransformationOfAttributePerformedSucessfully() throws Exception {
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    List requiredAttributes = requestEntity.getRequiredAttributes();

    addKeywords(documentAttributes, "keywordList");
    documentAttributes.addAttribute("fileName", "testName", null);
    documentAttributes.addAttribute("documentSubject", "testSubject", null);
    requiredAttributes.add("fileName");

    assertEquals(documentAttributes.getAttrValue("fileName"), "testName");
    assertEquals(documentAttributes.getAttrValue("documentSubject"), "testSubject");
    assertEquals(documentAttributes.getAttrValues("keywordList").get(0), "farm");
    assertEquals(documentAttributes.getAttrValues("keywordList").get(1), "crop");
    assertEquals(documentAttributes.getAttrValues("keywordList").get(2), "seed");
    assertEquals(documentAttributes.getAttrValues("keywordList").get(2), "seed");
    assertEquals(requiredAttributes.get(0), "fileName");

    List nameList = new ArrayList();
    nameList.add(new TransformationObject("fileName", "object_name"));
    nameList.add(new TransformationObject("keywordList", "keywords"));
    nameList.add(new TransformationObject("documentSubject", "subject"));

    requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameList);

    assertEquals(documentAttributes.getAttrValue("object_name"), "testName");
    assertEquals(documentAttributes.getAttrValue("subject"), "testSubject");
    assertEquals(documentAttributes.getAttrValues("keywords").get(0), "farm");
    assertEquals(documentAttributes.getAttrValues("keywords").get(1), "crop");
    assertEquals(documentAttributes.getAttrValues("keywords").get(2), "seed");
    assertEquals(requiredAttributes.get(0), "object_name");
  }

  private void addKeywords(DocumentAttributes documentAttributes, String attrName) {
    List keywordList = new ArrayList();
    keywordList.add("farm");
    keywordList.add("crop");
    keywordList.add("seed");
    documentAttributes.addAttribute(attrName, keywordList, null);
  }
}