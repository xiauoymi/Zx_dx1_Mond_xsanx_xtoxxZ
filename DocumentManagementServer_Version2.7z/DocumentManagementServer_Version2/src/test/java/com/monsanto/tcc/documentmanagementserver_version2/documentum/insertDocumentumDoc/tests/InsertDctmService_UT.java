package com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.AttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumAttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumService;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.DFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumResponseEntity;
import junit.framework.TestCase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Mar 7, 2006 Time: 11:55:51 AM To change this template use File |
 * Settings | File Templates.
 */
public class InsertDctmService_UT extends TestCase {
  private static final String CABINET = "/POS Test";
  private static final String DOC_BASE = "stltst03";
  private static final String DOC_BROKER = "stddma00.monsanto.com";
  private static final String USER_NAME = "devl30";
  private static final String PASSWORD = "devl30";
  private static final String OBJECT_TYPE = "dm_document";
  private static final String INVALID_OBJECT_TYPE = "invalid_document";
  private static final String TEST_INPUT_REQUEST_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/TestInsertDocRequest.xml";
  private static final String TEST_DOC_ATTACHMENT_2 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/test2.doc";
  private static final String TEST_DOC_ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/test.doc";
  private static final String TEST_TEXT_FILE_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/testFile1.txt";
  private static final String TEST_DOC_FILE_NAME = "test.doc";
  private static final String TEST_2_FILE_NAME = "test2.doc";
  private static final String TEST_1_FILE_NAME = "testFile1.txt";
  InsertDocumentumRequestEntity requestEntity;
  DocumentumService documentumService;
  MockUCCHelper mockHelper;
  ConnectionInfo connectionInfo;
  private ResponseEntity responseEntity;

  protected void setUp() throws IOException, DocumentManagerException, AttributeListParseException {
    responseEntity = new InsertDocumentumResponseEntity();
    documentumService = new DocumentumService(getConnectionParams(OBJECT_TYPE));
    insertTestDoc(TEST_2_FILE_NAME);
  }

  protected void tearDown() throws Exception {
    IDFCServices service = new DFCServices(DOC_BROKER, USER_NAME, PASSWORD, DOC_BASE, CABINET, OBJECT_TYPE);
		deleteTestDocument(service, TEST_1_FILE_NAME, "dm_document");
		deleteTestDocument(service, "testFolder2", "dm_folder");
		deleteTestDocument(service, "testFolder1", "dm_folder");
		deleteTestDocument(service, "dir", "dm_folder");
		deleteTestDocument(service,TEST_2_FILE_NAME, "dm_document");
		deleteTestDocument(service,TEST_DOC_FILE_NAME, "dm_document");
  }

	private void deleteTestDocument(IDFCServices service, String test1FileName, String objectType) throws DocumentManagerException {
		service.connect();
		try {
			service.beginTransaction();
			service.deleteByName(test1FileName, objectType);
			service.commitTransaction();
		} catch (Exception e) {
			System.out.println("InsertDctmService_UT.deleteTestDocument: e = " + e.toString());
			service.rollbackTransaction();
		} finally {
			service.close();
		}
	}

	public void testFileInsertedIntoDctm() throws Exception {
    initRequestEntity(TEST_DOC_FILE_NAME, connectionInfo);
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile(TEST_DOC_ATTACHMENT_1);
    transformDctmSpecificAttrs();
    insertDocument();
    validateObjectIdAndVersionPresentInResponse(getDocumentAttributesFromResponse());
  }

  private void validateObjectIdAndVersionPresentInResponse(DocumentAttributes documentAttributes) throws
      AttributeListParseException {
    assertNotNull(documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID));
    assertEquals("1.0", documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_VERSION));
  }

  private DocumentAttributes getDocumentAttributesFromResponse() {
    return ((RetrievedDocument) responseEntity.getRetrievedDocumentList().get(0)).getDocumentAttributes();
  }

  private void insertDocument() throws DocumentManagerException, AttributeListParseException, IOException {
    documentumService.insert(requestEntity, responseEntity, mockHelper);
    responseEntity.sendResponseToClient(mockHelper);
  }

  public void testInsertThrowsExceptionWhenDocumentAlreadyExists() throws Exception {
    initRequestEntity(TEST_2_FILE_NAME, connectionInfo);
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile(TEST_DOC_ATTACHMENT_1);
    transformDctmSpecificAttrs();
    try {
      insertDocument();
      validateObjectIdAndVersionPresentInResponse(getDocumentAttributesFromResponse());
      fail("Document already present in the cabinet, exception not thrown.");
    } catch (Exception e) {
      if (!(e instanceof DocumentManagerException
          && e.getMessage().equalsIgnoreCase("Document already present in the specified cabinet."))) {
        fail("Unknown Exception thrown.");
      }
    }
  }

  public void testExceptionThrownIfDocumentumContentTypeNotFound() throws Exception {
    initRequestEntity("testFile.cat", connectionInfo);
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile("C:\\testFile.cat");
    transformDctmSpecificAttrs();
    try {
      insertDocument();
      validateObjectIdAndVersionPresentInResponse(getDocumentAttributesFromResponse());
      fail("Document content type not found, exception not thrown.");
    } catch (Exception e) {
      if (!(e instanceof DocumentManagerException
          && e.getMessage().equalsIgnoreCase("Document content type not allowed."))) {
        fail("Unknown Exception thrown.");
      }
    }
  }

  public void testExceptionThrownIfObjectTypeIsInvalid() throws Exception {
    connectionInfo = getConnectionParams(INVALID_OBJECT_TYPE);
    initRequestEntity(TEST_2_FILE_NAME, connectionInfo);
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile(TEST_TEXT_FILE_1);
    transformDctmSpecificAttrs();
    try {
      insertDocument();
      validateObjectIdAndVersionPresentInResponse(getDocumentAttributesFromResponse());
      fail("Document content type not found, exception not thrown.");
    } catch (DocumentManagerException e) {
      //expected path
    }
  }

  public void testFileInsertedWithAttributes() throws Exception {
    initRequestEntity(TEST_1_FILE_NAME, connectionInfo);
    initTestAttr();
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile(TEST_TEXT_FILE_1);
    transformDctmSpecificAttrs();
    insertDocument();
    validateObjectIdAndVersionPresentInResponse(getDocumentAttributesFromResponse());
  }

  public void testExceptionThrownIfFileInsertedWithInvalidAttributeNotRecognizedByDctm() throws Exception {
    initRequestEntity(TEST_1_FILE_NAME, connectionInfo);
    initTestAttr();
    initInvalidAttr();
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile(TEST_TEXT_FILE_1);
    transformDctmSpecificAttrs();
    try {
      insertDocument();
      validateObjectIdAndVersionPresentInResponse(getDocumentAttributesFromResponse());
			fail("Should have thrown exception");
		} catch (DocumentManagerException e) {
      //expected path...
    }
  }

  public void testFileInsertedWithAttributesIntoSpecifedDirectoryStructure() throws Exception {
    initRequestEntity(TEST_1_FILE_NAME, connectionInfo);
    initTestAttr();
    initDirStructure("dir/testFolder1/testFolder2");
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile(TEST_TEXT_FILE_1);
    transformDctmSpecificAttrs();
    insertDocument();
    validateObjectIdAndVersionPresentInResponse(getDocumentAttributesFromResponse());
  }

  private void transformDctmSpecificAttrs() throws AttributeListParseException, DocumentManagerException {
    AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
    List nameTransformationList = attributeTransformer.getTransformationList();
    requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
  }

  private void initDirStructure(String dir) {
    requestEntity.setDirectoryStructure(dir);
  }

  private void initInvalidAttr() {
    requestEntity.getDocumentAttributes().addAttribute("invalid-attribute", "testValue", null);
  }

  private void insertTestDoc(String fileName) throws DocumentManagerException, AttributeListParseException,
      IOException {
    initRequestEntity(fileName, connectionInfo);
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    mockHelper.addClientFile(TEST_DOC_ATTACHMENT_2);
    transformDctmSpecificAttrs();
    insertDocument();
  }

  private ConnectionInfo getConnectionParams(String objectType) {
    connectionInfo = new ConnectionInfo();
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_CABINET, CABINET);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_DOCBASE, DOC_BASE);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_DOCBROKER, DOC_BROKER);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_USERNAME, USER_NAME);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_PASSWORD, PASSWORD);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_OBJECT_TYPE, objectType);
    return connectionInfo;
  }

  private void initRequestEntity(String fileName, ConnectionInfo connectionInfo) {
    requestEntity = new InsertDocumentumRequestEntity();
    requestEntity.getDocumentAttributes().addAttribute("name", fileName, null);
    requestEntity.setConnectionInfo(connectionInfo);
  }

  private void initTestAttr() {
    requestEntity.getDocumentAttributes().addAttribute("subject", "testSubject", null);

    List keywordList = new ArrayList();
    keywordList.add("farm");
    keywordList.add("seed");
    keywordList.add("weed");
    requestEntity.getDocumentAttributes().addAttribute("keywords", keywordList, null);

    List authorList = new ArrayList();
    authorList.add("testAuthor1");
    authorList.add("testAuthor2");
    authorList.add("testAuthor3");
    requestEntity.getDocumentAttributes().addAttribute("authors", authorList, null);

    requestEntity.getDocumentAttributes().addAttribute("title", "testTitle", null);
    requestEntity.setConnectionInfo(connectionInfo);
  }
}