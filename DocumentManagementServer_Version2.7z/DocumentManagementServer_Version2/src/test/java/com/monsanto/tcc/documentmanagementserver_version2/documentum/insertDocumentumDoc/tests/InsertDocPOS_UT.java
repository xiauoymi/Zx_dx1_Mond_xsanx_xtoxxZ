package com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.ServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.insertService.InsertDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.builder.InsertDocumentumBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.DFCServices;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.apache.xpath.XPathAPI;

import javax.xml.transform.TransformerException;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Feb 23, 2006 Time: 3:18:14 PM To change this template use File |
 * Settings | File Templates.
 */
public class InsertDocPOS_UT extends XMLTestCase {

  private static final String DOC_BASE = "stltst03";
  private static final String DOC_BROKER = "stddma00.monsanto.com";
  private static final String USER_NAME = "devl30";
  private static final String PASSWORD = "devl30";
  private static final String CABINET = "/POS Test";
  private static final String OBJECT_TYPE = "dm_document";

  private static final String TEST_INPUT_REQUEST_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/TestInsertDocRequest.xml";
  private static final String TEST_INPUT_REQUEST_XML_2 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/TestInsertDocRequest2.xml";
  private static final String INSERT_DOC_REQUEST_SEC_ENV_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/InsertDocWithSecurityEnvelope1.xml";
  private static final String INSERT_DOC_REQUEST_SEC_ENV_XML_2 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/InsertDocWithSecEnv2.xml";
  private static final String INSERT_DOC_REQUEST_SEC_ENV_XML_3 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/InsertDocWithSecEnv3.xml";
  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";
  private static final String TEST_DOC_ATTACHMENT_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/test.doc";

  InsertDocumentPOS insertDocumentPOS;
  MockUCCHelper mockUCCHelper;

  protected void setUp() throws IOException {
    insertDocumentPOS = new MockInsertDocPOS();
    mockUCCHelper = new MockUCCHelper(null);
  }

  protected void tearDown() throws Exception {
    IDFCServices service = new DFCServices(DOC_BROKER, USER_NAME, PASSWORD, DOC_BASE, CABINET, OBJECT_TYPE);
    service.connect();
    try {
      service.beginTransaction();
      service.deleteByName("testFile.doc", OBJECT_TYPE);
      service.deleteByName("folder2", "dm_folder");
      service.deleteByName("folder1", "dm_folder");
      service.deleteByName("some dir", "dm_folder");
      service.commitTransaction();
    } catch (Exception e) {
      service.rollbackTransaction();
    } finally {
      service.close();
    }
  }

  public void testCorrectBuilderInitialized() throws Exception {
    Document inputDoc = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_1);
    assertEquals(InsertDocumentumBuilder.class, insertDocumentPOS.getBuilder(inputDoc).getClass());
  }

  public void testExceptionThrownIfBuilderImplementationNotFound() throws Exception {
    try {
      Document inputDoc = DOMUtil.newDocument(TEST_INPUT_REQUEST_XML_2);
      assertEquals(InsertDocumentumBuilder.class, insertDocumentPOS.getBuilder(inputDoc).getClass());
      fail("Builder not initailized Exception NOT thrown.");
    } catch (ServiceConfigException e) {
      System.out.println("Required exception thrown: " + e.getMessage());
    }
  }

  public void testErrorResponseGeneratedIfSchemaValidationFails() throws Exception {
    Document responseDoc = runInsertPOS(INSERT_DOC_REQUEST_SEC_ENV_XML_1);
    checkErrorTagCreatedCorrectly(responseDoc);
    assertXpathEvaluatesTo(
        "org.xml.sax.SAXParseException: cvc-complex-type.2.4.a: Invalid content was found starting with element 'directoryStructure'. One of '{\"www.monsanto.com/pos\":folder}' is expected.\r\n",
        "/ERROR/ERROR_MESSAGE", responseDoc);
  }

  public void testInsertDocument() throws Exception {
    Document responseDoc = runInsertPOS(INSERT_DOC_REQUEST_SEC_ENV_XML_2);
    checkNoErrorResponseTag(responseDoc);
  }

  public void testErrorResponseSentByBaseDocPOSIfBuilderImplNotFound() throws Exception {
    Document responseDoc = runInsertPOS(INSERT_DOC_REQUEST_SEC_ENV_XML_3);
    checkErrorTagCreatedCorrectly(responseDoc);
  }

  public void testErrorResponseSentByBaseDocPOSIfLsiEnvironmentVariableNotSet() throws Exception {
    String lsiFunction = System.getProperty("lsi.function");
    System.setProperty("lsi.function", "win");
    Document responseDoc = runInsertPOS(INSERT_DOC_REQUEST_SEC_ENV_XML_2);
    checkErrorTagCreatedCorrectly(responseDoc);
    assertXpathEvaluatesTo("lsi environment variable not set:Bad value for lsi.function", "/ERROR/ERROR_MESSAGE",
        responseDoc);
    System.setProperty("lsi.function", lsiFunction);
  }

  private Document runInsertPOS(String inputRequestFilePath) throws IOException {
    mockUCCHelper.addClientFile(inputRequestFilePath);
    mockUCCHelper.addClientFile(TEST_DOC_ATTACHMENT_1);
    insertDocumentPOS.run(mockUCCHelper);
    return mockUCCHelper.getXML();
  }

  private void checkNoErrorResponseTag(Document responseDoc) throws TransformerException {
    String xpathString = "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" +
        DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value";
    assertXpathExists(xpathString, responseDoc);
    String objectId = XPathAPI.eval(responseDoc.getDocumentElement(), xpathString).toString();
    assertNotNull(objectId);
    assertXpathEvaluatesTo("1.0", "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" +
        DocumentManagerConstants.ATTR_STR_VERSION + "']/value", responseDoc);
  }

  private void checkErrorTagCreatedCorrectly(Document responseDoc) throws TransformerException {
    assertXpathExists("/ERROR", responseDoc);
    assertXpathEvaluatesTo("-1", "/ERROR/ERROR_CODE", responseDoc);
    assertXpathExists("/ERROR/ERROR_MESSAGE", responseDoc);
    assertXpathExists("/ERROR/STACK_TRACE", responseDoc);
  }

  class MockInsertDocPOS extends InsertDocumentPOS {

    protected IServiceLookup instantiateServiceLookup() throws ServiceConfigException {
      return new ServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    }
  }
}