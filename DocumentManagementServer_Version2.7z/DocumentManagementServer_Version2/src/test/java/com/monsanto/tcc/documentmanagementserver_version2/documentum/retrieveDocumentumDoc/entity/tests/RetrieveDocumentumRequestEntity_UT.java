package com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.tests;

import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.RetrieveDocumentumRequestEntity;

import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 29, 2006
 * Time: 11:44:40 AM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveDocumentumRequestEntity_UT extends TestCase {

  RetrieveDocumentumRequestEntity requestEntity;
  DocumentAttributes documentAttributes;

  public void setUp(){
    requestEntity = new RetrieveDocumentumRequestEntity();
    documentAttributes = new DocumentAttributes();
  }

  public void testCheckEmptyAttributeMap(){
    DocumentAttributes requestMap = requestEntity.getDocumentAttributes();
    assertNotNull(requestMap);
    assertEquals(0,requestMap.getLength());
  }
}