package com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.parser.tests;

import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.parser.RetrieveDocumentumRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockRetrieveDocumentumRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.RetrieveDocumentumRequestEntity;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 29, 2006
 * Time: 10:15:19 AM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveDocumentumRequestParser_UT extends TestCase {

  private static final String TEST_CUSTOM_ATTR_RETRIEVE_REQUEST_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/retrieveDocumentumDoc/parser/tests/TestCustomAttrRetrieveReq1.xml";
  private static final String TEST_RETRIEVE_REQUEST_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/retrieveDocumentumDoc/tests/TestRetrieveDocRequest.xml";

  RetrieveDocumentumRequestParser retrieveParser;
  RetrieveDocumentumRequestEntity requestEntity;

  private static final String REQUEST_DETAILS = "requestDetails";
  private static final String OBJECT_ID = "objectId";
  private static final String CABINET = "cabinet";
  private static final String DOC_BASE = "docBase";
  private static final String DOC_BROKER = "docBroker";
  private static final String USER_NAME = "userName";
  private static final String PASSWORD = "password";
  private static final String OBJECT_TYPE = "objectType";
  private static final String APHIS_CABINET = "/APHIS CABINET";
  private static final String STLTST01 = "stltst01";
  private static final String STDDMA00_MONSANTO_COM = "stddma00.monsanto.com";
  private static final String APHIS = "aphis";
  private static final String ENCRYPTED_PASSWORD = "devl30";
  private static final String APHIS_DOC = "aphis_doc";

  public void setUp(){
    retrieveParser = new MockRetrieveDocumentumRequestParser();
    requestEntity = new RetrieveDocumentumRequestEntity();
  }

  public void testParsingOfFolderAndDirectoryNameWithCorrectStructure() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_RETRIEVE_REQUEST_XML_1);
    retrieveParser.parseInputXML(inputDocument,requestEntity);
    assertEquals("myTestFolder1", requestEntity.getFolderName());
    assertEquals("test/folder1/folder2", requestEntity.getDirectoryStructure());
  }

  public void testServiceSpecificConfigDetailsParsedCorrectlyForRequestingRetrieveDocument() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_RETRIEVE_REQUEST_XML_1);
    retrieveParser.parseInputXML(inputDocument, requestEntity);
    assertEquals(APHIS_CABINET, requestEntity.getConnectionInfo().getConnectionParameterValue(CABINET));
    assertEquals(STLTST01, requestEntity.getConnectionInfo().getConnectionParameterValue(DOC_BASE));
    assertEquals(STDDMA00_MONSANTO_COM, requestEntity.getConnectionInfo().getConnectionParameterValue(DOC_BROKER));
    assertEquals(APHIS, requestEntity.getConnectionInfo().getConnectionParameterValue(USER_NAME));
    assertEquals(ENCRYPTED_PASSWORD, requestEntity.getConnectionInfo().getConnectionParameterValue(PASSWORD));
    assertEquals(APHIS_DOC, requestEntity.getConnectionInfo().getConnectionParameterValue(OBJECT_TYPE));
  }

  public void testParsingOfDocumentAttributesAndCheckingObjectIdValue() throws Exception {
    parseRequestXML(TEST_RETRIEVE_REQUEST_XML_1);
    validateDocumentAttributes("09001abe80089209");
  }

  public void testParsingOfCustomRequiredAttributes() throws Exception {
    parseRequestXML(TEST_CUSTOM_ATTR_RETRIEVE_REQUEST_XML_1);
    validateDocumentAttributes("09001abe80089209");
    validateRequiredAttributes();
  }

  private void parseRequestXML(String requestXML) throws ParserException, DocumentManagerException {
    Document inputDocument = DOMUtil.newDocument(requestXML);
    Node requestNode = DOMUtil.getChild(inputDocument.getDocumentElement(), REQUEST_DETAILS);
    retrieveParser.parseOperationSpecificRequest(requestNode, requestEntity);
  }

  private void validateDocumentAttributes(String objectId) throws AttributeListParseException {
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    assertEquals(1, documentAttributes.getLength());
    assertEquals(objectId, documentAttributes.getAttrValue(OBJECT_ID));
  }

  private void validateRequiredAttributes() {
    List requiredAttributes = requestEntity.getRequiredAttributes();
    assertEquals(3, requiredAttributes.size());
    assertEquals("title", requiredAttributes.get(0));
    assertEquals("subject", requiredAttributes.get(1));
    assertEquals("keywords", requiredAttributes.get(2));
  }
}