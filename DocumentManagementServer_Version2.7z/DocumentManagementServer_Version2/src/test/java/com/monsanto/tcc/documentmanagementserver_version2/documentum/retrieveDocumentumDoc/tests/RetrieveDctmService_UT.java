package com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.Util.FileUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.retrieveService.RetrieveDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.AttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumAttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumService;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.DFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.RetrieveDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.RetrieveDocumentumResponseEntity;
import com.monsanto.XMLUtil.DOMUtil;
import org.apache.xerces.impl.dv.util.Base64;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.custommonkey.xmlunit.XMLTestCase;

import javax.xml.transform.TransformerException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Apr 25, 2006
 * Time: 11:32:57 AM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveDctmService_UT extends XMLTestCase {

  private static final String CABINET = "/POS Test";
  private static final String DOC_BASE = "stltst03";
  private static final String DOC_BROKER = "stddma00.monsanto.com";
  private static final String USER_NAME = "devl30";
  private static final String PASSWORD = "devl30";
  private static final String DEFAULT_OBJECT_TYPE = "dm_document";

  private static final String TEST_DOC_ATTACHMENT = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/test2.doc";
  private static final String TEST_FILE_NAME_SINGLE_ATTR = "testRetrieveWithSingleValuedAttr.doc";
  private static final String TEST_FILE_NAME_MULTIPLE_ATTR = "testRetrieveWithMultipleValuedAttr.doc";

  private String insertedObjectIdForSingleValuedAttributeTest;
  private String insertedObjectIdForMultipleValuedAttributeTest;

  private static final String TITLE_ATTRIBUTE_VALUE = "testTitle";
  private static final String SUB_ATTRIBUTE_VALUE = "testSubject";

  private static final String KEYWORD_ATTRIBUTE_VALUE_1 = "farm";
  private static final String KEYWORD_ATTRIBUTE_VALUE_2 = "crop";
  private static final String KEYWORD_ATTRIBUTE_VALUE_3 = "field";

  private static final String INVALID_ATTR_NAME_STR = "INVALID_ATTR";

  private static List keywords;

  private static final String XPATH_START_STRING_ATTR_MATCH = "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name = '";
  private static final String XPATH_END_STRING_ATTR_MATCH = "']/value";

  MockUCCHelper mockHelper;

  static{
    keywords = new ArrayList();
    keywords.add(KEYWORD_ATTRIBUTE_VALUE_1);
    keywords.add(KEYWORD_ATTRIBUTE_VALUE_2);
    keywords.add(KEYWORD_ATTRIBUTE_VALUE_3);
  }

  InsertDocumentumRequestEntity insertRequestEntity;
  RetrieveDocumentumRequestEntity retrieveRequestEntity;
  DocumentumService documentumService;
  ConnectionInfo connectionInfo;
  private ResponseEntity responseEntity;

  protected void setUp() throws IOException, AttributeListParseException, TransformerException, DocumentManagerException {
    documentumService = new DocumentumService(getConnectionParams(DEFAULT_OBJECT_TYPE));
    insertFileWithSingleValuedAttr();
    insertFileWithMultipleValuedAttr();
    responseEntity = new RetrieveDocumentumResponseEntity();
  }

  protected void tearDown() throws Exception {
    IDFCServices service = new DFCServices(DOC_BROKER, USER_NAME, PASSWORD, DOC_BASE, CABINET, DEFAULT_OBJECT_TYPE);
    service.connect();
    try {
      service.beginTransaction();
      service.deleteByName(TEST_FILE_NAME_SINGLE_ATTR, DEFAULT_OBJECT_TYPE);
      service.deleteByName(TEST_FILE_NAME_MULTIPLE_ATTR, DEFAULT_OBJECT_TYPE);
      service.commitTransaction();
    } catch (Exception e) {
      service.rollbackTransaction();
    } finally{
      service.close();
    }
  }

  public void testRetriveOfDocumentWithCustomSingleValuedAttributes() throws Exception {
    initRequestEntityForRetrieve(connectionInfo, insertedObjectIdForSingleValuedAttributeTest);
    addRequiredAttribute(DocumentManagerConstants.ATTR_STR_TITLE);
    addRequiredAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT);
    transformDctmSpecificAttrsForRetrieve();
    MockUCCHelper mockUCCHelper = retrieveDocument();
    String pathToRetrievedFile = getRetrievedDocumentContents(getDocumentAttributesFromResponse(), mockUCCHelper);
    assertTrue(FileUtil.compareFiles(TEST_DOC_ATTACHMENT, pathToRetrievedFile));
    validateRetrievedFileSingleAttributes(insertedObjectIdForSingleValuedAttributeTest, TEST_FILE_NAME_SINGLE_ATTR, getDocumentAttributesFromResponse());
  }

  private DocumentAttributes getDocumentAttributesFromResponse() {
    return ((RetrievedDocument) responseEntity.getRetrievedDocumentList().get(0)).getDocumentAttributes();
  }

  private MockUCCHelper retrieveDocument() throws DocumentManagerException, AttributeListParseException, IOException {
   RetrieveDocumentPOS retrieveDocumentPOS = new RetrieveDocumentPOS();
    mockHelper = new MockUCCHelper(null);
    retrieveDocumentPOS.performOperation(retrieveRequestEntity, documentumService, responseEntity, mockHelper);
    responseEntity.sendResponseToClient(mockHelper);
    return mockHelper;
  }

  public void testRetriveOfDocumentWithCustomMultipleValuedAttributes() throws Exception {
    initRequestEntityForRetrieve(connectionInfo, insertedObjectIdForMultipleValuedAttributeTest);
    addRequiredAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS);
    addRequiredAttribute(DocumentManagerConstants.ATTR_STR_TITLE);
    addRequiredAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT);
    transformDctmSpecificAttrsForRetrieve();
    MockUCCHelper mockUCCHelper =  retrieveDocument();
    String pathToRetrievedFile = getRetrievedDocumentContents(getDocumentAttributesFromResponse(), mockUCCHelper);
    assertTrue(FileUtil.compareFiles(TEST_DOC_ATTACHMENT, pathToRetrievedFile));
    validateRetrievedFileSingleAttributes(insertedObjectIdForMultipleValuedAttributeTest, TEST_FILE_NAME_MULTIPLE_ATTR, getDocumentAttributesFromResponse());
    validateKeywords(getDocumentAttributesFromResponse());
  }

  public void testRetrieveRequestForInvalidFormatRendition_ReturnsDefaultFormat() throws Exception {
    initRequestEntityForRetrieveWithInvalidFormat(connectionInfo, insertedObjectIdForMultipleValuedAttributeTest);
    addRequiredAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS);
    addRequiredAttribute(DocumentManagerConstants.ATTR_STR_TITLE);
    addRequiredAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT);
    transformDctmSpecificAttrsForRetrieve();
    MockUCCHelper mockUCCHelper =  retrieveDocument();
    String pathToRetrievedFile = getRetrievedDocumentContents(getDocumentAttributesFromResponse(), mockUCCHelper);
    assertTrue(FileUtil.compareFiles(TEST_DOC_ATTACHMENT, pathToRetrievedFile));
    validateRetrievedFileSingleAttributes(insertedObjectIdForMultipleValuedAttributeTest, TEST_FILE_NAME_MULTIPLE_ATTR, getDocumentAttributesFromResponse());
    validateKeywords(getDocumentAttributesFromResponse());
  }

  public void testExceptionThrownIfNonExistingAttributeIsRequested() throws Exception {
    try {
      initRequestEntityForRetrieve(connectionInfo, insertedObjectIdForMultipleValuedAttributeTest);
      addRequiredAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS);
      addRequiredAttribute(DocumentManagerConstants.ATTR_STR_TITLE);
      addRequiredAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT);
      addRequiredAttribute(INVALID_ATTR_NAME_STR);
      transformDctmSpecificAttrsForRetrieve();
      retrieveDocument();
      fail("Exception for requesting Invalid-Att not thown");
    } catch (DocumentManagerException e) {
      System.out.println("Required Exception thrown for requesting Invalid-Attr: " + e.getMessage());
      //expected path
    }
  }

  public void testRetriveWithAttr_RetrievesWithRequestedCoreAttributeName_BackTransformationCheck() throws Exception {
    String requestedCoreAttribute = DocumentManagerConstants.ATTR_STR_SIZE;
    initRequestEntityForRetrieve(connectionInfo, insertedObjectIdForSingleValuedAttributeTest);
    addRequiredAttribute(DocumentManagerConstants.ATTR_STR_TITLE);
    addRequiredAttribute(requestedCoreAttribute);
    transformDctmSpecificAttrsForRetrieve();
    MockUCCHelper mockUCCHelper = retrieveDocument();
    String pathToRetrievedFile = getRetrievedDocumentContents(getDocumentAttributesFromResponse(), mockUCCHelper);
    assertTrue(FileUtil.compareFiles(TEST_DOC_ATTACHMENT, pathToRetrievedFile));
    validateAttribute(DocumentManagerConstants.ATTR_STR_SIZE, "19968", getDocumentAttributesFromResponse());
  }

  public void testRetriveWithAttr_ThrowsException_IfServiceSpecificNameSpecifiedInRequestForCoreAttributes() throws Exception {
    try {
      String requestedDctmSpecificAttribute = "owner_name";
      initRequestEntityForRetrieve(connectionInfo, insertedObjectIdForSingleValuedAttributeTest);
      addRequiredAttribute(DocumentManagerConstants.ATTR_STR_TITLE);
      addRequiredAttribute(requestedDctmSpecificAttribute);
      transformDctmSpecificAttrsForRetrieve();
      retrieveDocument();
      fail("Exception not thrown for requesting service specific name");
    } catch (DocumentManagerException e) {
      System.out.println("Required Exception thrown for requesting service-specific attr name: " + e.getMessage());
      //expected path
    }
  }

  private void insertFileWithMultipleValuedAttr() throws AttributeListParseException, DocumentManagerException, TransformerException, IOException {
    initRequestEntityForInsert(TEST_FILE_NAME_MULTIPLE_ATTR, connectionInfo);
    insertRequestEntity.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, keywords, null);
    insertedObjectIdForMultipleValuedAttributeTest = insertTestDocWithAttributes();
  }

  private void insertFileWithSingleValuedAttr() throws AttributeListParseException, DocumentManagerException, TransformerException, IOException {
    initRequestEntityForInsert(TEST_FILE_NAME_SINGLE_ATTR, connectionInfo);
    insertedObjectIdForSingleValuedAttributeTest = insertTestDocWithAttributes();
  }

  private void validateKeywords(DocumentAttributes documentAttributes) throws AttributeListParseException {
    List retrievedKeywords = documentAttributes.getAttrValues(DocumentManagerConstants.ATTR_STR_KEYWORDS);
    for (int i = 0; i < keywords.size(); i++) {
      String expectedKeyword = (String) keywords.get(i);
      assertEquals(expectedKeyword, retrievedKeywords.get(i));
    }
  }

  private void validateRetrievedFileSingleAttributes(String objecId, String fileNameSpecifiedInRequest, DocumentAttributes documentAttributes) throws  AttributeListParseException {
    validateAttribute(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID, objecId, documentAttributes);
    validateAttribute(DocumentManagerConstants.ATTR_STR_NAME, fileNameSpecifiedInRequest, documentAttributes);
    validateAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TITLE_ATTRIBUTE_VALUE, documentAttributes);
    validateAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT, SUB_ATTRIBUTE_VALUE, documentAttributes);
  }

  private void validateAttribute(String attrName, String expectedAttrValue, DocumentAttributes documentAttributes) throws AttributeListParseException {
    assertEquals(expectedAttrValue, documentAttributes.getAttrValue(attrName));
  }

  private String getRetrievedDocumentContents(DocumentAttributes documentAttributes, MockUCCHelper mockUCCHelper) throws IOException, AttributeListParseException, SAXException, TransformerException {
    Document retrieveResponseDoc = DOMUtil.newDocument(mockUCCHelper.getInputStream(""));
    String encodedContentString = XPathAPI.eval(retrieveResponseDoc,
            XPATH_START_STRING_ATTR_MATCH + DocumentManagerConstants.ATTR_STR_CONTENTS + XPATH_END_STRING_ATTR_MATCH).toString();
    byte decodedByte[] = Base64.decode(encodedContentString);
    String filePath = System.getProperty(DocumentManagerConstants.TEMP_DIRECTORY) + documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_NAME);
    FileOutputStream foStream = new FileOutputStream(filePath);
    foStream.write(decodedByte, 0, decodedByte.length);
    foStream.flush();
    foStream.close();
    return filePath;
  }

  private void initRequestEntityForRetrieve(ConnectionInfo connectionInfo, String objectId) {
    retrieveRequestEntity = new RetrieveDocumentumRequestEntity();
    retrieveRequestEntity.getDocumentAttributes().addAttribute("objectId", objectId, null);
    retrieveRequestEntity.setConnectionInfo(connectionInfo);
  }

  private void initRequestEntityForRetrieveWithInvalidFormat(ConnectionInfo connectionInfo, String objectId) {
    retrieveRequestEntity = new RetrieveDocumentumRequestEntity();
    retrieveRequestEntity.getDocumentAttributes().addAttribute("objectId", objectId, null);
    retrieveRequestEntity.getDocumentAttributes().addAttribute(DocumentManagerConstants.DCTM_ATTR_STR_FORMAT, "InvalidFormat", null);
    retrieveRequestEntity.setConnectionInfo(connectionInfo);
  }

  private void addRequiredAttribute(String attribute1) {
    retrieveRequestEntity.getRequiredAttributes().add(attribute1);
  }

  private ConnectionInfo getConnectionParams(String objectType) {
    connectionInfo = new ConnectionInfo();
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_CABINET, CABINET);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_DOCBASE, DOC_BASE);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_DOCBROKER, DOC_BROKER);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_USERNAME, USER_NAME);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_PASSWORD, PASSWORD);
    connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_OBJECT_TYPE, objectType);
    return connectionInfo;
  }

  private String insertTestDocWithAttributes() throws AttributeListParseException, DocumentManagerException, TransformerException, IOException {
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile("RequestXML_WillNotBeUsedByThisUT");
    mockHelper.addClientFile(TEST_DOC_ATTACHMENT);
    transformDctmSpecificAttrsForInsert();
    ResponseEntity responseEntity = new InsertDocumentumResponseEntity();
    documentumService.insert(insertRequestEntity, responseEntity, mockHelper);
    responseEntity.sendResponseToClient(mockHelper);
    Document responseDoc = mockHelper.getXML();
    return getObjectIdOfInsertedDocument(responseDoc);
  }

  private String getObjectIdOfInsertedDocument(Document responseDoc) throws TransformerException {
    String expression = "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value";
    Object objId = XPathAPI.eval(responseDoc, expression);
    return objId.toString();
  }

  private void initRequestEntityForInsert(String fileName, ConnectionInfo connectionInfo) {
    insertRequestEntity = new InsertDocumentumRequestEntity();
    insertRequestEntity.getDocumentAttributes().addAttribute("name", fileName, null);
    insertRequestEntity.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TITLE_ATTRIBUTE_VALUE, null);
    insertRequestEntity.getDocumentAttributes().addAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT, SUB_ATTRIBUTE_VALUE, null);
    insertRequestEntity.setConnectionInfo(connectionInfo);
  }

  private void transformDctmSpecificAttrsForInsert() throws AttributeListParseException, DocumentManagerException {
    AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
    List nameTransformationList = attributeTransformer.getTransformationList();
    insertRequestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
  }

  private void transformDctmSpecificAttrsForRetrieve() throws AttributeListParseException, DocumentManagerException {
    AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
    List nameTransformationList = attributeTransformer.getTransformationList();
    retrieveRequestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
  }
}