package com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.DocBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.AttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.retrieveService.RetrieveDocumentPOS;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumAttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumService;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.DFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.builder.RetrieveDocumentumBuilder;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.RetrieveDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.RetrieveDocumentumResponseEntity;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rgeorge
 * Date: Mar 29, 2006
 * Time: 1:38:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class RetrieveDocumentPOS_UT extends XMLTestCase {

  private static final String TEST_RETRIEVE_REQUEST_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/retrieveDocumentumDoc/tests/TestRetrieveDocRequest.xml";
  private static final String TEST_RETRIEVE_REQUEST_XML_2 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/retrieveDocumentumDoc/tests/TestRetrieveDocRequest2.xml";
  private static final String TEST_INPUT_REQUEST_XML_1 = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/TestInsertDocRequest.xml";

  RetrieveDocumentPOS retrieveDocumentPOS;
  DocumentumService documentumService;
  ConnectionInfo connectionInfo;
  RetrieveDocumentumRequestEntity requestEntity;
  MockUCCHelper mockHelper;

  private static final String CABINET = "/POS Test";
  private static final String DOC_BASE = "stltst03";
  private static final String DOC_BROKER = "stddma00.monsanto.com";
  private static final String USER_NAME = "devl30";
  private static final String PASSWORD = "devl30";
  private static final String OBJECT_TYPE = "dm_document";
  private static final String RETRIEVE_DOCUMENT_SCHEMA_LOCATION = "com/monsanto/tcc/documentmanagementserver_version2/xmlSchemas/RetrieveDocumentRequest.xsd";
  private static final String INVALID_OBJECT_ID = "11111abcdefgh222";
  private static final String EMPTY_OBJECT_ID = "";
  private static final String INVALID_OBJECT_ID_1 = "101";
  private static final String OBJECT_ID = "objectId";
  private static final String DOCUMENTUM_STRING = "Dctm";
  private static final String DOMINO_STRING = "Domino";

  private String PDF_OBJECT_ID;
  private static final String PDF_DOCUMENT_NAME = "testsigpagemeadiaserviceswordtest2.pdf";
  private static final String PDF_ATTACHMENT = "com/monsanto/tcc/documentmanagementserver_version2/documentum/retrieveDocumentumDoc/tests/" + PDF_DOCUMENT_NAME;

  private InsertDocumentumRequestEntity insertRequestEntity;

  public void setUp() throws IOException, DocumentManagerException, AttributeListParseException, TransformerException {
    retrieveDocumentPOS = new RetrieveDocumentPOS();
    documentumService = new DocumentumService(getConnectionParams());
    mockHelper = new MockUCCHelper(null);
    insertRequestEntity = new InsertDocumentumRequestEntity();
    //PDF_OBJECT_ID = insertPDFDocument();
  }

  protected void tearDown() throws Exception {
    IDFCServices service = new DFCServices(DOC_BROKER, USER_NAME, PASSWORD, DOC_BASE, CABINET, OBJECT_TYPE);
    service.connect();
    try {
      service.beginTransaction();
      service.deleteByName(PDF_DOCUMENT_NAME, OBJECT_TYPE);
      service.commitTransaction();
    } catch (Exception e) {
      service.rollbackTransaction();
    } finally{
      service.close();
    }
  }

  public void testCorrectBuilderInitializedForRetrievingDocuments() throws ServiceConfigException, ParserException {
    Document inputDoc = DOMUtil.newDocument(TEST_RETRIEVE_REQUEST_XML_1);
    assertNotNull(retrieveDocumentPOS.getBuilder(inputDoc).getClass());
    assertEquals(RetrieveDocumentumBuilder.class, retrieveDocumentPOS.getBuilder(inputDoc).getClass());
  }

  public void testCheckDocumentumBuilderInitializationNoException(){
    DocBuilder docBuilder = null;
    try {
      docBuilder = retrieveDocumentPOS.getRepositorySpecificBuilder(DOCUMENTUM_STRING);
    } catch (ServiceConfigException e) {
      assertFalse(true);
    }
    assertTrue(docBuilder instanceof RetrieveDocumentumBuilder);
  }

  public void testCheckDocumentumBuilderInitializationThrowsException(){
    try {
      retrieveDocumentPOS.getRepositorySpecificBuilder(DOMINO_STRING);
    } catch (ServiceConfigException e) {
      assertTrue(true);
    }
  }

  public void testExceptionThrownIfBuilderImplementationNotFound() throws Exception {
    try {
      Document inputDoc = DOMUtil.newDocument(TEST_RETRIEVE_REQUEST_XML_2);
      retrieveDocumentPOS.getBuilder(inputDoc);
      fail("Builder not initailized, Service Exception NOT thrown.");
    } catch (ServiceConfigException e) {
      assertTrue(true);
      assertEquals("No service found for specified folder: \"null\"",e.getMessage());
    }
  }

  public void testRetrieveDocumentWithValidInputRequest() throws IOException, SAXException, DocumentManagerException, AttributeListParseException, TransformerException {
    ResponseEntity responseEntity = new RetrieveDocumentumResponseEntity();
    PDF_OBJECT_ID = insertPDFDocument();
    initRequestEntity(PDF_OBJECT_ID);
    transformDctmSpecificAttrs();
    retrieveDocumentPOS.performOperation(requestEntity, documentumService, responseEntity, mockHelper);
    responseEntity.sendResponseToClient(mockHelper);
    Document responseDocument = DOMUtil.newDocument(mockHelper.getInputStream(""));
    validateResponse(responseDocument);
  }

  public void testRetrieveOperationExecutedUnSucessfullyNoObjectIdSpecified() {
    initRequestEntity(EMPTY_OBJECT_ID);
    try {
      ResponseEntity responseEntity = new RetrieveDocumentumResponseEntity();
      retrieveDocumentPOS.performOperation(requestEntity, documentumService, responseEntity, mockHelper);
      fail("No ObjectId specified, Exception Not Thrown");
    } catch (DocumentManagerException e) {
      assertTrue(true);
    }
  }

  public void testRetrieveOperationExecutedUnSucessfullyInvalidObjectIdSpecified() {
    initRequestEntity(INVALID_OBJECT_ID_1);
    try {
      ResponseEntity responseEntity = new RetrieveDocumentumResponseEntity();
      retrieveDocumentPOS.performOperation(requestEntity, documentumService, responseEntity, mockHelper);
      fail("Invalid ObjectId, Exception Not Thrown");
    } catch (DocumentManagerException e) {
      assertTrue(true);
    }
  }

  public void testRetrieveOperationExecutedUnSucessfullyInvalidObjectIdCompleteSpecified() {
    initRequestEntity(INVALID_OBJECT_ID);
    try {
      ResponseEntity responseEntity = new RetrieveDocumentumResponseEntity();
      retrieveDocumentPOS.performOperation(requestEntity, documentumService, responseEntity, mockHelper);
      fail("Invalid ObjectId, Exception Not Thrown");
    } catch (DocumentManagerException e) {
      assertTrue(true);
    }
  }

  public void testSchemaRequiredForRetrievingDocuments(){
    String schemaLocation = retrieveDocumentPOS.getXMLSchemaRelativeToServletContext();
    assertNotNull(schemaLocation);
    assertEquals(RETRIEVE_DOCUMENT_SCHEMA_LOCATION,schemaLocation);
  }

  public void testErrorResponseGeneratedForSchemaValidationFailing() throws Exception {
    Document responseDoc;
    mockHelper.addClientFile(TEST_INPUT_REQUEST_XML_1);
    retrieveDocumentPOS.run(mockHelper);
    responseDoc = mockHelper.getXML();
    checkErrorResponseGenerated(responseDoc);
    assertXpathExists("/ERROR/ERROR_MESSAGE", responseDoc);
  }

  private void validateResponse(Document responseDocument) throws TransformerException {
    assertXpathExists("/documentManagerResponse/retrieveDocument/documentDetails/attribute[name='" + DocumentManagerConstants.ATTR_STR_CONTENTS + "']/value", responseDocument);
    assertXpathEvaluatesTo(PDF_DOCUMENT_NAME, "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name='" + DocumentManagerConstants.ATTR_STR_NAME + "']/value", responseDocument);
    assertXpathEvaluatesTo(PDF_OBJECT_ID, "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name='" + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value", responseDocument);
  }

  private String insertPDFDocument() throws AttributeListParseException, IOException, TransformerException, DocumentManagerException {
    initRequestEntityForInsert(PDF_DOCUMENT_NAME, getConnectionParams());
    return insertTestDocWithAttributes();
  }

  private String insertTestDocWithAttributes() throws AttributeListParseException, DocumentManagerException, TransformerException, IOException {
    mockHelper = new MockUCCHelper(null);
    mockHelper.addClientFile("RequestXML_WillNotBeUsedByThisUT");
    mockHelper.addClientFile(PDF_ATTACHMENT);
    transformDctmSpecificAttrsForInsert();
    ResponseEntity responseEntity = new InsertDocumentumResponseEntity();
    documentumService.insert(insertRequestEntity, responseEntity, mockHelper);
    responseEntity.sendResponseToClient(mockHelper);
    Document responseDoc = mockHelper.getXML();
    return getObjectIdOfInsertedDocument(responseDoc);
  }

  private void transformDctmSpecificAttrsForInsert() throws AttributeListParseException, DocumentManagerException {
    AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
    List nameTransformationList = attributeTransformer.getTransformationList();
    insertRequestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
  }

  private String getObjectIdOfInsertedDocument(Document responseDoc) throws TransformerException {
    String expression = "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value";
    Object objId = XPathAPI.eval(responseDoc, expression);
    return objId.toString();
  }

  private void initRequestEntityForInsert(String fileName, ConnectionInfo connectionInfo) {
    insertRequestEntity = new InsertDocumentumRequestEntity();
    insertRequestEntity.getDocumentAttributes().addAttribute("name", fileName, null);
    insertRequestEntity.setConnectionInfo(connectionInfo);
  }

  private void transformDctmSpecificAttrs() throws AttributeListParseException, DocumentManagerException {
    AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
    List nameTransformationList = attributeTransformer.getTransformationList();
    requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
  }

  private ConnectionInfo getConnectionParams() {
    ConnectionInfo connectionInfo = new ConnectionInfo();
    connectionInfo.addConnectionParameter("cabinet", CABINET);
    connectionInfo.addConnectionParameter("docBase", DOC_BASE);
    connectionInfo.addConnectionParameter("docBroker", DOC_BROKER);
    connectionInfo.addConnectionParameter("userName", USER_NAME);
    connectionInfo.addConnectionParameter("password", PASSWORD);
    connectionInfo.addConnectionParameter("objectType", OBJECT_TYPE);
    return connectionInfo;
  }

  private void initRequestEntity(String objectId) {
    requestEntity = new RetrieveDocumentumRequestEntity();
    requestEntity.getDocumentAttributes().addAttribute(OBJECT_ID, objectId, null);
    requestEntity.setConnectionInfo(connectionInfo);
  }

  private void checkErrorResponseGenerated(Document responseDoc) throws TransformerException {
    assertXpathExists("/ERROR", responseDoc);
    assertXpathEvaluatesTo("-1", "/ERROR/ERROR_CODE", responseDoc);
    assertXpathExists("/ERROR/ERROR_MESSAGE", responseDoc);
    assertXpathExists("/ERROR/STACK_TRACE", responseDoc);
  }
}