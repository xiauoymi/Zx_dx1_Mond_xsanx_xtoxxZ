package com.monsanto.tcc.documentmanagementserver_version2.documentum.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.RetrievedDocument;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.AttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.DocumentManagerException;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumAttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.DocumentumService;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.DFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.IDFCServices;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.RetrieveDocumentumResponseEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.searchDocumentumDocs.entity.SearchDocumentumRequestEntity;
import junit.framework.TestCase;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: May 5, 2006
 * Time: 10:04:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class SearchService_UT extends TestCase {

    InsertDocumentumRequestEntity insertRequestEntity1;
    InsertDocumentumRequestEntity insertRequestEntity2;
    InsertDocumentumRequestEntity insertRequestEntity3;
    SearchDocumentumRequestEntity searchRequestEntity;
    ResponseEntity responseEntity;
    DocumentumService documentumService;
    ConnectionInfo connectionInfo;
    MockUCCHelper mockHelper;

    private static final String CABINET = "/POS Test";
    private static final String DOC_BASE = "stltst03";
    private static final String DOC_BROKER = "stddma00.monsanto.com";
    private static final String USER_NAME = "devl30";
    private static final String PASSWORD = "devl30";
    private static final String OBJECT_TYPE = "dm_document";

    private static final String TEST_DOC_ATTACHMENT = "com/monsanto/tcc/documentmanagementserver_version2/documentum/insertDocumentumDoc/tests/test2.doc";

    private static final String FILE_NAME_1 = "attachment1";
    private static final String FILE_NAME_2 = "attachment2";
    private static final String FILE_NAME_3 = "attachment3";

    private String objectId1;
    private String objectId2;
    private String objectId3;
    private static final List KEYWORDS1 = new ArrayList();
    private static final List KEYWORDS2 = new ArrayList();
    private static final List KEYWORDS3 = new ArrayList();
    private static final String SUB_DOC_1 = "farm resource";
    private static final String SUB_DOC_2 = "farm resource";
    private static final String SUB_DOC_3 = "crop details";
    private static final String TITLE_QUERY_ATTR_VALUE = "monsanto search docs";
    private static final String SUBJECT_QUERY_ATTR_VALUE = "farm resource";
    private static final String KEYWORD_QUERY_ATTR_VALUE = "farm";

    protected void setUp() throws IOException, AttributeListParseException, TransformerException,
                                  DocumentManagerException {
        connectionInfo = getConnectionParams(OBJECT_TYPE);
        insertTestDocumentsForQuerying();
    }

    protected void tearDown() throws Exception {
        deleteInsertedDocuments();
    }

    private void deleteInsertedDocuments() throws DocumentManagerException {
        IDFCServices service = new DFCServices(DOC_BROKER, USER_NAME, PASSWORD, DOC_BASE, CABINET, OBJECT_TYPE);
        service.connect();
        try {
            service.beginTransaction();
            service.deleteByName(FILE_NAME_1, OBJECT_TYPE);
            service.deleteByName(FILE_NAME_2, OBJECT_TYPE);
            service.deleteByName(FILE_NAME_3, OBJECT_TYPE);
            service.commitTransaction();
            service.beginTransaction();
            service.deleteByName("testFolder", "dm_folder");
            service.deleteByName("testSearchDir", "dm_folder");
            service.commitTransaction();
        } catch (Exception e) {
            service.rollbackTransaction();
        } finally {
            service.close();
        }
    }

    public void testSearchFunctionality_SingleValuedQueryAttribute_Subject() throws Exception {
        initializeRequestEntityForQueryAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT, SUBJECT_QUERY_ATTR_VALUE);
        transformDctmSpecificAttrs(searchRequestEntity);
        ResponseEntity responseEntity = new RetrieveDocumentumResponseEntity();
        documentumService = new DocumentumService(getConnectionParams(OBJECT_TYPE));
        documentumService.search(searchRequestEntity, responseEntity, mockHelper);
        responseEntity.backTransformCoreAttributeNames();
        if (validateSearchResponseForSubject(responseEntity) != 2) {
            fail("Search results are not as expected");
        }
    }

    public void testSearchFunctionality_MultipleValuedQueryAttribute_Keywords() throws Exception {
        initializeRequestEntityForQueryAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, KEYWORD_QUERY_ATTR_VALUE);
        transformDctmSpecificAttrs(searchRequestEntity);
        ResponseEntity responseEntity = new RetrieveDocumentumResponseEntity();
        documentumService = new DocumentumService(getConnectionParams(OBJECT_TYPE));
        documentumService.search(searchRequestEntity, responseEntity, mockHelper);
        responseEntity.backTransformCoreAttributeNames();
        if (validateSearchResponseForKeywords(responseEntity) != 2) {
            fail("Search results are not as expected");
        }
    }

    public void testSearchFunctionality_WithoutAnyQueryAttribute_ReturnsAllDocuments() throws Exception {
        initializeRequestEntityWithoutQueryAttribute();
        transformDctmSpecificAttrs(searchRequestEntity);
        ResponseEntity responseEntity = new RetrieveDocumentumResponseEntity();
        documentumService = new DocumentumService(getConnectionParams(OBJECT_TYPE));
        documentumService.search(searchRequestEntity, responseEntity, mockHelper);
        responseEntity.backTransformCoreAttributeNames();
        if (validateSearchResponseThatReturnsAllDocuments(responseEntity) != 3) {
            fail("Search results are not as expected");
        }
    }

    public void testSearchFunctionality_MultipleQueryAttributes_RelatedBy_AND() throws Exception {
        initializeRequestEntityMultipleQueryAttribute();
        transformDctmSpecificAttrs(searchRequestEntity);
        ResponseEntity responseEntity = new RetrieveDocumentumResponseEntity();
        documentumService = new DocumentumService(getConnectionParams(OBJECT_TYPE));
        documentumService.search(searchRequestEntity, responseEntity, mockHelper);
        responseEntity.backTransformCoreAttributeNames();
        validateNumberOfDocumentsReturned(1, responseEntity);
        validateDocument1(
                ((RetrievedDocument) responseEntity.getRetrievedDocumentList().get(0)).getDocumentAttributes());
    }

    private void validateNumberOfDocumentsReturned(int numberOfRetrievedDocuments, ResponseEntity responseEntity) {
        assertEquals(numberOfRetrievedDocuments, responseEntity.getRetrievedDocumentList().size());
    }

    private int validateSearchResponseThatReturnsAllDocuments(ResponseEntity responseEntity) throws
                                                                                             AttributeListParseException {
        int validDocumentsReturned = 0;
        List listOfRetrievedDocs = responseEntity.getRetrievedDocumentList();
        for (int i = 0; i < listOfRetrievedDocs.size(); i++) {
            RetrievedDocument retrievedDocument = (RetrievedDocument) listOfRetrievedDocs.get(i);
            DocumentAttributes documentAttributes = retrievedDocument.getDocumentAttributes();
            String documentId = documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
            if (documentId.equalsIgnoreCase(objectId1)) {
                validateDocument1(documentAttributes);
                validDocumentsReturned++;
            }
            if (documentId.equalsIgnoreCase(objectId2)) {
                validateDocument2(documentAttributes);
                validDocumentsReturned++;
            }
            if (documentId.equalsIgnoreCase(objectId3)) {
                validateDocument3(documentAttributes);
                validDocumentsReturned++;
            }
        }
        return validDocumentsReturned;
    }

    private int validateSearchResponseForSubject(ResponseEntity responseEntity) throws AttributeListParseException {
        int validDocumentsReturned = 0;
        List listOfRetrievedDocs = responseEntity.getRetrievedDocumentList();
        for (int i = 0; i < listOfRetrievedDocs.size(); i++) {
            RetrievedDocument retrievedDocument = (RetrievedDocument) listOfRetrievedDocs.get(i);
            DocumentAttributes documentAttributes = retrievedDocument.getDocumentAttributes();
            String documentId = documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
            if (documentId.equalsIgnoreCase(objectId1)) {
                validateDocument1(documentAttributes);
                validDocumentsReturned++;
            }
            if (documentId.equalsIgnoreCase(objectId2)) {
                validateDocument2(documentAttributes);
                validDocumentsReturned++;
            }
        }
        return validDocumentsReturned;
    }

    private int validateSearchResponseForKeywords(ResponseEntity responseEntity) throws AttributeListParseException {
        int validDocumentsReturned = 0;
        List listOfRetrievedDocs = responseEntity.getRetrievedDocumentList();
        for (int i = 0; i < listOfRetrievedDocs.size(); i++) {
            RetrievedDocument retrievedDocument = (RetrievedDocument) listOfRetrievedDocs.get(i);
            DocumentAttributes documentAttributes = retrievedDocument.getDocumentAttributes();
            String documentId = documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID);
            if (documentId.equalsIgnoreCase(objectId1)) {
                validateDocument1(documentAttributes);
                validDocumentsReturned++;
            }
            if (documentId.equalsIgnoreCase(objectId3)) {
                validateDocument3(documentAttributes);
                validDocumentsReturned++;
            }
        }
        return validDocumentsReturned;
    }

    private void validateDocument1(DocumentAttributes documentAttributes) throws AttributeListParseException {
        validateTitle(documentAttributes);
        validateSize(documentAttributes);
        validateCreator(documentAttributes);
        validateSubject(SUB_DOC_1, documentAttributes);
        validateKeywords(KEYWORDS1, documentAttributes);
    }

    private void validateCreator(DocumentAttributes documentAttributes) throws AttributeListParseException {
        assertEquals("devl30", documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_CREATOR));
    }

    private void validateSize(DocumentAttributes documentAttributes) throws AttributeListParseException {
        assertEquals("19968", documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_SIZE));
    }

    private void validateDocument2(DocumentAttributes documentAttributes) throws AttributeListParseException {
        validateTitle(documentAttributes);
        validateSize(documentAttributes);
        validateCreator(documentAttributes);
        validateSubject(SUB_DOC_2, documentAttributes);
        validateKeywords(KEYWORDS2, documentAttributes);
    }

    private void validateDocument3(DocumentAttributes documentAttributes) throws AttributeListParseException {
        validateTitle(documentAttributes);
        validateSize(documentAttributes);
        validateCreator(documentAttributes);
        validateSubject(SUB_DOC_3, documentAttributes);
        validateKeywords(KEYWORDS3, documentAttributes);
    }

    private void validateKeywords(List keywords1, DocumentAttributes documentAttributes) throws
                                                                                         AttributeListParseException {
        List actualKeywords = documentAttributes.getAttrValues(DocumentManagerConstants.ATTR_STR_KEYWORDS);
        for (int i = 0; i < keywords1.size(); i++) {
            String expectedKeyword = (String) keywords1.get(i);
            assertEquals(expectedKeyword, actualKeywords.get(i));
        }
    }

    private void validateSubject(String subject, DocumentAttributes documentAttributes) throws
                                                                                        AttributeListParseException {
        assertEquals(subject, documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_SUBJECT));
    }

    private void validateTitle(DocumentAttributes documentAttributes) throws AttributeListParseException {
        assertEquals(TITLE_QUERY_ATTR_VALUE, documentAttributes.getAttrValue(DocumentManagerConstants.ATTR_STR_TITLE));
    }

    private void initializeRequestEntityForQueryAttribute(String queryAttrName, String queryAttrValue) {
        searchRequestEntity = new SearchDocumentumRequestEntity();
        searchRequestEntity.setConnectionInfo(connectionInfo);
        searchRequestEntity.setDirectoryStructure("testSearchDir/testFolder");
        addQueryAttribute(queryAttrName, queryAttrValue, DocumentManagerConstants.OPERATOR_EQUALS);
        String[] requiredAttrs = {DocumentManagerConstants.ATTR_STR_CREATOR,
                                  DocumentManagerConstants.ATTR_STR_SUBJECT,
                                  DocumentManagerConstants.ATTR_STR_SIZE,
                                  DocumentManagerConstants.ATTR_STR_KEYWORDS,
                                  DocumentManagerConstants.ATTR_STR_TITLE};
        addRequiredAttributes(requiredAttrs);
    }

    private void initializeRequestEntityMultipleQueryAttribute() {
        searchRequestEntity = new SearchDocumentumRequestEntity();
        searchRequestEntity.setConnectionInfo(connectionInfo);
        searchRequestEntity.setDirectoryStructure("testSearchDir/testFolder");
        addQueryAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, KEYWORD_QUERY_ATTR_VALUE,
                          DocumentManagerConstants.OPERATOR_EQUALS);
        addQueryAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT, SUBJECT_QUERY_ATTR_VALUE,
                          DocumentManagerConstants.OPERATOR_EQUALS);
        String[] requiredAttrs = {DocumentManagerConstants.ATTR_STR_CREATOR,
                                  DocumentManagerConstants.ATTR_STR_SUBJECT,
                                  DocumentManagerConstants.ATTR_STR_SIZE,
                                  DocumentManagerConstants.ATTR_STR_KEYWORDS,
                                  DocumentManagerConstants.ATTR_STR_TITLE};
        addRequiredAttributes(requiredAttrs);
    }

    private void initializeRequestEntityWithoutQueryAttribute() {
        searchRequestEntity = new SearchDocumentumRequestEntity();
        searchRequestEntity.setConnectionInfo(connectionInfo);
        searchRequestEntity.setDirectoryStructure("testSearchDir/testFolder");
        String[] requiredAttrs = {DocumentManagerConstants.ATTR_STR_CREATOR,
                                  DocumentManagerConstants.ATTR_STR_SUBJECT,
                                  DocumentManagerConstants.ATTR_STR_SIZE,
                                  DocumentManagerConstants.ATTR_STR_KEYWORDS,
                                  DocumentManagerConstants.ATTR_STR_TITLE};
        addRequiredAttributes(requiredAttrs);
    }

    private void addRequiredAttributes(String[] requiredAttrs) {
        for (int i = 0; i < requiredAttrs.length; i++) {
            String requiredAttr = requiredAttrs[i];
            searchRequestEntity.getRequiredAttributes().add(requiredAttr);
        }
    }

    private void addQueryAttribute(String attrName, String attrValue, String operator) {
        searchRequestEntity.getDocumentAttributes().addAttribute(attrName, attrValue, operator);
    }

    private void insertTestDocumentsForQuerying() throws AttributeListParseException, TransformerException, IOException,
                                                         DocumentManagerException {
        deleteInsertedDocuments();
        objectId1 = insertDocument1();
        objectId2 = insertDocument2();
        objectId3 = insertDocument3();
    }

    private String insertDocument1() throws AttributeListParseException, IOException, TransformerException,
                                            DocumentManagerException {
        insertRequestEntity1 = new InsertDocumentumRequestEntity();
        insertRequestEntity1.setConnectionInfo(connectionInfo);
        insertRequestEntity1.setDirectoryStructure("testSearchDir/testFolder");
        insertRequestEntity1.getDocumentAttributes().addAttribute("name", FILE_NAME_1, null);
        insertRequestEntity1.getDocumentAttributes()
                .addAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TITLE_QUERY_ATTR_VALUE, null);
        insertRequestEntity1.getDocumentAttributes()
                .addAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT, SUB_DOC_1, null);
        KEYWORDS1.add("farm");
        KEYWORDS1.add("field");
        insertRequestEntity1.getDocumentAttributes()
                .addAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, KEYWORDS1, null);
        transformDctmSpecificAttrs(insertRequestEntity1);
        return insertTestDocument(insertRequestEntity1);
    }

    private String insertDocument2() throws AttributeListParseException, IOException, TransformerException,
                                            DocumentManagerException {
        insertRequestEntity2 = new InsertDocumentumRequestEntity();
        insertRequestEntity2.setConnectionInfo(connectionInfo);
        insertRequestEntity2.setDirectoryStructure("testSearchDir/testFolder");
        insertRequestEntity2.getDocumentAttributes().addAttribute("name", FILE_NAME_2, null);
        insertRequestEntity2.getDocumentAttributes()
                .addAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TITLE_QUERY_ATTR_VALUE, null);
        insertRequestEntity2.getDocumentAttributes()
                .addAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT, SUB_DOC_2, null);
        KEYWORDS2.add("crop");
        KEYWORDS2.add("manure");
        KEYWORDS2.add("pesticide");
        insertRequestEntity2.getDocumentAttributes()
                .addAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, KEYWORDS2, null);
        transformDctmSpecificAttrs(insertRequestEntity2);
        return insertTestDocument(insertRequestEntity2);
    }

    private String insertDocument3() throws AttributeListParseException, IOException, TransformerException,
                                            DocumentManagerException {
        insertRequestEntity3 = new InsertDocumentumRequestEntity();
        insertRequestEntity3.setConnectionInfo(connectionInfo);
        insertRequestEntity3.setDirectoryStructure("testSearchDir/testFolder");
        insertRequestEntity3.getDocumentAttributes().addAttribute("name", FILE_NAME_3, null);
        insertRequestEntity3.getDocumentAttributes()
                .addAttribute(DocumentManagerConstants.ATTR_STR_TITLE, TITLE_QUERY_ATTR_VALUE, null);
        insertRequestEntity3.getDocumentAttributes()
                .addAttribute(DocumentManagerConstants.ATTR_STR_SUBJECT, SUB_DOC_3, null);
        KEYWORDS3.add("manure");
        KEYWORDS3.add("farm");
        insertRequestEntity3.getDocumentAttributes()
                .addAttribute(DocumentManagerConstants.ATTR_STR_KEYWORDS, KEYWORDS3, null);
        transformDctmSpecificAttrs(insertRequestEntity3);
        return insertTestDocument(insertRequestEntity3);
    }

    private String insertTestDocument(RequestEntity requestEntity) throws AttributeListParseException,
                                                                          DocumentManagerException,
                                                                          TransformerException, IOException {
        mockHelper = new MockUCCHelper(null);
        mockHelper.addClientFile("RequestXML_WillNotBeUsedByThisUT");
        mockHelper.addClientFile(TEST_DOC_ATTACHMENT);
        ResponseEntity responseEntity = new InsertDocumentumResponseEntity();
        documentumService = new DocumentumService(getConnectionParams(OBJECT_TYPE));
        documentumService.insert(requestEntity, responseEntity, mockHelper);
        responseEntity.sendResponseToClient(mockHelper);
        Document responseDoc = mockHelper.getXML();
        return getObjectIdOfInsertedDocument(responseDoc);
    }

    private void transformDctmSpecificAttrs(RequestEntity requestEntity) throws AttributeListParseException,
                                                                                DocumentManagerException {
        AttributeTransformer attributeTransformer = new DocumentumAttributeTransformer();
        List nameTransformationList = attributeTransformer.getTransformationList();
        requestEntity.transformAttrNamesToServiceSpecificAttrNames(nameTransformationList);
    }

    private String getObjectIdOfInsertedDocument(Document responseDoc) throws TransformerException {
        String expression = "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" +
                            DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + "']/value";
        Object objId = XPathAPI.eval(responseDoc, expression);
        return objId.toString();
    }

    private ConnectionInfo getConnectionParams(String objectType) {
        connectionInfo = new ConnectionInfo();
        connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_CABINET, CABINET);
        connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_DOCBASE, DOC_BASE);
        connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_DOCBROKER, DOC_BROKER);
        connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_USERNAME, USER_NAME);
        connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_PASSWORD, PASSWORD);
        connectionInfo.addConnectionParameter(DocumentManagerConstants.STRING_OBJECT_TYPE, objectType);
        return connectionInfo;
    }
}