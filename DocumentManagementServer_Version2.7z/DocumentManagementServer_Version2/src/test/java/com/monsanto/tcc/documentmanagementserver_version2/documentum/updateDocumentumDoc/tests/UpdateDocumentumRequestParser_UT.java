/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.tests;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.parser.UpdateDocumentumRequestParser;
import junit.framework.TestCase;
import org.w3c.dom.Document;

import java.io.IOException;

/**
 * Filename:    $RCSfile: UpdateDocumentumRequestParser_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: ussing $    	 On:	$Date: 2007-11-15 23:34:29 $
 *
 * @author ussing
 * @version $Revision: 1.1 $
 */
public class UpdateDocumentumRequestParser_UT extends TestCase {
  private static final String TEST_UPDATE_REQUEST_XML_WITH_PDF_TRUE = "com/monsanto/tcc/documentmanagementserver_version2/documentum/updateDocumentumDoc/tests/TestUpdateDocRequestWithPDFRenditionTrue.xml";
  private static final String TEST_UPDATE_REQUEST_XML_WITHOUT_PDF = "com/monsanto/tcc/documentmanagementserver_version2/documentum/updateDocumentumDoc/tests/TestUpdateDocRequestWithNoPDFRendition.xml";
  private static final String TEST_UPDATE_REQUEST_XML_WITH_PDF_FALSE = "com/monsanto/tcc/documentmanagementserver_version2/documentum/updateDocumentumDoc/tests/TestUpdateDocRequestWithPDFRenditionFalse.xml";
  UpdateDocumentumRequestParser requestParser;
  UpdateDocumentumRequestEntity requestEntity;

  protected void setUp() throws IOException {
    requestParser = new MockUpdateDocumentumRequestParser();
    requestEntity = new UpdateDocumentumRequestEntity();
  }

  public void testRequestPDFRenditionTrue() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_UPDATE_REQUEST_XML_WITH_PDF_TRUE);
    requestParser.parseInputXML(inputDocument, requestEntity);
    assertTrue(requestEntity.getRequestPDFRendition());
  }

  public void testRequestPDFRenditionDefaultsToFalse() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_UPDATE_REQUEST_XML_WITHOUT_PDF);
    requestParser.parseInputXML(inputDocument, requestEntity);
    assertFalse(requestEntity.getRequestPDFRendition());
  }

  public void testRequestPDFRenditionFalse() throws Exception {
    Document inputDocument = DOMUtil.newDocument(TEST_UPDATE_REQUEST_XML_WITH_PDF_FALSE);
    requestParser.parseInputXML(inputDocument, requestEntity);
    assertFalse(requestEntity.getRequestPDFRendition());
  }
}