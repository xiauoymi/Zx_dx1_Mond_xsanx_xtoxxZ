/*
 MitratechAdapterAuthFilter_UT was created on Sep 22, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.documentmanagementserver_version2.mitratech.tests;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.tcc.documentmanagementserver_version2.mitratech.MitratechAdapter;
import com.monsanto.tcc.documentmanagementserver_version2.mitratech.MitratechAdapterAuthFilter;
import junit.framework.TestCase;
import org.ietf.jgss.GSSException;

import javax.servlet.ServletRequest;
import javax.servlet.FilterChain;
import javax.servlet.ServletResponse;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Filename:    $RCSfile: MitratechAdapterAuthFilter_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2006-11-10 16:48:26 $
 *
 * @author VRBETHI
 * @version $Revision: 1.2 $
 */
public class MitratechAdapterAuthFilter_UT extends TestCase {

  public MitratechAdapterAuthFilter_UT(String name) {
    super(name);
  }

  public void testFilterAddsSystemSecurityProxyToSession() throws Exception {
    MitratechAdapterAuthFilter filter = new MockMitratechAdapterAuthFilter();
    HttpServletRequest request = new MockHttpRequest();
    filter.doFilter(request, null, new MockFilterChain());
    SystemSecurityProxy proxy = (SystemSecurityProxy) request.getSession().getAttribute(
            MitratechAdapter.SYSTEM_SECURITY_PROXY);
    assertNotNull(proxy);
    String expectedUserid = System.getProperty("user.name").toLowerCase();
    assertEquals(expectedUserid, proxy.getUserID());
  }

  class MockMitratechAdapterAuthFilter extends MitratechAdapterAuthFilter {

    protected SystemSecurityProxy createSystemSecurityProxy(ServletRequest servletRequest) {
      try {
        return new KerberosStandaloneCredential();
      } catch (GSSException e) {
        fail();
      }
      return null;
    }
  }

  class MockFilterChain implements FilterChain {

    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse) throws IOException, ServletException {
      //no-op
    }
  }
}