/*
 MitratechMockHttpSession was created on Sep 22, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.documentmanagementserver_version2.mitratech.tests;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.tcc.documentmanagementserver_version2.mitratech.MitratechAdapter;
import junit.framework.Assert;
import org.ietf.jgss.GSSException;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;
import java.util.Enumeration;

/**
 * Filename:    $RCSfile: MockMitratechHttpSession.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2006-09-22 19:10:16 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class MockMitratechHttpSession implements HttpSession {

    public long getCreationTime() {
        return 0;
    }

    public String getId() {
        return null;
    }

    public long getLastAccessedTime() {
        return 0;
    }

    public ServletContext getServletContext() {
        return null;
    }

    public void setMaxInactiveInterval(int i) {
    }

    public int getMaxInactiveInterval() {
        return 0;
    }

    public HttpSessionContext getSessionContext() {
        return null;
    }

    public Object getAttribute(String attributeTag) {
        if (attributeTag.equals(MitratechAdapter.SYSTEM_SECURITY_PROXY)) {
            try {
                return new KerberosStandaloneCredential();
            } catch (GSSException e) {
                Assert.fail();
            }
        }
        return null;
    }

    public Object getValue(String s) {
        return null;
    }

    public Enumeration getAttributeNames() {
        return null;
    }

    public String[] getValueNames() {
        return new String[0];
    }

    public void setAttribute(String s, Object o) {
    }

    public void putValue(String s, Object o) {
    }

    public void removeAttribute(String s) {
    }

    public void removeValue(String s) {
    }

    public void invalidate() {
    }

    public boolean isNew() {
        return false;
    }
}