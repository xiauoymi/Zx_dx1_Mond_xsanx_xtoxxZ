package com.monsanto.tcc.documentmanagementserver_version2.testSuite;

import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.deleteSharePointDocs.tests.DeleteDocPOSSP_UT;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.*;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.test.DocumentAttributes_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.tests.ServiceConfigError_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.tests.ServiceLookup_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.tests.DeleteDocPOSServiceException_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.tests.DeletePOSBuilderConfig_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.deleteService.tests.DeletePOSVersionException_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.retrieveService.tests.RetrieveWithRendition_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.retrieveService.tests.RetrieveWithVersion_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.searchService.tests.SearchDocumentsPOS_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.searchService.tests.SearchFullText_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.updateService.tests.UpdateDocumentPOS_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.dctmAttrType.tests.DctmAttrType_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.queryBuilder.tests.DocumentumQueryBuilder_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.dfcServices.tests.DFCServices_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.tests.InsertDocumentumResponseEntity_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.parser.tests.InsertDctmParser_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.tests.InsertDctmRequestEntity_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.tests.InsertDctmService_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.tests.InsertDocPOS_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.tests.InsertDocumentumRequestParser_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.entity.tests.RetrieveDocumentumRequestEntity_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.parser.tests.RetrieveDocumentumRequestParser_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.tests.RetrieveDctmService_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.retrieveDocumentumDoc.tests.RetrieveDocumentPOS_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.tests.SearchService_UT;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.tests.UpdateDocumentumRequestParser_UT;
import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Apr 20, 2006 Time: 12:42:55 PM To change this template use File |
 * Settings | File Templates.
 */
public class DocumentManagementServer_TS extends TestSuite {

  public static Test suite() {
    TestSuite testSuite = new TestSuite();

    testSuite.addTestSuite(DFCServices_UT.class);
    testSuite.addTestSuite(DocumentumQueryBuilder_UT.class);
    testSuite.addTestSuite(DctmAttrType_UT.class);
    testSuite.addTestSuite(DocumentAttributes_UT.class);
    testSuite.addTestSuite(ServiceLookup_UT.class);
    testSuite.addTestSuite(ServiceConfigError_UT.class);

    testSuite.addTestSuite(InsertDocPOS_UT.class);
    testSuite.addTestSuite(InsertDocumentumRequestParser_UT.class);
    testSuite.addTestSuite(InsertDctmRequestEntity_UT.class);
    testSuite.addTestSuite(InsertDctmParser_UT.class);
    testSuite.addTestSuite(InsertDctmService_UT.class);
    testSuite.addTestSuite(InsertDocumentumResponseEntity_UT.class);

    testSuite.addTestSuite(RetrieveDocumentPOS_UT.class);
    testSuite.addTestSuite(RetrieveDocumentumRequestParser_UT.class);
    testSuite.addTestSuite(RetrieveDocumentumRequestEntity_UT.class);
    testSuite.addTestSuite(RetrieveDctmService_UT.class);
    testSuite.addTestSuite(RetrieveWithRendition_UT.class);

    testSuite.addTestSuite(SearchDocumentsPOS_UT.class);
    testSuite.addTestSuite(SearchService_UT.class);

    testSuite.addTestSuite(SearchFullText_UT.class);

    testSuite.addTestSuite(DeletePOSBuilderConfig_UT.class);
    testSuite.addTestSuite(DeleteDocPOSSP_UT.class);
    testSuite.addTestSuite(DeleteDocPOSServiceException_UT.class);
    testSuite.addTestSuite(DeletePOSVersionException_UT.class);

    testSuite.addTestSuite(UpdateDocumentPOS_UT.class);
    testSuite.addTestSuite(UpdateDocumentumRequestParser_UT.class);

    testSuite.addTestSuite(RetrieveWithVersion_UT.class);

    testSuite.addTestSuite(InsertRetrieveDoc_AT.class);
    testSuite.addTestSuite(SearchService_AT.class);
    testSuite.addTestSuite(DeleteService_AT.class);
    testSuite.addTestSuite(UpdateRetrieveDocumentWithVersion_AT.class);
    testSuite.addTestSuite(DocPOSSecurity_AT.class);
    testSuite.addTestSuite(DocPOSGroupSecurity_AT.class);

    testSuite.addTestSuite(Client_AT.class);
    return testSuite;
  }
}