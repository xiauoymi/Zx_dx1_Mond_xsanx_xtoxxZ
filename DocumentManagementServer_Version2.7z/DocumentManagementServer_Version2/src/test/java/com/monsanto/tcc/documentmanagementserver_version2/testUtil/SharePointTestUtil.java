package com.monsanto.tcc.documentmanagementserver_version2.testUtil;

import com.microsoft.schemas.sharepoint.soap.*;
import com.monsanto.Util.FileUtil;
import com.monsanto.Util.StringUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.ServiceConfig.SharePointServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.SharePointAttributeTransformer;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updateSharePointDoc.entity.UpdateSharePointRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.SharePoint.updatesharepointdocs.tests.MockUpdateSharePointRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.apptests.MockInsertDocumentumRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.ConnectionInfo;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.attributeTransformation.TransformationObject;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.AttributeListParseException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.documentAttributes.DocumentAttributes;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.exception.ServiceConfigException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.serviceConfig.IServiceLookup;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.entity.InsertDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.insertDocumentumDoc.parser.InsertDocumentumRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.entity.UpdateDocumentumRequestEntity;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.parser.UpdateDocumentumRequestParser;
import com.monsanto.tcc.documentmanagementserver_version2.documentum.updateDocumentumDoc.tests.MockUpdateDocumentumRequestParser;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.*;

import javax.xml.soap.Detail;
import javax.xml.soap.SOAPFault;
import javax.xml.transform.TransformerException;
import javax.xml.ws.Holder;
import javax.xml.ws.soap.SOAPFaultException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rdesai2 Date: Jun 9, 2006 Time: 10:37:02 AM To change this template use File |
 * Settings | File Templates.
 */
public abstract class SharePointTestUtil {
  private static final String TEST_SERVICE_CONFIG_FILE_NAME = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/serviceConfig/tests/TestServiceConfig.xml";
  public static final String XPATH_BEGIN_STR = "/documentManagerResponse/searchDocuments/documentDetails/attribute[name = '";
  public static final String XPATH_END_STR = "']/value";
  public static final String CONTENTS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";
  private static final String CR_LF = "\r\n";
  private static final String CONTENT_TYPE = "Content Type";
  private static final String FILE_TYPE = "File Type";
  private static final String TYPE = "Type";
  private static final String DOT = ".";

  public static String insertTestDocument(String filePath, String insertRequestXml)
      throws Exception {
    Document inputDoc = DOMUtil.newDocument(insertRequestXml);
    InsertDocumentumRequestParser requestParser = new MockInsertDocumentumRequestParser();
    InsertDocumentumRequestEntity requestEntity = new InsertDocumentumRequestEntity();
    Node requestNode = DOMUtil.getChild(inputDoc.getDocumentElement(), "requestDetails");
    requestParser.parseOperationSpecificRequest(requestNode, requestEntity);
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    String fileNameInSP = documentAttributes.getAttrValue("name");
    System.out.println("fileNameInSP = " + fileNameInSP);
    String folder = getFolderNameFromInputDocument(inputDoc);
    System.out.println("TestUtil.insertTestDocument: folder = " + folder);
    //ToDo: Need to get "directoryStructure" from request document and use it in Destination Url below - the beginnings of this are now in the spike and in SharePointServices
    IServiceLookup serviceLookup = new SharePointServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails(folder, "win");
    String site = connectionInfo.getConnectionParameterValue("site");
    String documentLibrary = connectionInfo.getConnectionParameterValue("documentLibrary");
    CopySoap copySoap = createCopyService(site + "/_vti_bin/Copy.asmx?WSDL");
    DestinationUrlCollection destUrls = setupDestinationUrls(site + "/" + documentLibrary + "/", fileNameInSP);
    FieldInformationCollection fields = new FieldInformationCollection();
    List<FieldInformation> fieldInformationList = fields.getFieldInformation();
    SharePointAttributeTransformer attributeTransformer = new SharePointAttributeTransformer();
    TransformationObject NameTranslation = new TransformationObject(DocumentManagerConstants.ATTR_STR_NAME,
        DocumentManagerConstants.SHAREPOINT_ATTR_STR_NAME);
    String transformedNameName = NameTranslation.getServiceSpecificAttrName();
    addFieldToList(fieldInformationList, transformedNameName, fileNameInSP);
    Iterator iterator = documentAttributes.getAttrIterator();
    while (iterator.hasNext()) {
      String attrName = (String) iterator.next();
      if (documentAttributes.hasMultipleValues(attrName)) {
        //ToDo: Handle multi-value attribute - Need to research this
        System.out.println("TestUtil.insertTestDocument: attrName MULTIPLE = " + attrName);
        List list = documentAttributes.getAttrValues(attrName);
        String valueString = "";
        for (Object aList : list) {
          String attr = (String) aList;
          System.out.println("TestUtil.insertTestDocument: attr = " + attr);
          if (valueString.length() == 0) {
            valueString = attr;
          } else {
//            valueString = valueString + ";#" + attr;
            valueString = valueString + CR_LF + attr;
          }
        }
        System.out.println("SharePointTestUtil.insertTestDocument: valueString = " + valueString);
        addMultiValuedFieldToList(fieldInformationList, attrName, valueString);

      } else {
        String value = documentAttributes.getAttrValue(attrName);
        addFieldToList(fieldInformationList, attrName, value);
      }
    }
    byte[] stream = FileUtil.fileToByteArray(filePath);
    Holder<Long> result = new Holder<Long>();
    Holder<CopyResultCollection> results = new Holder<CopyResultCollection>();
    copySoap.copyIntoItems(destUrls.getString().get(0), destUrls, fields, stream, result, results);
    List<CopyResult> copyResults = results.value.getCopyResult();
    for (CopyResult copyResult : copyResults) {
      System.out.println(
          "SharePointTestUtil.insertTestDocument: copyResult.getErrorMessage() = " + copyResult.getErrorMessage());
      System.out.println(
          "SharePointTestUtil.insertTestDocument: copyResult.getDestinationUrl() = " + copyResult.getDestinationUrl());
      System.out.println("SharePointTestUtil.insertTestDocument: copyResult.getErrorCode().value() = " +
          copyResult.getErrorCode().value());
    }
    forceFirstVersionToBeOneDotZero(fileNameInSP, site, documentLibrary);
    return getID(fileNameInSP, site, documentLibrary);
  }

  public static void checkOutFile(String insertRequestXml) throws Exception {
    Document inputDoc = DOMUtil.newDocument(insertRequestXml);
    InsertDocumentumRequestParser requestParser = new MockInsertDocumentumRequestParser();
    InsertDocumentumRequestEntity requestEntity = new InsertDocumentumRequestEntity();
    Node requestNode = DOMUtil.getChild(inputDoc.getDocumentElement(), "requestDetails");
    requestParser.parseOperationSpecificRequest(requestNode, requestEntity);
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    String fileNameInSP = documentAttributes.getAttrValue("name");
    String folder = getFolderNameFromInputDocument(inputDoc);
    System.out.println("TestUtil.insertTestDocument: folder = " + folder);
    //ToDo: Need to get "directoryStructure" from request document and use it in Destination Url below - the beginnings of this are now in the spike and in SharePointServices
    IServiceLookup serviceLookup = new SharePointServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails(folder, "win");
    String site = connectionInfo.getConnectionParameterValue("site");
    String documentLibrary = connectionInfo.getConnectionParameterValue("documentLibrary");
    ListsSoap listsSoap = setupListsService(site);
    listsSoap.checkOutFile(site + "/" + documentLibrary + "/" + fileNameInSP, "true", "");
  }

  private static void forceFirstVersionToBeOneDotZero(String fileNameInSP, String site, String documentLibrary) throws
      MalformedURLException {
    ListsSoap listsSoap = setupListsService(site);
    listsSoap.checkOutFile(site + "/" + documentLibrary + "/" + fileNameInSP, "true", "");
    listsSoap.checkInFile(site + "/" + documentLibrary + "/" + fileNameInSP, "", "1");
    VersionsSoap versionsSoap = createVersionsService(site + "/_vti_bin/versions.asmx?WSDL");
//		DeleteVersionResponse.DeleteVersionResult result = versionsSoap.deleteVersion(fileNameInSP, "0.1");


  }

  private static VersionsSoap createVersionsService(String wsdlLocation) throws MalformedURLException {
    Versions service = new Versions(new URL(wsdlLocation));
    VersionsSoap versionsSoap = service.getVersionsSoap();
    turnOffChunkingForNTLM(versionsSoap);
    return versionsSoap;
  }

  private static String getFolderNameFromInputDocument(Document inputDoc) {
    NodeList listByTagName = DOMUtil.getNodeListByTagName(inputDoc, "folder");
    return listByTagName.item(0).getNodeValue();
  }

  public static boolean deleteAllVersionsOfInsertedDocument(String objectId) throws ServiceConfigException, IOException,
      ParserException, EncryptorException, AttributeListParseException {
//		Document deleteReq = transformRequestXML(DELETE_REQUEST_TEMPLATE, objectId, "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value", 0);
    IServiceLookup serviceLookup = new SharePointServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    //ToDo: Hard-coded for now - NEED TO FIX THIS SOON
    ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails("posTestFolder-SP", "win");
    String site = connectionInfo.getConnectionParameterValue("site");
    String documentLibrary = connectionInfo.getConnectionParameterValue("documentLibrary");
    String fileName = getFileName(objectId, site, documentLibrary);
    System.out.println("TestUtil.deleteDocumentByID: fileName = " + fileName);
    Lists service = new Lists(new URL(site + "/_vti_bin/Lists.asmx?WSDL"));
    ListsSoap listsSoap = service.getListsSoap();
    String strBatch = "<?xml version='1.0' encoding='UTF-8'?><Batch><Method ID='1' Cmd='Delete'>" +
        "<Field Name='ID'>" + objectId + "</Field>" +
        "<Field Name='FileRef'>" + site + "/" + documentLibrary + "/" + fileName +
        "</Field>" +
        "</Method></Batch>";
    System.out.println("TestUtil.deleteDocumentByID: strBatch = " + strBatch);
    Document document = DOMUtil.newDocumentFromXML(strBatch);
    UpdateListItems.Updates updates = new UpdateListItems.Updates();
    List<Object> content = updates.getContent();
    content.add(document.getDocumentElement());
    runListUpdate(listsSoap, updates);
    return true;
  }

  public static void deleteDocumentByName(String nameFromInsertRequest) throws ServiceConfigException,
      EncryptorException,
      AttributeListParseException, IOException, ParserException {
    IServiceLookup serviceLookup = new SharePointServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    //ToDo: Hard-coded for now - NEED TO FIX THIS SOON
    ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails("posTestFolder-SP", "win");
    String site = connectionInfo.getConnectionParameterValue("site");
    String documentLibrary = connectionInfo.getConnectionParameterValue("documentLibrary");
    String objectId = null;
    try {
      objectId = getID(nameFromInsertRequest, site, documentLibrary);
    } catch (Exception e) {
      //Ignore
    }
    if (!StringUtils.isNullOrEmpty(objectId)) {
      deleteAllVersionsOfInsertedDocument(objectId);
    }
  }

  //ToDo
  public static Document updateDocument(String filePath, Document updateRequest, String contentType) throws
      Exception {
    IServiceLookup serviceLookup = new SharePointServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    String folder = getFolderNameFromInputDocument(updateRequest);
    System.out.println("TestUtil.updateDocument: folder = " + folder);
    ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails(folder, "win");
    String site = connectionInfo.getConnectionParameterValue("site");
    String documentLibrary = connectionInfo.getConnectionParameterValue("documentLibrary");
//		Document inputDoc = DOMUtil.newDocument(updateRequest);
    UpdateDocumentumRequestParser requestParser = new MockUpdateDocumentumRequestParser();
    UpdateDocumentumRequestEntity requestEntity = new UpdateDocumentumRequestEntity();
    Node requestNode = DOMUtil.getChild(updateRequest.getDocumentElement(), "requestDetails");
    requestParser.parseOperationSpecificRequest(requestNode, requestEntity);
    //ToDo: Need to get "directoryStructure" from request document and use it in Destination Url below
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    String objectId = documentAttributes.getAttrValue("objectId");
    String fileNameInSP = getFileName(objectId, site, documentLibrary);
    System.out.println("SharePointTestUtil.updateDocument: fileNameInSP = " + fileNameInSP);
    CopySoap copySoap = createCopyService(site + "/_vti_bin/Copy.asmx?WSDL");
    ListsSoap listsSoap = setupListsService(site);
    boolean success = listsSoap.checkOutFile(site + "/" + documentLibrary + "/" + fileNameInSP, "true", null);
    System.out.println("TestUtil.testUploadDocument_WithNewVersion: success = " + success);
    DestinationUrlCollection destUrls = setupDestinationUrls(site + "/" + documentLibrary + "/", fileNameInSP);
    byte[] stream = FileUtil.fileToByteArray(filePath);
    FieldInformationCollection fields = new FieldInformationCollection();
    List<FieldInformation> fieldInformationList = fields.getFieldInformation();
    addFieldToList(fieldInformationList, "Publisher", "TestPublisherValue");
    setContentTypeForDocument(fieldInformationList, contentType);
    Holder<Long> result = new Holder<Long>();
    Holder<CopyResultCollection> results = new Holder<CopyResultCollection>();
    //ToDo: HERE IS THE SUPER-SECRET TRICK FROM THE BOTTOM OF THIS URL:
    //ToDo:  http://www.sharepointdev.net/sharepoint--development-programming/web-service-to-add-new-version-to-document-44572.shtml
    //ToDo: To Update to a new version with new content, ONLY USE THE FILE NAME AS THE URL, NOT THE FULL URL LIKE YOU DID
    //ToDo: ON THE INSERT.
//    copySoap.copyIntoItems(destUrls.getString().get(0), destUrls, fields, stream, result, results);
    copySoap.copyIntoItems(fileNameInSP, destUrls, fields, stream, result, results);
    parseCopyResult(results);

    String titleValue = null;
    try {
      titleValue = documentAttributes.getAttrValue("title");
      System.out.println("SharePointTestUtil.updateDocument: titleValue = " + titleValue);
      if (!StringUtils.isNullOrEmpty(titleValue)) {
        String strBatch = "<?xml version='1.0' encoding='UTF-8'?><Batch>" +
            "<Method ID='1' Cmd='Update'>" +
            "<Field Name='ID'>" + objectId + "</Field>" +
            "<Field Name='Title'>" + titleValue + "</Field>" +
            "</Method></Batch>";
        System.out.println("TestUtil.updateDocument: strBatch = " + strBatch);
        Document document = DOMUtil.newDocumentFromXML(strBatch);
        UpdateListItems.Updates updates = new UpdateListItems.Updates();
        List<Object> content = updates.getContent();
        content.add(document.getDocumentElement());
        runListUpdate(listsSoap, updates);
      }
    } catch (AttributeListParseException e) {
      System.out.println("NO TITLE AVAILABLE IN THIS UPDATE REQUEST");
    }

    //ToDo: Keep this code around - may need it later - however, it causes Sharepoint to add stuff at the end of Word document contents
    //ToDo: which makes it impossible to do asserts that you got the right data back
//    String strBatch = "<?xml version='1.0' encoding='UTF-8'?><Batch>" +
//        "<Method ID='1' Cmd='Update'>" +
//        "<Field Name='ID'>" + objectId + "</Field>" +
//        "<Field Name='ContentType'>" + contentType + "</Field>" +
//        "<Field Name='BaseName'>" + fileNameInSP + DOT + contentType + "</Field>" +
//        "</Method></Batch>";
//    System.out.println("TestUtil.updateDocument: strBatch = " + strBatch);
//    Document document = DOMUtil.newDocumentFromXML(strBatch);
//    UpdateListItems.Updates updates = new UpdateListItems.Updates();
//    List<Object> content = updates.getContent();
//    content.add(document.getDocumentElement());
//    runListUpdate(listsSoap, updates);

//    boolean checkinSuccess = listsSoap
//        .checkInFile(site + "/" + documentLibrary + "/" + fileNameInSP + DOT + contentType, "the next version", null);

    boolean checkinSuccess = listsSoap
        .checkInFile(site + "/" + documentLibrary + "/" + fileNameInSP, "the next version", "1");
    System.out.println("SharePointTestUtil.updateDocument: checkinSuccess = " + checkinSuccess);

    //ToDo: This needs to return a Response Document that has the objectId and Version in it

    return DOMUtil.newDocument();
  }

  //ToDo: remobve this method; it was an experiment to see how useful returning the fieldInformastionCollection would be; turns out not at all
  public static FieldInformationCollection updateDocument(String filePath, Document updateRequest, String contentType,
                                                          String dummy) throws
      Exception {
    System.out.println("SharePointTestUtil.updateDocument: dummy = " + dummy);
    IServiceLookup serviceLookup = new SharePointServiceLookup(TEST_SERVICE_CONFIG_FILE_NAME);
    String folder = getFolderNameFromInputDocument(updateRequest);
    System.out.println("TestUtil.updateDocument: folder = " + folder);
    ConnectionInfo connectionInfo = serviceLookup.getConnectionDetails(folder, "win");
    String site = connectionInfo.getConnectionParameterValue("site");
    String documentLibrary = connectionInfo.getConnectionParameterValue("documentLibrary");
//		Document inputDoc = DOMUtil.newDocument(updateRequest);
    MockUpdateSharePointRequestParser requestParser = new MockUpdateSharePointRequestParser();
    UpdateSharePointRequestEntity requestEntity = new UpdateSharePointRequestEntity();
    Node requestNode = DOMUtil.getChild(updateRequest.getDocumentElement(), "requestDetails");
    requestParser.parseOperationSpecificRequest(requestNode, requestEntity);
    //ToDo: Need to get "directoryStructure" from request document and use it in Destination Url below
    DocumentAttributes documentAttributes = requestEntity.getDocumentAttributes();
    String objectId = documentAttributes.getAttrValue("objectId");
    String fileNameInSP = getFileName(objectId, site, documentLibrary);
    System.out.println("SharePointTestUtil.updateDocument: fileNameInSP = " + fileNameInSP);
    CopySoap copySoap = createCopyService(site + "/_vti_bin/Copy.asmx?WSDL");
    ListsSoap listsSoap = setupListsService(site);
    boolean success = listsSoap.checkOutFile(site + "/" + documentLibrary + "/" + fileNameInSP, "true", null);
    System.out.println("TestUtil.testUploadDocument_WithNewVersion: success = " + success);
    DestinationUrlCollection destUrls = setupDestinationUrls(site + "/" + documentLibrary + "/", fileNameInSP);
    byte[] stream = FileUtil.fileToByteArray(filePath);
    FieldInformationCollection fields = new FieldInformationCollection();
    List<FieldInformation> fieldInformationList = fields.getFieldInformation();
    addFieldToList(fieldInformationList, "Publisher", "TestPublisherValue");
    setContentTypeForDocument(fieldInformationList, contentType);
    Holder<Long> result = new Holder<Long>();
    Holder<CopyResultCollection> results = new Holder<CopyResultCollection>();
    //ToDo: HERE IS THE SUPER-SECRET TRICK FROM THE BOTTOM OF THIS URL:
    //ToDo:  http://www.sharepointdev.net/sharepoint--development-programming/web-service-to-add-new-version-to-document-44572.shtml
    //ToDo: To Update to a new version with new content, ONLY USE THE FILE NAME AS THE URL, NOT THE FULL URL LIKE YOU DID
    //ToDo: ON THE INSERT.
//    copySoap.copyIntoItems(destUrls.getString().get(0), destUrls, fields, stream, result, results);
    copySoap.copyIntoItems(fileNameInSP, destUrls, fields, stream, result, results);
    parseCopyResult(results);
    String strBatch = "<?xml version='1.0' encoding='UTF-8'?><Batch>" +
        "<Method ID='1' Cmd='Update'>" +
        "<Field Name='ID'>" + objectId + "</Field>" +
        "<Field Name='ContentType'>" + contentType + "</Field>" +
        "<Field Name='BaseName'>" + fileNameInSP + DOT + contentType + "</Field>" +
//        "<Field Name='FileType'>" + contentType + "</Field>" +
//        "<Field Name='Type'>" + contentType + "</Field>" +
        "</Method></Batch>";
    System.out.println("TestUtil.updateDocument: strBatch = " + strBatch);
    Document document = DOMUtil.newDocumentFromXML(strBatch);
    UpdateListItems.Updates updates = new UpdateListItems.Updates();
    List<Object> content = updates.getContent();
    content.add(document.getDocumentElement());
    runListUpdate(listsSoap, updates);
    boolean checkinSuccess = listsSoap
        .checkInFile(site + "/" + documentLibrary + "/" + fileNameInSP + DOT + contentType, "the next version", "1");
    System.out.println("SharePointTestUtil.updateDocument: checkinSuccess = " + checkinSuccess);

    //ToDo: This needs to return a Response Document that has the objectId and Version in it

    return fields;
  }

  private static void runListUpdate(ListsSoap listsSoap, UpdateListItems.Updates updates) {
    UpdateListItemsResponse.UpdateListItemsResult listItemsResult;
    try {
      listItemsResult = listsSoap.updateListItems("ScannedImages", updates);
      parseResult(listItemsResult);
    } catch (SOAPFaultException e) {
      SOAPFault fault = e.getFault();
      System.out.println("TestUtil.runListUpdate: e.getMessage() = " + e.getMessage());
      Detail detail = fault.getDetail();
      System.out
          .println("TestUtil.runListUpdate: detail.toString() = " + detail.toString());
      System.out
          .println("TestUtil.runListUpdate: detail.getValue() = " + detail.getValue());
      Iterator entries = detail.getDetailEntries();
      while (entries.hasNext()) {
        Object o = entries.next();
        System.out.println("TestUtil.runListUpdate: o.toString() = " + o.toString());
      }
      System.out.println(
          "TestUtil.runListUpdate: fault.getFaultActor() = " + fault.getFaultActor());
      System.out.println(
          "TestUtil.runListUpdate: fault.getFaultCode() = " + fault.getFaultCode());
      System.out.println(
          "TestUtil.runListUpdate: fault.getFaultString() = " + fault.getFaultString());
      System.out.println("TestUtil.runListUpdate: e.toString() = " + e.toString());
    }
  }

  public static Document transformRequestXML(String templateFileName, String newValue, String xpathString,
                                             int indexOfXPath) throws ParserException, TransformerException {
    Document deleteRequestDoc = DOMUtil.newDocument(templateFileName);
    Node objectIdValueNode = XPathAPI.eval(deleteRequestDoc, xpathString).nodelist().item(indexOfXPath);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(newValue);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    return deleteRequestDoc;
  }

  public static String deleteExistingDocumentIdAndInsert(String insertRequest, String updateRequestTemplate) throws
      Exception {
//		Document searchReponseDoc = searchDocument();
//		String id = XPathAPI.eval(searchReponseDoc,
//															XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR).toString();
//		try {
//			SharePointTestUtil.deleteAllVersionsOfInsertedDocument(id);
//		} catch (Throwable e1) {
//			//ignore
//		}
    return insertUpdateDocument(insertRequest, updateRequestTemplate);
  }

  private static void addMultiValuedFieldToList(List<FieldInformation> fieldInformationList, String name,
                                                String value) {
    FieldInformation fieldInformation = new FieldInformation();
    fieldInformation.setDisplayName(name);
    fieldInformation.setValue(value);
    fieldInformation.setInternalName(name);
    fieldInformation.setType(FieldType.NOTE);
    fieldInformationList.add(fieldInformation);
  }

  private static void addFieldToList(List<FieldInformation> fieldInformationList, String name, String value) {
    FieldInformation fieldInformation = new FieldInformation();
    fieldInformation.setDisplayName(name);
    fieldInformation.setValue(value);
    fieldInformation.setInternalName(name);
    fieldInformation.setType(FieldType.TEXT);
    fieldInformationList.add(fieldInformation);
  }

  private static void setContentTypeForDocument(List<FieldInformation> fieldInformationList, String value) {
    //ToDo <FieldInformation Type=�Choice� DisplayName=�Content Type� InternalName=�ContentType� Value=�Word� />
    FieldInformation fieldInformation = new FieldInformation();
    fieldInformation.setType(FieldType.CHOICE);
    fieldInformation.setDisplayName(CONTENT_TYPE);
    fieldInformation.setInternalName("ContentType");
    fieldInformation.setValue(value);
    fieldInformationList.add(fieldInformation);

    fieldInformation = new FieldInformation();
    fieldInformation.setType(FieldType.TEXT);
    fieldInformation.setDisplayName(FILE_TYPE);
    fieldInformation.setInternalName(FILE_TYPE);
    fieldInformation.setValue(value);
    fieldInformationList.add(fieldInformation);

    fieldInformation = new FieldInformation();
    fieldInformation.setType(FieldType.COMPUTED);
    fieldInformation.setDisplayName(TYPE);
    fieldInformation.setInternalName(TYPE);
    fieldInformation.setValue(value);
    fieldInformationList.add(fieldInformation);
  }

//	private static Document searchDocument() throws IOException {
//		SearchDocumentsPOS searchDocumentsPOS = new SearchDocumentsPOS();
//		MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
//		mockUCCHelper.addClientFile(SEARCH_REQUEST_CURRENT_VERSIONS);
//		searchDocumentsPOS.run(mockUCCHelper);
//		return mockUCCHelper.getXML();
//	}

  public static String insertUpdateDocument(String insertRequest, String updateRequestTemplate) throws
      Exception {
    String objectId = SharePointTestUtil.insertTestDocument(CONTENTS, insertRequest);
    String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document updateReq = SharePointTestUtil
        .transformRequestXML(updateRequestTemplate, objectId, updateTransformationXPathString, 0);
    SharePointTestUtil.updateDocument(CONTENTS, updateReq, DocumentManagerConstants.TEXT_DOC_FILETYPE);
    return objectId;
  }

  private static String getFileName(String id, String site, String documentLibrary) throws IOException,
      ParserException {
    ListsSoap listsSoap = setupListsService(site);
    String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
        "<Query>" +
        "<Where>" +
        "<Contains>" +
        "<FieldRef Name='ID' />" +
        "<Value Type='counter'>" + id + "</Value>" +
        "</Contains>" +
        "</Where>" +
        "</Query>";
    Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
    GetListItems.Query query = new GetListItems.Query();
    List<Object> content = query.getContent();
    content.add(queryDoc.getDocumentElement());
    GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
        .getListItems(documentLibrary, "", query, null, null, null, "");
    Element listResult = (Element) scannedImagesResult.getContent().get(0);
    NodeList list = listResult.getElementsByTagName("z:row");
    NamedNodeMap attributes = list.item(0).getAttributes();
    String owsFileRef = attributes.getNamedItem("ows_FileRef").getNodeValue();
    return owsFileRef.substring(owsFileRef.lastIndexOf("/") + 1);
  }


  private static ListsSoap setupListsService(String site) throws MalformedURLException {
    Lists service = new Lists(new URL(site + "/_vti_bin/Lists.asmx?WSDL"));
    ListsSoap listsSoap = service.getListsSoap();
    turnOffChunkingForNTLM(listsSoap);
    return listsSoap;
  }

  private static void turnOffChunkingForNTLM(Object port) throws MalformedURLException {
    jcifs.Config.setProperty("jcifs.smb.client.domain", "monsanto.com");
    jcifs.Config.setProperty("jcifs.netbios.wins", "xxx.xxx.xxx.xxx");
    jcifs.Config.setProperty("jcifs.smb.client.soTimeout", "300000"); //5 minutes
    jcifs.Config.setProperty("jcifs.netbios.cachePolicy", "1200"); //20 minutes
    jcifs.Config.registerSmbURLHandler();
    Client client = ClientProxy.getClient(port);
    HTTPConduit http = (HTTPConduit) client.getConduit();
    HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
    httpClientPolicy.setConnectionTimeout(36000);
    httpClientPolicy.setAllowChunking(false);
    http.setClient(httpClientPolicy);
  }

  private static void parseCopyResult(Holder<CopyResultCollection> results) {
    List<CopyResult> resultsList = results.value.getCopyResult();
    for (CopyResult copyResult : resultsList) {
      System.out.println(
          "SharePointTestUtil.parseCopyResult: copyResult.getDestinationUrl() = " + copyResult.getDestinationUrl());
      System.out.println(
          "SharePointTestUtil.parseCopyResult: copyResult.getErrorMessage() = " + copyResult.getErrorMessage());
      System.out.println("SharePointTestUtil.parseCopyResult: copyResult.getErrorCode().value() = " +
          copyResult.getErrorCode().value());
    }
  }

  private static Element parseResult(UpdateListItemsResponse.UpdateListItemsResult listItemsResult) {
    Element result = (Element) listItemsResult.getContent().get(0);
    NodeList list = result.getElementsByTagName("Result");
    System.out.println("TestUtil.parseResult: list.getLength() = " + list.getLength());
    for (int j = 0; j < list.getLength(); j++) {
      Node node = list.item(j);
      System.out.println("TestUtil.parseResult: node.getNodeName() = " + node.getNodeName());
      listAttributes(node);
      NodeList children = node.getChildNodes();
      for (int k = 0; k < children.getLength(); k++) {
        listValue(children.item(k));
        listAttributes(children.item(k));
      }
    }
    return result;
  }

  private static CopySoap createCopyService(String wsdlLocation) throws MalformedURLException {
    Copy service = new Copy(new URL(wsdlLocation));
    CopySoap copySoap = service.getCopySoap();
    turnOffChunkingForNTLM(copySoap);
    return copySoap;
  }

  private static void listValue(Node node) {
    System.out.println("TestUtil.listValue: node.getNodeName() = " + node.getNodeName());
    System.out.println("TestUtil.listValue: node.getNodeValue() = " + node.getTextContent());
  }

  private static void listAttributes(Node node) {
    NamedNodeMap map = node.getAttributes();
    System.out.println("TestUtil.listAttributes: map.getLength() = " + map.getLength());
    for (int k = 0; k < map.getLength(); k++) {
      Node attrNode = map.item(k);
      System.out.println("TestUtil.listAttributes: attrNode.getNodeName() = " + attrNode.getNodeName());
      System.out.println("TestUtil.listAttributes: attrNode.getNodeValue() = " + attrNode.getNodeValue());
    }
  }

  private static DestinationUrlCollection setupDestinationUrls(String scannedImagesUrl, String fileName) {
    DestinationUrlCollection destUrls = new DestinationUrlCollection();
    List<String> urlList = destUrls.getString();
    String documentDestinationUrl = scannedImagesUrl + fileName;
    System.out.println("SharePointTestUtil.setupDestinationUrls: documentDestinationUrl = " + documentDestinationUrl);
    urlList.add(documentDestinationUrl);
    return destUrls;
  }

  private static String getID(String fileName, String site, String documentLibrary) throws IOException,
      ParserException {
    ListsSoap listsSoap = setupListsService(site);
    String strQuery = "<?xml version='1.0' encoding='UTF-8'?>" +
        "<Query>" +
        "<Where>" +
        "<Contains>" +
        "<FieldRef Name='FileRef' />" +
        "<Value Type='Text'>" + documentLibrary + "/" + fileName + "</Value>" +
        "</Contains>" +
        "</Where>" +
        "</Query>";
    Document queryDoc = DOMUtil.newDocumentFromXML(strQuery);
    GetListItems.Query query = new GetListItems.Query();
    List<Object> content = query.getContent();
    content.add(queryDoc.getDocumentElement());
    GetListItemsResponse.GetListItemsResult scannedImagesResult = listsSoap
        .getListItems(documentLibrary, "", query, null, null, null, "");
    Element listResult = (Element) scannedImagesResult.getContent().get(0);
    NodeList list = listResult.getElementsByTagName("z:row");
    NamedNodeMap attributes = list.item(0).getAttributes();
    return attributes.getNamedItem("ows_ID").getNodeValue();
  }


}