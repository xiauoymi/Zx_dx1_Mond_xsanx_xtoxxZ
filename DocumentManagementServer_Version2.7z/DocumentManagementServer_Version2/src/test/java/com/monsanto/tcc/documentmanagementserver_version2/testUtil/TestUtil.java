package com.monsanto.tcc.documentmanagementserver_version2.testUtil;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.*;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.constants.DocumentManagerConstants;
import com.monsanto.tcc.documentmanagementserver_version2.documentManagerFramework.services.searchService.SearchDocumentsPOS;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import org.apache.xpath.XPathAPI;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Jun 9, 2006
 * Time: 10:37:02 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class TestUtil{

  private static final String POS_INSERT_SERVICE_NAME = "InsertDocumentService";
  private static final String POS_DELETE_SERVICE_NAME = "DeleteDocumentService";
  private static final String POS_UPDATE_SERVICE_NAME = "UpdateDocumentService";

  private static final String DELETE_REQUEST_TEMPLATE = "com/monsanto/tcc/documentmanagementserver_version2/apptests/deleteRequest.xml";

  public static final String XPATH_BEGIN_STR = "/documentManagerResponse/searchDocuments/documentDetails/attribute[name = '";
  public static final String XPATH_END_STR = "']/value";
  public static final String SEARCH_REQUEST_CURRENT_VERSIONS = "com/monsanto/tcc/documentmanagementserver_version2/documentManagerFramework/services/searchService/tests/searchRequestCurrentVersions.xml";
  public static final String CONTENTS = "com/monsanto/tcc/documentmanagementserver_version2/apptests/testFile1.txt";

  public static String insertTestDocument(String originalContents, String mimeType, String insertRequestXml) throws InvalidMimeTypeException, TransformerException, ParserException, GSSException, IOException, SAXException, POSCommunicationException, POSException {
    MultipartAttachmentList attachmentList = new MultipartAttachmentList();
    addAttachment(attachmentList, originalContents, mimeType);
    Document responseDoc = insertIntoDctm(attachmentList, insertRequestXml);
    return getObjectIdOfInsertedDocument(responseDoc);
  }

  public static boolean deleteAllVersionsOfInsertedDocument(String objectId) throws ParserException, POSCommunicationException, POSException, TransformerException, GSSException {
    Document deleteReq = transformRequestXML(DELETE_REQUEST_TEMPLATE, objectId, "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value", 0);
    SecureXMLPOSConnection posConn = new SecureXMLPOSConnection(new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    posConn.callService(POS_DELETE_SERVICE_NAME, deleteReq);
    return true;
  }

  public static Document updateDocument(String updatedContents,Document updateRequest, String contentMimeType) throws InvalidMimeTypeException, GSSException, POSCommunicationException, POSException, IOException, SAXException {
    MultipartAttachmentList attachmentList = new MultipartAttachmentList();
    addAttachment(attachmentList, updatedContents, contentMimeType);
    XMLPOSConnection posConn = new SecureXMLPOSConnection(new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    addAttachmentToConnection(attachmentList, posConn);
    POSResult posResult = posConn.callService(POS_UPDATE_SERVICE_NAME, updateRequest);
    return DOMUtil.newDocument(posResult.getInputStream());
  }

  public static Document transformRequestXML(String templateFileName, String newValue, String xpathString, int indexOfXPath) throws ParserException, TransformerException {
    Document deleteRequestDoc = DOMUtil.newDocument(templateFileName);
    Node objectIdValueNode = XPathAPI.eval(deleteRequestDoc, xpathString).nodelist().item(indexOfXPath);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(newValue);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    return deleteRequestDoc;
  }
  public static String deleteExistingDocumentIdAndInsert(String insertRequest, String updateRequestTemplate) throws
      IOException, TransformerException, ParserException,
      GSSException, POSException, POSCommunicationException, InvalidMimeTypeException, SAXException {
    Document searchReponseDoc = searchDocument();
    String id = XPathAPI.eval(searchReponseDoc,
        XPATH_BEGIN_STR + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID + XPATH_END_STR).toString();
    try {
            TestUtil.deleteAllVersionsOfInsertedDocument(id);
    } catch (Throwable e1) {
      //ignore
    }
    return insertUpdateDocument(insertRequest, updateRequestTemplate);
  }
    private static Document searchDocument() throws IOException {
    SearchDocumentsPOS searchDocumentsPOS = new SearchDocumentsPOS();
    MockUCCHelper mockUCCHelper = new MockUCCHelper(null);
    mockUCCHelper.addClientFile(SEARCH_REQUEST_CURRENT_VERSIONS);
    searchDocumentsPOS.run(mockUCCHelper);
      return mockUCCHelper.getXML();
  }
 public static String insertUpdateDocument(String insertRequest, String updateRequestTemplate) throws
      InvalidMimeTypeException, TransformerException, ParserException, GSSException, IOException, SAXException,
      POSCommunicationException, POSException {
    String objectId = TestUtil.insertTestDocument(CONTENTS, POSMIMEConstants.MIME_TYPE_TEXT, insertRequest);
    String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document updateReq = TestUtil
        .transformRequestXML(updateRequestTemplate, objectId, updateTransformationXPathString, 0);
    TestUtil.updateDocument(CONTENTS, updateReq, POSMIMEConstants.MIME_TYPE_TEXT);
    return objectId;
  }
  private static Document insertIntoDctm(MultipartAttachmentList attachmentList, String requestXmlDocument) throws ParserException, POSException, POSCommunicationException, IOException, SAXException, GSSException {
    Document inputDoc = DOMUtil.newDocument(requestXmlDocument);
    XMLPOSConnection posConn = new SecureXMLPOSConnection(new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
    addAttachmentToConnection(attachmentList, posConn);
    POSResult result = posConn.callService(POS_INSERT_SERVICE_NAME, inputDoc);
    return DOMUtil.newDocument(result.getInputStream());
  }

  private static void addAttachment(MultipartAttachmentList attachmentList, String fileName, String mimeType) throws InvalidMimeTypeException {
    MultiPartFormAttachment attachment = new MultiPartFormAttachment(fileName, mimeType);
    attachmentList.addAttachment(attachment);
  }

  private static void addAttachmentToConnection(MultipartAttachmentList attachmentList, XMLPOSConnection posConn) {
    int numberOfAttachments = attachmentList.getLength();
    for (int i = 0; i < numberOfAttachments; i++) {
      MultiPartFormAttachment attachment = attachmentList.getAttachment(i);
      posConn.addAttachment(attachment);
    }
  }

  private static String getObjectIdOfInsertedDocument(Document responseDoc) throws TransformerException {
    String expression = "/documentManagerResponse/insertDocument/documentDetails/attribute[name = '" + DocumentManagerConstants.ATTR_STR_UNIQUE_DOCUMENT_ID +"']/value";
    Object objId = XPathAPI.eval(responseDoc, expression);
    return objId.toString();
  }

}