package com.monsanto.tcc.documentum;

import java.util.*;

/**
 * Set info needed for the created Documentum object
 *
 * @author WWZHOU
 */
public class DocumentInfo {
  public static final String PDF_TYPE = "pdf";
  //public static final String TEXT_TYPE = "crtext";

  private String name;
  private String title;
  private String subject;
  private String contentType;
  private List authors;
  private List keywords;

  public DocumentInfo() {
    authors = new ArrayList();
    keywords = new ArrayList();
  }

  public String getName() {
    return name;
  }

  public void setName(String documentumName) {
    this.name = documentumName;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String documentumTitle) {
    this.title = documentumTitle;
  }

  public String getSubject() {
    return subject;
  }

  public void setSubject(String documentumSubject) {
    this.subject = documentumSubject;
  }

  public String getContentType() {
    return contentType;
  }

  public void setContentType(String documentumContentType) {
    this.contentType = documentumContentType;
  }

  public List getAuthors() {
    return Collections.unmodifiableList(authors);
  }

  public void addAuthor(String author) {
    authors.add(author);
  }

  public List getKeywords() {
    return Collections.unmodifiableList(keywords);
  }

  public void addKeyword(String keyWord) {
    keywords.add(keyWord);
  }
}