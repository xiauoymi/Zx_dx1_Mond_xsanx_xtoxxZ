package com.monsanto.tcc.documentum;

/**
 * @author WWZHOU
 */
public class DocumentumException extends Exception {

  /**
   *
   */
  public DocumentumException() {
    super();
  }

  /**
   * @param arg0
   */
  public DocumentumException(String arg0) {
    super(arg0);
  }
}
