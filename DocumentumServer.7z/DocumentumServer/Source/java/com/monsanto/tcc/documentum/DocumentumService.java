package com.monsanto.tcc.documentum;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

import java.io.*;
import java.util.*;

/**
 * Service class to communicate with Documentum
 *
 * @author WWZHOU
 */
public class DocumentumService {
  private String docBroker;
  private String userName;
  private String password;
  private IDfSession sess;
  private boolean supportVersioning;

  private static final boolean REMOVE_PATH = true;

  public DocumentumService(String docBrokerHost, String userName, String pwd) {
    this.docBroker = docBrokerHost;
    this.userName = userName;
    this.password = pwd;
  }

  /**
   * Connect to Documentum
   *
   * @param docBaseName the Documentum docBase to connect
   * @throws DocumentumException
   */
  public void connect(String docBaseName) throws DocumentumException {
    sess = null;
    try {
      IDfClient client = DfClient.getLocalClient();
      IDfTypedObject config = client.getClientConfig();
      config.setString("primary_host", docBroker);

      //Set up login credentials.
      IDfLoginInfo li = new DfLoginInfo();
      li.setUser(userName);
      li.setPassword(password);
      sess = client.newSession(docBaseName, li);
    } catch (DfException dfe) {
      throw new DocumentumException("Exception in connect() " + dfe.getMessage());
    }
  }

  /**
   * Close the current Documentum connection
   */
  public void close() {
    checkSessionOpen();
    try {
      sess.disconnect();
    } catch (DfException e) {
    }
  }

  /**
   * Start the transaction
   */
  public void beginTransaction() throws DocumentumException {
    try {
      sess.beginTrans();
    } catch (DfException e) {
      throw new DocumentumException(e.getMessage());
    }
  }

  /**
   * Commit all the changes from last call to <code>beginTransaction()</code>
   */
  public void commitTransaction() throws DocumentumException {
    try {
      sess.commitTrans();
    } catch (DfException e) {
      throw new DocumentumException(e.getMessage());
    }
  }

  /**
   * Roll back all the changes for current transaction
   */
  public void rollbackTransaction() throws DocumentumException {
    try {
      sess.abortTrans();
    } catch (DfException e) {
      throw new DocumentumException(e.getMessage());
    }
  }

  /**
   * Set the Documentum session. This method is provided for flexibility.
   *
   * @param session the Documentum session to use
   */
  public void setSession(IDfSession session) {
    this.sess = session;
  }

  /**
   * Create a Documentum folder
   *
   * @param folderName the folder name to create
   * @param parent     the context
   * @throws DocumentumException
   * @see #createFolder(String, String, DocumentInfo)
   */
  public void createFolder(String folderName, String parent)
      throws DocumentumException {
    createFolder(folderName, parent, null);
  }

  /**
   * Create a Documentum folder
   *
   * @param folderName the folder name to create
   * @param parent     the context
   * @param docInfo    the DocumentInfo to set
   * @throws DocumentumException
   */
  public void createFolder(String folderName, String parent, DocumentInfo docInfo)
      throws DocumentumException {
    checkSessionOpen();
    try {
      // Create the dm_folder object, set some attributes, then save it.
      IDfSysObject sysObj = (IDfSysObject) sess.newObject("dm_folder");
      if (docInfo == null) {
        docInfo = createDefaultDocumentInfo(folderName, !REMOVE_PATH);
      }
      setDocumentumObjectInfo(sysObj, docInfo);
      sysObj.link(parent);
      sysObj.save();
    } catch (DfException dfe) {
      throw new DocumentumException("Exception in createFolder():" +
          dfe.getMessage());
    }
  }

  /**
   * Create a Documentum document
   *
   * @param fileName the file name
   * @param parent   the context
   * @throws DocumentumException
   * @see #createDocument(String,String, DocumentInfo)
   */
  public void createDocument(String fileName, String parent)
      throws DocumentumException {
    createDocument(fileName, parent, null);
  }

  /**
   * Create a Documentum document. The created Documentum object will use
   * name specified in docInfo as its name. If no name is specified in docInfo,
   * the fileName with no path info will be used as default name. For example,
   * if the fileName testdata/xml-mapping.xml, the Documentum object name will
   * be xml-mapping.xml
   *
   * @param fileName the file name
   * @param parent   the context
   * @param docInfo  the DocumentInfo to set
   * @throws DocumentumException
   */
  public void createDocument(String fileName, String parent, DocumentInfo docInfo)
      throws DocumentumException {
    checkSessionOpen();
    try {
      // Create the dm_cabinet object, set some attributes, then save it.
      //changed to aphis_doc 09/22/04IDfSysObject sysObj = (IDfSysObject) sess.newObject("dm_document");
      IDfSysObject sysObj = (IDfSysObject) sess.newObject("aphis_doc");

      if (docInfo == null) {
        docInfo = createDefaultDocumentInfo(fileName, REMOVE_PATH);
      }
      setDocumentumObjectInfo(sysObj, docInfo);
      sysObj.setFile(fileName);
      sysObj.link(parent);
      sysObj.save();
    } catch (DfException dfe) {
      throw new DocumentumException("Exception in createDocument() " +
          dfe.getMessage());
    }
  }

  /**
   * Save the Documentum object with the fileName
   *
   * @param fileName
   * @param parent
   * @throws DocumentumException
   * @see #saveDocument(String,String,DocumentInfo)
   */
  public void saveDocument(String fileName, String parent)
      throws DocumentumException {
    saveDocument(fileName, parent, null);
  }

  /**
   * Save the Documentum object with the fileName. Depends on the current
   * versioningSupport setting, if no versioningSupport, the behaviour is the
   * same as createDocument(). If versioningSupport is set, it will check
   * if there is same Documentum object name exists. If no same Documentum object
   * exists, a new one will be created, else a new version of the existing
   * object will be created.
   * <p/>
   * The difference between createDocument() and saveDocument() is
   * that createDocument() will always create a new Document object
   *
   * @param fileName file name
   * @param parent   context
   * @param docInfo  Documentum info to set
   * @throws DocumentumException
   */
  public void saveDocument(String fileName, String parent, DocumentInfo docInfo)
      throws DocumentumException {
    checkSessionOpen();
    if (docInfo == null) {
      docInfo = createDefaultDocumentInfo(fileName, REMOVE_PATH);
    }

    if (!supportVersioning) {
      createDocument(fileName, parent, docInfo);
    } else {
      List existingDoc = findIdByName(docInfo.getName(), parent);
      if (existingDoc.size() == 0) {
        createDocument(fileName, parent, docInfo);
      } else {
        try {
          String id = (String) existingDoc.get(0);
          IDfSysObject obj = getById(id);
          if (!obj.isCheckedOut()) {
            checkOutDocument(obj);
          }

          setDocumentumObjectInfo(obj, docInfo);
          // Have the user specify a file on disk.
          obj.setFile(fileName);
          //note: if exception occurs, the doc may be left in check out state
          checkInDocument(obj);
        } catch (DfException dfe) {
          throw new DocumentumException("Exception in saveDocument() " +
              dfe.getMessage());
        }
      }
    }
  }

  /**
   * Set versioning support. By default versioning support is false.
   *
   * @param supportVersioning if need to support versioning
   * @see #saveDocument(String,String,DocumentInfo)
   */
  public void setVersioningSupport(boolean supportVersioning) {
    this.supportVersioning = supportVersioning;
  }

  /**
   * Find the Documentum object id for the given name and context
   *
   * @param name   Documentum object name
   * @param parent Documentum folder info
   * @return a list of the object ids found, return an empty list if no objects found
   * @throws DocumentumException
   */
  public List findIdByName(String name, String parent)
      throws DocumentumException {
    return findIdByName(name, parent, false); //just search in the parent folder
  }

  /**
   * Find the Documentum object id for the given name and context
   *
   * @param name      Documentum object name
   * @param parent    Documentum folder info
   * @param recursive whether to search the sub folder under parent
   * @return a list of the object ids found, return an empty list if no objects found
   * @throws DocumentumException
   */
  public List findIdByName(String name, String parent, boolean recursive)
      throws DocumentumException {
    List result = new ArrayList();
    try {
      IDfCollection queryResult = null;
      if (recursive == true) {
        queryResult = execQuery("select r_object_id from dm_document where folder " +
            "('" + parent + "',DESCEND) AND object_name='" + name + "'");
      } else {
        queryResult = execQuery("select r_object_id from dm_document where folder " +
            "('" + parent + "') AND object_name='" + name + "'");
      }
      if (queryResult != null) {
        while (queryResult.next()) {
          IDfAttr attr = queryResult.getAttr(0);
          String id = queryResult.getId(attr.getName()).toString();
          result.add(id);
        }
        //must close the collection because it is a limited resource
        queryResult.close();
      }
    } catch (DfException dfe) {
      throw new DocumentumException("Exception in findIdByDocumentName() " +
          dfe.getMessage());
    }
    return result;
  }

  /**
   * Find the Documentum object id and format for the given name and context
   *
   * @param name      Documentum object name
   * @param parent    Documentum folder info
   * @param recursive whether to search the sub folder under parent
   * @return a list of the object ids found and its format, return an empty list
   *         if no objects found
   * @throws DocumentumException
   */
  public List findIdAndFormatByName(String name, String parent, boolean recursive)
      throws DocumentumException {
    List result = new ArrayList();
    try {
      IDfCollection queryResult = null;
      if (recursive == true) {
        queryResult = execQuery("select r_object_id,a_content_type from dm_document where folder " +
            "('" + parent + "',DESCEND) AND object_name='" + name + "'");
      } else {
        queryResult = execQuery("select r_object_id,a_content_type from dm_document where folder " +
            "('" + parent + "') AND object_name='" + name + "'");
      }
      if (queryResult != null) {
        while (queryResult.next()) {
          IDfAttr idAttr = queryResult.getAttr(0);
          String id = queryResult.getId(idAttr.getName()).toString();
          IDfAttr formatAttr = queryResult.getAttr(1);
          String format = queryResult.getId(formatAttr.getName()).toString();
          String[] idAndFormat = new String[]{id, format};
          result.add(idAndFormat);
        }
        //must close the collection because it is a limited resource
        queryResult.close();
      }
    } catch (DfException dfe) {
      throw new DocumentumException("Exception in findIdByDocumentName() " +
          dfe.getMessage());
    }
    return result;
  }

  /**
   * If the given Documentum folder name exists in Documentum
   *
   * @param name   Documentum folder name
   * @param parent Documentum context info
   * @return true if the Documentum folder already exists. Return false if no such
   *         folder exists
   * @throws DocumentumException
   */
  public boolean existFolderByName(String name, String parent)
      throws DocumentumException {
    boolean exist = false;
    try {
      IDfCollection queryResult = execQuery("select r_object_id from dm_folder where folder " +
          "('" + parent + "') AND object_name='" + name + "'");
      if (queryResult != null) {
        while (queryResult.next()) {
          exist = true;
          break;
        }
        queryResult.close();
      }
      return exist;
    } catch (DfException dfe) {
      throw new DocumentumException("Exception in findIdByDocumentName() " +
          dfe.getMessage());
    }
  }

  /**
   * Delete the given Documentum object id
   *
   * @param objectId the Documentum object id
   * @throws DocumentumException
   */
  public void destroyById(String objectId) throws DocumentumException {
    checkSessionOpen();
    try {
      IDfSysObject sysObj = (IDfSysObject) sess.getObject(new DfId(objectId));
      sysObj.destroy();
    } catch (DfException dfe) {
      throw new DocumentumException("Exception in destroyById() " +
          dfe.getMessage());
    }
  }


  /**
   * Check if the connection to Documentum is still open
   */
  public void checkSessionOpen() throws IllegalStateException {
    if (sess == null || !sess.isConnected()) {
      throw new IllegalStateException("Not connected to Documentum yet");
    }
  }

  /**
   * Helper method to display session info
   *
   * @param s   the current Documentum session
   * @param out the destination to send out the info
   */
  public void displaySessionInfo(IDfSession s, PrintWriter out) {
    checkSessionOpen();
    try {
      out.println("\nDocbase : " + s.getDocbaseName());
      out.println("Srvr Vers : " + s.getServerVersion());
      out.println("DBMS : " + s.getDBMSName());
      out.println("Owner : " + s.getDocbaseOwnerName());
      out.println("Sess Id : " + s.getSessionId());
      out.println("DMCL Sess Id: " + s.getDMCLSessionId());
      out.println("Docbase Id : " + s.getDocbaseId());
      out.println("Scope : " + s.getDocbaseScope());
      out.println("User : " + s.getLoginUserName());
      out.println("Login Ticket: " + s.getLoginTicket());
      out.println("Security : " + s.getSecurityMode());
    } catch (DfException dfe) {
      System.out.println("\n" + dfe.toString());
    }
  }

  /**
   * Retrieve the Documentum document for the given Documentum object id.
   * The retrived document is put under the given path using the given name.
   *
   * @param objectId the Documentum object id
   * @param path     the location for the retrieved file. Must not be null.
   * @param fileName the file name for the retrieved file. Pass in null to
   *                 use the Documentum object name as the file name
   * @return the file name retrieved. It will the same as the passed in
   *         file name if the passed in file name is not null otherwise it will be
   *         the Documentum object name plus object id and using Documentum object
   *         content type as file name suffix if the Documentum object name doesn't
   *         have suffix
   */
  public String retrieveDocumentById(String objectId, String path,
                                     String fileName) throws DocumentumException {
    try {
      IDfSysObject sysObj = (IDfSysObject) sess.getObject(new DfId(objectId));
      String physicalFile = fileName;
      if (physicalFile == null) {
        String objName = sysObj.getObjectName();
        physicalFile = objectId + objName;
        if (objName.indexOf(".") == -1) {//no suffix in name
          //use the content type as suffix
          physicalFile = physicalFile + "." + sysObj.getContentType();
        }
      }
      sysObj.getFile(path + "/" + physicalFile);
      return physicalFile;
    } catch (DfException dfe) {
      throw new DocumentumException("Exception in retrieveDocumentById() " +
          dfe.getMessage());
    }
  }

  /**
   * Find the Documentum object by its object id
   *
   * @param objectId
   * @return the Documentum object
   * @throws DocumentumException if anything wrong happens
   */
  protected IDfSysObject getById(String objectId) throws DocumentumException {
    checkSessionOpen();
    try {
      IDfSysObject sysObj = (IDfSysObject) sess.getObject(new DfId(objectId));
      return sysObj;
    } catch (DfException dfe) {
      throw new DocumentumException("Exception in getById() " +
          dfe.getMessage());
    }
  }

  /**
   * Check in the given Documentum object
   *
   * @param sysObj
   * @return the new Documentum object id
   * @throws DocumentumException if anything wrong happens
   */
  protected IDfId checkInDocument(IDfSysObject sysObj) throws DocumentumException {
    try {
      IDfId newSysObjId = sysObj.checkin(false, "");
      return newSysObjId;
    } catch (DfException dfe) {
      throw new DocumentumException("Exception in checkInDocument() " +
          dfe.getMessage());
    }
  }

  /**
   * Check out the given Documentum object
   *
   * @param sysObj
   * @throws DocumentumException if anything wrong happens
   */
  protected void checkOutDocument(IDfSysObject sysObj) throws DocumentumException {
    try {
      sysObj.checkout();
    } catch (DfException dfe) {
      throw new DocumentumException("Exception in checkOutDocument() " +
          dfe.getMessage());
    }
  }

  /**
   * Execute the query
   *
   * @param queryString
   * @return a collection of the Documentum objects found
   * @throws DocumentumException if anything wrong happens
   */
  protected IDfCollection execQuery(String queryString) throws DocumentumException {
    IDfCollection col = null;
    checkSessionOpen();
    try {
      // Create the query object then set the query string.
      IDfQuery q = new DfQuery();
      q.setDQL(queryString);

      // Synchronously execute the query.
      col = q.execute(sess, DfQuery.DF_READ_QUERY);
    } catch (DfException dfe) {
      throw new DocumentumException("Exception in execQuery() " +
          dfe.getMessage());
    }
    return col;
  }

  private DocumentInfo createDefaultDocumentInfo(String fileName, boolean removePath) {
    DocumentInfo docInfo = new DocumentInfo();

    String objName = fileName;
    if (removePath) {
      //remove the path info
      int lastIndex = fileName.lastIndexOf("\\");
      if (lastIndex == -1) {
        lastIndex = fileName.lastIndexOf("/");
      }

      if (lastIndex != -1) {
        objName = fileName.substring(lastIndex + 1);
      }
    }

    docInfo.setName(objName);
    //Modified on 09/22/04 docInfo.setContentType(DocumentInfo.TEXT_TYPE);
    return docInfo;
  }

  private void setDocumentumObjectInfo(IDfSysObject sysObj, DocumentInfo docInfo)
      throws DocumentumException {
    try {
      //object name is required fields
      if (docInfo.getName() != null) {
        sysObj.setObjectName(docInfo.getName());
      } else {
        throw new DocumentumException("No Documentum object name specified");
      }

      if (docInfo.getContentType() != null) {
        sysObj.setContentType(docInfo.getContentType());
        System.out.println("ContentType: " + docInfo.getContentType());
      }

      if (docInfo.getSubject() != null) {
        sysObj.setSubject(docInfo.getSubject());
      }

      if (docInfo.getTitle() != null) {
        sysObj.setTitle(docInfo.getTitle());
      }

      Iterator authorIterator = docInfo.getAuthors().iterator();
      int authorIndex = 0;
      while (authorIterator.hasNext()) {
        sysObj.setAuthors(authorIndex++, (String) authorIterator.next());
      }

      Iterator keywordIterator = docInfo.getKeywords().iterator();
      int keywordIndex = 0;
      while (keywordIterator.hasNext()) {
        sysObj.setKeywords(keywordIndex++, (String) keywordIterator.next());
      }
    } catch (DfException e) {
      throw new DocumentumException("Exception in setDocumentumObjectInfo() " +
          e.getMessage());
    }
  }
}