/*
 * Created on Sep 9, 2003
 *
 * $Revision: 1.1 $
 * $Id: DocumentumServiceObjectFactory.java,v 1.1 2005-04-20 18:12:49 mpgren Exp $
 */
package com.monsanto.tcc.documentumserver;

import com.monsanto.tcc.documentum.*;
import org.apache.commons.pool.BasePoolableObjectFactory;

/**
 * Factory to create DocumentumService objects
 *
 * @author WWZHOU
 */
public class DocumentumServiceObjectFactory extends BasePoolableObjectFactory {
  private String docBroker;
  private String userName;
  private String password;
  private String docBase;

  /**
   * Constructs a <code>DocumentumServiceObjectFactory</code> instance
   *
   * @param docBroker
   * @param userName
   * @param password
   * @param docBase
   */
  public DocumentumServiceObjectFactory(String docBroker, String userName,
                                        String password, String docBase) {
    super();
    this.docBroker = docBroker;
    this.userName = userName;
    this.password = password;
    this.docBase = docBase;
  }

  /*
   * Create a new DocumentumService object
   * @see org.apache.commons.pool.PoolableObjectFactory#makeObject()
   */
  public Object makeObject() throws Exception {
    DocumentumService newObj = new DocumentumService(docBroker, userName,
        password);
    newObj.connect(docBase);
    return newObj;
  }

  /*
   * Destroy an existing DocumentumService object
   * @see org.apache.commons.pool.PoolableObjectFactory#destroyObject(java.lang.Object)
   */
  public void destroyObject(Object arg0) throws Exception {
    ((DocumentumService) arg0).close();
    super.destroyObject(arg0);
  }

  /*
   * Activate the DocumentumService object to return to the client
   * @see org.apache.commons.pool.PoolableObjectFactory#activateObject(java.lang.Object)
   */
  public void activateObject(Object arg0) throws Exception {
    DocumentumService serviceObj = (DocumentumService) arg0;
    try {
      //check to see if the Documentum connection is still available
      serviceObj.checkSessionOpen();
    } catch (IllegalStateException e) { //closed or not opened yet
      serviceObj.connect(docBase);
    }
    super.activateObject(arg0);
  }
}
