/*
 * Created on Sep. 8, 2003
 *
 * $Revision: 1.1 $
 * $Id: DocumentumServlet.java,v 1.1 2005-04-20 18:12:49 mpgren Exp $
 */
package com.monsanto.tcc.documentumserver;

import com.monsanto.tcc.documentum.*;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;
import org.apache.commons.pool.*;
import org.apache.commons.pool.impl.StackObjectPool;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

/**
 * Servlet to retrieve file from Documentum using the pass in Documentum object id.
 * The documentumconfig.properties file needs to be located on the classpath.
 * Required pass in parameter: object_id
 * <p/>
 * The retrieved Documentum file will be displayed in the browser. The file should
 * define the following values:
 * doc-broker: the Documentum server name
 * user-name: the Documentum user name
 * password: the Documentum password for the user
 * doc-base: the Documentum doc base
 * doc-root: the Documentum folder root
 * name-encoded: if the passed in object name is encoded(true/false)
 * recursive-search: search the sub folder or not(true/false)
 * result-file-cache: using the existing fetched file or not(true/false)
 * retain-connection: the number of Documentum connections to keep
 * web-file-root: the web path to return the retrieved Documentum file to browser
 *
 * @author WWZHOU
 * @web.servlet name="Documentum"
 * @web.servlet-init-param name="config-source"
 * value="com.monsanto.tcc.documentumserver.documentumconfig"
 * @web.servlet-mapping url-pattern="/Documentum"
 */
public class DocumentumServlet extends HttpServlet {
  //jsp page to display multiple results
  private final static String DISPLAY_MULTI_RESULT_URL = "/jsp/display-multi-result.jsp";

  //the physical path where the retrieved Documentum files will be stored
  private String path;

  //the virtual web path to return the file to the web browser
  private String webDocumentPath;

  //the DocumentumService object pool to cache the connection
  private ObjectPool documentumServicePool;

  //default Documentum folder root to start search
  private String defaultFolderName;

  //passed in object name is encoded
  private boolean nameEncoded;

  //recursive to search the sub folder
  private boolean recursiveSearch;

  //use the existing fetched file or fetch the file every time
  private boolean useCache;

  //cache for already retrieved files
  private Map retrievedFileCache;

  /**
   * Initialize the servlet
   *
   * @param cfg
   */
  public void init(ServletConfig cfg) throws ServletException {
    super.init(cfg);
    log("DocumentumServlet init start");
    String prefix = null;
    try {
      prefix = EnvironmentHelper.getPropertyPrefix();
    } catch (EnvironmentHelperException e) {
      throw new ServletException(e.toString());
    }
    String configSource = cfg.getInitParameter("config-source");
    ResourceBundle config = ResourceBundle.getBundle(configSource);
    webDocumentPath = config.getString(prefix + "web-file-root");
    path = cfg.getServletContext().getRealPath(webDocumentPath);

    String docBroker = config.getString(prefix + "doc-broker");
    String userName = config.getString(prefix + "user-name");
    String password = config.getString(prefix + "password");
    String docBase = config.getString(prefix + "doc-base");
    defaultFolderName = config.getString(prefix + "doc-root");
    String nameEncodedValue = config.getString(prefix + "name-encoded");
    if (nameEncodedValue != null) {
      nameEncoded = Boolean.valueOf(nameEncodedValue).booleanValue();
    } else {
      nameEncoded = true;
    }
    String recursiveSearchValue = config.getString(prefix + "recursive-search");
    if (recursiveSearchValue != null) {
      recursiveSearch = Boolean.valueOf(recursiveSearchValue).booleanValue();
    } else {
      recursiveSearch = true;
    }
    String resultCache = config.getString(prefix + "result-file-cache");
    if (resultCache != null) {
      useCache = Boolean.valueOf(resultCache).booleanValue();
    } else {
      useCache = false;
    }

    String keepConnection = config.getString(prefix + "retain-connection");

    //create the DocumentumService object pool
    PoolableObjectFactory documentumServiceFactory = new DocumentumServiceObjectFactory(docBroker, userName, password, docBase);
    documentumServicePool = new StackObjectPool(documentumServiceFactory, Integer.parseInt(keepConnection));
    retrievedFileCache = Collections.synchronizedMap(new HashMap());
    log("DocumentumServlet init complete");
  }

  /**
   * Destroy the servlet
   */
  public void destroy() {
    try {
      //clear the pool to release all holding Documentum connections
      documentumServicePool.close();
    } catch (Exception e) {
    }
    super.destroy();
  }

  protected void doGet(HttpServletRequest req, HttpServletResponse res)
      throws ServletException, IOException {
    try {
      String objectId = req.getParameter("object_id");
      if (objectId == null || objectId.equals("")) {
        String objectName = req.getParameter("object_name");
        String folderName = req.getParameter("folder_name");
        if (objectName == null || objectName.equals("")) {
          throw new DocumentumException("No object name/id specified");
        }
        if (folderName == null || folderName.equals("")) {
          folderName = defaultFolderName;
        }
        if (folderName == null) {
          throw new DocumentumException("No folder name specified");
        }
        String realObjectName = objectName;
        if (nameEncoded) {
          realObjectName = Base64Decoder.decode(objectName);
        }

        List ids = getDocumentumObjectIds(realObjectName, folderName);

        if (ids.size() == 0) {
          throw new DocumentumException("No match Document found");
        }
        if (ids.size() == 1) {
          objectId = ((String[]) ids.get(0))[0];
        } else {
//					req.setAttribute("object_ids", ids);
//					req.getRequestDispatcher(DISPLAY_MULTI_RESULT_URL).forward(
//						req, res);
          HttpSession session = req.getSession();
          session.setAttribute("object_name", realObjectName);
          session.setAttribute("object_ids", ids);
          session.setAttribute("target_url", req.getRequestURL().toString());
          String webAppPath = getWebAppPath(req);
          res.sendRedirect(res.encodeRedirectURL(webAppPath +
              DISPLAY_MULTI_RESULT_URL));
          return;
        }
      }

      String fileName = retrieveDocumentumFile(objectId);
      String mimeType =
          this.getServletConfig().getServletContext().getMimeType(fileName);
      res.setContentType(mimeType);
//			res.addDateHeader("Expires", 0);
//			res.addHeader("Cache-Control", "no-cache");
//			res.addHeader("Pragma", "no-cache");
      req.getRequestDispatcher(webDocumentPath + "/" +
          fileName).forward(req, res);

      /*use sendRedirect() if the above doesn't work*/
//			String webAppPath = getWebAppPath(req);
//			res.sendRedirect(res.encodeRedirectURL(webAppPath + webDocumentPath + 
//				"/" + fileName));
    } catch (DocumentumException e) {
      log("Exception in DocumentumServlet " + e);
      res.getWriter().println("Error retrieving Documentum file. " + e);
    }
  }

  protected void doPost(HttpServletRequest req, HttpServletResponse res)
      throws ServletException, IOException {
    doGet(req, res);
  }

  /**
   * Retrive the Documentum file from Documentum for the given Documentum object id
   *
   * @param objectId
   * @return the file name retrieved
   * @throws DocumentumException if no Documentum document exists for the given object
   *                             id or anything abnormal occurs
   */
  private String retrieveDocumentumFile(String objectId) throws DocumentumException {
    DocumentumService documentumService = null;
    try {
      //check cache first to see if already fetched
      String fileName = (String) retrievedFileCache.get(objectId);
      if (useCache && fileName != null) {
        return fileName;
      }
      documentumService = (DocumentumService) documentumServicePool.borrowObject();
      //pass in null to use the Documentum object name as result file name
      fileName = documentumService.retrieveDocumentById(objectId,
          path, null);
      //put in cache
      retrievedFileCache.put(objectId, fileName);
      return fileName;
    } catch (DocumentumException e) {
      throw e;
    } catch (Exception e) {
      e.printStackTrace();
      throw new DocumentumException("Exception in get DocumentumServiceObject from pool " + e);
    } finally {
      if (documentumService != null) {
        try {
          documentumServicePool.returnObject(documentumService);
        } catch (Exception e) {
        }
      }
    }
  }

  /**
   * Get Documentum object ids which match the given Documentum object name
   *
   * @param objectName
   * @param folderName
   * @return a list of Documentum object ids whose name matches the given object name
   * @throws DocumentumException
   */
  private List getDocumentumObjectIds(String objectName, String folderName)
      throws DocumentumException {
    DocumentumService documentumService = null;
    try {
      documentumService = (DocumentumService) documentumServicePool.borrowObject();
      List ids = documentumService.findIdAndFormatByName(objectName, folderName,
          recursiveSearch);
      return ids;
    } catch (DocumentumException e) {
      throw e;
    } catch (Exception e) {
      throw new DocumentumException("Exception in get DocumentumServiceObject from pool " + e);
    } finally {
      if (documentumService != null) {
        try {
          documentumServicePool.returnObject(documentumService);
        } catch (Exception e) {
        }
      }
    }
  }

  /**
   * Get the Wep application root path
   *
   * @param req
   * @return the web app root path
   */
  private String getWebAppPath(HttpServletRequest req) {
    /*it turns out that we just need to use the context path instead of
     * the whole URL for redirect, so we don't need the following code
     * to create the whole URL
    */
    /*
    String requestURL = req.getRequestURL().toString();
    String servletPath = req.getServletPath();
    int index = requestURL.indexOf(servletPath);
    String webAppPath = requestURL.substring(0, index);
    log("context path is " + req.getContextPath());
    return webAppPath;
    */
    return req.getContextPath();
  }
}
