// ---------------------------------------------------------------------------
// This file has been generated partially by the Web Dynpro Code Generator.
// MODIFY CODE ONLY IN SECTIONS ENCLOSED BY @@begin AND @@end.
// ALL OTHER CHANGES WILL BE LOST IF THE FILE IS REGENERATED.
// ---------------------------------------------------------------------------
package com.monsanto.xrpm;

// 
// IMPORTANT NOTE: 
// _ALL_ IMPORT STATEMENTS MUST BE PLACED IN THE FOLLOWING SECTION ENCLOSED
// BY @@begin imports AND @@end. FURTHERMORE, THIS SECTION MUST ALWAYS CONTAIN
// AT LEAST ONE IMPORT STATEMENT (E.G. THAT FOR IPrivateComp_group_resource_task_rep).
// OTHERWISE, USING THE ECLIPSE FUNCTION "Organize Imports" FOLLOWED BY
// A WEB DYNPRO CODE GENERATION (E.G. PROJECT BUILD) WILL RESULT IN THE LOSS
// OF IMPORT STATEMENTS.
//
//@@begin imports
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;

import com.monsanto.xrpm.model.GroupTaskReport;
import com.monsanto.xrpm.model.Y_Xrpm_Group_Resource_Tasks_Input;
import com.monsanto.xrpm.model.Y_Xrpm_Maintain_Variant_Input;
import com.monsanto.xrpm.model.Y_Xrpm_Search_Help_Input;
import com.monsanto.xrpm.model.Yrespvar;
import com.monsanto.xrpm.wdp.IPrivateComp_group_resource_task_rep;
import com.monsanto.xrpm.wdp.IPrivateView_Rep;
import com.monsanto.xrpm.wdp.IPrivateView_group_resource_task_rep;
import com.monsanto.xrpm.wdp.IPublicComp_group_resource_task_rep;
import com.sap.dictionary.runtime.ISimpleTypeModifiable;
import com.sap.security.api.IUser;
import com.sap.security.api.IUserAccount;
import com.sap.tc.webdynpro.progmodel.api.IWDAttributeInfo;
import com.sap.tc.webdynpro.progmodel.api.IWDNode;
import com.sap.tc.webdynpro.progmodel.api.IWDNodeElement;
import com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener;
import com.sap.tc.webdynpro.progmodel.api.WDVisibility;
import com.sap.tc.webdynpro.progmodel.context.Node;
import com.sap.tc.webdynpro.progmodel.model.api.WDModelFactory;
import com.sap.tc.webdynpro.services.sal.um.api.IWDClientUser;
import com.sap.tc.webdynpro.services.sal.um.api.WDClientUser;
import com.sap.tc.webdynpro.services.session.api.IWDWindow;
import com.sap.tc.webdynpro.services.session.api.WDWindowPos;
import com.sap.typeservices.IModifiableSimpleValueSet;
//@@end

//@@begin documentation
//@@end

public class Comp_group_resource_task_rep
{
  /**
   * Logging location.
   */
  private static final com.sap.tc.logging.Location logger = 
    com.sap.tc.logging.Location.getLocation(Comp_group_resource_task_rep.class);

  static 
  {
    //@@begin id
    String id = "$Id$";
    //@@end
    com.sap.tc.logging.Location.getLocation("ID.com.sap.tc.webdynpro").infoT(id);
  }

  /**
   * Private access to the generated Web Dynpro counterpart 
   * for this controller class.  </p>
   *
   * Use <code>wdThis</code> to gain typed access to the context,
   * to trigger navigation via outbound plugs, to get and enable/disable
   * actions, fire declared events, and access used controllers and/or 
   * component usages.
   *
   * @see com.monsanto.xrpm.wdp.IPrivateComp_group_resource_task_rep for more details
   */
  private final IPrivateComp_group_resource_task_rep wdThis;

  /**
   * Root node of this controller's context. </p>
   *
   * Provides typed access not only to the elements of the root node 
   * but also to all nodes in the context (methods node<i>XYZ</i>()) 
   * and their currently selected element (methods current<i>XYZ</i>Element()). 
   * It also facilitates the creation of new elements for all nodes 
   * (methods create<i>XYZ</i>Element()). </p>
   *
   * @see com.monsanto.xrpm.wdp.IPrivateComp_group_resource_task_rep.IContextNode for more details.
   */
  private final IPrivateComp_group_resource_task_rep.IContextNode wdContext;

  /**
   * A shortcut for <code>wdThis.wdGetAPI()</code>. </p>
   * 
   * Represents the generic API of the generic Web Dynpro counterpart 
   * for this controller. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdControllerAPI;
  
  /**
   * A shortcut for <code>wdThis.wdGetAPI().getComponent()</code>. </p>
   * 
   * Represents the generic API of the Web Dynpro component this controller 
   * belongs to. Can be used to access the message manager, the window manager,
   * to add/remove event handlers and so on. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdComponentAPI;
  
  public Comp_group_resource_task_rep(IPrivateComp_group_resource_task_rep wdThis)
  {
    this.wdThis = wdThis;
    this.wdContext = wdThis.wdGetContext();
    this.wdControllerAPI = wdThis.wdGetAPI();
    this.wdComponentAPI = wdThis.wdGetAPI().getComponent();
  }

  //@@begin javadoc:wdDoInit()
  /** Hook method called to initialize controller. */
  //@@end
  public void wdDoInit()
  {
    //@@begin wdDoInit()
	Y_Xrpm_Search_Help_Input input = new Y_Xrpm_Search_Help_Input();
	wdContext.nodeY_Xrpm_Search_Help_Input().bind(input);
	
	Y_Xrpm_Maintain_Variant_Input variant_input = new Y_Xrpm_Maintain_Variant_Input();
	wdContext.nodeY_Xrpm_Maintain_Variant_Input().bind(variant_input);
	
	Y_Xrpm_Group_Resource_Tasks_Input task_report = new Y_Xrpm_Group_Resource_Tasks_Input();
	wdContext.nodeY_Xrpm_Group_Resource_Tasks_Input().bind(task_report);
	
	wdContext.currentContextElement().setImage_muliti_functionalArea("~sapicons/s_b_more.gif");
	wdContext.currentContextElement().setImage_multi_resp_resource("~sapicons/s_b_more.gif");
	wdContext.currentContextElement().setImage_multi_taskstatus("~sapicons/s_b_more.gif");
	wdContext.currentContextElement().setImage_multi_persons("~sapicons/s_b_more.gif");
	
	wdContext.nodeOVSTaskstatusOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("Task Status");
	wdContext.nodeOVSTaskstatusOutput().getNodeInfo().getAttribute("Yytext1").getModifiableSimpleType().setColumnLabel("Description");
    
	wdContext.nodeOVSTaskstatusInput().getNodeInfo().getAttribute("YYFIELD1").getModifiableSimpleType().setFieldLabel("Task Status");
	wdContext.nodeOVSTaskstatusInput().getNodeInfo().getAttribute("YYTEXT1").getModifiableSimpleType().setFieldLabel("Description");
	
	wdContext.nodeOVSResponsibleResourceOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("User ID");
	wdContext.nodeOVSResponsibleResourceOutput().getNodeInfo().getAttribute("Yyfield2").getModifiableSimpleType().setColumnLabel("Last Name");
	wdContext.nodeOVSResponsibleResourceOutput().getNodeInfo().getAttribute("Yytext1").getModifiableSimpleType().setColumnLabel("First Name");
	
	wdContext.nodeOVSPeopleOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("User ID");
	wdContext.nodeOVSPeopleOutput().getNodeInfo().getAttribute("Yyfield2").getModifiableSimpleType().setColumnLabel("Last Name");
	wdContext.nodeOVSPeopleOutput().getNodeInfo().getAttribute("Yytext1").getModifiableSimpleType().setColumnLabel("First Name");
	
	wdContext.nodeOVSFuncAreaOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("Role Function ID");
	wdContext.nodeOVSFuncAreaOutput().getNodeInfo().getAttribute("Yyfield2").getModifiableSimpleType().setColumnLabel("Role Function Name");
		
	wdContext.nodeOVSRespResInput().getNodeInfo().getAttribute("Field1").getModifiableSimpleType().setFieldLabel("Last Name");
	wdContext.nodeOVSRespResInput().getNodeInfo().getAttribute("Field2").getModifiableSimpleType().setFieldLabel("First Name");
	
	wdContext.nodeOVSPeopleInput().getNodeInfo().getAttribute("Field1").getModifiableSimpleType().setFieldLabel("Last Name");
	wdContext.nodeOVSPeopleInput().getNodeInfo().getAttribute("Field2").getModifiableSimpleType().setFieldLabel("First Name");
	
	//wdContext.nodeOVSFuncAreaInput().getNodeInfo().getAttribute("Field2").getModifiableSimpleType().setFieldLabel("Role Function ID");
	wdContext.nodeOVSFuncAreaInput().getNodeInfo().getAttribute("Field1").getModifiableSimpleType().setFieldLabel("Role Function Name");
	
	wdContext.currentContextElement().setRadioButton_groupBy("2");
	wdContext.currentContextElement().setVisible_group_selection(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_individual_selection(WDVisibility.NONE);
	wdContext.currentContextElement().setRole_function("");
	wdContext.currentContextElement().setPersons("");
	
	//Get userId from portal database
	String strUserid = "";
	try	{
		IWDClientUser wdUser = WDClientUser.getCurrentUser();
		IUser user = wdUser.getSAPUser();
		if (user != null) {
			IUserAccount[] acct = user.getUserAccounts();
			if(acct[0] != null)	{
				strUserid = acct[0].getLogonUid();
				wdContext.currentContextElement().setUserId(strUserid);
			}
		}
		else {
			wdContext.currentContextElement().setUserId("");
			wdComponentAPI.getMessageManager().reportException("Error in retrieving the UserID from portal database", true);
		}
	} catch (Exception e) {
		wdContext.currentContextElement().setUserId("");
		wdComponentAPI.getMessageManager().reportException("Error in retrieving the UserID from portal database", true);
	}
	
	if (!wdContext.currentContextElement().getUserId().equalsIgnoreCase("")) {
		wdThis.fetch_selections();
	}

    //@@end
  }

  //@@begin javadoc:wdDoExit()
  /** Hook method called to clean up controller. */
  //@@end
  public void wdDoExit()
  {
    //@@begin wdDoExit()
    //@@end
  }

  //@@begin javadoc:wdDoPostProcessing()
  /**
   * Hook called to handle data retrieval errors before rendering.
   *
   * After doModifyView(), the Web Dynpro Framework gets all context data needed
   * for rendering by validating the contexts (which in turn calls the supply
   * functions and supplying relation roles). In this hook, the application
   * should handle the errors which occurred during validation of the contexts.
   * 
   * Using preorder depth-first traversal, this hook is called for all component
   * controllers starting with the current root component.
   *
   * Permitted operations:
   * - Flushing model queue
   * - Creating messages
   * - Reading context and model data
   *
   * Forbidden operations: 
   * - Invalidating model data
   * - Manipulating the context
   * - Firing outbound plugs
   * - Creating components
   * - ...   
   *
   * @param isCurrentRoot true if this is the root of the current request
   */
  //@@end
  public void wdDoPostProcessing(boolean isCurrentRoot)
  {
    //@@begin wdDoPostProcessing()
    //@@end
  }

  //@@begin javadoc:wdDoBeforeNavigation()
  /**
   * Hook before the navigation phase starts.
   *
   * This hook allows you to flush the model queue and handle any
   * errors that occur. Firing outbound plugs is allowed in this hook.
   *
   * Using preorder depth-first traversal, this hook is called for all component
   * controllers starting with the current root component.
   *
   * @param isCurrentRoot true if this is the root of the current request
   */
  //@@end
  public void wdDoBeforeNavigation(boolean isCurrentRoot)
  {
    //@@begin wdDoBeforeNavigation()
    //@@end
  }
  
  //@@begin javadoc:wdDoApplicationStateChange()
  /**
   * Hook that informs the application about a state change.
   * <p>
   * This hook is called e.g. to tell the application that will be
   * <ul>
   *  <li>left via a suspend plug and therefore should go into a suspend/sleep
   *      mode with minimal need of resources. errors that occur. Firing 
   *      outbound plugs is allowed in this hook.
   *  <li>left due to a timeout and could write it's state to a data base if the 
   *      user comes back later on
   * </ul>
   *
   * The concrete reason is available via IWDApplicationStateChangeInfo
   * <p>
   * <b>Important</b>: This hook is called for the top level component only!
   *
   * @param stateChangeInfo contains the information about the nature of the state change
   * @param stateChangeReturn allows the application to ask for a different state change. 
   *        The framework is allowed to ignore it considering i.e. the current resources situation.
   */
  //@@end
  public void wdDoApplicationStateChange(com.sap.tc.webdynpro.progmodel.api.IWDApplicationStateChangeInfo stateChangeInfo, com.sap.tc.webdynpro.progmodel.api.IWDApplicationStateChangeReturn stateChangeReturn)
  {
    //@@begin wdDoApplicationStateChange()
    //@@end
  }

  //@@begin javadoc:MD_execute_f4_help_rfc()
  /** Declared method. */
  //@@end
  public void MD_execute_f4_help_rfc( java.lang.String s_help, java.lang.String input1, java.lang.String input2 )
  {
    //@@begin MD_execute_f4_help_rfc()
	String s_temp = s_help;
	wdContext.currentY_Xrpm_Search_Help_InputElement().setS_Help(s_help);
	wdContext.currentY_Xrpm_Search_Help_InputElement().setField1(input1);
	wdContext.currentY_Xrpm_Search_Help_InputElement().setField2(input2);
	
	//Execute the RFC
	try {
		wdContext.currentY_Xrpm_Search_Help_InputElement().modelObject().execute();
		wdContext.nodeHelp_Tab().invalidate();
		wdContext.nodeOutput_Help_Tab().invalidate();
		
		if (wdContext.nodeHelp_Tab().size() > 0) {
			//Sort table elements
			IPublicComp_group_resource_task_rep.IHelp_TabNode node = wdContext.nodeHelp_Tab();
			node.sortElements
			(
			  new Comparator()
			  {
				public int compare(Object x, Object y)
				{
				  /* passed values are of type I<Node>Element */
				  String ax = ((IPublicComp_group_resource_task_rep.IHelp_TabElement) x).getYyfield2();
				  String ay = ((IPublicComp_group_resource_task_rep.IHelp_TabElement) y).getYyfield2();
				  
				  if (ax == null)
				  {
					return ay == null ? 0 : 1;
				  }
				  return ax.compareTo(ay);
				}
			  }
			);
		}
		
	}
	catch (Exception e) {
		wdComponentAPI.getMessageManager().reportException("Error in executing f4 RFC: " + e.getMessage(), true);
	   
		//Disconnect the connection
		GroupTaskReport model = (GroupTaskReport) WDModelFactory.getModelInstance(GroupTaskReport.class);
		model.disconnectIfAlive();
	}
	//Disconnect the connection
	GroupTaskReport model = (GroupTaskReport) WDModelFactory.getModelInstance(GroupTaskReport.class);
	model.disconnectIfAlive();

    //@@end
  }

  //@@begin javadoc:getOVSTaskstatusInputNode()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDNode getOVSTaskstatusInputNode( )
  {
    //@@begin getOVSTaskstatusInputNode()
    return wdContext.nodeOVSTaskstatusInput();
    //@@end
  }

  //@@begin javadoc:getOVSTaskstausOutputNode()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDNode getOVSTaskstausOutputNode( )
  {
    //@@begin getOVSTaskstausOutputNode()
    return wdContext.nodeOVSTaskstatusOutput();
    //@@end
  }

  //@@begin javadoc:getOVSTaskstatusListener()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener getOVSTaskstatusListener( )
  {
    //@@begin getOVSTaskstatusListener()
    return ovsListener_taskstatus;
    //@@end
  }

  //@@begin javadoc:MD_execute_maintain_variant()
  /** Declared method. */
  //@@end
  public void MD_execute_maintain_variant( java.lang.String option )
  {
    //@@begin MD_execute_maintain_variant()
	//Execute the RFC
	try {
		wdContext.currentY_Xrpm_Maintain_Variant_InputElement().setVar_Option(option);
		wdContext.currentY_Xrpm_Maintain_Variant_InputElement().modelObject().execute();
		wdContext.nodeUser_Variant().invalidate();
		wdContext.nodeOutput_User_Variant().invalidate();
		
		if (option.equalsIgnoreCase("SAVE")) {
			wdComponentAPI.getMessageManager().reportSuccess("Selection saved successfully.");
		}
		else 
			if (option.equalsIgnoreCase("DELE")) {
				wdComponentAPI.getMessageManager().reportSuccess("Selection deleted.");
			}
	}
	catch (Exception e) {
		wdComponentAPI.getMessageManager().reportException("Error in executing maintain variant RFC: " + e.getMessage(), true);
	   
		//Disconnect the connection
		GroupTaskReport model = (GroupTaskReport) WDModelFactory.getModelInstance(GroupTaskReport.class);
		model.disconnectIfAlive();
	}
	//Disconnect the connection
	GroupTaskReport model = (GroupTaskReport) WDModelFactory.getModelInstance(GroupTaskReport.class);
	model.disconnectIfAlive();

    //@@end
  }

  //@@begin javadoc:getOVSRespResourceListener()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener getOVSRespResourceListener( )
  {
    //@@begin getOVSRespResourceListener()
	return ovsListener_resp_resource;
    //@@end
  }

  //@@begin javadoc:getOVSRespResourceInputNode()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDNode getOVSRespResourceInputNode( )
  {
    //@@begin getOVSRespResourceInputNode()
	return wdContext.nodeOVSRespResInput();
    //@@end
  }

  //@@begin javadoc:getOVSRespResourceOutputNode()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDNode getOVSRespResourceOutputNode( )
  {
    //@@begin getOVSRespResourceOutputNode()
	return wdContext.nodeOVSResponsibleResourceOutput();
    //@@end
  }

  //@@begin javadoc:getOVSPersonListener()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener getOVSPersonListener( )
  {
    //@@begin getOVSPersonListener()
    return ovsListener_person;
    //@@end
  }

  //@@begin javadoc:open_popup_new()
  /** Declared method. */
  //@@end
  public void open_popup_new( )
  {
    //@@begin open_popup_new()
	popup = wdComponentAPI.getWindowManager().createModalWindow(wdComponentAPI.getComponentInfo().findInWindows("W_popup"));
	popup.setWindowPosition(WDWindowPos.CENTER);
	popup.show();
    //@@end
  }

  //@@begin javadoc:open_popup_saveas()
  /** Declared method. */
  //@@end
  public void open_popup_saveas( )
  {
    //@@begin open_popup_saveas()
	popup1 = wdComponentAPI.getWindowManager().createModalWindow(wdComponentAPI.getComponentInfo().findInWindows("W_popup1"));
	popup1.setWindowPosition(WDWindowPos.CENTER);
	popup1.show();
    //@@end
  }

  //@@begin javadoc:close_popup_new()
  /** Declared method. */
  //@@end
  public void close_popup_new( )
  {
    //@@begin close_popup_new()
	if (popup != null) {
		popup.destroyInstance();
		popup = null;
	}
    //@@end
  }

  //@@begin javadoc:close_popup_saveas()
  /** Declared method. */
  //@@end
  public void close_popup_saveas( )
  {
    //@@begin close_popup_saveas()
	if (popup1 != null) {
		popup1.destroyInstance();
		popup1 = null;
	}
    //@@end
  }

  //@@begin javadoc:open_waring_popup()
  /** Declared method. */
  //@@end
  public void open_waring_popup( )
  {
    //@@begin open_waring_popup()
	warning = wdComponentAPI.getWindowManager().createModalWindow(wdComponentAPI.getComponentInfo().findInWindows("W_warning"));
	warning.setWindowPosition(WDWindowPos.CENTER);
	warning.show();
    //@@end
  }

  //@@begin javadoc:close_waring_popup()
  /** Declared method. */
  //@@end
  public void close_waring_popup( )
  {
    //@@begin close_waring_popup()
	if (warning != null) {
		warning.destroyInstance();
		warning = null;
	}
    //@@end
  }

  //@@begin javadoc:saveNewSelection()
  /** Declared method. */
  //@@end
  public void saveNewSelection( )
  {
    //@@begin saveNewSelection()
	for (int b=0; b < wdContext.nodeInput_User_Variant().size(); b++) {
		wdContext.nodeInput_User_Variant().removeElement(wdContext.nodeInput_User_Variant().getInput_User_VariantElementAt(b));
	}
	wdContext.nodeInput_User_Variant().invalidate();
    	
	//Execute the RFCs
	Yrespvar var = new Yrespvar();
	var.setMandt("208");
	var.setYyuserid(wdContext.currentContextElement().getUserId().toUpperCase());
	var.setYyvarname(wdContext.currentContextElement().getNew_selectionName().toUpperCase());
	var.setYybegda(wdContext.currentContextElement().getBegdate());
	var.setYyendda(wdContext.currentContextElement().getEnddate());
	
	//Get multiple selection table
	IWDNode node = wdThis.wdGetMultipleSelectionInterface().getMultiselectionTable();
	
	String text1 = "", text2 = "", text3 = "", text4 = "";
	 
	for (int z=0; z < node.size(); z++) {
		if (node.getElementAt(z).getAttributeAsText("Field").equalsIgnoreCase("Task Status")) 
			text1 = text1 + node.getElementAt(z).getAttributeAsText("Value1") + ",";
		else 	
			if (node.getElementAt(z).getAttributeAsText("Field").equalsIgnoreCase("Resp Resource")) 
				text2 = text2 + node.getElementAt(z).getAttributeAsText("Value1") + ",";
			else
				if (node.getElementAt(z).getAttributeAsText("Field").equalsIgnoreCase("Person(s)")) 
					text3 = text3 + node.getElementAt(z).getAttributeAsText("Value1") + ",";
				else
					if (node.getElementAt(z).getAttributeAsText("Field").equalsIgnoreCase("Role Function")) 
						text4 = text4 + node.getElementAt(z).getAttributeAsText("Value1") + ",";	
	}	

	//set task staus
	try {
		if (text1.equalsIgnoreCase("")) {
			if (!wdContext.currentTaskStatusElement().getTask_staus().equalsIgnoreCase(""))
				text1 = wdContext.currentTaskStatusElement().getTask_staus() + ",";
			else
				text1 = ",";		 
		}
	}
	catch (NullPointerException e) {
		text1 = ",";
	}
	
	//set resp resource
	try {
		if (text2.equalsIgnoreCase("")) {
			if (!wdContext.currentResponsibleResourceElement().getField1().equalsIgnoreCase(""))
				text2 = wdContext.currentResponsibleResourceElement().getField1() + ",";
			else
				text2 = ",";		 
		}
	}
	catch (NullPointerException e) {
		text2 = ",";
	}
	
	//set person(s)
	try {
		if (text3.equalsIgnoreCase("")) {
			if (!wdContext.currentPersonElement().getField1().equalsIgnoreCase(""))
				text3 = wdContext.currentPersonElement().getField1() + ",";
			else
				text3 = ",";		 
		}
	}
	catch (NullPointerException e) {
		text3 = ",";
	}
	
	//set functional area
	try {
		if (text4.equalsIgnoreCase("")) {
			if (!wdContext.currentFunctionalAreaElement().getFuntional_area().equalsIgnoreCase(""))
				text4 = wdContext.currentFunctionalAreaElement().getFuntional_area() + ",";
			else
				text4 = ",";		 
		}
	}
	catch (NullPointerException e) {
		text4 = ",";
	}

	if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("2")) {
		var.setYygflag("A"); //Area
		var.setYyrespre(wdContext.currentContextElement().getResponsible_area()); //Responsible Area
		var.setYyrespbu(text4.toUpperCase()); //Functional Area
		
	}
	else {//"1"	 
		var.setYygflag("P"); //Person(s)
		var.setYyrespre(text2.toUpperCase()); //Responsible Resource
		var.setYyrespbu(text3.toUpperCase()); //Person(s)
	}
	
	var.setYystatus(text1);
	
//	wdComponentAPI.getMessageManager().reportSuccess("task sta" + text1 + "xx");
//	wdComponentAPI.getMessageManager().reportSuccess("rep resource" + text2  + "xx");
//	wdComponentAPI.getMessageManager().reportSuccess("person" + text3  + "xx");
//	wdComponentAPI.getMessageManager().reportSuccess("function" + text4  + "xx");
	
	wdContext.currentY_Xrpm_Maintain_Variant_InputElement().modelObject().addUser_Variant(var);
	
	wdThis.MD_execute_maintain_variant("SAVE");
	
	wdThis.fetch_selections();
	
	//set the current variant as default
	wdThis.change_variant(wdContext.currentContextElement().getNew_selectionName().toUpperCase()); 

    //@@end
  }

  //@@begin javadoc:delete_selection()
  /** Declared method. */
  //@@end
  public void delete_selection( )
  {
    //@@begin delete_selection()
	wdThis.close_popup_delete();
	for (int b=0; b < wdContext.nodeInput_User_Variant().size(); b++) {
		wdContext.nodeInput_User_Variant().removeElement(wdContext.nodeInput_User_Variant().getInput_User_VariantElementAt(b));
	}
	wdContext.nodeInput_User_Variant().invalidate();
    
	Yrespvar var = new Yrespvar();
	var.setMandt("208");
	var.setYyuserid(wdContext.currentContextElement().getUserId().toUpperCase());
	var.setYyvarname(wdContext.currentContextElement().getSavedSelection());
	wdContext.currentY_Xrpm_Maintain_Variant_InputElement().modelObject().addUser_Variant(var);
	wdThis.MD_execute_maintain_variant("DELE");
	
	
	//-----Set default values------
	wdContext.currentTaskStatusElement().setTask_staus("");
	wdContext.currentResponsibleResourceElement().setField1("");
	wdContext.currentPersonElement().setField1("");
	wdContext.currentFunctionalAreaElement().setFuntional_area("");
	wdContext.currentContextElement().setResponsible_area("");
	
	java.util.Date utilDate = new java.util.Date();
	java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
	wdContext.currentContextElement().setBegdate(null);
	wdContext.currentContextElement().setEnddate(null);
	wdContext.currentContextElement().setSavedSelection("");
	wdContext.currentContextElement().setRadioButton_groupBy("2");
	//------------------------------------
	
	wdThis.fetch_selections();

    //@@end
  }

  //@@begin javadoc:fetch_selections()
  /** Declared method. */
  //@@end
  public void fetch_selections( )
  {
    //@@begin fetch_selections()
	wdContext.currentContextElement().setRole_function("");
	wdContext.currentContextElement().setPersons("");
    
	for (int b = wdContext.nodeInput_User_Variant().size() -1; b >=0; --b) {
		wdContext.nodeInput_User_Variant().removeElement(wdContext.nodeInput_User_Variant().getInput_User_VariantElementAt(b));
	}
	wdContext.nodeInput_User_Variant().invalidate();
	
	Yrespvar var = new Yrespvar();
	var.setMandt("208");
	var.setYyuserid(wdContext.currentContextElement().getUserId().toUpperCase());
	var.setYyvarname("");
	wdContext.currentY_Xrpm_Maintain_Variant_InputElement().modelObject().addUser_Variant(var);
	wdThis.MD_execute_maintain_variant("FETC");
	
	for (int b = wdContext.nodeUser_Variant_Temp().size() - 1; b >=0; --b) {
		wdContext.nodeUser_Variant_Temp().removeElement(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(b));
	}
	wdContext.nodeUser_Variant_Temp().invalidate();

	for (int j=0; j < wdContext.nodeUser_Variant().size(); j++) {
		IPublicComp_group_resource_task_rep.IUser_Variant_TempElement var_temp = wdContext.createUser_Variant_TempElement();
		var_temp.setMandt(wdContext.nodeUser_Variant().getUser_VariantElementAt(j).getMandt());
		var_temp.setYybegda(wdContext.nodeUser_Variant().getUser_VariantElementAt(j).getYybegda());
		var_temp.setYyendda(wdContext.nodeUser_Variant().getUser_VariantElementAt(j).getYyendda());
		var_temp.setYygflag(wdContext.nodeUser_Variant().getUser_VariantElementAt(j).getYygflag());
		var_temp.setYyrespbu(wdContext.nodeUser_Variant().getUser_VariantElementAt(j).getYyrespbu());
		var_temp.setYyrespre(wdContext.nodeUser_Variant().getUser_VariantElementAt(j).getYyrespre());
		var_temp.setYystatus(wdContext.nodeUser_Variant().getUser_VariantElementAt(j).getYystatus());
		var_temp.setYyuserid(wdContext.nodeUser_Variant().getUser_VariantElementAt(j).getYyuserid());
		var_temp.setYyvarname(wdContext.nodeUser_Variant().getUser_VariantElementAt(j).getYyvarname());
		wdContext.nodeUser_Variant_Temp().addElement(var_temp);
	}

	IWDAttributeInfo attributeInfo = this.wdContext.getNodeInfo().getAttribute("savedSelection");
	ISimpleTypeModifiable savedSelectionType = attributeInfo.getModifiableSimpleType();
	valueSet = savedSelectionType.getSVServices().getModifiableSimpleValueSet();
	valueSet.clear();
		
	for (int b=0; b < wdContext.nodeUser_Variant_Temp().size(); b++) 
		valueSet.put(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(b).getYyvarname(), wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(b).getYyvarname());
			
	if (valueSet.size() > 0) {
		
		for (int b = wdContext.nodeTableToMultiselection().size() - 1; b >=0 ; --b) {
			wdContext.nodeTableToMultiselection().removeElement(wdContext.nodeTableToMultiselection().getTableToMultiselectionElementAt(b));
		}
		wdContext.nodeTableToMultiselection().invalidate();
		
		wdContext.currentContextElement().setSavedSelection(valueSet.getText(0));
		wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
		wdContext.currentContextElement().setTray_header_text("Saved selections");
		wdContext.currentContextElement().setSelectedKey("2");
		wdContext.currentContextElement().setVisible_new_variantName(WDVisibility.NONE);
		wdContext.currentContextElement().setVisible_variantName(WDVisibility.VISIBLE);
		
		wdContext.currentContextElement().setBegdate(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYybegda());
		wdContext.currentContextElement().setEnddate(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYyendda());
		
//		wdThis.MD_execute_f4_help_rfc("TS", "", "");
		//Task status
		String[] strFull_task_staus = splitString(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYystatus());
//		wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYystatus());
		for (int d=0; d < strFull_task_staus.length; d++) {
			IPublicComp_group_resource_task_rep.ITableToMultiselectionElement table_to_multi = wdContext.createTableToMultiselectionElement();		
			table_to_multi.setField("Task Status");
			table_to_multi.setValue1(strFull_task_staus[d]);
			table_to_multi.setCategory("Tab_single_include");
			table_to_multi.setExtra1("");
//			for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
//				if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_task_staus[d])) {
//					table_to_multi.setExtra1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
//					//wdContext.currentTaskStatusElement().setDescription(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
//					break;
//				}
//			}
			
			table_to_multi.setExtra2("");
			table_to_multi.setOperation("EQ");
			table_to_multi.setOperation_image("~sapicons/s_bgequa.gif");
			table_to_multi.setValue2("");
			table_to_multi.setTo("");
			wdContext.nodeTableToMultiselection().addElement(table_to_multi);
		}
		
		String[] strFull_fun_area = {} ,strFull_resp_resource = {} , strFull_persons = {}; 
		
		if (wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYygflag().equalsIgnoreCase("A")) {
			wdContext.currentContextElement().setRadioButton_groupBy("2"); //Area
			wdContext.currentContextElement().setVisible_group_selection(WDVisibility.VISIBLE);
			wdContext.currentContextElement().setVisible_individual_selection(WDVisibility.NONE);
			wdContext.currentContextElement().setResponsible_area(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYyrespre());
			
			wdThis.MD_execute_f4_help_rfc("RF", "", "");
			
			strFull_fun_area = splitString(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYyrespbu());
			for (int b=0; b < strFull_fun_area.length; b++) {
				IPublicComp_group_resource_task_rep.ITableToMultiselectionElement table_to_multi = wdContext.createTableToMultiselectionElement();		
				table_to_multi.setField("Role Function");
				table_to_multi.setValue1(strFull_fun_area[b]);
				table_to_multi.setCategory("Tab_single_include");
				table_to_multi.setExtra1("");
				
				for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
					if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_fun_area[b])) {
						//wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						table_to_multi.setExtra1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						//wdContext.currentFunctionalAreaElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						//wdContext.currentContextElement().setRole_function(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						break;
					}
				}
				
				table_to_multi.setExtra2("");
				table_to_multi.setOperation("EQ");
				table_to_multi.setOperation_image("~sapicons/s_bgequa.gif");
				table_to_multi.setValue2("");
				table_to_multi.setTo("");
				wdContext.nodeTableToMultiselection().addElement(table_to_multi);
			}
		}
		else { 
			wdContext.currentContextElement().setRadioButton_groupBy("1"); //Person(s)
			wdContext.currentContextElement().setVisible_group_selection(WDVisibility.NONE);
			wdContext.currentContextElement().setVisible_individual_selection(WDVisibility.VISIBLE);
			
			wdThis.MD_execute_f4_help_rfc("RP", "", "");
			
//			strFull_resp_resource = splitString(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYyrespre());
//			for (int b=0; b < strFull_resp_resource.length; b++) {
//				IPublicComp_group_resource_task_rep.ITableToMultiselectionElement table_to_multi = wdContext.createTableToMultiselectionElement();		
//				table_to_multi.setField("Resp Resource");
//				table_to_multi.setValue1(strFull_resp_resource[b]);
//				table_to_multi.setCategory("Tab_single_include");
//				table_to_multi.setExtra1("");
//				for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
//					if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_resp_resource[b])) {
//						table_to_multi.setExtra1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
//						wdContext.currentResponsibleResourceElement().setField2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2());
//						wdContext.currentResponsibleResourceElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
//						wdContext.currentResponsibleResourceElement().setField4(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
//						break;
//					}
//				}
//				
//				table_to_multi.setExtra2("");
//				table_to_multi.setOperation("EQ");
//				table_to_multi.setOperation_image("~sapicons/s_bgequa.gif");
//				table_to_multi.setValue2("");
//				table_to_multi.setTo("");
//				wdContext.nodeTableToMultiselection().addElement(table_to_multi);
//			}
			
			strFull_persons = splitString(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYyrespbu());
			for (int c=0; c < strFull_persons.length; c++) {
				IPublicComp_group_resource_task_rep.ITableToMultiselectionElement table_to_multi = wdContext.createTableToMultiselectionElement();		
				table_to_multi.setField("Person(s)");
				table_to_multi.setValue1(strFull_persons[c]);
				table_to_multi.setCategory("Tab_single_include");
				table_to_multi.setExtra1("");
				for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
					if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_persons[c])) {
						table_to_multi.setExtra1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						//wdContext.currentPersonElement().setField2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2());
						//wdContext.currentPersonElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						//wdContext.currentPersonElement().setField4(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						break;
					}
				}
				
				table_to_multi.setExtra2("");
				table_to_multi.setOperation("EQ");
				table_to_multi.setOperation_image("~sapicons/s_bgequa.gif");
				table_to_multi.setValue2("");
				table_to_multi.setTo("");
				wdContext.nodeTableToMultiselection().addElement(table_to_multi);
			}	   
		}
		
		//Change multiple selection images
		if (strFull_task_staus.length > 1) 					
			wdContext.currentContextElement().setImage_multi_taskstatus("~sapicons/s_bgmore.gif");
		else 		
			wdContext.currentContextElement().setImage_multi_taskstatus("~sapicons/s_b_more.gif");
				
		if (strFull_resp_resource.length > 1)
			wdContext.currentContextElement().setImage_multi_resp_resource("~sapicons/s_bgmore.gif");
		else
			wdContext.currentContextElement().setImage_multi_resp_resource("~sapicons/s_b_more.gif");

		if (strFull_persons.length > 1)
			wdContext.currentContextElement().setImage_multi_persons("~sapicons/s_bgmore.gif");
		else
			wdContext.currentContextElement().setImage_multi_persons("~sapicons/s_b_more.gif");
 
		if (strFull_fun_area.length > 1)
			wdContext.currentContextElement().setImage_muliti_functionalArea("~sapicons/s_bgmore.gif");
		else
			wdContext.currentContextElement().setImage_muliti_functionalArea("~sapicons/s_b_more.gif");
 		

		String task_stat = "", func_area = "", resp_res = "", persons = "";
		
		if (strFull_task_staus.length > 0) {	
			task_stat = strFull_task_staus[0];
			wdContext.currentTaskStatusElement().setTask_staus(task_stat);
//			wdThis.MD_execute_f4_help_rfc("TS", task_stat, "");
//			for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
//				if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(task_stat)) {
//					wdContext.currentTaskStatusElement().setDescription(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
//					break;
//				}
//			}
		}
		
//		if (strFull_resp_resource.length > 0) {	
//			resp_res = strFull_resp_resource[0];
//			wdThis.MD_execute_f4_help_rfc("RP", task_stat, "");
//			for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
//				if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(task_stat)) {
//					wdContext.currentTaskStatusElement().setDescription(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
//					break;
//				}
//			}
//		
//		}
			
		if (strFull_persons.length > 0) {	
			persons = strFull_persons[0];
			wdContext.currentPersonElement().setField1(persons);
			wdThis.MD_execute_f4_help_rfc("RP", "", "");
			for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
				if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(persons)) {
					wdContext.currentPersonElement().setField2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2());
					wdContext.currentPersonElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
					wdContext.currentPersonElement().setField4(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
					wdContext.currentContextElement().setPersons(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
					break;
				}
			}
		}
					
		if (strFull_fun_area.length > 0) {	
			func_area = strFull_fun_area[0];
			wdContext.currentFunctionalAreaElement().setFuntional_area(func_area);
			wdThis.MD_execute_f4_help_rfc("RF", func_area, "");
			for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
				if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(func_area)) {
					wdContext.currentFunctionalAreaElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
					wdContext.currentContextElement().setRole_function(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
					break;
				}
			}
		}
		
		//send the data to multiple selection component
		wdThis.wdGetMultipleSelectionInterface().setMultiple_selection_table(wdContext.nodeTableToMultiselection());
		
//		wdContext.currentResponsibleResourceElement().setField1(resp_res);
		
		

	}
	else {
		valueSet.clear();
		wdThis.open_waring_popup();
		
		//-----Set default values------
		wdContext.currentTaskStatusElement().setTask_staus("");
		wdContext.currentTaskStatusElement().setDescription("");
		
		//wdContext.currentResponsibleResourceElement().setField1("");
		wdContext.currentPersonElement().setField1("");
		wdContext.currentPersonElement().setField2("");
		wdContext.currentPersonElement().setField3("");
		wdContext.currentPersonElement().setField4("");
		
		wdContext.currentFunctionalAreaElement().setFuntional_area("");
		wdContext.currentFunctionalAreaElement().setField3("");
		
		wdContext.currentContextElement().setResponsible_area("");
	
		java.util.Date utilDate = new java.util.Date();
		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
		wdContext.currentContextElement().setBegdate(null);
		wdContext.currentContextElement().setEnddate(null);
		wdContext.currentContextElement().setSavedSelection("");
		wdContext.currentContextElement().setRadioButton_groupBy("2");
		//wdContext.currentContextElement().setRole_function("");
		//------------------------------------
		
		for (int b=wdContext.nodeTableToMultiselection().size()-1; b >=0; --b) {
			wdContext.nodeTableToMultiselection().removeElement(wdContext.nodeTableToMultiselection().getTableToMultiselectionElementAt(b));
		}
		wdContext.nodeTableToMultiselection().invalidate();
		
		//send the data to multiple selection component
		wdThis.wdGetMultipleSelectionInterface().setMultiple_selection_table(wdContext.nodeTableToMultiselection());
		wdContext.currentContextElement().setImage_muliti_functionalArea("~sapicons/s_b_more.gif");
		wdContext.currentContextElement().setImage_multi_resp_resource("~sapicons/s_b_more.gif");
		wdContext.currentContextElement().setImage_multi_taskstatus("~sapicons/s_b_more.gif");
		wdContext.currentContextElement().setImage_multi_persons("~sapicons/s_b_more.gif");
		
	}

    //@@end
  }

  //@@begin javadoc:open_popup_delete()
  /** Declared method. */
  //@@end
  public void open_popup_delete( )
  {
    //@@begin open_popup_delete()
	popup2 = wdComponentAPI.getWindowManager().createModalWindow(wdComponentAPI.getComponentInfo().findInWindows("W_popup2"));
	popup2.setWindowPosition(WDWindowPos.CENTER);
	popup2.show();
    //@@end
  }

  //@@begin javadoc:close_popup_delete()
  /** Declared method. */
  //@@end
  public void close_popup_delete( )
  {
    //@@begin close_popup_delete()
	if (popup2 != null) {
		popup2.destroyInstance();
		popup2 = null;
	}
    //@@end
  }

  //@@begin javadoc:saveExistingSelection()
  /** Declared method. */
  //@@end
  public void saveExistingSelection( )
  {
    //@@begin saveExistingSelection()
	for (int b=0; b < wdContext.nodeInput_User_Variant().size(); b++) {
		wdContext.nodeInput_User_Variant().removeElement(wdContext.nodeInput_User_Variant().getInput_User_VariantElementAt(b));
	}
	wdContext.nodeInput_User_Variant().invalidate();
    	
	//Execute the RFCs
	Yrespvar var = new Yrespvar();
	var.setMandt("208");
	var.setYyuserid(wdContext.currentContextElement().getUserId().toUpperCase());
	var.setYyvarname(wdContext.currentContextElement().getSavedSelection());
	var.setYybegda(wdContext.currentContextElement().getBegdate());
	var.setYyendda(wdContext.currentContextElement().getEnddate());
	
	String variant = wdContext.currentContextElement().getSavedSelection();
	
	//Get multiple selection table
	IWDNode node = wdThis.wdGetMultipleSelectionInterface().getMultiselectionTable();
	String text1 = "", text2 = "", text3 = "", text4 = "";
	 
	for (int z=0; z < node.size(); z++) {
		if (node.getElementAt(z).getAttributeAsText("Field").equalsIgnoreCase("Task Status")) 
			text1 = text1 + node.getElementAt(z).getAttributeAsText("Value1") + ",";
		else 	
			if (node.getElementAt(z).getAttributeAsText("Field").equalsIgnoreCase("Resp Resource")) 
				text2 = text2 + node.getElementAt(z).getAttributeAsText("Value1") + ",";
			else
				if (node.getElementAt(z).getAttributeAsText("Field").equalsIgnoreCase("Person(s)")) 
					text3 = text3 + node.getElementAt(z).getAttributeAsText("Value1") + ",";
				else
					if (node.getElementAt(z).getAttributeAsText("Field").equalsIgnoreCase("Role Function")) 
						text4 = text4 + node.getElementAt(z).getAttributeAsText("Value1") + ",";	
	}	
	
	//set task staus
	try {
		if (text1.equalsIgnoreCase("")) {
			if (!wdContext.currentTaskStatusElement().getTask_staus().equalsIgnoreCase(""))
				text1 = wdContext.currentTaskStatusElement().getTask_staus() + ",";
			else
				text1 = ",";		 
		}
	}
	catch (NullPointerException e) {
		text1 = ",";
	}
	
	//set resp resource
	try {
		if (text2.equalsIgnoreCase("")) {
			if (!wdContext.currentResponsibleResourceElement().getField1().equalsIgnoreCase(""))
				text2 = wdContext.currentResponsibleResourceElement().getField1() + ",";
			else
				text2 = ",";		 
		}
	}
	catch (NullPointerException e) {
		text2 = ",";
	}
	
	//set person(s)
	try {
		if (text3.equalsIgnoreCase("")) {
			if (!wdContext.currentPersonElement().getField1().equalsIgnoreCase(""))
				text3 = wdContext.currentPersonElement().getField1() + ",";
			else
				text3 = ",";		 
		}
	}
	catch (NullPointerException e) {
		text3 = ",";
	}
	
	//set functional area
	try {
		if (text4.equalsIgnoreCase("")) {
			if (!wdContext.currentFunctionalAreaElement().getFuntional_area().equalsIgnoreCase(""))
				text4 = wdContext.currentFunctionalAreaElement().getFuntional_area() + ",";
			else
				text4 = ",";		 
		}
	}
	catch (NullPointerException e) {
		text4 = ",";
	}
	
	if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("2")) {
		var.setYygflag("A"); //Area
		var.setYyrespre(wdContext.currentContextElement().getResponsible_area()); //Responsible Area
		var.setYyrespbu(text4.toUpperCase()); //Functional Area
		
	}
	else {//"1"	 
		var.setYygflag("P"); //Person(s)
		var.setYyrespre(text2.toUpperCase()); //Responsible Resource
		var.setYyrespbu(text3.toUpperCase()); //Person(s)
	}
	
	var.setYystatus(text1);
	
//	wdComponentAPI.getMessageManager().reportSuccess("task sta" + text1 + "xx");
//	wdComponentAPI.getMessageManager().reportSuccess("rep resource" + text2  + "xx");
//	wdComponentAPI.getMessageManager().reportSuccess("person" + text3  + "xx");
//	wdComponentAPI.getMessageManager().reportSuccess("function" + text4  + "xx");
	wdContext.currentY_Xrpm_Maintain_Variant_InputElement().modelObject().addUser_Variant(var);
	wdThis.MD_execute_maintain_variant("SAVE");
	
	wdThis.fetch_selections();
	
	//set the current variant as default
	wdThis.change_variant(variant);

    //@@end
  }

  //@@begin javadoc:saveAsSelection()
  /** Declared method. */
  //@@end
  public void saveAsSelection( )
  {
    //@@begin saveAsSelection()
	for (int b=0; b < wdContext.nodeInput_User_Variant().size(); b++) {
		wdContext.nodeInput_User_Variant().removeElement(wdContext.nodeInput_User_Variant().getInput_User_VariantElementAt(b));
	}
	wdContext.nodeInput_User_Variant().invalidate();
    	
	//Execute the RFCs
	Yrespvar var = new Yrespvar();
	var.setMandt("208");
	var.setYyuserid(wdContext.currentContextElement().getUserId().toUpperCase());
	var.setYyvarname(wdContext.currentContextElement().getSaveAs_selectionName().toUpperCase());
	var.setYybegda(wdContext.currentContextElement().getBegdate());
	var.setYyendda(wdContext.currentContextElement().getEnddate());
	
	//Get multiple selection table
	IWDNode node = wdThis.wdGetMultipleSelectionInterface().getMultiselectionTable();
	
	String text1 = "", text2 = "", text3 = "", text4 = "";
	 
	for (int z=0; z < node.size(); z++) {
		if (node.getElementAt(z).getAttributeAsText("Field").equalsIgnoreCase("Task Status")) 
			text1 = text1 + node.getElementAt(z).getAttributeAsText("Value1") + ",";
		else 	
			if (node.getElementAt(z).getAttributeAsText("Field").equalsIgnoreCase("Resp Resource")) 
				text2 = text2 + node.getElementAt(z).getAttributeAsText("Value1") + ",";
			else
				if (node.getElementAt(z).getAttributeAsText("Field").equalsIgnoreCase("Person(s)")) 
					text3 = text3 + node.getElementAt(z).getAttributeAsText("Value1") + ",";
				else
					if (node.getElementAt(z).getAttributeAsText("Field").equalsIgnoreCase("Role Function")) 
						text4 = text4 + node.getElementAt(z).getAttributeAsText("Value1") + ",";	
	}	

	//set task staus
	try {
		if (text1.equalsIgnoreCase("")) {
			if (!wdContext.currentTaskStatusElement().getTask_staus().equalsIgnoreCase(""))
				text1 = wdContext.currentTaskStatusElement().getTask_staus() + ",";
			else
				text1 = ",";		 
		}
	}
	catch (NullPointerException e) {
		text1 = ",";
	}
	
	//set resp resource
	try {
		if (text2.equalsIgnoreCase("")) {
			if (!wdContext.currentResponsibleResourceElement().getField1().equalsIgnoreCase(""))
				text2 = wdContext.currentResponsibleResourceElement().getField1() + ",";
			else
				text2 = ",";		 
		}
	}
	catch (NullPointerException e) {
		text2 = ",";
	}
	
	//set person(s)
	try {
		if (text3.equalsIgnoreCase("")) {
			if (!wdContext.currentPersonElement().getField1().equalsIgnoreCase(""))
				text3 = wdContext.currentPersonElement().getField1() + ",";
			else
				text3 = ",";		 
		}
	}
	catch (NullPointerException e) {
		text3 = ",";
	}
	
	//set functional area
	try {
		if (text4.equalsIgnoreCase("")) {
			if (!wdContext.currentFunctionalAreaElement().getFuntional_area().equalsIgnoreCase(""))
				text4 = wdContext.currentFunctionalAreaElement().getFuntional_area() + ",";
			else
				text4 = ",";		 
		}
	}
	catch (NullPointerException e) {
		text4 = ",";
	}

	if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("2")) {
		var.setYygflag("A"); //Area
		var.setYyrespre(wdContext.currentContextElement().getResponsible_area()); //Responsible Area
		var.setYyrespbu(text4.toUpperCase()); //Functional Area
		
	}
	else {//"1"	 
		var.setYygflag("P"); //Person(s)
		var.setYyrespre(text2.toUpperCase()); //Responsible Resource
		var.setYyrespbu(text3.toUpperCase()); //Person(s)
	}
	
	var.setYystatus(text1);
	
//	wdComponentAPI.getMessageManager().reportSuccess("task sta" + text1 + "xx");
//	wdComponentAPI.getMessageManager().reportSuccess("rep resource" + text2  + "xx");
//	wdComponentAPI.getMessageManager().reportSuccess("person" + text3  + "xx");
//	wdComponentAPI.getMessageManager().reportSuccess("function" + text4  + "xx");
	wdContext.currentY_Xrpm_Maintain_Variant_InputElement().modelObject().addUser_Variant(var);
	wdThis.MD_execute_maintain_variant("SAVE");
	
	wdThis.fetch_selections();
	
	//set the current variant as default
	wdThis.change_variant(wdContext.currentContextElement().getSaveAs_selectionName().toUpperCase());

    //@@end
  }

  //@@begin javadoc:notOverride()
  /** Declared method. */
  //@@end
  public boolean notOverride( java.lang.String variantName )
  {
    //@@begin notOverride()
    for (int m=0; m < valueSet.size(); m++) {
    	if (valueSet.getKey(m).toString().equalsIgnoreCase(variantName)) {
    		return false;
    	}
    }
    return true;
    //@@end
  }

  //@@begin javadoc:open_popup_overwrite()
  /** Declared method. */
  //@@end
  public void open_popup_overwrite( )
  {
    //@@begin open_popup_overwrite()
	popup3 = wdComponentAPI.getWindowManager().createModalWindow(wdComponentAPI.getComponentInfo().findInWindows("W_popup3"));
	popup3.setWindowPosition(WDWindowPos.CENTER);
	popup3.show();
    //@@end
  }

  //@@begin javadoc:close_popup_overwrite()
  /** Declared method. */
  //@@end
  public void close_popup_overwrite( )
  {
    //@@begin close_popup_overwrite()
	if (popup3 != null) {
		popup3.destroyInstance();
		popup3 = null;
	}
    //@@end
  }

  //@@begin javadoc:setDefaultAsFirstElement()
  /** Declared method. */
  //@@end
  public void setDefaultAsFirstElement( )
  {
    //@@begin setDefaultAsFirstElement()
    wdContext.currentContextElement().setSavedSelection(valueSet.getKey(0).toString());
    //@@end
  }

  //@@begin javadoc:getOVSPersonOutputNode()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDNode getOVSPersonOutputNode( )
  {
    //@@begin getOVSPersonOutputNode()
    return wdContext.nodeOVSPeopleOutput();
    //@@end
  }

  //@@begin javadoc:getOVSPersonInputNode()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDNode getOVSPersonInputNode( )
  {
    //@@begin getOVSPersonInputNode()
	return wdContext.nodeOVSPeopleInput();
    //@@end
  }

  //@@begin javadoc:getOVSFunctionalAreaListener()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener getOVSFunctionalAreaListener( )
  {
    //@@begin getOVSFunctionalAreaListener()
    return ovsListener_func_area;
    //@@end
  }

  //@@begin javadoc:getOVSFunctionalAreaInputNode()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDNode getOVSFunctionalAreaInputNode( )
  {
    //@@begin getOVSFunctionalAreaInputNode()
    return wdContext.nodeOVSFuncAreaInput();
    //@@end
  }

  //@@begin javadoc:getOVSFunctionalAreaOutputNode()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDNode getOVSFunctionalAreaOutputNode( )
  {
    //@@begin getOVSFunctionalAreaOutputNode()
	return wdContext.nodeOVSFuncAreaOutput();
    //@@end
  }

  //@@begin javadoc:change_variant()
  /** Declared method. */
  //@@end
  public void change_variant( java.lang.String variant_name )
  {
    //@@begin change_variant()
	wdContext.currentContextElement().setRole_function("");
	wdContext.currentContextElement().setPersons("");
	wdContext.currentContextElement().setSavedSelection(variant_name); 
	Node node = wdContext.nodeUser_Variant_Temp();
	for (int n=0; n < node.size(); n++) {
		if (node.getElementAt(n).getAttributeAsText("Yyvarname").equalsIgnoreCase(variant_name)) {
			wdContext.currentContextElement().setBegdate(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(n).getYybegda());
			wdContext.currentContextElement().setEnddate(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(n).getYyendda());
			if (wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(n).getYygflag().equalsIgnoreCase("A")) //Area
				wdContext.currentContextElement().setRadioButton_groupBy("2");
			else
				wdContext.currentContextElement().setRadioButton_groupBy("1");	
    		
			for (int b=wdContext.nodeTableToMultiselection().size()-1; b >=0; --b) {
				wdContext.nodeTableToMultiselection().removeElement(wdContext.nodeTableToMultiselection().getTableToMultiselectionElementAt(b));
			}
			wdContext.nodeTableToMultiselection().invalidate();
    		
			//Task status
			String[] strFull_task_staus = splitString(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(n).getYystatus());
			for (int d=0; d < strFull_task_staus.length; d++) {
				IPublicComp_group_resource_task_rep.ITableToMultiselectionElement table_to_multi = wdContext.createTableToMultiselectionElement();		
				table_to_multi.setField("Task Status");
				table_to_multi.setValue1(strFull_task_staus[d]);
				table_to_multi.setCategory("Tab_single_include");
				table_to_multi.setExtra1("");
				table_to_multi.setExtra2("");
				table_to_multi.setOperation("EQ");
				table_to_multi.setOperation_image("~sapicons/s_bgequa.gif");
				table_to_multi.setValue2("");
				table_to_multi.setTo("");
				wdContext.nodeTableToMultiselection().addElement(table_to_multi);
			}
		
			String[] strFull_fun_area = {} ,strFull_resp_resource = {} , strFull_persons = {}; 
		
			if (wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(n).getYygflag().equalsIgnoreCase("A")) {
				wdContext.currentContextElement().setRadioButton_groupBy("2"); //Area
				wdContext.currentContextElement().setVisible_group_selection(WDVisibility.VISIBLE);
				wdContext.currentContextElement().setVisible_individual_selection(WDVisibility.NONE);
				wdContext.currentContextElement().setResponsible_area(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(n).getYyrespre());
				
				wdThis.MD_execute_f4_help_rfc("RF", "", "");
				strFull_fun_area = splitString(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(n).getYyrespbu());
				
				for (int b=0; b < strFull_fun_area.length; b++) {
					IPublicComp_group_resource_task_rep.ITableToMultiselectionElement table_to_multi = wdContext.createTableToMultiselectionElement();		
					table_to_multi.setField("Role Function");
					table_to_multi.setValue1(strFull_fun_area[b]);
					table_to_multi.setCategory("Tab_single_include");
					table_to_multi.setExtra1("");
					
					for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
						if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_fun_area[b])) {
							//wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
							table_to_multi.setExtra1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
							//wdContext.currentFunctionalAreaElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
							//wdContext.currentContextElement().setRole_function(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
							break;
						}
					}
					
					table_to_multi.setExtra2("");
					table_to_multi.setOperation("EQ");
					table_to_multi.setOperation_image("~sapicons/s_bgequa.gif");
					table_to_multi.setValue2("");
					table_to_multi.setTo("");
					wdContext.nodeTableToMultiselection().addElement(table_to_multi);
				}
			}
			else { 
				wdContext.currentContextElement().setRadioButton_groupBy("1"); //Person(s)
				wdContext.currentContextElement().setVisible_group_selection(WDVisibility.NONE);
				wdContext.currentContextElement().setVisible_individual_selection(WDVisibility.VISIBLE);
				wdThis.MD_execute_f4_help_rfc("RP", "", "");
			
//				strFull_resp_resource = splitString(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(n).getYyrespre());
//				for (int b=0; b < strFull_resp_resource.length; b++) {
//					IPublicComp_group_resource_task_rep.ITableToMultiselectionElement table_to_multi = wdContext.createTableToMultiselectionElement();		
//					table_to_multi.setField("Resp Resource");
//					table_to_multi.setValue1(strFull_resp_resource[b]);
//					table_to_multi.setCategory("Tab_single_include");
//					table_to_multi.setExtra1("");
//					for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
//						if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_resp_resource[b])) {
//							table_to_multi.setExtra1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
//							//wdContext.currentPersonElement().setField2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2());
//							//wdContext.currentPersonElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
//							//wdContext.currentPersonElement().setField4(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
//							break;
//						}
//					}
//					
//					table_to_multi.setExtra2("");
//					table_to_multi.setOperation("EQ");
//					table_to_multi.setOperation_image("~sapicons/s_bgequa.gif");
//					table_to_multi.setValue2("");
//					table_to_multi.setTo("");
//					wdContext.nodeTableToMultiselection().addElement(table_to_multi);
//				}
			
				strFull_persons = splitString(wdContext.nodeUser_Variant_Temp().getUser_Variant_TempElementAt(n).getYyrespbu());
				for (int c=0; c < strFull_persons.length; c++) {
					IPublicComp_group_resource_task_rep.ITableToMultiselectionElement table_to_multi = wdContext.createTableToMultiselectionElement();		
					table_to_multi.setField("Person(s)");
					table_to_multi.setValue1(strFull_persons[c]);
					table_to_multi.setCategory("Tab_single_include");
					table_to_multi.setExtra1("");
					for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
						if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_persons[c])) {
							table_to_multi.setExtra1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
							//wdContext.currentPersonElement().setField2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2());
							//wdContext.currentPersonElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
							//wdContext.currentPersonElement().setField4(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
							break;
						}
					}
					table_to_multi.setExtra2("");
					table_to_multi.setOperation("EQ");
					table_to_multi.setOperation_image("~sapicons/s_bgequa.gif");
					table_to_multi.setValue2("");
					table_to_multi.setTo("");
					wdContext.nodeTableToMultiselection().addElement(table_to_multi);
				}	   
			}
		
			//Change multiple selection images
			if (strFull_task_staus.length > 1) 					
				wdContext.currentContextElement().setImage_multi_taskstatus("~sapicons/s_bgmore.gif");
			else 		
				wdContext.currentContextElement().setImage_multi_taskstatus("~sapicons/s_b_more.gif");
				
			if (strFull_resp_resource.length > 1)
				wdContext.currentContextElement().setImage_multi_resp_resource("~sapicons/s_bgmore.gif");
			else
				wdContext.currentContextElement().setImage_multi_resp_resource("~sapicons/s_b_more.gif");

			if (strFull_persons.length > 1)
				wdContext.currentContextElement().setImage_multi_persons("~sapicons/s_bgmore.gif");
			else
				wdContext.currentContextElement().setImage_multi_persons("~sapicons/s_b_more.gif");
 
			if (strFull_fun_area.length > 1)
				wdContext.currentContextElement().setImage_muliti_functionalArea("~sapicons/s_bgmore.gif");
			else
				wdContext.currentContextElement().setImage_muliti_functionalArea("~sapicons/s_b_more.gif");
 		
 		
 		
			if (strFull_task_staus.length > 0) 	
				wdContext.currentTaskStatusElement().setTask_staus(strFull_task_staus[0]);
			else 
				wdContext.currentTaskStatusElement().setTask_staus("");	
 		 			
			if (strFull_resp_resource.length > 0) 	
				wdContext.currentResponsibleResourceElement().setField1(strFull_resp_resource[0]);
			else 
				wdContext.currentResponsibleResourceElement().setField1("");
			
			if (strFull_persons.length > 0) {	
				wdContext.currentPersonElement().setField1(strFull_persons[0]);
				wdThis.MD_execute_f4_help_rfc("RP", "", "");
				for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
					if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_persons[0])) {
						wdContext.currentPersonElement().setField2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2());
						wdContext.currentPersonElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						wdContext.currentPersonElement().setField4(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						wdContext.currentContextElement().setPersons(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						break;
					}
				}
			}
			else 
				wdContext.currentPersonElement().setField1("");
					
			if (strFull_fun_area.length > 0) {	
				wdContext.currentFunctionalAreaElement().setFuntional_area(strFull_fun_area[0]);
				wdThis.MD_execute_f4_help_rfc("RF", strFull_fun_area[0], "");
				for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
					if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_fun_area[0])) {
						wdContext.currentFunctionalAreaElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						wdContext.currentContextElement().setRole_function(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						break;
					}
				}
			}
			else
				wdContext.currentFunctionalAreaElement().setFuntional_area("");
			
			//send the data to multiple selection component
			wdThis.wdGetMultipleSelectionInterface().setMultiple_selection_table(wdContext.nodeTableToMultiselection());
		
    		
			break;
		}
	}

    //@@end
  }

  //@@begin javadoc:MD_execute_task_resource_report()
  /** Declared method. */
  //@@end
  public void MD_execute_task_resource_report( )
  {
    //@@begin MD_execute_task_resource_report()
	try {
		wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().modelObject().execute();
		wdContext.nodeGt_Tasks().invalidate();
		wdContext.nodeGt_Return().invalidate();
		wdContext.nodeOutput_Tasks().invalidate();
		
//		wdComponentAPI.getMessageManager().reportSuccess("" + wdContext.nodeGt_Tasks().size());
		
//		//Check for Errors, if the Error Type is E, then display the message
//		if (wdContext.currentGt_ReturnElement().getType().equalsIgnoreCase("E")) {
//			wdComponentAPI.getMessageManager().reportException("Error in executing task resource RFC - " + wdContext.currentGt_ReturnElement().getMessage(), true);
//		}



//		for (int b=0; b < wdContext.nodeGt_Tasks().size(); b++) {
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYactivity());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYactualfinish());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYactualstart());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYmilestone());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYmsl_Number());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYnotes());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYplanfinish());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYplanstart());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYproduct_Name());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYresource());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYrole_Func_Name());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYstatus());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYstudy_Number());
//			wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYtask());
//			
//		}

		//remove elements from the table
		for (int v = wdContext.nodeCus_Gt_Tasks().size() - 1; v >=0; --v ) {
			wdContext.nodeCus_Gt_Tasks().removeElement(wdContext.nodeCus_Gt_Tasks().getElementAt(v));
		}
		wdContext.nodeCus_Gt_Tasks().invalidate();
	
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy"); 
		java.util.Date plan_start, plan_finish, actual_start, actual_finish; 

		for (int b=0; b < wdContext.nodeGt_Tasks().size(); b++) {
			IPublicComp_group_resource_task_rep.ICus_Gt_TasksElement ele = wdContext.createCus_Gt_TasksElement();
		
			ele.setYactivity(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYactivity());

			try {
				plan_start = dateFormat.parse(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYplanstart());
			}
			catch (ParseException e) {
				plan_start = null;
			}
		
			try {
				ele.setYplanstart(new Date(plan_start.getTime()));
			}
			catch (NullPointerException e) {
			}
		
			try {
				plan_finish = dateFormat.parse(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYplanfinish());
			}
			catch (ParseException e) {
				plan_finish = null;
			}
		
			try {
				ele.setYplanfinish(new Date(plan_finish.getTime()));
			}
			catch (NullPointerException e) {
			}

			try {
				actual_start = dateFormat.parse(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYactualstart());
			}
			catch (ParseException e) {
				actual_start = null;
			}
		
			try {
				ele.setYactualstart(new Date(actual_start.getTime()));
			}
			catch (NullPointerException e) {
			}
		
			try {
				actual_finish = dateFormat.parse(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYactualfinish());
			}
			catch (ParseException e) {
				actual_finish = null;
			}
	
			try {
				ele.setYactualfinish(new Date(actual_finish.getTime()));
			}
			catch (NullPointerException e) {
			}
		
//				ele.setYactualfinish();
//				ele.setYactualstart();'
//				ele.setYplanfinish();
			
//				ele.setYplanstart(Date.valueOf(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYplanstart()));
//				wdComponentAPI.getMessageManager().reportSuccess("" + plan_finish);
//				wdComponentAPI.getMessageManager().reportSuccess("" + plan_start);
//				wdComponentAPI.getMessageManager().reportSuccess("" + actual_finish);
//				wdComponentAPI.getMessageManager().reportSuccess("" + actual_start);
			
//				wdComponentAPI.getMessageManager().reportSuccess("ppp");
//				wdComponentAPI.getMessageManager().reportSuccess("" + new Date(plan_finish.getTime()));	
			

//			}
//			catch (IllegalArgumentException e) {
//				wdComponentAPI.getMessageManager().reportSuccess("1");		
//			}
//			catch (ParseException e) {
//				wdComponentAPI.getMessageManager().reportSuccess("2");
//			}
		
			ele.setYmilestone(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYmilestone());
			ele.setYmsl_Number(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYmsl_Number());
			ele.setYnotes(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYnotes());
			ele.setYproduct_Name(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYproduct_Name());
			ele.setYresource(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYresource());
			ele.setYrole_Func_Name(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYrole_Func_Name());
			ele.setYstatus(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYstatus());
			ele.setYstudy_Number(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYstudy_Number());
			ele.setYtask(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYtask());
			wdContext.nodeCus_Gt_Tasks().addElement(ele);
		}



	}
	catch (Exception e) {
		wdComponentAPI.getMessageManager().reportException("Error in executing task resource RFC: " + e.getMessage(), true);
	   
		//Disconnect the connection
		GroupTaskReport model = (GroupTaskReport) WDModelFactory.getModelInstance(GroupTaskReport.class);
		model.disconnectIfAlive();
	}
	//Disconnect the connection
	GroupTaskReport model = (GroupTaskReport) WDModelFactory.getModelInstance(GroupTaskReport.class);
	model.disconnectIfAlive();

    //@@end
  }

  //@@begin javadoc:close()
  /** Declared method. */
  //@@end
  public void close( )
  {
    //@@begin close()
	if (link != null) {
		//surveyConfirmation.destroy();
		link.destroyInstance();
		link = null;
	}
    //@@end
  }

  //@@begin javadoc:open()
  /** Declared method. */
  //@@end
  public void open( )
  {
    //@@begin open()
	link = wdComponentAPI.getWindowManager().createModalWindow(wdComponentAPI.getComponentInfo().findInWindows("W_ExcelLink"));
	link.setWindowPosition(WDWindowPos.CENTER);
	// Netweaver 2004
	//surveyConfirmation.open();
	
	// Netweaver 2004s
	link.show();
    //@@end
  }

  //@@begin javadoc:OVSInputValues(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void OVSInputValues(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent, java.lang.String screen_name, java.lang.String input1, java.lang.String input2, java.lang.String input3, java.lang.String input4, java.lang.String input5, java.lang.String input6, java.lang.String input7 )
  {
    //@@begin OVSInputValues(ServerEvent)
	if (screen_name.equalsIgnoreCase("Task Status")) 
		wdThis.MD_execute_f4_help_rfc("TS", input1, input2);
	else 
		if (screen_name.equalsIgnoreCase("Resp Resource") || screen_name.equalsIgnoreCase("Person(s)")) 
			wdThis.MD_execute_f4_help_rfc("RP", input1, input2);
		else
			if (screen_name.equalsIgnoreCase("Role Function"))
				wdThis.MD_execute_f4_help_rfc("RF", "", input1);
//			else 
//				wdThis.MD_execute_f4_help_rfc("", input1, input2);
//						
	if (screen_name.equalsIgnoreCase("Task Status"))
		wdThis.wdGetMultipleSelectionInterface().f4SearchHelpDataToMultiselection(wdContext.nodeHelp_Tab(), "Yyfield1", "Yytext1", "", "", "", "", ""); //Here YYFIELD1... are the attributes in the node wdContext.nodeHelp_Tab()
	else
		if (screen_name.equalsIgnoreCase("Role Function"))	
			wdThis.wdGetMultipleSelectionInterface().f4SearchHelpDataToMultiselection(wdContext.nodeHelp_Tab(), "Yyfield1", "Yytext1", "", "", "", "", ""); //Here YYFIELD1... are the attributes in the node wdContext.nodeHelp_Tab()
		else
			if (screen_name.equalsIgnoreCase("Resp Resource") || screen_name.equalsIgnoreCase("Person(s)"))
				wdThis.wdGetMultipleSelectionInterface().f4SearchHelpDataToMultiselection(wdContext.nodeHelp_Tab(), "Yyfield1", "Yyfield2", "Yytext1", "", "", "", ""); //Here YYFIELD1... are the attributes in the node wdContext.nodeHelp_Tab()

			
	

    //@@end
  }

  /*
   * The following code section can be used for any Java code that is 
   * not to be visible to other controllers/views or that contains constructs
   * currently not supported directly by Web Dynpro (such as inner classes or
   * member variables etc.). </p>
   *
   * Note: The content of this section is in no way managed/controlled
   * by the Web Dynpro Designtime or the Web Dynpro Runtime. 
   */
  //@@begin others
  private IWDWindow popup, popup1, popup2, popup3, warning, link;
  private IWDOVSContextNotificationListener ovsListener_taskstatus = new OVSContextNotificationTaskstatusListener();
  private IWDOVSContextNotificationListener ovsListener_resp_resource = new OVSContextNotificationRespResourceListener();
  private IWDOVSContextNotificationListener ovsListener_person = new OVSContextNotificationPersonListener();
  private IWDOVSContextNotificationListener ovsListener_func_area = new OVSContextNotificationFuncAreaListener();
  IModifiableSimpleValueSet valueSet;
  
  //Listener for ovs taskstatus...........
  private class OVSContextNotificationTaskstatusListener implements IWDOVSContextNotificationListener {
	public void onQuery(IWDNodeElement queryInputNodeElement, IWDNode queryOutputNode) {
		IPublicComp_group_resource_task_rep.IOVSTaskstatusOutputNode ovsOutput = (IPublicComp_group_resource_task_rep.IOVSTaskstatusOutputNode) queryOutputNode;
		IPublicComp_group_resource_task_rep.IOVSTaskstatusInputElement ovsInput = (IPublicComp_group_resource_task_rep.IOVSTaskstatusInputElement) queryInputNodeElement;
		
		//remove elements from the node
		for (int b=0; b < wdContext.nodeOVSTaskstatusOutput().size(); b++) {
			wdContext.nodeOVSTaskstatusOutput().removeElement(wdContext.nodeOVSTaskstatusOutput().getElementAt(b));
		}
		wdContext.nodeOVSTaskstatusOutput().invalidate();
		
		String taskstaus_input_from, taskstaus_input_to;
		try {
			if (!ovsInput.getYYFIELD1().equalsIgnoreCase(""))
				taskstaus_input_from = ovsInput.getYYFIELD1().toUpperCase(); 
			else 
				taskstaus_input_from = "";
		}
		catch (NullPointerException e){
			taskstaus_input_from = "";	
		}
		
		try {
			if (!ovsInput.getYYTEXT1().equalsIgnoreCase(""))
				taskstaus_input_to = ovsInput.getYYTEXT1().toUpperCase(); 
			else 
				taskstaus_input_to = "";
		}
		catch (NullPointerException e){
			taskstaus_input_to = "";	
		}
		
		wdThis.MD_execute_f4_help_rfc("TS", taskstaus_input_from, taskstaus_input_to);
			
		for (int j=0; j < wdContext.nodeHelp_Tab().size(); j++) {
			IPublicComp_group_resource_task_rep.IOVSTaskstatusOutputElement ele = wdContext.createOVSTaskstatusOutputElement();
			ele.setYyfield1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYyfield1());
			ele.setYytext1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYytext1());
			wdContext.nodeOVSTaskstatusOutput().addElement(ele);
		}
		
		wdContext.nodeOVSTaskstatusOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("Task Status");
		wdContext.nodeOVSTaskstatusOutput().getNodeInfo().getAttribute("Yytext1").getModifiableSimpleType().setColumnLabel("Description");
		
		// Clear the input fields
		ovsInput.setYYFIELD1("");
		ovsInput.setYYTEXT1("");
		wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	}
	
	/* (non-Javadoc)
	 * @see com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener#applyResult(com.sap.tc.webdynpro.progmodel.api.IWDNodeElement, com.sap.tc.webdynpro.progmodel.api.IWDNodeElement)
	 */
	public void applyResult(IWDNodeElement applicationNodeElement, IWDNodeElement queryOutputNodeElement) {
		IPrivateView_group_resource_task_rep.ITaskStatusElement ovsCallerNodeElement = (IPrivateView_group_resource_task_rep.ITaskStatusElement) applicationNodeElement;
		IPublicComp_group_resource_task_rep.IOVSTaskstatusOutputElement output = (IPublicComp_group_resource_task_rep.IOVSTaskstatusOutputElement) queryOutputNodeElement;
		ovsCallerNodeElement.setTask_staus(output.getYyfield1());
		ovsCallerNodeElement.setDescription(output.getYytext1());
		wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	}
	
	  /* (non-Javadoc)
	   * @see com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener#applyInputValues(com.sap.tc.webdynpro.progmodel.api.IWDNodeElement, com.sap.tc.webdynpro.progmodel.api.IWDNodeElement)
	   */
	  public void applyInputValues(IWDNodeElement applicationNodeElement, IWDNodeElement queryInputNodeElement) {
				 
		// Set the node labels (OVS)
		wdContext.nodeOVSTaskstatusOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("Task Status");
		wdContext.nodeOVSTaskstatusOutput().getNodeInfo().getAttribute("Yytext1").getModifiableSimpleType().setColumnLabel("Description");
		
		wdContext.currentContextElement().setVisibility_message(WDVisibility.VISIBLE);
	  }
  }

  //Listener for ovs responsible resource...........
  private class OVSContextNotificationRespResourceListener implements IWDOVSContextNotificationListener {
	public void onQuery(IWDNodeElement queryInputNodeElement, IWDNode queryOutputNode) {
		IPublicComp_group_resource_task_rep.IOVSResponsibleResourceOutputNode ovsOutput = (IPublicComp_group_resource_task_rep.IOVSResponsibleResourceOutputNode) queryOutputNode;
		IPublicComp_group_resource_task_rep.IOVSRespResInputElement ovsInput = (IPublicComp_group_resource_task_rep.IOVSRespResInputElement) queryInputNodeElement;
		
		//remove elements from the node
		for (int b=0; b < wdContext.nodeOVSResponsibleResourceOutput().size(); b++) {
			wdContext.nodeOVSResponsibleResourceOutput().removeElement(wdContext.nodeOVSResponsibleResourceOutput().getElementAt(b));
		}
		wdContext.nodeOVSResponsibleResourceOutput().invalidate();
		
		String resp_resource_input_lastName, resp_resource_input_firstName;
					
		try {
			if (!ovsInput.getField1().equalsIgnoreCase(""))
				resp_resource_input_lastName = ovsInput.getField1().toUpperCase(); 
			else 
				resp_resource_input_lastName = "";
		}
		catch (NullPointerException e){
			resp_resource_input_lastName = "";	
		}
		
		try {
			if (!ovsInput.getField2().equalsIgnoreCase(""))
				resp_resource_input_firstName = ovsInput.getField2().toUpperCase(); 
			else 
				resp_resource_input_firstName = "";
		}
		catch (NullPointerException e){
			resp_resource_input_firstName = "";	
		}
		
		wdThis.MD_execute_f4_help_rfc("RP", resp_resource_input_lastName, resp_resource_input_firstName);
		
		for (int j=0; j < wdContext.nodeHelp_Tab().size(); j++) {
			IPublicComp_group_resource_task_rep.IOVSResponsibleResourceOutputElement ele = wdContext.createOVSResponsibleResourceOutputElement();
			ele.setYyfield1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYyfield1());
			ele.setYyfield2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYyfield2());
			ele.setYytext1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYytext1());
			
			wdContext.nodeOVSResponsibleResourceOutput().addElement(ele);
	
		}
		
		wdContext.nodeOVSResponsibleResourceOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("User ID");
		wdContext.nodeOVSResponsibleResourceOutput().getNodeInfo().getAttribute("Yyfield2").getModifiableSimpleType().setColumnLabel("Last Name");
		wdContext.nodeOVSResponsibleResourceOutput().getNodeInfo().getAttribute("Yytext1").getModifiableSimpleType().setColumnLabel("First Name");
		
		// Clear the input fields
		ovsInput.setField1("");
		ovsInput.setField2("");
		wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	}
	
	/* (non-Javadoc)
	 * @see com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener#applyResult(com.sap.tc.webdynpro.progmodel.api.IWDNodeElement, com.sap.tc.webdynpro.progmodel.api.IWDNodeElement)
	 */
	public void applyResult(IWDNodeElement applicationNodeElement, IWDNodeElement queryOutputNodeElement) {
		IPublicComp_group_resource_task_rep.IOVSResponsibleResourceOutputElement output = (IPublicComp_group_resource_task_rep.IOVSResponsibleResourceOutputElement) queryOutputNodeElement;
		IPrivateView_group_resource_task_rep.IResponsibleResourceElement ovsCallerNodeElement = (IPrivateView_group_resource_task_rep.IResponsibleResourceElement) applicationNodeElement;
		ovsCallerNodeElement.setField1(output.getYyfield1());
		ovsCallerNodeElement.setField2(output.getYyfield2());
		ovsCallerNodeElement.setField3(output.getYytext1());
		ovsCallerNodeElement.setField4(output.getYyfield2() + ", " + output.getYytext1());		

		wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	}
	
	/* (non-Javadoc)
	 * @see com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener#applyInputValues(com.sap.tc.webdynpro.progmodel.api.IWDNodeElement, com.sap.tc.webdynpro.progmodel.api.IWDNodeElement)
	 */
	public void applyInputValues(IWDNodeElement applicationNodeElement, IWDNodeElement queryInputNodeElement) {
		// Set the node labels (OVS)
		wdContext.nodeOVSResponsibleResourceOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("User ID");
		wdContext.nodeOVSResponsibleResourceOutput().getNodeInfo().getAttribute("Yyfield2").getModifiableSimpleType().setColumnLabel("Last Name");
		wdContext.nodeOVSResponsibleResourceOutput().getNodeInfo().getAttribute("Yytext1").getModifiableSimpleType().setColumnLabel("First Name");
		wdContext.currentContextElement().setVisibility_message(WDVisibility.VISIBLE);
	  }
  }
  
  //Listener for person(s)...........
  private class OVSContextNotificationPersonListener implements IWDOVSContextNotificationListener {
	public void onQuery(IWDNodeElement queryInputNodeElement, IWDNode queryOutputNode) {
		IPublicComp_group_resource_task_rep.IOVSPeopleOutputNode ovsOutput = (IPublicComp_group_resource_task_rep.IOVSPeopleOutputNode) queryOutputNode;
		IPublicComp_group_resource_task_rep.IOVSPeopleInputElement ovsInput = (IPublicComp_group_resource_task_rep.IOVSPeopleInputElement) queryInputNodeElement;
		
		//remove elements from the node
		for (int b=0; b < wdContext.nodeOVSPeopleOutput().size(); b++) {
			wdContext.nodeOVSPeopleOutput().removeElement(wdContext.nodeOVSPeopleOutput().getElementAt(b));
		}
		wdContext.nodeOVSPeopleOutput().invalidate();
		
		String people_input_lastName, people_input_firstName;
				
		try {
			if (!ovsInput.getField1().equalsIgnoreCase(""))
			people_input_lastName = ovsInput.getField1().toUpperCase(); 
			else 
			people_input_lastName = "";
		}
		catch (NullPointerException e){
			people_input_lastName = "";	
		}
		
		try {
			if (!ovsInput.getField2().equalsIgnoreCase(""))
			people_input_firstName = ovsInput.getField2().toUpperCase(); 
			else 
			people_input_firstName = "";
		}
		catch (NullPointerException e){
			people_input_firstName = "";	
		}
		
		wdThis.MD_execute_f4_help_rfc("RP", people_input_lastName, people_input_firstName);
			
		for (int j=0; j < wdContext.nodeHelp_Tab().size(); j++) {
			IPublicComp_group_resource_task_rep.IOVSPeopleOutputElement ele = wdContext.createOVSPeopleOutputElement();
			ele.setYyfield1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYyfield1());
			ele.setYyfield2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYyfield2());
			ele.setYytext1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYytext1());
			
			wdContext.nodeOVSPeopleOutput().addElement(ele);
		}
		
		wdContext.nodeOVSPeopleOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("User ID");
		wdContext.nodeOVSPeopleOutput().getNodeInfo().getAttribute("Yyfield2").getModifiableSimpleType().setColumnLabel("Last Name");
		wdContext.nodeOVSPeopleOutput().getNodeInfo().getAttribute("Yytext1").getModifiableSimpleType().setColumnLabel("First Name");
		
		// Clear the input fields
		ovsInput.setField1("");
		ovsInput.setField2("");
		wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	}
	
	/* (non-Javadoc)
	 * @see com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener#applyResult(com.sap.tc.webdynpro.progmodel.api.IWDNodeElement, com.sap.tc.webdynpro.progmodel.api.IWDNodeElement)
	 */
	public void applyResult(IWDNodeElement applicationNodeElement, IWDNodeElement queryOutputNodeElement) {
		IPublicComp_group_resource_task_rep.IOVSPeopleOutputElement output = (IPublicComp_group_resource_task_rep.IOVSPeopleOutputElement) queryOutputNodeElement;
		IPrivateView_group_resource_task_rep.IPersonElement ovsCallerNodeElement_ = (IPrivateView_group_resource_task_rep.IPersonElement) applicationNodeElement;
		ovsCallerNodeElement_.setField1(output.getYyfield1());
		ovsCallerNodeElement_.setField2(output.getYyfield2());
		ovsCallerNodeElement_.setField3(output.getYytext1());			
		ovsCallerNodeElement_.setField4(output.getYyfield2() + ", " + output.getYytext1());
		wdContext.currentContextElement().setPersons(output.getYyfield2() + ", " + output.getYytext1());

		wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	}
	
	/* (non-Javadoc)
	 * @see com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener#applyInputValues(com.sap.tc.webdynpro.progmodel.api.IWDNodeElement, com.sap.tc.webdynpro.progmodel.api.IWDNodeElement)
	 */
	public void applyInputValues(IWDNodeElement applicationNodeElement, IWDNodeElement queryInputNodeElement) {
		// Set the node labels (OVS)
		wdContext.nodeOVSPeopleOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("User ID");
		wdContext.nodeOVSPeopleOutput().getNodeInfo().getAttribute("Yyfield2").getModifiableSimpleType().setColumnLabel("Last Name");
		wdContext.nodeOVSPeopleOutput().getNodeInfo().getAttribute("Yytext1").getModifiableSimpleType().setColumnLabel("First Name");
		
		wdContext.currentContextElement().setVisibility_message(WDVisibility.VISIBLE);
	  }
  }


  //Listener for Role Function...........
  private class OVSContextNotificationFuncAreaListener implements IWDOVSContextNotificationListener {
	public void onQuery(IWDNodeElement queryInputNodeElement, IWDNode queryOutputNode) {
		IPublicComp_group_resource_task_rep.IOVSFuncAreaOutputNode ovsOutput = (IPublicComp_group_resource_task_rep.IOVSFuncAreaOutputNode) queryOutputNode;
		IPublicComp_group_resource_task_rep.IOVSFuncAreaInputElement ovsInput = (IPublicComp_group_resource_task_rep.IOVSFuncAreaInputElement) queryInputNodeElement;
		
		//remove elements from the node
		for (int b=0; b < wdContext.nodeOVSFuncAreaOutput().size(); b++) {
			wdContext.nodeOVSFuncAreaOutput().removeElement(wdContext.nodeOVSFuncAreaOutput().getElementAt(b));
		}
		wdContext.nodeOVSFuncAreaOutput().invalidate();
		
		String field1_input;
				
		try {
			if (!ovsInput.getField1().equalsIgnoreCase(""))
				field1_input = ovsInput.getField1().toUpperCase(); 
			else 
				field1_input = "";
		}
		catch (NullPointerException e){
			field1_input = "";	
		}
		
//		try {
//			if (!ovsInput.getField2().equalsIgnoreCase(""))
//				field2 = ovsInput.getField2().toUpperCase(); 
//			else 
//				field2 = "";
//		}
//		catch (NullPointerException e){
//			field2 = "";	
//		}
		
		wdThis.MD_execute_f4_help_rfc("RF", "", field1_input);
			
		for (int j=0; j < wdContext.nodeHelp_Tab().size(); j++) {
			IPublicComp_group_resource_task_rep.IOVSFuncAreaOutputElement ele = wdContext.createOVSFuncAreaOutputElement();
			ele.setYyfield1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYyfield1());
			ele.setYyfield2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYytext1());
			
			wdContext.nodeOVSFuncAreaOutput().addElement(ele);
		}
		
		wdContext.nodeOVSFuncAreaOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("Role Function ID");
		//wdContext.nodeOVSFuncAreaOutput().getNodeInfo().getAttribute("Yyfield2").getModifiableSimpleType().setColumnLabel("column2");
		wdContext.nodeOVSFuncAreaOutput().getNodeInfo().getAttribute("Yyfield2").getModifiableSimpleType().setColumnLabel("Role Function Name");
		
		// Clear the input fields
		ovsInput.setField1("");
		//ovsInput.setField2("");
		wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	}
	
	/* (non-Javadoc)
	 * @see com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener#applyResult(com.sap.tc.webdynpro.progmodel.api.IWDNodeElement, com.sap.tc.webdynpro.progmodel.api.IWDNodeElement)
	 */
	public void applyResult(IWDNodeElement applicationNodeElement, IWDNodeElement queryOutputNodeElement) {
		IPublicComp_group_resource_task_rep.IOVSFuncAreaOutputElement output = (IPublicComp_group_resource_task_rep.IOVSFuncAreaOutputElement) queryOutputNodeElement;
		IPrivateView_group_resource_task_rep.IFunctionalAreaElement ovsCallerNodeElement_ = (IPrivateView_group_resource_task_rep.IFunctionalAreaElement) applicationNodeElement;
		ovsCallerNodeElement_.setFuntional_area(output.getYyfield1());
		//ovsCallerNodeElement_.setField2(output.getYyfield2());
		ovsCallerNodeElement_.setField3(output.getYyfield2());			
		wdContext.currentContextElement().setRole_function(output.getYyfield2());		
		wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	}
	
	  /* (non-Javadoc)
	   * @see com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener#applyInputValues(com.sap.tc.webdynpro.progmodel.api.IWDNodeElement, com.sap.tc.webdynpro.progmodel.api.IWDNodeElement)
	   */
	  public void applyInputValues(IWDNodeElement applicationNodeElement, IWDNodeElement queryInputNodeElement) {
				 
		// Set the node labels (OVS)
		wdContext.nodeOVSFuncAreaOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("Role Function ID");
		//wdContext.nodeOVSFuncAreaOutput().getNodeInfo().getAttribute("Yyfield2").getModifiableSimpleType().setColumnLabel("column2");
		wdContext.nodeOVSFuncAreaOutput().getNodeInfo().getAttribute("Yyfield2").getModifiableSimpleType().setColumnLabel("Role Function Name");
		
		wdContext.currentContextElement().setVisibility_message(WDVisibility.VISIBLE);
	  }
  }



  public String[] splitString(String Line) {	
	return Line.split(",");
  }

  //@@end
}
