// ---------------------------------------------------------------------------
// This file has been generated partially by the Web Dynpro Code Generator.
// MODIFY CODE ONLY IN SECTIONS ENCLOSED BY @@begin AND @@end.
// ALL OTHER CHANGES WILL BE LOST IF THE FILE IS REGENERATED.
// ---------------------------------------------------------------------------
package com.monsanto.xrpm;

// 
// IMPORTANT NOTE: 
// _ALL_ IMPORT STATEMENTS MUST BE PLACED IN THE FOLLOWING SECTION ENCLOSED
// BY @@begin imports AND @@end. FURTHERMORE, THIS SECTION MUST ALWAYS CONTAIN
// AT LEAST ONE IMPORT STATEMENT (E.G. THAT FOR IPrivateView_Rep).
// OTHERWISE, USING THE ECLIPSE FUNCTION "Organize Imports" FOLLOWED BY
// A WEB DYNPRO CODE GENERATION (E.G. PROJECT BUILD) WILL RESULT IN THE LOSS
// OF IMPORT STATEMENTS.
//
//@@begin imports
import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Hashtable;

import jxl.HeaderFooter;
import jxl.SheetSettings;
import jxl.Workbook;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.format.PageOrientation;
import jxl.format.PaperSize;
import jxl.format.UnderlineStyle;
import jxl.format.VerticalAlignment;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.rtf.headerfooter.RtfHeaderFooter;
import com.monsanto.xrpm.utils.TableFilter;
import com.monsanto.xrpm.utils.TableSorter;
import com.monsanto.xrpm.wdp.IPrivateView_Rep;
import com.sap.tc.webdynpro.clientserver.uielib.standard.api.IWDTable;
import com.sap.tc.webdynpro.progmodel.api.WDVisibility;
import com.sap.tc.webdynpro.services.sal.datatransport.api.IWDResource;
import com.sap.tc.webdynpro.services.sal.url.api.IWDCachedWebResource;
import com.sap.tc.webdynpro.services.sal.url.api.WDWebResource;
import com.sap.tc.webdynpro.services.sal.url.api.WDWebResourceType;
//@@end

//@@begin documentation
//@@end

public class View_Rep
{
  /**
   * Logging location.
   */
  private static final com.sap.tc.logging.Location logger = 
    com.sap.tc.logging.Location.getLocation(View_Rep.class);

  static 
  {
    //@@begin id
    String id = "$Id$";
    //@@end
    com.sap.tc.logging.Location.getLocation("ID.com.sap.tc.webdynpro").infoT(id);
  }

  /**
   * Private access to the generated Web Dynpro counterpart 
   * for this controller class.  </p>
   *
   * Use <code>wdThis</code> to gain typed access to the context,
   * to trigger navigation via outbound plugs, to get and enable/disable
   * actions, fire declared events, and access used controllers and/or 
   * component usages.
   *
   * @see com.monsanto.xrpm.wdp.IPrivateView_Rep for more details
   */
  private final IPrivateView_Rep wdThis;

  /**
   * Root node of this controller's context. </p>
   *
   * Provides typed access not only to the elements of the root node 
   * but also to all nodes in the context (methods node<i>XYZ</i>()) 
   * and their currently selected element (methods current<i>XYZ</i>Element()). 
   * It also facilitates the creation of new elements for all nodes 
   * (methods create<i>XYZ</i>Element()). </p>
   *
   * @see com.monsanto.xrpm.wdp.IPrivateView_Rep.IContextNode for more details.
   */
  private final IPrivateView_Rep.IContextNode wdContext;

  /**
   * A shortcut for <code>wdThis.wdGetAPI()</code>. </p>
   * 
   * Represents the generic API of the generic Web Dynpro counterpart 
   * for this controller. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDViewController wdControllerAPI;
  
  /**
   * A shortcut for <code>wdThis.wdGetAPI().getComponent()</code>. </p>
   * 
   * Represents the generic API of the Web Dynpro component this controller 
   * belongs to. Can be used to access the message manager, the window manager,
   * to add/remove event handlers and so on. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdComponentAPI;
  
  public View_Rep(IPrivateView_Rep wdThis)
  {
    this.wdThis = wdThis;
    this.wdContext = wdThis.wdGetContext();
    this.wdControllerAPI = wdThis.wdGetAPI();
    this.wdComponentAPI = wdThis.wdGetAPI().getComponent();
  }

  //@@begin javadoc:wdDoInit()
  /** Hook method called to initialize controller. */
  //@@end
  public void wdDoInit()
  {
    //@@begin wdDoInit()
    wdContext.currentContextElement().setVisible_Group_Table(WDVisibility.NONE);
    wdContext.currentContextElement().setVisible_Individual_Table(WDVisibility.NONE);
    //@@end
  }

  //@@begin javadoc:wdDoExit()
  /** Hook method called to clean up controller. */
  //@@end
  public void wdDoExit()
  {
    //@@begin wdDoExit()
    //@@end
  }

  //@@begin javadoc:wdDoModifyView
  /**
   * Hook method called to modify a view just before rendering.
   * This method conceptually belongs to the view itself, not to the
   * controller (cf. MVC pattern).
   * It is made static to discourage a way of programming that
   * routinely stores references to UI elements in instance fields
   * for access by the view controller's event handlers, and so on.
   * The Web Dynpro programming model recommends that UI elements can
   * only be accessed by code executed within the call to this hook method.
   *
   * @param wdThis Generated private interface of the view's controller, as
   *        provided by Web Dynpro. Provides access to the view controller's
   *        outgoing controller usages, etc.
   * @param wdContext Generated interface of the view's context, as provided
   *        by Web Dynpro. Provides access to the view's data.
   * @param view The view's generic API, as provided by Web Dynpro.
   *        Provides access to UI elements.
   * @param firstTime Indicates whether the hook is called for the first time
   *        during the lifetime of the view.
   */
  //@@end
  public static void wdDoModifyView(IPrivateView_Rep wdThis, IPrivateView_Rep.IContextNode wdContext, com.sap.tc.webdynpro.progmodel.api.IWDView view, boolean firstTime)
  {
    //@@begin wdDoModifyView
	if ( firstTime ) {
		wdContext.currentContextElement().setNotes_width("400px");
		wdContext.currentContextElement().setNotes_wrapping(true);
			
		IWDTable tableSort = (IWDTable) view.getElement("tbl_group");
		wdContext.currentContextElement().setTableSorter( new TableSorter(tableSort, wdThis.wdGetSortGroupReportAction(), null));
		tableSort.mappingOfOnLeadSelect().addSourceMapping("col", "selectCol"); 
		
		IWDTable tableSort1 = (IWDTable) view.getElement("tbl_individual");
		wdContext.currentContextElement().setTableSorter1( new TableSorter(tableSort1, wdThis.wdGetSortIndividualReportAction(), null));
		tableSort1.mappingOfOnLeadSelect().addSourceMapping("col", "selectCol");     
		
		if ( null != view ) { 
			IWDTable tableFilter = (IWDTable) view.getElement("tbl_group");
			Hashtable tbl = new Hashtable(); //if the HashTable if null, you get NullPointerException
			wdContext.currentContextElement().setTableFilter( new TableFilter(tableFilter, wdThis.wdGetFilterGroupReportAction(), wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeCus_Gt_Tasks(), tbl));
		
			IWDTable tableFilter1 = (IWDTable) view.getElement("tbl_individual");
			Hashtable tbl1 = new Hashtable(); //if the HashTable if null, you get NullPointerException
			wdContext.currentContextElement().setTableFilter1( new TableFilter(tableFilter1, wdThis.wdGetFilterIndividualReportAction(), wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeCus_Gt_Tasks(), tbl1));
		}
	}

    //@@end
  }

  //@@begin javadoc:exporttoexcel_jxl()
  /** Declared method. */
  //@@end
  public void exporttoexcel_jxl( )
  {
    //@@begin exporttoexcel_jxl()
	//	-----------Export to Excel - Jexcel API------------------
	Calendar cal = new GregorianCalendar();
	String fileName = "Project Task Report" + cal.getTimeInMillis() + ".xls";
	IWDCachedWebResource cachedExcelResource = null;
	try {
		File f = new File(fileName);
		
		//com.monsanto.xrpm.WorkbookSettings workbook_setting = new com.monsanto.xrpm.WorkbookSettings();
		//workbook_setting.setAutoFilterDisabled(false);
		//WorkbookSettings workbook_setting = new WorkbookSettings();
		//WritableWorkbook workbook =	Workbook.createWorkbook(f, workbook_setting);
		
		WritableWorkbook workbook =	Workbook.createWorkbook(f);
 		
		WritableFont red = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.BOLD, false, UnderlineStyle.SINGLE, Colour.RED);
		WritableCellFormat redFormat = new WritableCellFormat(red);
		redFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
		redFormat.setVerticalAlignment(VerticalAlignment.TOP);
					
//		WritableFont black = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.AUTOMATIC);
//		WritableCellFormat blackFormat = new WritableCellFormat(black);
//		blackFormat.setWrap(true);
//		blackFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
//		blackFormat.setVerticalAlignment(VerticalAlignment.TOP);
		
//		WritableFont black_ = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.AUTOMATIC);
//		WritableCellFormat blackFormat_ = new WritableCellFormat(black_);
//		blackFormat_.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
//		blackFormat_.setVerticalAlignment(VerticalAlignment.TOP);
//		
		WritableFont blue = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLUE2);
		WritableCellFormat blueFormat = new WritableCellFormat(blue);
//		blueFormat.setWrap(true);
		blueFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
		blueFormat.setVerticalAlignment(VerticalAlignment.TOP);
		
		WritableFont blue_ = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLUE2);
		WritableCellFormat blueFormat_ = new WritableCellFormat(blue_);
		blueFormat_.setWrap(true);
		blueFormat_.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
		blueFormat_.setVerticalAlignment(VerticalAlignment.TOP);
		
//		WritableFont blue_backgroundcolour = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLUE2);
//		WritableCellFormat blueFormat_backgroundcolour = new WritableCellFormat(blue_backgroundcolour);
//		blueFormat_backgroundcolour.setWrap(true);
//		blueFormat_backgroundcolour.setBackground(Colour.VERY_LIGHT_YELLOW);
//		blueFormat_backgroundcolour.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
//		blueFormat_backgroundcolour.setVerticalAlignment(VerticalAlignment.TOP);
//		
//		WritableFont black_backgroundcolor = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.AUTOMATIC);
//		WritableCellFormat blackFormat_backgroundcolor = new WritableCellFormat(black_backgroundcolor);
//		blackFormat_backgroundcolor.setWrap(true);
//		blackFormat_backgroundcolor.setBackground(Colour.VERY_LIGHT_YELLOW);
//		blackFormat_backgroundcolor.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
//		blackFormat_backgroundcolor.setVerticalAlignment(VerticalAlignment.TOP);
//		
//		WritableFont blue_backgroundcolour1 = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLUE2);
//		WritableCellFormat blueFormat_backgroundcolour1 = new WritableCellFormat(blue_backgroundcolour1);
//		blueFormat_backgroundcolour1.setWrap(true);
//		blueFormat_backgroundcolour1.setBackground(Colour.LIGHT_GREEN);
//		blueFormat_backgroundcolour1.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
//		blueFormat_backgroundcolour1.setVerticalAlignment(VerticalAlignment.TOP);
//		
//		WritableFont black_backgroundcolor1 = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.AUTOMATIC);
//		WritableCellFormat blackFormat_backgroundcolor1 = new WritableCellFormat(black_backgroundcolor1);
//		blackFormat_backgroundcolor1.setWrap(true);
//		blackFormat_backgroundcolor1.setBackground(Colour.LIGHT_GREEN);
//		blackFormat_backgroundcolor1.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
//		blackFormat_backgroundcolor1.setVerticalAlignment(VerticalAlignment.TOP);
		
		WritableSheet sheet = workbook.createSheet("Project Task Report", 0);
	
		//================ Headings ================
		SheetSettings setting = sheet.getSettings( );
		setting.setPrintGridLines(true);
		setting.setFitToPages(true);
		setting.setFitWidth(1);	
		setting.setRightMargin(0.2);
		setting.setLeftMargin(0.2);
		setting.setTopMargin(0.5);
		setting.setBottomMargin(.5);
		setting.setFooterMargin(0.25);
		setting.setHeaderMargin(0.25);
		setting.setHorizontalCentre(true);
		
		HeaderFooter header = new HeaderFooter();
		
		HeaderFooter.Contents header_content_left = header.getLeft();
		header_content_left.append("Global Project Management Group/Individual Tasks Report");
		header_content_left.setFontSize(8);
		
		HeaderFooter.Contents header_content_right = header.getRight();
		header_content_right.append("Printed on ");
		header_content_right.appendDate();
		header_content_right.append(" at ");
		header_content_right.appendTime();
		header_content_right.setFontSize(8);			
		
		HeaderFooter footer = new HeaderFooter();
		
		HeaderFooter.Contents footer_content_left = footer.getLeft();
		footer_content_left.append("");
		footer_content_left.setFontSize(8);
		
		HeaderFooter.Contents footer_content_centre = footer.getCentre();
		footer_content_centre.append("Monsanto Company Confidential");
		footer_content_centre.setFontSize(8);
		
		HeaderFooter.Contents footer_content_right = footer.getRight();
		footer_content_right.append("Page ");
		footer_content_right.appendPageNumber();
		footer_content_right.append(" of ");
		footer_content_right.appendTotalPages();
		footer_content_right.setFontSize(8);
		
		setting.setFooter(footer);
		setting.setHeader(header); 
		
		setting.setPaperSize(PaperSize.TABLOID);
		setting.setOrientation(PageOrientation.LANDSCAPE);
		Label label;
		
		
		if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("2")) { //Group 
			label = new Label(0, 0, "Functional Area",redFormat);
			sheet.addCell(label);
		
			label = new Label(1, 0,"Resource",redFormat);
			sheet.addCell(label);
	
			label = new Label(2,0,"Product Name",redFormat);
			sheet.addCell(label);
		
			label = new Label(3,0,"Activity",redFormat);
			sheet.addCell(label);
		
			label = new Label(4,0,"Task",redFormat);
			sheet.addCell(label);
		
			label = new Label(5,0,"Status",redFormat);
			sheet.addCell(label);
		
			label = new Label(6,0,"Milestone",redFormat);
			sheet.addCell(label);
		
			label = new Label(7,0,"Planned Start",redFormat);
			sheet.addCell(label);
		
			label = new Label(8,0,"Planned Finish",redFormat);
			sheet.addCell(label);
		
			label = new Label(9,0,"Actual Start",redFormat);
			sheet.addCell(label);
			
			label = new Label(10,0,"Actual Finish",redFormat);
			sheet.addCell(label);
			
			label = new Label(11,0,"Notes",redFormat);
			sheet.addCell(label);
		
			label = new Label(12,0,"Search Field",redFormat);
			sheet.addCell(label);
	
			label = new Label(13,0,"Grouping",redFormat);
			sheet.addCell(label);
		}
		else { //Person(s)
			label = new Label(0, 0,"Resource",redFormat);
			sheet.addCell(label);
	
			label = new Label(1,0,"Product Name",redFormat);
			sheet.addCell(label);
		
			label = new Label(2,0,"Activity",redFormat);
			sheet.addCell(label);
					
			label = new Label(3,0,"Task",redFormat);
			sheet.addCell(label);
		
			label = new Label(4,0,"Status",redFormat);
			sheet.addCell(label);
		
			label = new Label(5,0,"Milestone",redFormat);
			sheet.addCell(label);
		
			label = new Label(6,0,"Planned Start",redFormat);
			sheet.addCell(label);
		
			label = new Label(7,0,"Planned Finish",redFormat);
			sheet.addCell(label);
		
			label = new Label(8,0,"Actual Start",redFormat);
			sheet.addCell(label);
			
			label = new Label(9,0,"Actual Finish",redFormat);
			sheet.addCell(label);
			
			label = new Label(10,0,"Notes",redFormat);
			sheet.addCell(label);
					
			label = new Label(11,0,"Search Field",redFormat);
			sheet.addCell(label);
	
			label = new Label(12,0,"Grouping",redFormat);
			sheet.addCell(label);
		
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

		if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("2")) { //Group		
			for (int n=0; n < wdContext.nodeDis_Gt_Tasks().size(); n++) {
				label = new Label(0, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYrole_Func_Name(), blueFormat);
				sheet.addCell(label);
				
				label = new Label(1, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYresource(), blueFormat);
				sheet.addCell(label);
								
				label = new Label(2, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYproduct_Name(), blueFormat);
				sheet.addCell(label);
								
				label = new Label(3, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYactivity(), blueFormat);
				sheet.addCell(label);
								
				label = new Label(4, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYtask(), blueFormat);
				sheet.addCell(label);
								
				label = new Label(5, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYstatus(), blueFormat);
				sheet.addCell(label);
								
				label = new Label(6, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYmilestone(), blueFormat);
				sheet.addCell(label);
				
				try {				
					label = new Label(7, n+1, dateFormat.format(wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYplanstart()), blueFormat);
					sheet.addCell(label);
				}
				catch (NullPointerException e) {
					label = new Label(7, n+1, "", blueFormat);
					sheet.addCell(label);
				}
				
				try {
					label = new Label(8, n+1, dateFormat.format(wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYplanfinish()), blueFormat);
					sheet.addCell(label);
				}
				catch (NullPointerException e) {
					label = new Label(8, n+1, "", blueFormat);
					sheet.addCell(label);
				}
				
				try {
					label = new Label(9, n+1, dateFormat.format(wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYactualstart()), blueFormat);
					sheet.addCell(label);
				}
				catch (Exception e) {
					label = new Label(9, n+1, "", blueFormat);
					sheet.addCell(label);
				}
				
				try {				
					label = new Label(10, n+1, dateFormat.format(wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYactualfinish()), blueFormat);							
					sheet.addCell(label);
				}
				catch (Exception e) {
					label = new Label(10, n+1, "", blueFormat);							
					sheet.addCell(label);
				}
				
				label = new Label(11, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYnotes(), blueFormat_);
				sheet.addCell(label);
								
				label = new Label(12, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYstudy_Number(), blueFormat);
				sheet.addCell(label);
								
				label = new Label(13, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYmsl_Number(), blueFormat);
				sheet.addCell(label);
			}
		}
		else { //Person(s)
			for (int n=0; n < wdContext.nodeDis_Gt_Tasks().size(); n++) {
				label = new Label(0, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYresource(), blueFormat);
				sheet.addCell(label);
								
				label = new Label(1, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYproduct_Name(), blueFormat);
				sheet.addCell(label);
								
				label = new Label(2, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYactivity(), blueFormat);
				sheet.addCell(label);
				
				label = new Label(3, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYtask(), blueFormat);
				sheet.addCell(label);
								
				label = new Label(4, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYstatus(), blueFormat);
				sheet.addCell(label);
								
				label = new Label(5, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYmilestone(), blueFormat);
				sheet.addCell(label);
								
				try {
					label = new Label(6, n+1, dateFormat.format(wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYplanstart()), blueFormat);
					sheet.addCell(label);
				}
				catch (NullPointerException e) {
					label = new Label(6, n+1, "", blueFormat);
					sheet.addCell(label);
				}
								
				try {
					label = new Label(7, n+1, dateFormat.format(wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYplanfinish()), blueFormat);
					sheet.addCell(label);
				}
				catch (NullPointerException e) {
					label = new Label(7, n+1, "", blueFormat);
					sheet.addCell(label);
				}
				
				try {				
					label = new Label(8, n+1, dateFormat.format(wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYactualstart()), blueFormat);
					sheet.addCell(label);
				}
				catch (NullPointerException e) {
					label = new Label(8, n+1, "", blueFormat);
					sheet.addCell(label);
				}
								
				try {
					label = new Label(9, n+1, dateFormat.format(wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYactualfinish()), blueFormat);							
					sheet.addCell(label);
				}
				catch (NullPointerException e) {
					label = new Label(9, n+1, "", blueFormat);							
					sheet.addCell(label);
				}
				
				label = new Label(10, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYnotes(), blueFormat_);
				sheet.addCell(label);
				
				label = new Label(11, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYstudy_Number(), blueFormat);
				sheet.addCell(label);
								
				label = new Label(12, n+1, wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(n).getYmsl_Number(), blueFormat);
				sheet.addCell(label);
			}
		}

		//Set Column Width
		if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("2")) { //Group
			sheet.setColumnView(0, 30);
			
			sheet.setColumnView(1, 30);
			sheet.setColumnView(2, 40);
			sheet.setColumnView(3, 40);
			sheet.setColumnView(4, 40);
			sheet.setColumnView(5, 15);
			sheet.setColumnView(6, 15);
			sheet.setColumnView(7, 14);
			sheet.setColumnView(8, 15);
			sheet.setColumnView(9, 14);
			sheet.setColumnView(10, 15);
			sheet.setColumnView(11, 60);
			sheet.setColumnView(12, 20);
			sheet.setColumnView(13, 16);
		}
		else { //Person(s)
			sheet.setColumnView(0, 30);
			sheet.setColumnView(1, 40);
			sheet.setColumnView(2, 40);
			sheet.setColumnView(3, 40);
			sheet.setColumnView(4, 15);
			sheet.setColumnView(5, 15);
			sheet.setColumnView(6, 14);
			sheet.setColumnView(7, 15);
			sheet.setColumnView(8, 14);
			sheet.setColumnView(9, 15);
			sheet.setColumnView(10, 60);
			sheet.setColumnView(11, 20);
			sheet.setColumnView(12, 16);
		}

		//workbook.setColourRGB(Colour.LIME, 0xff, 0, 0);
		workbook.write();
		workbook.close();
		FileInputStream excelCSVFile = new FileInputStream(f);
		cachedExcelResource = getCachedWebResource(excelCSVFile, fileName, WDWebResourceType.XLS);
	
		wdContext.currentContextElement().setExcelURL(cachedExcelResource.getURL());
	}
	catch (Exception e) {
		StringBuffer buffer = new StringBuffer();
		StackTraceElement[] ex = e.getStackTrace();
		for(int i=0;i<ex.length;i++){
				buffer.append(ex[i].toString());
		}
		wdComponentAPI.getMessageManager().reportException(e.getMessage()+ buffer.toString(), true);
	}
    //@@end
  }

  //@@begin javadoc:onPlugFromSelection(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onPlugFromSelection(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onPlugFromSelection(ServerEvent)
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYactivity_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYactualfinish_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYactualstart_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYmilestone_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYmsl_Number_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYnotes_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYplanfinish_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYplanstart_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYproduct_Name_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYresource_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYrole_Func_Name_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYstatus_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYstudy_Number_Filters("");
	wdContext.nodeDis_Gt_Tasks_Filters().currentDis_Gt_Tasks_FiltersElement().setYtask_Filters("");
	
	wdContext.currentContextElement().setFirstVisibleRow(0);
	wdContext.currentContextElement().setFirstVisibleColumn("Yactivity");
	wdContext.currentContextElement().setFirstVisibleColumn_Individual("Yactivity_0");
	wdContext.currentContextElement().setNotes_width("400px");
	wdContext.currentContextElement().setNotes_wrapping(true);
    
	if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("1")) { //Person
		wdContext.currentContextElement().setVisible_Group_Table(WDVisibility.NONE);
		wdContext.currentContextElement().setVisible_Individual_Table(WDVisibility.VISIBLE);
		wdContext.currentContextElement().setReport_type("Individual Tasks Report");
	}
	else { //Area
		wdContext.currentContextElement().setVisible_Group_Table(WDVisibility.VISIBLE);
		wdContext.currentContextElement().setVisible_Individual_Table(WDVisibility.NONE);
		wdContext.currentContextElement().setReport_type("Group Tasks Report");
	}
    
//	wdComponentAPI.getMessageManager().reportSuccess("=======Task status========");
//	for (int b=0; b < wdContext.nodeGt_Status_Input().size(); b++) {
//		wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Status_Input().getGt_Status_InputElementAt(b).getLow());
//	}
//    
//	wdComponentAPI.getMessageManager().reportSuccess("=========Option==========");
//	for (int b=0; b < wdContext.nodeGt_Options_Input().size(); b++) {
//		wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeGt_Options_Input().getGt_Options_InputElementAt(b).getLow());
//	} 
//	wdComponentAPI.getMessageManager().reportSuccess("============================");
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().getGv_Group());
//	wdComponentAPI.getMessageManager().reportSuccess("" + wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().getGv_Begda());
//	wdComponentAPI.getMessageManager().reportSuccess("" + wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().getGv_Endda());
    
	wdThis.wdGetComp_group_resource_task_repController().MD_execute_task_resource_report();
	
	//remove elements from the table
	for (int v = wdContext.nodeDis_Gt_Tasks().size() - 1; v >=0; --v ) {
		wdContext.nodeDis_Gt_Tasks().removeElement(wdContext.nodeDis_Gt_Tasks().getElementAt(v));
	}
	wdContext.nodeDis_Gt_Tasks().invalidate();
	
	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy"); 
	java.util.Date plan_start, plan_finish, actual_start, actual_finish; 

	for (int b=0; b < wdContext.nodeGt_Tasks().size(); b++) {
		IPrivateView_Rep.IDis_Gt_TasksElement ele = wdContext.createDis_Gt_TasksElement();
		
		ele.setYactivity(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYactivity());

		try {
			plan_start = dateFormat.parse(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYplanstart());
		}
		catch (ParseException e) {
			plan_start = null;
		}
		
		try {
			ele.setYplanstart(new Date(plan_start.getTime()));
		}
		catch (NullPointerException e) {
		}
		
		try {
			plan_finish = dateFormat.parse(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYplanfinish());
		}
		catch (ParseException e) {
			plan_finish = null;
		}
		
		try {
			ele.setYplanfinish(new Date(plan_finish.getTime()));
		}
		catch (NullPointerException e) {
		}

		try {
			actual_start = dateFormat.parse(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYactualstart());
		}
		catch (ParseException e) {
			actual_start = null;
		}
		
		try {
			ele.setYactualstart(new Date(actual_start.getTime()));
		}
		catch (NullPointerException e) {
		}
		
		try {
			actual_finish = dateFormat.parse(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYactualfinish());
		}
		catch (ParseException e) {
			actual_finish = null;
		}
	
		try {
			ele.setYactualfinish(new Date(actual_finish.getTime()));
		}
		catch (NullPointerException e) {
		}
		
//			ele.setYactualfinish();
//			ele.setYactualstart();'
//			ele.setYplanfinish();
			
//			ele.setYplanstart(Date.valueOf(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYplanstart()));
//			wdComponentAPI.getMessageManager().reportSuccess("" + plan_finish);
//			wdComponentAPI.getMessageManager().reportSuccess("" + plan_start);
//			wdComponentAPI.getMessageManager().reportSuccess("" + actual_finish);
//			wdComponentAPI.getMessageManager().reportSuccess("" + actual_start);
			
//			wdComponentAPI.getMessageManager().reportSuccess("ppp");
//			wdComponentAPI.getMessageManager().reportSuccess("" + new Date(plan_finish.getTime()));	
			

//		}
//		catch (IllegalArgumentException e) {
//			wdComponentAPI.getMessageManager().reportSuccess("1");		
//		}
//		catch (ParseException e) {
//			wdComponentAPI.getMessageManager().reportSuccess("2");
//		}
		
		ele.setYmilestone(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYmilestone());
		ele.setYmsl_Number(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYmsl_Number());
		ele.setYnotes(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYnotes());
		ele.setYproduct_Name(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYproduct_Name());
		ele.setYresource(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYresource());
		ele.setYrole_Func_Name(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYrole_Func_Name());
		ele.setYstatus(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYstatus());
		ele.setYstudy_Number(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYstudy_Number());
		ele.setYtask(wdContext.nodeGt_Tasks().getGt_TasksElementAt(b).getYtask());
		wdContext.nodeDis_Gt_Tasks().addElement(ele);
	}
	 
    //@@end
  }

  //@@begin javadoc:onActionPrevious(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionPrevious(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionPrevious(ServerEvent)
    wdThis.wdFirePlugToSelection();
    //@@end
  }

  //@@begin javadoc:onActionExportToExcel(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionExportToExcel(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionExportToExcel(ServerEvent)
	wdThis.exporttoexcel_jxl(); 
	wdThis.wdGetComp_group_resource_task_repController().open();
    //@@end
  }

  //@@begin javadoc:onActionExportToPDF(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionExportToPDF(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionExportToPDF(ServerEvent)
	Document document = null;
	PdfWriter writer = null;
	IWDResource resource = null;
	ByteArrayOutputStream outputStream = null;
	IWDCachedWebResource pdfResource = null;
	Calendar cal = new GregorianCalendar();
	String fileName = "Project Task Report" + cal.getTimeInMillis() + ".pdf";
	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	try {
		//creation of the document with a certain size and certain margins
		//create the document 		
		document = new Document();
		document.setPageSize(PageSize.TABLOID.rotate()); //landscape
		document.setMargins(20,20,30,30);
		//document.addTitle("Global Project Management Group/Individual Tasks Report");
		
		
		//we need a buffer to where the PDF Content will be written into
		outputStream = new ByteArrayOutputStream();
		
		//creation of the different writers
		writer = PdfWriter.getInstance(document, outputStream);
		//fonts
		BaseFont baseFontTimes = BaseFont.createFont(BaseFont.TIMES_ROMAN, "Cp1252", false);
		Font font = new Font(baseFontTimes, 9, Font.NORMAL);
		
		//headers and footers must be added before the document is opened
		com.lowagie.text.HeaderFooter footer = new com.lowagie.text.HeaderFooter(new Phrase("Monsanto Company Confidential", font), false);
		footer.setBorder(Rectangle.NO_BORDER);
		footer.setAlignment(Element.ALIGN_CENTER);
		document.setFooter(footer);
		
//		Paragraph header_left = new Paragraph("Global Project Management Group/Individual Tasks Report");
//		header_left.setAlignment(Paragraph.ALIGN_LEFT);
//		
//		Paragraph header_right = new Paragraph("Global Project Management Group/Individual Tasks Report");
//		header_right.setAlignment(Paragraph.ALIGN_RIGHT);
		
				
		//RtfHeaderFooter header_ = new RtfHeaderFooter(new Element []{header_left, header_right});
		//header.setAlignment(Element.ALIGN_LEFT);
		
		//document.setHeader(header_);
		
		com.lowagie.text.HeaderFooter header = new com.lowagie.text.HeaderFooter(new Phrase("Global Project Management Group/Individual Tasks Report", font), false);
		header.setAlignment(Element.ALIGN_CENTER);
		document.setHeader(header);
		
		
		document.open();
		
		//create a table with 3 columns
		PdfPTable pdf_table;
		float [] widths;
		//create a cell
		PdfPCell pdf_cell;
		
		if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("1")) { //Person
			pdf_table = new PdfPTable(13);
			widths = new float[] {30,40,40,40,15,15,16,16,16,16,55,20,22};
			pdf_table.setWidths(widths);
			pdf_table.setWidthPercentage(100);		
		}
		else {
			pdf_table = new PdfPTable(14); //Area
			widths = new float[] {30,30,35,35,35,15,15,16,16,16,16,52,18,22};
			pdf_table.setWidths(widths);
			pdf_table.setWidthPercentage(100);
			
			pdf_cell = new PdfPCell(new Paragraph("Functional Area", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
			pdf_cell.setBackgroundColor(Color.lightGray);
			//pdf_cell.setPadding(5);
			pdf_table.addCell(pdf_cell);
				
		}
		
		
		
//		float [] widths_group = {40,30,40,40,40,15,15,16,16,16,16,55,20,22};
//		float [] widths_individual = {30,40,40,40,15,15,16,16,16,16,55,20,22};
		
		
		


		pdf_cell = new PdfPCell(new Paragraph("Resource", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		//pdf_cell.setPadding(5);
		pdf_table.addCell(pdf_cell);

		
		pdf_cell = new PdfPCell(new Paragraph("Product Name", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		pdf_table.addCell(pdf_cell);

		pdf_cell = new PdfPCell(new Paragraph("Activity", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		pdf_table.addCell(pdf_cell);
		
		pdf_cell = new PdfPCell(new Paragraph("Task", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		pdf_table.addCell(pdf_cell);
		
		pdf_cell = new PdfPCell(new Paragraph("Status", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		pdf_table.addCell(pdf_cell);
		
		pdf_cell = new PdfPCell(new Paragraph("Milestone", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		pdf_table.addCell(pdf_cell);
		
		pdf_cell = new PdfPCell(new Paragraph("Planned Start", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		pdf_table.addCell(pdf_cell);
		
		pdf_cell = new PdfPCell(new Paragraph("Planned Finish", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		pdf_table.addCell(pdf_cell);
		
		pdf_cell = new PdfPCell(new Paragraph("Actual Start", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		pdf_table.addCell(pdf_cell);
		
		pdf_cell = new PdfPCell(new Paragraph("Actual Finish", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		pdf_table.addCell(pdf_cell);
		
		pdf_cell = new PdfPCell(new Paragraph("Notes", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		pdf_table.addCell(pdf_cell);
		
		pdf_cell = new PdfPCell(new Paragraph("Search Field", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		pdf_table.addCell(pdf_cell);
		
		pdf_cell = new PdfPCell(new Paragraph("Grouping", FontFactory.getFont(FontFactory.TIMES_BOLD, 11, Color.BLACK)));
		pdf_cell.setBackgroundColor(Color.lightGray);
		pdf_table.addCell(pdf_cell);
  	
		//Data From the Table
		for(int x=0; x < wdContext.nodeDis_Gt_Tasks().size(); x++) {
			IPrivateView_Rep.IDis_Gt_TasksElement element = wdContext.nodeDis_Gt_Tasks().getDis_Gt_TasksElementAt(x);
			
			if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("2")) //Group
				pdf_table.addCell(new Paragraph(element.getYrole_Func_Name(), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
				
			pdf_table.addCell(new Paragraph(element.getYresource(), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
			//table.setBackgroundColor(Color.YELLOW);
//			table.addCell(element.getYproduct_Name());
			pdf_table.addCell(new Paragraph(element.getYproduct_Name(), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
			pdf_table.addCell(new Paragraph(element.getYactivity(), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
			pdf_table.addCell(new Paragraph(element.getYtask(), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
			pdf_table.addCell(new Paragraph(element.getYstatus(), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
			pdf_table.addCell(new Paragraph(element.getYmilestone(), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
//			table.addCell(element.getYmilestone());
			
			try {
				pdf_table.addCell(new Paragraph(dateFormat.format(element.getYplanstart()), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
			}
			catch (NullPointerException e) {
				pdf_table.addCell("");
			}
			
			try {
				pdf_table.addCell(new Paragraph(dateFormat.format(element.getYplanfinish()), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
			}
			catch (NullPointerException e) {
				pdf_table.addCell("");
			}
			
			try {
				pdf_table.addCell(new Paragraph(dateFormat.format(element.getYactualstart()), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
			}
			catch (NullPointerException e) {
				pdf_table.addCell("");
			}
			
			try {
				pdf_table.addCell(new Paragraph(dateFormat.format(element.getYactualfinish()), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
			}
			catch (NullPointerException e) {
				pdf_table.addCell(""); 
			}
			
			pdf_table.addCell(new Paragraph(element.getYnotes(), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
			pdf_table.addCell(new Paragraph(element.getYstudy_Number(), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
			pdf_table.addCell(new Paragraph(element.getYmsl_Number(), FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Color.BLACK)));
			
			//table.addCell(element.getYnotes());
			//table.addCell(element.getYstudy_Number());
			//table.addCell(element.getYmsl_Number());
		}
	
		//Adding table to the document
		document.add(pdf_table);
		
		document.close();
  	
		//we have now a filled bytearray with our PDF content and we want to display it 
		  byte[] pdfContent= outputStream.toByteArray();
		  pdfResource = WDWebResource.getWebResource(pdfContent, WDWebResourceType.PDF);
			pdfResource.setResourceName(fileName);
		wdComponentAPI.getWindowManager().createExternalWindow(pdfResource.getURL(),"Test View",true).open();
 

  	
		//FileInputStream excelCSVFile = new FileInputStream();
		//cachedExcelResource = getCachedWebResource(outputStream, fileName, WDWebResourceType.PDF);

  	
	  //	showPopUp(WDWebResourceType.PDF, outputStream, "PDF Out Put");
		writer.close();
		outputStream.close();
	} catch (Exception ex) {
		wdComponentAPI.getMessageManager().reportException(ex.toString(), true);
	}

    //@@end
  }

  //@@begin javadoc:onActionSortGroupReport(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSortGroupReport(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSortGroupReport(ServerEvent)
	wdContext.currentContextElement().getTableSorter().sort(wdEvent, wdContext.nodeDis_Gt_Tasks());
    //@@end
  }

  //@@begin javadoc:onActionSortIndividualReport(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSortIndividualReport(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSortIndividualReport(ServerEvent)
	wdContext.currentContextElement().getTableSorter1().sort(wdEvent, wdContext.nodeDis_Gt_Tasks());
    //@@end
  }

  //@@begin javadoc:onActionFilterIndividualReport(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionFilterIndividualReport(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionFilterIndividualReport(ServerEvent)
	wdContext.currentContextElement().getTableFilter1().filter(wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeCus_Gt_Tasks(),
															  wdContext.nodeDis_Gt_Tasks());


    //@@end
  }

  //@@begin javadoc:onActionFilterGroupReport(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionFilterGroupReport(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionFilterGroupReport(ServerEvent)
	wdContext.currentContextElement().getTableFilter().filter(wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeCus_Gt_Tasks(),
															  wdContext.nodeDis_Gt_Tasks());

    //@@end
  }

  /*
   * The following code section can be used for any Java code that is 
   * not to be visible to other controllers/views or that contains constructs
   * currently not supported directly by Web Dynpro (such as inner classes or
   * member variables etc.). </p>
   *
   * Note: The content of this section is in no way managed/controlled
   * by the Web Dynpro Designtime or the Web Dynpro Runtime. 
   */
  //@@begin others
  public com.sap.tc.webdynpro.services.sal.url.api.IWDCachedWebResource getCachedWebResource( java.io.InputStream file, java.lang.String name, com.sap.tc.webdynpro.services.sal.url.api.WDWebResourceType type )
  {
	IWDCachedWebResource cachedWebResource = null;

	if (file != null){
		cachedWebResource = WDWebResource.getWebResource(file, type);
		cachedWebResource.setResourceName(name);
	}
	return cachedWebResource;
  }
  //@@end
}
