// ---------------------------------------------------------------------------
// This file has been generated partially by the Web Dynpro Code Generator.
// MODIFY CODE ONLY IN SECTIONS ENCLOSED BY @@begin AND @@end.
// ALL OTHER CHANGES WILL BE LOST IF THE FILE IS REGENERATED.
// ---------------------------------------------------------------------------
package com.monsanto.xrpm;

// 
// IMPORTANT NOTE: 
// _ALL_ IMPORT STATEMENTS MUST BE PLACED IN THE FOLLOWING SECTION ENCLOSED
// BY @@begin imports AND @@end. FURTHERMORE, THIS SECTION MUST ALWAYS CONTAIN
// AT LEAST ONE IMPORT STATEMENT (E.G. THAT FOR IPrivateView_group_resource_task_rep).
// OTHERWISE, USING THE ECLIPSE FUNCTION "Organize Imports" FOLLOWED BY
// A WEB DYNPRO CODE GENERATION (E.G. PROJECT BUILD) WILL RESULT IN THE LOSS
// OF IMPORT STATEMENTS.
//
//@@begin imports
import com.monsanto.xrpm.model.Rsdsselopt;
import com.monsanto.xrpm.model.Y_Xrpm_Group_Resource_Tasks_Input;
import com.monsanto.xrpm.wdp.IPrivateView_group_resource_task_rep;
import com.sap.tc.webdynpro.progmodel.api.IWDAttributeInfo;
import com.sap.tc.webdynpro.progmodel.api.IWDNode;
import com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener;
import com.sap.tc.webdynpro.progmodel.api.WDValueServices;
import com.sap.tc.webdynpro.progmodel.api.WDVisibility;
import com.sap.tc.webdynpro.progmodel.context.Node;
//@@end

//@@begin documentation
//@@end

public class View_group_resource_task_rep
{
  /**
   * Logging location.
   */
  private static final com.sap.tc.logging.Location logger = 
    com.sap.tc.logging.Location.getLocation(View_group_resource_task_rep.class);

  static 
  {
    //@@begin id
    String id = "$Id$";
    //@@end
    com.sap.tc.logging.Location.getLocation("ID.com.sap.tc.webdynpro").infoT(id);
  }

  /**
   * Private access to the generated Web Dynpro counterpart 
   * for this controller class.  </p>
   *
   * Use <code>wdThis</code> to gain typed access to the context,
   * to trigger navigation via outbound plugs, to get and enable/disable
   * actions, fire declared events, and access used controllers and/or 
   * component usages.
   *
   * @see com.monsanto.xrpm.wdp.IPrivateView_group_resource_task_rep for more details
   */
  private final IPrivateView_group_resource_task_rep wdThis;

  /**
   * Root node of this controller's context. </p>
   *
   * Provides typed access not only to the elements of the root node 
   * but also to all nodes in the context (methods node<i>XYZ</i>()) 
   * and their currently selected element (methods current<i>XYZ</i>Element()). 
   * It also facilitates the creation of new elements for all nodes 
   * (methods create<i>XYZ</i>Element()). </p>
   *
   * @see com.monsanto.xrpm.wdp.IPrivateView_group_resource_task_rep.IContextNode for more details.
   */
  private final IPrivateView_group_resource_task_rep.IContextNode wdContext;

  /**
   * A shortcut for <code>wdThis.wdGetAPI()</code>. </p>
   * 
   * Represents the generic API of the generic Web Dynpro counterpart 
   * for this controller. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDViewController wdControllerAPI;
  
  /**
   * A shortcut for <code>wdThis.wdGetAPI().getComponent()</code>. </p>
   * 
   * Represents the generic API of the Web Dynpro component this controller 
   * belongs to. Can be used to access the message manager, the window manager,
   * to add/remove event handlers and so on. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdComponentAPI;
  
  public View_group_resource_task_rep(IPrivateView_group_resource_task_rep wdThis)
  {
    this.wdThis = wdThis;
    this.wdContext = wdThis.wdGetContext();
    this.wdControllerAPI = wdThis.wdGetAPI();
    this.wdComponentAPI = wdThis.wdGetAPI().getComponent();
  }

  //@@begin javadoc:wdDoInit()
  /** Hook method called to initialize controller. */
  //@@end
  public void wdDoInit()
  {
    //@@begin wdDoInit()
	wdContext.currentContextElement().setVisible_variantName(WDVisibility.VISIBLE);
    
	IWDAttributeInfo[] ovsStartUpAttributes = {wdContext.nodeTaskStatus().getNodeInfo().getAttribute("task_staus")};
	IWDOVSContextNotificationListener listener_taskstatus = wdThis.wdGetComp_group_resource_task_repController().getOVSTaskstatusListener();
	WDValueServices.addOVSExtension("OVS", // not used yet by the current OVS Service 
									ovsStartUpAttributes, // fields bound to startup attributes will be ovs-enabled 
									wdThis.wdGetComp_group_resource_task_repController().getOVSTaskstatusInputNode(), 
									wdThis.wdGetComp_group_resource_task_repController().getOVSTaskstausOutputNode(), 
									listener_taskstatus);
									
	IWDAttributeInfo[] ovsStartUpAttributes_resp_res = {wdContext.nodeResponsibleResource().getNodeInfo().getAttribute("field1")};
	IWDOVSContextNotificationListener listener_resp_res = wdThis.wdGetComp_group_resource_task_repController().getOVSRespResourceListener();
	WDValueServices.addOVSExtension("OVS", // not used yet by the current OVS Service 
									ovsStartUpAttributes_resp_res, // fields bound to startup attributes will be ovs-enabled 
									wdThis.wdGetComp_group_resource_task_repController().getOVSRespResourceInputNode(), 
									wdThis.wdGetComp_group_resource_task_repController().getOVSRespResourceOutputNode(), 
									listener_resp_res);	
									
	IWDAttributeInfo[] ovsStartUpAttributes_person = {wdContext.nodePerson().getNodeInfo().getAttribute("field1")};
	IWDOVSContextNotificationListener listener_person = wdThis.wdGetComp_group_resource_task_repController().getOVSPersonListener();
	WDValueServices.addOVSExtension("OVS", // not used yet by the current OVS Service 
									ovsStartUpAttributes_person, // fields bound to startup attributes will be ovs-enabled 
									wdThis.wdGetComp_group_resource_task_repController().getOVSPersonInputNode(), 
									wdThis.wdGetComp_group_resource_task_repController().getOVSPersonOutputNode(), 
									listener_person);																	
	
	IWDAttributeInfo[] ovsStartUpAttributes_fun_area = {wdContext.nodeFunctionalArea().getNodeInfo().getAttribute("funtional_area")};
	IWDOVSContextNotificationListener listener_fun_area = wdThis.wdGetComp_group_resource_task_repController().getOVSFunctionalAreaListener();
	WDValueServices.addOVSExtension("OVS", // not used yet by the current OVS Service 
									ovsStartUpAttributes_fun_area, // fields bound to startup attributes will be ovs-enabled 
									wdThis.wdGetComp_group_resource_task_repController().getOVSFunctionalAreaInputNode(), 
									wdThis.wdGetComp_group_resource_task_repController().getOVSFunctionalAreaOutputNode(), 
									listener_fun_area);		
	
	wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	wdContext.currentContextElement().setTray_header_text("Saved selections");
	wdContext.currentContextElement().setSelectedKey("2");
	wdContext.currentContextElement().setVisible_new_variantName(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_variantName(WDVisibility.VISIBLE);


    //@@end
  }

  //@@begin javadoc:wdDoExit()
  /** Hook method called to clean up controller. */
  //@@end
  public void wdDoExit()
  {
    //@@begin wdDoExit()
    //@@end
  }

  //@@begin javadoc:wdDoModifyView
  /**
   * Hook method called to modify a view just before rendering.
   * This method conceptually belongs to the view itself, not to the
   * controller (cf. MVC pattern).
   * It is made static to discourage a way of programming that
   * routinely stores references to UI elements in instance fields
   * for access by the view controller's event handlers, and so on.
   * The Web Dynpro programming model recommends that UI elements can
   * only be accessed by code executed within the call to this hook method.
   *
   * @param wdThis Generated private interface of the view's controller, as
   *        provided by Web Dynpro. Provides access to the view controller's
   *        outgoing controller usages, etc.
   * @param wdContext Generated interface of the view's context, as provided
   *        by Web Dynpro. Provides access to the view's data.
   * @param view The view's generic API, as provided by Web Dynpro.
   *        Provides access to UI elements.
   * @param firstTime Indicates whether the hook is called for the first time
   *        during the lifetime of the view.
   */
  //@@end
  public static void wdDoModifyView(IPrivateView_group_resource_task_rep wdThis, IPrivateView_group_resource_task_rep.IContextNode wdContext, com.sap.tc.webdynpro.progmodel.api.IWDView view, boolean firstTime)
  {
    //@@begin wdDoModifyView
	wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
    //@@end
  }

  //@@begin javadoc:onActionMultiselection_func_area(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionMultiselection_func_area(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionMultiselection_func_area(ServerEvent)
	int noOfInputs = 1, noOfOutputs = 2;
	String column1 = "Role Function ID", column2 = "Role Function Name", column3 = "", column4 = "", column5 = "", column6 = "", column7 = "";
	String label1 = "Role Function Name", label2 = "", label3 = "", label4 = "", label5 = "", label6 = "", label7 = "";
	boolean visibleAddButton = true, visibleDeleteButton = true, visibleDeleteAllButton = true; 
	boolean enableSingleInclude = true, enableRangeInclude = false, enableSingleExclude = false, enableRangeExclude = false, multipleselectionEnabled = false;
	String extra1 = wdContext.currentFunctionalAreaElement().getField3(), extra2 = "";
	String image = "~sapicons/s_bgequa.gif"; //Always equal sign (include) - The other signs are not applicable for this application
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentFunctionalAreaElement().getFuntional_area());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentFunctionalAreaElement().getField3());
	wdThis.wdGetMultipleSelectionInterface().DC_open_multiselection_screen("Role Function", wdContext.currentFunctionalAreaElement().getFuntional_area(), "", extra1, extra2, noOfInputs, noOfOutputs, image, column1, column2, column3, column4, column5, column6, column7, label1, label2, label3, label4, label5, label6, label7, visibleAddButton, visibleDeleteButton, visibleDeleteAllButton, enableSingleInclude, enableRangeInclude, enableSingleExclude, enableRangeExclude, multipleselectionEnabled);
    //@@end
  }

  //@@begin javadoc:onActionMultiselection_person(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionMultiselection_person(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionMultiselection_person(ServerEvent)
	int noOfInputs = 2, noOfOutputs = 3;
	String column1 = "User ID", column2 = "Last Name", column3 = "First Name", column4 = "", column5 = "", column6 = "", column7 = "";
	String label1 = "Last Name", label2 = "First Name", label3 = "", label4 = "", label5 = "", label6 = "", label7 = "";
	boolean visibleAddButton = true, visibleDeleteButton = true, visibleDeleteAllButton = true; 
	boolean enableSingleInclude = true, enableRangeInclude = false, enableSingleExclude = false, enableRangeExclude = false, multipleselectionEnabled = false;
	String extra1 = wdContext.currentPersonElement().getField4(), extra2 = "";
	String image = "~sapicons/s_bgequa.gif"; //Always equal sign (include) - The other signs are not applicable for this application
	wdThis.wdGetMultipleSelectionInterface().DC_open_multiselection_screen("Person(s)", wdContext.currentPersonElement().getField1(), "", extra1, extra2, noOfInputs, noOfOutputs, image, column1, column2, column3, column4, column5, column6, column7, label1, label2, label3, label4, label5, label6, label7, visibleAddButton, visibleDeleteButton, visibleDeleteAllButton, enableSingleInclude, enableRangeInclude, enableSingleExclude, enableRangeExclude, multipleselectionEnabled);
    //@@end
  }

  //@@begin javadoc:onActionSaveAs(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSaveAs(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSaveAs(ServerEvent)
	wdThis.wdGetComp_group_resource_task_repController().open_popup_saveas();
    //@@end
  }

  //@@begin javadoc:onActionMultiselection_Resp_Resource(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionMultiselection_Resp_Resource(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionMultiselection_Resp_Resource(ServerEvent)
	int noOfInputs = 2, noOfOutputs = 3;
	String column1 = "User ID", column2 = "Last Name", column3 = "First Name", column4 = "", column5 = "", column6 = "", column7 = "";
	String label1 = "Last Name", label2 = "First Name", label3 = "", label4 = "", label5 = "", label6 = "", label7 = "";
	boolean visibleAddButton = true, visibleDeleteButton = true, visibleDeleteAllButton = true; 
	boolean enableSingleInclude = true, enableRangeInclude = false, enableSingleExclude = false, enableRangeExclude = false, multipleselectionEnabled = false;
	String extra1 = "", extra2 = "";
	String image = "~sapicons/s_bgequa.gif"; //Always equal sign (include) - The other signs are not applicable for this application
	wdThis.wdGetMultipleSelectionInterface().DC_open_multiselection_screen("Resp Resource", wdContext.currentResponsibleResourceElement().getField1(), "", extra1, extra2, noOfInputs, noOfOutputs, image, column1, column2, column3, column4, column5, column6, column7, label1, label2, label3, label4, label5, label6, label7, visibleAddButton, visibleDeleteButton, visibleDeleteAllButton, enableSingleInclude, enableRangeInclude, enableSingleExclude, enableRangeExclude, multipleselectionEnabled);
    //@@end
  }

  //@@begin javadoc:onActionMultiselection_Taskstatus(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionMultiselection_Taskstatus(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionMultiselection_Taskstatus(ServerEvent)
	int noOfInputs = 2, noOfOutputs = 2;
	String column1 = "Task Status", column2 = "Description", column3 = "", column4 = "", column5 = "", column6 = "", column7 = "";
	String label1 = "Task Status", label2 = "Description", label3 = "", label4 = "", label5 = "", label6 = "", label7 = ""; 
	boolean visibleAddButton = true, visibleDeleteButton = true, visibleDeleteAllButton = true; 
	boolean enableSingleInclude = true, enableRangeInclude = false, enableSingleExclude = false, enableRangeExclude = false, multipleselectionEnabled = false;
	String extra1 = "", extra2 = "";
	String image = "~sapicons/s_bgequa.gif"; //Always equal sign (include) - The other signs are not applicable for this application
	wdThis.wdGetMultipleSelectionInterface().DC_open_multiselection_screen("Task Status", wdContext.currentTaskStatusElement().getTask_staus(), "", extra1, extra2, noOfInputs, noOfOutputs, image, column1, column2, column3, column4, column5, column6, column7, label1, label2, label3, label4, label5, label6, label7, visibleAddButton, visibleDeleteButton, visibleDeleteAllButton, enableSingleInclude, enableRangeInclude, enableSingleExclude, enableRangeExclude, multipleselectionEnabled);

    //@@end
  }

  //@@begin javadoc:getSelections(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void getSelections(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent, java.lang.String screen_for, java.lang.String value1, java.lang.String value2, java.lang.String extra1, java.lang.String extra2, int totNoOfCriterias, java.lang.String image )
  {
    //@@begin getSelections(ServerEvent)
	if (screen_for.equalsIgnoreCase("Task Status")) {
		wdContext.currentTaskStatusElement().setTask_staus(value1);
		wdContext.currentTaskStatusElement().setDescription(value2);
						
		if (totNoOfCriterias > 1)
			wdContext.currentContextElement().setImage_multi_taskstatus("~sapicons/s_bgmore.gif");
		else
			wdContext.currentContextElement().setImage_multi_taskstatus("~sapicons/s_b_more.gif");
					
//		wdContext.currentContextElement().setImage_taskstatus_operator(image);
//		if (!image.equalsIgnoreCase("")) {
//			wdContext.currentContextElement().setVisibility_taskstatus_operator(WDVisibility.VISIBLE);		
//		}
//		else {
//			wdContext.currentContextElement().setVisibility_taskstatus_operator(WDVisibility.NONE);
//		}		    	
	}
	else 
		if (screen_for.equalsIgnoreCase("Resp Resource")) {
			wdContext.currentResponsibleResourceElement().setField1(value1);
			wdContext.currentResponsibleResourceElement().setField2(value2);
							
			if (totNoOfCriterias > 1)
				wdContext.currentContextElement().setImage_multi_resp_resource("~sapicons/s_bgmore.gif");
			else
				wdContext.currentContextElement().setImage_multi_resp_resource("~sapicons/s_b_more.gif");
//						
//	//		wdContext.currentContextElement().setImage_taskstatus_operator(image);
//	//		if (!image.equalsIgnoreCase("")) {
//	//			wdContext.currentContextElement().setVisibility_taskstatus_operator(WDVisibility.VISIBLE);		
//	//		}
//	//		else {
//	//			wdContext.currentContextElement().setVisibility_taskstatus_operator(WDVisibility.NONE);
//	//		}		    	
		}
		else 
			if (screen_for.equalsIgnoreCase("Person(s)")) {
				wdContext.currentPersonElement().setField1(value1);
				wdContext.currentPersonElement().setField4(extra1);
				wdContext.currentContextElement().setPersons(extra1);
								
				if (totNoOfCriterias > 1)
					wdContext.currentContextElement().setImage_multi_persons("~sapicons/s_bgmore.gif");
				else
					wdContext.currentContextElement().setImage_multi_persons("~sapicons/s_b_more.gif");
//							
//		//		wdContext.currentContextElement().setImage_taskstatus_operator(image);
//		//		if (!image.equalsIgnoreCase("")) {
//		//			wdContext.currentContextElement().setVisibility_taskstatus_operator(WDVisibility.VISIBLE);		
//		//		}
//		//		else {
//		//			wdContext.currentContextElement().setVisibility_taskstatus_operator(WDVisibility.NONE);
//		//		}		    	
			}
			else 
				if (screen_for.equalsIgnoreCase("Role Function")) {
					wdContext.currentFunctionalAreaElement().setFuntional_area(value1);
					wdContext.currentFunctionalAreaElement().setField3(extra1);
					wdContext.currentContextElement().setRole_function(extra1);
					//wdComponentAPI.getMessageManager().reportSuccess(value1);
					//wdComponentAPI.getMessageManager().reportSuccess(extra1);
											
					if (totNoOfCriterias > 1)
						wdContext.currentContextElement().setImage_muliti_functionalArea("~sapicons/s_bgmore.gif");
					else
						wdContext.currentContextElement().setImage_muliti_functionalArea("~sapicons/s_b_more.gif");
			//							
			////		wdContext.currentContextElement().setImage_taskstatus_operator(image);
			////		if (!image.equalsIgnoreCase("")) {
			////			wdContext.currentContextElement().setVisibility_taskstatus_operator(WDVisibility.VISIBLE);		
			////		}
			////		else {
			////			wdContext.currentContextElement().setVisibility_taskstatus_operator(WDVisibility.NONE);
			////		}		    	
				}

    //@@end
  }

  //@@begin javadoc:onActionSelectArea(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelectArea(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelectArea(ServerEvent)
	wdContext.currentContextElement().setVisible_group_selection(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_individual_selection(WDVisibility.NONE);
    //@@end
  }

  //@@begin javadoc:onActionSelectPerson(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelectPerson(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelectPerson(ServerEvent)
	wdContext.currentContextElement().setVisible_group_selection(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_individual_selection(WDVisibility.VISIBLE);

    //@@end
  }

  //@@begin javadoc:onActionSave(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSave(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSave(ServerEvent)
    wdThis.wdGetComp_group_resource_task_repController().saveExistingSelection();
    //@@end
  }

  //@@begin javadoc:onActionNew(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionNew(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionNew(ServerEvent)
    wdThis.wdGetComp_group_resource_task_repController().open_popup_new();
    
    //@@end
  }

  //@@begin javadoc:onActionDelete(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionDelete(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionDelete(ServerEvent)
    wdThis.wdGetComp_group_resource_task_repController().open_popup_delete();
	
    //@@end
  }

  //@@begin javadoc:onActionExistingSelections(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionExistingSelections(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionExistingSelections(ServerEvent)
	wdContext.currentContextElement().setRole_function("");
	wdContext.currentContextElement().setPersons("");
	wdContext.currentContextElement().setTray_header_text("Saved selections");
	wdContext.currentContextElement().setVisible_variantName(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_new_variantName(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_group_selection(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_individual_selection(WDVisibility.NONE);
	wdContext.currentContextElement().setRadioButton_groupBy("2");
	
	if (wdContext.nodeUser_Variant().size() > 0) {
		wdContext.currentContextElement().setVisible_variantName(WDVisibility.VISIBLE);
		wdContext.currentContextElement().setVisible_new_variantName(WDVisibility.NONE);
		wdContext.currentContextElement().setTray_header_text("Saved selections");
		wdThis.wdGetComp_group_resource_task_repController().setDefaultAsFirstElement();
    	
		Node node = wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeUser_Variant_Temp();
		wdContext.currentContextElement().setBegdate(wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYybegda());
		wdContext.currentContextElement().setEnddate(wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYyendda());
		
		for (int b = wdContext.nodeTableToMultiselection().size() - 1; b >=0; --b) {
			wdContext.nodeTableToMultiselection().removeElement(wdContext.nodeTableToMultiselection().getTableToMultiselectionElementAt(b));
		}
		wdContext.nodeTableToMultiselection().invalidate();

		//Task status
		String[] strFull_task_staus = splitString(wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYystatus());
		for (int d=0; d < strFull_task_staus.length; d++) {
			IPrivateView_group_resource_task_rep.ITableToMultiselectionElement table_to_multi = wdContext.createTableToMultiselectionElement();		
			table_to_multi.setField("Task Status");
			table_to_multi.setValue1(strFull_task_staus[d]);
			table_to_multi.setCategory("Tab_single_include");
			table_to_multi.setExtra1("");
			table_to_multi.setExtra2("");
			table_to_multi.setOperation("EQ");
			table_to_multi.setOperation_image("~sapicons/s_bgequa.gif");
			table_to_multi.setValue2("");
			table_to_multi.setTo("");
			wdContext.nodeTableToMultiselection().addElement(table_to_multi);
		}

		String[] strFull_fun_area = {} ,strFull_resp_resource = {} , strFull_persons = {}; 

		if (wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYygflag().equalsIgnoreCase("A")) {
			wdContext.currentContextElement().setRadioButton_groupBy("2"); //Area
			wdContext.currentContextElement().setVisible_group_selection(WDVisibility.VISIBLE);
			wdContext.currentContextElement().setVisible_individual_selection(WDVisibility.NONE);
			wdContext.currentContextElement().setResponsible_area(wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYyrespre());
			
			wdThis.wdGetComp_group_resource_task_repController().MD_execute_f4_help_rfc("RF", "", "");
			strFull_fun_area = splitString(wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYyrespbu());
			for (int b=0; b < strFull_fun_area.length; b++) {
				IPrivateView_group_resource_task_rep.ITableToMultiselectionElement table_to_multi = wdContext.createTableToMultiselectionElement();		
				table_to_multi.setField("Role Function");
				table_to_multi.setValue1(strFull_fun_area[b]);
				table_to_multi.setCategory("Tab_single_include");
				table_to_multi.setExtra1("");
				for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
					if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_fun_area[b])) {
						//wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						table_to_multi.setExtra1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						//wdContext.currentFunctionalAreaElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						//wdContext.currentContextElement().setRole_function(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						break;
					}
				}
				
				table_to_multi.setExtra2("");
				table_to_multi.setOperation("EQ");
				table_to_multi.setOperation_image("~sapicons/s_bgequa.gif");
				table_to_multi.setValue2("");
				table_to_multi.setTo("");
				wdContext.nodeTableToMultiselection().addElement(table_to_multi);
			}
		}
		else { 
			wdContext.currentContextElement().setRadioButton_groupBy("1"); //Person(s)
			wdContext.currentContextElement().setVisible_group_selection(WDVisibility.NONE);
			wdContext.currentContextElement().setVisible_individual_selection(WDVisibility.VISIBLE);

//			strFull_resp_resource = splitString(wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYyrespre());
//			for (int b=0; b < strFull_resp_resource.length; b++) {
//				IPrivateView_group_resource_task_rep.ITableToMultiselectionElement table_to_multi = wdContext.createTableToMultiselectionElement();		
//				table_to_multi.setField("Resp Resource");
//				table_to_multi.setValue1(strFull_resp_resource[b]);
//				table_to_multi.setCategory("Tab_single_include");
//				table_to_multi.setExtra1("");
//				table_to_multi.setExtra2("");
//				table_to_multi.setOperation("EQ");
//				table_to_multi.setOperation_image("~sapicons/s_bgequa.gif");
//				table_to_multi.setValue2("");
//				table_to_multi.setTo("");
//				wdContext.nodeTableToMultiselection().addElement(table_to_multi);
//			}
			wdThis.wdGetComp_group_resource_task_repController().MD_execute_f4_help_rfc("RP", "", "");
			strFull_persons = splitString(wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeUser_Variant_Temp().getUser_Variant_TempElementAt(0).getYyrespbu());
			for (int c=0; c < strFull_persons.length; c++) {
				IPrivateView_group_resource_task_rep.ITableToMultiselectionElement table_to_multi = wdContext.createTableToMultiselectionElement();		
				table_to_multi.setField("Person(s)");
				table_to_multi.setValue1(strFull_persons[c]);
				table_to_multi.setCategory("Tab_single_include");
				table_to_multi.setExtra1("");
				
				for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
					if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_persons[c])) {
						table_to_multi.setExtra1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						//wdContext.currentPersonElement().setField2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2());
						//wdContext.currentPersonElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						//wdContext.currentPersonElement().setField4(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
						break;
					}
				}
				table_to_multi.setExtra2("");
				table_to_multi.setOperation("EQ");
				table_to_multi.setOperation_image("~sapicons/s_bgequa.gif");
				table_to_multi.setValue2("");
				table_to_multi.setTo("");
				wdContext.nodeTableToMultiselection().addElement(table_to_multi);
			}	   
		}

		//Change multiple selection images
		if (strFull_task_staus.length > 1) 					
			wdContext.currentContextElement().setImage_multi_taskstatus("~sapicons/s_bgmore.gif");
		else 		
			wdContext.currentContextElement().setImage_multi_taskstatus("~sapicons/s_b_more.gif");
	
		if (strFull_resp_resource.length > 1)
			wdContext.currentContextElement().setImage_multi_resp_resource("~sapicons/s_bgmore.gif");
		else
			wdContext.currentContextElement().setImage_multi_resp_resource("~sapicons/s_b_more.gif");

		if (strFull_persons.length > 1)
			wdContext.currentContextElement().setImage_multi_persons("~sapicons/s_bgmore.gif");
		else
			wdContext.currentContextElement().setImage_multi_persons("~sapicons/s_b_more.gif");
 
		if (strFull_fun_area.length > 1)
			wdContext.currentContextElement().setImage_muliti_functionalArea("~sapicons/s_bgmore.gif");
		else
			wdContext.currentContextElement().setImage_muliti_functionalArea("~sapicons/s_b_more.gif");


		if (strFull_task_staus.length > 0) 	
			wdContext.currentTaskStatusElement().setTask_staus(strFull_task_staus[0]);
		else 
			wdContext.currentTaskStatusElement().setTask_staus("");
		
		if (strFull_resp_resource.length > 0) 	
			wdContext.currentResponsibleResourceElement().setField1(strFull_resp_resource[0]);
		else
			wdContext.currentResponsibleResourceElement().setField1("");

		if (strFull_persons.length > 0) { 	
			wdContext.currentPersonElement().setField1(strFull_persons[0]);
			wdThis.wdGetComp_group_resource_task_repController().MD_execute_f4_help_rfc("RP", "", "");
			for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
				if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_persons[0])) {
					wdContext.currentPersonElement().setField2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2());
					wdContext.currentPersonElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
					wdContext.currentPersonElement().setField4(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
					wdContext.currentContextElement().setPersons(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield2() + ", " + wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
					break;
				}
			}
		}
		else
			wdContext.currentPersonElement().setField1("");
			
		if (strFull_fun_area.length > 0) { 	
			wdContext.currentFunctionalAreaElement().setFuntional_area(strFull_fun_area[0]);
			wdThis.wdGetComp_group_resource_task_repController().MD_execute_f4_help_rfc("RF", strFull_fun_area[0], "");
			for (int v=0; v < wdContext.nodeHelp_Tab().size(); v++) {
				if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYyfield1().equalsIgnoreCase(strFull_fun_area[0])) {
					wdContext.currentFunctionalAreaElement().setField3(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
					wdContext.currentContextElement().setRole_function(wdContext.nodeHelp_Tab().getHelp_TabElementAt(v).getYytext1());
					break;
				}
			}
		}
		else
			wdContext.currentFunctionalAreaElement().setFuntional_area("");
			
		//send the data to multiple selection component
		wdThis.wdGetMultipleSelectionInterface().setMultiple_selection_table(wdContext.nodeTableToMultiselection());
		

	}
	else {
		wdThis.wdGetComp_group_resource_task_repController().open_waring_popup();
	}

    //@@end
  }

  //@@begin javadoc:onActionNewSelections(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionNewSelections(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionNewSelections(ServerEvent)
	wdContext.currentContextElement().setRole_function("");
	wdContext.currentContextElement().setPersons("");
	wdContext.currentContextElement().setVisible_variantName(WDVisibility.NONE);
	wdContext.currentContextElement().setTray_header_text("New selection");
	wdContext.currentContextElement().setVisible_new_variantName(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_group_selection(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_individual_selection(WDVisibility.NONE);
	wdContext.currentContextElement().setRadioButton_groupBy("2");
	
	java.util.Date utilDate = new java.util.Date();
	java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
    
	wdContext.currentContextElement().setBegdate(null);
	wdContext.currentContextElement().setEnddate(null);
	wdContext.currentFunctionalAreaElement().setFuntional_area("");
	
	wdContext.currentResponsibleResourceElement().setField1("");
	wdContext.currentResponsibleResourceElement().setField2("");
	wdContext.currentResponsibleResourceElement().setField3("");
	wdContext.currentResponsibleResourceElement().setField4("");
	
	wdContext.currentPersonElement().setField1("");
	wdContext.currentPersonElement().setField2("");
	wdContext.currentPersonElement().setField3("");
	wdContext.currentPersonElement().setField4("");
	
	wdContext.currentTaskStatusElement().setDescription("");
	wdContext.currentTaskStatusElement().setTask_staus("");
	
	wdContext.currentContextElement().setSavedSelection("");
	
	
	for (int b = wdContext.nodeTableToMultiselection().size() - 1; b >= 0; --b) {
		wdContext.nodeTableToMultiselection().removeElement(wdContext.nodeTableToMultiselection().getTableToMultiselectionElementAt(b));
	}
	wdContext.nodeTableToMultiselection().invalidate();
		
	wdContext.currentContextElement().setImage_muliti_functionalArea("~sapicons/s_b_more.gif");
	wdContext.currentContextElement().setImage_multi_resp_resource("~sapicons/s_b_more.gif");
	wdContext.currentContextElement().setImage_multi_taskstatus("~sapicons/s_b_more.gif");
	wdContext.currentContextElement().setImage_multi_persons("~sapicons/s_b_more.gif");
	
	wdThis.wdGetMultipleSelectionInterface().setMultiple_selection_table(wdContext.nodeTableToMultiselection());
	
	//send the data to multiple selection component
	wdThis.wdGetMultipleSelectionInterface().setMultiple_selection_table(wdContext.nodeTableToMultiselection());

	
	//wdThis.wdGetComp_group_resource_task_repController().open_popup_new();
    //@@end
  }

  //@@begin javadoc:onActionSaveNewVariant(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSaveNewVariant(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSaveNewVariant(ServerEvent)
	wdThis.wdGetComp_group_resource_task_repController().open_popup_new();
    //@@end
  }

  //@@begin javadoc:onActionchangeVariant(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionchangeVariant(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionchangeVariant(ServerEvent)
    wdThis.wdGetComp_group_resource_task_repController().change_variant(wdContext.currentContextElement().getSavedSelection());
    //@@end
  }

  //@@begin javadoc:onPlugFromReport(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onPlugFromReport(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onPlugFromReport(ServerEvent)
    //@@end
  }

  //@@begin javadoc:onActionSubmit(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSubmit(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSubmit(ServerEvent)
	IWDNode node = wdThis.wdGetMultipleSelectionInterface().getMultiselectionTable();
    
	//clear the node
	for (int b = wdContext.nodeGt_Options_Input().size() - 1; b >= 0; --b ) {
		wdContext.nodeGt_Options_Input().removeElement(wdContext.nodeGt_Options_Input().getElementAt(b));
	}
	wdContext.nodeGt_Options_Input().invalidate();
    
	for (int b = wdContext.nodeGt_Status_Input().size() - 1; b >= 0; --b ) {
		wdContext.nodeGt_Status_Input().removeElement(wdContext.nodeGt_Status_Input().getElementAt(b));
	}
	wdContext.nodeGt_Status_Input().invalidate();
    
	//Add multiple selection table elements
	for (int v=0; v < node.size(); v++) {
		Y_Xrpm_Group_Resource_Tasks_Input task = new Y_Xrpm_Group_Resource_Tasks_Input();
    	    	
		if (node.getElementAt(v).getAttributeAsText("Field").equalsIgnoreCase("Task Status")) {
			Rsdsselopt opt = new Rsdsselopt();
			opt.setSign("I"); //Include
			opt.setOption("EQ");
			opt.setHigh("");
			opt.setLow(node.getElementAt(v).getAttributeAsText("Value1"));
			wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().modelObject().addGt_Status(opt);
		}
		else
			if (node.getElementAt(v).getAttributeAsText("Field").equalsIgnoreCase("Person(s)")) {
				if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("1")) { //Individual
					Rsdsselopt opt = new Rsdsselopt();
					opt.setSign("I"); //Include
					opt.setOption("EQ");
					opt.setHigh("");
					opt.setLow(node.getElementAt(v).getAttributeAsText("Value1"));
					wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().modelObject().addGt_Options(opt);
				}
			}
			else
				if (node.getElementAt(v).getAttributeAsText("Field").equalsIgnoreCase("Role Function")) {
					if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("2")) { //Group
						Rsdsselopt opt = new Rsdsselopt();
						opt.setSign("I"); //Include
						opt.setOption("EQ");
						opt.setHigh("");
						opt.setLow(node.getElementAt(v).getAttributeAsText("Value1"));
						wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().modelObject().addGt_Options(opt);
					}
				}
	}
	//wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentTaskStatusElement().getTask_staus());
	//Task Status
	int count_task = 1;
	for (int x = 0; x < wdContext.nodeGt_Status_Input().size(); x++) {
		if (wdContext.nodeGt_Status_Input().getGt_Status_InputElementAt(x).getLow().equalsIgnoreCase(wdContext.currentTaskStatusElement().getTask_staus())) { 
			count_task = 0;
			break;     	
		}
		else
			count_task++;
	}
    
	if (count_task != 0) {
		String task_stat = "";
		try {
			if (!wdContext.currentTaskStatusElement().getTask_staus().toUpperCase().equalsIgnoreCase(""))
				task_stat = wdContext.currentTaskStatusElement().getTask_staus().toUpperCase();
			else 
				task_stat = "";	
		}
		catch (NullPointerException e) {
			task_stat = "";
		}
    	
		if (!task_stat.equalsIgnoreCase("")) {
			//wdComponentAPI.getMessageManager().reportSuccess(task_stat); 
			Rsdsselopt opt = new Rsdsselopt();
			opt.setSign("I"); //Include
			opt.setOption("EQ");
			opt.setHigh("");
			opt.setLow(task_stat);
			wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().modelObject().addGt_Status(opt);
		}
	}
    
	if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("2")) { //Group
		//Role Function
		//wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentFunctionalAreaElement().getFuntional_area());
		//wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentFunctionalAreaElement().getField3());	
		//wdComponentAPI.getMessageManager().reportSuccess("ff");
		
		int count_role_function = 1;
		for (int x = 0; x < wdContext.nodeGt_Options_Input().size(); x++) {
			if (wdContext.nodeGt_Options_Input().getGt_Options_InputElementAt(x).getLow().equalsIgnoreCase(wdContext.currentFunctionalAreaElement().getFuntional_area())) { 
				count_role_function = 0;
				break;     	
			}
			else {
				//wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentFunctionalAreaElement().getFuntional_area());
				count_role_function++;
			}
		}
    
		if (count_role_function != 0) {
			String role_fun = "";
			try {
				if (!wdContext.currentFunctionalAreaElement().getFuntional_area().toUpperCase().equalsIgnoreCase(""))
					role_fun = wdContext.currentFunctionalAreaElement().getFuntional_area().toUpperCase();
				else 
					role_fun = "";	
			}
			catch (NullPointerException e) {
				role_fun = "";
			}
			
			if (!role_fun.equalsIgnoreCase("")) {
				Rsdsselopt opt = new Rsdsselopt();
				opt.setSign("I"); //Include
				opt.setOption("EQ");
				opt.setHigh("");
				opt.setLow(role_fun);
				wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().modelObject().addGt_Options(opt);
			}
		}
	}
	else { //Person(s)
		//Person(s)
		int count_person = 1;
		for (int x = 0; x < wdContext.nodeGt_Options_Input().size(); x++) {
			if (wdContext.nodeGt_Options_Input().getGt_Options_InputElementAt(x).getLow().equalsIgnoreCase(wdContext.currentPersonElement().getField1())) { 
				count_person = 0;
				break;     	
			}
			else
				count_person++;
		}
    
		if (count_person != 0) {
			String person = "";
			try {
				if (!wdContext.currentPersonElement().getField1().toUpperCase().equalsIgnoreCase(""))
					person = wdContext.currentPersonElement().getField1().toUpperCase();
				else 
					person = "";	
			}
			catch (NullPointerException e) {
				person = "";
			}
			
			if (!person.equalsIgnoreCase("")) {
				Rsdsselopt opt = new Rsdsselopt();
				opt.setSign("I"); //Include
				opt.setOption("EQ");
				opt.setHigh("");
				opt.setLow(person);
				wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().modelObject().addGt_Options(opt);
			}
		}
	}
    
	wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeGt_Options_Input().invalidate();
	wdThis.wdGetComp_group_resource_task_repController().wdGetContext().nodeGt_Status_Input().invalidate();
    
    
	wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().setGv_Begda(wdContext.currentContextElement().getBegdate());
	wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().setGv_Endda(wdContext.currentContextElement().getEnddate());
	
	if (wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("2"))
		wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().setGv_Group("A");
	else
		wdContext.currentY_Xrpm_Group_Resource_Tasks_InputElement().setGv_Group("P");
    
    
	if (wdContext.nodeGt_Options_Input().size() == 0 && wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("2")) //Group
		wdComponentAPI.getMessageManager().reportException("Role Function is mandatory. Please enter one or more role functions to run the report.", true);
	else 
		if (wdContext.nodeGt_Options_Input().size() == 0 && wdContext.currentContextElement().getRadioButton_groupBy().equalsIgnoreCase("1")) //Person(s)
			wdComponentAPI.getMessageManager().reportException("The field Person(s) is mandatory. Please enter one or more Person(s) to run the report", true);
		else
			wdThis.wdFirePlugToReport();

    //@@end
  }

  /*
   * The following code section can be used for any Java code that is 
   * not to be visible to other controllers/views or that contains constructs
   * currently not supported directly by Web Dynpro (such as inner classes or
   * member variables etc.). </p>
   *
   * Note: The content of this section is in no way managed/controlled
   * by the Web Dynpro Designtime or the Web Dynpro Runtime. 
   */
  //@@begin others
  public String[] splitString(String Line) {	
	//wdComponentAPI.getMessageManager().reportSuccess(Line);
	return Line.split(",");
  }
  //@@end
}
