// ---------------------------------------------------------------------------
// This file has been generated partially by the Web Dynpro Code Generator.
// MODIFY CODE ONLY IN SECTIONS ENCLOSED BY @@begin AND @@end.
// ALL OTHER CHANGES WILL BE LOST IF THE FILE IS REGENERATED.
// ---------------------------------------------------------------------------
package com.monsanto.hr;

// 
// IMPORTANT NOTE: 
// _ALL_ IMPORT STATEMENTS MUST BE PLACED IN THE FOLLOWING SECTION ENCLOSED
// BY @@begin imports AND @@end. FURTHERMORE, THIS SECTION MUST ALWAYS CONTAIN
// AT LEAST ONE IMPORT STATEMENT (E.G. THAT FOR IPrivateComp_incentive_pernr_planning).
// OTHERWISE, USING THE ECLIPSE FUNCTION "Organize Imports" FOLLOWED BY
// A WEB DYNPRO CODE GENERATION (E.G. PROJECT BUILD) WILL RESULT IN THE LOSS
// OF IMPORT STATEMENTS.
//
//@@begin imports
import com.monsanto.hr.wdp.IPrivateComp_incentive_pernr_planning;
import com.sap.tc.webdynpro.progmodel.model.api.WDModelFactory;
import com.sap.tc.webdynpro.services.session.api.IWDWindow;
import com.sap.tc.webdynpro.services.session.api.WDWindowPos;
//@@end

//@@begin documentation
//@@end

public class Comp_incentive_pernr_planning
{
  /**
   * Logging location.
   */
  private static final com.sap.tc.logging.Location logger = 
    com.sap.tc.logging.Location.getLocation(Comp_incentive_pernr_planning.class);

  static 
  {
    //@@begin id
    String id = "$Id$";
    //@@end
    com.sap.tc.logging.Location.getLocation("ID.com.sap.tc.webdynpro").infoT(id);
  }

  /**
   * Private access to the generated Web Dynpro counterpart 
   * for this controller class.  </p>
   *
   * Use <code>wdThis</code> to gain typed access to the context,
   * to trigger navigation via outbound plugs, to get and enable/disable
   * actions, fire declared events, and access used controllers and/or 
   * component usages.
   *
   * @see com.monsanto.hr.wdp.IPrivateComp_incentive_pernr_planning for more details
   */
  private final IPrivateComp_incentive_pernr_planning wdThis;

  /**
   * Root node of this controller's context. </p>
   *
   * Provides typed access not only to the elements of the root node 
   * but also to all nodes in the context (methods node<i>XYZ</i>()) 
   * and their currently selected element (methods current<i>XYZ</i>Element()). 
   * It also facilitates the creation of new elements for all nodes 
   * (methods create<i>XYZ</i>Element()). </p>
   *
   * @see com.monsanto.hr.wdp.IPrivateComp_incentive_pernr_planning.IContextNode for more details.
   */
  private final IPrivateComp_incentive_pernr_planning.IContextNode wdContext;

  /**
   * A shortcut for <code>wdThis.wdGetAPI()</code>. </p>
   * 
   * Represents the generic API of the generic Web Dynpro counterpart 
   * for this controller. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdControllerAPI;
  
  /**
   * A shortcut for <code>wdThis.wdGetAPI().getComponent()</code>. </p>
   * 
   * Represents the generic API of the Web Dynpro component this controller 
   * belongs to. Can be used to access the message manager, the window manager,
   * to add/remove event handlers and so on. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdComponentAPI;
  
  public Comp_incentive_pernr_planning(IPrivateComp_incentive_pernr_planning wdThis)
  {
    this.wdThis = wdThis;
    this.wdContext = wdThis.wdGetContext();
    this.wdControllerAPI = wdThis.wdGetAPI();
    this.wdComponentAPI = wdThis.wdGetAPI().getComponent();
  }

  //@@begin javadoc:wdDoInit()
  /** Hook method called to initialize controller. */
  //@@end
  public void wdDoInit()
  {
    //@@begin wdDoInit()
	Y_Hrcm_Mss_Org_Overview_New_Input ip_OrgOverview = new Y_Hrcm_Mss_Org_Overview_New_Input();
	wdContext.nodeY_Hrcm_Mss_Org_Overview_New_Input().bind(ip_OrgOverview);

	// View MSS_Plan Initialization
	Y_Hrcm_Mss_Pernr_Plan_Elig_Input plan_elig = new Y_Hrcm_Mss_Pernr_Plan_Elig_Input();
	wdContext.nodeY_Hrcm_Mss_Pernr_Plan_Elig_Input().bind(plan_elig);

	Y_Hrcm_Mss_Comp_Download_Copy_Input comp_download = new Y_Hrcm_Mss_Comp_Download_Copy_Input();
	wdContext.nodeY_Hrcm_Mss_Comp_Download_Copy_Input().bind(comp_download);

	// View SubmitEligibility Initialization
	Y_Hrcm_Mss_Submit_Comp_New_Input submit = new Y_Hrcm_Mss_Submit_Comp_New_Input();
	wdContext.nodeY_Hrcm_Mss_Submit_Comp_Data_Input().bind(submit);
	
	Y_Hrcm_Check_Awd_Amt_New_Input awd_amt = new Y_Hrcm_Check_Awd_Amt_New_Input();
	wdContext.nodeY_Hrcm_Check_Awd_Amt_New_Input().bind(awd_amt);
    //@@end
  }

  //@@begin javadoc:wdDoExit()
  /** Hook method called to clean up controller. */
  //@@end
  public void wdDoExit()
  {
    //@@begin wdDoExit()
    //@@end
  }

  //@@begin javadoc:wdDoPostProcessing()
  /**
   * Hook called to handle data retrieval errors before rendering.
   *
   * After doModifyView(), the Web Dynpro Framework gets all context data needed
   * for rendering by validating the contexts (which in turn calls the supply
   * functions and supplying relation roles). In this hook, the application
   * should handle the errors which occurred during validation of the contexts.
   * 
   * Using preorder depth-first traversal, this hook is called for all component
   * controllers starting with the current root component.
   *
   * Permitted operations:
   * - Flushing model queue
   * - Creating messages
   * - Reading context and model data
   *
   * Forbidden operations: 
   * - Invalidating model data
   * - Manipulating the context
   * - Firing outbound plugs
   * - Creating components
   * - ...   
   *
   * @param isCurrentRoot true if this is the root of the current request
   */
  //@@end
  public void wdDoPostProcessing(boolean isCurrentRoot)
  {
    //@@begin wdDoPostProcessing()
    //@@end
  }

  //@@begin javadoc:wdDoBeforeNavigation()
  /**
   * Hook before the navigation phase starts.
   *
   * This hook allows you to flush the model queue and handle any
   * errors that occur. Firing outbound plugs is allowed in this hook.
   *
   * Using preorder depth-first traversal, this hook is called for all component
   * controllers starting with the current root component.
   *
   * @param isCurrentRoot true if this is the root of the current request
   */
  //@@end
  public void wdDoBeforeNavigation(boolean isCurrentRoot)
  {
    //@@begin wdDoBeforeNavigation()
    //@@end
  }
  
  //@@begin javadoc:wdDoApplicationStateChange()
  /**
   * Hook that informs the application about a state change.
   * <p>
   * This hook is called e.g. to tell the application that will be
   * <ul>
   *  <li>left via a suspend plug and therefore should go into a suspend/sleep
   *      mode with minimal need of resources. errors that occur. Firing 
   *      outbound plugs is allowed in this hook.
   *  <li>left due to a timeout and could write it's state to a data base if the 
   *      user comes back later on
   * </ul>
   *
   * The concrete reason is available via IWDApplicationStateChangeInfo
   * <p>
   * <b>Important</b>: This hook is called for the top level component only!
   *
   * @param stateChangeInfo contains the information about the nature of the state change
   * @param stateChangeReturn allows the application to ask for a different state change. 
   *        The framework is allowed to ignore it considering i.e. the current resources situation.
   */
  //@@end
  public void wdDoApplicationStateChange(com.sap.tc.webdynpro.progmodel.api.IWDApplicationStateChangeInfo stateChangeInfo, com.sap.tc.webdynpro.progmodel.api.IWDApplicationStateChangeReturn stateChangeReturn)
  {
    //@@begin wdDoApplicationStateChange()
    //@@end
  }

  //@@begin javadoc:CloseSubmitEligibilityConfirmation()
  /** Declared method. */
  //@@end
  public void CloseSubmitEligibilityConfirmation( )
  {
    //@@begin CloseSubmitEligibilityConfirmation()
	if (submitEligibilityConfirmation != null) {
		submitEligibilityConfirmation.destroyInstance();
		submitEligibilityConfirmation = null;
	}
    //@@end
  }

  //@@begin javadoc:CloseSubmitFundingConfirmation()
  /** Declared method. */
  //@@end
  public void CloseSubmitFundingConfirmation( )
  {
    //@@begin CloseSubmitFundingConfirmation()

	if (submitFundingConfirmation != null) {
		
		submitFundingConfirmation.destroyInstance();
		submitFundingConfirmation = null;
	}
    //@@end
  }

  //@@begin javadoc:MD_execute_Get_Planning_Employees()
  /** Declared method. */
  //@@end
  public void MD_execute_Get_Planning_Employees( java.lang.String OrgId, java.lang.String Action, java.lang.String Plan, java.lang.String Folder, java.lang.String Pernr )
  {
    //@@begin MD_execute_Get_Planning_Employees()
//	boolean firstTime = false;
	  //Set the Ord Id Number
	  wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().setI_Orgeh(OrgId);
	  //Set the Action
	  wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().setI_Action(Action);
	  //Set the Plan
	  wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().setI_Plan(Plan);
	  //Set the Folder (All - 1, Directs - 2, Deligates - 3......)
	  wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().setI_Folder(Folder);
	  //Pernr retrieves from name search
	  wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().setI_Pernr(Pernr);
	
	  wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().setI_Userid(wdContext.currentContextElement().getPortal_LoginId());
	  wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().setI_Usertyp(wdContext.currentContextElement().getUserType());
//
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().getI_Action());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().getI_Folder());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().getI_Orgeh());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().getI_Pernr());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().getI_Plan());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().getI_Userid());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().getI_Usertyp());
//	
//	wdComponentAPI.getMessageManager().reportSuccess("" + wdContext.nodeTab_Eligibility_Input().size());
//	wdComponentAPI.getMessageManager().reportSuccess("" + wdContext.nodeTab_Planning_Input().size());
	  // Execute the MSS Planning RFC
	  try {	
		  wdContext.currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().modelObject().execute();
		 
		  wdContext.nodeTab_Eligibility_Plan().invalidate();
		  wdContext.nodeTab_Planning_Plan().invalidate();
		  wdContext.nodeMessage_Plan().invalidate();
		  wdContext.nodeOutput_MSS_Plan().invalidate();
		  
	//	wdComponentAPI.getMessageManager().reportSuccess("" + wdContext.nodeTab_Eligibility_Plan().size());
	//	wdComponentAPI.getMessageManager().reportSuccess("" + wdContext.nodeTab_Planning_Plan().size());
		
	  } catch (Exception e) {
		  wdThis.wdGetMessageAreaInterface().DC_Get_Message("Error in retreiving planning table: " + e.toString());	
		  //Disconnect the connection
		  IncentivePlanning model = (IncentivePlanning) WDModelFactory.getModelInstance(IncentivePlanning.class);
		  model.disconnectIfAlive();
	  }
	  //Disconnect the connection
	  IncentivePlanning model = (IncentivePlanning) WDModelFactory.getModelInstance(IncentivePlanning.class);
	  model.disconnectIfAlive();
		
	  if (wdContext.currentContextElement().getPath().equalsIgnoreCase("T")) {// Call the following method when comes through the team viewer. It gets called for namesearch in View_incentive_pernr_planning.		
	  	this.MD_execute_Org_Overview(OrgId, Plan, Folder, wdContext.currentContextElement().getPortal_LoginId(), "");
//		wdComponentAPI.getMessageManager().reportSuccess("" + wdContext.nodeTab_Eligibility_Plan().size());
//		wdComponentAPI.getMessageManager().reportSuccess("" + wdContext.nodeTab_Planning_Plan().size());
//		wdComponentAPI.getMessageManager().reportSuccess(Folder);
//		wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentContextElement().getPortal_LoginId());
		
	  }

    //@@end
  }

  //@@begin javadoc:MD_execute_MSS_Comp_Data_Download()
  /** Declared method. */
  //@@end
  public void MD_execute_MSS_Comp_Data_Download( )
  {
    //@@begin MD_execute_MSS_Comp_Data_Download()
//  wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().getI_Direct());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().getI_Report());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().getI_Userid());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().getI_Usertyp());
    
	try {
			wdContext.currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().modelObject().execute();
			wdContext.nodeOutput_Comp_Download().invalidate();
			wdContext.nodeOutput_Tab_Data().invalidate();	

//			wdComponentAPI.getMessageManager().reportSuccess("size" + wdContext.nodeOutput_Tab_Data().size());
//			for (int i=0; i< wdContext.nodeOutput_Tab_Data().size(); i++)
//				wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeOutput_Tab_Data().getOutput_Tab_DataElementAt(i).getRec());
	
		} catch (Exception e) {
			wdThis.wdGetMessageAreaInterface().DC_Get_Message("Problem in getting the Data for Excel Download: " + e.getMessage());
			//Disconnect the connection
			IncentivePlanning model = (IncentivePlanning) WDModelFactory.getModelInstance(IncentivePlanning.class);
			model.disconnectIfAlive();
		}
		//Disconnect the connection
		IncentivePlanning model = (IncentivePlanning) WDModelFactory.getModelInstance(IncentivePlanning.class);
		model.disconnectIfAlive();
    //@@end
  }

  //@@begin javadoc:MD_execute_Org_Overview()
  /** Declared method. */
  //@@end
  public void MD_execute_Org_Overview( java.lang.String OrgId, java.lang.String Plan, java.lang.String Folder, java.lang.String UserId, java.lang.String Pernr )
  {
    //@@begin MD_execute_Org_Overview()
//	Set the Ord Id Number
	  wdContext.currentY_Hrcm_Mss_Org_Overview_New_InputElement().setI_Org_Number(OrgId);	
	  //Set the Plan
	  wdContext.currentY_Hrcm_Mss_Org_Overview_New_InputElement().setI_Plan(Plan);
	  //Set folder (direct/all/matrix/deligated)
	  wdContext.currentY_Hrcm_Mss_Org_Overview_New_InputElement().setI_Fold(Folder);
	  wdContext.currentY_Hrcm_Mss_Org_Overview_New_InputElement().setI_Userid(UserId);
	  wdContext.currentY_Hrcm_Mss_Org_Overview_New_InputElement().setI_Pernr(Pernr);
	
//	wdComponentAPI.getMessageManager().reportSuccess("overview :  " + wdContext.currentY_Hrcm_Mss_Org_Overview_New_InputElement().getI_Flag());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Org_Overview_New_InputElement().getI_Fold());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Org_Overview_New_InputElement().getI_Org_Number());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Org_Overview_New_InputElement().getI_Pernr());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Org_Overview_New_InputElement().getI_Plan());
//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentY_Hrcm_Mss_Org_Overview_New_InputElement().getI_Userid());
	
	
	  //Execute the Org. OverView RFC to get the details by passing the IOrg_Number
	  try {	
		  wdContext.currentY_Hrcm_Mss_Org_Overview_New_InputElement().modelObject().execute();
		  wdContext.nodeOutput_MSS_Org_Overview().invalidate();
	  } catch (Exception e) {
			wdThis.wdGetMessageAreaInterface().DC_Get_Message("Error in retreiving 'Annual Incentive Budget': " + e.getMessage());
		  		
		  //Disconnect the connection
		  IncentivePlanning model = (IncentivePlanning) WDModelFactory.getModelInstance(IncentivePlanning.class);
		  model.disconnectIfAlive();
	  }
	  //Disconnect the connection
	  IncentivePlanning model = (IncentivePlanning) WDModelFactory.getModelInstance(IncentivePlanning.class);
	  model.disconnectIfAlive();
    //@@end
  }

  //@@begin javadoc:MD_execute_Submit_Org_Data()
  /** Declared method. */
  //@@end
  public void MD_execute_Submit_Org_Data( java.lang.String UserId )
  {
    //@@begin MD_execute_Submit_Org_Data()
//	Execute the Submit Org. RFC to Submit the Eligibility or Funding by passing the IUserId
	 try {
		 //Set the UserId
		 wdContext.currentY_Hrcm_Mss_Submit_Comp_Data_InputElement().setI_Userid(UserId);	
	
		 wdContext.currentY_Hrcm_Mss_Submit_Comp_Data_InputElement().modelObject().execute();
		 wdContext.nodeOutput_Submit_Comp_Data().invalidate();
		 wdContext.nodeE_Error().invalidate();
		//wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentE_ErrorElement().getMessage());
		 //Check for Errors, if the Error Type is E, then display the message
		 if (wdContext.currentE_ErrorElement().getType().equalsIgnoreCase("E")){
		 	//wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentE_ErrorElement().getMessage());
			wdThis.wdGetMessageAreaInterface().DC_Get_Message(wdContext.currentE_ErrorElement().getMessage());
		 }
	 } catch (Exception e) {
		wdThis.wdGetMessageAreaInterface().DC_Get_Message("Problem in Submit Eligibility/Funding: " + e.getMessage());
		
		 //Disconnect the connection
		 IncentivePlanning model = (IncentivePlanning) WDModelFactory.getModelInstance(IncentivePlanning.class);
		 model.disconnectIfAlive();
	 }
	 //Disconnect the connection
	 IncentivePlanning model = (IncentivePlanning) WDModelFactory.getModelInstance(IncentivePlanning.class);
	 model.disconnectIfAlive();
    //@@end
  }

  //@@begin javadoc:refresh_View()
  /** Declared method. */
  //@@end
  public void refresh_View( )
  {
    //@@begin refresh_View()
	wdThis.wdFireEventRefresh_Views();
    //@@end
  }

  //@@begin javadoc:checkForZeroAwardAmount()
  /** Declared method. */
  //@@end
  public void checkForZeroAwardAmount( )
  {
    //@@begin checkForZeroAwardAmount()
	for (int z=0; z < wdContext.nodeAwardConfirmationTable().size(); z++) {
		IPrivateComp_incentive_pernr_planning.IAwardConfirmationTableElement ele = wdContext.nodeAwardConfirmationTable().getAwardConfirmationTableElementAt(z);
		wdContext.nodeAwardConfirmationTable().removeElement(ele);
	}

	//Invalidate the node..
	wdContext.nodeAwardConfirmationTable().invalidate();

	wdThis.MD_execute_Check_Awd_Amt(wdContext.currentContextElement().getPortal_LoginId());

	for (int i=0; i < wdContext.nodeTab_Planning_Awd_Amt_New().size(); i++){
		if (wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(i).getYyawd_Amt().intValue() == 0  || wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(i).getYyawd_Amt_Usd().intValue() == 0) {
			if (wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(i).getYygoal_Txt().equalsIgnoreCase("Business")) {
				IPrivateComp_incentive_pernr_planning.IAwardConfirmationTableElement ele = wdContext.createAwardConfirmationTableElement();
				ele.setName(wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(i).getYyname());
				ele.setPernr(wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(i).getYypernr());
				ele.setStatus("Business Award is Zero");
				wdContext.nodeAwardConfirmationTable().addElement(ele);	
			}
			else
				if (wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(i).getYygoal_Txt().equalsIgnoreCase("Development")) {
					String name = "";
					IPrivateComp_incentive_pernr_planning.IAwardConfirmationTableElement ele = wdContext.createAwardConfirmationTableElement();
					for (int p=0; p < wdContext.nodeTab_Planning_Awd_Amt_New().size(); p++) {
						if (wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(p).getYypernr().equalsIgnoreCase(wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(i).getYypernr())) {
							name = wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(p).getYyname();
							break;
						}
					}
				
					ele.setName(name);
					ele.setPernr(wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(i).getYypernr());
					ele.setStatus("Development Award is Zero");			
					wdContext.nodeAwardConfirmationTable().addElement(ele);
				}
				else
					if (wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(i).getYygoal_Txt().equalsIgnoreCase("Additional")) {	
						IPrivateComp_incentive_pernr_planning.IAwardConfirmationTableElement ele = wdContext.createAwardConfirmationTableElement();
						String name = "";
						for (int q=0; q < wdContext.nodeTab_Planning_Awd_Amt_New().size(); q++) {
							if (wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(q).getYypernr().equalsIgnoreCase(wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(i).getYypernr())) {
								name = wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(q).getYyname();
								break;
							}
						}
				
						ele.setName(name);
						ele.setPernr(wdContext.nodeTab_Planning_Awd_Amt_New().getTab_Planning_Awd_Amt_NewElementAt(i).getYypernr());
						ele.setStatus("Additional Award is Zero");
						wdContext.nodeAwardConfirmationTable().addElement(ele);
					}					
		}
	
	}
    //@@end
  }

  //@@begin javadoc:closeAwardConfirmation()
  /** Declared method. */
  //@@end
  public void closeAwardConfirmation( )
  {
    //@@begin closeAwardConfirmation()
	if (awardConfirmation != null) {
		awardConfirmation.destroyInstance();
		awardConfirmation = null;
	}
    //@@end
  }

  //@@begin javadoc:openSurveyConfirmation()
  /** Declared method. */
  //@@end
  public void openSurveyConfirmation( java.lang.String windowName )
  {
    //@@begin openSurveyConfirmation()
	surveyConfirmation = wdComponentAPI.getWindowManager().createModalWindow(
			wdComponentAPI.getComponentInfo().findInWindows(windowName)); //"W_SurveyPopUp"));
	surveyConfirmation.setWindowPosition(WDWindowPos.CENTER);
	surveyConfirmation.show();
    //@@end
  }

  //@@begin javadoc:openAwardConfirmation()
  /** Declared method. */
  //@@end
  public void openAwardConfirmation( java.lang.String windowName )
  {
    //@@begin openAwardConfirmation()
	awardConfirmation = wdComponentAPI.getWindowManager().createModalWindow(
				wdComponentAPI.getComponentInfo().findInWindows(windowName)); 
		awardConfirmation.setWindowPosition(WDWindowPos.CENTER);
		
		awardConfirmation.show();
    //@@end
  }

  //@@begin javadoc:MD_execute_Check_Awd_Amt()
  /** Declared method. */
  //@@end
  public void MD_execute_Check_Awd_Amt( java.lang.String UserId )
  {
    //@@begin MD_execute_Check_Awd_Amt()
	try {
		//Set the UserId
		wdContext.currentY_Hrcm_Check_Awd_Amt_New_InputElement().setI_Userid(UserId);	

		wdContext.currentY_Hrcm_Check_Awd_Amt_New_InputElement().modelObject().execute();
		wdContext.nodeTab_Planning_Awd_Amt_New().invalidate();
		wdContext.nodeOutput_Check_Awd_Amt_New().invalidate();
	
	} catch (Exception e) {
		wdThis.wdGetMessageAreaInterface().DC_Get_Message("Problem in executing the Check award amount RFC: " + e.getMessage());
		
		//Disconnect the connection
		IncentivePlanning model = (IncentivePlanning) WDModelFactory.getModelInstance(IncentivePlanning.class);
		model.disconnectIfAlive();
	}
	//Disconnect the connection
	IncentivePlanning model = (IncentivePlanning) WDModelFactory.getModelInstance(IncentivePlanning.class);
	model.disconnectIfAlive();
    //@@end
  }

  //@@begin javadoc:MD_execute_Submit_Funding_Org_Data()
  /** Declared method. */
  //@@end
  public boolean MD_execute_Submit_Funding_Org_Data( java.lang.String UserId )
  {
    //@@begin MD_execute_Submit_Funding_Org_Data()
	boolean ret = true;
	try {
		//Set the UserId
		wdContext.currentY_Hrcm_Mss_Submit_Comp_Data_InputElement().setI_Userid(UserId);	

		wdContext.currentY_Hrcm_Mss_Submit_Comp_Data_InputElement().modelObject().execute();
		wdContext.nodeOutput_Submit_Comp_Data().invalidate();
		wdContext.nodeE_Error().invalidate();

		//Check for Errors, if the Error Type is E, then display the message
		if (wdContext.currentE_ErrorElement().getType().equalsIgnoreCase("E"))
		{
			ret = false;
	//		wdThis.wdGetMessageAreaInterface().DC_Get_Message(wdContext.currentE_ErrorElement().getMessage());
		}

	} catch (Exception e) {
		ret = false;
		wdThis.wdGetMessageAreaInterface().DC_Get_Message("Problem in Submit Eligibility/Funding: " + e.getMessage());
			
		//Disconnect the connection
		IncentivePlanning model = (IncentivePlanning) WDModelFactory.getModelInstance(IncentivePlanning.class);
		model.disconnectIfAlive();
	}
	//Disconnect the connection
	IncentivePlanning model = (IncentivePlanning) WDModelFactory.getModelInstance(IncentivePlanning.class);
	model.disconnectIfAlive();

	return ret;
    //@@end
  }

  //@@begin javadoc:closeSurveyConfirmation()
  /** Declared method. */
  //@@end
  public void closeSurveyConfirmation( )
  {
    //@@begin closeSurveyConfirmation()
	if (surveyConfirmation != null) {
		surveyConfirmation.destroyInstance();
		surveyConfirmation = null;
	}
    //@@end
  }

  //@@begin javadoc:RefreshTeamviewer()
  /** Declared method. */
  //@@end
  public void RefreshTeamviewer( )
  {
    //@@begin RefreshTeamviewer()
	
    wdThis.wdGetTeamViewerInterface().RefreshTeamViewer();
    //@@end
  }

  //@@begin javadoc:print_message()
  /** Declared method. */
  //@@end
  public void print_message( )
  {
    //@@begin print_message()
	wdThis.wdGetMessageAreaInterface().DC_Get_Message(wdContext.currentE_ErrorElement().getMessage());
    //@@end
  }

  //@@begin javadoc:fire_OpenSubmitEligibility(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void fire_OpenSubmitEligibility(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent, java.lang.String windowName )
  {
    //@@begin fire_OpenSubmitEligibility(ServerEvent)
	submitEligibilityConfirmation = wdComponentAPI.getWindowManager().createModalWindow(
				wdComponentAPI.getComponentInfo().findInWindows(windowName)); //"SubmitEligibilityPopUp"));
		submitEligibilityConfirmation.setWindowPosition(WDWindowPos.CENTER);
		submitEligibilityConfirmation.show();
    //@@end
  }

  //@@begin javadoc:fire_OpenSubmitFunding(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void fire_OpenSubmitFunding(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent, java.lang.String windowName )
  {
    //@@begin fire_OpenSubmitFunding(ServerEvent)
	submitFundingConfirmation = wdComponentAPI.getWindowManager().createModalWindow(
				wdComponentAPI.getComponentInfo().findInWindows(windowName)); //"SubmitFundingPopup"));
	submitFundingConfirmation.setWindowPosition(WDWindowPos.CENTER);
	submitFundingConfirmation.show();
    //@@end
  }

  //@@begin javadoc:fire_mss_plan_table(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void fire_mss_plan_table(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent, java.lang.String OrgId, java.lang.String Action, java.lang.String Plan, java.lang.String Folder, java.lang.String UserId, java.lang.String UserType, java.lang.String TextOfSelectedOrg )
  {
    //@@begin fire_mss_plan_table(ServerEvent)
    wdContext.currentContextElement().setOrgId(OrgId);
	wdContext.currentContextElement().setAction(Action); 
	wdContext.currentContextElement().setPlan(Plan);
	wdContext.currentContextElement().setFolder(Folder);
	wdContext.currentContextElement().setPortal_LoginId(UserId);
	wdContext.currentContextElement().setUserType(UserType);

	this.refresh_View();
    //@@end
  }

  //@@begin javadoc:GetUserInfo(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void GetUserInfo(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent, java.lang.String UserId, java.lang.String UserType )
  {
    //@@begin GetUserInfo(ServerEvent)
    wdContext.currentContextElement().setPortal_LoginId(UserId);
    wdContext.currentContextElement().setUserType(UserType);
    //@@end
  }

  /*
   * The following code section can be used for any Java code that is 
   * not to be visible to other controllers/views or that contains constructs
   * currently not supported directly by Web Dynpro (such as inner classes or
   * member variables etc.). </p>
   *
   * Note: The content of this section is in no way managed/controlled
   * by the Web Dynpro Designtime or the Web Dynpro Runtime. 
   */
  //@@begin others
  private IWDWindow submitEligibilityConfirmation;
  private IWDWindow submitFundingConfirmation;
  private IWDWindow awardConfirmation;
  private IWDWindow surveyConfirmation;
  //@@end
}

// ---- content of obsolete user coding area(s) ----
//@@begin obsolete:initialisePlanningTable(ServerEvent)
//    wdDoInit();
//@@end
//@@begin obsolete:javadoc:initialisePlanningTable(ServerEvent)
//  /** Declared validating event handler. */
//@@end
