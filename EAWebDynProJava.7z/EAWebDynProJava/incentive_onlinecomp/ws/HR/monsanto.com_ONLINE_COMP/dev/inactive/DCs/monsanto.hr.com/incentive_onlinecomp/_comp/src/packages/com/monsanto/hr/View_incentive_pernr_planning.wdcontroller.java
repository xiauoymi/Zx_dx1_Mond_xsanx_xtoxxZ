// ---------------------------------------------------------------------------
// This file has been generated partially by the Web Dynpro Code Generator.
// MODIFY CODE ONLY IN SECTIONS ENCLOSED BY @@begin AND @@end.
// ALL OTHER CHANGES WILL BE LOST IF THE FILE IS REGENERATED.
// ---------------------------------------------------------------------------
package com.monsanto.hr;

// 
// IMPORTANT NOTE: 
// _ALL_ IMPORT STATEMENTS MUST BE PLACED IN THE FOLLOWING SECTION ENCLOSED
// BY @@begin imports AND @@end. FURTHERMORE, THIS SECTION MUST ALWAYS CONTAIN
// AT LEAST ONE IMPORT STATEMENT (E.G. THAT FOR IPrivateView_incentive_pernr_planning).
// OTHERWISE, USING THE ECLIPSE FUNCTION "Organize Imports" FOLLOWED BY
// A WEB DYNPRO CODE GENERATION (E.G. PROJECT BUILD) WILL RESULT IN THE LOSS
// OF IMPORT STATEMENTS.
//
//@@begin imports
import com.monsanto.hr.wdp.IPrivateView_incentive_pernr_planning;
import com.sap.dictionary.runtime.ISimpleTypeModifiable;
import com.sap.tc.webdynpro.clientserver.uielib.standard.api.WDTableSelectionMode;
import com.sap.tc.webdynpro.clientserver.uielib.standard.api.WDTextViewDesign;
import com.sap.tc.webdynpro.clientserver.uielib.standard.api.WDTextViewSemanticColor;
import com.sap.tc.webdynpro.progmodel.api.IWDAttributeInfo;
import com.sap.tc.webdynpro.progmodel.api.WDVisibility;
import com.sap.typeservices.IModifiableSimpleValueSet;
//@@end

//@@begin documentation
//@@end

public class View_incentive_pernr_planning
{
  /**
   * Logging location.
   */
  private static final com.sap.tc.logging.Location logger = 
    com.sap.tc.logging.Location.getLocation(View_incentive_pernr_planning.class);

  static 
  {
    //@@begin id
    String id = "$Id$";
    //@@end
    com.sap.tc.logging.Location.getLocation("ID.com.sap.tc.webdynpro").infoT(id);
  }

  /**
   * Private access to the generated Web Dynpro counterpart 
   * for this controller class.  </p>
   *
   * Use <code>wdThis</code> to gain typed access to the context,
   * to trigger navigation via outbound plugs, to get and enable/disable
   * actions, fire declared events, and access used controllers and/or 
   * component usages.
   *
   * @see com.monsanto.hr.wdp.IPrivateView_incentive_pernr_planning for more details
   */
  private final IPrivateView_incentive_pernr_planning wdThis;

  /**
   * Root node of this controller's context. </p>
   *
   * Provides typed access not only to the elements of the root node 
   * but also to all nodes in the context (methods node<i>XYZ</i>()) 
   * and their currently selected element (methods current<i>XYZ</i>Element()). 
   * It also facilitates the creation of new elements for all nodes 
   * (methods create<i>XYZ</i>Element()). </p>
   *
   * @see com.monsanto.hr.wdp.IPrivateView_incentive_pernr_planning.IContextNode for more details.
   */
  private final IPrivateView_incentive_pernr_planning.IContextNode wdContext;

  /**
   * A shortcut for <code>wdThis.wdGetAPI()</code>. </p>
   * 
   * Represents the generic API of the generic Web Dynpro counterpart 
   * for this controller. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDViewController wdControllerAPI;
  
  /**
   * A shortcut for <code>wdThis.wdGetAPI().getComponent()</code>. </p>
   * 
   * Represents the generic API of the Web Dynpro component this controller 
   * belongs to. Can be used to access the message manager, the window manager,
   * to add/remove event handlers and so on. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdComponentAPI;
  
  public View_incentive_pernr_planning(IPrivateView_incentive_pernr_planning wdThis)
  {
    this.wdThis = wdThis;
    this.wdContext = wdThis.wdGetContext();
    this.wdControllerAPI = wdThis.wdGetAPI();
    this.wdComponentAPI = wdThis.wdGetAPI().getComponent();
  }

  //@@begin javadoc:wdDoInit()
  /** Hook method called to initialize controller. */
  //@@end
  public void wdDoInit()
  {
    //@@begin wdDoInit()
	wdContext.currentContextElement().setVisible_EmpPlanningTable(WDVisibility.NONE);
	wdContext.currentContextElement().setPernr_From_Namesearch("");
	wdContext.currentContextElement().setTableSelectionMode(WDTableSelectionMode.NONE);
    
    wdContext.currentContextElement().setReports("Select Report");
    wdContext.currentContextElement().setVisible_Reports(WDVisibility.NONE);
    
	// Drop down for reports   
	IWDAttributeInfo attributeInfo = this.wdContext.getNodeInfo().getAttribute("Reports");
	ISimpleTypeModifiable plansType = attributeInfo.getModifiableSimpleType();
	IModifiableSimpleValueSet valueSet = plansType.getSVServices().getModifiableSimpleValueSet();
	valueSet.clear();
	valueSet.put("E", "Eligibility");
	valueSet.put("G", "Awards by Goal");
	valueSet.put("T", "Award Total");	
	
    //@@end
  }

  //@@begin javadoc:wdDoExit()
  /** Hook method called to clean up controller. */
  //@@end
  public void wdDoExit()
  {
    //@@begin wdDoExit()
    //@@end
  }

  //@@begin javadoc:wdDoModifyView
  /**
   * Hook method called to modify a view just before rendering.
   * This method conceptually belongs to the view itself, not to the
   * controller (cf. MVC pattern).
   * It is made static to discourage a way of programming that
   * routinely stores references to UI elements in instance fields
   * for access by the view controller's event handlers, and so on.
   * The Web Dynpro programming model recommends that UI elements can
   * only be accessed by code executed within the call to this hook method.
   *
   * @param wdThis Generated private interface of the view's controller, as
   *        provided by Web Dynpro. Provides access to the view controller's
   *        outgoing controller usages, etc.
   * @param wdContext Generated interface of the view's context, as provided
   *        by Web Dynpro. Provides access to the view's data.
   * @param view The view's generic API, as provided by Web Dynpro.
   *        Provides access to UI elements.
   * @param firstTime Indicates whether the hook is called for the first time
   *        during the lifetime of the view.
   */
  //@@end
  public static void wdDoModifyView(IPrivateView_incentive_pernr_planning wdThis, IPrivateView_incentive_pernr_planning.IContextNode wdContext, com.sap.tc.webdynpro.progmodel.api.IWDView view, boolean firstTime)
  {
    //@@begin wdDoModifyView
    //@@end
  }

  //@@begin javadoc:updateMSSPlanningInputTable()
  /** Declared method. */
  //@@end
  public void updateMSSPlanningInputTable( )
  {
    //@@begin updateMSSPlanningInputTable()
	Y_Hrcm_Mss_Pernr_Plan_Elig_Input pernrInput = new Y_Hrcm_Mss_Pernr_Plan_Elig_Input();
	
	// Delete the Input Table rows - Planning Table
	for(int i = wdContext.nodeTab_Planning_Input().size() - 1; i >= 0; i--) {
		wdContext.nodeTab_Planning_Input().removeElement(wdContext.nodeTab_Planning_Input().getElementAt(i));
		wdContext.nodeTab_Planning_Input().invalidate();
	}	
	// Delete the Input Table rows - Eligibility Table
	for(int i = wdContext.nodeTab_Eligibility_Input().size() - 1; i >= 0; i--) {
		wdContext.nodeTab_Eligibility_Input().removeElement(wdContext.nodeTab_Eligibility_Input().getElementAt(i));
		wdContext.nodeTab_Eligibility_Input().invalidate();
	}	

	for (int i=0; i< wdContext.nodeTab_Planning_Plan().size(); i++){
		Yhrcm_Pernr_Plng mktAttri = new Yhrcm_Pernr_Plng();
		// Get the reference
		IPrivateView_incentive_pernr_planning.ITab_Planning_PlanElement mssPlan = wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(i);
		//Get the values
		
		mktAttri.setYyplan(mssPlan.getYyplan());
		mktAttri.setYyname(mssPlan.getYyname());
		mktAttri.setYypernr(mssPlan.getYypernr());
		mktAttri.setYygoal_Pct(mssPlan.getYygoal_Pct());
		mktAttri.setYygoal_Txt(mssPlan.getYygoal_Txt());
		mktAttri.setYyelig_Mos(mssPlan.getYyelig_Mos());
		mktAttri.setYycurr(mssPlan.getYycurr());
		mktAttri.setYyawd_Amt(mssPlan.getYyawd_Amt());
		mktAttri.setYyawd_Amt_Usd(mssPlan.getYyawd_Amt_Usd());
		mktAttri.setYyfnd_Amt(mssPlan.getYyfnd_Amt());
		mktAttri.setYyfnd_Amt_Usd(mssPlan.getYyfnd_Amt_Usd());
		mktAttri.setYyfnd_Pct(mssPlan.getYyfnd_Pct());
		mktAttri.setYytgt_Amt(mssPlan.getYytgt_Amt());
		mktAttri.setYytgt_Amt_Usd(mssPlan.getYytgt_Amt_Usd());
		mktAttri.setYytgt_Pct(mssPlan.getYytgt_Pct());
		mktAttri.setYyelig_Lgart(mssPlan.getYyelig_Lgart());
		mktAttri.setYyoppcd(mssPlan.getYyoppcd());
		mktAttri.setYyperfrating(mssPlan.getYyperfrating());
		mktAttri.setYyurl(mssPlan.getYyurl());

		// Add the row into the input table in the model
		wdThis.wdGetComp_incentive_pernr_planningController().wdGetContext().currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().modelObject().addTab_Planning(mktAttri);
	}
	
	// Move the rows from output eligibility table to input to save the update values
	for (int i=0; i< wdContext.nodeTab_Eligibility_Plan().size(); i++){
		Yhrcm_Pernr_Elig mktAttri1 = new Yhrcm_Pernr_Elig();
		// Get the reference
		IPrivateView_incentive_pernr_planning.ITab_Eligibility_PlanElement mssElig = wdContext.nodeTab_Eligibility_Plan().getTab_Eligibility_PlanElementAt(i);
		//Get the values
		mktAttri1.setYycurr(mssElig.getYycurr());
		mktAttri1.setYyelig_L(mssElig.getYyelig_L());
		mktAttri1.setYyelig_Mos(mssElig.getYyelig_Mos());
		mktAttri1.setYyelig_Us(mssElig.getYyelig_Us());
		mktAttri1.setYygoals(mssElig.getYygoals());
		mktAttri1.setYyname(mssElig.getYyname());
		mktAttri1.setYyoppcode(mssElig.getYyoppcode());
		mktAttri1.setYypernr(mssElig.getYypernr());
		mktAttri1.setYyplans(mssElig.getYyplans());
		mktAttri1.setYyposdes(mssElig.getYyposdes());
		mktAttri1.setYytgtper(mssElig.getYytgtper());
		mktAttri1.setYytgtval(mssElig.getYytgtval());
	
		// Add the row into the input table in the model
		wdThis.wdGetComp_incentive_pernr_planningController().wdGetContext().currentY_Hrcm_Mss_Pernr_Plan_Elig_InputElement().modelObject().addTab_Eligibility(mktAttri1);
	}

	// Invalidate the Input Table
	wdThis.wdGetComp_incentive_pernr_planningController().wdGetContext().nodeTab_Planning_Input().invalidate();
	wdThis.wdGetComp_incentive_pernr_planningController().wdGetContext().nodeTab_Eligibility_Input().invalidate();
    //@@end
  }

  //@@begin javadoc:supplyTotal_InpFields(IWDNode,IWDNodeElement)
  /** 
   * Declared supply function for IPrivateView_incentive_pernr_planning.ITotal_InpFieldsNode. 
   * This method is called when the node is invalid and the collection is 
   * requested. This may occur during any phase, even at the beginning to 
   * initialize the node. The method is expected to fill the node 
   * collection using IWDNode.bind(Collection) or 
   * IWDNode.addElement(IWDNodeElement).
   *
   * @param node the node that is to be filled
   * @param parentElement The element that this node is a child of. May be
   *        <code>null</code> if there is none.
   * @see com.sap.tc.webdynpro.progmodel.api.IWDNode#bind(Collection)
   * @see com.sap.tc.webdynpro.progmodel.api.IWDNode#bind(IWDNodeElement)
   */
  //@@end
  public void supplyTotal_InpFields(IPrivateView_incentive_pernr_planning.ITotal_InpFieldsNode node, IPrivateView_incentive_pernr_planning.ITab_Planning_PlanElement parentElement)
  {
    //@@begin supplyTotal_InpFields(IWDNode,IWDNodeElement)
	IPrivateView_incentive_pernr_planning.ITotal_InpFieldsElement element = node.createTotal_InpFieldsElement();
	node.bind(element);

	// For user type 'G' - Generalist and 'R' - Reward Group	
	if (wdContext.currentContextElement().getUserType().equalsIgnoreCase("G") || wdContext.currentContextElement().getUserType().equalsIgnoreCase("R")) {
		if (wdContext.currentContextElement().getSelected_SubmitStatus().equalsIgnoreCase("A")) {// After approved no one can change (input boxes are closed)
			node.currentTotal_InpFieldsElement().setVisible_InpFields(true); // read only (close)
			node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.STANDARD); //Black Color
			node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.STANDARD); 
		}
		else { // not approved
			if (parentElement.getYygoal_Txt().equalsIgnoreCase("Total")) {
				node.currentTotal_InpFieldsElement().setVisible_InpFields(true); //close
				node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.HEADER3);
				node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.NEGATIVE);
			}
			else 
				if (parentElement.getYytgt_Amt().toString().equalsIgnoreCase("0")) { 
					node.currentTotal_InpFieldsElement().setVisible_InpFields(true); //close
					node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.STANDARD);
					node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.STANDARD);
				}
				else {
					node.currentTotal_InpFieldsElement().setVisible_InpFields(false); //open
					node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.STANDARD);
					node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.STANDARD);
				}
		}
	}
	else 
		if (wdContext.currentContextElement().getUserType().equalsIgnoreCase("P")) { //Planning Manager
			//wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentContextElement().getSelected_SubmitStatus());
			if ( wdContext.currentContextElement().getSelected_SubmitStatus().equalsIgnoreCase("A") || wdContext.currentContextElement().getSelected_SubmitStatus().equalsIgnoreCase("S") ){
				node.currentTotal_InpFieldsElement().setVisible_InpFields(true); // read only (close)
				node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.STANDARD); //Black Color
				node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.STANDARD); 
			}
			else { //if not submitted or approved
				if (parentElement.getYygoal_Txt().equalsIgnoreCase("Total")) {
					node.currentTotal_InpFieldsElement().setVisible_InpFields(true); //close
					node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.HEADER3);
					node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.NEGATIVE);
				}
				else 
					if (parentElement.getYytgt_Amt().toString().equalsIgnoreCase("0")) { 
						node.currentTotal_InpFieldsElement().setVisible_InpFields(true); //close
						node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.STANDARD);
						node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.STANDARD);
					}
					else {
						node.currentTotal_InpFieldsElement().setVisible_InpFields(false); //open
						node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.STANDARD);
						node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.STANDARD);
					}
//												else 
//													node.currentTotal_InpFieldsElement().setVisible_InpFields(false); //open
//						//					//node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.STANDARD);
//						//					//node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.STANDARD);
//						//					}
			}
//					if (wdContext.currentContextElement().getMasterEditData() == true) { // if the top org is not submitted or approved, the subordinated can be changed. input boxes are open.
//		 		
//		 		
//						String design;
//			 		
//			 		
//						try { 
//							design = wdContext.currentContextElement().getDesign();
//							if (design.equalsIgnoreCase("")) 
//								design = "";
//						
//						}
//						catch (NullPointerException e){
//							//wdContext.currentContextElement().setDesign("EMPHASIZED");
//							design = "EMPHASIZED";
//							//wdComponentAPI.getMessageManager().reportSuccess(design);
//						}
//			 		
//					
//			 		
//						if (design.equalsIgnoreCase("EMPHASIZED")){
//					
//							node.currentTotal_InpFieldsElement().setVisible_InpFields(true); // close
//					
//					
//						}
//						else 
//							{
//						
//				//			node.currentTotal_InpFieldsElement().setVisible_InpFields(false); // open
//							if (parentElement.getYygoal_Txt().equalsIgnoreCase("Total"))
//								node.currentTotal_InpFieldsElement().setVisible_InpFields(true);
//							else 
//								if (parentElement.getYytgt_Amt().toString().equalsIgnoreCase("0")) 
//									node.currentTotal_InpFieldsElement().setVisible_InpFields(true);
//		//					//						node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.STANDARD);
//		//					//						node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.STANDARD);
//								else 
//									node.currentTotal_InpFieldsElement().setVisible_InpFields(false); //open
//		//					//node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.STANDARD);
//		//					//node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.STANDARD);
//		//					}
//						}
//					}
//				else // the top org is submitted or approved, everything should be closed 
//					node.currentTotal_InpFieldsElement().setVisible_InpFields(true); // closed
//			}
//			else
//				if (parentElement.getYygoal_Txt().equalsIgnoreCase("Total")) {
//					node.currentTotal_InpFieldsElement().setVisible_InpFields(true);
//					node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.HEADER3);
//					node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.NEGATIVE);
//				}
//				else
//					if (!parentElement.getYygoal_Txt().equalsIgnoreCase("Total") && !wdContext.currentContextElement().getEditData()) {
//						node.currentTotal_InpFieldsElement().setVisible_InpFields(true);
//						node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.STANDARD);
//						node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.STANDARD);
//					}
//					else 
//						if (parentElement.getYytgt_Amt().toString().equalsIgnoreCase("0")) {
//							node.currentTotal_InpFieldsElement().setVisible_InpFields(true);
//							node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.STANDARD);
//							node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.STANDARD);
//						}
//						else {
//							node.currentTotal_InpFieldsElement().setVisible_InpFields(false); //open
//							node.currentTotal_InpFieldsElement().setDesign_TextView(WDTextViewDesign.STANDARD);
//							node.currentTotal_InpFieldsElement().setColor_TextView(WDTextViewSemanticColor.STANDARD);
//						}
		}
    //@@end
  }

  //@@begin javadoc:refresh_mss_plan_table(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void refresh_mss_plan_table(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin refresh_mss_plan_table(ServerEvent)
	wdContext.currentContextElement().setPath("T"); // Path - "TeamViewer"
	wdThis.wdGetComp_incentive_pernr_planningController().MD_execute_Get_Planning_Employees(wdContext.currentContextElement().getOrgId(),
																					wdContext.currentContextElement().getAction(),
																					wdContext.currentContextElement().getPlan(),
																					wdContext.currentContextElement().getFolder(),
																					""
																					);
																					
	wdContext.currentContextElement().setReports("Select Report");		
	wdContext.currentContextElement().setVisible_Reports(WDVisibility.VISIBLE);																					
    
    //@@end
  }

  //@@begin javadoc:onActionExportToExcel(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionExportToExcel(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionExportToExcel(ServerEvent)
	Y_Hrcm_Mss_Comp_Download_Copy_Input pernrInput = new Y_Hrcm_Mss_Comp_Download_Copy_Input();
	
		// Delete the Input Table rows
		for(int i = wdContext.nodeInput_Tab_Planning_Comp_Download().size() - 1; i >= 0; i--) {
			wdContext.nodeInput_Tab_Planning_Comp_Download().removeElement(wdContext.nodeInput_Tab_Planning_Comp_Download().getElementAt(i));
			wdContext.nodeInput_Tab_Planning_Comp_Download().invalidate();
		}	

//		wdComponentAPI.getMessageManager().reportSuccess("input table size:  " + wdContext.nodeInput_Tab_Planning_Comp_Download().size());
		
		// Move the rows from output table to input to get the data to Export into Excel
		for (int i=0; i< wdContext.nodeTab_Planning_Plan().size(); i++){
			Yhrcm_Pernr_Plng mktAttri = new Yhrcm_Pernr_Plng();
			IPrivateView_incentive_pernr_planning.ITab_Planning_PlanElement ele = wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(i);
			//Get the values
			mktAttri.setYyawd_Amt(ele.getYyawd_Amt());
			mktAttri.setYyawd_Amt_Usd(ele.getYyawd_Amt_Usd());
			mktAttri.setYycurr(ele.getYycurr());
			mktAttri.setYyelig_Lgart(ele.getYyelig_Lgart());
			mktAttri.setYyelig_Mos(ele.getYyelig_Mos());
			mktAttri.setYyfnd_Amt(ele.getYyfnd_Amt());
			mktAttri.setYyfnd_Amt_Usd(ele.getYyfnd_Amt_Usd());
			mktAttri.setYyfnd_Pct(ele.getYyfnd_Pct());
			mktAttri.setYygoal_Pct(ele.getYygoal_Pct());
			mktAttri.setYygoal_Txt(ele.getYygoal_Txt());
			mktAttri.setYyname(ele.getYyname());
			mktAttri.setYyoppcd(ele.getYyoppcd());
			mktAttri.setYyperfrating(ele.getYyperfrating());
			mktAttri.setYypernr(ele.getYypernr());
			mktAttri.setYyplan(ele.getYyplan());
			mktAttri.setYytgt_Amt(ele.getYytgt_Amt());
			mktAttri.setYytgt_Amt_Usd(ele.getYytgt_Amt_Usd());
			mktAttri.setYytgt_Pct(ele.getYytgt_Pct());
			mktAttri.setYyurl(ele.getYyurl());
	
			// Add the row into the input table in the model
			wdThis.wdGetComp_incentive_pernr_planningController().wdGetContext().currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().modelObject().addTab_Planning(mktAttri);
		}
//	wdComponentAPI.getMessageManager().reportSuccess("input table size:  " + wdContext.nodeInput_Tab_Planning_Comp_Download().size());
		// Invalidate the Input Table
		wdThis.wdGetComp_incentive_pernr_planningController().wdGetContext().nodeInput_Tab_Planning_Comp_Download().invalidate();
//	wdComponentAPI.getMessageManager().reportSuccess("input table size:  " + wdContext.nodeInput_Tab_Planning_Comp_Download().size());
		if (wdContext.currentContextElement().getFolder().equalsIgnoreCase("00000002")) //All Employees
			wdContext.nodeY_Hrcm_Mss_Comp_Download_Copy_Input().currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().setI_Direct("A");
		else 
			if (wdContext.currentContextElement().getFolder().equalsIgnoreCase("00000001")) //Direct Employees
				wdContext.nodeY_Hrcm_Mss_Comp_Download_Copy_Input().currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().setI_Direct("D");
			else
				if (wdContext.currentContextElement().getFolder().equalsIgnoreCase("00000004")) //Direct Employees
					wdContext.nodeY_Hrcm_Mss_Comp_Download_Copy_Input().currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().setI_Direct("X"); 
				else {
					wdContext.nodeY_Hrcm_Mss_Comp_Download_Copy_Input().currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().setI_Direct("X");	 		
				//	wdComponentAPI.getMessageManager().reportSuccess(wdContext.nodeY_Hrcm_Mss_Comp_Download_Copy_Input().currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().getI_Direct());
				}
		
		wdContext.nodeY_Hrcm_Mss_Comp_Download_Copy_Input().currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().setI_Report(wdContext.currentContextElement().getReports());
		wdContext.nodeY_Hrcm_Mss_Comp_Download_Copy_Input().currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().setI_Userid(wdContext.currentContextElement().getPortal_LoginId());
		wdContext.nodeY_Hrcm_Mss_Comp_Download_Copy_Input().currentY_Hrcm_Mss_Comp_Download_Copy_InputElement().setI_Usertyp(wdContext.currentContextElement().getUserType());

		// Execute the RFC
		wdThis.wdGetComp_incentive_pernr_planningController().MD_execute_MSS_Comp_Data_Download();
	
//	wdComponentAPI.getMessageManager().reportSuccess("output table size:  " + wdContext.nodeOutput_Tab_Data().size());
		if (wdContext.nodeOutput_Tab_Data().size() > 0)
			wdThis.wdGetExportToExcelInterface().exportToExcel(wdContext.nodeOutput_Tab_Data(), wdContext.currentContextElement().getReports());		
    	else {
    		wdThis.wdGetMessageAreaInterface().DC_Get_Message("No data received for download");
			wdContext.currentContextElement().setReports("Select Report");
    	}
    //@@end
  }

  //@@begin javadoc:onActionSAVE(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSAVE(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSAVE(ServerEvent)
	int cursor=wdContext.nodeTab_Planning_Plan().getLeadSelection();
	
		boolean check = true;
	
		// Convert int to BigDecimal 
		int i = 0;
		java.math.BigDecimal bd = new java.math.BigDecimal(String.valueOf(i));
	
		int count = 0; //Total number of records which contains zero values
		for (int p=0; p < wdContext.nodeTab_Planning_Plan().size(); p++) {
			// Compare two BigDecimal Values
			if (wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(p).getYyawd_Amt().compareTo(bd) == -1 ||
				wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(p).getYyawd_Amt_Usd().compareTo(bd) == -1 ||
				wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(p).getYytgt_Pct().compareTo(bd) == -1 ||
				wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(p).getYyfnd_Pct().compareTo(bd) == -1) {
				count = p;
				check = false;
				break;
			}
		}
	
		if (check){
			// Update the Input MSS Planning Table with the new updated values
			
			this.updateMSSPlanningInputTable();
			
		
			
			// Call the Custom Controller to SAVE the update values
			if (wdContext.currentContextElement().getPath().equalsIgnoreCase("T")) {// Teamviewer 
			
				wdThis.wdGetComp_incentive_pernr_planningController().MD_execute_Get_Planning_Employees(wdContext.currentContextElement().getOrgId(), "SAVE", wdContext.currentContextElement().getPlan(), wdContext.currentContextElement().getFolder(), wdContext.currentContextElement().getPernr_From_Namesearch());
			}
			else // Namesearch	
			{
				wdComponentAPI.getMessageManager().reportSuccess(wdContext.currentOutput_MSS_PlanElement().getE_Plan());
				wdThis.wdGetComp_incentive_pernr_planningController().MD_execute_Get_Planning_Employees(wdContext.currentOutput_MSS_PlanElement().getE_Orgeh(), "SAVE", wdContext.currentOutput_MSS_PlanElement().getE_Plan(), "", wdContext.currentContextElement().getPernr_From_Namesearch());
				
				//Swap the elements, place the search element on the top of the table (both planning and eligibility)
				  int [] array_planning = new int[5]; //It may be 2, 3 or 4
				  int array_eligibility = 0; //Always one
				  int count1 = 0;   
				  for (int y=0; y < wdContext.nodeTab_Planning_Plan().size(); y++) {
					  if (wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(y).getYypernr().equalsIgnoreCase(wdContext.currentContextElement().getPernr_From_Namesearch())) {
						  array_planning[count1] = y; 
						  count1++;
					  }
				  }

				  for (int j=0; j < wdContext.nodeTab_Eligibility_Plan().size(); j++) {
					  if (wdContext.nodeTab_Eligibility_Plan().getTab_Eligibility_PlanElementAt(j).getYypernr().equalsIgnoreCase(wdContext.currentContextElement().getPernr_From_Namesearch())) 
						  array_eligibility = j;		
				  }
	
				  // Move the set of planning records to the top of the planning table	
				  for (int j=0; j<count1; j++) {
					  wdContext.nodeTab_Planning_Plan().moveElement(array_planning[j], j);
				  }
	
				  // Move the eligiblity record to the first row
				  wdContext.nodeTab_Eligibility_Plan().moveElement(array_eligibility, 0);
				  //================================================================================
			}
			
			if (wdContext.currentMessage_PlanElement().getType().equalsIgnoreCase("E")){
				
		   		wdThis.wdGetMessageAreaInterface().DC_Get_Message(wdContext.currentMessage_PlanElement().getMessage());
			}
			else {
				// Set the Table Selected Row
				wdContext.currentContextElement().setTableSelectionMode(WDTableSelectionMode.NONE);
				wdContext.nodeTab_Planning_Plan().setLeadSelection(cursor);
			}
		}
		else{
			wdThis.wdGetMessageAreaInterface().DC_Get_Message("A Negative number was entered. Only Positive numbers are acceptable.");
			wdContext.currentContextElement().setTableSelectionMode(WDTableSelectionMode.SINGLE);
			wdContext.nodeTab_Planning_Plan().setLeadSelection(count);
		}
    //@@end
  }

  //@@begin javadoc:onActionSelectSeason(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelectSeason(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelectSeason(ServerEvent)
	if (wdContext.currentContextElement().getSeason().equalsIgnoreCase("E")) {
			wdContext.currentContextElement().setVisible_EligibilityTable(WDVisibility.VISIBLE);
			wdContext.currentContextElement().setVisible_PlanningTable(WDVisibility.NONE);
			wdContext.currentContextElement().setReports("Select Report");
		}
		else {
			wdContext.currentContextElement().setVisible_EligibilityTable(WDVisibility.NONE);
			wdContext.currentContextElement().setVisible_PlanningTable(WDVisibility.VISIBLE);
			wdContext.currentContextElement().setReports("Select Report");
		}
    //@@end
  }

  //@@begin javadoc:onActionEmployeeOverview(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionEmployeeOverview(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionEmployeeOverview(ServerEvent)
    if (wdContext.currentContextElement().getSeason().equalsIgnoreCase("P")) 
    	wdThis.wdGetEmployeeOverviewInterface().openEmployeeOverview(wdContext.currentTab_Planning_PlanElement().getYypernr(), wdContext.currentTab_Planning_PlanElement().getYyplan());
    else {
  		wdThis.wdGetEmployeeOverviewInterface().openEmployeeOverview(wdContext.currentTab_Eligibility_PlanElement().getYypernr(), wdContext.currentTab_Planning_PlanElement().getYyplan());
    }
    //@@end
  }

  //@@begin javadoc:Get_NameSearchSelection(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void Get_NameSearchSelection(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent, java.lang.String Pernr )
  {
    //@@begin Get_NameSearchSelection(ServerEvent)
	wdContext.currentContextElement().setPath("N"); //Path - "Namesearch"
    wdThis.wdGetComp_incentive_pernr_planningController().MD_execute_Get_Planning_Employees("", "FETCH", "", "", Pernr);
    wdContext.currentContextElement().setPernr_From_Namesearch(Pernr);
   
	//========== Swap, place the searched record to the top of the table ==========
	int [] array_planning = new int[5]; //It may be 2, 3 or 4
	int array_eligibility = 0; //Always one
	int count = 0;   
	for (int y=0; y < wdContext.nodeTab_Planning_Plan().size(); y++) {
		if (wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(y).getYypernr().equalsIgnoreCase(Pernr)) {
			array_planning[count] = y; 
			count++;
		}
	}

	for (int j=0; j < wdContext.nodeTab_Eligibility_Plan().size(); j++) {
		if (wdContext.nodeTab_Eligibility_Plan().getTab_Eligibility_PlanElementAt(j).getYypernr().equalsIgnoreCase(Pernr)) 
			array_eligibility = j;		
	}
	
	// Move the set of planning records to the top of the planning table	
	for (int j=0; j<count; j++) {
		wdContext.nodeTab_Planning_Plan().moveElement(array_planning[j], j);
	}
	
	// Move the eligiblity record to the first row
	wdContext.nodeTab_Eligibility_Plan().moveElement(array_eligibility, 0);
	//================================================================================

//		
//	int index = 0;
//    for (int x =0; x < wdContext.nodeTab_Planning_Plan().size(); x++) {
//    	if (wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(x).getYypernr().equalsIgnoreCase(Pernr)) {
//    		wdComponentAPI.getMessageManager().reportSuccess("" + x);
//    		wdContext.nodeTab_Planning_Plan().swapElements(x, index);
//    		
////    		wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(x).setYypernr(wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(index).getYypernr());
////    		wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(index).setYypernr(wdContext.nodeTab_Planning_Plan().getTab_Planning_PlanElementAt(x).getYypernr());
//    		index++;
//    	}
//    }
    
    wdContext.currentContextElement().setVisible_Reports(WDVisibility.VISIBLE);
    wdThis.wdGetComp_incentive_pernr_planningController().MD_execute_Org_Overview(wdContext.currentOutput_MSS_PlanElement().getE_Orgeh(), wdContext.currentOutput_MSS_PlanElement().getE_Plan(), "", wdContext.currentContextElement().getPortal_LoginId(), Pernr);
    //@@end
  }

  //@@begin javadoc:clearDownloadText(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void clearDownloadText(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin clearDownloadText(ServerEvent)
	wdContext.currentContextElement().setReports("Select Report");
    //@@end
  }

  /*
   * The following code section can be used for any Java code that is 
   * not to be visible to other controllers/views or that contains constructs
   * currently not supported directly by Web Dynpro (such as inner classes or
   * member variables etc.). </p>
   *
   * Note: The content of this section is in no way managed/controlled
   * by the Web Dynpro Designtime or the Web Dynpro Runtime. 
   */
  //@@begin others
  //@@end
}
