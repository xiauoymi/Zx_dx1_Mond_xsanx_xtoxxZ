// ---------------------------------------------------------------------------
// This file has been generated partially by the Web Dynpro Code Generator.
// MODIFY CODE ONLY IN SECTIONS ENCLOSED BY @@begin AND @@end.
// ALL OTHER CHANGES WILL BE LOST IF THE FILE IS REGENERATED.
// ---------------------------------------------------------------------------
package com.monsanto.xrpm;

// 
// IMPORTANT NOTE: 
// _ALL_ IMPORT STATEMENTS MUST BE PLACED IN THE FOLLOWING SECTION ENCLOSED
// BY @@begin imports AND @@end. FURTHERMORE, THIS SECTION MUST ALWAYS CONTAIN
// AT LEAST ONE IMPORT STATEMENT (E.G. THAT FOR IPrivateComp_schedule_variance_rep).
// OTHERWISE, USING THE ECLIPSE FUNCTION "Organize Imports" FOLLOWED BY
// A WEB DYNPRO CODE GENERATION (E.G. PROJECT BUILD) WILL RESULT IN THE LOSS
// OF IMPORT STATEMENTS.
//
//@@begin imports
import java.util.Comparator;

import com.monsanto.xrpm.model.ScheduleVarianceReport;
import com.monsanto.xrpm.model.Y_Xrpm_Search_Help_Input;
import com.monsanto.xrpm.wdp.IPrivateComp_schedule_variance_rep;
import com.monsanto.xrpm.wdp.IPublicComp_schedule_variance_rep;
import com.sap.dictionary.runtime.ISimpleTypeModifiable;
import com.sap.tc.webdynpro.progmodel.api.IWDAttributeInfo;
import com.sap.tc.webdynpro.progmodel.model.api.WDModelFactory;
import com.sap.typeservices.IModifiableSimpleValueSet;
//@@end

//@@begin documentation
//@@end

public class Comp_schedule_variance_rep
{
  /**
   * Logging location.
   */
  private static final com.sap.tc.logging.Location logger = 
    com.sap.tc.logging.Location.getLocation(Comp_schedule_variance_rep.class);

  static 
  {
    //@@begin id
    String id = "$Id$";
    //@@end
    com.sap.tc.logging.Location.getLocation("ID.com.sap.tc.webdynpro").infoT(id);
  }

  /**
   * Private access to the generated Web Dynpro counterpart 
   * for this controller class.  </p>
   *
   * Use <code>wdThis</code> to gain typed access to the context,
   * to trigger navigation via outbound plugs, to get and enable/disable
   * actions, fire declared events, and access used controllers and/or 
   * component usages.
   *
   * @see com.monsanto.xrpm.wdp.IPrivateComp_schedule_variance_rep for more details
   */
  private final IPrivateComp_schedule_variance_rep wdThis;

  /**
   * Root node of this controller's context. </p>
   *
   * Provides typed access not only to the elements of the root node 
   * but also to all nodes in the context (methods node<i>XYZ</i>()) 
   * and their currently selected element (methods current<i>XYZ</i>Element()). 
   * It also facilitates the creation of new elements for all nodes 
   * (methods create<i>XYZ</i>Element()). </p>
   *
   * @see com.monsanto.xrpm.wdp.IPrivateComp_schedule_variance_rep.IContextNode for more details.
   */
  private final IPrivateComp_schedule_variance_rep.IContextNode wdContext;

  /**
   * A shortcut for <code>wdThis.wdGetAPI()</code>. </p>
   * 
   * Represents the generic API of the generic Web Dynpro counterpart 
   * for this controller. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdControllerAPI;
  
  /**
   * A shortcut for <code>wdThis.wdGetAPI().getComponent()</code>. </p>
   * 
   * Represents the generic API of the Web Dynpro component this controller 
   * belongs to. Can be used to access the message manager, the window manager,
   * to add/remove event handlers and so on. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdComponentAPI;
  
  public Comp_schedule_variance_rep(IPrivateComp_schedule_variance_rep wdThis)
  {
    this.wdThis = wdThis;
    this.wdContext = wdThis.wdGetContext();
    this.wdControllerAPI = wdThis.wdGetAPI();
    this.wdComponentAPI = wdThis.wdGetAPI().getComponent();
  }

  //@@begin javadoc:wdDoInit()
  /** Hook method called to initialize controller. */
  //@@end
  public void wdDoInit()
  {
    //@@begin wdDoInit()
    Y_Xrpm_Search_Help_Input input = new Y_Xrpm_Search_Help_Input();
    wdContext.nodeY_Xrpm_Search_Help_Input().bind(input);
    
    //execute the RFC
    wdThis.MD_execute_f4_help_rfc();
    
	//Sort table elements
	IPublicComp_schedule_variance_rep.IHelp_TabNode node = wdContext.nodeHelp_Tab();
	node.sortElements
	(
	  new Comparator()
	  {
		public int compare(Object x, Object y)
		{
		  /* passed values are of type I<Node>Element */
		  String ax = ((IPublicComp_schedule_variance_rep.IHelp_TabElement) x).getYyfield1();
		  String ay = ((IPublicComp_schedule_variance_rep.IHelp_TabElement) y).getYyfield1();
		  if (ax == null)
		  {
			return ay == null ? 0 : 1;
		  }
		  return ax.compareTo(ay);
		}
	  }
	);
    
	//Drop down for project No 1
	IWDAttributeInfo attributeInfo1 = this.wdContext.getNodeInfo().getAttribute("projectNumber1");
	ISimpleTypeModifiable plansType1 = attributeInfo1.getModifiableSimpleType();
	IModifiableSimpleValueSet valueSet1 = plansType1.getSVServices().getModifiableSimpleValueSet();
	valueSet1.clear();
		
	for (int n=0; n < wdContext.nodeHelp_Tab().size(); n++) {
		valueSet1.put(wdContext.nodeHelp_Tab().getHelp_TabElementAt(n).getYyfield1(), wdContext.nodeHelp_Tab().getHelp_TabElementAt(n).getYyfield1());
	}
	
	if (wdContext.nodeHelp_Tab().size() > 0)
		wdContext.currentContextElement().setProjectNumber1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(0).getYyfield1());
	else 
		wdContext.currentContextElement().setProjectNumber1("");
	
	//Drop down for project No 2
	IWDAttributeInfo attributeInfo2 = this.wdContext.getNodeInfo().getAttribute("projectNumber2");
	ISimpleTypeModifiable plansType2 = attributeInfo2.getModifiableSimpleType();
	IModifiableSimpleValueSet valueSet2 = plansType2.getSVServices().getModifiableSimpleValueSet();
	valueSet2.clear();
	
	for (int n=0; n < wdContext.nodeHelp_Tab().size(); n++) {
		valueSet2.put(wdContext.nodeHelp_Tab().getHelp_TabElementAt(n).getYyfield1(), wdContext.nodeHelp_Tab().getHelp_TabElementAt(n).getYyfield1());
	}
	
	if (wdContext.nodeHelp_Tab().size() > 0)
		wdContext.currentContextElement().setProjectNumber2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(0).getYyfield1());
	else 
		wdContext.currentContextElement().setProjectNumber2("");
	
	
	//Drop down for project version 1
	IWDAttributeInfo attributeInfo3 = this.wdContext.getNodeInfo().getAttribute("projectVersion1");
	ISimpleTypeModifiable plansType3 = attributeInfo3.getModifiableSimpleType();
	valueSet3 = plansType3.getSVServices().getModifiableSimpleValueSet();
	valueSet3.clear();

	for (int b=0; b < wdContext.nodeHelp_Tab().size(); b++) {
		if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYyfield1().equalsIgnoreCase(wdContext.nodeHelp_Tab().getHelp_TabElementAt(0).getYyfield1())) {
		//if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYyfield1().equalsIgnoreCase("AR500548_SM")) {
			valueSet3.put(wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYyfield2(), wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYyfield2());
		}
	}
	
	if (valueSet3.size() == 1)
		if (valueSet3.getText(0).equalsIgnoreCase(""))
			wdContext.currentContextElement().setProjectVersion1Width("40px");
		else 
			wdContext.currentContextElement().setProjectVersion1Width("");
	else 
		wdContext.currentContextElement().setProjectVersion1Width("");
			
	//Drop down for project version 2
	IWDAttributeInfo attributeInfo4 = this.wdContext.getNodeInfo().getAttribute("projectVersion2");
	ISimpleTypeModifiable plansType4 = attributeInfo4.getModifiableSimpleType();
	valueSet4 = plansType4.getSVServices().getModifiableSimpleValueSet();
	valueSet4.clear();

	for (int c=0; c < wdContext.nodeHelp_Tab().size(); c++) {
		if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(c).getYyfield1().equalsIgnoreCase(wdContext.nodeHelp_Tab().getHelp_TabElementAt(0).getYyfield1())) {
		//if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYyfield1().equalsIgnoreCase("AR500548_SM")) {
			valueSet4.put(wdContext.nodeHelp_Tab().getHelp_TabElementAt(c).getYyfield2(), wdContext.nodeHelp_Tab().getHelp_TabElementAt(c).getYyfield2());
		}
	}
	
	if (valueSet4.size() == 1)
		if (valueSet4.getText(0).equalsIgnoreCase(""))
			wdContext.currentContextElement().setProjectVersion2Width("40px");
		else 
			wdContext.currentContextElement().setProjectVersion2Width("");	
	else 
		wdContext.currentContextElement().setProjectVersion2Width("");		
	
	//RadioGroupButton
	String [] display = {"All", "Changes Only"};
	for (int i=0; i < display.length; i++) {
		IPublicComp_schedule_variance_rep.IDisplayOptionElement ele = wdContext.createDisplayOptionElement();
		ele.setDisplay(display[i]);
		wdContext.nodeDisplayOption().addElement(ele);
	}
    //@@end
  }

  //@@begin javadoc:wdDoExit()
  /** Hook method called to clean up controller. */
  //@@end
  public void wdDoExit()
  {
    //@@begin wdDoExit()
    //@@end
  }

  //@@begin javadoc:wdDoPostProcessing()
  /**
   * Hook called to handle data retrieval errors before rendering.
   *
   * After doModifyView(), the Web Dynpro Framework gets all context data needed
   * for rendering by validating the contexts (which in turn calls the supply
   * functions and supplying relation roles). In this hook, the application
   * should handle the errors which occurred during validation of the contexts.
   * 
   * Using preorder depth-first traversal, this hook is called for all component
   * controllers starting with the current root component.
   *
   * Permitted operations:
   * - Flushing model queue
   * - Creating messages
   * - Reading context and model data
   *
   * Forbidden operations: 
   * - Invalidating model data
   * - Manipulating the context
   * - Firing outbound plugs
   * - Creating components
   * - ...   
   *
   * @param isCurrentRoot true if this is the root of the current request
   */
  //@@end
  public void wdDoPostProcessing(boolean isCurrentRoot)
  {
    //@@begin wdDoPostProcessing()
    //@@end
  }

  //@@begin javadoc:wdDoBeforeNavigation()
  /**
   * Hook before the navigation phase starts.
   *
   * This hook allows you to flush the model queue and handle any
   * errors that occur. Firing outbound plugs is allowed in this hook.
   *
   * Using preorder depth-first traversal, this hook is called for all component
   * controllers starting with the current root component.
   *
   * @param isCurrentRoot true if this is the root of the current request
   */
  //@@end
  public void wdDoBeforeNavigation(boolean isCurrentRoot)
  {
    //@@begin wdDoBeforeNavigation()
    //@@end
  }
  
  //@@begin javadoc:wdDoApplicationStateChange()
  /**
   * Hook that informs the application about a state change.
   * <p>
   * This hook is called e.g. to tell the application that will be
   * <ul>
   *  <li>left via a suspend plug and therefore should go into a suspend/sleep
   *      mode with minimal need of resources. errors that occur. Firing 
   *      outbound plugs is allowed in this hook.
   *  <li>left due to a timeout and could write it's state to a data base if the 
   *      user comes back later on
   * </ul>
   *
   * The concrete reason is available via IWDApplicationStateChangeInfo
   * <p>
   * <b>Important</b>: This hook is called for the top level component only!
   *
   * @param stateChangeInfo contains the information about the nature of the state change
   * @param stateChangeReturn allows the application to ask for a different state change. 
   *        The framework is allowed to ignore it considering i.e. the current resources situation.
   */
  //@@end
  public void wdDoApplicationStateChange(com.sap.tc.webdynpro.progmodel.api.IWDApplicationStateChangeInfo stateChangeInfo, com.sap.tc.webdynpro.progmodel.api.IWDApplicationStateChangeReturn stateChangeReturn)
  {
    //@@begin wdDoApplicationStateChange()
    //@@end
  }

  //@@begin javadoc:MD_execute_f4_help_rfc()
  /** Declared method. */
  //@@end
  public void MD_execute_f4_help_rfc( )
  {
    //@@begin MD_execute_f4_help_rfc()
	wdContext.currentY_Xrpm_Search_Help_InputElement().setS_Help("PN");
	wdContext.currentY_Xrpm_Search_Help_InputElement().setField1("");
	wdContext.currentY_Xrpm_Search_Help_InputElement().setField2("");

	//Execute the RFC
	try {
		wdContext.currentY_Xrpm_Search_Help_InputElement().modelObject().execute();
		wdContext.nodeHelp_Tab().invalidate();
		wdContext.nodeOutput_Help_Tab().invalidate();
	}
	catch (Exception e) {
		wdComponentAPI.getMessageManager().reportException("Error in executing f4 RFC: " + e.getMessage(), true);
	   
	   	//Disconnect the connection
		ScheduleVarianceReport model = (ScheduleVarianceReport) WDModelFactory.getModelInstance(ScheduleVarianceReport.class);
		model.disconnectIfAlive();
	}
	//Disconnect the connection
	ScheduleVarianceReport model = (ScheduleVarianceReport) WDModelFactory.getModelInstance(ScheduleVarianceReport.class);
	model.disconnectIfAlive();
    //@@end
  }

  //@@begin javadoc:select_project1()
  /** Declared method. */
  //@@end
  public void select_project1( )
  {
    //@@begin select_project1()
	valueSet3.clear();
	for (int b=0; b < wdContext.nodeHelp_Tab().size(); b++) {
		if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYyfield1().equalsIgnoreCase(wdContext.currentContextElement().getProjectNumber1())) {
		//if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYyfield1().equalsIgnoreCase("AR500548_SM")) {
			valueSet3.put(wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYyfield2(), wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYyfield2());
		}
	}
	
	//Sorting in accending order
	valueSet3.sort(new Comparator()
	{
	  public int compare(Object x, Object y)
	  {
		/* passed values are of type I<Node>Element */
		String ax = valueSet3.getText(x);
		String ay = valueSet3.getText(y);
		if (ax == null)
		{
		  return ay == null ? 0 : 1;
		}
		return ax.compareTo(ay);
	  }
	}
	);
	
	if (valueSet3.size() == 1)
		if (valueSet3.getText(0).equalsIgnoreCase(""))
			wdContext.currentContextElement().setProjectVersion1Width("40px");
		else 
			wdContext.currentContextElement().setProjectVersion1Width("");
	else 
		wdContext.currentContextElement().setProjectVersion1Width("");			
	
	wdContext.currentContextElement().setProjectNumber2(wdContext.currentContextElement().getProjectNumber1());	
	if (valueSet3.size() > 0)
		wdContext.currentContextElement().setProjectVersion1(valueSet3.getText(0));
	else 	
		wdContext.currentContextElement().setProjectVersion1("");
	
	valueSet4.clear();

	for (int c=0; c < wdContext.nodeHelp_Tab().size(); c++) {
		if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(c).getYyfield1().equalsIgnoreCase(wdContext.currentContextElement().getProjectNumber2())) {
			valueSet4.put(wdContext.nodeHelp_Tab().getHelp_TabElementAt(c).getYyfield2(), wdContext.nodeHelp_Tab().getHelp_TabElementAt(c).getYyfield2());
		}
	}
	
	//Sorting in accending order
	valueSet4.sort(new Comparator()
	{
	  public int compare(Object x, Object y)
	  {
		/* passed values are of type I<Node>Element */
		String ax = valueSet4.getText(x);
		String ay = valueSet4.getText(y);
		if (ax == null)
		{
		  return ay == null ? 0 : 1;
		}
		return ax.compareTo(ay);
	  }
	}
	);
	
	if (valueSet4.size() == 1)
		if (valueSet4.getText(0).equalsIgnoreCase(""))
			wdContext.currentContextElement().setProjectVersion2Width("40px");
		else 
			wdContext.currentContextElement().setProjectVersion2Width("");
	else 
		wdContext.currentContextElement().setProjectVersion2Width("");	
	
	if (valueSet4.size() > 0)
		wdContext.currentContextElement().setProjectVersion2(valueSet4.getText(0));
	else 
		wdContext.currentContextElement().setProjectVersion2("");	
    //@@end
  }

  //@@begin javadoc:select_project2()
  /** Declared method. */
  //@@end
  public void select_project2( )
  {
    //@@begin select_project2()
	valueSet4.clear();

	for (int c=0; c < wdContext.nodeHelp_Tab().size(); c++) {
		if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(c).getYyfield1().equalsIgnoreCase(wdContext.currentContextElement().getProjectNumber2())) {
		//if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYyfield1().equalsIgnoreCase("AR500548_SM")) {
			valueSet4.put(wdContext.nodeHelp_Tab().getHelp_TabElementAt(c).getYyfield2(), wdContext.nodeHelp_Tab().getHelp_TabElementAt(c).getYyfield2());
		}
	}
	
	//Sorting in accending order
	valueSet4.sort(new Comparator()
	{
	  public int compare(Object x, Object y)
	  {
		/* passed values are of type I<Node>Element */
		String ax = valueSet4.getText(x);
		String ay = valueSet4.getText(y);
		if (ax == null)
		{
		  return ay == null ? 0 : 1;
		}
		return ax.compareTo(ay);
	  }
	}
  	);
  	
  	if (valueSet4.size() > 0)
  		wdContext.currentContextElement().setProjectVersion2(valueSet4.getText(0));
  	else 	
		wdContext.currentContextElement().setProjectVersion2("");
  	
	if (valueSet4.size() == 1)
		if (valueSet4.getText(0).equalsIgnoreCase(""))
			wdContext.currentContextElement().setProjectVersion2Width("40px");
		else 
			wdContext.currentContextElement().setProjectVersion2Width("");
	else 
		wdContext.currentContextElement().setProjectVersion2Width("");			
    //@@end
  }

  /*
   * The following code section can be used for any Java code that is 
   * not to be visible to other controllers/views or that contains constructs
   * currently not supported directly by Web Dynpro (such as inner classes or
   * member variables etc.). </p>
   *
   * Note: The content of this section is in no way managed/controlled
   * by the Web Dynpro Designtime or the Web Dynpro Runtime. 
   */
  //@@begin others
  IModifiableSimpleValueSet valueSet3, valueSet4; 
  //@@end
}
