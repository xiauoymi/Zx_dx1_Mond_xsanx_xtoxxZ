// ---------------------------------------------------------------------------
// This file has been generated partially by the Web Dynpro Code Generator.
// MODIFY CODE ONLY IN SECTIONS ENCLOSED BY @@begin AND @@end.
// ALL OTHER CHANGES WILL BE LOST IF THE FILE IS REGENERATED.
// ---------------------------------------------------------------------------
package com.monsanto.xrpm;

// 
// IMPORTANT NOTE: 
// _ALL_ IMPORT STATEMENTS MUST BE PLACED IN THE FOLLOWING SECTION ENCLOSED
// BY @@begin imports AND @@end. FURTHERMORE, THIS SECTION MUST ALWAYS CONTAIN
// AT LEAST ONE IMPORT STATEMENT (E.G. THAT FOR IPrivateComp_schedule_variance_report).
// OTHERWISE, USING THE ECLIPSE FUNCTION "Organize Imports" FOLLOWED BY
// A WEB DYNPRO CODE GENERATION (E.G. PROJECT BUILD) WILL RESULT IN THE LOSS
// OF IMPORT STATEMENTS.
//
//@@begin imports
import java.util.Comparator;

import com.monsanto.xrpm.model.ScheduleVarianceReport;
import com.monsanto.xrpm.model.Y_Xrpm_Schedule_Variance_Rep_Input;
import com.monsanto.xrpm.model.Y_Xrpm_Search_Help_Input;
import com.monsanto.xrpm.model.Y_Xrpm_Shlp_Simulations_Input;
import com.monsanto.xrpm.wdp.IPrivateComp_schedule_variance_report;
import com.monsanto.xrpm.wdp.IPrivateView_schedule_variance_report;
import com.monsanto.xrpm.wdp.IPublicComp_schedule_variance_report;
import com.sap.dictionary.runtime.ISimpleTypeModifiable;
import com.sap.tc.webdynpro.progmodel.api.IWDAttributeInfo;
import com.sap.tc.webdynpro.progmodel.api.IWDNode;
import com.sap.tc.webdynpro.progmodel.api.IWDNodeElement;
import com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener;
import com.sap.tc.webdynpro.progmodel.api.WDVisibility;
import com.sap.tc.webdynpro.progmodel.model.api.WDModelFactory;
import com.sap.tc.webdynpro.services.session.api.IWDWindow;
import com.sap.tc.webdynpro.services.session.api.WDWindowPos;
import com.sap.typeservices.IModifiableSimpleValueSet;
//@@end

//@@begin documentation
//@@end

public class Comp_schedule_variance_report
{
  /**
   * Logging location.
   */
  private static final com.sap.tc.logging.Location logger = 
    com.sap.tc.logging.Location.getLocation(Comp_schedule_variance_report.class);

  static 
  {
    //@@begin id
    String id = "$Id$";
    //@@end
    com.sap.tc.logging.Location.getLocation("ID.com.sap.tc.webdynpro").infoT(id);
  }

  /**
   * Private access to the generated Web Dynpro counterpart 
   * for this controller class.  </p>
   *
   * Use <code>wdThis</code> to gain typed access to the context,
   * to trigger navigation via outbound plugs, to get and enable/disable
   * actions, fire declared events, and access used controllers and/or 
   * component usages.
   *
   * @see com.monsanto.xrpm.wdp.IPrivateComp_schedule_variance_report for more details
   */
  private final IPrivateComp_schedule_variance_report wdThis;

  /**
   * Root node of this controller's context. </p>
   *
   * Provides typed access not only to the elements of the root node 
   * but also to all nodes in the context (methods node<i>XYZ</i>()) 
   * and their currently selected element (methods current<i>XYZ</i>Element()). 
   * It also facilitates the creation of new elements for all nodes 
   * (methods create<i>XYZ</i>Element()). </p>
   *
   * @see com.monsanto.xrpm.wdp.IPrivateComp_schedule_variance_report.IContextNode for more details.
   */
  private final IPrivateComp_schedule_variance_report.IContextNode wdContext;

  /**
   * A shortcut for <code>wdThis.wdGetAPI()</code>. </p>
   * 
   * Represents the generic API of the generic Web Dynpro counterpart 
   * for this controller. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdControllerAPI;
  
  /**
   * A shortcut for <code>wdThis.wdGetAPI().getComponent()</code>. </p>
   * 
   * Represents the generic API of the Web Dynpro component this controller 
   * belongs to. Can be used to access the message manager, the window manager,
   * to add/remove event handlers and so on. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdComponentAPI;
  
  public Comp_schedule_variance_report(IPrivateComp_schedule_variance_report wdThis)
  {
    this.wdThis = wdThis;
    this.wdContext = wdThis.wdGetContext();
    this.wdControllerAPI = wdThis.wdGetAPI();
    this.wdComponentAPI = wdThis.wdGetAPI().getComponent();
  }

  //@@begin javadoc:wdDoInit()
  /** Hook method called to initialize controller. */
  //@@end
  public void wdDoInit()
  {
    //@@begin wdDoInit()
	Y_Xrpm_Search_Help_Input input = new Y_Xrpm_Search_Help_Input();
	wdContext.nodeY_Xrpm_Search_Help_Input().bind(input);
    
    Y_Xrpm_Shlp_Simulations_Input sim = new Y_Xrpm_Shlp_Simulations_Input();
    wdContext.nodeY_Xrpm_Shlp_Simulations_Input().bind(sim);
    
	Y_Xrpm_Schedule_Variance_Rep_Input schedule = new Y_Xrpm_Schedule_Variance_Rep_Input();
	wdContext.nodeY_Xrpm_Schedule_Variance_Rep_Input().bind(schedule);
	
	wdContext.currentY_Xrpm_Search_Help_InputElement().setField1("");
	wdContext.currentY_Xrpm_Search_Help_InputElement().setField2("");
	    
	//execute the RFC
	wdThis.MD_execute_f4_help_rfc();
	 
	for (int b=0; b < wdContext.nodeHelp_Tab().size(); b++) {
		IPublicComp_schedule_variance_report.ISearchHelpElement ele = wdContext.createSearchHelpElement();
		ele.setYyfield1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYyfield1());
		ele.setYyfield2(wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYyfield2());
		ele.setYytext1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(b).getYytext1());
		wdContext.nodeSearchHelp().addElement(ele);
	}
    
	//Sort table elements
	IPublicComp_schedule_variance_report.ISearchHelpNode node = wdContext.nodeSearchHelp();
	node.sortElements
	(
	  new Comparator()
	  {
		public int compare(Object x, Object y)
		{
		  /* passed values are of type I<Node>Element */
		  String ax = ((IPublicComp_schedule_variance_report.ISearchHelpElement) x).getYyfield1();
		  String ay = ((IPublicComp_schedule_variance_report.ISearchHelpElement) y).getYyfield1();
		  if (ax == null)
		  {
			return ay == null ? 0 : 1;
		  }
		  return ax.compareTo(ay);
		}
	  }
	);
       
	//Drop down for project version 1 - Snap Shot
	IWDAttributeInfo attributeInfo3 = this.wdContext.getNodeInfo().getAttribute("snap_shot_proj1_version");
	ISimpleTypeModifiable plansType3 = attributeInfo3.getModifiableSimpleType();
	valueSet3 = plansType3.getSVServices().getModifiableSimpleValueSet();
	valueSet3.clear();
	
	//Drop down for project version 1 - Simulation
	IWDAttributeInfo attributeInfo5 = this.wdContext.getNodeInfo().getAttribute("simulation_proj1_version");
	ISimpleTypeModifiable plansType5 = attributeInfo5.getModifiableSimpleType();
	valueSet5 = plansType5.getSVServices().getModifiableSimpleValueSet();
	valueSet5.clear();
	
	//Drop down for project version 2 - Snap Shot
	IWDAttributeInfo attributeInfo4 = this.wdContext.getNodeInfo().getAttribute("snap_shot_proj2_version");
	ISimpleTypeModifiable plansType4 = attributeInfo4.getModifiableSimpleType();
	valueSet4 = plansType4.getSVServices().getModifiableSimpleValueSet();
	valueSet4.clear();
	
	//Drop down for project number 2 - Simulation
	IWDAttributeInfo attributeInfo6 = this.wdContext.getNodeInfo().getAttribute("projectNumber2_simulation");
	ISimpleTypeModifiable plansType6 = attributeInfo6.getModifiableSimpleType();
	valueSet6 = plansType6.getSVServices().getModifiableSimpleValueSet();
	valueSet6.clear();
	
	//Drop down for project version 2 - Simulation
	IWDAttributeInfo attributeInfo7 = this.wdContext.getNodeInfo().getAttribute("simulation_proj2_version");
	ISimpleTypeModifiable plansType7 = attributeInfo7.getModifiableSimpleType();
	valueSet7 = plansType7.getSVServices().getModifiableSimpleValueSet();
	valueSet7.clear();

	//Drop down for project number 1 - Simulation
	IWDAttributeInfo attributeInfo8 = this.wdContext.getNodeInfo().getAttribute("projectNumber1_Simulation");
	ISimpleTypeModifiable plansType8 = attributeInfo8.getModifiableSimpleType();
	valueSet8 = plansType8.getSVServices().getModifiableSimpleValueSet();
	valueSet8.clear();
	
	wdContext.currentContextElement().setProjectVersion1Width("40px");
	wdContext.currentContextElement().setProjectVersion3Width("40px");
	wdContext.currentContextElement().setProjectVersion2Width("40px");
   	wdContext.currentContextElement().setProjectNumber2Width("40px");
	wdContext.currentContextElement().setSnap_shot_proj2_versionWidth("40px");
	wdContext.currentContextElement().setProjectnumber1_simulation_width("40px");

	//set ovs input labels and output column names
	wdContext.nodeOVSProjectNumberOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("Project Number");
	wdContext.nodeOVSProjectNumberOutput().getNodeInfo().getAttribute("Yytext1").getModifiableSimpleType().setColumnLabel("Project Name");
	
	wdContext.nodeOVSProjectNumberInput().getNodeInfo().getAttribute("YYFIELD1").getModifiableSimpleType().setFieldLabel("Project Number");
	wdContext.nodeOVSProjectNumberInput().getNodeInfo().getAttribute("YYTEXT1").getModifiableSimpleType().setFieldLabel("Project Name");	
    //@@end
  }

  //@@begin javadoc:wdDoExit()
  /** Hook method called to clean up controller. */
  //@@end
  public void wdDoExit()
  {
    //@@begin wdDoExit()
    //@@end
  }

  //@@begin javadoc:wdDoPostProcessing()
  /**
   * Hook called to handle data retrieval errors before rendering.
   *
   * After doModifyView(), the Web Dynpro Framework gets all context data needed
   * for rendering by validating the contexts (which in turn calls the supply
   * functions and supplying relation roles). In this hook, the application
   * should handle the errors which occurred during validation of the contexts.
   * 
   * Using preorder depth-first traversal, this hook is called for all component
   * controllers starting with the current root component.
   *
   * Permitted operations:
   * - Flushing model queue
   * - Creating messages
   * - Reading context and model data
   *
   * Forbidden operations: 
   * - Invalidating model data
   * - Manipulating the context
   * - Firing outbound plugs
   * - Creating components
   * - ...   
   *
   * @param isCurrentRoot true if this is the root of the current request
   */
  //@@end
  public void wdDoPostProcessing(boolean isCurrentRoot)
  {
    //@@begin wdDoPostProcessing()
    //@@end
  }

  //@@begin javadoc:wdDoBeforeNavigation()
  /**
   * Hook before the navigation phase starts.
   *
   * This hook allows you to flush the model queue and handle any
   * errors that occur. Firing outbound plugs is allowed in this hook.
   *
   * Using preorder depth-first traversal, this hook is called for all component
   * controllers starting with the current root component.
   *
   * @param isCurrentRoot true if this is the root of the current request
   */
  //@@end
  public void wdDoBeforeNavigation(boolean isCurrentRoot)
  {
    //@@begin wdDoBeforeNavigation()
    //@@end
  }
  
  //@@begin javadoc:wdDoApplicationStateChange()
  /**
   * Hook that informs the application about a state change.
   * <p>
   * This hook is called e.g. to tell the application that will be
   * <ul>
   *  <li>left via a suspend plug and therefore should go into a suspend/sleep
   *      mode with minimal need of resources. errors that occur. Firing 
   *      outbound plugs is allowed in this hook.
   *  <li>left due to a timeout and could write it's state to a data base if the 
   *      user comes back later on
   * </ul>
   *
   * The concrete reason is available via IWDApplicationStateChangeInfo
   * <p>
   * <b>Important</b>: This hook is called for the top level component only!
   *
   * @param stateChangeInfo contains the information about the nature of the state change
   * @param stateChangeReturn allows the application to ask for a different state change. 
   *        The framework is allowed to ignore it considering i.e. the current resources situation.
   */
  //@@end
  public void wdDoApplicationStateChange(com.sap.tc.webdynpro.progmodel.api.IWDApplicationStateChangeInfo stateChangeInfo, com.sap.tc.webdynpro.progmodel.api.IWDApplicationStateChangeReturn stateChangeReturn)
  {
    //@@begin wdDoApplicationStateChange()
    //@@end
  }

  //@@begin javadoc:MD_execute_f4_help_rfc()
  /** Declared method. */
  //@@end
  public void MD_execute_f4_help_rfc( )
  {
    //@@begin MD_execute_f4_help_rfc()
	wdContext.currentY_Xrpm_Search_Help_InputElement().setS_Help("PN");

	//Execute the RFC
	try {
		wdContext.currentY_Xrpm_Search_Help_InputElement().modelObject().execute();
		wdContext.nodeHelp_Tab().invalidate();
		wdContext.nodeOutput_Help_Tab().invalidate();
	}
	catch (Exception e) {
		wdComponentAPI.getMessageManager().reportException("Error in executing f4 RFC: " + e.getMessage(), true);
   
		//Disconnect the connection
		ScheduleVarianceReport model = (ScheduleVarianceReport) WDModelFactory.getModelInstance(ScheduleVarianceReport.class);
		model.disconnectIfAlive();
	}
	//Disconnect the connection
	ScheduleVarianceReport model = (ScheduleVarianceReport) WDModelFactory.getModelInstance(ScheduleVarianceReport.class);
	model.disconnectIfAlive();

    //@@end
  }

  //@@begin javadoc:select_project1()
  /** Declared method. */
  //@@end
  public void select_project1( java.lang.String proj_number )
  {
    //@@begin select_project1()
	valueSet3.clear(); //Remove all elements...
	valueSet5.clear(); //Remove all elements...
	valueSet4.clear(); //Remove all elements...
	valueSet8.clear(); //Remove all elements...

	for (int b=0; b < wdContext.nodeSearchHelp().size(); b++) {
		if (wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield1().equalsIgnoreCase(wdContext.currentContextElement().getProject_number1())) {
			//Snap shot naming convension - starts with SNP or VERS...
			if ((wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield2().startsWith("SNP") || wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield2().startsWith("VERS")) && !wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield2().trim().equalsIgnoreCase("")) {
				valueSet3.put(wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield2(), wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield2());
				valueSet4.put(wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield2(), wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield2());
			}
		
//			//Simulations naming convension - starts with SIM or SIMU..
//			if ((wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield2().startsWith("SIM") || wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield2().startsWith("SIMU")) && !wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield2().trim().equalsIgnoreCase("")) 
//				valueSet5.put(wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield2(), wdContext.nodeSearchHelp().getSearchHelpElementAt(b).getYyfield2());
				
		}
	}

	wdThis.MD_execute_get_simulations(proj_number.toUpperCase(), "", "");
	
	for (int b=0; b < wdContext.nodeGt_Projects().size(); b++) {
		valueSet8.put(wdContext.nodeGt_Projects().getGt_ProjectsElementAt(b).getYyfield1(), wdContext.nodeGt_Projects().getGt_ProjectsElementAt(b).getYyfield1());
	}

	for (int b=0; b < wdContext.nodeGt_Versions().size(); b++) {
		valueSet5.put(wdContext.nodeGt_Versions().getGt_VersionsElementAt(b).getYyfield1(), wdContext.nodeGt_Versions().getGt_VersionsElementAt(b).getYyfield1());
	}
	
	
	//Sorting in accending order
	valueSet3.sort(new Comparator()
	{
	  public int compare(Object x, Object y)
	  {
		/* passed values are of type I<Node>Element */
		String ax = valueSet3.getText(x);
		String ay = valueSet3.getText(y);
		if (ax == null)
		{
		  return ay == null ? 0 : 1;
		}
		return ax.compareTo(ay);
	  }
	}
	);
	
	//Sorting in accending order
	valueSet5.sort(new Comparator()
	{
	  public int compare(Object x, Object y)
	  {
		/* passed values are of type I<Node>Element */
		String ax = valueSet5.getText(x);
		String ay = valueSet5.getText(y);
		if (ax == null)
		{
		  return ay == null ? 0 : 1;
		}
		return ax.compareTo(ay);
	  }
	}
	);
	
	//Sorting in accending order
	valueSet4.sort(new Comparator()
	{
	  public int compare(Object x, Object y)
	  {
		/* passed values are of type I<Node>Element */
		String ax = valueSet4.getText(x);
		String ay = valueSet4.getText(y);
		if (ax == null)
		{
		  return ay == null ? 0 : 1;
		}
		return ax.compareTo(ay);
	  }
	}
	);
	
	//Sorting in accending order
	valueSet8.sort(new Comparator()
	{
	  public int compare(Object x, Object y)
	  {
		/* passed values are of type I<Node>Element */
		String ax = valueSet8.getText(x);
		String ay = valueSet8.getText(y);
		if (ax == null)
		{
		  return ay == null ? 0 : 1;
		}
		return ax.compareTo(ay);
	  }
	}
	);

	if (valueSet3.size() == 0)
		wdContext.currentContextElement().setProjectVersion1Width("40px");
	else 
		wdContext.currentContextElement().setProjectVersion1Width("");			

	if (valueSet5.size() == 0)
		wdContext.currentContextElement().setProjectVersion3Width("40px");
	else 
		wdContext.currentContextElement().setProjectVersion3Width("");

	if (valueSet4.size() == 0)
		wdContext.currentContextElement().setProjectVersion2Width("40px");
	else 
		wdContext.currentContextElement().setProjectVersion2Width("");	

	if (valueSet8.size() == 0)
		wdContext.currentContextElement().setProjectnumber1_simulation_width("40px");
	else 
		wdContext.currentContextElement().setProjectnumber1_simulation_width("");	

	if (valueSet3.size() > 0)
		wdContext.currentContextElement().setSnap_shot_proj1_version(valueSet3.getText(0));
	else 	
		wdContext.currentContextElement().setSnap_shot_proj1_version("");

	if (valueSet5.size() > 0)
		wdContext.currentContextElement().setSimulation_proj1_version(valueSet5.getText(0));
	else 	
		wdContext.currentContextElement().setSimulation_proj1_version("");
	

	if (valueSet4.size() > 0)
		wdContext.currentContextElement().setSnap_shot_proj2_version(valueSet4.getText(0));
	else 
		wdContext.currentContextElement().setSnap_shot_proj2_version("");	

	if (valueSet8.size() > 0)
		wdContext.currentContextElement().setProjectNumber1_Simulation(valueSet8.getText(0));
	else 
		wdContext.currentContextElement().setProjectNumber1_Simulation("");
		
	for (int o=0; o < wdContext.nodeSnapshot_Version().size(); o++) {
		wdContext.nodeSnapshot_Version().removeElement(wdContext.nodeSnapshot_Version().getElementAt(o)); 
	}
	wdContext.nodeSnapshot_Version().invalidate();
	
	for (int v=0; v < valueSet4.size(); v++) {
		IPublicComp_schedule_variance_report.ISnapshot_VersionElement ele = wdContext.createSnapshot_VersionElement();
		ele.setVersion(valueSet4.getText(v));
		wdContext.nodeSnapshot_Version().addElement(ele);
	}	

	//wdThis.MD_execute_get_simulations(wdContext.currentContextElement().getProject_number1(), wdContext.currentContextElement().getSnap_shot_proj1_version(), "");
    //wdThis.setDefaults();
    //@@end
  }

  //@@begin javadoc:select_project2()
  /** Declared method. */
  //@@end
  public void select_project2( )
  {
    //@@begin select_project2()
    //@@end
  }

  //@@begin javadoc:removeVersion()
  /** Declared method. */
  //@@end
  public void removeVersion( )
  {
    //@@begin removeVersion()
    try {
		if (!wdContext.currentContextElement().getSnap_shot_proj1_version().equalsIgnoreCase("")) {
	    	if (valueSet4.size() > 0) {
				valueSet4.removeKey(wdContext.currentContextElement().getSnap_shot_proj1_version());
				if (valueSet4.size() > 0)
					wdContext.currentContextElement().setSnap_shot_proj2_version(valueSet4.getText(0));
				else 
					wdContext.currentContextElement().setSnap_shot_proj2_version("");	
			}
	    }
    }
    catch (NullPointerException e) {	
    }
    //@@end
  }

  //@@begin javadoc:addVersion()
  /** Declared method. */
  //@@end
  public void addVersion( )
  {
    //@@begin addVersion()
    valueSet4.clear();
    
    for (int x=0; x < wdContext.nodeSnapshot_Version().size(); x++) {
		valueSet4.put(wdContext.nodeSnapshot_Version().getSnapshot_VersionElementAt(x).getVersion(), wdContext.nodeSnapshot_Version().getSnapshot_VersionElementAt(x).getVersion());
    }
	
	if (valueSet4.size() > 0)
		wdContext.currentContextElement().setSnap_shot_proj2_version(valueSet4.getText(0));    
    //@@end
  }

  //@@begin javadoc:MD_execute_get_simulations()
  /** Declared method. */
  //@@end
  public void MD_execute_get_simulations( java.lang.String project_num, java.lang.String project_ver, java.lang.String project_ver2 )
  {
    //@@begin MD_execute_get_simulations()
	wdContext.currentY_Xrpm_Shlp_Simulations_InputElement().setProject(project_num);
	wdContext.currentY_Xrpm_Shlp_Simulations_InputElement().setVersion_L(project_ver); 
	wdContext.currentY_Xrpm_Shlp_Simulations_InputElement().setVersion_R(project_ver2);

	//Execute the RFC
	try {
		wdContext.currentY_Xrpm_Shlp_Simulations_InputElement().modelObject().execute();
		wdContext.nodeGt_Projects().invalidate();
		wdContext.nodeGt_Versions().invalidate();
		wdContext.nodeOutput().invalidate();
	}
	catch (Exception e) {
		wdComponentAPI.getMessageManager().reportException("Error in executing simulation RFC: " + e.getMessage(), true);
   
		//Disconnect the connection
		ScheduleVarianceReport model = (ScheduleVarianceReport) WDModelFactory.getModelInstance(ScheduleVarianceReport.class);
		model.disconnectIfAlive();
	}
	//Disconnect the connection
	ScheduleVarianceReport model = (ScheduleVarianceReport) WDModelFactory.getModelInstance(ScheduleVarianceReport.class);
	model.disconnectIfAlive();
    //@@end
  }

  //@@begin javadoc:setDefault_Snapshot_Ver1()
  /** Declared method. */
  //@@end
  public void setDefault_Snapshot_Ver1( )
  {
    //@@begin setDefault_Snapshot_Ver1()
	if (valueSet3.size() > 0)
		wdContext.currentContextElement().setSnap_shot_proj1_version(valueSet3.getText(0));
	else 	
		wdContext.currentContextElement().setSnap_shot_proj1_version("");
    //@@end
  }

  //@@begin javadoc:setDefault_Simulation_Ver1()
  /** Declared method. */
  //@@end
  public void setDefault_Simulation_Ver1( )
  {
    //@@begin setDefault_Simulation_Ver1()
	if (valueSet5.size() > 0)
		wdContext.currentContextElement().setSimulation_proj1_version(valueSet5.getText(0));
	else 	
		wdContext.currentContextElement().setSimulation_proj1_version("");
    //@@end
  }

  //@@begin javadoc:getOVSProjectNoFromListener()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener getOVSProjectNoFromListener( )
  {
    //@@begin getOVSProjectNoFromListener()
	return ovsListener_projectnofrom; 
    //@@end
  }

  //@@begin javadoc:getOVSProjectNoInputNode()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDNode getOVSProjectNoInputNode( )
  {
    //@@begin getOVSProjectNoInputNode()
	return wdContext.nodeOVSProjectNumberInput();
    //@@end
  }

  //@@begin javadoc:getOVSProjectNoOutputNode()
  /** Declared method. */
  //@@end
  public com.sap.tc.webdynpro.progmodel.api.IWDNode getOVSProjectNoOutputNode( )
  {
    //@@begin getOVSProjectNoOutputNode()
	return wdContext.nodeOVSProjectNumberOutput();
    //@@end
  }

  //@@begin javadoc:MD_execute_schedule_variance_rep()
  /** Declared method. */
  //@@end
  public void MD_execute_schedule_variance_rep( )
  {
    //@@begin MD_execute_schedule_variance_rep()
	//Execute the RFC
	try {
		wdContext.currentY_Xrpm_Schedule_Variance_Rep_InputElement().modelObject().execute();
		wdContext.nodeGt_Data().invalidate();
		wdContext.nodeOutput_Gt_Data().invalidate();
	}
	catch (Exception e) {
		wdComponentAPI.getMessageManager().reportException("Error in executing schedule variance report RFC: " + e.getMessage(), true);
   
		//Disconnect the connection
		ScheduleVarianceReport model = (ScheduleVarianceReport) WDModelFactory.getModelInstance(ScheduleVarianceReport.class);
		model.disconnectIfAlive();
	}
	//Disconnect the connection
	ScheduleVarianceReport model = (ScheduleVarianceReport) WDModelFactory.getModelInstance(ScheduleVarianceReport.class);
	model.disconnectIfAlive();
    //@@end
  }

  //@@begin javadoc:setProjectNumber()
  /** Declared method. */
  //@@end
  public void setProjectNumber( )
  {
    //@@begin setProjectNumber()
    valueSet8.clear();
	for (int b=0; b < wdContext.nodeGt_Projects().size(); b++) {
		valueSet8.put(wdContext.nodeGt_Projects().getGt_ProjectsElementAt(b).getYyfield1(), wdContext.nodeGt_Projects().getGt_ProjectsElementAt(b).getYyfield1());
	}
    
	if (valueSet8.size() > 0)
		wdContext.currentContextElement().setProjectNumber1_Simulation(valueSet8.getText(0));
	else 	
		wdContext.currentContextElement().setProjectNumber1_Simulation("");	
		
	if (valueSet8.size() == 0)
		wdContext.currentContextElement().setProjectnumber1_simulation_width("40px");
	else
		wdContext.currentContextElement().setProjectnumber1_simulation_width("");	
    //@@end
  }

  //@@begin javadoc:setSimulations()
  /** Declared method. */
  //@@end
  public void setSimulations( )
  {
    //@@begin setSimulations()
	valueSet6.clear();
	valueSet7.clear();
	
	for (int b=0; b < wdContext.nodeGt_Projects().size(); b++) {
		valueSet6.put(wdContext.nodeGt_Projects().getGt_ProjectsElementAt(b).getYyfield1(), wdContext.nodeGt_Projects().getGt_ProjectsElementAt(b).getYyfield1());
	}
	
	for (int b=0; b < wdContext.nodeGt_Versions().size(); b++) {
		valueSet7.put(wdContext.nodeGt_Versions().getGt_VersionsElementAt(b).getYyfield1(), wdContext.nodeGt_Versions().getGt_VersionsElementAt(b).getYyfield1());
	}
    
	if (valueSet6.size() > 0)
		wdContext.currentContextElement().setProjectNumber2_simulation(valueSet6.getText(0));
	else 	
		wdContext.currentContextElement().setProjectNumber2_simulation("");	
		
	if (valueSet6.size() == 0)
		wdContext.currentContextElement().setProjectNumber2Width("40px");
	else
		wdContext.currentContextElement().setProjectNumber2Width("");	
		
		
	if (valueSet7.size() > 0)
		wdContext.currentContextElement().setSimulation_proj2_version(valueSet7.getText(0));
	else 	
		wdContext.currentContextElement().setSimulation_proj2_version("");	
		
	if (valueSet7.size() == 0)
		wdContext.currentContextElement().setSnap_shot_proj2_versionWidth("40px");
	else
		wdContext.currentContextElement().setSnap_shot_proj2_versionWidth("");		
    //@@end
  }

  //@@begin javadoc:setDefaults()
  /** Declared method. */
  //@@end
  public void setDefaults( )
  {
    //@@begin setDefaults()
	if (valueSet7.size() > 0)
		wdContext.currentContextElement().setSimulation_proj2_version(valueSet7.getText(0));
	else 	
		wdContext.currentContextElement().setSimulation_proj2_version("");
			
	if (valueSet6.size() == 0)
		wdContext.currentContextElement().setProjectNumber2Width("40px");
	else
		wdContext.currentContextElement().setProjectNumber2Width("");
		
	if (valueSet6.size() > 0)
		wdContext.currentContextElement().setProjectNumber2_simulation(valueSet6.getText(0));
	else 	
		wdContext.currentContextElement().setProjectNumber2_simulation("");	
		
	if (valueSet7.size() == 0)
		wdContext.currentContextElement().setSnap_shot_proj2_versionWidth("40px");
	else
		wdContext.currentContextElement().setSnap_shot_proj2_versionWidth("");				
    //@@end
  }

  //@@begin javadoc:setSimulations_1()
  /** Declared method. */
  //@@end
  public void setSimulations_1( )
  {
    //@@begin setSimulations_1()
	valueSet6.clear();
	//valueSet7.clear();
	
	for (int b=0; b < wdContext.nodeGt_Projects().size(); b++) {
		valueSet6.put(wdContext.nodeGt_Projects().getGt_ProjectsElementAt(b).getYyfield1(), wdContext.nodeGt_Projects().getGt_ProjectsElementAt(b).getYyfield1());
	}
	
//	for (int b=0; b < wdContext.nodeGt_Versions().size(); b++) {
//		valueSet7.put(wdContext.nodeGt_Versions().getGt_VersionsElementAt(b).getYyfield1(), wdContext.nodeGt_Versions().getGt_VersionsElementAt(b).getYyfield1());
//	}
    
	if (valueSet6.size() > 0)
		wdContext.currentContextElement().setProjectNumber2_simulation(valueSet6.getText(0));
	else 	
		wdContext.currentContextElement().setProjectNumber2_simulation("");	
		
	if (valueSet6.size() == 0)
		wdContext.currentContextElement().setProjectNumber2Width("40px");
	else
		wdContext.currentContextElement().setProjectNumber2Width("");	
//		
//		
//	if (valueSet7.size() > 0)
//		wdContext.currentContextElement().setSimulation_proj2_version(valueSet7.getText(0));
//	else 	
//		wdContext.currentContextElement().setSimulation_proj2_version("");	
//		
//	if (valueSet7.size() == 0)
//		wdContext.currentContextElement().setSnap_shot_proj2_versionWidth("40px");
//	else
//		wdContext.currentContextElement().setSnap_shot_proj2_versionWidth("");	
    //@@end
  }

  //@@begin javadoc:close()
  /** Declared method. */
  //@@end
  public void close( )
  {
    //@@begin close()
	if (link != null) {
		//surveyConfirmation.destroy();
		link.destroyInstance();
		link = null;
	}
    //@@end
  }

  //@@begin javadoc:open()
  /** Declared method. */
  //@@end
  public void open( )
  {
    //@@begin open()
	link = wdComponentAPI.getWindowManager().createModalWindow(wdComponentAPI.getComponentInfo().findInWindows("W_ExcelLink"));
	link.setWindowPosition(WDWindowPos.CENTER);
	// Netweaver 2004
	//surveyConfirmation.open();
	
	// Netweaver 2004s
	link.show();
    //@@end
  }

  //@@begin javadoc:open_pdf_link()
  /** Declared method. */
  //@@end
  public void open_pdf_link( )
  {
    //@@begin open_pdf_link()
	link1 = wdComponentAPI.getWindowManager().createModalWindow(wdComponentAPI.getComponentInfo().findInWindows("W_PDFLink"));
	link1.setWindowPosition(WDWindowPos.CENTER);
	// Netweaver 2004
	//surveyConfirmation.open();
	
	// Netweaver 2004s
	link1.show();
    //@@end
  }

  //@@begin javadoc:close_pdf_link()
  /** Declared method. */
  //@@end
  public void close_pdf_link( )
  {
    //@@begin close_pdf_link()
	if (link1 != null) {
		//surveyConfirmation.destroy();
		link1.destroyInstance();
		link1 = null;
	}
    //@@end
  }

  /*
   * The following code section can be used for any Java code that is 
   * not to be visible to other controllers/views or that contains constructs
   * currently not supported directly by Web Dynpro (such as inner classes or
   * member variables etc.). </p>
   *
   * Note: The content of this section is in no way managed/controlled
   * by the Web Dynpro Designtime or the Web Dynpro Runtime. 
   */
  //@@begin others
  String removedVersion;
  IModifiableSimpleValueSet valueSet3, valueSet4, valueSet5, valueSet6, valueSet7, valueSet8; 
  private IWDWindow link, link1;
  
  private IWDOVSContextNotificationListener ovsListener_projectnofrom = new OVSContextNotificationProjectNoFromListener();
  
  //Listener for ovs porject no from...........
  private class OVSContextNotificationProjectNoFromListener implements IWDOVSContextNotificationListener {
	public void onQuery(IWDNodeElement queryInputNodeElement, IWDNode queryOutputNode) {
		
		IPublicComp_schedule_variance_report.IOVSProjectNumberOutputNode ovsOutput = (IPublicComp_schedule_variance_report.IOVSProjectNumberOutputNode) queryOutputNode;
		IPublicComp_schedule_variance_report.IOVSProjectNumberInputElement ovsInput = (IPublicComp_schedule_variance_report.IOVSProjectNumberInputElement) queryInputNodeElement;
		
		for (int b=0; b < wdContext.nodeOVSProjectNumberOutput().size(); b++) {
			wdContext.nodeOVSProjectNumberOutput().removeElement(wdContext.nodeOVSProjectNumberOutput().getElementAt(b));
		}
		wdContext.nodeOVSProjectNumberOutput().invalidate();
		
		String project_no_input, project_name_input;
		try {
			if (!ovsInput.getYYFIELD1().equalsIgnoreCase("")) {
				project_no_input = ovsInput.getYYFIELD1().toUpperCase(); 
			}
			else 
				project_no_input = "";
		}
		catch (NullPointerException e){
			project_no_input = "";	
		}
		
		try {
			if (!ovsInput.getYYTEXT1().equalsIgnoreCase(""))
				project_name_input = ovsInput.getYYTEXT1().toUpperCase(); 
			else 
				project_name_input = "";
		}
		catch (NullPointerException e){
			project_name_input = "";	
		}
		
		wdContext.currentY_Xrpm_Search_Help_InputElement().setField1(project_no_input);
		wdContext.currentY_Xrpm_Search_Help_InputElement().setField2(project_name_input);	   
		wdThis.MD_execute_f4_help_rfc();
		if (wdContext.nodeHelp_Tab().size() == 0) {
			wdContext.currentContextElement().setVisibility_searchhelp_message(WDVisibility.VISIBLE);
		}
		else {
			wdContext.currentContextElement().setVisibility_searchhelp_message(WDVisibility.NONE);
		}
		
		for (int j=0; j < wdContext.nodeHelp_Tab().size(); j++) {
			if (wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYyfield2().equalsIgnoreCase("")) {
				IPublicComp_schedule_variance_report.IOVSProjectNumberOutputElement ele = wdContext.createOVSProjectNumberOutputElement();
				ele.setYytext1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYytext1());
				ele.setYyfield1(wdContext.nodeHelp_Tab().getHelp_TabElementAt(j).getYyfield1());
				wdContext.nodeOVSProjectNumberOutput().addElement(ele);
			}
		}
		
		//set the label
		wdContext.nodeOVSProjectNumberOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("Project Number");
		wdContext.nodeOVSProjectNumberOutput().getNodeInfo().getAttribute("Yytext1").getModifiableSimpleType().setColumnLabel("Project Name");
		
		// Clear the input fields
		ovsInput.setYYFIELD1("");
		ovsInput.setYYTEXT1("");
		
		wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	}
	
	/* (non-Javadoc)
	 * @see com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener#applyResult(com.sap.tc.webdynpro.progmodel.api.IWDNodeElement, com.sap.tc.webdynpro.progmodel.api.IWDNodeElement)
	 */
	public void applyResult(IWDNodeElement applicationNodeElement, IWDNodeElement queryOutputNodeElement) {
		
		IPrivateView_schedule_variance_report.IProjectNo_FromElement ovsCallerNodeElement = (IPrivateView_schedule_variance_report.IProjectNo_FromElement) applicationNodeElement;
		IPublicComp_schedule_variance_report.IOVSProjectNumberOutputElement output = (IPublicComp_schedule_variance_report.IOVSProjectNumberOutputElement) queryOutputNodeElement;
		
		ovsCallerNodeElement.setYYFIELD1(output.getYyfield1());
		ovsCallerNodeElement.setYYTEXT1(output.getYytext1());
		
		wdContext.currentContextElement().setProject_number1(output.getYyfield1());
		wdContext.currentContextElement().setProj1_radiobutton("2");
		wdContext.currentContextElement().setProj2_radiobutton("1");
		wdContext.currentContextElement().setVisible_Operational_Proj2(WDVisibility.NONE);
		wdContext.currentContextElement().setVisible_snapshot_proj1_version(WDVisibility.VISIBLE);
		wdContext.currentContextElement().setVisible_snapshot_proj2_version(WDVisibility.NONE);
		wdContext.currentContextElement().setVisible_simulation_proj1_ver(WDVisibility.NONE);
		wdContext.currentContextElement().setVisible_simulation_proj2_ver(WDVisibility.NONE);
		wdThis.select_project1(wdContext.currentContextElement().getProject_number1());
		wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	}
	
	  /* (non-Javadoc)
	   * @see com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener#applyInputValues(com.sap.tc.webdynpro.progmodel.api.IWDNodeElement, com.sap.tc.webdynpro.progmodel.api.IWDNodeElement)
	   */
	  public void applyInputValues(IWDNodeElement applicationNodeElement, IWDNodeElement queryInputNodeElement) {
				 
		// Set the node labels (OVS)
		wdContext.nodeOVSProjectNumberOutput().getNodeInfo().getAttribute("Yyfield1").getModifiableSimpleType().setColumnLabel("Project Number");
		wdContext.nodeOVSProjectNumberOutput().getNodeInfo().getAttribute("Yytext1").getModifiableSimpleType().setColumnLabel("Project Name");
		wdContext.currentContextElement().setVisibility_message(WDVisibility.VISIBLE);
	  }
  }
  //@@end
}
