// ---------------------------------------------------------------------------
// This file has been generated partially by the Web Dynpro Code Generator.
// MODIFY CODE ONLY IN SECTIONS ENCLOSED BY @@begin AND @@end.
// ALL OTHER CHANGES WILL BE LOST IF THE FILE IS REGENERATED.
// ---------------------------------------------------------------------------
package com.monsanto.xrpm;

// 
// IMPORTANT NOTE: 
// _ALL_ IMPORT STATEMENTS MUST BE PLACED IN THE FOLLOWING SECTION ENCLOSED
// BY @@begin imports AND @@end. FURTHERMORE, THIS SECTION MUST ALWAYS CONTAIN
// AT LEAST ONE IMPORT STATEMENT (E.G. THAT FOR IPrivateView_Rep).
// OTHERWISE, USING THE ECLIPSE FUNCTION "Organize Imports" FOLLOWED BY
// A WEB DYNPRO CODE GENERATION (E.G. PROJECT BUILD) WILL RESULT IN THE LOSS
// OF IMPORT STATEMENTS.
//
//@@begin imports
import java.io.File;
import java.io.FileInputStream;
import java.util.Calendar;
import java.util.GregorianCalendar;

import jxl.HeaderFooter;
import jxl.SheetSettings;
import jxl.Workbook;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.format.PageOrientation;
import jxl.format.PaperSize;
import jxl.format.UnderlineStyle;
import jxl.format.VerticalAlignment;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import com.monsanto.xrpm.wdp.IPrivateView_Rep;
import com.sap.tc.webdynpro.clientserver.uielib.standard.api.IWDTreeByNestingTableColumn;
import com.sap.tc.webdynpro.clientserver.uielib.standard.api.WDTableCellDesign;
import com.sap.tc.webdynpro.progmodel.api.WDVisibility;
import com.sap.tc.webdynpro.services.sal.url.api.IWDCachedWebResource;
import com.sap.tc.webdynpro.services.sal.url.api.WDWebResource;
import com.sap.tc.webdynpro.services.sal.url.api.WDWebResourceType;
//@@end

//@@begin documentation
//@@end

public class View_Rep
{
  /**
   * Logging location.
   */
  private static final com.sap.tc.logging.Location logger = 
    com.sap.tc.logging.Location.getLocation(View_Rep.class);

  static 
  {
    //@@begin id
    String id = "$Id$";
    //@@end
    com.sap.tc.logging.Location.getLocation("ID.com.sap.tc.webdynpro").infoT(id);
  }

  /**
   * Private access to the generated Web Dynpro counterpart 
   * for this controller class.  </p>
   *
   * Use <code>wdThis</code> to gain typed access to the context,
   * to trigger navigation via outbound plugs, to get and enable/disable
   * actions, fire declared events, and access used controllers and/or 
   * component usages.
   *
   * @see com.monsanto.xrpm.wdp.IPrivateView_Rep for more details
   */
  private final IPrivateView_Rep wdThis;

  /**
   * Root node of this controller's context. </p>
   *
   * Provides typed access not only to the elements of the root node 
   * but also to all nodes in the context (methods node<i>XYZ</i>()) 
   * and their currently selected element (methods current<i>XYZ</i>Element()). 
   * It also facilitates the creation of new elements for all nodes 
   * (methods create<i>XYZ</i>Element()). </p>
   *
   * @see com.monsanto.xrpm.wdp.IPrivateView_Rep.IContextNode for more details.
   */
  private final IPrivateView_Rep.IContextNode wdContext;

  /**
   * A shortcut for <code>wdThis.wdGetAPI()</code>. </p>
   * 
   * Represents the generic API of the generic Web Dynpro counterpart 
   * for this controller. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDViewController wdControllerAPI;
  
  /**
   * A shortcut for <code>wdThis.wdGetAPI().getComponent()</code>. </p>
   * 
   * Represents the generic API of the Web Dynpro component this controller 
   * belongs to. Can be used to access the message manager, the window manager,
   * to add/remove event handlers and so on. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdComponentAPI;
  
  public View_Rep(IPrivateView_Rep wdThis)
  {
    this.wdThis = wdThis;
    this.wdContext = wdThis.wdGetContext();
    this.wdControllerAPI = wdThis.wdGetAPI();
    this.wdComponentAPI = wdThis.wdGetAPI().getComponent();
  }

  //@@begin javadoc:wdDoInit()
  /** Hook method called to initialize controller. */
  //@@end
  public void wdDoInit()
  {
    //@@begin wdDoInit()
	wdContext.currentContextElement().setVisible_columns(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_columns2(WDVisibility.NONE);
	wdContext.currentContextElement().setRadiobuton_selection("1");
	wdContext.currentContextElement().setRadiobutton_columns("1");

    //@@end
  }

  //@@begin javadoc:wdDoExit()
  /** Hook method called to clean up controller. */
  //@@end
  public void wdDoExit()
  {
    //@@begin wdDoExit()
    //@@end
  }

  //@@begin javadoc:wdDoModifyView
  /**
   * Hook method called to modify a view just before rendering.
   * This method conceptually belongs to the view itself, not to the
   * controller (cf. MVC pattern).
   * It is made static to discourage a way of programming that
   * routinely stores references to UI elements in instance fields
   * for access by the view controller's event handlers, and so on.
   * The Web Dynpro programming model recommends that UI elements can
   * only be accessed by code executed within the call to this hook method.
   *
   * @param wdThis Generated private interface of the view's controller, as
   *        provided by Web Dynpro. Provides access to the view controller's
   *        outgoing controller usages, etc.
   * @param wdContext Generated interface of the view's context, as provided
   *        by Web Dynpro. Provides access to the view's data.
   * @param view The view's generic API, as provided by Web Dynpro.
   *        Provides access to UI elements.
   * @param firstTime Indicates whether the hook is called for the first time
   *        during the lifetime of the view.
   */
  //@@end
  public static void wdDoModifyView(IPrivateView_Rep wdThis, IPrivateView_Rep.IContextNode wdContext, com.sap.tc.webdynpro.progmodel.api.IWDView view, boolean firstTime)
  {
    //@@begin wdDoModifyView
	if (firstTime) {
		IWDTreeByNestingTableColumn masterColumn = (IWDTreeByNestingTableColumn) view.getElement("MasterColumn");
		masterColumn.mappingOfOnLoadChildren().addSourceMapping("path", "element");
		
		IWDTreeByNestingTableColumn masterColumn2 = (IWDTreeByNestingTableColumn) view.getElement("MasterColumn2");
		masterColumn2.mappingOfOnLoadChildren().addSourceMapping("path", "element");
	}

    //@@end
  }

  //@@begin javadoc:addInitialTreeStructure()
  /** Declared method. */
  //@@end
  public void addInitialTreeStructure( )
  {
    //@@begin addInitialTreeStructure()
	IPrivateView_Rep.IFolderContentNode rootFolderContentNode = wdContext.nodeFolderContent();
	IPrivateView_Rep.IFolderContentElement rootFolderContentElement;
	int count = 0;
	for (int n=0; n < wdContext.nodeGt_Data().size(); n++) {
		if (n == 0) {
			rootFolderContentElement = rootFolderContentNode.createFolderContentElement();
			//set contained context value attributes
			rootFolderContentElement.setHierarchy_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Name1());
			rootFolderContentElement.setActualFinish_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualfinish1());
			rootFolderContentElement.setActualStart_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualstart1());
			rootFolderContentElement.setDuration_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYduration1().toString());
			rootFolderContentElement.setGrouping_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYgrouping1());
			rootFolderContentElement.setNotes_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYnotes1());
			rootFolderContentElement.setPercentageComplete_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYcompletion1());
			rootFolderContentElement.setPlannedFinish_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanfinish1());
			rootFolderContentElement.setPlannedStart_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanstart1());
			rootFolderContentElement.setSearchField_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsearchfield1());
			rootFolderContentElement.setSystemStatus_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsys_Status1());
			
			rootFolderContentElement.setHierarchy_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Name2());
			rootFolderContentElement.setActualFinish_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualfinish2());
			rootFolderContentElement.setActualStart_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualstart2());
			rootFolderContentElement.setDuration_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYduration2().toString());
			rootFolderContentElement.setGrouping_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYgrouping2());
			rootFolderContentElement.setNotes_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYnotes2());
			rootFolderContentElement.setPercentageComplete_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYcompletion2());
			rootFolderContentElement.setPlannedFinish_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanfinish2());
			rootFolderContentElement.setPlannedStart_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanstart2());
			rootFolderContentElement.setSearchField_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsearchfield2());
			rootFolderContentElement.setSystemStatus_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsys_Status2());
			rootFolderContentElement.setDisplayOnly(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYchange_Flag());
			if (rootFolderContentElement.getDisplayOnly().equalsIgnoreCase("X"))
				rootFolderContentElement.setCell_Design(WDTableCellDesign.CRITICALVALUE_MEDIUM);
			else 
				rootFolderContentElement.setCell_Design(WDTableCellDesign.STANDARD);
			rootFolderContentElement.setIsLeaf(false);
			rootFolderContentElement.setRoot(true);
			rootFolderContentElement.setChildrenLoaded(true);
			rootFolderContentElement.setLevel(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Level1());
			
			
			//---------Cell Color - to show Changes-------
			//Hierachy
			if (rootFolderContentElement.getHierarchy_proj1().compareTo(rootFolderContentElement.getHierarchy_proj2()) == 0) {
				rootFolderContentElement.setCell_Design_hierachy(WDTableCellDesign.CRITICALVALUE_MEDIUM);
			}
			else {
				rootFolderContentElement.setCell_Design_hierachy(WDTableCellDesign.GOODVALUE_LIGHT);
			}
			
			//System status
			if (rootFolderContentElement.getSystemStatus_proj1().compareTo(rootFolderContentElement.getSystemStatus_proj2()) == 0) {
				rootFolderContentElement.setCell_Design_systemStatus(WDTableCellDesign.CRITICALVALUE_MEDIUM);
			}
			else {
				rootFolderContentElement.setCell_Design_systemStatus(WDTableCellDesign.GOODVALUE_LIGHT);
			}
			
			//Actual Start
			if (rootFolderContentElement.getActualStart_proj1().compareTo(rootFolderContentElement.getActualStart_proj2()) == 0) {
				rootFolderContentElement.setCell_Design_actualStart(WDTableCellDesign.CRITICALVALUE_MEDIUM);
			}
			else {
				rootFolderContentElement.setCell_Design_actualStart(WDTableCellDesign.GOODVALUE_LIGHT);
			}
			
			//Actual Finish
			if (rootFolderContentElement.getActualFinish_proj1().compareTo(rootFolderContentElement.getActualFinish_proj2()) == 0) {
				rootFolderContentElement.setCell_Design_actualFinish(WDTableCellDesign.CRITICALVALUE_MEDIUM);
			}
			else {
				rootFolderContentElement.setCell_Design_actualFinish(WDTableCellDesign.GOODVALUE_LIGHT);
			}
			
			//Percentage Complete
			if (rootFolderContentElement.getPercentageComplete_proj1().compareTo(rootFolderContentElement.getPercentageComplete_proj2()) == 0) {
				rootFolderContentElement.setCell_Design_percentageComplete(WDTableCellDesign.CRITICALVALUE_MEDIUM);
			}
			else {
				rootFolderContentElement.setCell_Design_percentageComplete(WDTableCellDesign.GOODVALUE_LIGHT);
			}
			
			//Planned Start
			if (rootFolderContentElement.getPlannedStart_proj1().compareTo(rootFolderContentElement.getPlannedStart_proj2()) == 0) {
				rootFolderContentElement.setCell_Design_plannedStart(WDTableCellDesign.CRITICALVALUE_MEDIUM);
			}
			else {
				rootFolderContentElement.setCell_Design_plannedStart(WDTableCellDesign.GOODVALUE_LIGHT);
			}
			
			//Planned Finish
			if (rootFolderContentElement.getPlannedFinish_proj1().compareTo(rootFolderContentElement.getPlannedFinish_proj2()) == 0) {
				rootFolderContentElement.setCell_Design_plannedFinish(WDTableCellDesign.CRITICALVALUE_MEDIUM);
			}
			else {
				rootFolderContentElement.setCell_Design_plannedFinish(WDTableCellDesign.GOODVALUE_LIGHT);
			}
			
			//Duration
			if (rootFolderContentElement.getDuration_proj1().compareTo(rootFolderContentElement.getDuration_proj2()) == 0) {
				rootFolderContentElement.setCell_Design_duration(WDTableCellDesign.CRITICALVALUE_MEDIUM);
			}
			else {
				rootFolderContentElement.setCell_Design_duration(WDTableCellDesign.GOODVALUE_LIGHT);
			}
			
			//Grouping
			if (rootFolderContentElement.getGrouping_proj1().compareTo(rootFolderContentElement.getGrouping_proj2()) == 0) {
				rootFolderContentElement.setCell_Design_grouping(WDTableCellDesign.CRITICALVALUE_MEDIUM);
			}
			else {
				rootFolderContentElement.setCell_Design_grouping(WDTableCellDesign.GOODVALUE_LIGHT);
			}
			
			//Search Field
			if (rootFolderContentElement.getSearchField_proj1().compareTo(rootFolderContentElement.getSearchField_proj2()) == 0) {
				rootFolderContentElement.setCell_Design_searchField(WDTableCellDesign.CRITICALVALUE_MEDIUM);
			}
			else {
				rootFolderContentElement.setCell_Design_searchField(WDTableCellDesign.GOODVALUE_LIGHT);
			}
			
			//wdComponentAPI.getMessageManager().reportSuccess("test");
			//Notes
			if (!wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("3") && !wdContext.currentContextElement().getProj2_radiobutton().equalsIgnoreCase("3")) {
				if (rootFolderContentElement.getNotes_proj1().compareTo(rootFolderContentElement.getNotes_proj2()) == 0) {
					rootFolderContentElement.setCell_Design_notes(WDTableCellDesign.CRITICALVALUE_MEDIUM);
				}
				else {
					rootFolderContentElement.setCell_Design_notes(WDTableCellDesign.GOODVALUE_LIGHT);
				}
			}
			else {
				rootFolderContentElement.setCell_Design_notes(WDTableCellDesign.CRITICALVALUE_MEDIUM);
			}
			
			if (rootFolderContentElement.getCell_Design_hierachy().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
				rootFolderContentElement.getCell_Design_systemStatus().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
				rootFolderContentElement.getCell_Design_actualStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
				rootFolderContentElement.getCell_Design_actualFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
				rootFolderContentElement.getCell_Design_percentageComplete().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
				rootFolderContentElement.getCell_Design_plannedStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
				rootFolderContentElement.getCell_Design_plannedFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
				rootFolderContentElement.getCell_Design_duration().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
				rootFolderContentElement.getCell_Design_grouping().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
				rootFolderContentElement.getCell_Design_searchField().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
				rootFolderContentElement.getCell_Design_notes().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					rootFolderContentElement.setCell_Design_hierachy(WDTableCellDesign.STANDARD);
					rootFolderContentElement.setCell_Design_systemStatus(WDTableCellDesign.STANDARD);
					rootFolderContentElement.setCell_Design_actualStart(WDTableCellDesign.STANDARD);
					rootFolderContentElement.setCell_Design_actualFinish(WDTableCellDesign.STANDARD);
					rootFolderContentElement.setCell_Design_percentageComplete(WDTableCellDesign.STANDARD);
					rootFolderContentElement.setCell_Design_plannedStart(WDTableCellDesign.STANDARD);
					rootFolderContentElement.setCell_Design_plannedFinish(WDTableCellDesign.STANDARD);
					rootFolderContentElement.setCell_Design_duration(WDTableCellDesign.STANDARD);
					rootFolderContentElement.setCell_Design_grouping(WDTableCellDesign.STANDARD);
					rootFolderContentElement.setCell_Design_searchField(WDTableCellDesign.STANDARD);
					rootFolderContentElement.setCell_Design_notes(WDTableCellDesign.STANDARD);
			}
			
			//--------------------------
			
			// add root folder element to root folder node
			rootFolderContentNode.addElement(rootFolderContentElement);
			
			rootFolderContentElement.setExpanded(true);
			count = 0;
			temp_element = rootFolderContentElement;
		}
		else
			if (wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Level1() == 0 || temp_element.getLevel() + 1 == wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Level1()) {
				if (wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Level1() == 0) {
					
					if (!temp_element.getRoot()) {
						IPrivateView_Rep.IFolderContentElement temp = (IPrivateView_Rep.IFolderContentElement) temp_element;
						temp.setIsLeaf(true);
						temp.setExpanded(false);
						temp.setChildrenLoaded(false);
					}
					
					IPrivateView_Rep.IFolderContentNode folderContentNode = wdContext.currentFolderContentElement().nodeChildNode();
					IPrivateView_Rep.IFolderContentElement folderContentElement;
					folderContentElement = folderContentNode.createFolderContentElement();
						
					folderContentElement.setHierarchy_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Name1());
					
					folderContentElement.setActualFinish_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualfinish1());
					folderContentElement.setActualStart_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualstart1());
					folderContentElement.setDuration_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYduration1().toString());
					folderContentElement.setGrouping_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYgrouping1());
					folderContentElement.setNotes_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYnotes1());
					folderContentElement.setPercentageComplete_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYcompletion1());
					folderContentElement.setPlannedFinish_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanfinish1());
					folderContentElement.setPlannedStart_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanstart1());
					folderContentElement.setSearchField_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsearchfield1());
					folderContentElement.setSystemStatus_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsys_Status1());
					
					folderContentElement.setHierarchy_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Name2());
					folderContentElement.setActualFinish_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualfinish2());
					folderContentElement.setActualStart_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualstart2());
					folderContentElement.setDuration_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYduration2().toString());
					folderContentElement.setGrouping_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYgrouping2());
					folderContentElement.setNotes_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYnotes2());
					folderContentElement.setPercentageComplete_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYcompletion2());
					folderContentElement.setPlannedFinish_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanfinish2());
					folderContentElement.setPlannedStart_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanstart2());
					folderContentElement.setSearchField_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsearchfield2());
					folderContentElement.setSystemStatus_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsys_Status2());
					folderContentElement.setDisplayOnly(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYchange_Flag());
					if (folderContentElement.getDisplayOnly().equalsIgnoreCase("X"))
						folderContentElement.setCell_Design(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					else 
						folderContentElement.setCell_Design(WDTableCellDesign.STANDARD);
					
					folderContentElement.setRoot(false);
					folderContentElement.setLevel(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Level1());
					temp_element = folderContentElement;
					folderContentElement.setExpanded(true);
					folderContentElement.setIsLeaf(false);
					folderContentElement.setRoot(false);
					folderContentElement.setChildrenLoaded(true);
					
					//---------Cell color - to show Changes-------
					//Hierachy
					if (folderContentElement.getHierarchy_proj1().compareTo(folderContentElement.getHierarchy_proj2()) == 0) {
						folderContentElement.setCell_Design_hierachy(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_hierachy(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//System status
					if (folderContentElement.getSystemStatus_proj1().compareTo(folderContentElement.getSystemStatus_proj2()) == 0) {
						folderContentElement.setCell_Design_systemStatus(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_systemStatus(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Actual Start
					if (folderContentElement.getActualStart_proj1().compareTo(folderContentElement.getActualStart_proj2()) == 0) {
						folderContentElement.setCell_Design_actualStart(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_actualStart(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Actual Finish
					if (folderContentElement.getActualFinish_proj1().compareTo(folderContentElement.getActualFinish_proj2()) == 0) {
						folderContentElement.setCell_Design_actualFinish(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_actualFinish(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Percentage Complete
					if (folderContentElement.getPercentageComplete_proj1().compareTo(folderContentElement.getPercentageComplete_proj2()) == 0) {
						folderContentElement.setCell_Design_percentageComplete(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_percentageComplete(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Planned Start
					if (folderContentElement.getPlannedStart_proj1().compareTo(folderContentElement.getPlannedStart_proj2()) == 0) {
						folderContentElement.setCell_Design_plannedStart(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_plannedStart(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Planned Finish
					if (folderContentElement.getPlannedFinish_proj1().compareTo(folderContentElement.getPlannedFinish_proj2()) == 0) {
						folderContentElement.setCell_Design_plannedFinish(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_plannedFinish(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Duration
					if (folderContentElement.getDuration_proj1().compareTo(folderContentElement.getDuration_proj2()) == 0) {
						folderContentElement.setCell_Design_duration(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_duration(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Grouping
					if (folderContentElement.getGrouping_proj1().compareTo(folderContentElement.getGrouping_proj2()) == 0) {
						folderContentElement.setCell_Design_grouping(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_grouping(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Search Field
					if (folderContentElement.getSearchField_proj1().compareTo(folderContentElement.getSearchField_proj2()) == 0) {
						folderContentElement.setCell_Design_searchField(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_searchField(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Notes
					if (!wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("3") && !wdContext.currentContextElement().getProj2_radiobutton().equalsIgnoreCase("3")) {
						if (folderContentElement.getNotes_proj1().compareTo(folderContentElement.getNotes_proj2()) == 0) {
							folderContentElement.setCell_Design_notes(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						else {
							folderContentElement.setCell_Design_notes(WDTableCellDesign.GOODVALUE_LIGHT);
						}
					}
					else {
						folderContentElement.setCell_Design_notes(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					
					
					if (folderContentElement.getCell_Design_hierachy().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_systemStatus().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_actualStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_actualFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_percentageComplete().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_plannedStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_plannedFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_duration().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_grouping().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_searchField().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_notes().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
							folderContentElement.setCell_Design_hierachy(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_systemStatus(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_actualStart(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_actualFinish(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_percentageComplete(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_plannedStart(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_plannedFinish(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_duration(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_grouping(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_searchField(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_notes(WDTableCellDesign.STANDARD);
					}
					//--------------------------
					
					folderContentNode.addElement(folderContentElement);
					count++;
				}
				else {
					IPrivateView_Rep.IFolderContentNode folderContentNode = temp_element.nodeChildNode();
					IPrivateView_Rep.IFolderContentElement folderContentElement;
					folderContentElement = folderContentNode.createFolderContentElement();
					folderContentElement.setHierarchy_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Name1());
					folderContentElement.setActualFinish_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualfinish1());
					folderContentElement.setActualStart_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualstart1());
					folderContentElement.setDuration_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYduration1().toString());
					folderContentElement.setGrouping_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYgrouping1());
					folderContentElement.setNotes_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYnotes1());
					folderContentElement.setPercentageComplete_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYcompletion1());
					folderContentElement.setPlannedFinish_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanfinish1());
					folderContentElement.setPlannedStart_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanstart1());
					folderContentElement.setSearchField_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsearchfield1());
					folderContentElement.setSystemStatus_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsys_Status1());
					
					folderContentElement.setHierarchy_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Name2());
					folderContentElement.setActualFinish_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualfinish2());
					folderContentElement.setActualStart_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualstart2());
					folderContentElement.setDuration_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYduration2().toString());
					folderContentElement.setGrouping_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYgrouping2());
					folderContentElement.setNotes_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYnotes2());
					folderContentElement.setPercentageComplete_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYcompletion2());
					folderContentElement.setPlannedFinish_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanfinish2());
					folderContentElement.setPlannedStart_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanstart2());
					folderContentElement.setSearchField_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsearchfield2());
					folderContentElement.setSystemStatus_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsys_Status2());
					folderContentElement.setDisplayOnly(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYchange_Flag());
					if (folderContentElement.getDisplayOnly().equalsIgnoreCase("X"))
						folderContentElement.setCell_Design(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					else 
						folderContentElement.setCell_Design(WDTableCellDesign.STANDARD);
					folderContentElement.setRoot(false);
					folderContentElement.setLevel(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Level1());
					temp_element = folderContentElement;
					
					//---------Cell color - to show Changes-------
					//Hierachy
					if (folderContentElement.getHierarchy_proj1().compareTo(folderContentElement.getHierarchy_proj2()) == 0) {
						folderContentElement.setCell_Design_hierachy(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_hierachy(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//System status
					if (folderContentElement.getSystemStatus_proj1().compareTo(folderContentElement.getSystemStatus_proj2()) == 0) {
						folderContentElement.setCell_Design_systemStatus(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_systemStatus(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Actual Start
					if (folderContentElement.getActualStart_proj1().compareTo(folderContentElement.getActualStart_proj2()) == 0) {
						folderContentElement.setCell_Design_actualStart(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_actualStart(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Actual Finish
					if (folderContentElement.getActualFinish_proj1().compareTo(folderContentElement.getActualFinish_proj2()) == 0) {
						folderContentElement.setCell_Design_actualFinish(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_actualFinish(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Percentage Complete
					if (folderContentElement.getPercentageComplete_proj1().compareTo(folderContentElement.getPercentageComplete_proj2()) == 0) {
						folderContentElement.setCell_Design_percentageComplete(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_percentageComplete(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Planned Start
					if (folderContentElement.getPlannedStart_proj1().compareTo(folderContentElement.getPlannedStart_proj2()) == 0) {
						folderContentElement.setCell_Design_plannedStart(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_plannedStart(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Planned Finish
					if (folderContentElement.getPlannedFinish_proj1().compareTo(folderContentElement.getPlannedFinish_proj2()) == 0) {
						folderContentElement.setCell_Design_plannedFinish(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_plannedFinish(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Duration
					if (folderContentElement.getDuration_proj1().compareTo(folderContentElement.getDuration_proj2()) == 0) {
						folderContentElement.setCell_Design_duration(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_duration(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Grouping
					if (folderContentElement.getGrouping_proj1().compareTo(folderContentElement.getGrouping_proj2()) == 0) {
						folderContentElement.setCell_Design_grouping(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_grouping(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Search Field
					if (folderContentElement.getSearchField_proj1().compareTo(folderContentElement.getSearchField_proj2()) == 0) {
						folderContentElement.setCell_Design_searchField(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
					else {
						folderContentElement.setCell_Design_searchField(WDTableCellDesign.GOODVALUE_LIGHT);
					}
			
					//Notes
					if (!wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("3") && !wdContext.currentContextElement().getProj2_radiobutton().equalsIgnoreCase("3")) {
						if (folderContentElement.getNotes_proj1().compareTo(folderContentElement.getNotes_proj2()) == 0) {
							folderContentElement.setCell_Design_notes(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						else {
							folderContentElement.setCell_Design_notes(WDTableCellDesign.GOODVALUE_LIGHT);
						}
					}
					else {
						folderContentElement.setCell_Design_notes(WDTableCellDesign.CRITICALVALUE_MEDIUM);
					}
						
					
					if (folderContentElement.getCell_Design_hierachy().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_systemStatus().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_actualStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_actualFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_percentageComplete().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_plannedStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_plannedFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_duration().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_grouping().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_searchField().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
						folderContentElement.getCell_Design_notes().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
							folderContentElement.setCell_Design_hierachy(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_systemStatus(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_actualStart(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_actualFinish(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_percentageComplete(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_plannedStart(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_plannedFinish(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_duration(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_grouping(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_searchField(WDTableCellDesign.STANDARD);
							folderContentElement.setCell_Design_notes(WDTableCellDesign.STANDARD);
					}
					//--------------------------				
					
					folderContentNode.addElement(folderContentElement);
					folderContentElement.setExpanded(true);
					folderContentElement.setRoot(false);
					folderContentElement.setChildrenLoaded(true);
					folderContentElement.setIsLeaf(false);
					count++;			
				}
			}
			else {	
				IPrivateView_Rep.IFolderContentElement temp = (IPrivateView_Rep.IFolderContentElement) temp_element;
				temp.setIsLeaf(true);
				temp.setExpanded(false);
				temp.setChildrenLoaded(false);
							
				IPrivateView_Rep.IFolderContentElement par = (IPrivateView_Rep.IFolderContentElement) temp_element.node().getParentElement();
				while (!par.getRoot()) {
					if (par.getLevel() + 1 == wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Level1()) {
						IPrivateView_Rep.IFolderContentNode folderContentNode = par.nodeChildNode();
						IPrivateView_Rep.IFolderContentElement folderContentElement;
						folderContentElement = folderContentNode.createFolderContentElement();
						folderContentElement.setHierarchy_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Name1());
						folderContentElement.setActualFinish_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualfinish1());
						folderContentElement.setActualStart_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualstart1());
						folderContentElement.setDuration_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYduration1().toString());
						folderContentElement.setGrouping_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYgrouping1());
						folderContentElement.setNotes_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYnotes1());
						folderContentElement.setPercentageComplete_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYcompletion1());
						folderContentElement.setPlannedFinish_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanfinish1());
						folderContentElement.setPlannedStart_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanstart1());
						folderContentElement.setSearchField_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsearchfield1());
						folderContentElement.setSystemStatus_proj1(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsys_Status1());
					
						folderContentElement.setHierarchy_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Name2());
						folderContentElement.setActualFinish_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualfinish2());
						folderContentElement.setActualStart_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYactualstart2());
						folderContentElement.setDuration_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYduration2().toString());
						folderContentElement.setGrouping_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYgrouping2());
						folderContentElement.setNotes_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYnotes2());
						folderContentElement.setPercentageComplete_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYcompletion2());
						folderContentElement.setPlannedFinish_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanfinish2());
						folderContentElement.setPlannedStart_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYplanstart2());
						folderContentElement.setSearchField_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsearchfield2());
						folderContentElement.setSystemStatus_proj2(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYsys_Status2());
						folderContentElement.setDisplayOnly(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYchange_Flag());
						if (folderContentElement.getDisplayOnly().equalsIgnoreCase("X"))
							folderContentElement.setCell_Design(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						else 
							folderContentElement.setCell_Design(WDTableCellDesign.STANDARD);
						folderContentElement.setRoot(false);
						folderContentElement.setLevel(wdContext.nodeGt_Data().getGt_DataElementAt(n).getYtask_Level1());
						temp_element = folderContentElement;
						folderContentElement.setExpanded(true);
						folderContentElement.setIsLeaf(false);
						folderContentElement.setRoot(false);
						folderContentElement.setChildrenLoaded(true);
						
						//---------Cell color - to show Changes-------
						//Hierachy
						if (folderContentElement.getHierarchy_proj1().compareTo(folderContentElement.getHierarchy_proj2()) == 0) {
							folderContentElement.setCell_Design_hierachy(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						else {
							folderContentElement.setCell_Design_hierachy(WDTableCellDesign.GOODVALUE_LIGHT);
						}
			
						//System status
						if (folderContentElement.getSystemStatus_proj1().compareTo(folderContentElement.getSystemStatus_proj2()) == 0) {
							folderContentElement.setCell_Design_systemStatus(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						else {
							folderContentElement.setCell_Design_systemStatus(WDTableCellDesign.GOODVALUE_LIGHT);
						}
			
						//Actual Start
						if (folderContentElement.getActualStart_proj1().compareTo(folderContentElement.getActualStart_proj2()) == 0) {
							folderContentElement.setCell_Design_actualStart(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						else {
							folderContentElement.setCell_Design_actualStart(WDTableCellDesign.GOODVALUE_LIGHT);
						}
			
						//Actual Finish
						if (folderContentElement.getActualFinish_proj1().compareTo(folderContentElement.getActualFinish_proj2()) == 0) {
							folderContentElement.setCell_Design_actualFinish(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						else {
							folderContentElement.setCell_Design_actualFinish(WDTableCellDesign.GOODVALUE_LIGHT);
						}
			
						//Percentage Complete
						if (folderContentElement.getPercentageComplete_proj1().compareTo(folderContentElement.getPercentageComplete_proj2()) == 0) {
							folderContentElement.setCell_Design_percentageComplete(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						else {
							folderContentElement.setCell_Design_percentageComplete(WDTableCellDesign.GOODVALUE_LIGHT);
						}
			
						//Planned Start
						if (folderContentElement.getPlannedStart_proj1().compareTo(folderContentElement.getPlannedStart_proj2()) == 0) {
							folderContentElement.setCell_Design_plannedStart(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						else {
							folderContentElement.setCell_Design_plannedStart(WDTableCellDesign.GOODVALUE_LIGHT);
						}
			
						//Planned Finish
						if (folderContentElement.getPlannedFinish_proj1().compareTo(folderContentElement.getPlannedFinish_proj2()) == 0) {
							folderContentElement.setCell_Design_plannedFinish(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						else {
							folderContentElement.setCell_Design_plannedFinish(WDTableCellDesign.GOODVALUE_LIGHT);
						}
			
						//Duration
						if (folderContentElement.getDuration_proj1().compareTo(folderContentElement.getDuration_proj2()) == 0) {
							folderContentElement.setCell_Design_duration(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						else {
							folderContentElement.setCell_Design_duration(WDTableCellDesign.GOODVALUE_LIGHT);
						}
			
						//Grouping
						if (folderContentElement.getGrouping_proj1().compareTo(folderContentElement.getGrouping_proj2()) == 0) {
							folderContentElement.setCell_Design_grouping(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						else {
							folderContentElement.setCell_Design_grouping(WDTableCellDesign.GOODVALUE_LIGHT);
						}
			
						//Search Field
						if (folderContentElement.getSearchField_proj1().compareTo(folderContentElement.getSearchField_proj2()) == 0) {
							folderContentElement.setCell_Design_searchField(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						else {
							folderContentElement.setCell_Design_searchField(WDTableCellDesign.GOODVALUE_LIGHT);
						}
			
						//Notes
						if (!wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("3") && !wdContext.currentContextElement().getProj2_radiobutton().equalsIgnoreCase("3")) {
							if (folderContentElement.getNotes_proj1().compareTo(folderContentElement.getNotes_proj2()) == 0) {
								folderContentElement.setCell_Design_notes(WDTableCellDesign.CRITICALVALUE_MEDIUM);
							}
							else {
								folderContentElement.setCell_Design_notes(WDTableCellDesign.GOODVALUE_LIGHT);
							}
						}
						else {
							folderContentElement.setCell_Design_notes(WDTableCellDesign.CRITICALVALUE_MEDIUM);
						}
						
						if (folderContentElement.getCell_Design_hierachy().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
							folderContentElement.getCell_Design_systemStatus().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
							folderContentElement.getCell_Design_actualStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
							folderContentElement.getCell_Design_actualFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
							folderContentElement.getCell_Design_percentageComplete().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
							folderContentElement.getCell_Design_plannedStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
							folderContentElement.getCell_Design_plannedFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
							folderContentElement.getCell_Design_duration().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
							folderContentElement.getCell_Design_grouping().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
							folderContentElement.getCell_Design_searchField().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM) &&
							folderContentElement.getCell_Design_notes().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								folderContentElement.setCell_Design_hierachy(WDTableCellDesign.STANDARD);
								folderContentElement.setCell_Design_systemStatus(WDTableCellDesign.STANDARD);
								folderContentElement.setCell_Design_actualStart(WDTableCellDesign.STANDARD);
								folderContentElement.setCell_Design_actualFinish(WDTableCellDesign.STANDARD);
								folderContentElement.setCell_Design_percentageComplete(WDTableCellDesign.STANDARD);
								folderContentElement.setCell_Design_plannedStart(WDTableCellDesign.STANDARD);
								folderContentElement.setCell_Design_plannedFinish(WDTableCellDesign.STANDARD);
								folderContentElement.setCell_Design_duration(WDTableCellDesign.STANDARD);
								folderContentElement.setCell_Design_grouping(WDTableCellDesign.STANDARD);
								folderContentElement.setCell_Design_searchField(WDTableCellDesign.STANDARD);
								folderContentElement.setCell_Design_notes(WDTableCellDesign.STANDARD);
						}
						//--------------------------
												
						folderContentNode.addElement(folderContentElement);
						count++;			
						break;
					}
					else {
						par = (IPrivateView_Rep.IFolderContentElement) par.node().getParentElement();
					}
				}			
				
			}
	}
	
	if (wdContext.nodeGt_Data().size() > 0) {
		IPrivateView_Rep.IFolderContentElement temp_last_ele = (IPrivateView_Rep.IFolderContentElement) temp_element;
		temp_last_ele.setIsLeaf(true);
		temp_last_ele.setChildrenLoaded(false);
	}
		
    //@@end
  }

  //@@begin javadoc:recursive_collapse()
  /** Declared method. */
  //@@end
  public void recursive_collapse( com.monsanto.xrpm.wdp.IPrivateView_Rep.IFolderContentElement element )
  {
    //@@begin recursive_collapse()
	if (element.getChildrenLoaded()) {
		IPrivateView_Rep.IFolderContentNode child_node = element.nodeChildNode();
		for (int p=0; p < child_node.size(); p++) {
			if (child_node.getFolderContentElementAt(p).getChildrenLoaded()) {
				child_node.getFolderContentElementAt(p).setExpanded(false);
				wdThis.recursive_collapse(child_node.getFolderContentElementAt(p));	
			}
		}
	}
    //@@end
  }

  //@@begin javadoc:recursive_expand()
  /** Declared method. */
  //@@end
  public void recursive_expand( com.monsanto.xrpm.wdp.IPrivateView_Rep.IFolderContentElement element )
  {
    //@@begin recursive_expand()
    if (element.getChildrenLoaded()) {
		IPrivateView_Rep.IFolderContentNode child_node = element.nodeChildNode();
		for (int p=0; p < child_node.size(); p++) {
			if (child_node.getFolderContentElementAt(p).getChildrenLoaded()) {
				child_node.getFolderContentElementAt(p).setExpanded(true);
				wdThis.recursive_expand(child_node.getFolderContentElementAt(p));	
			}
		}
	}
    //@@end
  }

  //@@begin javadoc:recursive_remove_leafs()
  /** Declared method. */
  //@@end
  public void recursive_remove_leafs( com.monsanto.xrpm.wdp.IPrivateView_Rep.IFolderContentElement element )
  {
    //@@begin recursive_remove_leafs()
	if (element.getChildrenLoaded()) {
		IPrivateView_Rep.IFolderContentNode child_node = element.nodeChildNode();
		for (int p = child_node.size() - 1; p >= 0; --p) {
			if (child_node.getFolderContentElementAt(p).getChildrenLoaded()) {
				wdThis.recursive_remove_leafs(child_node.getFolderContentElementAt(p));	
			}
			else {
				if (!child_node.getFolderContentElementAt(p).getDisplayOnly().equalsIgnoreCase("X")) {
					parent_leaf = false;
					IPrivateView_Rep.IFolderContentElement parent = (IPrivateView_Rep.IFolderContentElement) child_node.getParentElement();
					if (child_node.size() == 1) {
						parent.setIsLeaf(true);
						parent.setExpanded(false);
						parent.setChildrenLoaded(false);
						parent_leaf = true;
					}
					
					child_node.removeElement(child_node.getFolderContentElementAt(p));
						
					while (!parent.getRoot() && parent_leaf) {
						IPrivateView_Rep.IFolderContentElement grand_parent = (IPrivateView_Rep.IFolderContentElement) parent.node().getParentElement();	
						parent_leaf = false;
						
						if (parent.node().size() == 1) {
							grand_parent.setIsLeaf(true);
							grand_parent.setExpanded(false); 
							grand_parent.setChildrenLoaded(false);
							parent_leaf = true;
						}
						
						if (!parent.getDisplayOnly().equalsIgnoreCase("X"))
							parent.node().removeElement(parent);
						
						parent = grand_parent;
					}
				}
			}
		}
	}
    //@@end
  }

  //@@begin javadoc:exporttoexcel_jxl()
  /** Declared method. */
  //@@end
  public void exporttoexcel_jxl( )
  {
    //@@begin exporttoexcel_jxl()
	//	-----------Export to Excel - Jexcel API------------------
		Calendar cal = new GregorianCalendar();
		String fileName = "Schedule Variance Report" + cal.getTimeInMillis() + ".xls";
		IWDCachedWebResource cachedExcelResource = null;
		try {
			File f = new File(fileName);
			WritableWorkbook workbook =	Workbook.createWorkbook(f);
 
			WritableFont red = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.BOLD, false, UnderlineStyle.SINGLE, Colour.RED);
			WritableCellFormat redFormat = new WritableCellFormat(red);
			redFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
			redFormat.setVerticalAlignment(VerticalAlignment.TOP);
						
			WritableFont black = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.AUTOMATIC);
			WritableCellFormat blackFormat = new WritableCellFormat(black);
			blackFormat.setWrap(true);
			blackFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
			blackFormat.setVerticalAlignment(VerticalAlignment.TOP);
			
			WritableFont black_ = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.AUTOMATIC);
			WritableCellFormat blackFormat_ = new WritableCellFormat(black_);
			blackFormat_.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
			blackFormat_.setVerticalAlignment(VerticalAlignment.TOP);
			
			WritableFont blue = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLUE2);
			WritableCellFormat blueFormat = new WritableCellFormat(blue);
			blueFormat.setWrap(true);
			blueFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
			blueFormat.setVerticalAlignment(VerticalAlignment.TOP);
			
			WritableFont blue_backgroundcolour = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLUE2);
			WritableCellFormat blueFormat_backgroundcolour = new WritableCellFormat(blue_backgroundcolour);
			blueFormat_backgroundcolour.setWrap(true);
			blueFormat_backgroundcolour.setBackground(Colour.VERY_LIGHT_YELLOW);
			blueFormat_backgroundcolour.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
			blueFormat_backgroundcolour.setVerticalAlignment(VerticalAlignment.TOP);
			
			WritableFont black_backgroundcolor = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.AUTOMATIC);
			WritableCellFormat blackFormat_backgroundcolor = new WritableCellFormat(black_backgroundcolor);
			blackFormat_backgroundcolor.setWrap(true);
			blackFormat_backgroundcolor.setBackground(Colour.VERY_LIGHT_YELLOW);
			blackFormat_backgroundcolor.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
			blackFormat_backgroundcolor.setVerticalAlignment(VerticalAlignment.TOP);
			
			WritableFont blue_backgroundcolour1 = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLUE2);
			WritableCellFormat blueFormat_backgroundcolour1 = new WritableCellFormat(blue_backgroundcolour1);
			blueFormat_backgroundcolour1.setWrap(true);
			blueFormat_backgroundcolour1.setBackground(Colour.LIGHT_GREEN);
			blueFormat_backgroundcolour1.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
			blueFormat_backgroundcolour1.setVerticalAlignment(VerticalAlignment.TOP);
			
			WritableFont black_backgroundcolor1 = new WritableFont(WritableFont.ARIAL, WritableFont.DEFAULT_POINT_SIZE, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.AUTOMATIC);
			WritableCellFormat blackFormat_backgroundcolor1 = new WritableCellFormat(black_backgroundcolor1);
			blackFormat_backgroundcolor1.setWrap(true);
			blackFormat_backgroundcolor1.setBackground(Colour.LIGHT_GREEN);
			blackFormat_backgroundcolor1.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
			blackFormat_backgroundcolor1.setVerticalAlignment(VerticalAlignment.TOP);
			
			WritableSheet sheet = workbook.createSheet("Schedule Variance Report", 0);
			
			//================ Headings ================
			SheetSettings setting = sheet.getSettings( );
			setting.setPrintGridLines(true);
			setting.setFitToPages(true);
			setting.setFitWidth(1);	
			setting.setRightMargin(0.2);
			setting.setLeftMargin(0.2);
			setting.setTopMargin(0.5);
			setting.setBottomMargin(.5);
			setting.setFooterMargin(0.25);
			setting.setHeaderMargin(0.25);
			setting.setHorizontalCentre(true);
			//setting.setVerticalCentre(true); 
				
			HeaderFooter header = new HeaderFooter();
			
			HeaderFooter.Contents header_content_left = header.getLeft();
			header_content_left.append("Global Project Management Variance Report");
			header_content_left.setFontSize(8);
			
			HeaderFooter.Contents header_content_right = header.getRight();
			header_content_right.append("Printed on ");
			header_content_right.appendDate();
			header_content_right.append(" at ");
			header_content_right.appendTime();
			header_content_right.setFontSize(8);			
			
			HeaderFooter footer = new HeaderFooter();
			
			HeaderFooter.Contents footer_content_left = footer.getLeft();
			footer_content_left.append(wdContext.currentContextElement().getHeader_ver1() + " and " + wdContext.currentContextElement().getHeader_ver2());
			footer_content_left.setFontSize(8);
			
			HeaderFooter.Contents footer_content_centre = footer.getCentre();
			footer_content_centre.append("Monsanto Company Confidential");
			footer_content_centre.setFontSize(8);
			
			HeaderFooter.Contents footer_content_right = footer.getRight();
			footer_content_right.append("Page ");
			footer_content_right.appendPageNumber();
			footer_content_right.append(" of ");
			footer_content_right.appendTotalPages();
			footer_content_right.setFontSize(8);
			
			setting.setFooter(footer);
			setting.setHeader(header); 
			
			setting.setPaperSize(PaperSize.TABLOID);
			setting.setOrientation(PageOrientation.LANDSCAPE);
			Label label;
			
			
			//with all columns
			if (wdContext.currentContextElement().getRadiobutton_columns().equalsIgnoreCase("1")) {
				label = new Label(0, 0, "Hierarchy",redFormat);
				sheet.addCell(label);
			
				label = new Label(1, 0,"System Status",redFormat);
				sheet.addCell(label);
		
				label = new Label(2,0,"Actual Start",redFormat);
				sheet.addCell(label);
			
				label = new Label(3,0,"Actual Finish",redFormat);
				sheet.addCell(label);
			
				label = new Label(4,0,"Perc. Complete / %",redFormat);
				sheet.addCell(label);
			
				label = new Label(5,0,"Planned Start",redFormat);
				sheet.addCell(label);
			
				label = new Label(6,0,"Planned Finish",redFormat);
				sheet.addCell(label);
			
				label = new Label(7,0,"Duration",redFormat);
				sheet.addCell(label);
			
				label = new Label(8,0,"Grouping",redFormat);
				sheet.addCell(label);
			
				label = new Label(9,0,"Search Field",redFormat);
				sheet.addCell(label);
				
				label = new Label(10,0,"Notes",redFormat);
				sheet.addCell(label);
				
				label = new Label(11,0,"Hierarchy",redFormat);
				sheet.addCell(label);
			
				label = new Label(12,0,"System Status",redFormat);
				sheet.addCell(label);
		
				label = new Label(13,0,"Actual Start",redFormat);
				sheet.addCell(label);
			
				label = new Label(14,0,"Actual Finish",redFormat);
				sheet.addCell(label);
			
				label = new Label(15,0,"Perc. Complete / %",redFormat);
				sheet.addCell(label);
			
				label = new Label(16,0,"Planned Start",redFormat);
				sheet.addCell(label);
			
				label = new Label(17,0,"Planned Finish",redFormat);
				sheet.addCell(label);
			
				label = new Label(18,0,"Duration",redFormat);
				sheet.addCell(label);
			
				label = new Label(19,0,"Grouping",redFormat);
				sheet.addCell(label);
			   
				label = new Label(20,0,"Search Field",redFormat);
				sheet.addCell(label);
			   
				label = new Label(21,0,"Notes",redFormat);
				sheet.addCell(label);
			}
			else { //For fewer columns
				label = new Label(0, 0, "Hierarchy",redFormat);
				sheet.addCell(label);
		
				label = new Label(1, 0,"System Status",redFormat);
				sheet.addCell(label);
				
				label = new Label(2,0,"Planned Start",redFormat);
				sheet.addCell(label);
		
				label = new Label(3,0,"Planned Finish",redFormat);
				sheet.addCell(label);
				
				label = new Label(4,0,"Hierarchy",redFormat);
				sheet.addCell(label);
		
				label = new Label(5,0,"System Status",redFormat);
				sheet.addCell(label);
				
				label = new Label(6,0,"Planned Start",redFormat);
				sheet.addCell(label);
		
				label = new Label(7,0,"Planned Finish",redFormat);
				sheet.addCell(label);
			}
			
			IPrivateView_Rep.IFolderContentNode root = wdContext.nodeFolderContent();
			for (int b=0; b < wdContext.nodeFolderContent().size(); b++) {
				wdThis.recursive_excel_export(root.getFolderContentElementAt(b), label, sheet, blueFormat, blackFormat, blueFormat_backgroundcolour, blackFormat_backgroundcolor, blueFormat_backgroundcolour1, blackFormat_backgroundcolor1);
			}

			//with all columns
			if (wdContext.currentContextElement().getRadiobutton_columns().equalsIgnoreCase("1")) {

				//Set Column Width
				sheet.setColumnView(0, 50);
				sheet.setColumnView(1, 17);
				sheet.setColumnView(2, 16);
				sheet.setColumnView(3, 16);
				sheet.setColumnView(4, 18);
				sheet.setColumnView(5, 16);
				sheet.setColumnView(6, 16);
				sheet.setColumnView(7, 10);
				sheet.setColumnView(8, 19);
				sheet.setColumnView(9, 20);
				sheet.setColumnView(10, 50);
				
				sheet.setColumnView(11, 50);
				sheet.setColumnView(12, 17);
				sheet.setColumnView(13, 16);
				sheet.setColumnView(14, 16);
				sheet.setColumnView(15, 18);
				sheet.setColumnView(16, 16);
				sheet.setColumnView(17, 16);
				sheet.setColumnView(18, 10);
				sheet.setColumnView(19, 19);
				sheet.setColumnView(20, 20);
				sheet.setColumnView(21, 50);
			}
			else { //for fewer columns
				sheet.setColumnView(0, 50);
				sheet.setColumnView(1, 17);
				sheet.setColumnView(2, 16);
				sheet.setColumnView(3, 16);
				sheet.setColumnView(4, 50);
				sheet.setColumnView(5, 17);
				sheet.setColumnView(6, 16);
				sheet.setColumnView(7, 16);
			}
			
//			workbook.setColourRGB(Colour.LIME, 0xff, 0, 0);
			workbook.write();
			workbook.close();
			FileInputStream excelCSVFile = new FileInputStream(f);
			cachedExcelResource = getCachedWebResource(excelCSVFile, fileName, WDWebResourceType.XLS);
		
			wdContext.currentContextElement().setExcelURL(cachedExcelResource.getURL());
	   }
	   catch (Exception e) {
	   	
		StringBuffer buffer = new StringBuffer();
		StackTraceElement[] ex = e.getStackTrace();
		for(int i=0;i<ex.length;i++){
				buffer.append(ex[i].toString());
		}
		wdComponentAPI.getMessageManager().reportException(e.getMessage()+buffer.toString(), true);
	   }
    //@@end
  }

  //@@begin javadoc:recursive_excel_export()
  /** Declared method. */
  //@@end
  public void recursive_excel_export( com.monsanto.xrpm.wdp.IPrivateView_Rep.IFolderContentElement element, jxl.write.Label label, jxl.write.WritableSheet sheet, jxl.write.WritableCellFormat blueFormat, jxl.write.WritableCellFormat blackFormat, jxl.write.WritableCellFormat blueFormat_backgroundcolour, jxl.write.WritableCellFormat blackFormat_backgroundcolour, jxl.write.WritableCellFormat blueFormat_backgroundcolour1, jxl.write.WritableCellFormat blackFormat_backgroundcolour1 )
  {
    //@@begin recursive_excel_export()
    try {
	    n++;
	    if (element.getRoot()) {
	    	space = space + "";
	    }
	    else {
	    	space = "";
	    	if (element.getLevel() == 0) {
	    		space = space + "   ";
	    	}
	    	else {
	    	  	for (int n=0; n <= element.getLevel(); n++) {
	    			space = space + "   "; 
	    		}
	    	}
	    }
	    
		if (wdContext.currentContextElement().getRadiobutton_columns().equalsIgnoreCase("1")) {
		    //Hierachy 1
		    if (element.getCell_Design_hierachy().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(0, n, space + "- " + element.getHierarchy_proj1(), blueFormat);
		    }
		    else 
		    	if (element.getCell_Design_hierachy().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(0, n, space + "- " + element.getHierarchy_proj1(), blueFormat_backgroundcolour);
		    	}
		    	else 
					if (element.getCell_Design_hierachy().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(0, n, space + "- " + element.getHierarchy_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//System Status 1
			if (element.getCell_Design_systemStatus().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(1, n, element.getSystemStatus_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_systemStatus().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(1, n, element.getSystemStatus_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_systemStatus().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(1, n, element.getSystemStatus_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Actual Start 1
			if (element.getCell_Design_actualStart().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(2, n, element.getActualStart_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_actualStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(2, n, element.getActualStart_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_actualStart().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(2, n, element.getActualStart_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Actual Finish 1
			if (element.getCell_Design_actualFinish().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(3, n, element.getActualFinish_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_actualFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(3, n, element.getActualFinish_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_actualFinish().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(3, n, element.getActualFinish_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Percentage Complete 1
			if (element.getCell_Design_percentageComplete().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(4, n, element.getPercentageComplete_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_percentageComplete().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(4, n, element.getPercentageComplete_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_percentageComplete().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(4, n, element.getPercentageComplete_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Planned Start 1
			if (element.getCell_Design_plannedStart().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(5, n, element.getPlannedStart_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_plannedStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(5, n, element.getPlannedStart_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_plannedStart().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(5, n, element.getPlannedStart_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
	
			//Planned Finish 1
			if (element.getCell_Design_plannedFinish().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(6, n, element.getPlannedFinish_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_plannedFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(6, n, element.getPlannedFinish_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_plannedFinish().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(6, n, element.getPlannedFinish_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Duration 1
			if (element.getCell_Design_duration().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(7, n, element.getDuration_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_duration().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(7, n, element.getDuration_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_duration().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(7, n, element.getDuration_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Grouping 1
			if (element.getCell_Design_grouping().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(8, n, element.getGrouping_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_grouping().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(8, n, element.getGrouping_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_grouping().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(8, n, element.getGrouping_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Search Field 1
			if (element.getCell_Design_searchField().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(9, n, element.getSearchField_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_searchField().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(9, n, element.getSearchField_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_searchField().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(9, n, element.getSearchField_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Notes 1
			if (element.getCell_Design_notes().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(10, n, element.getNotes_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_notes().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(10, n, element.getNotes_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_notes().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(10, n, element.getNotes_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
	
			//Hierachy 2
			if (element.getCell_Design_hierachy().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(11, n, space + "- " + element.getHierarchy_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_hierachy().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(11, n, space + "- " + element.getHierarchy_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_hierachy().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(11, n, space + "- " + element.getHierarchy_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//System Status 2
			if (element.getCell_Design_systemStatus().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(12, n, element.getSystemStatus_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_systemStatus().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(12, n, element.getSystemStatus_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_systemStatus().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(12, n, element.getSystemStatus_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Actual Start 2
			if (element.getCell_Design_actualStart().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(13, n, element.getActualStart_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_actualStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(13, n, element.getActualStart_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_actualStart().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(13, n, element.getActualStart_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Actual Finish 2
			if (element.getCell_Design_actualFinish().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(14, n, element.getActualFinish_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_actualFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(14, n, element.getActualFinish_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_actualFinish().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(14, n, element.getActualFinish_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Percentage Complete 2
			if (element.getCell_Design_percentageComplete().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(15, n, element.getPercentageComplete_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_percentageComplete().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(15, n, element.getPercentageComplete_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_percentageComplete().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(15, n, element.getPercentageComplete_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Planned Start 2
			if (element.getCell_Design_plannedStart().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(16, n, element.getPlannedStart_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_plannedStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(16, n, element.getPlannedStart_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_plannedStart().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(16, n, element.getPlannedStart_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
	
			//Planned Finish 2
			if (element.getCell_Design_plannedFinish().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(17, n, element.getPlannedFinish_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_plannedFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(17, n, element.getPlannedFinish_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_plannedFinish().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(17, n, element.getPlannedFinish_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Duration 2
			if (element.getCell_Design_duration().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(18, n, element.getDuration_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_duration().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(18, n, element.getDuration_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_duration().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(18, n, element.getDuration_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Grouping 2
			if (element.getCell_Design_grouping().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(19, n, element.getGrouping_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_grouping().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(19, n, element.getGrouping_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_grouping().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(19, n, element.getGrouping_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Search Field 2
			if (element.getCell_Design_searchField().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(20, n, element.getSearchField_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_searchField().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(20, n, element.getSearchField_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_searchField().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(20, n, element.getSearchField_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Notes 2
			if (element.getCell_Design_notes().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(21, n, element.getNotes_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_notes().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(21, n, element.getNotes_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_notes().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(21, n, element.getNotes_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
		
		}
		else { //for fewer columns
			//Hierachy 1
			if (element.getCell_Design_hierachy().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(0, n, space + "- " + element.getHierarchy_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_hierachy().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(0, n, space + "- " + element.getHierarchy_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_hierachy().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(0, n, space + "- " + element.getHierarchy_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//System Status 1
			if (element.getCell_Design_systemStatus().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(1, n, element.getSystemStatus_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_systemStatus().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(1, n, element.getSystemStatus_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_systemStatus().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(1, n, element.getSystemStatus_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Planned Start 1
			if (element.getCell_Design_plannedStart().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(2, n, element.getPlannedStart_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_plannedStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(2, n, element.getPlannedStart_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_plannedStart().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(2, n, element.getPlannedStart_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
	
			//Planned Finish 1
			if (element.getCell_Design_plannedFinish().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(3, n, element.getPlannedFinish_proj1(), blueFormat);
			}
			else 
				if (element.getCell_Design_plannedFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(3, n, element.getPlannedFinish_proj1(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_plannedFinish().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(3, n, element.getPlannedFinish_proj1(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Hierachy 2
			if (element.getCell_Design_hierachy().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(4, n, space + "- " + element.getHierarchy_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_hierachy().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(4, n, space + "- " + element.getHierarchy_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_hierachy().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(4, n, space + "- " + element.getHierarchy_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//System Status 2
			if (element.getCell_Design_systemStatus().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(5, n, element.getSystemStatus_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_systemStatus().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(5, n, element.getSystemStatus_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_systemStatus().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(5, n, element.getSystemStatus_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
			
			//Planned Start 2
			if (element.getCell_Design_plannedStart().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(6, n, element.getPlannedStart_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_plannedStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(6, n, element.getPlannedStart_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_plannedStart().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(6, n, element.getPlannedStart_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
	
			//Planned Finish 2
			if (element.getCell_Design_plannedFinish().equals(WDTableCellDesign.STANDARD)) {
				label = new Label(7, n, element.getPlannedFinish_proj2(), blueFormat);
			}
			else 
				if (element.getCell_Design_plannedFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
					label = new Label(7, n, element.getPlannedFinish_proj2(), blueFormat_backgroundcolour);
				}
				else 
					if (element.getCell_Design_plannedFinish().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
						label = new Label(7, n, element.getPlannedFinish_proj2(), blueFormat_backgroundcolour1);
					}
			sheet.addCell(label);
		}
	
    }
    catch (Exception e) {
		StringBuffer buffer = new StringBuffer();
		StackTraceElement[] ex = e.getStackTrace();
		for(int i=0;i<ex.length;i++){
				buffer.append(ex[i].toString());
		}
		wdComponentAPI.getMessageManager().reportException(e.getMessage()+buffer.toString(), true);
    }
    
	if (element.getChildrenLoaded()) {
		IPrivateView_Rep.IFolderContentNode child_node = element.nodeChildNode();
		for (int p=0; p < child_node.size(); p++) {
			flag ++;
			if (child_node.getFolderContentElementAt(p).getChildrenLoaded()) {
				wdThis.recursive_excel_export(child_node.getFolderContentElementAt(p), label, sheet, blueFormat, blackFormat, blueFormat_backgroundcolour, blackFormat_backgroundcolour, blueFormat_backgroundcolour1, blackFormat_backgroundcolour1);	
			}
			else {
				try {
					n++;
					space = "";
					if (child_node.getFolderContentElementAt(p).getLevel() == 0) {
						space = space + "   ";
					}
					else {
						for (int n=0; n <= child_node.getFolderContentElementAt(p).getLevel(); n++) {
							space = space + "   "; 
						}
					}
					
					//For all columns
					if (wdContext.currentContextElement().getRadiobutton_columns().equalsIgnoreCase("1")) {
					
						//Hierachy 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_hierachy().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(0, n, space + ". " + child_node.getFolderContentElementAt(p).getHierarchy_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_hierachy().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(0, n, space + ". " + child_node.getFolderContentElementAt(p).getHierarchy_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_hierachy().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(0, n, space + ". " + child_node.getFolderContentElementAt(p).getHierarchy_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//System Status 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_systemStatus().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(1, n, child_node.getFolderContentElementAt(p).getSystemStatus_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_systemStatus().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(1, n, child_node.getFolderContentElementAt(p).getSystemStatus_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_systemStatus().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(1, n, child_node.getFolderContentElementAt(p).getSystemStatus_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Actual Start 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_actualStart().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(2, n, child_node.getFolderContentElementAt(p).getActualStart_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_actualStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(2, n, child_node.getFolderContentElementAt(p).getActualStart_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_actualStart().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(2, n, child_node.getFolderContentElementAt(p).getActualStart_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Actual Finish 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_actualFinish().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(3, n, child_node.getFolderContentElementAt(p).getActualFinish_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_actualFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(3, n, child_node.getFolderContentElementAt(p).getActualFinish_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_actualFinish().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(3, n, child_node.getFolderContentElementAt(p).getActualFinish_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Percentage Complete 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_percentageComplete().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(4, n, child_node.getFolderContentElementAt(p).getPercentageComplete_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_percentageComplete().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(4, n, child_node.getFolderContentElementAt(p).getPercentageComplete_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_percentageComplete().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(4, n, child_node.getFolderContentElementAt(p).getPercentageComplete_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Planned Start 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_plannedStart().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(5, n, child_node.getFolderContentElementAt(p).getPlannedStart_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_plannedStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(5, n, child_node.getFolderContentElementAt(p).getPlannedStart_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_plannedStart().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(5, n, child_node.getFolderContentElementAt(p).getPlannedStart_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
	
						//Planned Finish 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_plannedFinish().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(6, n, child_node.getFolderContentElementAt(p).getPlannedFinish_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_plannedFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(6, n, child_node.getFolderContentElementAt(p).getPlannedFinish_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_plannedFinish().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(6, n, child_node.getFolderContentElementAt(p).getPlannedFinish_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Duration 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_duration().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(7, n, child_node.getFolderContentElementAt(p).getDuration_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_duration().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(7, n, child_node.getFolderContentElementAt(p).getDuration_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_duration().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(7, n, child_node.getFolderContentElementAt(p).getDuration_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Grouping 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_grouping().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(8, n, child_node.getFolderContentElementAt(p).getGrouping_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_grouping().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(8, n, child_node.getFolderContentElementAt(p).getGrouping_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_grouping().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(8, n, child_node.getFolderContentElementAt(p).getGrouping_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Search Field 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_searchField().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(9, n, child_node.getFolderContentElementAt(p).getSearchField_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_searchField().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(9, n, child_node.getFolderContentElementAt(p).getSearchField_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_searchField().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(9, n, child_node.getFolderContentElementAt(p).getSearchField_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Notes 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_notes().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(10, n, child_node.getFolderContentElementAt(p).getNotes_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_notes().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(10, n, child_node.getFolderContentElementAt(p).getNotes_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_notes().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(10, n, child_node.getFolderContentElementAt(p).getNotes_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
	
						//Hierachy 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_hierachy().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(11, n, space + ". " + child_node.getFolderContentElementAt(p).getHierarchy_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_hierachy().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(11, n, space + ". " + child_node.getFolderContentElementAt(p).getHierarchy_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_hierachy().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(11, n, space + ". " + child_node.getFolderContentElementAt(p).getHierarchy_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//System Status 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_systemStatus().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(12, n, child_node.getFolderContentElementAt(p).getSystemStatus_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_systemStatus().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(12, n, child_node.getFolderContentElementAt(p).getSystemStatus_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_systemStatus().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(12, n, child_node.getFolderContentElementAt(p).getSystemStatus_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Actual Start 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_actualStart().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(13, n, child_node.getFolderContentElementAt(p).getActualStart_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_actualStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(13, n, child_node.getFolderContentElementAt(p).getActualStart_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_actualStart().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(13, n, child_node.getFolderContentElementAt(p).getActualStart_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Actual Finish 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_actualFinish().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(14, n, child_node.getFolderContentElementAt(p).getActualFinish_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_actualFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(14, n, child_node.getFolderContentElementAt(p).getActualFinish_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_actualFinish().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(14, n, child_node.getFolderContentElementAt(p).getActualFinish_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Percentage Complete 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_percentageComplete().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(15, n, child_node.getFolderContentElementAt(p).getPercentageComplete_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_percentageComplete().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(15, n, child_node.getFolderContentElementAt(p).getPercentageComplete_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_percentageComplete().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(15, n, child_node.getFolderContentElementAt(p).getPercentageComplete_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Planned Start 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_plannedStart().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(16, n, child_node.getFolderContentElementAt(p).getPlannedStart_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_plannedStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(16, n, child_node.getFolderContentElementAt(p).getPlannedStart_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_plannedStart().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(16, n, child_node.getFolderContentElementAt(p).getPlannedStart_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
	
						//Planned Finish 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_plannedFinish().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(17, n, child_node.getFolderContentElementAt(p).getPlannedFinish_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_plannedFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(17, n, child_node.getFolderContentElementAt(p).getPlannedFinish_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_plannedFinish().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(17, n, child_node.getFolderContentElementAt(p).getPlannedFinish_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Duration 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_duration().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(18, n, child_node.getFolderContentElementAt(p).getDuration_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_duration().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(18, n, child_node.getFolderContentElementAt(p).getDuration_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_duration().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(18, n, child_node.getFolderContentElementAt(p).getDuration_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Grouping 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_grouping().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(19, n, child_node.getFolderContentElementAt(p).getGrouping_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_grouping().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(19, n, child_node.getFolderContentElementAt(p).getGrouping_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_grouping().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(19, n, child_node.getFolderContentElementAt(p).getGrouping_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Search Field 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_searchField().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(20, n, child_node.getFolderContentElementAt(p).getSearchField_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_searchField().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(20, n, child_node.getFolderContentElementAt(p).getSearchField_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_searchField().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(20, n, child_node.getFolderContentElementAt(p).getSearchField_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//Notes 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_notes().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(21, n, child_node.getFolderContentElementAt(p).getNotes_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_notes().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(21, n, child_node.getFolderContentElementAt(p).getNotes_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_notes().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(21, n, child_node.getFolderContentElementAt(p).getNotes_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
					}
					else { //For fewer columns
						//Hierachy 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_hierachy().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(0, n, space + ". " + child_node.getFolderContentElementAt(p).getHierarchy_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_hierachy().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(0, n, space + ". " + child_node.getFolderContentElementAt(p).getHierarchy_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_hierachy().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(0, n, space + ". " + child_node.getFolderContentElementAt(p).getHierarchy_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
						//System Status 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_systemStatus().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(1, n, child_node.getFolderContentElementAt(p).getSystemStatus_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_systemStatus().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(1, n, child_node.getFolderContentElementAt(p).getSystemStatus_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_systemStatus().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(1, n, child_node.getFolderContentElementAt(p).getSystemStatus_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
				
					
						//Planned Start 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_plannedStart().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(2, n, child_node.getFolderContentElementAt(p).getPlannedStart_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_plannedStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(2, n, child_node.getFolderContentElementAt(p).getPlannedStart_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_plannedStart().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(2, n, child_node.getFolderContentElementAt(p).getPlannedStart_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
		
						//Planned Finish 1
						if (child_node.getFolderContentElementAt(p).getCell_Design_plannedFinish().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(3, n, child_node.getFolderContentElementAt(p).getPlannedFinish_proj1(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_plannedFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(3, n, child_node.getFolderContentElementAt(p).getPlannedFinish_proj1(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_plannedFinish().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(3, n, child_node.getFolderContentElementAt(p).getPlannedFinish_proj1(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
						
						//Hierachy 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_hierachy().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(4, n, space + ". " + child_node.getFolderContentElementAt(p).getHierarchy_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_hierachy().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(4, n, space + ". " + child_node.getFolderContentElementAt(p).getHierarchy_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_hierachy().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(4, n, space + ". " + child_node.getFolderContentElementAt(p).getHierarchy_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
				
						//System Status 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_systemStatus().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(5, n, child_node.getFolderContentElementAt(p).getSystemStatus_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_systemStatus().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(5, n, child_node.getFolderContentElementAt(p).getSystemStatus_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_systemStatus().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(5, n, child_node.getFolderContentElementAt(p).getSystemStatus_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
					
					
						//Planned Start 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_plannedStart().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(6, n, child_node.getFolderContentElementAt(p).getPlannedStart_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_plannedStart().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(6, n, child_node.getFolderContentElementAt(p).getPlannedStart_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_plannedStart().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(6, n, child_node.getFolderContentElementAt(p).getPlannedStart_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
	
						//Planned Finish 2
						if (child_node.getFolderContentElementAt(p).getCell_Design_plannedFinish().equals(WDTableCellDesign.STANDARD)) {
							label = new Label(7, n, child_node.getFolderContentElementAt(p).getPlannedFinish_proj2(), blackFormat);
						}
						else 
							if (child_node.getFolderContentElementAt(p).getCell_Design_plannedFinish().equals(WDTableCellDesign.CRITICALVALUE_MEDIUM)) {
								label = new Label(7, n, child_node.getFolderContentElementAt(p).getPlannedFinish_proj2(), blackFormat_backgroundcolour);
							}
							else 
								if (child_node.getFolderContentElementAt(p).getCell_Design_plannedFinish().equals(WDTableCellDesign.GOODVALUE_LIGHT)) {
									label = new Label(7, n, child_node.getFolderContentElementAt(p).getPlannedFinish_proj2(), blackFormat_backgroundcolour1);
								}
						sheet.addCell(label);
			
					}
				}
				catch (Exception e) {
					StringBuffer buffer = new StringBuffer();
					StackTraceElement[] ex = e.getStackTrace();
					for(int i=0;i<ex.length;i++){
							buffer.append(ex[i].toString());
					}
					wdComponentAPI.getMessageManager().reportException(e.getMessage()+buffer.toString(), true);
				}
			}
		}
		flag = 0;
		
	}
    //@@end
  }

  //@@begin javadoc:onActionPrevious(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionPrevious(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionPrevious(ServerEvent)
	for (int i = wdContext.nodeGt_Data().size() - 1; i >= 0; --i) {
		wdContext.nodeGt_Data().removeElement(wdContext.nodeGt_Data().getElementAt(i));
	}
	wdContext.nodeGt_Data().invalidate();
	
	//Get the Root Folder for Tree
	IPrivateView_Rep.IFolderContentNode rootFolderContentNode = wdContext.nodeFolderContent();
	
	if (rootFolderContentNode.size() > 0) {
		// Initialize the Root Element		
		IPrivateView_Rep.IFolderContentElement rootFolderContentElement;
		// instantiate the new context node element of type
		
		rootFolderContentElement = rootFolderContentNode.getFolderContentElementAt(0);
		// Remove the Root Element
		rootFolderContentNode.removeElement(rootFolderContentElement);
	}
	
    wdThis.wdFirePlugToSelection();
    //@@end
  }

  //@@begin javadoc:onPlugfromSelection(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onPlugfromSelection(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onPlugfromSelection(ServerEvent)
    wdContext.currentContextElement().setRadiobuton_selection("1");
	wdContext.currentContextElement().setRadiobutton_columns("1");
	wdContext.currentContextElement().setVisible_columns(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_columns2(WDVisibility.NONE);
	
	wdContext.currentContextElement().setHeader_ver1(wdContext.currentContextElement().getSelectedProject1().toUpperCase() +" / "+wdContext.currentContextElement().getSelectedProjectVer1().toUpperCase());
	if (!wdContext.currentContextElement().getSelectedProjectVer2().equalsIgnoreCase(""))
		wdContext.currentContextElement().setHeader_ver2(wdContext.currentContextElement().getSelectedProject2().toUpperCase() +" / "+wdContext.currentContextElement().getSelectedProjectVer2().toUpperCase());
    else 
		wdContext.currentContextElement().setHeader_ver2(wdContext.currentContextElement().getSelectedProject2().toUpperCase() +" / "+ "Operational");
	
	//call the RFC to get the schedule variance report
	wdContext.currentY_Xrpm_Schedule_Variance_Rep_InputElement().setProject_L(wdContext.currentContextElement().getSelectedProject1().toUpperCase());
	wdContext.currentY_Xrpm_Schedule_Variance_Rep_InputElement().setProject_R(wdContext.currentContextElement().getSelectedProject2().toUpperCase());
	wdContext.currentY_Xrpm_Schedule_Variance_Rep_InputElement().setVersion_L(wdContext.currentContextElement().getSelectedProjectVer1().toUpperCase());
	wdContext.currentY_Xrpm_Schedule_Variance_Rep_InputElement().setVersion_R(wdContext.currentContextElement().getSelectedProjectVer2().toUpperCase());
	wdThis.wdGetComp_schedule_variance_reportController().MD_execute_schedule_variance_rep();
	
	if (wdContext.currentContextElement().getSelectedProjectVer2().equalsIgnoreCase(""))
		wdContext.currentContextElement().setSelectedProjectVer2("Operational");
	
	try {		
		if (wdContext.nodeGt_Data().size() > 0) 
			wdThis.addInitialTreeStructure();
		else 
			wdComponentAPI.getMessageManager().reportException("No results found.", true);
	}
	catch (Exception e) {
		wdThis.addInitialTreeStructure();
	}
	
	if (wdContext.nodeFolderContent().size() > 0)
		wdContext.currentContextElement().setFirstVisibleRow(0);
    //@@end
  }

  //@@begin javadoc:onActionLoadChildCatalogEntries(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionLoadChildCatalogEntries(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionLoadChildCatalogEntries(ServerEvent)
    //@@end
  }

  //@@begin javadoc:onActionPrint(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionPrint(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionPrint(ServerEvent)
	//Expand entire tree structure prior to exporting to excel
	IPrivateView_Rep.IFolderContentNode root = wdContext.nodeFolderContent();
	for (int b=0; b < wdContext.nodeFolderContent().size(); b++) {
		root.getFolderContentElementAt(b).setExpanded(true);
		wdThis.recursive_expand(root.getFolderContentElementAt(b));
	}
    
    n = 0; // set n=0 to start from row 1 (Excel)
	space = "";
	wdThis.exporttoexcel_jxl(); 
	wdThis.wdGetComp_schedule_variance_reportController().open();
    //@@end
  }

  //@@begin javadoc:onActionExpand(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionExpand(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionExpand(ServerEvent)
	IPrivateView_Rep.IFolderContentNode root = wdContext.nodeFolderContent();
	for (int b=0; b < wdContext.nodeFolderContent().size(); b++) {
		root.getFolderContentElementAt(b).setExpanded(true);
		wdThis.recursive_expand(root.getFolderContentElementAt(b));
	}
	
	if (wdContext.nodeFolderContent().size() > 0) {
		wdContext.currentContextElement().setFirstVisibleRow(0);
	}
    //@@end
  }

  //@@begin javadoc:onActionCollapse(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionCollapse(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionCollapse(ServerEvent)
    IPrivateView_Rep.IFolderContentNode root = wdContext.nodeFolderContent();
    for (int b=0; b < wdContext.nodeFolderContent().size(); b++) {
		wdThis.recursive_collapse(root.getFolderContentElementAt(b));
		root.getFolderContentElementAt(b).setExpanded(false);
	}
	
	if (wdContext.nodeFolderContent().size() > 0) {
		wdContext.currentContextElement().setFirstVisibleRow(0);
	}
    //@@end
  }

  //@@begin javadoc:onActionSelectDisplayOption(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelectDisplayOption(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelectDisplayOption(ServerEvent)
    //@@end
  }

  //@@begin javadoc:onActionSelect_display_entire_projects(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelect_display_entire_projects(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelect_display_entire_projects(ServerEvent)
	//Get the Root Folder for Tree
	IPrivateView_Rep.IFolderContentNode rootFolderContentNode = wdContext.nodeFolderContent();
	// Initialize the Root Element		
	IPrivateView_Rep.IFolderContentElement rootFolderContentElement;
	// instantiate the new context node element of type
	try {
		rootFolderContentElement = rootFolderContentNode.getFolderContentElementAt(0);
		// Remove the Root Element
		rootFolderContentNode.removeElement(rootFolderContentElement);
	}
	catch (Exception e) {
		
	}
	wdThis.addInitialTreeStructure();
	
	if (wdContext.nodeFolderContent().size() > 0) {
		wdContext.currentContextElement().setFirstVisibleRow(0);
	}
    //@@end
  }

  //@@begin javadoc:onActionSelect_changes_only(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelect_changes_only(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelect_changes_only(ServerEvent)
	IPrivateView_Rep.IFolderContentNode root = wdContext.nodeFolderContent();
	int size = 0; 
	for (int b=0; b < wdContext.nodeFolderContent().size(); b++) {
		wdThis.recursive_remove_leafs(root.getFolderContentElementAt(b));
		
		//Expand the tree after displaying the changes only...
		root.getFolderContentElementAt(b).setExpanded(true);
		wdThis.recursive_expand(root.getFolderContentElementAt(b));
		
		IPrivateView_Rep.IFolderContentNode child;
		size = 0; 
		try {
			child = root.nodeChildNode();
			size = child.size();  
		}
		catch (Exception e) {
			size = 0;
		}
		
		if (size == 0) {
			if (!root.getFolderContentElementAt(b).getDisplayOnly().equalsIgnoreCase("X"))
				root.removeElement(root.getFolderContentElementAt(b));	
		}
	}

	if (wdContext.nodeFolderContent().size() > 0) {
		wdContext.currentContextElement().setFirstVisibleRow(0);
	}

    //@@end
  }

  //@@begin javadoc:onActionSelect_display_all_columns(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelect_display_all_columns(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelect_display_all_columns(ServerEvent)
    wdContext.currentContextElement().setVisible_columns(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_columns2(WDVisibility.NONE);
	
//	if (wdContext.nodeFolderContent().size() > 0) {
//		wdContext.currentContextElement().setFirstVisibleRow(0);
//	}
    //@@end
  }

  //@@begin javadoc:onActionSelect_fewer_columns(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelect_fewer_columns(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelect_fewer_columns(ServerEvent)
	wdContext.currentContextElement().setVisible_columns(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_columns2(WDVisibility.VISIBLE);
	
//	if (wdContext.nodeFolderContent().size() > 0) {
//		wdContext.currentContextElement().setFirstVisibleRow(0);
//	}
    //@@end
  }

  //@@begin javadoc:onActionExportToPDF(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionExportToPDF(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionExportToPDF(ServerEvent)
    wdThis.wdGetComp_schedule_variance_reportController().open_pdf_link();
    //@@end
  }

  /*
   * The following code section can be used for any Java code that is 
   * not to be visible to other controllers/views or that contains constructs
   * currently not supported directly by Web Dynpro (such as inner classes or
   * member variables etc.). </p>
   *
   * Note: The content of this section is in no way managed/controlled
   * by the Web Dynpro Designtime or the Web Dynpro Runtime. 
   */
  //@@begin others
  IPrivateView_Rep.IFolderContentElement temp_element;
  int level, n=0, flag = 0;
  String space = "";
  boolean parent_leaf;
  
  public com.sap.tc.webdynpro.services.sal.url.api.IWDCachedWebResource getCachedWebResource( java.io.InputStream file, java.lang.String name, com.sap.tc.webdynpro.services.sal.url.api.WDWebResourceType type )
  {
	IWDCachedWebResource cachedWebResource = null;

	if (file != null){
		cachedWebResource = WDWebResource.getWebResource(file, type);
		cachedWebResource.setResourceName(name);
	}
	return cachedWebResource;
  }
  //@@end
}
