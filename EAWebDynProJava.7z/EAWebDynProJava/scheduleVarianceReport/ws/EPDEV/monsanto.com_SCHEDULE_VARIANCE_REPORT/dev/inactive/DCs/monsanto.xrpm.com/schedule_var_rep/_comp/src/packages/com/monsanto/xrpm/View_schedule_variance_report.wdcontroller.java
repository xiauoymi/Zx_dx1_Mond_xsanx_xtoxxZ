// ---------------------------------------------------------------------------
// This file has been generated partially by the Web Dynpro Code Generator.
// MODIFY CODE ONLY IN SECTIONS ENCLOSED BY @@begin AND @@end.
// ALL OTHER CHANGES WILL BE LOST IF THE FILE IS REGENERATED.
// ---------------------------------------------------------------------------
package com.monsanto.xrpm;

// 
// IMPORTANT NOTE: 
// _ALL_ IMPORT STATEMENTS MUST BE PLACED IN THE FOLLOWING SECTION ENCLOSED
// BY @@begin imports AND @@end. FURTHERMORE, THIS SECTION MUST ALWAYS CONTAIN
// AT LEAST ONE IMPORT STATEMENT (E.G. THAT FOR IPrivateView_schedule_variance_report).
// OTHERWISE, USING THE ECLIPSE FUNCTION "Organize Imports" FOLLOWED BY
// A WEB DYNPRO CODE GENERATION (E.G. PROJECT BUILD) WILL RESULT IN THE LOSS
// OF IMPORT STATEMENTS.
//
//@@begin imports

import com.monsanto.xrpm.wdp.IPrivateView_schedule_variance_report;
import com.sap.tc.webdynpro.progmodel.api.IWDAttributeInfo;
import com.sap.tc.webdynpro.progmodel.api.IWDOVSContextNotificationListener;
import com.sap.tc.webdynpro.progmodel.api.WDValueServices;
import com.sap.tc.webdynpro.progmodel.api.WDVisibility;
//@@end

//@@begin documentation
//@@end

public class View_schedule_variance_report
{
  /**
   * Logging location.
   */
  private static final com.sap.tc.logging.Location logger = 
    com.sap.tc.logging.Location.getLocation(View_schedule_variance_report.class);

  static 
  {
    //@@begin id
    String id = "$Id$";
    //@@end
    com.sap.tc.logging.Location.getLocation("ID.com.sap.tc.webdynpro").infoT(id);
  }

  /**
   * Private access to the generated Web Dynpro counterpart 
   * for this controller class.  </p>
   *
   * Use <code>wdThis</code> to gain typed access to the context,
   * to trigger navigation via outbound plugs, to get and enable/disable
   * actions, fire declared events, and access used controllers and/or 
   * component usages.
   *
   * @see com.monsanto.xrpm.wdp.IPrivateView_schedule_variance_report for more details
   */
  private final IPrivateView_schedule_variance_report wdThis;

  /**
   * Root node of this controller's context. </p>
   *
   * Provides typed access not only to the elements of the root node 
   * but also to all nodes in the context (methods node<i>XYZ</i>()) 
   * and their currently selected element (methods current<i>XYZ</i>Element()). 
   * It also facilitates the creation of new elements for all nodes 
   * (methods create<i>XYZ</i>Element()). </p>
   *
   * @see com.monsanto.xrpm.wdp.IPrivateView_schedule_variance_report.IContextNode for more details.
   */
  private final IPrivateView_schedule_variance_report.IContextNode wdContext;

  /**
   * A shortcut for <code>wdThis.wdGetAPI()</code>. </p>
   * 
   * Represents the generic API of the generic Web Dynpro counterpart 
   * for this controller. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDViewController wdControllerAPI;
  
  /**
   * A shortcut for <code>wdThis.wdGetAPI().getComponent()</code>. </p>
   * 
   * Represents the generic API of the Web Dynpro component this controller 
   * belongs to. Can be used to access the message manager, the window manager,
   * to add/remove event handlers and so on. </p>
   */
  private final com.sap.tc.webdynpro.progmodel.api.IWDComponent wdComponentAPI;
  
  public View_schedule_variance_report(IPrivateView_schedule_variance_report wdThis)
  {
    this.wdThis = wdThis;
    this.wdContext = wdThis.wdGetContext();
    this.wdControllerAPI = wdThis.wdGetAPI();
    this.wdComponentAPI = wdThis.wdGetAPI().getComponent();
  }

  //@@begin javadoc:wdDoInit()
  /** Hook method called to initialize controller. */
  //@@end
  public void wdDoInit()
  {
    //@@begin wdDoInit()
    wdContext.currentContextElement().setProj1_radiobutton("2");
	wdContext.currentContextElement().setProj2_radiobutton("1");
	//wdContext.currentContextElement().setVisible_Operational_Proj2(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_snapshot_proj2_version(WDVisibility.NONE); 
	wdContext.currentContextElement().setVisible_snapshot_proj1_version(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_simulation_proj1_ver(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_simulation_proj2_ver(WDVisibility.NONE);
	wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	
	IWDAttributeInfo[] ovsStartUpAttributes1 = {wdContext.nodeProjectNo_From().getNodeInfo().getAttribute("YYFIELD1")};
	IWDOVSContextNotificationListener listener_projectnofrom = wdThis.wdGetComp_schedule_variance_reportController().getOVSProjectNoFromListener();
	WDValueServices.addOVSExtension("OVS", // not used yet by the current OVS Service 
									ovsStartUpAttributes1, // fields bound to startup attributes will be ovs-enabled 
									wdThis.wdGetComp_schedule_variance_reportController().getOVSProjectNoInputNode(), 
									wdThis.wdGetComp_schedule_variance_reportController().getOVSProjectNoOutputNode(), 
									listener_projectnofrom);
    
	wdContext.currentContextElement().setVisibility_searchhelp_message(WDVisibility.NONE);
    //@@end
  }

  //@@begin javadoc:wdDoExit()
  /** Hook method called to clean up controller. */
  //@@end
  public void wdDoExit()
  {
    //@@begin wdDoExit()
    //@@end
  }

  //@@begin javadoc:wdDoModifyView
  /**
   * Hook method called to modify a view just before rendering.
   * This method conceptually belongs to the view itself, not to the
   * controller (cf. MVC pattern).
   * It is made static to discourage a way of programming that
   * routinely stores references to UI elements in instance fields
   * for access by the view controller's event handlers, and so on.
   * The Web Dynpro programming model recommends that UI elements can
   * only be accessed by code executed within the call to this hook method.
   *
   * @param wdThis Generated private interface of the view's controller, as
   *        provided by Web Dynpro. Provides access to the view controller's
   *        outgoing controller usages, etc.
   * @param wdContext Generated interface of the view's context, as provided
   *        by Web Dynpro. Provides access to the view's data.
   * @param view The view's generic API, as provided by Web Dynpro.
   *        Provides access to UI elements.
   * @param firstTime Indicates whether the hook is called for the first time
   *        during the lifetime of the view.
   */
  //@@end
  public static void wdDoModifyView(IPrivateView_schedule_variance_report wdThis, IPrivateView_schedule_variance_report.IContextNode wdContext, com.sap.tc.webdynpro.progmodel.api.IWDView view, boolean firstTime)
  {
    //@@begin wdDoModifyView
	wdContext.currentContextElement().setVisibility_message(WDVisibility.NONE);
	wdContext.currentContextElement().setVisibility_searchhelp_message(WDVisibility.NONE);
    //@@end
  }

  //@@begin javadoc:onActionselectProject1(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionselectProject1(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionselectProject1(ServerEvent)
	String project_num;
	try {
		if (!wdContext.currentProjectNo_FromElement().getYYFIELD1().equalsIgnoreCase(""))
			project_num = wdContext.currentProjectNo_FromElement().getYYFIELD1();
		else
			project_num = "";
	}
	catch (NullPointerException e) {
		project_num = "";
	}
    
    if (!project_num.equalsIgnoreCase("")) {
	    wdContext.currentContextElement().setProj1_radiobutton("2");
		wdContext.currentContextElement().setProj2_radiobutton("1");
		//wdContext.currentContextElement().setVisible_Operational_Proj2(WDVisibility.NONE);
		wdContext.currentContextElement().setVisible_snapshot_proj1_version(WDVisibility.VISIBLE);
		wdContext.currentContextElement().setVisible_snapshot_proj2_version(WDVisibility.NONE);
		wdContext.currentContextElement().setVisible_simulation_proj1_ver(WDVisibility.NONE);
		wdContext.currentContextElement().setVisible_simulation_proj2_ver(WDVisibility.NONE);
		wdContext.currentContextElement().setProject_number1(wdContext.currentProjectNo_FromElement().getYYFIELD1());
	    wdThis.wdGetComp_schedule_variance_reportController().select_project1(wdContext.currentProjectNo_FromElement().getYYFIELD1());
    }
    //@@end
  }

  //@@begin javadoc:onActionselectProject2(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionselectProject2(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionselectProject2(ServerEvent)
	//wdThis.wdGetComp_schedule_variance_reportController().select_project2();
    //@@end
  }

  //@@begin javadoc:onActionsubmit(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionsubmit(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionsubmit(ServerEvent)
    String project_num;
    try {
    	if (!wdContext.currentProjectNo_FromElement().getYYFIELD1().equalsIgnoreCase(""))
    		project_num = wdContext.currentProjectNo_FromElement().getYYFIELD1();
    	else
			project_num = "";
    }
    catch (NullPointerException e) {
		project_num = "";
    }
    
    if (!project_num.equalsIgnoreCase("")) {
	    //if ((wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("1")) || (wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("2") && !wdContext.currentContextElement().getSnap_shot_proj1_version().equalsIgnoreCase("")) || (wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("3") && !wdContext.currentContextElement().getSimulation_proj1_version().equalsIgnoreCase("") && !wdContext.currentContextElement().getProjectNumber1_Simulation().equalsIgnoreCase(""))) {
		if ((wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("2") && !wdContext.currentContextElement().getSnap_shot_proj1_version().equalsIgnoreCase("")) || (wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("3") && !wdContext.currentContextElement().getSimulation_proj1_version().equalsIgnoreCase("") && !wdContext.currentContextElement().getProjectNumber1_Simulation().equalsIgnoreCase(""))) {
	    	if ((wdContext.currentContextElement().getProj2_radiobutton().equalsIgnoreCase("1")) || (wdContext.currentContextElement().getProj2_radiobutton().equalsIgnoreCase("2") && !wdContext.currentContextElement().getSnap_shot_proj2_version().equalsIgnoreCase("")) || (wdContext.currentContextElement().getProj2_radiobutton().equalsIgnoreCase("3") && !wdContext.currentContextElement().getProjectNumber2_simulation().equalsIgnoreCase("") && !wdContext.currentContextElement().getSimulation_proj2_version().equalsIgnoreCase(""))) {    
				
				//if (wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("2") || wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("1"))
				if (wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("2"))
	    			wdContext.currentContextElement().setSelectedProject1(wdContext.currentProjectNo_FromElement().getYYFIELD1());
			    else
					wdContext.currentContextElement().setSelectedProject1(wdContext.currentContextElement().getProjectNumber1_Simulation());
			    
			    if (wdContext.currentContextElement().getProj2_radiobutton().equalsIgnoreCase("1") || wdContext.currentContextElement().getProj2_radiobutton().equalsIgnoreCase("2"))
					wdContext.currentContextElement().setSelectedProject2(wdContext.currentProjectNo_FromElement().getYYFIELD1());
				else
					wdContext.currentContextElement().setSelectedProject2(wdContext.currentContextElement().getProjectNumber2_simulation());
				
				
				if (wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("2"))
					wdContext.currentContextElement().setSelectedProjectVer1(wdContext.currentContextElement().getSnap_shot_proj1_version());
				else
					wdContext.currentContextElement().setSelectedProjectVer1(wdContext.currentContextElement().getSimulation_proj1_version());
				
				
				if (wdContext.currentContextElement().getProj2_radiobutton().equalsIgnoreCase("1"))	
					wdContext.currentContextElement().setSelectedProjectVer2("");
			    else
					if (wdContext.currentContextElement().getProj2_radiobutton().equalsIgnoreCase("2"))	
						wdContext.currentContextElement().setSelectedProjectVer2(wdContext.currentContextElement().getSnap_shot_proj2_version());
			    	else
						wdContext.currentContextElement().setSelectedProjectVer2(wdContext.currentContextElement().getSimulation_proj2_version());
			    
			    wdThis.wdFirePlugToReport();
	    	}
	    	else {
				wdComponentAPI.getMessageManager().reportException("No project versions available to compare.", true);
	    	}
	    }
	    else {
			wdComponentAPI.getMessageManager().reportException("No project versions available to compare.", true);
	    }
    }
    else {
		wdComponentAPI.getMessageManager().reportException("A valid project number is required to process the request.", true);
	}
    //@@end
  }

  //@@begin javadoc:onPlugfromReport(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onPlugfromReport(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onPlugfromReport(ServerEvent)
    //@@end
  }

  //@@begin javadoc:onActionSelectOperational_Proj1(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelectOperational_Proj1(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelectOperational_Proj1(ServerEvent)
	wdContext.currentContextElement().setVisible_Operational_Proj2(WDVisibility.NONE);
	wdContext.currentContextElement().setProj2_radiobutton("2");
	wdContext.currentContextElement().setVisible_simulation_proj1_ver(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_snapshot_proj1_version(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_simulation_proj2_ver(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_snapshot_proj2_version(WDVisibility.VISIBLE);
	
	wdThis.wdGetComp_schedule_variance_reportController().addVersion();	
    //@@end
  }

  //@@begin javadoc:onActionSelect_Snapshot_Proj1(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelect_Snapshot_Proj1(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelect_Snapshot_Proj1(ServerEvent)
	wdContext.currentContextElement().setVisible_Operational_Proj2(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setProj2_radiobutton("1");
	wdContext.currentContextElement().setVisible_snapshot_proj1_version(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_simulation_proj1_ver(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_simulation_proj2_ver(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_snapshot_proj2_version(WDVisibility.NONE);
	wdThis.wdGetComp_schedule_variance_reportController().MD_execute_get_simulations(wdContext.currentProjectNo_FromElement().getYYFIELD1(), wdContext.currentContextElement().getSnap_shot_proj1_version(), "");
    wdThis.wdGetComp_schedule_variance_reportController().setDefaults();
    wdThis.wdGetComp_schedule_variance_reportController().setDefault_Snapshot_Ver1();
	wdThis.wdGetComp_schedule_variance_reportController().addVersion();
    //@@end
  }

  //@@begin javadoc:onActionSelectSimulation_Proj1(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelectSimulation_Proj1(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelectSimulation_Proj1(ServerEvent)
	wdContext.currentContextElement().setVisible_Operational_Proj2(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setProj2_radiobutton("1");
	wdContext.currentContextElement().setVisible_simulation_proj1_ver(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_snapshot_proj1_version(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_simulation_proj2_ver(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_snapshot_proj2_version(WDVisibility.NONE);
	wdThis.wdGetComp_schedule_variance_reportController().addVersion();
	//wdThis.wdGetComp_schedule_variance_reportController().MD_execute_get_simulations(wdContext.currentProjectNo_FromElement().getYYFIELD1(), wdContext.currentContextElement().getSimulation_proj1_version(), "");
	//wdThis.wdGetComp_schedule_variance_reportController().setDefaults();
	//wdThis.wdGetComp_schedule_variance_reportController().setDefault_Simulation_Ver1();
	//wdContext.currentContextElement().setProjectVersion3Width("40px");
    //@@end
  }

  //@@begin javadoc:onActionSelectOperational_Proj2(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelectOperational_Proj2(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelectOperational_Proj2(ServerEvent)
	wdContext.currentContextElement().setVisible_simulation_proj2_ver(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_snapshot_proj2_version(WDVisibility.NONE);
    //@@end
  }

  //@@begin javadoc:onActionSelectSnapshot_Proj2(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelectSnapshot_Proj2(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelectSnapshot_Proj2(ServerEvent)
	wdContext.currentContextElement().setVisible_simulation_proj2_ver(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_snapshot_proj2_version(WDVisibility.VISIBLE);
	
	if (wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("2")) {
		wdThis.wdGetComp_schedule_variance_reportController().removeVersion();
	}
    //@@end
  }

  //@@begin javadoc:onActionSelect_Simulation_Proj2(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionSelect_Simulation_Proj2(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionSelect_Simulation_Proj2(ServerEvent)
	wdContext.currentContextElement().setVisible_simulation_proj2_ver(WDVisibility.VISIBLE);
	wdContext.currentContextElement().setVisible_snapshot_proj2_version(WDVisibility.NONE);
	if (wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("2")) {
		wdThis.wdGetComp_schedule_variance_reportController().MD_execute_get_simulations(wdContext.currentProjectNo_FromElement().getYYFIELD1(), wdContext.currentContextElement().getSnap_shot_proj1_version(), "");
		wdThis.wdGetComp_schedule_variance_reportController().setSimulations();
	}
//	else
//		if (wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("1")) {
//			wdThis.wdGetComp_schedule_variance_reportController().MD_execute_get_simulations(wdContext.currentProjectNo_FromElement().getYYFIELD1(), "", "");
//			wdThis.wdGetComp_schedule_variance_reportController().setSimulations();
//		}
		else {
			wdThis.wdGetComp_schedule_variance_reportController().MD_execute_get_simulations(wdContext.currentContextElement().getProjectNumber1_Simulation(), wdContext.currentContextElement().getSimulation_proj1_version(), "");
			wdThis.wdGetComp_schedule_variance_reportController().setSimulations();
		}
    //@@end
  }

  //@@begin javadoc:onActionDropdown_snapshot_ver2(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionDropdown_snapshot_ver2(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionDropdown_snapshot_ver2(ServerEvent)
    //@@end
  }

  //@@begin javadoc:onActionDropdown_snapshot_ver1(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionDropdown_snapshot_ver1(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionDropdown_snapshot_ver1(ServerEvent)
 	wdThis.wdGetComp_schedule_variance_reportController().MD_execute_get_simulations(wdContext.currentProjectNo_FromElement().getYYFIELD1(), wdContext.currentContextElement().getSnap_shot_proj1_version(), "");
    wdThis.wdGetComp_schedule_variance_reportController().setDefaults();
    wdContext.currentContextElement().setProj2_radiobutton("1");
	wdThis.wdGetComp_schedule_variance_reportController().addVersion();
	wdContext.currentContextElement().setVisible_simulation_proj2_ver(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_snapshot_proj2_version(WDVisibility.NONE);
    //@@end
  }

  //@@begin javadoc:onActionDropdown_simulation_ver1(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionDropdown_simulation_ver1(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionDropdown_simulation_ver1(ServerEvent)
	wdThis.wdGetComp_schedule_variance_reportController().MD_execute_get_simulations(wdContext.currentProjectNo_FromElement().getYYFIELD1(), "", wdContext.currentContextElement().getSimulation_proj1_version());
	wdThis.wdGetComp_schedule_variance_reportController().setProjectNumber();
	wdContext.currentContextElement().setProj2_radiobutton("1");
	wdContext.currentContextElement().setVisible_simulation_proj2_ver(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_snapshot_proj2_version(WDVisibility.NONE);
    //@@end
  }

  //@@begin javadoc:onActionDropdown_simulation_ver2(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionDropdown_simulation_ver2(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionDropdown_simulation_ver2(ServerEvent)
	if (wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("2")) {
		wdThis.wdGetComp_schedule_variance_reportController().MD_execute_get_simulations(wdContext.currentProjectNo_FromElement().getYYFIELD1(), wdContext.currentContextElement().getSnap_shot_proj2_version(), wdContext.currentContextElement().getSimulation_proj2_version());
		wdThis.wdGetComp_schedule_variance_reportController().setSimulations_1();
	}
    else
		if (wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("3")) {
	   		wdThis.wdGetComp_schedule_variance_reportController().MD_execute_get_simulations(wdContext.currentContextElement().getProjectNumber1_Simulation(), wdContext.currentContextElement().getSimulation_proj1_version(), wdContext.currentContextElement().getSimulation_proj2_version());
			wdThis.wdGetComp_schedule_variance_reportController().setSimulations_1();
		}
//		else 
//			if (wdContext.currentContextElement().getProj1_radiobutton().equalsIgnoreCase("1")) {
//				wdThis.wdGetComp_schedule_variance_reportController().MD_execute_get_simulations(wdContext.currentProjectNo_FromElement().getYYFIELD1(), "", wdContext.currentContextElement().getSimulation_proj2_version());
//				wdThis.wdGetComp_schedule_variance_reportController().setSimulations();
//			}
    //@@end
  }

  //@@begin javadoc:onActionDropdown_proj1_simulation(ServerEvent)
  /** Declared validating event handler. */
  //@@end
  public void onActionDropdown_proj1_simulation(com.sap.tc.webdynpro.progmodel.api.IWDCustomEvent wdEvent )
  {
    //@@begin onActionDropdown_proj1_simulation(ServerEvent)
	wdContext.currentContextElement().setProj2_radiobutton("1");
	wdContext.currentContextElement().setVisible_simulation_proj2_ver(WDVisibility.NONE);
	wdContext.currentContextElement().setVisible_snapshot_proj2_version(WDVisibility.NONE);
    //@@end
  }

  /*
   * The following code section can be used for any Java code that is 
   * not to be visible to other controllers/views or that contains constructs
   * currently not supported directly by Web Dynpro (such as inner classes or
   * member variables etc.). </p>
   *
   * Note: The content of this section is in no way managed/controlled
   * by the Web Dynpro Designtime or the Web Dynpro Runtime. 
   */
  //@@begin others
  //@@end
}
