/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.monsanto.encrypt.servlet;

import com.monsanto.encrypt.util.EncryptUtil;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author RRBHAR2
 */
public class Encrypt extends HttpServlet {

    public static final String ENCRYPT = "/encrypt";
    public static final String DECRYPT = "/decrypt";
    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String userPath = request.getServletPath();
        String key = request.getParameter("key");
        String startType = request.getParameter("startType");
        String password = request.getParameter("password");
        String url = null;

        if(null == key || ("").equals(key)){
            if("new".equals(startType))
            try {
                request.setAttribute("key", EncryptUtil.getKey());
            } catch(Exception exp) {
                request.setAttribute("error", exp.getMessage());
            }
        } else {        

            if (ENCRYPT.equals(userPath)) {
                String encryptedPassword = EncryptUtil.getEncryptedPassword(key, password);
                request.setAttribute("encryptedPassword", encryptedPassword);

            }

            if (DECRYPT.equals(userPath)) {
                String decryptedPassword = EncryptUtil.getDecryptedPassword(key, password);
                request.setAttribute("decryptedPassword", decryptedPassword);
            }
        }
        url = userPath.concat(".jsp");
        request.getRequestDispatcher(url).forward(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}
