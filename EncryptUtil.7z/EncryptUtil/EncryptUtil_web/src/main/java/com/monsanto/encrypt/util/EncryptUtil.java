/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.monsanto.encrypt.util;

import com.monsanto.Util.databasepasswordencryption.AES_Encryptor;
import com.monsanto.Util.databasepasswordencryption.EncryptedString;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import javax.crypto.KeyGenerator;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;


/**
 *
 * @author rrbhar2
 */
public class EncryptUtil {

    private static final int NUMBER_OF_BYTES = 16;
    private static final String ALGORITHM = "AES";
    
    public static String getEncryptedPassword(String key, String password) {
       return getPassword(key,password,false);
    }
    
     public static String getDecryptedPassword(String key, String encryptedPassword){
        return getPassword(key,encryptedPassword,true);
    }
     
     private static String getPassword(String key, String password, boolean isEncrypted){
        String getPassword;
        AES_Encryptor aes128;
        try {
            aes128 = new AES_Encryptor(key);
             EncryptedString cryEncryptedString= new EncryptedString(aes128, password, isEncrypted);
             getPassword=isEncrypted?cryEncryptedString.getPlainText():cryEncryptedString.getCipherText();
        } catch (EncryptorException ex) {
            getPassword="Please put a valid Key. eg. 8C8C588B5EE05BC0C37DD73F9238B9F7";
        }
       
        return getPassword;
     }

    public static String getKey() throws EncryptorException{
        
        Key key = generateRandomKey();
        return convertBytesToHexString(key.getEncoded());

    }

    private static Key generateRandomKey() throws EncryptorException
    {
        Key key = null;
        try
        {
            KeyGenerator kgen = KeyGenerator.getInstance(ALGORITHM);	// for ex., "AES"
            kgen.init(NUMBER_OF_BYTES * 8);	// for ex., 128-bit

            // generate random key
            key = kgen.generateKey();
        }
        catch (NoSuchAlgorithmException ex)
        {
            throw new EncryptorException("AES_Encryptor::getKey - " + ex.getMessage());
        }
        return key;
    }

    
    public static String convertBytesToHexString(byte[] bytes) {   
        
        StringBuilder sb = new StringBuilder(bytes.length * 2);   
        Formatter formatter = new Formatter(sb);
        for (byte b : bytes) {
            formatter.format("%02X", b);
        }   
        return sb.toString();   
    }       
    
}
