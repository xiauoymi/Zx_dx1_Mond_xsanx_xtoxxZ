/*
 Copyable was created on Feb 9, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis;

/**
 * Filename:    $RCSfile: Copyable.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-10 16:56:08 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public interface Copyable extends Cloneable{
  Object createCopy() throws CloneNotSupportedException;
}