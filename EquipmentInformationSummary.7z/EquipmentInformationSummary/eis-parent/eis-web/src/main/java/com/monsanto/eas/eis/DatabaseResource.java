package com.monsanto.eas.eis;

import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.info.ApplicationResource;
import com.monsanto.wst.hibernate.HibernateFactory;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Apr 16, 2009
 * Time: 3:44:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class DatabaseResource implements ApplicationResource{
  public boolean validateResource() {
    HibernateFactory hibernateFactory = EISHibernateUtil.getHibernateFactory();
    try{
    hibernateFactory.beginTransaction();
    hibernateFactory.commitTransaction();
    }catch(Exception e){
      if (hibernateFactory.getSession().getTransaction().isActive()) {
          hibernateFactory.rollbackTransaction();
      }
      return false;
    }
    return true;  //To change body of implemented methods use File | Settings | File Templates.
  }
}
