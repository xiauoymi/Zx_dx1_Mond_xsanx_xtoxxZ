/*
 AlertController was created on Feb 9, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.eas.eis.controller.EISController;
import com.monsanto.eas.eis.equipment.service.*;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.domain.Area;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.EquipmentType;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.services.ProjectsServiceImpl;
import com.monsanto.eas.eis.projects.services.UserService;
import com.monsanto.eas.eis.projects.services.UserServiceImpl;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.ElectricalConstants;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: AlertController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-19 20:26:56 $
 *
 * @author rrmall
 * @version $Revision: 1.4 $
 */
public class AlertController extends EISController {
  private ProjectsService projectService;
  private ProcessService processService;
  private EquipmentService equipmentService;
  private ElectricalService electricalService;
  private CostScheduleService costScheduleService;
  private MechanicalService mechanicalService;
  private UserService userService;

  public AlertController() {
    this(new ProjectsServiceImpl(),
        new ProcessServiceImpl(), new EquipmentServiceImpl(), new ElectricalServiceImpl(),
        new CostScheduleServiceImpl(), new MechanicalServiceImpl(),
        new UserServiceImpl());
  }

  public AlertController(ProjectsService projectService, ProcessService processService,
                         EquipmentService equipmentService, ElectricalService electricalService,
                         CostScheduleService costScheduleService, MechanicalService mechanicalService,
                         UserService userService) {
    this.projectService = projectService;
    this.processService = processService;
    this.equipmentService = equipmentService;
    this.electricalService = electricalService;
    this.costScheduleService = costScheduleService;
    this.mechanicalService = mechanicalService;
    this.userService = userService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    setReferenceDataInHelper(helper);
    helper.forward("/WEB-INF/jsp/home.jspx");
  }

  public void lookupProjectsByProjectStatusForAUser(UCCHelper helper) throws IOException, ParserException {
    List<Projects> projectsList = getListOfProjectsForAUser(helper);
    StringBuffer responseStr = createResponseXml(projectsList);
    try {
      Document document = DOMUtil.stringToXML(responseStr.toString());
      helper.setContentType(EISConstants.XML_TEXT);
      helper.writeXMLDocument(document);
    }catch (ParserException e){
      throw new RuntimeException(e);
    }
  }

  private StringBuffer createResponseXml(List<Projects> projectsList) {
    StringBuffer responseStr = new StringBuffer("<projects>");
    responseStr.append("<count>").append(projectsList.size()).append("</count>");
    for (Projects project: projectsList){
      responseStr.append("<projectId>");
      responseStr.append(project.getId().toString());
      responseStr.append("</projectId>");
      responseStr.append("<projectName>");
      responseStr.append(project.getProjName()).append(" - ").append(project.getProjNumber());
      responseStr.append("</projectName>");
    }
    responseStr.append("</projects>");
    return responseStr;
  }


  private List<Projects> getListOfProjectsForAUser(UCCHelper helper) throws IOException {
    String projectStatus = EISConstants.PROJECT_STATUS_DETAILED_DESIGN;
    String[] roleNames = new String[]{EISConstants.MECHANICAL_ENGINEER,
        EISConstants.MECHANICAL_DESIGNER, EISConstants.ELECTRICAL_ENGINEER,
        EISConstants.ELECTRICAL_DESIGNER, EISConstants.PROCESS_ENGINEER};;
    User logonUser = (User) helper.getSessionParameter(EISConstants.LOGIN_USER);

    String checkForProjectStatus = helper.getRequestParameterValue(EISConstants.CHECK_FOR_PROJECT_STATUS);
    if (checkForProjectStatus != null && "false".equalsIgnoreCase(checkForProjectStatus)){
      projectStatus = null;
    }
    return logonUser.lookupProjectsByRolesAndStatus(roleNames, projectStatus);
  }

   private void setReferenceDataInHelper(UCCHelper helper) throws IOException {
    List<EquipmentType> equimentTypeList = this.equipmentService.lookupAllParentEquipmentTypes();
    helper.setRequestAttributeValue(EISConstants.EQUIPMENT_TYPES, equimentTypeList);
    helper.setRequestAttributeValue(EISConstants.FIELD_EQUIPMENT_TYPES,
        processService.lookupAllFieldEquipmentTypes(null));
    helper.setRequestAttributeValue(EISConstants.GAS_TYPES, processService.lookupAllGasTypes());
    helper.setRequestAttributeValue(EISConstants.WATER_TYPES, processService.lookupAllWaterTypes());
    helper.setRequestAttributeValue(EISConstants.DUST_TYPES, processService.lookupAllDustTypes());
    helper.setRequestAttributeValue(ElectricalConstants.ELECTRICAL_INPUTS, electricalService.lookupAllInputs());
    helper.setRequestAttributeValue(ElectricalConstants.ELECTRICAL_OUTPUTS, electricalService.lookupAllOutputs());
    helper.setRequestAttributeValue(ElectricalConstants.OTHER_MEASUREMENTS,
        electricalService.lookupAllOtherMeasurements());
    helper.setRequestAttributeValue(EISConstants.FUNDING_SOURCES, costScheduleService.lookupAllFundingSources());
    helper.setRequestAttributeValue(EISConstants.PURCHASE_SCOPES, mechanicalService.lookupAllPurchaseScopes());
  }


  public void lookupAllRefDataForProjectAndEquipmentXML(UCCHelper helper) throws IOException {
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    String equipmentId = helper.getRequestParameterValue(EISConstants.EQUIPMENT_ID);
    Projects project = this.projectService.lookupProjectById(Long.valueOf(projectId));
    Equipment equipment = this.equipmentService.lookupEquipment(Long.valueOf(equipmentId));
    StringBuffer xmlStr = new StringBuffer("<refData>");
    appendAreaXml(xmlStr, project);
    appendUserData(xmlStr, project, helper);
    xmlStr.append("<areaSelected>").append(equipment.getArea().getId()).append("</areaSelected>");
    xmlStr.append("<unitMeasureId>").append(equipment.getArea().getId()).append("</unitMeasureId>");
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  private void appendUserData(StringBuffer xmlStr, Projects project, UCCHelper helper) {
    xmlStr.append("<editAccess>");
    xmlStr.append(userService.doesUserHaveEditAccessToThisProject(helper.getAuthenticatedUserID(), project));
    xmlStr.append("</editAccess>");
    xmlStr.append("<processRole>");
    xmlStr.append( userService.isUserInProcessRoleForThisProject(helper.getAuthenticatedUserID(), project));
    xmlStr.append("</processRole>");
    xmlStr.append("<mechanicalEngineerRole>");
    xmlStr.append( userService.isUserInMechanicalEngineerRoleForThisProject(helper.getAuthenticatedUserID(), project));
    xmlStr.append("</mechanicalEngineerRole>");
  }

  private Document getDocument(StringBuffer xmlStr) throws IOException {
    Document document;
    try {
      document = DOMUtil.stringToXML(xmlStr.toString());
    } catch (ParserException e) {
      throw new RuntimeException("Unable to parse process xml");
    }
    return document;
  }

  private void appendAreaXml(StringBuffer xmlStr, Projects project) {
    xmlStr.append("<areas>");
    for (Area area : project.getCrop().getAreas()) {
      xmlStr.append(area.toXml());
    }
    xmlStr.append("</areas>");
  }

}