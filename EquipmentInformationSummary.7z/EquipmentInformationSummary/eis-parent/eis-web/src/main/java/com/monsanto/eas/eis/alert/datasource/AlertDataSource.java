/*
 AlertDataSource was created on Feb 5, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.audit.service.AuditService;
import com.monsanto.eas.eis.audit.service.AuditServiceImpl;
import com.monsanto.eas.eis.controller.XmlDataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.services.ProjectsServiceImpl;
import com.monsanto.eas.eis.util.EISConstants;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: AlertDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 15:44:37 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class AlertDataSource implements XmlDataSource {
  private UCCHelper helper;
  private ProjectsService projectService;
  private AuditService auditService;
  private ProjectsDAOImpl projectDao;
  private PaginatedResult result = null;


  public AlertDataSource(UCCHelper helper) {
    this(helper, new ProjectsDAOImpl(), new ProjectsServiceImpl(), new AuditServiceImpl());
  }

  public AlertDataSource(UCCHelper helper,
                         ProjectsDAOImpl projectDAO, ProjectsService projectService, AuditService auditService) {
    this.helper = helper;
    this.projectDao = projectDAO;
    this.projectService = projectService;
    this.auditService = auditService;
  }

  public List<? extends XmlObject> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws
      IOException {
    User loginUser = (User) helper.getSessionParameter(EISConstants.LOGIN_USER);
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    insertChangeHistoryApprovalForEachEquipmentInProject(projectId);
    result = projectDao.lookupVerificationsNotApprovedForAnEquipment(projectId,
         loginUser.getUserId(), sortKey, sortDir, startIndex, maxResults);
    return result.getData();
  }

  private void insertChangeHistoryApprovalForEachEquipmentInProject(String projectId) {
    Projects project = this.projectService.lookupProjectByIdForAlert(new Long(projectId));
    this.auditService.insertChangeHistoryEntriesForEachProject(project);
  }

  public int getTotalRecords() {
   if(result == null){
      return DataSource.UNKNOWN_RECORD_COUNT;
    }
    return result.getTotalRecords();
  }
}