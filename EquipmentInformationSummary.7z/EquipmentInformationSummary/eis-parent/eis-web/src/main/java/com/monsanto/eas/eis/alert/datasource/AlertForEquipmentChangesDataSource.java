/*
 AlertForEquipmentChanges was created on Feb 11, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.datasource;

import com.monsanto.eas.eis.controller.XmlDataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.ServletFramework.UCCHelper;

import java.util.List;
import java.io.IOException;

/**
 * Filename:    $RCSfile: AlertForEquipmentChangesDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 15:44:37 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class AlertForEquipmentChangesDataSource implements XmlDataSource {
  private UCCHelper helper;
  private ProjectsDAOImpl projectDao;
  PaginatedResult result;


  public AlertForEquipmentChangesDataSource(UCCHelper helper) {
    this.helper = helper;
    this.projectDao = new ProjectsDAOImpl();
  }

  public AlertForEquipmentChangesDataSource(UCCHelper helper,
                         ProjectsDAOImpl projectDAO) {
    this.helper = helper;
    this.projectDao = projectDAO;
  }
  public List<? extends XmlObject> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws
      IOException {
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    result = projectDao.lookupAllEquipmentsAddedAndDeleted(projectId, sortKey, sortDir, startIndex, maxResults);
    return result.getData();
  }

  public int getTotalRecords() {
   if(result == null){
      return DataSource.UNKNOWN_RECORD_COUNT;
    }
    return result.getTotalRecords();
  }
}