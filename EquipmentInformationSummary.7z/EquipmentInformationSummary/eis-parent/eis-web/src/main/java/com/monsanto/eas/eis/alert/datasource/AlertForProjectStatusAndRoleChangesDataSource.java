/*
 AlertForProjectStatusAndRoleChangesDataSource was created on Feb 13, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.ProjectUserRole;
import com.monsanto.eas.eis.controller.XmlDataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.alert.domain.AlertForProjectRoleAndStatus;

import java.util.List;
import java.io.IOException;

/**
 * Filename:    $RCSfile: AlertForProjectStatusAndRoleChangesDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-23 23:24:53 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class AlertForProjectStatusAndRoleChangesDataSource implements XmlDataSource {
  private UCCHelper helper;
  private ProjectsDAOImpl projectsDAO;
   PaginatedResult result;

  public AlertForProjectStatusAndRoleChangesDataSource(UCCHelper helper){
   this(helper, new ProjectsDAOImpl());
  }

  public AlertForProjectStatusAndRoleChangesDataSource(UCCHelper helper, ProjectsDAOImpl projectsDAO
  ) {
    this.helper = helper;
    this.projectsDAO = projectsDAO;
  }

  public List<? extends XmlObject> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws
      IOException {
    User logonUser = (User) helper.getSessionParameter(EISConstants.LOGIN_USER);
    List<ProjectUserRole> projectUserRoleList = logonUser.getProjUserRoles();
    List<AlertForProjectRoleAndStatus> resultSet =
        projectsDAO.lookupAllStatusAndRoleChangesInAllProjectsForAUser(projectUserRoleList, sortKey, sortDir);
    result = new PaginatedResult(resultSet.size(), resultSet);
    return result.getData();
  }

  public int getTotalRecords() {
     if(result == null){
      return DataSource.UNKNOWN_RECORD_COUNT;
    }
    return result.getTotalRecords();
  }
}
