/*
 Alert was created on Feb 6, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.eas.eis.util.ConvertUtil;

import java.util.Map;

/**
 * Filename:    $RCSfile: Alert.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-18 19:19:35 $
 *
 * @author rrmall
 * @version $Revision: 1.3 $
 */
public class Alert implements XmlObject {
  private Integer projectId;
  private Integer equipmentId;
  private String equipmentNumber;
  private String equipmentName;
  private Integer processNotVerified;
  private Integer mechanicalNotVerified;
  private Integer electricalNotVerified;

  public Alert() {
  }

  public Alert(Object[] result) {
    processNotVerified = (Integer)result[0];
    mechanicalNotVerified = (Integer)result[1];
    electricalNotVerified = (Integer)result[2];
    equipmentId = (Integer)result[3];
    equipmentName = (String)result[4];
    equipmentNumber = (String)result[5];
    projectId = (Integer) result[6];
  }

  public Alert(Integer equipmentId, String equipmentNumber, String equipmentName,
               Integer processNotVerified, Integer mechanicalNotVerified, Integer electricalNotVerified,
               Integer projectId) {
    this.equipmentId = equipmentId;
    this.equipmentNumber = equipmentNumber;
    this.equipmentName = equipmentName;
    this.processNotVerified = processNotVerified;
    this.mechanicalNotVerified = mechanicalNotVerified;
    this.electricalNotVerified = electricalNotVerified;
    this.projectId = projectId;
  }

  public Integer getEquipmentId() {
    return equipmentId;
  }

  public String getEquipmentNumber() {
    return equipmentNumber;
  }

  public String getEquipmentName() {
    return equipmentName;
  }

  public Integer getProcessNotVerified() {
    return processNotVerified;
  }

  public Integer getMechanicalNotVerified() {
    return mechanicalNotVerified;
  }

  public Integer getElectricalNotVerified() {
    return electricalNotVerified;
  }

  public Integer getProjectId() {
    return projectId;
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer();
    xml.append("<alert>");
    xml.append("<id>");
    xml.appendValue(this.getEquipmentId()).append("</id>");
    xml.append("<equipmentNumber>");
    xml.appendValue(this.getEquipmentNumber()).append("</equipmentNumber>");
    xml.append("<equipmentName>");
    xml.appendValue(this.getEquipmentName()).append("</equipmentName>");
    xml.append("<processNotVerified>");
    xml.appendValue(this.getProcessNotVerified()).append("</processNotVerified>");
    xml.append("<mechanicalNotVerified>");
    xml.appendValue(this.getMechanicalNotVerified()).append("</mechanicalNotVerified>");
    xml.append("<electricalNotVerified>");
    xml.appendValue(this.getElectricalNotVerified()).append("</electricalNotVerified>");
    xml.append("<projectId>");
    xml.appendValue(this.getProjectId()).append("</projectId>");
    xml.append("</alert>");
    return xml.toString();
  }
}