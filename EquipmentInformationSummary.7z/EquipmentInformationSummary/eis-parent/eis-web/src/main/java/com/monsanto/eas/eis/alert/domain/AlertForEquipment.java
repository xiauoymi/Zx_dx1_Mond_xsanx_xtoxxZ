/*
 AlertForEquipment was created on Feb 11, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.eas.eis.util.ConvertUtil;

import java.util.Date;

/**
 * Filename:    $RCSfile: AlertForEquipment.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-24 18:49:44 $
 *
 * @author rrmall
 * @version $Revision: 1.4 $
 */
public class AlertForEquipment implements XmlObject {
  private Integer id;
  private String modifiedBy;
  private String equipmentNumber;
  private Date dateModified;
  private String addedOrDeleted;
  private Integer projectId;

  public AlertForEquipment() {
  }

  public AlertForEquipment(Object[] result) {
    this.id = (Integer)result[0];
    this.equipmentNumber = (String)result[1];
    this.dateModified = (Date)result[2];
    this.addedOrDeleted = (String)result[3];
    this.modifiedBy = (String)result[4];
    this.projectId = (Integer)result[5];
  }

  public AlertForEquipment(Integer equipmentId, String equipmentNumber, Date dateModified,
                           String addedOrDeleted, String modifiedBy, Integer projectId) {
    this.id = equipmentId;
    this.equipmentNumber = equipmentNumber;
    this.dateModified = dateModified;
    this.addedOrDeleted = addedOrDeleted;
    this.modifiedBy = modifiedBy;
    this.projectId = projectId;
  }

  public Integer getId() {
    return id;
  }

  public String getModifiedBy() {
    return modifiedBy;
  }

  public String getEquipmentNumber() {
    return equipmentNumber;
  }

  public Date getDateModified() {
    return dateModified;
  }

  public String getAddedOrDeleted() {
    return addedOrDeleted;
  }

  public Integer getProjectId() {
    return projectId;
  }

  public String toXml() {
     XMLBuffer xml = new XMLBuffer();
    xml.append("<alertForEquipmentAddDelete>");
    xml.append("<id>");
    xml.appendValue(this.getId()).append("</id>");
    xml.append("<equipmentNumber>");
    xml.appendValue(this.getEquipmentNumber()).append("</equipmentNumber>");
    xml.append("<modifiedBy>");
    xml.appendValue(this.getModifiedBy()).append("</modifiedBy>");
    String changeDateTime = ConvertUtil.toString(this.getDateModified(), ConvertUtil.DATE_PATTERN_SHORT);
    changeDateTime = changeDateTime == null ? "" : changeDateTime;
    xml.append("<dateModified>");
    xml.appendValue(changeDateTime).append("</dateModified>");
    xml.append("<addedOrDeleted>");
    xml.appendValue(this.getAddedOrDeleted()).append("</addedOrDeleted>");
    xml.append("<projectId>");
    xml.appendValue(this.getProjectId()).append("</projectId>");
    xml.append("</alertForEquipmentAddDelete>");
    return xml.toString();
  }
}