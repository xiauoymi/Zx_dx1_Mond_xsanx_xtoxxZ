/*
 AlertForProjectRoleAndStatus was created on Feb 13, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.ConvertUtil;

import java.util.Date;

/**
 * Filename:    $RCSfile: AlertForProjectRoleAndStatus.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-24 18:49:44 $
 *
 * @author rrmall
 * @version $Revision: 1.5 $
 */
public class AlertForProjectRoleAndStatus implements XmlObject {
  private Integer id;
  private String projectNumber;
  private String tableName;
  private Date dateModified;
  private String modifiedBy;

  public AlertForProjectRoleAndStatus() {
  }

  public AlertForProjectRoleAndStatus(Object[] result){
    this.modifiedBy = (String) result[0];
    this.dateModified = (Date) result[1];
    this.tableName = (String) result[2];
    this.projectNumber = (String) result[3];
    this.id = (Integer) result[4];
  }

  public AlertForProjectRoleAndStatus(Integer id, String projectNumber, String columnName, Date dateModified,
                                      String modifiedBy) {
    this.id = id;
    this.projectNumber = projectNumber;
    this.tableName = columnName;
    this.dateModified = dateModified;
    this.modifiedBy = modifiedBy;
  }

  public Integer getId() {
    return id;
  }

  public String getProjectNumber() {
    return projectNumber;
  }

  public String getTableName() {
    return tableName;
  }

  public Date getDateModified() {
    return dateModified;
  }

  public String getModifiedBy() {
    return modifiedBy;
  }

  public String toXml() {
      XMLBuffer xml = new XMLBuffer();
    String url = EISConstants.DATA_URL + "/equipment?method=lookupProjectXml&projectId=" + this.getId();
    xml.append("<alertForProjectRoleStatus>");
    xml.append("<id>");
    xml.appendValue(this.getId()).append("</id>");
    xml.append("<projectNumber>");
    xml.appendValue(this.getProjectNumber()).append("</projectNumber>");
    xml.append("<description>");
    String description = "";
    if (EISConstants.PROJ_USER_ROLE_TABLE.equalsIgnoreCase(this.getTableName())){
      description = "Project role(s) changed";
    }else if (EISConstants.PROJECTS_TABLE.equalsIgnoreCase(this.getTableName())){
      description = "Project Status changed";
    }
    xml.appendValue(description).append("</description>");
    String date = ConvertUtil.toString(this.getDateModified(), ConvertUtil.DATE_PATTERN_SHORT);
    date = date == null ? "" : date;
    xml.append("<dateModified>");
    xml.appendValue(date).append("</dateModified>");
    xml.append("<modifiedBy>");
    xml.appendValue(this.getModifiedBy()).append("</modifiedBy>");
    xml.append("<goToProjectUrl>");
    xml.appendValue(url).append("</goToProjectUrl>");
    xml.append("</alertForProjectRoleStatus>");
    return xml.toString();
  }
}