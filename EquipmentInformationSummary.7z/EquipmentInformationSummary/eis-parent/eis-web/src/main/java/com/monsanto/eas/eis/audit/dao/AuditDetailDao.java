package com.monsanto.eas.eis.audit.dao;

import com.monsanto.eas.eis.audit.domain.AuditDetail;
import com.monsanto.eas.eis.audit.domain.AuditTransactionApproval;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.alert.domain.Alert;

import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: AuditDetailDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-23 19:25:15 $
 *
 * @author rrmall
 * @version $Revision: 1.4 $
 */
public interface AuditDetailDao {
  PaginatedResult lookupAuditDetailsByCriteria(String projectId, Equipment equipment, String userId, String sortKey,
                                               String sortDir, int startIndex, int maxResults);

  AuditDetail findByPrimaryKey(Long id);
}
