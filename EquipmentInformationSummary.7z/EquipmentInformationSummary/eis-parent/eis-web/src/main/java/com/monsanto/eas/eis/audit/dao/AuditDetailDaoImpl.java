/*
 AuditDetailDaoImpl was created on Jan 14, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao;

import com.monsanto.eas.eis.audit.domain.AuditDetail;
import com.monsanto.eas.eis.audit.domain.ChangeHistory;
import com.monsanto.eas.eis.audit.domain.AuditTransactionApproval;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.criterion.Restrictions;

import java.util.*;

/**
 * Filename:    $RCSfile: AuditDetailDaoImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-23 19:25:15 $
 *
 * @author rrmall
 * @version $Revision: 1.11 $
 */
public class AuditDetailDaoImpl extends HibernateDAO<AuditDetail, Long> implements AuditDetailDao{

   public AuditDetailDaoImpl(HibernateFactory hibernate) {
    super(hibernate, AuditDetail.class);
  }

  public AuditDetailDaoImpl() {
    super(EISHibernateUtil.getHibernateFactory(), AuditDetail.class);
  }


  public AuditDetail findByPrimaryKey(Long id) {
    Criteria criteria = getCriteria();
    criteria.add(Restrictions.eq("id", id));
    return (AuditDetail) criteria.uniqueResult();
  }

  //protected only for testing
  protected Criteria getCriteria() {
    return createCriteria();
  }

  public PaginatedResult lookupAuditDetailsByCriteria(String projectId, Equipment equipment, String userId,
                                                       String sortKey, String sortDir, int startIndex, int maxResults){
     String objectIds = equipment.getEquipmentAndRelatedIds();

     String changeHistoryQuery = getQueryToGenerateChangeHistoryReport(projectId, objectIds, sortKey, sortDir);

     Integer recordCount = getTotalRecordCountForChangeHistory(changeHistoryQuery);

    int maxRecordsToFetch = getMaxRecordCountForQuery(startIndex, maxResults, recordCount);

    String changeHistoryPaginatedResultsQuery = getPaginatedRecordsForChangeHistoryQuery(changeHistoryQuery, startIndex,
        maxRecordsToFetch);

     List results = getResultsForChangeHistoryPaginatedResultsQuery(changeHistoryPaginatedResultsQuery);

     List<ChangeHistory> changeHistoryList = createChangeHistoryList(results);
     return new PaginatedResult(recordCount.intValue(), changeHistoryList);
  }

  private int getMaxRecordCountForQuery(int startIndex, int maxResults, Integer recordCount) {
    int maxRecordsToFetch = startIndex + maxResults;
    if (maxRecordsToFetch == 0){
      maxRecordsToFetch = recordCount.intValue();
    }
    return maxRecordsToFetch;
  }

  private Integer getTotalRecordCountForChangeHistory(String changeHistoryQuery) {
    String recordCountQuery = getRecordCountForChangeHistoryQuery(changeHistoryQuery);
    Integer recordCount = (Integer)this.getHibernate().getSession().createSQLQuery(recordCountQuery)
        .addScalar("totalRecords", Hibernate.INTEGER).uniqueResult();
    return recordCount;
  }

  private List getResultsForChangeHistoryPaginatedResultsQuery(String changeHistoryPaginatedResultsQuery) {
    return this.getHibernate().getSession().createSQLQuery(changeHistoryPaginatedResultsQuery)
       .addScalar("id", Hibernate.LONG)
        .addScalar("columnName", Hibernate.STRING)
        .addScalar("oldValue", Hibernate.STRING)
        .addScalar("newValue", Hibernate.STRING)
        .addScalar("changeDateTime", Hibernate.TIMESTAMP)
        .addScalar("auditRequestor", Hibernate.STRING)
        .addScalar("transactionId", Hibernate.LONG)
        .addScalar("tabName", Hibernate.STRING)
        .addScalar("process", Hibernate.STRING)
        .addScalar("mechanical", Hibernate.STRING)
        .addScalar("electrical", Hibernate.STRING)
        .addScalar("componentNumber", Hibernate.STRING).list();
  }

  private String getQueryToGenerateChangeHistoryReport(String projectId,  String keyValue,
                                                      String sortKey, String sortDir) {
     StringBuffer sqlQuery  = new StringBuffer();
       sqlQuery.append("select d.audit_detail_id as id, ")
        .append("eis.get_column_header('EIS', h.table_name, d.column_name, h.key_value, cref.column_description) as columnName, ")
        .append("eis.get_reference_value('EIS', h.table_name, d.column_name, d.old_value) as oldValue, ")
        .append("eis.get_reference_value('EIS', h.table_name, d.column_name, d.new_value) as newValue, ")
        .append("h.change_datetime as changeDateTime, t.audit_requestor as auditRequestor, ")
        .append("t.audit_transaction_id as transactionId, ")
        .append("eis.get_tab_name('EIS', h.table_name, d.column_name) as tabName, ")
        .append("tranApproval.process as process, tranApproval.mechanical as mechanical, ")
        .append("tranApproval.electrical as electrical, ")
        .append("eis.get_component_number('EIS', h.table_name, d.column_name, h.key_value) as componentNumber ")
        .append("from (select h.key_value,  d.column_name, max(h.change_datetime) last_change from eis.audit_header h ")
        .append("inner join eis.audit_detail d ")
        .append("on d.audit_header_id = h.audit_header_id ")
        .append("where h.key_value in (").append(keyValue).append(") and h.change_datetime >= (SELECT max(h2.change_datetime) ")
        .append("FROM eis.audit_detail d1, eis.audit_header h2 ")
        .append("WHERE h2.key_value = '").append(projectId).append("' ")
        .append("AND d1.column_name = 'STATUS_ID' ")
        .append("AND d1.new_value in (SELECT status.id FROM eis.eis_proj_status status ")
        .append("WHERE status.status_name = 'Detailed Design') ").append("AND d1.audit_header_id = h2.audit_header_id)")
        .append("AND  d.column_name != 'IS_DELETED' ").append("AND d.old_value IS NOT NULL ")
        .append("group by ").append("h.key_value, ").append("d.column_name) lastchanges ")
        .append("inner join eis.audit_header h on h.key_value = lastchanges.key_value and h.change_datetime = lastchanges.last_change ")
        .append(" and h.operation_type in ('U', 'D') ")
        .append("inner join eis.audit_detail d on h.audit_header_id = d.audit_header_id and d.column_name = lastchanges.column_name ")
        .append("left outer join eis.audit_transaction t on t.audit_transaction_id = h.audit_transaction_id ")
        .append("left outer join eis.audit_transaction_approval tranApproval ")
        .append("on tranApproval.audit_detail_id = d.audit_detail_id ")
        .append("left outer join eis.eis_column_name_ref cref ")
        .append("on  cref.column_name = d.column_name and cref.table_name = h.table_name ");
    if (sortKey != null && sortDir != null){
      sqlQuery.append("order by ").append(sortKey).append(" ").append(sortDir);
    }
     return sqlQuery.toString();

   }

  private String getRecordCountForChangeHistoryQuery(String sqlQueryForChangeHistory) {
    StringBuffer sqlQuery  = new StringBuffer();
    sqlQuery.append("select count(*) as totalRecords from (").append(sqlQueryForChangeHistory).append(")");
    return sqlQuery.toString();
  }

  private String getPaginatedRecordsForChangeHistoryQuery(String sqlQueryForChangeHistory, int startIndex, int maxResults) {
    StringBuffer sqlQuery  = new StringBuffer();
    sqlQuery.append("select * from (select").append(" row_.*, rownum rownum_  from (")
        .append(sqlQueryForChangeHistory).append(") row_ where rownum <=").append(maxResults).append(") where rownum_ >")
        .append(startIndex);
    return sqlQuery.toString();
  }

  private List<ChangeHistory> createChangeHistoryList(List results) {
    Iterator resultsIterator = results.iterator();
    List<ChangeHistory> changeHistoryList = new ArrayList<ChangeHistory>();
    while(resultsIterator.hasNext()){
      Object[] object = (Object[])resultsIterator.next();
      ChangeHistory history = createNewChangeHistoryObject(object);
      if (!(history.getIsProcessVerified() && history.getIsMechanicalVerified() && history.getIsElectricalVerified())){
          changeHistoryList.add(history);
      }
    }
    return changeHistoryList;
  }

  private ChangeHistory createNewChangeHistoryObject(Object[] result) throws ClassCastException{
    try{
    return new ChangeHistory(result);
    }catch (ClassCastException e){
      throw new RuntimeException(e);
    }
  }
}