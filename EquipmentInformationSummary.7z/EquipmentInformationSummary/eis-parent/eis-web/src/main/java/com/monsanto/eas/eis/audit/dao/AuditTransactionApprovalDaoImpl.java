/*
 AuditTransactionApprovalDaoImpl was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao;

import com.monsanto.eas.eis.audit.domain.AuditTransactionApproval;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.Util.StringUtils;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    $RCSfile: AuditTransactionApprovalDaoImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-23 19:25:15 $
 *
 * @author rrmall
 * @version $Revision: 1.4 $
 */
public class AuditTransactionApprovalDaoImpl extends HibernateDAO<AuditTransactionApproval, Long>  implements AuditTransactionApprovalDao{

  public AuditTransactionApprovalDaoImpl() {
    super(EISHibernateUtil.getHibernateFactory(), AuditTransactionApproval.class);
  }

  public AuditTransactionApprovalDaoImpl(HibernateFactory factory) {
    super(factory, AuditTransactionApproval.class);
  }


  public List<AuditTransactionApproval> findByCriteria(String id, Long auditDetailId, Long auditTransactionId) {
    Criteria criteria = getCriteria();
    addRestriction(criteria, "id", id);
    addRestrictionIfNotNull(criteria, "detail.id", auditDetailId);
    addRestrictionIfNotNull(criteria, "transaction.id", auditTransactionId);
    criteria.addOrder(Order.asc("id"));
    return criteria.list();
  }

  private void addRestrictionIfNotNull(Criteria criteria, String propertyName, Long value) {
    if (value != null && !StringUtils.isNullOrEmpty(value.toString())){
      criteria.add(Restrictions.eq(propertyName, value));
    }
  }

  private void addRestriction(Criteria criteria, String columnName, String value) {
    if (!StringUtils.isNullOrEmpty(value)){
        criteria.add(Restrictions.eq(columnName, value).ignoreCase());
    }
  }

  //protected only for test.
  protected Criteria getCriteria() {
    return createCriteria();
  }

  public AuditTransactionApproval save(AuditTransactionApproval entity) {
    return super.save(entity);
  }

  public List lookupAllChangesForAnEquipmentNotInTransactionApproval(Equipment equipment){
    String objectIds = equipment.getEquipmentAndRelatedIds();
    String projectId = equipment.getProjects().getId().toString();
    String query = getQueryToLookupAllChangesForAnEquipment(projectId, objectIds);

    return this.getHibernate().getSession().createSQLQuery(query)
        .addScalar("tranId", Hibernate.LONG)
        .addScalar("detailid", Hibernate.LONG)
        .addScalar("lastChange", Hibernate.TIMESTAMP)
        .addScalar("columnName", Hibernate.STRING)
        .list();
  }

 private String getQueryToLookupAllChangesForAnEquipment(String projectId, String objectIds
 ) {
        StringBuffer sqlQuery = new StringBuffer();
        sqlQuery.append("SELECT h.audit_transaction_id tranId, d.audit_detail_id detailid, MAX(h.change_datetime) lastChange, ")
            .append("d.column_name columnName FROM eis.audit_header h ")
            .append("INNER JOIN eis.audit_detail d ON d.audit_header_id = h.audit_header_id ")
            .append("WHERE h.key_value IN (").append(objectIds).append(") AND h.change_datetime >=  ")
            .append("(SELECT MAX(h2.change_datetime)  FROM eis.audit_detail d1, eis.audit_header h2 ")
            .append("WHERE h2.key_value = to_char(").append(projectId).append(")  AND d1.column_name = 'STATUS_ID' ")
            .append("AND d1.new_value IN ").append("   (SELECT status.id ")
            .append("FROM eis.eis_proj_status status ")
            .append("WHERE status.status_name = 'Detailed Design') ")
            .append("AND d1.audit_header_id = h2.audit_header_id) AND d.column_name != 'IS_DELETED' ")
            .append("AND d.old_value IS NOT NULL ").append(" ").append("   and not exists ( ")
            .append("select ata.audit_detail_id  ").append("   from eis.audit_transaction_approval ata ")
            .append("where ata.audit_detail_id = d.audit_detail_id ) ")
            .append("GROUP BY h.key_value, h.audit_transaction_id, d.column_name, d.audit_detail_id");
        return sqlQuery.toString();
 }

}