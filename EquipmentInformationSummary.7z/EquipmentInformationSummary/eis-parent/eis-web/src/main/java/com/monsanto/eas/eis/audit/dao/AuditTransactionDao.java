/*
 AuditTransactionDao was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao;

import com.monsanto.eas.eis.audit.domain.AuditTransaction;
import com.monsanto.eas.eis.audit.domain.AuditTransactionApproval;
import com.monsanto.eas.eis.projects.domain.Equipment;

import java.util.List;

/**
 * Filename:    $RCSfile: AuditTransactionDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-23 19:25:15 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public interface AuditTransactionDao {
  List<AuditTransaction> findByCriteria(Long id, String auditRequestor);

  AuditTransaction findByPrimaryKey(Long transactionId);
}