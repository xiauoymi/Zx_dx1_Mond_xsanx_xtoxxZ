/*
 AuditTransactionDaoImpl was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.eas.eis.audit.domain.AuditTransaction;
import com.monsanto.eas.eis.audit.domain.AuditDetail;
import com.monsanto.eas.eis.audit.domain.AuditTransactionApproval;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Order;

import java.util.List;

/**
 * Filename:    $RCSfile: AuditTransactionDaoImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-23 19:25:15 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class AuditTransactionDaoImpl extends HibernateDAO<AuditTransaction, Long> implements AuditTransactionDao {

  public AuditTransactionDaoImpl() {
    super(EISHibernateUtil.getHibernateFactory(), AuditTransaction.class);
  }

  public AuditTransactionDaoImpl(HibernateFactory hibernate) {
    super(hibernate, AuditTransaction.class);
  }

  public List<AuditTransaction> findByCriteria(Long id, String auditRequestor) {
    Criteria criteria = getCriteria();
    if (id != null){
      criteria.add(Restrictions.eq("id", id));
    }
    addRestriction(criteria, "audit_requestor", auditRequestor);
    criteria.addOrder(Order.asc("id"));
    return criteria.list();
  }

  private void addRestriction(Criteria criteria, String columnName, String value) {
    if (!StringUtils.isNullOrEmpty(value)){
        criteria.add(Restrictions.eq(columnName, value));
    }
  }

  //protected only for test.
  protected Criteria getCriteria() {
    return createCriteria();
  }

  public AuditTransaction findByPrimaryKey(Long id){
    Criteria criteria = getCriteria();
    criteria.add(Restrictions.eq("id", id));
    return (AuditTransaction) criteria.uniqueResult();
  }
}