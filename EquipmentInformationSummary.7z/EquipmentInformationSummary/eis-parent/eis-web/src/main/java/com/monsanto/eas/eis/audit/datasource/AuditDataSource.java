/*
 AuditDataSource was created on Jan 14, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.audit.service.AuditService;
import com.monsanto.eas.eis.audit.service.AuditServiceImpl;
import com.monsanto.eas.eis.controller.XmlDataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.util.*;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.equipment.service.EquipmentService;
import com.monsanto.eas.eis.equipment.service.EquipmentServiceImpl;
import com.monsanto.Util.StringUtils;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: AuditDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 20:46:49 $
 *
 * @author rrmall
 * @version $Revision: 1.4 $
 */
public class AuditDataSource implements XmlDataSource {
  private UCCHelper helper;
  private AuditService auditService;
  private PaginatedResult result = null;
  private EquipmentService equipmentService;

  public AuditDataSource(UCCHelper helper) {
    this(helper, new AuditServiceImpl(), new EquipmentServiceImpl());
  }

  public AuditDataSource(UCCHelper helper, AuditService auditService, EquipmentService equipmentService) {
    this.helper = helper;
    this.auditService = auditService;
    this.equipmentService = equipmentService;
  }

  public List<? extends XmlObject> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws
      IOException {
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    String equipmentId = helper.getRequestParameterValue(EISConstants.EQUIPMENT_ID);
    Equipment equipment = this.equipmentService.lookupEquipment(new Long(equipmentId));
     if (StringUtils.isNullOrEmpty(projectId)){
      projectId = equipment.getProjects().getId().toString();
    }
    result = this.auditService.lookupChangeHistoryByCriteria(projectId, equipment, helper.getAuthenticatedUserID(),
        sortKey, sortDir, startIndex, maxResults);
    return result.getData();
  }

  public int getTotalRecords() {
    if(result == null){
      return DataSource.UNKNOWN_RECORD_COUNT;
    }
    return result.getTotalRecords();
  }
}