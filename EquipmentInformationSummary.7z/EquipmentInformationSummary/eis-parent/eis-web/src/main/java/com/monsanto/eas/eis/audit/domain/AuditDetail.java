/*
 AuditDetail was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;

import javax.persistence.*;

import org.w3c.dom.Document;


/**
 * Filename:    $RCSfile: AuditDetail.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 15:31:29 $
 *
 * @author rrmall
 * @version $Revision: 1.3 $
 */
@Entity
@NoDeleteAllowed
@Table(schema="EIS", name = "audit_detail")
public class AuditDetail implements XmlObject {
  @Id
  @Column(name="AUDIT_DETAIL_ID")
  private Long id;

  @ManyToOne
  @JoinColumn(name = "AUDIT_HEADER_ID")
  private AuditHeader header;

  @Column(name="COLUMN_NAME")
  private String column_name;

  @Column(name="OLD_VALUE")
  private String old_value;

  @Column(name="NEW_VALUE")
  private String new_value;

  public AuditDetail() {
  }

  public AuditDetail(Long id, AuditHeader header, String column_name, String old_value, String new_value) {
    this.id = id;
    this.header = header;
    this.column_name = column_name;
    this.old_value = old_value;
    this.new_value = new_value;
  }

  public Long getId() {
    return id;
  }

  public AuditHeader getHeader(){
    return header;
  }
  

  public String getColumn_name() {
    return column_name;
  }

  public String getOld_value() {
    return old_value;
  }

  public String getNew_value() {
    return new_value;
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer();
    xml.append("<auditDetail>");
    xml.append("<columnName>");
    xml.appendValue(this.getColumn_name()).append("</columnName>");
    xml.append("<oldValue>");
    xml.appendValue(this.getOld_value()).append("</oldValue>");
    xml.append("<newValue>");
    xml.appendValue(this.getNew_value()).append("</newValue>");
    xml.append("</auditDetail>");
    return xml.toString();
  }

  public void setId(Long id) {
    this.id = id;
  }
}