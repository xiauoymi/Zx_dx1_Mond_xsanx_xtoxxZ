/*
 AuditHeader was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.domain;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

/**
 * Filename:    $RCSfile: AuditHeader.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-01-27 18:27:01 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */

@Entity
@NoDeleteAllowed
@Table(schema="EIS",  name="AUDIT_HEADER")
public class AuditHeader {

  @Id
  @Column(name="AUDIT_HEADER_ID")
  private Long headerId;

  @Column(name="OPERATION_TYPE")
  private String operation_type;

  @Column(name="CHANGE_DATETIME")
  private Date changeDateTime;

  @Column(name="TABLE_NAME")
  private String table_name;

  @Column(name="KEY_VALUE")
  private String keyForTable;

  @OneToMany(mappedBy = "header",
      targetEntity = AuditDetail.class, cascade = CascadeType.ALL)
   private List<AuditDetail> detailList = new ArrayList<AuditDetail>();

  @ManyToOne
  @JoinColumn(name="AUDIT_TRANSACTION_ID")
  private AuditTransaction transaction;

  public AuditHeader() {
  }

  public AuditHeader(Long id, String operation_type, Date changeDateTime, String table_name, String keyForTable, AuditTransaction transaction) {
    this.headerId = id;
    this.operation_type = operation_type;
    this.changeDateTime = changeDateTime;
    this.table_name = table_name;
    this.keyForTable = keyForTable;
    this.transaction = transaction;
  }

  public Long getId() {
    return headerId;
  }

  public String getOperation_type() {
    return operation_type;
  }

  public Date getChangeDateTime() {
    return changeDateTime;
  }

  public String getTable_name() {
    return table_name;
  }

  public String getKeyForTable() {
    return keyForTable;
  }

  public List<AuditDetail> getDetailList() {
    return detailList;
  }

  public AuditTransaction getTransaction() {
    return transaction;
  }
}