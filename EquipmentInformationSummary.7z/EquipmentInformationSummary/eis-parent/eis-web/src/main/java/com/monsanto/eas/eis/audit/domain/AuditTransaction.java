/*
 AuditTransaction was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.domain;

import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

/**
 * Filename:    $RCSfile: AuditTransaction.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-01-27 18:27:01 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name="AUDIT_TRANSACTION")
public class AuditTransaction {
  @Id
  @Column(name="AUDIT_TRANSACTION_ID")
  private Long id;

  @Column(name= "AUDIT_REQUESTOR")
  private String audit_requestor;

  @OneToMany(mappedBy = "transaction",
      targetEntity = AuditHeader.class, cascade = CascadeType.ALL)
    private List<AuditHeader> headers = new ArrayList<AuditHeader>();

  public AuditTransaction() {
  }

  public AuditTransaction(Long id, String auditRequestor) {
    this.id = id;
    this.audit_requestor = auditRequestor;
  }

  public Long getId() {
    return id;
  }

  public List<AuditHeader> getHeaders() {
    return headers;
  }

  public String getAudit_requestor() {
    return audit_requestor;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void setAudit_requestor(String audit_requestor) {
    this.audit_requestor = audit_requestor;
  }

  public void setHeaders(List<AuditHeader> headers) {
    this.headers = headers;
  }
}
