/*
 AuditTransactionApproval was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.domain;

import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;
import java.util.Date;

/**
 * Filename:    $RCSfile: AuditTransactionApproval.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 15:31:29 $
 *
 * @author rrmall
 * @version $Revision: 1.4 $
 */

@Entity
@Table(schema="EIS", name="AUDIT_TRANSACTION_APPROVAL")
@NoDeleteAllowed
public class AuditTransactionApproval {

  @Id
  @SequenceGenerator(name = "equipmentSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "equipmentSeqGen")
  @Column(name="ID")
  private Long id;

  @ManyToOne
  @JoinColumn(name = "AUDIT_TRANSACTION_ID")
  private AuditTransaction transaction;

  @ManyToOne 
  @JoinColumn(name = "AUDIT_DETAIL_ID")
  private AuditDetail detail;

  @ManyToOne (targetEntity = User.class)
  @JoinColumn(name = "PROCESS")
  private User processApprover;

  @ManyToOne (targetEntity = User.class)
  @JoinColumn(name = "MECHANICAL")
  private User mechanicalApprover;

  @ManyToOne (targetEntity = User.class)
  @JoinColumn(name = "ELECTRICAL")
  private User electricalApprover;

  @ManyToOne(targetEntity = Equipment.class)
  @JoinColumn(name="EQUIPMENT_ID")
  private Equipment equipment;

  @Column(name="CHANGE_DATETIME")
  private Date changeDateTime;

  @Column(name="COLUMN_NAME")
  private String columnName;

  public AuditTransactionApproval() {
  }

  public AuditTransactionApproval(Long id, AuditTransaction transaction, AuditDetail detail, User process,
                                  User mechanical,
                                  User electrical, Equipment equipment, Date changeDateTime, String columnName) {
    this.id = id;
    this.transaction = transaction;
    this.detail = detail;
    this.processApprover = process; //process
    this.mechanicalApprover = mechanical; //mechanical
    this.electricalApprover = electrical; //electrical
    this.equipment = equipment;
    this.changeDateTime = changeDateTime;
    this.columnName = columnName;
  }

  public Long getId() {
    return id;
  }

  public AuditTransaction getTransaction() {
    return transaction;
  }

  public AuditDetail getDetail() {
    return detail;
  }

  public User getProcessApprover() {
    return processApprover;
  }

  public User getMechanicalApprover() {
    return mechanicalApprover;
  }

  public User getElectricalApprover() {
    return electricalApprover;
  }

  public void setProcessApprover(User processApprover) {
    this.processApprover = processApprover;
  }

  public void setMechanicalApprover(User mechanicalApprover) {
    this.mechanicalApprover = mechanicalApprover;
  }

  public void setElectricalApprover(User electricalApprover) {
    this.electricalApprover = electricalApprover;
  }

  public Equipment getEquipment() {
    return equipment;
  }

  public Date getChangeDateTime() {
    return changeDateTime;
  }

  public String getColumnName() {
    return columnName;
  }
}