/*
 ChangeHistory was created on Jan 14, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.domain;

import com.monsanto.Util.StringUtils;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.XMLBuffer;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.sql.Timestamp;

/**
 * Filename:    $RCSfile: ChangeHistory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date:
 * 2009/02/18 14:10:21 $
 *
 * @author rrmall
 * @version $Revision: 1.6 $
 */

public class ChangeHistory implements XmlObject {
  private Long auditDetailId;
  private String columnName;
  private String oldValue;
  private String newValue;
  private Timestamp changeTime;
  private String auditRequestor;
  private Long transactionId;
  private String tabName;
  private boolean processVerified;
  private boolean mechanicalVerified;
  private boolean electricalVerified;
  private String componentNumber;

  public ChangeHistory() {
  }

  public ChangeHistory(Object[] result) {
    this.auditDetailId = (Long) result[0];
    this.columnName = (String) result[1];
    this.oldValue = (String) result[2];
    this.newValue = (String) result[3];
    this.changeTime = (Timestamp) result[4];
    this.auditRequestor = (String) result[5];
    this.transactionId = (Long) result[6];
    this.tabName = (String) result[7];
    this.processVerified = getBooleanValue((String) result[8]);
    this.mechanicalVerified = getBooleanValue((String) result[9]);
    this.electricalVerified = getBooleanValue((String) result[10]);
    this.componentNumber = (String) result[11];
  }

  private boolean getBooleanValue(String s) {
    return (s != null);
  }

  public Long getAuditDetailId() {
    return auditDetailId;
  }

  public String getColumnName() {
    return columnName;
  }

  public String getOldValue() {
    return oldValue;
  }

  public String getNewValue() {
    return newValue;
  }

  public Timestamp getChangeTime() {
    return changeTime;
  }

  public String getAuditRequestor() {
    return auditRequestor;
  }

  public boolean getIsProcessVerified() {
    return processVerified;
  }

  public boolean getIsMechanicalVerified() {
    return mechanicalVerified;
  }

  public boolean getIsElectricalVerified() {
    return electricalVerified;
  }

  public Long getTransactionId() {
    return transactionId;
  }

  public String getTabName() {
    return tabName;
  }

  public String getComponentNumber() {
    return componentNumber;
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer();
    String url = EISConstants.DATA_URL + "/equipment?method=updateVerificationForEquipmentChange&auditDetailId=" +
        this.getAuditDetailId() +
        "&auditTransactionId=" + this.getTransactionId();
    xml.append("<changeHistory>");
    xml.append("<auditDetailId>");
    xml.appendValue(this.getAuditDetailId()).append("</auditDetailId>");
    xml.append("<auditTransactionId>");
    xml.appendValue(this.getTransactionId()).append("</auditTransactionId>");
    xml.append("<tabName>");
    xml.appendValue(this.getTabName()).append("</tabName>");
    xml.append("<componentNumber>");
    xml.appendValue(this.getComponentNumber()).append("</componentNumber>");
    xml.append("<columnName>");
    xml.appendValue(this.getColumnName()).append("</columnName>");
    xml.append("<oldValue>");
    xml.appendValue(formatValue(this.getOldValue())).append("</oldValue>");
    xml.append("<newValue>");
    xml.appendValue(formatValue(this.getNewValue())).append("</newValue>");
    String changeDateTime = ConvertUtil.toString(this.getChangeTime(), ConvertUtil.PROJECTS_DATE_FORMAT);
    changeDateTime = changeDateTime == null ? "" : changeDateTime;
    xml.append("<changeDateTime>");
    xml.appendValue(changeDateTime).append("</changeDateTime>");
    xml.append("<auditRequestor>");
    xml.appendValue(this.getAuditRequestor()).append("</auditRequestor>");
    xml.append("<processVerified>");
    xml.appendValue(Boolean.valueOf(this.getIsProcessVerified())).append("</processVerified>");
    xml.append("<mechanicalVerified>");
    xml.appendValue(Boolean.valueOf(this.getIsMechanicalVerified())).append("</mechanicalVerified>");
    xml.append("<electricalVerified>");
    xml.appendValue(Boolean.valueOf(this.getIsElectricalVerified())).append("</electricalVerified>");
    xml.append("<updateUserVerifiedUrl>");
    xml.appendValue(url).append("</updateUserVerifiedUrl>");
    xml.append("</changeHistory>");
    return xml.toString();
  }

  private String formatValue(String str) {
    return StringUtils.isNullOrEmpty(str) ? "" : str;
  }
}