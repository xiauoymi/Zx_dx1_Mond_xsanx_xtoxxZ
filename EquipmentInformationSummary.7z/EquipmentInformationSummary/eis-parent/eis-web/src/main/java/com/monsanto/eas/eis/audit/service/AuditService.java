/*
 AuditService was created on Jan 13, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.service;

import com.monsanto.eas.eis.audit.domain.AuditDetail;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.alert.domain.Alert;

import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: AuditService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 15:39:45 $
 *
 * @author rrmall
 * @version $Revision: 1.4 $
 */
public interface AuditService {
  PaginatedResult lookupChangeHistoryByCriteria(String projectId, Equipment equipment, String userId, String sortKey,
                                                String sortDir, int startIndex, int maxResults);

  void updateVerificationForEquipmentChange(String detailId, String tranId, String changeVerifiedColumn, User user);

//  PaginatedResult getListOfChangesNotApprovedForAnEquipment(String projectId, String userId,
//                                                            String sortKey, String sortDir, int startIndex,
//                                                            int maxResults);

  void insertChangeHistoryEntriesForEachProject(Projects project);
}