/*
 AuditServiceImpl was created on Jan 13, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.service;

import com.monsanto.eas.eis.audit.domain.AuditTransaction;
import com.monsanto.eas.eis.audit.domain.AuditTransactionApproval;
import com.monsanto.eas.eis.audit.domain.ChangeHistory;
import com.monsanto.eas.eis.audit.dao.*;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;

import java.util.List;
import java.util.Iterator;
import java.sql.Timestamp;

/**
 * Filename:    $RCSfile: AuditServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-23 19:25:15 $
 *
 * @author rrmall
 * @version $Revision: 1.7 $
 */
public class AuditServiceImpl implements AuditService{
    private AuditDetailDao detailDao;
    private GenericDAO<AuditTransaction, Long> transactionDao;
    private AuditTransactionApprovalDao approvalDao;

   public AuditServiceImpl() {
    this(new AuditDetailDaoImpl(),
        new HibernateDAO<AuditTransaction, Long>(EISHibernateUtil.getHibernateFactory(), AuditTransaction.class),
        new AuditTransactionApprovalDaoImpl());
  }
  public AuditServiceImpl(AuditDetailDao detailDao,
                          GenericDAO<AuditTransaction, Long> transactionDao,
                          AuditTransactionApprovalDao approvalDao) {
    this.detailDao = detailDao;
    this.transactionDao = transactionDao;
    this.approvalDao = approvalDao;
  }

  public PaginatedResult lookupChangeHistoryByCriteria(String project, Equipment equipment, String userId,
                                                       String sortKey, String sortDir, int startIndex, int maxResults){
    PaginatedResult resultSet = this.detailDao.lookupAuditDetailsByCriteria(project, equipment, userId, sortKey,
        sortDir, startIndex, maxResults);
    insertChangeHistoryEntriesIntoApprovalTable((List<ChangeHistory>) resultSet.getData(), equipment);
    return resultSet;
  }

  public void updateVerificationForEquipmentChange(String detailId, String tranId, String changeVerifiedColumn,
                                                   User user) {
    List<AuditTransactionApproval> approvalList = approvalDao.findByCriteria(null, new Long(detailId), new Long(tranId));
    for(AuditTransactionApproval approval: approvalList){
      determineWhichUserRoleVerifiedTheChange(changeVerifiedColumn, user, approval);
      approvalDao.save(approval);
    }
  }

  private void determineWhichUserRoleVerifiedTheChange(String changeVerifiedColumn, User user,
                                                       AuditTransactionApproval approval) {
    if ("processVerified".equalsIgnoreCase(changeVerifiedColumn)){
      approval.setProcessApprover(user);
    }
    if ("mechanicalVerified".equalsIgnoreCase(changeVerifiedColumn)){
      approval.setMechanicalApprover(user);
    }
    if ("electricalVerified".equalsIgnoreCase(changeVerifiedColumn)){
      approval.setElectricalApprover(user);
    }
  }

   private void insertChangeHistoryEntriesIntoApprovalTable(List<ChangeHistory> changeHistoryList,
                                                            Equipment equipment) {
    for (ChangeHistory changeHistory : changeHistoryList){
      if (approvalDao.findByCriteria(null, changeHistory.getAuditDetailId(), null).size() == 0) {
        AuditTransactionApproval approval = new AuditTransactionApproval(null, transactionDao.findByPrimaryKey(
            changeHistory.getTransactionId()),
            detailDao.findByPrimaryKey(changeHistory.getAuditDetailId()), null, null, null, equipment, changeHistory.getChangeTime(),
            changeHistory.getColumnName());
        approvalDao.save(approval);
      }
    }
  }

  public void insertChangeHistoryEntriesForEachProject(Projects project){
    for (Equipment equipment: project.getEquipments()){
      List results = this.approvalDao.lookupAllChangesForAnEquipmentNotInTransactionApproval(equipment);
      Iterator resultsIterator = results.iterator();
      if (resultsIterator.hasNext()) {
       while (resultsIterator.hasNext()) {
         Object[] result = (Object[]) resultsIterator.next();
         approvalDao.save(new AuditTransactionApproval(null, transactionDao.findByPrimaryKey((Long) result[0]),
             detailDao.findByPrimaryKey((Long) result[1]), null, null, null, equipment,
             (Timestamp) result[2], (String) result[3]));
       }
     }
    }
  }
}