/*
 AutosaveController was created on Dec 9, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.autosave;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.controller.EISController;
import com.monsanto.eas.eis.equipment.service.ProcessService;
import com.monsanto.eas.eis.equipment.service.ProcessServiceImpl;
import com.monsanto.eas.eis.projects.domain.ProcessFieldEquipmentType;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;

/**
 * Filename:    $RCSfile: AutosaveController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $ On:	$Date:
 * 2008/12/11 19:21:16 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class AutosaveController extends EISController {
  String OBJECT = "__AUTOSAVE_OBJECT";
  String OBJECT_ID = "__AUTOSAVE_OBJECT_ID";
  String SESSION_ID = "__AUTOSAVE_SESSION_ID";
  String SESSION_SEQ = "__AUTOSAVE_SESSION_SEQ";

  protected void notSpecified(UCCHelper helper) throws IOException {
  }

  public void autosaveField(UCCHelper helper) throws Exception {
    String clazzName = helper.getRequestParameterValue("className");
    String primaryKey = helper.getRequestParameterValue("primaryKey");
    String fieldName = getFieldName(helper.getRequestParameterValue("fieldName"));
    String fieldValue = helper.getRequestParameterValue("fieldValue");
    Class<?> clazz = getClass(clazzName);

    Class<?> fieldType = getFieldType(fieldName, clazz);
    Method setter = findMethod(fieldName, fieldType, clazz);
    Object value = getValue(fieldValue, fieldType);

    GenericDAO<Object, Long> dao = getHibernateDao(clazz);
    Object object = dao.findByPrimaryKey(new Long(primaryKey));
    setter.invoke(object, value);

    dao.save(object);
    helper.getPrintWriter().write("ok");
  }

  public void autosaveProcessFieldEquipmentType(UCCHelper helper) throws Exception {
    String processId = helper.getRequestParameterValue("processId");
    String fieldName = helper.getRequestParameterValue("fieldName");
    String fieldValue = helper.getRequestParameterValue("fieldValue");
    ProcessFieldEquipmentType processFieldEquipmentType = getProcessService()
        .lookupProcessFieldEquipmentTypeByFieldName(new Long(processId), fieldName);
    processFieldEquipmentType.setValue(fieldValue);
    helper.setRequestAttributeValue("pfe", processFieldEquipmentType);//setting in helper onyl for testing
    helper.getPrintWriter().write("ok");
  }

  private String getFieldName(String fieldName) {
    if (fieldName.endsWith("Id")) {
      fieldName = fieldName.substring(0, fieldName.length() - 2);
    }
    return fieldName;
  }

  //protected for testing
  protected ProcessService getProcessService() {
    return new ProcessServiceImpl();
  }

  //Protected for testing only
  protected GenericDAO<Object, Long> getHibernateDao(Class<?> clazz) {
    return new HibernateDAO<Object, Long>(EISHibernateUtil.getHibernateFactory(), clazz);
  }

  private Class<?> getClass(String clazzName) throws ClassNotFoundException {
    String packageName = Projects.class.getPackage().getName();
    return Class.forName(packageName + "." + StringUtils.capitalize(clazzName));
  }

  private Class<?> getFieldType(String fieldName, Class<?> clazz) throws NoSuchFieldException {
    Field field = clazz.getDeclaredField(fieldName);
    return field.getType();
  }

  private Object getValue(String fieldValue, Class<?> type) throws NoSuchMethodException, InstantiationException,
      IllegalAccessException, InvocationTargetException {
    if (StringUtils.isBlank(fieldValue)) {
      return null;
    } else {
      if (isPrimitiveBoolean(type)) {
        return "Y".equalsIgnoreCase(fieldValue) || "true".equalsIgnoreCase(fieldValue);
      }
      if (isDate(type)) {
        return ConvertUtil.toDate(fieldValue, ConvertUtil.PROJECTS_DATE);
      }

      Constructor<?> constructor = null;
      try {
        constructor = type.getConstructor(String.class);
        return constructor.newInstance(fieldValue);
      } catch (NoSuchMethodException e) {
        constructor = type.getConstructor(Long.class);
        return constructor.newInstance(new Long(fieldValue));
      }
    }
  }

  private Method findMethod(String cellKey, Class<?> type, Class<?> aClass) throws NoSuchMethodException {
    return aClass.getMethod("set" + StringUtils.capitalize(cellKey), type);
  }

  private boolean isPrimitiveBoolean(Class<?> type) {
    return boolean.class.getName().equalsIgnoreCase(type.getName());
  }

  private boolean isDate(Class<?> type) {
    return Date.class.getName().equalsIgnoreCase(type.getName());
  }
}

//  public void startAutosaveSession(UCCHelper helper) throws IOException {
//    HibernateFactory hibernate = EISHibernateUtil.getHibernateFactory();
//    String nextId = hibernate.getSession().createSQLQuery("select eis.eis_seq.nextval from dual").uniqueResult()
//        .toString();
//    helper.getPrintWriter().print(nextId);
//  }

//  private Method findMethod(Class<Accessory> clazz, String fieldName) throws NoSuchMethodException {
//    String methodName = "set" + fieldName;
//    for (Method method : clazz.getMethods()) {
//      if (methodName.equalsIgnoreCase(method.getName())) {
//        return method;
//      }
//    }
//
//    throw new NoSuchMethodException(methodName);
//  }
//
//  private boolean acceptsSingleStringParameter(Method method) {
//    Class<?>[] paramTypes = method.getParameterTypes();
//    return (paramTypes.length == 1 && paramTypes[0].getName().equals("java.lang.String"));
//  }

//  public void deleteAutosaveEvent(UCCHelper helper) throws IOException {
//    String object = helper.getRequestParameterValue(OBJECT);
//    Long objectId = Long.valueOf(helper.getRequestParameterValue(OBJECT_ID));
//    Long sessionId = Long.valueOf(helper.getRequestParameterValue(SESSION_ID));
//    AutosaveEvent autosave = autosaveService.lookAutosaveEvent(object, objectId, sessionId);
//    autosaveService.deleteAutosaveEvent(autosave);
//  }
//
//  public Integer getInteger(String str) {
//    if (StringUtils.isBlank(str)) {
//      return null;
//    } else {
//      return new Integer(str);
//    }
//  }
//}

//      Method method = findMethod(Accessory.class, cellKey);
//      Class<?>[] types = method.getParameterTypes();
//      Constructor<?> constructor = types[0].getConstructor(String.class);

//    HibernateFactory hibernate = EISHibernateUtil.getHibernateFactory();
//    String userId = (String) helper.getSessionParameter(EISConstants.USER_ID);
//    String object = helper.getRequestParameterValue(OBJECT);
//    Long objectId = Long.valueOf(helper.getRequestParameterValue(OBJECT_ID));
//    Long sessionId = Long.valueOf(helper.getRequestParameterValue(SESSION_ID));
//    Long sessionSeq = Long.valueOf(helper.getRequestParameterValue(SESSION_SEQ));
//
//    AutosaveEvent existingAutosaveEvent = autosaveService.lookAutosaveEvent(object, objectId, sessionId);
//    if (existingAutosaveEvent == null) {
//      existingAutosaveEvent = new AutosaveEvent();
//    }
//    if (existingAutosaveEvent.getSessionSequnce() == null || existingAutosaveEvent.getSessionSequnce() < sessionSeq) {
////      hibernate.getSession().lock(existingAutosaveEvent, LockMode.UPGRADE);
//      existingAutosaveEvent.setUserId(userId);
//      existingAutosaveEvent.setObject(object);
//      existingAutosaveEvent.setObjectId(objectId);
//      existingAutosaveEvent.setSessionId(sessionId);
//      existingAutosaveEvent.setSessionSequnce(sessionSeq);
//      autosaveService.saveAutosave(existingAutosaveEvent);
//      String accessoryName = helper.getRequestParameterValue("accessoryName");
//      Integer quantity = getInteger(helper.getRequestParameterValue("quantity"));
//      String acceDescription = helper.getRequestParameterValue("acceDescription");
//      GenericDAO<Accessory, Long> dao = new HibernateDAO<Accessory, Long>(EISHibernateUtil.getHibernateFactory(),
//          Accessory.class);
//      Accessory accesory = dao.findByPrimaryKey(objectId);
//      accesory.setAccessoryName(accessoryName);
//      accesory.setQuantity(quantity);
//      accesory.setAcceDescription(acceDescription);
//      dao.beginTransaction();
//      dao.save(accesory);
//      dao.commitTransaction();
//    }//else do nothing coz the seq is older