/*
 AutosaveEvent was created on Dec 9, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.autosave;

import com.monsanto.wst.hibernate.TrueDelete;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: AutosaveEvent.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-12 20:01:53 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */

public class AutosaveEvent {
}
//
//@Entity
//@TrueDelete(reason = "Dont need to store", approval = "have to as k Ken")
//@Table(schema = "EIS", name = "AUTOSAVE_EVENT")
//public class AutosaveEvent {
//
//  @Id
//  @SequenceGenerator(name = "equipmentSeqGen", sequenceName = "EIS.EIS_SEQ")
//  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "equipmentSeqGen")
//  @Column(name = "ID")
//  private Long id;
//
//  @Column(name = "USER_ID")
//  private String userId;
//
//  @Column(name = "OBJECT")
//  private String object;
//
//  @Column(name = "OBJECT_PK")
//  private Long objectId;
//
//  @SequenceGenerator(name = "equipmentSeqGen", sequenceName = "EIS.EIS_SEQ")
//  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "equipmentSeqGen")
//  @Column(name = "SESSION_ID")
//  private Long sessionId;
//
//  @Column(name = "SESSION_SEQUENCE")
//  private Long sessionSequnce;
//
//  public AutosaveEvent() {
//  }
//
//  public Long getSessionSequnce() {
//    return sessionSequnce;
//  }
//
//  public void setUserId(String userId) {
//    this.userId = userId;
//  }
//
//  public void setObject(String object) {
//    this.object = object;
//  }
//
//  public void setObjectId(Long objectId) {
//    this.objectId = objectId;
//  }
//
//  public void setSessionId(Long sessionId) {
//    this.sessionId = sessionId;
//  }
//
//  public void setSessionSequnce(Long sessionSequnce) {
//    this.sessionSequnce = sessionSequnce;
//  }
//}