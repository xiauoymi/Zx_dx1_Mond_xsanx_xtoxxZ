/*
 AutosaveService was created on Dec 9, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.autosave;

import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    $RCSfile: AutosaveServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-12 20:02:01 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class AutosaveServiceImpl {
//  private GenericDAO<AutosaveEvent, Long> autosaveDao = new HibernateDAO<AutosaveEvent, Long>(EISHibernateUtil.getHibernateFactory(),
//      AutosaveEvent.class);
//
//  public void saveAutosave(AutosaveEvent event){
//    autosaveDao.beginTransaction();
//    autosaveDao.save(event);
//    autosaveDao.commitTransaction();
//  }
//
//  public AutosaveEvent lookAutosaveEvent(String object, Long objectId, Long sessionId){
//    Criteria criteria = autosaveDao.createCriteria();
//    criteria.add(Restrictions.eq("object", object));
//    criteria.add(Restrictions.eq("objectId", objectId));
//    criteria.add(Restrictions.eq("sessionId", sessionId));
//    return (AutosaveEvent) criteria.uniqueResult();
//  }
//
//  public void deleteAutosaveEvent(AutosaveEvent event){
//    autosaveDao.delete(event);
//  }
}