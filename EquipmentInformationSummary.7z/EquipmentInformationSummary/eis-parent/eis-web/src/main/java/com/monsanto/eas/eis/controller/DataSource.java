/*
 DataSource was created on Oct 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.controller;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: DataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-10 16:55:43 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public interface DataSource<T> {
  int UNKNOWN_RECORD_COUNT = -1; //todo need a better name for this

  List<? extends T> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws IOException;

  int getTotalRecords();
}
