/*
 EISController was created on Sep 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;

/**
 * Filename:    $RCSfile: EISController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date:
 * 2008/11/06 21:32:02 $
 *
 * @author sspati1
 * @version $Revision: 1.8 $
 */
public abstract class EISController extends AbstractDispatchController {
  private static final Log logger = LogFactory.getLog(EISController.class);

  public void run(UCCHelper helper) throws IOException {
    helper.setHeader("Cache-Control", "no-cache");//To ensure that AJAX call does not use cache
    setActiveTabIndex(helper);
    try {
      super.run(helper);
    } catch (Exception e) {
      logger.error(e);
      helper.setRequestAttributeValue("exception", e.getMessage());
      helper.setRequestAttributeValue("stackTrace", ExceptionUtils.getFullStackTrace(e));
      helper.forward(EISConstants.ERROR_JSP);
    }
  }

  public void setActiveTabIndex(UCCHelper helper) throws IOException {
    helper.setRequestAttributeValue(EISConstants.ACTIVE_TAB_INDEX,
        helper.getRequestParameterValue(EISConstants.ACTIVE_TAB_INDEX));
  }

}