/*
 XmlDataPaginationController was created on Oct 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.eas.eis.util.EISConstants;
import org.w3c.dom.Document;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.List;

/**
 * Filename:    $RCSfile: XmlDataPaginationController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2008-12-22 14:17:42 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public class XmlDataPaginationController extends EISController {
  public static final String DATA_SOURCE_CLASSNAME = "data-source";
  public static final String START_INDEX = "startIndex";
  public static final String ROWS_PER_PAGE = "rowsPerPage";
  public static final String SORT = "sort";
  public static final String SORT_DIRECTION = "dir";

  public void notSpecified(UCCHelper helper) throws IOException {
    int startIndex = getNumericParameter(helper, START_INDEX, 0);
    int rowsPerPage = getNumericParameter(helper, ROWS_PER_PAGE, 0);
    String sortKey = nullIfBlank(helper.getRequestParameterValue(SORT));
    String sortDir = helper.getRequestParameterValue(SORT_DIRECTION);

    XmlDataSource rawSource = getDataSource(helper);

    List<? extends XmlObject> data = rawSource.getData(sortKey, sortDir, startIndex, rowsPerPage);
    int totalRecords = rawSource.getTotalRecords();

    Document resultDoc = getResults(totalRecords, data, startIndex, rowsPerPage);
    helper.setContentType("text/xml");
    helper.writeXMLDocument(resultDoc, EISConstants.LATIN1_ENCODING);
  }

  private static String nullIfBlank(String st) {
    if (st == null || st.length() == 0) {
      return null;
    } else {
      return st;
    }
  }

  private int getNumericParameter(UCCHelper helper, String name, int defaultValue) throws IOException {
    try {
      return Integer.parseInt(helper.getRequestParameterValue(name));
    } catch (NullPointerException e) {
      return defaultValue;
    } catch (NumberFormatException e) {
      return defaultValue;
    }
  }

  private XmlDataSource getDataSource(UCCHelper helper) {
    String className = (String) helper.getInitParameters().get(DATA_SOURCE_CLASSNAME);
    Constructor<? extends XmlDataSource> constructor = getConstructor(className);
    return getNewInstance(helper, className, constructor);
  }

  private XmlDataSource getNewInstance(UCCHelper helper, String className,
                                       Constructor<? extends XmlDataSource> constructor) {
    try {
      return constructor.newInstance(helper);
    } catch (RuntimeException e) {
      throw e;
    } catch (Exception e) {
      throw new RuntimeException("Error on constructor call for data source class: " + className, e);
    }
  }

  private Constructor<? extends XmlDataSource> getConstructor(String className) {
    try {
      Class<? extends XmlDataSource> dataSourceClass = (Class<? extends XmlDataSource>) Class.forName(className);
      return dataSourceClass.getConstructor(UCCHelper.class);
    } catch (ClassNotFoundException e) {
      throw new RuntimeException("Unknown data source class: " + className, e);
    } catch (NoSuchMethodException e) {
      throw new RuntimeException("No valid constructor for data source class: " + className, e);
    }
  }

  private Document getResults(int totalRecords, List<? extends XmlObject> data, int startIndex, int rowsPerPage) throws
      IOException {
    if (totalRecords == DataSource.UNKNOWN_RECORD_COUNT) {
      totalRecords = data.size();
    }
    StringBuffer xmlBuf = new StringBuffer(
        "<ResultSet xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"urn:yahoo:lcl\" xsi:schemaLocation=\"urn:yahoo:lcl http://api.local.yahoo.com/LocalSearchService/V2/LocalSearchResponse.xsd\" >");
    xmlBuf.append("<totalRecords>").append(totalRecords).append("</totalRecords>");

//    int endIndex = startIndex + rowsPerPage;
//    if (data.size() < endIndex) {
//      endIndex = data.size();
//    }
//    for (int i = startIndex; i < endIndex; i++) {
      for (int i = 0; i < data.size(); i++) {
      XmlObject obj = data.get(i);
      xmlBuf.append(obj.toXml());
    }
    xmlBuf.append("</ResultSet>");

    try {
      return DOMUtil.stringToXML(xmlBuf.toString());
    } catch (ParserException e) {
      throw new RuntimeException("XML Exception", e);
    }
  }
}