/*
 AccessoryBuilder was created on Nov 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.AccessoryConstants;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.util.Validator;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: AccessoryBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $ On:	$Date:
 * 2008/11/10 19:34:13 $
 *
 * @author sspati1
 * @version $Revision: 1.13 $
 */
public class AccessoryBuilder extends BaseBuilder {
  public Set<Accessory> createAccessoryListFromRequest(Equipment equipment, UCCHelper helper) throws IOException {
    String hasAccessoriesDataChanged = helper.getRequestParameterValue(AccessoryConstants.HAS_ACCESSORIES_DATA_CHANGED);

    if ("true".equalsIgnoreCase(hasAccessoriesDataChanged)) {
      String[] acceId = helper.getRequestParameterValues(AccessoryConstants.ACCE_ID);
      String[] acceElectId = helper.getRequestParameterValues(AccessoryConstants.ACCE_ELECT_ID);
      String[] accePurchaseId = helper.getRequestParameterValues(AccessoryConstants.ACCE_PURCHASING_ID);
      String[] name = helper.getRequestParameterValues(AccessoryConstants.ACCE_NAME);
      String[] autoManualId = helper.getRequestParameterValues(AccessoryConstants.ACCE_AUTO_MANUAL_ID);
      String[] designatorId = helper.getRequestParameterValues(AccessoryConstants.ACCE_DESGINATOR_ID);
      String[] seqNumber = helper.getRequestParameterValues(AccessoryConstants.ACCE_SEQUENCE_NUMBER);
      String[] description = helper.getRequestParameterValues(AccessoryConstants.ACCE_DESCRIPTION);
      String[] comments = helper.getRequestParameterValues(AccessoryConstants.ACCE_COMMENTS);
      String[] purchasedWithEquip = helper.getRequestParameterValues(AccessoryConstants.ACCE_PURCHASED_WITH_EQUIP);
      String[] quantity = helper.getRequestParameterValues(AccessoryConstants.ACCE_QUANTITY);
      String[] compAirReqd = helper.getRequestParameterValues(AccessoryConstants.ACCE_COMP_AIR_REQD);
      String[] gasReqd = helper.getRequestParameterValues(AccessoryConstants.ACCE_GAS_REQD);
      String[] waterReqd = helper.getRequestParameterValues(AccessoryConstants.ACCE_WATER_REQD);
      String[] utilityFlowrate = helper.getRequestParameterValues(AccessoryConstants.ACCE_UTILITY_FLOWRATE);
      String[] selfCleaning = helper.getRequestParameterValues(AccessoryConstants.ACCE_SELF_CLEANING);
      String[] acceSize = helper.getRequestParameterValues(AccessoryConstants.ACCE_SIZE);

      String[] proofOfPositionReq = helper
          .getRequestParameterValues(AccessoryConstants.ACCE_PROOF_OF_POSITION_REQUIRED);
      String[] solenoidReq = helper.getRequestParameterValues(AccessoryConstants.ACCE_SOLENOID_REQUIRED);
      String[] localPushButtonReq = helper
          .getRequestParameterValues(AccessoryConstants.ACCE_LOCAL_PUSH_BUTTON_REQUIRED);
      String[] input = helper.getRequestParameterValues(AccessoryConstants.ACCE_INPUT_ID);
      String[] inputQty = helper.getRequestParameterValues(AccessoryConstants.ACCE_INPUT_QUANTITY);
      String[] output = helper.getRequestParameterValues(AccessoryConstants.ACCE_OUTPUT_ID);
      String[] outputQty = helper.getRequestParameterValues(AccessoryConstants.ACCE_OUTPUT_QUANTITY);
      String[] hmiDisplay = helper.getRequestParameterValues(AccessoryConstants.ACCE_HMI_DISPLAY);
      String[] otherMeasurementId = helper.getRequestParameterValues(AccessoryConstants.ACCE_OTHER_MEASUREMENT_ID);
      String[] communications = helper.getRequestParameterValues(AccessoryConstants.ACCE_COMMUNICATIONS);
      String[] voltage = helper.getRequestParameterValues(AccessoryConstants.ACCE_VOLTAGE);
      String[] bidPackage = helper.getRequestParameterValues(AccessoryConstants.BID_PACKAGE);

      String[] vendor = helper.getRequestParameterValues(AccessoryConstants.ACCE_VENDOR);
      String[] rtpNumber = helper.getRequestParameterValues(AccessoryConstants.ACCE_RTP_NUMBER);
      String[] poNumber = helper.getRequestParameterValues(AccessoryConstants.ACCE_PO_NUMBER);
      String[] lineNumber = helper.getRequestParameterValues(AccessoryConstants.ACCE_LINE_NUMBER);
      String[] estimatedCost = helper.getRequestParameterValues(AccessoryConstants.ACCE_ESTIMATED_COST);
      String[] actualCost = helper.getRequestParameterValues(AccessoryConstants.ACCE_ACTUAL_COST);
      String[] actualDeliveryDate = helper.getRequestParameterValues(AccessoryConstants.ACCE_ACTUAL_DELIVERY_DATE);
      Set<Accessory> accessories = new HashSet<Accessory>();
      int size = acceId == null ? 0 : acceId.length;
      for (int i = 0; i < size; i++) {
        Electrical electrical = new Electrical(getLong(acceElectId[i]), getBool(proofOfPositionReq[i]), getBool(solenoidReq[i]),
            getBool(localPushButtonReq[i]),
            createElectricalInput(input[i]), getInteger(inputQty[i]), createElectricalOutput(output[i]),
            getInteger(outputQty[i]),
            hmiDisplay[i], createOtherMeasurement(otherMeasurementId[i]), communications[i], getInteger(voltage[i]),
            null);
        boolean isPurchasedWithEquipment = getBool(purchasedWithEquip[i]);
        if (isPurchasedWithEquipment) {
          vendor[i] = null;
          rtpNumber[i] = null;
          poNumber[i] = null;
          lineNumber[i] = null;
          actualDeliveryDate[i] = null;
        }
        Purchasing purchasing = new Purchasing(getLong(accePurchaseId[i]), vendor[i], getInteger(rtpNumber[i]),
            getLong(poNumber[i]),
            getInteger(lineNumber[i]), null, null, null, null, null, null,
            ConvertUtil.toDate(actualDeliveryDate[i], ConvertUtil.PROJECTS_DATE), false);

        AccessoryDesignator designator =
            getLong(designatorId[i]) == null ? null : new AccessoryDesignator(getLong(designatorId[i]), null, null);
        AutoManual autoManual = getLong(autoManualId[i]) == null ? null : new AutoManual(getLong(autoManualId[i]));
        String estCost = estimatedCost != null && estimatedCost[i] != null ? estimatedCost[i] : "";
        String actCost = actualCost != null && actualCost[i] != null ? actualCost[i] : "";
        accessories.add(new Accessory(getLong(acceId[i]), isPurchasedWithEquipment, name[i],
            designator, seqNumber[i], getInteger(quantity[i]), description[i], comments[i],
            getBool(compAirReqd[i]),
            getBool(gasReqd[i]), getBool(waterReqd[i]), utilityFlowrate[i], getBool(selfCleaning[i]),
            getInteger(acceSize[i]), autoManual, electrical, purchasing, equipment, getInteger(estCost), getInteger(actCost),
            bidPackage[i]));
      }
      flagAccessoriesThatWereDeleted(equipment, helper.getRequestParameterValue(AccessoryConstants.DELETED_ACCESSORY_IDS));
      return accessories;
    } else {
      return equipment.getAccessories();
    }
  }

  //protected for testing
  protected void flagAccessoriesThatWereDeleted(Equipment equipment, String deletedAccessoryIds) {
    String[] deletedIds = deletedAccessoryIds.split(",");
    for (int j = 0; j < deletedIds.length; j++) {
      String deletedId = StringUtils.trim(deletedIds[j]);
      if (StringUtils.isNotBlank(deletedId)) {
        Set<Accessory> existingInstruments = equipment.getAccessories();
        for (Accessory accessory : existingInstruments) {
          if (accessory.getId().toString().equals(deletedId)) {
            accessory.setDeleted(true);
            break;
          }
        }
      }
    }
  }

  public List<String> validateRequiredFields(UCCHelper helper) throws IOException {
    List<String> requiredFields = new ArrayList<String>();
    String[] sequenceNumber = helper.getRequestParameterValues(AccessoryConstants.ACCE_SEQUENCE_NUMBER);
    String[] designatorId = helper.getRequestParameterValues(AccessoryConstants.ACCE_DESGINATOR_ID);

    if (designatorId != null) {
      for (int i = 0; i < designatorId.length; i++) {
        Validator.validateRequiredFieldInARow(designatorId[i], "Designator", false, 0, requiredFields, i);
      }
    }
    if (sequenceNumber != null) {
      for (int i = 0; i < sequenceNumber.length; i++) {
        Validator.validateRequiredFieldInARow(sequenceNumber[i], "Sequence Number", true, 2, requiredFields, i);
      }
    }
    return requiredFields;
  }

  private OtherMeasurement createOtherMeasurement(String str) {
    Long id = getLong(str);
    if (id == null) {
      return null;
    } else {
      OtherMeasurement otherMeasurement = new OtherMeasurement();
      otherMeasurement.setId(id);
      return otherMeasurement;
    }
  }

  private ElectricalOutput createElectricalOutput(String str) {
    Long id = getLong(str);
    if (id == null) {
      return null;
    } else {
      ElectricalOutput electricalOutput = new ElectricalOutput();
      electricalOutput.setId(id);
      return electricalOutput;
    }
  }

  private ElectricalInput createElectricalInput(String str) {
    Long id = getLong(str);
    if (id == null) {
      return null;
    } else {
      ElectricalInput electricalInput = new ElectricalInput();
      electricalInput.setId(id);
      return electricalInput;
    }
  }
}