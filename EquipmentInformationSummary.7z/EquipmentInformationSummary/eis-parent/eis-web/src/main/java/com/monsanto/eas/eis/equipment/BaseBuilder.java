/*
 BaseBuilder was created on Nov 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment;

import org.apache.commons.lang.StringUtils;

import java.util.List;

/**
 * Filename:    $RCSfile: BaseBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-11-07 17:23:21 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class BaseBuilder {

  public Integer getInteger(String str) {
    if (StringUtils.isBlank(str)) {
      return null;
    } else {
      return new Integer(str);
    }
  }

  public Long getLong(String str) {
    if (StringUtils.isBlank(str) || str.equalsIgnoreCase("Please Select")) {
      return null;
    } else {
      return new Long(str);
    }
  }

  public Double getDouble(String str) {
    if (StringUtils.isBlank(str)) {
      return null;
    } else {
      return new Double(str);
    }
  }

  public boolean getBool(String str) {
    if (StringUtils.isBlank(str) || str.equalsIgnoreCase("false")) {
      return false;
    } else {
      return true;
    }
  }

  public boolean isCheckboxChecked(String str) {
    if (StringUtils.isBlank(str) || !str.equalsIgnoreCase("on")) {
      return false;
    }
    return true;
  }

  public boolean isRadioButtonChecked(String str) {
    if (StringUtils.isBlank(str) || str.equalsIgnoreCase("n")) {
      return false;
    } else {
      return true;
    }
  }

}