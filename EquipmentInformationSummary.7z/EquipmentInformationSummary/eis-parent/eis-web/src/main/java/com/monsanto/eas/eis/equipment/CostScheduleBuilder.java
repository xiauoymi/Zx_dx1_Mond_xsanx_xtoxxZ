/*
 CostScheduleBuilder was created on Nov 10, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.equipment.service.CostScheduleService;
import com.monsanto.eas.eis.equipment.service.CostScheduleServiceImpl;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.util.CostScheduleConstants;

import java.io.IOException;
import java.util.Date;

/**
 * Filename:    $RCSfile: CostScheduleBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $ On:	$Date:
 * 2008/12/05 16:40:20 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class CostScheduleBuilder extends BaseBuilder {
  private CostScheduleService costScheduleService;

  public CostScheduleBuilder() {
    this(new CostScheduleServiceImpl());
  }

  public CostScheduleBuilder(CostScheduleService costScheduleService) {
    this.costScheduleService = costScheduleService;
  }

  public CostSchedule createCostScheduleFromRequest(Equipment equipment, UCCHelper helper) throws IOException {
    String hasCostScheduledDataChanged = helper.getRequestParameterValue(CostScheduleConstants.HAS_COST_SCHEDULED_DATA_CHANGED);
    CostSchedule costSchedule = equipment.getCostSchedule();
    if ("true".equalsIgnoreCase(hasCostScheduledDataChanged)) {
      Date scheduledSpecificationDate = ConvertUtil.toDate(
          helper.getRequestParameterValue(CostScheduleConstants.CS_SCHEDULED_SPECIFICATION), ConvertUtil.PROJECTS_DATE);
      Date scheduledQuoteDate = ConvertUtil
          .toDate(helper.getRequestParameterValue(CostScheduleConstants.CS_SCHEDULED_QUOTE), ConvertUtil.PROJECTS_DATE);
      Date scheduledPurchaseDate = ConvertUtil.toDate(
          helper.getRequestParameterValue(CostScheduleConstants.CS_SCHEDULED_PURCHASE), ConvertUtil.PROJECTS_DATE);
      Integer drawingTurnaroundTime = getInteger(
          helper.getRequestParameterValue(CostScheduleConstants.CS_DRAWING_TURNAROUNDTIME));
      Integer estiamtedFabricationTime = getInteger(
          helper.getRequestParameterValue(CostScheduleConstants.CS_EST_FABRICATION_TIME));
      Date estiamtedShippingDate = ConvertUtil
          .toDate(helper.getRequestParameterValue(CostScheduleConstants.CS_EST_SHIPPING), ConvertUtil.PROJECTS_DATE);
      Date specIssuedDate = ConvertUtil
          .toDate(helper.getRequestParameterValue(CostScheduleConstants.CS_SPEC_ISSED), ConvertUtil.PROJECTS_DATE);
      Date rtqEnteredDate = ConvertUtil
          .toDate(helper.getRequestParameterValue(CostScheduleConstants.CS_RTQ_ENTERED), ConvertUtil.PROJECTS_DATE);
      Date rtpEnteredDate = ConvertUtil
          .toDate(helper.getRequestParameterValue(CostScheduleConstants.CS_RTP_ENTERED), ConvertUtil.PROJECTS_DATE);
      Date prelDrawingIssuedDate = ConvertUtil.toDate(
          helper.getRequestParameterValue(CostScheduleConstants.CS_PREL_DRAWING_ISSUED), ConvertUtil.PROJECTS_DATE);
      Date approvalDrawingDate = ConvertUtil.toDate(
          helper.getRequestParameterValue(CostScheduleConstants.CS_APPROVAL_DRAWING), ConvertUtil.PROJECTS_DATE);
      Date finalDrawingDate = ConvertUtil
          .toDate(helper.getRequestParameterValue(CostScheduleConstants.CS_FINAL_DRAWING), ConvertUtil.PROJECTS_DATE);
      Date iomReceivedDate = ConvertUtil
          .toDate(helper.getRequestParameterValue(CostScheduleConstants.CS_IOM_RECEIVED), ConvertUtil.PROJECTS_DATE);
      String estimatedSource = helper.getRequestParameterValue(CostScheduleConstants.CS_EST_SOURCE);
      Long estimatedCost = getLong(helper.getRequestParameterValue(CostScheduleConstants.CS_EST_COST));
      Long fundingSourceId = getLong(helper.getRequestParameterValue(CostScheduleConstants.CS_FUNDING_SOURCE_ID));
      Integer estimatedMechHours = getInteger(helper.getRequestParameterValue(CostScheduleConstants.CS_EST_MECH_HRS));
      FundingSource fundingSource = getFundingSource(fundingSourceId);
      Double escalationFactor = getDouble(helper.getRequestParameterValue(CostScheduleConstants.CS_ESCALATION_FACTOR));
      if (costSchedule == null) {
        costSchedule = new CostSchedule(null, scheduledSpecificationDate,
            scheduledQuoteDate, scheduledPurchaseDate, drawingTurnaroundTime, estiamtedFabricationTime,
            estiamtedShippingDate, specIssuedDate, rtqEnteredDate, rtpEnteredDate,
            prelDrawingIssuedDate, approvalDrawingDate, finalDrawingDate, iomReceivedDate,
            estimatedCost, estimatedSource, fundingSource,
            estimatedMechHours, escalationFactor);
        costSchedule.setEquipment(equipment);
      } else {
        costSchedule.setScheduledSpecificationDate(scheduledSpecificationDate);
        costSchedule.setScheduledQuoteDate(scheduledQuoteDate);
        costSchedule.setScheduledPurchaseDate(scheduledPurchaseDate);
        costSchedule.setDrawingTurnaroundTime(drawingTurnaroundTime);
        costSchedule.setEstiamtedFabricationTime(estiamtedFabricationTime);
        costSchedule.setEstiamtedShippingDate(estiamtedShippingDate);
        costSchedule.setSpecIssuedDate(specIssuedDate);
        costSchedule.setRtqEnteredDate(rtqEnteredDate);
        costSchedule.setRtpEnteredDate(rtpEnteredDate);
        costSchedule.setPrelDrawingIssuedDate(prelDrawingIssuedDate);
        costSchedule.setApprovalDrawingDate(approvalDrawingDate);
        costSchedule.setFinalDrawingDate(finalDrawingDate);
        costSchedule.setIomReceivedDate(iomReceivedDate);
        costSchedule.setEstimatedSource(estimatedSource);
        costSchedule.setEstimatedCost(estimatedCost);
        costSchedule.setFundingSource(fundingSource);
        costSchedule.setEstimatedMechHours(estimatedMechHours);
        costSchedule.setEscalationFactor(escalationFactor);
      }
    }
    if (costSchedule == null) {
      costSchedule = new CostSchedule();
      costSchedule.setEquipment(equipment);
    }
    return costSchedule;
  }

  private FundingSource getFundingSource(Long fundingSourceId) {
    FundingSource fundingSource = null;
    if (fundingSourceId != null) {
      fundingSource = costScheduleService.lookupFundingSourceById(fundingSourceId);
    }
    return fundingSource;
  }
}