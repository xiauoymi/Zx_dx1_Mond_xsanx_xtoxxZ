package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.equipment.service.ElectricalService;
import com.monsanto.eas.eis.equipment.service.ElectricalServiceImpl;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.ElectricalConstants;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 24, 2008 Time: 9:37:30 AM To change this template use File |
 * Settings | File Templates.
 */
public class ElectricalBuilder extends BaseBuilder {
  private ElectricalService electricalService;

  public ElectricalBuilder() {
    this(new ElectricalServiceImpl());
  }

  public ElectricalBuilder(ElectricalService electricalService) {
    this.electricalService = electricalService;
  }

  public Electrical createElectricalFromRequest(Equipment equipment, UCCHelper helper) throws
      IOException {
    String hasElectricalDataChanged = helper.getRequestParameterValue(ElectricalConstants.HAS_ELECTRICAL_DATA_CHANGED);
    List<ElectricalInput> inputsRef = electricalService.lookupAllInputs();
    List<ElectricalOutput> outputsRef = electricalService.lookupAllOutputs();
    Electrical electrical = equipment.getElectrical();
    if ("true".equalsIgnoreCase(hasElectricalDataChanged)) {
      String proofOfPositionReq = helper.getRequestParameterValue(ElectricalConstants.PROOF_OF_POSITION_REQUIRED);
      String solenoidReq = helper.getRequestParameterValue(ElectricalConstants.SOLENOID_REQUIRED);
      String localPushButtonReq = helper.getRequestParameterValue(ElectricalConstants.LOCAL_PUSH_BUTTON_REQUIRED);
      String hmiDisplay = helper.getRequestParameterValue(ElectricalConstants.HMI_DISPLAY);
      String otherMeasurement = helper.getRequestParameterValue(ElectricalConstants.OTHER_MEASURMENT);
      String communications = helper.getRequestParameterValue(ElectricalConstants.COMMUNICATIONS);
      String voltage = helper.getRequestParameterValue(ElectricalConstants.VOLTAGE);

      OtherMeasurement otherMsrmt = setupOtherMeasurement(otherMeasurement);
      electrical = setupelectrical(equipment, electrical, proofOfPositionReq, solenoidReq, localPushButtonReq,
          hmiDisplay, communications, voltage, null, null,
          null, null, otherMsrmt);
    }
    if (electrical == null) {
      electrical = new Electrical();
      electrical.setEquipment(equipment);
    }
    electrical.setInputQuantity(setupInputQuantity(helper, electrical, inputsRef));
    electrical.setOutputQuantity(setupOutputQuantity(helper, electrical, outputsRef));

    return electrical;
  }

  private Set<ElectricalInputQuantity> setupInputQuantity(UCCHelper helper, Electrical electrical,
                                                          List<ElectricalInput> inputsRef
  ) throws IOException {
    Set<ElectricalInputQuantity> inputQuantities = new HashSet<ElectricalInputQuantity>();
    for (ElectricalInput inRef : inputsRef) {
      String id = "InputCheckbox" + inRef.getId();
      String checked = helper.getRequestParameterValue(id);
      boolean isChecked = checked != null && "true".equalsIgnoreCase(checked);
      Integer quantity = getInteger(helper.getRequestParameterValue("InputQuantity" + inRef.getId()));

      ElectricalInputQuantity inputQuantity = this.electricalService
          .lookupInputQuantityByInputForElectrical(inRef.getId(), electrical.getId());
      if (inputQuantity == null) {
        inputQuantity = new ElectricalInputQuantity(null, inRef, quantity, electrical, isChecked);
      } else {
        inputQuantity.setChecked(isChecked);
        inputQuantity.setInputQty(quantity);
      }
      inputQuantities.add(inputQuantity);
    }
    return inputQuantities;
  }

  private Set<ElectricalOutputQuantity> setupOutputQuantity(UCCHelper helper, Electrical electrical,
                                                            List<ElectricalOutput> outputsRef
  ) throws IOException {
    Set<ElectricalOutputQuantity> outputQuantities = new HashSet<ElectricalOutputQuantity>();
    for (ElectricalOutput outRef : outputsRef) {
      String id = "OutputCheckbox" + outRef.getId();
      String checked = helper.getRequestParameterValue(id);
      boolean isChecked = checked != null && "true".equalsIgnoreCase(checked);
      Integer quantity = getInteger(helper.getRequestParameterValue("OutputQuantity" + outRef.getId()));
      ElectricalOutputQuantity outputQuantity = this.electricalService
          .lookupInputQuantityByOutputForElectrical(outRef.getId(), electrical.getId());
      if (outputQuantity == null) {
        outputQuantity = new ElectricalOutputQuantity(null, outRef, quantity, electrical, isChecked);
      } else {
        outputQuantity.setChecked(isChecked);
        outputQuantity.setOutputQty(quantity);
      }
      outputQuantities.add(outputQuantity);
    }
    return outputQuantities;
  }

  private Electrical setupelectrical(Equipment equipment, Electrical electrical, String proofOfPositionReq,
                                     String solenoidReq, String localPushButtonReq, String hmiDisplay,
                                     String communications, String voltage, ElectricalInput electricalInput,
                                     String inputQty,
                                     ElectricalOutput electricalOutput, String outputQty,
                                     OtherMeasurement otherMsrmt) {
    if (electrical == null) {
      electrical = new Electrical(null, getBool(proofOfPositionReq), getBool(solenoidReq), getBool(localPushButtonReq),
          electricalInput, getInteger(inputQty), electricalOutput, getInteger(outputQty),
          hmiDisplay, otherMsrmt, communications, getInteger(voltage), equipment);
    } else {
      electrical.setProofOfPositionReq(getBool(proofOfPositionReq));
      electrical.setSolenoidReq(getBool(solenoidReq));
      electrical.setLocalPushButtonReq(getBool(localPushButtonReq));
      electrical.setInput(electricalInput);
      electrical.setInputQty(getInteger(inputQty));
      electrical.setOutput(electricalOutput);
      electrical.setOutputQty(getInteger(outputQty));
      electrical.setHmiDisplay(hmiDisplay);
      electrical.setOtherMeasurement(otherMsrmt);
      electrical.setCommunications(communications);
      electrical.setVoltage(getInteger(voltage));
    }
    return electrical;
  }

  private OtherMeasurement setupOtherMeasurement(String otherMeasurement) {
    OtherMeasurement otherMsrmt = null;
    if (getLong(otherMeasurement) != null) {
      otherMsrmt = electricalService.lookupOtherMeasurement(getLong(otherMeasurement));
    }
    return otherMsrmt;

  }
}
