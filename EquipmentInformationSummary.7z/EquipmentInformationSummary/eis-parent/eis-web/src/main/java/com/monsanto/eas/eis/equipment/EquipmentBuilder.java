package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.projects.EISDAOFactory;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.Validator;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Sep 2, 2008 Time: 3:44:00 PM To change this template use File | Settings
 * | File Templates.
 */
public class EquipmentBuilder extends BaseBuilder {
  private EISDAOFactory daoFactory;

  public EquipmentBuilder(EISDAOFactory daoFactory) {
    this.daoFactory = daoFactory;
  }

  public Equipment createEquipmentFromParameters(UCCHelper helper) throws IOException {
    Long projectId = Long.valueOf(helper.getRequestParameterValue(EISConstants.PROJECT_ID));
    Projects project = daoFactory.getProjectsDAOImpl().findByPrimaryKey(projectId);

    String areaString = checkForInvalidDropDownValue(helper.getRequestParameterValue(EISConstants.EQUIPMENT_AREA));
    Long areaId = getLong(areaString);
    String processLineNumber = helper.getRequestParameterValue(EISConstants.PROCESS_LINE_NUMBER);
    String equipmentTagNumber = helper.getRequestParameterValue(EISConstants.EQUIPMENT_TAG_NUMBER);
    String subTypeOneString = checkForInvalidDropDownValue(
        helper.getRequestParameterValue(EISConstants.EQUIPMENT_SUB_TYPE_ID));
    Long subTypeOneId = getLong(subTypeOneString);
    String equipmentTypeString = checkForInvalidDropDownValue(
        helper.getRequestParameterValue(EISConstants.EQUIPMENT_TYPE_ID));
    Long equipmentTypeId = getLong(equipmentTypeString);
    String equipmentName = helper.getRequestParameterValue(EISConstants.EQUIPMENT_NAME);
    String existingEquipmentNumber = helper.getRequestParameterValue(EISConstants.EXISTING_EQUIPMENT_NUMBER);
    String equipmentDescription = helper.getRequestParameterValue(EISConstants.EQUIPMENT_DESCRIPTION);
    boolean soleSource = getBool(helper.getRequestParameterValue(EISConstants.EQUIPMENT_SOLE_SOURCE));
    boolean existingEquipmentModification = getBool(
        helper.getRequestParameterValue(EISConstants.EXISTING_EQUIPMENT_MODIFICATION));
    boolean standardEquipment = getBool(helper.getRequestParameterValue(EISConstants.STANDARD_EQUIPMENT));

    Area area = validateAndGetArea(areaId);
    EquipmentType equipmentType = validateAndGetEquipmentType(equipmentTypeId);
    EquipmentType subTypeOne = validateAndGetEquipmentType(subTypeOneId);
    return setupEquipment(helper, equipmentType, subTypeOne, area, processLineNumber,
        equipmentTagNumber, equipmentName, equipmentDescription, existingEquipmentNumber, project, soleSource, existingEquipmentModification,
        standardEquipment);
  }

  private Equipment setupEquipment(UCCHelper helper, EquipmentType equipmentType,
                                   EquipmentType subTypeOne, Area area,
                                   String processLineNumber, String equipmentTagNumber,
                                   String equipmentName, String equipmentDescription, String existingEquipmentNumber,
                                   Projects project,
                                   boolean soleSource, boolean existingEquipmentModification,
                                   boolean standardEquipment) throws IOException {
    Equipment equipment;
    String equipmentNumber = generateEquipmentNumber(equipmentType, area, processLineNumber, equipmentTagNumber);
    if (StringUtils.isBlank(helper.getRequestParameterValue(EISConstants.EQUIPMENT_ID))) {
      equipment = new Equipment(equipmentNumber, existingEquipmentNumber, equipmentName, equipmentDescription, area, processLineNumber,
          equipmentTagNumber, equipmentType, subTypeOne, project);
      equipment.setEquipmentSoleSource(soleSource);
      equipment.setExistingEquipmentModification(existingEquipmentModification);
      equipment.setStandardEquipment(standardEquipment);
      equipment.setElectrical(new Electrical());
    } else {
      Long equipmentId = Long.valueOf(helper.getRequestParameterValue(EISConstants.EQUIPMENT_ID));
      equipment = daoFactory.getEquipmentDAOImpl().findByPrimaryKey(equipmentId);

      equipment.setArea(area);
      equipment.setEquipmentType(equipmentType);
      equipment.setProcessLineNumber(processLineNumber);
      equipment.setEquipmentTagNumber(equipmentTagNumber);
      equipment.setExistingEquipmentNumber(existingEquipmentNumber);
      equipment.setDescription(equipmentDescription);
      equipment.setName(equipmentName);
      equipment.setSubTypeOne(subTypeOne);
      equipment.setEquipmentSoleSource(soleSource);
      equipment.setExistingEquipmentModification(existingEquipmentModification);
      equipment.setStandardEquipment(standardEquipment);
      equipment.setEquipmentNumber(equipmentNumber);
    }
    return equipment;
  }

  private EquipmentType validateAndGetEquipmentType(Long equipmentTypeId) {
    if (equipmentTypeId == null) {
      return null;
    } else {
      return daoFactory.getEquipmentTypeDAOImpl().findByPrimaryKey(equipmentTypeId);
    }
  }

  private Area validateAndGetArea(Long areaId) {
    if (areaId == null) {
      return null;
    } else {
      return daoFactory.getAreaDAOImpl().findByPrimaryKey(areaId);
    }
  }

  public List<String> validate(Equipment equipment) throws IOException {
    List<String> requiredFields = new ArrayList<String>();
    String areaId = equipment.getArea() == null ? "" : equipment.getArea().getId().toString();
    validateRequiredField(areaId, "Area", requiredFields);
    String typeId = equipment.getEquipmentType() == null ? "" : equipment.getEquipmentType().getId().toString();
    validateRequiredField(typeId, "Equipment Type",
        requiredFields);
    validateRequiredField(equipment.getProcessLineNumber(), "Process Line #",
        requiredFields);
    validateRequiredField(equipment.getEquipmentTagNumber(), "Equipment Tag #",
        requiredFields);
    validateRequiredField(equipment.getName(), "Name", requiredFields);
    return requiredFields;
  }

  private void validateRequiredField(String requestParameterValue, String label, List<String> requiredFields) {
    if (Validator.isRequiredFieldEmpty(requestParameterValue) ||
        "Please Select".equalsIgnoreCase(requestParameterValue)) {
      requiredFields.add(label + " is a required field");
    }
  }

  public List<String> validateAllFieldsLength(Equipment equipment) throws IOException {
    List<String> invalidFieldLength = new ArrayList<String>();
    validateFieldLength(equipment.getEquipmentTagNumber(), "Equipment Tag #", 3,
        invalidFieldLength);
    return invalidFieldLength;
  }


  private void validateFieldLength(String requestParameterValue, String label, int expectedLength,
                                   List<String> invalidFieldLength) {
    if (!Validator.isFieldLengthValid(requestParameterValue, expectedLength)) {
      String message = label + " has an invalid minimum length";
      invalidFieldLength.add(message);
    }
  }

  private String generateEquipmentNumber(EquipmentType equipmentType, Area area, String processLineNumber,
                                         String equipmentTagNumber) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(area == null ? "" : area.getAreaCode())
                 .append(".")
                 .append(processLineNumber == null ? "" : processLineNumber)
                 .append(".")
                 .append(equipmentTagNumber == null ? "" : equipmentTagNumber)
                 .append(equipmentType == null ? "" : equipmentType.getTypeCode());
    return stringBuffer.toString();
  }


  private String checkForInvalidDropDownValue(String requestparameterValue) {
    if (Validator.isRequiredFieldEmpty(requestparameterValue) ||
        "Please Select".equalsIgnoreCase(requestparameterValue)) {
      requestparameterValue = "";
    }
    return requestparameterValue;
  }

}
