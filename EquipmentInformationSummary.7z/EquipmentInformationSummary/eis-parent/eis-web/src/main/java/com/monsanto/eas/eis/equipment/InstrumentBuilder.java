/*
 IntrumentBuilder was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.util.InstrumentConstants;
import com.monsanto.eas.eis.util.Validator;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Filename:    $RCSfile: InstrumentBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $
 * On:	$Date: 2009-01-30 18:44:41 $
 *
 * @author sspati1
 * @version $Revision: 1.15 $
 */
public class InstrumentBuilder extends BaseBuilder {
  public Set<Instrument> createIntrumentListFromRequest(Equipment equipment, UCCHelper helper) throws IOException {
    String hasInstrumentsDataChanged = helper.getRequestParameterValue(InstrumentConstants.HAS_INTRUMENTS_DATA_CHANGED);
    if ("true".equalsIgnoreCase(hasInstrumentsDataChanged)) {
      String[] instrumentId = helper.getRequestParameterValues(InstrumentConstants.INSTRUMENT_ID);
      String[] instPurchaseId = helper.getRequestParameterValues(InstrumentConstants.INST_PURCHASING_ID);
      String[] designatorFirstChar = helper.getRequestParameterValues(InstrumentConstants.DESIGNATOR_FIRST_CHAR_ID);
      String[] designatorSecondChar = helper.getRequestParameterValues(InstrumentConstants.DESIGNATOR_SECOND_CHAR_ID);
      String[] sequenceNumber = helper.getRequestParameterValues(InstrumentConstants.INST_SEQUENCE_NUMBER);
      String[] description = helper.getRequestParameterValues(InstrumentConstants.INST_DESCRIPTION);
      String[] ioType = helper.getRequestParameterValues(InstrumentConstants.IO_TYPE_ID);
      String[] alarmPoints = helper.getRequestParameterValues(InstrumentConstants.ALARM_POINTS);
      String[] alarmPointsQuantity = helper.getRequestParameterValues(InstrumentConstants.ALARM_POINTS_QUANTITY);
      String[] volts = helper.getRequestParameterValues(InstrumentConstants.INST_VOLTS);
      String[] range = helper.getRequestParameterValues(InstrumentConstants.INST_RANGE);
      String[] units = helper.getRequestParameterValues(InstrumentConstants.INST_UNITS);
      String[] comments = helper.getRequestParameterValues(InstrumentConstants.INST_COMMENTS);
      String[] bidPackage = helper.getRequestParameterValues(InstrumentConstants.INST_BID_PACAKAGE);
      String[] manufacturer = helper.getRequestParameterValues(InstrumentConstants.INST_MANUFACTURER);
      String[] modelNumber = helper.getRequestParameterValues(InstrumentConstants.INST_MODEL_NUMBER);
      String[] purchasedWithEquip = helper.getRequestParameterValues(InstrumentConstants.INST_PURCHASED_WITH_EQUIP);

      String[] vendor = helper.getRequestParameterValues(InstrumentConstants.INST_VENDOR);
      String[] rtpNumber = helper.getRequestParameterValues(InstrumentConstants.INST_RTP_NUMBER);
      String[] poNumber = helper.getRequestParameterValues(InstrumentConstants.INST_PO_NUMBER);
      String[] lineNumber = helper.getRequestParameterValues(InstrumentConstants.INST_LINE_NUMBER);
      String[] estimatedCost = helper.getRequestParameterValues(InstrumentConstants.INST_ESTIMATED_COST);
      String[] actualCost = helper.getRequestParameterValues(InstrumentConstants.INST_ACTUAL_COST);
      String[] actualDeliveryDate = helper.getRequestParameterValues(InstrumentConstants.INST_ACTUAL_DELIVERY_DATE);

      Set<Instrument> instruments = new HashSet<Instrument>();
      int size = instrumentId == null ? 0 : instrumentId.length;
      for (int i = 0; i < size; i++) {
        boolean isPurchasedWithEquipment = getBool(purchasedWithEquip[i]);
        if (isPurchasedWithEquipment) {
          vendor[i] = null;
          rtpNumber[i] = null;
          poNumber[i] = null;
          lineNumber[i] = null;
          actualDeliveryDate[i] = null;
        }
        Purchasing purchasing = new Purchasing(getLong(instPurchaseId[i]), vendor[i], getInteger(rtpNumber[i]),
            getLong(poNumber[i]),
            getInteger(lineNumber[i]), null, null, null, null, null, null,
            ConvertUtil.toDate(actualDeliveryDate[i], ConvertUtil.PROJECTS_DATE), false);

        InstrumentDesignator dfc =
            getLong(designatorFirstChar[i]) == null ? null :
                new InstrumentDesignator(getLong(designatorFirstChar[i]), null, null);
        InstrumentDesignator dsc =
            getLong(designatorSecondChar[i]) == null ? null :
                new InstrumentDesignator(getLong(designatorSecondChar[i]), null, null);
        IOType iot =
            getLong(ioType[i]) == null ? null : new IOType(getLong(ioType[i]));
        String estCost = estimatedCost != null && estimatedCost[i] != null ? estimatedCost[i] : "";
        String actCost = actualCost != null && actualCost[i] != null ? actualCost[i] : "";
        instruments
            .add(
                new Instrument(getLong(instrumentId[i]), dfc, dsc, sequenceNumber[i], description[i], iot,
                    alarmPoints[i],
                    getInteger(alarmPointsQuantity[i]),
                    getInteger(volts[i]), range[i], units[i], comments[i], isPurchasedWithEquipment, purchasing,
                    equipment, getInteger(estCost), getInteger(actCost), bidPackage[i], manufacturer[i], modelNumber[i]));
      }
      flagInstrumentsThatWereDeleted(equipment,
          helper.getRequestParameterValue(InstrumentConstants.DELETED_INSTRUMENT_IDS));
      return instruments;
    } else {
      return equipment.getInstruments();
    }
  }

  //protected for testing
  protected void flagInstrumentsThatWereDeleted(Equipment equipment, String deletedInstrumentIds) {
    String[] deletedIds = deletedInstrumentIds.split(",");
    for (int j = 0; j < deletedIds.length; j++) {
      String deletedId = StringUtils.trim(deletedIds[j]);
      if (StringUtils.isNotBlank(deletedId)) {
        Set<Instrument> existingInstruments = equipment.getInstruments();
        for (Instrument inst : existingInstruments) {
          if (inst.getId().toString().equals(deletedId)) {
            inst.setDeleted(true);
            break;
          }
        }
      }
    }
  }

  public List<String> validateRequiredFields(UCCHelper helper) throws IOException {
    List<String> requiredFields = new ArrayList<String>();
    String[] sequenceNumber = helper.getRequestParameterValues(InstrumentConstants.INST_SEQUENCE_NUMBER);
    String[] designatorFirstChar = helper.getRequestParameterValues(InstrumentConstants.DESIGNATOR_FIRST_CHAR_ID);
    String[] designatorSecondChar = helper.getRequestParameterValues(InstrumentConstants.DESIGNATOR_SECOND_CHAR_ID);

    if (designatorFirstChar != null) {
      for (int i = 0; i < designatorFirstChar.length; i++) {
        Validator.validateRequiredFieldInARow(designatorFirstChar[i], "First Designator", false, 0, requiredFields, i);
      }
    }
    if (designatorSecondChar != null) {
      for (int i = 0; i < designatorSecondChar.length; i++) {
        Validator
            .validateRequiredFieldInARow(designatorSecondChar[i], "Second Designator", false, 0, requiredFields, i);
      }
    }
    if (sequenceNumber != null) {
      for (int i = 0; i < sequenceNumber.length; i++) {
        Validator.validateRequiredFieldInARow(sequenceNumber[i], "Sequence Number", false, 0, requiredFields, i);
      }
    }
    return requiredFields;
  }
}