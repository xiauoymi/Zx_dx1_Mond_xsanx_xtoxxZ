package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.equipment.service.MechanicalService;
import com.monsanto.eas.eis.equipment.service.MechanicalServiceImpl;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Mechanical;
import com.monsanto.eas.eis.projects.domain.PurchaseScope;
import com.monsanto.eas.eis.util.EISConstants;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 13, 2008 Time: 6:12:40 PM To change this template use File |
 * Settings | File Templates.
 */
public class MechanicalBuilder extends BaseBuilder {
  private MechanicalService mechanicalService;

  public MechanicalBuilder() {
    this(new MechanicalServiceImpl());
  }

  public MechanicalBuilder(MechanicalService mechanicalService) {
    this.mechanicalService = mechanicalService;
  }

  public Mechanical createMechanicalFromRequest(Equipment equipment, UCCHelper helper) throws IOException {
    String hasMechanicalDataChanged = helper.getRequestParameterValue(EISConstants.HAS_MECHANICAL_DATA_CHANGED);
    Mechanical mechanical = equipment.getMechanical();
    if ("true".equalsIgnoreCase(hasMechanicalDataChanged)) {
      String engineer = helper.getRequestParameterValue(EISConstants.ENGINEER);
      String modelNumber = helper.getRequestParameterValue(EISConstants.MODEL_NUMBER);
      Integer shippingWeight = validateAndSetInteger(helper.getRequestParameterValue(EISConstants.SHIPPING_WEIGHT));
      String purchaseScopeId = helper.getRequestParameterValue(EISConstants.PURCHASE_SCOPE);
      PurchaseScope purchaseScope = null;
      if (!"".equals(purchaseScopeId) && purchaseScopeId != null) {
        purchaseScope = mechanicalService.lookupPurchaseScopeById(Long.valueOf(purchaseScopeId));
      }

      Integer operatingWeight = validateAndSetInteger(helper.getRequestParameterValue(EISConstants.OPERATING_WEIGHT));
//      Integer dynamicLoad = validateAndSetInteger(helper.getRequestParameterValue(EISConstants.DYNAMIC_LOAD));
      String serialNumber = helper.getRequestParameterValue(EISConstants.SERIAL_NUMBER);
      String bidPackageOne = helper.getRequestParameterValue(EISConstants.BID_PACKAGE_ONE);
      String workDescriptionOne = helper.getRequestParameterValue(EISConstants.WORK_DESCRIPTION_ONE);
      String bidPackageTwo = helper.getRequestParameterValue(EISConstants.BID_PACKAGE_TWO);
      String workDescriptionTwo = helper.getRequestParameterValue(EISConstants.WORK_DESCRIPTION_TWO);
      String dynLoad = helper.getRequestParameterValue(EISConstants.DYNAMIC_LOAD);

      mechanical = setupMechanical(mechanical, equipment, engineer, modelNumber, shippingWeight, purchaseScope,
          operatingWeight,
          serialNumber, bidPackageOne, workDescriptionOne, bidPackageTwo, workDescriptionTwo, dynLoad);
    }
    if (mechanical == null) {
      mechanical = new Mechanical();
      mechanical.setEquipment(equipment);
    }
    return mechanical;
  }

  private Mechanical setupMechanical(Mechanical mechanical, Equipment equipment, String engineer, String modelNumber,
                                     Integer shippingWeight, PurchaseScope purchaseScope, Integer operatingWeight,
                                     String serialNumber, String bidPackageOne,
                                     String workDescriptionOne, String bidPackageTwo, String workDescriptionTwo,
                                     String dynLoad) {
    if (mechanical == null) {
      mechanical = new Mechanical(engineer, modelNumber, shippingWeight, purchaseScope, operatingWeight,
          serialNumber,
          dynLoad, equipment);
    } else {
      mechanical.setEngineer(engineer);
      mechanical.setModelNumber(modelNumber);
      mechanical.setShippingWeight(shippingWeight);
      mechanical.setPurchaseScope(purchaseScope);
      mechanical.setOperatingWeight(operatingWeight);
//      mechanical.setDynamicLoad(dynamicLoad);
      mechanical.setDynLoad(dynLoad);
      mechanical.setSerialNumber(serialNumber);
    }
    mechanical.setBidPackageOne(bidPackageOne);
    mechanical.setWorkDescriptionOne(workDescriptionOne);
    mechanical.setBidPackageTwo(bidPackageTwo);
    mechanical.setWorkDescriptionTwo(workDescriptionTwo);

    return mechanical;
  }


  private Integer validateAndSetInteger(String property) {
    if (!StringUtils.isEmpty(property)) {
      return Integer.valueOf(property);
    }
    return null;
  }


}
