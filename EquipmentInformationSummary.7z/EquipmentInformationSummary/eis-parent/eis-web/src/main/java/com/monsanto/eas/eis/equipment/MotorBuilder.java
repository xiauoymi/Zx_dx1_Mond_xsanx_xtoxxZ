/*
 MotorBuilder was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.MotorConstants;
import com.monsanto.eas.eis.util.Validator;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Filename:    $RCSfile: MotorBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date:
 * 2008/10/23 19:51:05 $
 *
 * @author sspati1
 * @version $Revision: 1.16 $
 */
public class MotorBuilder extends BaseBuilder {

  public Set<Motor> createMotorListFromRequest(Equipment equipment, UCCHelper helper) throws IOException {
    String hasMotorsDataChanged = helper.getRequestParameterValue(MotorConstants.HAS_MOTORS_DATA_CHANGED);
    if ("true".equalsIgnoreCase(hasMotorsDataChanged)) {
      String[] motorId = helper.getRequestParameterValues(MotorConstants.MOTOR_ID);
      String[] componentDesignator = helper.getRequestParameterValues(MotorConstants.COMPONENT_DESIGNATOR_ID);
      String[] sequenceNumber = helper.getRequestParameterValues(MotorConstants.MOTOR_SEQUENCE_NUMBER);
      String[] componentName = helper.getRequestParameterValues(MotorConstants.COMPONENT_NAME);
      String[] fla = helper.getRequestParameterValues(MotorConstants.FLA);
      String[] motorVoltage = helper.getRequestParameterValues(MotorConstants.MOTOR_VOLTAGE);
      String[] phase = helper.getRequestParameterValues(MotorConstants.PHASE);
      String[] frequency = helper.getRequestParameterValues(MotorConstants.FREQUENVY);
      String[] rpm = helper.getRequestParameterValues(MotorConstants.RPM);
      String[] designStatusId = helper.getRequestParameterValues(MotorConstants.DESIGN_STATUS_ID);
      String[] comments = helper.getRequestParameterValues(MotorConstants.MOTOR_COMMENTS);
      String[] loadValueTypeId = helper.getRequestParameterValues(MotorConstants.LOAD_VALUE_TYPE_ID);
      String[] loadValueQuantity = helper.getRequestParameterValues(MotorConstants.LOAD_VALUE_QUANTITY);
      String[] ioCabinet = helper.getRequestParameterValues(MotorConstants.IO_CABINET);
      String[] powerSource = helper.getRequestParameterValues(MotorConstants.POWER_SOURCE);
      String[] loadDisconnectReqd = helper.getRequestParameterValues(MotorConstants.LOAD_DISCONNECT_REQUIRED);
      String[] starterSize = helper.getRequestParameterValues(MotorConstants.STARTER_SIZE);
      String[] motorBrake = helper.getRequestParameterValues(MotorConstants.MOTOR_BRAKE);
      String[] bidPackage = helper.getRequestParameterValues(MotorConstants.BID_PACKAGE);
      Set<Motor> motors = new HashSet<Motor>();

      int size = motorId == null ? 0 : motorId.length;
      for (int i = 0; i < size; i++) {
        MotorDesignStatus ds =
            getLong(designStatusId[i]) == null ? null : new MotorDesignStatus(getLong(designStatusId[i]));
        MotorLoadValueType lv =
            getLong(loadValueTypeId[i]) == null ? null : new MotorLoadValueType(getLong(loadValueTypeId[i]));
        ComponentDesignator cd =
            getLong(componentDesignator[i]) == null ? null :
                new ComponentDesignator(getLong(componentDesignator[i]), null, null);

        Motor motor = new Motor(getLong(motorId[i]), cd, sequenceNumber[i], componentName[i], getDouble(fla[i]),
            getInteger(motorVoltage[i]),
            getInteger(phase[i]),
            getInteger(frequency[i]), getInteger(rpm[i]), ds, comments[i], lv,
            getDouble(loadValueQuantity[i]),
            powerSource[i],
            ioCabinet[i], getBool(loadDisconnectReqd[i]), starterSize[i], equipment, bidPackage[i]);
        motor.setMotorBrake(getBool(motorBrake[i]));
        motors.add(motor);
      }
      flagMotorsThatWereDeleted(equipment, helper.getRequestParameterValue(MotorConstants.DELETED_MOTOR_IDS));
      return motors;
    } else {
      return equipment.getMotors();
    }
  }

  //protected for testing
  protected void flagMotorsThatWereDeleted(Equipment equipment, String deletedMotorIds) {
    String[] deletedIds = deletedMotorIds.split(",");
    for (int j = 0; j < deletedIds.length; j++) {
      String deletedId = StringUtils.trim(deletedIds[j]);
      if (StringUtils.isNotBlank(deletedId)) {
        Set<Motor> existingMotors = equipment.getMotors();
        for (Motor motor : existingMotors) {
          if (motor.getId().toString().equals(deletedId)) {
            motor.setDeleted(true);
            break;
          }
        }
      }
    }
  }

  public List<String> validateRequiredFields(UCCHelper helper) throws IOException {
    List<String> requiredFields = new ArrayList<String>();
    String[] componentDesignator = helper.getRequestParameterValues(MotorConstants.COMPONENT_DESIGNATOR_ID);
    String[] sequenceNumber = helper.getRequestParameterValues(MotorConstants.MOTOR_SEQUENCE_NUMBER);
    if (sequenceNumber != null) {
      for (int i = 0; i < sequenceNumber.length; i++) {
        Validator.validateRequiredFieldInARow(sequenceNumber[i], "Sequence Number", false, 0, requiredFields, i);
      }
    }
    if (componentDesignator != null) {
      for (int i = 0; i < componentDesignator.length; i++) {
        Validator
            .validateRequiredFieldInARow(componentDesignator[i], "Component Designator", false, 0, requiredFields, i);
      }
    }
    return requiredFields;
  }
}