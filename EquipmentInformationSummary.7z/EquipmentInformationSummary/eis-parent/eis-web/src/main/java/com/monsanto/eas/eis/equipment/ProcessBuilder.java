/*
 ProcessBuilder was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.equipment.service.ProcessService;
import com.monsanto.eas.eis.equipment.service.ProcessServiceImpl;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.domain.Process;
import com.monsanto.eas.eis.util.ProcessConstants;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: ProcessBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * sspati1 $    	 On:	$Date: 2008/12/15 14:28:33 $
 *
 * @author sspati1
 * @version $Revision: 1.11 $
 */
public class ProcessBuilder extends BaseBuilder {
  private ProcessService processService;

  public ProcessBuilder() {
    this(new ProcessServiceImpl());
  }

  public ProcessBuilder(ProcessService processService) {
    this.processService = processService;
  }

  public Process createProcessFromRequest(Equipment equipment, UCCHelper helper) throws IOException {
    String hasProcessDataChanged = helper.getRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED);
    Process process = equipment.getProcess();
    if ("true".equalsIgnoreCase(hasProcessDataChanged)) {
      String productType = helper.getRequestParameterValue(ProcessConstants.PRODUCT_TYPE);
      Double productDensity = getDouble(helper.getRequestParameterValue(ProcessConstants.PRODUCT_DENSITY));
      Integer designCapacity = getInteger(helper.getRequestParameterValue(ProcessConstants.DESIGN_CAPACITY));
      boolean compAirRequired = isCheckboxChecked(helper.getRequestParameterValue(ProcessConstants.COMP_AIR_REQUIRED));
      Integer compAirPressure = getInteger(helper.getRequestParameterValue(ProcessConstants.COMP_AIR_PRESSURE));
      Integer compAirFlowrate = getInteger(helper.getRequestParameterValue(ProcessConstants.COMP_AIR_FLOWRATE));
      boolean gasRequired = isCheckboxChecked(helper.getRequestParameterValue(ProcessConstants.GAS_REQUIRED));
      Integer gasPressure = getInteger(helper.getRequestParameterValue(ProcessConstants.GAS_PRESSURE));
      Integer gasFlowrate = getInteger(helper.getRequestParameterValue(ProcessConstants.GAS_FLOWRATE));
      Long gasTypeId = getLong(helper.getRequestParameterValue(ProcessConstants.GAS_TYPE));
      boolean waterRequired = isCheckboxChecked(helper.getRequestParameterValue(ProcessConstants.WATER_REQUIRED));
      Integer waterPressure = getInteger(helper.getRequestParameterValue(ProcessConstants.WATER_PRESSURE));
      Integer waterFlowrate = getInteger(helper.getRequestParameterValue(ProcessConstants.WATER_FLOWRATE));
      Long waterTypeId = getLong(helper.getRequestParameterValue(ProcessConstants.WATER_TYPE));
      boolean dustPickupRequired = isCheckboxChecked(
          helper.getRequestParameterValue(ProcessConstants.DUST_PICKUP_REQUIRED));
      Integer ductSize = getInteger(helper.getRequestParameterValue(ProcessConstants.DUCT_SIZE));
      Integer ductFlowrate = getInteger(helper.getRequestParameterValue(ProcessConstants.DIST_FLOWRATE));
      Long dustTypeId = getLong(helper.getRequestParameterValue(ProcessConstants.DUST_TYPE));
      Long designCapacityUnitId = getLong(helper.getRequestParameterValue(ProcessConstants.DESIGN_CAPACITY_UNIT));
      String designCapacityUnitText = helper.getRequestParameterValue(ProcessConstants.DESIGN_CAPACITY_UNIT_TEXT);
      String baghouseCyclone = helper.getRequestParameterValue(ProcessConstants.BAGHOUSE_CYCLONE);
      Integer dustPickupVelocity = getInteger(helper.getRequestParameterValue(ProcessConstants.DUST_PICKUP_VELOCITY));
      String processRemarks = helper.getRequestParameterValue(ProcessConstants.PROCESS_REMARKS);
      boolean specificationRequired =
          isRadioButtonChecked(helper.getRequestParameterValue(ProcessConstants.SPECIFICATION_REQUIRED));

      GasType gasType = gasTypeId == null ? null : this.processService.lookupGasTypeById(gasTypeId);
      WaterType waterType = waterTypeId == null ? null : this.processService.lookupWaterTypeById(waterTypeId);
      DustType dustType = dustTypeId == null ? null : this.processService.lookupDustTypeById(dustTypeId);
      DesignCapacityUnit designCapacityUnit =
          designCapacityUnitId == null ? null : this.processService.lookupDesignCapacityUnitById(designCapacityUnitId);
      if (equipment.getProcess() == null) {
        process = new com.monsanto.eas.eis.projects.domain.Process(null, productType, productDensity, designCapacity,
            designCapacityUnit, compAirRequired, compAirPressure,
            compAirFlowrate, gasRequired, gasType, gasPressure, gasFlowrate, waterRequired,
            waterPressure, waterFlowrate, waterType, dustPickupRequired, dustPickupVelocity,
            dustType, baghouseCyclone, ductSize, ductFlowrate, specificationRequired, processRemarks,
            designCapacityUnitText);
        process.setEquipment(equipment);
        createProcessFieldEquipmentTypesForProcess(process, helper);
      } else {
        process.setProductType(productType);
        process.setProductDensity(productDensity);
        process.setDesignCapacity(designCapacity);
        process.setDesignCapacityUnit(designCapacityUnit);
        process.setDesignCapacityUnitText(designCapacityUnitText);
        process.setCompAirRequired(compAirRequired);
        process.setCompAirPressure(compAirPressure);
        process.setCompAirFlowrate(compAirFlowrate);
        process.setGasRequired(gasRequired);
        process.setGasType(gasType);
        process.setGasPressure(gasPressure);
        process.setGasFlowrate(gasFlowrate);
        process.setWaterRequired(waterRequired);
        process.setWaterPressure(waterPressure);
        process.setWaterFlowrate(waterFlowrate);
        process.setWaterType(waterType);
        process.setDustPickupRequired(dustPickupRequired);
        process.setDustPickupVelocity(dustPickupVelocity);
        process.setDustType(dustType);
        process.setBaghouseCyclone(baghouseCyclone);
        process.setDuctSize(ductSize);
        process.setDuctFlowrate(ductFlowrate);
        process.setSpecificationRequired(specificationRequired);
        process.setProcessRemarks(processRemarks);
        updateProcessFieldEquipmentTypesFromRequest(process, helper);
      }
    }
    if (process == null) {
      process = new Process();
      process.setEquipment(equipment);
      createProcessFieldEquipmentTypesForProcess(process, helper);
    }

    return process;
  }

  private void createProcessFieldEquipmentTypesForProcess(Process process, UCCHelper helper) throws IOException {
    EquipmentType equipmentType = process.getEquipment().getEquipmentType();
    if (equipmentType != null) {
      List<FieldEquipmentType> fieldEquipmentTypes = this.processService
          .lookupAllFieldEquipmentTypes(equipmentType.getId());
      List<ProcessFieldEquipmentType> pfes = new ArrayList<ProcessFieldEquipmentType>();
      for (FieldEquipmentType fe : fieldEquipmentTypes) {
        String value = helper.getRequestParameterValue(fe.getName());
        ProcessFieldEquipmentType pfe = new ProcessFieldEquipmentType(null, process, fe, value);
        pfes.add(pfe);
      }
      process.setProcessFieldEquipmentTypes(pfes);
    }
  }

  private void updateProcessFieldEquipmentTypesFromRequest(Process process,
                                                           UCCHelper helper) throws IOException {
    EquipmentType equipmentType = process.getEquipment().getEquipmentType();
    if (equipmentType != null) {
      List<FieldEquipmentType> fieldEquipmentTypes = this.processService
          .lookupAllFieldEquipmentTypes(equipmentType.getId());
      List<ProcessFieldEquipmentType> pfes = new ArrayList<ProcessFieldEquipmentType>();
      for (FieldEquipmentType fe : fieldEquipmentTypes) {
        String value = helper.getRequestParameterValue(fe.getName());
        ProcessFieldEquipmentType pfe = this.processService
            .lookupProcessFieldEquipmentTypeByFieldName(process.getId(), fe.getName());
        //this test is required for any field that was added to the process field equipment, after the equipment was created.
        if (pfe == null) {
          pfe = new ProcessFieldEquipmentType(null, process, fe, value);
        } else {
          pfe.setValue(value);
        }
        pfes.add(pfe);
      }
      process.setProcessFieldEquipmentTypes(pfes);
    }
  }
}