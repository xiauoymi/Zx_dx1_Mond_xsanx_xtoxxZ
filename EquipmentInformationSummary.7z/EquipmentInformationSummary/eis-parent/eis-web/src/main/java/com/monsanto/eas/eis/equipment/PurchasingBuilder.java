package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Purchasing;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.util.PurchasingConstants;
import com.monsanto.eas.eis.util.EISConstants;

import java.io.IOException;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 28, 2008 Time: 9:25:35 AM To change this template use File |
 * Settings | File Templates.
 */
public class PurchasingBuilder extends BaseBuilder {


  public Purchasing createPurchasingFromRequest(Equipment equipment, UCCHelper helper) throws
      IOException {
    String hasPurchasingDataChanged = helper.getRequestParameterValue(PurchasingConstants.HAS_PURCHASING_DATA_CHANGED);
    Purchasing purchasing = equipment.getPurchasing();
    if ("true".equalsIgnoreCase(hasPurchasingDataChanged)) {
      String vendor = helper.getRequestParameterValue(PurchasingConstants.VENDOR);
      String rtpNumber = helper.getRequestParameterValue(PurchasingConstants.RTP_NUMBER);
      String poNumber = helper.getRequestParameterValue(PurchasingConstants.PO_NUMBER);
      String lineNumber = helper.getRequestParameterValue(PurchasingConstants.LINE_NUMBER);
      String poLineAmount = helper.getRequestParameterValue(PurchasingConstants.PO_LINE_AMOUNT);
      String poLineQuantity = helper.getRequestParameterValue(PurchasingConstants.PO_LINE_QUANTITY);
      String poLineValue = helper.getRequestParameterValue(PurchasingConstants.PO_LINE_VALUE);
      String coAmount = helper.getRequestParameterValue(PurchasingConstants.CO_AMOUNT);
      String originalShipDate = helper.getRequestParameterValue(PurchasingConstants.ORIGINAL_SHIP_DATE);
      String revisedShipDate = helper.getRequestParameterValue(PurchasingConstants.REVISED_SHIP_DATE);
      String actualDeliveryDate = helper.getRequestParameterValue(PurchasingConstants.ACTUAL_DELIVERY_DATE);
      String exportDocuments = helper.getRequestParameterValue(PurchasingConstants.EXPORT_DOCUMENTS);
      //TODO: get back to this later
//    if(soleSourceFromEquipment) {
//      soleSourceForPurchasing = soleSourceFromEquipment;
//    }
//
//    if(soleSourceForPurchasing) {
//      equipment.setSoleSource(soleSourceForPurchasing);
//    }

      purchasing = setupPurchasing(vendor, getInteger(rtpNumber), getLong(poNumber),
          getInteger(lineNumber), getLong(poLineAmount), getInteger(poLineQuantity),
          getLong(poLineValue), getLong(coAmount), ConvertUtil.toDate(originalShipDate,
          ConvertUtil.PROJECTS_DATE), ConvertUtil.toDate(revisedShipDate, ConvertUtil.PROJECTS_DATE),
          ConvertUtil.toDate(actualDeliveryDate, ConvertUtil.PROJECTS_DATE), getBool(exportDocuments),
          purchasing, equipment);
    }
    if (purchasing == null) {
      purchasing = new Purchasing();
      purchasing.setEquipment(equipment);
    }
    return purchasing;
  }

  private Purchasing setupPurchasing(String vendor, Integer rtpNumber, Long poNumber,
                                     Integer lineNumber,
                                     Long poLineAmount, Integer poLineQuantity, Long poLineValue,
                                     Long coAmount, Date originalShipDate, Date revisedShipDate,
                                     Date actualDeliveryDate, boolean exportDocuments, Purchasing purchasing,
                                     Equipment equipment) {
    if (purchasing == null) {
      purchasing = new Purchasing(null, vendor, rtpNumber, poNumber, lineNumber, poLineAmount,
          poLineQuantity, poLineValue, coAmount, originalShipDate,
          revisedShipDate, actualDeliveryDate, exportDocuments);
      purchasing.setEquipment(equipment);
    } else {
      purchasing.setVendor(vendor);
      purchasing.setRtpNumber(rtpNumber);
      purchasing.setPoNumber(poNumber);
      purchasing.setLineNumber(lineNumber);
      purchasing.setPoLineAmount(poLineAmount);
      purchasing.setPoLineQuantity(poLineQuantity);
      purchasing.setPoLineValue(poLineValue);
      purchasing.setCoAmount(coAmount);
      purchasing.setOriginalShipDate(originalShipDate);
      purchasing.setRevisedShipDate(revisedShipDate);
      purchasing.setActualDeliveryDate(actualDeliveryDate);
      purchasing.setExportDocuments(exportDocuments);
      purchasing.setEquipment(equipment);
    }
    return purchasing;
  }

}
