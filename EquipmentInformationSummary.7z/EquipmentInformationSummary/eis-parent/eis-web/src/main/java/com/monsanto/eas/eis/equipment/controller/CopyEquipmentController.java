/*
 CopyEquipmentController was created on Feb 5, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.eas.eis.controller.EISController;
import com.monsanto.eas.eis.equipment.service.EquipmentService;
import com.monsanto.eas.eis.equipment.service.EquipmentServiceImpl;
import com.monsanto.eas.eis.projects.AreaComparator;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.domain.Area;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.services.ProjectsServiceImpl;
import com.monsanto.eas.eis.util.CopyEquipmentConstants;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.util.Validator;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Filename:    $RCSfile: CopyEquipmentController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-20 17:45:54 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class CopyEquipmentController extends EISController {
  private ProjectsService projectService;
  private EquipmentService equipmentService;

  public CopyEquipmentController() {
    this(new ProjectsServiceImpl(), new EquipmentServiceImpl());
  }

  public CopyEquipmentController(ProjectsService projectService, EquipmentService equipmentService) {
    this.projectService = projectService;
    this.equipmentService = equipmentService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
  }

  public void setupSearchForEquipmentsToCopy(UCCHelper helper) throws IOException {
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    String copyFromMaster = helper.getRequestParameterValue(EISConstants.COPY_FROM_MASTER);
    Projects project = this.projectService.lookupProjectById(Long.valueOf(projectId));
    if("true".equalsIgnoreCase(copyFromMaster)){
      Projects masterProject = this.projectService.lookupMasterProjectForThisProject(project);
      helper.setRequestAttributeValue(CopyEquipmentConstants.COPY_FROM_PROJECT_ID, masterProject.getId());
    }else{
      helper.setRequestAttributeValue(CopyEquipmentConstants.COPY_FROM_PROJECT_ID, project.getId());
    }
    helper.setRequestAttributeValue(EISConstants.PROJECT_DETAIL, project);
    helper.setRequestAttributeValue(EISConstants.COPY_FROM_MASTER, copyFromMaster);
    helper.setRequestAttributeValue(EISConstants.EQUIPMENT_AREAS, getAreas(project));
    helper
        .setRequestAttributeValue(EISConstants.EQUIPMENT_TYPES, this.equipmentService.lookupAllParentEquipmentTypes());
    helper.setRequestAttributeValue(EISConstants.SAVE_SUCCESSFUL_MSG, helper.getRequestParameterValue(EISConstants.SAVE_SUCCESSFUL_MSG));
    helper.forward(CopyEquipmentConstants.SEARCH_EQUIPMENTS_TO_COPY_JSP);
  }

  public void setupEquipmentsToCopy(UCCHelper helper) throws IOException {
    String equipmentIdToCopy = helper.getRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_ID_TO_COPY);
    String quantity = helper.getRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_QUANTITY);
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    Projects project = this.projectService.lookupProjectById(Long.valueOf(projectId));
    helper.setRequestAttributeValue(EISConstants.COPY_FROM_MASTER, helper.getRequestParameterValue(EISConstants.COPY_FROM_MASTER));
    helper.setRequestAttributeValue(CopyEquipmentConstants.EQUIPMENT_ID_TO_COPY, equipmentIdToCopy);
    helper.setRequestAttributeValue(CopyEquipmentConstants.EQUIPMENT_QUANTITY, quantity);
    helper.setRequestAttributeValue(EISConstants.PROJECT_DETAIL, project);
    helper.forward(CopyEquipmentConstants.EDIT_EQUIPMENTS_BEFORE_COPYING_JSP);
  }

  public void lookupRefDataForEditEquipmentsBeforeCopyingXML(UCCHelper helper) throws IOException {
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    Projects project = this.projectService.lookupProjectById(Long.valueOf(projectId));
    StringBuffer xmlStr = new StringBuffer("<refData>");
    appendAreaXml(xmlStr, project);
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  public void copyEquipmentsToProject(UCCHelper helper) throws IOException, CloneNotSupportedException {
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    Projects project = this.projectService.lookupProjectById(Long.valueOf(projectId));
    String equipmentIdToCopy = helper.getRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_ID_TO_COPY);
    Equipment eqipmentToCopyFrom = this.equipmentService.lookupEquipment(new Long(equipmentIdToCopy));

    String[] equipmentName = helper.getRequestParameterValues(CopyEquipmentConstants.EQUIPMENT_NAME);
    String[] areaId = helper.getRequestParameterValues(CopyEquipmentConstants.EQUIPMENT_AREA);
    String[] processLineNumber = helper.getRequestParameterValues(CopyEquipmentConstants.PROCESS_LINE_NUMBER);
    String[] equipmentTagNumber = helper.getRequestParameterValues(CopyEquipmentConstants.EQUIPMENT_TAG_NUMBER);

    String successMsg = null;
    List<String> requiredFieldErrors = validateEquipmentForRequiredFields(equipmentName, areaId, processLineNumber,
        equipmentTagNumber);
    List<String> invalidLengthErrors = validateEquipmentForRequiredLength(equipmentTagNumber);
    if (requiredFieldErrors.isEmpty() && invalidLengthErrors.isEmpty()) {
      for (int i = 0; i < equipmentName.length; i++) {
          eqipmentToCopyFrom.copyingForSave=true;
        Equipment copyOfEquipment = eqipmentToCopyFrom.createCopy();
          eqipmentToCopyFrom.copyingForSave=false;
        copyOfEquipment.setName(equipmentName[i]);
        Area area = this.equipmentService.lookupAreaById(new Long(areaId[i]));
        copyOfEquipment.setArea(area);
        copyOfEquipment.setProcessLineNumber(processLineNumber[i]);
        copyOfEquipment.setEquipmentTagNumber(equipmentTagNumber[i]);
        copyOfEquipment
            .setEquipmentNumber(buildEquipmentNumber(eqipmentToCopyFrom, processLineNumber[i], equipmentTagNumber[i],
                area));
        copyOfEquipment.setProjects(project);
        this.equipmentService.saveEquipment(copyOfEquipment);
        successMsg = "" + equipmentName.length + " Equipment Item(s) successfully saved";
      }
    } else {
      clearHibernateSession();
    }
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(createResponseDocument(successMsg, requiredFieldErrors, invalidLengthErrors));
  }

  //protected for testing
  protected void clearHibernateSession() {
    EISHibernateUtil.getHibernateFactory().getSession().clear();
  }

  private String buildEquipmentNumber(Equipment eqipmentToCopyFrom, String processLineNumber,
                                      String equipmentTagNumber, Area area) {
    return area.getAreaCode() + "." + processLineNumber + "." + equipmentTagNumber + eqipmentToCopyFrom.getEquipmentType().getTypeCode();
  }

  private Document createResponseDocument(String successMsg, List<String> requiredFieldErrors,
                                          List<String> invalidLengthErrors) throws IOException {
    StringBuffer responseStr = new StringBuffer("<response>");
    responseStr.append("<successMsg>");
    responseStr.append(successMsg == null ? "" : successMsg);
    responseStr.append("</successMsg>");
    responseStr.append("<errors>");
    appendErrors(responseStr, requiredFieldErrors, "Required Fields:");
    appendErrors(responseStr, invalidLengthErrors, "Fields with invalid length:");
    responseStr.append("</errors>");
    responseStr.append("</response>");
    return getDocument(responseStr);
  }

  private void appendErrors(StringBuffer responseStr, List<String> requiredFieldList,
                            String errorHeader) {
    if (!requiredFieldList.isEmpty()) {
      responseStr.append("<error>");
      responseStr.append("<errorHeader>");
      responseStr.append(errorHeader);
      responseStr.append("</errorHeader>");
      for (String errorMsg : requiredFieldList) {
        responseStr.append("<errorMsg>");
        responseStr.append(errorMsg);
        responseStr.append("</errorMsg>");
      }
      responseStr.append("</error>");
    }
  }

  private List<String> validateEquipmentForRequiredFields(String[] equipmentName, String[] areaId,
                                                          String[] processLineNumber,
                                                          String[] equipmentTagNumber) {
    List<String> errors = new ArrayList<String>();
    for (int i = 0; i < equipmentName.length; i++) {
      validateRequiredField(i, equipmentName[i], "Equipment Name", errors);
      validateRequiredField(i, areaId[i], "Equipment Area", errors);
      validateRequiredField(i, processLineNumber[i], "Process Line Number", errors);
      validateRequiredField(i, equipmentTagNumber[i], "Equipment Tag Number", errors);
    }
    return errors;
  }

  private List<String> validateEquipmentForRequiredLength(String[] equipmentTagNumber) {
    List<String> errors = new ArrayList<String>();
    for (int i = 0; i < equipmentTagNumber.length; i++) {
      validateEquipmentTagNumberLength(i, equipmentTagNumber[i], "Equipment Tag Number", 3, errors);
    }
    return errors;
  }

  private void validateRequiredField(int rowNum, String requestParameterValue, String label,
                                     List<String> requiredFields) {
    if (Validator.isRequiredFieldEmpty(requestParameterValue)) {
      requiredFields.add("On row " + (rowNum + 1) + ": " + label + " is a required field");
    }
  }

  private void validateEquipmentTagNumberLength(int rowNum, String requestParameterValue, String label,
                                                int expectedLength,
                                                List<String> invalidFieldLength) {
    if (!Validator.isFieldLengthValid(requestParameterValue, expectedLength)) {
      String message = "On row " + (rowNum + 1) + ": " + label + " has an invalid minimum length";
      invalidFieldLength.add(message);
    }
  }

  private List<Area> getAreas(Projects project) {
    List<Area> areaList = project.getCrop().getAreas();
    Collections.sort(areaList, new AreaComparator());
    return areaList;
  }

  private void appendAreaXml(StringBuffer xmlStr, Projects project) {
    xmlStr.append("<areas>");
    for (Area area : getAreas(project)) {
      xmlStr.append(area.toXml());
    }
    xmlStr.append("</areas>");
  }

  private Document getDocument(StringBuffer xmlStr) throws IOException {
    Document document;
    try {
      document = DOMUtil.stringToXML(xmlStr.toString());
    } catch (ParserException e) {
      throw new RuntimeException("Unable to parse process xml");
    }
    return document;
  }

}