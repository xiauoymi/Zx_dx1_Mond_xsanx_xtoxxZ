package com.monsanto.eas.eis.equipment.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.eas.eis.controller.EISController;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.equipment.*;
import com.monsanto.eas.eis.equipment.ProcessBuilder;
import com.monsanto.eas.eis.equipment.service.EquipmentService;
import com.monsanto.eas.eis.equipment.service.EquipmentServiceImpl;
import com.monsanto.eas.eis.equipment.service.ElectricalService;
import com.monsanto.eas.eis.equipment.service.ElectricalServiceImpl;
import com.monsanto.eas.eis.projects.EISDAOFactoryImpl;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.util.EquipmentConstants;
import com.monsanto.eas.eis.audit.service.AuditService;
import com.monsanto.eas.eis.audit.service.AuditServiceImpl;
import com.monsanto.eas.eis.audit.domain.AuditDetail;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.List;


/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Sep 2, 2008 Time: 3:31:57 PM To change this template use File | Settings
 * | File Templates.
 */
public class EquipmentController extends EISController {
  private EquipmentService equipmentService;
  private EquipmentBuilder equipmentBuilder;
  private ProcessBuilder processBuilder;
  private MechanicalBuilder mechanicalBuilder;
  private MotorBuilder motorBuilder;
  private InstrumentBuilder instrumentBuilder;
  private AccessoryBuilder accessoryBuilder;
  private ElectricalBuilder electricalBuilder;
  private PurchasingBuilder purchasingBuilder;
  private CostScheduleBuilder costScheduleBuilder;
  private AuditService auditService;
  private ElectricalService electricalService;


  protected void notSpecified(UCCHelper helper) throws IOException {
  }

  public EquipmentController() {
    this(new EquipmentServiceImpl(new EISDAOFactoryImpl()), new EquipmentBuilder(new EISDAOFactoryImpl()),
        new ProcessBuilder(), new MechanicalBuilder(), new MotorBuilder(), new InstrumentBuilder(),
        new AccessoryBuilder(), new ElectricalBuilder(), new PurchasingBuilder(), new CostScheduleBuilder(), new AuditServiceImpl(),
        new ElectricalServiceImpl());
  }

  public EquipmentController(EquipmentService equipmentService, EquipmentBuilder equipmentBuilder,
                             ProcessBuilder processBuilder, MechanicalBuilder mechanicalBuilder,
                             MotorBuilder motorBuilder, InstrumentBuilder instrumentBuilder,
                             AccessoryBuilder accessoryBuilder, ElectricalBuilder electricalBuilder,
                             PurchasingBuilder purchasingBuilder, CostScheduleBuilder costScheduleBuilder,
                             AuditService auditService, ElectricalService electricalService) {
    this.equipmentService = equipmentService;
    this.equipmentBuilder = equipmentBuilder;
    this.processBuilder = processBuilder;
    this.mechanicalBuilder = mechanicalBuilder;
    this.motorBuilder = motorBuilder;
    this.instrumentBuilder = instrumentBuilder;
    this.accessoryBuilder = accessoryBuilder;
    this.electricalBuilder = electricalBuilder;
    this.purchasingBuilder = purchasingBuilder;
    this.costScheduleBuilder = costScheduleBuilder;
    this.auditService = auditService;
    this.electricalService = electricalService;
  }

  public void saveEquipment(UCCHelper helper) throws IOException {
    Equipment equipment = this.equipmentBuilder.createEquipmentFromParameters(helper);
    List<String> requiredFieldList = this.equipmentBuilder.validate(equipment);
    List<String> invalidFieldLengthList = this.equipmentBuilder.validateAllFieldsLength(equipment);
    equipment.setProcess(this.processBuilder.createProcessFromRequest(equipment, helper));
    equipment.setMotors(this.motorBuilder.createMotorListFromRequest(equipment, helper));
    List<String> motorRequiredFields = this.motorBuilder.validateRequiredFields(helper);
    equipment.setInstruments(this.instrumentBuilder.createIntrumentListFromRequest(equipment, helper));
    List<String> instrumentRequiredFields = this.instrumentBuilder.validateRequiredFields(helper);
    equipment.setAccessories(this.accessoryBuilder.createAccessoryListFromRequest(equipment, helper));
    List<String> accessoryRequiredFields = this.accessoryBuilder.validateRequiredFields(helper);
    equipment.setMechanical(this.mechanicalBuilder.createMechanicalFromRequest(equipment, helper));
    equipment.setElectrical(this.electricalBuilder.createElectricalFromRequest(equipment, helper));
    equipment.setPurchasing(
        this.purchasingBuilder.createPurchasingFromRequest(equipment, helper));
    equipment.setCostSchedule(this.costScheduleBuilder.createCostScheduleFromRequest(equipment, helper));
    if (requiredFieldList.size() == 0 && invalidFieldLengthList.size() == 0 && motorRequiredFields.size() == 0
        && instrumentRequiredFields.size() == 0 && accessoryRequiredFields.size() == 0) {
      equipment = equipmentService.saveEquipment(equipment);
    } else {
      clearHibernateSession();
    }
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(createResponseDocument(equipment.getId(), requiredFieldList,
        invalidFieldLengthList, motorRequiredFields, instrumentRequiredFields, accessoryRequiredFields));
  }

  //protected for testing
  protected void clearHibernateSession() {
    EISHibernateUtil.getHibernateFactory().getSession().clear();
  }

  private Document createResponseDocument(Long equipId, List<String> requiredFieldList,
                                          List<String> invalidFieldLengthList, List<String> motorRequiredFields,
                                          List<String> instrumentRequiredFields,
                                          List<String> accessoryRequiredFields) throws IOException {
    StringBuffer responseStr = new StringBuffer("<response>");
    responseStr.append("<equipmentId>");
    responseStr.append(equipId == null ? "" : equipId.toString());
    responseStr.append("</equipmentId>");
    responseStr.append("<errors>");
    appendErrors(responseStr, requiredFieldList, "Details Required Fields:");
    appendErrors(responseStr, invalidFieldLengthList, "Details Fields with invalid length:");
    appendErrors(responseStr, motorRequiredFields, "Motor Required Fields:");
    appendErrors(responseStr, instrumentRequiredFields, "Instrument Required Fields:");
    appendErrors(responseStr, accessoryRequiredFields, "Accessory Required Fields:");
    responseStr.append("</errors>");
    responseStr.append("</response>");
    Document document = null;
    try {
      document = DOMUtil.stringToXML(responseStr.toString());
    } catch (ParserException e) {
      throw new RuntimeException("Unable to parse response xml", e);
    }
    return document;
  }

  private void appendErrors(StringBuffer responseStr, List<String> requiredFieldList,
                            String errorHeader) {
    if (!requiredFieldList.isEmpty()) {
      responseStr.append("<error>");
      responseStr.append("<errorHeader>");
      responseStr.append(errorHeader);
      responseStr.append("</errorHeader>");
      for (String errorMsg : requiredFieldList) {
        responseStr.append("<errorMsg>");
        responseStr.append(errorMsg);
        responseStr.append("</errorMsg>");
      }
      responseStr.append("</error>");
    }
  }

  public void lookupEquipmentSubTypes(UCCHelper helper) throws IOException {
    Document document = equipmentService
        .lookupEquipmentSubTypes(Long.valueOf(helper.getRequestParameterValue(EquipmentConstants.EQUIPMENT_TYPE)));
    helper.setContentType("text/xml");
    helper.writeXMLDocument(document);
  }

  public void lookupEquipmentXml(UCCHelper helper) throws IOException {
    Equipment equipment = getEquipmentFromHelper(helper);
    Document document = null;
    try {
      document = DOMUtil.stringToXML(equipment.toXml());
    } catch (ParserException e) {
      throw new RuntimeException("Unable to parse equipment xml", e);
    }
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(document);
  }

  private Equipment getEquipmentFromHelper(UCCHelper helper) throws IOException {
    String equipmentId = helper.getRequestParameterValue(EISConstants.EQUIPMENT_ID);
    return equipmentService.lookupEquipment(Long.valueOf(equipmentId));
  }

  private static interface EquipmentComponentAction {
    XmlObject getComponent(Equipment eq);
  }

  private Document getDocumentFromComponent(EquipmentComponentAction action, Equipment eq) throws IOException {
    try {
      return DOMUtil.stringToXML(action.getComponent(eq).toXml());
    } catch (ParserException e) {
      throw new RuntimeException("Unable to parse xml", e);
    }
  }

  private void lookupComponentXml(UCCHelper helper, EquipmentComponentAction action) throws IOException {
    Equipment equipment = getEquipmentFromHelper(helper);
    Document document = getDocumentFromComponent(action, equipment);
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(document);
  }

  public void lookupProcessXml(UCCHelper helper) throws IOException {
    lookupComponentXml(helper, new EquipmentComponentAction() {
      public XmlObject getComponent(Equipment eq) {
        return eq.getProcess();
      }
    }
    );
  }

  public void lookupMechanicalXml(UCCHelper helper) throws IOException {
    lookupComponentXml(helper, new EquipmentComponentAction() {
      public XmlObject getComponent(Equipment eq) {
        return eq.getMechanical();
      }
    }
    );
  }

  public void lookupElectricalXml(UCCHelper helper) throws IOException {
    lookupComponentXml(helper, new EquipmentComponentAction() {
      public XmlObject getComponent(Equipment eq) {
        return electricalService.lookupElectrical(eq.getElectrical().getId());
//        return eq.getElectrical();
      }
    }
    );
  }

  public void deleteEquipment(UCCHelper helper) throws IOException {
    String equipmentId = helper.getRequestParameterValue(EISConstants.EQUIPMENT_ID);
    this.equipmentService.deleteEquipment(equipmentId);
    helper.setContentType(EISConstants.TEXT_PLAIN);
    helper.getPrintWriter().write("ok");
  }

  public void lookupPurchasingXml(UCCHelper helper) throws IOException {
    lookupComponentXml(helper, new EquipmentComponentAction() {
      public XmlObject getComponent(Equipment eq) {
        return eq.getPurchasing();
      }
    }
    );
  }


  public void lookupCostScheduleXml(UCCHelper helper) throws IOException {
    lookupComponentXml(helper, new EquipmentComponentAction() {
      public XmlObject getComponent(Equipment eq) {
        return eq.getCostSchedule();
      }
    }
    );
  }

  public void updateVerificationForEquipmentChange(UCCHelper helper) throws IOException {
    User logonUser = (User) helper.getSessionParameter(EISConstants.LOGIN_USER);
    String detailId = helper.getRequestParameterValue(EISConstants.AUDIT_DETAIL_ID);
    String tranId = helper.getRequestParameterValue(EISConstants.AUDIT_TRANSACTION_ID);
    String changeVerifiedColumn = helper.getRequestParameterValue(EISConstants.EQUIPMENT_CHANGE_VERIFIED_COLUMN);
    String checkedUnchecked = helper.getRequestParameterValue(EISConstants.EQUIPMENT_CHANGE_VERIFIED_CHECKED_UNCHECKED);
    if ("false".equalsIgnoreCase(checkedUnchecked)) {
      logonUser = null;
    }
    this.auditService.updateVerificationForEquipmentChange(detailId, tranId, changeVerifiedColumn, logonUser);
  }
}
