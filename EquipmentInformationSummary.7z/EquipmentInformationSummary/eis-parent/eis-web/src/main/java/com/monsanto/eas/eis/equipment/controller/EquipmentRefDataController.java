/*
 EquipmentRefDataController was created on Oct 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.eas.eis.controller.EISController;
import com.monsanto.eas.eis.equipment.service.*;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.EISConstants;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: EquipmentRefDataController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-01-22 19:18:46 $
 *
 * @author sspati1
 * @version $Revision: 1.17 $
 */
public class EquipmentRefDataController extends EISController {
  private MotorService motorService;
  private InstrumentService instrumentService;
  private ElectricalService electricalService;
  private AccessoryService accessoryService;
  private ProcessService processService;
  private CostScheduleService costScheduleService;
  private MechanicalService mechanicalService;
  private EquipmentService equipmentService;

  public EquipmentRefDataController() {
    this(new MotorServiceImpl(),
        new InstrumentServiceImpl(),
        new ElectricalServiceImpl(),
        new AccessoryServiceImpl(),
        new ProcessServiceImpl(),
        new CostScheduleServiceImpl(),
        new MechanicalServiceImpl(),
        new EquipmentServiceImpl());
  }

  public EquipmentRefDataController(MotorService motorService, InstrumentService instrumentService,
                                    ElectricalService electricalService, AccessoryService accessoryService,
                                    ProcessService processService, CostScheduleService costScheduleService,
                                    MechanicalService mechanicalService, EquipmentService equipmentService) {
    this.motorService = motorService;
    this.instrumentService = instrumentService;
    this.electricalService = electricalService;
    this.accessoryService = accessoryService;
    this.processService = processService;
    this.costScheduleService = costScheduleService;
    this.mechanicalService = mechanicalService;
    this.equipmentService = equipmentService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
  }

  public void lookupRefDataForMechanicalXML(UCCHelper helper) throws IOException {
    StringBuffer xmlStr = new StringBuffer("<refData>");
    appendPurchaseScopeXml(xmlStr);
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  public void lookupRefDataForMotorXML(UCCHelper helper) throws IOException {
    StringBuffer xmlStr = new StringBuffer("<refData>");
    appendDesignStatusXml(xmlStr);
    appendLoadValueXml(xmlStr);
    appendComponentDesignatorXml(xmlStr);
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  public void lookupRefDataForInstrumentXML(UCCHelper helper) throws IOException {
    StringBuffer xmlStr = new StringBuffer("<refData>");
    appendDesignatorFirstCharXml(xmlStr);
    appendDesignatorSecondCharXml(xmlStr);
    appendIoTypeXml(xmlStr);
 //   appendInstrumentTypeXml(xmlStr);
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  public void lookupRefDataForElectricalXML(UCCHelper helper) throws IOException {
    StringBuffer xmlStr = new StringBuffer("<refData>");
    appendInputXml(xmlStr);
    appendOutputXml(xmlStr);
    appendOtherMeasurementXml(xmlStr);
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  public void lookupRefDataForAccessoryXML(UCCHelper helper) throws IOException {
    StringBuffer xmlStr = new StringBuffer("<refData>");
    appendAccessoryDesignatorXml(xmlStr);
    appendAutoManualXml(xmlStr);
    appendInputXml(xmlStr);
    appendOutputXml(xmlStr);
    appendOtherMeasurementXml(xmlStr);
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  public void lookupRefDataForProcessXML(UCCHelper helper) throws IOException {
    StringBuffer xmlStr = new StringBuffer("<refData>");
    appendFieldEquipmentTypesXml(xmlStr);
    appendGasTypeXml(xmlStr);
    appendWaterTypeXml(xmlStr);
    appendDustTypeXml(xmlStr);
    appendDesignCapacityUnitXml(xmlStr, helper.getRequestParameterValue("unitMeasureId"));
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  public void lookupRefDataForProcessDetailsTabXML(UCCHelper helper) throws IOException {
    StringBuffer xmlStr = new StringBuffer("<refData>");
    xmlStr.append("<designCapacityUnits>");
    String equipmentTypeId = helper.getRequestParameterValue("equipmentTypeId");
    String unitMeasureId = helper.getRequestParameterValue("unitMeasureId");
    for (DesignCapacityUnit dcu : this.processService
        .lookupDesignCapacityUnitsByEquipmentTypeAndUnitMeasure(new Long(equipmentTypeId),
            new Long(unitMeasureId))) {
      xmlStr.append(dcu.toXml());
    }
    xmlStr.append("</designCapacityUnits>");
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  public void lookupRefDataForCostScheduleXML(UCCHelper helper) throws IOException {
    StringBuffer xmlStr = new StringBuffer("<refData>");
    appendFundingSourceXml(xmlStr);
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  private void appendPurchaseScopeXml(StringBuffer xmlStr) {
    xmlStr.append("<purchaseScopes>");
    for (PurchaseScope fs : mechanicalService.lookupAllPurchaseScopes()) {
      xmlStr.append(fs.toXml());
    }
    xmlStr.append("</purchaseScopes>");
  }

  private void appendFundingSourceXml(StringBuffer xmlStr) {
    xmlStr.append("<fundingSources>");
    for (FundingSource fs : costScheduleService.lookupAllFundingSources()) {
      xmlStr.append(fs.toXml());
    }
    xmlStr.append("</fundingSources>");
  }

  private void appendFieldEquipmentTypesXml(StringBuffer xmlStr) {
    xmlStr.append("<fieldEquipmentTypes>");
    for (FieldEquipmentType fet : processService.lookupAllFieldEquipmentTypes(null)) {
      xmlStr.append(fet.toXml());
    }
    xmlStr.append("</fieldEquipmentTypes>");
  }

  private void appendGasTypeXml(StringBuffer xmlStr) {
    xmlStr.append("<gasTypes>");
    for (GasType in : this.processService.lookupAllGasTypes()) {
      xmlStr.append(in.toXml());
    }
    xmlStr.append("</gasTypes>");
  }

  private void appendWaterTypeXml(StringBuffer xmlStr) {
    xmlStr.append("<waterTypes>");
    for (WaterType in : this.processService.lookupAllWaterTypes()) {
      xmlStr.append(in.toXml());
    }
    xmlStr.append("</waterTypes>");
  }

  private void appendDustTypeXml(StringBuffer xmlStr) {
    xmlStr.append("<dustTypes>");
    for (DustType in : this.processService.lookupAllDustTypes()) {
      xmlStr.append(in.toXml());
    }
    xmlStr.append("</dustTypes>");
  }

  private void appendDesignCapacityUnitXml(StringBuffer xmlStr, String unitMeasureId) {
    UnitMeasure unitMeasure = this.processService.lookupUnitMeasureById(new Long(unitMeasureId));
    List<EquipmentType> equipmentTypes = equipmentService.lookupAllParentEquipmentTypes();
    xmlStr.append("<equipmentTypes>");
    for (EquipmentType et : equipmentTypes) {
      xmlStr.append("<equipmentType>");
      xmlStr.append("<typeCode>");
      xmlStr.append(et.getTypeCode());
      xmlStr.append("</typeCode>");
      xmlStr.append("<designCapacityUnits>");
      for (DesignCapacityUnit dcu : et.getDesignCapacityUnits()) {
        if (dcu.getUnitMeasure().equals(unitMeasure)) {
          xmlStr.append(dcu.toXml());
        }
      }
      xmlStr.append("</designCapacityUnits>");
      xmlStr.append("</equipmentType>");
    }
    xmlStr.append("</equipmentTypes>");
  }

  private void appendAutoManualXml(StringBuffer xmlStr) {
    xmlStr.append("<autoManuals>");
    for (AutoManual in : this.accessoryService.lookupAllAutoManuals()) {
      xmlStr.append(in.toXml());
    }
    xmlStr.append("</autoManuals>");
  }

  private void appendAccessoryDesignatorXml(StringBuffer xmlStr) {
    xmlStr.append("<accessoryDesignators>");
    for (AccessoryDesignator in : this.accessoryService.lookupAllAccessoryDesignators()) {
      xmlStr.append(in.toXml());
    }
    xmlStr.append("</accessoryDesignators>");
  }

  private Document getDocument(StringBuffer xmlStr) throws IOException {
    Document document;
    try {
      document = DOMUtil.stringToXML(xmlStr.toString());
    } catch (ParserException e) {
      throw new RuntimeException("Unable to parse process xml");
    }
    return document;
  }

  private void appendInputXml(StringBuffer xmlStr) {
    xmlStr.append("<inputs>");
    for (ElectricalInput in : this.electricalService.lookupAllInputs()) {
      xmlStr.append(in.toXml());
    }
    xmlStr.append("</inputs>");
  }

  private void appendOutputXml(StringBuffer xmlStr) {
    xmlStr.append("<outputs>");
    for (ElectricalOutput in : this.electricalService.lookupAllOutputs()) {
      xmlStr.append(in.toXml());
    }
    xmlStr.append("</outputs>");
  }

  private void appendOtherMeasurementXml(StringBuffer xmlStr) {
    xmlStr.append("<otherMeasurements>");
    for (OtherMeasurement in : this.electricalService.lookupAllOtherMeasurements()) {
      xmlStr.append(in.toXml());
    }
    xmlStr.append("</otherMeasurements>");
  }


  private void appendIoTypeXml(StringBuffer xmlStr) {
    xmlStr.append("<ioTypes>");
    for (IOType type : this.instrumentService.lookupAllIOTypes()) {
      xmlStr.append(type.toXml());
    }
    xmlStr.append("</ioTypes>");
  }

  private void appendDesignatorSecondCharXml(StringBuffer xmlStr) {
    xmlStr.append("<instrumentDesignatorsForSecondChar>");
    for (InstrumentDesignator id : this.instrumentService.lookupAllInstrumentDesignatorsForSecondChar()) {
      xmlStr.append(id.toXml());
    }
    xmlStr.append("</instrumentDesignatorsForSecondChar>");
  }

  private void appendDesignatorFirstCharXml(StringBuffer xmlStr) {
    xmlStr.append("<instrumentDesignatorsForFirstChar>");
    for (InstrumentDesignator id : this.instrumentService.lookupAllInstrumentDesignatorsForFirstChar()) {
      xmlStr.append(id.toXml());
    }
    xmlStr.append("</instrumentDesignatorsForFirstChar>");
  }

  private void appendLoadValueXml(StringBuffer xmlStr) {
    xmlStr.append("<loadValueTypes>");
    for (MotorLoadValueType lv : this.motorService.lookupAllLoadValyeTypes()) {
      xmlStr.append(lv.toXml());
    }
    xmlStr.append("</loadValueTypes>");
  }

  private void appendComponentDesignatorXml(StringBuffer xmlStr) {
    xmlStr.append("<componentDesignators>");
    for (ComponentDesignator cd : this.motorService.lookupAllComponentDesignators()) {
      xmlStr.append(cd.toXml());
    }
    xmlStr.append("</componentDesignators>");
  }

  private void appendDesignStatusXml(StringBuffer xmlStr) {
    xmlStr.append("<designStatuses>");
    for (MotorDesignStatus ds : this.motorService.lookupAllDesignStatus()) {
      xmlStr.append(ds.toXml());
    }
    xmlStr.append("</designStatuses>");
  }

}