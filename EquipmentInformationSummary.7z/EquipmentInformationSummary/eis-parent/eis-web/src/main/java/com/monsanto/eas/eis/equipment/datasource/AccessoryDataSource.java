/*
 AccessoryDataSource was created on Nov 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.domain.Accessory;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.util.*;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;

import java.util.*;

/**
 * Filename:    $RCSfile: AccessoryDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2008-12-22 14:17:43 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class AccessoryDataSource extends BaseDisciplineDataSource {
  private static Map<String, String[]> sortKeyAliasMap = new HashMap<String, String[]>();

  static {
    sortKeyAliasMap.put(AccessoryConstants.ACCE_AUTO_MANUAL_ID, new String[]{"autoManual", "value"});
    sortKeyAliasMap.put(AccessoryConstants.ACCE_DESGINATOR_ID, new String[]{"acccessoryDesignator", "typeCode"});

    sortKeyAliasMap.put(ElectricalConstants.INPUT_ID, new String[]{"electrical,input", "input"});
    sortKeyAliasMap.put(ElectricalConstants.OUTPUT_ID, new String[]{"electrical,output", "output"});
    sortKeyAliasMap.put(ElectricalConstants.OTHER_MEASUREMENT_ID, new String[]{"electrical,otherMeasurement", "measurement"});
    sortKeyAliasMap
        .put(ElectricalConstants.PROOF_OF_POSITION_REQUIRED, new String[]{"electrical", "proofOfPositionReq"});
    sortKeyAliasMap.put(ElectricalConstants.SOLENOID_REQUIRED, new String[]{"electrical", "solenoidReq"});
    sortKeyAliasMap
        .put(ElectricalConstants.LOCAL_PUSH_BUTTON_REQUIRED, new String[]{"electrical", "localPushButtonReq"});
    sortKeyAliasMap.put(ElectricalConstants.INPUT_QUANTITY, new String[]{"electrical", "inputQty"});
    sortKeyAliasMap.put(ElectricalConstants.OUTPUT_QUANTITY, new String[]{"electrical", "outputQty"});
    sortKeyAliasMap.put(ElectricalConstants.HMI_DISPLAY, new String[]{"electrical", "hmiDisplay"});
    sortKeyAliasMap.put(ElectricalConstants.COMMUNICATIONS, new String[]{"electrical", "communications"});
    sortKeyAliasMap.put(ElectricalConstants.VOLTAGE, new String[]{"electrical", "voltage"});

    sortKeyAliasMap.put(InstrumentConstants.IO_TYPE_ID, new String[]{"ioType", "type"});
    sortKeyAliasMap.put(InstrumentConstants.INST_TYPE_ID, new String[]{"instrumentType", "type"});
    sortKeyAliasMap.put(PurchasingConstants.VENDOR, new String[]{"purchasing", "vendor"});
    sortKeyAliasMap.put(PurchasingConstants.RTP_NUMBER, new String[]{"purchasing", "rtpNumber"});
    sortKeyAliasMap.put(PurchasingConstants.PO_NUMBER, new String[]{"purchasing", "poNumber"});
    sortKeyAliasMap.put(PurchasingConstants.LINE_NUMBER, new String[]{"purchasing", "lineNumber"});
    sortKeyAliasMap.put(PurchasingConstants.ACTUAL_DELIVERY_DATE, new String[]{"purchasing", "actualDeliveryDate"});
  }

  public AccessoryDataSource(UCCHelper helper) {
    this(helper, new HibernateDAO<Accessory, Long>(EISHibernateUtil.getHibernateFactory(), Accessory.class));
  }

  public AccessoryDataSource(UCCHelper helper, GenericDAO<Accessory, Long> accessoryDao) {
    super(helper, accessoryDao, sortKeyAliasMap);
  }

  public Set<? extends XmlObject> getSetFromSession(Equipment equipment) {
    return new HashSet<XmlObject>(equipment.getAccessories());
//    return equipment.getAccessories();
  }
}