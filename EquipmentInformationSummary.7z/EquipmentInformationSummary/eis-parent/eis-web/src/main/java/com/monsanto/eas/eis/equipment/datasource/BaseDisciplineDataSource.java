/*
 BaseDisciplineDataSource was created on Nov 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.controller.XmlDataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.wst.dao.GenericDAO;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.io.IOException;
import java.util.*;

/**
 * Filename:    $RCSfile: BaseDisciplineDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-01-29 22:18:42 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public abstract class BaseDisciplineDataSource implements XmlDataSource {
  private UCCHelper helper;
  private final GenericDAO<? extends XmlObject, Long> dao;
  private final Map<String, String[]> sortKeyAliasMap;
  private PaginatedResult result = null;

  public BaseDisciplineDataSource(UCCHelper helper,
                                  GenericDAO<? extends XmlObject, Long> dao,
                                  Map<String, String[]> sortKeyAliasMap) {
    this.helper = helper;
    this.dao = dao;
    this.sortKeyAliasMap = sortKeyAliasMap;
  }

  public abstract Set<? extends XmlObject> getSetFromSession(Equipment equipment);

  public List<? extends XmlObject> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws
      IOException {
    return getDisciplineListFromDB(sortKey, sortDir, startIndex, maxResults);
  }

  private List<? extends XmlObject> getDisciplineListFromDB(String sortKey, String sortDir, int startIndex,
                                                            int maxResults) throws IOException {
    List<? extends XmlObject> list;
    String equipmentId = helper.getRequestParameterValue(EISConstants.EQUIPMENT_ID);
    if (StringUtils.isEmpty(equipmentId)) {
      list = Collections.emptyList();
      result = new PaginatedResult(0, list);
    } else {
      result = getPaginatedResult(sortKey, sortDir, startIndex, maxResults, equipmentId);
      list = result.getData();
    }
    return list;
  }

  private List<? extends XmlObject> getDisciplineListFromSession(int startIndex, int maxResults, Equipment equipment) {
    Set<? extends XmlObject> fromSession = getSetFromSession(equipment);
    int totalRecords = fromSession.size();
    int endIndex = startIndex + maxResults;
    if (fromSession.size() < endIndex) {
      endIndex = fromSession.size();
    }
    List<? extends XmlObject> list = new ArrayList<XmlObject>(fromSession);
    list = list.subList(startIndex, endIndex);
    result = new PaginatedResult(totalRecords, list);
    return list;
  }

  public int getTotalRecords() {
    if (result == null) {
      return DataSource.UNKNOWN_RECORD_COUNT;
    }
    return result.getTotalRecords();
  }

  private PaginatedResult getPaginatedResult(String sortKey, String sortDir, int startIndex, int maxResults,
                                             String equipmentId) {
    Criteria criteria = dao.createCriteria();
    criteria.createAlias("equipment", "e");
    criteria.add(Restrictions.eq("e.id", new Long(equipmentId)));
    sortKey = updateSortKey(sortKey, criteria);

    criteria.setProjection(Projections.rowCount());
    Integer totalRecords = (Integer) criteria.uniqueResult();

    if (sortDir.equalsIgnoreCase("asc")) {
      criteria.addOrder(Order.asc(sortKey));
    } else {
      criteria.addOrder(Order.desc(sortKey));
    }

    //http://forum.hibernate.org/viewtopic.php?p=2379096
//    criteria.setProjection(null);
//    criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
////    http://www.hibernate.org/117.html#A12
//    criteria.setFirstResult(startIndex);
//    if(totalRecords.intValue() <= maxResults){
//      maxResults = totalRecords.intValue();
//    }
//    criteria.setMaxResults(maxResults);
//    return new PaginatedResult(totalRecords, newList);

    criteria.setProjection(null);
    criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
//    http://www.hibernate.org/117.html#A12
    criteria.setFirstResult(startIndex);
    if (totalRecords.intValue() <= maxResults) {
      maxResults = totalRecords.intValue();
    }
    criteria.setMaxResults(maxResults);

    return new PaginatedResult(totalRecords.intValue(), criteria.list());
  }

  private String updateSortKey(String sortKey, Criteria criteria) {
    if (sortKeyAliasMap != null) {
      String[] aliasAndSortKey = sortKeyAliasMap.get(sortKey);
      if (aliasAndSortKey != null) {
        String[] aliases = aliasAndSortKey[0].split(",");
        if (aliases.length == 2) {
          String alias = getAlias(aliases[0]);
          criteria.createAlias(aliases[0], alias);
          criteria.createAlias(alias + "." + aliases[1], aliases[1], CriteriaSpecification.LEFT_JOIN);
          sortKey = aliases[1] + "." + aliasAndSortKey[1];
        } else {
          String alias = getAlias(aliasAndSortKey[0]);
          criteria.createAlias(aliasAndSortKey[0], alias, CriteriaSpecification.LEFT_JOIN);
          sortKey = alias + "." + aliasAndSortKey[1];
        }
      }
    }
    return sortKey;
  }

  private String getAlias(String str) {
    return str.substring(0, str.length() - 1);
  }
}