/*
 InstrumentDataSource was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.controller.XmlDataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Instrument;
import com.monsanto.eas.eis.projects.domain.Motor;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.util.InstrumentConstants;
import com.monsanto.eas.eis.util.PurchasingConstants;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.CriteriaSpecification;

import java.io.IOException;
import java.util.*;

/**
 * Filename:    $RCSfile: InstrumentDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $
 * On:	$Date: 2009-01-21 18:28:35 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class InstrumentDataSource extends BaseDisciplineDataSource{
  private static Map<String, String[]> sortKeyAliasMap = new LinkedHashMap<String, String[]>();

  static {
    sortKeyAliasMap.put(InstrumentConstants.DESIGNATOR_FIRST_CHAR_ID, new String[]{"designatorFirstChar", "typeCode"});
    sortKeyAliasMap.put(InstrumentConstants.DESIGNATOR_SECOND_CHAR_ID, new String[]{"designatorSecondChar", "typeCode"});
    sortKeyAliasMap.put(InstrumentConstants.IO_TYPE_ID, new String[]{"ioType", "type"});
    sortKeyAliasMap.put(PurchasingConstants.VENDOR, new String[]{"purchasing", "vendor"});
    sortKeyAliasMap.put(PurchasingConstants.RTP_NUMBER, new String[]{"purchasing", "rtpNumber"});
    sortKeyAliasMap.put(PurchasingConstants.PO_NUMBER, new String[]{"purchasing", "poNumber"});
    sortKeyAliasMap.put(PurchasingConstants.LINE_NUMBER, new String[]{"purchasing", "lineNumber"});
    sortKeyAliasMap.put(PurchasingConstants.ACTUAL_DELIVERY_DATE, new String[]{"purchasing", "actualDeliveryDate"});
  }

  public InstrumentDataSource(UCCHelper helper) {
    this(helper, new HibernateDAO<Instrument, Long>(EISHibernateUtil.getHibernateFactory(), Instrument.class));
  }

  public InstrumentDataSource(UCCHelper helper, GenericDAO<Instrument, Long> instrumentDAO) {
    super(helper, instrumentDAO, sortKeyAliasMap);
  }

  public Set<? extends XmlObject> getSetFromSession(Equipment equipment) {
    return new HashSet<XmlObject>(equipment.getInstruments());
//    return equipment.getInstruments();
  }
}