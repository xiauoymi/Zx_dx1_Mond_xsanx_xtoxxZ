/*
 MotorDataSource was created on Oct 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Motor;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.util.MotorConstants;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Filename:    $RCSfile: MotorDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $ On:	$Date:
 * 2008/10/23 16:20:48 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public class MotorDataSource extends BaseDisciplineDataSource{
  private static Map<String, String[]> sortKeyAliasMap = new HashMap<String, String[]>();

  static {
    sortKeyAliasMap.put(MotorConstants.STARTER_ID, new String[]{"starter", "starter"});
    sortKeyAliasMap.put(MotorConstants.DESIGN_STATUS_ID, new String[]{"designStatus", "status"});
    sortKeyAliasMap.put(MotorConstants.LOAD_VALUE_TYPE_ID, new String[]{"loadValueType", "type"});
    sortKeyAliasMap.put(MotorConstants.COMPONENT_DESIGNATOR_ID, new String[]{"componentDesignator", "typeCode"});
  }
  
  public MotorDataSource(UCCHelper helper) {
    this(helper, new HibernateDAO<Motor, Long>(EISHibernateUtil.getHibernateFactory(), Motor.class));
  }

  public MotorDataSource(UCCHelper helper, GenericDAO<Motor, Long> motorDao) {
    super(helper, motorDao, sortKeyAliasMap);
  }

  public Set<? extends XmlObject> getSetFromSession(Equipment equipment) {
    return equipment.getMotors();
  }
}
