/*
 AccessorySearchDataSource was created on Nov 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAO;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAOImpl;
import com.monsanto.eas.eis.projects.domain.Accessory;
import com.monsanto.eas.eis.util.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: AccessorySearchDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-11-13 16:32:50 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class AccessorySearchDataSource extends BaseDisciplineSearchDataSource {
  private static Map<String, String[]> sortKeyAliasMap = new HashMap<String, String[]>();

  static {
    sortKeyAliasMap.put(AccessoryConstants.ACCE_AUTO_MANUAL_ID, new String[]{"autoManual", "value"});
    sortKeyAliasMap.put(AccessoryConstants.ACCE_DESGINATOR_ID, new String[]{"acccessoryDesignator", "typeCode"});

    sortKeyAliasMap.put(ElectricalConstants.INPUT_ID, new String[]{"electrical,input", "input"});
    sortKeyAliasMap.put(ElectricalConstants.OUTPUT_ID, new String[]{"electrical,output", "output"});
    sortKeyAliasMap.put(ElectricalConstants.OTHER_MEASUREMENT_ID, new String[]{"electrical,otherMeasurement", "measurement"});
    sortKeyAliasMap
        .put(ElectricalConstants.PROOF_OF_POSITION_REQUIRED, new String[]{"electrical", "proofOfPositionReq"});
    sortKeyAliasMap.put(ElectricalConstants.SOLENOID_REQUIRED, new String[]{"electrical", "solenoidReq"});
    sortKeyAliasMap
        .put(ElectricalConstants.LOCAL_PUSH_BUTTON_REQUIRED, new String[]{"electrical", "localPushButtonReq"});
    sortKeyAliasMap.put(ElectricalConstants.INPUT_QUANTITY, new String[]{"electrical", "inputQty"});
    sortKeyAliasMap.put(ElectricalConstants.OUTPUT_QUANTITY, new String[]{"electrical", "outputQty"});
    sortKeyAliasMap.put(ElectricalConstants.HMI_DISPLAY, new String[]{"electrical", "hmiDisplay"});
    sortKeyAliasMap.put(ElectricalConstants.COMMUNICATIONS, new String[]{"electrical", "communications"});
    sortKeyAliasMap.put(ElectricalConstants.VOLTAGE, new String[]{"electrical", "voltage"});

    sortKeyAliasMap.put(InstrumentConstants.IO_TYPE_ID, new String[]{"ioType", "type"});
    sortKeyAliasMap.put(InstrumentConstants.INST_TYPE_ID, new String[]{"instrumentType", "type"});
    sortKeyAliasMap.put(PurchasingConstants.VENDOR, new String[]{"purchasing", "vendor"});
    sortKeyAliasMap.put(PurchasingConstants.RTP_NUMBER, new String[]{"purchasing", "rtpNumber"});
    sortKeyAliasMap.put(PurchasingConstants.PO_NUMBER, new String[]{"purchasing", "poNumber"});
    sortKeyAliasMap.put(PurchasingConstants.LINE_NUMBER, new String[]{"purchasing", "lineNumber"});
    sortKeyAliasMap.put(PurchasingConstants.ACTUAL_DELIVERY_DATE, new String[]{"purchasing", "actualDeliveryDate"});
  }

  public AccessorySearchDataSource(UCCHelper helper) {
    this(helper, new DisciplineSearchDAOImpl<Accessory, Long>(EISHibernateUtil.getHibernateFactory(), Accessory.class));
  }

  public AccessorySearchDataSource(UCCHelper helper, DisciplineSearchDAO<Accessory, Long> accessorySearchDao) {
    super(helper, accessorySearchDao, sortKeyAliasMap);
  }
}