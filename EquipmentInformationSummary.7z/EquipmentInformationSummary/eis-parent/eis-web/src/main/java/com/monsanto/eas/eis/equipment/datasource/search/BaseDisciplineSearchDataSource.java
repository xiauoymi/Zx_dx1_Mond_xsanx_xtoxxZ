/*
 EquipmentSearchDataSource was created on Oct 31, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.controller.XmlDataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAO;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EquipmentConstants;
import org.hibernate.Criteria;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Restrictions;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: BaseDisciplineSearchDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-02-13 15:36:16 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class BaseDisciplineSearchDataSource implements XmlDataSource {
  private UCCHelper helper;
  private final DisciplineSearchDAO<? extends XmlObject, Long> disciplineSearchDAO;
  private final Map<String, String[]> sortKeyAliasMap;
  protected PaginatedResult result = null;

  public BaseDisciplineSearchDataSource(UCCHelper helper,
                                        DisciplineSearchDAO<? extends XmlObject, Long> disciplineSearchDAO,
                                        Map<String, String[]> sortKeyAliasMap) {
    this.helper = helper;
    this.disciplineSearchDAO = disciplineSearchDAO;
    this.sortKeyAliasMap = sortKeyAliasMap;
  }

  public List<? extends XmlObject> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws
      IOException {
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    String equipmentTypeId = helper.getRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE);
    String areaId = helper.getRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA);
    String processLineNum = StringUtils
        .trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE));
    String equipmentNumber = StringUtils
        .trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER));
    String equipmentName = StringUtils
        .trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME));
    String vendor = StringUtils.trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_VENDOR));

    Criteria criteria = disciplineSearchDAO.createCriteria();
    sortKey = updateSortKey(sortKey, criteria);
    result = disciplineSearchDAO.findBySearchCriteria(criteria, projectId, equipmentNumber,
        equipmentName, processLineNum, equipmentTypeId, areaId, vendor, sortKey, sortDir, startIndex, maxResults);
    return result.getData();
  }

  public int getTotalRecords() {
    if (result == null) {
      return DataSource.UNKNOWN_RECORD_COUNT;
    }
    return result.getTotalRecords();
  }

  protected void addCriteriaForSearchParameters(UCCHelper helper, Criteria criteria) throws IOException {
    String equipmentTypeId = helper.getRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE);
    String areaId = helper.getRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA);
    String processLineNum = StringUtils
        .trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE));
    String equipmentNumber = StringUtils
        .trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER));
    String equipmentName = StringUtils
        .trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME));
    String vendor = StringUtils.trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_VENDOR));

    addCriteriaForEquipmentType(equipmentTypeId, criteria);
    addCriteriaForArea(areaId, criteria);
    addCriteriaForVendor(vendor, criteria);
    addLikeRestrictionsIfNotNull(criteria, "eq.equipmentNumber", equipmentNumber);
    addLikeRestrictionsIfNotNull(criteria, "eq.name", equipmentName);
    addLikeRestrictionsIfNotNull(criteria, "eq.processLineNumber", processLineNum);
  }

  protected void addLikeRestrictionsIfNotNull(Criteria criteria, String propertyName, String value) {
    value = StringUtils.trimNullable(value);
    if (!StringUtils.isNullOrEmpty(value)) {
      criteria.add(Restrictions.like(propertyName, "%" + value + "%").ignoreCase());
    }
  }

  protected void addCriteriaForEquipmentType(String equipmentTypeId, Criteria criteria) {
    if (!StringUtils.isNullOrEmpty(equipmentTypeId)) {
      criteria.createAlias("eq.equipmentType", "et");
      if (!StringUtils.isNullOrEmpty(equipmentTypeId)) {
        criteria.add(Restrictions.eq("et.id", Long.valueOf(equipmentTypeId)));
      }
    }
  }

  protected void addCriteriaForArea(String areaId, Criteria criteria) {
    if (!StringUtils.isNullOrEmpty(areaId)) {
      criteria.createAlias("eq.area", "a");
      if (!StringUtils.isNullOrEmpty(areaId)) {
        criteria.add(Restrictions.eq("a.id", Long.valueOf(areaId)));
      }
    }
  }

  protected void addCriteriaForVendor(String vendor, Criteria criteria) {
    if (!StringUtils.isNullOrEmpty(vendor)) {
      criteria.createAlias("eq.purchasing", "pu");
      if (!StringUtils.isNullOrEmpty(vendor)) {
        criteria.add(Restrictions.like("pu.vendor", "%" + vendor + "%").ignoreCase());
      }
    }
  }


  private String updateSortKey(String sortKey, Criteria criteria) {
    if (sortKeyAliasMap != null) {
      String[] aliasAndSortKey = sortKeyAliasMap.get(sortKey);
      if (aliasAndSortKey != null) {
        String[] aliases = aliasAndSortKey[0].split(",");
        if (aliases.length == 2) {
          String alias = getAlias(aliases[0]);
          criteria.createAlias(aliases[0], alias);
          criteria.createAlias(alias + "." + aliases[1], aliases[1], CriteriaSpecification.LEFT_JOIN);
          sortKey = aliases[1] + "." + aliasAndSortKey[1];
        } else {
          String alias = getAlias(aliasAndSortKey[0]);
          criteria.createAlias(aliasAndSortKey[0], alias, CriteriaSpecification.LEFT_JOIN);
          sortKey = alias + "." + aliasAndSortKey[1];
        }
      }
    }
    return sortKey;
  }

  private String getAlias(String str) {
    return str.substring(0, str.length() - 1);
  }
}