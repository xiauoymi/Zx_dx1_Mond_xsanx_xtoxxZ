/*
 EquipmentSearchDataSource was created on Oct 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAO;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAOImpl;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.util.ElectricalConstants;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: ElectricalSearchDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-02-13 15:36:15 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class ElectricalSearchDataSource extends BaseDisciplineSearchDataSource {
  private static Map<String, String[]> sortKeyAliasMap = new HashMap<String, String[]>();
  private static final String INPUT_ID = "inputId";
  private static final String INPUT_QTY = "inputQty";
  private static final String OUTPUT_ID = "outputId";
  private static final String OUTPUT_QTY = "outputQty";
  private UCCHelper helper;

  static {
    sortKeyAliasMap.put(ElectricalConstants.OTHER_MEASUREMENT_ID, new String[]{"otherMeasurement", "measurement"});
  }

  public ElectricalSearchDataSource(UCCHelper helper) {
    this(helper,
        new DisciplineSearchDAOImpl<Electrical, Long>(EISHibernateUtil.getHibernateFactory(), Electrical.class));
    this.helper = helper;
  }

  public ElectricalSearchDataSource(UCCHelper helper, DisciplineSearchDAO<Electrical, Long> disciplineSearchDAO) {
    super(helper, disciplineSearchDAO, sortKeyAliasMap);
    this.helper = helper;
  }

  public List<? extends XmlObject> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws
      IOException {
    if (needToSortByInputOrOutput(sortKey)) {
      GenericDAO<? extends ElectricalInputOutput, Long> dao = getDaoBasedOnSortKey(sortKey);
      Criteria criteria = dao.createCriteria();
      criteria.createAlias("electrical", "elec");
      criteria.createAlias("elec.equipment", "eq");
      String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
      criteria.add(Restrictions.eq("eq.projects.id", new Long(projectId)));

      addCriteriaForId(sortKey, criteria);

      addCriteriaForSearchParameters(helper, criteria);

      String orderBy = getOrderByString(sortKey);
      if (sortDir.equalsIgnoreCase("asc")) {
        criteria.addOrder(Order.asc(orderBy));
      } else {
        criteria.addOrder(Order.desc(orderBy));
      }
      criteria.setProjection(Projections.rowCount());
      Integer totalRecords = (Integer) criteria.uniqueResult();

      criteria.setProjection(null);
      criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
      criteria.setFirstResult(startIndex);
      if (totalRecords.intValue() <= maxResults) {
        maxResults = totalRecords.intValue();
      }
      criteria.setMaxResults(maxResults);

      result = new PaginatedResult(totalRecords.intValue(),
          buildElectricalList((List<ElectricalInputOutput>) criteria.list()));

      return result.getData();
    } else {
      return super.getData(sortKey, sortDir, startIndex, maxResults);
    }
  }

  private void addCriteriaForId(String sortKey, Criteria criteria) {
    if (sortKey.startsWith(INPUT_ID)) {
      criteria.add(Restrictions.eq("input.id", new Long(sortKey.substring(INPUT_ID.length(), sortKey.length()))));
    } else if (sortKey.startsWith(INPUT_QTY)) {
      criteria.add(Restrictions.eq("input.id", new Long(sortKey.substring(INPUT_QTY.length(), sortKey.length()))));
    } else if (sortKey.startsWith(OUTPUT_ID)) {
      criteria.add(Restrictions.eq("output.id", new Long(sortKey.substring(OUTPUT_ID.length(), sortKey.length()))));
    } else if (sortKey.startsWith(OUTPUT_QTY)) {
      criteria.add(Restrictions.eq("output.id", new Long(sortKey.substring(OUTPUT_QTY.length(), sortKey.length()))));
    }
  }

  private String getOrderByString(String sortKey) {
    if (sortKey.startsWith(INPUT_ID) || sortKey.startsWith(OUTPUT_ID)) {
      return "checked";
    } else if (sortKey.startsWith(INPUT_QTY)) {
      return "inputQty";
    } else {
      return "outputQty";
    }
  }

  private GenericDAO<? extends ElectricalInputOutput, Long> getDaoBasedOnSortKey(String sortKey) {
    if (sortKey.startsWith(INPUT_ID) || sortKey.startsWith(INPUT_QTY)) {
      return getElectricalInputQuantityDao();
    } else //(sortKey.startsWith(OUTPUT_ID) || sortKey.startsWith(OUTPUT_QTY)))
      return getElectricalOutputQuantityDao();

  }

  //protected for testing only
  protected GenericDAO<ElectricalOutputQuantity, Long> getElectricalOutputQuantityDao() {
    return new HibernateDAO<ElectricalOutputQuantity, Long>(
        EISHibernateUtil.getHibernateFactory(), ElectricalOutputQuantity.class);
  }

  //protected for testing only
  protected GenericDAO<ElectricalInputQuantity, Long> getElectricalInputQuantityDao() {
    return new HibernateDAO<ElectricalInputQuantity, Long>(
        EISHibernateUtil.getHibernateFactory(), ElectricalInputQuantity.class);
  }

  private boolean needToSortByInputOrOutput(String sortKey) {
    return sortKey.startsWith(INPUT_ID) || sortKey.startsWith(INPUT_QTY) ||
        sortKey.startsWith(OUTPUT_ID) || sortKey.startsWith(OUTPUT_QTY);
  }

  private List<? extends XmlObject> buildElectricalList(List<ElectricalInputOutput> electricalInputQuantities) {
    List<Electrical> list = new ArrayList<Electrical>();
    for (ElectricalInputOutput iq : electricalInputQuantities) {
      list.add(iq.getElectrical());
    }
    return list;
  }
}