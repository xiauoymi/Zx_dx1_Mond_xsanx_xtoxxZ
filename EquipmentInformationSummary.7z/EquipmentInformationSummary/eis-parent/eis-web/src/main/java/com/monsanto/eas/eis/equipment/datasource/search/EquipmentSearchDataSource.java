/*
 EquipmentDataSource was created on Oct 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.controller.XmlDataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.dao.EquipmentDAO;
import com.monsanto.eas.eis.projects.dao.EquipmentDAOImpl;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EquipmentConstants;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: EquipmentSearchDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $
 * On:	$Date: 2008-12-27 05:11:36 $
 *
 * @author SSPATI1
 * @version $Revision: 1.3 $
 */
public class EquipmentSearchDataSource implements XmlDataSource {
  private final UCCHelper helper;
  private final EquipmentDAO equipmentDAO;
  private PaginatedResult result = null;

  public EquipmentSearchDataSource(UCCHelper helper) {
    this(helper, new EquipmentDAOImpl());
  }

  public EquipmentSearchDataSource(UCCHelper helper, EquipmentDAO equipmentDAO) {
    this.helper = helper;
    this.equipmentDAO = equipmentDAO;
  }

  public List<? extends XmlObject> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws
      IOException {
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    String equipmentTypeId = helper.getRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE);
    String areaId = helper.getRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA);
    String processLineNum = StringUtils
        .trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE));
    String equipmentNumber = StringUtils
        .trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER));
    String equipmentName = StringUtils
        .trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME));
    String vendor = StringUtils.trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_VENDOR));
    String existingEquipmentNumber = StringUtils.trimNullable(helper.getRequestParameterValue(EquipmentConstants.SEARCH_EXISTING_EQUIPMENT_NUMBER));

    result = equipmentDAO.findBySearchCriteria(projectId, equipmentNumber,
        equipmentName, processLineNum, equipmentTypeId, areaId, vendor, existingEquipmentNumber, sortKey, sortDir, startIndex, maxResults);
    return result.getData();
  }

  public int getTotalRecords() {
    if (result == null) {
      return DataSource.UNKNOWN_RECORD_COUNT;
    }
    return result.getTotalRecords();
  }
}