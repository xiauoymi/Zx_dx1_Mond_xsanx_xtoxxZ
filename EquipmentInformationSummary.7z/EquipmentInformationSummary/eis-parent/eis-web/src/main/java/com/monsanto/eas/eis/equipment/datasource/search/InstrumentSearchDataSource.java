/*
 InstrumentSearchDataSource was created on Nov 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAO;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAOImpl;
import com.monsanto.eas.eis.projects.domain.Instrument;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.util.InstrumentConstants;
import com.monsanto.eas.eis.util.PurchasingConstants;
import com.monsanto.eas.eis.equipment.datasource.search.BaseDisciplineSearchDataSource;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: InstrumentSearchDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-11-12 23:32:11 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class InstrumentSearchDataSource extends BaseDisciplineSearchDataSource {
  private static Map<String, String[]> sortKeyAliasMap = new HashMap<String, String[]>();

  static {
    sortKeyAliasMap.put(InstrumentConstants.IO_TYPE_ID, new String[]{"ioType", "type"});
    sortKeyAliasMap.put(InstrumentConstants.INST_TYPE_ID, new String[]{"instrumentType", "type"});
    sortKeyAliasMap.put(PurchasingConstants.VENDOR, new String[]{"purchasing", "vendor"});
    sortKeyAliasMap.put(PurchasingConstants.RTP_NUMBER, new String[]{"purchasing", "rtpNumber"});
    sortKeyAliasMap.put(PurchasingConstants.PO_NUMBER, new String[]{"purchasing", "poNumber"});
    sortKeyAliasMap.put(PurchasingConstants.LINE_NUMBER, new String[]{"purchasing", "lineNumber"});
    sortKeyAliasMap.put(PurchasingConstants.ACTUAL_DELIVERY_DATE, new String[]{"purchasing", "actualDeliveryDate"});
  }

  public InstrumentSearchDataSource(UCCHelper helper) {
    this(helper,
        new DisciplineSearchDAOImpl<Instrument, Long>(EISHibernateUtil.getHibernateFactory(), Instrument.class));
  }

  public InstrumentSearchDataSource(UCCHelper helper, DisciplineSearchDAO<Instrument, Long> instrumentSearchDso) {
    super(helper, instrumentSearchDso, sortKeyAliasMap);
  }
}