/*
 MechanicalSearchDataSource was created on Oct 31, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAO;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAOImpl;
import com.monsanto.eas.eis.projects.domain.Mechanical;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.equipment.datasource.search.BaseDisciplineSearchDataSource;

/**
 * Filename:    $RCSfile: MechanicalSearchDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2008-11-12 23:32:11 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class MechanicalSearchDataSource extends BaseDisciplineSearchDataSource {

  public MechanicalSearchDataSource(UCCHelper helper) {
    this(helper,
        new DisciplineSearchDAOImpl<Mechanical, Long>(EISHibernateUtil.getHibernateFactory(), Mechanical.class));
  }

  public MechanicalSearchDataSource(UCCHelper helper, DisciplineSearchDAO<Mechanical, Long> disciplineSearchDAO) {
    super(helper, disciplineSearchDAO, null);
  }

}