/*
 ProcessSearchDataSource was created on Nov 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAO;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAOImpl;
import com.monsanto.eas.eis.projects.domain.FieldEquipmentType;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.Process;
import com.monsanto.eas.eis.projects.domain.ProcessFieldEquipmentType;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.util.EquipmentConstants;
import com.monsanto.eas.eis.util.ProcessConstants;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: ProcessSearchDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-02-13 15:36:16 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class ProcessSearchDataSource extends BaseDisciplineSearchDataSource {
  private static Map<String, String[]> sortKeyAliasMap = new HashMap<String, String[]>();
  private UCCHelper helper;

  static {
    sortKeyAliasMap.put(ProcessConstants.GAS_TYPE_ID, new String[]{"gasType", "type"});
    sortKeyAliasMap.put(ProcessConstants.WATER_TYPE_ID, new String[]{"waterType", "type"});
    sortKeyAliasMap.put(ProcessConstants.DUST_TYPE_ID, new String[]{"dustType", "type"});
    sortKeyAliasMap.put(ProcessConstants.DESIGN_CAPACITY_UNIT_ID, new String[]{"designCapacityUnit", "unitName"});
  }

  public ProcessSearchDataSource(UCCHelper helper) {
    this(helper,
        new DisciplineSearchDAOImpl<com.monsanto.eas.eis.projects.domain.Process, Long>(
            EISHibernateUtil.getHibernateFactory(), com.monsanto.eas.eis.projects.domain.Process.class));
    this.helper = helper;
  }

  public ProcessSearchDataSource(UCCHelper helper,
                                 DisciplineSearchDAO<com.monsanto.eas.eis.projects.domain.Process, Long> disciplineSearchDAO) {
    super(helper, disciplineSearchDAO, sortKeyAliasMap);
    this.helper = helper;
  }

  public List<? extends XmlObject> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws
      IOException {

    FieldEquipmentType fet = lookupFieldEquipmentTypeByName(sortKey);
    if (fet == null) {//not a dynamic field
      return super.getData(sortKey, sortDir, startIndex, maxResults);
    } else {
      String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);

      GenericDAO<ProcessFieldEquipmentType, Long> pfeDao = getProcessFieldEquipmentTypeDao();
      Criteria criteria = pfeDao.createCriteria();
      criteria.createAlias("process", "pr");
      criteria.createAlias("pr.equipment", "eq");
      criteria.add(Restrictions.eq("eq.projects.id", new Long(projectId)));
      criteria.createAlias("fieldEquipmentType", "ft");
      criteria.add(Restrictions.eq("ft.name", sortKey));

      addCriteriaForSearchParameters(helper, criteria);

      if (sortDir.equalsIgnoreCase("asc")) {
        criteria.addOrder(Order.asc("value"));
      } else {
        criteria.addOrder(Order.desc("value"));
      }
      criteria.setProjection(Projections.rowCount());
      Integer totalRecords = (Integer) criteria.uniqueResult();

      criteria.setProjection(null);
      criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
      criteria.setFirstResult(startIndex);
      if (totalRecords.intValue() <= maxResults) {
        maxResults = totalRecords.intValue();
      }
      criteria.setMaxResults(maxResults);

      result = new PaginatedResult(totalRecords.intValue(),
          buildProcessList((List<ProcessFieldEquipmentType>) criteria.list()));

      return result.getData();
    }
  }

  private FieldEquipmentType lookupFieldEquipmentTypeByName(String sortKey) {
    GenericDAO<FieldEquipmentType, Long> ftDao = getFieldEquipmentTypeDao();
    Criteria criteria = ftDao.createCriteria();
    criteria.add(Restrictions.eq("name", sortKey));
    return (FieldEquipmentType) criteria.uniqueResult();
  }

  //protected for testing
  protected GenericDAO<ProcessFieldEquipmentType, Long> getProcessFieldEquipmentTypeDao() {
    return new HibernateDAO<ProcessFieldEquipmentType, Long>(
        EISHibernateUtil.getHibernateFactory(), ProcessFieldEquipmentType.class);
  }

  //protected for testing 
  protected GenericDAO<FieldEquipmentType, Long> getFieldEquipmentTypeDao() {
    return new HibernateDAO<FieldEquipmentType, Long>(
        EISHibernateUtil.getHibernateFactory(), FieldEquipmentType.class);
  }

  private List<com.monsanto.eas.eis.projects.domain.Process> buildProcessList(List<ProcessFieldEquipmentType> list) {
    List<com.monsanto.eas.eis.projects.domain.Process> processes = new ArrayList<Process>();
    for (ProcessFieldEquipmentType pfe : list) {
      processes.add(pfe.getProcess());
    }
    return processes;
  }
}