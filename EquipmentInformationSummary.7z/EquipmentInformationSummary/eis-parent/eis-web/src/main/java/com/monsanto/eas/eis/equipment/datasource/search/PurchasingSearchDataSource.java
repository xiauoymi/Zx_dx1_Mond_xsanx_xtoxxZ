/*
 PurchasingSearchDataSource was created on Dec 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAO;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAOImpl;
import com.monsanto.eas.eis.projects.domain.Purchasing;
import com.monsanto.eas.eis.util.EISHibernateUtil;

/**
 * Filename:    $RCSfile: PurchasingSearchDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-05 16:40:27 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class PurchasingSearchDataSource extends BaseDisciplineSearchDataSource {
  public PurchasingSearchDataSource(UCCHelper helper) {
    this(helper,
        new DisciplineSearchDAOImpl<Purchasing, Long>(EISHibernateUtil.getHibernateFactory(), Purchasing.class));
  }

  public PurchasingSearchDataSource(UCCHelper helper, DisciplineSearchDAO<Purchasing, Long> disciplineSearchDAO) {
    super(helper, disciplineSearchDAO, null);
  }
}