/*
 AccessoryService was created on Nov 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.domain.AccessoryDesignator;
import com.monsanto.eas.eis.projects.domain.AutoManual;

import java.util.List;

/**
 * Filename:    $RCSfile: AccessoryService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-11-05 16:55:41 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public interface AccessoryService {
  List<AccessoryDesignator> lookupAllAccessoryDesignators();

  List<AutoManual> lookupAllAutoManuals();
}