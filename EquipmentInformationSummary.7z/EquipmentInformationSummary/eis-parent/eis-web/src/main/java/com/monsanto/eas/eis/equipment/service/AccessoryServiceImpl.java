/*
 AccessoryServiceImpl was created on Nov 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.domain.AccessoryDesignator;
import com.monsanto.eas.eis.projects.domain.AutoManual;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;

import java.util.List;

/**
 * Filename:    $RCSfile: AccessoryServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-11-13 16:32:50 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class AccessoryServiceImpl implements AccessoryService {
  private GenericDAO<AccessoryDesignator, Long> designatorDao;
  private GenericDAO<AutoManual, Long> autoManualDao;

  public AccessoryServiceImpl() {
    this(new HibernateDAO<AccessoryDesignator, Long>(EISHibernateUtil.getHibernateFactory(), AccessoryDesignator.class),
        new HibernateDAO<AutoManual, Long>(EISHibernateUtil.getHibernateFactory(), AutoManual.class));
  }

  public AccessoryServiceImpl(GenericDAO<AccessoryDesignator, Long> designatorDao,
                              GenericDAO<AutoManual, Long> autoManualId) {
    this.designatorDao = designatorDao;
    this.autoManualDao = autoManualId;
  }

  public List<AccessoryDesignator> lookupAllAccessoryDesignators() {
    return this.designatorDao.findAll("typeCode", true);
  }

  public List<AutoManual> lookupAllAutoManuals() {
    return this.autoManualDao.findAll("value", true);
  }
}