package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.domain.*;

import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 23, 2008 Time: 3:45:59 PM To change this template use File |
 * Settings | File Templates.
 */
public interface ElectricalService {
  List<ElectricalInput> lookupAllInputs();

  List<ElectricalOutput> lookupAllOutputs();

  List<OtherMeasurement> lookupAllOtherMeasurements();

  ElectricalInput lookupElectricalInput(Long id);

  ElectricalOutput lookupElectricalOutput(Long id);

  OtherMeasurement lookupOtherMeasurement(Long id);

  Electrical lookupElectrical(Long id);

  ElectricalInputQuantity lookupInputQuantityByInputForElectrical(Long inputId, Long electricalId);

  ElectricalOutputQuantity lookupInputQuantityByOutputForElectrical(Long outputId, Long electricalId);
}
