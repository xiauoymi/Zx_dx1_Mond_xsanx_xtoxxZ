package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 23, 2008 Time: 3:46:32 PM To change this template use File |
 * Settings | File Templates.
 */
public class ElectricalServiceImpl implements ElectricalService {
  private GenericDAO<ElectricalInput, Long> inputDao;
  private GenericDAO<ElectricalOutput, Long> outputDao;
  private GenericDAO<OtherMeasurement, Long> otherMeasurementDao;
  private GenericDAO<Electrical, Long> electricalDao;
  private GenericDAO<ElectricalInputQuantity, Long> inputQuantityDao;
  private GenericDAO<ElectricalOutputQuantity, Long> outputQuantityDao;


  public ElectricalServiceImpl() {
    this(new HibernateDAO<ElectricalInput, Long>(EISHibernateUtil.getHibernateFactory(), ElectricalInput.class),
        new HibernateDAO<ElectricalOutput, Long>(EISHibernateUtil.getHibernateFactory(), ElectricalOutput.class),
        new HibernateDAO<OtherMeasurement, Long>(EISHibernateUtil.getHibernateFactory(), OtherMeasurement.class),
        new HibernateDAO<Electrical, Long>(EISHibernateUtil.getHibernateFactory(), Electrical.class),
        new HibernateDAO<ElectricalInputQuantity, Long>(EISHibernateUtil.getHibernateFactory(),
            ElectricalInputQuantity.class),
        new HibernateDAO<ElectricalOutputQuantity, Long>(EISHibernateUtil.getHibernateFactory(),
            ElectricalOutputQuantity.class));
  }

  public ElectricalServiceImpl(GenericDAO<ElectricalInput, Long> inputDao,
                               GenericDAO<ElectricalOutput, Long> outputDao,
                               GenericDAO<OtherMeasurement, Long> otherMeasurementDao,
                               GenericDAO<Electrical, Long> electricalDao,
                               GenericDAO<ElectricalInputQuantity, Long> inputQuantityDao,
                               GenericDAO<ElectricalOutputQuantity, Long> outputQuantityDao) {
    this.inputDao = inputDao;
    this.outputDao = outputDao;
    this.otherMeasurementDao = otherMeasurementDao;
    this.electricalDao = electricalDao;
    this.inputQuantityDao = inputQuantityDao;
    this.outputQuantityDao = outputQuantityDao;
  }

  public List<ElectricalInput> lookupAllInputs() {
    return this.inputDao.findAll("input", true);
  }

  public List<ElectricalOutput> lookupAllOutputs() {
    return this.outputDao.findAll("output", true);
  }

  public List<OtherMeasurement> lookupAllOtherMeasurements() {
    return this.otherMeasurementDao.findAll("measurement", true);
  }

  public ElectricalInput lookupElectricalInput(Long id) {
    return this.inputDao.findByPrimaryKey(id);
  }

  public ElectricalOutput lookupElectricalOutput(Long id) {
    return this.outputDao.findByPrimaryKey(id);
  }

  public OtherMeasurement lookupOtherMeasurement(Long id) {
    return this.otherMeasurementDao.findByPrimaryKey(id);
  }

  public ElectricalInputQuantity lookupInputQuantityByInputForElectrical(Long inputId, Long electricalId) {
    Criteria criteria = this.inputQuantityDao.createCriteria();
    criteria.add(Restrictions.eq("input.id", inputId));
    criteria.add(Restrictions.eq("electrical.id", electricalId));
    return (ElectricalInputQuantity) criteria.uniqueResult();
  }

  public ElectricalOutputQuantity lookupInputQuantityByOutputForElectrical(Long outputId, Long electricalId) {
    Criteria criteria = this.outputQuantityDao.createCriteria();
    criteria.add(Restrictions.eq("output.id", outputId));
    criteria.add(Restrictions.eq("electrical.id", electricalId));
    return (ElectricalOutputQuantity) criteria.uniqueResult();
  }

  public Electrical lookupElectrical(Long id) {
    Criteria criteria = electricalDao.createCriteria();
    criteria.add(Restrictions.eq("id", id));
    criteria.setFetchMode("inputQuantity", FetchMode.JOIN);
    criteria.setFetchMode("outputQuantity", FetchMode.JOIN);
    return (Electrical) criteria.uniqueResult();
  }
}
