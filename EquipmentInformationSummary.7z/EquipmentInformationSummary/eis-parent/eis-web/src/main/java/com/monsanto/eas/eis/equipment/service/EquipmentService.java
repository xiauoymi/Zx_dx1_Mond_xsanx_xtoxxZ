package com.monsanto.eas.eis.equipment.service;


import org.w3c.dom.Document;

import java.util.Map;
import java.util.List;
import java.io.IOException;

import com.monsanto.eas.eis.projects.domain.*;

/**
 * Created by IntelliJ IDEA.
 * User: vvvelu
 * Date: Sep 2, 2008
 * Time: 3:17:34 PM
 * To change this template use File | Settings | File Templates.
 */
public interface EquipmentService {

  public Equipment saveEquipment(Equipment equipment);

  Document lookupEquipmentSubTypes(Long equipmentTypeId) throws IOException;

  Equipment lookupEquipment(Long equipmentId);

  List<Area> lookupAllAreas();

  List<EquipmentType> lookupAllParentEquipmentTypes();

  void deleteEquipment(String equipmentId);

  Area lookupAreaById(Long areaId);

  PaginatedResult findBySearchCriteria(String projectId, String equipmentNumber, String equipmentName,
                                       String processLineNum, String equipmentTypeId,
                                       String areaId, String vendor,
                                       String existingEquipmentNumber, String sortKey, String sortDir, int startIndex,
                                       int maxResults);
}
