package com.monsanto.eas.eis.equipment.service;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.eas.eis.projects.EISDAOFactory;
import com.monsanto.eas.eis.projects.EISDAOFactoryImpl;
import com.monsanto.eas.eis.projects.domain.Area;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.EquipmentType;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.Collections;
import java.util.List;


/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Sep 2, 2008 Time: 3:17:52 PM To change this template use File | Settings
 * | File Templates.
 */
public class EquipmentServiceImpl implements EquipmentService {
  private EISDAOFactory daoFactory;

  public EquipmentServiceImpl() {
    this(new EISDAOFactoryImpl());
  }

  public EquipmentServiceImpl(EISDAOFactory daoFactory) {
    this.daoFactory = daoFactory;
  }

  public Equipment saveEquipment(Equipment equipment) {
    equipment = mergeEquipmentWithDB(equipment);
    daoFactory.getEquipmentDAOImpl().save(equipment);
    return equipment;
  }

  public Document lookupEquipmentSubTypes(Long equipmentTypeId) throws IOException {
    EquipmentType equipmentType = daoFactory.getEquipmentTypeDAOImpl().findByPrimaryKey(equipmentTypeId);
    List<EquipmentType> list = equipmentType.getSubEquipmentTypes();
    Collections.sort(list);
    StringBuffer xmlStr = new StringBuffer("<types>");
    for (EquipmentType et : list) {
      xmlStr.append("<type>");
      xmlStr.append("<id>").append(et.getId()).append("</id>");
      xmlStr.append("<description>").append(et.getName()).append("</description>");
      xmlStr.append("</type>");
    }
    xmlStr.append("</types>");
    try {
      return DOMUtil.stringToXML(xmlStr.toString());
    } catch (ParserException e) {
      throw new RuntimeException("XML Exception", e);
    }
  }

  public void deleteEquipment(String equipmentId) {
    Equipment equipment = daoFactory.getEquipmentDAOImpl().findByPrimaryKey(Long.valueOf(equipmentId));
    daoFactory.getEquipmentDAOImpl().delete(equipment);
  }

  public Equipment lookupEquipment(Long equipmentId) {
    return daoFactory.getEquipmentDAOImpl().findByPrimaryKey(equipmentId);
  }

  public List<Area> lookupAllAreas() {
    return daoFactory.getAreaDAOImpl().findAll();
  }

  public List<EquipmentType> lookupAllParentEquipmentTypes() {
    Criteria criteria = daoFactory.getEquipmentTypeDAOImpl().createCriteria();
    criteria.add(Restrictions.isNull("parentEquipmentType"));
    criteria.addOrder(Order.asc("typeCode").ignoreCase());
    return criteria.list();
  }

  public Area lookupAreaById(Long areaId) {
    return daoFactory.getAreaDAOImpl().findByPrimaryKey(areaId);
  }

  //protected for testing
  protected Equipment mergeEquipmentWithDB(Equipment equipment) {
    //have to merge coz equipment from httpsession might be detached and so merge will load it in
    // hibernate session and update it instead of treating it was a new equipment and inserting a new one
    return (Equipment) EISHibernateUtil.getHibernateFactory().getSession().merge(equipment);
  }

  public PaginatedResult findBySearchCriteria(String projectId, String equipmentNumber, String equipmentName,
                                              String processLineNum, String equipmentTypeId, String areaId,
                                              String vendor, String existingEquipmentNumber, String sortKey,
                                              String sortDir, int startIndex,
                                              int maxResults) {
    return daoFactory.getEquipmentDAOImpl().findBySearchCriteria(projectId, equipmentNumber, equipmentName, processLineNum,
        equipmentTypeId, areaId, vendor, existingEquipmentNumber, sortKey, sortDir, startIndex, maxResults);
  }
}
