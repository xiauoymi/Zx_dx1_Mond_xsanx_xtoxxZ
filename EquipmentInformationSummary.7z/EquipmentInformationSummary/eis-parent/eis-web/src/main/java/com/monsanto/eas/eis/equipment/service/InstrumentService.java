/*
 InstrumentService was created on Oct 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.domain.InstrumentDesignator;
import com.monsanto.eas.eis.projects.domain.IOType;
import com.monsanto.eas.eis.projects.domain.InstrumentType;

import java.util.List;

/**
 * Filename:    $RCSfile: InstrumentService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2009-01-21 18:28:35 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public interface InstrumentService {
  List<InstrumentDesignator> lookupAllInstrumentDesignatorsForFirstChar();

  List<InstrumentDesignator> lookupAllInstrumentDesignatorsForSecondChar();

  List<IOType> lookupAllIOTypes();

}