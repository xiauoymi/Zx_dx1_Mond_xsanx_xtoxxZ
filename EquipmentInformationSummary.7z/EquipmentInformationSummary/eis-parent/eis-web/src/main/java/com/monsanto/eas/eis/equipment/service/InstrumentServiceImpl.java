/*
 InstrumentServiceImpl was created on Oct 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.domain.IOType;
import com.monsanto.eas.eis.projects.domain.InstrumentDesignator;
import com.monsanto.eas.eis.projects.domain.InstrumentType;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: InstrumentServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $
 * On:	$Date: 2009-01-21 18:28:35 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class InstrumentServiceImpl implements InstrumentService {
  private GenericDAO<InstrumentDesignator, Long> designatorDao;
  private GenericDAO<IOType, Long> ioTypeDao;

  public InstrumentServiceImpl() {
    this(new HibernateDAO<InstrumentDesignator, Long>(EISHibernateUtil.getHibernateFactory(),
        InstrumentDesignator.class),
        new HibernateDAO<IOType, Long>(EISHibernateUtil.getHibernateFactory(), IOType.class)
    );
  }

  public InstrumentServiceImpl(GenericDAO<InstrumentDesignator, Long> designatorDao,
                               GenericDAO<IOType, Long> ioTypeDao) {
    this.designatorDao = designatorDao;
    this.ioTypeDao = ioTypeDao;
  }

  public List<InstrumentDesignator> lookupAllInstrumentDesignatorsForFirstChar() {
    Criteria criteria = designatorDao.createCriteria();
    criteria.add(Restrictions.eq("charNum", 1));
    criteria.addOrder(Order.asc("typeCode"));
    return criteria.list();
  }

  public List<InstrumentDesignator> lookupAllInstrumentDesignatorsForSecondChar() {
    Criteria criteria = designatorDao.createCriteria();
    criteria.add(Restrictions.eq("charNum", 2));
    criteria.addOrder(Order.asc("typeCode"));
    return criteria.list();
  }

  public List<IOType> lookupAllIOTypes() {
    return ioTypeDao.findAll("type", true);
  }

}