package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.domain.PurchaseScope;

import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Dec 8, 2008 Time: 5:11:09 PM To change this template use File | Settings
 * | File Templates.
 */
public interface MechanicalService {

  List<PurchaseScope> lookupAllPurchaseScopes();

  PurchaseScope lookupPurchaseScopeById(Long id);
}
