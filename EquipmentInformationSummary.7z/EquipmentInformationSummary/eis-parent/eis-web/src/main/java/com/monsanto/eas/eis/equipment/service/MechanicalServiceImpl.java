package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.domain.PurchaseScope;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;

import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Dec 8, 2008 Time: 5:11:35 PM To change this template use File | Settings
 * | File Templates.
 */
public class MechanicalServiceImpl implements MechanicalService {

  private GenericDAO<PurchaseScope, Long> purchaseScopeDao;


  public MechanicalServiceImpl() {
    this(new HibernateDAO<PurchaseScope, Long>(EISHibernateUtil.getHibernateFactory(), PurchaseScope.class));
  }
  
  public MechanicalServiceImpl(GenericDAO<PurchaseScope, Long> purchaseScopeDao) {
    this.purchaseScopeDao = purchaseScopeDao;
  }

  public List<PurchaseScope> lookupAllPurchaseScopes() {
    return purchaseScopeDao.findAll("purchaseScopeName", true);
  }

  public PurchaseScope lookupPurchaseScopeById(Long id) {
    return this.purchaseScopeDao.findByPrimaryKey(id);
  }
}
