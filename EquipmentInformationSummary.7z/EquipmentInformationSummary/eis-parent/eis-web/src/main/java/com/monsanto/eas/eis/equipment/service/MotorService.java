/*
 MotorService was created on Oct 20, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.domain.MotorDesignStatus;
import com.monsanto.eas.eis.projects.domain.MotorLoadValueType;
import com.monsanto.eas.eis.projects.domain.ComponentDesignator;

import java.util.List;

/**
 * Filename:    $RCSfile: MotorService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vvvelu $    	 On:	$Date: 2008-12-09 01:38:54 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public interface MotorService {
  List<MotorDesignStatus> lookupAllDesignStatus();

  List<MotorLoadValueType> lookupAllLoadValyeTypes();

  List<ComponentDesignator> lookupAllComponentDesignators();
}