/*
 MotorServiceImpl was created on Oct 20, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.eas.eis.projects.domain.MotorDesignStatus;
import com.monsanto.eas.eis.projects.domain.MotorLoadValueType;
import com.monsanto.eas.eis.projects.domain.ComponentDesignator;
import com.monsanto.eas.eis.util.EISHibernateUtil;

import java.util.List;

/**
 * Filename:    $RCSfile: MotorServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-01-20 22:41:39 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class MotorServiceImpl implements MotorService {
  private GenericDAO<MotorDesignStatus, Long> designStatusDao;
  private GenericDAO<MotorLoadValueType, Long> loadValueTypeDao;
  private GenericDAO<ComponentDesignator, Long> compDesignatorDao;

  public MotorServiceImpl() {
    this(new HibernateDAO<MotorDesignStatus, Long>(EISHibernateUtil.getHibernateFactory(), MotorDesignStatus.class),
    new HibernateDAO<MotorLoadValueType, Long>(EISHibernateUtil.getHibernateFactory(), MotorLoadValueType.class),
    new HibernateDAO<ComponentDesignator, Long>(EISHibernateUtil.getHibernateFactory(), ComponentDesignator.class));
  }

  public MotorServiceImpl(GenericDAO<MotorDesignStatus, Long> designStatusDao,
                          GenericDAO<MotorLoadValueType, Long> loadValueTypeDao,
                          GenericDAO<ComponentDesignator, Long> compDesignatorDao) {
    this.designStatusDao = designStatusDao;
    this.loadValueTypeDao = loadValueTypeDao;
    this.compDesignatorDao = compDesignatorDao;
  }


  public List<MotorDesignStatus> lookupAllDesignStatus() {
    return this.designStatusDao.findAll("status", false);
  }

  public List<MotorLoadValueType> lookupAllLoadValyeTypes() {
    return this.loadValueTypeDao.findAll("type", true);
  }

  public List<ComponentDesignator> lookupAllComponentDesignators() {
    return this.compDesignatorDao.findAll("value", true);
  }
}