/*
 ProcessService was created on Sep 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.domain.*;

import java.util.List;

/**
 * Filename:    $RCSfile: ProcessService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-01-23 14:43:36 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public interface ProcessService {
  List<GasType> lookupAllGasTypes();

  List<WaterType> lookupAllWaterTypes();

  List<DustType> lookupAllDustTypes();

  List<FieldEquipmentType> lookupAllFieldEquipmentTypes(Long equipmentTypeId);

  GasType lookupGasTypeById(Long id);

  WaterType lookupWaterTypeById(Long id);

  DustType lookupDustTypeById(Long id);

  DesignCapacityUnit lookupDesignCapacityUnitById(Long id);

  List<DesignCapacityUnit> lookupDesignCapacityUnitsByEquipmentTypeAndUnitMeasure(Long equipmentTypeId,
                                                                                  Long unitMeasureId);

  UnitMeasure lookupUnitMeasureById(Long id);

  ProcessFieldEquipmentType lookupProcessFieldEquipmentTypeByFieldName(Long processId, String fieldName);
}