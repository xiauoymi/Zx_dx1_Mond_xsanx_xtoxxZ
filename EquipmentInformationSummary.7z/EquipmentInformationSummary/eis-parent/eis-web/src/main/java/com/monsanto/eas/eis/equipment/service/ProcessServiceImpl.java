/*
 ProcessServiceImpl was created on Sep 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: ProcessServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $ On:	$Date:
 * 2008/10/07 20:34:00 $
 *
 * @author sspati1
 * @version $Revision: 1.11 $
 */
public class ProcessServiceImpl implements ProcessService {
  private GenericDAO<GasType, Long> gasTypeDao;
  private GenericDAO<WaterType, Long> waterTypeDao;
  private GenericDAO<DustType, Long> dustTypeDao;
  private GenericDAO<FieldEquipmentType, Long> feTypeDao;
  private GenericDAO<DesignCapacityUnit, Long> designCapacityUnitDao;
  private GenericDAO<EquipmentType, Long> equipmentTypeDao;
  private GenericDAO<UnitMeasure, Long> unitMeasureDao;
  private GenericDAO<ProcessFieldEquipmentType, Long> pfeDao;

  public ProcessServiceImpl() {
    this(new HibernateDAO<GasType, Long>(EISHibernateUtil.getHibernateFactory(), GasType.class),
        new HibernateDAO<WaterType, Long>(EISHibernateUtil.getHibernateFactory(), WaterType.class),
        new HibernateDAO<DustType, Long>(EISHibernateUtil.getHibernateFactory(), DustType.class),
        new HibernateDAO<FieldEquipmentType, Long>(EISHibernateUtil.getHibernateFactory(), FieldEquipmentType.class),
        new HibernateDAO<DesignCapacityUnit, Long>(EISHibernateUtil.getHibernateFactory(), DesignCapacityUnit.class),
        new HibernateDAO<EquipmentType, Long>(EISHibernateUtil.getHibernateFactory(), EquipmentType.class),
        new HibernateDAO<UnitMeasure, Long>(EISHibernateUtil.getHibernateFactory(), UnitMeasure.class),
        new HibernateDAO<ProcessFieldEquipmentType, Long>(EISHibernateUtil.getHibernateFactory(), ProcessFieldEquipmentType.class));
  }

  public ProcessServiceImpl(GenericDAO<GasType, Long> gasTypeDao, GenericDAO<WaterType, Long> waterTypeDao,
                            GenericDAO<DustType, Long> dustTypeDao, GenericDAO<FieldEquipmentType, Long> feTypeDao,
                            GenericDAO<DesignCapacityUnit, Long> designCapacityUnitDao,
                            GenericDAO<EquipmentType, Long> equipmentTypeDao,
                            GenericDAO<UnitMeasure, Long> unitMeasureDao,
                            GenericDAO<ProcessFieldEquipmentType, Long> pfeDao) {
    this.gasTypeDao = gasTypeDao;
    this.waterTypeDao = waterTypeDao;
    this.dustTypeDao = dustTypeDao;
    this.feTypeDao = feTypeDao;
    this.designCapacityUnitDao = designCapacityUnitDao;
    this.equipmentTypeDao = equipmentTypeDao;
    this.unitMeasureDao = unitMeasureDao;
    this.pfeDao = pfeDao;
  }

  public List<GasType> lookupAllGasTypes() {
    return gasTypeDao.findAll("type", true);
  }

  public GasType lookupGasTypeById(Long id) {
    return gasTypeDao.findByPrimaryKey(id);
  }

  public List<WaterType> lookupAllWaterTypes() {
    return waterTypeDao.findAll("type", true);
  }

  public List<DesignCapacityUnit> lookupDesignCapacityUnitsByEquipmentTypeAndUnitMeasure(Long equipmentTypeId,
                                                                                         Long unitMeasureId) {
    List<DesignCapacityUnit> list = new ArrayList<DesignCapacityUnit>();
    if (equipmentTypeId != null && unitMeasureId != null) {
      UnitMeasure unitMeasure = unitMeasureDao.findByPrimaryKey(unitMeasureId);
      EquipmentType equipmentType = equipmentTypeDao.findByPrimaryKey(equipmentTypeId);
      List<DesignCapacityUnit> designCapacityUnits = equipmentType.getDesignCapacityUnits();
      for (DesignCapacityUnit dcu : designCapacityUnits) {
        if (dcu.getUnitMeasure().equals(unitMeasure)) {
          list.add(dcu);
        }
      }
    }
    return list;
  }

  public WaterType lookupWaterTypeById(Long id) {
    return waterTypeDao.findByPrimaryKey(id);
  }

  public List<DustType> lookupAllDustTypes() {
    return dustTypeDao.findAll("type", true);
  }

  public DustType lookupDustTypeById(Long id) {
    return dustTypeDao.findByPrimaryKey(id);
  }

  public DesignCapacityUnit lookupDesignCapacityUnitById(Long id) {
    return designCapacityUnitDao.findByPrimaryKey(id);
  }

  public UnitMeasure lookupUnitMeasureById(Long id) {
    return unitMeasureDao.findByPrimaryKey(id);
  }

  public List<FieldEquipmentType> lookupAllFieldEquipmentTypes(Long equipmentTypeId) {
    Criteria criteria = this.feTypeDao.createCriteria();
    if(equipmentTypeId != null){
      criteria.add(Restrictions.eq("equipmentType.id", equipmentTypeId));
    }
    criteria.addOrder(Order.asc("equipmentType"));
    criteria.addOrder(Order.asc("order"));
    return criteria.list();
  }

  public ProcessFieldEquipmentType lookupProcessFieldEquipmentTypeByFieldName(Long processId, String fieldName) {
    Criteria criteria = pfeDao.createCriteria();
    criteria.createAlias("fieldEquipmentType", "ft");
    criteria.add(Restrictions.eq("ft.name", fieldName));
    criteria.add(Restrictions.eq("process.id", processId));
    try {
      return (ProcessFieldEquipmentType) criteria.uniqueResult();
    } catch (HibernateException e) {
      e.printStackTrace();
    }
    return null;
  }

}