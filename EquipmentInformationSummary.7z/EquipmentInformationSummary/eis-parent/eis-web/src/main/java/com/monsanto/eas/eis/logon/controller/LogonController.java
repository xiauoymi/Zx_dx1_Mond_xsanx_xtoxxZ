package com.monsanto.eas.eis.logon.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.projects.services.UserService;
import com.monsanto.eas.eis.projects.services.UserServiceImpl;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.alert.controller.AlertController;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: AFHYAT Date: Jul 22, 2008 Time: 1:24:20 PM To change this template use File |
 * Settings | File Templates.
 */
public class LogonController implements UseCaseController {
  private UserService userService;


  public LogonController() {
    this(new UserServiceImpl());
  }

  public LogonController(UserService userService) {
    this.userService = userService;
  }

  public void run(UCCHelper helper) throws IOException {
    String userId = helper.getAuthenticatedUserID();
    String method = helper.getRequestParameterValue(EISConstants.METHOD);
    User user = lookupUser(userId);

    if (user == null || !user.getIsAuthorized()) {
      helper.forward("/WEB-INF/jsp/unauthorizedUser.jspx");
    } else {
      if (!StringUtils.isNullOrEmpty(method) && "error".equalsIgnoreCase(method)) {
        helper.setSessionParameter(EISConstants.LOGIN_USER, user);
        helper.forward(EISConstants.ERROR_JSP);
      } else {
        helper.setSessionParameter(EISConstants.LOGIN_USER, user);
        AlertController alertController = getAlertController();
        alertController.run(helper);
//        helper.forward("/WEB-INF/jsp/home.jspx");
      }
    }
  }

  //protected onlt for testing
  protected AlertController getAlertController() {
    return new AlertController();
  }

  private User lookupUser(String userId) {
    return userService.lookupUserByLogonId(userId);
  }
}
