package com.monsanto.eas.eis.logon.hibernateMappings;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Jul 30, 2008
 * Time: 9:26:00 AM
 * To change this t
 * emplate use File | Settings | File Templates.
 */

@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name="EIS_ROLE")
public class Role implements Serializable {

  @Id
  @SequenceGenerator(name = "roleSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "roleSeqGen")
  @Column(name="ID")
  private Long id;

  @Column(name="NAME")
  private String roleName;

  public Role() { }

  public Role(Long id, String roleName) {
    this.id = id;
    this.roleName = roleName;
  }

  public Long getId() {
    return id;
  }

  public String getRoleName() {
    return roleName;
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    Role role = (Role) o;
    return id.longValue() == role.id.longValue();
  }

  public int hashCode() {
    return id.hashCode();
  }

}
