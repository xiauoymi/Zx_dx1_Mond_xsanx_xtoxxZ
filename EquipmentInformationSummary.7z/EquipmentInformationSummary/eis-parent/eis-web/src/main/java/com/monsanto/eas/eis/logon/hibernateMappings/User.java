package com.monsanto.eas.eis.logon.hibernateMappings;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.domain.ProjectUserRole;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.wst.hibernate.IUser;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * User: afhyat Date: Aug 4, 2008 Time: 4:37:34 PM
 */
@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_USER")
public class User implements Serializable, XmlObject, IUser {

  @Id
  @SequenceGenerator(name = "projUserSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "projUserSeqGen")
  @Column(name = "ID")
  private Long id;

  @Column(name = "USER_ID")
  private String userId;

  @Column(name = "FIRSTNAME")
  private String firstName;

  @Column(name = "LASTNAME")
  private String lastName;

  @Column(name = "EMAIL")
  private String email;

  @Column(name = "MIDDLENAME")
  private String middleName;

  @ManyToMany(targetEntity = Role.class)
  @JoinTable(
      name = "EIS_USER_ROLE", uniqueConstraints = @UniqueConstraint(columnNames = {"USER_ID_FK", "ROLE_ID_FK"}),
      joinColumns = @JoinColumn(name = "USER_ID_FK", referencedColumnName = "ID"),
      inverseJoinColumns = @JoinColumn(name = "ROLE_ID_FK", referencedColumnName = "ID")
  )
  private Set<Role> roles = new HashSet<Role>();

  @OneToMany(mappedBy = "user",
      targetEntity = ProjectUserRole.class,
      fetch = FetchType.LAZY)
  @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
  private List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();

  public User() {
  }

  public User(Long id, String userId, String firstName, String lastName, Set<Role> roles,
              List<ProjectUserRole> projUserRoles) {
    this.id = id;
    this.userId = userId;
    this.firstName = firstName;
    this.lastName = lastName;
    this.roles = roles;
    this.projUserRoles = projUserRoles;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getUserId() {
    return userId;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public String getEmail() {
    return email;
  }

  public String getMiddleName() {
    return middleName;
  }

  public Set<Role> getRoles() {
    return roles;
  }

  public boolean getIsAuthorized() {
    return !roles.isEmpty();
//    for (Role role : roles) {
//      if (role.getRoleName().equalsIgnoreCase("eis_user")) {
//        return true;
//      }
//    }
//
//    return false;
  }

  public boolean getIsProcessTeamLead() {
    for (Role role : roles) {
      if (role.getRoleName().equalsIgnoreCase("eis_team_lead")) {
        return true;
      }
    }
    return false;
  }

  public boolean doesUserHaveEditAccessToThisProject(Projects project) {
    for (ProjectUserRole projUserRole : this.projUserRoles) {
      if (projUserRole.getProject().equals(project)) {
        if (projUserRole.getProjRole().getAccessType().getAccessType().equalsIgnoreCase("EDIT")) {
          return true;
        }
      }
    }
    return false;
  }

  public boolean isUserInProcessRoleForThisProject(Projects project) {
    return doesUserHaveThisRoleForThisProject(project, "Process Engineer");
  }

  public boolean isUserInMechanicalEngineerRoleForThisProject(Projects project) {
    return doesUserHaveThisRoleForThisProject(project, "Mechanical Engineer");
  }

  public List<Projects> lookupProjectsForAUser() {
    List<Projects> projects = new ArrayList<Projects>();
    for (ProjectUserRole projUserRole : this.projUserRoles) {
      Projects project = projUserRole.getProject();
      projects.add(project);
    }
    return projects;
  }

  public List<Projects> lookupProjectsByRolesAndStatus(String[] roleNames, String projectStatusName) {
    List<Projects> projects = new ArrayList<Projects>();
    for (ProjectUserRole projUserRole : this.projUserRoles) {
      Projects project = projUserRole.getProject();
      if (isProjectInThisStatus(projectStatusName, project) &&
          doesUserHaveTheseRoleForThisProject(roleNames, project)) {
        if (!projects.contains(project)) {
          projects.add(project);
        }
      }
    }
    return projects;
  }

  private boolean isProjectInThisStatus(String projectStatusName, Projects project) {
    return StringUtils.isBlank(projectStatusName) ||
        project.getProjStatus().getName().equalsIgnoreCase(projectStatusName);
  }

  private boolean doesUserHaveTheseRoleForThisProject(String[] roleNames, Projects project) {
    for (String roleName : roleNames) {
      if (doesUserHaveThisRoleForThisProject(project, roleName)) {
        return true;
      }
    }
    return false;
  }

  private boolean doesUserHaveThisRoleForThisProject(Projects project, String processEngineer) {
    for (ProjectUserRole projUserRole : this.projUserRoles) {
      if (projUserRole.getProject().equals(project)) {
        if (projUserRole.getProjRole().getName().equalsIgnoreCase(processEngineer)) {
          return true;
        }
      }
    }
    return false;
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<user>");
    xml.append("<userId>");
    xml.appendValue(getId()).append("</userId>");
    xml.append("<name>");
    xml.appendValue(getLastName());
    xml.appendValue(", ");
    xml.appendValue(getFirstName()).append("</name>");
    xml.append("</user>");
    return xml.toString();
  }

  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    User user = (User) o;
    return userId.equalsIgnoreCase(user.userId);
  }

  public int hashCode() {
    return userId.hashCode();
  }

  public void setProjUserRoles(List<ProjectUserRole> projUserRoles) {
    this.projUserRoles = projUserRoles;
  }

  public List<ProjectUserRole> getProjUserRoles() {
    return projUserRoles;
  }
}

