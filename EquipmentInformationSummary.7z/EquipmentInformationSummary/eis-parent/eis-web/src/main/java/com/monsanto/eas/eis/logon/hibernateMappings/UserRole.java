/*
 UserRole was created on Feb 10, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.logon.hibernateMappings;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: UserRole.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-11 15:18:53 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
@Entity
@AccessType("field")
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_USER_ROLE")
public class UserRole {
  @Id
  private UserRoleId id;

  @SuppressWarnings("unused")
  @Column(name="USER_ID_FK", insertable = false, updatable = false)
  private Long userId;

  @SuppressWarnings("unused")
  @Column(name="ROLE_ID_FK", insertable = false, updatable = false)
  private Long roleId;
  
  @ManyToOne
  @JoinColumn(name = "USER_ID_FK", insertable = false, updatable = false)
  private User user;

  @ManyToOne
  @JoinColumn(name = "ROLE_ID_FK", insertable = false, updatable = false)
  private Role role;
  
  public UserRole() {
  }

  public UserRole(UserRoleId id) {
    this.id = id;
  }

  public User getUser() {
    return id.getUser();
  }

  public Role getRole() {
    return id.getRole();
  }
}