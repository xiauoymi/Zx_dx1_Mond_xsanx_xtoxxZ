/*
 UserRoleId was created on Feb 10, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.logon.hibernateMappings;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.io.Serializable;
/**
 * Filename:    $RCSfile: UserRoleId.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-11 15:18:53 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
@Embeddable
public class UserRoleId implements Serializable {
  @ManyToOne
  @JoinColumn(name = "USER_ID_FK")
  private User user;

  @ManyToOne
  @JoinColumn(name = "ROLE_ID_FK")
  private Role role;

  public UserRoleId() {}

  public UserRoleId(User user, Role role) {
    this.user = user;
    this.role = role;
  }

  public User getUser() {
    return user;
  }

  public Role getRole() {
    return role;
  }
}