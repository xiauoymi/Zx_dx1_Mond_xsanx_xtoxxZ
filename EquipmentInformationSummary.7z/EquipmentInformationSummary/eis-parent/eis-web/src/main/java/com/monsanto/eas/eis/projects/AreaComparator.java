/*
 AreaComparator was created on Feb 6, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects;

import com.monsanto.eas.eis.projects.domain.Area;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: AreaComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-10 16:56:08 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class AreaComparator implements Comparator<Area> {

  public int compare(Area area1, Area area2) {
    if (area1 == null || area2 == null) {
      return -1;
    } else {
      return area1.compareTo(area2);
    }
  }
}