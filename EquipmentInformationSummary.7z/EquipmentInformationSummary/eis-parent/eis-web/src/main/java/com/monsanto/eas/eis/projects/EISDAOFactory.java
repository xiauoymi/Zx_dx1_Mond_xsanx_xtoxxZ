package com.monsanto.eas.eis.projects;

import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.eas.eis.projects.dao.*;
import com.monsanto.eas.eis.projects.domain.*;/*
 EISDAOFactory was created on Aug 21, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public interface EISDAOFactory {
  HibernateFactory getHibernateFactory();

  ProjectsDAOImpl getProjectsDAOImpl();

  ProjectStatusDAOImpl getProjectStatusDAOImpl();

  GenericDAO<UnitMeasure, Long> getUnitMeasureDAOImpl();

  LocationDAOImpl getLocationDAOImpl();

  GenericDAO<Crop, Long> getCropDAOImpl();

  GenericDAO<Area, Long> getAreaDAOImpl();

  GenericDAO<EquipmentType, Long> getEquipmentTypeDAOImpl();

  EquipmentDAO getEquipmentDAOImpl();

}
