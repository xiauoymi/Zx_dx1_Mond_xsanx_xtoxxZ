/*
 EISDAOFactory was created on Aug 20, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects;

import com.monsanto.eas.eis.projects.dao.*;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;

/**
 * Filename:    $RCSfile: EISDAOFactoryImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $
 * On:	$Date: 2009-01-01 23:33:08 $
 *
 * @author VRBETHI
 * @version $Revision: 1.17 $
 */
public class EISDAOFactoryImpl implements EISDAOFactory {
  private ProjectsDAOImpl projectsDAOImpl;
  private ProjectStatusDAOImpl projectStatusDAOImpl;
  private GenericDAO<UnitMeasure, Long> unitMeasureDAOImpl;
  private LocationDAOImpl locationDAOImpl;
  private GenericDAO<Crop, Long> cropDAOImpl;
  private GenericDAO<Area, Long> areaDAOImpl;
  private GenericDAO<EquipmentType, Long> equipmentTypeDAOImpl;
  private EquipmentDAO equipmentDAOImpl;


  private final HibernateFactory hibernate;

  public EISDAOFactoryImpl() {
    this(EISHibernateUtil.getHibernateFactory());
  }

  public EISDAOFactoryImpl(HibernateFactory hibernate) {
    this(hibernate, new ProjectsDAOImpl(),
        new ProjectStatusDAOImpl(),
        new HibernateDAO<UnitMeasure, Long>(hibernate, UnitMeasure.class),
        new LocationDAOImpl(),
        new HibernateDAO<Crop, Long>(hibernate, Crop.class),
        new HibernateDAO<Area, Long>(hibernate, Area.class),
        new HibernateDAO<EquipmentType, Long>(hibernate, EquipmentType.class),
        new EquipmentDAOImpl()
    );
  }

  public EISDAOFactoryImpl(HibernateFactory hibernateFactory, ProjectsDAOImpl projectsDAOImpl,
                           ProjectStatusDAOImpl projectStatusDAOImpl,
                           GenericDAO<UnitMeasure, Long> unitMeasureDAOImpl, LocationDAOImpl locationDAOImpl,
                           GenericDAO<Crop, Long> cropDAOImpl,
                           GenericDAO<Area, Long> areaDAOImpl, GenericDAO<EquipmentType, Long> equipmentTypeDAOImpl,
                           EquipmentDAO equipmentDAOImpl

  ) {
    this.hibernate = hibernateFactory;
    this.projectsDAOImpl = projectsDAOImpl;
    this.projectStatusDAOImpl = projectStatusDAOImpl;
    this.unitMeasureDAOImpl = unitMeasureDAOImpl;
    this.locationDAOImpl = locationDAOImpl;
    this.cropDAOImpl = cropDAOImpl;
    this.areaDAOImpl = areaDAOImpl;
    this.equipmentTypeDAOImpl = equipmentTypeDAOImpl;
    this.equipmentDAOImpl = equipmentDAOImpl;
  }

  public HibernateFactory getHibernateFactory() {
    return hibernate;
  }

  public ProjectsDAOImpl getProjectsDAOImpl() {
    return projectsDAOImpl;
  }

  public ProjectStatusDAOImpl getProjectStatusDAOImpl() {
    return projectStatusDAOImpl;
  }

  public GenericDAO<UnitMeasure, Long> getUnitMeasureDAOImpl() {
    return unitMeasureDAOImpl;
  }

  public LocationDAOImpl getLocationDAOImpl() {
    return locationDAOImpl;
  }

  public GenericDAO<Crop, Long> getCropDAOImpl() {
    return cropDAOImpl;
  }

  public GenericDAO<Area, Long> getAreaDAOImpl() {
    return areaDAOImpl;
  }

  public GenericDAO<EquipmentType, Long> getEquipmentTypeDAOImpl() {
    return equipmentTypeDAOImpl;
  }

  public EquipmentDAO getEquipmentDAOImpl() {
    return equipmentDAOImpl;
  }
  
}