package com.monsanto.eas.eis.projects;

import java.util.Map;
import java.util.HashMap;

/**
 * TODO: REFACTOR THIS CLASS
 * Created by IntelliJ IDEA.
 * User: vvvelu
 * Date: Sep 2, 2008
 * Time: 4:28:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class EISServiceFactory {
  private static EISServiceFactory eisServiceFactory = new EISServiceFactory();
  private static Map services = new HashMap();

  private EISServiceFactory() {}


  /**
   *   This method returns the instance of EISFactory
   * @return  EISServiceFactory
   */
  public static EISServiceFactory getInstance() {
    return eisServiceFactory;
  }

  /**
   *   The purpose of this method is to retrieve Service based on passed in Class
   * @param clazz
   * @return Object
   */
  public Object getService(Class clazz) {
    Object service = services.get(clazz.getName());
    if(service == null) {
      try {
        service = clazz.newInstance();
        services.put(clazz.getName(), service);
      } catch (InstantiationException e) {
        e.printStackTrace();
      } catch (IllegalAccessException e) {
        e.printStackTrace();
      }
    }
    return service;
  }


}
