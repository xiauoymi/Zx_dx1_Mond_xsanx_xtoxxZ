package com.monsanto.eas.eis.projects;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.services.ProjectsServiceImpl;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.Validator;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/*
 ProjectBuilder was created on Aug 21, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class ProjectBuilder {
  private ProjectPeopleBuilder projectPeopleBuilder;
  private ProjectsService projectsService;

  public ProjectBuilder() {
    this(new ProjectsServiceImpl(new EISDAOFactoryImpl()), new ProjectPeopleBuilder());
  }

  public ProjectBuilder(ProjectsService projectsService, ProjectPeopleBuilder projectPeopleBuilder) {
    this.projectsService = projectsService;
    this.projectPeopleBuilder = projectPeopleBuilder;
  }

  public Projects createProjectFromParameterData(UCCHelper helper,boolean createCopy) throws IOException {
    Projects project = null;
    String projectName = helper.getRequestParameterValue(EISConstants.PROJECT_NAME);
    String projectNumber = helper.getRequestParameterValue(EISConstants.PROJECT_NUMBER);

    String newStartDate = helper.getRequestParameterValue(EISConstants.STARTUP_DATE);
    Date startupDate = ConvertUtil.toDate(newStartDate, ConvertUtil.PROJECTS_DATE);
    //TODO: This has to be changed to reflect the date format in Data Dictionary.
    String newApprovalDate = helper.getRequestParameterValue(EISConstants.AR_APPROVAL_DATE);
    Date arApprovalDate = ConvertUtil.toDate(newApprovalDate, ConvertUtil.PROJECTS_DATE);

    Location region = getLocation(helper.getRequestParameterValue(EISConstants.LOCATION_ID));
    Location country = getLocation(helper.getRequestParameterValue(EISConstants.COUNTRY_ID));
    Location state = getLocation(helper.getRequestParameterValue(EISConstants.STATE_ID));
    Location city = getLocation(helper.getRequestParameterValue(EISConstants.CITY_ID));
    Crop crop = getCrop(helper.getRequestParameterValue(EISConstants.CROP_ID));
    UnitMeasure unitMeasure = getUnitOfMeasure(helper.getRequestParameterValue(EISConstants.UNIT_MEASURE_ID));
    ProjectStatus projectStatus = getProjectStatus(helper.getRequestParameterValue(EISConstants.PROJECT_STATUS_ID));

    //TODO: make sure the createdUser is retrieved correctly. as of now it is hard coded

    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    if(createCopy){
      projectId="";
    }
    project = getProject(projectName, projectNumber, startupDate, arApprovalDate, region, country, state, city, crop, unitMeasure, projectStatus, projectId);
    setupProjectPeople(project, helper);

    return project;
  }

  //todo
  public Projects getProject(String projectName, String projectNumber, Date startupDate, Date arApprovalDate, Location region, Location country, Location state, Location city, Crop crop, UnitMeasure unitMeasure, ProjectStatus projectStatus, String projectId) throws IOException {
    Projects project;
    if (StringUtils.isNotBlank(projectId)) {
      project = projectsService.lookupProjectById(Long.valueOf(projectId));
      project = updateProject(projectNumber, projectName, startupDate, arApprovalDate,
          projectStatus, unitMeasure, region, country, state, city, crop, project);
    } else {
      project = new Projects(projectNumber, projectName, startupDate, arApprovalDate,
          projectStatus, unitMeasure, region, country, state, city,
          crop, "EIS_USER", new Date());
    }
    return project;
  }

  private Projects updateProject(String projectNumber, String projectName, Date startupDate, Date arApprovalDate,
                                 ProjectStatus projectStatus, UnitMeasure unitMeasure, Location region,
                                 Location country, Location state, Location city,
                                 Crop crop, Projects projectToBeEdited) throws IOException {

    projectToBeEdited.setProjNumber(projectNumber);
    projectToBeEdited.setProjName(projectName);
    projectToBeEdited.setStartupDate(startupDate);
    projectToBeEdited.setArApprovalDate(arApprovalDate);
    projectToBeEdited.setProjStatus(projectStatus);
    projectToBeEdited.setUnitMeasure(unitMeasure);
    projectToBeEdited.setRegion(region);
    projectToBeEdited.setCountry(country);
    projectToBeEdited.setState(state);
    projectToBeEdited.setCity(city);
    projectToBeEdited.setCrop(crop);

    projectToBeEdited.setUpdatedDate(new Date());
    //TODO: Updated User has to be the logged in USer.
    projectToBeEdited.setUpdatedUser("VVVELU");
    return projectToBeEdited;
  }

  private Projects setupProjectPeople(Projects project, UCCHelper helper) throws IOException {
    return this.projectPeopleBuilder.setupProjectPeople(project, helper);
  }

  public List<String> validateRequiredFields(UCCHelper helper) throws IOException {
    List<String> requiredFields = new ArrayList<String>();
    validateRequiredField(helper.getRequestParameterValue(EISConstants.PROJECT_NAME), "Project Name", requiredFields);
    validateRequiredField(helper.getRequestParameterValue(EISConstants.PROJECT_NUMBER), "Project Number",
        requiredFields);

    validateRequiredField(helper.getRequestParameterValue(EISConstants.LOCATION_ID), "Region", requiredFields);
    validateRequiredField(helper.getRequestParameterValue(EISConstants.COUNTRY_ID), "Country", requiredFields);
    validateRequiredField(helper.getRequestParameterValue(EISConstants.STATE_ID), "State", requiredFields);
    validateRequiredField(helper.getRequestParameterValue(EISConstants.CITY_ID), "City", requiredFields);
    validateRequiredField(helper.getRequestParameterValue(EISConstants.CROP_ID), "Crop", requiredFields);
    validateRequiredField(helper.getRequestParameterValue(EISConstants.UNIT_MEASURE_ID), "English/Metric",
        requiredFields);
    validateRequiredField(helper.getRequestParameterValue(EISConstants.PROJECT_STATUS_ID), "Status",
        requiredFields);
    return requiredFields;
  }

  private void validateRequiredField(String requestParameterValue, String label, List<String> requiredFields) {
    if (Validator.isRequiredFieldEmpty(requestParameterValue)) {
      requiredFields.add(label + " is a required field");
    }
  }

  public List<String> validateAllFieldsLength(UCCHelper helper) throws IOException {
    List<String> invalidFieldLength = new ArrayList<String>();
    validateFieldLength(helper.getRequestParameterValue(EISConstants.PROJECT_NUMBER), "Project Number", 8,
        invalidFieldLength);
    return invalidFieldLength;
  }

  private void validateFieldLength(String requestParameterValue, String label, int expectedLength,
                                   List<String> invalidFieldLength) {
    if (!Validator.isFieldLengthValid(requestParameterValue, expectedLength)) {
      String message = label + " is required to be " + expectedLength + " characters";
      invalidFieldLength.add(message);
    }
  }

  private Crop getCrop(String cropId) throws IOException {
    if (StringUtils.isNotBlank(cropId)) {
      return projectsService.lookupCropById(Long.valueOf(cropId));
    }
    return null;
  }

  private Location getLocation(String locationId) {
    if (StringUtils.isNotBlank(locationId)) {
      Long locationID = Long.valueOf(locationId);
      return projectsService.lookupLocationById(locationID);
    }
    return null;
  }

  private UnitMeasure getUnitOfMeasure(String unitOfMeasure) {
    if (StringUtils.isNotBlank(unitOfMeasure)) {
      Long unitMeasureID = Long.valueOf(unitOfMeasure);
      return projectsService.lookupUnitMeasureById(unitMeasureID);
    }
    return null;
  }

  private ProjectStatus getProjectStatus(String statusId) {
    if (StringUtils.isNotBlank(statusId)) {
      Long projectStatusID = Long.valueOf(statusId);
      return projectsService.lookupStatusById(projectStatusID);
    }
    return null;
  }
}
