package com.monsanto.eas.eis.projects;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.equipment.BaseBuilder;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.projects.domain.ProjectRole;
import com.monsanto.eas.eis.projects.domain.ProjectUserRole;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Nov 13, 2008 Time: 1:30:18 PM To change this template use File |
 * Settings | File Templates.
 */
public class ProjectPeopleBuilder extends BaseBuilder {
  private GenericDAO<ProjectRole, Long> projRoleDao;

  public ProjectPeopleBuilder() {
    this(new HibernateDAO<ProjectRole, Long>(
        EISHibernateUtil.getHibernateFactory(), ProjectRole.class));
  }

  public ProjectPeopleBuilder(GenericDAO<ProjectRole, Long> projRoleDao) {
    this.projRoleDao = projRoleDao;
  }

  public Projects setupProjectPeople(Projects project, UCCHelper helper) throws IOException {
    flagExistingUserRolesAsDeleted(project);

    Set<ProjectUserRole> projUserRoles = new HashSet<ProjectUserRole>();
    projUserRoles.addAll(getProjectUserRoles(project, EISConstants.PROJECT_SPONSOR,
        helper.getRequestParameterValues(EISConstants.PROJECT_SPONSOR_ID),
        helper.getRequestParameterValues(EISConstants.IS_LEAD_PROJECT_SPONSOR)));
    projUserRoles.addAll(
        getProjectUserRoles(project, EISConstants.PROCESS_ENGINEER,
            helper.getRequestParameterValues(EISConstants.LEAD_PROCESS_ID),
            helper.getRequestParameterValues(EISConstants.IS_LEAD_PROCESS_LEAD)));
    projUserRoles.addAll(getProjectUserRoles(project, EISConstants.PROJECT_MANAGER,
        helper.getRequestParameterValues(EISConstants.PROJECT_MANAGER_ID),
        helper.getRequestParameterValues(EISConstants.IS_LEAD_PROJECT_MANAGER)));
    projUserRoles.addAll(getProjectUserRoles(project, EISConstants.MECHANICAL_ENGINEER,
        helper.getRequestParameterValues(EISConstants.LEAD_MECH_ENGR_ID),
        helper.getRequestParameterValues(EISConstants.IS_LEAD_MECH_ENGR_LEAD)));
    projUserRoles.addAll(getProjectUserRoles(project, EISConstants.MANUFACTURING_REPRESENTATIVE,
        helper.getRequestParameterValues(EISConstants.MANUFACTURE_REP_ID),
        helper.getRequestParameterValues(EISConstants.IS_LEAD_MANUFACTURE_REP)));
    projUserRoles.addAll(getProjectUserRoles(project, EISConstants.MECHANICAL_DESIGNER,
        helper.getRequestParameterValues(EISConstants.LEAD_MECH_DESIGNER_ID),
        helper.getRequestParameterValues(EISConstants.IS_LEAD_MECH_DESIGNER_LEAD)));
    projUserRoles.addAll(getProjectUserRoles(project, EISConstants.LOCATION_MANAGER,
        helper.getRequestParameterValues(EISConstants.LOCATION_MANAGER_ID),
        helper.getRequestParameterValues(EISConstants.IS_LEAD_LOCATION_MANAGER)));
    projUserRoles.addAll(getProjectUserRoles(project, EISConstants.ELECTRICAL_ENGINEER,
        helper.getRequestParameterValues(EISConstants.LEAD_ELECT_ENGR_ID),
        helper.getRequestParameterValues(EISConstants.IS_LEAD_ELECT_ENGR_LEAD)));
    projUserRoles.addAll(
        getProjectUserRoles(project, EISConstants.PROJECT_BUYER,
            helper.getRequestParameterValues(EISConstants.PROJECT_BUYER_ID),
            helper.getRequestParameterValues(EISConstants.IS_LEAD_PROJECT_BUYER)));
    projUserRoles.addAll(getProjectUserRoles(project, EISConstants.ELECTRICAL_DESIGNER,
        helper.getRequestParameterValues(EISConstants.LEAD_ELECT_DESIGNER_ID),
        helper.getRequestParameterValues(EISConstants.IS_LEAD_ELECT_DESIGNER_LEAD)));
    projUserRoles.addAll(
        getProjectUserRoles(project, EISConstants.PROJECT_ENGINEER,
            helper.getRequestParameterValues(EISConstants.PROJECT_ENGR_ID),
            helper.getRequestParameterValues(EISConstants.IS_PROJECT_ENGR_LEAD)));
    projUserRoles.addAll(getProjectUserRoles(project, EISConstants.PROJECT_CONTROLS,
        helper.getRequestParameterValues(EISConstants.PROJECT_CONTROLS_ID),
        helper.getRequestParameterValues(EISConstants.IS_PROJECT_CONTROLS_LEAD)));
    project.setUserRoles(projUserRoles);
    return project;
  }

  private void flagExistingUserRolesAsDeleted(Projects project) {
    Set<ProjectUserRole> existingProjUserRoles = project.getUserRoles();
    for (ProjectUserRole pur : existingProjUserRoles) {
      pur.setDeleted(true);
    }
  }

  private Set<ProjectUserRole> getProjectUserRoles(Projects project, String roleName,
                                                   String[] userIds, String[] isLeads) throws IOException {
    Set<ProjectUserRole> projUserRoles = new HashSet<ProjectUserRole>();
    if (userIds != null) {
      for (int i = 0; i < userIds.length; i++) {
        if (StringUtils.isNotBlank(userIds[i])) {
          User user = new User();
          user.setId(new Long(userIds[i]));
          ProjectRole projRole = lookupProjectRoleByName(roleName);
          boolean isLead = getBool(isLeads[i]);
          ProjectUserRole projUserRole = new ProjectUserRole(project, user, projRole, isLead);
          projUserRoles.add(projUserRole);
        }
      }
    }
    return projUserRoles;
  }

  private ProjectRole lookupProjectRoleByName(String roleName) {
    Criteria criteria = projRoleDao.createCriteria();
    criteria.add(Restrictions.eq("name", roleName).ignoreCase());
    return (ProjectRole) criteria.uniqueResult();
  }
}
