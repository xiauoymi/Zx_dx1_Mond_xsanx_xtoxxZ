package com.monsanto.eas.eis.projects;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.eis.controller.EISController;
import com.monsanto.eas.eis.equipment.service.*;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.services.ProjectsServiceImpl;
import com.monsanto.eas.eis.projects.services.UserService;
import com.monsanto.eas.eis.projects.services.UserServiceImpl;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.util.ElectricalConstants;
import com.monsanto.eas.eis.util.EquipmentConstants;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.io.IOException;
import java.util.*;

/**
 * Created by IntelliJ IDEA. User: VVVELU Date: Jul 29, 2008 Time: 3:43:47 PM
 */
public class ProjectsController extends EISController {
  private final ProjectsUtility projectsUtility;
  private final ProjectsService projectsService;
  private ProcessService processService;
  private EquipmentService equipmentService;
  private ElectricalService electricalService;
  private CostScheduleService costScheduleService;
  private ProjectBuilder projectBuilder;
  private MechanicalService mechanicalService;
  private UserService userService;

  public ProjectsController() {
    this(new EISDAOFactoryImpl());
  }

  public ProjectsController(EISDAOFactory daoFactory) {
    this(new ProjectsServiceImpl(daoFactory), new ProjectsUtility(daoFactory),
        new ProcessServiceImpl(), new EquipmentServiceImpl(), new ElectricalServiceImpl(),
        new CostScheduleServiceImpl(), new MechanicalServiceImpl(),
        new ProjectBuilder(new ProjectsServiceImpl(daoFactory), new ProjectPeopleBuilder()),
        new UserServiceImpl());
  }

  public ProjectsController(ProjectsService projectsService, ProjectsUtility projectUtility,
                            ProcessService processService, EquipmentService equipmentService,
                            ElectricalService electricalService, CostScheduleService costScheduleService,
                            MechanicalService mechanicalService, ProjectBuilder projectBuilder,
                            UserService userService) {
    this.projectsUtility = projectUtility;
    this.processService = processService;
    this.equipmentService = equipmentService;
    this.electricalService = electricalService;
    this.costScheduleService = costScheduleService;
    this.projectsService = projectsService;
    this.projectBuilder = projectBuilder;
    this.mechanicalService = mechanicalService;
    this.userService = userService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
  }

  public void list_location_xml(UCCHelper helper) throws IOException {
    Document document = projectsService
        .getLocationsAsXML(Long.valueOf(helper.getRequestParameterValue(EISConstants.LOCATION_ID)));
    helper.setContentType("text/xml");
    helper.writeXMLDocument(document);
  }

  public void archiveProjects(UCCHelper helper) throws IOException {
    String projectIDs = helper.getRequestParameterValue("projectIds");
    String[] projectIDsArray = projectIDs.split(",");
    projectsService.archiveProjects(projectIDsArray);
  }

  public void deleteProject(UCCHelper helper) throws IOException {
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    projectsService.deleteProject(new Long(projectId));
    helper.setContentType(EISConstants.TEXT_PLAIN);
    helper.getPrintWriter().write("ok");
  }

  public void edit_project(UCCHelper helper) throws IOException {
    Map projectMap = projectsUtility.createProject();
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    Projects project = projectsService.lookupProjectById(Long.valueOf(projectId));
    Location country = project.getCountry();
    List<Location> countryLocationList = country.getParentLocation().getChildLocations();
    projectMap.put(EISConstants.COUNTRY, countryLocationList);
    Location state = project.getState();
    List<Location> stateList = state.getParentLocation().getChildLocations();
    projectMap.put(EISConstants.STATE, stateList);
    Location city = project.getCity();
    List<Location> cityList = city.getParentLocation().getChildLocations();
    projectMap.put(EISConstants.CITY, cityList);
    helper.setRequestAttributeValue(EISConstants.PROJECT_DETAIL, project);
    helper.setRequestAttributeValue(EISConstants.DOES_PROJECT_HAVE_EQUIPMENTS,
        projectsService.doesProjectHaveEquipments(Long.valueOf(projectId)));
    helper.setRequestAttributeValue(EISConstants.CREATE_PROJECT_REF_DATA, projectMap);
    helper.setRequestAttributeValue(EISConstants.PROJECT_ID, String.valueOf(project.getId().longValue()));
    helper.setRequestAttributeValue(EISConstants.OPERATION, EISConstants.EDIT_PROJECT);

    setReferenceDataInHelper(helper, project);
    helper.forward(EISConstants.WEB_INF_JSP_PROJECTS_PROJECT_DETAIL_JSP);
  }

  public void project_detail(UCCHelper helper) throws IOException {
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    Projects project = projectsService.lookupProjectById(Long.valueOf(projectId));
    helper.setRequestAttributeValue(EISConstants.PROJECT_DETAIL, project);
    helper.setRequestAttributeValue(EISConstants.PROJECT_ID, projectId);
    helper.setRequestAttributeValue(EISConstants.PROJECT_SAVE_MSG, helper.getRequestParameterValue(EISConstants.PROJECT_SAVE_MSG));
    helper.setRequestAttributeValue(EISConstants.LOAD_ALL_EQUIPMENT_LIST, helper.getRequestParameterValue(EISConstants.LOAD_ALL_EQUIPMENT_LIST));
    setReferenceDataInHelper(helper, project);

    helper.forward(EISConstants.WEB_INF_JSP_PROJECTS_PROJECT_DETAIL_JSP);
  }

  private void setReferenceDataInHelper(UCCHelper helper, Projects project) throws IOException {
    List<Area> areaList = project.getCrop().getAreas();
    Collections.sort(areaList, new AreaComparator());
    List<EquipmentType> equimentTypeList = this.equipmentService.lookupAllParentEquipmentTypes();
    helper.setRequestAttributeValue(EISConstants.EQUIPMENT_AREAS, areaList);
    helper.setRequestAttributeValue(EISConstants.EQUIPMENT_TYPES, equimentTypeList);
    helper.setRequestAttributeValue(EISConstants.FIELD_EQUIPMENT_TYPES,
        processService.lookupAllFieldEquipmentTypes(null));
    helper.setRequestAttributeValue(EISConstants.GAS_TYPES, processService.lookupAllGasTypes());
    helper.setRequestAttributeValue(EISConstants.WATER_TYPES, processService.lookupAllWaterTypes());
    helper.setRequestAttributeValue(EISConstants.DUST_TYPES, processService.lookupAllDustTypes());
//    helper.setRequestAttributeValue(EISConstants.DESIGN_CAPACITY_UNITS, processService.lookupDesignCapacityUnitsByUnitMeasureId(project.getUnitMeasure().getId()));
//    helper.setRequestAttributeValue(EISConstants.EQUIPMENT_ID,
//        helper.getRequestParameterValue(EISConstants.EQUIPMENT_ID));
    helper.setRequestAttributeValue(ElectricalConstants.ELECTRICAL_INPUTS, electricalService.lookupAllInputs());
    helper.setRequestAttributeValue(ElectricalConstants.ELECTRICAL_OUTPUTS, electricalService.lookupAllOutputs());
    helper.setRequestAttributeValue(ElectricalConstants.OTHER_MEASUREMENTS,
        electricalService.lookupAllOtherMeasurements());
    helper.setRequestAttributeValue(EISConstants.FUNDING_SOURCES, costScheduleService.lookupAllFundingSources());
    helper.setRequestAttributeValue(EISConstants.PURCHASE_SCOPES, mechanicalService.lookupAllPurchaseScopes());
    helper.setRequestAttributeValue(EISConstants.USER_HAS_EDIT_ACCESS_TO_THIS_PROJECT,
        userService.doesUserHaveEditAccessToThisProject(helper.getAuthenticatedUserID(), project));
    helper.setRequestAttributeValue(EISConstants.IS_USER_IN_PROCESS_ROLE_FOR_THIS_PROJECT,
        userService.isUserInProcessRoleForThisProject(helper.getAuthenticatedUserID(), project));
    helper.setRequestAttributeValue(EISConstants.IS_USER_IN_MECHANICAL_ENG_ROLE_FOR_THIS_PROJECT,
        userService.isUserInMechanicalEngineerRoleForThisProject(helper.getAuthenticatedUserID(), project));
  }

  /**
   * This method is used to unpack all the form data from Create New Project Page, retrieve the data and make a database
   * call to insert Projects record. To get all this work, this method calls ProjectBuilder.createProjectFromParameterData()
   * and submitCreateProject().
   */
  public void submit_create_project(UCCHelper helper) throws IOException {
    List<String> requiredFields = projectBuilder.validateRequiredFields(helper);
    List<String> invalidFieldLengthList = projectBuilder.validateAllFieldsLength(helper);
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    boolean isUniqueProjectNumber = !projectsService
        .doesProjectExist(projectId, helper.getRequestParameterValue(EISConstants.PROJECT_NUMBER));
    Projects newProject = projectBuilder
        .createProjectFromParameterData(helper,false);
    boolean isValid = requiredFields.isEmpty() && invalidFieldLengthList.isEmpty() && isUniqueProjectNumber;

    Document responseDoc;
    if (isValid) {
      projectsUtility.saveProject(newProject);
      responseDoc = getValidResponseDocument(newProject.getId());
    } else {
      clearHibernateSession();
      responseDoc = getErrorResponseDocument(isUniqueProjectNumber, requiredFields, invalidFieldLengthList);
    }
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(responseDoc);
  }

  public void saveAs(UCCHelper helper) throws Exception{
    List<String> requiredFields = projectBuilder.validateRequiredFields(helper);
    List<String> invalidFieldLengthList = projectBuilder.validateAllFieldsLength(helper);
    String oldProjectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    String projectId = "";
    boolean isUniqueProjectNumber = !projectsService
        .doesProjectExist(projectId, helper.getRequestParameterValue(EISConstants.PROJECT_NUMBER));
    boolean isValid = requiredFields.isEmpty() && invalidFieldLengthList.isEmpty() && isUniqueProjectNumber;


    Document responseDoc;
    if (isValid) {
      Projects newProject = projectBuilder.createProjectFromParameterData(helper,true);
      saveNewProjectWithCopyOfOldProjectsEquipment(oldProjectId, newProject);

      responseDoc = getValidResponseDocument(newProject.getId());
    } else {
      clearHibernateSession();
      responseDoc = getErrorResponseDocument(isUniqueProjectNumber, requiredFields, invalidFieldLengthList);
    }
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(responseDoc);
  }

  private void saveNewProjectWithCopyOfOldProjectsEquipment(String oldProjectId, Projects newProject) throws CloneNotSupportedException {
    projectsUtility.saveProject(newProject);
    PaginatedResult result = equipmentService.findBySearchCriteria(oldProjectId,
            null, null, null, null, null, null, null, EquipmentConstants.EQUIPMENT_TYPE, "asc", 0, 1000);
    Iterable<Equipment> equipments = (Iterable<Equipment>) result.getData();

    for (Equipment equipment : equipments) {
      Equipment equipmentCopy = equipment.createCopy();
      equipmentCopy.setProjects(newProject);
      setPurchasingAndCostScheduleToEmptyIfProjectIsInIdleOrCompletedState(newProject, equipmentCopy);
      equipmentService.saveEquipment(equipmentCopy);
    }
  }

  private Long getLongParameter(UCCHelper helper, String paramName) throws IOException {

    String paramString = helper.getRequestParameterValue(paramName);
    if (paramString == null || StringUtils.isEmpty(paramString)) {
      return null;
    } else {
      try {
        return new Long(paramString);
      } catch (NumberFormatException nfe) {
        return null;
      }
    }
  }

  public void saveAsById(UCCHelper helper) throws IOException, CloneNotSupportedException {
    Long oldProjectId = getLongParameter(helper, EISConstants.PROJECT_ID);
    String newProjectNumber = helper.getRequestParameterValue(EISConstants.PROJECT_NUMBER);
    boolean isUniqueProjectNumber = !projectsService.doesProjectExist("", newProjectNumber);
    Projects oldProject = projectsService.lookupProjectById(oldProjectId);
    boolean doesOldProjectExist = oldProject != null;
    boolean isValid = doesOldProjectExist && isUniqueProjectNumber;
    Document responseDoc;
    if (isValid) {
      Projects newProject = projectBuilder.getProject(
              oldProject.getProjName(),
              newProjectNumber,
              oldProject.getStartupDateAsDate(),
              oldProject.getArApprovalDateAsDate(),
              oldProject.getRegion(),
              oldProject.getCountry(),
              oldProject.getState(),
              oldProject.getCity(),
              oldProject.getCrop(),
              oldProject.getUnitMeasure(),
              oldProject.getProjStatus(),
              null
      );
      saveNewProjectWithCopyOfOldProjectsEquipment(oldProjectId.toString(), newProject);

      responseDoc = getValidResponseDocument(newProject.getId());
    } else {
      responseDoc = getErrorResponseDocument(isUniqueProjectNumber, doesOldProjectExist);
    }

    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(responseDoc);
  }

  private void setPurchasingAndCostScheduleToEmptyIfProjectIsInIdleOrCompletedState(Projects newProject,
                                                                                    Equipment equipmentCopy) {
    if (EISConstants.PROJECT_STATUS_IDLE.equalsIgnoreCase(newProject.getProjStatus().getName())
              || EISConstants.PROJECT_STATUS_COMPLETED.equalsIgnoreCase(newProject.getProjStatus().getName())){
      equipmentCopy.setPurchasing(new Purchasing());
      equipmentCopy.setCostSchedule(new CostSchedule());
    }
  }

   //protected only for testing
  protected void clearHibernateSession() {
    EISHibernateUtil.getHibernateFactory().getSession().clear();
  }

  private void appendSingleError(Node parent, String header, String msg) {
    Collection<String> singleList = new LinkedList<String>();
    singleList.add(msg);
    appendMultipleError(parent, header, singleList);
  }

  private void appendMultipleError(Node parent, String header, Collection<String> msgs) {
    if (!msgs.isEmpty()) {
      Element errorElement = DOMUtil.addChildElement(parent, "error");
      DOMUtil.addChildElement(errorElement, "errorHeader", header);
      for (String msg : msgs) {
        DOMUtil.addChildElement(errorElement, "errorMsg", msg);
      }
    }
  }

  private Document getErrorResponseDocument(boolean isProjectNumberUnique, boolean doesOldProjectExist) {
    Document doc = DOMUtil.newDocument();
    Element responseElement = DOMUtil.addChildElement(doc, "response");
    DOMUtil.addChildElement(responseElement, "projectId");
    Element errorElement = DOMUtil.addChildElement(responseElement, "errors");
    if (!isProjectNumberUnique) {
      appendSingleError(errorElement, EISConstants.MESSAGE_FOR_NON_UNIQUE_PROJ_NUMBER, "Please enter a unique Project Number");
    }

    if (!doesOldProjectExist) {
      appendSingleError(errorElement, EISConstants.MESSAGE_FOR_NON_EXISTING_PROJ_ID, "Invalid request - The old project does not exist.");
    }

    return doc;
  }

  private Document getErrorResponseDocument(boolean isProjectNumberUnique,
                                            Collection<String> missingRequiredFields,
                                            Collection<String> invalidLengthFields) {

    Document doc = DOMUtil.newDocument();
    Element responseElement = DOMUtil.addChildElement(doc, "response");
    DOMUtil.addChildElement(responseElement, "projectId");
    Element errorElement = DOMUtil.addChildElement(responseElement, "errors");
    if (!isProjectNumberUnique) {
      appendSingleError(errorElement, EISConstants.MESSAGE_FOR_NON_UNIQUE_PROJ_NUMBER, "Please enter a unique Project Number");
    }

    appendMultipleError(errorElement, "Required Fields:", missingRequiredFields);
    appendMultipleError(errorElement, "Project Fields with invalid length:", invalidLengthFields);

    return doc;
  }

  private Document getValidResponseDocument(Long projectId) throws IOException {
    Document doc = DOMUtil.newDocument();
    Element responseElement = DOMUtil.addChildElement(doc, "response");
    DOMUtil.addChildElement(responseElement, "projectId", (projectId == null) ? "" : projectId.toString());
    DOMUtil.addChildElement(responseElement, "errors");
    return doc;
  }

  /**
   * This method collects all reference data that is required to populate list boxes in Create New Project Page.
   */
  public void create(UCCHelper helper) throws IOException {
    setupReferenceData(helper);
    helper.forward(EISConstants.WEB_INF_JSP_PROJECTS_CREATE_PROJECT_JSP);
  }

  private void setupReferenceData(UCCHelper helper) throws IOException {
    Map projectMap = projectsUtility.createProject();
    helper.setRequestAttributeValue(EISConstants.CREATE_PROJECT_REF_DATA, projectMap);
  }
}
