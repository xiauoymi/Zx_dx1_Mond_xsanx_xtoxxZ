package com.monsanto.eas.eis.projects;

import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.alert.domain.AlertForProjectRoleAndStatus;

import java.util.List;

import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 9, 2008
 * Time: 1:26:16 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProjectsService {

  void deleteProject(Long projectId);

  void archiveProjects(String[] projectIDsArray);

  Document getLocationsAsXML(Long locationId);

  Projects lookupProjectById(Long id);

  List<ProjectStatus> getAllActiveProjectStatus();

  List<ProjectStatus> getAllInActiveProjectStatus();

  List<ProjectStatus> getProjectStatuses(boolean isArchivedStatus);

  boolean doesProjectExist(String projectId, String projectNumber);

  Crop lookupCropById(Long id);

  Location lookupLocationById(Long id);

  ProjectStatus lookupStatusById(Long id);

  UnitMeasure lookupUnitMeasureById(Long id);

  List<Location> lookupChildLocations(Long locationId);

  boolean doesProjectHaveEquipments(Long id);

  Projects lookupMasterProjectForThisProject(Projects project);

  Projects lookupProjectByIdForAlert(Long id);
}
