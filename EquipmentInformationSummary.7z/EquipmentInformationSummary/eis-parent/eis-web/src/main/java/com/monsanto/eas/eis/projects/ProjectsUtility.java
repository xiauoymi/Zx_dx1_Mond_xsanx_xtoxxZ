package com.monsanto.eas.eis.projects;

import com.monsanto.eas.eis.projects.domain.*;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Aug 29, 2008
 * Time: 1:51:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProjectsUtility{

  private final EISDAOFactory daoFactory;

  public ProjectsUtility() {
    this(new EISDAOFactoryImpl());
  }

  public ProjectsUtility(EISDAOFactory daoFactory) {
    this.daoFactory = daoFactory;
  }

  /**
   * This method makes a database call to retrieve all Locations
   * @return
   */
  public List<Location> getLocations() {
    return daoFactory.getLocationDAOImpl().findByRegion();
  }

  /**
   * This method makes a database call to retrieve all Crops
   * @return
   */
  public List<Crop> getCropsList() {
    return daoFactory.getCropDAOImpl().findAll("name", true);
  }

  /**
   * This method makes a database call to return Projects object by Primary Key/Id
   * @param id
   * @return
   */
  public Projects getProjectById(Long id) {
    return daoFactory.getProjectsDAOImpl().findByPrimaryKey(id);
  }

  /**
   * This method makes a database call to insert/update the Projects Object passed in.
   * @param projects
   */
  public Projects saveProject(Projects projects) {
    return daoFactory.getProjectsDAOImpl().save(projects);
  }


  public void deleteProject(String projectId) {
    ProjectStatus et = new ProjectStatus();
    et.setName("Deleted");
    List<ProjectStatus> list = daoFactory.getProjectStatusDAOImpl().findByExample(et, new String[0]);
    ProjectStatus ps = list.get(0);
    Long id = Long.valueOf(projectId);
    Projects project = daoFactory.getProjectsDAOImpl().findByPrimaryKey(id);
    project.setProjStatus(ps);
    daoFactory.getProjectsDAOImpl().save(project);
  }

  /**
   * This method put all the reference data together in an HashMap that would be used to populate
   * List Boxes in Create New Project Page.
   * @return java.util.Map
   */
  public Map createProject() {
    //todo MAP being miss-used in place of an object
    //Prepare all the reference data
    Map refData = new HashMap();
    List<ProjectStatus> projectStatus = daoFactory.getProjectStatusDAOImpl().findAllExcludingDelete();
    refData.put("PROJECT_STATUS", projectStatus);

    List<UnitMeasure> unitMeasure = daoFactory.getUnitMeasureDAOImpl().findAll("name", true);
    refData.put("UNIT_MEASURE", unitMeasure);

    List<Location> location = daoFactory.getLocationDAOImpl().findByRegion();
    refData.put("LOCATION", location);

    List<Crop> crop = daoFactory.getCropDAOImpl().findAll("name", true);
    refData.put("CROP", crop);
    return refData;
  }
}
