package com.monsanto.eas.eis.projects.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.projects.services.UserService;
import com.monsanto.eas.eis.projects.services.UserServiceImpl;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Nov 18, 2008 Time: 5:42:54 PM To change this template use File |
 * Settings | File Templates.
 */
public class ProjectRefDataController extends AbstractDispatchController {
  private UserService userService;

  public ProjectRefDataController() {
    this(new UserServiceImpl());
  }

  public ProjectRefDataController(UserService userService) {
    this.userService = userService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
  }

  public void lookupRefDataForProjectPeople(UCCHelper helper) throws IOException {
    StringBuffer xmlStr = new StringBuffer("<refData>");
    appendProjectUsersXml(xmlStr);
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  private void appendProjectUsersXml(StringBuffer xmlStr) {
    xmlStr.append("<projectUsers>");
    List<User> projectUserList = userService.lookupAllUsersWithProjectUserRole();
    for (User pu : projectUserList) {
      xmlStr.append(pu.toXml());
    }
    xmlStr.append("</projectUsers>");
  }

  private Document getDocument(StringBuffer xmlStr) throws IOException {
    Document document;
    try {
      document = DOMUtil.stringToXML(xmlStr.toString());
    } catch (ParserException e) {
      throw new RuntimeException("Unable to parse process xml");
    }
    return document;
  }
}
