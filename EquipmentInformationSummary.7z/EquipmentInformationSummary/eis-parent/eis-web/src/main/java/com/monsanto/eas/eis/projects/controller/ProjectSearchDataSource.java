/*
 ProjectSearchDataSource was created on Nov 24, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.eis.controller.XmlDataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.projects.dao.ProjectsDAO;
import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: ProjectSearchDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-15 14:28:34 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class ProjectSearchDataSource implements XmlDataSource {
  private UCCHelper helper;
  private final ProjectsDAO projectDao;
  private PaginatedResult result = null;

  public ProjectSearchDataSource(UCCHelper helper) {
    this(helper, new ProjectsDAOImpl());
  }

  public ProjectSearchDataSource(UCCHelper helper, ProjectsDAO projectDao) {
    this.helper = helper;
    this.projectDao = projectDao;
  }

  public List<? extends XmlObject> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws IOException {
    return getProjectsBasedOnSearchCriteria(sortKey, sortDir, startIndex, maxResults);
  }

  private List<? extends XmlObject> getProjectsBasedOnSearchCriteria(String sortKey, String sortDir, int startIndex, int maxResults) throws
      IOException {
    String archived = helper.getRequestParameterValue("archived");
    String projectNumber = StringUtils.trimNullable(helper.getRequestParameterValue("projectNumber"));
    String location = StringUtils.trimNullable(helper.getRequestParameterValue("location"));
    String country = StringUtils.trimNullable(helper.getRequestParameterValue("country"));
    String state = StringUtils.trimNullable(helper.getRequestParameterValue("state"));
    String city = StringUtils.trimNullable(helper.getRequestParameterValue("city"));
    String crop = StringUtils.trimNullable(helper.getRequestParameterValue("crop"));
    String status = StringUtils.trimNullable(helper.getRequestParameterValue("status"));
    result =  projectDao.findBySearchCriteria(projectNumber, location, country, state, city,
        crop, status, !"true".equalsIgnoreCase(archived), sortKey, sortDir, startIndex, maxResults);
    return result.getData();
  }

  public int getTotalRecords() {
    if(result == null){
      return DataSource.UNKNOWN_RECORD_COUNT;
    }
    return result.getTotalRecords();
  }
}