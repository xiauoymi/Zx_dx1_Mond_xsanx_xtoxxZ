package com.monsanto.eas.eis.projects.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.eas.eis.projects.EISDAOFactory;
import com.monsanto.eas.eis.projects.EISDAOFactoryImpl;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.ProjectsUtility;
import com.monsanto.eas.eis.projects.domain.Location;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import com.monsanto.eas.eis.projects.services.ProjectsServiceImpl;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.controller.EISController;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: afhyat Date: Aug 28, 2008 Time: 8:33:04 AM To change this template use File |
 * Settings | File Templates.
 */
public class SearchProjectsController extends EISController {

  private final EISDAOFactory daoFactory;
  private ProjectsUtility projectUtility;
  private ProjectsService projectsService;

  public SearchProjectsController() {
    this(new EISDAOFactoryImpl());
  }

  public SearchProjectsController(EISDAOFactory daoFactory) {
    this(daoFactory, new ProjectsServiceImpl(daoFactory), new ProjectsUtility());
  }

  public SearchProjectsController(EISDAOFactory daoFactory, ProjectsService projectsService,
                                  ProjectsUtility projectUtility) {
    this.projectsService = projectsService;
    this.daoFactory = daoFactory;
    this.projectUtility = projectUtility;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    helper.setRequestAttributeValue(EISConstants.PROJECT_LOCATION_LIST, projectUtility.getLocations());
    helper.setRequestAttributeValue(EISConstants.PROJECT_CROP_LIST, projectUtility.getCropsList());
    helper.setRequestAttributeValue(EISConstants.PROJECT_STATUS_LIST, projectsService.getAllActiveProjectStatus());
    helper.setRequestAttributeValue(EISConstants.CANCEL_PROJECT_CREATION,
        helper.getRequestParameterValue(EISConstants.CANCEL_PROJECT_CREATION));
    helper.forward(EISConstants.WEB_INF_JSP_PROJECTS_PROJECTS_LIST_JSP);
  }

  public void lookupProjectStatusXml(UCCHelper helper) throws IOException {
    boolean isArchivedStatus = isArchivedStatusList(helper);
    List<ProjectStatus> projectStatusList = projectsService.getProjectStatuses(isArchivedStatus);
    StringBuffer xmlStr = new StringBuffer("<refData>");
    for (ProjectStatus ps : projectStatusList) {
      xmlStr.append(ps.toXml());
    }
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  public void lookupProjectLocationXml(UCCHelper helper) throws IOException {
    String locationId = helper.getRequestParameterValue("locationId");
    List<Location> locations = projectsService.lookupChildLocations(new Long(locationId));
    StringBuffer xmlStr = new StringBuffer("<refData>");
    for (Location loc : locations) {
      xmlStr.append(loc.toXml());
    }
    xmlStr.append("</refData>");
    helper.setContentType(EISConstants.XML_TEXT);
    helper.writeXMLDocument(getDocument(xmlStr));
  }

  private Document getDocument(StringBuffer xmlStr) throws IOException {
    Document document;
    try {
      document = DOMUtil.stringToXML(xmlStr.toString());
    } catch (ParserException e) {
      throw new RuntimeException("Unable to parse process xml");
    }
    return document;
  }

  private boolean isArchivedStatusList(UCCHelper helper) throws IOException {
    return "true".equalsIgnoreCase(helper.getRequestParameterValue(EISConstants.ARCHIVED_STATUS));
  }
}
