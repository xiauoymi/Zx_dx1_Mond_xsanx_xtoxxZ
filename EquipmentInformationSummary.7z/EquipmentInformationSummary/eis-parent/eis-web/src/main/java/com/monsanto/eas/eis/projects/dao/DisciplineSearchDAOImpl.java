/*
 MyDAO was created on Oct 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.eas.eis.util.EquipmentConstants;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Projections;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: DisciplineSearchDAOImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-01-29 22:18:41 $
 *
 * @author sspati1
 * @version $Revision: 1.8 $
 */
public class DisciplineSearchDAOImpl<T, ID extends Serializable> extends HibernateDAO<T, ID> implements
    DisciplineSearchDAO<T, ID> {
  private static Map<String, String> equipmentSortKeyMap = new LinkedHashMap<String, String>();

  static {
    equipmentSortKeyMap.put(EquipmentConstants.VENDOR, "pu.vendor");
    equipmentSortKeyMap.put(EquipmentConstants.EQUIPMENT_TYPE, "et.name");
    equipmentSortKeyMap.put(EquipmentConstants.AREA, "a.areaCode");
    equipmentSortKeyMap.put(EquipmentConstants.EQUIPMENT_NUMBER, "eq.equipmentNumber");
    equipmentSortKeyMap.put(EquipmentConstants.EQUIPMENT_NAME, "eq.name");
    equipmentSortKeyMap.put(EquipmentConstants.PROCESS_LINE_NUMBER, "eq.processLineNumber");
  }

  public DisciplineSearchDAOImpl(HibernateFactory hibernate, Class<? extends T> persistentClass) {
    super(hibernate, persistentClass);
  }

  public PaginatedResult findBySearchCriteria(Criteria criteria, String projectId, String equipmentNumber,
                                              String equipmentName,
                                              String processLineNum, String equipmentTypeId,
                                              String areaId, String vendor,
                                              String sortKey, String sortDir, int startIndex, int maxResults) {
    criteria.createAlias("equipment", "eq");
    criteria.add(Restrictions.eq("eq.projects.id", new Long(projectId)));
    addCriteriaForArea(areaId, sortKey, criteria);
    addCriteriaForEquipmentType(equipmentTypeId, sortKey, criteria);
    addCriteriaForVendor(vendor, sortKey, criteria);
    addLikeRestrictionsIfNotNull(criteria, "eq.equipmentNumber", equipmentNumber);
    addLikeRestrictionsIfNotNull(criteria, "eq.name", equipmentName);
    addLikeRestrictionsIfNotNull(criteria, "eq.processLineNumber", processLineNum);
    criteria.add(Restrictions.eq("eq.isDeleted", false));//have to add this manually coz ManyToOne mappings dont append where clause automatically
    //to avoid pulling up motors of deleted equipments

//    criteria.setFetchMode("eq.motors", FetchMode.JOIN);
//    criteria.setFetchMode("eq.instruments", FetchMode.JOIN);
//    criteria.setFetchMode("eq.accessories", FetchMode.JOIN);

    sortKey = updateSortKey(sortKey);

    criteria.setProjection(Projections.rowCount());
    Integer totalRecords = (Integer) criteria.uniqueResult();

    if (sortDir.equalsIgnoreCase("asc")) {
      criteria.addOrder(Order.asc(sortKey));
    } else {
      criteria.addOrder(Order.desc(sortKey));
    }

    criteria.setProjection(null);
    criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
    criteria.setFirstResult(startIndex);
    if(totalRecords.intValue() <= maxResults){
      maxResults = totalRecords.intValue();
    }
    criteria.setMaxResults(maxResults);

    return new PaginatedResult(totalRecords.intValue(), criteria.list());
  }

  private void addCriteriaForVendor(String vendor, String sortKey, Criteria criteria) {
    if (!StringUtils.isNullOrEmpty(vendor) || sortKey.equalsIgnoreCase(EquipmentConstants.VENDOR)) {
      criteria.createAlias("eq.purchasing", "pu");
      if (!StringUtils.isNullOrEmpty(vendor)) {
        criteria.add(Restrictions.like("pu.vendor", "%" + vendor + "%").ignoreCase());
      }
    }
  }

  private void addCriteriaForEquipmentType(String equipmentTypeId, String sortKey, Criteria criteria) {
    if (!StringUtils.isNullOrEmpty(equipmentTypeId) || sortKey.equalsIgnoreCase(EquipmentConstants.EQUIPMENT_TYPE)) {
      criteria.createAlias("eq.equipmentType", "et");
      if (!StringUtils.isNullOrEmpty(equipmentTypeId)) {
        criteria.add(Restrictions.eq("et.id", Long.valueOf(equipmentTypeId)));
      }
    }
  }

  private void addCriteriaForArea(String areaId, String sortKey, Criteria criteria) {
    if (!StringUtils.isNullOrEmpty(areaId) ||
        sortKey.equalsIgnoreCase(EquipmentConstants.AREA)) {
      criteria.createAlias("eq.area", "a");
      if (!StringUtils.isNullOrEmpty(areaId)) {
        criteria.add(Restrictions.eq("a.id", Long.valueOf(areaId)));
      }
    }
  }

  private void addLikeRestrictionsIfNotNull(Criteria criteria, String propertyName, String value) {
    value = StringUtils.trimNullable(value);
    if (!StringUtils.isNullOrEmpty(value)) {
      criteria.add(Restrictions.like(propertyName, "%" + value + "%").ignoreCase());
    }
  }

  private String updateSortKey(String sortKey) {
    String qualifiedSortKey = equipmentSortKeyMap.get(sortKey);
    if (qualifiedSortKey != null) {
      return qualifiedSortKey;
    }
    return sortKey;
  }
}