package com.monsanto.eas.eis.projects.dao;

import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.wst.dao.GenericDAO;

import java.util.List;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 9, 2008
 * Time: 2:37:55 PM
 * To change this template use File | Settings | File Templates.
 */
public interface EquipmentDAO extends GenericDAO<Equipment, Long> {
  void delete(Equipment equipment);
  PaginatedResult findBySearchCriteria(String projectId, String equipmentNumber, String equipmentName,
                                       String processLineNum, String equipmentTypeId,
                                       String areaId, String vendor,
                                       String existingEquipmentNumber, String sortKey, String sortDir, int startIndex,
                                       int maxResults);

  void clearHibernateSession();

  Equipment findByPrimaryKey(Long id);
}
