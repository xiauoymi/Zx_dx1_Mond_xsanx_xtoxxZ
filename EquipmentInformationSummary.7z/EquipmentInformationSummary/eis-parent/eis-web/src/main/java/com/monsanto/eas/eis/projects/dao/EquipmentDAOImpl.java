package com.monsanto.eas.eis.projects.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.util.EquipmentConstants;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

/**
 * Created by IntelliJ IDEA. User: afhyat Date: Sep 9, 2008 Time: 2:36:42 PM To change this template use File | Settings
 * | File Templates.
 */
public class EquipmentDAOImpl extends HibernateDAO<Equipment, Long> implements EquipmentDAO {

  public EquipmentDAOImpl(HibernateFactory hibernate) {
    super(hibernate, Equipment.class);
  }

  public EquipmentDAOImpl() {
    super(EISHibernateUtil.getHibernateFactory(), Equipment.class);
  }

  public void delete(Equipment equipment) {
    equipment.setDeleted(true);
    save(equipment);
  }

  public Equipment findByPrimaryKey(Long id) {
    Criteria criteria = getCriteria();    
    criteria.add(Restrictions.eq("id", id));
    criteria.setFetchMode("motors", FetchMode.JOIN);
    criteria.setFetchMode("instruments", FetchMode.JOIN);
    criteria.setFetchMode("accessories", FetchMode.JOIN);
    criteria.setFetchMode("process.processFieldEquipmentTypes", FetchMode.JOIN);
    return (Equipment) criteria.uniqueResult();
  }

  public PaginatedResult findBySearchCriteria(String projectId, String equipmentNumber, String equipmentName,
                                              String processLineNum, String equipmentTypeId, String areaId,
                                              String vendor,
                                              String existingEquipmentNumber, String sortKey, String sortDir,
                                              int startIndex, int maxResults) {
    Criteria criteria = getCriteria();
    criteria.add(Restrictions.eq("projects.id", new Long(projectId)));

    sortKey = addCriteriaForArea(areaId, sortKey, criteria);
    sortKey = addCriteriaForEquipmentType(equipmentTypeId, sortKey, criteria);
    addLikeRestrictionsIfNotNull(criteria, "equipmentNumber", equipmentNumber);
    addLikeRestrictionsIfNotNull(criteria, "name", equipmentName);
    addLikeRestrictionsIfNotNull(criteria, "processLineNumber", processLineNum);
    addLikeRestrictionsIfNotNull(criteria, "existingEquipmentNumber", existingEquipmentNumber);
    sortKey = addCriteriaForVendor(vendor, sortKey, criteria);

    if (sortDir.equalsIgnoreCase("asc")) {
      criteria.addOrder(Order.asc(sortKey));
    } else {
      criteria.addOrder(Order.desc(sortKey));
    }

    criteria.setProjection(Projections.rowCount());
    Integer totalRecords = (Integer) criteria.uniqueResult();

    criteria.setProjection(null);
    criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
    criteria.setFirstResult(startIndex);
    if (totalRecords.intValue() <= maxResults) {
      maxResults = totalRecords.intValue();
    }
    criteria.setMaxResults(maxResults);

    return new PaginatedResult(totalRecords.intValue(), criteria.list());
  }

  public void clearHibernateSession() {
    getHibernate().getSession().clear();
  }

  protected Criteria getCriteria() {
    return createCriteria();
  }

  private String addCriteriaForVendor(String vendor, String sortKey, Criteria criteria) {
    if (!StringUtils.isNullOrEmpty(vendor) || sortKey.equalsIgnoreCase(EquipmentConstants.VENDOR)) {
      criteria.createAlias("purchasing", "pu");
      if (!StringUtils.isNullOrEmpty(vendor)) {
        criteria.add(Restrictions.like("pu.vendor", "%" + vendor + "%").ignoreCase());
      }
      if (sortKey.equalsIgnoreCase(EquipmentConstants.VENDOR)) {
        sortKey = "pu.vendor";
      }
    }
    return sortKey;
  }

  private String addCriteriaForEquipmentType(String equipmentTypeId, String sortKey, Criteria criteria) {
    if (!StringUtils.isNullOrEmpty(equipmentTypeId) || sortKey.equalsIgnoreCase(EquipmentConstants.EQUIPMENT_TYPE)) {
      criteria.createAlias("equipmentType", "et");
      if (!StringUtils.isNullOrEmpty(equipmentTypeId)) {
        criteria.add(Restrictions.eq("et.id", Long.valueOf(equipmentTypeId)));
      }
      if (sortKey.equalsIgnoreCase(EquipmentConstants.EQUIPMENT_TYPE)) {
        sortKey = "et.name";
      }
    }
    return sortKey;
  }

  private String addCriteriaForArea(String areaId, String sortKey, Criteria criteria) {
    if (!StringUtils.isNullOrEmpty(areaId) || sortKey.equalsIgnoreCase(EquipmentConstants.AREA)) {
      criteria.createAlias("area", "a");
      if (!StringUtils.isNullOrEmpty(areaId)) {
        criteria.add(Restrictions.eq("a.id", Long.valueOf(areaId)));
      }
      if (sortKey.equalsIgnoreCase(EquipmentConstants.AREA)) {
        sortKey = "a.areaCode";
      }
    }
    return sortKey;
  }

  private void addLikeRestrictionsIfNotNull(Criteria criteria, String propertyName, String value) {
    value = StringUtils.trimNullable(value);
    if (!StringUtils.isNullOrEmpty(value))
      criteria.add(Restrictions.like(propertyName, "%" + value + "%").ignoreCase());
  }
}
