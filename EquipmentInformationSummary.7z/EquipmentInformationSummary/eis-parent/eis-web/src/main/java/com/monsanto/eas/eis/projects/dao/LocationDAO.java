package com.monsanto.eas.eis.projects.dao;

import com.monsanto.eas.eis.projects.domain.Location;
import com.monsanto.wst.dao.GenericDAO;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vvvelu
 * Date: Sep 17, 2008
 * Time: 2:34:47 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LocationDAO extends GenericDAO<Location, Long> {

  public List<Location> findByRegion();

  
}
