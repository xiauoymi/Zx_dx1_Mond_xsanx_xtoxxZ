package com.monsanto.eas.eis.projects.dao;

import com.monsanto.eas.eis.projects.domain.Location;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vvvelu
 * Date: Sep 13, 2008
 * Time: 1:39:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationDAOImpl extends HibernateDAO<Location, Long> implements LocationDAO{
  public LocationDAOImpl() {
    super(EISHibernateUtil.getHibernateFactory(), Location.class);
  }

  public List<Location> findByRegion() {
    Criteria crit = createCriteria();
//    Long[] regionIds = new Long[] {1L, 2L};
//    crit.add(Restrictions.in("id", regionIds));
    crit.add(Restrictions.isNull("parentLocation.id"));
    crit.addOrder(Order.asc("name").ignoreCase());
    List<Location> list = crit.list();
    return list;
  }
}
