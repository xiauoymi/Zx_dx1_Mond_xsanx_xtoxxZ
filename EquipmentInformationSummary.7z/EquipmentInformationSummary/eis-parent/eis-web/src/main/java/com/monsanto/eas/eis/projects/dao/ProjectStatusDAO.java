package com.monsanto.eas.eis.projects.dao;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 18, 2008
 * Time: 2:29:18 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProjectStatusDAO extends GenericDAO<ProjectStatus, Long> {

  List<ProjectStatus> findAllExcludingDelete();

  List<ProjectStatus> findAllActiveStatus();

  List<ProjectStatus> findAllInActiveStatus();
}
