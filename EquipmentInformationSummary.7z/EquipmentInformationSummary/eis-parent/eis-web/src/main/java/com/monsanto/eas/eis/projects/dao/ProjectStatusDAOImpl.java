package com.monsanto.eas.eis.projects.dao;

import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Order;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 18, 2008
 * Time: 2:33:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProjectStatusDAOImpl extends HibernateDAO<ProjectStatus, Long> implements ProjectStatusDAO {

  public ProjectStatusDAOImpl() {
    this (EISHibernateUtil.getHibernateFactory());
  }

  public ProjectStatusDAOImpl(HibernateFactory hibernateFactory ) {
    super (hibernateFactory, ProjectStatus.class);
  }

  public List<ProjectStatus> findAllExcludingDelete() {
    Criteria crit = createCriteria();
    ProjectStatus status = new ProjectStatus();
    //todo replace by getDeletedStatus
    status.setId(5L);
    status.setName("Deleted");
    crit.add(Restrictions.not(Example.create(status)));
    //crit.addOrder(Order.asc("name").ignoreCase());
    return crit.list();
  }

  public List<ProjectStatus> findAllActiveStatus() {
    Criteria crit = createCriteria();
    crit.add(Restrictions.in("id", new Object[] {1L, 2L}));
    crit.addOrder(Order.asc("name").ignoreCase());
    return crit.list();
  }

  public List<ProjectStatus> findAllInActiveStatus() {
    Criteria crit = createCriteria();
    crit.add(Restrictions.in("id", new Object[] {3L, 4L}));
    crit.addOrder(Order.asc("name").ignoreCase());
    return crit.list();
    
  }

}
