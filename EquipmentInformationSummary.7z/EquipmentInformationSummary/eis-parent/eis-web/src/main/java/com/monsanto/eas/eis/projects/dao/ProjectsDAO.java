package com.monsanto.eas.eis.projects.dao;

import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.ProjectUserRole;
import com.monsanto.eas.eis.alert.domain.AlertForProjectRoleAndStatus;
import com.monsanto.wst.dao.GenericDAO;

import java.util.List;
import java.util.Date;

public interface ProjectsDAO extends GenericDAO<Projects, Long> {
  PaginatedResult findBySearchCriteria(String projectNumber, String regionId, String countryId, String stateId,
                                      String cityId,
                                      String cropID, String statusID, boolean activeProjects, String sortKey,
                                      String sortDir, int startIndex, int maxResults);
  void archive(Projects project);

  PaginatedResult lookupVerificationsNotApprovedForAnEquipment(String projectId,
                                                                      String userId, String sortKey,
                                                                      String sortDir, int startIndex, int maxResults);

  List<AlertForProjectRoleAndStatus> lookupAllStatusAndRoleChangesInAllProjectsForAUser(
      List<ProjectUserRole> projectUserRoles, String sortKey, String sortDir);
}
