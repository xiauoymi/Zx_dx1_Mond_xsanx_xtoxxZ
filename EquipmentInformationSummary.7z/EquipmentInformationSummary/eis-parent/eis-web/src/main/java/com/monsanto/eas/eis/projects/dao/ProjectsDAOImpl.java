package com.monsanto.eas.eis.projects.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import com.monsanto.eas.eis.projects.domain.ProjectUserRole;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.alert.domain.Alert;
import com.monsanto.eas.eis.alert.domain.AlertForEquipment;
import com.monsanto.eas.eis.alert.domain.AlertForProjectRoleAndStatus;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Projections;

import java.util.*;

public class ProjectsDAOImpl extends HibernateDAO<Projects, Long> implements ProjectsDAO {
  private final GenericDAO<ProjectStatus, Long> projectStatusDAO;

  public void delete(Projects project) {
    project.setProjStatus(projectStatusDAO.findByPrimaryKey(5L));
    save(project);
  }

  public ProjectsDAOImpl() {
    this(EISHibernateUtil.getHibernateFactory(),
        new HibernateDAO<ProjectStatus, Long>(EISHibernateUtil.getHibernateFactory(), ProjectStatus.class)
    );
  }

  protected ProjectsDAOImpl(HibernateFactory hibernate,
                            GenericDAO<ProjectStatus, Long> projectStatusDAO) {
    super(hibernate, Projects.class);
    this.projectStatusDAO = projectStatusDAO;
  }

  public PaginatedResult findBySearchCriteria(String projectNumber, String regionId, String countryId, String stateId,
                                              String cityId, String cropID, String statusID, boolean activeProjects,
                                              String sortKey, String sortDir, int startIndex, int maxResults) {

    Criteria criteria = getCriteria();
    addRestrictionForEntity(cropID, criteria, "crop", "cr", "cr.id");
    addRestrictionForEntity(regionId, criteria, "region", "re", "re.id");
    addRestrictionForEntity(countryId, criteria, "country", "co", "co.id");
    addRestrictionForEntity(stateId, criteria, "state", "st", "st.id");
    sortKey = addRestrictionForCity(cityId, sortKey, criteria);
    sortKey = addRestrictionForStatus(statusID, sortKey, criteria, activeProjects);
    addLikeRestrictionsIfNotNull(criteria, "projNumber", projectNumber);

    criteria.setProjection(Projections.rowCount());
    Integer totalRecords = (Integer) criteria.uniqueResult();

    if (sortDir.equalsIgnoreCase("asc")) {
      criteria.addOrder(Order.asc(sortKey));
    } else {
      criteria.addOrder(Order.desc(sortKey));
    }

    criteria.setProjection(null);
    criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
    criteria.setFirstResult(startIndex);
    if(totalRecords.intValue() <= maxResults){
      maxResults = totalRecords.intValue();
    }
    criteria.setMaxResults(maxResults);

    return new PaginatedResult(totalRecords.intValue(), criteria.list());
  }

  //todo refactor this to not use hard coded status ids
  private String addRestrictionForStatus(String statusID, String sortKey, Criteria criteria, boolean activeProjects) {
    criteria.createAlias("projStatus", "ps");
    criteria.add(Restrictions.ne("ps.id", new Long(5L)));
    if (StringUtils.isNullOrEmpty(statusID)) {
      criteria.add(Restrictions.in("ps.id", getStatusIds(activeProjects)));
    } else {
      criteria.add(Restrictions.eq("ps.id", Long.valueOf(statusID)));
    }
    if (sortKey.equalsIgnoreCase("projStatusName")) {
      sortKey = "ps.name";
    }
    return sortKey;
  }

  private Long[] getStatusIds(boolean activeProjects) {
    Long[] list = new Long[2];
    if (activeProjects) {
      list[0] = new Long(1L);
      list[1] = new Long(2L);
    } else {
      list[0] = new Long(3L);
      list[1] = new Long(4L);
    }
    return list;
  }

  private String addRestrictionForCity(String cityId, String sortKey, Criteria criteria) {
    if (!StringUtils.isNullOrEmpty(cityId) || sortKey.equalsIgnoreCase("cityName")) {
      criteria.createAlias("city", "ci");
      if (!StringUtils.isNullOrEmpty(cityId)) {
        criteria.add(Restrictions.eq("ci.id", Long.valueOf(cityId)));
      }
      if (sortKey.equalsIgnoreCase("cityName")) {
        sortKey = "ci.name";
      }
    }
    return sortKey;
  }

  private void addRestrictionForEntity(String cropId, Criteria criteria, String restrictionEntity, String alias, String aliasId) {
    if (!StringUtils.isNullOrEmpty(cropId)) {
      if (!StringUtils.isNullOrEmpty(cropId)) {
        criteria.createAlias(restrictionEntity, alias);
        criteria.add(Restrictions.eq(aliasId, Long.valueOf(cropId)));
      }
    }
  }

  public Criteria getCriteria() {
    return super.createCriteria();
  }

  private void addLikeRestrictionsIfNotNull(Criteria criteria, String propertyName, String value) {
    value = StringUtils.trimNullable(value);
    if (!StringUtils.isNullOrEmpty(value))
      criteria.add(Restrictions.like(propertyName, "%" + value + "%").ignoreCase());
  }

  public void archive(Projects project) {
    // todo : include code to archive project
  }

  public PaginatedResult lookupVerificationsNotApprovedForAnEquipment(String projectId,
                                                                      String userId, String sortKey,
                                                                      String sortDir, int startIndex, int maxResults){
    String countOfVerificationsNotApprovedSql = getQueryToGenerateAlertsForEquipment(projectId, sortKey, sortDir);
    Integer recordCount  = getTotalRecordCountForQuery(countOfVerificationsNotApprovedSql);

    String queryForPagination = getPaginatedRecordsForQuery(countOfVerificationsNotApprovedSql, startIndex, startIndex + maxResults);

    List result = this.getHibernate().getSession().createSQLQuery(queryForPagination)
        .addScalar("processNotVerified", Hibernate.INTEGER)
        .addScalar("mechanicalNotVerified", Hibernate.INTEGER)
        .addScalar("electricalNotVerified", Hibernate.INTEGER)
        .addScalar("id", Hibernate.INTEGER)
        .addScalar("name", Hibernate.STRING)
        .addScalar("equipmentNumber", Hibernate.STRING)
        .addScalar("projectId", Hibernate.INTEGER)
        .list();

    List<Alert> alertList = getResultList(result);
    return new PaginatedResult(recordCount.intValue(), alertList);
  }

  private List<Alert> getResultList(List result) {
    Iterator iterator = result.iterator();
    List<Alert> alertList = new ArrayList<Alert>();
    while(iterator.hasNext()){
       alertList.add(new Alert((Object[])iterator.next()));
     }
    return alertList;
  }

  private Integer getTotalRecordCountForQuery(String query) {
    String recordCountQuery = getRecordCountQuery(query);
    return (Integer)this.getHibernate().getSession().createSQLQuery(recordCountQuery)
        .addScalar("totalRecords", Hibernate.INTEGER).uniqueResult();
  }

  private String getRecordCountQuery(String query) {
    StringBuffer sqlQuery  = new StringBuffer();
    sqlQuery.append("select count(*) as totalRecords from (").append(query).append(")");
    return sqlQuery.toString();
  }

  private String getQueryToGenerateAlertsForEquipment(String projectId, String sortKey,
                                                      String sortDir) {
    StringBuffer sqlQuery  = new StringBuffer();

    sqlQuery.append(" select tranApprovalPerEquipment.processNotVerified, ")
        .append("tranApprovalPerEquipment.mechanicalNotVerified, ")
        .append("tranApprovalPerEquipment.electricalNotVerified, equip.id as id, equip.name as name, ")
        .append("equip.equipment_number as equipmentNumber, p.id as projectId ")
        .append("from eis.eis_projects p ")
        .append("inner join eis.eis_equipment equip on equip.projects_id = p.id  ")
        .append("inner join (select approvalCount.* from ( select ")
        .append("sum(decode(ata.process, null, 1, 0)) as processNotVerified, ")
        .append("sum(decode(ata.mechanical,null, 1, 0)) as mechanicalNotVerified, ")
        .append("sum(decode(ata.electrical,null, 1, 0))  as electricalNotVerified, ")
        .append("e.id as id from eis.eis_equipment e,  ")
        .append("eis.audit_transaction_approval ata ").append(" where ata.change_datetime IN ( ")
        .append("SELECT MAX(tranapproval.change_datetime) FROM eis.audit_transaction_approval tranapproval,")
        .append("eis.eis_equipment e1  WHERE tranapproval.equipment_id = e1.id\n")
        .append("AND e1.id = e.id  GROUP BY tranapproval.column_name ) ")
       .append("and e.projects_id = ").append(projectId).append("  and nvl(e.is_deleted, 'N') <> 'Y' ")
       .append("group by e.id) approvalCount where (approvalCount.processNotVerified > 0 or ")
        .append("approvalCount.mechanicalNotVerified > 0 or approvalCount.electricalNotVerified > 0))tranApprovalPerEquipment on tranApprovalPerEquipment.id = equip.id  ")
       .append("where p.id = ").append(projectId).append(" order by ").append(sortKey).append(" ").append(sortDir);
    return sqlQuery.toString();
  }


   private String getPaginatedRecordsForQuery(String query, int startIndex, int maxResults) {
    StringBuffer sqlQuery  = new StringBuffer();
    sqlQuery.append("select * from (select").append(" row_.*, rownum rownum_  from (")
        .append(query).append(") row_ where rownum <=").append(maxResults).append(") where rownum_ > ")
        .append(startIndex);
    return sqlQuery.toString();
  }

  public PaginatedResult lookupAllEquipmentsAddedAndDeleted(String projectId, String sortKey, String sortDir,
                                                            int startIndex, int maxResults){
    StringBuffer sqlQuery = getQueryToGetAllEquipmentsAddedAndDeletedFromAProjectInThePastTwentyDays(projectId, sortKey,
        sortDir);

    Integer recordCount  = getTotalRecordCountForQuery(sqlQuery.toString());

    String queryForPagination = getPaginatedRecordsForQuery(sqlQuery.toString(), startIndex, startIndex + maxResults);

    List result = this.getHibernate().getSession().createSQLQuery(queryForPagination)
        .addScalar("id", Hibernate.INTEGER)
        .addScalar("equipmentNumber", Hibernate.STRING)
        .addScalar("dateModified", Hibernate.DATE)
        .addScalar("addedOrDeleted", Hibernate.STRING)
        .addScalar("modifiedBy", Hibernate.STRING)
        .addScalar("projectId", Hibernate.INTEGER)
        .list();

    List<AlertForEquipment> alertList = getResultListForEquipmentChanges(result);
    return new PaginatedResult(recordCount.intValue(), alertList);
  }

  private StringBuffer getQueryToGetAllEquipmentsAddedAndDeletedFromAProjectInThePastTwentyDays(String projectId,
                                                                                                String sortKey,
                                                                                                String sortDir) {
    StringBuffer sqlQuery = new StringBuffer();
    sqlQuery.append(" select equipment.id as id, equipment.equipment_number as equipmentNumber, ")
        .append("  h.change_datetime dateModified, h.operation_type addedOrDeleted, ")
        .append("  t.audit_requestor modifiedBy,  ")
        .append("  equipment.projects_id projectId  ")
        .append("  from eis.audit_header_view_ins_del h, ")
        .append("      eis.eis_equipment equipment, ")
        .append("      eis.audit_transaction t, ")
        .append("      eis.eis_user u ")
        .append("  where h.key_value = to_char(equipment.id) ")
        .append("  and h.table_name = 'EIS_EQUIPMENT' ")
        .append("  and h.operation_type in ('I', 'D') ")
        .append("  and h.change_datetime between (systimestamp - 20) and systimestamp  ")
        .append("  and h.change_datetime >= (select max(h1.change_datetime) from eis.audit_header h1 ")
        .append(" left outer join eis.audit_detail d1 on d1.audit_header_id = h1.audit_header_id")
        .append(" where key_value = '").append(projectId) .append("'")
        .append(" and d1.column_name = 'STATUS_ID' and d1.new_value = (select id from eis.eis_proj_status where status_name = 'Detailed Design'))")
        .append("  and t.audit_transaction_id = h.audit_transaction_id  ")
        .append("  and t.audit_requestor = u.user_id ")
        .append("  and equipment.id in (select id from eis.eis_equipment eq where eq.projects_id  = ").append(projectId) .append(")")
        .append(" order by ").append(sortKey).append(" ").append(sortDir);
    return sqlQuery;
  }

  private StringBuffer getQueryToGetAllRoleAndStatusChangeForAProjectInThePastTwentyDays(String projectIds,
                                                                                         String sortKey, String sortDir) {
    StringBuffer sqlQuery = new StringBuffer();
    sqlQuery.append("SELECT modifiedby, change_datetime AS changeDateTime, ")
        .append("psv.TABLE_NAME AS tablename, p.proj_number projectnumber, ")
        .append("p.id id FROM eis.audit_proj_status_view psv, eis.eis_projects p ")
        .append("WHERE psv.TABLE_NAME = 'EIS_PROJECTS' ")
        .append("AND psv.key_value IN(").append(projectIds).append(") ")
        .append("AND psv.key_value = to_char(p.id) ")
        .append("UNION ")
        .append("select t.audit_requestor modifiedBy, innerQuery.* from ").append(" ( ")
        .append("select max(change_datetime) AS changeDateTime, ")
        .append("psv.TABLE_NAME AS tablename, ")
        .append("p.proj_number projectnumber, p.id as id ")
        .append("FROM eis.AUD_PROJ_STAT_ROLE_CHG_VIEW psv, ").append("        eis.eis_proj_user_role pur, ")
        .append("eis.eis_projects p WHERE psv.TABLE_NAME = 'EIS_PROJ_USER_ROLE' ")
        .append("AND psv.key_value IN(").append(projectIds).append(") ")
        .append("AND psv.key_value = to_char(pur.id) ").append("       AND pur.project_id = p.id ")
        .append("group by p.id, psv.TABLE_NAME, p.proj_number, p.id ").append("       )innerQuery ")
        .append("left outer join eis.audit_header h on h.change_datetime = innerQuery.changeDateTime ")
        .append("left outer join eis.audit_transaction t on t.audit_transaction_id = h.audit_transaction_id ")
        .append("order by ").append(sortKey).append(" ").append(sortDir);

    return sqlQuery;
  }

  private List<AlertForEquipment> getResultListForEquipmentChanges(List result) {
    Iterator iterator = result.iterator();
    List<AlertForEquipment> alertList = new ArrayList<AlertForEquipment>();
    while(iterator.hasNext()){
       alertList.add(new AlertForEquipment((Object[])iterator.next()));
     }
    return alertList;
  }

  public List<AlertForProjectRoleAndStatus> lookupAllStatusAndRoleChangesInAllProjectsForAUser(
      List<ProjectUserRole> projectUserRoles, String sortKey, String sortDir) {

    String projIds = getStringOfProjectIds(projectUserRoles);

    StringBuffer query = getQueryToGetAllRoleAndStatusChangeForAProjectInThePastTwentyDays(projIds, sortKey, sortDir);
    List result = this.getHibernate().getSession().createSQLQuery(query.toString())
        .addScalar("modifiedBy", Hibernate.STRING)
        .addScalar("changeDateTime", Hibernate.DATE)
        .addScalar("tablename", Hibernate.STRING)
        .addScalar("projectNumber", Hibernate.STRING)
        .addScalar("id", Hibernate.INTEGER)
        .list();

    Iterator iterator = result.iterator();
    List<AlertForProjectRoleAndStatus> alertList = new ArrayList<AlertForProjectRoleAndStatus>();
    while(iterator.hasNext()){
      AlertForProjectRoleAndStatus roleAndStatus = new AlertForProjectRoleAndStatus((Object[]) iterator.next());
      alertList.add(roleAndStatus);
    }

    return alertList;
  }

  private String getStringOfProjectIds(List<ProjectUserRole> projectUserRoles) {
    StringBuffer formattedProjectIds = new StringBuffer();

    Set<Projects> projects = new HashSet<Projects>();
    for (ProjectUserRole projectUserRole: projectUserRoles){
      if (!projects.contains(projectUserRole.getProject())){
        projects.add(projectUserRole.getProject());
        formattedProjectIds.append(projectUserRole.getProject().getFormattedId());
      }
      formattedProjectIds.append(projectUserRole.getFormattedId());
    }

    return formattedProjectIds.length() > 0 ? formattedProjectIds.substring(0, formattedProjectIds.toString().length() - 1)
        :null;
  }
}
