package com.monsanto.eas.eis.projects.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.controller.XmlDataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.services.ProjectsServiceImpl;
import com.monsanto.eas.eis.util.EISConstants;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Dec 17, 2008 Time: 5:54:46 PM To change this template use File |
 * Settings | File Templates.
 */
public class ProjectUserRoleDataSource implements XmlDataSource {
  private UCCHelper helper;
  private ProjectsService projectService;

  public ProjectUserRoleDataSource(UCCHelper helper) {
    this(helper, new ProjectsServiceImpl());
  }

  public ProjectUserRoleDataSource(UCCHelper helper, ProjectsService projectService) {
    this.helper = helper;
    this.projectService = projectService;
  }

  public List<? extends XmlObject> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws
      IOException {
    String projectId = helper.getRequestParameterValue(EISConstants.PROJECT_ID);
    String projectRole = helper.getRequestParameterValue(EISConstants.PROJECT_ROLE);
    if (StringUtils.isBlank(projectId)) {
      return Collections.emptyList();
    } else {
      Projects projects = projectService.lookupProjectById(Long.valueOf(projectId));
      return projects.getProjectUserRoles(projectRole);
    }
  }

  public int getTotalRecords() {
    return DataSource.UNKNOWN_RECORD_COUNT;
  }
}
