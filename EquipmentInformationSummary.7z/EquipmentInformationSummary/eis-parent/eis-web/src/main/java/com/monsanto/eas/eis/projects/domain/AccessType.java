/*
 AccessType was created on Dec 26, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: AccessType.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2009-01-01 23:33:34 $
 *
 * @author SSPATI1
 * @version $Revision: 1.1 $
 */
@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_ACCESS_TYPE")
public class AccessType {
  @Id
  @SequenceGenerator(name = "seqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqGen")
  @Column(name = "ID")
  private Long id;

  @Column(name = "ACCESS_TYPE")
	private String accessType;

  public AccessType() {
  }

  public AccessType(Long id, String accessType) {
    this.id = id;
    this.accessType = accessType;
  }

  public Long getId() {
    return id;
  }

  public String getAccessType() {
    return accessType;
  }
}