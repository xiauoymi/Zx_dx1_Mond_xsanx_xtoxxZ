/*
 Accessory was created on Nov 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.eas.eis.Copyable;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: Accessory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 15:31:29 $
 *
 * @author sspati1
 * @version $Revision: 1.14 $
 */
@Entity
@AccessType("field")
@Table(schema = "EIS", name = "EIS_ACCESSORY")
public class Accessory implements XmlObject, Copyable, Comparable {
  @Id
  @SequenceGenerator(name = "equipmentSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "equipmentSeqGen")
  @Column(name = "ID")
  private Long id;

  @Column(name = "PURCHASED_WITH_EQUIP")
  @Type(type = "yes_no")
  private boolean purchasedWithEquipment;

  @Column(name = "ACCE_NAME")
  private String accessoryName;

  @ManyToOne
  @JoinColumn(name = "ACCE_DESIGNATOR_ID")
  private AccessoryDesignator accessoryDesignator;

  @Column(name = "SEQ_NUM")
  private String sequenceNumber;

  @Column(name = "QUANTITY")
  private Integer quantity;

  @Column(name = "DESCRIPTION")
  private String acceDescription;

  @Column(name = "COMMENTS")
  private String comments;

  @Column(name = "COMP_AIR_REQD")
  @Type(type = "yes_no")
  private boolean compAirReqd;

  @Column(name = "GAS_REQD")
  @Type(type = "yes_no")
  private boolean gasReqd;

  @Column(name = "WATER_REQD")
  @Type(type = "yes_no")
  private boolean waterReqd;

  @Column(name = "UTILITY_FLOWRATE")
  private String utilityFlowrate;

  @Column(name = "SELF_CLEANING")
  @Type(type = "yes_no")
  private boolean selfCleaning;

  @Column(name = "ACCE_SIZE")
  private Integer size;

  @ManyToOne
  @JoinColumn(name = "AUTO_MANUAL_ID")
  private AutoManual autoManual;

  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "ELECTRICAL_ID")
  private Electrical electrical;

  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "PURCHASING_ID")
  private Purchasing purchasing;

  @ManyToOne(fetch=FetchType.LAZY) 
  @JoinColumn(name = "EQUIPMENT_ID")
  private Equipment equipment;

  @Column(name = "IS_DELETED")
  @Type(type = "yes_no")
  private boolean isDeleted;

  @Column(name="ESTIMATED_COST")
  private Integer estimatedCost;

  @Column(name="ACTUAL_COST")
  private Integer actualCost;

  @Column(name="BID_PACKAGE")
  private String bidPackage;

  public Accessory() {
  }

  public Accessory(Long id, boolean purchasedWithEquipment, String accessoryName,
                   AccessoryDesignator accessoryDesignator,
                   String sequenceNumber, Integer quantity, String acceDescription, String comments,
                   boolean compAirReqd,
                   boolean gasReqd, boolean waterReqd, String utilityFlowrate, boolean selfCleaning, Integer size,
                   AutoManual autoManual, Electrical electrical, Purchasing purchasing, Equipment equipment,
                   Integer estimatedCost, Integer actualCost, String bidPackage) {
    this.id = id;
    this.purchasedWithEquipment = purchasedWithEquipment;
    this.accessoryName = accessoryName;
    this.accessoryDesignator = accessoryDesignator;
    this.sequenceNumber = sequenceNumber;
    this.quantity = quantity;
    this.acceDescription = acceDescription;
    this.comments = comments;
    this.compAirReqd = compAirReqd;
    this.gasReqd = gasReqd;
    this.waterReqd = waterReqd;
    this.utilityFlowrate = utilityFlowrate;
    this.selfCleaning = selfCleaning;
    this.size = size;
    this.autoManual = autoManual;
    this.electrical = electrical;
    this.purchasing = purchasing;
    this.equipment = equipment;
    this.estimatedCost = estimatedCost;
    this.actualCost = actualCost;
    this.bidPackage = bidPackage;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public boolean isPurchasedWithEquipment() {
    return purchasedWithEquipment;
  }

  public String getAccessoryName() {
    return accessoryName;
  }

  public AccessoryDesignator getAccessoryDesignator() {
    return accessoryDesignator;
  }

  public String getSequenceNumber() {
    return sequenceNumber;
  }

  public Integer getQuantity() {
    return (quantity == null) ? new Integer(1): quantity;
  }

  public String getAcceDescription() {
    return acceDescription;
  }

  public String getComments() {
    return comments;
  }

  public boolean isCompAirReqd() {
    return compAirReqd;
  }

  public boolean isGasReqd() {
    return gasReqd;
  }

  public boolean isWaterReqd() {
    return waterReqd;
  }

  public String getUtilityFlowrate() {
    return utilityFlowrate;
  }

  public boolean isSelfCleaning() {
    return selfCleaning;
  }

  public Integer getSize() {
    return size;
  }

  public AutoManual getAutoManual() {
    return autoManual;
  }

  public Electrical getElectrical() {
    return electrical;
  }

  public Purchasing getPurchasing() {
    return purchasing;
  }

  public Equipment getEquipment() {
    return equipment;
  }

  public boolean isDeleted() {
    return isDeleted;
  }

  public void setDeleted(boolean deleted) {
    isDeleted = deleted;
  }

  public void setAccessoryName(String accessoryName) {
    this.accessoryName = accessoryName;
  }

  public void setQuantity(Integer quantity) {
    this.quantity = quantity;
  }

  public void setAcceDescription(String acceDescription) {
    this.acceDescription = acceDescription;
  }

  public void setPurchasedWithEquipment(boolean purchasedWithEquipment) {
    this.purchasedWithEquipment = purchasedWithEquipment;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public void setCompAirReqd(boolean compAirReqd) {
    this.compAirReqd = compAirReqd;
  }

  public void setGasReqd(boolean gasReqd) {
    this.gasReqd = gasReqd;
  }

  public void setWaterReqd(boolean waterReqd) {
    this.waterReqd = waterReqd;
  }

  public void setUtilityFlowrate(String utilityFlowrate) {
    this.utilityFlowrate = utilityFlowrate;
  }

  public void setSelfCleaning(boolean selfCleaning) {
    this.selfCleaning = selfCleaning;
  }

  public void setSize(Integer size) {
    this.size = size;
  }

  public void setAutoManual(AutoManual autoManual) {
    this.autoManual = autoManual;
  }

  public void setPurchasing(Purchasing purchasing) {
    this.purchasing = purchasing;
  }

  public void setElectrical(Electrical electrical) {
    this.electrical = electrical;
  }

  public void setEquipment(Equipment equipment) {
    this.equipment = equipment;
  }

  public String getBidPackage() {
    return bidPackage;
  }

  public void setBidPackage(String bidPackage) {
    this.bidPackage = bidPackage;
  }


  public Accessory createCopy() throws CloneNotSupportedException {
    Accessory accessory = (Accessory) super.clone();
    accessory.setId(null);
    accessory.setElectrical(getElectrical().createCopy());
    accessory.setPurchasing(getPurchasing().createCopy());
    return accessory;
  }

  public String toXml() {
    XMLBuffer xmlStr = new XMLBuffer("<accessory>");
    xmlStr.append(getEquipment().toXmlWithBasicFields());
    xmlStr.append("<acceId>");
    xmlStr.appendValue(getId()).append("</acceId>");
    xmlStr.append("<accessoryName>");
    xmlStr.appendValue(getAccessoryName()).append("</accessoryName>");
    xmlStr.append("<purchasedWithEquipment>");
    xmlStr.appendValue(new Boolean(isPurchasedWithEquipment()))
        .append("</purchasedWithEquipment>");
    appendAccessoryDesignatorXml(xmlStr);
    xmlStr.append("<sequenceNumber>");
    xmlStr.appendValue(getSequenceNumber()).append("</sequenceNumber>");
    xmlStr.append("<quantity>");
    xmlStr.appendValue(getQuantity()).append("</quantity>");
    xmlStr.append("<acceDescription>");
    xmlStr.appendValue(getAcceDescription()).append("</acceDescription>");
    xmlStr.append("<comments>");
    xmlStr.appendValue(getComments()).append("</comments>");
    xmlStr.append("<compAirReqd>");
    xmlStr.appendValue(new Boolean(isCompAirReqd())).append("</compAirReqd>");
    xmlStr.append("<gasReqd>");
    xmlStr.appendValue(new Boolean(isGasReqd())).append("</gasReqd>");
    xmlStr.append("<waterReqd>");
    xmlStr.appendValue(new Boolean(isWaterReqd())).append("</waterReqd>");
    xmlStr.append("<utilityFlowrate>");
    xmlStr.appendValue(getUtilityFlowrate()).append("</utilityFlowrate>");
    xmlStr.append("<selfCleaning>");
    xmlStr.appendValue(new Boolean(isSelfCleaning())).append("</selfCleaning>");
    xmlStr.append("<size>");
    xmlStr.appendValue(getSize()).append("</size>");
    xmlStr.append("<autoManualId>");
    xmlStr.appendValue(getAutoManualId()).append("</autoManualId>");
    xmlStr.append(getElectrical().toXmlWithoutEquipment());
    xmlStr.append(getPurchasing().toXmlWithoutEquipment());
    xmlStr.append("<estimatedCost>");
    xmlStr.appendValue(getEstimatedCost()).append("</estimatedCost>");
    xmlStr.append("<actualCost>");
    xmlStr.appendValue(getActualCost()).append("</actualCost>");
    xmlStr.append("<bidPackage>");
    xmlStr.appendValue(getBidPackage()).append("</bidPackage>");
    xmlStr.append("</accessory>");
    return xmlStr.toString();
  }

  private Object getAutoManualId() {
    if (getAutoManual() == null) {
      return "";
    } else {
      return getAutoManual().getId();
    }
  }

  private void appendAccessoryDesignatorXml(XMLBuffer xmlStr) {
    xmlStr.append("<accessoryDesignator>");
    if (getAccessoryDesignator() == null) {
      xmlStr.append("<accessoryDesignatorId>");
      xmlStr.appendValue("").append("</accessoryDesignatorId>");
      xmlStr.append("<accessoryDesignatorTypeCode>");
      xmlStr.appendValue("").append("</accessoryDesignatorTypeCode>");
    } else {
      xmlStr.append("<accessoryDesignatorId>");
      xmlStr.appendValue(getAccessoryDesignator().getId())
          .append("</accessoryDesignatorId>");
      xmlStr.append("<accessoryDesignatorTypeCode>");
      xmlStr.appendValue(getAccessoryDesignator().getTypeCode())
          .append("</accessoryDesignatorTypeCode>");
    }
    xmlStr.append("</accessoryDesignator>");
  }

    public String getFormattedId(){
    return "'" + this.getId() + "',";
  }

  public String getAccessoryAndRelatedIds(){
    StringBuffer ids = new StringBuffer();
    ids.append(this.getFormattedId());
    if (getAccessoryDesignator() != null){
       ids.append(getAccessoryDesignator().getFormattedId());
    }
    if (this.getElectrical() != null){
      ids.append(this.getElectrical().getElectricalAndRelatedIds()).append(",");
    }
    if (this.getPurchasing() != null){
      ids.append(this.getPurchasing().getFormattedId());
    }
   return ids.toString().substring(0, ids.toString().length() - 1);
  }

  public int compareTo(Object o) {
    return id.compareTo(((Accessory)o).getId());
  }

  public Integer getEstimatedCost() {
    return estimatedCost;
  }

  public Integer getActualCost() {
    return actualCost;
  }

  public void setEstimatedCost(Integer estimatedCost) {
    this.estimatedCost = estimatedCost;
  }

  public void setActualCost(Integer actualCost) {
    this.actualCost = actualCost;
  }
}