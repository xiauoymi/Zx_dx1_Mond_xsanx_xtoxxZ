/*
 AccessoryDesignator was created on Nov 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import com.monsanto.eas.eis.util.XMLBuffer;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: AccessoryDesignator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-11 17:43:57 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_ACCE_DESIGNATOR")
public class AccessoryDesignator implements XmlObject {
  @Id
  @SequenceGenerator(name = "equipmentSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "equipmentSeqGen")
  @Column(name = "ID")
  private Long id;

  @Column(name = "VALUE")
  private String value;

  @Column(name = "TYPE_CODE")
  private String typeCode;

  public AccessoryDesignator() {
  }

  public AccessoryDesignator(Long id, String value, String typeCode) {
    this.id = id;
    this.value = value;
    this.typeCode = typeCode;
  }

  public Long getId() {
    return id;
  }

  public String getValue() {
    return value;
  }

  public String getTypeCode() {
    return typeCode;
  }

   public String getFormattedId(){
    return "'" + this.getId() + "',";
  }

  public String toXml() {
    XMLBuffer xmlStr = new XMLBuffer("<accessoryDesignator>");
    xmlStr.append("<id>");
    xmlStr.appendValue(getId()).append("</id>");
    xmlStr.append("<name>");
    xmlStr.appendValue(getTypeCode()).append(" - ");
    xmlStr.appendValue(getValue()).append("</name>");
    xmlStr.append("</accessoryDesignator>");
    return xmlStr.toString();
  }
}