package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: VVVELU Date: Aug 29, 2008 Time: 9:05:42 AM To change this template use File |
 * Settings | File Templates.
 */

@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_AREA")

public class Area implements Serializable, XmlObject {

  @Id
  @SequenceGenerator(name = "areaSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "areaSeqGen")
  @Column(name = "ID")

  private Long id;

  @Column(name = "area_code")
  private String areaCode;

  @Column(name = "description")
  private String description;

  //private String secret;

  public Area() {
  }

  public Area(Long id, String areaCode, String description) {
    this.id = id;
    this.areaCode = areaCode;
    this.description = description;

  }


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getAreaCode() {
    return areaCode;
  }

  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  public String getDescription() {
    return description;
  }

//  public String getSecret() {
//    return secret;
//  }
//
//  public void setSecret(String secret) {
//    this.secret = areaCode + " - " + description;
//  }

  //  public String getDescriptionWithAreaCode() {
//    return this.descriptionWithAreaCode;
//  }
//
//  public void setDescriptionWithAreaCode() {
//    StringBuffer stringBuffer = new StringBuffer(areaCode);
//    stringBuffer.append(" - ").append(description);
//
//    this.descriptionWithAreaCode = stringBuffer.toString();
//  }

//  public void setDescription(String description) {
//    this.description = description;
//  }

  public boolean equals(Object obj) {
    return obj == null || !(obj instanceof Area) ? false : id.equals(((Area) obj).getId());
  }

  public int hashCode() {
    return id.hashCode();
  }

  public int compareTo(Object o) {
    Area area = (Area) o;
    if (this.getAreaCode().compareTo(area.getAreaCode()) == 0)
      return 0;
    else if (this.getAreaCode().compareTo(area.getAreaCode()) > 0)
      return 1;
    else return -1;

  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<area>");
    xml.append("<id>");
    xml.appendValue(getId()).append("</id>");
    xml.append("<areaCodeDescription>");
    xml.appendValue(getAreaCode()).append(" - ");
    xml.appendValue(getDescription())
        .append("</areaCodeDescription>");
    xml.append("</area>");
    return xml.toString();
  }
}
