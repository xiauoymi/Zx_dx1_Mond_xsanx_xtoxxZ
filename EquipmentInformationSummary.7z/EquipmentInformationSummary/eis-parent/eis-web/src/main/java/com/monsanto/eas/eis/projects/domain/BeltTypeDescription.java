/*
 BeltTypeDescription was created on Dec 10, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;

import javax.persistence.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_BELT_TYPE")
public class BeltTypeDescription {
  private Long id;
  @Column(name = "TYPE_CODE")
  private String typeCode;
  @Column(name ="VALUE")
  private String value;
   @ManyToOne()
  @JoinColumn(name = "FIELD_EQUIPMENT_ID")
  private FieldEquipmentType fieldEquipmentType;

  public BeltTypeDescription() {
  }

  public BeltTypeDescription(Long id, String typeCode, String value, FieldEquipmentType fieldEquipmentType) {
    this.id = id;
    this.typeCode = typeCode;
    this.value = value;
    this.fieldEquipmentType = fieldEquipmentType;
  }
}