/*
 CostSchedule was created on Oct 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.ConvertUtil;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.eas.eis.Copyable;

import javax.persistence.*;
import java.util.Date;

/**
 * Filename:    $RCSfile: CostSchedule.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date:
 * 2008/10/27 15:46:49 $
 *
 * @author sspati1
 * @version $Revision: 1.9 $
 */
@Entity
@AccessType("field")
@Table(schema = "EIS", name = "EIS_COST_SCHEDULE")
public class CostSchedule implements XmlObject, Copyable {
  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "SCHEDULED_SPECIFICATION")
  private Date scheduledSpecificationDate;

  @Column(name = "SCHEDULED_QUOTE")
  private Date scheduledQuoteDate;

  @Column(name = "SCHEDULED_PURCHASE")
  private Date scheduledPurchaseDate;

  @Column(name = "DRAWING_TURNAROUND_TIME")
  private Integer drawingTurnaroundTime;

  @Column(name = "ESTIMATED_FABRICATION_TIME")
  private Integer estiamtedFabricationTime;

  @Column(name = "ESTIMATED_SHIPPING_DATE")
  private Date estiamtedShippingDate;

  @Column(name = "SPEC_ISSUED_DATE")
  private Date specIssuedDate;

  @Column(name = "RTQ_ENTERED")
  private Date rtqEnteredDate;

  @Column(name = "RTP_ENTERED")
  private Date rtpEnteredDate;

  @Column(name = "PREL_DRAWING_ISSUED_DATE")
  private Date prelDrawingIssuedDate;

  @Column(name = "APPROVAL_DRAWING_APPROVED")
  private Date approvalDrawingDate;

  @Column(name = "FINAL_DRAWING_COMPLETE")
  private Date finalDrawingDate;

  @Column(name = "IOM_INFO_RECEIVED")
  private Date iomReceivedDate;

  @Column(name = "ESTIMATED_COST")
  private Long estimatedCost;

  @Column(name = "ESTIMATED_SOURCE")
  private String estimatedSource;

  @ManyToOne
  @JoinColumn(name = "FUNDING_SOURCE_ID")
  private FundingSource fundingSource;

  @Column(name = "ESTIMATED_MECHANICAL_HOURS")
  private Integer estimatedMechHours;

  @Column(name = "ESCALATION_FACTOR")
  private Double escalationFactor;

  @OneToOne(mappedBy = "costSchedule")
  private Equipment equipment;

  @Column(name = "IS_DELETED")
  @Type(type = "yes_no")
  private boolean isDeleted;

  public CostSchedule() {
  }

  public CostSchedule(Long id, Date scheduledSpecifiaction, Date scheduledQuote, Date scheduledPurchase,
                      Integer drawingTurnaroundTime, Integer estiamtedFabricationTime, Date estiamtedShippingDate,
                      Date specIssuedDate, Date rtqEnteredDate, Date rtpEnteredDate, Date prelDrawingIssuedDate,
                      Date approvalDrawingDate, Date finalDrawingDate, Date ionReceivedDate, Long estimatedCost,
                      String estimatedSource, FundingSource fundingSource, Integer estimatedMechHours,
                      Double escalationFactor) {
    this.id = id;
    this.scheduledSpecificationDate = scheduledSpecifiaction;
    this.scheduledQuoteDate = scheduledQuote;
    this.scheduledPurchaseDate = scheduledPurchase;
    this.drawingTurnaroundTime = drawingTurnaroundTime;
    this.estiamtedFabricationTime = estiamtedFabricationTime;
    this.estiamtedShippingDate = estiamtedShippingDate;
    this.specIssuedDate = specIssuedDate;
    this.rtqEnteredDate = rtqEnteredDate;
    this.rtpEnteredDate = rtpEnteredDate;
    this.prelDrawingIssuedDate = prelDrawingIssuedDate;
    this.approvalDrawingDate = approvalDrawingDate;
    this.finalDrawingDate = finalDrawingDate;
    this.iomReceivedDate = ionReceivedDate;
    this.estimatedCost = estimatedCost;
    this.estimatedSource = estimatedSource;
    this.fundingSource = fundingSource;
    this.estimatedMechHours = estimatedMechHours;
    this.escalationFactor = escalationFactor;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Date getscheduledSpecificationDate() {
    return scheduledSpecificationDate;
  }

  public Date getScheduledQuoteDate() {
    return scheduledQuoteDate;
  }

  public Date getScheduledPurchaseDate() {
    return scheduledPurchaseDate;
  }

  public Integer getDrawingTurnaroundTime() {
    return drawingTurnaroundTime;
  }

  public Integer getEstiamtedFabricationTime() {
    return estiamtedFabricationTime;
  }

  public Date getEstiamtedShippingDate() {
    return estiamtedShippingDate;
  }

  public Date getSpecIssuedDate() {
    return specIssuedDate;
  }

  public Date getRtqEnteredDate() {
    return rtqEnteredDate;
  }

  public Date getRtpEnteredDate() {
    return rtpEnteredDate;
  }

  public Date getPrelDrawingIssuedDate() {
    return prelDrawingIssuedDate;
  }

  public Date getApprovalDrawingDate() {
    return approvalDrawingDate;
  }

  public Date getFinalDrawingDate() {
    return finalDrawingDate;
  }

  public Date getIomReceivedDate() {
    return iomReceivedDate;
  }

  public Long getEstimatedCost() {
    return estimatedCost;
  }

  public String getEstimatedSource() {
    return estimatedSource;
  }

  public FundingSource getFundingSource() {
    return fundingSource;
  }

  public Integer getEstimatedMechHours() {
    return estimatedMechHours;
  }

  public Equipment getEquipment() {
    return equipment;
  }

  public void setEquipment(Equipment equipment) {
    this.equipment = equipment;
  }

  public boolean isDeleted() {
    return isDeleted;
  }

  public void setDeleted(boolean deleted) {
    isDeleted = deleted;
  }

  public void setScheduledSpecificationDate(Date scheduledSpecificationDate) {
    this.scheduledSpecificationDate = scheduledSpecificationDate;
  }

  public void setScheduledQuoteDate(Date scheduledQuoteDate) {
    this.scheduledQuoteDate = scheduledQuoteDate;
  }

  public void setScheduledPurchaseDate(Date scheduledPurchaseDate) {
    this.scheduledPurchaseDate = scheduledPurchaseDate;
  }

  public void setDrawingTurnaroundTime(Integer drawingTurnaroundTime) {
    this.drawingTurnaroundTime = drawingTurnaroundTime;
  }

  public void setEstiamtedFabricationTime(Integer estiamtedFabricationTime) {
    this.estiamtedFabricationTime = estiamtedFabricationTime;
  }

  public void setEstiamtedShippingDate(Date estiamtedShippingDate) {
    this.estiamtedShippingDate = estiamtedShippingDate;
  }

  public void setSpecIssuedDate(Date specIssuedDate) {
    this.specIssuedDate = specIssuedDate;
  }

  public void setRtqEnteredDate(Date rtqEnteredDate) {
    this.rtqEnteredDate = rtqEnteredDate;
  }

  public void setRtpEnteredDate(Date rtpEnteredDate) {
    this.rtpEnteredDate = rtpEnteredDate;
  }

  public void setPrelDrawingIssuedDate(Date prelDrawingIssuedDate) {
    this.prelDrawingIssuedDate = prelDrawingIssuedDate;
  }

  public void setApprovalDrawingDate(Date approvalDrawingDate) {
    this.approvalDrawingDate = approvalDrawingDate;
  }

  public void setFinalDrawingDate(Date finalDrawingDate) {
    this.finalDrawingDate = finalDrawingDate;
  }

  public void setIomReceivedDate(Date iomReceivedDate) {
    this.iomReceivedDate = iomReceivedDate;
  }

  public void setEstimatedCost(Long estimatedCost) {
    this.estimatedCost = estimatedCost;
  }

  public void setEstimatedSource(String estimatedSource) {
    this.estimatedSource = estimatedSource;
  }

  public void setFundingSource(FundingSource fundingSource) {
    this.fundingSource = fundingSource;
  }

  public void setEstimatedMechHours(Integer estimatedMechHours) {
    this.estimatedMechHours = estimatedMechHours;
  }

  public Double getEscalationFactor() {
    return escalationFactor;
  }

  public void setEscalationFactor(Double escalationFactor) {
    this.escalationFactor = escalationFactor;
  }

  public CostSchedule createCopy() throws CloneNotSupportedException {
    CostSchedule costSchedule = (CostSchedule) super.clone();
    costSchedule.setId(null);
    return costSchedule;
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<costSchedule>");
    xml.append(getEquipment().toXmlWithBasicFields());
    xml.append("<costScheduleId>");
    xml.appendValue(returnEmptyIfNull(getId()))
        .append("</costScheduleId>");
    xml.append("<scheduledSpecificationDate>");
    xml.appendValue(formatDate(getscheduledSpecificationDate()))
        .append("</scheduledSpecificationDate>");
    xml.append("<scheduledQuoteDate>");
    xml.appendValue(formatDate(getScheduledQuoteDate()))
        .append("</scheduledQuoteDate>");
    xml.append("<scheduledPurchaseDate>");
    xml.appendValue(formatDate(getScheduledPurchaseDate()))
        .append("</scheduledPurchaseDate>");
    xml.append("<drawingTurnaroundTime>");
    xml.appendValue(returnEmptyIfNull(getDrawingTurnaroundTime()))
        .append("</drawingTurnaroundTime>");
    xml.append("<estiamtedFabricationTime>");
    xml.appendValue(returnEmptyIfNull(getEstiamtedFabricationTime()))
        .append("</estiamtedFabricationTime>");
    xml.append("<estiamtedShippingDate>");
    xml.appendValue(formatDate(getEstiamtedShippingDate()))
        .append("</estiamtedShippingDate>");
    xml.append("<specIssuedDate>");
    xml.appendValue(formatDate(getSpecIssuedDate()))
        .append("</specIssuedDate>");
    xml.append("<rtqEnteredDate>");
    xml.appendValue(formatDate(getRtqEnteredDate()))
        .append("</rtqEnteredDate>");
    xml.append("<rtpEnteredDate>");
    xml.appendValue(formatDate(getRtpEnteredDate()))
        .append("</rtpEnteredDate>");
    xml.append("<prelDrawingIssuedDate>");
    xml.appendValue(formatDate(getPrelDrawingIssuedDate()))
        .append("</prelDrawingIssuedDate>");
    xml.append("<approvalDrawingDate>");
    xml.appendValue(formatDate(getApprovalDrawingDate()))
        .append("</approvalDrawingDate>");
    xml.append("<finalDrawingDate>");
    xml.appendValue(formatDate(getFinalDrawingDate()))
        .append("</finalDrawingDate>");
    xml.append("<iomReceivedDate>");
    xml.appendValue(formatDate(getIomReceivedDate()))
        .append("</iomReceivedDate>");
    xml.append("<estimatedCost>");
    xml.appendValue(returnEmptyIfNull(getEstimatedCost()))
        .append("</estimatedCost>");
    xml.append("<estimatedSource>");
    xml.appendValue(returnEmptyIfNull(getEstimatedSource()))
        .append("</estimatedSource>");
    if (getFundingSource() == null) {
      xml.append("<fundingSourceId>").append("").append("</fundingSourceId>");
    } else {
      xml.append("<fundingSourceId>");
      xml.appendValue(getFundingSource().getId()).append("</fundingSourceId>");
    }
    xml.append("<estimatedMechHours>");
    xml.appendValue(returnEmptyIfNull(getEstimatedMechHours()))
        .append("</estimatedMechHours>");
    xml.append("<purchasing>");
    xml.append("<poLineAmount>");
    xml.appendValue(returnEmptyIfNull(getEquipment().getPurchasing().getPoLineAmount()))
        .append("</poLineAmount>");
    xml.append("<coAmount>");
    xml.appendValue(returnEmptyIfNull(getEquipment().getPurchasing().getCoAmount()))
        .append("</coAmount>");
    xml.append("</purchasing>");
    xml.append("<escalationFactor>");
    xml.appendValue(returnEmptyIfNull(getEscalationFactor())).append("</escalationFactor>");
    xml.append("</costSchedule>");
    return xml.toString();
  }

  private Object returnEmptyIfNull(Object obj) {
    if (obj == null) {
      return "";
    } else {
      return obj;
    }
  }

  private String formatDate(Date date) {
    if (date == null) {
      return "";
    } else {
      return ConvertUtil.toString(date, ConvertUtil.PROJECTS_DATE_FORMAT);
    }
  }

  private String getFormattedId(){
     return getId() == null ? "" : "'" + getId() + "',";
  }

  public String getCostScheduleAndRelatedIds(){
    StringBuffer ids = new StringBuffer();
    ids.append(this.getFormattedId());
    if (this.getFundingSource() != null){
      ids.append(this.getFundingSource().getFormattedId());
     }
    return ids.toString().substring(0, ids.toString().length() - 1);
  }
}