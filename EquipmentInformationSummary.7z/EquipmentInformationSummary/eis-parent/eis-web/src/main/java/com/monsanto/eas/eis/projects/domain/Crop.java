package com.monsanto.eas.eis.projects.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import com.monsanto.eas.eis.util.XMLBuffer;

/**
 * @author VVVELU
 */


@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_CROP")
public class Crop implements Serializable {

  private static final long serialVersionUID = 8884343309440669510L;

  @Id
  @SequenceGenerator(name = "cropSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cropSeqGen")
  @Column(name="ID")
  private Long id;

  @Column(name = "CROP_NAME")
  private String name;

  @ManyToMany(cascade = CascadeType.ALL)
  @JoinTable(
          name="EIS_CROP_AREA",
          joinColumns=@JoinColumn(name="CROP_ID_FOR_AREA", referencedColumnName="ID"),
          inverseJoinColumns=@JoinColumn(name="AREA_ID", referencedColumnName="ID")
  )
   private List<Area> areas; //15

  public Crop() {}

  public Crop(Long id, String name, List<Area> areas) {
    this.id = id;
    this.name = name;
    this.areas = areas;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public List<Area> getAreas() {
    return areas;
  }

//  public void setAreas(List<Area> areas) {
//    this.areas = areas;
//  }
//

  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("[Crop id=");
    stringBuffer.append(id);
    stringBuffer.append(']'+"[Crop name=");
    stringBuffer.append(name);
    stringBuffer.append(']');    
    return  stringBuffer.toString();
  }

  public boolean equals(Object obj) {
    return obj == null || !(obj instanceof Crop) ? false : id.equals(((Crop) obj).getId());
  }

  public int hashCode() {
    return id.hashCode();
  }
}
