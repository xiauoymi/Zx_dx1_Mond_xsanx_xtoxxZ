package com.monsanto.eas.eis.projects.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.eas.eis.controller.XmlObject;
import org.hibernate.annotations.AccessType;
import com.monsanto.eas.eis.util.XMLBuffer;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Dec 2, 2008 Time: 6:24:22 PM To change this template use File | Settings
 * | File Templates.
 */
@Entity
@AccessType("field")
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_DESIGN_CAPACITY_UNIT")
public class DesignCapacityUnit implements Serializable, XmlObject {
  private static final long serialVersionUID = 8174343349445666510L;
  @Id
  @SequenceGenerator(name = "dcuSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dcuSeqGen")
  @Column(name = "ID")
  private Long id;

  @Column(name = "UNIT_NAME")
  private String unitName;

  @ManyToOne()
  @JoinColumn(name = "UNIT_MEASURE_ID")
  private UnitMeasure unitMeasure;

  public DesignCapacityUnit() {
  }

  public DesignCapacityUnit(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public String getUnitName() {
    return unitName;
  }

  public void setUnitName(String unitName) {
    this.unitName = unitName;
  }

  public UnitMeasure getUnitMeasure() {
    return unitMeasure;
  }

  public void setUnitMeasure(UnitMeasure unitMeasure) {
    this.unitMeasure = unitMeasure;
  }

   public String getFormattedId(){
     return getId() == null ? "" : "'" + getId() + "',";
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<designCapacityUnit>");
    xml.append("<id>");
    xml.appendValue(getId()).append("</id>");
    xml.append("<unitName>");
    xml.append(getUnitName()).append("</unitName>");
    xml.append("</designCapacityUnit>");
    return xml.toString();
  }
}
