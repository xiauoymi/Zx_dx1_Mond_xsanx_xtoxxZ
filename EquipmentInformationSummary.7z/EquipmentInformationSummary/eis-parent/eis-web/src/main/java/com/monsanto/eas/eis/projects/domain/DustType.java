/*
 DustType was created on Sep 29, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import com.monsanto.eas.eis.util.XMLBuffer;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: DustType.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date:
 * 2008/10/01 13:15:48 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_DUST_TYPE")
public class DustType implements XmlObject {

  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "TYPE")
  private String type;

  public DustType() {
  }

  public DustType(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

   public String getFormattedId () throws Exception {
    return getId() == null ? "" : "'" + getId() + "',";
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<dustType>");
    xml.append("<id>");
    xml.appendValue(getId()).append("</id>");
    xml.append("<type>");
    xml.appendValue(getType()).append("</type>");
    xml.append("</dustType>");
    return xml.toString();
  }
}