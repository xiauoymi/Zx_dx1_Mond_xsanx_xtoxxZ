package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.Copyable;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 23, 2008 Time: 10:15:53 AM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_ELECTRICAL")
public class Electrical implements Serializable, XmlObject, Copyable {

  private static final long serialVersionUID = 1L;

  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "PROOF_OF_POS_REQ")
  @Type(type = "yes_no")
  private boolean proofOfPositionReq;

  @Column(name = "SOLENOID_REQ")
  @Type(type = "yes_no")
  private boolean solenoidReq;

  @Column(name = "LOCAL_PUSH_BUT_REQ")
  @Type(type = "yes_no")
  private boolean localPushButtonReq;

  @ManyToOne
  @JoinColumn(name = "INPUT_ID")
  private ElectricalInput input;

  @Column(name = "INPUT_QTY")
  private Integer inputQty;

  @ManyToOne
  @JoinColumn(name = "OUTPUT_ID")
  private ElectricalOutput output;

  @Column(name = "OUTPUT_QTY")
  private Integer outputQty;

  @Column(name = "HMI_DISPLAY")
  private String hmiDisplay;

  @ManyToOne
  @JoinColumn(name = "OTHER_MEASUREMENT_ID")
  private OtherMeasurement otherMeasurement;

  @Column(name = "COMMUNICATIONS")
  private String communications;

  @Column(name = "VOLTAGE")
  private Integer voltage;

  @OneToOne(mappedBy = "electrical")
  private Equipment equipment;

  //http://www.jroller.com/eyallupu/entry/solving_simultaneously_fetch_multiple_bags
  @OneToMany(mappedBy = "electrical",
      targetEntity = ElectricalInputQuantity.class,
      cascade = CascadeType.ALL,
      fetch = FetchType.LAZY)
  @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
  private Set<ElectricalInputQuantity> inputQuantity = new HashSet<ElectricalInputQuantity>();

  //http://www.jroller.com/eyallupu/entry/solving_simultaneously_fetch_multiple_bags
  @OneToMany(mappedBy = "electrical",
      targetEntity = ElectricalOutputQuantity.class,
      cascade = CascadeType.ALL,
      fetch = FetchType.LAZY)
  @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
  private Set<ElectricalOutputQuantity> outputQuantity = new HashSet<ElectricalOutputQuantity>();

  public Electrical() {
  }

  public Electrical(Long id, boolean proofOfPositionReq, boolean solenoidReq, boolean localPushButtonReq,
                    ElectricalInput input, Integer inputQty,
                    ElectricalOutput output, Integer outputQty, String hmiDisplay, OtherMeasurement otherMeasurement,
                    String communications, Integer voltage, Equipment equipment) {
    this.id = id;
    this.proofOfPositionReq = proofOfPositionReq;
    this.solenoidReq = solenoidReq;
    this.localPushButtonReq = localPushButtonReq;
    this.input = input;
    this.inputQty = inputQty;
    this.output = output;
    this.outputQty = outputQty;
    this.hmiDisplay = hmiDisplay;
    this.otherMeasurement = otherMeasurement;
    this.communications = communications;
    this.voltage = voltage;
    this.equipment = equipment;
  }

  public Long getId() {
    return id;
  }

  public Boolean isProofOfPositionReq() {
    return proofOfPositionReq;
  }

  public Boolean isSolenoidReq() {
    return solenoidReq;
  }

  public Boolean isLocalPushButtonReq() {
    return localPushButtonReq;
  }

  public ElectricalInput getInput() {
    return input;
  }

  public Integer getInputQty() {
    return inputQty;
  }

  public ElectricalOutput getOutput() {
    return output;
  }

  public Integer getOutputQty() {
    return outputQty;
  }

  public String getHmiDisplay() {
    return hmiDisplay;
  }

  public OtherMeasurement getOtherMeasurement() {
    return otherMeasurement;
  }

  public String getCommunications() {
    return communications;
  }

  public Integer getVoltage() {
    return voltage;
  }

  public Set<ElectricalInputQuantity> getInputQuantity() {
    return inputQuantity;
  }

  public Set<ElectricalOutputQuantity> getOutputQuantity() {
    return outputQuantity;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void setProofOfPositionReq(boolean proofOfPositionReq) {
    this.proofOfPositionReq = proofOfPositionReq;
  }

  public void setSolenoidReq(boolean solenoidReq) {
    this.solenoidReq = solenoidReq;
  }

  public void setLocalPushButtonReq(boolean localPushButtonReq) {
    this.localPushButtonReq = localPushButtonReq;
  }

  public void setInput(ElectricalInput input) {
    this.input = input;
  }

  public void setInputQty(Integer inputQty) {
    this.inputQty = inputQty;
  }

  public void setOutput(ElectricalOutput output) {
    this.output = output;
  }

  public void setOutputQty(Integer outputQty) {
    this.outputQty = outputQty;
  }

  public void setHmiDisplay(String hmiDisplay) {
    this.hmiDisplay = hmiDisplay;
  }

  public void setOtherMeasurement(OtherMeasurement otherMeasurement) {
    this.otherMeasurement = otherMeasurement;
  }

  public void setCommunications(String communications) {
    this.communications = communications;
  }

  public void setVoltage(Integer voltage) {
    this.voltage = voltage;
  }

  public void setInputQuantity(Set<ElectricalInputQuantity> inputQuantity) {
    this.inputQuantity = inputQuantity;
  }

  public void setOutputQuantity(Set<ElectricalOutputQuantity> outputQuantity) {
    this.outputQuantity = outputQuantity;
  }

  public Equipment getEquipment() {
    return equipment;
  }

  public Electrical createCopy() throws CloneNotSupportedException {
    Electrical electrical = (Electrical) super.clone();
    electrical.setId(null);
    return electrical;
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<electrical>");
    xml.append(getEquipment().toXmlWithBasicFields());
    getChildNodes(xml);
    xml.append(getInputQuantities());
    xml.append(getOutputQuantities());
    xml.append("</electrical>");
    return xml.toString();
  }

  public String toXmlWithoutEquipment() {
    XMLBuffer xml = new XMLBuffer("<electrical>");
    getChildNodes(xml);
    xml.append("</electrical>");
    return xml.toString();
  }

  private void getChildNodes(XMLBuffer xml) {
    xml.append("<electId>");
    xml.appendValue(returnEmptyIfNull(getId())).append("</electId>");
    xml.append("<proofOfPositionReq>");
    xml.appendValue(returnEmptyIfNull(new Boolean(isProofOfPositionReq()).toString())).append("</proofOfPositionReq>");
    xml.append("<solenoidReq>");
    xml.appendValue(returnEmptyIfNull(new Boolean(isSolenoidReq()).toString())).append("</solenoidReq>");
    xml.append("<localPushButtonReq>");
    xml.appendValue(returnEmptyIfNull(new Boolean(isLocalPushButtonReq()).toString())).append("</localPushButtonReq>");

//    for (ElectricalInputQuantity iq : inputQuantity) {
//      String iqId = iq.getInput().getId().toString();
//      xml.append("<electricalInput" + iqId + ">");
//      xml.append(iqId);
//      xml.append("</inputId" + iqId + ">");
//      xml.append("<inputId" + iqId + ">");
//      xml.append(iqId);
//      xml.append("</inputId" + iqId + ">");
//      xml.append("<inputQty" + iqId + ">");
//      xml.append(iq.getInputQty().toString());
//      xml.append("</inputQty" + iqId + ">");
//    }
//    for (ElectricalOutputQuantity oq : outputQuantity) {
//      String oqId = oq.getOutput().getId().toString();
//      xml.append("<outputId" + oqId + ">");
//      xml.append(oqId);
//      xml.append("</outputId" + oqId + ">");
//      xml.append("<outputQty" + oqId + ">");
//      xml.append(oq.getOutputQty().toString());
//      xml.append("</outputQty" + oqId + ">");
//    }
    if (getInput() != null) {
      xml.append("<inputId>");
      xml.appendValue(returnEmptyIfNull(getInput().getId())).append("</inputId>");
    } else {
      xml.append("<inputId>");
      xml.appendValue("").append("</inputId>");
    }

    xml.append("<inputQty>");
    xml.appendValue(returnEmptyIfNull(getInputQty())).append("</inputQty>");

    if (getOutput() != null) {
      xml.append("<outputId>");
      xml.appendValue(returnEmptyIfNull(getOutput().getId())).append("</outputId>");
    } else {
      xml.append("<outputId>");
      xml.appendValue("").append("</outputId>");
    }

    xml.append("<outputQty>");
    xml.appendValue(returnEmptyIfNull(getOutputQty())).append("</outputQty>");

    xml.append("<hmiDisplay>");
    xml.appendValue(returnEmptyIfNull(getHmiDisplay())).append("</hmiDisplay>");

    if (getOtherMeasurement() != null) {
      xml.append("<otherMeasurementId>");
      xml.appendValue(returnEmptyIfNull(getOtherMeasurement().getId())).append("</otherMeasurementId>");
    } else {
      xml.append("<otherMeasurementId>");
      xml.appendValue("").append("</otherMeasurementId>");
    }
    xml.append("<communications>");
    xml.appendValue(returnEmptyIfNull(getCommunications())).append("</communications>");
    xml.append("<voltage>");
    xml.appendValue(returnEmptyIfNull(getVoltage())).append("</voltage>");
  }

  private String getInputQuantities() {
    XMLBuffer xml = new XMLBuffer();
    Set<ElectricalInputQuantity> quantitySet = getInputQuantity();
    if (quantitySet != null && quantitySet.size() > 0) {
      xml.append("<inputQuantities>");
      for (ElectricalInputQuantity qty : quantitySet) {
        xml.append(qty.toXml());
      }
      xml.append("</inputQuantities>");
    }
    return xml.toString();
  }

  private String getOutputQuantities() {
    XMLBuffer xml = new XMLBuffer();
    Set<ElectricalOutputQuantity> quantitySet = getOutputQuantity();
    if (quantitySet != null && quantitySet.size() > 0) {
      xml.append("<outputQuantities>");
      for (ElectricalOutputQuantity qty : quantitySet) {
        xml.append(qty.toXml());
      }
      xml.append("</outputQuantities>");
    }
    return xml.toString();
  }


  private Object returnEmptyIfNull(Object obj) {
    if (obj == null) {
      return "";
    } else {
      return obj;
    }
  }

  public String getFormattedId() {
    return getId() == null ? "" : "'" + getId() + "',";
  }

  public void setEquipment(Equipment equipment) {
    this.equipment = equipment;
  }

  public String getElectricalAndRelatedIds() {
    StringBuffer ids = new StringBuffer();
    ids.append(this.getFormattedId());
    if (this.getOtherMeasurement() != null) {
      ids.append(this.getOtherMeasurement().getFormattedId());
    }
    if (this.getInput() != null) {
      ids.append(this.getInput().getFormattedId());
    }
    if (this.getOutput() != null) {
      ids.append(this.getOutput().getFormattedId());
    }

    for (ElectricalInputQuantity inputQuantity : getInputQuantity()) {
      ids.append(inputQuantity.getFormattedId());
    }

    for (ElectricalOutputQuantity outputQuantity : getOutputQuantity()) {
      ids.append(outputQuantity.getFormattedId());
    }

    return ids.toString().substring(0, ids.toString().length() - 1);
  }

  public boolean equals(Object obj) {
    return obj == null || id == null || !(obj instanceof Electrical) ? false : id.equals(((Electrical) obj).getId());
  }

  public int hashCode() {
    return id.hashCode();
  }

}
