package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import com.monsanto.eas.eis.util.XMLBuffer;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 23, 2008 Time: 10:24:59 AM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@AccessType("field")
@Table(schema = "EIS", name = "EIS_INPUT")
@NoDeleteAllowed

public class ElectricalInput implements Serializable, XmlObject {
  private static final long serialVersionUID = 1L;

  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;


  @Column(name = "INPUT")
  private String input;

  public ElectricalInput() {
  }

  public ElectricalInput(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getInput() {
    return input;
  }

  public void setInput(String input) {
    this.input = input;
  }

  public String toXml() {
    XMLBuffer xmlStr = new XMLBuffer("<electricalInput>");
    xmlStr.append("<id>");
    xmlStr.appendValue(getId())
            .append("</id>");
    xmlStr.append("<input>");
    xmlStr.appendValue(getInput())
            .append("</input>");
    xmlStr.append("</electricalInput>");
    return xmlStr.toString();
  }

  public String getFormattedId() {
    return getId() == null ? "" : "'" + getId() + "',";
  }
}
