/*
 ElectricalInputOutput was created on Feb 13, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

/**
 * Filename:    $RCSfile: ElectricalInputOutput.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-13 15:36:16 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public abstract class ElectricalInputOutput {
  public abstract Electrical getElectrical();
}