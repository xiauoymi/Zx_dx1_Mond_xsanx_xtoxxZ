/*
 ElectricalInputQuantity was created on Feb 2, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;

import javax.persistence.*;

import org.hibernate.annotations.Type;


/**
 * Filename:    $RCSfile: ElectricalInputQuantity.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 15:31:29 $
 *
 * @author rrmall
 * @version $Revision: 1.6 $
 */
@Entity
@Table(schema = "EIS", name = "EIS_ELECTRICAL_INPUT")
public class ElectricalInputQuantity extends ElectricalInputOutput implements XmlObject, Comparable {
  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @ManyToOne
  @JoinColumn(name = "INPUT_ID")
  private ElectricalInput input;

  @Column(name = "QUANTITY")
  private Integer inputQty;

  @ManyToOne(fetch=FetchType.LAZY)
  @JoinColumn(name = "ELECTRICAL_ID")
  private Electrical electrical;

  @Column(name = "IS_CHECKED")
  @Type(type = "yes_no")
  private boolean checked;

  @Column(name = "IS_DELETED")
  @Type(type = "yes_no")
  private boolean isDeleted;

  public ElectricalInputQuantity() {
  }

  public ElectricalInputQuantity(Long id, ElectricalInput input, Integer inputQty, Electrical electrical,
                                 boolean isChecked) {
    this.id = id;
    this.input = input;
    this.inputQty = inputQty;
    this.electrical = electrical;
    this.checked = isChecked;
  }

  public Long getId() {
    return id;
  }

  public ElectricalInput getInput() {
    return input;
  }

  public Integer getInputQty() {
    return inputQty;
  }

  public Electrical getElectrical() {
    return electrical;
  }

  public boolean isDeleted() {
    return isDeleted;
  }

  public void setDeleted(boolean deleted) {
    isDeleted = deleted;
  }

  public void setChecked(boolean checked) {
    this.checked = checked;
  }

  public boolean isChecked() {
    return checked;
  }

  public void setInputQty(Integer inputQty) {
    this.inputQty = inputQty;
  }

  public String toXml() {
    XMLBuffer xmlBuffer = new XMLBuffer();
    xmlBuffer.append("<inputQuantity>");

    xmlBuffer.append("<inputQuantityId" + getInput().getId() + ">");
    xmlBuffer.append(getId().toString());
    xmlBuffer.append("</inputQuantityId" + getInput().getId() + ">");

    xmlBuffer.append("<inputIdChecked" + getInput().getId() + ">");
    xmlBuffer.appendValue(new Boolean(checked));
    xmlBuffer.append("</inputIdChecked" + getInput().getId() + ">");

    xmlBuffer.append("<inputId" + getInput().getId() + ">");
    xmlBuffer.append(getInput().getId().toString());
    xmlBuffer.append("</inputId" + getInput().getId() + ">");

    xmlBuffer.append("<inputQty" + getInput().getId() + ">");
    xmlBuffer.appendValue(getInputQty());
    xmlBuffer.append("</inputQty" + getInput().getId() + ">");

//    xmlBuffer.appendValue(getInputQty());
    xmlBuffer.append("</inputQuantity>");
//    xmlBuffer.append("<inputQuantity id=\"").append(getInput().getId()).append("\">");
//    xmlBuffer.appendValue(getInputQty());
//    xmlBuffer.append("</inputQuantity>");
    return xmlBuffer.toString();
  }

 public String getFormattedId (){
    return getId() == null ? "" : "'" + getId() + "',";
  }

  public int compareTo(Object o) {
    return id.compareTo(((ElectricalInputQuantity)o).getId());
  }
}