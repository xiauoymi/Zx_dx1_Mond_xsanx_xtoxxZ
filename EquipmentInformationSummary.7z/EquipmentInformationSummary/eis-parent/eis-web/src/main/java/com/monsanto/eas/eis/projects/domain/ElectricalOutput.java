package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import com.monsanto.eas.eis.util.XMLBuffer;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 23, 2008 Time: 10:26:42 AM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_OUTPUT")

public class ElectricalOutput implements Serializable, XmlObject {

  private static final long serialVersionUID = 1L;

  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "OUTPUT")
  private String output;

  public ElectricalOutput() {
  }

  public ElectricalOutput(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getOutput() {
    return output;
  }

  public void setOutput(String output) {
    this.output = output;
  }

  public String toXml() {
    XMLBuffer xmlStr = new XMLBuffer("<electricalOutput>");
    xmlStr.append("<id>");
    xmlStr.appendValue(getId())
            .append("</id>");
    xmlStr.append("<output>");
    xmlStr.append(getOutput())
            .append("</output>");
    xmlStr.append("</electricalOutput>");
    return xmlStr.toString();
  }

  public String getFormattedId() {
    return getId() == null ? "" : "'" + getId() + "',";
  }
}
