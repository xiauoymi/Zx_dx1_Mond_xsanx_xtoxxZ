/*
 ElectricalOutputQuantity was created on Feb 2, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import org.hibernate.annotations.Type;

/**
 * Filename:    $RCSfile: ElectricalOutputQuantity.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 15:31:29 $
 *
 * @author rrmall
 * @version $Revision: 1.5 $
 */
@Entity
@Table(schema = "EIS", name = "EIS_ELECTRICAL_OUTPUT")
public class ElectricalOutputQuantity extends ElectricalInputOutput implements XmlObject, Comparable {
  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @ManyToOne
  @JoinColumn(name = "OUTPUT_ID")
  private ElectricalOutput output;

  @Column(name = "QUANTITY")
  private Integer outputQty;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "ELECTRICAL_ID")
  private Electrical electrical;

  @Column(name = "IS_CHECKED")
  @Type(type = "yes_no")
  private boolean checked;

  @Column(name = "IS_DELETED")
  @Type(type = "yes_no")
  private boolean isDeleted;

  public ElectricalOutputQuantity() {
  }

  public ElectricalOutputQuantity(Long id, ElectricalOutput output, Integer outputQty, Electrical electrical,
                                  boolean isChecked) {
    this.id = id;
    this.output = output;
    this.outputQty = outputQty;
    this.electrical = electrical;
    this.checked = isChecked;
  }

  public Long getId() {
    return id;
  }

  public ElectricalOutput getOutput() {
    return output;
  }

  public Integer getOutputQty() {
    return outputQty;
  }

  public Electrical getElectrical() {
    return electrical;
  }

  public boolean isDeleted() {
    return isDeleted;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void setOutput(ElectricalOutput output) {
    this.output = output;
  }

  public void setOutputQty(Integer outputQty) {
    this.outputQty = outputQty;
  }

  public void setElectrical(Electrical electrical) {
    this.electrical = electrical;
  }

  public void setDeleted(boolean deleted) {
    isDeleted = deleted;
  }

  public void setChecked(boolean checked) {
    this.checked = checked;
  }

  public boolean isChecked() {
    return checked;
  }

  public String toXml() {
    XMLBuffer xmlBuffer = new XMLBuffer();
    xmlBuffer.append("<outputQuantity>");

    xmlBuffer.append("<outputQuantityId" + getOutput().getId() + ">");
    xmlBuffer.append(getId().toString());
    xmlBuffer.append("</outputQuantityId" + getOutput().getId() + ">");

    xmlBuffer.append("<outputIdChecked" + getOutput().getId() + ">");
    xmlBuffer.appendValue(new Boolean(checked));
    xmlBuffer.append("</outputIdChecked" + getOutput().getId() + ">");

    xmlBuffer.append("<outputId" + getOutput().getId() + ">");
    xmlBuffer.append(getOutput().getId().toString());
    xmlBuffer.append("</outputId" + getOutput().getId() + ">");

    xmlBuffer.append("<outputQty" + getOutput().getId() + ">");
    xmlBuffer.appendValue(getOutputQty());
    xmlBuffer.append("</outputQty" + getOutput().getId() + ">");

//    xmlBuffer.appendValue(getOutputQty());
    xmlBuffer.append("</outputQuantity>");
//    xmlBuffer.append("<outputQuantity id=\"").append(getOutput().getId()).append("\">");
//    xmlBuffer.appendValue(getOutputQty());
//    xmlBuffer.append("</outputQuantity>");
    return xmlBuffer.toString();
  }

  public String getFormattedId () {
    return getId() == null ? "" : "'" + getId() + "',";
  }

   public int compareTo(Object o) {
    return id.compareTo(((ElectricalOutputQuantity)o).getId());
  }
}