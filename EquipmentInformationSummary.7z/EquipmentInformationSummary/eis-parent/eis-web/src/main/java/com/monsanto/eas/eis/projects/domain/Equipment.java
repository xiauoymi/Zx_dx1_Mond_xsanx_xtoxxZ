package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.Copyable;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.hibernate.Criteria;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import javax.persistence.*;
import java.util.*;

/**
 * Created by IntelliJ IDEA. User: VVVELU Date: Aug 29, 2008 Time: 9:11:35 AM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@Table(schema = "EIS", name = "EIS_EQUIPMENT")
public class Equipment implements XmlObject, Copyable {

    @Id
    @SequenceGenerator(name = "equipmentSeqGen", sequenceName = "EIS.EIS_SEQ")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "equipmentSeqGen")
    @Column(name = "ID")
    private Long id;

    @Column(name = "equipment_number")
    private String equipmentNumber;

    @Column(name = "existing_equipment_number")
    private String existingEquipmentNumber;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @ManyToOne
    @JoinColumn(name = "area_id")
    private Area area;

    @Column(name = "process_line_number")
    private String processLineNumber;

    @Column(name = "equip_tag_number")
    private String equipmentTagNumber;

    @ManyToOne
    @JoinColumn(name = "equip_type_id")
    private EquipmentType equipmentType;

    @ManyToOne
    @JoinColumn(name = "sub_type_1_id")
    private EquipmentType subType;

    @ManyToOne
    @JoinColumn(name = "projects_id")
    private Projects projects;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "PROCESS_ID")
    private Process process;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "MECHANICAL_ID")
    private Mechanical mechanical;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ELECTRICAL_ID")
    private Electrical electrical;

    //http://www.jroller.com/eyallupu/entry/solving_simultaneously_fetch_multiple_bags
    @OneToMany(mappedBy = "equipment",
            targetEntity = Motor.class,
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY)
    @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
    private Set<Motor> motors = new HashSet<Motor>();

    @OneToMany(mappedBy = "equipment",
            targetEntity = Instrument.class, cascade = CascadeType.ALL,
            fetch = FetchType.LAZY)
    @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
    private Set<Instrument> instruments = new HashSet<Instrument>();

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "PURCHASE_ID")
    private Purchasing purchasing;

    @Column(name = "is_deleted")
    @Type(type = "yes_no")
    private boolean isDeleted;

    @Column(name = "EXST_EQPMT_MODIFICATION")
    @Type(type = "yes_no")
    private boolean existingEquipmentModification;

    @Column(name = "STD_EQPMT")
    @Type(type = "yes_no")
    private boolean standardEquipment;

    @Column(name = "SOLE_SOURCE")
    @Type(type = "yes_no")
    private boolean equipmentSoleSource;

    @OneToMany(mappedBy = "equipment",
            targetEntity = Accessory.class, cascade = CascadeType.ALL,
            fetch = FetchType.LAZY)
    @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
    private Set<Accessory> accessories = new HashSet<Accessory>();

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "COST_SCHEDULE_ID")
    private CostSchedule costSchedule;


    @Transient
    public boolean copyingForSave;

    public Equipment() {
    }

    public Equipment(String equipmentNumber, String existingEquipmentNumber, String name, String description, Area area,
                     String processLineNumber,
                     String equipmentTagNumber, EquipmentType equipmentType, EquipmentType subType,
                     Projects p) {

        this.equipmentNumber = equipmentNumber;
        this.existingEquipmentNumber = existingEquipmentNumber;
        this.name = name;
        this.description = description;
        this.area = area;
        this.processLineNumber = processLineNumber;
        this.equipmentTagNumber = equipmentTagNumber;
        this.equipmentType = equipmentType;
        this.subType = subType;
        this.projects = p;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEquipmentNumber() {
        return this.equipmentNumber;
    }

    public void setEquipmentNumber(String equipmentNumber) {
        this.equipmentNumber = equipmentNumber;
    }

    public String getExistingEquipmentNumber() {
        return existingEquipmentNumber;
    }

    public void setExistingEquipmentNumber(String existingEquipmentNumber) {
        this.existingEquipmentNumber = existingEquipmentNumber;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    //
    public Area getArea() {
        return this.area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    //
    public String getProcessLineNumber() {
        return this.processLineNumber;
    }

    public void setProcessLineNumber(String processLineNumber) {
        this.processLineNumber = processLineNumber;
    }

    //
    public String getEquipmentTagNumber() {
        return this.equipmentTagNumber;
    }

    public void setEquipmentTagNumber(String equipmentTagNumber) {
        this.equipmentTagNumber = equipmentTagNumber;
    }


    //
    public EquipmentType getEquipmentType() {
        return this.equipmentType;
    }

    public void setEquipmentType(EquipmentType equipmentType) {
        this.equipmentType = equipmentType;
    }

    public EquipmentType getSubType() {
        return this.subType;
    }

    public void setSubTypeOne(EquipmentType subTypeOne) {
        this.subType = subTypeOne;
    }

    public Projects getProjects() {
        return projects;
    }

    public void setProjects(Projects projects) {
        this.projects = projects;
    }

    public Process getProcess() {
        return process;
    }

    public void setProcess(Process process) {
        this.process = process;
    }

    public Mechanical getMechanical() {
        return mechanical;
    }

    public void setMechanical(Mechanical mechanical) {
        this.mechanical = mechanical;
    }

    public Electrical getElectrical() {
        return electrical;
    }

    public void setElectrical(Electrical electrical) {
        this.electrical = electrical;
    }

    public Set<Motor> getMotors() {
        return motors;
    }

    public void setMotors(Set<Motor> motor) {
        this.motors = motor;
    }

    public Boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Set<Instrument> getInstruments() {
        return instruments;
    }

    public void setInstruments(Set<Instrument> instruments) {
        this.instruments = instruments;
    }

    public Set<Accessory> getAccessories() {
        return accessories;
    }

    public void setAccessories(Set<Accessory> accessories) {
        this.accessories = accessories;
    }

    public CostSchedule getCostSchedule() {
        return costSchedule;
    }

    public void setCostSchedule(CostSchedule costSchedule) {
        this.costSchedule = costSchedule;
    }

    public Purchasing getPurchasing() {
        return purchasing;
    }

    public void setPurchasing(Purchasing purchasing) {
        this.purchasing = purchasing;
    }

    public boolean isExistingEquipmentModification() {
        return this.existingEquipmentModification;
    }

    public void setExistingEquipmentModification(boolean existingEquipmentModification) {
        this.existingEquipmentModification = existingEquipmentModification;
    }

    public boolean isStandardEquipment() {
        return this.standardEquipment;
    }

    public void setStandardEquipment(boolean standardEquipment) {
        this.standardEquipment = standardEquipment;
    }


    public boolean isEquipmentSoleSource() {
        return this.equipmentSoleSource;
    }

    public void setEquipmentSoleSource(boolean soleSource) {
        this.equipmentSoleSource = soleSource;
    }

    public Equipment createCopy() throws CloneNotSupportedException {
        Equipment equipment = (Equipment) super.clone();
        equipment.setId(null);
        equipment.setProcess(removedDeletedEquipmentTypes(getProcess().createCopy()));
        equipment.setElectrical(getElectrical().createCopy());
        equipment.setMechanical(getMechanical().createCopy());
        equipment.setPurchasing(getPurchasing().createCopy());
        if (copyingForSave && getCostSchedule() != null && (getCostSchedule().isDeleted())) {
            equipment.setPurchasing(null);
        }
        equipment.setCostSchedule(getCostSchedule().createCopy());
        if (copyingForSave && getCostSchedule() != null && (getCostSchedule().isDeleted())) {
            equipment.setCostSchedule(null);
        }
        equipment.setMotors(getCopyOfMotors(equipment, copyingForSave));
        equipment.setInstruments(getCopyOfInstruments(equipment, copyingForSave));
        equipment.setAccessories(getCopyOfAccessories(equipment, copyingForSave));
        return equipment;
    }

    private Process removedDeletedEquipmentTypes(Process copy) {
        List<ProcessFieldEquipmentType> copyOfPfes = new ArrayList<ProcessFieldEquipmentType>();
        HashMap<String, ProcessFieldEquipmentType> uniqueEquipmentType = new HashMap<String, ProcessFieldEquipmentType>();
        String key;
        ProcessFieldEquipmentType temp = null;
        for (ProcessFieldEquipmentType pfe : copy.getProcessFieldEquipmentTypes()) {
            if (pfe.isDeleted() && copyingForSave) {
                continue;
            }
            if (pfe.getId()!=null){
                key = pfe.buildKeyForUniqueEquipmentTypeAndValue();
                if (!copyingForSave || !uniqueEquipmentType.containsKey(key)) {
                    uniqueEquipmentType.put(key, pfe);
                } else {
                    temp = uniqueEquipmentType.get(key);
                    if (pfe.getId().compareTo(temp.getId()) > 0) {
                        uniqueEquipmentType.put(key, pfe);
                    }
                }
            }else {
                copyOfPfes.add(pfe);
            }
        }
        copyOfPfes.addAll(uniqueEquipmentType.values());
        copy.setProcessFieldEquipmentTypes(copyOfPfes);
        return copy;

    }

    private Set<Motor> getCopyOfMotors(Equipment equipment, boolean copyForSaving) throws CloneNotSupportedException {
        Set<Motor> copyOfMotors = new HashSet<Motor>();
        for (Motor motor : this.getMotors()) {
            if (motor.isDeleted() && copyForSaving) {
                continue;
            }
            Motor copyOfMotor = motor.createCopy();
            copyOfMotor.setEquipment(equipment);
            copyOfMotors.add(copyOfMotor);
        }
        return copyOfMotors;
    }

    private Set<Instrument> getCopyOfInstruments(Equipment equipment, boolean copyForSaving) throws CloneNotSupportedException {
        Set<Instrument> copyOfInstruments = new HashSet<Instrument>();
        for (Instrument instrument : this.getInstruments()) {
            if (instrument.isDeleted() && copyForSaving) {
                continue;
            }
            Instrument copyOfMotor = instrument.createCopy();
            copyOfMotor.setEquipment(equipment);
            copyOfInstruments.add(copyOfMotor);
        }
        return copyOfInstruments;
    }

    private Set<Accessory> getCopyOfAccessories(Equipment equipment, boolean copyForSaving) throws CloneNotSupportedException {
        Set<Accessory> copyOfAccessories = new HashSet<Accessory>();
        for (Accessory accessory : this.getAccessories()) {
            if (accessory.isDeleted() && copyForSaving) {
                continue;
            }
            Accessory copyOfAccessory = accessory.createCopy();
            copyOfAccessory.setEquipment(equipment);
            copyOfAccessories.add(copyOfAccessory);
        }
        return copyOfAccessories;
    }


    public String getFormattedId() {
        return "'" + this.getId() + "',";
    }

    public String toXml() {
        XMLBuffer xml = new XMLBuffer("<equipment>");
        xml.append("<id>");
        xml.appendValue(getId()).append("</id>");
        xml.append("<equipmentNumber>");
        xml.appendValue(getEquipmentNumber()).append("</equipmentNumber>");
        xml.append("<existingEquipmentNumber>");
        xml.appendValue(getExistingEquipmentNumber()).append("</existingEquipmentNumber>");
        xml.append("<name>");
        xml.appendValue(getName()).append("</name>");
        xml.append("<description>");
        xml.appendValue(getDescription()).append("</description>");
        xml.append("<modifiedDate>");
        xml.appendValue("")
                .append("</modifiedDate>");//todo: fix this when updated date is added to the db
        appendAreaXml(xml);
        xml.append("<processLineNumber>");
        xml.appendValue(getProcessLineNumber()).append("</processLineNumber>");
        xml.append("<equipmentTagNumber>");
        xml.appendValue(getEquipmentTagNumber()).append("</equipmentTagNumber>");
        xml.append(getEquipmentTypeXML(getEquipmentType(), "equipmentType"));
        xml.append(getEquipmentTypeXML(getSubType(), "equipmentSubType"));
        xml.append("<equipmentVendor>");
        xml.appendValue(getPurchasing().getVendor()).append("</equipmentVendor>");
        xml.append("<motors>").append(doMotorsExist()).append("</motors>");
        xml.append("<instruments>").append(doInstrumentsExist()).append("</instruments>");
        xml.append("<accessories>").append(doAccessoriesExist()).append("</accessories>");
//    xml.append("<motors>").append(!getMotors().isEmpty()).append("</motors>");
//    xml.append("<instruments>").append(!getInstruments().isEmpty()).append("</instruments>");
//    xml.append("<accessories>").append(!getAccessories().isEmpty()).append("</accessories>");
        xml.append("<existingEquipmentModification>");
        xml.appendValue(new Boolean(isExistingEquipmentModification()).toString())
                .append("</existingEquipmentModification>");
        xml.append("<standardEquipment>");
        xml.appendValue(new Boolean(isStandardEquipment()).toString())
                .append("</standardEquipment>");
        xml.append("<equipmentSoleSource>");
        xml.appendValue(new Boolean(isEquipmentSoleSource()).toString())
                .append("</equipmentSoleSource>");

        xml.append("</equipment>");
        return xml.toString();
    }

    public String toXmlWithBasicFields() {
        XMLBuffer xml = new XMLBuffer("<equipment>");
        xml.append("<id>");
        xml.appendValue(getId()).append("</id>");
        xml.append("<equipmentNumber>");
        xml.appendValue(getEquipmentNumber()).append("</equipmentNumber>");
        xml.append("<existingEquipmentNumber>");
        xml.appendValue(getExistingEquipmentNumber()).append("</existingEquipmentNumber>");
        xml.append("<name>");
        xml.appendValue(getName()).append("</name>");
        xml.append("<processLineNumber>");
        xml.appendValue(getProcessLineNumber()).append("</processLineNumber>");
        appendAreaXml(xml);
        xml.append(getEquipmentTypeXML(getEquipmentType(), "equipmentType"));
        xml.append("<equipmentVendor>");
        xml.appendValue(getPurchasing().getVendor()).append("</equipmentVendor>");
        xml.append("</equipment>");
        return xml.toString();
    }

    //Coz Motors are loaded lazily and might not be queried in the same session as the parent, if not queried here will throw
    //lazyinitialization exception
    private boolean doMotorsExist() {
        GenericDAO<Motor, Long> dao = getMotorDao();
        Criteria criteria = dao.createCriteria();
        criteria.add(Restrictions.eq("equipment.id", getId()));
        criteria.setProjection(Projections.rowCount());
        Integer totalRecords = (Integer) criteria.uniqueResult();
        return totalRecords.intValue() > 0;
    }

    private boolean doInstrumentsExist() {
        GenericDAO<Instrument, Long> dao = getInstrumentDao();
        Criteria criteria = dao.createCriteria();
        criteria.add(Restrictions.eq("equipment.id", getId()));
        criteria.setProjection(Projections.rowCount());
        Integer totalRecords = (Integer) criteria.uniqueResult();
        return totalRecords.intValue() > 0;
    }

    private boolean doAccessoriesExist() {
        GenericDAO<Accessory, Long> dao = getAccessoryDao();
        Criteria criteria = dao.createCriteria();
        criteria.add(Restrictions.eq("equipment.id", getId()));
        criteria.setProjection(Projections.rowCount());
        Integer totalRecords = (Integer) criteria.uniqueResult();
        return totalRecords.intValue() > 0;
    }

    //protected only for testing
    protected GenericDAO<Motor, Long> getMotorDao() {
        return new HibernateDAO<Motor, Long>(EISHibernateUtil.getHibernateFactory(),
                Motor.class);
    }

    protected GenericDAO<Instrument, Long> getInstrumentDao() {
        return new HibernateDAO<Instrument, Long>(EISHibernateUtil.getHibernateFactory(),
                Instrument.class);
    }

    protected GenericDAO<Accessory, Long> getAccessoryDao() {
        return new HibernateDAO<Accessory, Long>(EISHibernateUtil.getHibernateFactory(),
                Accessory.class);
    }

    private void appendAreaXml(XMLBuffer xml) {
        xml.append("<area>");
        if (getArea() == null) {
            xml.append("<areaId>");
            xml.appendValue("").append("</areaId>");
            xml.append("<areaCode>");
            xml.appendValue("").append("</areaCode>");
            xml.append("<areaDescription>");
            xml.appendValue("").append("</areaDescription>");
        } else {
            xml.append("<areaId>");
            xml.appendValue(getArea().getId()).append("</areaId>");
            xml.append("<areaCode>");
            xml.appendValue(getArea().getAreaCode()).append("</areaCode>");
            xml.append("<areaDescription>");
            xml.appendValue(getArea().getDescription()).append("</areaDescription>");
        }
        xml.append("</area>");
    }

    private String getEquipmentTypeXML(EquipmentType equipmentType, String nodeName) {
        XMLBuffer xml = new XMLBuffer();
        String idNode = nodeName + "Id";
        String codeNode = nodeName + "Code";
        String nameNode = nodeName + "Name";
        xml.append("<").append(nodeName).append(">");
        if (equipmentType == null) {
            xml.append("<").append(idNode).append(">").append("").append("</").append(idNode).append(">");
            xml.append("<").append(codeNode).append(">").append("").append("</").append(codeNode).append(">");
            xml.append("<").append(nameNode).append(">").append("").append("</").append(nameNode).append(">");
        } else {
            xml.append("<").append(idNode).append(">").append(equipmentType.getId()).append("</").append(idNode).append(">");
            xml.append("<").append(codeNode).append(">").append(equipmentType.getTypeCode()).append("</").append(codeNode)
                    .append(">");
            xml.append("<").append(nameNode).append(">").append(equipmentType.getName()).append("</").append(nameNode)
                    .append(">");
        }
        xml.append("</").append(nodeName).append(">");
        return xml.toString();
    }

    public boolean equals(Object obj) {
        return obj == null || id == null || !(obj instanceof Equipment) ? false : id.equals(((Equipment) obj).getId());
    }

    public int hashCode() {
        return id.hashCode();
    }

    public String getEquipmentAndRelatedIds() {
        StringBuffer ids = new StringBuffer();
        ids.append(this.getFormattedId());
        ids.append(getProcess().getProcessAndItsRelatedsIds()).append(",");
        ids.append(getMechanical().getMechanicalAndRelatedIds()).append(",");
        ids.append(getElectrical().getElectricalAndRelatedIds()).append(",");
        ids.append(getCostSchedule().getCostScheduleAndRelatedIds()).append(",");
        ids.append(getPurchasing().getFormattedId());
        if (getMotors().size() > 0) {
            getMotorIds(ids);
        }
        if (getInstruments().size() > 0) {
            getInstrumentIds(ids);
        }

        if (getAccessories().size() > 0) {
            getAccessoryIds(ids);
        }

        return ids.toString().substring(0, ids.toString().length() - 1);
    }

    private void getAccessoryIds(StringBuffer ids) {
        for (Accessory accessory : getAccessories()) {
            ids.append(accessory.getAccessoryAndRelatedIds());
            ids.append(",");
        }
    }

    private void getInstrumentIds(StringBuffer ids) {
        for (Instrument instrument : getInstruments()) {
            ids.append(instrument.getInstrumentAndRelatedIds());
            ids.append(",");
        }
    }

    private void getMotorIds(StringBuffer ids) {
        for (Motor motor : getMotors()) {
            ids.append(motor.getMotorAndRelatedIds());
            ids.append(",");
        }
    }

}
