package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.logon.hibernateMappings.Role;
import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by IntelliJ IDEA. User: VVVELU Date: Aug 29, 2008 Time: 9:13:47 AM To change this template use File |
 * Settings | File Templates.
 */

@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_EQUIPMENT_TYPE")
public class EquipmentType implements Serializable, Comparable {

  @Id
  @SequenceGenerator(name = "equipTypSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "equipTypSeqGen")
  @Column(name = "ID")
  private Long id;

  @Column(name = "NAME")
  private String name;

  @Column(name = "TYPE_CODE")
  private String typeCode;

  @ManyToOne
  @JoinColumn(name = "PARENT_ID", referencedColumnName = "ID")
  private EquipmentType parentEquipmentType;

  @OneToMany
  @JoinColumn(name = "PARENT_ID", referencedColumnName = "ID")
  private List<EquipmentType> subEquipmentTypes = new ArrayList<EquipmentType>();

  @ManyToMany(targetEntity = DesignCapacityUnit.class)
  @JoinTable(
      name = "EIS_EQUIP_TYP_DSGN_CAP_UNT", uniqueConstraints = @UniqueConstraint(columnNames = {"EQUIP_TYP_ID", "DSGN_CAP_UNT_ID"}),
      joinColumns = @JoinColumn(name = "EQUIP_TYP_ID", referencedColumnName = "ID"),
      inverseJoinColumns = @JoinColumn(name = "DSGN_CAP_UNT_ID", referencedColumnName = "ID")
  )
  private List<DesignCapacityUnit> designCapacityUnits = new ArrayList<DesignCapacityUnit>();

  public EquipmentType() {
  }

  public EquipmentType(Long id, String name, String typeCode) {
    this.id = id;
    this.name = name;
    this.typeCode = typeCode;
  }

  public Long getId() {
    return id;
  }


  public void setId(Long id) {
    this.id = id;
  }

  //todo come back and take a look where a test needs to be added.
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getTypeCode() {
    return typeCode;
  }

  public List<EquipmentType> getSubEquipmentTypes() {
    return subEquipmentTypes;
  }

  public void setSubEquipmentTypes(List<EquipmentType> subEquipmentTypes) {
    this.subEquipmentTypes = subEquipmentTypes;
  }

  public List<DesignCapacityUnit> getDesignCapacityUnits() {
    return designCapacityUnits;
  }

  public void setDesignCapacityUnits(List<DesignCapacityUnit> designCapacityUnits) {
    this.designCapacityUnits = designCapacityUnits;
  }

  public boolean equals(Object obj) {
    return obj == null || !(obj instanceof EquipmentType) ? false : id.equals(((EquipmentType) obj).getId());
  }

  public int hashCode() {
    return id.hashCode();
  }

  public int compareTo(Object o) {
    EquipmentType equipmentType = (EquipmentType) o;
    if (this.getName().compareTo(equipmentType.getName()) == 0)
      return 0;
    else if (this.getName().compareTo(equipmentType.getName()) > 0)
      return 1;
    else return -1;
  }
}
