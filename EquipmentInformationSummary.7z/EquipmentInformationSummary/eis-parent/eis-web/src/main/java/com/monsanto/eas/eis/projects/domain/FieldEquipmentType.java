/*
 FieldEquipmentType was created on Oct 3, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.List;

/**
 * Filename:    $RCSfile: FieldEquipmentType.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $ On:	$Date:
 * 2008/10/09 18:12:37 $
 *
 * @author sspati1
 * @version $Revision: 1.12 $
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_FIELD_EQUIPMENT_TYPE")
public class FieldEquipmentType implements XmlObject {

  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "NAME")
  private String name;

  @Column(name = "LABEL")
  private String label;

  @Column(name = "ORDER_NUM")
  private int order;
  
  @Column(name = "TAB_INDEX")
  private int tabIndex;

  @Column(name = "IS_REQUIRED")
  @Type(type = "yes_no")
  private boolean isRequired;

  @Column(name = "UNIT_OF_MEASURE")
  private String unitOfMeasure;

  @Column(name = "SIZE_OF_FIELD")
  private int size;

  @Column(name = "DATA_TYPE")
  private String dataType;

  @Column(name = "PRECISION")
  private int precision;

  @ManyToOne
  @JoinColumn(name = "FIELD_TYPE_ID")
  private FieldType fieldType;

  @ManyToOne
  @JoinColumn(name = "EQUIPMENT_TYPE_ID")
  private EquipmentType equipmentType;

  @OneToMany(mappedBy = "fieldEquipmentType")
  private List<ListValue> listValues;

  
  public FieldEquipmentType() {
  }

  public FieldEquipmentType(FieldType fieldType, String name, String label, int size, String dataType,
                            EquipmentType equipmentType,
                            List<ListValue> listValues, int precision) {
    this.name = name;
    this.label = label;
    this.size = size;
    this.dataType = dataType;
    this.fieldType = fieldType;
    this.equipmentType = equipmentType;
    this.listValues = listValues;
    this.precision = precision;
  }

  public Long getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public String getLabel() {
    return label;
  }

  public FieldType getFieldType() {
    return fieldType;
  }

  public EquipmentType getEquipmentType() {
    return equipmentType;
  }

  public int getOrder() {
    return order;
  }

  public int getTabIndex() {
    return tabIndex;
  }

  public boolean isRequired() {
    return isRequired;
  }

  public String getUnitOfMeasure() {
    return unitOfMeasure;
  }

  public int getSize() {
    return size;
  }

  public String getDataType() {
    return dataType;
  }

  public List<ListValue> getListValues() {
    return listValues;
  } 

  public int getPrecision() {
    return precision;
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<fieldEquipmentType>");
    xml.append("<equipmentTypeId>");
    xml.appendValue(getEquipmentType().getId())
            .append("</equipmentTypeId>");
    xml.append("<fieldType>");
    xml.appendValue(getFieldType().getType())
            .append("</fieldType>");
    xml.append("<name>");
    xml.appendValue(getName()).append("</name>");
    xml.append("<label>");
    xml.appendValue(getLabel())
            .append("</label>");
    xml.append("<dataType>");
    xml.appendValue(getDataType())
            .append("</dataType>");
    xml.append("<size>");
    xml.appendValue(getSize())
            .append("</size>");
    xml.append("<precision>");
      xml.appendValue(getPrecision())
              .append("</precision>");
    xml.append("<listValues>");
    for (ListValue lv : getListValues()) {
      xml.append("<listValue>");
      xml.append("<id>");
      xml.appendValue(lv.getId()).append("</id>");
      xml.append("<value>");
      xml.appendValue(lv.getValue()).append("</value>");
      xml.append("</listValue>");
    }
    xml.append("</listValues>");
    xml.append("</fieldEquipmentType>");
    return xml.toString();
  }
}