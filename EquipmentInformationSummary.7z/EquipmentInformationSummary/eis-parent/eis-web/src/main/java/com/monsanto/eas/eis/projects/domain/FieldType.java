/*
 FieldType was created on Oct 3, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: FieldType.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date:
 * 2008/10/06 18:07:47 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_FIELD_TYPE")
public class FieldType {

  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "TYPE")
  private String type;

  public FieldType() {
  }

  public Long getId() {
    return id;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public boolean isValueNotNull(String value) {
    String fieldType = this.getType();
    if (fieldType.equalsIgnoreCase("text") || fieldType.equalsIgnoreCase("textarea") ||
        fieldType.equalsIgnoreCase("select") || fieldType.equalsIgnoreCase("radio")) {
      return value != null && value.trim().length() > 0;
    } else if (this.getType().equalsIgnoreCase("checkbox")) {
      return value != null && value.equalsIgnoreCase("on");
    }
    return false;
  }

}