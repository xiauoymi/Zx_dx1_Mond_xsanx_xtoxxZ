/*
 Instrument was created on Oct 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.eas.eis.Copyable;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: Instrument.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date:
 * 2008/10/23 16:20:37 $
 *
 * @author sspati1
 * @version $Revision: 1.17 $
 */
@Entity
@AccessType("field")
@Table(schema = "EIS", name = "EIS_INSTRUMENT")
public class Instrument implements XmlObject, Copyable, Comparable {
  @Id
  @SequenceGenerator(name = "equipmentSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "equipmentSeqGen")
  @Column(name = "ID")
  private Long id;

  @Column(name = "PURCHASED_WITH_EQUIP")
  @Type(type = "yes_no")
  private boolean purchasedWithEquipment;

  @ManyToOne()
  @JoinColumn(name = "DESIGNATOR_CHAR_1")
  private InstrumentDesignator designatorFirstChar;

  @ManyToOne()
  @JoinColumn(name = "DESIGNATOR_CHAR_2")
  private InstrumentDesignator designatorSecondChar;

  @Column(name = "SEQ_NUM")
  private String sequenceNumber;

  @Column(name = "DESCRIPTION")
  private String instDescription;

  @ManyToOne
  @JoinColumn(name = "IO_TYPE_ID")
  private IOType ioType;

  @Column(name = "ALARM_POINTS")
  private String alarmPoints;

  @Column(name = "ALARM_POINTS_QTY")
  private Integer alarmPointsQuantity;

  @Column(name = "VOLTS")
  private Integer volts;

  @Column(name = "RANGE")
  private String range;

  @Column(name = "UNITS")
  private String units;

  @Column(name = "COMMENTS")
  private String comments;

  @ManyToOne(fetch=FetchType.LAZY) 
  @JoinColumn(name = "equipment_id")
  private Equipment equipment;

  @Column(name="ESTIMATED_COST")
  private Integer estimatedCost;

  @Column(name="ACTUAL_COST")
  private Integer actualCost;

  @Column(name="BID_PACKAGE")
  private String bidPackage;

  @Column(name="MANUFACTURER")
  private String manufacturer;

  @Column(name="MODEL_NUMBER")
  private String modelNumber;

  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "PURCHASING_ID")
  private Purchasing purchasing;

  @Column(name = "IS_DELETED")
  @Type(type = "yes_no")
  private boolean isDeleted;

  public Instrument() {
  }

  public Instrument(Long id, InstrumentDesignator designatorFirstChar, InstrumentDesignator designatorSecondChar,
                    String sequenceNumber, String instDescription, IOType ioType,
                    String alarmPoints, Integer alarmPointsQuantity, Integer volts, String range, String units,
                    String comments, boolean purchasedWithEquipment, Purchasing purchasing, Equipment equipment,
                    Integer estimatedCost, Integer actualCost, String bidPackage, String manufacturer,
                    String modelNumber) {
    this.id = id;
    this.designatorFirstChar = designatorFirstChar;
    this.designatorSecondChar = designatorSecondChar;
    this.sequenceNumber = sequenceNumber;
    this.instDescription = instDescription;
    this.ioType = ioType;
    this.alarmPoints = alarmPoints;
    this.alarmPointsQuantity = alarmPointsQuantity;
    this.volts = volts;
    this.range = range;
    this.units = units;
    this.comments = comments;
    this.purchasedWithEquipment = purchasedWithEquipment;
    this.purchasing = purchasing;
    this.equipment = equipment;
    this.estimatedCost = estimatedCost;
    this.actualCost = actualCost;
    this.bidPackage = bidPackage;
    this.manufacturer = manufacturer;
    this.modelNumber = modelNumber;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public boolean isPurchasedWithEquipment() {
    return purchasedWithEquipment;
  }

  public InstrumentDesignator getDesignatorFirstChar() {
    return designatorFirstChar;
  }

  public InstrumentDesignator getDesignatorSecondChar() {
    return designatorSecondChar;
  }

  public String getSequenceNumber() {
    return sequenceNumber;
  }

  public String getInstDescription() {
    return instDescription;
  }

  public IOType getIoType() {
    return ioType;
  }

  public String getAlarmPoints() {
    return alarmPoints;
  }

  public Integer getAlarmPointsQuantity() {
    return alarmPointsQuantity;
  }

  public Integer getVolts() {
    return volts;
  }

  public String getRange() {
    return range;
  }

  public String getUnits() {
    return units;
  }

  public String getComments() {
    return comments;
  }

  public Equipment getEquipment() {
    return equipment;
  }

  public Purchasing getPurchasing() {
    return purchasing;
  }

  public void setPurchasedWithEquipment(boolean purchasedWithEquipment) {
    this.purchasedWithEquipment = purchasedWithEquipment;
  }

  public void setInstDescription(String instDescription) {
    this.instDescription = instDescription;
  }

  public void setIoType(IOType ioType) {
    this.ioType = ioType;
  }

  public void setAlarmPoints(String alarmPoints) {
    this.alarmPoints = alarmPoints;
  }

  public void setAlarmPointsQuantity(Integer alarmPointsQuantity) {
    this.alarmPointsQuantity = alarmPointsQuantity;
  }

  public void setVolts(Integer volts) {
    this.volts = volts;
  }

  public void setRange(String range) {
    this.range = range;
  }
  
  public void setUnits(String units) {
    this.units = units;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public void setDeleted(boolean deleted) {
    isDeleted = deleted;
  }

  public boolean isDeleted() {
    return isDeleted;
  }

  public void setPurchasing(Purchasing purchasing) {
    this.purchasing = purchasing;
  }

  public void setEquipment(Equipment equipment) {
    this.equipment = equipment;
  }

  public String getBidPackage() {
    return bidPackage;
  }

  public void setBidPackage(String bidPackage) {
    this.bidPackage = bidPackage;
  }

  public String getManufacturer() {
    return manufacturer;
  }

  public void setManufacturer(String manufacturer) {
    this.manufacturer = manufacturer;
  }

  public String getModelNumber() {
    return modelNumber;
  }

  public void setModelNumber(String modelNumber) {
    this.modelNumber = modelNumber;
  }

  public Instrument createCopy() throws CloneNotSupportedException {
    Instrument instrument = (Instrument) super.clone();
    instrument.setId(null);
    instrument.setPurchasing(getPurchasing().createCopy());
    return instrument;
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<instrument>");
    xml.append(getEquipment().toXmlWithBasicFields());
    xml.append("<instrumentId>");
    xml.appendValue(getId()).append("</instrumentId>");
    appendDesignatorFirstCharXml(xml);
    appendDesignatorSecondCharXml(xml);
    xml.append("<sequenceNumber>");
    xml.appendValue(getSequenceNumber()).append("</sequenceNumber>");
    xml.append("<instDescription>");
    xml.appendValue(getInstDescription()).append("</instDescription>");
    if (getIoType() == null) {
      xml.append("<ioTypeId>");
      xml.appendValue("").append("</ioTypeId>");
    } else {
      xml.append("<ioTypeId>");
      xml.appendValue(getIoType().getId()).append("</ioTypeId>");
    }
    xml.append("<alarmPoints>");
    xml.appendValue(getAlarmPoints()).append("</alarmPoints>");
    xml.append("<alarmPointsQuantity>");
    xml.appendValue(getAlarmPointsQuantity())
        .append("</alarmPointsQuantity>");
    xml.append("<volts>");
    xml.appendValue(getVolts()).append("</volts>");
    xml.append("<range>");
    xml.appendValue(getRange()).append("</range>");
    xml.append("<units>");
    xml.appendValue(getUnits()).append("</units>");
    xml.append("<comments>");
    xml.appendValue(getComments()).append("</comments>");
    xml.append("<bidPackage>");
    xml.appendValue(getBidPackage()).append("</bidPackage>");
    xml.append("<manufacturer>");
    xml.appendValue(getManufacturer()).append("</manufacturer>");
    xml.append("<modelNumber>");
    xml.appendValue(getModelNumber()).append("</modelNumber>");
    xml.append("<estimatedCost>");
    xml.appendValue(getEstimatedCost());
    xml.append("</estimatedCost>");
    xml.append("<actualCost>");
    xml.appendValue(getActualCost());
    xml.append("</actualCost>");

    xml.append("<purchasedWithEquipment>");
    xml.appendValue(new Boolean(isPurchasedWithEquipment()))
        .append("</purchasedWithEquipment>");
    xml.append(getPurchasing().toXmlWithoutEquipment());
    xml.append("</instrument>");
    return xml.toString();
  }

  //todo refactor this 
  private void appendDesignatorSecondCharXml(XMLBuffer xml) {
    if (getDesignatorSecondChar() == null) {
      xml.append("<designatorSecondCharId>");
      xml.appendValue("").append("</designatorSecondCharId>");
      xml.append("<designatorSecondCharTypeCode>");
      xml.appendValue("").append("</designatorSecondCharTypeCode>");
    } else {
      xml.append("<designatorSecondCharId>");
      xml.appendValue(getDesignatorSecondChar().getId())
          .append("</designatorSecondCharId>");
      xml.append("<designatorSecondCharTypeCode>");
      xml.appendValue(getDesignatorSecondChar().getTypeCode())
          .append("</designatorSecondCharTypeCode>");
    }
  }

  private void appendDesignatorFirstCharXml(XMLBuffer xml) {
    if (getDesignatorFirstChar() == null) {
      xml.append("<designatorFirstCharId>");
      xml.appendValue("").append("</designatorFirstCharId>");
      xml.append("<designatorFirstCharTypeCode>");
      xml.appendValue("").append("</designatorFirstCharTypeCode>");
    } else {
      xml.append("<designatorFirstCharId>");
      xml.appendValue(getDesignatorFirstChar().getId())
          .append("</designatorFirstCharId>");
      xml.append("<designatorFirstCharTypeCode>");
      xml.appendValue(getDesignatorFirstChar().getTypeCode())
          .append("</designatorFirstCharTypeCode>");
    }
  }

  private Object returnEmptyIfNull(Object obj) {
    if (obj == null) {
      return "";
    } else {
      return obj;
    }
  }

  public String getFormattedId(){
    return "'" + this.getId() + "',";
  }
  
  public String getInstrumentAndRelatedIds(){
    StringBuffer ids = new StringBuffer();
    ids.append(getFormattedId());
    if (getDesignatorFirstChar() != null){
      ids.append(getDesignatorFirstChar().getFormattedId());
    }
    if (getDesignatorSecondChar() != null){
      ids.append(getDesignatorSecondChar().getFormattedId());
    }
    
    if (this.getIoType() != null){
      ids.append(getIoType().getFormattedId());
    }
    if (getPurchasing() != null){
      ids.append(getPurchasing().getFormattedId());
    }
    return ids.toString().substring(0, ids.toString().length() - 1);
  }

  public int compareTo(Object o) {
    return id.compareTo(((Instrument)o).getId());
  }

  public Integer getEstimatedCost() {
    return estimatedCost;
  }

  public Integer getActualCost() {
    return actualCost;
  }

  //Need setters for autosave functionality to work.
  public void setEstimatedCost(Integer estimatedCost) {
    this.estimatedCost = estimatedCost;
  }

  public void setActualCost(Integer actualCost) {
    this.actualCost = actualCost;
  }
}