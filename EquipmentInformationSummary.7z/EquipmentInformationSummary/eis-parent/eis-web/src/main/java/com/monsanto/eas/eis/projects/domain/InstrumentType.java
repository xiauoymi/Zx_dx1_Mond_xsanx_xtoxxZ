/*
 Instrument_Type was created on Oct 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import org.hibernate.annotations.AccessType;

import javax.persistence.*;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.eas.eis.util.XMLBuffer;

/**
 * Filename:    $RCSfile: InstrumentType.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2009-01-30 22:13:29 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_INSTRUMENT_TYPE")
public class InstrumentType implements XmlObject {
  @Id
  @SequenceGenerator(name = "equipmentSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "equipmentSeqGen")
  @Column(name = "ID")
  private Long id;

  @Column(name = "TYPE")
  private String type;

  public InstrumentType() {
  }

  public InstrumentType(Long id) {
    this.id = id;
    this.type = type;
  }

  public Long getId() {
    return id;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String toXml() {
    XMLBuffer xmlStr = new XMLBuffer("<instrumentType>");
    xmlStr.append("<id>");
    xmlStr.appendValue(getId())
            .append("</id>");
    xmlStr.append("<name>");
    xmlStr.appendValue(getType())
            .append("</name>");
    xmlStr.append("</instrumentType>");
    return xmlStr.toString();
  }
}