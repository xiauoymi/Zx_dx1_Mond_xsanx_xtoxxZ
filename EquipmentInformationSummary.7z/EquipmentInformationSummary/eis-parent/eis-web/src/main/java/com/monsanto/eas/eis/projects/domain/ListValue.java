/*
 ListValue was created on Oct 3, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;

import org.hibernate.annotations.AccessType;

/**
 * Filename:    $RCSfile: ListValue.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-11-20 21:53:59 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_LIST_VALUE")
public class ListValue {
    @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "VALUE")
  private String value;

  @ManyToOne()
  @JoinColumn(name = "FIELD_EQUIPMENT_ID")
  private FieldEquipmentType fieldEquipmentType;

  public ListValue() {
  }

  public ListValue(Long id, String value) {
    this.value = value;
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public String getValue() {
    return value;
  }

  public FieldEquipmentType getFieldEquipmentType() {
    return fieldEquipmentType;
  }
}