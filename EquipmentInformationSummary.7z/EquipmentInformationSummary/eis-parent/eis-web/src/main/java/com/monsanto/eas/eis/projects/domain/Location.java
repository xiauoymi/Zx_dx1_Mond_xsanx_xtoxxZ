package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.eas.eis.util.XMLBuffer;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * @author VVVELU
 */

@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_LOC")
public class Location implements Serializable, XmlObject {

  private static final long serialVersionUID = -8702798533419799188L;

  @Id
  @SequenceGenerator(name = "locSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "locSeqGen")
  private Long id;

  @OneToMany(mappedBy = "parentLocation")
  @org.hibernate.annotations.OrderBy(clause = "LOC_NAME asc")
  private List<Location> childLocations = new ArrayList<Location>();

  @ManyToOne
  @JoinColumn(name = "PARENT_LOC_ID")
  private Location parentLocation;

  @Column(name = "LOC_NAME")
  private String name;

//  @Column(name = "parent_loc_id")
//  private String parent_loc_id;

  public Location() {
  }

  public Location(Long id, String name) {
    this.id = id;
    this.name = name;
  }


  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<Location> getChildLocations() {
    return childLocations;
  }

  public void setChildLocations(List<Location> childLocations) {
    this.childLocations = childLocations;
  }

  public void setParentLocation(Location parentLocation) {
    this.parentLocation = parentLocation;
  }

  public void addChildLocation(Location location) {
    getChildLocations().add(location);
  }

  public Location getParentLocation() {
    return parentLocation;
  }

  public boolean equals(Object obj) {
//    return obj == null || !(obj instanceof Location) ? false : name.equals(((Location) obj).getName());
    return obj == null || !(obj instanceof Location) ? false : id.equals(((Location) obj).getId());
  }

//  public String getParent_loc_id() {
//    return parent_loc_id;
//  }
//
//  public void setParent_loc_id(String parent_loc_id) {
//    this.parent_loc_id = parent_loc_id;
//  }

  public int hashCode() {
    return id.hashCode();
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<location>");
    xml.append("<id>");
    xml.appendValue(getId())
            .append("</id>");
    xml.append("<name>");
    xml.appendValue(getName())
            .append("</name>");
    xml.append("</location>");
    return xml.toString();
  }
}
