package com.monsanto.eas.eis.projects.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.eas.eis.controller.XmlObject;

import javax.persistence.*;
import java.io.Serializable;

import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 20, 2008 Time: 2:58:48 PM To change this template use File |
 * Settings | File Templates.
 */
//TODO: TO BE DELTED
public class MechBidPackWorkDesc {


  public MechBidPackWorkDesc() {
  }


}
