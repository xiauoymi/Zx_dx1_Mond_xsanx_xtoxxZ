package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.eas.eis.Copyable;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 13, 2008 Time: 10:17:21 AM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_MECHANICAL")

public class Mechanical implements Serializable, XmlObject, Copyable {

  private static final long serialVersionUID = 1L;

  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "engineer")
  private String engineer;

  @Column(name = "model_number")
  private String modelNumber;

  @Column(name = "shipping_weight")
  private Integer shippingWeight;


  @ManyToOne
  @JoinColumn(name = "PURCHASE_SCOPE_ID")
  private PurchaseScope purchaseScope;


  @Column(name = "operating_weight")
  private Integer operatingWeight;

  @Column(name = "serial_number")
  private String serialNumber;

  @Column(name = "bid_package_one")
  private String bidPackageOne;

  @Column(name = "work_description_one")
  private String workDescriptionOne;

  @Column(name = "bid_package_two")
  private String bidPackageTwo;

  @Column(name = "work_description_two")
  private String workDescriptionTwo;

  @Column(name = "dyn_load")
  private String dynLoad;
  
  @OneToOne(mappedBy = "mechanical")
  private Equipment equipment;


  public Mechanical() {}

  public Mechanical(String engineer, String modelNumber, Integer shippingWeight, PurchaseScope purchaseScope,
                    Integer operatingWeight, String serialNumber,
                    String dynLoad, Equipment equipment) {
    this.engineer = engineer;
    this.modelNumber = modelNumber;
    this.shippingWeight = shippingWeight;
    this.purchaseScope = purchaseScope;
    this.operatingWeight = operatingWeight;
    this.serialNumber = serialNumber;
    this.dynLoad = dynLoad;
    this.equipment = equipment;
  }

  public Equipment getEquipment() {
    return equipment;
  }

  public Long getId() {
    return this.id;
  }

  public String getEngineer() {
    return this.engineer;
  }

  public String getModelNumber() {
    return this.modelNumber;
  }

  public Integer getShippingWeight() {
    return shippingWeight;
  }

  public PurchaseScope getPurchaseScope() {
    return purchaseScope;
  }

  public Integer getOperatingWeight() {
    return operatingWeight;
  }

   public String getSerialNumber() {
    return serialNumber;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void setEngineer(String engineer) {
    this.engineer = engineer;
  }

  public void setModelNumber(String modelNumber) {
    this.modelNumber = modelNumber;
  }

  public void setShippingWeight(Integer shippingWeight) {
    this.shippingWeight = shippingWeight;
  }

  public void setPurchaseScope(PurchaseScope purchaseScope) {
    this.purchaseScope = purchaseScope;
  }

  public void setOperatingWeight(Integer operatingWeight) {
    this.operatingWeight = operatingWeight;
  }

   public void setSerialNumber(String serialNumber) {
    this.serialNumber = serialNumber;
  }

  public String getBidPackageOne() {
    return bidPackageOne;
  }

  public void setBidPackageOne(String bidPackageOne) {
    this.bidPackageOne = bidPackageOne;
  }

  public String getWorkDescriptionOne() {
    return workDescriptionOne;
  }

  public void setWorkDescriptionOne(String workDescriptionOne) {
    this.workDescriptionOne = workDescriptionOne;
  }

  public String getBidPackageTwo() {
    return bidPackageTwo;
  }

  public void setBidPackageTwo(String bidPackageTwo) {
    this.bidPackageTwo = bidPackageTwo;
  }

  public String getWorkDescriptionTwo() {
    return workDescriptionTwo;
  }

  public void setWorkDescriptionTwo(String workDescriptionTwo) {
    this.workDescriptionTwo = workDescriptionTwo;
  }

  public Mechanical createCopy() throws CloneNotSupportedException {
    Mechanical mechanical = (Mechanical) super.clone();
    mechanical.setId(null);
    return mechanical;
  }

    public String getFormattedId(){
    return getId() == null ? "" : "'" + getId() + "',";
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<mechanical>");
    xml.append(getEquipment().toXmlWithBasicFields());
    xml.append("<mechId>");
    xml.appendValue(returnEmptyIfNull(getId()))
            .append("</mechId>");
    xml.append("<engineer>");
    xml.appendValue(returnEmptyIfNull(getEngineer()))
            .append("</engineer>");
    xml.append("<modelNumber>");
    xml.appendValue(returnEmptyIfNull(getModelNumber()))
            .append("</modelNumber>");
    xml.append("<shippingWeight>");
    xml.appendValue(returnEmptyIfNull(getShippingWeight()))
            .append("</shippingWeight>");

    if(getPurchaseScope() != null) {
      xml.append("<purchaseScopeId>");
      xml.appendValue(returnEmptyIfNull(getPurchaseScope().getId()))
              .append("</purchaseScopeId>");
      xml.append("<purchaseScopeName>");
      xml.appendValue(returnEmptyIfNull(getPurchaseScope().getPurchaseScopeName()))
              .append("</purchaseScopeName>");
    } else {
      xml.append("<purchaseScopeId>").append("").append("</purchaseScopeId>");
      xml.append("<purchaseScopeName>").append("").append("</purchaseScopeName>");
    }

    xml.append("<operatingWeight>");
    xml.appendValue(returnEmptyIfNull(getOperatingWeight()))
            .append("</operatingWeight>");
    xml.append("<dynamicLoad>");
    xml.appendValue(returnEmptyIfNull(getDynLoad()))
            .append("</dynamicLoad>");
    xml.append("<serialNumber>");
    xml.appendValue(returnEmptyIfNull(getSerialNumber()))
            .append("</serialNumber>");
    xml.append("<bidPackageOne>");
    xml.appendValue(returnEmptyIfNull(getBidPackageOne()))
            .append("</bidPackageOne>");
    xml.append("<workDescriptionOne>");
    xml.appendValue(returnEmptyIfNull(getWorkDescriptionOne()))
            .append("</workDescriptionOne>");
    xml.append("<bidPackageTwo>");
    xml.appendValue(returnEmptyIfNull(getBidPackageTwo()))
            .append("</bidPackageTwo>");
    xml.append("<workDescriptionTwo>");
    xml.appendValue(returnEmptyIfNull(getWorkDescriptionTwo()))
            .append("</workDescriptionTwo>");
    xml.append("</mechanical>");
    return xml.toString();
  }

  private Object returnEmptyIfNull(Object obj){
    if(obj == null){
      return "";
    }else{
      return obj;
    }
  }


  public void setEquipment(Equipment equipment) {
    this.equipment = equipment;
  }

  public String getMechanicalAndRelatedIds() {
     StringBuffer ids = new StringBuffer();
     ids.append(this.getFormattedId());
     ids.append(this.getPurchaseScopeId());
    return ids.toString().substring(0, ids.toString().length() - 1);
  }

  private String getPurchaseScopeId() {
    String id = "";
    if (this.getPurchaseScope() != null){
       return this.getPurchaseScope().getFormattedId();
     }
    return id;
  }

  public String getDynLoad() {
    return dynLoad;
  }

  public void setDynLoad(String dynLoad) {
    this.dynLoad = dynLoad;
  }
}
