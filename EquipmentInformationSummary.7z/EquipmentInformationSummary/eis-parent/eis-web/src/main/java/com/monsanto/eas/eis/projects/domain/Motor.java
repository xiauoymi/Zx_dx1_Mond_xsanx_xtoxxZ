package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.eas.eis.Copyable;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

import javax.persistence.*;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 14, 2008 Time: 10:45:14 AM To change this template use File |
 * Settings | File Templates.
 */

@Entity
@AccessType("field")
@Table(schema = "EIS", name = "EIS_MOTOR")
public class Motor implements XmlObject, Copyable, Comparable {

  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @ManyToOne
  @JoinColumn(name = "COMP_DESIGNATOR_ID")
  private ComponentDesignator componentDesignator;

  @Column(name = "SEQ_NUM")
  private String sequenceNumber;

  @Column(name = "COMPONENT_NAME")
  private String componentName;

  @Column(name = "FLA")
  private Double fla;

  @Column(name = "MOTOR_VOLTAGE", columnDefinition = "Number(4,2) default=460")
  private Integer motorVoltage = 460;

  @Column(name = "PHASE", columnDefinition = "Number(1, 0) default=1")
  private Integer phase = 1;

  @Column(name = "FREQUENCY", columnDefinition = "Number(2, 0) default=60")
  private Integer frequency = 60;

  @Column(name = "RPM")
  private Integer rpm;

  @ManyToOne
  @JoinColumn(name = "DESIGN_STATUS_ID")
  private MotorDesignStatus designStatus;

  @Column(name = "COMMENTS")
  private String comments;

  @ManyToOne
  @JoinColumn(name = "LOAD_VALUE_TYP_ID")
  private MotorLoadValueType loadValueType;

  @Column(name = "LOAD_VALUE_QTY")
  private Double loadValueQuantity;

  @Column(name = "POWER_SOURCE")
  private String powerSource;

  @Column(name = "IO_CABINET")
  private String ioCabinet;

  @Column(name = "LOAD_DISCONNECT_REQ")
  @Type(type = "yes_no")
  private boolean loadDisconnectRequired;

  @Column(name = "STARTER_SIZE")
  private String starterSize;


  @ManyToOne(fetch=FetchType.LAZY) 
  @JoinColumn(name = "equipment_id")
  private Equipment equipment;

  @Column(name="BID_PACKAGE")
  private String bidPackage;

  @Column(name = "MOTOR_BRAKE")
  @Type(type = "yes_no")
  private boolean motorBrake;


  @Column(name = "IS_DELETED")
  @Type(type = "yes_no")
  private boolean isDeleted;

  public Motor() {
  }

  public Motor(Long id, ComponentDesignator componentDesignator, String sequenceNum,
               String componentName, Double fla,
               Integer motorVoltage,
               Integer phase, Integer frequency, Integer rpm, MotorDesignStatus designStatus,
               String comments, MotorLoadValueType loadValueType, Double loadValueQty, String powerSource,
               String ioCabinet, boolean loadDisconnectReq, String starterSize, Equipment equipment, String bidPackage) {
    this.id = id;
    this.componentDesignator = componentDesignator;
    this.sequenceNumber = sequenceNum;
    this.componentName = componentName;
    this.fla = fla;
    this.motorVoltage = motorVoltage;
    this.phase = phase;
    this.frequency = frequency;
    this.rpm = rpm;
    this.designStatus = designStatus;
    this.comments = comments;
    this.loadValueType = loadValueType;
    this.loadValueQuantity = loadValueQty;
    this.powerSource = powerSource;
    this.ioCabinet = ioCabinet;
    this.loadDisconnectRequired = loadDisconnectReq;
    this.starterSize = starterSize;
    this.equipment = equipment;
    this.bidPackage = bidPackage;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public ComponentDesignator getComponentDesignator() {
    return componentDesignator;
  }

  public String getSequenceNumber() {
    return sequenceNumber;
  }

  public String getComponentName() {
    return componentName;
  }

  public Double getFla() {
    return fla;
  }

  public Integer getMotorVoltage() {
    return motorVoltage;
  }

  public Integer getPhase() {
    return phase;
  }

  public Integer getFrequency() {
    return frequency;
  }

  public Integer getRpm() {
    return rpm;
  }


  public MotorDesignStatus getDesignStatus() {
    return designStatus;
  }

  public String getComments() {
    return comments;
  }

  public MotorLoadValueType getLoadValueType() {
    return loadValueType;
  }

  public Double getLoadValueQuantity() {
    return loadValueQuantity;
  }

  public String getPowerSource() {
    return powerSource;
  }

  public String getIoCabinet() {
    return ioCabinet;
  }

  public boolean isLoadDisconnectRequired() {
    return loadDisconnectRequired;
  }

  public String getStarterSize() {
    return starterSize;
  }

  public Equipment getEquipment() {
    return equipment;
  }

  public boolean isMotorBrake() {
    return motorBrake;
  }

  public void setMotorBrake(boolean motorBrake) {
    this.motorBrake = motorBrake;
  }

  public void setDeleted(boolean deleted) {
    isDeleted = deleted;
  }

  public boolean isDeleted() {
    return isDeleted;
  }

  public void setComponentName(String componentName) {
    this.componentName = componentName;
  }

  public void setComponentDesignator(ComponentDesignator componentDesignator) {
    this.componentDesignator = componentDesignator;
  }

  public void setFla(Double fla) {
    this.fla = fla;
  }

  public void setMotorVoltage(Integer motorVoltage) {
    this.motorVoltage = motorVoltage;
  }

  public void setPhase(Integer phase) {
    this.phase = phase;
  }

  public void setFrequency(Integer frequency) {
    this.frequency = frequency;
  }

  public void setRpm(Integer rpm) {
    this.rpm = rpm;
  }

  public void setDesignStatus(MotorDesignStatus designStatus) {
    this.designStatus = designStatus;
  }

  public void setComments(String comments) {
    this.comments = comments;
  }

  public void setLoadValueType(MotorLoadValueType loadValueType) {
    this.loadValueType = loadValueType;
  }

  public void setLoadValueQuantity(Double loadValueQuantity) {
    this.loadValueQuantity = loadValueQuantity;
  }

  public void setPowerSource(String powerSource) {
    this.powerSource = powerSource;
  }

  public void setIoCabinet(String ioCabinet) {
    this.ioCabinet = ioCabinet;
  }

  public void setLoadDisconnectRequired(boolean loadDisconnectRequired) {
    this.loadDisconnectRequired = loadDisconnectRequired;
  }

  public void setStarterSize(String starterSize) {
    this.starterSize = starterSize;
  }

  public void setEquipment(Equipment equipment) {
    this.equipment = equipment;
  }

  public void setBidPackage(String bidPackage) {
    this.bidPackage = bidPackage;
  }

  public String getBidPackage() {
    return bidPackage;
  }

  public Motor createCopy() throws CloneNotSupportedException {
    Motor motor = (Motor) super.clone();
    motor.setId(null);
    return motor;
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<motor>");
    xml.append(getEquipment().toXmlWithBasicFields());
    xml.append("<motorId>");
    xml.appendValue(getId()).append("</motorId>");
    getComponentDesignatorXml(xml);
    xml.append("<sequenceNumber>");
    xml.appendValue(getSequenceNumber()).append("</sequenceNumber>");
    xml.append("<componentName>");
    xml.appendValue(getComponentName()).append("</componentName>");
    xml.append("<fla>");
    xml.appendValue(getFla()).append("</fla>");
    xml.append("<motorVoltage>");
    xml.appendValue(getMotorVoltage()).append("</motorVoltage>");
    xml.append("<phase>");
    xml.appendValue(getPhase()).append("</phase>");
    xml.append("<frequency>");
    xml.appendValue(getFrequency()).append("</frequency>");
    xml.append("<rpm>");
    xml.appendValue(getRpm()).append("</rpm>");
    getDesignStatusXml(xml);
    xml.append("<comments>");
    xml.appendValue(getComments()).append("</comments>");
    getLoadValueTypeXml(xml);
    xml.append("<loadValueQuantity>");
    xml.appendValue(getLoadValueQuantity()).append("</loadValueQuantity>");
    xml.append("<ioCabinet>");
    xml.appendValue(getIoCabinet()).append("</ioCabinet>");
    xml.append("<powerSource>");
    xml.appendValue(getPowerSource()).append("</powerSource>");
    xml.append("<loadDisconnectRequired>");
    xml.appendValue(new Boolean(isLoadDisconnectRequired()).toString())
        .append("</loadDisconnectRequired>");
    xml.append("<starterSize>");
    xml.appendValue(getStarterSize()).append("</starterSize>");
    xml.append("<motorBrake>");
    xml.appendValue(new Boolean(isMotorBrake()).toString()).append("</motorBrake>");
    xml.append("<bidPackage>");
    xml.appendValue(getBidPackage()).append("</bidPackage>");
    xml.append("</motor>");
    return xml.toString();
  }

  private void getComponentDesignatorXml(XMLBuffer xml) {
    if (getComponentDesignator() == null) {
      xml.append("<componentDesignatorId>");
      xml.appendValue("")
          .append("</componentDesignatorId>");
      xml.append("<componentDesignatorTypeCode>");
      xml.appendValue("")
          .append("</componentDesignatorTypeCode>");
    } else {
      xml.append("<componentDesignatorId>");
      xml.appendValue(getComponentDesignator().getId())
          .append("</componentDesignatorId>");
      xml.append("<componentDesignatorTypeCode>");
      xml.appendValue(getComponentDesignator().getTypeCode())
          .append("</componentDesignatorTypeCode>");
    }
  }

  private void getLoadValueTypeXml(XMLBuffer xml) {
    if (getLoadValueType() == null) {
      xml.append("<loadValueTypeId>");
      xml.appendValue("").append("</loadValueTypeId>");
    } else {
      xml.append("<loadValueTypeId>");
      xml.appendValue(getLoadValueType().getId()).append("</loadValueTypeId>");
    }
  }

  private void getDesignStatusXml(XMLBuffer xml) {
    if (getDesignStatus() == null) {
      xml.append("<designStatusId>");
      xml.appendValue("").append("</designStatusId>");
    } else {
      xml.append("<designStatusId>");
      xml.appendValue(getDesignStatus().getId()).append("</designStatusId>");
    }
  }
  public String getFormattedId(){
    return "'" + this.getId() + "',";
  }

 public String getMotorAndRelatedIds(){
    StringBuffer ids = new StringBuffer();
    ids.append(this.getFormattedId());
    if (this.getLoadValueType() != null){
       ids.append(this.getLoadValueType().getFormattedId());
    }
    if (this.getComponentDesignator() != null){
      ids.append(this.getComponentDesignator().getFormattedId());
    }
    if (this.getDesignStatus() != null){
      ids.append(this.getDesignStatus().getFormattedId());
    }
   return ids.toString().substring(0, ids.toString().length() - 1);
 }

  public int compareTo(Object o) {
   return id.compareTo(((Motor) o).getId());
  }
}
