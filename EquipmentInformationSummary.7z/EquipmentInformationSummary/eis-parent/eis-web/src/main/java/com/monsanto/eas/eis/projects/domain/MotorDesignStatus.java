package com.monsanto.eas.eis.projects.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import javax.persistence.*;
import java.io.Serializable;

import org.hibernate.annotations.AccessType;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 14, 2008 Time: 10:33:19 AM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_MOTOR_DESIGN_STATUS")
public class MotorDesignStatus implements XmlObject {
  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "STATUS")
  private String status;

  public MotorDesignStatus() {}

  public MotorDesignStatus(Long id) {
    this.id = id;
    this.status = status;
  }

  public Long getId() {
    return id;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

    public String getFormattedId(){
    return "'" + this.getId() + "',";
  }

  public String toXml() {
    XMLBuffer xmlStr = new XMLBuffer("<designStatus>");
    xmlStr.append("<id>");
    xmlStr.appendValue(getId()).append("</id>");
    xmlStr.append("<name>");
    xmlStr.appendValue(getStatus()).append("</name>");
    xmlStr.append("</designStatus>");
    return xmlStr.toString();
  }
}
