package com.monsanto.eas.eis.projects.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.eas.eis.controller.XmlObject;
import org.hibernate.annotations.AccessType;
import com.monsanto.eas.eis.util.XMLBuffer;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 14, 2008 Time: 10:39:20 AM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_MOTOR_LOAD_VALUE_TYPE")
public class MotorLoadValueType implements XmlObject {
  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "TYPE")
  private String type;

  public MotorLoadValueType() {
  }

  public MotorLoadValueType(Long id) {
    this.id = id;
    this.type = type;
  }

  public Long getId() {
    return id;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

    public String getFormattedId(){
    return "'" + this.getId() + "',";
  }

  public String toXml() {
    XMLBuffer xmlStr = new XMLBuffer("<loadValueType>");
    xmlStr.append("<id>");
    xmlStr.appendValue(getId()).append("</id>");
    xmlStr.append("<name>");
    xmlStr.appendValue(getType()).append("</name>");
    xmlStr.append("</loadValueType>");
    return xmlStr.toString();
  }
}
