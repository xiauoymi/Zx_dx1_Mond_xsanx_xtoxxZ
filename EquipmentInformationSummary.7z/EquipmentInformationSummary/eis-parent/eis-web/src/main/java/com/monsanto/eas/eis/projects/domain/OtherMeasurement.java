package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.eas.eis.util.XMLBuffer;
import javax.persistence.*;
import java.io.Serializable;

import org.hibernate.annotations.AccessType;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 23, 2008 Time: 10:30:58 AM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_OTHER_MEASUREMENT")

public class OtherMeasurement implements Serializable, XmlObject {
  private static final long serialVersionUID = 1L;

  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "OTHER_MEASUREMENT")
  private String measurement;

  public OtherMeasurement() {}

  public OtherMeasurement(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getMeasurement() {
    return measurement;
  }

  public void setMeasurement(String measurement) {
    this.measurement = measurement;
  }

  public String toXml() {
    XMLBuffer xmlStr = new XMLBuffer("<otherMeasurement>");
    xmlStr.append("<id>");
    xmlStr.appendValue(getId()).append("</id>");
    xmlStr.append("<measurement>");
    xmlStr.appendValue(getMeasurement()).append("</measurement>");
    xmlStr.append("</otherMeasurement>");
    return xmlStr.toString();
  }

   public String getFormattedId (){
    return getId() == null ? "" : "'" + getId() + "',";
  }

}
