/*
 Process was created on Sep 29, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.Copyable;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: Process.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date:
 * 2008/10/01 13:15:48 $
 *
 * @author sspati1
 * @version $Revision: 1.14 $
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_PROCESS")
public class Process implements Serializable, XmlObject, Copyable {

  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "PRODUCT_TYPE")
  private String productType;

  @Column(name = "PRODUCT_DENSITY")
  private Double productDensity;

  @Column(name = "DESIGN_CAPACITY")
  private Integer designCapacity;

  @Column(name = "COMP_AIR_REQUIRED")
  @Type(type = "yes_no")
  private boolean compAirRequired;

  @Column(name = "COMP_AIR_PRESSURE")
  private Integer compAirPressure;

  @Column(name = "COMP_AIR_FLOWRATE")
  private Integer compAirFlowrate;

  @Column(name = "GAS_REQUIRED")
  @Type(type = "yes_no")
  private boolean gasRequired;

  @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
  @JoinColumn(name = "GAS_TYPE_ID")
  private GasType gasType;

  @Column(name = "GAS_PRESSURE")
  private Integer gasPressure;

  @Column(name = "GAS_FLOWRATE")
  private Integer gasFlowrate;

  @Column(name = "WATER_REQUIRED")
  @Type(type = "yes_no")
  private boolean waterRequired;

  @Column(name = "WATER_PRESSURE")
  private Integer waterPressure;

  @Column(name = "WATER_FLOWRATE")
  private Integer waterFlowrate;

  @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
  @JoinColumn(name = "WATER_TYPE_ID")
  private WaterType waterType;

  @Column(name = "DUST_PICKUP_REQUIRED")
  @Type(type = "yes_no")
  private boolean dustPickupRequired;

  @Column(name = "DUST_PICKUP_VELOCITY")
  private Integer dustPickupVelocity;

  @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
  @JoinColumn(name = "DUST_TYPE_ID")
  private DustType dustType;

  @Column(name = "BAGHOUSE_CYCLONE")
  private String baghouseCyclone;

  @Column(name = "DUCT_SIZE")
  private Integer ductSize;


  @Column(name = "DUCT_FLOWRATE")
  private Integer ductFlowrate;

  @Column(name = "SPECIFICATION_REQUIRED")
  @Type(type = "yes_no")
  private boolean specificationRequired;

  @Column(name = "PROCESS_REMARKS")
  private String processRemarks;

  @OneToOne(mappedBy = "process")
  private Equipment equipment;

  @OneToMany(mappedBy = "process", cascade = CascadeType.ALL,
      targetEntity = ProcessFieldEquipmentType.class, fetch = FetchType.LAZY)
  @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
  private List<ProcessFieldEquipmentType> processFieldEquipmentTypes = new ArrayList<ProcessFieldEquipmentType>();

  @ManyToOne
  @JoinColumn(name = "DSGN_CAP_UNT_ID")
  private DesignCapacityUnit designCapacityUnit; //8

  @Column(name="DSGN_CAP_UNIT_TEXT")
  private String designCapacityUnitText;


  public Process() {
  }

  public Process(Long id, String productType, Double productDensity, Integer designCapacity,
                 DesignCapacityUnit designCapacityUnit, boolean compAirRequired,
                 Integer compAirPressure, Integer compAirFlowrate, boolean gasRequired, GasType gasType,
                 Integer gasPressure, Integer gasFlowrate, boolean waterRequired, Integer waterPressure,
                 Integer waterFlowrate, WaterType waterType, boolean dustPickupRequired, Integer dustPickupVelocity,
                 DustType dustType, String baghouseCyclone, Integer ductSize, Integer ductFlowrate,
                 boolean specificationRequired, String processRemarks, String dsgnCapUnitText) {
    this.id = id;
    this.productType = productType;
    this.productDensity = productDensity;
    this.designCapacity = designCapacity;
    this.designCapacityUnit = designCapacityUnit;
    this.designCapacityUnitText = dsgnCapUnitText;
    this.compAirRequired = new Boolean(compAirRequired);
    this.compAirPressure = compAirPressure;
    this.compAirFlowrate = compAirFlowrate;
    this.gasRequired = new Boolean(gasRequired);
    this.gasType = gasType;
    this.gasPressure = gasPressure;
    this.gasFlowrate = gasFlowrate;
    this.waterRequired = new Boolean(waterRequired);
    this.waterPressure = waterPressure;
    this.waterFlowrate = waterFlowrate;
    this.waterType = waterType;
    this.dustPickupRequired = new Boolean(dustPickupRequired);
    this.dustPickupVelocity = dustPickupVelocity;
    this.dustType = dustType;
    this.baghouseCyclone = baghouseCyclone;
    this.ductSize = ductSize;
    this.ductFlowrate = ductFlowrate;
    this.specificationRequired = new Boolean(specificationRequired);
    this.processRemarks = processRemarks;
  }

  public Long getId() {
    return id;
  }

  public String getProductType() {
    return productType;
  }

  public Double getProductDensity() {
    return productDensity;
  }

  public Integer getDesignCapacity() {
    return designCapacity;
  }

  public Boolean isCompAirRequired() {
    return compAirRequired;
  }

  public Integer getCompAirPressure() {
    return compAirPressure;
  }

  public Integer getCompAirFlowrate() {
    return compAirFlowrate;
  }

  public Boolean isGasRequired() {
    return gasRequired;
  }

  public GasType getGasType() {
    return gasType;
  }

  public Integer getGasPressure() {
    return gasPressure;
  }

  public Integer getGasFlowrate() {
    return gasFlowrate;
  }

  public Boolean isWaterRequired() {
    return waterRequired;
  }

  public Integer getWaterPressure() {
    return waterPressure;
  }

  public Integer getWaterFlowrate() {
    return waterFlowrate;
  }

  public WaterType getWaterType() {
    return waterType;
  }

  public Boolean isDustPickupRequired() {
    return dustPickupRequired;
  }

  public Integer getDustPickupVelocity() {
    return dustPickupVelocity;
  }

  public DustType getDustType() {
    return dustType;
  }

  public String getBaghouseCyclone() {
    return baghouseCyclone;
  }

  public Integer getDuctSize() {
    return ductSize;
  }

  public Integer getDuctFlowrate() {
    return ductFlowrate;
  }

  public Boolean isSpecificationRequired() {
    return specificationRequired;
  }

  public String getProcessRemarks() {
    return processRemarks;
  }

  public Equipment getEquipment() {
    return equipment;
  }

  public DesignCapacityUnit getDesignCapacityUnit() {
    return designCapacityUnit;
  }

  public void setDesignCapacityUnit(DesignCapacityUnit designCapacityUnit) {
    this.designCapacityUnit = designCapacityUnit;
  }

  public List<ProcessFieldEquipmentType> getProcessFieldEquipmentTypes() {
    return processFieldEquipmentTypes;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void setProductType(String productType) {
    this.productType = productType;
  }

  public void setProductDensity(Double productDensity) {
    this.productDensity = productDensity;
  }

  public void setDesignCapacity(Integer designCapacity) {
    this.designCapacity = designCapacity;
  }

  public void setCompAirRequired(boolean compAirRequired) {
    this.compAirRequired = compAirRequired;
  }

  public void setCompAirPressure(Integer compAirPressure) {
    this.compAirPressure = compAirPressure;
  }

  public void setCompAirFlowrate(Integer compAirFlowrate) {
    this.compAirFlowrate = compAirFlowrate;
  }

  public void setGasRequired(boolean gasRequired) {
    this.gasRequired = gasRequired;
  }

  public void setGasType(GasType gasType) {
    this.gasType = gasType;
  }

  public void setGasPressure(Integer gasPressure) {
    this.gasPressure = gasPressure;
  }

  public void setGasFlowrate(Integer gasFlowrate) {
    this.gasFlowrate = gasFlowrate;
  }

  public void setWaterRequired(boolean waterRequired) {
    this.waterRequired = waterRequired;
  }

  public void setWaterPressure(Integer waterPressure) {
    this.waterPressure = waterPressure;
  }

  public void setWaterFlowrate(Integer waterFlowrate) {
    this.waterFlowrate = waterFlowrate;
  }

  public void setWaterType(WaterType waterType) {
    this.waterType = waterType;
  }

  public void setDustPickupRequired(boolean dustPickupRequired) {
    this.dustPickupRequired = dustPickupRequired;
  }

  public void setDustPickupVelocity(Integer dustPickupVelocity) {
    this.dustPickupVelocity = dustPickupVelocity;
  }

  public void setDustType(DustType dustType) {
    this.dustType = dustType;
  }

  public void setBaghouseCyclone(String baghouseCyclone) {
    this.baghouseCyclone = baghouseCyclone;
  }

  public void setDuctSize(Integer ductSize) {
    this.ductSize = ductSize;
  }

  public void setDuctFlowrate(Integer ductFlowrate) {
    this.ductFlowrate = ductFlowrate;
  }

  public void setSpecificationRequired(boolean specificationRequired) {
    this.specificationRequired = specificationRequired;
  }

  public void setProcessRemarks(String processRemarks) {
    this.processRemarks = processRemarks;
  }

  public void setEquipment(Equipment equipment) {
    this.equipment = equipment;
  }

  public String getDesignCapacityUnitText() {
    return designCapacityUnitText;
  }

  public void setDesignCapacityUnitText(String designCapacityUnitText) {
    this.designCapacityUnitText = designCapacityUnitText;
  }

  public void setProcessFieldEquipmentTypes(List<ProcessFieldEquipmentType> processFieldEquipmentTypes) {
    this.processFieldEquipmentTypes = processFieldEquipmentTypes;
  }

  public String getFormattedId(){
    return "'" + this.getId() + "',";
  }

  public Process createCopy() throws CloneNotSupportedException {
    Process process = (Process) super.clone();
    process.setId(null);
    List<ProcessFieldEquipmentType> copyOfPfes = new ArrayList<ProcessFieldEquipmentType>();
    for (ProcessFieldEquipmentType pfe : this.getProcessFieldEquipmentTypes()) {
            ProcessFieldEquipmentType copyOfPfe = pfe.createCopy();
            copyOfPfe.setProcess(process);
            copyOfPfes.add(copyOfPfe);
    }
    process.setProcessFieldEquipmentTypes(copyOfPfes);
    return process;
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<process>");
    xml.append(getEquipment().toXmlWithBasicFields());
    xml.append("<processId>");
    xml.appendValue(getId()).append("</processId>");
    xml.append("<productType>");
    xml.appendValue(getProductType()).append("</productType>");
    xml.append("<productDensity>");
    xml.appendValue(getProductDensity()).append("</productDensity>");
    xml.append("<productDensity>");
    xml.appendValue(getProductDensity()).append("</productDensity>");
    xml.append("<designCapacity>");
    xml.appendValue(getDesignCapacity()).append("</designCapacity>");
    if (getDesignCapacityUnit() == null) {
      xml.append("<designCapacityUnitId>").append("").append("</designCapacityUnitId>");
    } else {
      xml.append("<designCapacityUnitId>");
      xml.appendValue(getDesignCapacityUnit().getId()).append("</designCapacityUnitId>");
    }
    xml.append("<compAirRequired>");
    xml.appendValue(isCompAirRequired()).append("</compAirRequired>");
    xml.append("<compAirPressure>");
    xml.appendValue(getCompAirPressure()).append("</compAirPressure>");
    xml.append("<compAirFlowrate>");
    xml.appendValue(getCompAirFlowrate()).append("</compAirFlowrate>");
    xml.append("<gasRequired>");
    xml.appendValue(isGasRequired()).append("</gasRequired>");
    xml.append("<gasType>");
    if (getGasType() == null) {
      xml.append("<gasTypeId>").append("").append("</gasTypeId>");
    } else {
      xml.append("<gasTypeId>");
      xml.appendValue(getGasType().getId()).append("</gasTypeId>");
    }
    xml.append("</gasType>");
    xml.append("<gasPressure>");
    xml.appendValue(getGasPressure()).append("</gasPressure>");
    xml.append("<gasFlowrate>");
    xml.appendValue(getGasFlowrate()).append("</gasFlowrate>");
    xml.append("<waterRequired>");
    xml.appendValue(isWaterRequired()).append("</waterRequired>");
    xml.append("<waterPressure>");
    xml.appendValue(getWaterPressure()).append("</waterPressure>");
    xml.append("<waterFlowrate>");
    xml.appendValue(getWaterFlowrate()).append("</waterFlowrate>");
    xml.append("<waterType>");
    if (getWaterType() == null) {
      xml.append("<waterTypeId>").append("").append("</waterTypeId>");
    } else {
      xml.append("<waterTypeId>");
      xml.appendValue(getWaterType().getId()).append("</waterTypeId>");
    }
    xml.append("</waterType>");
    xml.append("<dustPickupRequired>");
    xml.appendValue(isDustPickupRequired())
        .append("</dustPickupRequired>");
    xml.append("<dustPickupVelocity>");
    xml.appendValue(getDustPickupVelocity())
        .append("</dustPickupVelocity>");
    xml.append("<dustType>");
    if (getDustType() == null) {
      xml.append("<dustTypeId>").append("").append("</dustTypeId>");
    } else {
      xml.append("<dustTypeId>");
      xml.appendValue(getDustType().getId()).append("</dustTypeId>");
    }
    xml.append("</dustType>");
    xml.append("<baghouseCyclone>");
    xml.appendValue(getBaghouseCyclone()).append("</baghouseCyclone>");
    xml.append("<ductSize>");
    xml.appendValue(getDuctSize()).append("</ductSize>");
    xml.append("<ductFlowrate>");
    xml.appendValue(getDuctFlowrate()).append("</ductFlowrate>");
    xml.append("<specificationRequired>");
    xml.appendValue(isSpecificationRequired())
        .append("</specificationRequired>");
    xml.append("<designCapacityUnitText>");
    xml.appendValue(getDesignCapacityUnitText())
        .append("</designCapacityUnitText>");
    xml.append("<processRemarks>");
    xml.appendValue(getProcessRemarks()).append("</processRemarks>");

    xml.append("<processFieldEquipmentTypes>");
    for (ProcessFieldEquipmentType pfe : getProcessFieldEquipmentTypes()) {
      xml.append(pfe.toXml());
    }
    xml.append("</processFieldEquipmentTypes>");
    xml.append("</process>");
    return xml.toString();
  }

  private Object returnEmptyIfNull(Object obj) {
    if (obj == null) {
      return "";
    } else {
      return obj;
    }
  }

   public String getProcessAndItsRelatedsIds() {
     StringBuffer ids = new StringBuffer();
     ids.append(this.getFormattedId());
     if (this.getDesignCapacityUnit() != null){
      ids.append(this.getDesignCapacityUnit().getFormattedId());
     }
     for(ProcessFieldEquipmentType fieldEquipmentType : this.getProcessFieldEquipmentTypes())
     {
        ids.append(fieldEquipmentType.getFormattedId());
    }
    return ids.toString().substring(0, ids.toString().length() - 1);
  }
}