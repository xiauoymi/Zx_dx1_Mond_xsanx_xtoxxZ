/*
 ProcessFieldEquipmentType was created on Oct 3, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.eas.eis.Copyable;

/**
 * Filename:    $RCSfile: ProcessFieldEquipmentType.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $
 * On:	$Date: 2009-02-11 17:43:56 $
 *
 * @author sspati1
 * @version $Revision: 1.9 $
 */
@Entity
@AccessType("field")
@Table(schema = "EIS", name = "EIS_PROCESS_FIELD_EQUIPMENT")
public class ProcessFieldEquipmentType implements Copyable {

  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @ManyToOne(targetEntity = Process.class)
  @JoinColumn(name = "PROCESS_ID", referencedColumnName = "ID")
  private Process process;

  @ManyToOne
  @JoinColumn(name = "FIELD_EQUIPMENT_ID")
  private FieldEquipmentType fieldEquipmentType;

  @Column(name = "VALUE")
  private String value;

  @Column(name = "IS_DELETED")
  @Type(type = "yes_no")
  private boolean isDeleted;

  public ProcessFieldEquipmentType() {
  }

  public ProcessFieldEquipmentType(Long id, Process process, FieldEquipmentType fieldEquipmentType,
                                   String value) {
    this.id = id;
    this.process = process;
    this.fieldEquipmentType = fieldEquipmentType;
    this.value = value;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Process getProcess() {
    return process;
  }

  public FieldEquipmentType getFieldEquipmentType() {
    return fieldEquipmentType;
  }

  public String buildKeyForUniqueEquipmentTypeAndValue(){
      StringBuilder b = new StringBuilder();
      b.append("id:");
      if (getFieldEquipmentType()==null||getFieldEquipmentType().getId()==null){
          b.append("null");
      }else {
          b.append(getFieldEquipmentType().getId());
      }
     // b.append(":val:").append(getValue());
      return b.toString();
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public boolean isDeleted() {
    return isDeleted;
  }

  public void setDeleted(boolean deleted) {
    isDeleted = deleted;
  }

  public void setProcess(Process process) {
    this.process = process;
  }

    public String getFormattedId(){
     return getId() == null ? "" : "'" + getId() + "',";
  }

  public ProcessFieldEquipmentType createCopy() throws CloneNotSupportedException {
    ProcessFieldEquipmentType pfe = (ProcessFieldEquipmentType) super.clone();
    pfe.setId(null);
    return pfe;
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<");
    xml.appendValue(getFieldEquipmentType().getName());
    xml.append(" id='");
    xml.appendValue(getId()).append("'");
    xml.append(" fieldEquipmentType='");
    xml.appendValue(getFieldEquipmentType().getFieldType().getType());
    xml.append("'").append(">");
    xml.appendValue(getValue()).append("</");
    xml.appendValue(getFieldEquipmentType().getName()).append(">");
    return xml.toString();
  }

  }