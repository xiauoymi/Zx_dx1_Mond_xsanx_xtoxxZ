/*
 ProjectRole was created on Dec 26, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: ProjectRole.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2009-01-01 23:33:34 $
 *
 * @author SSPATI1
 * @version $Revision: 1.1 $
 */
@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_PROJ_ROLE")
public class ProjectRole {
  @Id
  @SequenceGenerator(name = "projRoleSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "projRoleSeqGen")
  @Column(name = "ID")
  private Long id;

  @Column(name = "NAME")
	private String name;

  @ManyToOne
  @JoinColumn(name = "ACCESS_TYPE_ID")
	private AccessType accessType;

  public ProjectRole() {
  }

  public ProjectRole(Long id, String name, AccessType accessType) {
    this.id = id;
    this.name = name;
    this.accessType = accessType;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public AccessType getAccessType() {
    return accessType;
  }

  public void setAccessType(AccessType accessType) {
    this.accessType = accessType;
  }
}