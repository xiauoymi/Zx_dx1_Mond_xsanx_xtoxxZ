package com.monsanto.eas.eis.projects.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author VVVELU
 */

@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_PROJ_STATUS")
public class ProjectStatus implements Serializable, XmlObject {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6128896660728646823L;

	@Id
	private Long id;

	@Column(name = "STATUS_NAME")
	private String name;
	
	public ProjectStatus() {}
	
	public ProjectStatus(Long id, String name) {
    this.id = id;
    this.name = name;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

  public void setId(Long id) {
    this.id = id;
  }

  /**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

  public void setName(String name) {
    this.name = name;
  }

  public boolean equals(Object obj) {
    return obj == null || !(obj instanceof ProjectStatus) ? false : id.equals(((ProjectStatus) obj).getId());
  }

  public int hashCode() {
    return id.hashCode();
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<projectStatus>");
    xml.append("<id>");
    xml.appendValue(getId()).append("</id>");
    xml.append("<name>");
    xml.appendValue(getName()).append("</name>");
    xml.append("</projectStatus>");
    return xml.toString();
  }
}
