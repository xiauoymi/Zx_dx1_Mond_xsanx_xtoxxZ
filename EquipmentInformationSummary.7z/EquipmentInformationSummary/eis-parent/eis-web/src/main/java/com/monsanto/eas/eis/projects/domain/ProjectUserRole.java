/*
 ProjectUserRole was created on Dec 26, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.Type;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: ProjectUserRole.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 16:02:05 $
 *
 * @author SSPATI1
 * @version $Revision: 1.5 $
 */
@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_PROJ_USER_ROLE")
public class ProjectUserRole implements XmlObject {
  @Id
  @SequenceGenerator(name = "seqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqGen")
  @Column(name = "ID")
  private Long id;

  @ManyToOne
  @JoinColumn(name = "PROJECT_ID")
  private Projects project;

  @ManyToOne
  @JoinColumn(name = "PROJ_USER_ID")
  private User user;

  @ManyToOne
  @JoinColumn(name = "PROJ_ROLE_ID")
  private ProjectRole projRole;

  @Column(name = "is_lead")
  @Type(type = "yes_no")
  private boolean isLead;

  @Column(name = "is_deleted")
  @Type(type = "yes_no")
  private boolean isDeleted;

  public ProjectUserRole() {
  }

  public ProjectUserRole(Projects project, User user, ProjectRole projRole, boolean lead) {
    this.project = project;
    this.user = user;
    this.projRole = projRole;
    isLead = lead;
  }

  public Long getId() {
    return id;
  }

  public Projects getProject() {
    return project;
  }

  public User getUser() {
    return user;
  }

  public ProjectRole getProjRole() {
    return projRole;
  }

  public boolean getIsLead() {
    return isLead;
  }

  public boolean isDeleted() {
    return isDeleted;
  }

  public void setDeleted(boolean deleted) {
    isDeleted = deleted;
  }

  public String getFormattedId(){
     return "'" + this.getId() + "',";
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<projectUserRole>");
    xml.append("<userId>");
    xml.appendValue(getUser().getId()).append("</userId>");
    xml.append("<isLead>");
    xml.appendValue(getIsLead()).append("</isLead>");
    xml.append("</projectUserRole>");
    return xml.toString();
  }

  public void setId(Long id) {
    this.id = id;
  }
}