package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;


/**
 * @author VVVELU
 */

@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_PROJECTS")
public class Projects implements Serializable, XmlObject {

  private static final long serialVersionUID = -8725968159262423384L;


  @Id
  @SequenceGenerator(name = "projectsSeqGen", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "projectsSeqGen")
  @Column(name = "ID")
  private Long id; //0

  @Column(name = "PROJ_NUMBER")
  private String projNumber; // 1

  @Column(name = "PROJ_NAME")
  private String projName; // 2


  @Column(name = "STARTUP_DATE")
  private Date startupDate; // 3

  @Column(name = "AR_APPROVAL_DATE")
  private Date arApprovalDate; //4

  @ManyToOne
  @JoinColumn(name = "STATUS_ID")
  private ProjectStatus projStatus; //6

  @ManyToOne
  @JoinColumn(name = "UNIT_MSR_ID")
  private UnitMeasure unitMeasure; //7


  @ManyToOne
  @JoinColumn(name = "REGION_ID")
  private Location region; //8


  @ManyToOne
  @JoinColumn(name = "COUNTRY_ID")
  private Location country; //8


  @ManyToOne
  @JoinColumn(name = "STATE_ID")
  private Location state; //8


  @ManyToOne
  @JoinColumn(name = "CITY_ID")
  private Location city; //8

  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "CROP_ID")
  private Crop crop; //14

  @OneToMany(
      targetEntity = ProjectUserRole.class,
      mappedBy = "project",
      cascade = CascadeType.ALL,
      fetch = FetchType.LAZY
  )
  @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
  private Set<ProjectUserRole> userRoles = new HashSet<ProjectUserRole>();

  @OneToMany(mappedBy = "projects",
      targetEntity = Equipment.class, cascade = CascadeType.ALL,
      fetch = FetchType.LAZY)
  @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
  private List<Equipment> equipments = new ArrayList<Equipment>();      //20

  @Column(name = "CREATED_USR")
  private String createdUser;     //23

  @Column(name = "CREATED_DATE")
  private Date createdDate;      //24

  @Column(name = "UPDATED_USR")
  private String updatedUser;   //optional 25

  @Column(name = "UPDATED_DATE")
  private Date updatedDate;     //optional 26

  @Column(name = "is_master")
  @Type(type = "yes_no")
  private boolean isMaster;

  public Projects() {
  }

  public Projects(String projNumber, String projName, Date startupDate, Date arApprovalDate,
                  ProjectStatus projStatus,
                  UnitMeasure unitMeasure,
                  Location region, Location country, Location state, Location city,
                  Crop crop,
                  String createdUser, Date createdDate
  ) {
    this.projNumber = projNumber;
    this.projName = projName;
    this.startupDate = startupDate;
    this.arApprovalDate = arApprovalDate;
    this.projStatus = projStatus;
    this.unitMeasure = unitMeasure;
    this.region = region;
    this.country = country;
    this.state = state;
    this.city = city;
    this.crop = crop;
    this.createdUser = createdUser;
    this.createdDate = createdDate;
  }

  /**
   * @return the id
   */
  public Long getId() {
    return id;
  }


  /**
   * @return the projNumber
   */
  public String getProjNumber() {
    return projNumber;
  }

  /**
   * @return the projName
   */
  public String getProjName() {
    return projName;
  }


  /**
   * @return the startupDate
   */
  public Date getStartupDateAsDate() {
    return startupDate;
  }

  public String getStartupDate() {
    if (this.startupDate != null) {
      return formatDate(this.startupDate);
    }
    return null;
  }

  /**
   * @return the arApprovalDate
   */
  public Date getArApprovalDateAsDate() {
    return arApprovalDate;
  }

  public String getArApprovalDate() {
    if (this.arApprovalDate != null) {
      return formatDate(this.arApprovalDate);
    }
    return null;
  }

  /**
   * @return the projStatus
   */
  public ProjectStatus getProjStatus() {
    return projStatus;
  }

  /**
   * @return the unitMeasure
   */
  public UnitMeasure getUnitMeasure() {
    return unitMeasure;
  }

  /**
   * @return the location
   */
  public Location getRegion() {
    return region;
  }

  /**
   * @return the crop
   */
  public Crop getCrop() {
    return crop;
  }

  public String getCreatedUser() {
    return createdUser;
  }

  public Date getCreatedDate() {
    return createdDate;
  }


  public String getUpdatedUser() {
    return updatedUser;
  }

  public void setUpdatedUser(String updatedUser) {
    this.updatedUser = updatedUser;
  }


  public Date getUpdatedDate() {
    return updatedDate;
  }

  public boolean getIsMaster() {
    return isMaster;
  }

  public void setMaster(boolean master) {
    isMaster = master;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void setProjNumber(String projNumber) {
    this.projNumber = projNumber;
  }

  public void setProjName(String projName) {
    this.projName = projName;
  }

  public void setStartupDate(Date startupDate) {
    this.startupDate = startupDate;
  }

  public void setArApprovalDate(Date arApprovalDate) {
    this.arApprovalDate = arApprovalDate;
  }

  public void setProjStatus(ProjectStatus projStatus) {
    this.projStatus = projStatus;
  }

  public void setUnitMeasure(UnitMeasure unitMeasure) {
    this.unitMeasure = unitMeasure;
  }

  public void setRegion(Location location) {
    this.region = location;
  }

  public void setCrop(Crop crop) {
    this.crop = crop;
  }

  public Set<ProjectUserRole> getUserRoles() {
    return userRoles;
  }

  public void setUserRoles(Set<ProjectUserRole> userRoles) {
    this.userRoles = userRoles;
  }

  public List<ProjectUserRole> getProjectUserRoles(String roleName) {
    List<ProjectUserRole> list = new ArrayList<ProjectUserRole>();
    for (ProjectUserRole userRole : userRoles) {
      if (userRole.getProjRole().getName().equalsIgnoreCase(roleName)) {
        list.add(userRole);
      }
    }
    return list;
  }

  public boolean isUserInProcessElectricalMechanicalRoles(){
    boolean userIsInRoles = false;
    if (getProcessEngr().size() > 0 || getMechanicalEngr().size() > 0
        || getMechanicalDesigner().size() > 0 || getMechanicalEngr().size() > 0 ||
        getElectricalDesigner().size() > 0 || getElectricalEngr().size() > 0){
      userIsInRoles = true;
    }
    return userIsInRoles;
  }

  public List<ProjectUserRole> getProjEngr() {
    return getProjectUserRoles(EISConstants.PROJECT_ENGINEER);
  }

  public List<ProjectUserRole> getProcessEngr() {
    return getProjectUserRoles(EISConstants.PROCESS_ENGINEER);
  }

  public List<ProjectUserRole> getMechanicalEngr() {
    return getProjectUserRoles(EISConstants.MECHANICAL_ENGINEER);
  }

  public List<ProjectUserRole> getMechanicalDesigner() {
    return getProjectUserRoles(EISConstants.MECHANICAL_DESIGNER);
  }

  public List<ProjectUserRole> getElectricalEngr() {
    return getProjectUserRoles(EISConstants.ELECTRICAL_ENGINEER);
  }

  public List<ProjectUserRole> getElectricalDesigner() {
    return getProjectUserRoles(EISConstants.ELECTRICAL_DESIGNER);
  }

  public List<ProjectUserRole> getProjectSponsor() {
    return getProjectUserRoles(EISConstants.PROJECT_SPONSOR);
  }

  public List<ProjectUserRole> getProjectManager() {
    return getProjectUserRoles(EISConstants.PROJECT_MANAGER);
  }

  public List<ProjectUserRole> getManufacturingRep() {
    return getProjectUserRoles(EISConstants.MANUFACTURING_REPRESENTATIVE);
  }

  public List<ProjectUserRole> getLocationManager() {
    return getProjectUserRoles(EISConstants.LOCATION_MANAGER);
  }

  public List<ProjectUserRole> getProjectBuyer() {
    return getProjectUserRoles(EISConstants.PROJECT_BUYER);
  }

  public List<ProjectUserRole> getProjectControls() {
    return getProjectUserRoles(EISConstants.PROJECT_CONTROLS);
  }

  public List<Equipment> getEquipments() {
    return equipments;
  }

  public void setEquipments(List<Equipment> equipments) {
    this.equipments = equipments;
  }

  public boolean equals(Object obj) {
    return obj == null || !(obj instanceof Projects) ? false : id.equals(((Projects) obj).getId());
  }

  public Location getCountry() {
    return country;
  }

  public Location getState() {
    return state;
  }

  public Location getCity() {
    return city;
  }

  public void setCountry(Location country) {
    this.country = country;
  }

  public void setState(Location state) {
    this.state = state;
  }

  public void setCity(Location city) {
    this.city = city;
  }

  public int hashCode() {
    return id.hashCode();
  }

  public Equipment getEquipment(Long equipmentId) {
    Iterator iterator = equipments.iterator();
    while (iterator.hasNext()) {
      Equipment equipment = (Equipment) iterator.next();
      if (equipment.getId().equals(equipmentId)) {
        return equipment;
      }
    }
    return null;
  }

  public String getFormattedId(){
    return "'" + this.getId() + "',";
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<project>");
    xml.append("<projectId>");
    xml.appendValue(getId()).append("</projectId>");
    xml.append("<projNumber>");
    xml.appendValue(getProjNumber()).append("</projNumber>");
    xml.append("<projName>");
    xml.appendValue(getProjName()).append("</projName>");
    xml.append("<startupDate>");
    xml.appendValue(formatDate(getStartupDateAsDate())).append("</startupDate>");
    xml.append("<arApprovalDate>");
    xml.appendValue(formatDate(getArApprovalDateAsDate())).append("</arApprovalDate>");
    xml.append("<isMaster>");
    xml.appendValue(getIsMaster()).append("</isMaster>");

    if (getProjStatus() != null) {
      xml.append("<projStatusId>");
      xml.appendValue(getProjStatus().getId()).append("</projStatusId>");
      xml.append("<projStatusName>");
      xml.appendValue(getProjStatus().getName()).append("</projStatusName>");
    } else {
      xml.append("<projStatusId>");
      xml.appendValue("").append("</projStatusId>");
      xml.append("<projStatusName>");
      xml.appendValue("").append("</projStatusName>");
    }

    if (getUnitMeasure() != null) {
      xml.append("<unitMeasureId>");
      xml.appendValue(getUnitMeasure().getId()).append("</unitMeasureId>");
      xml.append("<unitMeasureName>");
      xml.appendValue(getUnitMeasure().getName())
          .append("</unitMeasureName>");
    } else {
      xml.append("<unitMeasureId>");
      xml.appendValue("").append("</unitMeasureId>");
      xml.append("<unitMeasureName>");
      xml.appendValue("").append("</unitMeasureName>");
    }

    if (getRegion() != null) {
      xml.append("<regionId>");
      xml.appendValue(getRegion().getId()).append("</regionId>");
      xml.append("<regionName>");
      xml.appendValue(getRegion().getName()).append("</regionName>");
    } else {
      xml.append("<regionId>");
      xml.appendValue("").append("</regionId>");
      xml.append("<regionName>");
      xml.appendValue("").append("</regionName>");
    }

    if (getCountry() != null) {
      xml.append("<countryId>");
      xml.appendValue(getCountry().getId()).append("</countryId>");
      xml.append("<countryName>");
      xml.appendValue(getCountry().getName()).append("</countryName>");
    } else {
      xml.append("<countryId>");
      xml.appendValue("").append("</countryId>");
      xml.append("<countryName>");
      xml.appendValue("").append("</countryName>");
    }

    if (getState() != null) {
      xml.append("<stateId>");
      xml.appendValue(getState().getId()).append("</stateId>");
      xml.append("<stateName>");
      xml.appendValue(getState().getName()).append("</stateName>");
    } else {
      xml.append("<stateId>");
      xml.appendValue("").append("</stateId>");
      xml.append("<stateName>");
      xml.appendValue("").append("</stateName>");
    }

    if (getCity() != null) {
      xml.append("<cityId>");
      xml.appendValue(getCity().getId()).append("</cityId>");
      xml.append("<cityName>");
      xml.appendValue(getCity().getName()).append("</cityName>");
    } else {
      xml.append("<cityId>");
      xml.appendValue("").append("</cityId>");
      xml.append("<cityName>");
      xml.appendValue("").append("</cityName>");
    }

    if (getCrop() != null) {
      xml.append("<cropId>");
      xml.appendValue(getCrop().getId()).append("</cropId>");
      xml.append("<cropName>");
      xml.appendValue(getCrop().getName()).append("</cropName>");
    } else {
      xml.append("<cropId>");
      xml.appendValue("").append("</cropId>");
      xml.append("<cropName>");
      xml.appendValue("").append("</cropName>");
    }

//    xml.append("<revisionNumber>").append(returnEmptyIfNull(getRevisionNumber())).append("</revisionNumber>");
//    xml.append("<revisionDescription>").append(returnEmptyIfNull(getRevisionDescription())).append("</revisionDescription>");

//    appendLeadElectDesigner(xml);
//    appendLeadElectEngr(xml);
//    appendLeadMechDesigner(xml);
//    appendLeadMechEngr(xml);
//    appendLeadProcess(xml);
//    appendLocationManager(xml);
//    appendManuafactureRep(xml);
//    appendProjectBuyer(xml);
//    appendProjectControls(xml);
//    appendProjectManager(xml);
//    appendProjectSponsor(xml);
    xml.append("</project>");
    return xml.toString();
  }

  private String formatDate(Date date) {
    if (date == null) {
      return "";
    } else {
      return ConvertUtil.toString(date, ConvertUtil.PROJECTS_DATE_FORMAT);
    }
  }


}
