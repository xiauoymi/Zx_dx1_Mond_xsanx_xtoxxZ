package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;
import java.io.Serializable;

import org.hibernate.annotations.AccessType;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Dec 8, 2008 Time: 4:59:57 PM To change this template use File | Settings
 * | File Templates.
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "EIS", name = "EIS_PURCHASE_SCOPE")
public class PurchaseScope implements Serializable, XmlObject {

  private static final long serialVersionUID = 1L;

  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "PURCHASE_SCOPE")
  private String purchaseScopeName;

  public PurchaseScope() {}

  public PurchaseScope(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public String getPurchaseScopeName() {
    return purchaseScopeName;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void setPurchaseScopeName(String purchaseScopeName) {
    this.purchaseScopeName = purchaseScopeName;
  }

  public String getFormattedId () {
    return getId() == null ? "" : "'" + getId() + "',";
  }

  public String toXml() {
    XMLBuffer xmlStr = new XMLBuffer("<purchaseScope>");
    xmlStr.append("<id>");
    xmlStr.appendValue(getId()).append("</id>");
    xmlStr.append("<purchaseScopeName>");
    xmlStr.appendValue(getPurchaseScopeName()).append("</purchaseScopeName>");
    xmlStr.append("</purchaseScope>");
    return xmlStr.toString();
  }
}
