/*
 Purchasing was created on Oct 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.util.XMLBuffer;
import com.monsanto.eas.eis.Copyable;
import com.monsanto.wst.textutil.TextUtil;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;

/**
 * Filename:    $RCSfile: Purchasing.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-11 17:43:56 $
 *
 * @author sspati1
 * @version $Revision: 1.16 $
 */
@Entity
@AccessType("field")
@Table(schema = "EIS", name = "EIS_PURCHASING")
public class Purchasing implements XmlObject, Copyable {
  @Id
  @SequenceGenerator(name = "eisSeq", sequenceName = "EIS.EIS_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eisSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "VENDOR")
  private String vendor;

  @Column(name = "RTP_NUM")
  private Integer rtpNumber;

  @Column(name = "PO_NUM")
  private Long poNumber;

  @Column(name = "LINE_NUM")
  private Integer lineNumber;

  @Column(name = "PO_LINE_AMT")
  private Long poLineAmount;

  @Column(name = "PO_LINE_QTY")
  private Integer poLineQuantity;

  @Column(name = "PO_LINE_VALUE")
  private Long poLineValue;

  @Column(name = "CO_AMT")
  private Long coAmount;

  @Column(name = "ORIGINAL_SHIP_DATE")
  private Date originalShipDate;

  @Column(name = "REVISED_SHIP_DATE")
  private Date revisedShipDate;

  @Column(name = "ACTUAL_DELIVERY_DATE")
  private Date actualDeliveryDate;

  @Column(name = "EXPORT_DOCUMENTS")
  @Type(type = "yes_no")
  private boolean exportDocuments;

  @Column(name = "IS_DELETED")
  @Type(type = "yes_no")
  private boolean isDeleted;

  @OneToOne(mappedBy = "purchasing")
  private Equipment equipment;


  public Purchasing() {
  }

  public Purchasing(Long id, String vendor, Integer rtpNumber, Long poNumber, Integer lineNumber,
                    Long poLineAmount, Integer poLineQuantity, Long poLineValue, Long coAmount,
                    Date originalShipDate, Date revisedShipDate, Date actualDeliveryDate, boolean exportDocuments) {
    this.id = id;
    this.vendor = vendor;
    this.rtpNumber = rtpNumber;
    this.poNumber = poNumber;
    this.lineNumber = lineNumber;
    this.poLineAmount = poLineAmount;
    this.poLineQuantity = poLineQuantity;
    this.poLineValue = poLineValue;
    this.coAmount = coAmount;
    this.originalShipDate = originalShipDate;
    this.revisedShipDate = revisedShipDate;
    this.actualDeliveryDate = actualDeliveryDate;
    this.exportDocuments = exportDocuments;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getVendor() {
    return vendor;
  }

  public Integer getRtpNumber() {
    return rtpNumber;
  }

  public Long getPoNumber() {
    return poNumber;
  }

  public Integer getLineNumber() {
    return lineNumber;
  }

  public Long getPoLineAmount() {
    return poLineAmount;
  }

  public Integer getPoLineQuantity() {
    return (poLineQuantity == null)? new Integer(1): poLineQuantity;
  }

  public Long getPoLineValue() {
    return poLineValue;
  }

  public Long getCoAmount() {
    return coAmount;
  }

  public Date getOriginalShipDate() {
    return originalShipDate;
  }

  public Date getRevisedShipDate() {
    return revisedShipDate;
  }

  public Date getActualDeliveryDate() {
    return actualDeliveryDate;
  }

  public boolean isExportDocuments() {
    return exportDocuments;
  }

  public boolean isDeleted() {
    return isDeleted;
  }

  public void setDeleted(boolean deleted) {
    isDeleted = deleted;
  }

  public void setVendor(String vendor) {
    this.vendor = vendor;
  }

  public void setRtpNumber(Integer rtpNumber) {
    this.rtpNumber = rtpNumber;
  }

  public void setPoNumber(Long poNumber) {
    this.poNumber = poNumber;
  }

  public void setLineNumber(Integer lineNumber) {
    this.lineNumber = lineNumber;
  }

  public void setPoLineAmount(Long poLineAmount) {
    this.poLineAmount = poLineAmount;
  }

  public void setPoLineQuantity(Integer poLineQuantity) {
    this.poLineQuantity = poLineQuantity;
  }

  public void setPoLineValue(Long poLineValue) {
    this.poLineValue = poLineValue;
  }

  public void setCoAmount(Long coAmount) {
    this.coAmount = coAmount;
  }

  public void setOriginalShipDate(Date originalShipDate) {
    this.originalShipDate = originalShipDate;
  }

  public void setRevisedShipDate(Date revisedShipDate) {
    this.revisedShipDate = revisedShipDate;
  }

  public void setActualDeliveryDate(Date actualDeliveryDate) {
    this.actualDeliveryDate = actualDeliveryDate;
  }

  public void setExportDocuments(boolean exportDocuments) {
    this.exportDocuments = exportDocuments;
  }

  public void setEquipment(Equipment equipment) {
    this.equipment = equipment;
  }

  public Equipment getEquipment() {
    return equipment;
  }

  public Purchasing createCopy() throws CloneNotSupportedException {
    Purchasing purchasing = (Purchasing) super.clone();
    purchasing.setId(null);
    return purchasing;
  }

  public String toXml() {
    XMLBuffer xml = new XMLBuffer("<purchasing>");
    xml.append(getEquipment().toXmlWithBasicFields());
    getChildNodes(xml);
    xml.append("</purchasing>");
    return xml.toString();
  }

  public String toXmlWithoutEquipment() {
    XMLBuffer xml = new XMLBuffer("<purchasing>");
    getChildNodes(xml);
    xml.append("</purchasing>");
    return xml.toString();
  }

  private void getChildNodes(XMLBuffer xml) {
    xml.append("<purchaseId>");
    xml.appendValue(getId()).append("</purchaseId>");
    xml.append("<vendor>");
    xml.appendValue(getVendor()).append("</vendor>");
    xml.append("<purchaseSoleSource>");
    boolean equipmentSoleSource = getEquipment() != null && getEquipment().isEquipmentSoleSource();
    xml.appendValue(new Boolean(equipmentSoleSource).toString()).append("</purchaseSoleSource>");
    xml.append("<rtpNumber>");
    xml.appendValue(getRtpNumber()).append("</rtpNumber>");
    xml.append("<poNumber>");
    xml.appendValue(getPoNumber()).append("</poNumber>");
    xml.append("<lineNumber>");
    xml.appendValue(getLineNumber()).append("</lineNumber>");
    xml.append("<poLineAmount>");
    xml.appendValue(getPoLineAmount()).append("</poLineAmount>");
    xml.append("<poLineQuantity>");
    xml.appendValue(getPoLineQuantity()).append("</poLineQuantity>");
    xml.append("<poLineValue>");
    xml.appendValue(getPoLineValue()).append("</poLineValue>");
    xml.append("<coAmount>");
    xml.appendValue(getCoAmount()).append("</coAmount>");
    xml.append("<originalShipDate>");
    xml.appendValue(formatDate(getOriginalShipDate())).append("</originalShipDate>");
    xml.append("<revisedShipDate>");
    xml.appendValue(formatDate(getRevisedShipDate())).append("</revisedShipDate>");
    xml.append("<actualDeliveryDate>");
    xml.appendValue(formatDate(getActualDeliveryDate())).append("</actualDeliveryDate>");
    xml.append("<exportDocuments>");
    xml.appendValue(new Boolean(isExportDocuments()).toString()).append("</exportDocuments>");
  }

 private String formatDate(Date date){
    if(date == null){
      return "";
    }else{
      return ConvertUtil.toString(date, ConvertUtil.PROJECTS_DATE_FORMAT);
    }
  }

  public String getFormattedId() {
    return "'" + this.getId() + "',";
  }
}