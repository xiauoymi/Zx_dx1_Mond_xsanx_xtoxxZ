package com.monsanto.eas.eis.projects.domain;

import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author VVVELU
 */

@Entity
@NoDeleteAllowed
@Table(schema = "EIS", name = "EIS_UNIT_MEASURE")
public class UnitMeasure implements Serializable {

	private static final long serialVersionUID = -4555120397904461782L;
	
	@Id
	private Long id;

	@Column(name = "UNIT_NAME")
	private String name;
	
	public UnitMeasure() {}
	
	public UnitMeasure(Long id, String name) {
    this.id = id;
    this.name = name;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

  public void setId(Long id) {
    this.id = id;
  }

  /**
	 * @return the name
	 */
	public String getName() {
		return name;
	}


  public boolean equals(Object obj) {
    return obj == null || !(obj instanceof UnitMeasure) ? false : id.equals(((UnitMeasure) obj).getId());
  }

  public int hashCode() {
    return id.hashCode();
  }
}
