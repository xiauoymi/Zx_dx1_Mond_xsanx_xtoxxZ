package com.monsanto.eas.eis.projects.services;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.eis.projects.EISDAOFactory;
import com.monsanto.eas.eis.projects.EISDAOFactoryImpl;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.dao.ProjectStatusDAOImpl;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.alert.domain.AlertForProjectRoleAndStatus;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.List;

/**
 * Created by IntelliJ IDEA. User: afhyat Date: Sep 9, 2008 Time: 2:11:36 PM To change this template use File | Settings
 * | File Templates.
 */
public class ProjectsServiceImpl implements ProjectsService {
  EISDAOFactory daoFactory;

  public ProjectsServiceImpl() {
    this(new EISDAOFactoryImpl());
  }

  public ProjectsServiceImpl(EISDAOFactory eisDAOFactory) {
    this.daoFactory = eisDAOFactory;
  }

  public void deleteProject(Long projectId) {
    Projects project = daoFactory.getProjectsDAOImpl().findByPrimaryKey(projectId);
    daoFactory.getProjectsDAOImpl().delete(project);
  }

  public void archiveProjects(String[] projectIDs) {
    for (int i = 0; i < projectIDs.length; i++) {
      Projects project = daoFactory.getProjectsDAOImpl().findByPrimaryKey(Long.parseLong(projectIDs[i]));
      daoFactory.getProjectsDAOImpl().archive(project);
    }
  }

  public Document getLocationsAsXML(Long locationId) {
    Document document = DOMUtil.newDocument();
    Location location = daoFactory.getLocationDAOImpl().findByPrimaryKey(locationId);
    List<Location> childLocationList = location.getChildLocations();
    Element optionsElement = DOMUtil.addChildElement(document, EISConstants.OPTIONS);
    Element firstElement = DOMUtil.addChildElement(optionsElement, EISConstants.OPTION);
    //09-28-08: adding first option as Please Select
    DOMUtil.addChildElement(firstElement, EISConstants.ID, 0);
    DOMUtil.addChildElement(firstElement, EISConstants.DESCRIPTION, EISConstants.PLEASE_SELECT);

    for (Location childLoctaion : childLocationList) {
      Element optionElement = DOMUtil.addChildElement(optionsElement, EISConstants.OPTION);
      DOMUtil.addChildElement(optionElement, EISConstants.ID, childLoctaion.getId());
      DOMUtil.addChildElement(optionElement, EISConstants.DESCRIPTION, childLoctaion.getName());
    }
    return document;
  }

  public List<Location> lookupChildLocations(Long locationId) {
    Location location = daoFactory.getLocationDAOImpl().findByPrimaryKey(locationId);
    return location.getChildLocations();
  }

  public List<ProjectStatus> getProjectStatusesAsListExcludingDelete() {
    List statusList = null;
    ProjectStatusDAOImpl projectStatusDAO = daoFactory.getProjectStatusDAOImpl();
    statusList = projectStatusDAO.findAllExcludingDelete();
    return statusList;
  }

  public List<ProjectStatus> getAllActiveProjectStatus() {
    return daoFactory.getProjectStatusDAOImpl().findAllActiveStatus();
  }

  public List<ProjectStatus> getAllInActiveProjectStatus() {
    return daoFactory.getProjectStatusDAOImpl().findAllInActiveStatus();
  }


  public Projects lookupProjectById(Long id) {
    Criteria criteria = getProjectDaoCriteria();
    criteria.add(Restrictions.eq("id", id));
    criteria.setFetchMode("userRoles", FetchMode.JOIN);
//    criteria.setFetchMode("equipments", FetchMode.JOIN);
    return (Projects) criteria.uniqueResult();
  }

  public Projects lookupMasterProjectForThisProject(Projects project) {
    Criteria criteria = getProjectDaoCriteria();
    criteria.add(Restrictions.eq("crop.id", project.getCrop().getId()));
    criteria.add(Restrictions.eq("isMaster", true));
    return (Projects) criteria.uniqueResult();
  }

  public boolean doesProjectHaveEquipments(Long id) {
    Criteria criteria = getEquipmentDaoCriteria();
    criteria.add(Restrictions.eq("projects.id", id));
    criteria.setProjection(Projections.rowCount());
    Integer totalRecords = (Integer) criteria.uniqueResult();
    return totalRecords > 0;
  }

  protected Criteria getEquipmentDaoCriteria() {
    return daoFactory.getEquipmentDAOImpl().createCriteria();
  }

  public boolean doesProjectExist(String projectId, String projectNumber) {
    Criteria criteria = getProjectDaoCriteria();
    criteria.add(Restrictions.eq("projNumber", projectNumber));
    if (StringUtils.isNotBlank(projectId)) {
      criteria.add(Restrictions.ne("id", new Long(projectId)));
    }
    criteria.createAlias("projStatus", "ps");
    criteria.add(Restrictions.ne("ps.id", new Long(5L)));
    List list = criteria.list();
    return !list.isEmpty();
  }

  //protected for testing only
  protected Criteria getProjectDaoCriteria() {
    return daoFactory.getProjectsDAOImpl().getCriteria();
  }

  public List<ProjectStatus> getProjectStatuses(boolean isArchivedStatus) {
    if (isArchivedStatus) {
      return getAllInActiveProjectStatus();
    } else {
      return getAllActiveProjectStatus();
    }
  }

  public Crop lookupCropById(Long id) {
    return daoFactory.getCropDAOImpl().findByPrimaryKey(id);
  }

  public Location lookupLocationById(Long id) {
    return daoFactory.getLocationDAOImpl().findByPrimaryKey(id);
  }

  public ProjectStatus lookupStatusById(Long id) {
    return daoFactory.getProjectStatusDAOImpl().findByPrimaryKey(id);
  }

  public UnitMeasure lookupUnitMeasureById(Long id) {
    return daoFactory.getUnitMeasureDAOImpl().findByPrimaryKey(id);
  }

  public Projects lookupProjectByIdForAlert(Long id) {
    Criteria criteria = getProjectDaoCriteria();
    criteria.add(Restrictions.eq("id", id));
//    criteria.setFetchMode("userRoles", FetchMode.JOIN);
    criteria.setFetchMode("equipments", FetchMode.JOIN);
    return (Projects) criteria.uniqueResult();
  }
}

