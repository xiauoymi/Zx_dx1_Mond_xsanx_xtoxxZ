/*
 UserService was created on Jan 5, 2009 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.services;

import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.logon.hibernateMappings.User;

import java.util.List;

/**
 * Filename:    $RCSfile: UserService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-16 15:01:58 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public interface UserService {
  boolean doesUserHaveEditAccessToThisProject(String userId, Projects project);

  boolean isUserInProcessRoleForThisProject(String userId, Projects project);

  List<User> lookupAllUsersWithProjectUserRole();

  User lookupUserByLogonId(String userId);

  PaginatedResult lookupUsersByName (String userName);

  boolean isUserInMechanicalEngineerRoleForThisProject(String userId, Projects project);
}