/*
 UserServiceImpl was created on Jan 5, 2009 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.services;

import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.logon.hibernateMappings.UserRole;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.ProjectUserRole;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.alert.domain.AlertForProjectRoleAndStatus;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Projections;
import org.hibernate.FetchMode;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: UserServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $
 * On:	$Date: 2009-02-17 15:39:45 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public class UserServiceImpl implements UserService {
  private GenericDAO<User, Long> userDao;
  private GenericDAO<UserRole, Long> userRoleDao;
  private static final String EIS_PROJ_USER = "eis_proj_user";

  public UserServiceImpl() {
    this(new HibernateDAO<User, Long>(EISHibernateUtil.getHibernateFactory(), User.class),
        new HibernateDAO<UserRole, Long>(EISHibernateUtil.getHibernateFactory(), UserRole.class));
  }

  public UserServiceImpl(GenericDAO<User, Long> userDao, GenericDAO<UserRole, Long> userRoleDao) {
    this.userDao = userDao;
    this.userRoleDao = userRoleDao;
  }

  public boolean doesUserHaveEditAccessToThisProject(String userId, Projects project) {
    User user = lookupUserByLogonId(userId);
    return user != null && user.doesUserHaveEditAccessToThisProject(project);
  }

  public boolean isUserInProcessRoleForThisProject(String userId, Projects project) {
    User user = lookupUserByLogonId(userId);
    return user != null && user.isUserInProcessRoleForThisProject(project);
  }

  public boolean isUserInMechanicalEngineerRoleForThisProject(String userId, Projects project) {
    User user = lookupUserByLogonId(userId);
    return user != null && user.isUserInMechanicalEngineerRoleForThisProject(project);
  }

  public List<User> lookupAllUsersWithProjectUserRole() {
    Criteria criteria = userRoleDao.createCriteria();
    criteria.createAlias("role", "r");
    criteria.add(Restrictions.eq("r.roleName", EIS_PROJ_USER).ignoreCase());
    criteria.createAlias("user", "u");
    criteria.addOrder(Order.asc("u.lastName"));
    List<UserRole> userRoles = criteria.list();
    List<User> users = new ArrayList<User>();
    for (UserRole userRole : userRoles) {
      users.add(userRole.getUser());
    }
    return users;
  }
  public User lookupUserByLogonId(String userId) {
    Criteria criteria = userDao.createCriteria();
    criteria.setFetchMode("projUserRoles", FetchMode.JOIN);
    criteria.add(Restrictions.eq("userId", userId));
    return (User) criteria.uniqueResult();
  }

  public PaginatedResult lookupUsersByName (String userName){
    Criteria criteria = userDao.createCriteria();
    criteria.add(Restrictions.or(Restrictions.like("firstName", "%" + userName + "%").ignoreCase(),
        Restrictions.like("lastName", "%" + userName + "%").ignoreCase()));

    //criteria.setProjection(Projections.rowCount());
   // Integer totalRecords = (Integer) criteria.uniqueResult();

   // criteria.setProjection(null);
    criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
    List<User> userList = criteria.list();
    return new PaginatedResult(0, userList);
  }
}