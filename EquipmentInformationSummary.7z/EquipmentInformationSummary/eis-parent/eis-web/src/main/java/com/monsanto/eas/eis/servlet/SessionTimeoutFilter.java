/*
 SessionTimeoutFilter was created on Feb 17, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.servlet;

import com.monsanto.wst.hibernate.IUser;
import com.monsanto.eas.eis.logon.hibernateMappings.User;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Filename:    $RCSfile: SessionTimeoutFilter.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-17 19:30:21 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class SessionTimeoutFilter implements Filter {
  public void init(FilterConfig filterConfig) throws ServletException {
  }

  public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws
      IOException, ServletException {
    HttpServletRequest httpRequest = (HttpServletRequest) servletRequest;
    User user = (User) httpRequest.getSession().getAttribute(IUser.LOGIN_USER);
    if(user == null){
      servletRequest.getRequestDispatcher("/servlet/logon").forward(servletRequest, servletResponse);
    }
    filterChain.doFilter(servletRequest, servletResponse);
  }

  public void destroy() {
  } 

}