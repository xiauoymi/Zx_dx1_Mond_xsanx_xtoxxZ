/*
 CheckboxTag was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.tags;

import org.apache.commons.lang.StringUtils;

import javax.servlet.jsp.tagext.SimpleTagSupport;
import java.io.IOException;

/**
 * Filename:    $RCSfile: CheckboxTag.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date:
 * 2008/12/23 20:43:34 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class CheckboxTag extends SimpleTagSupport {
  private boolean isEditable;
  private String name;
  private boolean checked;
  private String id;
  private String className;
  private boolean readonly;

  public void doTag() throws IOException {
    getJspContext().getOut().write(buildHtmlForCheckbox());
  }

  private String buildHtmlForCheckbox() {
    StringBuffer result = new StringBuffer();
    if (!isEditable && readonly) {
      result.append("<span")
          .append(buildAttribute("id", this.id))
          .append(">")
          .append("</span>");
    } else {
      result.append("<input")
          .append(buildAttribute("type", "checkbox"))
          .append(buildAttribute("id", this.id))
          .append(buildAttribute("name", this.name))
          .append(buildAttribute("class", this.className))
          .append(appendChecked());
      if (!isEditable) {
        result.append(buildAttribute("disabled", "disabled"));
      }
      result.append("/>");
    }
    return result.toString();
  }

  private String appendChecked() {
    return this.checked ? " checked='checked'" : "";
  }

  private String buildAttribute(String attribute, String attributeValue) {
    StringBuffer result = new StringBuffer();
    if (StringUtils.isNotBlank(attributeValue)) {
      result.append(" ")
          .append(attribute)
          .append("=")
          .append("'")
          .append(attributeValue)
          .append("'");
    }
    return result.toString();
  }

  public void setIsEditable(boolean editable) {
    this.isEditable = editable;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setChecked(boolean checked) {
    this.checked = checked;
  }

  public void setId(String id) {
    this.id = id;
  }

  public void setClassName(String className) {
    this.className = className;
  }

  public void setReadonly(boolean readonly) {
    this.readonly = readonly;
  }
}