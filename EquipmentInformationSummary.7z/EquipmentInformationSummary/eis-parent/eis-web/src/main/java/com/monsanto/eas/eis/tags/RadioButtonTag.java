/*
 RadioButtonTag was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.tags;

import org.apache.commons.lang.StringUtils;

import javax.servlet.jsp.tagext.SimpleTagSupport;
import java.io.IOException;

/**
 * Filename:    $RCSfile: RadioButtonTag.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date:
 * 2008/12/23 20:43:34 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class RadioButtonTag extends SimpleTagSupport {
  private boolean isEditable;
  private String name;
  private String id;
  private String labels;
  private String values;
  private String valueToBeChecked;
  private String className;
  private boolean readonly;

  public void doTag() throws IOException {
    StringBuffer result = new StringBuffer();
    if (!isEditable && readonly) {
      result.append("<span")
          .append(buildAttribute("id", this.id))
          .append(">")
          .append(getValue())
          .append("</span>");
    } else {
      String[] labelArr = this.labels.split(",");
      String[] valueArr = this.values.split(",");
      for (int i = 0; i < labelArr.length; i++) {
        result.append("<label>")
            .append("<input")
            .append(buildAttribute("type", "radio"))
            .append(buildAttribute("id", this.id))
            .append(buildAttribute("name", this.name))
            .append(buildAttribute("class", this.className))
            .append(buildAttribute("value", valueArr[i].trim()))
            .append((appendChecked(valueArr, i)));
        if (!isEditable) {
          result.append(buildAttribute("disabled", "disabled"));
        }
        result.append("/>");
        result.append("<em>").append(labelArr[i].trim()).append("</em></label>");
      }
    }
    getJspContext().getOut().write(result.toString());
  }

  private String appendChecked(String[] valueArr, int i) {
    if (StringUtils.isNotBlank(this.valueToBeChecked) &&
        this.valueToBeChecked.trim().equalsIgnoreCase(valueArr[i].trim())) {
      return buildAttribute(" checked", "checked");
    }
    return "";
  }

  private String getValue() {
    String value = "";
    String[] labelArr = this.labels.split(",");
    String[] valueArr = this.values.split(",");
    for (int i = 0; i < labelArr.length; i++) {
      if (StringUtils.isNotBlank(this.valueToBeChecked) &&
          this.valueToBeChecked.trim().equalsIgnoreCase(valueArr[i].trim())) {
        value = valueArr[i].trim();
        break;
      }
    }
    return value;
  }

  private String buildAttribute(String attribute, String attributeValue) {
    StringBuffer result = new StringBuffer();
    if (StringUtils.isNotBlank(attributeValue)) {
      result.append(" ")
          .append(attribute)
          .append("=")
          .append("'")
          .append(attributeValue)
          .append("'");
    }
    return result.toString();
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setIsEditable(boolean editable) {
    isEditable = editable;
  }

  public void setId(String id) {
    this.id = id;
  }

  public void setLabels(String labels) {
    this.labels = labels;
  }

  public void setValues(String values) {
    this.values = values;
  }

  public void setValueToBeChecked(String valueToBeChecked) {
    this.valueToBeChecked = valueToBeChecked;
  }

  public void setClassName(String className) {
    this.className = className;
  }

  public void setReadonly(boolean readonly) {
    this.readonly = readonly;
  }
}