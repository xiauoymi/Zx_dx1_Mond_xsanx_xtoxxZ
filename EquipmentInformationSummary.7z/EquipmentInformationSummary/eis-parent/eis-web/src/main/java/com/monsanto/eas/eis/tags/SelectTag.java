/*
 SelectTag was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.tags;

import org.apache.commons.lang.StringUtils;

import javax.servlet.jsp.tagext.SimpleTagSupport;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: SelectTag.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date:
 * 2008/12/23 20:43:34 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class SelectTag extends SimpleTagSupport {

  private boolean isEditable;
  private List<Object> idValueList;
  private String idToBeSelected;
  private String onchange;
  private String name;
  private String idProperty;
  private String valueProperty;
  private String defaultOption;
  private String id;
  private String className;
  private boolean readonly;

  public void doTag() throws IOException {
    getJspContext().getOut().write(buildHtmlForSelect());
  }

  private String buildHtmlForSelect() {
    StringBuffer result = new StringBuffer();
    if (!isEditable && readonly) {
      result.append("<span")
          .append(buildAttribute("id", this.id))
          .append(">")
          .append(getValue())
          .append("</span>");
    } else {
      result.append("<select")
          .append(buildAttribute("id", this.id))
          .append(buildAttribute("name", this.name))
          .append(buildAttribute("class", this.className))
          .append(buildAttribute("onchange", this.onchange));
      if (!isEditable) {
        result.append(buildAttribute("disabled", "disabled"));
      }
      result.append(">")
          .append(getOptions())
          .append("</select>");
    }
    return result.toString();
  }

  private String getOptions() {
    StringBuffer options = new StringBuffer(
        "<option>" + (this.defaultOption == null ? "" : this.defaultOption) + "</option>");
    if (this.idValueList != null && !this.idValueList.isEmpty()) {
      try {
        Class<?> aClass = this.idValueList.get(0).getClass();
        Method idGetter = findGetter(this.idProperty, aClass);
        Method valueGetter = findGetter(this.valueProperty, aClass);
        for (Object obj : idValueList) {
          Object id = idGetter.invoke(obj);
          Object value = valueGetter.invoke(obj);
          options.append("<option")
              .append(buildAttribute("value", id.toString()));
          if (StringUtils.isNotBlank(this.idToBeSelected) &&
              this.idToBeSelected.trim().equalsIgnoreCase(id.toString())) {
            options.append(buildAttribute("selected", "selected"));
          }
          options.append(">")
              .append(value)
              .append("</option>");
        }
      } catch (NoSuchMethodException e) {
        e.printStackTrace();
      } catch (InvocationTargetException e) {
        e.printStackTrace();
      } catch (IllegalAccessException e) {
        e.printStackTrace();
      }
    }
    return options.toString();
  }

  private String getValue() {
    String valueToDisplay = "";
    if (this.idValueList != null && !this.idValueList.isEmpty()) {
      try {
        Class<?> aClass = this.idValueList.get(0).getClass();
        Method idGetter = findGetter(this.idProperty, aClass);
        Method valueGetter = findGetter(this.valueProperty, aClass);
        for (Object obj : idValueList) {
          Object id = idGetter.invoke(obj);
          Object value = valueGetter.invoke(obj);
          if (StringUtils.isNotBlank(this.idToBeSelected) &&
              this.idToBeSelected.trim().equalsIgnoreCase(id.toString())) {
            valueToDisplay = value.toString();
          }
        }
      } catch (NoSuchMethodException e) {
        e.printStackTrace();
      } catch (InvocationTargetException e) {
        e.printStackTrace();
      } catch (IllegalAccessException e) {
        e.printStackTrace();
      }
    }
    return valueToDisplay;
  }

  private Method findGetter(String propertyName, Class<?> aClass) throws NoSuchMethodException {
    return aClass.getMethod("get" + StringUtils.capitalize(propertyName));
  }

  private String buildAttribute(String attribute, String attributeValue) {
    StringBuffer result = new StringBuffer();
    if (StringUtils.isNotBlank(attributeValue)) {
      result.append(" ")
          .append(attribute)
          .append("=")
          .append("'")
          .append(attributeValue)
          .append("'");
    }
    return result.toString();
  }

  public void setIsEditable(boolean editable) {
    isEditable = editable;
  }

  public void setIdValueList(List<Object> idValueList) {
    if (idValueList == null) {
      idValueList = new ArrayList<Object>();
    }
    this.idValueList = idValueList;
  }

  public void setIdToBeSelected(String idToBeSelected) {
    this.idToBeSelected = idToBeSelected;
  }

  public void setOnchange(String onchange) {
    this.onchange = onchange;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setIdProperty(String idProperty) {
    this.idProperty = idProperty;
  }

  public void setValueProperty(String valueProperty) {
    this.valueProperty = valueProperty;
  }

  public void setDefaultOption(String defaultOption) {
    this.defaultOption = defaultOption;
  }

  public void setId(String id) {
    this.id = id;
  }

  public void setClassName(String className) {
    this.className = className;
  }

  public void setReadonly(boolean readonly) {
    this.readonly = readonly;
  }
}