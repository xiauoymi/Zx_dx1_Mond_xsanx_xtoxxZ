/*
 TextBoxTag was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.tags;

import org.apache.commons.lang.StringUtils;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import java.io.IOException;

/**
 * Filename:    $RCSfile: TextboxTag.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date:
 * 2008/12/23 20:43:34 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class TextboxTag extends SimpleTagSupport {
  private boolean isEditable;
  private String name;
  private String value;
  private String id;
  private String size;
  private String maxlength;
  private String onkeypress;
  private String onpaste;
  private String className;
  private boolean readonly;

  public void doTag() throws JspException, IOException {
    getJspContext().getOut().write(buildHtmlForTextBox());
  }

  private String buildHtmlForTextBox() {
    StringBuffer result = new StringBuffer();
    if (!isEditable && readonly) {
      result.append("<span")
          .append(buildAttribute("id", this.id))
          .append(">")
          .append(this.value)
          .append("</span>");
    } else {
      result.append("<input")
          .append(buildAttribute("type", "text"))
          .append(buildAttribute("name", this.name))
          .append(buildAttribute("id", this.id))
          .append(buildAttribute("class", this.className))
          .append(buildAttribute("size", this.size))
          .append(buildAttribute("maxlength", this.maxlength))
          .append(buildAttribute("onkeypress", this.onkeypress))
          .append(buildAttribute("onpaste", this.onpaste))
          .append(buildAttribute("value", this.value));
      if (!isEditable) {
        result.append(buildAttribute("disabled", "disabled"));
      }
      result.append("/>");
    }
    return result.toString();
  }

  private String buildAttribute(String attribute, String attributeValue) {
    StringBuffer result = new StringBuffer();
    if (StringUtils.isNotBlank(attributeValue)) {
      result.append(" ")
          .append(attribute)
          .append("=")
          .append("'")
          .append(attributeValue)
          .append("'");
    }
    return result.toString();
  }

  public void setIsEditable(boolean bool) {
    this.isEditable = bool;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public void setId(String id) {
    this.id = id;
  }

  public void setSize(String size) {
    this.size = size;
  }

  public void setMaxlength(String maxlength) {
    this.maxlength = maxlength;
  }

  public void setOnkeypress(String onkeypress) {
    this.onkeypress = onkeypress;
  }

  public void setOnpaste(String onpaste) {
    this.onpaste = onpaste;
  }

  public void setClassName(String className) {
    this.className = className;
  }

  public void setReadonly(boolean readonly) {
    this.readonly = readonly;
  }
}