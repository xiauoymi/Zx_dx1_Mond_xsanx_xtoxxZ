/*
 AccessoryConstants was created on Nov 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.util;

/**
 * Filename:    $RCSfile: AccessoryConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-01-27 14:25:07 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public interface AccessoryConstants {
  public static final String HAS_ACCESSORIES_DATA_CHANGED = "hasAccessoriesDataChanged";
  public final static String ACCE_ID = "acceId";
  public final static String ACCE_NAME = "accessoryName";
  public final static String ACCE_AUTO_MANUAL_ID = "autoManualId";
  public final static String ACCE_DESGINATOR_ID = "accessoryDesginatorId";
  public final static String ACCE_SEQUENCE_NUMBER = "acceSequenceNumber";
  public static final String ACCE_DESCRIPTION = "acceDescription";
  public static final String ACCE_COMMENTS = "acceComments";
  public static final String ACCE_PURCHASED_WITH_EQUIP = "accePurchasedWithEquip";
  public static final String ACCE_QUANTITY = "acceQuantity";
  public static final String ACCE_COMP_AIR_REQD = "acceCompAirReqd";
  public static final String ACCE_GAS_REQD = "acceGasReqd";
  public static final String ACCE_WATER_REQD = "acceWaterReqd";
  public static final String ACCE_UTILITY_FLOWRATE = "acceUtilityFlowrate";
  public static final String ACCE_SELF_CLEANING = "acceSelfCleaning";
  public static final String ACCE_SIZE = "acceSize";

  public static final String ACCE_ELECT_ID = "acceElectId";
  public static final String ACCE_INPUT_ID = "acceInputId";
  public static final String ACCE_OUTPUT_ID = "acceOutputId";
  public static final String ACCE_OTHER_MEASUREMENT_ID = "acceOtherMeasurementId";
  public static final String ACCE_PROOF_OF_POSITION_REQUIRED = "acceProofOfPositionReq";
  public static final String ACCE_SOLENOID_REQUIRED = "acceSolenoidReq";
  public static final String ACCE_LOCAL_PUSH_BUTTON_REQUIRED = "acceLocalPushButtonReq";
  public static final String ACCE_INPUT_QUANTITY = "acceInputQty";
  public static final String ACCE_OUTPUT_QUANTITY = "acceOutputQty";
  public static final String ACCE_HMI_DISPLAY = "acceHmiDisplay";
  public static final String ACCE_COMMUNICATIONS = "acceCommunications";
  public static final String ACCE_VOLTAGE = "acceVoltage";

  public static final String ACCE_PURCHASING_ID = "accePurchaseId";
  public static final String ACCE_VENDOR = "acceVendor";
  public static final String ACCE_RTP_NUMBER = "acceRtpNumber";
  public static final String ACCE_PO_NUMBER = "accePoNumber";
  public static final String ACCE_LINE_NUMBER = "acceLineNumber";
  public static final String ACCE_ACTUAL_DELIVERY_DATE = "acceActualDeliveryDate";
  public static final String DELETED_ACCESSORY_IDS = "deletedAccessoryIds";

  public static final String ACCE_ESTIMATED_COST = "acceEstimatedCost";
  public static final String ACCE_ACTUAL_COST = "acceActualCost";
  public static final String BID_PACKAGE = "acceBidPackage";
}