package com.monsanto.eas.eis.util;

import org.apache.commons.lang.StringUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Aug 7, 2008
 * Time: 4:39:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class ConvertUtil {
  //todo rename this class, its name is to vague, and it will probably turn into a grab-bag of convesion procedures
  
  public static final String DATE_PATTERN_SHORT = "MM/dd/yyyy";
  //public static final String PROJECTS_DATE_FORMAT = "MMddyyyy";
  public static final String PROJECTS_DATE_FORMAT = "MMM dd, yyyy";
  //public static final String MON_YEAR_DATE_PATTERN_SHORT = "MMMMM, yyyy";
  public static final int SHORT_DATE = 1; // todo if this isn't elminated, then it should be changed to an enum
  //public static final int MONTH_YEAR = 2;
  public static final int PROJECTS_DATE = 3;
  private ConvertUtil() { }

  public static Date toDate(String dateStr, int format)  {
    DateFormat dateFormat;
    if (StringUtils.isBlank(dateStr)) {
      return null;
    }

    try {
      if(format == SHORT_DATE)
        dateFormat = new SimpleDateFormat(DATE_PATTERN_SHORT);
//      else if(format == MONTH_YEAR)
//        dateFormat = new SimpleDateFormat(MON_YEAR_DATE_PATTERN_SHORT);
      else if(format == PROJECTS_DATE)
        dateFormat = new SimpleDateFormat(PROJECTS_DATE_FORMAT);
      else
        throw new RuntimeException("Inavalid Date Format");
      dateFormat.setLenient(false);
      return dateFormat.parse(dateStr);
    } catch (ParseException e) {
      throw new RuntimeException(e);
    }
  }

  public static String getDate(Date date, int format) {
    //todo what is the purpose of this method?
    /*
      It doesn't seem to make any sense what it is doing.  If format == SHORT_DATE, it does use simple date format,
      if it is any other value, it calls the default date formatting (from Date.toString()) on a DIFFERENT DATE (the current date/time)

      Looking for usages of this object, I can only find 1, and it is passing SHORT_DATE in.  If this is the case, can this
      instead be simplified to allways use SimpleDateFormat, and get rid of the format parameter.
    */
    String formattedDate = null;
    if(format == SHORT_DATE) {
      formattedDate = toString(date, null);
    }
    return formattedDate;
  }

  public static String toString(Date date, String format) {
     DateFormat dateFormat;
    if (date == null) {
      return null;
    }
    if(format == null)
     dateFormat = new SimpleDateFormat(DATE_PATTERN_SHORT);
    else
       dateFormat = new SimpleDateFormat(format);
    return dateFormat.format(date);
  }


}
