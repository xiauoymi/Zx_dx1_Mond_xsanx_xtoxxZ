/*
 CopyEquipmentConstants was created on Feb 5, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.util;

/**
 * Filename:    $RCSfile: CopyEquipmentConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-10 16:56:08 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public interface CopyEquipmentConstants {
  public static final String SEARCH_EQUIPMENTS_TO_COPY_JSP = "/WEB-INF/jsp/copyEquipment/setupSearchForEquipmentsToCopy.jspx";
  public static final String EDIT_EQUIPMENTS_BEFORE_COPYING_JSP = "/WEB-INF/jsp/copyEquipment/editEquipmentsBeforeCopying.jspx";
  public static final String EQUIPMENT_ID_TO_COPY = "equipmentIdToCopy";
  public static final String EQUIPMENT_QUANTITY = "quantity";
  public static final String COPY_FROM_PROJECT_ID   = "copyFromProjectId";
  public static final String EQUIPMENT_NAME   = "equipmentName";
  public static final String EQUIPMENT_AREA   = "areaId";
  public static final String PROCESS_LINE_NUMBER   = "processLineNumber";
  public static final String EQUIPMENT_TAG_NUMBER   = "equipmentTagNumber";
}