/*
 CostScheduleConstants was created on Nov 10, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.util;

/**
 * Filename:    $RCSfile: CostScheduleConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-22 14:17:42 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public interface CostScheduleConstants {
  public static final String HAS_COST_SCHEDULED_DATA_CHANGED = "hasCostScheduledDataChanged";
  public static final String COST_SCHEDULE_ID = "costScheduleId";
  public static final String CS_SCHEDULED_SPECIFICATION = "scheduledSpecificationDate";
  public static final String CS_SCHEDULED_QUOTE = "scheduledQuoteDate";
  public static final String CS_SCHEDULED_PURCHASE = "scheduledPurchaseDate";
  public static final String CS_DRAWING_TURNAROUNDTIME = "drawingTurnaroundTime";
  public static final String CS_EST_FABRICATION_TIME = "estiamtedFabricationTime";
  public static final String CS_EST_SHIPPING = "estiamtedShippingDate";
  public static final String CS_SPEC_ISSED = "specIssuedDate";
  public static final String CS_RTQ_ENTERED = "rtqEnteredDate";
  public static final String CS_RTP_ENTERED = "rtpEnteredDate";
  public static final String CS_PREL_DRAWING_ISSUED = "prelDrawingIssuedDate";
  public static final String CS_APPROVAL_DRAWING = "approvalDrawingDate";
  public static final String CS_FINAL_DRAWING = "finalDrawingDate";
  public static final String CS_IOM_RECEIVED = "iomReceivedDate";
  public static final String CS_EST_SOURCE = "estimatedSource";
  public static final String CS_EST_COST = "estimatedCost";
  public static final String CS_FUNDING_SOURCE_ID = "fundingSourceId";
  public static final String CS_EST_MECH_HRS = "estimatedMechHours";
  public static final String CS_ESCALATION_FACTOR = "escalationFactor";
}