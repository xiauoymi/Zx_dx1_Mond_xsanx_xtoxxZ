package com.monsanto.eas.eis.util;

import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.hibernate.HibernateFactoryImpl;
/*
 EISHibernateUtil was created on Aug 8, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class EISHibernateUtil {
  private static final String EIS_APP_NAME = "eis"; //todo change this once EIS gets its own schema

  public static HibernateFactory getHibernateFactory() {
    return HibernateFactoryImpl.getInstance(EIS_APP_NAME);
  }
}
