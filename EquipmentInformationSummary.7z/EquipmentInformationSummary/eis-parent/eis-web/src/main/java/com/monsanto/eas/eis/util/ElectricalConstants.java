package com.monsanto.eas.eis.util;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 23, 2008 Time: 2:33:56 PM To change this template use File |
 * Settings | File Templates.
 */
public interface ElectricalConstants {

  public static final String HAS_ELECTRICAL_DATA_CHANGED = "hasElectricalDataChanged";
  public static final String INPUT_ID = "inputId";
  public static final String OUTPUT_ID = "outputId";
  public static final String OTHER_MEASUREMENT_ID = "otherMeasurementId";
  public static final String PROOF_OF_POSITION_REQUIRED = "proofOfPositionReq";
  public static final String SOLENOID_REQUIRED = "solenoidReq";
  public static final String LOCAL_PUSH_BUTTON_REQUIRED = "localPushButtonReq";
  public static final String INPUT = "input";
  public static final String INPUT_QUANTITY = "inputQty";
  public static final String OUTPUT = "output";
  public static final String OUTPUT_QUANTITY = "outputQty";
  public static final String HMI_DISPLAY = "hmiDisplay";
  public static final String OTHER_MEASURMENT = "otherMeasurement";
  public static final String COMMUNICATIONS = "communications";
  public static final String VOLTAGE = "voltage";
  public static final String ELECTRICAL_INPUTS = "electricalInputs";
  public static final String ELECTRICAL_OUTPUTS = "electricalOutputs";
  public static final String OTHER_MEASUREMENTS = "otherMeasurements";
  public static final String ELECTRICAL_INPUTS_CHECKBOX = "electricalInputsCheckbox";
  public static final String ELECTRICAL_INPUTS_QUANTITY = "electricalInputsQty";
  public static final String ELECTRICAL_OUTPUTS_CHECKBOX = "electricalOutputsCheckbox";
  public static final String ELECTRICAL_OUTPUTS_QUANTITY = "electricalOutputsCheckbox";
}
