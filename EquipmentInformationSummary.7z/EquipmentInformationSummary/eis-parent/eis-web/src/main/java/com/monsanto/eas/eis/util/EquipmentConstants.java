/*
 EquipmentConstants was created on Oct 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.util;

/**
 * Filename:    $RCSfile: EquipmentConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2008-12-27 05:11:36 $
 *
 * @author sspati1
 * @version $Revision: 1.11 $
 */
public interface EquipmentConstants {
  public static final String SEARCH_EQUIPMENT_TYPE = "searchEquipmentType";
  public static final String SEARCH_EQUIPMENT_AREA = "searchEquipmentArea";
  public static final String SEARCH_PROCESS_LINE = "searchProcessLine";
  public static final String SEARCH_EQUIPMENT_NUMBER = "searchEquipmentNumber";
  public static final String SEARCH_EQUIPMENT_NAME = "searchEquipmentName";
  public static final String SEARCH_VENDOR = "searchVendor";
  public static final String SEARCH_EXISTING_EQUIPMENT_NUMBER = "searchExistingEquipmentNumber";

  public static final String SEARCH_EQUIPMENT_SUBTYPE = "searchEquipmentSubType";
  public static final String SEARCH_EQUIPMENT_TAG_NUM = "searchEquipmentTagNumber";
  public static final String AREA = "area";
  public static final String EQUIPMENT_TYPE = "equipmentType";
  public static final String VENDOR = "equipmentVendor";
  public static final String EQUIPMENT_NUMBER = "equipmentNumber";
  public static final String EQUIPMENT_NAME = "name";
  public static final String PROCESS_LINE_NUMBER = "processLineNumber";
  public static final String MOTORS = "motors";
  public static final String INSTRUMENTS = "instruments";
  public static final String ACCESSORIES = "accessories";


  public static final String MECHANICAL_ID = "mechanicalId";

  public static final String HAS_BID_PACK_WORK_DESC_DATA_CHANGED = "hasBidPackWorkDescDataChanged";
  public static final String BID_PACKAGE = "bidPackage";
  public static final String WORK_DESCRIPTION = "workDescription";
  public static final String METHOD_DELETE_EQUIPMENT = "deleteEquipment";
}