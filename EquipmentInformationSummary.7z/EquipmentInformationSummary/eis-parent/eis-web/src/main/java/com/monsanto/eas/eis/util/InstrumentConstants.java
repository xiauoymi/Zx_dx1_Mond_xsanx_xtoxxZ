/*
 InstrumentConstants was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.util;

/**
 * Filename:    $RCSfile: InstrumentConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-01-27 14:25:07 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public interface InstrumentConstants {
  public static final String HAS_INTRUMENTS_DATA_CHANGED = "hasInstrumentsDataChanged";
  public static final String INSTRUMENT_ID = "instrumentId";
  public static final String DESIGNATOR_FIRST_CHAR_ID = "designatorFirstCharId";
  public static final String DESIGNATOR_SECOND_CHAR_ID = "designatorSecondCharId";
  public static final String INST_SEQUENCE_NUMBER = "instSequenceNumber";
  public static final String INST_DESCRIPTION = "instDescription";
  public static final String IO_TYPE_ID = "ioTypeId";
  public static final String ALARM_POINTS = "alarmPoints";
  public static final String ALARM_POINTS_QUANTITY = "alarmPointsQuantity";
  public static final String INST_TYPE_ID = "instrumentTypeId";
  public static final String INST_VOLTS = "instVolts";
  public static final String INST_RANGE = "instRange";
  public static final String INST_UNITS = "instUnits";
  public static final String INST_COMMENTS = "instComments";

  public static final String INST_PURCHASED_WITH_EQUIP = "instPurchasedWithEquip";
  public static final String INST_PURCHASING_ID = "instPurchaseId";
  public static final String INST_VENDOR = "instVendor";
  public static final String INST_RTP_NUMBER = "instRtpNumber";
  public static final String INST_PO_NUMBER = "instPoNumber";
  public static final String INST_LINE_NUMBER = "instLineNumber";
  public static final String INST_ACTUAL_DELIVERY_DATE = "instActualDeliveryDate";
  public static final String DELETED_INSTRUMENT_IDS = "deletedInstrumentIds";
  public static final String INST_ESTIMATED_COST="instEstimatedCost";
  public static final String INST_ACTUAL_COST="instActualCost";
  public static final String INST_BID_PACAKAGE = "instBidPackage";
  public static final String INST_MANUFACTURER = "instManufacturer";
  public static final String INST_MODEL_NUMBER = "instModelNumber";
}