/*
 MotorConstants was created on Oct 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.util;

/**
 * Filename:    $RCSfile: MotorConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-01-27 14:25:07 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public interface MotorConstants {

  public static final String HAS_MOTORS_DATA_CHANGED = "hasMotorsDataChanged";
  public static final String MOTOR_ID = "motorId";
  public static final String COMPONENT_DESIGNATOR_ID = "componentDesignatorId";
  public static final String MOTOR_SEQUENCE_NUMBER = "motorSequenceNumber";
  public static final String COMPONENT_NAME = "componentName";
  public static final String FLA = "fla";
  public static final String MOTOR_VOLTAGE = "motorVoltage";
  public static final String PHASE = "phase";
  public static final String FREQUENVY = "frequency";
  public static final String RPM = "rpm";
  public static final String STARTER_ID = "starterId";
  public static final String DESIGN_STATUS_ID = "designStatusId";
  public static final String MOTOR_COMMENTS = "motorComments";
  public static final String LOAD_VALUE_TYPE_ID = "loadValueTypeId";
  public static final String LOAD_VALUE_QUANTITY = "loadValueQuantity";
  public static final String IO_CABINET = "ioCabinet";
  public static final String POWER_SOURCE = "powerSource";
  public static final String LOAD_DISCONNECT_REQUIRED = "loadDisconnectRequired";
  public static final String STARTER_SIZE = "starterSize";
  public static final String MOTOR_BRAKE = "motorBrake";
  public static final String DELETED_MOTOR_IDS = "deletedMotorIds";
  public static final String BID_PACKAGE = "bidPackage";
}