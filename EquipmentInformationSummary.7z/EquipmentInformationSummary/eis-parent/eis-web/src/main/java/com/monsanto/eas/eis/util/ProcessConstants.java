package com.monsanto.eas.eis.util;

/**
 * Filename:    $RCSfile: ProcessConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-01-23 14:43:36 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public interface ProcessConstants {  
  public static final String HAS_PROCESS_DATA_CHANGED = "hasProcessDataChanged";
  public static final String PRODUCT_TYPE = "productType";
  public static final String PRODUCT_DENSITY = "productDensity";
  public static final String DESIGN_CAPACITY = "designCapacity";
  public static final String DESIGN_CAPACITY_UNIT = "designCapacityUnit";
  public static final String COMP_AIR_REQUIRED = "compAirRequired";
  public static final String COMP_AIR_PRESSURE = "compAirPressure";
  public static final String COMP_AIR_FLOWRATE = "compAirFlowrate";
  public static final String GAS_REQUIRED = "gasRequired";
  public static final String GAS_PRESSURE = "gasPressure";
  public static final String GAS_FLOWRATE = "gasFlowrate";
  public static final String GAS_TYPE = "gasType";
  public static final String WATER_REQUIRED = "waterRequired";
  public static final String WATER_PRESSURE = "waterPressure";
  public static final String WATER_FLOWRATE = "waterFlowrate";
  public static final String WATER_TYPE = "waterType";
  public static final String DUST_PICKUP_REQUIRED = "dustPickupRequired";
  public static final String DUCT_SIZE = "ductSize";
  public static final String DIST_FLOWRATE = "dustFlowrate";
  public static final String DUST_TYPE = "dustType";
  public static final String BAGHOUSE_CYCLONE = "baghouseCyclone";
  public static final String DUST_PICKUP_VELOCITY = "dustPickupVelocity";
  public static final String PROCESS_REMARKS = "processRemarks";
  public static final String SPECIFICATION_REQUIRED = "specificationRequired";

  public static final String GAS_TYPE_ID = "gasTypeId";
  public static final String WATER_TYPE_ID = "waterTypeId";
  public static final String DUST_TYPE_ID = "dustTypeId";
  public static final String DESIGN_CAPACITY_UNIT_ID = "designCapacityUnitId";

  public static final String DESIGN_CAPACITY_UNIT_TEXT = "designCapacityUnitText";
}
