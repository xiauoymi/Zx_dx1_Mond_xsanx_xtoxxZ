package com.monsanto.eas.eis.util;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 28, 2008 Time: 9:29:06 AM To change this template use File |
 * Settings | File Templates.
 */
public interface PurchasingConstants {
  public static final String HAS_PURCHASING_DATA_CHANGED = "hasPurchasingDataChanged";
  public static final String VENDOR = "vendor";
  public static final String SOLE_SOURCE = "purchaseSoleSource";
  public static final String RTP_NUMBER = "rtpNumber";
  public static final String PO_NUMBER = "poNumber";
  public static final String LINE_NUMBER = "lineNumber";
  public static final String PO_LINE_AMOUNT = "poLineAmount";
  public static final String PO_LINE_QUANTITY = "poLineQuantity";
  public static final String PO_LINE_VALUE = "poLineValue";
  public static final String CO_AMOUNT = "coAmount";
  public static final String ORIGINAL_SHIP_DATE = "originalShipDate";
  public static final String REVISED_SHIP_DATE = "revisedShipDate";
  public static final String ACTUAL_DELIVERY_DATE = "actualDeliveryDate";
  public static final String EXPORT_DOCUMENTS = "exportDocuments";
}
