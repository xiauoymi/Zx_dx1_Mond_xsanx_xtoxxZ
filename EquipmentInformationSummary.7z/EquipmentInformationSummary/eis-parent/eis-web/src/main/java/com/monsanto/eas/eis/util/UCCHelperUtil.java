package com.monsanto.eas.eis.util;

import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Nov 12, 2008 Time: 1:39:21 PM To change this template use File |
 * Settings | File Templates.
 */
public class UCCHelperUtil {
  public static Map<String, String> getRequestParametersFromHelper(UCCHelper helper) throws IOException {
    Map<String, String> parameterMap = new HashMap<String, String>();
    Enumeration parameterNames = helper.getParameterNames();
    while(parameterNames.hasMoreElements()){
      String name = (String) parameterNames.nextElement();
      parameterMap.put(name, helper.getRequestParameterValue(name));
    }
    return parameterMap;
  }
}
