package com.monsanto.eas.eis.util;

import org.apache.commons.lang.StringUtils;

import java.io.UnsupportedEncodingException;

/**
 * Created by afhyat Aug 25, 2008
 */
public class Utilities {

   public static String escapeXml(String xml) {
    if (xml == null) {
      return "";
    } else {
      return xml.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
    }
  }

  public static String decodeUsingUTF8(String value) {

    if (StringUtils.isNotEmpty(value)) {
      try {
        byte[] latin1Bytes = value.getBytes("ISO-8859-1");
        return new String(latin1Bytes, "UTF-8");
      } catch (UnsupportedEncodingException e) {
        throw new RuntimeException(e);
      }
    }else{
      return null;
    }
  }
}
