package com.monsanto.eas.eis.util;

import org.apache.commons.lang.StringUtils;

import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 29, 2008 Time: 1:47:14 PM To change this template use File |
 * Settings | File Templates.
 */
public class Validator {

  public static void validateRequiredFieldInARow(String fieldValue, String label,
                                                 boolean checkMinLength, int minLength, List<String> requiredFields,
                                                 int rowNumber) {
    if (isRequiredFieldEmpty(fieldValue)) {
      String msg = label + " for row " + (rowNumber + 1);
      requiredFields.add(msg);
    } else {
      if (checkMinLength && !isFieldLengthValid(fieldValue, minLength)) {
        String msg = label + " for row " + (rowNumber + 1);
        msg += " should be at least " + minLength + " characters long";
        requiredFields.add(msg);
      }
    }
  }

  public static boolean isFieldLengthValid(String fieldValue, int expectedLength) {
    return !isRequiredFieldEmpty(fieldValue) && fieldValue.length() >= expectedLength;
  }

  public static boolean isRequiredFieldEmpty(String field) {
    return StringUtils.isBlank(field);
  }

}
