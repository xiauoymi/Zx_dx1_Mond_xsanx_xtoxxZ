/*
 XMLBuffer was created on Jan 29, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.util;

import com.monsanto.wst.textutil.TextUtil;
import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: XMLBuffer.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-01-30 16:27:33 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class XMLBuffer{
  private StringBuffer xmlbuffer = null;

  public XMLBuffer(){
    this.xmlbuffer = new StringBuffer();
  }

  public XMLBuffer(String string) {
    this.xmlbuffer = new StringBuffer(string);
  }

  public StringBuffer append(String str) {
    return xmlbuffer.append(str);
  }

  public StringBuffer appendValue(Object object) {
    return xmlbuffer.append(TextUtil.escapeXml(String.valueOf(returnEmptyIfNull(object))));
  }

   public String toString(){
    return xmlbuffer.toString();
  }

   private Object returnEmptyIfNull(Object obj) {
    if (obj == null) {
      return "";
    } else {
      return obj;
    }
  }
}