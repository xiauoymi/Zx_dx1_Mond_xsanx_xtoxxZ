package com.monsanto.eas.info;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Apr 16, 2009
 * Time: 2:42:02 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ApplicationResource {
  boolean validateResource();
}
