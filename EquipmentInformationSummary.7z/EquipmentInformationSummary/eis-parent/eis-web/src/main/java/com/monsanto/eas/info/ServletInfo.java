package com.monsanto.eas.info;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.ServletFramework.UseCaseController;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Apr 16, 2009
 * Time: 1:34:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class ServletInfo extends HttpServlet {
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

  }

  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    PrintWriter out = response.getWriter();
    out.println("<HTML>");
    out.println("<HEAD><TITLE>APPLICATION INFO</TITLE></HEAD>");
    out.println("<BODY>");
    out.println("<TABLE>");
    boolean finalResult=true;
    Enumeration parameterNames = getServletConfig().getInitParameterNames();
    while(parameterNames.hasMoreElements()){
      out.println("<TR>");

      String resource = (String) parameterNames.nextElement();
      String resourceValidator = getServletConfig().getInitParameter(resource);
      out.println("<TD>");
      out.println(resource);
      out.println("</TD>");

      Class controllerClass;
      try {
        controllerClass = Class.forName(resourceValidator.toString());
        ApplicationResource applicationResource = (ApplicationResource) controllerClass.newInstance();
        boolean result = applicationResource.validateResource();
        out.println("<TD>");
        out.println(result);
        out.println("</TD>");
        if(!result){
          finalResult=false;
        }
      } catch (ClassNotFoundException e) {
        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
      } catch (IllegalAccessException e) {
        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
      } catch (InstantiationException e) {
        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
      }
      out.println("</TR>");

    }

    out.println("<TR>");
    out.println("<TD>");


    if(finalResult){
      out.println("SUCCESS");
    } else{
      out.println("FAILURE");
    }
    out.println("</TD>");
    out.println("</TR>");

    out.println("</TABLE>");
    out.println("</BODY>");
    out.println("</HTML>");


    out.close();

  }
}
