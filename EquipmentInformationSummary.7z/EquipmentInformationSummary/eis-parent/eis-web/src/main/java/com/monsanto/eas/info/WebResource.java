package com.monsanto.eas.info;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Apr 16, 2009
 * Time: 2:47:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class WebResource implements ApplicationResource{
  public boolean validateResource() {
    return true;  //To change body of implemented methods use File | Settings | File Templates.
  }
}
