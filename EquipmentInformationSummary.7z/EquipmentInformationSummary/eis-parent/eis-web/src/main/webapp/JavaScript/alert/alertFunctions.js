var projectCount = 0;
var contextPath;

var projectCountToIdMap = {
  set : function(foo, bar) {
    this[foo] = bar;
  },
  get : function(foo) {
    return this[foo];
  }
}


YAHOO.util.Event.addListener(window, "load", function() {
  createEquipmentDialog();
    createCostScheduleCalendars();
    createPurchasingCalendars();
  getCountOfProjectsForUserProjectIsInDetailedDesign();
  createAlertTableForProjectStatusAndRoleChange();
});


function getCountOfProjectsForUserProjectIsInDetailedDesign(){
  var url = document.getElementById("contextPath").value + "/data/projectCountForAlertXml/alert?method=lookupProjectsByProjectStatusForAUser";
  contextPath = document.getElementById('contextPath').value;
  
  this.createAlertForProjectTables = {
  success: function(o) {
    this.cache = null;
    var xmlDoc = o.responseXML;
     projectCount = xmlDoc.getElementsByTagName("count")[0].text;
    if (projectCount > 0){
     createTablesForEachProjectForChangeVerification(o, projectCount);
     createTablesForEachProjectForEquipmentModification(o, projectCount);
    }else{
      document.getElementById('tableEntryForChangeVerification').innerHTML = "<B>There are no changes to display.</B>";
      document.getElementById('tableEntryForAddDeleteNotification').innerHTML = "<B>There are no changes to display.</B>";
    }
    },
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    },
    timeout: 30000 //30 seconds
  };

  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url, this.createAlertForProjectTables);
}

function createTablesForEachProjectForChangeVerification(o){
  var xmlDoc = o.responseXML;
   var parentDivForTable = document.getElementById("tableEntryForChangeVerification");
   parentDivForTable.innerHTML = '';
   for (var i = 0; i < projectCount;  i++){
    var projectId = xmlDoc.getElementsByTagName("projectId")[i].text;
    var projectName = xmlDoc.getElementsByTagName("projectName")[i].text;
    addDynamicTableForEachProject(parentDivForTable, i, projectId, projectName);
    projectCountToIdMap.set(i, projectId);
   }
}

function createTablesForEachProjectForEquipmentModification(o){
  var xmlDoc = o.responseXML;
   var parentDivForTable = document.getElementById("tableEntryForAddDeleteNotification");
   parentDivForTable.innerHTML = '';
   for (var i = 0; i < projectCount;  i++){
    var projectId = xmlDoc.getElementsByTagName("projectId")[i].text;
    var projectName = xmlDoc.getElementsByTagName("projectName")[i].text;
    addDynamicTableForEachProjectForEquipmentModification(parentDivForTable, i, projectId, projectName);
   }
}
function appendChildDivToParentElement(parentDiv, childIdName, index){
  var childDiv = createDivElement(childIdName + index);
  parentDiv.appendChild(childDiv);
}


function createTable(){
  var table = document.createElement('table');
   table.setAttribute('border', '0');
   table.setAttribute('cellpadding', '0');
   table.setAttribute('cellspacing', '0');
  return table;
}

function createTrElement(id){
  var tr = document.createElement('tr');
  if (id != null || id != undefined){
    tr.setAttribute('id', 'tr' + id);
  }
  return tr;
}

function createTdElement(id, width){
  var td = document.createElement('td');
  td.setAttribute('id', id);
  if (width != undefined || width != null){
    td.setAttribute('width', width);
  }
  return td;
}

function createAnchorElement(id){
  var anchor = document.createElement('a');
  anchor.setAttribute('id', id);
  anchor.setAttribute('href', '#');
  return anchor;
}

function createImgElement(id){
  var img = document.createElement('img');
  img.setAttribute('id', 'img' + id);
  img.setAttribute('align', 'absMiddle');
  img.setAttribute('border', '0');
  img.setAttribute('src', contextPath + '/images/expand-icon.gif');
  return img;
}

function createDivElement(id){
   var div = document.createElement('div');
  div.setAttribute('id', id);
  return div;
}


function addDynamicTableForEachProjectForEquipmentModification(parent, index, projectId, projectName) {
  var table = createTable();

  var tbody = document.createElement('tbody');

  var tr = createTrElement('trAddDelete' + projectId);

  var td = createTdElement('headerForAlert', '400px');

  var anchor = createAnchorElement('alertAddDelete' + projectId);

  var imgId = 'AddDelete' + projectId;
  var img = createImgElement(imgId);
  anchor.appendChild(img);


  td.appendChild(anchor);
  td.appendChild(document.createTextNode(projectName));
  tr.appendChild(td);

  tbody.appendChild(tr);

  tr = createTrElement();

  td = createTdElement('dataTableAddDelete' + projectId);

  var parentDiv = createDivElement('alertForProjectsDivAddDelete' + index);

  appendChildDivToParentElement(parentDiv, "topPaginatorForAlertAddDelete", projectId);
  appendChildDivToParentElement(parentDiv, "alertForProjectAddDeleteList", projectId);

  td.appendChild(parentDiv);

  tr.appendChild(td);

  tbody.appendChild(tr);
  table.appendChild(tbody);
  parent.appendChild(table);
  YAHOO.util.Event.addListener(anchor, 'click',
                   loadDataTableAddDelete, this);
}


function addDynamicTableForEachProject(parent, index, projectId, projectName){
  var wrapperDiv = createDivElement('wrapperDiv' + index);

  var table = createTable();
  YAHOO.util.Dom.addClass(table, "wrapperDiv");

  var tbody = document.createElement('tbody');

  var tr = createTrElement('tr' + projectId);

  var td = createTdElement('headerForAlert', '400px');

  var anchor = createAnchorElement(projectId);

  var img = createImgElement(projectId);
  anchor.appendChild(img);


  td.appendChild(anchor);
  td.appendChild(document.createTextNode(projectName));
  tr.appendChild(td);

  tbody.appendChild(tr);

  tr = createTrElement();

  td = createTdElement('dataTable' + projectId, '400px');

  var parentDiv = createDivElement('alertForProjectsDiv' + index);
  appendChildDivToParentElement(parentDiv, "topPaginatorForAlertForProject", projectId);
  appendChildDivToParentElement(parentDiv, "alertForProjectList", projectId);
  td.appendChild(parentDiv);

  tr.appendChild(td);

  tbody.appendChild(tr);
  table.appendChild(tbody);

  wrapperDiv.appendChild(table);
  parent.appendChild(wrapperDiv);
  YAHOO.util.Event.addListener(anchor, 'click',
                   loadDataTable, this);
}

function loadDataTable(){
  var anchor = this;
  var id = anchor.id;
  var img = document.getElementById('img'+ id);
  var tableDivId = "alertForProjectList" + id;
  var paginatorDivId = "topPaginatorForAlertForProject" + id;
  var dataTableId = 'dataTable' + id;

  if (img.src.match("expand") != null){
    var url =  document.getElementById('contextPath').value + "/data/alertForProjectXml?projectId=" + id;
  }

  toggleImage(id, img, tableDivId, paginatorDivId, dataTableId, url, createAlertTableForEquipmentChangeVerification, 'dataTable', 'img');

}

function loadDataTableAddDelete(){
  var anchor = this;
  var id = anchor.id;
  if (id.indexOf('Delete') != -1){
    id = id.substr(id.indexOf('Delete') + 6, id.length);
  }
  var img = document.getElementById('imgAddDelete'+ id);
   var tableDivId = "alertForProjectAddDeleteList" + id;
    var paginatorDivId = "topPaginatorForAlertAddDelete" + id;
  var dataTableId = 'dataTableAddDelete' + id;

  if (img.src.match("expand") != null){
    var url =  document.getElementById('contextPath').value + "/data/alertForEquipAddDeleteXml?projectId=" + id;
  }
  toggleImage(id, img, tableDivId, paginatorDivId, dataTableId, url, createAlertTableForEquipmentAddDelete, 'dataTableAddDelete', 'imgAddDelete');
}

function toggleImage(id, img, tableDivId, paginatorDivId, dataTableId, url, callCreateDataTable, dataTableIdFirstPart, imageIdFirstPart){
  var source = img.src;
  if (source.match("expand") != null){
    img.src = contextPath + "/images/collapse-icon.gif";
    document.getElementById(dataTableId).style.display = '';
    callCreateDataTable(url, tableDivId, paginatorDivId);
    var j = 0;
    for (j= 0; j < projectCount; j++){
      var projectIdInMap = projectCountToIdMap.get(j) + '';
      if (projectIdInMap === id){
      }else{
       var expandImage = contextPath + "/images/expand-icon.gif";
      document.getElementById(dataTableIdFirstPart + projectCountToIdMap.get(j)).style.display = 'none';
      document.getElementById(imageIdFirstPart + projectCountToIdMap.get(j)).src= expandImage;
      }
    }
  } else if (source.match("collapse") != null){
    img.src = contextPath + "/images/expand-icon.gif";
    document.getElementById(dataTableId).style.display = 'none';
  }
}

function lookupProjectSpecificDataForAnEquipment(projectId, equipmentId){
  this.populateArrays = {
    success: function(o) {
      this.cache = null;
      var xmlDoc = o.responseXML;
      var areaId = xmlDoc.getElementsByTagName('areaSelected')[0].text;
      //set all hidden variables
      document.getElementById('areaId').value = areaId;
      document.getElementById('projectId').value = projectId;
      document.getElementById('projectUnitMeasureId').value = xmlDoc.getElementsByTagName('unitMeasureId')[0].text;
      document.getElementById('userHasEditAccessToThisProject').value =
        xmlDoc.getElementsByTagName('editAccess')[0].text;
      document.getElementById('isUserInProcessRoleForThisProject').value =
        xmlDoc.getElementsByTagName('processRole')[0].text;
      document.getElementById('isUserInMechanicalEngineerRoleForThisProject').value =
        xmlDoc.getElementsByTagName('mechanicalEngineerRole')[0].text;

      var element = document.getElementById('equipmentAreaId');
      populateDropDown(xmlDoc, element, areaId);
      showEquipmentDetailsDialog(equipmentId);
    },
    failure: function(o) {
    },
    timeout: 30000 //30 seconds
  };


  var url = document.getElementById('contextPath').value +
            "/data/alertRefDataForProjectXml?method=lookupAllRefDataForProjectAndEquipmentXML"
      + "&projectId=" + projectId + "&equipmentId=" + equipmentId;
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url,
      this.populateArrays);
}
