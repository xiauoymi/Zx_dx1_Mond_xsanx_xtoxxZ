var alertDataTable = null;
var i = 0;

var projectIdToDataTableMap = {
  set : function(foo, bar) {
    this[foo] = bar;
  },
  get : function(foo) {
    return this[foo];
  }
}

function createAlertTableForEquipmentChangeVerification(url, tableIdName, paginatorName) {
  if (url.indexOf('projectId') != -1) {
    var projectId = url.substr(url.indexOf('projectId') + 10, url.length);
  }
  this.alertDataSource = createServerSidePaginationDataSource(url);
  var fieldArr = [];
  fieldArr[fieldArr.length] = "id";
  fieldArr[fieldArr.length] = "equipmentNumber";
  fieldArr[fieldArr.length] = "equipmentName";
  fieldArr[fieldArr.length] = "processNotVerified";
  fieldArr[fieldArr.length] = "mechanicalNotVerified";
  fieldArr[fieldArr.length] = "electricalNotVerified";
  fieldArr[fieldArr.length] = "projectId";
  this.alertDataSource.responseSchema = {
    resultNode: "alert",
    fields: fieldArr,
    metaFields: {totalRecords : "totalRecords"}
  };
  alertDataTable = getAlertForProjectTable(getAlertForProjectColumnDefs(), this.alertDataSource, tableIdName, paginatorName);
  projectIdToDataTableMap.set(projectId, alertDataTable);
}

function refreshDataTableForProjectChangeVerification(projectId){
  projectIdToDataTableMap.get(projectId).requery();
}

function getAlertForProjectTable(columnDefs, dataSource, tableIdName, paginatorName) {
  return createDataTable(tableIdName, columnDefs, dataSource, "equipmentNumber",
  {initialLoad:true, scrollable:false, width:getWidthForDataTable(), emptyMsg:"No Alerts Found"}, {pagination: true, topPaginator:paginatorName});
}


function getAlertForProjectColumnDefs() {
  this.equipmentNumberFormatterForAlert = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<a href="#" onclick="' + 'lookupProjectSpecificDataForAnEquipment(' +
                       oRecord.getData('projectId') + ', '
        + oRecord.getData('id') + '); return false;">' + oData + '</a>';

  };

  var columnDefs = [];
  columnDefs[columnDefs.length] = {key:"equipmentNumber", className:"equipNumberForAlert", formatter: this.equipmentNumberFormatterForAlert, label:"Equipment<br/>Number", sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"equipmentName", className:"equipNameForAlert", label:"Equipment Name", sortable:true, resizeable:true, width:150};
  columnDefs[columnDefs.length] = {key:"processNotVerified", className:"processNotVerified", label:"Process", sortable:true, resizeable:true, width: 60};
  columnDefs[columnDefs.length] = {key:"mechanicalNotVerified", className:"mechanicalNotVerified", label:"Mechanical", sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"electricalNotVerified", className:"electricalNotVerified", label:"Electrical", sortable:true, resizeable:true, width:60};
  return columnDefs;
}