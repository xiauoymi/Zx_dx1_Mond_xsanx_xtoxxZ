var alertDataTableForAddDelete = null;

function createAlertTableForEquipmentAddDelete(url, tableIdName, paginatorName) {
    this.alertDataSource = createServerSidePaginationDataSource(url);
    var fieldArr = [];
    fieldArr[fieldArr.length] = "id";
    fieldArr[fieldArr.length] = "equipmentNumber";
    fieldArr[fieldArr.length] = "modifiedBy";
    fieldArr[fieldArr.length] = "dateModified";
    fieldArr[fieldArr.length] = "addedOrDeleted";
    fieldArr[fieldArr.length] = "projectId";
    this.alertDataSource.responseSchema = {
      resultNode: "alertForEquipmentAddDelete",
      fields: fieldArr,
      metaFields: {totalRecords : "totalRecords"}
    };
    alertDataTableForAddDelete = getAlertForEquipmentAddDelete(getAlertForAddDeleteColumnDefs(), this.alertDataSource, tableIdName, paginatorName);
}

function getAlertForEquipmentAddDelete(columnDefs, dataSource, tableIdName, paginatorName) {
  return createDataTable(tableIdName, columnDefs, dataSource, "equipmentNumber",
  {initialLoad:true, scrollable:false, width:getWidthForDataTable(), emptyMsg:"No Alerts Found"}, {pagination: true, topPaginator:paginatorName});
}


function getAlertForAddDeleteColumnDefs() {
  this.equipmentNumberAddDeleteFormatterForAlert = function(elCell, oRecord, oColumn, oData) {
    if (oRecord.getData('addedOrDeleted') === 'I'){
      elCell.innerHTML = '<a href="#" onclick="lookupProjectSpecificDataForAnEquipment(' + oRecord.getData('projectId') + ', '
                      + oRecord.getData('id') + '); return false;">' + oData + '</a>';
    }else{
      elCell.innerHTML = oRecord.getData('equipmentNumber');
    }
    };

  this.equipmentStatusFormatter = function(elCell, oRecord, oColumn, oData) {
    var contextPath = document.getElementById('contextPath').value;
    if (oData === 'I'){
      elCell.innerHTML = '<img src="' + contextPath + "/images/new-icon.gif" + '" width="24" height="11"/>';
    }else if (oData === 'D'){
      elCell.innerHTML = '<img src="' + contextPath + "/images/deleted-icon.gif" + '" width="43" height="11"/>';
    }else{
      elCell.innerHTML = '';
    }
  };

  var columnDefs = [];
 columnDefs[columnDefs.length] = {key:"equipmentNumber", className:"equipNumberForAlert", formatter: this.equipmentNumberAddDeleteFormatterForAlert, label:"Equipment<br/>Number", sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"modifiedBy", className:"modifiedBy", label:"Modified<br/>By", sortable:true, resizeable:true, width:65};
  columnDefs[columnDefs.length] = {key:"dateModified", className:"dateModified", label:"Modified<br>Date", sortable:true, resizeable:true, width: 72};
  columnDefs[columnDefs.length] = {key:"addedOrDeleted", className:"addedOrDeleted", label:"Status", formatter: this.equipmentStatusFormatter, sortable:true, resizeable:true, width:50};
  return columnDefs;
}