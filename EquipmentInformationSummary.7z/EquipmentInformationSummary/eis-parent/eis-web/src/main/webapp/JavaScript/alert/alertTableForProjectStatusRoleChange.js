var alertDataTableForProjectStatusAndRoleChange = null;

function createAlertTableForProjectStatusAndRoleChange() {
  var url =  document.getElementById('contextPath').value + "/data/alertForProjectStatusAndRoleChangeXml?dummy=dummy";
  if (alertDataTableForProjectStatusAndRoleChange === null){
    var tableIdName = 'projectStatusRoleChangeList';
    this.alertDataSource = createServerSidePaginationDataSource(url);
    var fieldArr = [];
    fieldArr[fieldArr.length] = "id";
    fieldArr[fieldArr.length] = "projectNumber";
    fieldArr[fieldArr.length] = "description";
    fieldArr[fieldArr.length] = "modifiedBy";
    fieldArr[fieldArr.length] = "dateModified";
    fieldArr[fieldArr.length] = "goToProjectUrl";
    this.alertDataSource.responseSchema = {
      resultNode: "alertForProjectRoleStatus",
      fields: fieldArr
    };
    alertDataTableForProjectStatusAndRoleChange = getAlertForProjectStatusAndRoleChange(getAlertForProjectStatusAndRoleChangeColumnDefs(), this.alertDataSource, tableIdName);
  }
  else {
    alertDataTableForProjectStatusAndRoleChange.requery(url);
  }
}

function getAlertForProjectStatusAndRoleChange(columnDefs, dataSource, tableIdName) {
  return createDataTable(tableIdName, columnDefs, dataSource, "projectNumber",
  {initialLoad:true, scrollable:false, width:getWidthForDataTable(), emptyMsg:"No Changes Found"}, {pagination: false});
}

function getAlertForProjectStatusAndRoleChangeColumnDefs() {
   this.projectNumberFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<a href="' + document.getElementById('contextPath').value +
                       '/servlet/projects?method=project_detail&projectId=' + oRecord.getData('id') + '">' +
                       oData + '</a>';
  };

  var columnDefs = [];
  columnDefs[columnDefs.length] = {key:"projectNumber", className:"projectNumber", formatter: this.projectNumberFormatter, label:"Project<br/>Number", sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"description", className:"statusRoleDescription", label:"Description", sortable:true, resizeable:true, width:140};
  columnDefs[columnDefs.length] = {key:"modifiedBy", className:"modifiedBy", label:"Modified<br>By", sortable:true, resizeable:true, width: 65};
  columnDefs[columnDefs.length] = {key:"dateModified", className:"dateModified", label:"Modified<br>Date", sortable:true, resizeable:true, width:72};
  return columnDefs;
}