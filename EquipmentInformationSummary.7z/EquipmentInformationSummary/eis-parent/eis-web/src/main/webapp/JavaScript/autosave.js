function getQueryStringForAutosave(eisDataTable, oRecord, oKey, oValue) {
  var autosaveParams = eisDataTable.getAutosaveParams();
  var className = autosaveParams.columnKeyToClassNameMap[oKey];
  if (className === undefined) {
    return null;
  } else {
    var columnKeyForPrimaryKey = autosaveParams.primaryKeyForClassNameFnc(className);
      var primaryKey = '';
        primaryKey = oRecord.getData(columnKeyForPrimaryKey);

         if(oValue === undefined){
            oValue = oRecord.getData(oKey);
        }

      if (oKey === 'purchaseSoleSource'){
          oKey = 'equipmentSoleSource';
      }

    oValue = autosaveParams.formattedValueFnc === null ? oValue : autosaveParams.formattedValueFnc(oKey, oValue);
    return "&className=" + className + "&primaryKey=" + primaryKey + "&fieldName=" + oKey + "&fieldValue=" +
           oValue;
  }
}

function autosaveValue(dt, queryStr, url) {
  if (queryStr != null) {
    dt.disable();
    this.callBackAfterAutosaveField = {
      success: function(o) {
        dt.undisable();
      },
      failure: function(o) {
        dt.undisable();
        alert("Autosave failed");
      },
      timeout: 30000 //30 seconds
    };

    if (url === undefined || url === null) {
      url = document.getElementById('contextPath').value +
            "/data/autosave?method=autosaveField" + queryStr;
    }
    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
        url, this.callBackAfterAutosaveField);
  }
}

    //
//
//function sendSyncRequest(url, callbackMethodAfterSync) {
//  var http_request = false;
//  if (window.XMLHttpRequest) { // Mozilla, Safari,...
//    http_request = new XMLHttpRequest();
//    if (http_request.overrideMimeType) {
//      http_request.overrideMimeType('text/html');
//    }
//  } else if (window.ActiveXObject) { // IE
//    try {
//      http_request = new ActiveXObject("Msxml2.XMLHTTP");
//    } catch (e) {
//      try {
//        http_request = new ActiveXObject("Microsoft.XMLHTTP");
//      } catch (e) {
//      }
//    }
//  }
//  if (!http_request) {
//    alert('Cannot create XMLHTTP instance');
//    return false;
//  }
//  http_request.open('POST', url, false);
//  http_request.setRequestHeader("If-Modified-Since", "Sat, 1 Jan 2000 00:00:00 GMT");
//  http_request.onreadystatechange = function() {
//    if (http_request.readyState == 4) {
//      callbackMethodAfterSync(http_request);
//    }
//  }
//  http_request.send();
//  return true;
//}
//
//function callbackAfterGettingSessionId(http_request) {
//  document.getElementById('__AUTOSAVE_SESSION_ID').value = http_request.responseText;
//  document.getElementById('__AUTOSAVE_SESSION_SEQ').value = 0;
//}
//
//function startAutosaveSession() {
//  sendSyncRequest(document.getElementById('contextPath').value +
//                  '/data/autosave?method=startAutosaveSession', callbackAfterGettingSessionId);
//}
//
//function startSessionIfNotAlreadyStarted() {
//  var autosaveSessionId = document.getElementById('__AUTOSAVE_SESSION_ID').value;
//  if (autosaveSessionId == null || autosaveSessionId == "") {
//    startAutosaveSession();
//  }
//}
//
//function setNextSessionSequence() {
//  var autosaveSeqStr = document.getElementById('__AUTOSAVE_SESSION_SEQ').value;
//  var autosaveSeq = parseInt(autosaveSeqStr);
//  autosaveSeq += 1;
//  document.getElementById('__AUTOSAVE_SESSION_SEQ').value = autosaveSeq;
//}
//
//function getNextAutosaveSessionSequence(){
//  setNextSessionSequence();
//  return document.getElementById('__AUTOSAVE_SESSION_SEQ').value;
//}
//
//function getAutosaveSessionId(){
//  return document.getElementById("__AUTOSAVE_SESSION_ID").value;
//}