var editEquipmentsBeforeCopyingTable = null;
var areaArray = null;

YAHOO.util.Event.addListener(window, "load", function() {
  getRefDataForEditEquipmentsBeforeCopyingTable();
});

function getRefDataForEditEquipmentsBeforeCopyingTable() {
  this.populateArrays = {
    success: function(o) {
      var xmlDoc = o.responseXML;
      areaArray = populateArrayForDropdown(xmlDoc, 'areas/area', 'id', 'areaCodeDescription');
      createEditEquipmentsBeforeCopyingTable();
    },
    failure: function(o) {
    },
    timeout: 30000 //30 seconds
  };

  var url = document.getElementById('contextPath').value +
            "/data/copyEquipment/copy?method=lookupRefDataForEditEquipmentsBeforeCopyingXML"
      + "&projectId=" + document.getElementById("projectId").value;
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url,
      this.populateArrays);
}

function createEditEquipmentsBeforeCopyingTable() {
  var url = document.getElementById('contextPath').value + "/data/equipment/details?method=lookupEquipmentXml&equipmentId="
      + document.getElementById('equipmentIdToCopy').value;
  this.editEquipmentsBeforeCopyingDataSource = createServerSidePaginationDataSource(url);
  this.editEquipmentsBeforeCopyingDataSource.responseSchema = {
    resultNode: "equipment",
    fields: ["id", "name", "areaId", "processLineNumber", "equipmentTagNumber"],
    metaFields: {totalRecords : "totalRecords"}
  };
  editEquipmentsBeforeCopyingTable = getEditEquipmentsBeforeCopyingTable(getEditEquipmentsBeforeCopyingColumnDefs(), this.editEquipmentsBeforeCopyingDataSource);
}

function getEditEquipmentsBeforeCopyingTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 1;
  editableTableParams.lastEditableColumnIndex = 4;
  editableTableParams.newRecord = null;

  var eisDataTable = createEditableDataTable("editEquipmentsBeforeCopyingList", columnDefs, dataSource, null,
  {scrollable:true, width:getWidthForDataTable(), emptyMsg:"No Matching Equipments Found"}, {pagination: false}, {editableTableParams:editableTableParams});
  var dt = eisDataTable.getDataTable();
  dt.doBeforeLoadData = function(oRequest, oResponse, oPayload) {
    var quantity = parseInt(document.getElementById("quantity").value, 10);
    var record = oResponse.results[0];
    record.areaId = "";
    record.processLineNumber = "";
    record.equipmentTagNumber = "";
    for (var i = 1; i < quantity; i++) {
      oResponse.results[i] = record;
    }
    return true;
  }
  return eisDataTable;
}

function getEditEquipmentsBeforeCopyingColumnDefs() {

  this.rowNumFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = oRecord.getCount() + 1;
  }

  //  this.deleteEquipmentFormatter = function(el, oRecord, oColumn, oData) {
  //    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
  //                   '/images/icon_delete.gif" onclick="showDeleteEquipmentWarning(\'' + oRecord.getData('id') + '\')">';
  //    el.style.cursor = 'pointer';
  //  }

  this.textboxEditorForCopying = function (oEditor, oSelf) {
    textboxEditor(oEditor, editEquipmentsBeforeCopyingTable);
  }

  this.dropdownEditorForCopying = function (oEditor, oSelf) {
    dropdownEditor(oEditor, editEquipmentsBeforeCopyingTable);
  }

  this.areaDropDownFormatterForCopying = function(el, oRecord, oColumn, oData) {
    el.innerHTML = "&nbsp;"; //necessary for sorting to work properly
    var selectedValue = (YAHOO.lang.isValue(oData)) ? oData :
                        oRecord.getData(oColumn.key);
    var options = (YAHOO.lang.isArray(oColumn.editorOptions.dropdownOptions)) ?
                  oColumn.editorOptions.dropdownOptions : null;
    for (var i = 0; i < options.length; i++) {
      if (options[i].value == selectedValue) {
        if (selectedValue.length > 0) {
          var indexOfHyphen = options[i].label.indexOf(" - ");
          el.innerHTML = options[i].label.substring(0, indexOfHyphen);
        }
        break;
      }
    }
  }
  return [
    {key:"rowNum", label:"", className:"rowNum", formatter:this.rowNumFormatter, sortable:false, resizeable:false,  width:60},
    {key:"name", label:"Equipment Name<span class='required'>*</span>", className:"name editableCell", editor:this.textboxEditorForCopying, editorOptions:{disableBtns:true, maxLength:30, size:30}, sortable:false, resizeable:false, width:200},
    {key:"areaId", label:"Area<span class='required'>*</span>", className:"areaId editableCell", editor:this.dropdownEditorForCopying, editorOptions:{disableBtns:true, dropdownOptions:areaArray}, formatter:areaDropDownFormatterForCopying, sortable:false, resizeable:false, width:200},
    {key:"processLineNumber", label:"Process Line #<span class='required'>*</span>", className:"processLineNumber editableCell", abbr:"Process Line", editor:this.textboxEditorForCopying, editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:1, size:1}, sortable:false, resizeable:false, width:150},
    {key:"equipmentTagNumber", label:"Equipment Tag #<span class='required'>*</span>", className:"equipmentTagNumber editableCell", abbr:"Equipment Tag Number", editor:this.textboxEditorForCopying, editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:false, resizeable:false, width:150}
    //    {key:"delete", label:"Delete", className:"delete editableCell", formatter:this.deleteEquipmentFormatter, width:50}
  ]
}

function cancelEditEquipmentsForCoyping(successMsg) {
  var url = document.getElementById('contextPath').value +
            "/servlet/copyEquipments?method=setupSearchForEquipmentsToCopy&projectId="
      + document.getElementById('projectId').value + "&copyFromMaster=" + document.getElementById('copyFromMaster').value;
  if (successMsg) {
    url += "&saveSuccessfulMsg=" + successMsg;
  }
  document.location.href = url;
}

function addToProjectEditEquipmentsForCoyping() {
  removeHiddenFieldsForEditEquipmentsBeforeCopying();
  createHiddenFieldsForEditEquipmentsBeforeCopying();

  var callbackAfterCopyEquipments = {
    success: function(o) {
      this.cache = null;
      var xmlDoc = o.responseXML;
      document.getElementById('addToProjectEditEquipmentsForCoypingBtn').disabled = '';
      var errorStr = "";
      var errors = xmlDoc.selectNodes("//error");
      var errorDiv = document.getElementById('errorMsgsForEditEquipmentBeforeCopyingDiv');

      if (errors.length === 0) {
        var successMsg = xmlDoc.selectSingleNode("//successMsg").text;
        cancelEditEquipmentsForCoyping(successMsg);
      } else {
        for (var i = 0; i < errors.length; i++) {
          var errorHeader = errors[i].selectSingleNode("errorHeader").firstChild.nodeValue;
          errorStr += "<span class='errorMsgHeader'>" + errorHeader + "</span><br/>";
          var errorMsgs = errors[i].selectNodes("errorMsg");
          for (var j = 0; j < errorMsgs.length; j++) {
            var errorMsg = errorMsgs[j].firstChild.nodeValue;
            errorStr += errorMsg + "<br/>";
          }
        }
        errorDiv.style.display = "";
        errorDiv.innerHTML = errorStr;
      }

    },
    failure
        :
        function(o) {
          document.getElementById('addToProjectEditEquipmentsForCoypingBtn').disabled = '';
          document.location.href = document.getElementById('contextPath').value +
                                   "/servlet/logon?method=error";
        }
    ,
    cache:false,
    timeout
        :
        20000 //20 seconds
  }
      ;

  document.getElementById('addToProjectEditEquipmentsForCoypingBtn').disabled = "disabled";
  var equipmentToCopyFrm = document.getElementById("equipmentToCopyFrm");
  YAHOO.util.Connect.setForm(equipmentToCopyFrm);
  this.getXML = YAHOO.util.Connect.asyncRequest("POST",
      document.getElementById('contextPath').value + "/data/copyEquipment/copy?method=copyEquipmentsToProject",
      callbackAfterCopyEquipments);

}

function createHiddenFieldsForEditEquipmentsBeforeCopying() {
  var equipmentToCopyFrm = document.getElementById("equipmentToCopyFrm");
  var dt = editEquipmentsBeforeCopyingTable.getDataTable();
  for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
    var data = dt.getRecordSet().getRecord(i).getData();
    var name = getEmptyStringIfUndefined(data.name);
    var areaId = getEmptyStringIfUndefined(data.areaId);
    var processLineNumber = getEmptyStringIfUndefined(data.processLineNumber);
    var equipmentTagNumber = getEmptyStringIfUndefined(data.equipmentTagNumber);
    equipmentToCopyFrm.appendChild(createHiddenField("equipmentName", name));
    equipmentToCopyFrm.appendChild(createHiddenField("areaId", areaId));
    equipmentToCopyFrm.appendChild(createHiddenField("processLineNumber", processLineNumber));
    equipmentToCopyFrm.appendChild(createHiddenField("equipmentTagNumber", equipmentTagNumber));
  }
}

function removeHiddenFieldsForEditEquipmentsBeforeCopying() {
  var equipmentToCopyFrm = document.getElementById("equipmentToCopyFrm");
  removeHiddenFields(equipmentToCopyFrm, "equipmentName");
  removeHiddenFields(equipmentToCopyFrm, "areaId");
  removeHiddenFields(equipmentToCopyFrm, "processLineNumber");
  removeHiddenFields(equipmentToCopyFrm, "equipmentTagNumber");
}