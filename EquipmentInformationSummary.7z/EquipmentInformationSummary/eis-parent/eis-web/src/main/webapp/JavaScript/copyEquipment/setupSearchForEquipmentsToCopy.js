var searchEquipmentTableForProject = null;

if (typeof YAHOO == "undefined" || !YAHOO) {
    /**
     * The YAHOO global namespace object.  If YAHOO is already defined, the
     * existing YAHOO object will not be overwritten so that defined
     * namespaces are preserved.
     * @class YAHOO
     * @static
     */
    var YAHOO = {};
}

YAHOO.util.Event.addListener(window, "load", function() {
  searchEquipmentsOfProject();
});

function searchEquipmentsOfProject() {
  createEquipmentTableForProject(getUrlForSearchEquipmentsOfProject());
}

function getUrlForSearchEquipmentsOfProject() {
  var copyFromProjectId = document.getElementById('copyFromProjectId').value;
  var equipmentNumber = document.getElementById('searchEquipmentNumberForCopy').value;
  var equipmentType = document.getElementById('searchEquipmentTypeForCopy').value;
  var equipmentArea = document.getElementById('searchEquipmentAreaForCopy').value;
  var equipmentName = document.getElementById('searchEquipmentNameForCopy').value;
  var processLine = document.getElementById('searchProcessLineForCopy').value;
  var vendor = document.getElementById('searchVendorForCopy').value;

  return document.getElementById('contextPath').value + "/data/equipmentSearchXml/search?projectId="
      + copyFromProjectId
      + "&searchEquipmentNumber=" + equipmentNumber
      + "&searchEquipmentType=" + equipmentType
      + "&searchEquipmentName=" + equipmentName
      + "&searchEquipmentArea=" + equipmentArea
      + "&searchProcessLine=" + processLine
      + "&searchVendor=" + vendor;
}

function createEquipmentTableForProject(url) {
  if (searchEquipmentTableForProject == null) {
    this.equipmentListForProjectDataSource = createServerSidePaginationDataSource(url);
    this.equipmentListForProjectDataSource.responseSchema = {
      resultNode: "equipment",
      fields: ["id", "equipmentNumber", "name", "description", "equipmentTypeCode", "equipmentTypeName", "equipmentSubTypeCode", "equipmentSubTypeName", "areaCode", "areaDescription",
        "processLineNumber", "equipmentVendor", "motors", "instruments", "accessories"],
      metaFields: {totalRecords : "totalRecords"}
    };
    searchEquipmentTableForProject = getEquipmentTableForProject(getEquipmentTableForProjectColumnDefs(), this.equipmentListForProjectDataSource);
  } else {
    searchEquipmentTableForProject.requery(url);
  }
}

function getEquipmentTableForProject(columnDefs, dataSource) {
  return createDataTable("equipmentsListForCopy", columnDefs, dataSource, "equipmentNumber",
  {scrollable:true, width:getWidthForDataTable(), emptyMsg:"No Matching Equipments Found"}, {pagination: true, topPaginator:'topPaginatorForEquipmentsForCopy'});
}

function getEquipmentTableForProjectColumnDefs() {
  this.copyFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<input type="button" value="Copy" onclick="copyEquipments(\'' + oRecord.getId() + '\');"/>';
  };

  this.quantityFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<input type="text" maxlength="2" size="2" value="1"/>';
  };

  this.existsFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oData === "true") {
      elCell.innerHTML = '<img border="0" alt="Exists" src="' + document.getElementById('contextPath').value +
                         '/images/check.gif")">';
    }
  }
  this.equipmentTypeFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = oRecord.getData('equipmentTypeCode');
  }
  this.equipmentSubTypeFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = oRecord.getData('equipmentSubTypeCode');
  }

  return [
    {key:"copy", label:"Copy", className:"copy", formatter:this.copyFormatter, sortable:false, resizeable:false, width:60},
    {key:"quantity", label:"Quantity", className:"quantity", formatter:this.quantityFormatter, sortable:false, resizeable:false, width:60},
    {key:"equipmentNumber", label:"Equipment #", className:"equipmentNumber", sortable:true, resizeable:true, width:92},
    {key:"name", label:"Equipment Name", className:"name", sortable:true, resizeable:true,  width:200},
    {key:"description", label:"Description", abbr:"Equipment Description", className:"description", sortable:true, resizeable:true,  width:150},
    {key:"equipmentType", label:"Type", abbr:"Equipment Type", formatter:this.equipmentTypeFormatter, className:"equipmentTypeCode", sortable:true, resizeable:true, width:45},
    {key:"subType", label:"Sub<br/>Type", abbr:"Equipment Sub Type", formatter:this.equipmentSubTypeFormatter, className:"equipmentSubTypeCode", sortable:true, resizeable:true, width:45},
    {key:"equipmentVendor", label:"Vendor", className:"equipmentVendor", sortable:true, resizeable:true,  width:100},
    {key:"motors", label:"Motors<br/>Exist", formatter: this.existsFormatter, className:"motors", sortable:true, resizeable:true, width:60},
    {key:"instruments", label:"Instruments<br/>Exist", formatter: this.existsFormatter, className:"instruments", sortable:true, resizeable:true, width:80},
    {key:"accessories", label:"Accessories<br/>Exist", formatter: this.existsFormatter, className:"accessories", sortable:true, resizeable:true, width:80}
  ]
}

function copyEquipments(recordId) {
  var quantity = '';
  var dt = searchEquipmentTableForProject.getDataTable();
  var quantityTextboxString = dt.getTdEl({record:dt.getRecordSet().getRecord(recordId), column:dt.getColumn("quantity")}).firstChild.firstChild.outerHTML;
  var indexOfValue = quantityTextboxString.indexOf("value=");
  if (indexOfValue >= 0) {
    var valueString = quantityTextboxString.substring(quantityTextboxString.search("value="), quantityTextboxString.search(">"));
    quantity = valueString.substring(valueString.search("=") + 1, valueString.length);
  }

  if (quantity === "") {
    alert('Please enter a quantity');
  } else {
    var projectId = document.getElementById("projectId").value;
    var equipmentIdToCopy = dt.getRecordSet().getRecord(recordId).getData("id");
    document.location.href = document.getElementById("contextPath").value +
                             "/servlet/copyEquipments?method=setupEquipmentsToCopy"
        + "&projectId=" + projectId
        + "&equipmentIdToCopy=" + equipmentIdToCopy
        + "&quantity=" + quantity;
  }
}

function hideCopySuccessfullMsg(){
  document.getElementById('suscessMsgForEditEquipmentBeforeCopyingDiv').style.display = 'none';
}

