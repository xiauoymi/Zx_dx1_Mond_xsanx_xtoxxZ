function addOrRemoveEditableCellClassForInst_new(dt, oEditor, purchasedWithEquipment) {
	oRecord = oEditor._oRecord;
 // var purchasedWithEquipment = oRecord.getData('purchasedWithEquipment');
  if (purchasedWithEquipment === true) {
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("vendor")}), "editableCell");
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("rtpNumber")}), "editableCell");
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("poNumber")}), "editableCell");
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("lineNumber")}), "editableCell");
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("actualDeliveryDate")}), "editableCell");
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("estimatedCost")}), "editableCell");
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("actualCost")}), "editableCell");
  } else {
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("vendor")}), "editableCell");
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("rtpNumber")}), "editableCell");
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("poNumber")}), "editableCell");
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("lineNumber")}), "editableCell");
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("actualDeliveryDate")}), "editableCell");
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("estimatedCost")}), "editableCell");
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("actualCost")}), "editableCell");
  }
}


function formatTagForInstruments(oEditor) {
	   var oRecord = oEditor._oRecord;
       var oColumn = oEditor._oColumn;
       var dt = instrumentsDataTable.getDataTable();
       var oCell = dt.getTrEl(oRecord).cells[3];//cell for tag
       if (oColumn.key === 'designatorFirstCharId' || oColumn.key === 'designatorSecondCharId' ||
       oColumn.key === 'sequenceNumber') {
       oCell.firstChild.innerHTML = createInstrumentNumber(oRecord);
	   }
 }

function formatComponentNumberInMotors(oEditor) {
  var oRecord = oEditor._oRecord;
  var oColumn = oEditor._oColumn;
  var dt = motorsDataTable.getDataTable();
  var oCell = dt.getTrEl(oRecord).cells[2];//cell for component number
  if (oColumn.key === 'componentDesignatorId' || oColumn.key === 'sequenceNumber') {
    oCell.firstChild.innerHTML = createComponentNumber(oRecord);
  }
}

function formatComponentNumberInMotorsList(oEditor) {
  var oRecord = oEditor._oRecord;
  var oColumn = oEditor._oColumn;
  var dt = searchEquipmentsDataTableForMotor.getDataTable();
  var oCell = dt.getTrEl(oRecord).cells[6];//cell for component number
  if (oColumn.key === 'componentDesignatorId' || oColumn.key === 'sequenceNumber') {
    oCell.firstChild.innerHTML = createComponentNumberForMotorsList(oRecord);
  }
}

function formatAccessoryNumberInTable(oEditor) {
  var oRecord = oEditor.record;
  var oColumn = oEditor.column;
  var dt = accessoriesDataTable.getDataTable();
  var oCell = dt.getTrEl(oRecord).cells[3];//cell for accessory number
  if (oColumn.key === 'accessoryDesignatorId' || oColumn.key === 'sequenceNumber') {
    oCell.firstChild.innerHTML = createAccessoryNumber(oRecord);
  }
}

function calculateTotalItemCostForPurchasing(oEditor) {
    var oRecord = oEditor._oRecord;
    var oColumn = oEditor._oColumn;
    var dt = searchEquipmentsDataTableForPurchasing.getDataTable();
    var oCell = dt.getTrEl(oRecord).cells[12];//cell for total item cost
    if (oColumn.key === 'poLineAmount' || oColumn.key === 'coAmount') {
        oCell.firstChild.innerHTML = getTotalItemCostForPurchasing(oRecord);
    }
}

function calcualteOverUnderForCostScheduleTable(oEditor) {
  var oRecord = oEditor._oRecord;
  var oColumn = oEditor._oColumn;
  var oCell = searchEquipmentsDataTableForCostSchedule.getTrEl(oRecord).cells[23];//cell for over/under
  if (oColumn.key === 'estimatedCost') {
    oCell.firstChild.innerHTML = getOverUnderForCostSchedule(oRecord);
  }
}

(function () {

 var loader = new YAHOO.util.YUILoader();
 loader.loadOptional = true;
 loader.filter = "raw";
 loader.insert({
     onSuccess: function() {
         //shortcuts
         var Event = YAHOO.util.Event,
             Dom = YAHOO.util.Dom,
             Lang = YAHOO.lang,
             DT = YAHOO.widget.DataTable;


         DT.prototype.refreshRow = function(row) {
             var self = this;
             Dom.getElementsByClassName(DT.CLASS_LINER,'div',this.getTrEl(row),function(el) {
                 self.formatCell.call(self,el);
             });
         };

         YAHOO.widget.CustomTextBoxEditor = function (oConfigs) {
             this._sId = "yui-regexptextboxceditor" + YAHOO.widget.BaseCellEditor._nCount++;
             oConfigs = oConfigs || {};
             oConfigs.type = 'regexptextbox';
             YAHOO.widget.CustomTextBoxEditor.superclass.constructor.call(this, oConfigs);
         };

         Lang.extend(YAHOO.widget.CustomTextBoxEditor, YAHOO.widget.TextboxCellEditor, {
             regExp: null,
             finalRegExp: null,
             failedRegExpClassName : '',
             formatTag: false,
             allowDecimals:false,
             precision: null,
             wholeNumSize: null,
             render: function () {
                 if (this.regExp && Lang.isString(this.regExp)) { this.regExp = new RegExp(this.regExp); }
                 if (this.finalRegExp && Lang.isString(this.finalRegExp)) { this.finalRegExp = new RegExp(this.finalRegExp); }
                 YAHOO.widget.CustomTextBoxEditor.superclass.render.call(this);
                  if (this.size != undefined || this.size != null)
				 {
					 this.textbox.size = this.size;
				 }

 				 if (this.maxLength != undefined || this.maxLength != null)
				 {
				 this.textbox.maxLength = this.maxLength;
				 }

                 Event.on(this.textbox,'keypress', function(ev) {
                    if (Lang.isNull(this.regExp)) { return; }
                     var textbox = this.textbox;
                     if (YAHOO.env.ua.gecko > 0 && ev.keyCode) {
                         return;
                     }
                     var ch = ev.keyCode || ev.charCode,
                         val = textbox.value,
                         start,
                         end;
                     if (document.selection && document.selection.createRange) {
                         //undocumented IE trick to get the selection box.
                         start = Math.abs(document.selection.createRange().moveStart("character", -1000000));
                         end = Math.abs(document.selection.createRange().moveEnd("character", -1000000));
                     } else {
                         start = textbox.selectionStart;
                         end = textbox.selectionEnd;
                     }
                     val = val.substr(0,start) + String.fromCharCode(ch) + val.substr(end);
                     if (!this.regExp.test(val)) {
                         Event.stopEvent(ev);
                     }
                    if (val.length > this.maxLength)
					 {
						 Event.stopEvent(ev);
					 }
                 },this,true);


//                 Event.on(this.textbox,'keyup',function(ev) {
//                     if (Lang.isNull(this.finalRegExp)) { return; }
//                     if (this.finalRegExp.test(this.textbox.value)) {
//                         Dom.removeClass(this.textbox,this.failedRegExpClassName);
//                     } else {
//                         Dom.addClass(this.textbox,this.failedRegExpClassName);
//                     }
//                 },this,true);

                 Event.on(this.textbox, "focusout", function(v) {
					 if (this.formatTag === true){
						 if (this.table === "instruments"){
							 formatTagForInstruments(this);
						 }
                         if (this.table === "purchasing"){
                             calculateTotalItemCostForPurchasing(this);
                         }
                         if (this.table === "costSchedule"){
                             calcualteOverUnderForCostScheduleTable(this);
                         }
                    }
            }, this, true);
             }

         });
         Lang.augmentObject(YAHOO.widget.CustomTextBoxEditor, YAHOO.widget.TextboxCellEditor);

          YAHOO.widget.CustomDropDownCellEditor = function (oConfigs) {
              this._sId = "yui-cdropdownceditor" + YAHOO.widget.BaseCellEditor._nCount++;
              oConfigs = oConfigs || {};
              oConfigs.type = 'dropdown';
              YAHOO.widget.DropdownCellEditor.superclass.constructor.call(this, "dropdown", oConfigs);
         };

         Lang.extend(YAHOO.widget.CustomDropDownCellEditor, YAHOO.widget.DropdownCellEditor, {
             dropdownOptions : null,
             dropdown : null,
             formatTag: false,
 		     table: null,
             disableBtns: false,
             render: function () {
                 YAHOO.widget.CustomDropDownCellEditor.superclass.render.call(this);

                 Event.on(this.dropdown, "focusout", function(v) {
					 if (this.formatTag === true){
                         if (this.table === "motors"){
                             formatComponentNumberInMotors(this);
                         }
                         if (this.table === "motorsList"){
                             formatComponentNumberInMotorsList(this);
                         }
                         if (this.table === "instruments"){
                             formatTagForInstruments(this);
                         }
                         if(this.table === "accessories"){
                             formatAccessoryNumberInTable(this);
                         }
                    }
            }, this, true);
             }
         });
         Lang.augmentObject(YAHOO.widget.CustomDropDownCellEditor, YAHOO.widget.DropdownCellEditor);

         YAHOO.widget.CustomCheckboxCellEditor = function (oConfigs) {
             oConfigs = oConfigs || {};
             oConfigs.type = "customCheckbox";
              this._sId = "yui-ccheckboxceditor" + YAHOO.widget.BaseCellEditor._nCount++;
               YAHOO.widget.CheckboxCellEditor.superclass.constructor.call(this, "checkbox", oConfigs);

         };

         Lang.extend(YAHOO.widget.CustomCheckboxCellEditor, YAHOO.widget.CheckboxCellEditor, {
             purchasedWithEquipCheck: false,
             table: null,
             disableBtns: false,
             render: function () {
		 YAHOO.widget.CustomCheckboxCellEditor.superclass.render.call(this);
                 Event.on(this.getContainerEl(),'click', function(oArgs) {
				 if(Event.getTarget(oArgs).tagName.toLowerCase() === "input") {
		            // Save on blur
				    this.save();
				 }

                  if (this.purchasedWithEquipCheck === true){
                        addOrRemoveEditableCellClassForInst_new(instrumentsDataTable.getDataTable(), this, this.checkboxes[0].checked);
                  }

                 }, this, true);
             }
         });
         Lang.augmentObject(YAHOO.widget.CustomCheckboxCellEditor, YAHOO.widget.CheckboxCellEditor);

         YAHOO.widget.CustomTextareaCellEditor = function (oConfigs) {
             oConfigs = oConfigs || {};
             oConfigs.type = "customTextarea";
              this._sId = "yui-ctextareaceditor" + YAHOO.widget.BaseCellEditor._nCount++;
               YAHOO.widget.TextareaCellEditor.superclass.constructor.call(this, "textarea", oConfigs);

         };

         Lang.extend(YAHOO.widget.CustomTextareaCellEditor, YAHOO.widget.TextareaCellEditor, {
              disableBtns: false,
              maxLength: null,
             render: function () {
		        YAHOO.widget.CustomTextareaCellEditor.superclass.render.call(this);
                  if (this.size != undefined || this.size != null){
					 this.textarea.size = this.size;
				 }
 				 if (this.maxLength != undefined || this.maxLength != null){
				    this.textarea.maxLength = this.maxLength;
				 }else{
                      this.textarea.maxLength = 2000;
                  }

                 this.textarea.style.height = "100px";

                   Event.on(this.textarea,'keypress', function(ev) {
                     var textarea = this.textarea;
                     if (YAHOO.env.ua.gecko > 0 && ev.keyCode) {
                         return;
                     }
                     var ch = ev.keyCode || ev.charCode,
                         val = textarea.value,
                         start,
                         end;
                     if (document.selection && document.selection.createRange) {
                         //undocumented IE trick to get the selection box.
                         start = Math.abs(document.selection.createRange().moveStart("character", -1000000));
                         end = Math.abs(document.selection.createRange().moveEnd("character", -1000000));
                     } else {
                         start = textarea.selectionStart;
                         end = textarea.selectionEnd;
                     }
                     val = val.substr(0,start) + String.fromCharCode(ch) + val.substr(end);
                     if (val.length > this.maxLength)
					 {
						 Event.stopEvent(ev);
					 }
                 },this,true);
             }
         });
         Lang.augmentObject(YAHOO.widget.CustomTextareaCellEditor, YAHOO.widget.TextareaCellEditor);
     }
 });

 })();


function sendNewRequest(state, dataTable) {
  var request = buildQueryString(state, dataTable);
  dataTable.getDataSource().sendRequest(request, {
    success: dataTable.onDataReturnInitializeTable,
    failure: dataTable.onDataReturnInitializeTable,
    scope: dataTable,
    argument:state
  });
}
function goToNextRowsFirstEditableCell(eisDataTable, rowIndex, totalRows, firstEditableColumnIndex) {
  var dataTable = eisDataTable.getDataTable();
  if (totalRows - rowIndex === 1) {//at last row
    var newRecord = eisDataTable.getEditableTableParams().newRecord;
    if (newRecord) {// add a new row
      addNewRowToDataTable(eisDataTable);
      dataTable.fireEvent("cellClickEvent",
      {target:dataTable.getLastTrEl().cells[0], event:event});
    } else {
      dataTable.cancelCellEditor();
    }
  } else {//otherwise go to next row's first editable column
    dataTable.fireEvent("cellClickEvent", {target:dataTable.getTrEl(rowIndex + 1).cells[firstEditableColumnIndex]});
  }
}

function isCellEditable(elCell) {
  return YAHOO.util.Dom.hasClass(elCell, "yui-dt-editable");
}

function getNextEditableCellInThisRow(dataTable, oRecord, oColumn, lastEditableColumnIndex) {
  for (var i = oColumn.getIndex() + 1; i <= lastEditableColumnIndex; i++) {
    var nextCell = dataTable.getTrEl(oRecord).cells[i];
    if (isCellEditable(nextCell)) {
      return nextCell;
    }
  }
  return null;
}


function addCustomEditorOptionsForTextbox(editorOptions, element) {
  if (editorOptions.size) {
    element.size = editorOptions.size;
  }
  if (editorOptions.maxLength) {
    element.maxLength = editorOptions.maxLength;
  }
  if (editorOptions.blockNumbers === true) {
    YAHOO.util.Event.addListener(element, "keypress", function(v) {
      return onKeyPressBlockNumbers();
    });
    YAHOO.util.Event.addListener(element, "paste", function(v) {
      return onPasteBlockNumbers();
    });
  }
  if (editorOptions.allowDecimals === true) {
    YAHOO.util.Event.addListener(element, "keypress", function(v) {
      return onKeyPressAllowDecimals(element, editorOptions.wholeNumSize, editorOptions.precision);
    });
    YAHOO.util.Event.addListener(element, "paste", function(v) {
      return onPasteAllowDecimals(editorOptions.wholeNumSize, editorOptions.precision);
    });
  }
  if (editorOptions.blockAlphabets === true) {
    YAHOO.util.Event.addListener(element, "keypress", function(v) {
      return onKeyPressBlockAlphabets();
    });
  }
}

//initialLoad = false;
YAHOO.widget.DataTable.prototype.requery = function(url) {
  this.getMsgTbodyEl().style.display = "";
  this.getTbodyEl().style.display = "none";
  var state = this.getState();
  state.pagination.recordOffset = 0;
  if (url !== null || url !== undefined) {
    this.getDataSource().liveData = url;
  }
  sendNewRequest(state, this);
};

//YAHOO.widget.DataTable.prototype.requeryAfterAdding = function(url) {
//  debugger;
//  this.getMsgTbodyEl().style.display = "";
//  this.getTbodyEl().style.display = "none";
//  var state = this.getState();
//  var newTotalRecords = state.pagination.totalRecords + 1;
//  var rowsPerPage = state.pagination.rowsPerPage;
//  var newTotalPages = Math.ceil(newTotalRecords / rowsPerPage);
//
//  var lastPagesRecordOffset = (newTotalPages - 1) * rowsPerPage;
//  state.pagination.recordOffset = lastPagesRecordOffset;
//  if (url !== null || url !== undefined) {
//    this.getDataSource().liveData = url;
//  }
//  sendNewRequest(state, this);
//};


YAHOO.widget.DataTable.prototype.onEditorBlurEvent = function(oArgs) {
  if (oArgs.editor.isActive && oArgs.editor instanceof YAHOO.widget.DateCellEditor) {
    // Save on blur only when editor is not a calendar
    if (oArgs.editor.disableBtns) {
      if (oArgs.editor.cancel) { // Backward incompatible
        // Cancel on blur
        oArgs.editor.cancel();
        this._oCellEditor = null;
      }
    } else {
      if (oArgs.editor.save) { // Backward incompatible
        oArgs.editor.save();
      }
    }

  }
  else
    if (oArgs.editor.cancel) { // Backward incompatible
      // Cancel on blur
      oArgs.editor.cancel();
    }
};

YAHOO.widget.DateCellEditor.prototype.renderForm = function() {
  // Calendar widget
  if (YAHOO.widget.Calendar) {
    var calContainer = this.getContainerEl().appendChild(document.createElement("div"));
    calContainer.id = this.getId() + "-dateContainer"; // Needed for Calendar constructor
      var navConfig = {
              strings : {
                  month: "Choose Month",
                  year: "Enter Year",
                  submit: "OK",
                  cancel: "Cancel",
                  invalidYear: "Please enter a valid year"
              },
              monthFormat: YAHOO.widget.Calendar.SHORT,
              initialFocus: "year"
        };

    var calendar =
        new YAHOO.widget.CalendarGroup(this.getId() + "-date",
            calContainer.id, {navigator: navConfig});
    calendar.render();
    calContainer.style.cssFloat = "none";

//    if (YAHOO.env.ua.ie) {
    //      var calFloatClearer = this.getContainerEl().appendChild(document.createElement("br"));
    //      calFloatClearer.style.clear = "both";
    //    }
    this.calendar = calendar;
      this.calendar.navigator = navConfig;

    if (this.disableBtns) {
      this.handleDisabledBtns();
    }
  }
  else {
  }
};

YAHOO.widget.DateCellEditor.prototype.resetForm = function() {
  //  dont want the dedault date.
  try {
    var value = this.value;
    var selectedValue = (value.getMonth() + 1) + "/" + value.getDate() + "/" + value.getFullYear();
    this.calendar.cfg.setProperty("selected", selectedValue, false);
    this.calendar.render();
  } catch(e) {
  }
};

function getWidthForDataTable(parentElementName) {
  if (parentElementName) {
    var parentElement = document.getElementById(parentElementName);
    return Math.ceil((parentElement.clientWidth) * .96) + 'px';
  } else {
    return Math.ceil((document.body.clientWidth) * .92) + 'px';
  }
}

function onChangeSaveDataEvent(eisDataTable, newData) {
  var dataTable = eisDataTable.getDataTable();
  var oldData = dataTable._oCellEditor.record.getData(dataTable._oCellEditor.column.key);
  dataTable._oCellEditor.value = newData;
  dataTable.updateCell(dataTable._oCellEditor.record, dataTable._oCellEditor.column, newData);
//  dataTable.getRecordSet().updateRecordValue(dataTable._oCellEditor.record, dataTable._oCellEditor.column.key, newData);
//  dataTable.formatCell(dataTable._oCellEditor.cell.firstChild, dataTable._oCellEditor.record, dataTable._oCellEditor.column);
  dataTable.fireEvent("editorSaveEvent",
  {record:dataTable._oCellEditor.record, column:dataTable._oCellEditor.column});
}

function onEditorsKeydownEvent(eisDataTable, oRecord, oColumn, keyCode) {
  var dataTable = eisDataTable.getDataTable();
  var lastEditableColumnIndex = eisDataTable.getEditableTableParams().lastEditableColumnIndex;
  var firstEditableColumnIndex = eisDataTable.getEditableTableParams().firstEditableColumnIndex;
  var rowIndex = dataTable.getTrEl(oRecord).sectionRowIndex;
  var totalRows = dataTable.getRecordSet().getLength();
  if (keyCode === 9) {//tab
    if (oColumn.getIndex() === lastEditableColumnIndex) {//at last editable column
      goToNextRowsFirstEditableCell(eisDataTable, rowIndex, totalRows, firstEditableColumnIndex);
    } else {
      //go to the next editable column
      var nextCell = getNextEditableCellInThisRow(dataTable, oRecord, oColumn, lastEditableColumnIndex);
      if (nextCell === null) {
        goToNextRowsFirstEditableCell(eisDataTable, rowIndex, totalRows, firstEditableColumnIndex);
      } else {
        dataTable.fireEvent("cellClickEvent", {target:nextCell});
      }
    }
  }
  if (keyCode === 13) {//enter
    goToNextRowsFirstEditableCell(eisDataTable, rowIndex, totalRows, firstEditableColumnIndex);
  }
}



function addNewRowToDataTable(eisDataTable) {
  var dt = eisDataTable.getDataTable();
  var params = eisDataTable.getEditableTableParams();
  params.hasDataTableBeenModified = true;
  var newRecord = params.newRecord;
  dt.addRow(newRecord);
}

function okToDelete() {
  return confirm('You are attempting to delete information. Please select "OK" to continue or "Cancel" to end this attempt.');
}

function onRowDeleteOfEditableTable(eisDataTable, oRecord) {
  var params = eisDataTable.getEditableTableParams();
  if (params !== null && params.deletedIds !== null) {
    var id = oRecord.getData(params.keyForDeletedId);
    params.deletedIds[params.deletedIds.length] = id;
  }
}

function onCellClickEventOfEditableTable(eisDataTable, oArgs) {
  var target = oArgs.target;
  var dataTable = eisDataTable.getDataTable();
  var editableTableParams = eisDataTable.getEditableTableParams();
  var column = dataTable.getColumn(target);
  if (column.key === 'delete') {
    if (okToDelete()) {
      editableTableParams.hasDataTableBeenModified = true;
      var rowId = dataTable.getRow(target).sectionRowIndex;
      var oRecord = dataTable.getRecord(rowId);
      dataTable.deleteRow(rowId);
      onRowDeleteOfEditableTable(eisDataTable, oRecord);
    }
  } else {
    if (column.editor !== null) {
      dataTable.onEventShowCellEditor(oArgs);
    }
  }
}

var commentsFormatter = function(elCell, oRecord, oColumn, oData) {
  if (oData && oData.length > 80) {
    elCell.innerHTML = oData.substring(0, 50) + '...';
  } else {
    elCell.innerHTML = oData;
  }
};

var dateFormatter = function(elCell, oRecord, oColumn, oData) {
  if (oData !== null && oData !== '') {
    return YAHOO.widget.DataTable.formatDate.call(this, elCell, oRecord, oColumn, oData);
  }
};

function populateArrayForDropdown(xmlDoc, tagName, idNodeName, nameNode) {
var array = new Array();
    var j = 0;
    if (tagName !== 'designStatuses/designStatus' || tagName !== 'fundingSources/source' || tagName !== 'fundingSources/fundingSource'){
     array = [{value:"", label:"Select"}];
     j++;
    }
  var elements = xmlDoc.selectNodes('//refData/' + tagName);
  for (var i = 0; i < elements.length; i++) {
    var valueStr = elements[i].selectSingleNode(idNodeName).firstChild.nodeValue;
    var textStr = elements[i].selectSingleNode(nameNode).firstChild.nodeValue;
    array[j++] = {value:valueStr, label:textStr};
  }
  return array;
}

function addCustomEditorOptionsForTextarea(editorOptions, element) {
  if (editorOptions.maxLength) {
    element.maxLength = editorOptions.maxLength;
  }
  if (!editorOptions.blockNumbers && !editorOptions.allowDecimals && !editorOptions.blockAlphabets) {
    YAHOO.util.Event.addListener(element, "keypress", function(v) {
      return onKeyPressCheckMaxLength(element);
    });
    YAHOO.util.Event.addListener(element, "paste", function(v) {
      return onPasteCheckMaxLength(element);
    });
  } else {
    if (editorOptions.blockNumbers === true) {
      YAHOO.util.Event.addListener(element, "keypress", function(v) {
        return onKeyPressBlockNumbers() && onKeyPressCheckMaxLength(element);
      });
      YAHOO.util.Event.addListener(element, "paste", function(v) {
        return onPasteBlockNumbers() && onPasteCheckMaxLength(element);
      });
    }
    if (editorOptions.allowDecimals === true) {
      YAHOO.util.Event.addListener(element, "keypress", function(v) {
        return onKeyPressAllowDecimals(element, editorOptions.size, editorOptions.precision) &&
               onKeyPressCheckMaxLength(element);
      });
      YAHOO.util.Event.addListener(element, "paste", function(v) {
        return onPasteAllowDecimals(editorOptions.size, editorOptions.precision) && onPasteCheckMaxLength(element);
      });
    }
    if (editorOptions.blockAlphabets === true) {
      YAHOO.util.Event.addListener(element, "keypress", function(v) {
        return onKeyPressBlockAlphabets() && onKeyPressCheckMaxLength(element);
      });
    }
  }
}
var dropDownFormatter = function(el, oRecord, oColumn, oData) {
  el.innerHTML = "&nbsp;"; //necessary for sorting to work properly
  var selectedValue = (YAHOO.lang.isValue(oData)) ? oData :
                      oRecord.getData(oColumn.key);
  var options = (YAHOO.lang.isArray(oColumn.editorOptions.dropdownOptions)) ?
                oColumn.editorOptions.dropdownOptions : null;
  for (var i = 0; i < options.length && options !== null; i++) {
    if (options[i].value === selectedValue) {
      if (selectedValue.length > 0) {
        el.innerHTML = options[i].label;
      }
      break;
    }
  }
};

var dropdownEditor = function (oEditor, eisDataTable, customOnfocusoutFnc) {
  var oSelf = eisDataTable.getDataTable();
  var oRecord = oEditor.record;
  var oColumn = oEditor.column;
  var elContainer = oEditor.container;

  var value = oRecord.getData(oColumn.key);
  var elDropdown = elContainer.appendChild(document.createElement("select"));
  var dropdownOptions = (oColumn.editorOptions && YAHOO.lang.isArray(oColumn.editorOptions.dropdownOptions)) ?
                        oColumn.editorOptions.dropdownOptions : [];
  for (var j = 0; j < dropdownOptions.length; j++) {
    var dropdownOption = dropdownOptions[j];
    var elOption = document.createElement("option");
    elOption.value = (YAHOO.lang.isValue(dropdownOption.value)) ? dropdownOption.value : dropdownOption;
    elOption.innerHTML = (YAHOO.lang.isValue(dropdownOption.label)) ? dropdownOption.label : dropdownOption;
    elOption = elDropdown.appendChild(elOption);
    if (value === elDropdown.options[j].value) {
      elDropdown.options[j].selected = true;
    }
  }
  YAHOO.util.Event.addListener(elDropdown, "keydown", function(v) {
    onChangeSaveDataEvent(eisDataTable, elDropdown[elDropdown.selectedIndex].value);
    onEditorsKeydownEvent(eisDataTable, oRecord, oColumn, v.keyCode);
  });

  YAHOO.util.Event.addListener(elDropdown, "focusout", function(v) {
    onChangeSaveDataEvent(eisDataTable, elDropdown[elDropdown.selectedIndex].value);
    if (customOnfocusoutFnc) {
      customOnfocusoutFnc(oEditor);
    }
  });
  oSelf._focusEl(elDropdown);
};
var textboxEditor = function (oEditor, eisDataTable, customOnfocusoutFnc) {
  var oSelf = eisDataTable.getDataTable();
  var oRecord = oEditor.record;
  var oColumn = oEditor.column;
  var elContainer = oEditor.container;
  var value = oRecord.getData(oColumn.key);

  var elTextbox = elContainer.appendChild(document.createElement("input"));
  elTextbox.type = "text";
  elTextbox.value = value;

  addCustomEditorOptionsForTextbox(oEditor.column.editorOptions, elTextbox);

  YAHOO.util.Event.addListener(elTextbox, "keydown", function(v) {
    onEditorsKeydownEvent(eisDataTable, oRecord, oColumn, v.keyCode);
  });

  YAHOO.util.Event.addListener(elTextbox, "focusout", function(v) {
    onChangeSaveDataEvent(eisDataTable, elTextbox.value);
    if (customOnfocusoutFnc) {
      customOnfocusoutFnc(oEditor);
    }
  });
  elTextbox.focus();
  elTextbox.select();
};

var textAreaEditor = function (oEditor, eisDataTable) {
  var oSelf = eisDataTable.getDataTable();
  var oRecord = oEditor.record;
  var oColumn = oEditor.column;
  var elContainer = oEditor.container;
  var value = oRecord.getData(oColumn.key);
  if(value === undefined){
    value = "";
  }

  var elTextArea = elContainer.appendChild(document.createElement("textarea"));
  elTextArea.style.height = "100px";
  elTextArea.value = value;
  elTextArea.maxLength = 2000;

  addCustomEditorOptionsForTextarea(oEditor.column.editorOptions, elTextArea);

  YAHOO.util.Event.addListener(elTextArea, "keydown", function(v) {
    onEditorsKeydownEvent(eisDataTable, oRecord, oColumn, v.keyCode);
  });

  YAHOO.util.Event.addListener(elTextArea, "focusout", function(v) {
    onChangeSaveDataEvent(eisDataTable, elTextArea.value);
  });
  elTextArea.focus();
  elTextArea.select();
};



function handleEditableCheckboxClick(checkbox, eisDataTable, recordId, key) {
  //update recordset with new value of checkbox
  var dt = eisDataTable.getDataTable();
  var record = dt.getRecordSet().getRecord(recordId);
  record.setData(key, checkbox.checked + '');
}

