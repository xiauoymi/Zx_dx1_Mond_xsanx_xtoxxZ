var monthAbbr = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");

YAHOO.widget.Tab.prototype.ACTIVE_TITLE = '';

function onKeyPressBlockNumbers() {
    var e = event;
    var key = window.event ? e.keyCode : e.which;
    var keychar = String.fromCharCode(key);
    var reg = /\d/;
    return !reg.test(keychar);
}

function onPasteBlockNumbers() {
    var newString = window.clipboardData.getData("Text");
    var reg = /\d/;
    return !reg.test(newString);
}

function onKeyPressBlockAlphabets() {
    var e = event;
    var key = window.event ? e.keyCode : e.which;
    var keychar = String.fromCharCode(key);
    var reg = /\d/;
    return reg.test(keychar);
}

function onPasteBlockAlphabets() {
    var newString = window.clipboardData.getData("Text");
    var reg = /\d/;
    return reg.test(newString);
}

function onKeyPressAllowDecimals(element, integer, precision) {
    if (integer && precision) {
        integer = parseInt(integer);
        precision = parseInt(precision);
        var e = event;
        var key = window.event ? e.keyCode : e.which;
        var keychar = String.fromCharCode(key);
        var regDecimalStr = '^(?=.*[0-9]*$)' + '\\d{0,' + integer + '}(?:\\.\\d{0,' + precision + '})?$';
        var regDecimal = new RegExp(regDecimalStr);
        return regDecimal.test(element.value + keychar);
    } else {
        return false;
    }
}

function onPasteAllowDecimals(integer, precision) {
    if (integer && precision) {
        integer = parseInt(integer);
        precision = parseInt(precision);
        var newString = window.clipboardData.getData("Text");
        var regDecimalStr = '^(?=.*[0-9]*$)' + '\\d{0,' + integer + '}(?:\\.\\d{0,' + precision + '})?$';
        var regDecimal = new RegExp(regDecimalStr);
        return regDecimal.test(newString);
    } else {
        return false;
    }
}

function onPasteCheckMaxLength(element) {
    var newString = window.clipboardData.getData("Text");

    if (getTotalLength(newString, element.value) > getMaxLength(element)) {
        element.value = getCombinedText(element.value,newString).substring(0, getMaxLength(element));
        return false;
    } else {
        return true;
    }
}

function getCombinedText(s1,s2){
    return s1 + s2;
}
function getTotalLength(s1, s2) {
    return s1.length + s2.length;
}

function onKeyPressCheckMaxLength(element) {
    return element.value.length < getMaxLength(element);
}


function fillSelectDropdown(xmlDoc, selectElement, tagName, idNodeName, nameNode) {
    var elements = xmlDoc.selectNodes('//' + tagName);
    for (var i = 0; i < elements.length; i++) {
        var optionId = elements[i].selectSingleNode(idNodeName).firstChild.nodeValue;
        var projectStatusName = elements[i].selectSingleNode(nameNode).firstChild.nodeValue;
        var docoption = document.createElement("OPTION");
        docoption.text = projectStatusName;
        docoption.value = optionId;
        selectElement.options.add(docoption);
    }
}

function removeAllOptions(selectbox) {
    var i;
    for (i = selectbox.options.length - 1; i >= 0; i--) {
        selectbox.remove(i);
    }
}

function setSelectedInDropdown(dropdownElement, valueToSelect) {
    if (valueToSelect != "") {
        for (var i = 0; i < dropdownElement.length; i++) {
            if (dropdownElement.options[i].value === valueToSelect) {
                dropdownElement.options[i].selected = true;
                break;
            }
        }
    }
}

function getValueOfSelectedIdForDropdown(dropdownElement, valueToSelect) {
    if (valueToSelect != "") {
        for (var i = 0; i < dropdownElement.length; i++) {
            if (dropdownElement.options[i].value === valueToSelect) {
                return dropdownElement.options[i].text;
            }
        }
    }
    return "";
}

String.prototype.trim = function () {
    return this.replace(/^\s+|\s+$/g, "");
}

function isTrimmedToBlank(str) {
    return (str == null || str.trim().length == 0);
}

function searchProjectsOnEnter(e) {
    var characterCode = e.keyCode
    var searchProjects = document.getElementById('Search');
    if (characterCode == 13) {
        searchProjects.click();
        return false;
    }
    else {
        return true;
    }
}

function setFocus() {
    var firstElement = false;
    for (f = 0; f < document.forms.length; f++) {
        for (i = 0; i < document.forms[f].length; i++) {
            if (document.forms[f][i].type != "hidden") {
                var isDisabled = document.forms[f][i].disabled;
                var elementType = document.forms[f][i].type;
                if (!isDisabled && elementType == "text") {
                    document.forms[f][i].focus();
                    var firstElement = true;
                }
            }
            if (firstElement)
                break;
        }
        if (firstElement)
            break;
    }
}

function resetFormIfIdIsNull(form, idElementName) {
    var id = document.getElementById(idElementName).value;
    if (id === "") {
        form.reset();
    }
}

function getQueryStringForActiveTabIndex() {
    return "&activeTabIndex=" + document.getElementById("activeTabIndex").value;
}

function getActiveTabIndex() {
    var activeIndex = document.getElementById("activeTabIndex").value;
    if (activeIndex === "") {
        activeIndex = 0;
        setActiveTabIndexInHiddenField(activeIndex);
    }
    return activeIndex;
}

function setActiveTabIndexInHiddenField(activeIndex) {
    document.getElementById("activeTabIndex").value = activeIndex;
}

function getActiveTabIndexFromHiddenField() {
    return document.getElementById("activeTabIndex").value;
}

function getWidthForDialog() {
    return (document.body.clientWidth * 0.98);
}

function getHeightForDialog() {
    return (document.body.clientHeight * 0.98);
}

function getXForDialog() {
    return (document.body.clientWidth * 0.02);
}

function getYForDialog() {
    return (document.body.clientHeight * 0.02);
}

function sizeAndShowMask(maskId) {
    var Dom = YAHOO.util.Dom;
    Dom.addClass(document.body, "masked");
    // Shrink mask first, so it doesn't affect the document size.
    var mask = document.getElementById(maskId),
        viewWidth = Dom.getViewportWidth(),
        viewHeight = Dom.getViewportHeight();

    if (mask.offsetHeight > viewHeight) {
        mask.style.height = viewHeight + "px";
    }

    if (mask.offsetWidth > viewWidth) {
        mask.style.width = viewWidth + "px";
    }
    // Then size it to the document
    mask.style.height = Dom.getDocumentHeight() + "px";
    mask.style.width = Dom.getDocumentWidth() + "px";

    mask.style.display = "block";
}

function removeMask(maskId) {
    document.getElementById(maskId).style.display = "none";
    YAHOO.util.Dom.removeClass(document.body, "masked");
}

function createHiddenField(name, value) {
    var input = document.createElement("<input>");
    input.type = "hidden";
    input.id = name;
    input.name = name;
    input.value = value;
    return input;
}

function removeHiddenFields(frm, name) {
    var hiddenElements = document.getElementsByName(name);
    var numHiddenElements = hiddenElements.length;
    for (var i = numHiddenElements - 1; i >= 0; i--) {
        frm.removeChild(hiddenElements[i]);
    }
}

function getEmptyStringIfUndefined(str) {
    if (str == null || str == undefined) {
        return "";
    } else {
        return str;
    }
}

function createCalendar(textInputId, containerId) {
    var calendarMenuId = "calMenu-" + containerId;
    var calendarMenuBodyId = "calMenuBody-" + containerId;
    var calendarId = "cal-" + containerId;
    var buttonId = "btn-" + containerId;
    var oCalendarMenu = new YAHOO.widget.Overlay(calendarMenuId, { visible: false });
    var oCalButton = new YAHOO.widget.Button({
        type: "menu",
        className: "calender-button",
        id: buttonId,
        //label: "Choose A Date",
        label: "",
        menu: oCalendarMenu,
        container: containerId });

    oCalButton.on("appendTo", function () {
        oCalendarMenu.setBody(" ");
        oCalendarMenu.body.id = calendarMenuBodyId;
        oCalendarMenu.render(this.get("container"));
    });

    var oCalButtonClick = function () {
        var oCalendar = new YAHOO.widget.CalendarGroup(calendarId, oCalendarMenu.body.id);
        oCalendar.render();
        oCalendar.changePageEvent.subscribe(function () {
            window.setTimeout(function () {
                oCalendarMenu.show();
            }, 0);
        });

        oCalendar.selectEvent.subscribe(function (p_sType, p_aArgs) {
            var aDate;
            if (p_aArgs) {
                var period = document.getElementById(textInputId);
                var selDate = oCalendar.getSelectedDates()[0];
                var dStr = getDoubleDigitsForDate(selDate.getDate());
                var monthShort = oCalendar.cfg.getProperty("MONTHS_SHORT")[selDate.getMonth()];
                //var monthShort = getDoubleDigitsForDate(selDate.getMonth() + 1);
                var yStr = selDate.getFullYear();

//        period.value = monthShort + "-" + dStr + "-" + yStr; //month + day + year;
                period.value = monthShort + " " + dStr + ", " + yStr; //month + day + year;
            }
            oCalendarMenu.hide();
        });
        this.unsubscribe("click", oCalButtonClick);
    }
    oCalButton.on("click", oCalButtonClick);
}


function getDoubleDigitsForDate(value) {
    if (value.toString().length == 1) {
        return '0' + value;
    }
    return value;
}

function formatDateForSaving(oDate) {
    if (oDate instanceof Date) {
        //    return getDoubleDigitsForDate((oDate.getMonth() + 1)) + "" + getDoubleDigitsForDate(oDate.getDate()) + "" +
        //           oDate.getFullYear();//11052008
        var month = monthAbbr[oDate.getMonth()];
        var date = oDate.getDate();
        var year = oDate.getFullYear();
        return month + " " + date + ", " + year;//Nov 05, 2008
    } else {
        return oDate;
    }

}

function formatDateForDisplay(dateStr) {
    if (dateStr == null) {
        return "";
    } else {
        //    var month = monthAbbr[dateStr.substring(0, 2) - 1];
        //    var date = dateStr.substring(2, 4);
        //    var year = dateStr.substring(4, 8);
        //    return month + "-" + date + "-" + year;//Nov-05-2008
        return dateStr;
    }
}

function getDateFormatForCellEditor() {
    //return '%m%d%Y';
    return "%b %d, %Y";//Nov-05-2008
}

function getClassNameForEditableCell(isEditable) {
    if (isEditable || userHasEditAccessToThisProject()) {
        return "editableCell";
    }
    return "";
}

function userHasEditAccessToThisProject() {
    return (document.getElementById('userHasEditAccessToThisProject').value === "true") || isUserProcessTeamLead();
}

function isUserProcessTeamLead() {
    return document.getElementById('isUserProcessTeamLead').value === "true";
}

function hideCalendarIfReadOnlyAccess(calendarId) {
    var calendarSpan = document.getElementById(calendarId);
    if (calendarSpan != null) {
        if (!userHasEditAccessToThisProject()) {
            document.getElementById(calendarId).style.display = "none";
        }
    }
}

function updateTextField(id, value) {
    var element = document.getElementById(id);
    element.value = value;
    if (!userHasEditAccessToThisProject()) {
        element.style.display = "none";
        var span = getSpan(element, element.parentElement);
        span.innerHTML = value;
    }
}

function updateSelectField(id, value) {
    var element = document.getElementById(id);
    if (!userHasEditAccessToThisProject()) {
        element.style.display = "none";
        element.style.visibility = "hidden";
        var span = getSpan(element, element.parentElement);
        span.innerHTML = getValueOfSelectedIdForDropdown(element, value);
    } else if (userHasEditAccessToThisProject()) {
        setSelectedInDropdown(element, value);
    }
}

function updateCheckbox(id, value) {
    var element = document.getElementById(id);
    if (userHasEditAccessToThisProject()) {
        element.checked = (value === "true") || (value != null && value.toLowerCase() === "on");
    } else {
        element.style.display = "none";
        if (value === "true") {
            var span = getSpan(element, element.parentElement);
            var contextPath = document.getElementById('contextPath').value;
            span.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
        }
    }
}

function updateRadioButton(id, value) {
    var element = document.getElementsByName(id);
    if (userHasEditAccessToThisProject()) {
        for (var i = 0; i < element.length; i++) {
            if (value === "true") {
                if (element[i].value === "Y") {
                    element[i].checked = true;
                    break;
                }
            } else {
                if (element[i].value === "N") {
                    element[i].checked = true;
                    break;
                }
            }
        }
    } else {
        for (var i = 0; i < element.length; i++) {
            element[i].parentElement.style.display = "none";
        }
        var span = getSpan(element[0].parentElement, element[0].parentElement.parentElement);
        span.innerHTML = getTextValueForRadioButton(id, value);
    }
}

function getTextValueForRadioButton(id, value) {
    var element = document.getElementsByName(id);
    for (var i = 0; i < element.length; i++) {
        if (value === "true") {
            if (element[i].value === "Y") {
                return element[i].value;
            }
        } else {
            if (element[i].value === "N") {
                return element[i].value;
            }
        }
    }
    return "";
}


function getSpan(element, parentElement) {
    var span = getSpanIfPresent(parentElement);
    if (span === null) {
        span = document.createElement("span");
        span.name = "placeholder";
        span.innerHTML = ' ';
        span = parentElement.insertBefore(span, element);
    }
    return span;
}

function getSpanIfPresent(parentElement) {
    var childNodes = parentElement.childNodes;
    var length = childNodes == null ? 0 : childNodes.length;
    for (var i = 0; i < length; i++) {
        var node = childNodes[i];
        if (node.tagName != null && node.tagName.toUpperCase() === "SPAN") {
            if (node.name === "placeholder") {
                return node;
            }
        }
    }
    return null;
}

function hideOrShowSucessAndErrorMessageDiv(hide, successElement, errorElement, successStr, errorStr) {
    var display = "";
    if (hide) {
        display = "none";
        setDisplayAttributeForElement(successElement, display);
        setDisplayAttributeForElement(errorElement, display);
    } else {
        if (successStr != undefined && successStr != "") {
            setDisplayAttributeForElement(successElement, display);
        }
        if (errorStr != undefined && errorStr != "") {
            setDisplayAttributeForElement(errorElement, display);
        }
    }
}

function setDisplayAttributeForElement(element, display) {
    if (element != "" || element != null) {
        document.getElementById(element).style.display = display;
    }
}

function checkXMLReturnedFromAjaxCall(o, functionCallAfterSuccess, equipmentId) {
    if (o.responseText == '' || o.responseText == null) {
        document.location.href = document.getElementById('contextPath').value +
            "/servlet/logon?method=error";
    } else {
        functionCallAfterSuccess(o, equipmentId);
    }
}

function scrollToTop() {
    window.scrollTo(0, 0);
//  document.getElementById("TTS").focus();
    return true;
}

function setDefaultOption(element, defaultText) {
    removeAllOptions(element);
    var docOption = document.createElement("OPTION");
    docOption.text = defaultText;
    docOption.value = "";
    element.options.add(docOption);
}