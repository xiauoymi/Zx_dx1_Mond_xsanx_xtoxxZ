var activeEditor = null;
function EISDataTable(dt, customConfig) {
    this.dt = dt;
    this.customConfig = customConfig;
}

EISDataTable.prototype.getDataTable = function() {
    return this.dt;
}

EISDataTable.prototype.getEditableTableParams = function() {
    if (this.customConfig && this.customConfig.editableTableParams) {
        return this.customConfig.editableTableParams;
    }
    return null;
}

EISDataTable.prototype.getAutosaveParams = function() {
    if (this.customConfig && this.customConfig.autosaveParams) {
        return this.customConfig.autosaveParams;
    }
    return null;
}

EISDataTable.prototype.requery = function(url) {
    this.dt.requery((url));
}

EISDataTable.prototype.showSaveWarning = function() {
    if (this.customConfig && this.customConfig.editableTableParams &&
        this.customConfig.editableTableParams.showSaveWarning) {
        return this.customConfig.editableTableParams.showSaveWarning;
    }
    return false;
}

EISDataTable.prototype.hasDataTableBeenModified = function() {
    if (this.customConfig && this.customConfig.editableTableParams &&
        this.customConfig.editableTableParams.hasDataTableBeenModified) {
        return this.customConfig.editableTableParams.hasDataTableBeenModified;
    }
    return false;
}


function buildQueryString(state, dt) {
    var startIndex = 0;
    var rowsPerPage = 0;
    if (state.pagination != null) {
        startIndex = state.pagination.recordOffset;
        rowsPerPage = state.pagination.rowsPerPage;
    }
    //  var currentSortColumn = state.sorting.key;
    //    var currentSortOrder = ((state.sorting.dir === YAHOO.widget.DataTable.CLASS_DESC) ? "desc" : "asc");

    //  var oSortedByValues = document.getElementById("sortedBy").value;
    //  var dirByValues = document.getElementById("sortDir").value;
    var oSortedByValues = state.sortedBy.key;
    var dirByValues = ((state.sortedBy.dir === YAHOO.widget.DataTable.CLASS_DESC) ? "desc" : "asc");

    return "&startIndex=" + startIndex + "&rowsPerPage=" + rowsPerPage +
           "&sort=" + oSortedByValues + "&dir=" + dirByValues;
}

function createPaginator(paginatorConfig) {
    var imageDir = document.getElementById('contextPath').value + '/images/';
    var rowsPerPage = paginatorConfig.rowsPerPage ? paginatorConfig.rowsPerPage : 25;

    var paginator = new YAHOO.widget.Paginator({
        containers: getContainerConfig(paginatorConfig),
        alwaysVisible: true, // todo enabled for now to get the record count
        rowsPerPage: rowsPerPage, //todo let this be selected later
        rowsPerPageOptions: [rowsPerPage],
        pageLinks: 5,
        template : "<span class='currPageReport'>{CurrentPageReport}</span> <span class='pageLinks'>{FirstPageLink} {PreviousPageLink} {PageLinks} {NextPageLink} {LastPageLink}</span>",
        //        <span class='recordsPerPageControl>Results Per Page: {RowsPerPageDropdown}</span>
        pageReportTemplate : "Items <strong>{startRecord}</strong> - <strong>{endRecord}</strong> of <strong>{totalRecords}</strong>",
        firstPageLinkLabel : "<img style='vertical-align:middle;' alt='Go to first page' src='" + imageDir +
                             "page_first.gif'></img>",
        previousPageLinkLabel : "<img alt='Go to previous page' style='vertical-align:middle;' src='" + imageDir +
                                "page_prev.gif'></img>",
        nextPageLinkLabel : "<img alt='Go to next page' style='vertical-align:middle;' src='" + imageDir +
                            "page_next.gif'></img>",
        lastPageLinkLabel : "<img alt='Go to last page' style='vertical-align:middle;' src='" + imageDir +
                            "page_last.gif'></img>"
    });

    //  paginator.subscribe("pageChange", function (oArgs) {
    //    debugger;
    //    addRow();
    //  });

    //  paginator.subscribe('changeRequest', function(oArgs) {
    //    debugger;
    //    // Update the Paginator's state
    //    paginator.setState(oArgs.paginator.getState());
    //  });
    return paginator;
}

function getServerSidePaginationConfiguration(initialSort, config, paginatorConfig) {
    var rowsPerPage = paginatorConfig.rowsPerPage ? paginatorConfig.rowsPerPage : 25;
    var dtConfig = {
        initialRequest: '&startIndex=0&rowsPerPage=' + rowsPerPage + '&sort=' + initialSort + '&dir=asc',
        generateRequest: buildQueryString,
        dynamicData : true,
        selectionMode:"cellblock",
        sortedBy: {key:initialSort, dir:YAHOO.widget.DataTable.CLASS_ASC}
    };
    if (paginatorConfig) {
        if (paginatorConfig.pagination === true) {
            dtConfig.paginator = createPaginator(paginatorConfig);
        }
    }
    if (config) {
        if (config.initialLoad === false) {
            dtConfig.initialLoad = false;
        }
        if (config.scrollable === true) {
            dtConfig.scrollable = true;
        }
        if (config.height) {
            dtConfig.height = config.height;
        }
        if (config.width) {
            dtConfig.width = config.width;
        }
        if (config.draggableColumns === true) {
            dtConfig.draggableColumns = true;
        }
        if (config.editableTableParams) {
            dtConfig.editableTableParams = config.editableTableParams;
        }
        if (config.emptyMsg) {
            dtConfig.MSG_EMPTY = config.emptyMsg;
        }
    }
    return dtConfig;
}

function createServerSidePaginationDataSource(url) {
    var dataSource = new YAHOO.util.XHRDataSource(url);
    dataSource.responseType = YAHOO.util.DataSource.TYPE_XML;
    //  dataSource.subscribe("responseParseEvent", function(oArgs) {
    //    debugger;
    //    var thisNewRecords = getNewRecords();
    //    for(var i = 0; i < thisNewRecords.length; i++){
    //      oArgs.response.results[oArgs.response.results.length] = thisNewRecords[i];
    //      //update the paginator for totalrecords, may be use render
    //    }
    //    return true;
    //  });
    dataSource.parseXMLResult = function(result) {
        return customParseXmlResult(this, result);
    };

    dataSource.subscribe("dataErrorEvent", function(oArgs) {
    });
    return dataSource;
}

function createDataTable(id, columnDefs, dataSource, initialSort, config, paginatorConfig, customConfig) {
    //  YAHOO.widget.DataTable._bStylesheetFallback = !!YAHOO.env.ua.ie;

    YAHOO.widget.DataTable._bDynStylesFallback = true;

    var dataTable = new YAHOO.widget.DataTable(id, columnDefs, dataSource, getServerSidePaginationConfiguration(initialSort, config, paginatorConfig));
    var eisDataTable = new EISDataTable(dataTable, customConfig);
    if (dataTable instanceof YAHOO.widget.ScrollingDataTable) {//to avoid unwanted vertical scroll bars
        YAHOO.util.Dom.setStyle(dataTable.getBdContainerEl(), 'overflow-y', 'hidden')
    }
    dataTable.doBeforeSortColumn = function(oColumn, sSortDir) {
        var showSaveWarning = eisDataTable.showSaveWarning();
        var hasDataTableBeenModified = eisDataTable.hasDataTableBeenModified();
        if (showSaveWarning === true && hasDataTableBeenModified === true) {
            alert("A Sort or Pagination request prior to a Save will cause the loss of changes");
            return false;
        } else {
            dataTable.set("sortedBy", {key:oColumn.key, dir:sSortDir, column:oColumn});
            dataTable.getMsgTbodyEl().style.display = "";
            dataTable.getTbodyEl().style.display = "none";
            return true;
        }
    }

    dataTable.doBeforePaginatorChange = function(oPaginatorState) {
        var showSaveWarning = eisDataTable.showSaveWarning();
        var hasDataTableBeenModified = eisDataTable.hasDataTableBeenModified();
        if (showSaveWarning === true && hasDataTableBeenModified === true) {
            alert('A Sort or Pagination request prior to a Save will cause the loss of changes');
            return false;
        } else {
            dataTable.getMsgTbodyEl().style.display = "";
            dataTable.getTbodyEl().style.display = "none";
            return true;
        }
    }

    dataTable.handleDataReturnPayload = function(oRequest, oResponse, oPayload) {
        oPayload.totalRecords = parseInt(oResponse.meta.totalRecords, 10);
        return oPayload;
    }

    document.getElementById("sortedBy").value = initialSort;
    document.getElementById("sortDir").value = "asc";
    dataTable.sortedBy = {key:initialSort, dir:YAHOO.widget.DataTable.CLASS_ASC};

//    var highlightEditableCell = function(oArgs) {
//        var elCell = oArgs.target;
//        if (YAHOO.util.Dom.hasClass(elCell, "yui-dt-editable")) {
//            this.highlightCell(elCell);
//        }
//    };
//    dataTable.subscribe("cellMouseoverEvent", highlightEditableCell);
//    dataTable.subscribe("cellMouseoutEvent", dataTable.onEventUnhighlightCell);
//    //  dataTable.subscribe("cellClickEvent", dataTable.onEventSelectCell);
//    dataTable.subscribe("cellSelectEvent", dataTable.clearTextSelection);
//
//    var tt = new YAHOO.widget.Tooltip("myTooltip");
//    dataTable.on('theadCellMouseoverEvent', function (oArgs) {
//        var target = oArgs.target;
//        var column = this.getColumn(target);
//        var abbr = column.abbr;
//        if (abbr != null) {
//            var xy = [parseInt(oArgs.event.clientX, 10) + 10 ,parseInt(oArgs.event.clientY, 10) + 10 ];
//            tt.setBody(abbr);
//            tt.cfg.setProperty('xy', xy);
//            tt.cfg.setProperty('zIndex', 999999);
//            tt.show();
//        }
//    });
//    dataTable.on('theadCellMouseoutEvent', function (oArgs) {
//        tt.hide();
//    });


    return eisDataTable;
}

function createEditableDataTable(id, columnDefs, dataSource, initialSort, config, paginatorConfig,
                                 customConfig) {

    YAHOO.widget.DataTable._bDynStylesFallback = true;

    var eisDataTable = createDataTable(id, columnDefs, dataSource, initialSort, config, paginatorConfig, customConfig);
    var dataTable = eisDataTable.getDataTable();
    var autosaveParams = eisDataTable.getAutosaveParams();
    var editableTableParams = eisDataTable.getEditableTableParams();
    if (autosaveParams != null) {
        dataTable.subscribe('checkboxClickEvent', function(oArgs) {
            var oRecord = this.getRecord(oArgs.target);
            var oColumn = this.getColumn(oArgs.target);
            dataTable.fireEvent("editorSaveEvent", {record:oRecord, column:oColumn});
        });

        dataTable.subscribe('editorSaveEvent', function(oArgs) {
            var oRecord = oArgs.record;
            var oColumn = oArgs.column;
            if (oRecord === undefined) {//For Yahoo's BaseCellEditor
                oRecord = oArgs.editor.getRecord();
                oColumn = oArgs.editor.getColumn();
            }
            var oKey = oColumn.key;
            var queryStr = getQueryStringForAutosave(eisDataTable, oRecord, oKey);
            autosaveValue(this, queryStr);
        });
    }
    if (editableTableParams != null) {

        dataTable.subscribe('checkboxClickEvent', function(oArgs) {
            eisDataTable.getEditableTableParams().hasDataTableBeenModified = true;
        });

        dataTable.subscribe('editorSaveEvent', function(oArgs) {
            eisDataTable.getEditableTableParams().hasDataTableBeenModified = true;
        });

        dataTable.subscribe("tbodyKeyEvent", function(oArgs) {
            var evt = oArgs.event;
            if (evt.ctrlKey && evt.keyCode == 67) { // CTRL + C
                eisDataTable.getEditableTableParams().copyFromCell = this.getLastSelectedCell();
            } else if (evt.ctrlKey && evt.keyCode == 86) { // CTRL + V
                var copyFromCell = eisDataTable.getEditableTableParams().copyFromCell;
                if (copyFromCell != null) {
                    var copyFromColumn = this.getColumn(copyFromCell);
                    var copyFromCellDataType = getDataType(copyFromColumn);

                    var record = this.getRecord(copyFromCell.recordId);
                    var dataToCopy = record.getData(copyFromCell.columnKey);
                    var copyToCells = this.getSelectedCells();
                    for (var i = 0; i < copyToCells.length; i++) {
                        var recordIdColumnId = copyToCells[i];
                        record = this.getRecord(recordIdColumnId.recordId);
                        var oColumn = this.getColumn(recordIdColumnId.columnKey);
                        var thisCellsDataType = getDataType(oColumn);

                        if (((copyFromCellDataType === "dropdown") && (copyFromColumn.key === oColumn.key)) ||
                            ((copyFromCellDataType != "dropdown") && (copyFromCellDataType === thisCellsDataType))) {
                            var dataToPaste = getDataToPaste(oColumn, dataToCopy);
                            //              this.getRecordSet().updateRecordValue(record, recordIdColumnId.columnKey, dataToPaste);
                            //              var rowIndex = this.getTrEl(record).sectionRowIndex;
                            this.updateCell(record, recordIdColumnId.columnKey, dataToPaste);
                            //              this.updateRow(this.getTrEl(rowIndex), record.getData());

                            eisDataTable.getEditableTableParams().hasDataTableBeenModified = true;
                            if (autosaveParams != null) {
                                var queryStr = getQueryStringForAutosave(eisDataTable, record, recordIdColumnId.columnKey, dataToPaste);
                                autosaveValue(this, queryStr);
                            }
                        }

                    }
                    this.unselectAllCells();
                }
            }
        });
        dataTable.subscribe('renderEvent', function() {
            dataTable.getBdContainerEl().scrollLeft = dataTable.getHdContainerEl().scrollLeft;
        });

        dataTable.doBeforeShowCellEditor = function(oCellEditor) {
            activeEditor = oCellEditor;
            repositionEditorToBeWithinTheViewport(dataTable, oCellEditor);
            return true;
        }

        dataTable.subscribe("editorBlurEvent", function(oArgs) {
            this.cancelCellEditor();
        });

        dataTable.subscribe("cellClickEvent", function (oArgs) {
            var evt = oArgs.event;
            if (evt && evt.ctrlKey) {
                if (this.isSelected(oArgs.target)) {
                    this.unselectCell(oArgs.target);
                } else {
                    this.selectCell(oArgs.target);
                }
            } else {
                onCellClickEventOfEditableTable(eisDataTable, oArgs);
            }
        });
    }

    dataTable.subscribe("editorKeydownEvent", function(oArgs) {

        var self = this,
                editor = this._oCellEditor === null ? activeEditor : this._oCellEditor,
                event = oArgs.event,
                KEY = YAHOO.util.KeyListener.KEY,
                cell = editor.cell !== undefined ? editor.cell : editor.getTdEl(),
                col = editor.column !== undefined ? editor.column : editor.getColumn(),
                row,record,

                editNextCell = function(cell) {
                        if (self.configs.element !== null && self.configs.element === "equipmentsListForProcess") {
                            var parentTableLastEditableColumn = searchEquipmentsDataTableForProcess.customConfig.editableTableParams.lastEditableColumnIndex;
                            if (cell.cellIndex >= parentTableLastEditableColumn - 1) {
                                return true;
                            }
                        }

                    cell = self.getNextTdEl(cell);

                    while (cell && !self.getColumn(cell).editor) {
                        cell = self.getNextTdEl(cell);
                    }
                    if (cell) {
                        if (YAHOO.util.Dom.hasClass(cell, "editableCell")) {
                            self.showCellEditor(cell);
                        }
                    }
                },
                editPreviousCell = function(cell) {
                        if (self.configs.element !== null && self.configs.element === "equipmentsListForProcess") {
                            var parentTableFirstEditableIndex = searchEquipmentsDataTableForProcess.customConfig.editableTableParams.firstEditableColumnIndex;
                            if (cell.cellIndex == parentTableFirstEditableIndex) {
                                return true;
                            }
                        }
                    cell = self.getPreviousTdEl(cell);
                    while (cell && !self.getColumn(cell).editor) {
                        cell = self.getPreviousTdEl(cell);
                    }
                    if (cell) {
                        if (YAHOO.util.Dom.hasClass(cell, "editableCell")) {
                            self.showCellEditor(cell);
                        }
                    }
                };

        //based on the key pressed, show the appropriate cell.
        switch (event.keyCode) {
            case KEY.UP:
                YAHOO.util.Event.stopEvent(event);
                editor.save();
                row = this.getPreviousTrEl(cell);
                if (row) {
                    record = this.getRecord(row);
                    this.showCellEditor({record:record,column:col});
                }
                break;
            case KEY.DOWN:
                YAHOO.util.Event.stopEvent(event);
                editor.save();
                row = this.getNextTrEl(cell);
                if (row) {
                    record = this.getRecord(row);
                    this.showCellEditor({record:record,column:col});
                }
                break;
            case KEY.LEFT:
                YAHOO.util.Event.stopEvent(event);
                editor.save();
                editPreviousCell(cell);
                break;
            case KEY.RIGHT:
                YAHOO.util.Event.stopEvent(event);
                editor.save();
                editNextCell(cell);
                break;
            case KEY.TAB:

                YAHOO.util.Event.stopEvent(event);
                editor.save();
                if (event.shiftKey) {
                    editPreviousCell(cell);
                } else {
                    editNextCell(cell);
                }
                break;
            case KEY.ENTER:
                //for some reason it is not working for textarea.
                if (editor instanceof YAHOO.widget.TextareaCellEditor) {
                    return;
                }
                YAHOO.util.Event.stopEvent(event);
                editor.save();
                row = this.getNextTrEl(cell);
                if (row) {
                    record = this.getRecord(row);
                    this.showCellEditor({record:record,column:col});

                }
        }
    });

    dataTable.on('editorShowEvent', function (oArgs) {
        var Dom = YAHOO.util.Dom;
        var el = oArgs.editor.getContainerEl();
        var reg = Dom.getRegion(el);
        var topScreen = Dom.getDocumentScrollTop(),
                bottomScreen = topScreen + Dom.getViewportHeight();
        if (reg.top < topScreen) {
            el.scrollIntoView();
        }
        if (reg.bottom > bottomScreen) {
            el.scrollIntoView(false);
        }
        dataTable._oEditor = this._oCellEditor;
    });
    return eisDataTable;
}

function getDataType(oColumn) {
    if (oColumn.editorOptions === undefined) {
        return "date";
    } else if (oColumn.editorOptions.dropdownOptions) {
        return "dropdown";
    } else if (oColumn.editorOptions.blockAlphabets === true) {
        return "numeric";
    } else
        return "alphanumeric";
}

function getDataToPaste(oColumn, cellData) {
    return oColumn.editorOptions === undefined ? cellData :
           cellData.substring(0, oColumn.editorOptions.maxLength);
}

function repositionEditorToBeWithinTheViewport(dataTable, oCellEditor) {
    if (dataTable.getAttributeConfig('width').value) {
        //to make sure all the editors stay in the viewport
        var editorContainer = oCellEditor.container ? oCellEditor.container : oCellEditor.getContainerEl();//custom editor vs Yahoo's editor
        var editorCell = oCellEditor.cell ? oCellEditor.cell : oCellEditor.getTdEl();
        var tBodyWithPlusOffsetLeft = dataTable.getBdContainerEl().offsetWidth +
                                      YAHOO.util.Dom.getX(dataTable.getBdContainerEl());
        if (editorContainer.style.posLeft >= tBodyWithPlusOffsetLeft) {
            var diff = editorContainer.style.posLeft - tBodyWithPlusOffsetLeft;
            editorContainer.style.posLeft = tBodyWithPlusOffsetLeft - editorCell.offsetWidth;
            dataTable.getBdContainerEl().scrollLeft = dataTable.getBdContainerEl().scrollLeft + diff +
                                                      editorCell.offsetWidth;
        } else {
            if (dataTable.getBdContainerEl().scrollLeft > editorCell.offsetLeft) {
                editorContainer.style.posLeft = editorContainer.style.posLeft +
                                                dataTable.getBdContainerEl().scrollLeft;
                dataTable.getBdContainerEl().scrollLeft = 0;
            }
        }
    }
}

function getIndexIfColumnHasAlreadyBeenSortedBy(sortedByArray, sortedBy) {
    for (var i = 0; i < sortedByArray.length; i++) {
        if (sortedByArray[i] == sortedBy) {
            return i;
        }
    }
    return null;
}

function getContainerConfig(paginatorLinksConfig) {
    if (paginatorLinksConfig != null && paginatorLinksConfig != undefined) {
        var containersConfig = new Array();
        var topPaginator = document.getElementById(paginatorLinksConfig.topPaginator);
        if (topPaginator != null) {
            containersConfig[containersConfig.length] = paginatorLinksConfig.topPaginator;
        }
        if (containersConfig.length == 0) {
            return null;
        }
        return containersConfig;
    }
    return null;
}

function formatThead(dataTable, sortKey) {
    var oSortedByValues = document.getElementById("sortedBy").value;
    var dirByValues = document.getElementById("sortDir").value;

    var sortDirArray = dirByValues.split(",");
    var sortedByArray = oSortedByValues.split(",");

    var columns = dataTable.getColumnSet().getDefinitions();
    for (var i = 0; i < columns.length; i++) {
        var colKey = columns[i].key;
        var column = dataTable.getColumnSet().getColumn(i);

        var th = dataTable.getThEl(column);
        var labelValue = column.label;
        var index = getIndexIfColumnHasAlreadyBeenSortedBy(sortedByArray, colKey);
        if (index != null) {
            var sortD = sortDirArray[index];
            column.label = labelValue.substring(0, labelValue.indexOf("</b>") + 4);
            column.label = column.label + "    " + "<span class='sortSequence'>" + (index + 1) + "</span>";
            var classN = (sortD === "asc") ? "yui-dt-asc" : "yui-dt-desc";
            YAHOO.util.Dom.addClass(th, classN);
        } else {
            column.label = labelValue.substring(0, labelValue.indexOf("</b>") + 4);
            YAHOO.util.Dom.removeClass(th, "yui-dt-asc");
            YAHOO.util.Dom.removeClass(th, "yui-dt-desc");
        }

        dataTable.formatCell(dataTable.getThEl(column));
        YAHOO.widget.DataTable.formatTheadCell(dataTable.getThLinerEl(column).firstChild, column, dataTable);
    }
}

//need to do this coz xmlNode.item(0).firstChild can be null
function customParseXmlResult(ds, result) {
    var oResult = {},
            schema = ds.responseSchema,
            lang = YAHOO.lang;
    try {
        // Loop through each data field in each result using the schema
        for (var m = schema.fields.length - 1; m >= 0; m--) {
            var field = schema.fields[m];
            var key = (lang.isValue(field.key)) ? field.key : field;
            var data = null;
            // Values may be held in an attribute...
            var xmlAttr = result.attributes.getNamedItem(key);
            if (xmlAttr) {
                data = xmlAttr.value;
            }
            // ...or in a node
            else {
                var xmlNode = result.getElementsByTagName(key);
                if (xmlNode && xmlNode.item(0)) {
                    data = xmlNode.item(0).firstChild ? xmlNode.item(0).firstChild.nodeValue : null;
                    var item = xmlNode.item(0);
                    // For IE, then DOM...
                    data = (item.text) ? item.text : (item.textContent) ? item.textContent : null;
                    // ...then fallback, but check for multiple child nodes
                    if (!data) {
                        var datapieces = [];
                        for (var j = 0, len = item.childNodes.length; j < len; j++) {
                            if (item.childNodes[j].nodeValue) {
                                datapieces[datapieces.length] = item.childNodes[j].nodeValue;
                            }
                        }
                        if (datapieces.length > 0) {
                            data = datapieces.join("");
                        }
                    }
                }
            }
            // Safety net
            if (data === null) {
                data = "";
            }
            // Backward compatibility
            if (!field.parser && field.converter) {
                field.parser = field.converter;
            }
            var parser = (typeof field.parser === 'function') ?
                         field.parser :
                         YAHOO.util.DataSourceBase.Parser[field.parser + ''];
            if (parser) {
                data = parser.call(this, data);
            }
            // Safety measure
            if (data === undefined) {
                data = null;
            }
            oResult[key] = data;
        }
    }
    catch(e) {
    }

    return oResult;
}
