var accessoriesDataTable = null;
var inputArr = null;
var outputArr = null;
var measurementArr = null;
var acceDesignatorArray = null;
var autoManualArr = null;

var acceDesignatorIdToTypeCodeMap = {
  set : function(foo, bar) {
    this[foo] = bar;
  },
  get : function(foo) {
    return this[foo];
  }
}

function getRefDataForAccessoryTable(equipmentId) {
  this.populateArrays = {
    success: function(o) {
      checkXMLReturnedFromAjaxCall(o, populateAccessoryRelatedReferenceData, equipmentId);
    },
    failure: function(o) {
      document.location.href = document.getElementById('contextPath').value +
                               "/servlet/logon?method=error";
    },
    timeout: 30000 //30 seconds
  };

  var url = document.getElementById('contextPath').value +
            "/data/equipmentRefDataXml/details?method=lookupRefDataForAccessoryXML";
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url,
      this.populateArrays);
}

function populateAccessoryRelatedReferenceData(o, equipmentId) {
  var xmlDoc = o.responseXML;
  inputArr = populateArrayForDropdown(xmlDoc, 'inputs/electricalInput', 'id', 'input');
  outputArr = populateArrayForDropdown(xmlDoc, 'outputs/electricalOutput', 'id', 'output');
  measurementArr = populateArrayForDropdown(xmlDoc, 'otherMeasurements/otherMeasurement', 'id', 'measurement');
  acceDesignatorArray = populateArrayForDropdown(xmlDoc, 'accessoryDesignators/accessoryDesignator', 'id', 'name');
  autoManualArr = populateArrayForDropdown(xmlDoc, 'autoManuals/autoManual', 'id', 'name');
  for (var i = 0; i < acceDesignatorArray.length; i++) {
    var acceDesignatorArrayId = acceDesignatorArray[i].value;
    var typeCodeDesc = acceDesignatorArray[i].label;
    var typeCode = parseTypeCodeForAcce(typeCodeDesc);
    acceDesignatorIdToTypeCodeMap.set(acceDesignatorArrayId, typeCode);
  }
  createAccessoryTable(equipmentId);
}

function parseTypeCodeForAcce(designatorValue) {
  var indexOfHyphen = designatorValue.indexOf(" - ");
  return designatorValue.substring(0, indexOfHyphen);
}

function getColumnDefsForAccessory() {
  var fieldArr = [];
  fieldArr[fieldArr.length] = "acceId";
  fieldArr[fieldArr.length] = "accessoryDesignatorId";
  fieldArr[fieldArr.length] = "accessoryDesignatorTypeCode";
  fieldArr[fieldArr.length] = "sequenceNumber";
  fieldArr[fieldArr.length] = "accessoryNumber";
  fieldArr[fieldArr.length] = "accessoryName";
  fieldArr[fieldArr.length] = "quantity";
  fieldArr[fieldArr.length] = "purchasedWithEquipment";
  fieldArr[fieldArr.length] = "acceDescription";
  fieldArr[fieldArr.length] = "comments";
  fieldArr[fieldArr.length] = "compAirReqd";
  fieldArr[fieldArr.length] = "gasReqd";
  fieldArr[fieldArr.length] = "waterReqd";
  fieldArr[fieldArr.length] = "utilityFlowrate";
  fieldArr[fieldArr.length] = "selfCleaning";
  fieldArr[fieldArr.length] = "size";
  fieldArr[fieldArr.length] = "autoManualId";

  fieldArr[fieldArr.length] = "electId";
  fieldArr[fieldArr.length] = "proofOfPositionReq";
  fieldArr[fieldArr.length] = "solenoidReq";
  fieldArr[fieldArr.length] = "localPushButtonReq";
  fieldArr[fieldArr.length] = "inputId";
  fieldArr[fieldArr.length] = "input";
  fieldArr[fieldArr.length] = "inputQty";
  fieldArr[fieldArr.length] = "outputId";
  fieldArr[fieldArr.length] = "output";
  fieldArr[fieldArr.length] = "outputQty";
  fieldArr[fieldArr.length] = "hmiDisplay";
  fieldArr[fieldArr.length] = "otherMeasurementId";
  fieldArr[fieldArr.length] = "measurement";
  fieldArr[fieldArr.length] = "communications";
  fieldArr[fieldArr.length] = "voltage";
  fieldArr[fieldArr.length] = "bidPackage";

  fieldArr[fieldArr.length] = "purchaseId";
  fieldArr[fieldArr.length] = "vendor";
  fieldArr[fieldArr.length] = "rtpNumber";
  fieldArr[fieldArr.length] = "poNumber";
  fieldArr[fieldArr.length] = "lineNumber";
    fieldArr[fieldArr.length] = "actualDeliveryDate";
    fieldArr[fieldArr.length] = "estimatedCost";
    fieldArr[fieldArr.length] = "actualCost";
  return fieldArr;
}

function createAccessoryTable(equipmentId) {
  var url = "/eis/data/accessoryXml/details?equipmentId=" + equipmentId;
  if (accessoriesDataTable === null) {
    this.accessoriesDataSource = createServerSidePaginationDataSource(url);
    this.accessoriesDataSource.responseSchema = {
      resultNode : "accessory",
      fields: getColumnDefsForAccessory(),
      metaFields: {totalRecords : "totalRecords"}
    };
    accessoriesDataTable = getAccessoriesTable(getAccessoriesColumnDefs(), this.accessoriesDataSource);
  } else {
    setAccessoriesDataTableBeenModified(false);
    accessoriesDataTable.getEditableTableParams().deletedIds = [];
    accessoriesDataTable.requery(url);
  }
}

function formatAccessoryNumber(oEditor) {
  var oRecord = oEditor.record;
  var oColumn = oEditor.column;
  var dt = accessoriesDataTable.getDataTable();
  var oCell = dt.getTrEl(oRecord).cells[3];//cell for accessory number
  if (oColumn.key === 'accessoryDesignatorId' || oColumn.key === 'sequenceNumber') {
    oCell.firstChild.innerHTML = createAccessoryNumber(oRecord);
  }
}

function getAccessoriesColumnDefs() {
  this.accessoryNumberFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = createAccessoryNumber(oRecord);
  }

  this.accessoryCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (userHasEditAccessToThisProject()) {
      if (oData === "true") {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, accessoriesDataTable, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox" checked="true"/>';
      } else {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, accessoriesDataTable, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox"/>';
      }
    } else {
      if (oData === "true") {
        var contextPath = document.getElementById('contextPath').value;
        el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
      }
    }
  }


  this.deleteAccessoryFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }

  this.textboxEditorForAccessory = function (oEditor, oSelf) {
    textboxEditor(oEditor, accessoriesDataTable);
  }


  this.textboxEditorForQtyInAccessory = function (oEditor, oSelf) {
    textboxEditor(oEditor, accessoriesDataTable);
    var oRecord = oEditor.record;
    var oColumn = oRecord.column;
    oRecord.setData(oColumn.key, '1');
  }
  this.textAreaEditorForAccessory = function (oEditor, oSelf) {
    textAreaEditor(oEditor, accessoriesDataTable);
  }
  this.dropdownEditorForAccessory = function (oEditor, oSelf) {
    dropdownEditor(oEditor, accessoriesDataTable);
  }

  this.textboxEditorForAccessoryToFormatComponentNum = function (oEditor, oSelf) {
    textboxEditor(oEditor, accessoriesDataTable, formatAccessoryNumber);
  }
  this.dropdownEditorForAccessoryToFormatComponentNum = function (oEditor, oSelf) {
    dropdownEditor(oEditor, accessoriesDataTable, formatAccessoryNumber);
  }
  var className = getClassNameForEditableCell();

  return  [
    {key:"accessoryName", label:"Accessory<br/>Name", className:className, editor:new YAHOO.widget.TextboxCellEditor({disableBtns:true, maxLength: 50, size: 30}), editorOptions:{disableBtns:true, maxLength:50, size:30}, sortable:true, resizeable:true, width:100},
    {key:"accessoryDesignatorId", label:"Des<span class='required'>*</span>", abbr:"Designator", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:acceDesignatorArray}), editorOptions:{disableBtns:true, dropdownOptions:acceDesignatorArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:100},
    {key:"sequenceNumber", label:"Seq#<span class='required'>*</span>", abbr:"Sequence #", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 2, size: 2, regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$',formatTag: true, table:"accessories"}), editorOptions:{disableBtns:true, blockAlphabets:true, size:2, maxLength:2}, sortable:true, resizeable:true, width:50},
    {key:"accessoryNumber", label:"Accessory #", formatter: this.accessoryNumberFormatter, resizeable:true, width:80},
    {key:"quantity", label:"Qty", abbr:"Accessory Quantity", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 2, size: 2, regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$',formatTag: true, table:"accessories"}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:100},
    {key:"acceDescription", label:"Description", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength:200}), editorOptions:{disableBtns:true, maxLength:200}, formatter:commentsFormatter, sortable:true, resizeable:true, width:100},
    {key:"comments", label:"Comments", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength:200}), editorOptions:{disableBtns:true, maxLength:200}, formatter:commentsFormatter, sortable:true, resizeable:true, width:100},
    {key:"compAirReqd", label:"Air", abbr:"Compressed Air Required", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50},
    {key:"gasReqd", label:"Gas", abbr:"Gas Required", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50},
    {key:"waterReqd", label:"Water", abbr:"Water Required", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50},
    {key:"utilityFlowrate", label:"Utility<br/>Flowrate", className:className, editor:new YAHOO.widget.TextboxCellEditor({disableBtns:true, maxLength:50, size:30}), editorOptions:{disableBtns:true, maxLength:50, size:30}, sortable:true, resizeable:true, width:100},
    {key:"selfCleaning", label:"Self Cln", abbr:"Self Cleaning", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50},
    {key:"size", label:"Size", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 2, size: 2, regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$',formatTag: true, table:"accessories"}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:50},
    {key:"autoManualId", label:"Auto/Man", abbr:"Auto/Manual", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:autoManualArr}), editorOptions:{disableBtns:true, dropdownOptions:autoManualArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:80},

    {key:"proofOfPositionReq", label:"P of P", abbr:"Proof of Position Required", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50},
    {key:"solenoidReq", label:"Solenoid", abbr:"Solenoid Required",className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:60},
    {key:"localPushButtonReq", label:"Push<br/>Btns", abbr:"Local Pushbuttons Required", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50},
    {key:"inputId", label:"In", abbr:"Inputs", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:inputArr}), editorOptions:{disableBtns:true, dropdownOptions:inputArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:50},
    {key:"inputQty", label:"In<br/>Qty", abbr:"Input Quantity", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 2, size: 2, regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:50},
    {key:"outputId", label:"Output", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:outputArr}), editorOptions:{disableBtns:true, dropdownOptions:outputArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:50},
    {key:"outputQty", label:"Output<br/>Qty", abbr:"Output Quantity", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 2, size: 2, regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:50},
    {key:"hmiDisplay", label:"HMI<br/>Display", className:className, editor:new YAHOO.widget.TextboxCellEditor({disableBtns:true}), editorOptions:{disableBtns:true}, sortable:true, resizeable:true, width:100},
    {key:"otherMeasurementId", label:"Other<br/>Measurement", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:measurementArr}), editorOptions:{disableBtns:true, dropdownOptions:measurementArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:100},
    {key:"communications", label:"Communications", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:30, size:30}), editorOptions:{disableBtns:true, maxLength:30, size:30}, sortable:true, resizeable:true, width:100},
    {key:"voltage", label:"Supply<br/>Voltage", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 3, size: 3, regExp:/^\d{0,3}$/,finalRegExp:'^\\d{2}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:50},
    {key:"bidPackage", label:"Bid<br/>Package", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 250, size: 90}), editorOptions:{disableBtns:true, blockAlphabets:false, maxLength:250, size:90}, sortable:true, resizeable:true, width:80},

    {key:"purchasedWithEquipment", label:"P w/E", abbr:"Purchased With Equipment", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50},
    {key:"vendor", label:"Vendor", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 20, size: 20}), editorOptions:{disableBtns:true, maxLength:20, size:20}, sortable:true, resizeable:true, width:100},
    {key:"rtpNumber", label:"RTP Number", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 8, size: 8}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:8, size:8}, sortable:true, resizeable:true, width:100},
    {key:"poNumber", label:"PO Number", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,8}$/,finalRegExp:'^\\d{8}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:10, size:10}, sortable:true, resizeable:true, width:100},
    {key:"lineNumber", label:"Line Item", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:60},
    {key:"actualDeliveryDate", label:"Delivery<br/>Date", formatter:dateEditableCellFormatterForInstAndAcce, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100},
      {key:"estimatedCost", label:"Estimated<br/>Cost", formatter:currencyFormatterInstAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,5}$/,finalRegExp:'^\\d{5}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:5, size:5}, sortable:true, resizeable:true, width:80},
      {key:"actualCost", label:"Actual<br/>Cost", formatter:currencyFormatterInstAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,5}$/,finalRegExp:'^\\d{5}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:5, size:5}, sortable:true, resizeable:true, width:80},

    {key:"delete", label:"Delete", formatter:this.deleteAccessoryFormatter, width:120}
  ];
}

function getAccessoriesTable(columnDefs, dataSource) {
  var editableTableParams = null;
  if (userHasEditAccessToThisProject()) {
    editableTableParams = {};
    editableTableParams.firstEditableColumnIndex = 0;
    editableTableParams.lastEditableColumnIndex = 33;
    editableTableParams.newRecord = getNewAccessoryRecord();
    editableTableParams.showSaveWarning = true;
    editableTableParams.keyForDeletedId = "acceId";
    editableTableParams.deletedIds = [];
  }
  accessoriesDataTable = createEditableDataTable("accessoriesList", columnDefs, dataSource, "accessoryName", {initialLoad:true,
    scrollable:true, width: getWidthForDataTable('equipmentDivForDialog'),
    draggableColumns:true}, {pagination:true, topPaginator:'topPaginatorForAccessories'}, {editableTableParams:editableTableParams});

  if (userHasEditAccessToThisProject()) {
    var dt = accessoriesDataTable.getDataTable();
    dt.subscribe("renderEvent", function() {
      document.getElementById('addAccessoryBtn').disabled = '';
    });
    //make accessory's purchasing columns non-editable if purchased with equipment is checked
    dt.subscribe('cellClickEvent', function (oArgs) {
      onCellClickOfInstAndAcce(dt, oArgs);
    });
    dt.subscribe('checkboxClickEvent', function(oArgs) {
      onCheckboxClickOfInstAndAcce(dt, oArgs);
    });
  }
  return accessoriesDataTable;
}

function setAccessoriesDataTableBeenModified(boolValue) {
  if (accessoriesDataTable != null) {
    var params = accessoriesDataTable.getEditableTableParams();
    params.hasDataTableBeenModified = boolValue;
  }
}

function addNewAccessoryRow() {
  addNewRowToDataTable(accessoriesDataTable);
}

function getNewAccessoryRecord() {
  return {
    acceId:"",
    electId:"",
    purchaseId:"",
    accessoryName:"",
    purchasedWithEquipment:"",
    accessoryDesignatorId:"",
    accessoryDesignatorTypeCode:"",
    sequenceNumber:"",
    accessoryNumber:"",
    quantity:"",
    acceDescription:"",
    comments:"",
    compAirReqd:"",
    gasReqd:"",
    waterReqd:"",
    utilityFlowrate:"",
    selfCleaning:"",
    size:"",
    autoManualId:"",
    proofOfPositionReq:"",
    solenoidReq:"",
    localPushButtonReq:"",
    inputId:"",
    inputQty:"",
    outputId:"",
    outputQty:"",
    hmiDisplay:"",
    otherMeasurementId:"",
    communications:"",
    voltage:"",
    bidPackage: "",
    vendor:"",
    rtpNumber:"",
    poNumber:"",
    lineNumber:"",
    actualDeliveryDate:"",
    estimatedCost:"",
    actualCost:""
  };
}

function createAccessoryNumber(oRecord) {
  var acceDesignatorId = oRecord.getData('accessoryDesignatorId');
  var accecDesignatorTypeCode = acceDesignatorIdToTypeCodeMap.get(acceDesignatorId);
  var sequenceNumber = oRecord.getData('sequenceNumber');
  return getFirst5CharsOfEquipNum() + accecDesignatorTypeCode + sequenceNumber;
}

function resetAccessoryTable() {
  if (accessoriesDataTable != null) {
    var dt = accessoriesDataTable.getDataTable();
    dt.getRecordSet().reset();
  }
}

function createHiddenFieldsForAccessories() {
  var addEquipmentForm = document.getElementById("addEquipmentForm");
  if (accessoriesDataTable != null) {
    var dt = accessoriesDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var acceId = getEmptyStringIfUndefined(data.acceId);
      var electId = getEmptyStringIfUndefined(data.electId);
      var purchaseId = getEmptyStringIfUndefined(data.purchaseId);
      var accessoryName = getEmptyStringIfUndefined(data.accessoryName);
      var purchasedWithEquipment = getEmptyStringIfUndefined(data.purchasedWithEquipment);
      var accessoryDesignatorId = getEmptyStringIfUndefined(data.accessoryDesignatorId);
      var sequenceNumber = getEmptyStringIfUndefined(data.sequenceNumber);
      var quantity = getEmptyStringIfUndefined(data.quantity);
      var acceDescription = getEmptyStringIfUndefined(data.acceDescription);
      var comments = getEmptyStringIfUndefined(data.comments);
      var compAirReqd = getEmptyStringIfUndefined(data.compAirReqd);
      var gasReqd = getEmptyStringIfUndefined(data.gasReqd);
      var waterReqd = getEmptyStringIfUndefined(data.waterReqd);
      var utilityFlowrate = getEmptyStringIfUndefined(data.utilityFlowrate);
      var selfCleaning = getEmptyStringIfUndefined(data.selfCleaning);
      var size = getEmptyStringIfUndefined(data.size);
      var autoManualId = getEmptyStringIfUndefined(data.autoManualId);
      var proofOfPositionReq = getEmptyStringIfUndefined(data.proofOfPositionReq);
      var solenoidReq = getEmptyStringIfUndefined(data.solenoidReq);
      var localPushButtonReq = getEmptyStringIfUndefined(data.localPushButtonReq);
      var inputId = getEmptyStringIfUndefined(data.inputId);
      var inputQty = getEmptyStringIfUndefined(data.inputQty);
      var outputId = getEmptyStringIfUndefined(data.outputId);
      var outputQty = getEmptyStringIfUndefined(data.outputQty);
      var hmiDisplay = getEmptyStringIfUndefined(data.hmiDisplay);
      var otherMeasurementId = getEmptyStringIfUndefined(data.otherMeasurementId);
      var communications = getEmptyStringIfUndefined(data.communications);
      var voltage = getEmptyStringIfUndefined(data.voltage);
      var bidPackage = getEmptyStringIfUndefined(data.bidPackage);
      var vendor = getEmptyStringIfUndefined(data.vendor);
      var rtpNumber = getEmptyStringIfUndefined(data.rtpNumber);
      var poNumber = getEmptyStringIfUndefined(data.poNumber);
      var lineNumber = getEmptyStringIfUndefined(data.lineNumber);
      var estimatedCost = getEmptyStringIfUndefined(data.estimatedCost);
      var actualCost = getEmptyStringIfUndefined(data.actualCost);
      var actualDeliveryDate = formatDateForSaving(data.actualDeliveryDate);
      addEquipmentForm.appendChild(createHiddenField("acceId", acceId));
      addEquipmentForm.appendChild(createHiddenField("acceElectId", electId));
      addEquipmentForm.appendChild(createHiddenField("accePurchaseId", purchaseId));
      addEquipmentForm.appendChild(createHiddenField("accessoryName", accessoryName));
      addEquipmentForm.appendChild(createHiddenField("accePurchasedWithEquip", purchasedWithEquipment));
      addEquipmentForm.appendChild(createHiddenField("accessoryDesginatorId", accessoryDesignatorId));
      addEquipmentForm.appendChild(createHiddenField("acceSequenceNumber", sequenceNumber));
      addEquipmentForm.appendChild(createHiddenField("acceQuantity", quantity));
      addEquipmentForm.appendChild(createHiddenField("acceDescription", acceDescription));
      addEquipmentForm.appendChild(createHiddenField("acceComments", comments));
      addEquipmentForm.appendChild(createHiddenField("acceCompAirReqd", compAirReqd));
      addEquipmentForm.appendChild(createHiddenField("acceGasReqd", gasReqd));
      addEquipmentForm.appendChild(createHiddenField("acceWaterReqd", waterReqd));
      addEquipmentForm.appendChild(createHiddenField("acceUtilityFlowrate", utilityFlowrate));
      addEquipmentForm.appendChild(createHiddenField("acceSelfCleaning", selfCleaning));
      addEquipmentForm.appendChild(createHiddenField("acceSize", size));
      addEquipmentForm.appendChild(createHiddenField("autoManualId", autoManualId));
      addEquipmentForm.appendChild(createHiddenField("acceProofOfPositionReq", proofOfPositionReq));
      addEquipmentForm.appendChild(createHiddenField("acceSolenoidReq", solenoidReq));
      addEquipmentForm.appendChild(createHiddenField("acceLocalPushButtonReq", localPushButtonReq));
      addEquipmentForm.appendChild(createHiddenField("acceInputId", inputId));
      addEquipmentForm.appendChild(createHiddenField("acceInputQty", inputQty));
      addEquipmentForm.appendChild(createHiddenField("acceOutputId", outputId));
      addEquipmentForm.appendChild(createHiddenField("acceOutputQty", outputQty));
      addEquipmentForm.appendChild(createHiddenField("acceHmiDisplay", hmiDisplay));
      addEquipmentForm.appendChild(createHiddenField("acceOtherMeasurementId", otherMeasurementId));
      addEquipmentForm.appendChild(createHiddenField("acceHmiDisplay", hmiDisplay));
      addEquipmentForm.appendChild(createHiddenField("acceCommunications", communications));
      addEquipmentForm.appendChild(createHiddenField("acceVoltage", voltage));
      addEquipmentForm.appendChild(createHiddenField("acceBidPackage", bidPackage));
      addEquipmentForm.appendChild(createHiddenField("acceVendor", vendor));
      addEquipmentForm.appendChild(createHiddenField("acceRtpNumber", rtpNumber));
      addEquipmentForm.appendChild(createHiddenField("accePoNumber", poNumber));
      addEquipmentForm.appendChild(createHiddenField("acceLineNumber", lineNumber));
      addEquipmentForm.appendChild(createHiddenField("acceEstimatedCost", estimatedCost));
      addEquipmentForm.appendChild(createHiddenField("acceActualCost", actualCost));
      addEquipmentForm.appendChild(createHiddenField("acceActualDeliveryDate", actualDeliveryDate));
    }
  }
}

function removeHiddenFieldsForAccessories() {
  var addEquipmentForm = document.getElementById("addEquipmentForm");
  removeHiddenFields(addEquipmentForm, "acceId");
  removeHiddenFields(addEquipmentForm, "acceElectId");
  removeHiddenFields(addEquipmentForm, "accePurchaseId");
  removeHiddenFields(addEquipmentForm, "accessoryName");
  removeHiddenFields(addEquipmentForm, "accePurchasedWithEquip");
  removeHiddenFields(addEquipmentForm, "accessoryDesginatorId");
  removeHiddenFields(addEquipmentForm, "acceSequenceNumber");
  removeHiddenFields(addEquipmentForm, "acceQuantity");
  removeHiddenFields(addEquipmentForm, "acceDescription");
  removeHiddenFields(addEquipmentForm, "acceComments");
  removeHiddenFields(addEquipmentForm, "acceCompAirReqd");
  removeHiddenFields(addEquipmentForm, "acceGasReqd");
  removeHiddenFields(addEquipmentForm, "acceWaterReqd");
  removeHiddenFields(addEquipmentForm, "acceUtilityFlowrate");
  removeHiddenFields(addEquipmentForm, "acceSelfCleaning");
  removeHiddenFields(addEquipmentForm, "acceSize");
  removeHiddenFields(addEquipmentForm, "autoManualId");
  removeHiddenFields(addEquipmentForm, "acceProofOfPositionReq");
  removeHiddenFields(addEquipmentForm, "acceSolenoidReq");
  removeHiddenFields(addEquipmentForm, "acceLocalPushButtonReq");
  removeHiddenFields(addEquipmentForm, "acceInputId");
  removeHiddenFields(addEquipmentForm, "acceInputQty");
  removeHiddenFields(addEquipmentForm, "acceOutputId");
  removeHiddenFields(addEquipmentForm, "acceOutputQty");
  removeHiddenFields(addEquipmentForm, "acceHmiDisplay");
  removeHiddenFields(addEquipmentForm, "acceOtherMeasurementId");
  removeHiddenFields(addEquipmentForm, "acceCommunications");
  removeHiddenFields(addEquipmentForm, "acceVoltage");
  removeHiddenFields(addEquipmentForm, "acceBidPackage");
  removeHiddenFields(addEquipmentForm, "acceVendor");
  removeHiddenFields(addEquipmentForm, "acceRtpNumber");
  removeHiddenFields(addEquipmentForm, "accePoNumber");
  removeHiddenFields(addEquipmentForm, "acceLineNumber");
  removeHiddenFields(addEquipmentForm, "acceEstimatedCost");
  removeHiddenFields(addEquipmentForm, "acceActualCost");
  removeHiddenFields(addEquipmentForm, "acceActualDeliveryDate");
  removeHiddenFields(addEquipmentForm, "deletedAccessoryIds");
}

function createHiddenFieldForDeletedAccessoryIds() {
  var deletedAccessoryIdsStr = "";
  var deletedIds = accessoriesDataTable.getEditableTableParams().deletedIds;
  for (var i = 0; i < deletedIds.length; i++) {
    var deletedId = deletedIds[i];
    deletedAccessoryIdsStr += deletedId + ",";
  }
  var addEquipmentForm = document.getElementById("addEquipmentForm");
  addEquipmentForm.appendChild(createHiddenField("deletedAccessoryIds", deletedAccessoryIdsStr));
}