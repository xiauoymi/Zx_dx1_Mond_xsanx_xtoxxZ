function getChangeHistoyDataTable(equipmentId) {
  if (equipmentId != "") {
    var url =  document.getElementById('contextPath').value + "/data/changeHistoryXml?" +
      "equipmentId=" + equipmentId;
    createEquipmentChangeHistoryDataTable(url);
  }
}