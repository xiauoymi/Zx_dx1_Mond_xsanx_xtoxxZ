function createCostScheduleCalendars() {
  createCalendar("scheduledSpecificationDate", "scheduledSpecificationDateContainer");
  createCalendar("scheduledQuoteDate", "scheduledQuoteDateContainer");
  createCalendar("scheduledPurchaseDate", "scheduledPurchaseDateContainer");
  createCalendar("estiamtedShippingDate", "estiamtedShippingDateContainer");
  createCalendar("specIssuedDate", "specIssuedDateContainer");
  createCalendar("rtpEnteredDate", "rtpEnteredDateContainer");
  createCalendar("rtqEnteredDate", "rtqEnteredDateContainer");
  createCalendar("prelDrawingIssuedDate", "prelDrawingIssuedDateContainer");
  createCalendar("finalDrawingDate", "finalDrawingDateContainer");
  createCalendar("approvalDrawingDate", "approvalDrawingDateContainer");
  createCalendar("iomReceivedDate", "iomReceivedDateContainer");
}

function getCostScheduleDetails(equipmentId) {
  if (equipmentId != "") {
    var url = document.getElementById('contextPath').value
        + '/data/equipment/details?method=lookupCostScheduleXml&equipmentId=' + equipmentId;
    var callbackAfterGettingCostScheduleDetails = {
      success: function(o) {
        this.cache = null;
        checkXMLReturnedFromAjaxCall(o, populateCostScheduleDetails);
//        populateCostScheduleDetails(o.responseXML);
      }
      ,
      failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
      }
      ,
      cache:false
    }
    this.getXML = YAHOO.util.Connect.asyncRequest('GET', url, callbackAfterGettingCostScheduleDetails);
  }
}

function populateCostScheduleDetails(o) {
  var xmlDoc = o.responseXML;
  var costScheduleId = xmlDoc.getElementsByTagName("costScheduleId")[0].text;
  var scheduledSpecificationDate = xmlDoc.getElementsByTagName("scheduledSpecificationDate")[0].text;
  var scheduledQuoteDate = xmlDoc.getElementsByTagName("scheduledQuoteDate")[0].text;
  var scheduledPurchaseDate = xmlDoc.getElementsByTagName("scheduledPurchaseDate")[0].text;
  var drawingTurnaroundTime = xmlDoc.getElementsByTagName("drawingTurnaroundTime")[0].text;
  var estiamtedFabricationTime = xmlDoc.getElementsByTagName("estiamtedFabricationTime")[0].text;
  var estiamtedShippingDate = xmlDoc.getElementsByTagName("estiamtedShippingDate")[0].text;
  var specIssuedDate = xmlDoc.getElementsByTagName("specIssuedDate")[0].text;
  var rtqEnteredDate = xmlDoc.getElementsByTagName("rtqEnteredDate")[0].text;
  var rtpEnteredDate = xmlDoc.getElementsByTagName("rtpEnteredDate")[0].text;
  var prelDrawingIssuedDate = xmlDoc.getElementsByTagName("prelDrawingIssuedDate")[0].text;
  var approvalDrawingDate = xmlDoc.getElementsByTagName("approvalDrawingDate")[0].text;
  var finalDrawingDate = xmlDoc.getElementsByTagName("finalDrawingDate")[0].text;
  var iomReceivedDate = xmlDoc.getElementsByTagName("iomReceivedDate")[0].text;
  var estimatedSource = xmlDoc.getElementsByTagName("estimatedSource")[0].text;
  var estimatedCost = xmlDoc.getElementsByTagName("estimatedCost")[0].text;
  var fundingSourceId = xmlDoc.getElementsByTagName("fundingSourceId")[0].text;
  var estimatedMechHours = xmlDoc.getElementsByTagName("estimatedMechHours")[0].text;
  var escalationFactor = xmlDoc.getElementsByTagName("escalationFactor")[0].text;
  var poLineAmount = xmlDoc.getElementsByTagName("poLineAmount")[0].text;
  var coAmount = xmlDoc.getElementsByTagName("coAmount")[0].text;
  document.getElementById('costScheduleId').value = costScheduleId;

  hideCalendarIfReadOnlyAccess("btn-scheduledSpecificationDateContainer");
  hideCalendarIfReadOnlyAccess("btn-scheduledQuoteDateContainer");
  hideCalendarIfReadOnlyAccess("btn-scheduledPurchaseDateContainer");
  hideCalendarIfReadOnlyAccess("btn-estiamtedShippingDateContainer");
  hideCalendarIfReadOnlyAccess("btn-specIssuedDateContainer");
  hideCalendarIfReadOnlyAccess("btn-rtpEnteredDateContainer");
  hideCalendarIfReadOnlyAccess("btn-rtqEnteredDateContainer");
  hideCalendarIfReadOnlyAccess("btn-prelDrawingIssuedDateContainer");
  hideCalendarIfReadOnlyAccess("btn-finalDrawingDateContainer");
  hideCalendarIfReadOnlyAccess("btn-approvalDrawingDateContainer");
  hideCalendarIfReadOnlyAccess("btn-iomReceivedDateContainer");

  updateTextField('poLineAmount', poLineAmount);
  updateTextField('coAmount', coAmount);

  var costScheFundingSources = document.getElementById('fundingSourceId');
  setSelectedInDropdown(costScheFundingSources, fundingSourceId);
  updateSelectField('fundingSourceId', fundingSourceId);

  updateTextField('scheduledSpecificationDate', formatDateForDisplay(scheduledSpecificationDate));
  updateTextField('scheduledQuoteDate', formatDateForDisplay(scheduledQuoteDate));
  updateTextField('scheduledPurchaseDate', formatDateForDisplay(scheduledPurchaseDate));
  updateTextField('estiamtedShippingDate', formatDateForDisplay(estiamtedShippingDate));
  updateTextField('specIssuedDate', formatDateForDisplay(specIssuedDate));
  updateTextField('specIssuedDate', formatDateForDisplay(specIssuedDate));
  updateTextField('rtqEnteredDate', formatDateForDisplay(rtqEnteredDate));
  updateTextField('rtpEnteredDate', formatDateForDisplay(rtpEnteredDate));
  updateTextField('prelDrawingIssuedDate', formatDateForDisplay(prelDrawingIssuedDate));
  updateTextField('approvalDrawingDate', formatDateForDisplay(approvalDrawingDate));
  updateTextField('finalDrawingDate', formatDateForDisplay(finalDrawingDate));
  updateTextField('iomReceivedDate', formatDateForDisplay(iomReceivedDate));
  updateTextField('drawingTurnaroundTime', drawingTurnaroundTime);
  updateTextField('estiamtedFabricationTime', estiamtedFabricationTime);
  updateTextField('estimatedSource', estimatedSource);
  updateTextField('estimatedCost', estimatedCost);
  updateTextField('estimatedMechHours', estimatedMechHours);
  updateTextField('escalationFactor', escalationFactor);

  calculateOverUnder();
}

function calculateOverUnder() {
  var poLineAmount = document.getElementById('poLineAmount').value
  var coAmount = document.getElementById('coAmount').value
  var totalItemCost = '';
  if (poLineAmount != '' && coAmount != '') {
    totalItemCost = parseInt(poLineAmount) + parseInt(coAmount);
  }
  var estimatedCost = document.getElementById('estimatedCost').value;
  if (totalItemCost != '' && estimatedCost != '') {
    var costScheOverUnder = document.getElementById('costScheOverUnder');
    costScheOverUnder.innerHTML = totalItemCost - estimatedCost;
//    updateTextField('costScheOverUnder', totalItemCost - estimatedCost);
  }
}