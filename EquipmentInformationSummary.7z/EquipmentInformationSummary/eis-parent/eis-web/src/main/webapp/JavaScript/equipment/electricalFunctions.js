function populateDesignCapacityUnitDropdown() {

}


function getElectricalDetails(equipmentId) {
  if (equipmentId != "") {
    var url = document.getElementById('contextPath').value
        + '/data/equipment/details?method=lookupElectricalXml&equipmentId=' + equipmentId;
      document.body.style.cursor = 'progress';
    var callbackAfterGettingElectricalDetails = {
      success: function(o) {
        this.cache = null;
        populateDesignCapacityUnitDropdown();
        checkXMLReturnedFromAjaxCall(o, populateElectricalDetails);
//        populateElectricalDetails(o.responseXML);
          document.body.style.cursor = 'default';
      }
      ,
      failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
      }
      ,
      cache:false
    }
    this.getXML = YAHOO.util.Connect.asyncRequest('GET', url, callbackAfterGettingElectricalDetails);
  }
}

function populateElectricalDetails(o) {
  var xmlDoc = o.responseXML;
  var electricalId = xmlDoc.getElementsByTagName("electId")[0].text;
  var proofOfPositionReq = xmlDoc.getElementsByTagName("proofOfPositionReq")[0].text;
  var solenoidReq = xmlDoc.getElementsByTagName("solenoidReq")[0].text;
  var localPushButtonReq = xmlDoc.getElementsByTagName("localPushButtonReq")[0].text;

//  var inputId = xmlDoc.getElementsByTagName("inputId")[0].text;
  //  var inputQty = xmlDoc.getElementsByTagName("inputQty")[0].text;
  //  var outputId = xmlDoc.getElementsByTagName("outputId")[0].text;
  //  var outputQty = xmlDoc.getElementsByTagName("outputQty")[0].text;
  var hmiDisplay = xmlDoc.getElementsByTagName("hmiDisplay")[0].text;
  var otherMeasurementId = xmlDoc.getElementsByTagName("otherMeasurementId")[0].text;

  var communications = xmlDoc.getElementsByTagName("communications")[0].text;
  var voltage = xmlDoc.getElementsByTagName("voltage")[0].text;

  var inputQuantities = xmlDoc.getElementsByTagName("inputQuantities")[0];
  var outputQuantities = xmlDoc.getElementsByTagName("outputQuantities")[0];

  document.getElementById('electricalId').value = electricalId;

  updateCheckbox('proofOfPositionReq', proofOfPositionReq);
  updateCheckbox('solenoidReq', solenoidReq);
  updateCheckbox('localPushButtonReq', localPushButtonReq);

//  setSelectedInDropdown(inputs, inputId);
  //  updateSelectField('input', inputId);
  //
  //  var outputs = document.getElementById('output');
  //  setSelectedInDropdown(outputs, outputId);
  //  updateSelectField('output', outputId);

  var otherMeasurements = document.getElementById('otherMeasurement');
  setSelectedInDropdown(otherMeasurements, otherMeasurementId);
  updateSelectField('otherMeasurement', otherMeasurementId);

//  updateTextField('inputQty', inputQty);
  //  updateTextField('outputQty', outputQty);
  updateTextField('hmiDisplay', hmiDisplay);
  updateTextField('communications', communications);
  updateTextField('voltage', voltage);

  var i = 0;
  if (inputQuantities != null) {
    var inputQuantityChildren = inputQuantities.childNodes;
    for (i = 0; i < inputQuantityChildren.length; i++) {
      var inputIdCheckedNode = inputQuantityChildren[i].childNodes[1];//eg. <inputIdChecked1189>
      var inputChecked = inputIdCheckedNode.firstChild === null ? '' : inputIdCheckedNode.firstChild.nodeValue;
      var inputIdNode = inputQuantityChildren[i].childNodes[2];//eg. <inputId1189>
      var inputId = inputIdNode.firstChild === null ? '' : inputIdNode.firstChild.nodeValue;
      var inputQtyNode = inputQuantityChildren[i].childNodes[3];//eg. <inputQty1189>
      var inputQty = inputQtyNode.firstChild === null ? '' : inputQtyNode.firstChild.nodeValue;
      var checkbox = document.getElementById(inputId + 'InputCheckbox');
      checkbox.checked = inputChecked === "true";
      document.getElementById(inputId + 'InputQuantity').value = inputQty;
    }
  }

  if (outputQuantities != null) {
    var outputQuantityChildren = outputQuantities.childNodes;
    for (i = 0; i < outputQuantityChildren.length; i++) {
      var outputIdCheckedNode = outputQuantityChildren[i].childNodes[1];
      var outputChecked = outputIdCheckedNode.firstChild === null ? '' : outputIdCheckedNode.firstChild.nodeValue;
      var outputIdNode = outputQuantityChildren[i].childNodes[2];
      var outputId = outputIdNode.firstChild === null ? '' : outputIdNode.firstChild.nodeValue;
      var outputQtyNode = outputQuantityChildren[i].childNodes[3];
      var outputQty = outputQtyNode.firstChild === null ? '' : outputQtyNode.firstChild.nodeValue;

      checkbox = document.getElementById(outputId + 'OutputCheckbox');
      checkbox.checked = outputChecked === "true";
      document.getElementById(outputId + 'OutputQuantity').value = outputQty;
    }
  }
}

function createHiddenFieldsForElectricalInputAndOutput() {
  var addEquipmentForm = document.getElementById("addEquipmentForm");
  var inputsCheckbox = document.getElementsByName("electricalInputsCheckbox");
  var inputsQuantity = document.getElementsByName("electricalInputsQty");
  var outputsCheckbox = document.getElementsByName("electricalOutputsCheckbox");
  var outputsQuantity = document.getElementsByName("electricalOutputsQty");
  addHiddenFieldsForCheckbox(addEquipmentForm, inputsCheckbox, "InputCheckbox");
  addHiddenFieldsForCheckboxQuantity(addEquipmentForm, inputsQuantity, "InputQuantity");
  addHiddenFieldsForCheckbox(addEquipmentForm, outputsCheckbox, "OutputCheckbox");
  addHiddenFieldsForCheckboxQuantity(addEquipmentForm, outputsQuantity, "OutputQuantity");
}

function removeHiddenFieldsForElectricalInputAndOutput() {
  var addEquipmentForm = document.getElementById("addEquipmentForm");
  var inputsCheckbox = document.getElementsByName("electricalInputsCheckbox");
  var inputsQuantity = document.getElementsByName("electricalInputsQty");
  var outputsCheckbox = document.getElementsByName("electricalOutputsCheckbox");
  var outputsQuantity = document.getElementsByName("electricalOutputsQty");
  removeHiddenFieldsForCheckbox(addEquipmentForm, inputsCheckbox, "InputCheckbox");
  removeHiddenFieldsForCheckboxQuantity(addEquipmentForm, inputsQuantity, "InputQuantity");
  removeHiddenFieldsForCheckbox(addEquipmentForm, outputsCheckbox, "OutputCheckbox");
  removeHiddenFieldsForCheckboxQuantity(addEquipmentForm, outputsQuantity, "OutputQuantity");
}

function addHiddenFieldsForCheckbox(form, checkbox, inputOrOutput) {
  var i = 0;
  for (i = 0; i < checkbox.length; i++) {
    var checkboxName = checkbox[i].id.split(inputOrOutput);
    var hiddenName = inputOrOutput + checkboxName[0];
    form.appendChild(createHiddenField(hiddenName, checkbox[i].checked));
  }
}

function addHiddenFieldsForCheckboxQuantity(form, checkboxQuantity, inputOrOutput) {
  var i = 0;
  for (i = 0; i < checkboxQuantity.length; i++) {
    var quantityName = checkboxQuantity[i].id.split(inputOrOutput);
    var hiddenName = inputOrOutput + quantityName[0];
    form.appendChild(createHiddenField(hiddenName, checkboxQuantity[i].value));
  }
}

function removeHiddenFieldsForCheckbox(form, checkbox, inputOrOutput) {
  var i = 0;
  for (i = 0; i < checkbox.length; i++) {
    var checkboxName = checkbox[i].id.split(inputOrOutput);
    var hiddenName = inputOrOutput + checkboxName[0];
    removeHiddenFields(form, hiddenName);
  }
}

function removeHiddenFieldsForCheckboxQuantity(form, checkboxQuantity, inputOrOutput) {
  var i = 0;
  for (i = 0; i < checkboxQuantity.length; i++) {
    var quantityName = checkboxQuantity[i].id.split(inputOrOutput);
    var hiddenName = inputOrOutput + quantityName[0];
    removeHiddenFields(form, hiddenName);
  }
}

