var equipmentDialog = null;

function createEquipmentDialog() {
    var handleSubmit = function(e, closeDialogAfterSave) {
        removeHiddenFieldsForMotors();
        removeHiddenFieldsForInstruments();
        removeHiddenFieldsForAccessories();
        removeHiddenFieldsForElectricalInputAndOutput();
        if (document.getElementById("hasMotorsDataChanged").value === "true") {
            createHiddenFieldsForMotors();
            createHiddenFieldForDeletedMotorIds();
        }
        if (document.getElementById("hasInstrumentsDataChanged").value === "true") {
            createHiddenFieldsForInstruments();
            createHiddenFieldForDeletedInstrumentIds();
        }
        if (document.getElementById("hasAccessoriesDataChanged").value === "true") {
            createHiddenFieldsForAccessories();
            createHiddenFieldForDeletedAccessoryIds();
        }

        createHiddenFieldsForElectricalInputAndOutput();

        var callbackAfterEquipmentSave = {
            success: function(o) {
                this.cache = null;
                var xmlDoc = o.responseXML;
                var equipmentId = xmlDoc.selectSingleNode("//equipmentId").text;
                document.getElementById('equipmentId').value = equipmentId;
                document.getElementById("equipmentVendor").value = document.getElementById("vendor").value;
                updateEquipmentHeader();
                updateEquipmentDialogHeader(equipmentId);
                enableDisableOtherTabsDependingOnDetails(true);

                var messageElement = document.getElementById('messagesForEquipment');
                if (messageElement != null) {
                    messageElement.style.display = "";
                }
                var errors = xmlDoc.selectNodes("//error");
                var successStr = "";
                var errorStr = "";
                if (errors.length === 0) {
                    setMotorsDataTableBeenModified(false);
                    setInstrumentsDataTableBeenModified(false);
                    setAccessoriesDataTableBeenModified(false);
                    successStr = "Equipment Item Saved";
                    resetEquipmentTabIdsAlreadyClicked();
                    fireEquipmentTabsActiveTabChangeEvent(equipmentId);//to refresh tables and tabs
                } else {
                    for (var i = 0; i < errors.length; i++) {
                        var errorHeader = errors[i].selectSingleNode("errorHeader").firstChild.nodeValue;
                        errorStr += "<span class='errorMsgHeader'>" + errorHeader + "</span><br/>";
                        var errorMsgs = errors[i].selectNodes("errorMsg");
                        for (var j = 0; j < errorMsgs.length; j++) {
                            var errorMsg = errorMsgs[j].firstChild.nodeValue;
                            errorStr += errorMsg + "<br/>";
                        }
                    }
                }
                hideOrShowSucessAndErrorMessageDiv(false, "successMsgsForEquipmentDiv", "errorMsgsForEquipmentDiv", successStr, errorStr);
                document.getElementById('successMsgsForEquipmentDiv').innerHTML = successStr;
                document.getElementById('errorMsgsForEquipmentDiv').innerHTML = errorStr;

                if (document.getElementById("hasPurchasingDataChanged").value === "true") {
                    document.getElementById('equipmentVendor').value = document.getElementById('vendor').value;
                }
                document.getElementById('saveEquipmentBtn').disabled = '';
                if (errors.length == 0 && closeDialogAfterSave) {
                    showCancelEquipmentWarning();
                }
            },
            failure: function(o) {
                document.getElementById('saveEquipmentBtn').disabled = '';
                document.location.href = document.getElementById('contextPath').value +
                                         "/servlet/logon?method=error";
            },
            cache:false,
            timeout: 50000 //20 seconds
        };
        document.getElementById('saveEquipmentBtn').disabled = "disabled";
        var addEquipmentForm = document.getElementById("addEquipmentForm");
        YAHOO.util.Connect.setForm(addEquipmentForm);
        this.getXML = YAHOO.util.Connect.asyncRequest("POST",
                "/eis/data/equipment/details?method=saveEquipment",
                callbackAfterEquipmentSave);

        //    this.form.submit();
    };

    equipmentDialog = new YAHOO.widget.Dialog("equipmentDivForDialog",
    {
      // width : getWidthForDialog(),
       //height: getHeightForDialog(),
        width: "85em",
        height: "50em",
        visible : false,
        modal:false,
        constraintoviewport :false,
        fixedcenter: false

       // x : getXForDialog(),
        //y : getYForDialog()
    });

    equipmentDialog._doClose = function (e) {
        showCancelEquipmentWarning();
    };
    equipmentDialog.render();

    equipmentDialog.beforeHideEvent.subscribe(doBeforeEquipmentDialogHide);
    equipmentDialog.beforeShowEvent.subscribe(doBeforeEquipmentDialogShow);
    YAHOO.util.Event.addListener("saveEquipmentBtn", "click", handleSubmit, false, true);
    YAHOO.util.Event.addListener("cancelEquipmentBtn", "click", showCancelEquipmentWarning, equipmentDialog, true);
    YAHOO.util.Event.addListener("saveAndCloseEquipmentBtn", "click", handleSubmit, true, true);

    createEquipmentTabs("");
}

function showCancelEquipmentWarning() {
//    if (!userHasEditAccessToThisProject() ||
//          confirm("If Changes have been made without Saving they will be lost by Exiting")) {
    equipmentDialog.hide();
//      }
}

function showEquipmentDetailsDialog(equipmentId) {
    createEquipmentTabs(equipmentId);
    equipmentDialog.show();
}

function showEquipmentDialogForCreate() {
    createEquipmentTabs("");
    enableDisableOtherTabsDependingOnDetails(false);
    showEditableFieldsForDetails();
    equipmentDialog.show();
}

function showEditableFieldsForDetails() {
    showTextField('PROCESS_LINE_NUMBER', '', true);
    showTextField('EQUIPMENT_TAG_NUMBER', '', true);
    showTextField('EXISTING_EQUIPMENT_NUMBER', '', true);
    showSelect('equipmentAreaId', '', true);
    showSelect('equipmentTypeId', '', true);
    showSelect('equipmentSubTypeId', '', true);
}

function showTextField(id, value, isEditable) {
    var element = document.getElementById(id);
    if (element != null) {
        element.value = value;
        var span = getSpan(element, element.parentElement);
        if (isEditable) {
            element.style.display = "";
            span.style.display = "none";
        } else {
            element.style.display = "none";
            span.style.display = "";
            span.innerHTML = value;
        }
    }
}

function showSelect(id, value, isEditable) {
    var element = document.getElementById(id);
    var span = getSpan(element, element.parentElement);
    if (isEditable && isEditable === true) {
        element.style.display = "";
        span.style.display = "none";
    } else {
        element.style.display = "none";
        span.style.display = "";
        span.innerHTML = getValueOfSelectedIdForDropdown(element, value);
    }
}

function doBeforeEquipmentDialogShow() {
    YAHOO.util.Dom.removeClass("equipmentDivForDialog", "hideDialog");
    scrollToTop();
    if (document.getElementById('changeHistoryTabActive') != null &&
        document.getElementById('changeHistoryTabActive').value === "true") {
        getEquipmentDetails(document.getElementById('equipmentId').value);
        setChangeHistoryTabAsActive();
    } else {
        setEquipmentDetailsTabAsActive();
    }

    //  setEquipmentDetailsTabAsActive();
    hideOrShowSucessAndErrorMessageDiv(true, "successMsgsForEquipmentDiv", "errorMsgsForEquipmentDiv");
    //sizeAndShowMask('equipmentDivForDialog_mask');//For editors inside datatable to work properly
    updateEquipmentDialogHeader(document.getElementById('equipmentId').value);
}

function updateEquipmentDialogHeader(equipmentId) {
    var headerValue = '';
    if (equipmentId === "") {
        headerValue = "Create Equipment";
    } else {
        if (userHasEditAccessToThisProject()) {
            headerValue = "Edit Equipment"
        } else {
            headerValue = "View Equipment"
        }
    }
    document.getElementById('equipmentDialogHeader').innerHTML = headerValue;
}

function doBeforeEquipmentDialogHide() {
   // removeMask('equipmentDivForDialog_mask');
    resetEquipmentTabIdsAlreadyClicked();
    clearDataTablesOnOtherTabs();

   // disabledAddBtnsOnEquipmentDialog();
    var projectId = document.getElementById('projectId').value;//do this before form reset
    this.form.reset();
    document.getElementById('equip-name').innerHTML = "";//this should be set to empty after form reset
    document.getElementById('equip-description').innerHTML = "";//this should be set to empty after form reset
    //  var equipmentId = document.getElementById('equipmentId').value;
    document.getElementById('equipmentId').value = "";//this should be set to empty after form reset
    var messageElement = document.getElementById('messagesForEquipment');
    if (messageElement != null) {
        messageElement.style.display = "none"; //this should be set to empty after form reset
}
    resetSelectElement(false, document.getElementById("equipmentSubTypeId"));
    this.sizeUnderlay();

//    var refreshAllEquipmentList = document.getElementById('refreshAllEquipmentList') == null ? false :
//                                  document.getElementById('refreshAllEquipmentList').value;
//    if (refreshAllEquipmentList === "true") {
//        var url = document.getElementById('contextPath').value + "/data/equipmentSearchXml/search?projectId="
//                + projectId;
//        createEquipmentsListTabForAll(url);//basically refresh the table - to get rid of session parameters.
//    } else {
//        var refreshProjectChangeList = document.getElementById('refreshProjectChangeList') == null ? false :
//                                       document.getElementById('refreshProjectChangeList').value;
//
//        if (refreshProjectChangeList === "true") {
//            refreshDataTableForProjectChangeVerification(projectId);
//        }
//   }
}

function disabledAddBtnsOnEquipmentDialog() {
    document.getElementById('addMotorBtn').disabled = 'disabled';
    document.getElementById('addInstrumentBtn').disabled = 'disabled';
    document.getElementById('addAccessoryBtn').disabled = 'disabled';
}

function clearDataTablesOnOtherTabs() {
    resetMotorTable();
    resetInstrumentTable();
    resetAccessoryTable();
}
