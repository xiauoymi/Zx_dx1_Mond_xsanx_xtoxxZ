//function disableSelectElementsInParentWindow() {
//  document.getElementById('searchEquipmentTypeForAll').disabled = "disabled";
//  document.getElementById('searchEquipmentAreaForAll').disabled = "disabled";
//  document.getElementById('searchEquipmentTypeForMech').disabled = "disabled";
//  document.getElementById('searchEquipmentAreaForMech').disabled = "disabled";
//}
//
//function enableSelectElementsInParentWindow() {
//  document.getElementById('searchEquipmentTypeForAll').disabled = "";
//  document.getElementById('searchEquipmentAreaForAll').disabled = "";
//  document.getElementById('searchEquipmentTypeForMech').disabled = "";
//  document.getElementById('searchEquipmentAreaForMech').disabled = "";
//}

function getFirst5CharsOfEquipNum() {
  return document.getElementById('equipmentNumber').value ?
         document.getElementById('equipmentNumber').value.substring(0, 7) : "";//including 2 periods (.)
}

function updateSubTypes(parentElement, childElement, childIdToSelect, isEditable) {
  var parentId = parentElement.options[parentElement.selectedIndex].value;
  if (parentId != "") {
    var createList = {
      success: function(o) {
        this.cache = null;
        var span = getSpan(childElement, childElement.parentElement);
        if (isEditable && isEditable === true) {
          populateChildElement(o.responseXML, false, childElement, childIdToSelect);
          childElement.style.display = "";
          span.style.display = "none";
        } else {
          childElement.style.display = "none";
          span.style.display = "";
          span.innerHTML = getValueOfsubTypeIdForDropdown(o.responseXML, childElement, childIdToSelect);
        }
//        showSelect('equipmentSubTypeId', childIdToSelect, isEditable);
      },
      failure: function(o) {
          document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
      },
      cache:false,
      timeout: 20000 //20 seconds
    };
    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
        "/eis/data/equipment/details?method=lookupEquipmentSubTypes&equipmentType=" + parentId,
        createList);
  }
}

function getValueOfsubTypeIdForDropdown(xmlDoc, childElement, childIdToSelect) {
  var types = xmlDoc.selectNodes("//type");

  if (types.length === 0) {
    return "";
  } else {
    for (var i = 0; i < types.length; i++) {
      var id = types[i].selectSingleNode("id").firstChild.nodeValue;
      var description = types[i].selectSingleNode("description").firstChild.nodeValue;
      if (childIdToSelect === id) {
        var docoption = document.createElement("option");
        docoption.text = description;
        docoption.value = id;
        docoption.selected = true;
        childElement.options.add(docoption);
        return description;
      }
    }
    return "";
  }

}

function populateChildElement(xmlDoc, isForSearch, childElement, childIdToSelect) {
  removeOptions(childElement);
  var types = xmlDoc.selectNodes("//type");

  if (types.length === 0) {
    removeOptions(childElement);
    addOption(childElement, "No Subtype to Select");
  } else {
    resetSelectElement(isForSearch, childElement);
    var subTypeSelectedIndex = 0;
    for (var i = 0; i < types.length; i++) {
      var id = types[i].selectSingleNode("id").firstChild.nodeValue;
      var description = types[i].selectSingleNode("description").firstChild.nodeValue;
      var docoption = document.createElement("option");
      docoption.text = description;
      docoption.value = id;
      if (childIdToSelect === id) {
        subTypeSelectedIndex = i + 1;
      }
      childElement.options.add(docoption);

    }
    childElement.selectedIndex = subTypeSelectedIndex;
  }
}

function removeOptions(selectbox) {
  selectbox.innerHTML = '';
}

function resetSelectElement(isForSearch, selectElement) {
  removeOptions(selectElement);
  if (isForSearch) {
    addOption(selectElement, "All");
  } else {
    addOption(selectElement, "Please Select");
  }

}

function addOption(selectbox, text) {
  var docoption = document.createElement("OPTION");
  docoption.text = text;
  docoption.value = '';
  docoption.defaultSelected = true;
  selectbox.options.add(docoption);
}

function getEquipmentDetails(equipmentId) {
  if (equipmentId != "") {
    document.getElementById('equipmentId').value = equipmentId;
    var url = document.getElementById('contextPath').value
        + '/data/equipment/details?method=lookupEquipmentXml&equipmentId=' + equipmentId;

    document.getElementById('equip-name').innerHTML = "Loading....";
    document.body.style.cursor = 'progress';
    var callbackAfterGettingEquipmentDetails = {
      success: function(o) {
        this.cache = null;
       // alert("texgt:" + o.responseType);
         // alert("texgt:" + o.responseText);
          //alert("texgt:" + o.responseSchema);
//        alert(o.responseXML.text);
        populateEquipmentDetails(o.responseXML);
        updateEquipmentHeader();
        enableDisableOtherTabsDependingOnDetails(true);
        document.body.style.cursor = 'default';
      }
      ,
      cache:false ,
      failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
      }
      ,
      timeout: 40000 //40 seconds
    }
    this.getXML = YAHOO.util.Connect.asyncRequest('GET', url, callbackAfterGettingEquipmentDetails);
  }
}

function populateEquipmentDetails(xmlDoc) {

  var equipmentId = xmlDoc.getElementsByTagName("id")[0].text;
  var areaId = xmlDoc.getElementsByTagName("areaId")[0].text;
  var equipmentNumber = xmlDoc.getElementsByTagName("equipmentNumber")[0].text;
  var processLineNumber = xmlDoc.getElementsByTagName("processLineNumber")[0].text;
  var equipmentTagNumber = xmlDoc.getElementsByTagName("equipmentTagNumber")[0].text;
  var existingEquipmentNumber = xmlDoc.getElementsByTagName("existingEquipmentNumber")[0].text;
  var description = xmlDoc.getElementsByTagName("description")[0].text;
  var name = xmlDoc.getElementsByTagName("name")[0].text;
  var equipmentTypeId = xmlDoc.getElementsByTagName("equipmentType/equipmentTypeId")[0].text;
  var equipmentSubTypeId = xmlDoc.getElementsByTagName("equipmentSubType/equipmentSubTypeId")[0].text;
  var existingEquipmentModification = xmlDoc.getElementsByTagName("existingEquipmentModification")[0].text;
  var standardEquipment = xmlDoc.getElementsByTagName("standardEquipment")[0].text;
  var equipmentSoleSource = xmlDoc.getElementsByTagName("equipmentSoleSource")[0].text;

  document.getElementById('equipmentVendor').value = xmlDoc.getElementsByTagName("equipmentVendor")[0].text;
  document.getElementById('equipmentId').value = equipmentId;
  document.getElementById('equipmentNumber').value = equipmentNumber;

  updateTextField('EQUIPMENT_DESCRIPTION', description);
  updateTextField('EQUIPMENT_NAME', name);
  updateTextField('EXISTING_EQUIPMENT_NUMBER', existingEquipmentNumber);
  updateCheckbox('existingEquipmentModification', existingEquipmentModification);
  updateCheckbox('standardEquipment', standardEquipment);
  updateCheckbox('equipmentSoleSource', equipmentSoleSource);
  updateCheckbox('purchaseSoleSource', equipmentSoleSource);
  var equipmentAreas = document.getElementById('equipmentAreaId');
  var equipmentTypesElement = document.getElementById('equipmentTypeId');
  var equipmentSubTypesElement = document.getElementById('equipmentSubTypeId');

  setSelectedInDropdown(equipmentAreas, areaId);
  setSelectedInDropdown(equipmentTypesElement, equipmentTypeId);
  updateSubTypes(equipmentTypesElement, equipmentSubTypesElement, equipmentSubTypeId, false);
  hideShowEquipmentTypeSpecificProcessSections(equipmentTypesElement);

  var projectStatus = document.getElementById("projectStatus").value;
  if(projectStatus === "Definition" && userHasEditAccessToThisProject()){
    showTextField('PROCESS_LINE_NUMBER', processLineNumber, true);
    showTextField('EQUIPMENT_TAG_NUMBER', equipmentTagNumber, true);
    showTextField('EXISTING_EQUIPMENT_NUMBER', existingEquipmentNumber, true);
    showSelect('equipmentAreaId', areaId, true);
  }else{
    showTextField('PROCESS_LINE_NUMBER', processLineNumber, false);
    showTextField('EQUIPMENT_TAG_NUMBER', equipmentTagNumber, false);
    showTextField('existingEquipmentNumber', existingEquipmentNumber, false);
    showSelect('equipmentAreaId', areaId, false);
  }

  showSelect('equipmentTypeId', equipmentTypeId, false);
}

function updateEquipmentHeader() {
  var areaTypeCode = getTypeCode(document.getElementById('equipmentAreaId'));
  var equipmentTypeCode = getTypeCode(document.getElementById('equipmentTypeId'));
  var equipmentTagNumber = document.getElementById('EQUIPMENT_TAG_NUMBER').value;
  var processLineNumber = document.getElementById('PROCESS_LINE_NUMBER').value;
  var name = document.getElementById('EQUIPMENT_NAME').value;
  var description = document.getElementById('EQUIPMENT_DESCRIPTION').value;
  var vendorName = document.getElementById('equipmentVendor').value;
//  var equipmentSubType = document.getElementById('equipmentSubTypeId');
//  var equipmentSubTypeText = '';
//  if (equipmentSubType.selectedIndex > 0) {
//    equipmentSubTypeText = equipmentSubType[equipmentSubType.selectedIndex].text;
//  }
  document.getElementById('equip-name').innerHTML = areaTypeCode + "." +
                                                    processLineNumber + "." +
                                                    equipmentTagNumber +
                                                    equipmentTypeCode + ' ' +
                                                    name + ' - ' +
//                                                    equipmentSubTypeText + ' ' +
                                                    vendorName;
  document.getElementById('equip-description').innerHTML = description === '' ? '' : description.substring(0, 100);
//  document.getElementById('equip-description').innerHTML = description === '' ? '' : description;
}

function getTypeCode(element) {
  var selectedIndex = element.selectedIndex;
  if (selectedIndex < 0) {
    return "";
  } else {
    var text = element[element.selectedIndex].text;
    return element.value === '' ? '' : text.substring(0, 1);
  }
}

function updatePurchasingSoleSource(equipmentSoleSource){
  document.getElementById("purchaseSoleSource").checked = equipmentSoleSource.checked;
}

function populateDropDown(xmlDoc, element, idToSelect) {
  removeOptions(element);
  var types = xmlDoc.selectNodes("//area");

  if (types.length === 0) {
    removeOptions(element);
    addOption(element, "No Area to Select");
  } else {
    var selectedIndex = 0;
    for (var i = 0; i < types.length; i++) {
      var id = types[i].selectSingleNode("id").firstChild.nodeValue;
      var description = types[i].selectSingleNode("areaCodeDescription").firstChild.nodeValue;
      var docoption = document.createElement("option");
      docoption.text = description;
      docoption.value = id;
      if (idToSelect === id) {
        selectedIndex = i + 1;
      }
      element.options.add(docoption);

    }
    element.selectedIndex = selectedIndex;
  }
}
