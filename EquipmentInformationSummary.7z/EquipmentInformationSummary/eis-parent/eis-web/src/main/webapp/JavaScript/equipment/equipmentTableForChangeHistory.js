var changeHistoryDataTable = null;

function createEquipmentChangeHistoryDataTable(url) {
  if (changeHistoryDataTable == null) {
    this.changeHistoryDataSource = createServerSidePaginationDataSource(url);
    var fieldArr = [];
    fieldArr[fieldArr.length] = "auditDetailId";
    fieldArr[fieldArr.length] = "auditTransactionId";
    fieldArr[fieldArr.length] = "tabName";
    fieldArr[fieldArr.length] = "componentNumber";
    fieldArr[fieldArr.length] = "columnName";
    fieldArr[fieldArr.length] = "oldValue";
    fieldArr[fieldArr.length] = "newValue";
    fieldArr[fieldArr.length] = "changeDateTime";
    fieldArr[fieldArr.length] = "auditRequestor";
    fieldArr[fieldArr.length] = "processVerified";
    fieldArr[fieldArr.length] = "mechanicalVerified";
    fieldArr[fieldArr.length] = "electricalVerified";
    fieldArr[fieldArr.length] = "updateUserVerifiedUrl";
    this.changeHistoryDataSource.responseSchema = {
      resultNode: "changeHistory",
      fields: fieldArr,
      metaFields: {totalRecords : "totalRecords"}
    };
    changeHistoryDataTable = getChangeHistoryTable(getChangeHistoryColumnDefs(), this.changeHistoryDataSource);
  } else {
    changeHistoryDataTable.requery(url);
  }
}
function checkBoxClickEvent(oArgs, dt) {
  var elCheckbox = oArgs.target;
  var oRecord = dt.getRecord(elCheckbox);

  var updateUserVerifiedUrl = oRecord.getData("updateUserVerifiedUrl");
  var checkedUnchecked = oArgs.target.checked;
  updateUserVerifiedUrl += "&changeVerifiedColumn=" + oArgs.target.id + "&changeVerifiedCheckedUnchecked=" +
                           checkedUnchecked;

  var callBackAfterUpdatingUserVerified = {
    success: function(o) {
      this.cache = null;
    },
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    },
    timeout: 20000 //20 seconds
  };

  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      updateUserVerifiedUrl,
      callBackAfterUpdatingUserVerified);
}

function getChangeHistoryTable(columnDefs, dataSource) {
  var eisDataTable = createDataTable("equipmentsListForChangeHistory", columnDefs, dataSource, "columnName",
  {initialLoad:true, scrollable:true, width:getWidthForDataTable(), emptyMsg:"No Change History Found"}, {pagination: true, topPaginator:"topPaginatorForEquipmentsForChangeHistory"});
  var dt = eisDataTable.getDataTable();
  dt.subscribe("checkboxClickEvent", function(oArgs) {
    checkBoxClickEvent(oArgs, dt);
  });
  return eisDataTable;
}

function getChangeHistoryColumnDefs() {
  var columnDefs = [];
  this.checkboxFormatter = function(el, oRecord, oColumn, oData) {
    if (userHasEditAccessToThisProject()) {
      if (oData === "true") {
        el.innerHTML = '<input type="checkbox" id="' + oColumn.key +
                       '" onclick="handleEditableCheckboxClick(this, changeHistoryDataTable, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox" checked="true"/>';
      } else {
        el.innerHTML = '<input type="checkbox" id="' + oColumn.key +
                       '" onclick="handleEditableCheckboxClick(this, changeHistoryDataTable, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox"/>';
      }
    } else {
      if (oData === "true") {
        var contextPath = document.getElementById('contextPath').value;
        el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
      }
    }
  }
  columnDefs[columnDefs.length] = {key:"tabName", label:"Tab Name", sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"columnName", label:"Data Element", sortable:true, resizeable:true, width:150};
  columnDefs[columnDefs.length] = {key:"componentNumber", label:"Component #", sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"oldValue", label:"Previous Value", sortable:true, resizeable:true, width: 200};
  columnDefs[columnDefs.length] = {key:"newValue", label:"New Value", sortable:true, resizeable:true, width:200};
  columnDefs[columnDefs.length] = {key:"processVerified", label:"Process<br /> Verified", formatter: this.checkboxFormatter, sortable:true, resizeable:true, width:60};
  columnDefs[columnDefs.length] = {key:"mechanicalVerified", label:"Mechanical<br /> Verified", formatter: this.checkboxFormatter, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"electricalVerified", label:"Electrical<br /> Verified", formatter: this.checkboxFormatter, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"changeDateTime", label:"Date Modified", sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"auditRequestor", label:"Modified By", sortable:true, resizeable:true, width:80};
  return columnDefs;
}