var thisEquipmentId = null;
var equipmentTabs = null;
var equipmentTabIdsAlreadyClicked = "";
var changeHistoryTab = null;

function createEquipmentTabs(equipmentId) {
  thisEquipmentId = equipmentId;
  document.getElementById('equipmentId').value = equipmentId;
  if (equipmentTabs == null) {
    equipmentTabIdsAlreadyClicked = "";
    equipmentTabs = new YAHOO.widget.TabView();
    var equipmentDetailsTab = new YAHOO.widget.Tab({
      label: 'Details',
      content:  document.getElementById("equipmentDetailsTab").innerHTML,
      active: false
    });
    equipmentTabs.addTab(equipmentDetailsTab);

    var processTab = new YAHOO.widget.Tab({
      label: 'Process',
      content:  document.getElementById("processTab").innerHTML,
      active: false,
      disabled: true
    });
    equipmentTabs.addTab(processTab);

    var mechanicalTab = new YAHOO.widget.Tab({
      label: 'Mechanical',
      content:  document.getElementById("mechanicalTab").innerHTML,
      active: false,
      disabled: true
    });
    equipmentTabs.addTab(mechanicalTab);

    var electricalTab = new YAHOO.widget.Tab({
      label: 'Electrical',
      content:  document.getElementById("electricalTab").innerHTML,
      active: false,
      disabled: true
    });
    equipmentTabs.addTab(electricalTab);

    var motorTab = new YAHOO.widget.Tab({
      label: 'Motor',
      content:  document.getElementById("motorTab").innerHTML,
      active: false,
      disabled: true
    });
    equipmentTabs.addTab(motorTab);

    var instrumentTab = new YAHOO.widget.Tab({
      label: 'Instrument',
      content:  document.getElementById("instrumentTab").innerHTML,
      active: false,
      disabled: true
    });
    equipmentTabs.addTab(instrumentTab);

    var accessoriesTab = new YAHOO.widget.Tab({
      label: 'Accessory',
      content:  document.getElementById("accessoriesTab").innerHTML,
      active: false,
      disabled: true
    });
    equipmentTabs.addTab(accessoriesTab);

    var purchasingTab = new YAHOO.widget.Tab({
      label: 'Purchasing',
      content:  document.getElementById("purchasingTab").innerHTML,
      active: false,
      disabled: true
    });
    equipmentTabs.addTab(purchasingTab);

    var costScheduleTab = new YAHOO.widget.Tab({
      label: 'Cost/Schedule',
      content:  document.getElementById("costScheduleTab").innerHTML,
      active: false,
      disabled: true
    });
    equipmentTabs.addTab(costScheduleTab);

    changeHistoryTab = new YAHOO.widget.Tab({
      label: 'Change History',
      content:  document.getElementById("changeHistoryTab").innerHTML,
      active: false
    });

    equipmentTabs.on("activeTabChange", function(ev) {
      equipmentDialog.sizeUnderlay();
      var activeTabIndex = equipmentTabs.get("activeIndex");
      if (equipmentTabIdsAlreadyClicked.indexOf(activeTabIndex + ",") < 0) {
        equipmentTabIdsAlreadyClicked += activeTabIndex + ", ";
        if (ev.newValue === equipmentDetailsTab) {
          getEquipmentDetails(thisEquipmentId);
        } else
          if (ev.newValue === processTab) {
            document.getElementById("hasProcessDataChanged").value = true;
            getRefDataForProcessTab(thisEquipmentId, true);
            hideShowEquipmentTypeSpecificProcessSections(document.getElementById('equipmentTypeId'));
          } else if (ev.newValue === mechanicalTab) {
            document.getElementById("hasMechanicalDataChanged").value = true;
            getMechanicalDetails(thisEquipmentId);
          } else if (ev.newValue === motorTab) {
            document.getElementById("hasMotorsDataChanged").value = true;
            getRefDataForMotorTable(thisEquipmentId);
          } else if (ev.newValue === instrumentTab) {
            document.getElementById("hasInstrumentsDataChanged").value = true;
            getRefDataForInstrumentTable(thisEquipmentId);
          } else if (ev.newValue === electricalTab) {
            document.getElementById("hasElectricalDataChanged").value = true;
            getElectricalDetails(thisEquipmentId);
          } else if (ev.newValue === purchasingTab) {
            document.getElementById("hasPurchasingDataChanged").value = true;
            getPurchasingDetails(thisEquipmentId);
          } else if (ev.newValue === accessoriesTab) {
            document.getElementById("hasAccessoriesDataChanged").value = true;
            getRefDataForAccessoryTable(thisEquipmentId);
          } else if (ev.newValue === costScheduleTab) {
            document.getElementById("hasCostScheduledDataChanged").value = true;
            getCostScheduleDetails(thisEquipmentId);
          }
      }
       //reload the changeHistory Table when we tab in and out of it, so all changes can be displayed.
      if (ev.newValue === changeHistoryTab) {
        getChangeHistoyDataTable(thisEquipmentId);
      }
    });

    var equipmentTabsDiv = document.getElementById("equipmentTabs");
    equipmentTabsDiv.innerHTML = "";
    equipmentTabs.appendTo(equipmentTabsDiv);
  }

  var projectStatus = document.getElementById("projectStatus").value;
  if (projectStatus === 'Detailed Design' && thisEquipmentId != "") {
    equipmentTabs.addTab(changeHistoryTab);
  }
  if (projectStatus === 'Detailed Design' && thisEquipmentId === "") {
    if (equipmentTabs.getTab(9) != undefined) {
      equipmentTabs.removeTab(changeHistoryTab);
    }
  }
}

function setEquipmentDetailsTabAsActive() {
  getEquipmentDetails(document.getElementById('equipmentId').value);
  equipmentTabs.set("activeIndex", 0);
  equipmentTabIdsAlreadyClicked += "0,";
}

function setChangeHistoryTabAsActive() {
  getChangeHistoyDataTable(document.getElementById('equipmentId').value);
  equipmentTabs.set("activeIndex", 9);
  equipmentTabIdsAlreadyClicked += "9,";
}

function handleCancelOnEditEquipment() {
  setProjectTabsActiveIndex(1);
}

function resetEquipmentTabIdsAlreadyClicked() {
  equipmentTabIdsAlreadyClicked = "";
}

function fireEquipmentTabsActiveTabChangeEvent(equipmentId) {
  thisEquipmentId = equipmentId;
  var activeTabIndex = equipmentTabs.get("activeIndex");
  var activeTab = equipmentTabs.getTab(activeTabIndex);
  equipmentTabs.fireEvent("activeTabChange", {newValue:activeTab});
}

function enableDisableOtherTabsDependingOnDetails(enableTabs) {
  var equipmentAreaId = document.getElementById('equipmentAreaId').value;
  var equipmentTypeId = document.getElementById('equipmentTypeId').value;
  var processLineNumber = document.getElementById('PROCESS_LINE_NUMBER').value;
  var equipmentTagNumber = document.getElementById('EQUIPMENT_TAG_NUMBER').value;
  var equipmentName = document.getElementById('EQUIPMENT_NAME').value;
  var tabs = equipmentTabs.getAttributeConfig("tabs").value;
  var warningElement = document.getElementById('warningMsgsForEquipmentDiv');
  if (equipmentAreaId === '' || equipmentTypeId === '' || processLineNumber === '' ||
      equipmentTagNumber === '' || equipmentName === '') {
    warningElement.style.display = "";
    for (var i = 1; i < tabs.length; i++) {
      tabs[i].set("active", false);
      tabs[i].set("disabled", true);
    }
  } else {
    if (enableTabs) {
      warningElement.style.display = "none";
      for (i = 1; i < tabs.length; i++) {
        tabs[i].set("disabled", false);
      }
    }
  }
}
