var textEditableCellFormatterInstAndAcce = function(el, oRecord, oColumn, oData) {
  el.innerHTML = oData;
  if (userHasEditAccessToThisProject()) {
    var purchasedWithEquipment = oRecord.getData('purchasedWithEquipment');
    if (purchasedWithEquipment === "true") {
      YAHOO.util.Dom.removeClass(el.parentElement, "editableCell");
    } else {
      YAHOO.util.Dom.addClass(el.parentElement, "editableCell");
    }
  }
}

var currencyFormatterInstAcce = function(el, oRecord, oColumn, oData) {
    el.innerHTML = YAHOO.util.Number.format(oData, {
    prefix:"$",
    decimalPlaces:0,
    decimalSeparator:"",
    thousandsSeparator:","
    });
    if (userHasEditAccessToThisProject()) {
    var purchasedWithEquipment = oRecord.getData('purchasedWithEquipment');
    if (purchasedWithEquipment === "true") {
      YAHOO.util.Dom.removeClass(el.parentElement, "editableCell");
    } else {
      YAHOO.util.Dom.addClass(el.parentElement, "editableCell");
    }
  }
}

var dateEditableCellFormatterForInstAndAcce = function(el, oRecord, oColumn, oData) {
  var oConfig = oColumn.dateOptions || this.get("dateOptions");
  el.innerHTML = YAHOO.util.Date.format(oData, oConfig, oConfig.locale);
  if (userHasEditAccessToThisProject()) {
    var purchasedWithEquipment = oRecord.getData('purchasedWithEquipment');
    if (purchasedWithEquipment === "true") {
      YAHOO.util.Dom.removeClass(el.parentElement, "editableCell");
    } else {
      YAHOO.util.Dom.addClass(el.parentElement, "editableCell");
    }
  }
}

function onCellClickOfInstAndAcce(dt, oArgs) {
  var target = oArgs.target;
  var record = dt.getRecord(target);
  var column = dt.getColumn(target);
  var purchasedWithEquipment = record.getData('purchasedWithEquipment');
  if (purchasedWithEquipment === "true" &&
      (column.key === "vendor" || column.key === "rtpNumber" || column.key === "poNumber" ||
       column.key === "lineNumber" || column.key === "actualDeliveryDate" || column.key === "actualCost" || column.key === "estimatedCost")) {
    dt.cancelCellEditor();
  }
}

function onCheckboxClickOfInstAndAcce(dt, oArgs) {
  var oRecord = dt.getRecord(oArgs.target);
  var oColumn = dt.getColumn(oArgs.target);
  var oKey = oColumn.key;
  if (oKey === "purchasedWithEquipment") {
    addOrRemoveEditableCellClassForInst(dt, oRecord);
  }
}

function addOrRemoveEditableCellClassForInst(dt, oRecord) {
  var purchasedWithEquipment = oRecord.getData('purchasedWithEquipment');
  if (purchasedWithEquipment === "true") {
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("vendor")}), "editableCell");
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("rtpNumber")}), "editableCell");
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("poNumber")}), "editableCell");
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("lineNumber")}), "editableCell");
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("actualDeliveryDate")}), "editableCell");
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("estimatedCost")}), "editableCell");
    YAHOO.util.Dom.removeClass(dt.getTdEl({record:oRecord, column:dt.getColumn("actualCost")}), "editableCell");
  } else {
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("vendor")}), "editableCell");
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("rtpNumber")}), "editableCell");
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("poNumber")}), "editableCell");
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("lineNumber")}), "editableCell");
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("actualDeliveryDate")}), "editableCell");
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("estimatedCost")}), "editableCell");
    YAHOO.util.Dom.addClass(dt.getTdEl({record:oRecord, column:dt.getColumn("actualCost")}), "editableCell");
  }
}
