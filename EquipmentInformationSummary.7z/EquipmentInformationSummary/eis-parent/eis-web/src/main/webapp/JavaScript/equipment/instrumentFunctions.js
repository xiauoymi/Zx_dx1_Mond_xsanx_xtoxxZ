var instrumentsDataTable = null;
var designatorFirstCharArray = null;
var designatorSecondCharArray = null;
var ioTypeArray = null;
var instrumentTypeArray = null;

var designatorFirstCharIdToTypeCodeMap = {
    set : function(foo, bar) {
        this[foo] = bar;
    },
    get : function(foo) {
        return this[foo];
    }
}

var designatorSecondCharIdToTypeCodeMap = {
    set : function(foo, bar) {
        this[foo] = bar;
    },
    get : function(foo) {
        return this[foo];
    }
}

function getRefDataForInstrumentTable(equipmentId) {
    this.populateArrays = {
        success: function(o) {
            checkXMLReturnedFromAjaxCall(o, populateInstrumentRelatedFields, equipmentId)
        },
        failure: function(o) {
            document.location.href = document.getElementById('contextPath').value +
                                     "/servlet/logon?method=error";
        },
        timeout: 30000 //30 seconds
    };

    var url = document.getElementById('contextPath').value +
              "/data/equipmentRefDataXml/details?method=lookupRefDataForInstrumentXML";
    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
            url,
            this.populateArrays);
}

function populateInstrumentRelatedFields(o, equipmentId) {
    var xmlDoc = o.responseXML;
    designatorFirstCharArray = populateArrayForDropdown(xmlDoc, 'instrumentDesignatorsForFirstChar/instrumentDesignator', 'id', 'name');
    designatorSecondCharArray = populateArrayForDropdown(xmlDoc, 'instrumentDesignatorsForSecondChar/instrumentDesignator', 'id', 'name');
    ioTypeArray = populateArrayForDropdown(xmlDoc, 'ioTypes/ioType', 'id', 'name');
    instrumentTypeArray = populateArrayForDropdown(xmlDoc, 'instrumentTypes/instrumentType', 'id', 'name');
    for (var i = 0; i < designatorFirstCharArray.length; i++) {
        var instDesignatorArrayId = designatorFirstCharArray[i].value;
        var typeCodeDesc = designatorFirstCharArray[i].label;
        var typeCode = parseTypeCodeForInst(typeCodeDesc);
        designatorFirstCharIdToTypeCodeMap.set(instDesignatorArrayId, typeCode);
    }
    for (i = 0; i < designatorSecondCharArray.length; i++) {
        instDesignatorArrayId = designatorSecondCharArray[i].value;
        typeCodeDesc = designatorSecondCharArray[i].label;
        typeCode = parseTypeCodeForInst(typeCodeDesc);
        designatorSecondCharIdToTypeCodeMap.set(instDesignatorArrayId, typeCode);
    }
    createInstrumentTable(equipmentId);
}

function parseTypeCodeForInst(designatorValue) {
    var indexOfHyphen = designatorValue.indexOf(" - ");
    return designatorValue.substring(0, indexOfHyphen);
}

function getColumnDefsForInstrument() {
    var fieldArr = [];
    fieldArr[fieldArr.length] = "instrumentId";
    fieldArr[fieldArr.length] = "designatorFirstCharId";
    fieldArr[fieldArr.length] = "designatorFirstCharId";
    fieldArr[fieldArr.length] = "designatorFirstCharTypeCode";
    fieldArr[fieldArr.length] = "designatorSecondCharId";
    fieldArr[fieldArr.length] = "designatorSecondCharTypeCode";
    fieldArr[fieldArr.length] = "sequenceNumber";
    fieldArr[fieldArr.length] = "instDescription";
    fieldArr[fieldArr.length] = "manufacturer";
    fieldArr[fieldArr.length] = "modelNumber";
    fieldArr[fieldArr.length] = "ioTypeId";
    fieldArr[fieldArr.length] = "instrumentTypeId";
    fieldArr[fieldArr.length] = "alarmPoints";
    fieldArr[fieldArr.length] = "alarmPointsQuantity";
    fieldArr[fieldArr.length] = "volts";
    fieldArr[fieldArr.length] = "range";
    fieldArr[fieldArr.length] = "units";
    fieldArr[fieldArr.length] = "comments";
    fieldArr[fieldArr.length] = "bidPackage";
    fieldArr[fieldArr.length] = "purchasedWithEquipment";

    fieldArr[fieldArr.length] = "purchaseId";
    fieldArr[fieldArr.length] = "vendor";
    fieldArr[fieldArr.length] = "rtpNumber";
    fieldArr[fieldArr.length] = "poNumber";
    fieldArr[fieldArr.length] = "lineNumber";
    fieldArr[fieldArr.length] = "estimatedCost";
    fieldArr[fieldArr.length] = "actualCost";
    fieldArr[fieldArr.length] = "actualDeliveryDate";
    return fieldArr;
}

function createInstrumentTable(equipmentId) {
    var url = "/eis/data/instrumentXml/details?equipmentId=" + equipmentId;
    if (instrumentsDataTable === null) {
        this.instrumentDataSource = createServerSidePaginationDataSource(url);
        this.instrumentDataSource.responseSchema = {
            resultNode : "instrument",
            fields: getColumnDefsForInstrument(),
            metaFields: {totalRecords : "totalRecords"}
        };
        instrumentsDataTable = getInstrumentsTable(getInstrumentsColumnDefs(), this.instrumentDataSource);
    } else {
        setInstrumentsDataTableBeenModified(false);
        instrumentsDataTable.getEditableTableParams().deletedIds = [];
        instrumentsDataTable.requery(url);
    }
}

function formatInstrumentTag(oEditor) {
    var oRecord = oEditor.record;
    var oColumn = oEditor.column;
    var dt = instrumentsDataTable.getDataTable();
    var oCell = dt.getTrEl(oRecord).cells[3];//cell for tag
    if (oColumn.key === 'designatorFirstCharId' || oColumn.key === 'designatorSecondCharId' ||
        oColumn.key === 'sequenceNumber') {
        oCell.firstChild.innerHTML = createInstrumentNumber(oRecord);
    }
}

function getInstrumentsColumnDefs() {
    this.instrumentTagFormatter = function(elCell, oRecord, oColumn, oData) {
        elCell.innerHTML = createInstrumentNumber(oRecord);
    }

    this.deleteInstrumentFormatter = function(el, oRecord, oColumn, oData) {
        el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                       '/images/icon_delete.gif">';
        el.style.cursor = 'pointer';
    }

    this.instrumentCheckboxFormatter = function(el, oRecord, oColumn, oData) {
        if (userHasEditAccessToThisProject()) {
            if (oData === "true") {
                el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, instrumentsDataTable, \'' +
                               oRecord.getId() +
                               '\',\'' + oColumn.key +
                               '\')" class="yui-dt-checkbox" checked="true"/>';
            } else {
                el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, instrumentsDataTable, \'' +
                               oRecord.getId() +
                               '\',\'' + oColumn.key +
                               '\')" class="yui-dt-checkbox"/>';
            }
        } else {
            if (oData === "true") {
                var contextPath = document.getElementById('contextPath').value;
                el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
            }
        }
    }

    this.textboxEditorForInstruments = function (oEditor, oSelf) {
        textboxEditor(oEditor, instrumentsDataTable);
    }

    this.textAreaEditorForInstruments = function (oEditor, oSelf) {
        textAreaEditor(oEditor, instrumentsDataTable);
    }

    this.dropdownEditorForInstruments = function (oEditor, oSelf) {
        dropdownEditor(oEditor, instrumentsDataTable);
    }

    this.textboxEditorForInstrumentsToFormatComponentNum = function (oEditor, oSelf) {
        textboxEditor(oEditor, instrumentsDataTable, formatInstrumentTag);
    }

    this.dropdownEditorForInstrumentsToFormatComponentNum = function (oEditor, oSelf) {
        dropdownEditor(oEditor, instrumentsDataTable, formatInstrumentTag);
    }

    var className = getClassNameForEditableCell();

    return  [
        {label:"Instrument Designator", children:[
            {key:"designatorFirstCharId", label:"1<span class='required'>*</span>", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:designatorFirstCharArray, formatTag: true, table: "instruments"}) , editorOptions:{disableBtns:true, dropdownOptions:designatorFirstCharArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:120},
            {key:"designatorSecondCharId", label:"2<span class='required'>*</span>", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:designatorSecondCharArray, formatTag: true, table: "instruments"}) , editorOptions:{disableBtns:true, dropdownOptions:designatorSecondCharArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:120}
        ]},
        {key:"sequenceNumber", label:"Seq #<span class='required'>*</span>", abbr:"Sequence #", className:className,editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$',formatTag: true, table:"instruments"}),sortable:true, resizeable:true, width:50},
        {key:"tag", label:"Instrument<br/>Tag", formatter:this.instrumentTagFormatter, resizeable:true, width:120},
        {key:"instDescription", label:"Description ", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:50}), editorOptions:{disableBtns:true, maxLength:50}, formatter:commentsFormatter, sortable:true, resizeable:true, width:120},
        {key:"manufacturer", label:"Manufacturer", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, size:20, maxLength:20}), editorOptions:{disableBtns:true, maxLength:20, size:20}, sortable:true, resizeable:true, maxAutoWidth:120, width:100},
        {key:"modelNumber", label:"Model Number", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, size:30, maxLength:30}), editorOptions:{disableBtns:true, maxLength:30, size:30}, sortable:true, resizeable:true, maxAutoWidth:120, width:100},
        {key:"ioTypeId", label:"IO Type", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:ioTypeArray, formatTag: false}), editorOptions:{disableBtns:true, dropdownOptions:ioTypeArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:120},
        {key:"alarmPoints", label:"Alarm<br/>Points", className:className, editor: new YAHOO.widget.CustomTextBoxEditor({disableBtns: true, maxLength:10, size:10}), editorOptions:{disableBtns:true, maxLength:10, sixe:10}, sortable:true, resizeable:true, width:80},
        {key:"alarmPointsQuantity", label:"# of AP", abbr:"Alarm Points Quantity", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,1}$/,finalRegExp:'^\\d{1}$', maxLength:1, size: 1}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:1, size:1}, sortable:true, resizeable:true, width:50},
        //    {key:"instrumentTypeId", label:"Instrument<br/>Type", className:className, editor:dropdownEditorForInstruments, editorOptions:{disableBtns:true, dropdownOptions:instrumentTypeArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:120},
        {key:"volts", label:"Volts", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$', maxLength:3, size:3}), editorOptions:{disableBtns:true, maxLength:3, size:3, blockAlphabets:true}, sortable:true, resizeable:true, width:60},
        {key:"range", label:"Range", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, size:10, maxLength:10}), editorOptions:{disableBtns:true, maxLength:10, size:10}, sortable:true, resizeable:true, maxAutoWidth:120, width:90},
        {key:"units", label:"Units", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, size:10, maxLength:10}), editorOptions:{disableBtns:true, size:10, maxLength:10}, sortable:true, resizeable:true, width:90},
        {key:"comments", label:"Comments", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength:200}), editorOptions:{disableBtns:true, maxLength:200}, formatter:commentsFormatter, sortable:true, resizeable:true, width:200},
        {key:"bidPackage", label:"Bid<br/>Package", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength:250}), editorOptions:{disableBtns:true, maxLength:250}, formatter:commentsFormatter, sortable:true, resizeable:true, width:150},
        {key:"purchasedWithEquipment", label:"P w/E", abbr:"Purchased With Equipment", className:className, formatter: this.instrumentCheckboxFormatter, sortable:true, resizeable:true, width:50},
        {key:"vendor", label:"Vendor", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:20, size:20}), editorOptions:{disableBtns:true, maxLength:20, size:20}, sortable:true, resizeable:true, width:80},
        {key:"rtpNumber", label:"RTP Number", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,8}$/,finalRegExp:'^\\d{8}$'}), sortable:true, resizeable:true, width:80},
        {key:"poNumber", label:"PO Number", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,10}$/,finalRegExp:'^\\d{10}$'}), sortable:true, resizeable:true, width:90},
        {key:"lineNumber", label:"Line Item", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$'}), sortable:true, resizeable:true, width:80},
        {key:"actualDeliveryDate", label:"Delivery<br/>Date", formatter:dateEditableCellFormatterForInstAndAcce, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100},

        {key:"estimatedCost", label:"Estimated<br/>Cost", formatter:currencyFormatterInstAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,5}$/,finalRegExp:'^\\d{5}$'}), sortable:true, resizeable:true, width:80},
        {key:"actualCost", label:"Actual<br/>Cost", formatter:currencyFormatterInstAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,5}$/,finalRegExp:'^\\d{5}$'}), sortable:true, resizeable:true, width:80},
        {key:"delete", label:"Delete", formatter:this.deleteInstrumentFormatter, width:50}
    ];
}

function getInstrumentsTable(columnDefs, dataSource) {
    var editableTableParams = null;
    if (userHasEditAccessToThisProject()) {
        editableTableParams = {};
        editableTableParams.firstEditableColumnIndex = 0;
        editableTableParams.lastEditableColumnIndex = 22;
        editableTableParams.newRecord = getNewInstrumentRecord();
        editableTableParams.showSaveWarning = true;
        editableTableParams.keyForDeletedId = "instrumentId";
        editableTableParams.deletedIds = [];
    }
    instrumentsDataTable = createEditableDataTable("instrumentsList", columnDefs, dataSource, "designatorFirstCharId", {initialLoad:true,
        scrollable:true, width: getWidthForDataTable('equipmentDivForDialog'), draggableColumns:true},
    {pagination:true, topPaginator:'topPaginatorForInstruments'}, {editableTableParams:editableTableParams});

    if (userHasEditAccessToThisProject()) {
        var dt = instrumentsDataTable.getDataTable();
        dt.subscribe("renderEvent", function() {
            document.getElementById('addInstrumentBtn').disabled = '';
        });
        //make instrument's purchasing columns non-editable if purchased with equipment is checked
        dt.subscribe('cellClickEvent', function (oArgs) {
            onCellClickOfInstAndAcce(dt, oArgs);
        });
        dt.subscribe('checkboxClickEvent', function(oArgs) {
            onCheckboxClickOfInstAndAcce(dt, oArgs);
        });
    }

    return instrumentsDataTable;
}

function setInstrumentsDataTableBeenModified(boolValue) {
    if (instrumentsDataTable != null) {
        var params = instrumentsDataTable.getEditableTableParams();
        params.hasDataTableBeenModified = boolValue;
    }
}

function addNewInstrumentRow() {
    addNewRowToDataTable(instrumentsDataTable);
}

function getNewInstrumentRecord() {
    return {
        instrumentId:"",
        designatorFirstCharId:"",
        designatorFirstCharTypeCode:"",
        designatorSecondCharId:"",
        designatorSecondCharTypeCode:"",
        sequenceNumber:"",
        tag:"",
        instDescription:"",
        manufacturer:"",
        modelNumber:"",
        ioTypeId:"",
        alarmPoints:"",
        alarmPointsQuantity:"",
        instrumentTypeId:"",
        volts:"",
        range:"",
        units:"",
        comments:"",
        bidPackage:"",
        purchasedWithEquipment:"",
        purchaseId:"",
        vendor:"",
        rtpNumber:"",
        poNumber:"",
        lineNumber:"",
        estimatedCost:"",
        actualCost:"",
        actualDeliveryDate:""
    };
}

function resetInstrumentTable() {
    if (instrumentsDataTable != null) {
        var dt = instrumentsDataTable.getDataTable();
        dt.getRecordSet().reset();
    }
}

function createHiddenFieldsForInstruments() {
    var addEquipmentForm = document.getElementById("addEquipmentForm");
    if (instrumentsDataTable != null) {
        var dt = instrumentsDataTable.getDataTable();
        for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
            var data = dt.getRecordSet().getRecord(i).getData();
            var instrumentId = getEmptyStringIfUndefined(data.instrumentId);
            var purchaseId = getEmptyStringIfUndefined(data.purchaseId);
            var designatorFirstCharId = getEmptyStringIfUndefined(data.designatorFirstCharId);
            var designatorSecondCharId = getEmptyStringIfUndefined(data.designatorSecondCharId);
            var sequenceNumber = getEmptyStringIfUndefined(data.sequenceNumber);
            var description = getEmptyStringIfUndefined(data.instDescription);
            var ioTypeId = getEmptyStringIfUndefined(data.ioTypeId);
            var alarmPoints = getEmptyStringIfUndefined(data.alarmPoints);
            var alarmPointsQuantity = getEmptyStringIfUndefined(data.alarmPointsQuantity);
            var instrumentTypeId = getEmptyStringIfUndefined(data.instrumentTypeId);
            var volts = getEmptyStringIfUndefined(data.volts);
            var range = getEmptyStringIfUndefined(data.range);
            var units = getEmptyStringIfUndefined(data.units);
            var comments = getEmptyStringIfUndefined(data.comments);
            var bidPackage = getEmptyStringIfUndefined(data.bidPackage);
            var manufacturer = getEmptyStringIfUndefined(data.manufacturer);
            var modelNumber = getEmptyStringIfUndefined(data.modelNumber);
            var purchasedWithEquipment = getEmptyStringIfUndefined(data.purchasedWithEquipment);
            var vendor = getEmptyStringIfUndefined(data.vendor);
            var rtpNumber = getEmptyStringIfUndefined(data.rtpNumber);
            var poNumber = getEmptyStringIfUndefined(data.poNumber);
            var lineNumber = getEmptyStringIfUndefined(data.lineNumber);
            var estimatedCost = getEmptyStringIfUndefined(data.estimatedCost);
            var actualCost = getEmptyStringIfUndefined(data.actualCost);
            var actualDeliveryDate = formatDateForSaving(data.actualDeliveryDate);
            addEquipmentForm.appendChild(createHiddenField("instrumentId", instrumentId));
            addEquipmentForm.appendChild(createHiddenField("instPurchaseId", purchaseId));
            addEquipmentForm.appendChild(createHiddenField("designatorFirstCharId", designatorFirstCharId));
            addEquipmentForm.appendChild(createHiddenField("designatorSecondCharId", designatorSecondCharId));
            addEquipmentForm.appendChild(createHiddenField("instSequenceNumber", sequenceNumber));
            addEquipmentForm.appendChild(createHiddenField("instDescription", description));
            addEquipmentForm.appendChild(createHiddenField("instManufacturer", manufacturer));
            addEquipmentForm.appendChild(createHiddenField("instModelNumber", modelNumber));
            addEquipmentForm.appendChild(createHiddenField("ioTypeId", ioTypeId));
            addEquipmentForm.appendChild(createHiddenField("alarmPoints", alarmPoints));
            addEquipmentForm.appendChild(createHiddenField("alarmPointsQuantity", alarmPointsQuantity));
            addEquipmentForm.appendChild(createHiddenField("instrumentTypeId", instrumentTypeId));
            addEquipmentForm.appendChild(createHiddenField("instVolts", volts));
            addEquipmentForm.appendChild(createHiddenField("instRange", range));
            addEquipmentForm.appendChild(createHiddenField("instUnits", units));
            addEquipmentForm.appendChild(createHiddenField("instComments", comments));
            addEquipmentForm.appendChild(createHiddenField("instBidPackage", bidPackage));
            addEquipmentForm.appendChild(createHiddenField("instPurchasedWithEquip", purchasedWithEquipment));
            addEquipmentForm.appendChild(createHiddenField("instVendor", vendor));
            addEquipmentForm.appendChild(createHiddenField("instRtpNumber", rtpNumber));
            addEquipmentForm.appendChild(createHiddenField("instPoNumber", poNumber));
            addEquipmentForm.appendChild(createHiddenField("instLineNumber", lineNumber));
            addEquipmentForm.appendChild(createHiddenField("instEstimatedCost", estimatedCost));
            addEquipmentForm.appendChild(createHiddenField("instActualCost", actualCost));
            addEquipmentForm.appendChild(createHiddenField("instActualDeliveryDate", actualDeliveryDate));
        }
    }
}

function removeHiddenFieldsForInstruments() {
    var addEquipmentForm = document.getElementById("addEquipmentForm");
    removeHiddenFields(addEquipmentForm, "instrumentId");
    removeHiddenFields(addEquipmentForm, "instPurchaseId");
    removeHiddenFields(addEquipmentForm, "designatorFirstCharId");
    removeHiddenFields(addEquipmentForm, "designatorSecondCharId");
    removeHiddenFields(addEquipmentForm, "instSequenceNumber");
    removeHiddenFields(addEquipmentForm, "instDescription");
    removeHiddenFields(addEquipmentForm, "instManufacturer");
    removeHiddenFields(addEquipmentForm, "instModelNumber");
    removeHiddenFields(addEquipmentForm, "ioTypeId");
    removeHiddenFields(addEquipmentForm, "alarmPoints");
    removeHiddenFields(addEquipmentForm, "alarmPointsQuantity");
    removeHiddenFields(addEquipmentForm, "instrumentTypeId");
    removeHiddenFields(addEquipmentForm, "instVolts");
    removeHiddenFields(addEquipmentForm, "instRange");
    removeHiddenFields(addEquipmentForm, "instUnits");
    removeHiddenFields(addEquipmentForm, "instComments");
    removeHiddenFields(addEquipmentForm, "instBidPackage");
    removeHiddenFields(addEquipmentForm, "instPurchasedWithEquip");
    removeHiddenFields(addEquipmentForm, "instVendor");
    removeHiddenFields(addEquipmentForm, "instRtpNumber");
    removeHiddenFields(addEquipmentForm, "instPoNumber");
    removeHiddenFields(addEquipmentForm, "instLineNumber");
    removeHiddenFields(addEquipmentForm, "instEstimatedCost");
    removeHiddenFields(addEquipmentForm, "instActualCost");
    removeHiddenFields(addEquipmentForm, "instActualDeliveryDate");
    removeHiddenFields(addEquipmentForm, "deletedInstrumentIds");
}

function createInstrumentNumber(oRecord) {
    var designatorFirstCharId = oRecord.getData('designatorFirstCharId');
    var designatorSecondCharId = oRecord.getData('designatorSecondCharId');
    var firstDesignatorTypeCode = designatorFirstCharIdToTypeCodeMap.get(designatorFirstCharId);
    var secondDesignatorTypeCode = designatorSecondCharIdToTypeCodeMap.get(designatorSecondCharId);
    var sequenceNumber = oRecord.getData('sequenceNumber');
    return getFirst5CharsOfEquipNum() + firstDesignatorTypeCode + secondDesignatorTypeCode + sequenceNumber;
}

function createHiddenFieldForDeletedInstrumentIds() {
    var deletedInstrumentIdsStr = "";
    var deletedIds = instrumentsDataTable.getEditableTableParams().deletedIds;
    for (var i = 0; i < deletedIds.length; i++) {
        var deletedId = deletedIds[i];
        deletedInstrumentIdsStr += deletedId + ",";
    }
    var addEquipmentForm = document.getElementById("addEquipmentForm");
    addEquipmentForm.appendChild(createHiddenField("deletedInstrumentIds", deletedInstrumentIdsStr));
}