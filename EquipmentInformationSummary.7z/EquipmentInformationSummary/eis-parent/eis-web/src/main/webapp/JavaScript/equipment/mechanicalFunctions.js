var bidPackWorkDescTable = null;

function getMechanicalDetails(equipmentId) {
  if (equipmentId != "") {
    var url = document.getElementById('contextPath').value
        + '/data/equipment/details?method=lookupMechanicalXml&equipmentId=' + equipmentId;
      document.body.style.cursor = 'progress';
    var callbackAfterGettingMechanicalDetails = {
      success: function(o) {
        this.cache = null;
        checkXMLReturnedFromAjaxCall(o, populateMechanicalDetails);
//        if (o.responseText == '' || o.responseText == null) {
//          document.location.href = document.getElementById('contextPath').value +
//                                   "/servlet/logon?method=error";
//        } else {
//          populateMechanicalDetails(o);
//        }
          document.body.style.cursor = 'default';
      }
      ,
      failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
      }
      ,
      cache:false
    }
    this.getXML = YAHOO.util.Connect.asyncRequest('GET', url, callbackAfterGettingMechanicalDetails);
  } 
}

function populateMechanicalDetails(o) {
  var xmlDoc = o.responseXML;
  var mechanicalId = xmlDoc.getElementsByTagName("mechId")[0].text;
  var engineer = xmlDoc.getElementsByTagName("engineer")[0].text;
  var modelNumber = xmlDoc.getElementsByTagName("modelNumber")[0].text;
  var shippingWeight = xmlDoc.getElementsByTagName("shippingWeight")[0].text;

  var purchaseScopeId = xmlDoc.getElementsByTagName("purchaseScopeId")[0].text;
  var purchaseScopeName = xmlDoc.getElementsByTagName("purchaseScopeName")[0].text;

  var operatingWeight = xmlDoc.getElementsByTagName("operatingWeight")[0].text;
  var dynamicLoad = xmlDoc.getElementsByTagName("dynamicLoad")[0].text;
  var serialNumber = xmlDoc.getElementsByTagName("serialNumber")[0].text;
  var bidPackageOne = xmlDoc.getElementsByTagName("bidPackageOne")[0].text;
  var workDescriptionOne = xmlDoc.getElementsByTagName("workDescriptionOne")[0].text;
  var bidPackageTwo = xmlDoc.getElementsByTagName("bidPackageTwo")[0].text;
  var workDescriptionTwo = xmlDoc.getElementsByTagName("workDescriptionTwo")[0].text;

  document.getElementById('mechanicalId').value = mechanicalId;
  updateTextField('engineer', engineer);
  updateTextField('modelNumber', modelNumber);
  updateTextField('shippingWeight', shippingWeight);

  var purchaseScopes = document.getElementById('purchaseScope');
  setSelectedInDropdown(purchaseScopes, purchaseScopeId);
  updateSelectField('purchaseScope', purchaseScopeId);

  updateTextField('operatingWeight', operatingWeight);
  updateTextField('dynamicLoad', dynamicLoad);
  updateTextField('serialNumber', serialNumber);
  updateTextField('bidPackageOne', bidPackageOne);
  updateTextField('workDescriptionOne', workDescriptionOne);
  updateTextField('bidPackageTwo', bidPackageTwo);
  updateTextField('workDescriptionTwo', workDescriptionTwo);
}






