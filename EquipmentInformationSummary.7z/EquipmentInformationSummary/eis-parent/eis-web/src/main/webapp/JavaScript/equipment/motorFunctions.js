var motorsDataTable = null;
var motorsDataTableForAdd = null;
var designStatusArray = null;
var loadValueTypeArray = null;
var compDesignatorArray = null;

var compDesignatorIdToTypeCodeMap = {
  set : function(foo, bar) {
    this[foo] = bar;
  },
  get : function(foo) {
    return this[foo];
  }
}

function getRefDataForMotorTable(equipmentId) {
  this.populateArrays = {
    success: function(o) {
      //      var xmlDoc = o.responseXML;
      //      designStatusArray = populateArrayForDropdown(xmlDoc, 'designStatuses/designStatus', 'id', 'name');
      //      loadValueTypeArray = populateArrayForDropdown(xmlDoc, 'loadValueTypes/loadValueType', 'id', 'name');
      //      compDesignatorArray = populateArrayForDropdown(xmlDoc, 'componentDesignators/componentDesignator', 'id', 'name');
      //      createMotorTable(equipmentId);
      checkXMLReturnedFromAjaxCall(o, populateMotorRelatedData, equipmentId);
    },
    failure: function(o) {
      document.location.href = document.getElementById('contextPath').value +
                               "/servlet/logon?method=error";
    },
    timeout: 30000 //30 seconds
  };

  var url = document.getElementById('contextPath').value + "/data/equipmentRefDataXml/details?method=lookupRefDataForMotorXML";
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url,
      this.populateArrays);
}

function populateMotorRelatedData(o, equipmentId) {
  var xmlDoc = o.responseXML;
  designStatusArray = populateArrayForDropdown(xmlDoc, 'designStatuses/designStatus', 'id', 'name');
  loadValueTypeArray = populateArrayForDropdown(xmlDoc, 'loadValueTypes/loadValueType', 'id', 'name');
  compDesignatorArray = populateArrayForDropdown(xmlDoc, 'componentDesignators/componentDesignator', 'id', 'name');
  for (var i = 0; i < compDesignatorArray.length; i++) {
    var compDesignatorId = compDesignatorArray[i].value;
    var typeCodeDesc = compDesignatorArray[i].label;
    var typeCode = parseTypeCodeForMotor(typeCodeDesc);
    compDesignatorIdToTypeCodeMap.set(compDesignatorId, typeCode);
  }
  createMotorTable(equipmentId);
}

function parseTypeCodeForMotor(designatorValue) {
  var indexOfHyphen = designatorValue.indexOf(" - ");
  return designatorValue.substring(0, indexOfHyphen);
}

function getColumnDefsForMotor() {
  var fieldArr = [];
  fieldArr[fieldArr.length] = "motorId";
  fieldArr[fieldArr.length] = "componentDesignatorTypeCode";
  fieldArr[fieldArr.length] = "componentDesignatorId";
  fieldArr[fieldArr.length] = "sequenceNumber";
  fieldArr[fieldArr.length] = "componentNumber";
  fieldArr[fieldArr.length] = "componentName";
  fieldArr[fieldArr.length] = "fla";
  fieldArr[fieldArr.length] = "motorVoltage";
  fieldArr[fieldArr.length] = "phase";
  fieldArr[fieldArr.length] = "frequency";
  fieldArr[fieldArr.length] = "rpm";
  fieldArr[fieldArr.length] = "designStatusId";
  fieldArr[fieldArr.length] = "comments";
  fieldArr[fieldArr.length] = "loadValueTypeId";
  fieldArr[fieldArr.length] = "loadValueQuantity";
  fieldArr[fieldArr.length] = "powerSource";
  fieldArr[fieldArr.length] = "ioCabinet";
  fieldArr[fieldArr.length] = "loadDisconnectRequired";
  fieldArr[fieldArr.length] = "starterSize";
  fieldArr[fieldArr.length] = "motorBrake";
  fieldArr[fieldArr.length] = "bidPackage";
  return fieldArr;
}

function createMotorTable(equipmentId) {
  if (motorsDataTableForAdd != null) {
    //clear it.
    motorsDataTableForAdd.getRecordSet().reset();
    motorsDataTableForAdd.render();
  }
  var url = "/eis/data/motorXml/details?equipmentId=" + equipmentId;
  if (motorsDataTable === null) {
    this.motorsDataSource = createServerSidePaginationDataSource(url);
    this.motorsDataSource.responseSchema = {
      resultNode : "motor",
      fields: getColumnDefsForMotor(),
      metaFields: {totalRecords : "totalRecords"}
    };
    motorsDataTable = getMotorsTable(getMotorsColumnDefs(), this.motorsDataSource);
  } else {
    setMotorsDataTableBeenModified(false);
    motorsDataTable.getEditableTableParams().deletedIds = [];
    motorsDataTable.requery(url);
  }
}

function setMotorsDataTableBeenModified(boolValue) {
  if (motorsDataTable != null) {
    var params = motorsDataTable.getEditableTableParams();
    params.hasDataTableBeenModified = boolValue;
  }
}
//function createMotorTableForAdd() {
//  this.motorsDataSource = new YAHOO.util.DataSource([]);
//  this.motorsDataSource.responseType = YAHOO.util.DataSource.TYPE_JSARRAY;
//  this.motorsDataSource.responseSchema = {
//    resultNode : "motor",
//    fields: getColumnDefsForMotor()
//  };
//  motorsDataTableForAdd = getMotorsTableForAdd(getMotorsColumnDefs(), this.motorsDataSource);
//}

function formatComponentNumber(oEditor) {
  var oRecord = oEditor.record;
  var oColumn = oEditor.column;
  var dt = motorsDataTable.getDataTable();
  var oCell = dt.getTrEl(oRecord).cells[2];//cell for component number
  if (oColumn.key === 'componentDesignatorId' || oColumn.key === 'sequenceNumber') {
    oCell.firstChild.innerHTML = createComponentNumber(oRecord);
  }
}

function getMotorsColumnDefs() {

  this.motorComponentNumberFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = createComponentNumber(oRecord);
  }

  this.motorCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (userHasEditAccessToThisProject()) {
      if (oData === "true") {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, motorsDataTable, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox" checked="true"/>';
      } else {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, motorsDataTable, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox"/>';
      }
    } else {
      if (oData === "true") {
        var contextPath = document.getElementById('contextPath').value;
        el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
      }
    }
  }

  this.deleteMotorFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }


  this.textboxEditorForMotors = function (oEditor, oSelf) {
    textboxEditor(oEditor, motorsDataTable, formatComponentNumber);
  }

  this.textBoxEditorForPhInMotors = function (oEditor, oSelf){
    textboxEditor(oEditor, motorsDataTable, formatComponentNumber);
    var oRecord = oEditor.record;
    var oColumn = oEditor.column;
    var value = oRecord.getData(oColumn.key);
    if(value === undefined || value === ''){
    oRecord.setData(oColumn.key, "3");
    }
  }
     this.textBoxEditorForVoltInMotors = function (oEditor, oSelf){
    textboxEditor(oEditor, motorsDataTable, formatComponentNumber);
    var oRecord = oEditor.record;
    var oColumn = oEditor.column;
    var value = oRecord.getData(oColumn.key);
    if(value === undefined || value === ''){
    oRecord.setData(oColumn.key, "460");
    }
  }

   this.textBoxEditorForFreqInMotors = function (oEditor, oSelf){
    textboxEditor(oEditor, motorsDataTable, formatComponentNumber);
    var oRecord = oEditor.record;
    var oColumn = oEditor.column;
    var value = oRecord.getData(oColumn.key);
    if(value === undefined || value === ''){
    oRecord.setData(oColumn.key, "60");
    }
  }


  this.textAreaEditorForMotors = function (oEditor, oSelf) {
    textAreaEditor(oEditor, motorsDataTable, formatComponentNumber);
  }
  this.dropdownEditorForMotors = function (oEditor, oSelf) {
    dropdownEditor(oEditor, motorsDataTable, formatComponentNumber);
  }

  this.textboxEditorForMotorsToFormatComponentNum = function (oEditor, oSelf) {
    textboxEditor(oEditor, motorsDataTable, formatComponentNumber);
  }
  this.dropdownEditorForMotorsToFormatComponentNum = function (oEditor, oSelf) {
    dropdownEditor(oEditor, motorsDataTable, formatComponentNumber);
  }

  var className = getClassNameForEditableCell();
  return  [
    {key:"componentDesignatorId", label:"Designator<span class='required'>*</span>", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:compDesignatorArray, formatTag: true, table: "motors"}),editorOptions:{disableBtns:true, dropdownOptions:compDesignatorArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:80},
    {key:"sequenceNumber", label:"Seq #<span class='required'>*</span>", abbr:"Sequence Number", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true, regExp:/^\d{0,2}$/, finalRegExp:'^\\d{2}$',formatTag: true, table:"motors",size:2, maxLength:2}), editorOptions:{disableBtns:true, blockAlphabets:true, size:2, maxLength:2}, sortable:true, resizeable:true, width:50},
    {key:"componentNumber", label:"Component #", formatter: this.motorComponentNumberFormatter, resizeable:true, width:100},
    {key:"componentName", label:"Component<br/>Name", className:className, editor:new YAHOO.widget.TextboxCellEditor({disableBtns:true, maxLength:30}),editorOptions:{disableBtns:true, maxLength:30},  sortable:true, resizeable:true, width:100},
    {key:"loadValueQuantity", label:"Load", abbr:"Load Value Quantity", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,4}(?:\.\d{0,2})?$/,finalRegExp:'^\\d{4}.\\d{2}$', maxLength:7, size:7, wholeNumSize:4, precision:2}), sortable:true, resizeable:true, width:60},
    {key:"loadValueTypeId", label:"Load<br/>Units", abbr:"Load Units", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:loadValueTypeArray}),  editorOptions:{disableBtns:true, dropdownOptions:loadValueTypeArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:50},
    {key:"fla", label:"FLA", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true, regExp:/^\d{0,3}(?:\.\d{0,1})?$/,finalRegExp:'^\\d{3}.\\d{1}$', maxLength:5, size:5, wholeNumSize:3, precision:1}), sortable:true, resizeable:true, width:40},
    {key:"motorVoltage", label:"Volt", abbr:"Motor Voltage", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,4}$/,finalRegExp:'^\\d{4}$'}),sortable:true, resizeable:true, width:40},
    {key:"phase", label:"Ph", abbr:"Phase", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true, regExp:/^\d{0,1}$/,finalRegExp:'^\\d{1}$', maxLength:1, size:1}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:1, size:1}, sortable:true, resizeable:true, width:30},
    {key:"frequency", label:"Freq", abbr:"Frequency", className:className, editor: new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$',maxLength:2, size:2}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:40},
    {key:"rpm", label:"RPM", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,4}$/,finalRegExp:'^\\d{4}$',maxLength:4, size:4}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:4, size:4}, sortable:true, resizeable:true, width:40},
    {key:"designStatusId", label:"Design<br/>Status", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:designStatusArray}), editorOptions:{disableBtns:true, dropdownOptions:designStatusArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:60},
    {key:"comments", label:"Comments", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength:200}), editorOptions:{disableBtns:true, maxLength:200}, formatter:commentsFormatter, sortable:true, resizeable:true, maxAutoWidth:120, width:80},
    {key:"powerSource", label:"Power<br/>Source", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:10, size: 10}), editorOptions:{disableBtns:true, maxLength:10}, sortable:true, resizeable:true, width:60},
    {key:"ioCabinet", label:"IO Cabinet", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:10, size: 10}), editorOptions:{disableBtns:true, maxLength:10}, sortable:true, resizeable:true, width:80},
    {key:"loadDisconnectRequired", label:"LDR", className:className, abbr:"Load Disconnect Required", formatter: this.motorCheckboxFormatter, sortable:true, resizeable:true, width:40},
    {key:"starterSize", label:"Size", className:className, abbr:"Starter Size", editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:4, size: 4}), editorOptions:{disableBtns:true, maxLength:4, size:4}, sortable:true, resizeable:true, width:50},
    {key:"motorBrake", label:"Motor<br/>Brake", className:className, formatter: this.motorCheckboxFormatter, sortable:true, resizeable:true, width:50},
    {key:"bidPackage", label:"Bid<br/>Package", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength:200}), editorOptions:{disableBtns:true, maxLength:200}, formatter:commentsFormatter, sortable:true, resizeable:true, maxAutoWidth:250, width:80},
    {key:"delete", label:"Delete", formatter:this.deleteMotorFormatter, width:50}
  ];
}

function getMotorsTable(columnDefs, dataSource) {
  if (userHasEditAccessToThisProject()) {
    var editableTableParams = null;
    editableTableParams = {};
    editableTableParams.firstEditableColumnIndex = 0;
    editableTableParams.lastEditableColumnIndex = 18;
    editableTableParams.newRecord = getNewMotorRecord();
    editableTableParams.showSaveWarning = true;
    editableTableParams.keyForDeletedId = "motorId";
    editableTableParams.deletedIds = [];
  }
  motorsDataTable = createEditableDataTable("motorsList", columnDefs, dataSource, "componentName", {initialLoad:true,
    scrollable:true, width: getWidthForDataTable('equipmentDivForDialog'), draggableColumns:true},
  {pagination:true, topPaginator:'topPaginatorForMotors'}, {editableTableParams:editableTableParams});
  if (userHasEditAccessToThisProject()) {
    var dt = motorsDataTable.getDataTable();
    dt.subscribe("renderEvent", function() {
      document.getElementById('addMotorBtn').disabled = '';
    });
  }

  return motorsDataTable;
}

//function getMotorsTableForAdd(columnDefs, dataSource) {
//  if (userHasEditAccessToThisProject()) {
//    var editableTableParams = null;
//    editableTableParams = {};
//    editableTableParams.firstEditableColumnIndex = 0;
//    editableTableParams.lastEditableColumnIndex = 16;
//    editableTableParams.newRecord = getNewMotorRecord();
//    editableTableParams.deletedIdsFnc = addToDeletedMotorIds;
//  }
//  motorsDataTableForAdd = createEditableDataTable("motorsListForAdd", columnDefs, dataSource, "componentName", {initialLoad:true,
//    scrollable:true, width: getWidthForDataTable('equipmentDivForDialog'), draggableColumns:true},
//  {pagination:false}, editableTableParams);
//  if (userHasEditAccessToThisProject()) {
//    motorsDataTableForAdd.subscribe("renderEvent", function() {
//      //      addNewRowToDataTable(motorsDataTableForAdd);
//    });
//  }
//
//  return motorsDataTableForAdd;
//}

function addNewMotorRow() {
  //  if (motorsDataTableForAdd == null) {
  //    createMotorTableForAdd();
  //  }
  //  addNewRowToDataTable(motorsDataTableForAdd);
  addNewRowToDataTable(motorsDataTable);
}

function getNewMotorRecord() {
    var frequencyDefault = "";
    if (document.getElementById("projectUnitMeasure").value === 'English'){
        frequencyDefault = "60";
    }else{
        frequencyDefault = "50";
    }
  return {
    motorId:"",
    componentDesignatorId:"",
    componentDesignatorTypeCode:"",
    sequenceNumber:"",
    componentName:"",
    componentNumber:"",
    fla:"",
    motorVoltage:"460",
    phase:"3",
    frequency:frequencyDefault,
    rpm:"",
    designStatusId:"205",//205 is the id for "Preliminary"
    comments:"",
    loadValueTypeId:"",
    loadValueQuantity:"",
    powerSource:"",
    ioCabinet:"",
    loadDisconnectRequired:"",
    starterSize:"",
    motorBrake:"",
    bidPackage:""
  };
}

function createComponentNumber(oRecord) {
  var componentDesignatorId = oRecord.getData('componentDesignatorId');
  var componentDesignatorTypeCode = compDesignatorIdToTypeCodeMap.get(componentDesignatorId);
  var sequenceNumber = oRecord.getData('sequenceNumber');
  return getFirst5CharsOfEquipNum() + componentDesignatorTypeCode + sequenceNumber;
}

function resetMotorTable() {
  if (motorsDataTable != null) {
    var dt = motorsDataTable.getDataTable();
    dt.getRecordSet().reset();
  }
}

function createHiddenFieldsForMotors() {
  if (motorsDataTable != null) {
    createHiddenFieldsForMotorTable(motorsDataTable);
  }
  if (motorsDataTableForAdd != null) {
    createHiddenFieldsForMotorTable(motorsDataTableForAdd);
  }
}

function createHiddenFieldsForMotorTable(motorsDataTable) {
  var addEquipmentForm = document.getElementById("addEquipmentForm");
  var dt = motorsDataTable.getDataTable();
  for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
    var data = dt.getRecordSet().getRecord(i).getData();
    var motorId = getEmptyStringIfUndefined(data.motorId);
    var componentDesignatorId = getEmptyStringIfUndefined(data.componentDesignatorId);
    var sequenceNumber = getEmptyStringIfUndefined(data.sequenceNumber);
    var componentNumber = getEmptyStringIfUndefined(data.componentNumber);
    var componentName = getEmptyStringIfUndefined(data.componentName);
    var fla = getEmptyStringIfUndefined(data.fla);
    var motorVoltage = getEmptyStringIfUndefined(data.motorVoltage);
    var phase = getEmptyStringIfUndefined(data.phase);
    var frequency = getEmptyStringIfUndefined(data.frequency);
    var rpm = getEmptyStringIfUndefined(data.rpm);
    var designStatusId = getEmptyStringIfUndefined(data.designStatusId);
    var comments = getEmptyStringIfUndefined(data.comments);
    var loadValueTypeId = getEmptyStringIfUndefined(data.loadValueTypeId);
    var loadValueQuantity = getEmptyStringIfUndefined(data.loadValueQuantity);
    var powerSource = getEmptyStringIfUndefined(data.powerSource);
    var ioCabinet = getEmptyStringIfUndefined(data.ioCabinet);
    var loadDisconnectRequired = getEmptyStringIfUndefined(data.loadDisconnectRequired);
    var starterSize = getEmptyStringIfUndefined(data.starterSize);
    var motorBrake = getEmptyStringIfUndefined(data.motorBrake);
    var bidPackage = getEmptyStringIfUndefined(data.bidPackage);
    addEquipmentForm.appendChild(createHiddenField("motorId", motorId));
    addEquipmentForm.appendChild(createHiddenField("componentDesignatorId", componentDesignatorId));
    addEquipmentForm.appendChild(createHiddenField("motorSequenceNumber", sequenceNumber));
    addEquipmentForm.appendChild(createHiddenField("componentNumber", componentNumber));
    addEquipmentForm.appendChild(createHiddenField("componentName", componentName));
    addEquipmentForm.appendChild(createHiddenField("fla", fla));
    addEquipmentForm.appendChild(createHiddenField("motorVoltage", motorVoltage));
    addEquipmentForm.appendChild(createHiddenField("phase", phase));
    addEquipmentForm.appendChild(createHiddenField("frequency", frequency));
    addEquipmentForm.appendChild(createHiddenField("rpm", rpm));
    addEquipmentForm.appendChild(createHiddenField("designStatusId", designStatusId));
    addEquipmentForm.appendChild(createHiddenField("motorComments", comments));
    addEquipmentForm.appendChild(createHiddenField("loadValueTypeId", loadValueTypeId));
    addEquipmentForm.appendChild(createHiddenField("loadValueQuantity", loadValueQuantity));
    addEquipmentForm.appendChild(createHiddenField("powerSource", powerSource));
    addEquipmentForm.appendChild(createHiddenField("ioCabinet", ioCabinet));
    addEquipmentForm.appendChild(createHiddenField("loadDisconnectRequired", loadDisconnectRequired));
    addEquipmentForm.appendChild(createHiddenField("starterSize", starterSize));
    addEquipmentForm.appendChild(createHiddenField("motorBrake", motorBrake));
    addEquipmentForm.appendChild(createHiddenField("bidPackage", bidPackage));
  }
}

function removeHiddenFieldsForMotors() {
  var addEquipmentForm = document.getElementById("addEquipmentForm");
  removeHiddenFields(addEquipmentForm, "motorId");
  removeHiddenFields(addEquipmentForm, "componentDesignatorId");
  removeHiddenFields(addEquipmentForm, "motorSequenceNumber");
  removeHiddenFields(addEquipmentForm, "componentNumber");
  removeHiddenFields(addEquipmentForm, "componentName");
  removeHiddenFields(addEquipmentForm, "fla");
  removeHiddenFields(addEquipmentForm, "motorVoltage");
  removeHiddenFields(addEquipmentForm, "phase");
  removeHiddenFields(addEquipmentForm, "frequency");
  removeHiddenFields(addEquipmentForm, "rpm");
  removeHiddenFields(addEquipmentForm, "designStatusId");
  removeHiddenFields(addEquipmentForm, "motorComments");
  removeHiddenFields(addEquipmentForm, "loadValueTypeId");
  removeHiddenFields(addEquipmentForm, "loadValueQuantity");
  removeHiddenFields(addEquipmentForm, "powerSource");
  removeHiddenFields(addEquipmentForm, "ioCabinet");
  removeHiddenFields(addEquipmentForm, "loadDisconnectRequired");
  removeHiddenFields(addEquipmentForm, "starterSize");
  removeHiddenFields(addEquipmentForm, "motorBrake");
  removeHiddenFields(addEquipmentForm, "bidPackage");

  removeHiddenFields(addEquipmentForm, "deletedMotorIds");
}

function createHiddenFieldForDeletedMotorIds() {
  var deletedMotorIdsStr = "";
  var deletedIds = motorsDataTable.getEditableTableParams().deletedIds;
  for (var i = 0; i < deletedIds.length; i++) {
    var deletedId = deletedIds[i];
    deletedMotorIdsStr += deletedId + ",";
  }
  var addEquipmentForm = document.getElementById("addEquipmentForm");
  addEquipmentForm.appendChild(createHiddenField("deletedMotorIds", deletedMotorIdsStr));
}