function hideShowEquipmentTypeSpecificProcessSections(element) {
  var text = element[element.selectedIndex].text;
  var typeCode = element.value === '' ? '' : text.substring(0, 1);
  if (document.getElementById('ElevatorTable') != null) {
    document.getElementById('ElevatorTable').style.display = 'none';
  }
  if (document.getElementById('ConveyorTable') != null) {
    document.getElementById('ConveyorTable').style.display = 'none';
  }
  if (typeCode === 'C') {
    document.getElementById('ConveyorTable').style.display = '';
  } else if (typeCode === 'E') {
    document.getElementById('ElevatorTable').style.display = '';
  }
}

function getProcessDetails(equipmentId) {
  if (equipmentId != "") {
    var url = document.getElementById('contextPath').value
        + '/data/equipment/details?method=lookupProcessXml&equipmentId=' + equipmentId;
    var callbackAfterGettingProcessDetails = {
      success: function(o) {
        this.cache = null;
        populateProcessDetails(o.responseXML);
      }
      ,
      cache:false ,
      failure: function(o) {
         document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
      }
      ,
      timeout: 20000 //20 seconds
    }
    this.getXML = YAHOO.util.Connect.asyncRequest('GET', url, callbackAfterGettingProcessDetails);
  }

}

function populateProcessDetails(xmlDoc) {
  var processId = xmlDoc.getElementsByTagName("id")[0].text;
  var productType = xmlDoc.getElementsByTagName("productType")[0].text;
  var productDensity = xmlDoc.getElementsByTagName("productDensity")[0].text;
  var designCapacity = xmlDoc.getElementsByTagName("designCapacity")[0].text;
  var designCapacityUnitId = xmlDoc.getElementsByTagName("designCapacityUnitId")[0].text;
  var designCapacityUnitText = xmlDoc.getElementsByTagName("designCapacityUnitText")[0].text;
  var compAirRequired = xmlDoc.getElementsByTagName("compAirRequired")[0].text;
  var compAirPressure = xmlDoc.getElementsByTagName("compAirPressure")[0].text;
  var compAirFlowrate = xmlDoc.getElementsByTagName("compAirFlowrate")[0].text;
  var gasRequired = xmlDoc.getElementsByTagName("gasRequired")[0].text;
  var gasTypeId = xmlDoc.getElementsByTagName("gasTypeId")[0].text;
  var gasPressure = xmlDoc.getElementsByTagName("gasPressure")[0].text;
  var gasFlowrate = xmlDoc.getElementsByTagName("gasFlowrate")[0].text;
  var waterRequired = xmlDoc.getElementsByTagName("waterRequired")[0].text;
  var waterPressure = xmlDoc.getElementsByTagName("waterPressure")[0].text;
  var waterFlowrate = xmlDoc.getElementsByTagName("waterFlowrate")[0].text;
  var waterTypeId = xmlDoc.getElementsByTagName("waterTypeId")[0].text;
  var dustPickupRequired = xmlDoc.getElementsByTagName("dustPickupRequired")[0].text;
  var dustPickupVelocity = xmlDoc.getElementsByTagName("dustPickupVelocity")[0].text;
  var dustTypeId = xmlDoc.getElementsByTagName("dustType/dustTypeId")[0].text;
  var baghouseCyclone = xmlDoc.getElementsByTagName("baghouseCyclone")[0].text;
  var ductSize = xmlDoc.getElementsByTagName("ductSize")[0].text;
  var ductFlowrate = xmlDoc.getElementsByTagName("ductFlowrate")[0].text;
  var specificationRequired = xmlDoc.getElementsByTagName("specificationRequired")[0].text;
  var processRemarks = xmlDoc.getElementsByTagName("processRemarks")[0].text;
  var processFieldEquipmentTypes = xmlDoc.getElementsByTagName("processFieldEquipmentTypes")[0];

  document.getElementById('processId').value = processId;
  updateTextField('productType', productType);
  updateTextField('productDensity', productDensity);
  updateTextField('designCapacity', designCapacity);
  updateCheckbox('compAirRequired', compAirRequired);
  updateTextField('compAirPressure', compAirPressure);
  updateTextField('compAirFlowrate', compAirFlowrate);
  updateCheckbox('gasRequired', gasRequired);

  var gasTypes = document.getElementById('gasType');
  setSelectedInDropdown(gasTypes, gasTypeId);
  updateSelectField('gasType', gasTypeId);

  updateTextField('gasPressure', gasPressure);
  updateTextField('gasFlowrate', gasFlowrate);
  updateCheckbox('waterRequired', waterRequired);
  updateTextField('waterPressure', waterPressure);
  updateTextField('waterFlowrate', waterFlowrate);

  var waterTypes = document.getElementById('waterType');
  setSelectedInDropdown(waterTypes, waterTypeId);
  updateSelectField('waterType', waterTypeId);

  updateCheckbox('dustPickupRequired', dustPickupRequired);
  updateTextField('dustPickupVelocity', dustPickupVelocity);

  var dustTypes = document.getElementById('dustType');
  setSelectedInDropdown(dustTypes, dustTypeId);
  updateSelectField('dustType', dustTypeId);

  var designCapacityUnits = document.getElementById('designCapacityUnit');
  setSelectedInDropdown(designCapacityUnits, designCapacityUnitId);
  updateSelectField('designCapacityUnit', designCapacityUnitId);
  updateTextField('designCapacityUnitText', designCapacityUnitText);
  updateTextField('baghouseCyclone', baghouseCyclone);
  updateTextField('ductSize', ductSize);
  updateTextField('dustFlowrate', ductFlowrate);

  updateRadioButton('specificationRequired', specificationRequired);

  updateTextField('processRemarks', processRemarks);

  var fieldEquipmentTypes = processFieldEquipmentTypes.childNodes;
  for (i = 0; i < fieldEquipmentTypes.length; i++) {
    var name = fieldEquipmentTypes[i].nodeName;
    var fieldType = fieldEquipmentTypes[i].getAttribute("fieldEquipmentType");
    var fieldValue = fieldEquipmentTypes[i].firstChild === null ? '' : fieldEquipmentTypes[i].firstChild.nodeValue;
    var element = document.getElementById(name);
    if (fieldType === "text" || fieldType === "textarea") {
      updateTextField(name, fieldValue);
    } else if (fieldType === "checkbox") {
      updateCheckbox(name, fieldValue);
    } else if (fieldType === "radio") {
      var elements = document.getElementsByName(name);
      for (var k = 0; k < elements.length; k++) {
        element = elements[k];
        if (element.value === fieldValue) {
          updateRadioButton(name, fieldValue);
          break;
        }
      }
    } else if (fieldType === "select") {
      for (var j = 0; j < element.options.length; j++) {
        if (element.options[j].value === fieldValue) {
          updateSelectField(name, fieldValue);
          break;
        }
      }
    }
  }

}

function getRefDataForProcessTab(thisEquipmentId, populateDetailsAsWell) {
  if (thisEquipmentId != null) {
    this.populateArrays = {
      success: function(o) {
        var xmlDoc = o.responseXML;
        var designCapacityUnitElement = document.getElementById('designCapacityUnit');
        setDefaultOption(designCapacityUnitElement, "");
        fillSelectDropdown(xmlDoc, designCapacityUnitElement, 'designCapacityUnit', 'id', 'unitName');
        if (populateDetailsAsWell) {
          getProcessDetails(thisEquipmentId);
        }
      },
      failure: function(o) {
          document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
      },
      timeout: 30000 //30 seconds
    };

    var url = document.getElementById('contextPath').value +
              "/data/equipmentRefDataXml/details?method=lookupRefDataForProcessDetailsTabXML" +
              "&equipmentTypeId=" + document.getElementById('equipmentTypeId').value +
              "&unitMeasureId=" + document.getElementById('projectUnitMeasureId').value;
    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
        url,
        this.populateArrays);
  }
}
