function createPurchasingCalendars() {
  createCalendar("originalShipDate", "originalShipDateContainer");
  createCalendar("revisedShipDate", "revisedShipDateContainer");
  createCalendar("actualDeliveryDate", "actualDeliveryDateContainer");
}

function getPurchasingDetails(equipmentId) {
  if (equipmentId != "") {
    var url = document.getElementById('contextPath').value
        + '/data/equipment/details?method=lookupPurchasingXml&equipmentId=' + equipmentId;
    var callbackAfterGettingPurchasingDetails = {
      success: function(o) {
        this.cache = null;
        checkXMLReturnedFromAjaxCall(o, populatePurchasingDetails);
//        populatePurchasingDetails(o.responseXML);
      }
      ,
      failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
      }
      ,
      cache:false
    }
    this.getXML = YAHOO.util.Connect.asyncRequest('GET', url, callbackAfterGettingPurchasingDetails);
  }
}


function populatePurchasingDetails(o) {
  var xmlDoc = o.responseXML;
  var purchasingId = xmlDoc.getElementsByTagName("purchaseId")[0].text;
  var vendor = xmlDoc.getElementsByTagName("vendor")[0].text;
  var purchaseSoleSource = document.getElementById("equipmentSoleSource").checked === true ? "true" : "false";
//  var purchaseSoleSource = xmlDoc.getElementsByTagName("purchaseSoleSource")[0].text;
  var rtpNumber = xmlDoc.getElementsByTagName("rtpNumber")[0].text;
  var poNumber = xmlDoc.getElementsByTagName("poNumber")[0].text;
  var lineNumber = xmlDoc.getElementsByTagName("lineNumber")[0].text;
  var poLineAmount = xmlDoc.getElementsByTagName("poLineAmount")[0].text;
//  var poLineQuantity = xmlDoc.getElementsByTagName("poLineQuantity")[0].text;
//  var poLineValue = xmlDoc.getElementsByTagName("poLineValue")[0].text;
  var coAmount = xmlDoc.getElementsByTagName("coAmount")[0].text;
  var originalShipDate = xmlDoc.getElementsByTagName("originalShipDate")[0].text;
  var revisedShipDate = xmlDoc.getElementsByTagName("revisedShipDate")[0].text;
  var actualDeliveryDate = xmlDoc.getElementsByTagName("actualDeliveryDate")[0].text;
  var exportDocuments = xmlDoc.getElementsByTagName("exportDocuments")[0].text;

  hideCalendarIfReadOnlyAccess("btn-originalShipDateContainer");
  hideCalendarIfReadOnlyAccess("btn-revisedShipDateContainer");
  hideCalendarIfReadOnlyAccess("btn-actualDeliveryDateContainer");

  document.getElementById('purchasingId').value = purchasingId;
  updateTextField('vendor', vendor);
  updateCheckbox('purchaseSoleSource', purchaseSoleSource);
  updateTextField('rtpNumber', rtpNumber);
  updateTextField('poNumber', poNumber);
  updateTextField('lineNumber', lineNumber);
  updateTextField('poLineAmount', poLineAmount);
//  updateTextField('poLineQuantity', poLineQuantity);
//  updateTextField('poLineValue', poLineValue);
  updateTextField('coAmount', coAmount);
  updateTextField('originalShipDate', formatDateForDisplay(originalShipDate));
  updateTextField('revisedShipDate', formatDateForDisplay(revisedShipDate));
  updateTextField('actualDeliveryDate', formatDateForDisplay(actualDeliveryDate));
  updateCheckbox('exportDocuments', exportDocuments);
  calculateTotalItemCost();
}

function calculateTotalItemCost() {
  var poLineAmountValue = document.getElementById('poLineAmount').value;
  var coAmountValue = document.getElementById('coAmount').value;
  var totalItemCostValue = '';
  if (poLineAmountValue != "" && coAmountValue != "") {
    totalItemCostValue = parseInt(poLineAmountValue) + parseInt(coAmountValue);
    var totalItemCost = document.getElementById('totalItemCost');
    totalItemCost.innerHTML = totalItemCostValue;
//    updateTextField('totalItemCost', totalItemCost);
    calculateOverUnder();
  }
}

function updateEquipmentSoleSourceValue(purchasingSoleSource){
  document.getElementById("equipmentSoleSource").checked = purchasingSoleSource.checked;
}