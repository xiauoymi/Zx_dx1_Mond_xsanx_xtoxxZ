var equipmentListTabIdsAlreadyClicked = "";
var equipmentTypeId = "";
var equipmentTypeValue = "";
var equipmentAreaId = "";
var equipmentAreaValue = "";
var processLineId = "";
var processLineValue = "";
var equipmentNumberId = "";
var equipmentNumberValue = "";
var equipmentNameId = "";
var equipmentNameValue = "";
var vendorId = "";
var vendorValue = "";
function createEquipmentListTabs() {

    getReferenceDataForAllTabs();
    var equipmentListTabs = new YAHOO.widget.TabView();
    var allEquipmentsTab = new YAHOO.widget.Tab({
        label: 'All',
        content:  document.getElementById("allEquipmentsTab").innerHTML,
        active: true
    });
    equipmentListTabs.addTab(allEquipmentsTab);

    var processListTab = new YAHOO.widget.Tab({
        label: 'Process',
        content:  document.getElementById("processListTab").innerHTML,
        active: false
    });
    equipmentListTabs.addTab(processListTab);

    var mechanicalListTab = new YAHOO.widget.Tab({
        label: 'Mechanical',
        content:  document.getElementById("mechanicalListTab").innerHTML,
        active: false
    });
    equipmentListTabs.addTab(mechanicalListTab);

    var electricalListTab = new YAHOO.widget.Tab({
        label: 'Electrical',
        content:  document.getElementById("electricalListTab").innerHTML,
        active: false
    });
    equipmentListTabs.addTab(electricalListTab);

    var motorListTab = new YAHOO.widget.Tab({
        label: 'Motor',
        content:  document.getElementById("motorListTab").innerHTML,
        active: false
    });
    equipmentListTabs.addTab(motorListTab);

    var instrumentListTab = new YAHOO.widget.Tab({
        label: 'Instrument',
        content:  document.getElementById("instrumentListTab").innerHTML,
        active: false
    });
    equipmentListTabs.addTab(instrumentListTab);

    var accessoryListTab = new YAHOO.widget.Tab({
        label: 'Accessory',
        content:  document.getElementById("accessoryListTab").innerHTML,
        active: false
    });
    equipmentListTabs.addTab(accessoryListTab);

    var purchasingListTab = new YAHOO.widget.Tab({
        label: 'Purchasing',
        content:  document.getElementById("purchasingListTab").innerHTML,
        active: false
    });
    equipmentListTabs.addTab(purchasingListTab);

    var costScheduleListTab = new YAHOO.widget.Tab({
        label: 'Cost/Schedule',
        content:  document.getElementById("costScheduleListTab").innerHTML,
        active: false
    });
    equipmentListTabs.addTab(costScheduleListTab);


    equipmentListTabs.on("beforeActiveTabChange", function(ev) {
        var currentTab = equipmentListTabs.get('activeTab');
        var tabIndex = equipmentListTabs.getTabIndex(currentTab);

        equipmentTypeId = "searchEquipmentTypeForTab" + tabIndex;
        equipmentTypeValue = document.getElementById(equipmentTypeId).selectedIndex;
        equipmentAreaId = "searchEquipmentAreaForTab" + tabIndex;
        equipmentAreaValue = document.getElementById(equipmentAreaId).value;
        processLineId = "searchProcessLineForTab" + tabIndex;
        processLineValue = document.getElementById(processLineId).value;
        equipmentNumberId = "searchEquipmentNumberForTab" + tabIndex;
        equipmentNumberValue = document.getElementById(equipmentNumberId).value;
        equipmentNameId = "searchEquipmentNameForTab" + tabIndex;
        equipmentNameValue = document.getElementById(equipmentNameId).value;
        vendorId = "searchVendorForTab" + tabIndex;
        vendorValue = document.getElementById(vendorId).value;
    });

    equipmentListTabs.on("activeTabChange", function(ev) {
        var activeTabIndex = equipmentListTabs.get("activeIndex");
        retainSearchParameters(activeTabIndex);
            if (ev.newValue === electricalListTab) {
                searchEquipmentsForElec();
            } else  if (ev.newValue === processListTab) {
                searchEquipmentsForProcess();
            } else  if (ev.newValue === motorListTab) {
                searchEquipmentsForMotor();
            } else  if (ev.newValue === mechanicalListTab) {
                searchEquipmentsForMech();
            } else  if (ev.newValue === instrumentListTab) {
                searchEquipmentsForInst();
            } else  if (ev.newValue === accessoryListTab) {
                searchEquipmentsForAcce();
            } else  if (ev.newValue === costScheduleListTab) {
                searchEquipmentsForCostSchedule();
            }else if(ev.newValue === purchasingListTab){
                searchEquipmentsForPurchasing();
            }else {
                searchEquipmentsForAll();
            }

    });
    var equipmentListTabsDiv = document.getElementById("equipmentListTabs");
    equipmentListTabsDiv.innerHTML = "";
    equipmentListTabs.appendTo(equipmentListTabsDiv);

    var loadAllEquipmentList = document.getElementById('loadAllEquipmentList').value;
    if (loadAllEquipmentList === "true") {
        searchEquipmentsForAll();
    }
}

function getReferenceDataForAllTabs() {
    getRefDataForElectrical();
    getRefDataForProcess();
    getRefDataForMotor();
    getRefDataForMech();
    getRefDataForInstrument();
    getRefDataForAccessory();
    getRefDataForCostSchedule();
}

function retainSearchParameters(activeTabIndex){
           processLineId = "searchProcessLineForTab" + activeTabIndex;
        document.getElementById(processLineId).value = processLineValue;
        equipmentNumberId = "searchEquipmentNumberForTab" + activeTabIndex;
        document.getElementById(equipmentNumberId).value = equipmentNumberValue;
        equipmentNameId = "searchEquipmentNameForTab" + activeTabIndex;
        document.getElementById(equipmentNameId).value = equipmentNameValue;
        vendorId = "searchVendorForTab" + activeTabIndex;
        document.getElementById(vendorId).value = vendorValue;
        equipmentTypeId = "searchEquipmentTypeForTab" + activeTabIndex;
        document.getElementById(equipmentTypeId).selectedIndex = equipmentTypeValue;
        equipmentAreaId = "searchEquipmentAreaForTab" + activeTabIndex;
        document.getElementById(equipmentAreaId).selectedIndex = equipmentAreaValue;
}

function pausecomp(millis)
{
var date = new Date();
var curDate = null;

do { curDate = new Date(); }
while(curDate-date < millis);
}