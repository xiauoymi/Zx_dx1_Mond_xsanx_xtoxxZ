var inputArr = null;
var outputArr = null;
var measurementArr = null;
var acceDesignatorArray = null;
var autoManualArr = null;
var searchEquipmentsDataTableForAcce = null;

function getRefDataForAccessory() {
  this.populateArrays = {
    success: function(o) {
      var xmlDoc = o.responseXML;
      inputArr = populateArrayForDropdown(xmlDoc, 'inputs/electricalInput', 'id', 'input');
      outputArr = populateArrayForDropdown(xmlDoc, 'outputs/electricalOutput', 'id', 'output');
      measurementArr = populateArrayForDropdown(xmlDoc, 'otherMeasurements/otherMeasurement', 'id', 'measurement');
      autoManualArr = populateArrayForDropdown(xmlDoc, 'autoManuals/autoManual', 'id', 'name');
      document.getElementById('searchAccessoryBtn').disabled = '';
    },
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    },
    timeout: 30000 //30 seconds
  };

  var url = document.getElementById('contextPath').value +
            "/data/equipmentRefDataXml/details?method=lookupRefDataForAccessoryXML";
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url, this.populateArrays);
}

function createEquipmentsListTabForAcce(url) {
  if (searchEquipmentsDataTableForAcce == null) {
    this.equipmentsListDataSource = createServerSidePaginationDataSource(url);
    var fieldArr = getCommonEquipmentFields();
    fieldArr = fieldArr.concat(getColumnDefsForAccessory());
    this.equipmentsListDataSource.responseSchema = {
      resultNode: "accessory",
      fields: fieldArr,
      metaFields: {totalRecords : "totalRecords"}
    };
    searchEquipmentsDataTableForAcce = getEquipmentTableForAcce(getEquipmentsColumnDefsForAcce(), this.equipmentsListDataSource);
  } else {
    searchEquipmentsDataTableForAcce.requery(url);
  }
}

function isPurchasingField(oKey) {
  return (oKey === "vendor" || oKey === "rtpNumber" || oKey === "poNumber" ||
          oKey === "lineNumber" || oKey === "actualDeliveryDate");
}

function getAcceColumnKeyToClassNameMap() {
  var columnKeyToClassNameMap = new Object();
  columnKeyToClassNameMap["accessoryName"] = "Accessory";
  columnKeyToClassNameMap["quantity"] = "Accessory";
  columnKeyToClassNameMap["purchasedWithEquipment"] = "Accessory";
  columnKeyToClassNameMap["acceDescription"] = "Accessory";
  columnKeyToClassNameMap["comments"] = "Accessory";
  columnKeyToClassNameMap["compAirReqd"] = "Accessory";
  columnKeyToClassNameMap["gasReqd"] = "Accessory";
  columnKeyToClassNameMap["waterReqd"] = "Accessory";
  columnKeyToClassNameMap["utilityFlowrate"] = "Accessory";
  columnKeyToClassNameMap["selfCleaning"] = "Accessory";
  columnKeyToClassNameMap["size"] = "Accessory";
  columnKeyToClassNameMap["autoManualId"] = "Accessory";
  columnKeyToClassNameMap["proofOfPositionReq"] = "Electrical";
  columnKeyToClassNameMap["solenoidReq"] = "Electrical";
  columnKeyToClassNameMap["localPushButtonReq"] = "Electrical";
  columnKeyToClassNameMap["inputId"] = "Electrical";
  columnKeyToClassNameMap["inputQty"] = "Electrical";
  columnKeyToClassNameMap["outputId"] = "Electrical";
  columnKeyToClassNameMap["outputQty"] = "Electrical";
  columnKeyToClassNameMap["hmiDisplay"] = "Electrical";
  columnKeyToClassNameMap["otherMeasurementId"] = "Electrical";
  columnKeyToClassNameMap["communications"] = "Electrical";
  columnKeyToClassNameMap["voltage"] = "Electrical";
  columnKeyToClassNameMap["bidPackage"] = "Accessory";
  columnKeyToClassNameMap["vendor"] = "Purchasing";
  columnKeyToClassNameMap["rtpNumber"] = "Purchasing";
  columnKeyToClassNameMap["poNumber"] = "Purchasing";
  columnKeyToClassNameMap["lineNumber"] = "Purchasing";
  columnKeyToClassNameMap["actualDeliveryDate"] = "Purchasing";
  columnKeyToClassNameMap["estimatedCost"] = "Accessory";
  columnKeyToClassNameMap["actualCost"] = "Accessory";
  return columnKeyToClassNameMap;
}

function getAccePrimaryKeyForClassName(className) {
  if (className === "Electrical") {
    return "electId";
  }
  if (className === "Purchasing") {
    return "purchaseId";
  }
  return "acceId";
}

function getAcceFormattedValue(oKey, oValue) {
  if (oKey === "actualDeliveryDate") {
    return formatDateForSaving(oValue);
  }
  return oValue;
}

function getEquipmentTableForAcce(columnDefs, dataSource) {
  var editableTableParams = null;
  var autosaveParams = null;
  if (userHasEditAccessToThisProject()) {
    editableTableParams = {};
    editableTableParams.firstEditableColumnIndex = 7;
    editableTableParams.lastEditableColumnIndex = 37;
    editableTableParams.newRecord = null;

    autosaveParams = {};
    autosaveParams.columnKeyToClassNameMap = getAcceColumnKeyToClassNameMap();
    autosaveParams.primaryKeyForClassNameFnc = getAccePrimaryKeyForClassName;
    autosaveParams.formattedValueFnc = getAcceFormattedValue;
  }

  searchEquipmentsDataTableForAcce = createEditableDataTable("equipmentsListForAcce", columnDefs, dataSource, "equipmentNumber",
  {scrollable:true, width:getWidthForDataTable(), draggableColumns:true, emptyMsg:"No Matching Equipment Items Found"},
  {pagination:true, topPaginator:'topPaginatorForEquipmentsForAcce'}, {editableTableParams:editableTableParams, autosaveParams:autosaveParams});

  if (userHasEditAccessToThisProject()) {
    var dt = searchEquipmentsDataTableForAcce.getDataTable();
    dt.subscribe('cellClickEvent', function (oArgs) {
      onCellClickOfInstAndAcce(dt, oArgs);
    });
    dt.subscribe('checkboxClickEvent', function(oArgs) {
      onCheckboxClickOfInstAndAcce(dt, oArgs);
    });

    dt.subscribe('editorSaveEvent', function(oArgs) {
      var oRecord = oArgs.record;
      var oColumn = oArgs.column;
      if (oRecord === undefined) {//For Yahoo's BaseCellEditor
        oRecord = oArgs.editor.getRecord();
        oColumn = oArgs.editor.getColumn();
      }
      var oKey = oColumn.key;
      var queryStr = null;
      if (oKey === "purchasedWithEquipment" && oRecord.getData(oKey) === "true") {
        oRecord.setData("vendor", "");
        oRecord.setData("rtpNumber", "");
        oRecord.setData("poNumber", "");
        oRecord.setData("lineNumber", "");
        oRecord.setData("actualDeliveryDate", "");
        var rowIndex = this.getTrEl(oRecord).sectionRowIndex;
        this.updateRow(this.getTrEl(rowIndex), oRecord.getData());

        queryStr = getQueryStringForAutosave(searchEquipmentsDataTableForAcce, oRecord, "vendor");
        autosaveValue(this, queryStr);

        queryStr = getQueryStringForAutosave(searchEquipmentsDataTableForAcce, oRecord, "rtpNumber");
        autosaveValue(this, queryStr);

        queryStr = getQueryStringForAutosave(searchEquipmentsDataTableForAcce, oRecord, "poNumber");
        autosaveValue(this, queryStr);

        queryStr = getQueryStringForAutosave(searchEquipmentsDataTableForAcce, oRecord, "lineNumber");
        autosaveValue(this, queryStr);

        queryStr = getQueryStringForAutosave(searchEquipmentsDataTableForAcce, oRecord, "actualDeliveryDate");
        autosaveValue(this, queryStr);
      }
    });
  }
  return searchEquipmentsDataTableForAcce;
}

function getEquipmentsColumnDefsForAcce() {
  this.accessoryNumberFormatter = function(elCell, oRecord, oColumn, oData) {
    var acceDesignatorTypeCode = oRecord.getData('accessoryDesignatorTypeCode');
    var sequenceNumber = oRecord.getData('sequenceNumber');
    var equipmentNum = oRecord.getData('equipmentNumber');
    elCell.innerHTML = equipmentNum.substring(0, 7) + acceDesignatorTypeCode + sequenceNumber;
  }


  this.accessoryCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (userHasEditAccessToThisProject()) {
      if (oData === "true") {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForAcce, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox" checked="true"/>';
      } else {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForAcce, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox"/>';
      }
    } else {
      if (oData === "true") {
        var contextPath = document.getElementById('contextPath').value;
        el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
      }
    }
  }

  this.textboxEditorForAcceList = function (oEditor, oSelf) {
    textboxEditor(oEditor, searchEquipmentsDataTableForAcce);
  }
  this.textAreaEditorForAcceList = function (oEditor, oSelf) {
    textAreaEditor(oEditor, searchEquipmentsDataTableForAcce);
  }
  this.dropdownEditorForAcceList = function (oEditor, oSelf) {
    dropdownEditor(oEditor, searchEquipmentsDataTableForAcce);
  }

  var columnDefs = getCommonEquipmentColumnDefs();
  var className = getClassNameForEditableCell();
  columnDefs[columnDefs.length] = {key:"accessoryNumber", label:"Accessory<br/>Number", formatter: this.accessoryNumberFormatter, sortable:true, resizeable:true, width:120};
  columnDefs[columnDefs.length] = {key:"accessoryName", label:"Accessory<br/>Name", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:50, size:30}), editorOptions:{disableBtns:true, maxLength:50, size:30}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"quantity", label:"Qty", abbr:"Accessory Quantity", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 2, size: 2, regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"acceDescription", label:"Description", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength:200}), editorOptions:{disableBtns:true, maxLength:200}, formatter:commentsFormatter, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"comments", label:"Comments", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength:200}), editorOptions:{disableBtns:true, maxLength:200}, formatter:commentsFormatter, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"compAirReqd", label:"Air", abbr:"Compressed Air Required", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"gasReqd", label:"Gas", abbr:"Gas Required",className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"waterReqd", label:"Water", abbr:"Water Required", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"utilityFlowrate", label:"Flow", abbr:"Utility Flowrate", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:50, size:30}), editorOptions:{disableBtns:true, maxLength:50, size:30}, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"selfCleaning", label:"Self Cln", abbr:"Self Cleaning", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"size", label:"Size", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 2, size: 2, regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"autoManualId", label:"Auto/Man", abbr:"Auto/Manual", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:autoManualArr}), editorOptions:{disableBtns:true, dropdownOptions:autoManualArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:70};

  columnDefs[columnDefs.length] = {key:"proofOfPositionReq", label:"P of P", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"solenoidReq", label:"Solenoid", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"localPushButtonReq", label:"Push<br/>Btns", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"inputId", label:"In", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:inputArr}), editorOptions:{disableBtns:true, dropdownOptions:inputArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:40};
  columnDefs[columnDefs.length] = {key:"inputQty", label:"# In", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 2, size: 2, regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:40};
  columnDefs[columnDefs.length] = {key:"outputId", label:"Out", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:outputArr}), editorOptions:{disableBtns:true, dropdownOptions:outputArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:40};
  columnDefs[columnDefs.length] = {key:"outputQty", label:"# Out", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 2, size: 2, regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:40};
  columnDefs[columnDefs.length] = {key:"hmiDisplay", label:"HMI<br/>Display", className:className, editor:new YAHOO.widget.TextboxCellEditor({disableBtns:true, maxLength:30, size:30}), editorOptions:{disableBtns:true, maxLength:30, size:30}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"otherMeasurementId", label:"Other", abbr:"Other<br/>Measurement", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:measurementArr}), editorOptions:{disableBtns:true, dropdownOptions:measurementArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:60};
  columnDefs[columnDefs.length] = {key:"communications", label:"Communications", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:30, size:30}), editorOptions:{disableBtns:true, maxLength:30, size:30}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"voltage", label:"Volt", abbr:"Supply Voltage", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 3, size: 3, regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"bidPackage", label:"Bid<br/>Package", abbr:"Bid<br/>Package", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:250, size:80}), editorOptions:{disableBtns:true, blockAlphabets:false, maxLength:250, size:80}, sortable:true, resizeable:true, width:80};

  columnDefs[columnDefs.length] = {key:"purchasedWithEquipment", label:"P w/E", className:className, formatter: this.accessoryCheckboxFormatter, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"vendor", label:"Vendor", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:20, size:20}), editorOptions:{disableBtns:true, maxLength:20, size:20}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"rtpNumber", label:"RTP #", abbr:"RTP Number", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:8, size:8}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:8, size:8}, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"poNumber", label:"PO Number", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 10, size: 10, regExp:/^\d{0,10}$/,finalRegExp:'^\\d{10}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:10, size:10}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"lineNumber", label:"Line", abbr:"Line Item", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 3, size: 3, regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"actualDeliveryDate", label:"Del Date", abbr:"Delivery Date", formatter:dateEditableCellFormatterForInstAndAcce, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"estimatedCost", label:"Est<br/>Cost", abbr:"Estimated Cost", className: className, formatter:currencyFormatterInstAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 5, size: 5, regExp:/^\d{0,5}$/,finalRegExp:'^\\d{5}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:5, size:5}, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"actualCost", label:"Act<br/>Cost", abbr:"Actual Cost", className: className, formatter:currencyFormatterInstAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 5, size: 5, regExp:/^\d{0,5}$/,finalRegExp:'^\\d{5}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:5, size:5}, sortable:true, resizeable:true, width:80};

  return columnDefs;
}
