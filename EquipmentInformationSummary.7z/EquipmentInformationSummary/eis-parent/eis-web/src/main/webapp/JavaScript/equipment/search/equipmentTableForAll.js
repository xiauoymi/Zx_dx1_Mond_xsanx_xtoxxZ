var searchEquipmentsDataTableForAll = null;

function getCommonEquipmentFields() {
    return ["id", "equipmentNumber", "name", "equipmentTypeCode", "equipmentTypeName", "areaCode", "areaDescription",
        "processLineNumber", "equipmentVendor"];
}

var areaFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = oRecord.getData('areaCode');
}

var equipmentTypeFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = oRecord.getData('equipmentTypeCode');
}

var equipmentNumberFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<a href="#" onclick="showEquipmentDetailsDialog(' + oRecord.getData('id') +
                       '); return false;">' + oData + '</a>';
};

function getCommonEquipmentColumnDefs() {
    return [
        {key:"equipmentType", label:"Type", abbr:"Equipment Type", formatter: this.equipmentTypeFormatter, sortable:true, resizeable:true, width:45},
        {key:"area", label:"Area", formatter:this.areaFormatter, sortable:true, resizeable:true, width:45},
        {key:"processLineNumber", label:"PrLn", abbr:"Process Line", sortable:true, resizeable:true,  width:45},
        {key:"equipmentNumber", label:"Equipment #", formatter:this.equipmentNumberFormatter, sortable:true, resizeable:true, width:92},
        {key:"name", label:"Equipment Name", sortable:true, resizeable:true,  width:150},
        {key:"equipmentVendor", label:"Vendor", sortable:true, resizeable:true,  width:100}
    ]
}

function createEquipmentsListTabForAll(url) {
    if (searchEquipmentsDataTableForAll == null) {
        this.equipmentsListDataSource = createServerSidePaginationDataSource(url);
        var fieldArr = getCommonEquipmentFields();
        fieldArr[fieldArr.length] = "id";
        fieldArr[fieldArr.length] = "equipmentVendor";
        fieldArr[fieldArr.length] = "existingEquipmentModification";
        fieldArr[fieldArr.length] = "existingEquipmentNumber";
        fieldArr[fieldArr.length] = "motors";
        fieldArr[fieldArr.length] = "instruments";
        fieldArr[fieldArr.length] = "accessories";
        this.equipmentsListDataSource.responseSchema = {
            resultNode: "equipment",
            fields: fieldArr,
            metaFields: {totalRecords : "totalRecords"}
        };
        searchEquipmentsDataTableForAll = getEquipmentTableForAll(getEquipmentsColumnDefsForAll(), this.equipmentsListDataSource);
    } else {
        searchEquipmentsDataTableForAll.requery(url);
    }
}

function getEquipmentColumnKeyToClassNameMap() {
    var columnKeyToClassNameMap = new Object();
    columnKeyToClassNameMap["existingEquipmentModification"] = "Equipment";
    columnKeyToClassNameMap["existingEquipmentNumber"] = "Equipment";
    return columnKeyToClassNameMap;
}

function getEquipmentPrimaryKeyForClassName(className) {
    return "id";
}

function getEquipmentTableForAll(columnDefs, dataSource) {
    var editableTableParams = null;
    var autosaveParams = null;
    if (userHasEditAccessToThisProject()) {
        editableTableParams = {};
        editableTableParams.firstEditableColumnIndex = 6;
        editableTableParams.lastEditableColumnIndex = 7;
        editableTableParams.newRecord = null;

        autosaveParams = {};
        autosaveParams.columnKeyToClassNameMap = getEquipmentColumnKeyToClassNameMap();
        autosaveParams.primaryKeyForClassNameFnc = getEquipmentPrimaryKeyForClassName;
        autosaveParams.formattedValueFnc = null;
    }

    searchEquipmentsDataTableForAll = createEditableDataTable("equipmentsListForAll", columnDefs, dataSource, "equipmentNumber",
    {scrollable:true, width:getWidthForDataTable(), draggableColumns:true, emptyMsg:"No Matching Equipment Items Found"},
    {pagination:true, topPaginator:'topPaginatorForEquipmentsForAll'}, {editableTableParams:editableTableParams, autosaveParams:autosaveParams});
    return searchEquipmentsDataTableForAll;
}

function getEquipmentsColumnDefsForAll() {
    var className = getClassNameForEditableCell();

    this.existsFormatter = function(elCell, oRecord, oColumn, oData) {
        if (oData === "true") {
            elCell.innerHTML = '<img border="0" alt="Exists" src="' + document.getElementById('contextPath').value +
                               '/images/check.gif")">';
        }
    }

    this.editEquipmentFormatter = function(elCell, oRecord, oColumn, oData) {
        elCell.innerHTML = '<a href="#" onclick="showEquipmentDetailsDialog(' + oRecord.getData('id') +
                           '); return false;"> Edit </a>';
    };

    this.deleteEquipmentFormatter = function(el, oRecord, oColumn, oData) {
        el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                       '/images/icon_delete.gif" onclick="showDeleteEquipmentWarning(\'' + oRecord.getData('id') +
                       '\')">';
        el.style.cursor = 'pointer';
    }

    this.equipmentCheckboxFormatter = function(el, oRecord, oColumn, oData) {
        if (userHasEditAccessToThisProject()) {
            if (oData === "true") {
                el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForAll, \'' +
                               oRecord.getId() +
                               '\',\'' + oColumn.key +
                               '\')" class="yui-dt-checkbox" checked="true"/>';
            } else {
                el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForAll, \'' +
                               oRecord.getId() +
                               '\',\'' + oColumn.key +
                               '\')" class="yui-dt-checkbox"/>';
            }
        } else {
            if (oData === "true") {
                var contextPath = document.getElementById('contextPath').value;
                el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
            }
        }
    }

    var columnDefs = getCommonEquipmentColumnDefs();
    columnDefs[columnDefs.length] = {key:"existingEquipmentModification", label:"Existing<br/>Equipment<br/>Modification", className:className, formatter: this.equipmentCheckboxFormatter, sortable:true, resizeable:true, width:80};
    columnDefs[columnDefs.length] = {key:"existingEquipmentNumber", label:"Existing<br/>Equipment<br/>Number", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:12, size: 12}), editorOptions:{disableBtns:true, maxLength:12, size:12}, sortable:true, resizeable:true, width:80};
    columnDefs[columnDefs.length] = {key:"motors", label:"Motors<br/>Exist", formatter: this.existsFormatter, sortable:true, resizeable:true, width:60};
    columnDefs[columnDefs.length] = {key:"instruments", label:"Instruments<br/>Exist", formatter: this.existsFormatter, sortable:true, resizeable:true, width:80};
    columnDefs[columnDefs.length] = {key:"accessories", label:"Accessories<br/>Exist", formatter: this.existsFormatter, sortable:true, resizeable:true, width:80};
    if (userHasEditAccessToThisProject()) {
        columnDefs[columnDefs.length] = {key:"delete", label:"Delete", formatter:this.deleteEquipmentFormatter, width:50};
    }

    return columnDefs;
}

function showDeleteEquipmentWarning(equipmentId) {
    if (okToDelete()) {
        deleteEquipmentRow(equipmentId);
    }
}

function deleteEquipmentRow(equipmentId) {
    var callbackAfterDeletingEquipment = {
        success: function(o) {
            this.cache = null;
            searchEquipmentsForAll();
        },
        cache:false ,
        failure: function(o) {
            document.location.href = document.getElementById('contextPath').value +
                                     "/servlet/logon?method=error";
        }
        ,
        timeout: 20000 //20 seconds
    }
    var url = document.getElementById('contextPath').value + "/servlet/equipment?method=deleteEquipment&equipmentId=" +
              equipmentId;
    this.getXML = YAHOO.util.Connect.asyncRequest('GET', url, callbackAfterDeletingEquipment);
}
