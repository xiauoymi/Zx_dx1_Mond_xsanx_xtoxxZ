var fundingSourceArr = null;
var searchEquipmentsDataTableForCostSchedule = null;

function getRefDataForCostSchedule() {
  this.populateArrays = {
    success: function(o) {
      var xmlDoc = o.responseXML;
      fundingSourceArr = populateArrayForDropdown(xmlDoc, 'fundingSources/fundingSource', 'id', 'source');
      document.getElementById('searchCostScheduleBtn').disabled = '';
    },
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    },
    timeout: 30000 //30 seconds
  };

  var url = document.getElementById('contextPath').value +
            "/data/equipmentRefDataXml/details?method=lookupRefDataForCostScheduleXML";
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url,
      this.populateArrays);
}

function createEquipmentsListTabForCostSchedule(url) {
  if (searchEquipmentsDataTableForCostSchedule == null) {
    this.equipmentsListDataSource = createServerSidePaginationDataSource(url);
    var fieldArr = getCommonEquipmentFields();
    fieldArr[fieldArr.length] = "costScheduleId";
    fieldArr[fieldArr.length] = "scheduledSpecificationDate";
    fieldArr[fieldArr.length] = "scheduledQuoteDate";
    fieldArr[fieldArr.length] = "scheduledPurchaseDate";
    fieldArr[fieldArr.length] = "drawingTurnaroundTime";
    fieldArr[fieldArr.length] = "estiamtedFabricationTime";
    fieldArr[fieldArr.length] = "estiamtedShippingDate";
    fieldArr[fieldArr.length] = "specIssuedDate";
    fieldArr[fieldArr.length] = "rtqEnteredDate";
    fieldArr[fieldArr.length] = "rtpEnteredDate";
    fieldArr[fieldArr.length] = "prelDrawingIssuedDate";
    fieldArr[fieldArr.length] = "approvalDrawingDate";
    fieldArr[fieldArr.length] = "finalDrawingDate";
    fieldArr[fieldArr.length] = "iomReceivedDate";
    fieldArr[fieldArr.length] = "estimatedCost";
    fieldArr[fieldArr.length] = "estimatedSource";
    fieldArr[fieldArr.length] = "fundingSourceId";
    fieldArr[fieldArr.length] = "estimatedMechHours";
    fieldArr[fieldArr.length] = "escalationFactor";
    fieldArr[fieldArr.length] = "poLineAmount";
    fieldArr[fieldArr.length] = "coAmount";

    this.equipmentsListDataSource.responseSchema = {
      resultNode: "costSchedule",
      fields: fieldArr,
      metaFields: {totalRecords : "totalRecords"}
    };
    searchEquipmentsDataTableForCostSchedule = getEquipmentTableForCostSchedule(getEquipmentsColumnDefsForCostSchedule(), this.equipmentsListDataSource);
  } else {
    searchEquipmentsDataTableForCostSchedule.requery(url);
  }
}

function getCostScheduleColumnKeyToClassNameMap() {
  var columnKeyToClassNameMap = new Object();
  columnKeyToClassNameMap["scheduledSpecificationDate"] = "CostSchedule";
  columnKeyToClassNameMap["scheduledQuoteDate"] = "CostSchedule";
  columnKeyToClassNameMap["scheduledPurchaseDate"] = "CostSchedule";
  columnKeyToClassNameMap["drawingTurnaroundTime"] = "CostSchedule";
  columnKeyToClassNameMap["estiamtedFabricationTime"] = "CostSchedule";
  columnKeyToClassNameMap["estiamtedShippingDate"] = "CostSchedule";
  columnKeyToClassNameMap["specIssuedDate"] = "CostSchedule";
  columnKeyToClassNameMap["rtqEnteredDate"] = "CostSchedule";
  columnKeyToClassNameMap["rtpEnteredDate"] = "CostSchedule";
  columnKeyToClassNameMap["prelDrawingIssuedDate"] = "CostSchedule";
  columnKeyToClassNameMap["approvalDrawingDate"] = "CostSchedule";
  columnKeyToClassNameMap["finalDrawingDate"] = "CostSchedule";
  columnKeyToClassNameMap["iomReceivedDate"] = "CostSchedule";
  columnKeyToClassNameMap["estimatedCost"] = "CostSchedule";
  columnKeyToClassNameMap["estimatedSource"] = "CostSchedule";
  columnKeyToClassNameMap["fundingSourceId"] = "CostSchedule";
  columnKeyToClassNameMap["estimatedMechHours"] = "CostSchedule";
  columnKeyToClassNameMap["escalationFactor"] = "CostSchedule";
  return columnKeyToClassNameMap;
}

function getCostSchedulePrimaryKeyForClassName(className) {
  return "costScheduleId";
}

function getCostScheduleFormattedValue(oKey, oValue) {
  if (oKey === "scheduledSpecificationDate" || oKey === "scheduledQuoteDate" || oKey === "scheduledPurchaseDate"
      || oKey === "estiamtedShippingDate" || oKey === "estiamtedShippingDate" || oKey === "specIssuedDate"
      || oKey === "rtqEnteredDate" || oKey === "rtpEnteredDate" || oKey === "prelDrawingIssuedDate"
      || oKey === "approvalDrawingDate" || oKey === "finalDrawingDate" || oKey === "iomReceivedDate") {
    return formatDateForSaving(oValue);
  }
  return oValue;
}

function getEquipmentTableForCostSchedule(columnDefs, dataSource) {
  var editableTableParams = null;
  var autosaveParams = null;
  if (userHasEditAccessToThisProject()) {
    editableTableParams = {};
    editableTableParams.firstEditableColumnIndex = 9;
    editableTableParams.lastEditableColumnIndex = 23;
    editableTableParams.newRecord = null;
    autosaveParams = {};
    autosaveParams.columnKeyToClassNameMap = getCostScheduleColumnKeyToClassNameMap();
    autosaveParams.primaryKeyForClassNameFnc = getCostSchedulePrimaryKeyForClassName;
    autosaveParams.formattedValueFnc = getCostScheduleFormattedValue;
  }

  searchEquipmentsDataTableForCostSchedule = createEditableDataTable("equipmentsListForCostSchedule", columnDefs, dataSource, "equipmentNumber",
  {scrollable:true, width:getWidthForDataTable(), draggableColumns:true, emptyMsg:"No Matching Equipment Items Found"},
  {pagination:true, topPaginator:'topPaginatorForEquipmentsForCostSchedule'}, {editableTableParams:editableTableParams, autosaveParams:autosaveParams});
  return searchEquipmentsDataTableForCostSchedule;
}

function getEquipmentsColumnDefsForCostSchedule() {
  this.costSchedulelCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (userHasEditAccessToThisProject()) {
      if (oData === "true") {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForCostSchedule, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox" checked="true"/>';
      } else {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForCostSchedule, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox"/>';
      }
    } else {
      if (oData === "true") {
        var contextPath = document.getElementById('contextPath').value;
        el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
      }
    }
  }

  var columnDefs = getCommonEquipmentColumnDefs();
  columnDefs = columnDefs.concat(getCostScheduleColumnDefs());
  return columnDefs;
}

function getOverUnderForCostSchedule(oRecord) {
  var poLineAmount = oRecord.getData('poLineAmount');
  var coAmount = oRecord.getData('coAmount');
  var estimatedCost = oRecord.getData('estimatedCost');
  var totalItemCost = '';
  if (poLineAmount != '' && coAmount != '') {
    totalItemCost = parseInt(poLineAmount) + parseInt(coAmount);
  }
  if (totalItemCost != '' && estimatedCost != '') {
    return totalItemCost - estimatedCost;
  } else {
    return '';
  }
}

function calcualteOverUnderForCostSchedule(oEditor) {
  var oRecord = oEditor.record;
  var oColumn = oEditor.column;
  var oCell = searchEquipmentsDataTableForCostSchedule.getTrEl(oRecord).cells[23];//cell for over/under
  if (oColumn.key === 'estimatedCost') {
    oCell.firstChild.innerHTML = getOverUnderForCostSchedule(oRecord);
  }
}

function getCostScheduleColumnDefs() {
  this.textboxEditorForCostScheduleForOverUnder = function (oEditor, oSelf) {
    textboxEditor(oEditor, searchEquipmentsDataTableForCostSchedule, calcualteOverUnderForCostSchedule);
  }
  this.overUnderFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = getOverUnderForCostSchedule(oRecord);
  }

  var columnDefs = [];
  var className = getClassNameForEditableCell();
  this.textboxEditorForCostSchedule = function (oEditor, oSelf) {
    textboxEditor(oEditor, searchEquipmentsDataTableForCostSchedule);
  }
  this.textAreaEditorForCostSchedule = function (oEditor, oSelf) {
    textAreaEditor(oEditor, searchEquipmentsDataTableForCostSchedule);
  }
  this.dropdownEditorForCostSchedule= function (oEditor, oSelf) {
    dropdownEditor(oEditor, searchEquipmentsDataTableForCostSchedule);
  }
  columnDefs[columnDefs.length] = {key:"scheduledSpecificationDate", label:"RTQ Release", abbr:"Scheduled<br/>Specification", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"scheduledQuoteDate", label:"RTP Release", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"scheduledPurchaseDate", label:"PO<br/>Release", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"drawingTurnaroundTime", label:"DTT", abbr:"Drawing Turnaround Time", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$',maxLength:2, size: 2}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2},sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"estiamtedFabricationTime", label:"EFT", abbr:"Estimated Fabrication Time", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$',maxLength:2, size: 2}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2},sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"estiamtedShippingDate", label:"Required Ship Date", abbr:"Estimated Shipping Date", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"specIssuedDate", label:"PO Date", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"rtqEnteredDate", label:"RTQ<br/>Release", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"rtpEnteredDate", label:"RTP<br/>Release", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"prelDrawingIssuedDate", label:"Preliminary<br/>Drawing", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"finalDrawingDate", label:"Final<br/>Drawing<br/>Complete", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"approvalDrawingDate", label:"Approval<br/>Drawing<br/>Complete", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"iomReceivedDate", label:"IOM Info<br/>Received", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"estimatedCost", label:"Estimate<br/>Cost", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,10}$/,finalRegExp:'^\\d{10}$',maxLength:10, size: 10, formatTag:true, table: 'costSchedule'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:10, size:10},sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"estimatedSource", label:"Estimate<br/>Source", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,10}$/,finalRegExp:'^\\d{10}$',maxLength:10, size: 10}), editorOptions:{disableBtns:true, blockAlphabets:false, maxLength:10, size:10},sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"fundingSourceId", label:"Funding<br/>Source", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:fundingSourceArr}), editorOptions:{disableBtns:true, dropdownOptions:fundingSourceArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"estimatedMechHours", label:"Est Mechanical<br/>Hours", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$',maxLength:3, size: 3}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3},sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"escalationFactor", label:"Escalation<br/>Factor", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,1}(?:\.\d{0,3})?$/,finalRegExp:'^\\d{1}.\\d{3}$',maxLength:5, size: 5}), editorOptions:{disableBtns:true, allowDecimals:true, blockAlphabets:true, maxLength:5, size:5, wholeNumSize:1, precision:3},sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"overUnderReadOnly", label:"Over/Under", formatter: this.overUnderFormatter, resizeable:true, width:100};
  return columnDefs;
}
