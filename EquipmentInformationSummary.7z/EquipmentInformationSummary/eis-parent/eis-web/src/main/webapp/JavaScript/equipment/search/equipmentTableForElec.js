var inputArr = null;
var outputArr = null;
var measurementArr = null;
var searchEquipmentsDataTableForElec = null;

function getRefDataForElectrical() {
  this.populateArrays = {
    success: function(o) {
      var xmlDoc = o.responseXML;
      inputArr = populateArrayForDropdown(xmlDoc, 'inputs/electricalInput', 'id', 'input');
      outputArr = populateArrayForDropdown(xmlDoc, 'outputs/electricalOutput', 'id', 'output');
      measurementArr = populateArrayForDropdown(xmlDoc, 'otherMeasurements/otherMeasurement', 'id', 'measurement');
      document.getElementById('searchElectricalBtn').disabled = '';
    },
    failure: function(o) {
      document.location.href = document.getElementById('contextPath').value +
                               "/servlet/logon?method=error";
    },
    timeout: 30000 //30 seconds
  };

  var url = document.getElementById('contextPath').value +
            "/data/equipmentRefDataXml/details?method=lookupRefDataForElectricalXML";
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url,
      this.populateArrays);
}

function createEquipmentsListTabForElec(url) {
  if (searchEquipmentsDataTableForElec == null) {
    this.equipmentsListDataSource = createServerSidePaginationDataSource(url);
    var fieldArr = getCommonEquipmentFields();
    fieldArr[fieldArr.length] = "electId";
    fieldArr[fieldArr.length] = "proofOfPositionReq";
    fieldArr[fieldArr.length] = "solenoidReq";
    fieldArr[fieldArr.length] = "localPushButtonReq";
    for (var i = 1; i < inputArr.length; i++) {
      fieldArr[fieldArr.length] = "inputQuantityId" + inputArr[i].value;
      fieldArr[fieldArr.length] = "inputId" + inputArr[i].value;
      fieldArr[fieldArr.length] = "inputIdChecked" + inputArr[i].value;
      fieldArr[fieldArr.length] = "inputQty" + inputArr[i].value;
    }
    for (i = 1; i < outputArr.length; i++) {
      fieldArr[fieldArr.length] = "outputQuantityId" + outputArr[i].value;
      fieldArr[fieldArr.length] = "outputId" + outputArr[i].value;
      fieldArr[fieldArr.length] = "outputIdChecked" + outputArr[i].value;
      fieldArr[fieldArr.length] = "outputQty" + outputArr[i].value;
    }
//    fieldArr[fieldArr.length] = "inputId";
    //    fieldArr[fieldArr.length] = "inputQty";
    //    fieldArr[fieldArr.length] = "outputId";
    //    fieldArr[fieldArr.length] = "outputQty";
    fieldArr[fieldArr.length] = "hmiDisplay";
    fieldArr[fieldArr.length] = "otherMeasurementId";
    fieldArr[fieldArr.length] = "communications";
    fieldArr[fieldArr.length] = "voltage";
    this.equipmentsListDataSource.responseSchema = {
      resultNode: "electrical",
      fields: fieldArr,
      metaFields: {totalRecords : "totalRecords"}
    };
    searchEquipmentsDataTableForElec = getEquipmentTableForElec(getEquipmentsColumnDefsForElec(), this.equipmentsListDataSource);
  } else {
    searchEquipmentsDataTableForElec.requery(url);
  }
}

function getElecColumnKeyToClassNameMap() {
  var columnKeyToClassNameMap = new Object();
  columnKeyToClassNameMap["proofOfPositionReq"] = "Electrical";
  columnKeyToClassNameMap["solenoidReq"] = "Electrical";
  columnKeyToClassNameMap["localPushButtonReq"] = "Electrical";
//  for (var i = 1; i < inputArr.length; i++) {
  //    fieldArr[fieldArr.length] = "inputId" + inputArr[i].value;
  //    fieldArr[fieldArr.length] = "inputQty" + inputArr[i].value;
  //  }
  //  for (i = 1; i < outputArr.length; i++) {
  //    fieldArr[fieldArr.length] = "outputId" + outputArr[i].value;
  //    fieldArr[fieldArr.length] = "outputQty" + outputArr[i].value;
  //  }
  //
  //
  //
  //  columnKeyToClassNameMap["inputId"] = "Electrical";
  //  columnKeyToClassNameMap["inputQty"] = "Electrical";
  //  columnKeyToClassNameMap["outputId"] = "Electrical";
  //  columnKeyToClassNameMap["outputQty"] = "Electrical";

  columnKeyToClassNameMap["hmiDisplay"] = "Electrical";
  columnKeyToClassNameMap["otherMeasurementId"] = "Electrical";
  columnKeyToClassNameMap["communications"] = "Electrical";
  columnKeyToClassNameMap["voltage"] = "Electrical";
  return columnKeyToClassNameMap;
}

function getElecPrimaryKeyForClassName(className) {
  return "electId";
}

function getEquipmentTableForElec(columnDefs, dataSource) {
  var editableTableParams = null;
  var autosaveParams = null;
  if (userHasEditAccessToThisProject()) {
    editableTableParams = {};
    editableTableParams.firstEditableColumnIndex = 9;
    editableTableParams.lastEditableColumnIndex = 17;
    editableTableParams.newRecord = null;

    autosaveParams = {};
    autosaveParams.columnKeyToClassNameMap = getElecColumnKeyToClassNameMap();
    autosaveParams.primaryKeyForClassNameFnc = getElecPrimaryKeyForClassName;
    autosaveParams.formattedValueFnc = null;
  }

  searchEquipmentsDataTableForElec = createEditableDataTable("equipmentsListForElec", columnDefs, dataSource, "equipmentNumber",
  {scrollable:true, width:getWidthForDataTable(), draggableColumns:true, emptyMsg:"No Matching Equipment Items Found"},
  {pagination:true, topPaginator:'topPaginatorForEquipmentsForElec'}, {editableTableParams:editableTableParams, autosaveParams:autosaveParams});

  var dt = searchEquipmentsDataTableForElec.getDataTable();
  dt.subscribe('editorSaveEvent', function(oArgs) {
    var oRecord = oArgs.record;
    var oColumn = oArgs.column;
    if (oRecord === undefined) {//For Yahoo's BaseCellEditor
      oRecord = oArgs.editor.getRecord();
      oColumn = oArgs.editor.getColumn();
    }
    var oKey = oColumn.key;
    var queryStr = null;
    queryStr = getQueryStringForAutosave(searchEquipmentsDataTableForElec, oRecord, oKey);
    if (queryStr === null) {
      if (oKey.search('inputId') === 0 || oKey.search('inputQty') === 0) {//oKey startsWith these strings
        var className = 'ElectricalInputQuantity';
        if (oKey.search('inputId') === 0) {
          var valueOfId = oKey.substring(7, oKey.length)//1189 outof inputId1189
          var fieldName = "checked";
          var oValue = oRecord.getData(oKey);
        } else {
          valueOfId = oKey.substring(8, oKey.length)//1189 outof inputQty1189
          fieldName = "inputQty";
          oValue = oRecord.getData(oKey);
        }
        var primaryKey = oRecord.getData("inputQuantityId" + valueOfId);
      } else {
        if (oKey.search('outputId') === 0 || oKey.search('outputQty') === 0) {
          className = 'ElectricalOutputQuantity';
          if (oKey.search('outputId') === 0) {
            valueOfId = oKey.substring(8, oKey.length)
            fieldName = "checked";
            oValue = oRecord.getData(oKey);
          } else {
            valueOfId = oKey.substring(9, oKey.length)
            fieldName = "outputQty";
            oValue = oRecord.getData(oKey);
          }
          primaryKey = oRecord.getData("outputQuantityId" + valueOfId);
        }
      }
      queryStr = "&className=" + className + "&primaryKey=" + primaryKey + "&fieldName=" + fieldName + "&fieldValue=" +
                 oValue;
      autosaveValue(this, queryStr);
    }
  });

  return searchEquipmentsDataTableForElec;
}

function getEquipmentsColumnDefsForElec() {
  this.electricalCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (userHasEditAccessToThisProject()) {
      if (oData === "true") {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForElec, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox" checked="true"/>';
      } else {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForElec, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox"/>';
      }
    } else {
      if (oData === "true") {
        var contextPath = document.getElementById('contextPath').value;
        el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
      }
    }
  }

  this.electricalInputOutputCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    var oKey = oColumn.key;
    if(oKey.search("inputId") === 0){
      var valueOfId = oKey.substring(7, oKey.length)//inputId
      oData = oRecord.getData("inputIdChecked" + valueOfId);
    }else{
      valueOfId = oKey.substring(8, oKey.length)//outputId
      oData = oRecord.getData("outputIdChecked" + valueOfId);
    }
    if (userHasEditAccessToThisProject()) {
      if (oData === "true") {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForElec, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox" checked="true"/>';
      } else {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForElec, \'' +
                       oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox"/>';
      }
    } else {
      if (oData === "true") {
        var contextPath = document.getElementById('contextPath').value;
        el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
      }
    }
  }
  var columnDefs = getCommonEquipmentColumnDefs();
  columnDefs = columnDefs.concat(getElectricalColumnDefs());
  return columnDefs;
}

function getElectricalColumnDefs() {
  var columnDefs = [];
  var className = getClassNameForEditableCell();

  this.textboxEditorForElec = function (oEditor, oSelf) {
    textboxEditor(oEditor, searchEquipmentsDataTableForElec);
  }
  this.textAreaEditorForElec = function (oEditor, oSelf) {
    textAreaEditor(oEditor, searchEquipmentsDataTableForElec);
  }
  this.dropdownEditorForElec = function (oEditor, oSelf) {
    dropdownEditor(oEditor, searchEquipmentsDataTableForElec);
  }
  columnDefs[columnDefs.length] = {key:"proofOfPositionReq", label:"P of P", abbr:"Proof Of Position", className:className, formatter: this.electricalCheckboxFormatter, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"solenoidReq", label:"Sol", abbr:"Solenoid Required", className:className, formatter: this.electricalCheckboxFormatter, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"localPushButtonReq", label:"Push", abbr:"Local PushButtons Required", className:className, formatter: this.electricalCheckboxFormatter, sortable:true, resizeable:true, width:50};

  for (var i = 1; i < inputArr.length; i++) {
    columnDefs[columnDefs.length] = {key:"inputId" + inputArr[i].value, label:inputArr[i].label, abbr:inputArr[i].label + " Input", className:"elecInputOuput " +
                                                                                                              className, formatter: this.electricalInputOutputCheckboxFormatter, sortable:true, resizeable:true, width:40};
    columnDefs[columnDefs.length] = {key:"inputQty" + inputArr[i].value, label:inputArr[i].label +  "<br/>Qty", abbr:inputArr[i].label + " Quantity", className:"elecInputOuput " +
                                                                                                               className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,2}$/, finalRegExp:'^\\d{2}$', maxLength:2, size: 2}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:40};
  }

  for (i = 1; i < outputArr.length; i++) {
    columnDefs[columnDefs.length] = {key:"outputId" + outputArr[i].value, label:outputArr[i].label, abbr:outputArr[i].label + " Output", className:"elecInputOuput " +
                                                                                                                className, formatter: this.electricalInputOutputCheckboxFormatter, sortable:true, resizeable:true, width:40};
    columnDefs[columnDefs.length] = {key:"outputQty" + outputArr[i].value, label:outputArr[i].label + "<br/>Qty", abbr:outputArr[i].label + " Quantity", className:"elecInputOuput " +
                                                                                                                className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,2}$/, finalRegExp:'^\\d{2}$', maxLength:2, size: 2}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:40};
  }

//  columnDefs[columnDefs.length] = {key:"inputId", label:"In", abbr:"Inputs", className:className, editor:dropdownEditorForElec, editorOptions:{disableBtns:true, dropdownOptions:inputArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:40};
  //  columnDefs[columnDefs.length] = {key:"inputQty", label:"# In", abbr:"Input Quantity", className:className, editor:textboxEditorForElec, editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:40};
  //  columnDefs[columnDefs.length] = {key:"outputId", label:"Out", abbr:"Outputs", className:className, editor:dropdownEditorForElec, editorOptions:{disableBtns:true, dropdownOptions:outputArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:40};
  //  columnDefs[columnDefs.length] = {key:"outputQty", label:"# Out", abbr:"Output Quantity", className:className, editor:textboxEditorForElec, editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:40};
  columnDefs[columnDefs.length] = {key:"hmiDisplay", label:"HMI<br/>Display", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:30, size: 30}), editorOptions:{disableBtns:true, maxLength:30, size:30}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"otherMeasurementId", label:"Other", abbr:"Other<br/>Measurement", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:measurementArr}), editorOptions:{disableBtns:true, dropdownOptions:measurementArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:60};
  columnDefs[columnDefs.length] = {key:"communications", label:"Communications", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:30, size: 30}), editorOptions:{disableBtns:true, maxLength:30, size:30}, sortable:true, resizeable:true, width:120};
  columnDefs[columnDefs.length] = {key:"voltage", label:"Volt", abbr:"Supply Voltage", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,3}$/, finalRegExp:'^\\d{3}$', maxLength:3, size: 3}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:60};
  return columnDefs;
}
