var ioTypeArray = null;
var searchEquipmentsDataTableForInst = null;

function getRefDataForInstrument() {
  this.populateArrays = {
    success: function(o) {
      var xmlDoc = o.responseXML;
      ioTypeArray = populateArrayForDropdown(xmlDoc, 'ioTypes/ioType', 'id', 'name');
      document.getElementById('searchInstrumentBtn').disabled = '';
    },
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    },
    timeout: 30000 //30 seconds
  };

  var url = document.getElementById('contextPath').value +
            "/data/equipmentRefDataXml/details?method=lookupRefDataForInstrumentXML";
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url,
      this.populateArrays);
}

function createEquipmentsListTabForInst(url) {
  if (searchEquipmentsDataTableForInst == null) {
    this.equipmentsListDataSource = createServerSidePaginationDataSource(url);
    var fieldArr = getCommonEquipmentFields();
    fieldArr = fieldArr.concat(getColumnDefsForInstrument());
    this.equipmentsListDataSource.responseSchema = {
      resultNode: "instrument",
      fields: fieldArr,
      metaFields: {totalRecords : "totalRecords"}
    };
    searchEquipmentsDataTableForInst = getEquipmentTableForInst(getEquipmentsColumnDefsForInst(), this.equipmentsListDataSource);
  } else {
    searchEquipmentsDataTableForInst.requery(url);
  }
}
function getInstColumnKeyToClassNameMap() {
  var instColumnKeyToClassNameMap = new Object();
  instColumnKeyToClassNameMap["instDescription"] = "Instrument";
  instColumnKeyToClassNameMap["manufacturer"] = "Instrument";
  instColumnKeyToClassNameMap["modelNumber"] = "Instrument";
  instColumnKeyToClassNameMap["ioTypeId"] = "Instrument";
  instColumnKeyToClassNameMap["alarmPoints"] = "Instrument";
  instColumnKeyToClassNameMap["alarmPointsQuantity"] = "Instrument";
  instColumnKeyToClassNameMap["volts"] = "Instrument";
  instColumnKeyToClassNameMap["range"] = "Instrument";
  instColumnKeyToClassNameMap["units"] = "Instrument";
  instColumnKeyToClassNameMap["comments"] = "Instrument";
  instColumnKeyToClassNameMap["bidPackage"] = "Instrument";
  instColumnKeyToClassNameMap["purchasedWithEquipment"] = "Instrument";
  instColumnKeyToClassNameMap["vendor"] = "Purchasing";
  instColumnKeyToClassNameMap["rtpNumber"] = "Purchasing";
  instColumnKeyToClassNameMap["poNumber"] = "Purchasing";
  instColumnKeyToClassNameMap["lineNumber"] = "Purchasing";
  instColumnKeyToClassNameMap["estimatedCost"] = "Instrument";
  instColumnKeyToClassNameMap["actualCost"] = "Instrument";
  instColumnKeyToClassNameMap["actualDeliveryDate"] = "Purchasing";
  return instColumnKeyToClassNameMap;
}

function getInstPrimaryKeyForClassName(className) {
  if (className === "Purchasing") {
    return "purchaseId";
  }
  return "instrumentId";
}

function getInstFormattedValue(oKey, oValue) {
  if (oKey === "actualDeliveryDate") {
    return formatDateForSaving(oValue);
  }
  return oValue;
}


function getEquipmentTableForInst(columnDefs, dataSource) {
  var editableTableParams = null;
  var autosaveParams = null;
  if (userHasEditAccessToThisProject()) {
    editableTableParams = {};
    editableTableParams.firstEditableColumnIndex = 7;
    editableTableParams.lastEditableColumnIndex = 26;
    editableTableParams.newRecord = null;

    autosaveParams = {};
    autosaveParams.columnKeyToClassNameMap = getInstColumnKeyToClassNameMap();
    autosaveParams.primaryKeyForClassNameFnc = getInstPrimaryKeyForClassName;
    autosaveParams.formattedValueFnc = getInstFormattedValue;
  }

  searchEquipmentsDataTableForInst = createEditableDataTable("equipmentsListForInst", columnDefs, dataSource, "equipmentNumber",
  {scrollable:true, width:getWidthForDataTable(), draggableColumns:true, emptyMsg:"No Matching Equipment Items Found"},
  {pagination:true, topPaginator:'topPaginatorForEquipmentsForInst'}, {editableTableParams:editableTableParams, autosaveParams:autosaveParams});

  if (userHasEditAccessToThisProject()) {
    var dt = searchEquipmentsDataTableForInst.getDataTable();
    //make accessory's purchasing columns non-editable if purchased with equipment is checked
    dt.subscribe('cellClickEvent', function (oArgs) {
      onCellClickOfInstAndAcce(dt, oArgs);
    });
    dt.subscribe('checkboxClickEvent', function(oArgs) {
      onCheckboxClickOfInstAndAcce(dt, oArgs);
    });

    dt.subscribe('editorSaveEvent', function(oArgs) {
      var oRecord = oArgs.record;
      var oColumn = oArgs.column;
      if (oRecord === undefined) {//For Yahoo's BaseCellEditor
        oRecord = oArgs.editor.getRecord();
        oColumn = oArgs.editor.getColumn();
      }
      var oKey = oColumn.key;
      var queryStr = null;
      if (oKey === "purchasedWithEquipment" && oRecord.getData(oKey) === "true") {
        oRecord.setData("vendor", "");
        oRecord.setData("rtpNumber", "");
        oRecord.setData("poNumber", "");
        oRecord.setData("lineNumber", "");
        oRecord.setData("actualDeliveryDate", "");
        var rowIndex = this.getTrEl(oRecord).sectionRowIndex;
        this.updateRow(this.getTrEl(rowIndex), oRecord.getData());

        queryStr = getQueryStringForAutosave(searchEquipmentsDataTableForInst, oRecord, "vendor");
        autosaveValue(this, queryStr);

        queryStr = getQueryStringForAutosave(searchEquipmentsDataTableForInst, oRecord, "rtpNumber");
        autosaveValue(this, queryStr);

        queryStr = getQueryStringForAutosave(searchEquipmentsDataTableForInst, oRecord, "poNumber");
        autosaveValue(this, queryStr);

        queryStr = getQueryStringForAutosave(searchEquipmentsDataTableForInst, oRecord, "lineNumber");
        autosaveValue(this, queryStr);

        queryStr = getQueryStringForAutosave(searchEquipmentsDataTableForInst, oRecord, "actualDeliveryDate");
        autosaveValue(this, queryStr);
      }
    });
  }

  return searchEquipmentsDataTableForInst;
}

function getEquipmentsColumnDefsForInst() {
  this.instrumentTagFormatter = function(elCell, oRecord, oColumn, oData) {
    var designatorFirstTypeCode = oRecord.getData('designatorFirstCharTypeCode');
    var designatorSecondTypeCode = oRecord.getData('designatorSecondCharTypeCode');
    var sequenceNumber = oRecord.getData('sequenceNumber');
    var equipmentNum = oRecord.getData('equipmentNumber');
    elCell.innerHTML = equipmentNum.substring(0, 7) + designatorFirstTypeCode + designatorSecondTypeCode +
                       sequenceNumber;
  }

  this.instrumentCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (userHasEditAccessToThisProject()) {
      if (oData === "true") {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForInst, ' +
                       '\'' + oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox" checked="true"/>';
      } else {
        el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForInst, ' +
                       '\'' + oRecord.getId() +
                       '\',\'' + oColumn.key +
                       '\')" class="yui-dt-checkbox"/>';
      }
    } else {
      if (oData === "true") {
        var contextPath = document.getElementById('contextPath').value;
        el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
      }
    }
  }
  this.textboxEditorForInstList = function (oEditor, oSelf) {
    textboxEditor(oEditor, searchEquipmentsDataTableForInst);
  }
  this.textAreaEditorForInstList = function (oEditor, oSelf) {
    textAreaEditor(oEditor, searchEquipmentsDataTableForInst);
  }
  this.dropdownEditorForInstList = function (oEditor, oSelf) {
    dropdownEditor(oEditor, searchEquipmentsDataTableForInst);
  }

  var columnDefs = getCommonEquipmentColumnDefs();
  var className = getClassNameForEditableCell();

  columnDefs[columnDefs.length] = {key:"tag", label:"Instrument<br/>Tag", formatter:this.instrumentTagFormatter, resizeable:true, width:120};
  columnDefs[columnDefs.length] = {key:"instDescription", label:"Description ", className:className, editor:new YAHOO.widget.TextareaCellEditor({disableBtns:true, maxLength:50}), editorOptions:{disableBtns:true, maxLength:50}, formatter:commentsFormatter, sortable:true, resizeable:true, width:120};
  columnDefs[columnDefs.length] = {key:"manufacturer", label:"Manufacturer", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:20, size:20}), editorOptions:{disableBtns:true, blockAlphabets:false, maxLength:20, size:20}, sortable:true, resizeable:true, maxAutoWidth:120, width:100};
  columnDefs[columnDefs.length] = {key:"modelNumber", label:"Model Number", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:30, size:30}), editorOptions:{disableBtns:true, blockAlphabets:false, maxLength:30, size:30}, sortable:true, resizeable:true, maxAutoWidth:120, width:100};
  columnDefs[columnDefs.length] = {key:"ioTypeId", label:"IO Type", className:className, editor:new YAHOO.widget.DropdownCellEditor({disableBtns:true, dropdownOptions:ioTypeArray}), editorOptions:{disableBtns:true, dropdownOptions:ioTypeArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:120};
  columnDefs[columnDefs.length] = {key:"alarmPoints", label:"Alarm<br/>Points", className:className, editor:new YAHOO.widget.TextboxCellEditor({disableBtns:true, maxLength:10, size:10}), editorOptions:{disableBtns:true, size:10, maxLength:10}, sortable:true, resizeable:true, width:120};
  columnDefs[columnDefs.length] = {key:"alarmPointsQuantity", label:"# of AP", abbr:"Alarm Points<br/>Quantity", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,1}$/,finalRegExp:'^\\d{1}$', blockAlphabets:true, maxLength:1, size:1}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:1, size:1}, sortable:true, resizeable:true, width:60};
  columnDefs[columnDefs.length] = {key:"volts", label:"Volts", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$',failedRegExpClassName:'red', blockAlphabets:true, maxLength:3, size:3}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"range", label:"Range", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:10, size:10}), editorOptions:{disableBtns:true, blockAlphabets:false, maxLength:10, size:10}, sortable:true, resizeable:true, maxAutoWidth:120, width:100};
  columnDefs[columnDefs.length] = {key:"comments", label:"Comments", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength:200}), editorOptions:{disableBtns:true, maxLength:200}, formatter:commentsFormatter, sortable:true, resizeable:true, width:120};
  columnDefs[columnDefs.length] = {key:"bidPackage", label:"Bid<br/>Package", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength:250}), editorOptions:{disableBtns:true, maxLength:250}, formatter:commentsFormatter, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"purchasedWithEquipment", label:"P w/E", abbr:"Purchased with <br />Equipment", className:className,  formatter: this.instrumentCheckboxFormatter, sortable:true, resizeable:true, width:50};
  columnDefs[columnDefs.length] = {key:"vendor", label:"Vendor", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:20, size:20}), editorOptions:{disableBtns:true, maxLength:20, size:20}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"rtpNumber", label:"RTP Number", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,8}$/,finalRegExp:'^\\d{8}$', blockAlphabets:true, maxLength:8, size:8}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:8, size:8}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"poNumber", label:"PO Number", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,10}$/,finalRegExp:'^\\d{10}$', blockAlphabets:true, maxLength:10, size:10}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:10, size:10}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"lineNumber", label:"Line Item", formatter:textEditableCellFormatterInstAndAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$', blockAlphabets:true, maxLength:3, size:3}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"actualDeliveryDate", label:"Delivery<br/>Date", formatter:dateEditableCellFormatterForInstAndAcce, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"estimatedCost", label:"Estimated<br/>Cost", className: className, formatter:currencyFormatterInstAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,5}$/,finalRegExp:'^\\d{5}$', blockAlphabets:true, maxLength:5, size:5}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:5, size:5}, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"actualCost", label:"Actual<br/>Cost", className: className, formatter:currencyFormatterInstAcce, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,5}$/,finalRegExp:'^\\d{5}$', blockAlphabets:true, maxLength:5, size:5}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:5, size:5}, sortable:true, resizeable:true, width:80};
  return columnDefs;
}
