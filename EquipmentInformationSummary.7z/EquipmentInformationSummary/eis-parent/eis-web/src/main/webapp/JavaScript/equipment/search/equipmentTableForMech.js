var purchaseScopeArr = null;
var searchEquipmentsDataTableForMech = null;

function getRefDataForMech() {
  this.populateArrays = {
    success: function(o) {
      var xmlDoc = o.responseXML;
      purchaseScopeArr = populateArrayForDropdown(xmlDoc, 'purchaseScopes/purchaseScope', 'id', 'purchaseScopeName');
      document.getElementById('searchMechanicalBtn').disabled = '';
    },
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    },
    timeout: 30000 //30 seconds
  };

  var url = document.getElementById('contextPath').value +
            "/data/equipmentRefDataXml/details?method=lookupRefDataForMechanicalXML";
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url, this.populateArrays);
}

function createEquipmentsListTabForMech(url) {
  if (searchEquipmentsDataTableForMech == null) {
    this.equipmentsListDataSource = createServerSidePaginationDataSource(url);
    var fieldArr = getCommonEquipmentFields();
    fieldArr[fieldArr.length] = "mechId";
    fieldArr[fieldArr.length] = "engineer";
    fieldArr[fieldArr.length] = "modelNumber";
    fieldArr[fieldArr.length] = "serialNumber";
    fieldArr[fieldArr.length] = "shippingWeight";
    fieldArr[fieldArr.length] = "purchaseScopeId";
    fieldArr[fieldArr.length] = "operatingWeight";
    fieldArr[fieldArr.length] = "dynamicLoad";
    this.equipmentsListDataSource.responseSchema = {
      resultNode: "mechanical",
      fields: fieldArr,
      metaFields: {totalRecords : "totalRecords"}
    };
    searchEquipmentsDataTableForMech = getEquipmentTableForMech(getEquipmentsColumnDefsForMech(), this.equipmentsListDataSource);
  } else {
    searchEquipmentsDataTableForMech.requery(url);
  }
}

function getMechColumnKeyToClassNameMap() {
  var columnKeyToClassNameMap = new Object();
  columnKeyToClassNameMap["engineer"] = "Mechanical";
  columnKeyToClassNameMap["modelNumber"] = "Mechanical";
  columnKeyToClassNameMap["serialNumber"] = "Mechanical";
  columnKeyToClassNameMap["shippingWeight"] = "Mechanical";
  columnKeyToClassNameMap["purchaseScopeId"] = "Mechanical";
  columnKeyToClassNameMap["operatingWeight"] = "Mechanical";
  columnKeyToClassNameMap["dynamicLoad"] = "Mechanical";
  return columnKeyToClassNameMap;
}

function getMechPrimaryKeyForClassName(className) {
  return "mechId";
}

function getEquipmentTableForMech(columnDefs, dataSource) {
  var editableTableParams = null;
  var autosaveParams = null;
  if (userHasEditAccessToThisProject()) {
    editableTableParams = {};
    editableTableParams.firstEditableColumnIndex = 6;
    editableTableParams.lastEditableColumnIndex = 13;
    editableTableParams.newRecord = null;
    autosaveParams = {};
    autosaveParams.columnKeyToClassNameMap = getMechColumnKeyToClassNameMap();
    autosaveParams.primaryKeyForClassNameFnc = getMechPrimaryKeyForClassName;
    autosaveParams.formattedValueFnc = null;
  }

  searchEquipmentsDataTableForMech = createEditableDataTable("equipmentsListForMech", columnDefs, dataSource, "equipmentNumber",
  {scrollable:true, width:getWidthForDataTable(), draggableColumns:true, emptyMsg:"No Matching Equipment Items Found"},
  {pagination:true, topPaginator:'topPaginatorForEquipmentsForMech'}, {editableTableParams:editableTableParams, autosaveParams:autosaveParams});
  return searchEquipmentsDataTableForMech;
}

function getEquipmentsColumnDefsForMech() {
  var columnDefs = getCommonEquipmentColumnDefs();
  var className = getClassNameForEditableCell();

  this.textboxEditorForMech = function (oEditor, oSelf) {
    textboxEditor(oEditor, searchEquipmentsDataTableForMech);
  }
  this.dropdownEditorForMech = function (oEditor, oSelf) {
    dropdownEditor(oEditor, searchEquipmentsDataTableForMech);
  }

  columnDefs[columnDefs.length] = {key:"engineer", label:"Engineer", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:20, size:20}), editorOptions:{disableBtns:true, maxLength:20, size:20}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"modelNumber", label:"Model<br/>Number", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:20, size:20}), editorOptions:{disableBtns:true, maxLength:20, size:20}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"serialNumber", label:"Serial<br/>Number", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:30, size:30}), editorOptions:{disableBtns:true, maxLength:30, size:30}, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"purchaseScopeId", label:"Purchase<br/>Scope", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:purchaseScopeArr}), editorOptions:{disableBtns:true, dropdownOptions:purchaseScopeArr}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"shippingWeight", label:"Ship Wt", abbr:"Shipping Weight", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,5}$/, finalRegExp:'^\\d{5}$', maxLength:5, size: 5}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:5, size:5}, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"operatingWeight", label:"Oper Wt", abbr:"Operating Weight", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,5}$/, finalRegExp:'^\\d{5}$', maxLength:5, size: 5}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:5, size:5}, sortable:true, resizeable:true, width:80};
  columnDefs[columnDefs.length] = {key:"dynamicLoad", label:"Dynamic<br/>Load", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,5}$/, finalRegExp:'^\\d{5}$', maxLength:5, size: 5}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:5, size:5}, sortable:true, resizeable:true, width:100};

  return columnDefs;
}