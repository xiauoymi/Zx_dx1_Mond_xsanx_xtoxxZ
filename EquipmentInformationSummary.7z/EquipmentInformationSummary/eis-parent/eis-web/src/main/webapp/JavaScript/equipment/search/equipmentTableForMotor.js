var starterArray = null;
var designStatusArray = null;
var loadValueTypeArray = null;
var searchEquipmentsDataTableForMotor = null;
var compDesignatorArray = null;

var compDesignatorIdToTypeCodeMap = {
    set : function(foo, bar) {
        this[foo] = bar;
    },
    get : function(foo) {
        return this[foo];
    }
}

function parseTypeCodeForMotor(designatorValue) {
    var indexOfHyphen = designatorValue.indexOf(" - ");
    return designatorValue.substring(0, indexOfHyphen);
}

function getRefDataForMotor() {
    this.populateArrays = {
        success: function(o) {
            var xmlDoc = o.responseXML;
            //starterArray = populateArrayForDropdown(xmlDoc, 'starters/starter', 'id', 'name');
            designStatusArray = populateArrayForDropdown(xmlDoc, 'designStatuses/designStatus', 'id', 'name');
            loadValueTypeArray = populateArrayForDropdown(xmlDoc, 'loadValueTypes/loadValueType', 'id', 'name');
            document.getElementById('searchMotorBtn').disabled = '';
            compDesignatorArray = populateArrayForDropdown(xmlDoc, 'componentDesignators/componentDesignator', 'id', 'name');
            compDesignatorArray.splice(0, 1);
            for (var i = 0; i < compDesignatorArray.length; i++) {
                var compDesignatorId = compDesignatorArray[i].value;
                var typeCodeDesc = compDesignatorArray[i].label;
                var typeCode = parseTypeCodeForMotor(typeCodeDesc);
                compDesignatorIdToTypeCodeMap.set(compDesignatorId, typeCode);
            }
        },
        failure: function(o) {
            document.location.href = document.getElementById('contextPath').value +
                                     "/servlet/logon?method=error";
        },
        timeout: 30000 //30 seconds
    };

    var url = document.getElementById('contextPath').value +
              "/data/equipmentRefDataXml/details?method=lookupRefDataForMotorXML";
    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
            url,
            this.populateArrays);
}

function createEquipmentsListTabForMotor(url) {
    if (searchEquipmentsDataTableForMotor == null) {
        this.equipmentsListDataSource = createServerSidePaginationDataSource(url);
        var fieldArr = getCommonEquipmentFields();
        fieldArr = fieldArr.concat((getColumnDefsForMotor()));
        this.equipmentsListDataSource.responseSchema = {
            resultNode: "motor",
            fields: fieldArr,
            metaFields: {totalRecords : "totalRecords"}
        };
        searchEquipmentsDataTableForMotor = getEquipmentTableForMotor(getEquipmentsColumnDefsForMotor(), this.equipmentsListDataSource);
    } else {
        searchEquipmentsDataTableForMotor.requery(url);
    }
}

function getMotorColumnKeyToClassNameMap() {
    var columnKeyToClassNameMap = new Object();
    columnKeyToClassNameMap["componentName"] = "Motor";
    columnKeyToClassNameMap["componentDesignatorTypeCode"] = "Motor";
    columnKeyToClassNameMap["componentDesignatorId"] = "Motor";
    columnKeyToClassNameMap["sequenceNumber"] = "Motor";
    columnKeyToClassNameMap["fla"] = "Motor";
    columnKeyToClassNameMap["motorVoltage"] = "Motor";
    columnKeyToClassNameMap["phase"] = "Motor";
    columnKeyToClassNameMap["frequency"] = "Motor";
    columnKeyToClassNameMap["rpm"] = "Motor";
    columnKeyToClassNameMap["designStatusId"] = "Motor";
    columnKeyToClassNameMap["comments"] = "Motor";
    columnKeyToClassNameMap["loadValueTypeId"] = "Motor";
    columnKeyToClassNameMap["loadValueQuantity"] = "Motor";
    columnKeyToClassNameMap["powerSource"] = "Motor";
    columnKeyToClassNameMap["ioCabinet"] = "Motor";
    columnKeyToClassNameMap["loadDisconnectRequired"] = "Motor";
    columnKeyToClassNameMap["starterSize"] = "Motor";
    columnKeyToClassNameMap["motorBrake"] = "Motor";
    columnKeyToClassNameMap["bidPackage"] = "Motor";
    return columnKeyToClassNameMap;
}

function getMotorPrimaryKeyForClassName(className) {
    return "motorId";
}

function getEquipmentTableForMotor(columnDefs, dataSource) {
    var editableTableParams = null;
    var autosaveParams = null;
    if (userHasEditAccessToThisProject()) {
        editableTableParams = {};
        editableTableParams.firstEditableColumnIndex = 7;
        editableTableParams.lastEditableColumnIndex = 24;
        editableTableParams.newRecord = null;
        autosaveParams = {};
        autosaveParams.columnKeyToClassNameMap = getMotorColumnKeyToClassNameMap();
        autosaveParams.primaryKeyForClassNameFnc = getMotorPrimaryKeyForClassName;
        autosaveParams.formattedValueFnc = null;
    }

    searchEquipmentsDataTableForMotor = createEditableDataTable("equipmentsListForMotor", columnDefs, dataSource, "equipmentNumber",
    {scrollable:true, width:getWidthForDataTable(), draggableColumns:true, emptyMsg:"No Matching Equipment Items Found"},
    {pagination:true, topPaginator:'topPaginatorForEquipmentsForMotor'}, {editableTableParams:editableTableParams, autosaveParams:autosaveParams});
    return searchEquipmentsDataTableForMotor;
}

function createComponentNumberForMotorsList(oRecord) {
    var componentDesignatorId = oRecord.getData('componentDesignatorId');
    var componentDesignatorTypeCode = compDesignatorIdToTypeCodeMap.get(componentDesignatorId);
    var sequenceNumber = oRecord.getData('sequenceNumber');
    var equipmentNum = oRecord.getData('equipmentNumber');
    return equipmentNum.substring(0, 7) + componentDesignatorTypeCode + sequenceNumber;
}

function getEquipmentsColumnDefsForMotor() {
    this.motorComponentNumberFormatter = function(elCell, oRecord, oColumn, oData) {
        var componentDesignatorTypeCode = oRecord.getData('componentDesignatorTypeCode');
        var sequenceNumber = oRecord.getData('sequenceNumber');
        var equipmentNum = oRecord.getData('equipmentNumber');
        elCell.innerHTML = equipmentNum.substring(0, 7) + componentDesignatorTypeCode + sequenceNumber;
    }
    this.motorCheckboxFormatter = function(el, oRecord, oColumn, oData) {
        if (userHasEditAccessToThisProject()) {
            if (oData === "true") {
                el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForMotor, \'' +
                               oRecord.getId() +
                               '\',\'' + oColumn.key +
                               '\')" class="yui-dt-checkbox" checked="true"/>';
            } else {
                el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForMotor, \'' +
                               oRecord.getId() +
                               '\',\'' + oColumn.key +
                               '\')" class="yui-dt-checkbox"/>';
            }
        } else {
            if (oData === "true") {
                var contextPath = document.getElementById('contextPath').value;
                el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
            }
        }
    }

    this.textboxEditorForMotorList = function (oEditor, oSelf) {
        textboxEditor(oEditor, searchEquipmentsDataTableForMotor);
    }
    this.textAreaEditorForMotorList = function (oEditor, oSelf) {
        textAreaEditor(oEditor, searchEquipmentsDataTableForMotor);
    }
    this.dropdownEditorForMotorList = function (oEditor, oSelf) {
        dropdownEditor(oEditor, searchEquipmentsDataTableForMotor);
    }

    var columnDefs = getCommonEquipmentColumnDefs();
    var className = getClassNameForEditableCell();
    columnDefs[columnDefs.length] = {key:"componentNumber", label:"Component #", formatter: this.motorComponentNumberFormatter, resizeable:true, width:85};
    columnDefs[columnDefs.length] = {key:"componentName", label:"Component<br/>Name", className:className, editor:new YAHOO.widget.TextboxCellEditor({disableBtns:true, maxLength:30}), editorOptions:{disableBtns:true, maxLength:30}, sortable:true, resizeable:true, width:120};
    columnDefs[columnDefs.length] = {key:"componentDesignatorId", label:"Designator<span class='required'>*</span>", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:compDesignatorArray, formatTag: true, table: "motorsList"}), editorOptions:{disableBtns:true, dropdownOptions:compDesignatorArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:120};
    columnDefs[columnDefs.length] = {key:"loadValueQuantity", label:"Load", abbr:"Load Value Quantity", className:className, editor:new YAHOO.widget.TextboxCellEditor({disableBtns:true, regExp:/^\d{0,4}(?:\.\d{0,2})?$/,finalRegExp:'^\\d{4}.\\d{2}$', maxLength:7, size:7}), editorOptions:{disableBtns:true, allowDecimals:true, maxLength:7, size:7, wholeNumSize:4, precision:2}, sortable:true, resizeable:true, width:60};
    columnDefs[columnDefs.length] = {key:"loadValueTypeId", label:"Load Units", abbr:"Load Units", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:loadValueTypeArray}), editorOptions:{disableBtns:true, dropdownOptions:loadValueTypeArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:80};
    columnDefs[columnDefs.length] = {key:"fla", label:"FLA", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,3}(?:\.\d{0,1})?$/,finalRegExp:'^\\d{3}.\\d{1}$',maxLength:5, size:5}), editorOptions:{disableBtns:true, allowDecimals:true, maxLength:5, size:5, wholeNumSize:3, precision:1}, sortable:true, resizeable:true, width:40};
    columnDefs[columnDefs.length] = {key:"motorVoltage", label:"Volt", abbr:"Motor Voltage", className:className, editor:new YAHOO.widget.TextboxCellEditor({disableBtns:true, blockAlphabets:true, maxLength:4, size:4}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:4, size:4}, sortable:true, resizeable:true, width:50};
    columnDefs[columnDefs.length] = {key:"phase", label:"Ph", abbr:"Phase",className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,1}$/,finalRegExp:'^\\d{1}$', maxLength:1, size:1}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:1, size:1}, sortable:true, resizeable:true, width:50};
    columnDefs[columnDefs.length] = {key:"frequency", label:"Freq", abbr:"Frequency", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,2}$/,finalRegExp:'^\\d{2}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:2, size:2}, sortable:true, resizeable:true, width:50};
    columnDefs[columnDefs.length] = {key:"rpm", label:"RPM", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,4}$/,finalRegExp:'^\\d{4}$'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:4, size:4}, sortable:true, resizeable:true, width:50};
    // columnDefs[columnDefs.length] = {key:"starterId", label:"Starter", editor:dropdownEditor, editorOptions:{disableBtns:true, dropdownOptions:starterArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:120};
    columnDefs[columnDefs.length] = {key:"designStatusId", label:"Design<br/>Status", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:designStatusArray}), editorOptions:{disableBtns:true, dropdownOptions:designStatusArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:80};
    columnDefs[columnDefs.length] = {key:"comments", label:"Comments", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength:200}), editorOptions:{disableBtns:true, maxLength:200}, formatter:commentsFormatter, sortable:true, resizeable:true, maxAutoWidth:120, width:120};
    columnDefs[columnDefs.length] = {key:"powerSource", label:"Power<br/>Source", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 10}), editorOptions:{disableBtns:true, maxLength:10}, sortable:true, resizeable:true, width:80};
    columnDefs[columnDefs.length] = {key:"ioCabinet", label:"IO Cabinet", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 10}), editorOptions:{disableBtns:true, maxLength:10}, sortable:true, resizeable:true, width:80};
    columnDefs[columnDefs.length] = {key:"loadDisconnectRequired", label:"LDR", abbr:"Load Disconnect Required", className:className, formatter: this.motorCheckboxFormatter, sortable:true, resizeable:true, width:50};
    columnDefs[columnDefs.length] = {key:"starterSize", label:"Size", abbr:"Starter Size", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength: 4, size: 4}), editorOptions:{disableBtns:true, maxLength:4, size:4}, sortable:true, resizeable:true, width:40};
    columnDefs[columnDefs.length] = {key:"motorBrake", label:"Motor<br/>Brake", className:className, formatter: this.motorCheckboxFormatter, sortable:true, resizeable:true, width:50};
    columnDefs[columnDefs.length] = {key:"bidPackage", label:"Bid<br/>Package", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength: 250}), editorOptions:{disableBtns:true, maxLength:250}, formatter:commentsFormatter, sortable:true, resizeable:true, maxAutoWidth:250, width:120};
    return columnDefs;
}
