var gasTypeArray = null;
var waterTypeArray = null;
var dustTypeArray = null;
var designCapacityUnitArray = [{value:"", label:"Select"}];
var lastSelectedEquipmentTypeId = null;
var searchEquipmentsDataTableForProcess = null;

var keyToColumnDefMap = {
  set : function(foo, bar) {
    this[foo] = bar;
  },
  get : function(foo) {
    return this[foo];
  }
}

var equipmentTypeCodeToKeyMap = {
  set : function(foo, bar) {
    this[foo] = bar;
  },
  get : function(foo) {
    return this[foo];
  }
}

var equipmentTypeIdToFieldMap = {
  set : function(foo, bar) {
    this[foo] = bar;
  },
  get : function(foo) {
    return this[foo];
  }
}

var equipmentTypeIdToFieldArrayMap = {
  set : function(foo, bar) {
    this[foo] = bar;
  },
  get : function(foo) {
    return this[foo];
  }
}

var fieldNameToValueArrayMap = {
  set : function(foo, bar) {
    this[foo] = bar;
  },
  get : function(foo) {
    return this[foo];
  }
}

var equipmentTypeIdToColumnDefMap = {
  set : function(foo, bar) {
    this[foo] = bar;
  },
  get : function(foo) {
    return this[foo];
  }
}

function populateKeyToColumnDefMap() {
  this.textboxEditorForProcess = function (oEditor, oSelf) {
    textboxEditor(oEditor, searchEquipmentsDataTableForProcess);
  }
  this.textAreaEditorForProcess = function (oEditor, oSelf) {
    textAreaEditor(oEditor, searchEquipmentsDataTableForProcess);
  }
  this.dropdownEditorForProcess = function (oEditor, oSelf) {
    dropdownEditor(oEditor, searchEquipmentsDataTableForProcess);
  }
  var className = getClassNameForEditableCell();
  keyToColumnDefMap.set("productType", [{key:"productType", label:"Product<br/>Type", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:30, size:30}), editorOptions:{disableBtns:true, maxLength:30, size:30}, sortable:true, resizeable:true, width:100}]);
  keyToColumnDefMap.set("productDensity", [{key:"productDensity", label:"Product<br/>Density", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:/^\d{0,2}(?:\.\d{0,2})?$/,finalRegExp:'^\\d{2}.\\d{2}$',maxLength:5, size:5}), editorOptions:{disableBtns:true, allowDecimals:true, maxLength:5, size:5, wholeNumSize:2, precision:2}, sortable:true, resizeable:true, width:60}]);
  keyToColumnDefMap.set("designCapacity", [{key:"designCapacity", label:"Design<br/>Capacity", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,5}$/,finalRegExp:'^\\d{5}$', maxLength:5, size:5}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:5, size:5}, sortable:true, resizeable:true, width:60}]);
  keyToColumnDefMap.set("designCapacityUnitId", [{key:"designCapacityUnitId", label:"Design<br/>Capacity Unit", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:designCapacityUnitArray}), editorOptions: {disableBtns:true, dropdownOptions:designCapacityUnitArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:100}]);
  keyToColumnDefMap.set("designCapacityUnitText", [{key:"designCapacityUnitText", label:"DCU Text", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:10, size: 10}), editorOptions:{disableBtns:true, blockAlphabets:false, maxLength:10, size:10}, sortable:true, resizeable:true, width:60}]);
  keyToColumnDefMap.set("compAirRequired", [{key:"compAirRequired", label:"Air", abbr:"Comp Air Required", className:className, formatter: processCheckboxFormatter, sortable:true, resizeable:true, width:40}]);
  keyToColumnDefMap.set("compAirPressure", [{key:"compAirPressure", label:"Press", abbr:"Comp Air Pressure", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$', maxLength:3, size:3}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:40}]);
  keyToColumnDefMap.set("compAirFlowrate", [{key:"compAirFlowrate", label:"Flow", abbr:"Comp Air Flowrate", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$', maxLength:3, size:3}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:40}]);
  keyToColumnDefMap.set("gasRequired", [{key:"gasRequired", label:"Fuel", abbr:"Gas Required",className:className, formatter: processCheckboxFormatter, sortable:true, resizeable:true, width:40}]);
  keyToColumnDefMap.set("gasTypeId", [{key:"gasTypeId", label:"Gas<br/>Type", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:gasTypeArray}), editorOptions:{disableBtns:true, dropdownOptions:gasTypeArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:40}]);
  keyToColumnDefMap.set("gasPressure", [{key:"gasPressure", label:"Press", abbr:"Gas Pressure",className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$', maxLength:3, size:3}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:40}]);
  keyToColumnDefMap.set("gasFlowrate", [{key:"gasFlowrate", label:"Flow", abbr:"Gas Flowrate", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$', maxLength:3, size:3}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:40}]);
  keyToColumnDefMap.set("waterRequired", [{key:"waterRequired", label:"Water", abbr:"Water Required", className:className, formatter: processCheckboxFormatter, sortable:true, resizeable:true, width:50}]);
  keyToColumnDefMap.set("waterPressure", [{key:"waterPressure", label:"Press", abbr:"Water Pressure", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$', maxLength:1, size:1}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:40}]);
  keyToColumnDefMap.set("waterFlowrate", [{key:"waterFlowrate", label:"Flow", abbr:"Water Flowrate", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$', maxLength:1, size:1}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:40}]);
  keyToColumnDefMap.set("waterTypeId", [{key:"waterTypeId", label:"Water<br/>Type", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:waterTypeArray}), editorOptions:{disableBtns:true, dropdownOptions:waterTypeArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:80}]);
  keyToColumnDefMap.set("dustPickupRequired", [{key:"dustPickupRequired", label:"Dust", abbr:"Dust Pickup Required", className:className, formatter: processCheckboxFormatter, sortable:true, resizeable:true, width:40}]);
  keyToColumnDefMap.set("ductSize", [{key:"ductSize", label:"Size", abbr:"Duct Size", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$', maxLength:3, size:3}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:40}]);
  keyToColumnDefMap.set("ductFlowrate", [{key:"ductFlowrate", label:"Flow", abbr:"Duct Flowrate", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,5}$/,finalRegExp:'^\\d{5}$', maxLength:5, size:5}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:5, size:5}, sortable:true, resizeable:true, width:40}]);
  keyToColumnDefMap.set("baghouseCyclone", [{key:"baghouseCyclone", label:"ConBag/Cyc", abbr:"Connecting Baghouse/Cyclone", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:12, size:12}), editorOptions:{disableBtns:true, maxLength:12, size:12}, sortable:true, resizeable:true, width:80}]);
  keyToColumnDefMap.set("dustPickupVelocity", [{key:"dustPickupVelocity", label:"DPVel", abbr:"Dust Pickup Velocity", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true,regExp:/^\d{0,4}$/,finalRegExp:'^\\d{4}$', maxLength:4, size:4}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:4, size:4}, sortable:true, resizeable:true, width:50}]);
  keyToColumnDefMap.set("dustTypeId", [{key:"dustTypeId", label:"Dust<br/>Type", className:className, editor:new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:dustTypeArray}), editorOptions:{disableBtns:true, dropdownOptions:dustTypeArray}, formatter:dropDownFormatter, sortable:true, resizeable:true, width:60}]);
  keyToColumnDefMap.set("processRemarks", [{key:"processRemarks", label:"Process<br/>Remarks", className:className, editor:new YAHOO.widget.CustomTextareaCellEditor({disableBtns:true, maxLength:1000}), editorOptions:{disableBtns:true, maxLength:1000}, formatter:commentsFormatter, sortable:true, resizeable:true, width:120}]);
  keyToColumnDefMap.set("specificationRequired", [{key:"specificationRequired", label:"Spec", abbr:"Separate Specification Required",className:className, formatter: processCheckboxFormatter, sortable:true, resizeable:true, width:50}]);
}

function populateEquipmentTypeCodeToKeyMap() {
  equipmentTypeCodeToKeyMap.set("", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText", "compAirRequired", "compAirPressure", "compAirFlowrate", "gasRequired", "gasTypeId", "gasPressure", "gasFlowrate",
    "waterRequired", "waterPressure", "waterFlowrate", "waterTypeId", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("A", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText", "compAirRequired", "compAirPressure", "compAirFlowrate",
    "waterRequired", "waterPressure", "waterFlowrate", "waterTypeId", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("B", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText", "specificationRequired", "processRemarks"]);
  equipmentTypeCodeToKeyMap.set("C", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("D", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText", "gasRequired", "gasTypeId", "gasPressure", "gasFlowrate"]);
  equipmentTypeCodeToKeyMap.set("E", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("F", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText", "compAirRequired", "compAirPressure", "compAirFlowrate", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("G", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText", "compAirRequired", "compAirPressure", "compAirFlowrate", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("H", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText", "compAirRequired", "compAirPressure", "compAirFlowrate", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("I", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText", "compAirRequired", "compAirPressure", "compAirFlowrate", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("J", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("K", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText", "compAirRequired", "compAirPressure", "compAirFlowrate", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("L", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText", "compAirRequired", "compAirPressure", "compAirFlowrate", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("N", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("O", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("P", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("Q", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("R", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("S", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("T", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "waterRequired", "waterPressure", "waterFlowrate", "waterTypeId", "dustPickupRequired", "ductSize", "ductFlowrate","baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("U", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("V", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("W", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("X", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("Y", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "waterRequired", "waterPressure", "waterFlowrate", "waterTypeId", "dustPickupRequired", "ductSize", "ductFlowrate", "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
  equipmentTypeCodeToKeyMap.set("Z", ["productType", "productDensity", "designCapacity", "designCapacityUnitId", "designCapacityUnitText","compAirRequired", "compAirPressure", "compAirFlowrate", "dustPickupRequired", "ductSize", "ductFlowrate",  "baghouseCyclone", "dustPickupVelocity", "dustTypeId", "processRemarks", "specificationRequired"]);
}

function populateFieldEquipmentTypeMaps(xmlDoc) {
  var elements = xmlDoc.selectNodes('//refData/' + "fieldEquipmentTypes/fieldEquipmentType");
  for (var i = 0; i < elements.length; i++) {
    var equipmentTypeId = elements[i].selectSingleNode("equipmentTypeId").firstChild.nodeValue;
    var name = elements[i].selectSingleNode("name").firstChild.nodeValue;
    var label = elements[i].selectSingleNode("label").firstChild.nodeValue;
    var fieldType = elements[i].selectSingleNode("fieldType").firstChild.nodeValue;
    var dataType = elements[i].selectSingleNode("dataType").text;
    var size = elements[i].selectSingleNode("size").firstChild.nodeValue;
    var fieldArray = equipmentTypeIdToFieldMap.get(equipmentTypeId);
    if (fieldArray === undefined) {
      fieldArray = [];
    }
    fieldArray = fieldArray.concat({name:name, label:label, fieldType:fieldType, size:size, dataType:dataType});
    equipmentTypeIdToFieldMap.set(equipmentTypeId, fieldArray);

    var listValues = elements[i].selectNodes("listValues/listValue");
    for (var k = 0; k < listValues.length; k++) {
      var id = listValues[k].selectSingleNode("id").firstChild.nodeValue;
      var value = listValues[k].selectSingleNode("value").firstChild.nodeValue;
      var listValueArray = fieldNameToValueArrayMap.get(name);
      if (listValueArray === undefined) {
        listValueArray = [{value:"", label:"Select"}];
      }
      listValueArray = listValueArray.concat({value:id, label:value});
      fieldNameToValueArrayMap.set(name, listValueArray);
    }
  }
}

var designCapacityUnitMap = {
  set : function(foo, bar) {
    this[foo] = bar;
  },
  get : function(foo) {
    return this[foo];
  }
}

function populateDesignCapacityArrayForDropdown(xmlDoc) {
  var elements = xmlDoc.selectNodes('//refData/equipmentTypes/equipmentType');
  for (var i = 0; i < elements.length; i++) {
    var typeCodeNode = elements[i].selectSingleNode('typeCode');
    var typeCode = typeCodeNode.firstChild.nodeValue;
    var dcuArray = designCapacityUnitMap.get(typeCode);
    if (dcuArray == null) {
      dcuArray = [{value:"", label:"Select"}];
    }
    var dcuElements = elements[i].selectNodes('designCapacityUnits/designCapacityUnit');
    for (var k = 0; k < dcuElements.length; k++) {
      var dcuId = dcuElements[k].selectSingleNode('id').firstChild.nodeValue;
      var dcuUnitName = dcuElements[k].selectSingleNode('unitName').firstChild.nodeValue;
      dcuArray = dcuArray.concat({value:dcuId, label:dcuUnitName});
      designCapacityUnitArray = designCapacityUnitArray.concat(dcuArray);
    }
    designCapacityUnitMap.set(typeCode, dcuArray);
  }
}

function getRefDataForProcess() {
  this.populateArrays = {
    success: function(o) {
      var xmlDoc = o.responseXML;
      gasTypeArray = populateArrayForDropdown(xmlDoc, 'gasTypes/gasType', 'id', 'type');
      waterTypeArray = populateArrayForDropdown(xmlDoc, 'waterTypes/waterType', 'id', 'type');
      dustTypeArray = populateArrayForDropdown(xmlDoc, 'dustTypes/dustType', 'id', 'type');
      populateDesignCapacityArrayForDropdown(xmlDoc);
      populateKeyToColumnDefMap();
      populateEquipmentTypeCodeToKeyMap();
      populateFieldEquipmentTypeMaps(xmlDoc);
      document.getElementById('searchProcessBtn').disabled = '';
    },
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    },
    timeout: 30000 //30 seconds
  };

  var url = document.getElementById('contextPath').value +
            "/data/equipmentRefDataXml/details?method=lookupRefDataForProcessXML" +
            "&unitMeasureId=" + document.getElementById('projectUnitMeasureId').value;
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url,
      this.populateArrays);
}

function createEquipmentsListTabForProcess(url) {
  var equipmentTypeId = getSelectedEquipmentTypeId();
  if (lastSelectedEquipmentTypeId === null || lastSelectedEquipmentTypeId != equipmentTypeId) {
    lastSelectedEquipmentTypeId = equipmentTypeId
    this.equipmentsListDataSource = createServerSidePaginationDataSource(url);
    this.equipmentsListDataSource.responseSchema = {
      resultNode: "process",
      fields: getColumnDefsForProcess(),
      metaFields: {totalRecords : "totalRecords"}
    };

    searchEquipmentsDataTableForProcess = getEquipmentTableForProcess(getEquipmentsColumnDefsForProcess(), this.equipmentsListDataSource);
  } else {
    searchEquipmentsDataTableForProcess.requery(url);
  }
}

function getProcessColumnKeyToClassNameMap() {
  var columnKeyToClassNameMap = new Object();
  columnKeyToClassNameMap["productType"] = "Process";
  columnKeyToClassNameMap["productDensity"] = "Process";
  columnKeyToClassNameMap["designCapacity"] = "Process";
  columnKeyToClassNameMap["designCapacityUnitId"] = "Process";
  columnKeyToClassNameMap["designCapacityUnitText"] = "Process";
  columnKeyToClassNameMap["compAirRequired"] = "Process";
  columnKeyToClassNameMap["compAirPressure"] = "Process";
  columnKeyToClassNameMap["compAirFlowrate"] = "Process";
  columnKeyToClassNameMap["gasRequired"] = "Process";
  columnKeyToClassNameMap["gasTypeId"] = "Process";
  columnKeyToClassNameMap["gasPressure"] = "Process";
  columnKeyToClassNameMap["gasFlowrate"] = "Process";
  columnKeyToClassNameMap["waterRequired"] = "Process";
  columnKeyToClassNameMap["waterPressure"] = "Process";
  columnKeyToClassNameMap["waterFlowrate"] = "Process";
  columnKeyToClassNameMap["waterTypeId"] = "Process";
  columnKeyToClassNameMap["dustPickupRequired"] = "Process";
  columnKeyToClassNameMap["dustPickupVelocity"] = "Process";
  columnKeyToClassNameMap["dustTypeId"] = "Process";
  columnKeyToClassNameMap["baghouseCyclone"] = "Process";
  columnKeyToClassNameMap["ductSize"] = "Process";
  columnKeyToClassNameMap["ductFlowrate"] = "Process";
  columnKeyToClassNameMap["specificationRequired"] = "Process";
  columnKeyToClassNameMap["processRemarks"] = "Process";
  return columnKeyToClassNameMap;
}

function getProcessPrimaryKeyForClassName(className) {
  return "processId";
}

function getEquipmentTableForProcess(columnDefs, dataSource) {
  var editableTableParams = null;
  var autosaveParams = null;
  if (userHasEditAccessToThisProject()) {
    editableTableParams = {};
    editableTableParams.firstEditableColumnIndex = 6;
    editableTableParams.lastEditableColumnIndex = columnDefs.length - 1;
    editableTableParams.newRecord = null;
    autosaveParams = {};
    autosaveParams.columnKeyToClassNameMap = getProcessColumnKeyToClassNameMap();
    autosaveParams.primaryKeyForClassNameFnc = getProcessPrimaryKeyForClassName;
    autosaveParams.formattedValueFnc = null;
  }

  searchEquipmentsDataTableForProcess = createEditableDataTable("equipmentsListForProcess", columnDefs, dataSource, "equipmentNumber",
  {scrollable:true, width:getWidthForDataTable(), draggableColumns:true, emptyMsg:"No Matching Equipment Items Found"},
  {pagination:true, topPaginator:'topPaginatorForEquipmentsForProcess'}, {editableTableParams:editableTableParams, autosaveParams:autosaveParams});

  var dt = searchEquipmentsDataTableForProcess.getDataTable();
  dt.doBeforeShowCellEditor = function(oCellEditor) {
     repositionEditorToBeWithinTheViewport(dt, oCellEditor);
    var oRecord = oCellEditor._oRecord;
    var oColumn = oCellEditor._oColumn;
	var container = oCellEditor._elContainer;
	var containerTop = container.style.top;
	var containerLeft = container.style.left;

    var oKey = oColumn.key;
    if (oKey == "designCapacityUnitId") {
      var equipmentTypeCode = oRecord.getData('equipmentTypeCode');
      var arr = designCapacityUnitMap.get(equipmentTypeCode);
      if (arr == null) {
        arr = [{value:"", label:"Select"}];
      }
	  oCellEditor.dropdownOptions = arr;
      oCellEditor._oColumn.editorOptions.dropdownOptions = arr;
      oCellEditor.render();
        //Render pushes the cell editor to the top left, so have to reposition here.
      container = oCellEditor._elContainer;
	  container.style.top = containerTop;
	  container.style.left = containerLeft;
    }
    return true;
  }
  dt.subscribe('editorSaveEvent', function(oArgs) {
    var oRecord = oArgs.record;
    var oColumn = oArgs.column;
    if (oRecord === undefined) {//For Yahoo's BaseCellEditor
      oRecord = oArgs.editor.getRecord();
      oColumn = oArgs.editor.getColumn();
    }
    var oKey = oColumn.key;
    var queryStr = null;
    queryStr = getQueryStringForAutosave(searchEquipmentsDataTableForProcess, oRecord, oKey);
    if (queryStr === null) {
      queryStr = "&processId=" + oRecord.getData("processId") + "&fieldName=" + oKey + "&fieldValue=" +
                 oRecord.getData(oKey);
      var url = document.getElementById('contextPath').value +
                "/data/autosave?method=autosaveProcessFieldEquipmentType" + queryStr;
      autosaveValue(this, queryStr, url);
    }
  });

  return searchEquipmentsDataTableForProcess;
}

function processCheckboxFormatter(el, oRecord, oColumn, oData) {
  if (userHasEditAccessToThisProject()) {
    if (oData === "true" || oData === "on") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForProcess, \'' +
                     oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForProcess, \'' +
                     oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  } else {
    if (oData === "true" || oData === "on") {
      var contextPath = document.getElementById('contextPath').value;
      el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
    }
  }
}

function getColumnDefsForProcess() {
  var equipmentTypeIdFieldArray = equipmentTypeIdToFieldArrayMap.get(getSelectedEquipmentTypeId());
  if (equipmentTypeIdFieldArray === undefined) {
    var fieldArr = getCommonEquipmentFields();
    fieldArr[fieldArr.length] = "processId";
    fieldArr[fieldArr.length] = "productType";
    fieldArr[fieldArr.length] = "productDensity";
    fieldArr[fieldArr.length] = "designCapacity";
    fieldArr[fieldArr.length] = "designCapacityUnitId";
    fieldArr[fieldArr.length] = "designCapacityUnitText";
    fieldArr[fieldArr.length] = "compAirRequired";
    fieldArr[fieldArr.length] = "compAirPressure";
    fieldArr[fieldArr.length] = "compAirFlowrate";
    fieldArr[fieldArr.length] = "gasRequired";
    fieldArr[fieldArr.length] = "gasTypeId";
    fieldArr[fieldArr.length] = "gasPressure";
    fieldArr[fieldArr.length] = "gasFlowrate";
    fieldArr[fieldArr.length] = "waterRequired";
    fieldArr[fieldArr.length] = "waterPressure";
    fieldArr[fieldArr.length] = "waterFlowrate";
    fieldArr[fieldArr.length] = "waterTypeId";
    fieldArr[fieldArr.length] = "dustPickupRequired";
    fieldArr[fieldArr.length] = "dustPickupVelocity";
    fieldArr[fieldArr.length] = "dustTypeId";
    fieldArr[fieldArr.length] = "baghouseCyclone";
    fieldArr[fieldArr.length] = "ductSize";
    fieldArr[fieldArr.length] = "ductFlowrate";
    fieldArr[fieldArr.length] = "specificationRequired";
    fieldArr[fieldArr.length] = "processRemarks";

    var equipmentTypeSpecificFieldArray = equipmentTypeIdToFieldMap.get(getSelectedEquipmentTypeId());
    if (equipmentTypeSpecificFieldArray != undefined) {
      for (var t = 0; t < equipmentTypeSpecificFieldArray.length; t++) {
        fieldArr[fieldArr.length] = equipmentTypeSpecificFieldArray[t].name;
      }
    }
    return fieldArr;
  } else {
    return equipmentTypeIdFieldArray;
  }
}

function getEquipmentsColumnDefsForProcess() {
  var equipmentTypeToColDefs = equipmentTypeIdToColumnDefMap.get(getSelectedEquipmentTypeId());
  if (equipmentTypeToColDefs === undefined) {
    var columnDefs = getCommonEquipmentColumnDefs();
    columnDefs = columnDefs.concat(getEquipmentTypeSpecificColumnDefs());
    equipmentTypeIdToColumnDefMap.set(getSelectedEquipmentTypeId(), columnDefs);
    return columnDefs;
  } else {
    return equipmentTypeToColDefs;
  }
}

function getEquipmentTypeSpecificColumnDefs() {
  var columnDefs = [];
  var equipmentTypeId = getSelectedEquipmentTypeId();
  var equipmentTypeCode = getSelectedEquipmentTypeCode();
  var keysSpecificToEquipmentType = equipmentTypeCodeToKeyMap.get(equipmentTypeCode);
  if (keysSpecificToEquipmentType != undefined) {
    for (var t = 0; t < keysSpecificToEquipmentType.length; t++) {
      var key = keysSpecificToEquipmentType[t];
      columnDefs[columnDefs.length] = keyToColumnDefMap.get(key)[0];
    }
  }
  var equipmentTypeSpecificFieldArray = equipmentTypeIdToFieldMap.get(equipmentTypeId);
  if (equipmentTypeSpecificFieldArray != undefined) {
    for (var t = 0; t < equipmentTypeSpecificFieldArray.length; t++) {
      var field = equipmentTypeSpecificFieldArray[t];
      columnDefs[columnDefs.length] = getColumnDefinitionForDynamicFields(field);
    }
  }
  return columnDefs;
}


function textboxEditorForProcess(oEditor, oSelf) {
  textboxEditor(oEditor, searchEquipmentsDataTableForProcess);
}
function textAreaEditorForProcess(oEditor, oSelf) {
  textAreaEditor(oEditor, searchEquipmentsDataTableForProcess);
}
function dropdownEditorForProcess(oEditor, oSelf) {
  dropdownEditor(oEditor, searchEquipmentsDataTableForProcess);
}

function getColumnDefinitionForDynamicFields(field) {
  var name = field.name;
  var label = field.label;
  var fieldType = field.fieldType;
  var dataType = field.dataType;
  var size = field.size;
  if (fieldType === "text") {
     var editor =  new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:size, size:size});
    var editorOptions = {disableBtns:true, maxLength:size, size:size};
    if (dataType === "Integer") {
         var regExp = '^\\d{0,' + size + '}$';
		var finalExp = '\\d{' + size + '}$';
        editor = new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, regExp:regExp,finalRegExp:finalExp, maxLength:5, size:5});
      editorOptions.blockAlphabets = true;
    }
  }
  else if (fieldType === "textarea") {
     editor = new YAHOO.widget.TextareaCellEditor({disableBtns:true, maxLength:size});
        editorOptions = {disableBtns:true, maxLength:size};
  }
  else if (fieldType === "radio") {
    formatter = textAreaEditorForProcess;
  }
  else if (fieldType === "checkbox") {
    formatter = processCheckboxFormatter;
  }
  else if (fieldType === "select") {
    var listValueArr = fieldNameToValueArrayMap.get(name);
//    editor = dropdownEditorForProcess;
    editor = new YAHOO.widget.CustomDropDownCellEditor({disableBtns:true, dropdownOptions:listValueArr})                  
    editorOptions = {disableBtns:true, dropdownOptions:listValueArr};
    var formatter = dropDownFormatter;
  }
  var definition = {key:name, label:label, sortable:true, resizeable:true, width:120};
  if (editor) {
    definition.editor = editor;
    definition.className = getClassNameForEditableCell();
  }
  if (editorOptions) {
    definition.editorOptions = editorOptions;
  }
  if (formatter) {
    definition.formatter = formatter;
  }
  return definition;
}


function getColumnDefinition(field) {
  var name = field.name;
  var label = field.label;
  var fieldType = field.fieldType;
  var dataType = field.dataType;
  var size = field.size;
  if (fieldType === "text") {
    var editor = textboxEditorForProcess;
    var editorOptions = {disableBtns:true, maxLength:size, size:size};
    if (dataType === "Integer") {
      editorOptions.blockAlphabets = true;
    }
  }
  else if (fieldType === "textarea") {
    editor = textAreaEditorForProcess;
    editorOptions = {disableBtns:true, maxLength:size};
  }
  else if (fieldType === "radio") {
    formatter = textAreaEditorForProcess;
  }
  else if (fieldType === "checkbox") {
    formatter = processCheckboxFormatter;
  }
  else if (fieldType === "select") {
    var listValueArr = fieldNameToValueArrayMap.get(name);
    editor = dropdownEditorForProcess;
    editorOptions = {disableBtns:true, dropdownOptions:listValueArr};
    var formatter = dropDownFormatter;
  }
  var definition = {key:name, label:label, sortable:true, resizeable:true, width:120};
  if (editor) {
    definition.editor = editor;
    definition.className = getClassNameForEditableCell();
  }
  if (editorOptions) {
    definition.editorOptions = editorOptions;
  }
  if (formatter) {
    definition.formatter = formatter;
  }
  return definition;
}

function getSelectedEquipmentTypeId() {
  return getEquipmentTypeForProcessElement().value;
}

function getSelectedEquipmentTypeCode() {
  var element = getEquipmentTypeForProcessElement();
  var text = element[element.selectedIndex].text;
  return element.value === '' ? '' : text.substring(0, 1);
}

function getEquipmentTypeForProcessElement() {
  return document.getElementById('searchEquipmentTypeForTab1');
}