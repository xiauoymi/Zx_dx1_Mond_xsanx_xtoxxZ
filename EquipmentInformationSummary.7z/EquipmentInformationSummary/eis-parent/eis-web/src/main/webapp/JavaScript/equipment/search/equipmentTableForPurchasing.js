var searchEquipmentsDataTableForPurchasing = null;

function createEquipmentsListTabForPurchasing(url) {
    if (searchEquipmentsDataTableForPurchasing == null) {
        this.equipmentsListDataSource = createServerSidePaginationDataSource(url);
        var fieldArr = getCommonEquipmentFields();
        fieldArr[fieldArr.length] = "purchaseId";
        fieldArr[fieldArr.length] = "vendor";
        fieldArr[fieldArr.length] = "purchaseSoleSource";
        fieldArr[fieldArr.length] = "rtpNumber";
        fieldArr[fieldArr.length] = "poNumber";
        fieldArr[fieldArr.length] = "lineNumber";
        fieldArr[fieldArr.length] = "poLineAmount";
        //fieldArr[fieldArr.length] = "poLineQuantity";
        //fieldArr[fieldArr.length] = "poLineValue";
        fieldArr[fieldArr.length] = "coAmount";
        fieldArr[fieldArr.length] = "originalShipDate";
        fieldArr[fieldArr.length] = "revisedShipDate";
        fieldArr[fieldArr.length] = "actualDeliveryDate";
        fieldArr[fieldArr.length] = "exportDocuments";
        this.equipmentsListDataSource.responseSchema = {
            resultNode: "purchasing",
            fields: fieldArr,
            metaFields: {totalRecords : "totalRecords"}
        };
        searchEquipmentsDataTableForPurchasing = getEquipmentTableForPurchasing(getEquipmentsColumnDefsForPurchasing(), this.equipmentsListDataSource);
    } else {
        searchEquipmentsDataTableForPurchasing.requery(url);
    }
}

function getPurchasingColumnKeyToClassNameMap() {
    var columnKeyToClassNameMap = new Object();
    columnKeyToClassNameMap["vendor"] = "Purchasing";
    columnKeyToClassNameMap["purchaseSoleSource"] = "Equipment";
    columnKeyToClassNameMap["rtpNumber"] = "Purchasing";
    columnKeyToClassNameMap["poNumber"] = "Purchasing";
    columnKeyToClassNameMap["lineNumber"] = "Purchasing";
    columnKeyToClassNameMap["poLineAmount"] = "Purchasing";
    // columnKeyToClassNameMap["poLineQuantity"] = "Purchasing";
    //columnKeyToClassNameMap["poLineValue"] = "Purchasing";
    columnKeyToClassNameMap["coAmount"] = "Purchasing";
    columnKeyToClassNameMap["originalShipDate"] = "Purchasing";
    columnKeyToClassNameMap["revisedShipDate"] = "Purchasing";
    columnKeyToClassNameMap["actualDeliveryDate"] = "Purchasing";
    columnKeyToClassNameMap["exportDocuments"] = "Purchasing";
    return columnKeyToClassNameMap;
}

function getPurchasingPrimaryKeyForClassName(className) {
    if (className === 'Equipment') {
        return "id";
    }
    return "purchaseId";
}

function getPurchasingFormattedValue(oKey, oValue) {
    if (oKey === "originalShipDate" || oKey === "revisedShipDate" || oKey === "actualDeliveryDate") {
        return formatDateForSaving(oValue);
    }
    return oValue;
}

function getEquipmentTableForPurchasing(columnDefs, dataSource) {
    var editableTableParams = null;
    var autosaveParams = null;
    if (userHasEditAccessToThisProject()) {
        editableTableParams = {};
        editableTableParams.firstEditableColumnIndex = 5;
        editableTableParams.lastEditableColumnIndex = 13;
        editableTableParams.newRecord = null;
        autosaveParams = {};
        autosaveParams.columnKeyToClassNameMap = getPurchasingColumnKeyToClassNameMap();
        autosaveParams.primaryKeyForClassNameFnc = getPurchasingPrimaryKeyForClassName;
        autosaveParams.formattedValueFnc = getPurchasingFormattedValue;
    }
    searchEquipmentsDataTableForPurchasing = createEditableDataTable("equipmentsListForPurchasing", columnDefs, dataSource, "equipmentNumber",
    {scrollable:true, width:getWidthForDataTable(), draggableColumns:true, emptyMsg:"No Matching Equipment Items Found"},
    {pagination:true, topPaginator:'topPaginatorForEquipmentsForPurchasing'}, {editableTableParams:editableTableParams, autosaveParams:autosaveParams});

    return searchEquipmentsDataTableForPurchasing;
}

function getTotalItemCostForPurchasing(oRecord) {
    var poLineAmount = oRecord.getData('poLineAmount');
    var coAmount = oRecord.getData('coAmount');
    var totalItemCost = '';
    if (poLineAmount != '' && coAmount != '') {
        totalItemCost = parseInt(poLineAmount) + parseInt(coAmount);
    }
    return totalItemCost;
}

function calcualteTotalItemCostForPurchasing(oEditor) {
    var oRecord = oEditor.record;
    var oColumn = oEditor.column;
    var dt = searchEquipmentsDataTableForPurchasing.getDataTable();
    var oCell = dt.getTrEl(oRecord).cells[12];//cell for total item cost
    if (oColumn.key === 'poLineAmount' || oColumn.key === 'coAmount') {
        oCell.firstChild.innerHTML = getTotalItemCostForPurchasing(oRecord);
    }
}

function getEquipmentsColumnDefsForPurchasing() {
    this.purchasingCheckboxFormatter = function(el, oRecord, oColumn, oData) {
        if (userHasEditAccessToThisProject()) {
            if (oData === "true") {
                el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForPurchasing, ' +
                               '\'' + oRecord.getId() +
                               '\',\'' + oColumn.key +
                               '\')" class="yui-dt-checkbox" checked="true"/>';
            } else {
                el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, searchEquipmentsDataTableForPurchasing, ' +
                               '\'' + oRecord.getId() +
                               '\',\'' + oColumn.key +
                               '\')" class="yui-dt-checkbox"/>';
            }
        } else {
            if (oData === "true") {
                var contextPath = document.getElementById('contextPath').value;
                el.innerHTML = '<img src="' + contextPath + "/images/check.gif" + '" width="13" height="12"/>';
            }
        }
    }

    this.totalItemCostFormatter = function(elCell, oRecord, oColumn, oData) {
        elCell.innerHTML = getTotalItemCostForPurchasing(oRecord);
    }

    this.textboxEditorForPurchasing = function (oEditor, oSelf) {
        textboxEditor(oEditor, searchEquipmentsDataTableForPurchasing);
    }
    this.textAreaEditorForPurchasing = function (oEditor, oSelf) {
        textAreaEditor(oEditor, searchEquipmentsDataTableForPurchasing);
    }
    this.dropdownEditorForPurchasing = function (oEditor, oSelf) {
        dropdownEditor(oEditor, searchEquipmentsDataTableForPurchasing);
    }

    this.textboxEditorForPurchasingForTotalCost = function (oEditor, oSelf) {
        textboxEditor(oEditor, searchEquipmentsDataTableForPurchasing, calcualteTotalItemCostForPurchasing);
    }

    var columnDefs = getCommonEquipmentColumnDefs();
    columnDefs.splice(columnDefs.length - 1, 1);//remove common equipment vendor
    var className = getClassNameForEditableCell();

    columnDefs[columnDefs.length] = {key:"vendor", label:"Vendor", abbr:"Vendor", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns:true, maxLength:20, size: 20}), editorOptions:{disableBtns:true, maxLength:20, size:20}, sortable:true, resizeable:true, width:50};
    columnDefs[columnDefs.length] = {key:"purchaseSoleSource", label:"SS", abbr:"Sole Source", className:className, formatter: this.purchasingCheckboxFormatter, sortable:true, resizeable:true, width:50};
    columnDefs[columnDefs.length] = {key:"rtpNumber", label:"RTP #", abbr:"RTP Number", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,8}$/,finalRegExp:'^\\d{8}$',maxLength:8, size: 8}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:8, size:8}, sortable:true, resizeable:true, width:60};
    columnDefs[columnDefs.length] = {key:"poNumber", label:"PO #", abbr:"PO Number", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,10}$/,finalRegExp:'^\\d{10}$',maxLength:10, size: 10}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:10, size:10}, sortable:true, resizeable:true, width:60};
    columnDefs[columnDefs.length] = {key:"lineNumber", label:"Line", abbr:"Line Item", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,3}$/,finalRegExp:'^\\d{3}$',maxLength:10, size: 10}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:60};
    columnDefs[columnDefs.length] = {key:"poLineAmount", label:"PO Line<br/>Amt", abbr:"PO Line Amount", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,10}$/,finalRegExp:'^\\d{10}$',maxLength:10, size: 10, formatTag:true, table:'purchasing'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:10, size:10}, sortable:true, resizeable:true, width:60};
    //columnDefs[columnDefs.length] = {key:"poLineQuantity", label:"Quan", abbr:"PO Line Quantity", className:className, editor:textboxEditorForPurchasing, editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:3, size:3}, sortable:true, resizeable:true, width:60};
    //columnDefs[columnDefs.length] = {key:"poLineValue", label:"PO Line<br/>Value", className:className, editor:textboxEditorForPurchasing, editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:10, size:10}, sortable:true, resizeable:true, width:60};
    columnDefs[columnDefs.length] = {key:"coAmount", label:"CO<br/>Amount", className:className, editor:new YAHOO.widget.CustomTextBoxEditor({disableBtns: true,regExp:/^\d{0,10}$/,finalRegExp:'^\\d{10}$',maxLength:10, size: 10, formatTag:true, table:'purchasing'}), editorOptions:{disableBtns:true, blockAlphabets:true, maxLength:10, size:10}, sortable:true, resizeable:true, width:100};
    columnDefs[columnDefs.length] = {key:"costReadOnly", label:"Total Cost", abbr:"Total Item Cost", formatter: this.totalItemCostFormatter, resizeable:true, width:80};
    columnDefs[columnDefs.length] = {key:"originalShipDate", label:"Origi Ship", abbr:"Original Ship Date",className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:80};
    columnDefs[columnDefs.length] = {key:"revisedShipDate", label:"Rev Ship", abbr:"Revised Ship Date", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:80};
    columnDefs[columnDefs.length] = {key:"actualDeliveryDate", label:"Act Del", abbr:"Actual Delivery Date", className:className, formatter:YAHOO.widget.DataTable.formatDate, editor: new YAHOO.widget.DateCellEditor({disableBtns:true}), dateOptions: {format: getDateFormatForCellEditor()}, sortable:true, resizeable:true, width:80};
    columnDefs[columnDefs.length] = {key:"exportDocuments", label:"Ex Doc", abbr:"Export Documents<br/>Conditions", className:className, formatter: this.purchasingCheckboxFormatter, sortable:true, resizeable:true, width:50};

    return columnDefs;
}