function clearEquipmentsSearch() {
  document.getElementById('searchEquipmentNumber').value = '';
  document.getElementById('searchEquipmentType').value = '';
  document.getElementById('searchEquipmentSubType').value = '';
  document.getElementById('searchEquipmentArea').value = '';
  document.getElementById('searchEquipmentTagNumber').value = '';
  var url = document.getElementById('contextPath').value + "/data/equipmentSearchXml/search?projectId="
      + document.getElementById('projectId').value;
  createEquipmentsListTabForAll(url);
}

function getSearchingMsg(){
  return 'Searching...';
}

function searchEquipmentsForAll() {
//  document.getElementById('searchingForAll').style.display = '';
  var projectID = document.getElementById('projectId').value;
  var equipmentNumber = document.getElementById('searchEquipmentNumberForTab0').value;
  var equipmentType = document.getElementById('searchEquipmentTypeForTab0').value;
  var equipmentArea = document.getElementById('searchEquipmentAreaForTab0').value;
  var equipmentName = document.getElementById('searchEquipmentNameForTab0').value;
  var processLine = document.getElementById('searchProcessLineForTab0').value;
  var vendor = document.getElementById('searchVendorForTab0').value;
  var existingEquipmentNumber = document.getElementById('searchExistingEquipmentNumberForTab0').value;

  var url =  document.getElementById('contextPath').value + "/data/equipmentSearchXml/search?projectId="
      + projectID
      + "&searchEquipmentNumber=" + equipmentNumber
      + "&searchEquipmentType=" + equipmentType
      + "&searchEquipmentName=" + equipmentName
      + "&searchEquipmentArea=" + equipmentArea
      + "&searchProcessLine=" + processLine
      + "&searchExistingEquipmentNumber=" + existingEquipmentNumber
      + "&searchVendor=" + vendor;

  createEquipmentsListTabForAll(url);
}

function searchEquipmentsForMech() {
  var projectID = document.getElementById('projectId').value;
  var equipmentNumber = document.getElementById('searchEquipmentNumberForTab2').value;
  var equipmentType = document.getElementById('searchEquipmentTypeForTab2').value;
  var equipmentArea = document.getElementById('searchEquipmentAreaForTab2').value;
  var equipmentName = document.getElementById('searchEquipmentNameForTab2').value;
  var processLine = document.getElementById('searchProcessLineForTab2').value;
  var vendor = document.getElementById('searchVendorForTab2').value;

  var url =  document.getElementById('contextPath').value + "/data/mechanicalSearchXml/search?projectId="
      + projectID
      + "&searchEquipmentNumber=" + equipmentNumber
      + "&searchEquipmentType=" + equipmentType
      + "&searchEquipmentName=" + equipmentName
      + "&searchEquipmentArea=" + equipmentArea
      + "&searchProcessLine=" + processLine
      + "&searchVendor=" + vendor;

  createEquipmentsListTabForMech(url);
}

function searchEquipmentsForElec() {
  var projectID = document.getElementById('projectId').value;
  var equipmentNumber = document.getElementById('searchEquipmentNumberForTab3').value;
  var equipmentType = document.getElementById('searchEquipmentTypeForTab3').value;
  var equipmentArea = document.getElementById('searchEquipmentAreaForTab3').value;
  var equipmentName = document.getElementById('searchEquipmentNameForTab3').value;
  var processLine = document.getElementById('searchProcessLineForTab3').value;
  var vendor = document.getElementById('searchVendorForTab3').value;

  var url =  document.getElementById('contextPath').value + "/data/electricalSearchXml/search?projectId="
      + projectID
      + "&searchEquipmentNumber=" + equipmentNumber
      + "&searchEquipmentType=" + equipmentType
      + "&searchEquipmentName=" + equipmentName
      + "&searchEquipmentArea=" + equipmentArea
      + "&searchProcessLine=" + processLine
      + "&searchVendor=" + vendor;

  createEquipmentsListTabForElec(url);
}

function searchEquipmentsForMotor() {
  var projectID = document.getElementById('projectId').value;
  var equipmentNumber = document.getElementById('searchEquipmentNumberForTab4').value;
  var equipmentType = document.getElementById('searchEquipmentTypeForTab4').value;
  var equipmentArea = document.getElementById('searchEquipmentAreaForTab4').value;
  var equipmentName = document.getElementById('searchEquipmentNameForTab4').value;
  var processLine = document.getElementById('searchProcessLineForTab4').value;
  var vendor = document.getElementById('searchVendorForTab4').value;

  var url =  document.getElementById('contextPath').value + "/data/motorSearchXml/search?projectId="
      + projectID
      + "&searchEquipmentNumber=" + equipmentNumber
      + "&searchEquipmentType=" + equipmentType
      + "&searchEquipmentName=" + equipmentName
      + "&searchEquipmentArea=" + equipmentArea
      + "&searchProcessLine=" + processLine
      + "&searchVendor=" + vendor;

  createEquipmentsListTabForMotor(url);
}

function searchEquipmentsForInst() {
  var projectID = document.getElementById('projectId').value;
  var equipmentNumber = document.getElementById('searchEquipmentNumberForTab5').value;
  var equipmentType = document.getElementById('searchEquipmentTypeForTab5').value;
  var equipmentArea = document.getElementById('searchEquipmentAreaForTab5').value;
  var equipmentName = document.getElementById('searchEquipmentNameForTab5').value;
  var processLine = document.getElementById('searchProcessLineForTab5').value;
  var vendor = document.getElementById('searchVendorForTab5').value;

  var url =  document.getElementById('contextPath').value + "/data/instrumentSearchXml/search?projectId="
      + projectID
      + "&searchEquipmentNumber=" + equipmentNumber
      + "&searchEquipmentType=" + equipmentType
      + "&searchEquipmentName=" + equipmentName
      + "&searchEquipmentArea=" + equipmentArea
      + "&searchProcessLine=" + processLine
      + "&searchVendor=" + vendor;

  createEquipmentsListTabForInst(url);
}

function searchEquipmentsForAcce() {
  var projectID = document.getElementById('projectId').value;
  var equipmentNumber = document.getElementById('searchEquipmentNumberForTab6').value;
  var equipmentType = document.getElementById('searchEquipmentTypeForTab6').value;
  var equipmentArea = document.getElementById('searchEquipmentAreaForTab6').value;
  var equipmentName = document.getElementById('searchEquipmentNameForTab6').value;
  var processLine = document.getElementById('searchProcessLineForTab6').value;
  var vendor = document.getElementById('searchVendorForTab6').value;

  var url =  document.getElementById('contextPath').value + "/data/accessorySearchXml/search?projectId="
      + projectID
      + "&searchEquipmentNumber=" + equipmentNumber
      + "&searchEquipmentType=" + equipmentType
      + "&searchEquipmentName=" + equipmentName
      + "&searchEquipmentArea=" + equipmentArea
      + "&searchProcessLine=" + processLine
      + "&searchVendor=" + vendor;

  createEquipmentsListTabForAcce(url);
}

function searchEquipmentsForProcess() {
  var projectID = document.getElementById('projectId').value;
  var equipmentNumber = document.getElementById('searchEquipmentNumberForTab1').value;
  var equipmentType = document.getElementById('searchEquipmentTypeForTab1').value;
  var equipmentArea = document.getElementById('searchEquipmentAreaForTab1').value;
  var equipmentName = document.getElementById('searchEquipmentNameForTab1').value;
  var processLine = document.getElementById('searchProcessLineForTab1').value;
  var vendor = document.getElementById('searchVendorForTab1').value;

  var url =  document.getElementById('contextPath').value + "/data/processSearchXml/search?projectId="
      + projectID
      + "&searchEquipmentNumber=" + equipmentNumber
      + "&searchEquipmentType=" + equipmentType
      + "&searchEquipmentName=" + equipmentName
      + "&searchEquipmentArea=" + equipmentArea
      + "&searchProcessLine=" + processLine
      + "&searchVendor=" + vendor;

  createEquipmentsListTabForProcess(url);
}

function searchEquipmentsForPurchasing() {
  var projectID = document.getElementById('projectId').value;
  var equipmentNumber = document.getElementById('searchEquipmentNumberForTab7').value;
  var equipmentType = document.getElementById('searchEquipmentTypeForTab7').value;
  var equipmentArea = document.getElementById('searchEquipmentAreaForTab7').value;
  var equipmentName = document.getElementById('searchEquipmentNameForTab7').value;
  var processLine = document.getElementById('searchProcessLineForTab7').value;
  var vendor = document.getElementById('searchVendorForTab7').value;

  var url =  document.getElementById('contextPath').value + "/data/purchasingSearchXml/search?projectId="
      + projectID
      + "&searchEquipmentNumber=" + equipmentNumber
      + "&searchEquipmentType=" + equipmentType
      + "&searchEquipmentName=" + equipmentName
      + "&searchEquipmentArea=" + equipmentArea
      + "&searchProcessLine=" + processLine
      + "&searchVendor=" + vendor;

  createEquipmentsListTabForPurchasing(url);
}

function searchEquipmentsForCostSchedule() {
  var projectID = document.getElementById('projectId').value;
  var equipmentNumber = document.getElementById('searchEquipmentNumberForTab8').value;
  var equipmentType = document.getElementById('searchEquipmentTypeForTab8').value;
  var equipmentArea = document.getElementById('searchEquipmentAreaForTab8').value;
  var equipmentName = document.getElementById('searchEquipmentNameForTab8').value;
  var processLine = document.getElementById('searchProcessLineForTab8').value;
  var vendor = document.getElementById('searchVendorForTab8').value;

  var url =  document.getElementById('contextPath').value + "/data/costScheduleSearchXml/search?projectId="
      + projectID
      + "&searchEquipmentNumber=" + equipmentNumber
      + "&searchEquipmentType=" + equipmentType
      + "&searchEquipmentName=" + equipmentName
      + "&searchEquipmentArea=" + equipmentArea
      + "&searchProcessLine=" + processLine
      + "&searchVendor=" + vendor;

  createEquipmentsListTabForCostSchedule(url);
}