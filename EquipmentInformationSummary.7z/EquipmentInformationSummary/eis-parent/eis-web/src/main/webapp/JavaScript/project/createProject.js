YAHOO.util.Event.addListener(window, "load", function() {
  createProjectCalendars();
  getRefDataForProjectPeople();
});

function createProjectCalendars() {
  createCalendar("AR_APPROVAL_DATE", "arApprovalDateContainer");
  createCalendar("STARTUP_DATE", "startupDateContainer");
}

