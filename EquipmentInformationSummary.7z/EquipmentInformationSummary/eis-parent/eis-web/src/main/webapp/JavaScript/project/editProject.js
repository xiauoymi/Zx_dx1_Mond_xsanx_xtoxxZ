//function setHeaderCreateOrEdit() {
//  var operation = document.getElementById("OPERATION").value;
//  if (operation == 'edit_project') {
//    document.getElementById("createOrEditHeader").innerHTML = 'Edit';
//  }
//}

//function updateLocation(selectObject) {
//  //debugger;
//  //alert('In updateSubTypeOne');
//  var createList = {
//    success: function(o) {
//      fillLocationList(o, selectObject);
//    },
//    failure: function(o) {
//      // suppressed alert and displaying Please Select Option
//      alert("Unable to retrieve REGION OR COUNTRY OR STATE OR CITY list");
//    },
//    cache:false
//    //,timeout: 10000 //10 seconds
//  };
//  //todo change eis to get context path and change url once we are ready
//
//  //debugger;
//  var url = '';
//  if (selectObject == document.getElementById('LOCATION_ID')) {
//    url = document.getElementById('LOCATION_ID').value;
//
//  }
//  if (selectObject == document.getElementById('COUNTRY_ID')) {
//    url = document.getElementById('COUNTRY_ID').value;
//  }
//  if (selectObject == document.getElementById('STATE_ID')) {
//    url = document.getElementById('STATE_ID').value;
//  }
//
////  if(selectObject == document.getElementById('CITY_ID')) {
//  //    url = document.getElementById('CITY_ID').value;
//  //  }
//
//
//  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
//      "/eis/data/projects?method=list_location_xml&LOCATION_ID=" + url,
//      createList);
//
//}
//
//
//function fillLocationList(o, selectObject) {
//  var docXML = o.responseXML;
//  //alert(docXML);
//  var options = docXML.getElementsByTagName('option');
//  //alert(options.length);
//  //subTypeOneSelect
//  //debugger;
//  var subLocationSelect = '';
//
//  if (selectObject == document.getElementById('LOCATION_ID')) {
//    subLocationSelect = document.getElementById("COUNTRY_ID");
//  }
//  if (selectObject == document.getElementById('COUNTRY_ID')) {
//    subLocationSelect = document.getElementById("STATE_ID");
//  }
//  if (selectObject == document.getElementById('STATE_ID')) {
//    subLocationSelect = document.getElementById("CITY_ID");
//  }
//
//
//  removeAllSubLocations(subLocationSelect);
//
//  for (var i = 0; i < options.length; i++) {
//
//    var optionId;
//    //alert(optionId);
//    if (options[i].childNodes[0].firstChild == null) {
//      optionId = '';
//    } else {
//      optionId = options[i].childNodes[0].firstChild.nodeValue;
//    }
//
//    var locationName = options[i].childNodes[1].firstChild.nodeValue;
//    var docoption = document.createElement("OPTION");
//    docoption.text = locationName;
//    docoption.value = optionId;
//    subLocationSelect.options.add(docoption);
//
//
//    if (selectObject == document.getElementById('LOCATION_ID')) {
//      setDefaultLocation(document.getElementById("STATE_ID"));
//      setDefaultLocation(document.getElementById("CITY_ID"));
//    }
//
//    if (selectObject == document.getElementById('COUNTRY_ID')) {
//      setDefaultLocation(document.getElementById("CITY_ID"));
//    }
//
//
//  }
//
//}
//
//
//function removeAllSubLocations(selectbox) {
//  var i;
//  for (i = selectbox.options.length - 1; i >= 0; i--) {
//    selectbox.remove(i);
//  }
//}
//
//function setDefaultLocation(locationToBeSetForDefault) {
//  removeAllSubLocations(locationToBeSetForDefault);
//  var optionName = 'Please Select';
//  var docOption = document.createElement("OPTION");
//  docOption.text = optionName;
//  docOption.value = "0";
//  locationToBeSetForDefault.options.add(docOption);
//}

function goToProjectCancel(operation) {
  var projectId = document.getElementById("projectId").value;
  if (operation == 'editProject') {
    document.createProject.action = "/eis/servlet/projects?method=project_detail&projectId=" + projectId;
  } else {
    var cancelMessage = 'Project Creation Cancelled';
    document.createProject.action = "/eis/servlet/project/search?cancelProjectCreation=" + cancelMessage;
  }
  document.createProject.submit();
}

function submitProject() {
  removeHiddenFieldsForLeadProcessEngrs();
  removeHiddenFieldsForLocationManagers();
  removeHiddenFieldsForLeadElectDesigners();
  removeHiddenFieldsForLeadElectEngrs();
  removeHiddenFieldsForLeadMechDesigners();
  removeHiddenFieldsForLeadMechEngrs();
  removeHiddenFieldsForManufactureReps();
  removeHiddenFieldsForProjectBuyers();
  removeHiddenFieldsForProjectControls();
  removeHiddenFieldsForProjectManagers();
  removeHiddenFieldsForProjectSponsors();
  removeHiddenFieldsForProjectEngrs();

  createHiddenFieldsForLeadProcessEngrs();
  createHiddenFieldsForLocationManagers();
  createHiddenFieldsForLeadElectDesigners();
  createHiddenFieldsForLeadElectEngrs();
  createHiddenFieldsForLeadMechDesigners();
  createHiddenFieldsForLeadMechEngrs();
  createHiddenFieldsForManufactureReps();
  createHiddenFieldsForProjectBuyers();
  createHiddenFieldsForProjectControls();
  createHiddenFieldsForProjectManagers();
  createHiddenFieldsForProjectSponsors();
  createHiddenFieldsForProjectEngrs();

  var callbackAfterProjectSave = {
    success: function(o) {
      this.cache = null;
      var xmlDoc = o.responseXML;
        document.getElementById('projectId').value = xmlDoc.selectSingleNode("//projectId").text;

      var messageElement = document.getElementById('messagesForProject');
      if (messageElement != null) {
        messageElement.style.display = "";
      }
          var errors = xmlDoc.selectNodes("//error");
          var errorStr = "";
          if (errors.length === 0) {
            document.location.href = document.getElementById('contextPath').value +
                                     "/servlet/projects?method=project_detail&projectSavedMsg=Project Saved&projectId=" +
                                     document.getElementById('projectId').value;
          } else {
            for (var i = 0; i < errors.length; i++) {
              var errorHeader = errors[i].selectSingleNode("errorHeader").firstChild.nodeValue;
              errorStr += "<span class='errorMsgHeader'>" + errorHeader + "</span><br/>";
              var errorMsgs = errors[i].selectNodes("errorMsg");
              for (var j = 0; j < errorMsgs.length; j++) {
                var errorMsg = errorMsgs[j].firstChild.nodeValue;
                errorStr += errorMsg + "<br/>";
              }
            }
          }
      hideOrShowSucessAndErrorMessageDiv(false, null, "errorMsgsForProjectDiv", null, errorStr);
      document.getElementById('errorMsgsForProjectDiv').innerHTML = errorStr;

//      updateEquipmentHeader();
      document.getElementById('saveProjectBtn').disabled = '';
    },
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    },
    cache:false,
    timeout: 20000 //20 seconds
  };

  document.getElementById('saveProjectBtn').disabled = "disabled";
    enableOrDisableSaveAsButton("disabled");
  var createProjectForm = document.getElementById("createProject");
  YAHOO.util.Connect.setForm(createProjectForm);
  //if(var)
  this.getXML = YAHOO.util.Connect.asyncRequest("POST",
      "/eis/data/projects/create?method=submit_create_project",
      callbackAfterProjectSave);
}

function enableOrDisableSaveAsButton(enableOrDisable){
  if (document.getElementById('saveAsProjectBtn') != undefined || document.getElementById('saveAsProjectBtn') != null){
    document.getElementById('saveAsProjectBtn').disabled = enableOrDisable;
   }
}

function saveAsProject() {
  removeHiddenFieldsForLeadProcessEngrs();
  removeHiddenFieldsForLocationManagers();
  removeHiddenFieldsForLeadElectDesigners();
  removeHiddenFieldsForLeadElectEngrs();
  removeHiddenFieldsForLeadMechDesigners();
  removeHiddenFieldsForLeadMechEngrs();
  removeHiddenFieldsForManufactureReps();
  removeHiddenFieldsForProjectBuyers();
  removeHiddenFieldsForProjectControls();
  removeHiddenFieldsForProjectManagers();
  removeHiddenFieldsForProjectSponsors();
  removeHiddenFieldsForProjectEngrs();

  createHiddenFieldsForLeadProcessEngrs();
  createHiddenFieldsForLocationManagers();
  createHiddenFieldsForLeadElectDesigners();
  createHiddenFieldsForLeadElectEngrs();
  createHiddenFieldsForLeadMechDesigners();
  createHiddenFieldsForLeadMechEngrs();
  createHiddenFieldsForManufactureReps();
  createHiddenFieldsForProjectBuyers();
  createHiddenFieldsForProjectControls();
  createHiddenFieldsForProjectManagers();
  createHiddenFieldsForProjectSponsors();
  createHiddenFieldsForProjectEngrs();

  var callbackAfterProjectSave = {
    success: function(o) {
      this.cache = null;
      var xmlDoc = o.responseXML;
      document.getElementById('projectId').value = xmlDoc.selectSingleNode("//projectId").text;

      var messageElement = document.getElementById('messagesForProject');
      if (messageElement != null) {
        messageElement.style.display = "";
      }
      var errors = xmlDoc.selectNodes("//error");
      var errorStr = "";
      if (errors.length === 0) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/projects?method=project_detail&projectSavedMsg=Project Saved&projectId=" +
                                 document.getElementById('projectId').value;
      } else {
        for (var i = 0; i < errors.length; i++) {
          var errorHeader = errors[i].selectSingleNode("errorHeader").firstChild.nodeValue;
          errorStr += "<span class='errorMsgHeader'>" + errorHeader + "</span><br/>";
          var errorMsgs = errors[i].selectNodes("errorMsg");
          for (var j = 0; j < errorMsgs.length; j++) {
            var errorMsg = errorMsgs[j].firstChild.nodeValue;
            errorStr += errorMsg + "<br/>";
          }
        }
      }
      hideOrShowSucessAndErrorMessageDiv(false, null, "errorMsgsForProjectDiv", null, errorStr);
      document.getElementById('errorMsgsForProjectDiv').innerHTML = errorStr;

//      updateEquipmentHeader();
      document.getElementById('saveProjectBtn').disabled = '';
        enableOrDisableSaveAsButton("");
    },
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    },
    cache:false,
    timeout: 40000 //20 seconds
  };

  document.getElementById('saveProjectBtn').disabled = "disabled";
  enableOrDisableSaveAsButton("disabled");
  var createProjectForm = document.getElementById("createProject");
  YAHOO.util.Connect.setForm(createProjectForm);
  //if(var)
  this.getXML = YAHOO.util.Connect.asyncRequest("POST",
      "/eis/data/projects/create?method=saveAs",
      callbackAfterProjectSave);
}



