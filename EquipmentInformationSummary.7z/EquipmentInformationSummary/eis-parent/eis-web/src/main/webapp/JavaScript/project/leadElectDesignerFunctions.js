var leadElectDesignersDataTable = null;
var leadElectDesignersArray = null;


function getColumnDefsForLeadElectDesigners() {
  var fieldArr = [];
  fieldArr[fieldArr.length] = "leadElectDesignerId";
  fieldArr[fieldArr.length] = "isLeadElectDesignerLead";
  return fieldArr;
}

function createLeadElectDesignersTable(leadElectDesignersArray) {
  this.leadElectDesignersArray = leadElectDesignersArray;
  var projectId = document.getElementById("projectId").value;
  var url = "/eis/data/projectUserXml/details?projectRole=Electrical Designer&projectId=" + projectId;
  this.leadElectDesignersDataSource = createServerSidePaginationDataSource(url);
  this.leadElectDesignersDataSource.responseSchema = {
    resultNode : "projectUserRole",
    fields: getFieldsForProjectRoles(),
    metaFields: {totalRecords : "totalRecords"}
  };
  leadElectDesignersDataTable = getLeadElectDesignersTable(getLeadElectDesignersColumnDefs(), this.leadElectDesignersDataSource);
}

function getLeadElectDesignersColumnDefs() {
  this.leadElectDesignersCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (oData === "true") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, leadElectDesignersDataTable, \'' +
                     oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, leadElectDesignersDataTable, \'' +
                     oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  }


  this.deleteLeadElectDesignersFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }
  this.dropdownEditorForLeadElectDesignersDataTable = function (oEditor, oSelf) {
    dropdownEditor(oEditor, leadElectDesignersDataTable);
  }
  var className = getClassNameForEditableCell(true);
  return  [
    {label:"Electrical Designer", children:[
      {key:"userId", label:"Name", className:className, editor:dropdownEditorForLeadElectDesignersDataTable, editorOptions:{disableBtns:true, dropdownOptions:leadElectDesignersArray}, formatter:dropDownFormatter, sortable:false, resizeable:false, width:120},
      {key:"isLead", label:"Lead", className:className, formatter: this.leadElectDesignersCheckboxFormatter, sortable:false, resizeable:false, width:40},
      {key:"delete", label:"Delete", className:className, formatter:this.deleteLeadElectDesignersFormatter, width:50}]
    }];
}


function getLeadElectDesignersTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 0;
  editableTableParams.lastEditableColumnIndex = 1;
  editableTableParams.newRecord = getNewProjectEngrRecord();
  leadElectDesignersDataTable = createEditableDataTable("leadElectDesignersList", columnDefs, dataSource, null, {scrollable:false,  draggableColumns:false},
  {pagination:false}, {editableTableParams:editableTableParams});
  var dt = leadElectDesignersDataTable.getDataTable();
  dt.subscribe("renderEvent", function() {
    document.getElementById('addLeadElectDesignerBtn').disabled = '';
  });
  return leadElectDesignersDataTable;
}

function addNewLeadElectDesignerRow() {
  var dt = leadElectDesignersDataTable.getDataTable();
  if (dt.getRecordSet().getLength() < 4) {
    addNewRowToDataTable(leadElectDesignersDataTable);
  } else {
    alert('Not more than 4 people assigned to any given role');
  }

}

function getNewLeadElectDesignerRecord() {
  return {
    leadElectDesignerId:"",
    isLeadElectDesignerLead:""
  };
}

function removeHiddenFieldsForLeadElectDesigners() {
  var createProjectForm = document.getElementById("createProject");
  removeHiddenFields(createProjectForm, "leadElectDesignerId");
  removeHiddenFields(createProjectForm, "isLeadElectDesignerLead");
}

function createHiddenFieldsForLeadElectDesigners() {
  var createProject = document.getElementById("createProject");
  if (leadElectDesignersDataTable != null) {
    var dt = leadElectDesignersDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var userId = getEmptyStringIfUndefined(data.userId);
      var isLead = getEmptyStringIfUndefined(data.isLead);
      createProject.appendChild(createHiddenField("leadElectDesignerId", userId));
      createProject.appendChild(createHiddenField("isLeadElectDesignerLead", isLead));
    }
  }
}
