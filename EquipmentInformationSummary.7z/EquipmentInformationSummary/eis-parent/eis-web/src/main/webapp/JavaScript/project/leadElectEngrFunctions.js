var leadElectEngrsDataTable = null;
var leadElectEngrsArray = null;


function getColumnDefsForLeadElectEngrs(){
  var fieldArr = [];
  fieldArr[fieldArr.length] = "leadElectEngrId";
  fieldArr[fieldArr.length] = "isLeadElectEngrLead";
  return fieldArr;
}

function createLeadElectEngrsTable(leadElectEngrsArray) {
  this.leadElectEngrsArray = leadElectEngrsArray;
  var projectId = document.getElementById("projectId").value;
  var url = "/eis/data/projectUserXml/details?projectRole=Electrical Engineer&projectId=" + projectId;
  this.leadElectEngrsDataSource = createServerSidePaginationDataSource(url);
  this.leadElectEngrsDataSource.responseSchema = {
    resultNode : "projectUserRole",
    fields: getFieldsForProjectRoles(),
    metaFields: {totalRecords : "totalRecords"}
  };
  leadElectEngrsDataTable = getLeadElectEngrsTable(getLeadElectEngrsColumnDefs(), this.leadElectEngrsDataSource);
}

function getLeadElectEngrsColumnDefs() {
  this.leadElectEngrsCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (oData === "true") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, leadElectEngrsDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, leadElectEngrsDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  }


  this.deleteLeadElectEngrsFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }

  this.dropdownEditorForLeadElectEngrsDataTable = function (oEditor, oSelf) {
    dropdownEditor(oEditor, leadElectEngrsDataTable);
  }

  var className = getClassNameForEditableCell(true);
  return  [

    {label:"Electrical Engineer", children:[
    {key:"userId", label:"Name", className:className, editor:dropdownEditorForLeadElectEngrsDataTable, editorOptions:{disableBtns:true, dropdownOptions:leadElectEngrsArray}, formatter:dropDownFormatter, sortable:false, resizeable:false, width:120},
    {key:"isLead", label:"Lead", className:className, formatter: this.leadElectEngrsCheckboxFormatter, sortable:false, resizeable:false, width:40},
    {key:"delete", label:"Delete", className:className, formatter:this.deleteLeadElectEngrsFormatter, width:50}]
  }];
}


function getLeadElectEngrsTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 0;
  editableTableParams.lastEditableColumnIndex = 1;
  editableTableParams.newRecord = getNewProjectEngrRecord();
  leadElectEngrsDataTable = createEditableDataTable("leadElectEngrsList", columnDefs, dataSource, null, {scrollable:false,  draggableColumns:false},
  {pagination:false}, {editableTableParams:editableTableParams});
  var dt = leadElectEngrsDataTable.getDataTable();
  dt.subscribe("renderEvent", function() {
    document.getElementById('addLeadElectEngrBtn').disabled = '';
  });
  return leadElectEngrsDataTable;
}

function addNewLeadElectEngrRow() {
  var dt = leadElectEngrsDataTable.getDataTable();
  if(dt.getRecordSet().getLength() < 4) {
    addNewRowToDataTable(leadElectEngrsDataTable);
  } else {
    alert('Not more than 4 people assigned to any given role');
  }

}

function getNewLeadElectEngrRecord() {
  return {
      leadElectEngrId:"",
      isLeadElectEngrLead:""
  };
}

function removeHiddenFieldsForLeadElectEngrs() {
  var createProjectForm = document.getElementById("createProject");
  removeHiddenFields(createProjectForm, "leadElectEngrId");
  removeHiddenFields(createProjectForm, "isLeadElectEngrLead");
}


function createHiddenFieldsForLeadElectEngrs() {
  var createProject = document.getElementById("createProject");
  if (leadElectEngrsDataTable != null) {
    var dt = leadElectEngrsDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var userId = getEmptyStringIfUndefined(data.userId);
      var isLead = getEmptyStringIfUndefined(data.isLead);
      createProject.appendChild(createHiddenField("leadElectEngrId", userId));
      createProject.appendChild(createHiddenField("isLeadElectEngrLead", isLead));
    }
  }
}
