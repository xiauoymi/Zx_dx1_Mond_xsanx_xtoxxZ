var leadMechDesignersDataTable = null;
var leadMechDesignersArray = null;


function getColumnDefsForLeadMechDesigners(){
  var fieldArr = [];
  fieldArr[fieldArr.length] = "leadMechDesignerId";
  fieldArr[fieldArr.length] = "isLeadMechDesignerLead";
  return fieldArr;
}

function createLeadMechDesignersTable(leadMechDesignersArray) {
  this.leadMechDesignersArray = leadMechDesignersArray;
  var projectId = document.getElementById("projectId").value;
  var url = "/eis/data/projectUserXml/details?projectRole=Mechanical Designer&projectId=" + projectId;
  this.leadMechDesignersDataSource = createServerSidePaginationDataSource(url);
  this.leadMechDesignersDataSource.responseSchema = {
    resultNode : "projectUserRole",
    fields: getFieldsForProjectRoles(),
    metaFields: {totalRecords : "totalRecords"}
  };
  leadMechDesignersDataTable = getLeadMechDesignersTable(getLeadMechDesignersColumnDefs(), this.leadMechDesignersDataSource);
}

function getLeadMechDesignersColumnDefs() {
  this.leadMechDesignersCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (oData === "true") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, leadMechDesignersDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, leadMechDesignersDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  }


  this.deleteMechDesignersFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }
  this.dropdownEditorForLeadMechDesignersDataTable = function (oEditor, oSelf) {
    dropdownEditor(oEditor, leadMechDesignersDataTable);
  }
  var className = getClassNameForEditableCell(true);

  return  [
    {label:"Mechanical Designer", children:[
    {key:"userId", label:"Name", className:className, editor:dropdownEditorForLeadMechDesignersDataTable, editorOptions:{disableBtns:true, dropdownOptions:leadMechDesignersArray}, formatter:dropDownFormatter, sortable:false, resizeable:false, width:120},
    {key:"isLead", label:"Lead", className:className, formatter: this.leadMechDesignersCheckboxFormatter, sortable:false, resizeable:false, width:40},
    {key:"delete", label:"Delete", className:className, formatter:this.deleteMechDesignersFormatter, width:50}]
    }];
}


function getLeadMechDesignersTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 0;
  editableTableParams.lastEditableColumnIndex = 1;
  editableTableParams.newRecord = getNewProjectEngrRecord();
  leadMechDesignersDataTable = createEditableDataTable("leadMechDesignersList", columnDefs, dataSource, null, {scrollable:false,  draggableColumns:false},
  {pagination:false}, {editableTableParams:editableTableParams});
  var dt = leadMechDesignersDataTable.getDataTable();
  dt.subscribe("renderEvent", function() {
    document.getElementById('addLeadMechDesignerBtn').disabled = '';
  });
  return leadMechDesignersDataTable;
}

function addNewLeadMechDesignerRow() {
  var dt = leadMechDesignersDataTable.getDataTable();
  if(dt.getRecordSet().getLength() < 4) {
   addNewRowToDataTable(leadMechDesignersDataTable);
  }  else {
    alert('Not more than 4 people assigned to any given role');
  }

}

function getNewLeadMechDesignerRecord() {
  return {
      leadMechDesignerId:"",
      isLeadMechDesignerLead:""
  };
}


function removeHiddenFieldsForLeadMechDesigners() {
  var createProjectForm = document.getElementById("createProject");
  removeHiddenFields(createProjectForm, "leadMechDesignerId");
  removeHiddenFields(createProjectForm, "isLeadMechDesignerLead");
}

function createHiddenFieldsForLeadMechDesigners() {
  var createProject = document.getElementById("createProject");
  if (leadMechDesignersDataTable != null) {
    var dt = leadMechDesignersDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var userId = getEmptyStringIfUndefined(data.userId);
      var isLead = getEmptyStringIfUndefined(data.isLead);
      createProject.appendChild(createHiddenField("leadMechDesignerId", userId));
      createProject.appendChild(createHiddenField("isLeadMechDesignerLead", isLead));
    }
  }
}
