var leadMechEngrsDataTable = null;
var leadMechEngrsArray = null;


function getColumnDefsForLeadMechEngrs(){
  var fieldArr = [];
  fieldArr[fieldArr.length] = "leadMechEngrId";
  fieldArr[fieldArr.length] = "isLeadMechEngrLead";
  return fieldArr;
}

function createLeadMechEngrsTable(leadMechEngrsArray) {
  this.leadMechEngrsArray = leadMechEngrsArray;
  var projectId = document.getElementById("projectId").value;
  var url = "/eis/data/projectUserXml/details?projectRole=Mechanical Engineer&projectId=" + projectId;
  this.leadMechEngrsDataSource = createServerSidePaginationDataSource(url);
  this.leadMechEngrsDataSource.responseSchema = {
    resultNode : "projectUserRole",
    fields: getFieldsForProjectRoles(),
    metaFields: {totalRecords : "totalRecords"}
  };
  leadMechEngrsDataTable = getLeadMechEngrsTable(getLeadMechEngrsColumnDefs(), this.leadMechEngrsDataSource);
}

function getLeadMechEngrsColumnDefs() {
  this.leadMechEngrsCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (oData === "true") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, leadMechEngrsDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, leadMechEngrsDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  }


  this.deleteMechEngrsFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }

  this.dropdownEditorForLeadMechEngrsDataTable = function (oEditor, oSelf) {
    dropdownEditor(oEditor, leadMechEngrsDataTable);
  }
  var className = getClassNameForEditableCell(true);
  return  [

    {label:"Mechanical Engineer", children:[
    {key:"userId", label:"Name", className:className, editor:dropdownEditorForLeadMechEngrsDataTable, editorOptions:{disableBtns:true, dropdownOptions:leadMechEngrsArray}, formatter:dropDownFormatter, sortable:false, resizeable:false, width:120},
    {key:"isLead", label:"Lead", className:className, formatter: this.leadMechEngrsCheckboxFormatter, sortable:false, resizeable:false, width:40},
    {key:"delete", label:"Delete", className:className, formatter:this.deleteMechEngrsFormatter, width:50}]
    }];
}


function getLeadMechEngrsTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 0;
  editableTableParams.lastEditableColumnIndex = 1;
  editableTableParams.newRecord = getNewProjectEngrRecord();
  leadMechEngrsDataTable = createEditableDataTable("leadMechEngrsList", columnDefs, dataSource, null, {scrollable:false,  draggableColumns:false},
  {pagination:false}, {editableTableParams:editableTableParams});
  var dt = leadMechEngrsDataTable.getDataTable();
  dt.subscribe("renderEvent", function() {
    document.getElementById('addLeadMechEngrBtn').disabled = '';
  });
  return leadMechEngrsDataTable;
}

function addNewLeadMechEngrRow() {
  var dt = leadMechEngrsDataTable.getDataTable();
  if(dt.getRecordSet().getLength() < 4) {
   addNewRowToDataTable(leadMechEngrsDataTable);
  } else {
    alert('Not more than 4 people assigned to any given role');
  }

}

function getNewLeadMechEngrRecord() {
  return {
      leadMechEngrId:"",
      isLeadMechEngrLead:""
  };
}

function removeHiddenFieldsForLeadMechEngrs() {
  var createProjectForm = document.getElementById("createProject");
  removeHiddenFields(createProjectForm, "leadMechEngrId");
  removeHiddenFields(createProjectForm, "isLeadMechEngrLead");
}

function createHiddenFieldsForLeadMechEngrs() {
  var createProject = document.getElementById("createProject");
  if (leadMechEngrsDataTable != null) {
    var dt = leadMechEngrsDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var userId = getEmptyStringIfUndefined(data.userId);
      var isLead = getEmptyStringIfUndefined(data.isLead);
      createProject.appendChild(createHiddenField("leadMechEngrId", userId));
      createProject.appendChild(createHiddenField("isLeadMechEngrLead", isLead));
    }
  }
}
