var leadProcessEngrsDataTable = null;
var leadProcessEngrsArray = null;


function getColumnDefsForLeadProcessEngrs(){
  var fieldArr = [];
  fieldArr[fieldArr.length] = "leadProcessId";
  fieldArr[fieldArr.length] = "isLeadProcessLead";
  return fieldArr;
}

function createLeadProcessEngrsTable(leadProcessEngrsArray) {
  this.leadProcessEngrsArray = leadProcessEngrsArray;
  var projectId = document.getElementById("projectId").value;
  var url = "/eis/data/projectUserXml/details?projectRole=Process Engineer&projectId=" + projectId;
  this.leadProcessDataSource = createServerSidePaginationDataSource(url);
  this.leadProcessDataSource.responseSchema = {
    resultNode : "projectUserRole",
    fields: getFieldsForProjectRoles(),
    metaFields: {totalRecords : "totalRecords"}
  };
  leadProcessEngrsDataTable = getLeadProcessEngrsTable(getLeadProcessEngrsColumnDefs(), this.leadProcessDataSource);
}

function getLeadProcessEngrsColumnDefs() {
  this.leadProcessEngrsCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (oData === "true") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, leadProcessEngrsDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, leadProcessEngrsDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  }


  this.deleteLeadProcessEngrsFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }

  this.dropdownEditorForLeadProcessEngrsDataTable = function (oEditor, oSelf) {
    dropdownEditor(oEditor, leadProcessEngrsDataTable);
  }
  var className = getClassNameForEditableCell(true);
  return  [
    {label:"Process Engineer", children:[
    {key:"userId", label:"Name", className:className, editor:dropdownEditorForLeadProcessEngrsDataTable, editorOptions:{disableBtns:true, dropdownOptions:leadProcessEngrsArray}, formatter:dropDownFormatter, sortable:false, resizeable:false, width:120},
    {key:"isLead", label:"Lead", className:className, formatter: this.leadProcessEngrsCheckboxFormatter, sortable:false, resizeable:false, width:40},
    {key:"delete", label:"Delete", className:className, formatter:this.deleteLeadProcessEngrsFormatter, width:50}]
    }];
}


function getLeadProcessEngrsTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 0;
  editableTableParams.lastEditableColumnIndex = 1;
  editableTableParams.newRecord = getNewProjectEngrRecord();
  leadProcessEngrsDataTable = createEditableDataTable("leadProcessEngrsList", columnDefs, dataSource, null, {scrollable:false,  draggableColumns:false},
  {pagination: false}, {editableTableParams:editableTableParams});
  var dt = leadProcessEngrsDataTable.getDataTable();
  dt.subscribe("renderEvent", function() {
    document.getElementById('addLeadProcessEngrBtn').disabled = '';
  });
  return leadProcessEngrsDataTable;
}

function addNewLeadProcessEngrRow() {
  var dt = leadProcessEngrsDataTable.getDataTable();
  if(dt.getRecordSet().getLength() < 4) {
   addNewRowToDataTable(leadProcessEngrsDataTable);
  } else {
    alert('Not more than 4 people assigned to any given role');
  }

}

function getNewLeadProcessEngrRecord() {
  return {
      leadProcessId:"",
       isLeadProcessLead:""
  };
}

function removeHiddenFieldsForLeadProcessEngrs(){
  var createProjectForm = document.getElementById("createProject");
  removeHiddenFields(createProjectForm, "leadProcessId");
  removeHiddenFields(createProjectForm, "isLeadProcessLead");  
}

function createHiddenFieldsForLeadProcessEngrs() {
  var createProject = document.getElementById("createProject");
  if (leadProcessEngrsDataTable != null) {
    var dt = leadProcessEngrsDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var userId = getEmptyStringIfUndefined(data.userId);
      var isLead = getEmptyStringIfUndefined(data.isLead);
      createProject.appendChild(createHiddenField("leadProcessId", userId));
      createProject.appendChild(createHiddenField("isLeadProcessLead", isLead));
    }
  }
}
