var locationManagersDataTable = null;
var locationManagersArray = null;


function getColumnDefsForLocationManagers(){
  var fieldArr = [];
  fieldArr[fieldArr.length] = "locationManagerId";
  fieldArr[fieldArr.length] = "isLeadLocationManager";
  return fieldArr;
}

function createLocationManagersTable(locationManagersArray) {
  this.locationManagersArray = locationManagersArray;
  var projectId = document.getElementById("projectId").value;
  var url = "/eis/data/projectUserXml/details?projectRole=Location Manager&projectId=" + projectId;
  this.locationManagersDataSource = createServerSidePaginationDataSource(url);
  this.locationManagersDataSource.responseSchema = {
    resultNode : "projectUserRole",
    fields: getFieldsForProjectRoles(),
    metaFields: {totalRecords : "totalRecords"}
  };
  locationManagersDataTable = getLocationManagersTable(getLocationManagersColumnDefs(), this.locationManagersDataSource);
}

function getLocationManagersColumnDefs() {
  this.locationManagersCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (oData === "true") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, locationManagersDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, locationManagersDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  }


  this.deleteLocationManagersFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }

  this.dropdownEditorForLocationManagersDataTable = function (oEditor, oSelf) {
    dropdownEditor(oEditor, locationManagersDataTable);
  }
  var className = getClassNameForEditableCell(true);
  return  [

    {label:"Location Manager", children:[
    {key:"userId", label:"Name", className:className, editor:dropdownEditorForLocationManagersDataTable, editorOptions:{disableBtns:true, dropdownOptions:locationManagersArray}, formatter:dropDownFormatter, sortable:false, resizeable:false, width:120},
    {key:"isLead", label:"Lead", className:className, formatter: this.locationManagersCheckboxFormatter, sortable:false, resizeable:false, width:40},
    {key:"delete", label:"Delete", className:className, formatter:this.deleteLocationManagersFormatter, width:50}]
    }];
}


function getLocationManagersTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 0;
  editableTableParams.lastEditableColumnIndex = 1;
  editableTableParams.newRecord = getNewProjectEngrRecord();
  locationManagersDataTable = createEditableDataTable("locationManagersList", columnDefs, dataSource, null, {scrollable:false,  draggableColumns:false},
  {pagination:false}, {editableTableParams:editableTableParams});
  var dt = locationManagersDataTable.getDataTable();
  dt.subscribe("renderEvent", function() {
    document.getElementById('addLocationManagerBtn').disabled = '';
  });
  return locationManagersDataTable;
}

function addNewLocationManagerRow() {
  var dt = locationManagersDataTable.getDataTable();
  if(dt.getRecordSet().getLength() < 4) {
   addNewRowToDataTable(locationManagersDataTable);
  } else {
    alert('Not more than 4 people assigned to any given role');
  }

}

function getNewLocationManagerRecord() {
  return {
      locationManagerId:"",
      isLeadLocationManager:""
  };
}

function removeHiddenFieldsForLocationManagers() {
  var createProjectForm = document.getElementById("createProject");
  removeHiddenFields(createProjectForm, "locationManagerId");
  removeHiddenFields(createProjectForm, "isLeadLocationManager");
}


function createHiddenFieldsForLocationManagers() {
  var createProject = document.getElementById("createProject");
  createProject.appendChild(createHiddenField("hasLocationManagerDataChanged", locationManagersDataTable != null));
  if (locationManagersDataTable != null) {
    var dt = locationManagersDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var userId = getEmptyStringIfUndefined(data.userId);
      var isLead = getEmptyStringIfUndefined(data.isLead);
      createProject.appendChild(createHiddenField("locationManagerId", userId));
      createProject.appendChild(createHiddenField("isLeadLocationManager", isLead));
    }
  }
}
