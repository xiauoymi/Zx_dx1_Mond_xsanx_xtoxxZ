function updateLocation(selectObject, defaultText) {
  var locationId = selectObject[selectObject.selectedIndex].value;
  var childLocationElement = resetChildLocations(selectObject, defaultText);
  if (locationId != null && locationId != '') {
    var createList = {
      success: function(o) {
        fillSelectDropdown(o.responseXML, childLocationElement, 'location', "id", "name");
      },
      failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
      },
      cache:false,
      timeout: 10000 //10 seconds
    };
    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
        "/eis/data/project/search?method=lookupProjectLocationXml&locationId=" + locationId,
        createList);
  }
}

function resetChildLocations(parentLocation, defaultText) {
  var childLocation;
  if (parentLocation.id === 'location') {
    childLocation = document.getElementById("country");
    setDefaultOption(document.getElementById("state"), defaultText);
    setDefaultOption(document.getElementById("city"), defaultText);
  }
  if (parentLocation.id === 'country') {
    childLocation = document.getElementById("state");
    setDefaultOption(document.getElementById("city"), defaultText);
  }
  if (parentLocation.id === 'state') {
    childLocation = document.getElementById("city");
  }

  removeAllOptions(childLocation);
  var docoption = document.createElement("OPTION");
  docoption.text = defaultText;
  docoption.value = "";
  childLocation.options.add(docoption);
  return childLocation;
}

function setDefaultOption(element, defaultText) {
  removeAllOptions(element);
  var docOption = document.createElement("OPTION");
  docOption.text = defaultText;
  docOption.value = "";
  element.options.add(docOption);
}

