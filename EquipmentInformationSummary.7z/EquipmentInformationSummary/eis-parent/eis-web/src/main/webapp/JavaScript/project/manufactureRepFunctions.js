var manufactureRepsDataTable = null;
var manufactureRepsArray = null;


function getColumnDefsForManufactureReps(){
  var fieldArr = [];
  fieldArr[fieldArr.length] = "manufactureRepId";
  fieldArr[fieldArr.length] = "isLeadManufactureRep";
  return fieldArr;
}

function createManufactureRepsTable(manufactureRepsArray) {
  this.manufactureRepsArray = manufactureRepsArray;
  var projectId = document.getElementById("projectId").value;
  var url = "/eis/data/projectUserXml/details?projectRole=Manufacturing Representative&projectId=" + projectId;
  this.manufactureRepsDataSource = createServerSidePaginationDataSource(url);
  this.manufactureRepsDataSource.responseSchema = {
    resultNode : "projectUserRole",
    fields: getFieldsForProjectRoles(),
    metaFields: {totalRecords : "totalRecords"}
  };
  manufactureRepsDataTable = getManufactureRepsTable(getManufactureRepsColumnDefs(), this.manufactureRepsDataSource);
}

function getManufactureRepsColumnDefs() {
  this.manufactureRepsCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (oData === "true") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, manufactureRepsDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, manufactureRepsDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  }


  this.deleteManufactureRepsFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }

  this.dropdownEditorForManufactureRepsDataTable = function (oEditor, oSelf) {
    dropdownEditor(oEditor, manufactureRepsDataTable);
  }
  var className = getClassNameForEditableCell(true);
  return  [

    {label:"Manufacturing Representative", children:[
    {key:"userId", label:"Name", className:className, editor:dropdownEditorForManufactureRepsDataTable, editorOptions:{disableBtns:true, dropdownOptions:manufactureRepsArray}, formatter:dropDownFormatter, sortable:false, resizeable:false, width:120},
    {key:"isLead", label:"Lead", className:className, formatter: this.manufactureRepsCheckboxFormatter, sortable:false, resizeable:false, width:40},
    {key:"delete", label:"Delete", className:className, formatter:this.deleteManufactureRepsFormatter, width:50}]
    }];
}


function getManufactureRepsTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 0;
  editableTableParams.lastEditableColumnIndex = 1;
  editableTableParams.newRecord = getNewProjectEngrRecord();
  manufactureRepsDataTable = createEditableDataTable("manufactureRepsList", columnDefs, dataSource, null, {scrollable:false,  draggableColumns:false},
  {pagination:false}, {editableTableParams:editableTableParams});
  var dt = manufactureRepsDataTable.getDataTable();
  dt.subscribe("renderEvent", function() {
    document.getElementById('addManufactureRepBtn').disabled = '';
  });
  return manufactureRepsDataTable;
}

function addNewManufactureRepRow() {
  var dt = manufactureRepsDataTable.getDataTable();
  if(dt.getRecordSet().getLength() < 4) {
   addNewRowToDataTable(manufactureRepsDataTable);
  } else {
    alert('Not more than 4 people assigned to any given role');
  }

}

function getNewManufactureRepRecord() {
  return {
      manufactureRepId:"",
      isLeadManufactureRep:""
  };
}

function removeHiddenFieldsForManufactureReps() {
  var createProjectForm = document.getElementById("createProject");
  removeHiddenFields(createProjectForm, "manufactureRepId");
  removeHiddenFields(createProjectForm, "isLeadManufactureRep");
}


function createHiddenFieldsForManufactureReps() {
  var createProject = document.getElementById("createProject");
  if (manufactureRepsDataTable != null) {
    var dt = manufactureRepsDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var userId = getEmptyStringIfUndefined(data.userId);
      var isLead = getEmptyStringIfUndefined(data.isLead);
      createProject.appendChild(createHiddenField("manufactureRepId", userId));
      createProject.appendChild(createHiddenField("isLeadManufactureRep", isLead));
    }
  }
}
