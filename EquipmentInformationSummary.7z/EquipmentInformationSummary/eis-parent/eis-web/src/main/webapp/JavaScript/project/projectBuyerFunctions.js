var projectBuyersDataTable = null;
var projectBuyersArray = null;


function getColumnDefsForProjectBuyers(){
  var fieldArr = [];
  fieldArr[fieldArr.length] = "projectBuyerId";
  fieldArr[fieldArr.length] = "isLeadProjectBuyer";
  return fieldArr;
}

function createProjectBuyersTable(projectBuyersArray) {
  this.projectBuyersArray = projectBuyersArray;
  var projectId = document.getElementById("projectId").value;
  var url = "/eis/data/projectUserXml/details?projectRole=Project Buyer&projectId=" + projectId;
  this.projectBuyersDataSource = createServerSidePaginationDataSource(url);
  this.projectBuyersDataSource.responseSchema = {
    resultNode : "projectUserRole",
    fields: getFieldsForProjectRoles(),
    metaFields: {totalRecords : "totalRecords"}
  };
  projectBuyersDataTable = getProjectBuyersTable(getProjectBuyersColumnDefs(), this.projectBuyersDataSource);
}

function getProjectBuyersColumnDefs() {
  this.projectBuyersCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (oData === "true") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, projectBuyersDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, projectBuyersDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  }


  this.deleteProjectBuyersFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }

  this.dropdownEditorForProjectBuyersDataTable = function (oEditor, oSelf) {
    dropdownEditor(oEditor, projectBuyersDataTable);
  }
  var className = getClassNameForEditableCell(true);
  return  [

    {label:"Project Buyer", children:[
    {key:"userId", label:"Name", className:className, editor:dropdownEditorForProjectBuyersDataTable, editorOptions:{disableBtns:true, dropdownOptions:projectBuyersArray}, formatter:dropDownFormatter, sortable:false, resizeable:false, width:120},
    {key:"isLead", label:"Lead", className:className, formatter: this.projectBuyersCheckboxFormatter, sortable:false, resizeable:false, width:40},
    {key:"delete", label:"Delete", className:className, formatter:this.deleteProjectBuyersFormatter, width:50}]
    }];
}


function getProjectBuyersTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 0;
  editableTableParams.lastEditableColumnIndex = 1;
  editableTableParams.newRecord = getNewProjectEngrRecord();
  projectBuyersDataTable = createEditableDataTable("projectBuyersList", columnDefs, dataSource, null, {scrollable:false,  draggableColumns:false},
  {pagination:false}, {editableTableParams:editableTableParams});
  var dt = projectBuyersDataTable.getDataTable();
  dt.subscribe("renderEvent", function() {
    document.getElementById('addProjectBuyerBtn').disabled = '';
  });
  return projectBuyersDataTable;
}

function addNewProjectBuyerRow() {
  var dt = projectBuyersDataTable.getDataTable();
  if(dt.getRecordSet().getLength() < 4) {
   addNewRowToDataTable(projectBuyersDataTable);
  } else {
    alert('Not more than 4 people assigned to any given role');
  }

}

function getNewProjectBuyerRecord() {
  return {
      projectBuyerId:"",
      isLeadProjectBuyer:""
  };
}

function removeHiddenFieldsForProjectBuyers() {
  var createProjectForm = document.getElementById("createProject");
  removeHiddenFields(createProjectForm, "projectBuyerId");
  removeHiddenFields(createProjectForm, "isLeadProjectBuyer");
}


function createHiddenFieldsForProjectBuyers() {
  var createProject = document.getElementById("createProject");
  if (projectBuyersDataTable != null) {
    var dt = projectBuyersDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var userId = getEmptyStringIfUndefined(data.userId);
      var isLead = getEmptyStringIfUndefined(data.isLead);
      createProject.appendChild(createHiddenField("projectBuyerId", userId));
      createProject.appendChild(createHiddenField("isLeadProjectBuyer", isLead));
    }
  }
}
