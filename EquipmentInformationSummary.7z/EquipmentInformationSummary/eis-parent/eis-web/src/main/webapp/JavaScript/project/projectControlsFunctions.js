var projectControlsDataTable = null;
var projectControlsArray = null;


function getColumnDefsForProjectControls() {
  var fieldArr = [];
  fieldArr[fieldArr.length] = "projectControlsId";
  fieldArr[fieldArr.length] = "isProjectControlsLead";
  return fieldArr;
}

function createProjectControlsTable(projectControlsArray) {
  this.projectControlsArray = projectControlsArray;
  var projectId = document.getElementById("projectId").value;
  var url = "/eis/data/projectUserXml/details?projectRole=Project Controls&projectId=" + projectId;
  this.projectControlsDataSource = createServerSidePaginationDataSource(url);
  this.projectControlsDataSource.responseSchema = {
    resultNode : "projectUserRole",
    fields: getFieldsForProjectRoles(),
    metaFields: {totalRecords : "totalRecords"}
  };
  projectControlsDataTable = getProjectControlsTable(getProjectControlsColumnDefs(), this.projectControlsDataSource);
}

function getProjectControlsColumnDefs() {
  this.projectControlsCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (oData === "true") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, projectControlsDataTable, \'' +
                     oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, projectControlsDataTable, \'' +
                     oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  }


  this.deleteProjectControlsFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }
  this.dropdownEditorForProjectControlsDataTable = function (oEditor, oSelf) {
    dropdownEditor(oEditor, projectControlsDataTable);
  }

  var className = getClassNameForEditableCell(true);
  return  [

    {label:"Project Controls", children:[
      {key:"userId", label:"Name", className:className, editor:dropdownEditorForProjectControlsDataTable, editorOptions:{disableBtns:true, dropdownOptions:projectControlsArray}, formatter:dropDownFormatter, sortable:false, resizeable:false, width:120},
      {key:"isLead", label:"Lead", className:className, formatter: this.projectControlsCheckboxFormatter, sortable:false, resizeable:false, width:40},
      {key:"delete", label:"Delete", className:className, formatter:this.deleteProjectControlsFormatter, width:50}]
    }];
}


function getProjectControlsTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 0;
  editableTableParams.lastEditableColumnIndex = 1;
  editableTableParams.newRecord = getNewProjectEngrRecord();
  projectControlsDataTable = createEditableDataTable("projectControlsList", columnDefs, dataSource, null, {scrollable:false,  draggableColumns:false},
  {pagination:false}, {editableTableParams:editableTableParams});
  var dt = projectControlsDataTable.getDataTable();
  dt.subscribe("renderEvent", function() {
    document.getElementById('addProjectControlsBtn').disabled = '';
  });
  return projectControlsDataTable;
}

function addNewProjectControlsRow() {
  var dt = projectControlsDataTable.getDataTable();
  if (dt.getRecordSet().getLength() < 4) {
    addNewRowToDataTable(projectControlsDataTable);
  } else {
    alert('Not more than 4 people assigned to any given role');
  }

}

function getNewProjectControlsRecord() {
  return {
    projectControlsId:"",
    isProjectControlsLead:""
  };
}

function removeHiddenFieldsForProjectControls() {
  var createProjectForm = document.getElementById("createProject");
  removeHiddenFields(createProjectForm, "projectControlsId");
  removeHiddenFields(createProjectForm, "isProjectControlsLead");
}


function createHiddenFieldsForProjectControls() {
  var createProject = document.getElementById("createProject");
  if (projectControlsDataTable != null) {
    var dt = projectControlsDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var userId = getEmptyStringIfUndefined(data.userId);
      var isLead = getEmptyStringIfUndefined(data.isLead);
      createProject.appendChild(createHiddenField("projectControlsId", userId));
      createProject.appendChild(createHiddenField("isProjectControlsLead", isLead));
    }
  }
}
