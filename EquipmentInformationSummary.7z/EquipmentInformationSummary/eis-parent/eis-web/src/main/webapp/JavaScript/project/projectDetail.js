var projectTabs = null;
YAHOO.util.Event.addListener(window, "load", function() {
  createEquipmentDialog();
  if (userHasEditAccessToThisProject()) {
    if (!isProjectMaster()) {
      createProjectCalendars();
    }
    createCostScheduleCalendars();
    createPurchasingCalendars();
  }
  createProjectTabs();
});

function createProjectCalendars() {
  createCalendar("AR_APPROVAL_DATE", "arApprovalDateContainer");
  createCalendar("STARTUP_DATE", "startupDateContainer");
}

function createProjectTabs() {
  projectTabs = new YAHOO.widget.TabView();
  var detailsTab = new YAHOO.widget.Tab({
    label: 'Details',
    content:  document.getElementById("detailsTab").innerHTML,
    active: false
  });
  projectTabs.addTab(detailsTab);

  var addEditDetailsTab = new YAHOO.widget.Tab({
    label: 'Add/Edit Details',
    content:  document.getElementById("addEditDetailsTab").innerHTML,
    active: false
  });
  //projectTabs.addTab(addEditDetailsTab);

  var equipmentListTab = new YAHOO.widget.Tab({
    label: 'Equipment List',
    content:  document.getElementById("equipmentListTab").innerHTML,
    active: false
  });
  projectTabs.addTab(equipmentListTab);

  projectTabs.on("activeTabChange", function(ev) {
    if (ev.newValue === equipmentListTab) {
      createEquipmentListTabs();
    }
  });

  var tabs = document.getElementById("projectTabs");
  tabs.innerHTML = "";
  projectTabs.appendTo(tabs);
  var activeTabIndex = document.getElementById("activeTabIndex").value;
  var isNewProject = document.getElementById('projectId').value;
  var isEditOperation = document.getElementById('OPERATION').value;
  if (activeTabIndex == "") {
    //add condition for edit project
    //    if (isNewProject != "" && isEditOperation != 'edit_project') {
    if (isNewProject != "" && isEditOperation != 'edit_project') {
      //project details
      activeTabIndex = 0;
      //getFormattedDate();
    }
    else {
      // remove detailsTab
      // to add   addEditDetailsTab
      projectTabs.removeTab(detailsTab);
      if (isNewProject == '' || isNewProject == null) {
        projectTabs.removeTab(equipmentListTab);
      }
      projectTabs.addTab(addEditDetailsTab, 0);
//      setHeaderCreateOrEdit();
      getRefDataForProjectPeople();
      enableDisplayProjectDetailFields(isEditOperation);
      activeTabIndex = 0;
    }
  }
  projectTabs.set("activeIndex", activeTabIndex);
}

function setProjectTabsActiveIndex(activeIndex) {
  projectTabs.set("activeIndex", activeIndex);
}


function editProject() {
  var projId = document.getElementById('projectId').value;
  document.prjDetails.action = "/eis/servlet/projects?method=edit_project&projectId=" + projId;
  document.prjDetails.submit();
}

function isProjectMaster() {
  var isMaster = document.getElementById('isMaster').value;
  return isMaster === "true";
}

function enableDisplayProjectDetailFields(operation) {
  if (operation == 'edit_project') {
    if (isProjectMaster()) {
      showTextField('PROJECT_NUMBER', document.getElementById('PROJECT_NUMBER').value, false);
      showTextField('PROJECT_NAME', document.getElementById('PROJECT_NAME').value, false);
      showSelect('location', document.getElementById('location').value, false);
      showSelect('country', document.getElementById('country').value, false);
      showSelect('state', document.getElementById('state').value, false);
      showSelect('city', document.getElementById('city').value, false);
      showTextField('AR_APPROVAL_DATE', formatDateForDisplay(document.getElementById('AR_APPROVAL_DATE').value), false);
      showTextField('STARTUP_DATE', formatDateForDisplay(document.getElementById('STARTUP_DATE').value), false);
      showSelect('CROP_ID', document.getElementById('CROP_ID').value, false);
      showSelect('UNIT_MEASURE_ID', document.getElementById('UNIT_MEASURE_ID').value, false);
      showSelect('PROJECT_STATUS_ID', document.getElementById('PROJECT_STATUS_ID').value, false);
    } else {
      var doesProjectHaveEquipments = document.getElementById('doesProjectHaveEquipments').value;
      if (doesProjectHaveEquipments === "true") {
        showSelect('CROP_ID', document.getElementById('CROP_ID').value, false);
      } else {
        showSelect('CROP_ID', document.getElementById('CROP_ID').value, true);
      }
    }
//    if (cropEnableDisable > 0){
    //      showSelect('CROP_ID', document.getElementById('CROP_ID').value, false);
    //    }else{
    //      showSelect('CROP_ID', document.getElementById('CROP_ID').value, true);
    //    }
  }
}

