var projectEngrsDataTable = null;
var projectEngrsArray = null;

function getFieldsForProjectRoles(){
  var fieldArr = [];
  fieldArr[fieldArr.length] = "userId";
  fieldArr[fieldArr.length] = "isLead";
  return fieldArr;
}

function createProjectEngrsTable(projectEngrsArray) {
  this.projectEngrsArray = projectEngrsArray;
  var projectId = document.getElementById("projectId").value;
  var url = "/eis/data/projectUserXml/details?projectRole=Project Engineer&projectId=" + projectId;
  this.projectEngrDataSource = createServerSidePaginationDataSource(url);
  this.projectEngrDataSource.responseSchema = {
    resultNode : "projectUserRole",
    fields: getFieldsForProjectRoles(),
    metaFields: {totalRecords : "totalRecords"}
  };
  projectEngrsDataTable = getProjectEngrsTable(getProjectEngrsColumnDefs(), this.projectEngrDataSource);
}

function getProjectEngrsColumnDefs() {
  this.projectEngrsCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (oData === "true") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, projectEngrsDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, projectEngrsDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  }


  this.deleteProjectEngrsFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }
  this.dropdownEditorForProjectEngrsDataTable = function (oEditor, oSelf) {
    dropdownEditor(oEditor, projectEngrsDataTable);
  }
  var className = getClassNameForEditableCell(true);

  return  [
    {label:"Project Engineer", children:[
    {key:"userId", label:"Name", className:className, editor:dropdownEditorForProjectEngrsDataTable, editorOptions:{disableBtns:true, dropdownOptions:projectEngrsArray}, formatter:dropDownFormatter, sortable:false, resizeable:false, width:120},
    {key:"isLead", label:"Lead", className:className, formatter: this.projectEngrsCheckboxFormatter, sortable:false, resizeable:false, width:40},
    {key:"delete", label:"Delete", className:className, formatter:this.deleteProjectEngrsFormatter, width:50}]
    }];
}


function getProjectEngrsTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 0;
  editableTableParams.lastEditableColumnIndex = 1;
  editableTableParams.newRecord = getNewProjectEngrRecord();
  projectEngrsDataTable = createEditableDataTable("projectEngrsList", columnDefs, dataSource, null, {scrollable:false,  draggableColumns:false},
  {pagination: false}, {editableTableParams:editableTableParams});
  var dt = projectEngrsDataTable.getDataTable();
  dt.subscribe("renderEvent", function() {
    document.getElementById('addProjectEngrBtn').disabled = '';
  });
  return projectEngrsDataTable;
}

function addNewProjectEngrRow() {
  var dt = projectEngrsDataTable.getDataTable();
  if(dt.getRecordSet().getLength() < 4) {
   addNewRowToDataTable(projectEngrsDataTable);
  } else {
    alert('Not more than 4 people assigned to any given role');
  }

}

function getNewProjectEngrRecord() {
  return {
      userId:"",
      isLead:""
  };
}

function removeHiddenFieldsForProjectEngrs() {
  var createProjectForm = document.getElementById("createProject");
  removeHiddenFields(createProjectForm, "projEngrId");
  removeHiddenFields(createProjectForm, "isProjEngrLead");
}

function createHiddenFieldsForProjectEngrs() {
  var createProject = document.getElementById("createProject");
  if (projectEngrsDataTable != null) {
    var dt = projectEngrsDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var userId = getEmptyStringIfUndefined(data.userId);
      var isLead = getEmptyStringIfUndefined(data.isLead);
      createProject.appendChild(createHiddenField("projEngrId", userId));
      createProject.appendChild(createHiddenField("isProjEngrLead", isLead));
    }
  }
}
