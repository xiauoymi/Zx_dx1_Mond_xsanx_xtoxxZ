var projectManagersDataTable = null;
var projectManagersArray = null;


function getColumnDefsForProjectManagers(){
  var fieldArr = [];
  fieldArr[fieldArr.length] = "projectManagerId";
  fieldArr[fieldArr.length] = "isLeadProjectManager";
  return fieldArr;
}

function createProjectManagersTable(projectManagersArray) {
  this.projectManagersArray = projectManagersArray;
  var projectId = document.getElementById("projectId").value;
  var url = "/eis/data/projectUserXml/details?projectRole=Project Manager&projectId=" + projectId;
  this.projectManagersDataSource = createServerSidePaginationDataSource(url);
  this.projectManagersDataSource.responseSchema = {
    resultNode : "projectUserRole",
    fields: getFieldsForProjectRoles(),
    metaFields: {totalRecords : "totalRecords"}
  };
  projectManagersDataTable = getProjectManagersTable(getProjectManagersColumnDefs(), this.projectManagersDataSource);
}

function getProjectManagersColumnDefs() {
  this.projectManagersCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (oData === "true") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, projectManagersDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, projectManagersDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  }


  this.deleteProjectManagersFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }
  this.dropdownEditorForProjectManagersDataTable = function (oEditor, oSelf) {
    dropdownEditor(oEditor, projectManagersDataTable);
  }

  var className = getClassNameForEditableCell(true);
 return  [
    {label:"Project Manager", children:[
    {key:"userId", label:"Name", className:className, editor:dropdownEditorForProjectManagersDataTable, editorOptions:{disableBtns:true, dropdownOptions:projectManagersArray}, formatter:dropDownFormatter, sortable:false, resizeable:false, width:120},
    {key:"isLead", label:"Lead", className:className, formatter: this.projectManagersCheckboxFormatter, sortable:false, resizeable:false, width:40},
    {key:"delete", label:"Delete", className:className, formatter:this.deleteProjectManagersFormatter, width:50}]
    }];
}


function getProjectManagersTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 0;
  editableTableParams.lastEditableColumnIndex = 1;
  editableTableParams.newRecord = getNewProjectEngrRecord();
  projectManagersDataTable = createEditableDataTable("projectManagersList", columnDefs, dataSource, null, {scrollable:false,  draggableColumns:false},
  {pagination:false}, {editableTableParams:editableTableParams});
  var dt = projectManagersDataTable.getDataTable();
  dt.subscribe("renderEvent", function() {
    document.getElementById('addProjectManagerBtn').disabled = '';
  });
  return projectManagersDataTable;
}

function addNewProjectManagerRow() {
  var dt = projectManagersDataTable.getDataTable();
  if(dt.getRecordSet().getLength() < 4) {
    addNewRowToDataTable(projectManagersDataTable);
  }  else {
    alert('Not more than 4 people assigned to any given role');
  }

}

function getNewProjectManagersRecord() {
  return {
      projectManagerId:"",
      isLeadProjectManager:""
  };
}

function removeHiddenFieldsForProjectManagers() {
  var createProjectForm = document.getElementById("createProject");
  removeHiddenFields(createProjectForm, "projectManagerId");
  removeHiddenFields(createProjectForm, "isLeadProjectManager");
}


function createHiddenFieldsForProjectManagers() {
  var createProject = document.getElementById("createProject");
  if (projectManagersDataTable != null) {
    var dt = projectManagersDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var userId = getEmptyStringIfUndefined(data.userId);
      var isLead = getEmptyStringIfUndefined(data.isLead);
      createProject.appendChild(createHiddenField("projectManagerId", userId));
      createProject.appendChild(createHiddenField("isLeadProjectManager", isLead));
    }
  }
}
