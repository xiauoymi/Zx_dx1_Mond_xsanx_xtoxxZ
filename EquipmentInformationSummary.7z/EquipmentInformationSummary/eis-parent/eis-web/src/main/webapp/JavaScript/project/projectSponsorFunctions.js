var projectSponsorsDataTable = null;
var projectSponsorsArray = null;


function getColumnDefsForProjectSponsors(){
  var fieldArr = [];
  fieldArr[fieldArr.length] = "projectSponsorId";
  fieldArr[fieldArr.length] = "isLeadProjectSponsor";
  return fieldArr;
}

function createProjectSponsorsTable(projectSponsorsArray) {
  this.projectSponsorsArray = projectSponsorsArray;
  var projectId = document.getElementById("projectId").value;
  var url = "/eis/data/projectUserXml/details?projectRole=Project Sponsor&projectId=" + projectId;
  this.projectSponsorsDataSource = createServerSidePaginationDataSource(url);
  this.projectSponsorsDataSource.responseSchema = {
    resultNode : "projectUserRole",
    fields: getFieldsForProjectRoles(),
    metaFields: {totalRecords : "totalRecords"}
  };
  projectSponsorsDataTable = getProjectSponsorsTable(getProjectSponsorsColumnDefs(), this.projectSponsorsDataSource);
}

function getProjectSponsorsColumnDefs() {
  this.projectSponsorsCheckboxFormatter = function(el, oRecord, oColumn, oData) {
    if (oData === "true") {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, projectSponsorsDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox" checked="true"/>';
    } else {
      el.innerHTML = '<input type="checkbox" onclick="handleEditableCheckboxClick(this, projectSponsorsDataTable, \'' + oRecord.getId() +
                     '\',\'' + oColumn.key +
                     '\')" class="yui-dt-checkbox"/>';
    }
  }


  this.deleteProjectSponsorsFormatter = function(el, oRecord, oColumn, oData) {
    el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                   '/images/icon_delete.gif">';
    el.style.cursor = 'pointer';
  }

  this.dropdownEditorForProjectSponsorsDataTable = function (oEditor, oSelf) {
    dropdownEditor(oEditor, projectSponsorsDataTable);
  }
  var className = getClassNameForEditableCell(true);

  return  [
    {label:"Project Sponsor", children:[
    {key:"userId", label:"Name", className:className, editor:dropdownEditorForProjectSponsorsDataTable, editorOptions:{disableBtns:true, dropdownOptions:projectSponsorsArray}, formatter:dropDownFormatter, sortable:false, resizeable:false, width:120},
    {key:"isLead", label:"Lead", className:className, formatter: this.projectSponsorsCheckboxFormatter, sortable:false, resizeable:false, width:40},
    {key:"delete", label:"Delete", className:className, formatter:this.deleteProjectSponsorsFormatter, width:50}]
    }];
}


function getProjectSponsorsTable(columnDefs, dataSource) {
  var editableTableParams = {};
  editableTableParams.firstEditableColumnIndex = 0;
  editableTableParams.lastEditableColumnIndex = 1;
  editableTableParams.newRecord = getNewProjectEngrRecord();
  projectSponsorsDataTable = createEditableDataTable("projectSponsorsList", columnDefs, dataSource, null, {scrollable:false,  draggableColumns:false},
  {pagination:false}, {editableTableParams:editableTableParams});
  var dt = projectSponsorsDataTable.getDataTable();
  dt.subscribe("renderEvent", function() {
    document.getElementById('addProjectSponsorBtn').disabled = '';
  });
  return projectSponsorsDataTable;
}

function addNewProjectSponsorRow() {
  var dt = projectSponsorsDataTable.getDataTable();
  if(dt.getRecordSet().getLength() < 4) {
   addNewRowToDataTable(projectSponsorsDataTable);
  } else {
    alert('Not more than 4 people assigned to any given role');
  }

}

function getNewProjectSponsorRecord() {
  return {
      projectSponsorId:"",
      isLeadProjectSponsor:""
  };
}

function removeHiddenFieldsForProjectSponsors() {
  var createProjectForm = document.getElementById("createProject");
  removeHiddenFields(createProjectForm, "projectSponsorId");
  removeHiddenFields(createProjectForm, "isLeadProjectSponsor");
}

function createHiddenFieldsForProjectSponsors() {
  var createProject = document.getElementById("createProject");
  if (projectSponsorsDataTable != null) {
    var dt = projectSponsorsDataTable.getDataTable();
    for (var i = 0; i < dt.getRecordSet().getLength(); i++) {
      var data = dt.getRecordSet().getRecord(i).getData();
      var userId = getEmptyStringIfUndefined(data.userId);
      var isLead = getEmptyStringIfUndefined(data.isLead);
      createProject.appendChild(createHiddenField("projectSponsorId", userId));
      createProject.appendChild(createHiddenField("isLeadProjectSponsor", isLead));
    }
  }
}
