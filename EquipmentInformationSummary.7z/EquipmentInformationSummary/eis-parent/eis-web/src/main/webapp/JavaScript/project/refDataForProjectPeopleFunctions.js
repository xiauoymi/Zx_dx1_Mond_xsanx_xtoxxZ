var projectUsersArr = null;

function getRefDataForProjectPeople() {
  this.populateArrays = {
    success: function(o) {
      var xmlDoc = o.responseXML;
      projectUsersArr = populateArrayForDropdown(xmlDoc, 'projectUsers/user', 'userId', 'name');
      createLeadElectDesignersTable(projectUsersArr);
      createLeadElectEngrsTable(projectUsersArr);
      createLeadMechDesignersTable(projectUsersArr);
      createLeadMechEngrsTable(projectUsersArr);
      createLeadProcessEngrsTable(projectUsersArr);
      createLocationManagersTable(projectUsersArr);
      createManufactureRepsTable(projectUsersArr);
      createProjectBuyersTable(projectUsersArr);
      createProjectControlsTable(projectUsersArr);
      createProjectManagersTable(projectUsersArr);
      createProjectSponsorsTable(projectUsersArr);
      createProjectEngrsTable(projectUsersArr);
    },
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    },
    cache:false //30 seconds
  };

  var url = document.getElementById('contextPath').value +
            "/data/projectRefDataXml/details?method=lookupRefDataForProjectPeople";
  this.getXML = YAHOO.util.Connect.asyncRequest("GET", url, this.populateArrays);

}

