function saveAsProject() {
  removeHiddenFieldsForLeadProcessEngrs();
  removeHiddenFieldsForLocationManagers();
  removeHiddenFieldsForLeadElectDesigners();
  removeHiddenFieldsForLeadElectEngrs();
  removeHiddenFieldsForLeadMechDesigners();
  removeHiddenFieldsForLeadMechEngrs();
  removeHiddenFieldsForManufactureReps();
  removeHiddenFieldsForProjectBuyers();
  removeHiddenFieldsForProjectControls();
  removeHiddenFieldsForProjectManagers();
  removeHiddenFieldsForProjectSponsors();
  removeHiddenFieldsForProjectEngrs();

  createHiddenFieldsForLeadProcessEngrs();
  createHiddenFieldsForLocationManagers();
  createHiddenFieldsForLeadElectDesigners();
  createHiddenFieldsForLeadElectEngrs();
  createHiddenFieldsForLeadMechDesigners();
  createHiddenFieldsForLeadMechEngrs();
  createHiddenFieldsForManufactureReps();
  createHiddenFieldsForProjectBuyers();
  createHiddenFieldsForProjectControls();
  createHiddenFieldsForProjectManagers();
  createHiddenFieldsForProjectSponsors();
  createHiddenFieldsForProjectEngrs();

  var callbackAfterProjectSave = {
    success: function(o) {
      this.cache = null;
      var xmlDoc = o.responseXML;
      if(xmlDoc.selectSingleNode("//projectId") != null)  {
      document.getElementById('projectId').value = xmlDoc.selectSingleNode("//projectId").text;
        }

      var messageElement = document.getElementById('messagesForProject');
      if (messageElement != null) {
        messageElement.style.display = "";
      }

      var errors = xmlDoc.selectNodes("//error");
      var errorStr = "";
      if (errors.length === 0) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/projects?method=project_detail&projectSavedMsg=Project Saved&projectId=" +
                                 document.getElementById('projectId').value;
      } else {
        for (var i = 0; i < errors.length; i++) {
          var errorHeader = errors[i].selectSingleNode("errorHeader").firstChild.nodeValue;
          errorStr += "<span class='errorMsgHeader'>" + errorHeader + "</span><br/>";
          var errorMsgs = errors[i].selectNodes("errorMsg");
          for (var j = 0; j < errorMsgs.length; j++) {
            var errorMsg = errorMsgs[j].firstChild.nodeValue;
            errorStr += errorMsg + "<br/>";
          }
        }
      }

      hideOrShowSucessAndErrorMessageDiv(false, null, "errorMsgsForProjectDiv", null, errorStr);
      document.getElementById('errorMsgsForProjectDiv').innerHTML = errorStr;

//      updateEquipmentHeader();
      document.getElementById('saveProjectBtn').disabled = '';
      document.getElementById('saveAsProjectBtn').disabled = '';
    },
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    },
    cache:false,
    timeout: 40000 //20 seconds
  };

  document.getElementById('saveProjectBtn').disabled = "disabled";
  document.getElementById('saveAsProjectBtn').disabled = "disabled";
  var createProjectForm = document.getElementById("createProject");
  YAHOO.util.Connect.setForm(createProjectForm);
  //if(var)
  this.getXML = YAHOO.util.Connect.asyncRequest("POST",
      "/eis/data/projects/create?method=saveAs",
      callbackAfterProjectSave);
}

function saveAsProjectWithoutEdit(originalProjectId, originalProjectNumber) {
    openWindow(originalProjectId, originalProjectNumber);
}

function callSaveAs(){
    var projectNum = document.getElementById('projectNumberForSaveAs').value;
    if (projectNum != "" && projectNum.length != 8){
        alert("Please enter exactly 8 characters for the New Project #");
        projectNum = null;
    }

    if (projectNum == document.getElementById('originalProjectNumber').value) {
        alert("You must enter a DIFFERENT project number to save as.");
        projectNum = null;
    }
    var callbackAfterProjectSave = {
      success: function(o) {

          var xmlDoc = o.responseXML;
          var newProjectId = xmlDoc.selectSingleNode("//projectId").text;

          var errors = xmlDoc.selectNodes("//error");
          var errorStr = "";
          if (errors.length === 0) {
              alert("Project saved with project id " + newProjectId);
          } else {
            for (var i = 0; i < errors.length; i++) {
              var errorHeader = errors[i].selectSingleNode("errorHeader").firstChild.nodeValue;
              errorStr = errorHeader + "\n\n";
              var errorMsgs = errors[i].selectNodes("errorMsg");
              for (var j = 0; j < errorMsgs.length; j++) {
                var errorMsg = errorMsgs[j].firstChild.nodeValue;
                errorStr += errorMsg + "\n";
              }
            }

            alert(errorStr);
          }
      },
      failure: function(o) {
          document.location.href = document.getElementById('contextPath').value +
                                   "/servlet/logon?method=error";
      },
      cache:false,
      timeout: 40000 //20 seconds
    };


//    var projectNum = prompt("Enter the project number to save as:", "");
  

    if (projectNum!=null && projectNum!="") {
        var url = "/eis/data/projects/create?method=saveAsById&projectId=" + escape(document.getElementById('originalProjectId').value) +
                  "&PROJECT_NUMBER=" + escape(projectNum);
        this.getXML = YAHOO.util.Connect.asyncRequest("GET", url, callbackAfterProjectSave);
    }
}


  function openWindow() {
	var myWindow = window.open('about:blank', '', 'width=300,height=250');
	myWindow.document.write("<body><form id='formPopUp' name='formPopUp'>");
	myWindow.document.write("<h5>Please enter the Project # to save as:</h5>");
    myWindow.document.write("<input type='text' id='projectNum' name='projectNum' value='' maxLength='8'/>");
    myWindow.document.write("<br/>");
    myWindow.document.write("<br/>");
    myWindow.document.write("<input type='button' name='OK' value='OK' onclick='window.opener.prjDetails.projectNumberForSaveAs.value=document.formPopUp.projectNum.value; window.opener.callSaveAs(); window.close();'/>");
    myWindow.document.write("<input type='button' name='Cancel' value='Cancel' onclick='window.close()'/>");
	myWindow.document.write("</form></body>");
	myWindow.focus();
}

