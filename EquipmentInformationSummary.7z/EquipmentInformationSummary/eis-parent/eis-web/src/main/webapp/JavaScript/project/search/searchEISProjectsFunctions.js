var showingArchivedProjects = false;

YAHOO.util.Event.addListener(window, "load", function() {
  document.getElementById("areProjectsActive").innerHTML = 'Active ';
  searchProjectsBasedOnCriteria();
});

function hideCancelProjectMsg(){
  document.getElementById('cancelProjectMsg').style.display = 'none';
}

function toggleDiv(x, y) {
  if (document.getElementById(x).style.display == 'none') {
    document.getElementById(x).style.display = '';
    document.getElementById(y).style.display = 'none';
  } else {
    document.getElementById(x).style.display = 'none';
    document.getElementById(y).style.display = '';
  }
  if (x === 'showArchive') {
    showingArchivedProjects = true;
    viewArchivedProjects();
  }

  if (x === 'showActive') {
    showingArchivedProjects = false;
    viewActiveProjects();
  }
}

function viewActiveProjects() {
  populateProjectsStatus(false);
  document.getElementById("areProjectsActive").innerHTML = 'Active ';
  clearProjectsSearch();
  searchProjectsBasedOnCriteria();
}

function viewArchivedProjects() {
  populateProjectsStatus(true);
  document.getElementById("areProjectsActive").innerHTML = 'Archived ';
  clearProjectsSearch();
  searchProjectsBasedOnCriteria();
}

function searchProjectsBasedOnCriteria() {
  setFocus();
  var projectNumber = document.getElementById('projectNumber').value;
  var location = document.getElementById('location')[document.getElementById('location').selectedIndex].value;
  var country = document.getElementById('country')[document.getElementById('country').selectedIndex].value;
  var state = document.getElementById('state')[document.getElementById('state').selectedIndex].value;
  var city = document.getElementById('city')[document.getElementById('city').selectedIndex].value;
  var crop = document.getElementById('crop')[document.getElementById('crop').selectedIndex].value;
  var status = document.getElementById('status')[document.getElementById('status').selectedIndex].value;

  var url = document.getElementById('contextPath').value + "/data/project/datasource?projectNumber="
      + projectNumber + "&location=" + location + "&country=" + country + "&state=" + state + "&city=" + city
      + "&crop=" + crop + "&status=" + status + "&archived=" + showingArchivedProjects;

  createProjectListTable(url);
}

function populateProjectsStatus(isArchived) {
  var createProjectStatusList = {
    success: function(o) {
      fillProjectStatusList(o);
    },
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    },
    cache:false
  };
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      "/eis/data/project/search?method=lookupProjectStatusXml&archivedStatus=" +
      isArchived, createProjectStatusList);
}

function fillProjectStatusList(o) {
  var xmlDoc = o.responseXML;
  var projectsStatusSelectObject = document.getElementById('status');
  removeProjectsStatusOptions(projectsStatusSelectObject);

  var docoption = document.createElement("OPTION");
  docoption.text = "All";
  projectsStatusSelectObject.options.add(docoption);

  var elements = xmlDoc.selectNodes('//refData/projectStatus');
  for (var i = 0; i < elements.length; i++) {
    var optionId = elements[i].selectSingleNode("id").firstChild.nodeValue;
    var projectStatusName = elements[i].selectSingleNode("name").firstChild.nodeValue;
    docoption = document.createElement("OPTION");
    docoption.text = projectStatusName;
    docoption.value = optionId;
    projectsStatusSelectObject.options.add(docoption);
  }
}

function removeProjectsStatusOptions(projectsStatusSelectObject) {
  var i;
  for (i = projectsStatusSelectObject.options.length - 1; i >= 0; i--) {
    projectsStatusSelectObject.remove(i);
  }
}

function clearProjectsSearch() {
  setDefaultOption(document.getElementById("country"), 'All');
  setDefaultOption(document.getElementById("state"), 'All');
  setDefaultOption(document.getElementById("city"), 'All');

  document.getElementById('projectNumber').value = '';
  document.getElementById('location').selectedIndex = 0;
  document.getElementById('crop').selectedIndex = 0;
  document.getElementById('status').selectedIndex = 0;
}

//function getURLToRefreshProjectsList(isDelete) {
//  var projectNumber = document.getElementById('projectNumberLastSearch').value;
//  var location = document.getElementById('locationLastSearch').value;
//  var country = document.getElementById('countryLastSearch').value;
//  var state = document.getElementById('stateLastSearch').value;
//  var city = document.getElementById('cityLastSearch').value;
//  var crop = document.getElementById('cropLastSearch').value;
//  var status = document.getElementById('statusLastSearch').value;
//
//  var operation = 'archive';
//  if (isDelete)
//    operation = 'delete'
//
//  return (document.getElementById('contextPath').value + "/data/project/search?method=" + operation +
//          "Projects&projectNumber="
//      + projectNumber + "&location=" + location + "&country=" + country + "&state=" + state + "&city=" + city
//      + "&crop=" + crop + "&status=" + status );
//}
//
//function refreshSearchCriteria() {
//  //  debugger;
//  document.getElementById('projectNumber').value = document.getElementById('projectNumberLastSearch').value;
//  if (document.getElementById('locationLastSearch').value == '')
//    document.getElementById('location').value = '';
//
//  if (document.getElementById('countryLastSearch').value == '')
//    document.getElementById('country').value = '';
//
//  if (document.getElementById('stateLastSearch').value == '')
//    document.getElementById('state').value = '';
//
//  if (document.getElementById('cityLastSearch').value == '')
//    document.getElementById('city').value = '';
//
//
//  if (document.getElementById('cropLastSearch').value == '')
//    document.getElementById('crop').value = '';
//  if (document.getElementById('statusLastSearch').value == '')
//    document.getElementById('status').value = '';
//}
//
//function initDeleteAndArchiveButtons() {
//  // Instantiate the Dialog
//  var deleteConfirmation = new YAHOO.widget.SimpleDialog("deleteConfirmationDialog",
//  { width: "500px",
//    fixedcenter: true,
//    visible: false,
//    draggable: false,
//    close: true,
//    text: 'You are requesting this Project to be deleted. Please select \"Yes\" to continue or \"No\"to cancel.',
//    icon: YAHOO.widget.SimpleDialog.ICON_ALARM,
//    constraintoviewport: true,
//    buttons: [ { text:"Yes", handler:handleDeleteYes, isDefault:true },
//      { text:"No",  handler:handleNo } ]
//  });
//  deleteConfirmation.setHeader("Confirm Delete");
//  deleteConfirmation.render(document.body);
//  YAHOO.util.Event.addListener("deleteButton", "click", deleteConfirmation.show, deleteConfirmation, true);
//
//  var archiveConfirmation = new YAHOO.widget.SimpleDialog("archiveConfirmationDialog",
//  { width: "500px",
//    fixedcenter: true,
//    visible: false,
//    draggable: false,
//    close: true,
//    text: 'You are requesting this Project to be archived. Please select \"Yes\" to continue or \"No\" to cancel.',
//    icon: YAHOO.widget.SimpleDialog.ICON_ALARM,
//    constraintoviewport: true,
//    buttons: [ { text:"Yes", handler:handleArchiveYes, isDefault:true },
//      { text:"No",  handler:handleNo } ]
//  });
//  archiveConfirmation.setHeader("Confirm Archive");
//  archiveConfirmation.render(document.body);
//  YAHOO.util.Event.addListener("archiveButton", "click", archiveConfirmation.show, archiveConfirmation, true);
//}
//
//// Define various event handlers for Dialog
//var handleDeleteYes = function() {
//  this.hide();
//  var selectedIDs = getSelectedIds();
//  if (selectedIDs == null || selectedIDs == '') {
//    alert("Please select a project to delete.");
//    return;
//  }
//  var deleteProjectsURL = '&projectIds=' + selectedIDs;
//  var url = getURLToRefreshProjectsList(true) + deleteProjectsURL;
//  var callbackAfterGettingProjectsList = {
//    success: function(o) {
//      createProjectListTable(o);
//    }
//    ,
//    cache:false ,
//    failure: function(o) {
//      alert('call failed');
//    }
//    ,
//    timeout: 20000 //20 seconds
//  }
//  this.getXML = YAHOO.util.Connect.asyncRequest('GET', url, callbackAfterGettingProjectsList);
//
//  clearSelectedIds();
//  refreshSearchCriteria();
//};
//
//var handleNo = function() {
//  this.hide();
//  clearSelectedIds();
//};
//
//// Define various event handlers for Dialog
//var handleArchiveYes = function() {
//  alert("You clicked Yes Archive !");
//  this.hide();
//  var deleteProjectsURL = '&projectIds=' + getSelectedIds();
//  var url = getURLToRefreshProjectsList(false) + deleteProjectsURL;
//  alert(url);
//  /*   var callbackAfterGettingProjectsList = {
//      success: function(o) {
//        createProjectListTable(o);
//      }
//      ,
//      failure: function(o) {
//        alert('call failed');
//      }
//      ,
//      timeout: 20000 //20 seconds
//    }
//  this.getXML = YAHOO.util.Connect.asyncRequest('GET', url, callbackAfterGettingProjectsList);
//  */
//  clearSelectedIds();
//  refreshSearchCriteria();
//};


