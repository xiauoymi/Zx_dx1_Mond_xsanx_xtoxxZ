var searchProjectsDataTable = null;

function createProjectListTable(url) {
  if (searchProjectsDataTable == null) {
    this.projectListDataSource = createServerSidePaginationDataSource(url);
    var fieldArr = [];
    fieldArr[fieldArr.length] = "projectId";
    fieldArr[fieldArr.length] = "projNumber";
    fieldArr[fieldArr.length] = "projName";
    fieldArr[fieldArr.length] = "cityName";
    fieldArr[fieldArr.length] = "startupDate";
    fieldArr[fieldArr.length] = "projStatusName";
    fieldArr[fieldArr.length] = "isMaster";
    this.projectListDataSource.responseSchema = {
      resultNode: "project",
      fields: fieldArr,
      metaFields: {totalRecords : "totalRecords"}
    };
    searchProjectsDataTable = getProjectTable(getProjectListColumnDefs(), this.projectListDataSource);
  } else {
    searchProjectsDataTable.requery(url);
  }
}

function getProjectTable(columnDefs, dataSource) {
  var eisDataTable = createDataTable("projectsList", columnDefs, dataSource, "projNumber",
  {scrollable:true, width:getWidthForDataTable(), emptyMsg:"No Matching Projects Found"}, {pagination: true, topPaginator:'topPaginatorForProjectList'});

  var dt = eisDataTable.getDataTable();
  dt.doBeforeSortColumn = function(oColumn, sSortDir) {
    hideCancelProjectMsg();
    return true;
  }
  dt.doBeforePaginatorChange = function(oPaginatorState) {
    hideCancelProjectMsg();
    return true;
  }
  return eisDataTable;
}

function getProjectListColumnDefs() {
  this.projectNumberFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<a href="' + document.getElementById('contextPath').value +
                       '/servlet/projects?method=project_detail&projectId=' + oRecord.getData('projectId') + '">' +
                       oData + '</a>';
  };

  this.deleteProjectFormatter = function(el, oRecord, oColumn, oData) {
    if (oRecord.getData("isMaster") === "false") {
      el.innerHTML = '<img border="0" alt="Delete Row" src="' + document.getElementById('contextPath').value +
                     '/images/icon_delete.gif" onclick="showDeleteProjectWarning(\'' + oRecord.getData('projectId') +
                     '\')">';
      el.style.cursor = 'pointer';
    } else {
      el.innerHTML = '';
    }
  }
  var columnDefs = [];
  columnDefs[columnDefs.length] = {key:"projNumber", label:"Project #", formatter:this.projectNumberFormatter, sortable:true, resizeable:true, width:100};
  columnDefs[columnDefs.length] = {key:"projName", label:"Project Name", sortable:true, resizeable:true, width: 400};
  columnDefs[columnDefs.length] = {key:"cityName", label:"Location", sortable:true, resizeable:true, width:120};
  columnDefs[columnDefs.length] = {key:"startupDate", label:"Target Start-Up Date", sortable:true, resizeable:true, width:130};
  columnDefs[columnDefs.length] = {key:"projStatusName", label:"Status", sortable:true, resizeable:true, width:100};
  if (isUserProcessTeamLead()) {
    columnDefs[columnDefs.length] = {key:"deleteReadOnly",label:"Delete", formatter:this.deleteProjectFormatter, width:60};
  }
  return columnDefs;
}

function showDeleteProjectWarning(projectId) {
  if (okToDelete()) {
    hideCancelProjectMsg();
    deleteProjectRow(projectId);
  }
}

function deleteProjectRow(projectId) {
  var callbackAfterDeletingProject = {
    success: function(o) {
      this.cache = null;
      searchProjectsBasedOnCriteria();
    },
    cache:false ,
    failure: function(o) {
        document.location.href = document.getElementById('contextPath').value +
                                 "/servlet/logon?method=error";
    }
    ,
    timeout: 20000 //20 seconds
  }
  var url = document.getElementById('contextPath').value + "/servlet/projects?method=deleteProject&projectId=" +
            projectId;
  this.getXML = YAHOO.util.Connect.asyncRequest('GET', url, callbackAfterDeletingProject);
}


