var dt = null;
var key = null;
var selectedIdsElementName = 'selectedIds';
//var idsToExcludeElementName = 'idsToExclude';


function setParamsForSelectOperate(thisdt, thiskey) {
  dt = thisdt;
  key = thiskey;
}

function checkboxFormatter(elCell, oRecord, oColumn, oData) {
//  debugger;
  var id = oRecord.getData(key);
  var isCheckboxChecked = false;
  if (dt != null) {
    isCheckboxChecked = isIdInSelectedIds(id);
  }
  return YAHOO.widget.DataTable.formatCheckbox(elCell, oRecord, oColumn, isCheckboxChecked);
}

function checkboxClickEvent(oArgs) {
  //check for column key to be sure if there are more than 1 checkbox in the datatable
  var elCheckbox = oArgs.target;
  var oRecord = dt.getRecord(elCheckbox);
  var id = oRecord.getData(key);

  if (elCheckbox.checked) {
    addToSelectedIds(id);
  } else {
    removeFromSelectedIds(id);
  }
}

function clearSelectOperateSelections() {
  clearSelectedIds();
//  clearIdsToExclude();
}

function getSelectedIds() {
  return document.getElementById(selectedIdsElementName).value;
}

function isIdInSelectedIds(id) {
  return getSelectedIds().indexOf(',' + id) >= 0
}

function addToSelectedIds(id) {
  if(getSelectedIds() != '')
    return setSelectedIds(getSelectedIds() + ',' + id);
  else
    return setSelectedIds(id);
}

function removeFromSelectedIds(id) {
  setSelectedIds(getSelectedIds().replace(',' + id, ''));
}

function setSelectedIds(ids) {
  return document.getElementById(selectedIdsElementName).value = ids;
}

function clearSelectedIds() {
  return setSelectedIds("");
}

function getTotalNumberOfRecordsOnThisPage() {
  var firstIndexOnThisPage = getPaginator().getPageRecords()[0];
  var lastIndexOnThisPage = getPaginator().getPageRecords()[1];
  return lastIndexOnThisPage - firstIndexOnThisPage;
}

function getPaginator() {
  return dt.getAttributeConfig('paginator').value;
}

//function getCheckbox(index) {
//  var row = dt.getRow(index);
//  var cell = row.cells[0];
//  return cell.getElementsByTagName('input')[0];
//}

function getId(index) {
  var row = dt.getRow(index);
  var oRecord = dt.getRecord(row);
  return oRecord.getData(key);
}
//  var firstRow = v.getFirstTrEl();
//  if(firstRow != null){
//    checkUncheckAllBoxes(firstRow, allCheckbox);
//    var nextRow = dt.getNextTrEl(firstRow);
//    while(nextRow != null){
//      checkUncheckAllBoxes(nextRow, allCheckbox);
//      nextRow = dt.getNextTrEl(nextRow);
//    }
//  }


