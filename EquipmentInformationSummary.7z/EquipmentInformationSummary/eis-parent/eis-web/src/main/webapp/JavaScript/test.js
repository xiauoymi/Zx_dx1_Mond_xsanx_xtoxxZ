function DelSso2Cookie() {
    debugger;
    delete_cookie('MYSAPSSO2');
    var value = readCookie('MYSAPSSO2');
    alert('cookie' + value);
}
function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}
function delete_cookie(cookie_name) {
    var cookie_date = new Date();
    cookie_date.setTime ( cookie_date.getTime() - 1 );
    document.cookie = cookie_name += "=; expires=" + cookie_date.toGMTString();
}

function deleteCookie(){
    debugger;
    var sso2Domain = location.hostname;
    var sPath="/sap/bc/webdynpro/sap/y_mmim_tagprint/";
    var sName="sap-hostid";
    alert('Domain:'+sso2Domain);
    if (location.hostname.indexOf(".")>0)
    sso2Domain = location.hostname.substr(location.hostname.indexOf(".")+1);
    p="";
    if(sPath)p=" path="+sPath+";";
    alert('path:'+p);
    alert(sName+"=0; expires=Fri, 31 Dec 1999 23:59:59 GMT;"+p + "domain="+sso2Domain+";");
    document.cookie = sName+"=0; expires=Fri, 31 Dec 1999 23:59:59 GMT;"+p + "domain="+sso2Domain+";";
    alert('Delete Cookie');
}

function deleteCookie(){
    debugger;
    var sso2Domain = location.hostname;
    var sPath="/sap/bc/webdynpro/sap/y_mmim_tagprint/";
    var sName="sap-hostid";
    alert('Domain:'+sso2Domain);
    if (location.hostname.indexOf(".")>0)
    sso2Domain = location.hostname.substr(location.hostname.indexOf(".")+1);
    p="";
    if(sPath)p=" path="+sPath+";";
    alert('path:'+p);
    alert(sName+"=0; expires=Fri, 31 Dec 1999 23:59:59 GMT;"+p + "domain="+sso2Domain+";");
    document.cookie = sName+"=0; expires=Fri, 31 Dec 1999 23:59:59 GMT;"+p + "domain="+sso2Domain+";";
    alert('Delete Cookie');
}

function deleteCookie(){
    debugger;
    var sso2Domain = location.hostname;
    var sPath='/';
    var sName="MYSAPSSO2";
    alert('Domain:'+sso2Domain);
    if (location.hostname.indexOf(".")>0)
    sso2Domain = location.hostname.substr(location.hostname.indexOf(".")+1);
    p="";
    if(sPath)p=" path="+sPath+";";
    alert('path:'+p);
    alert(sName+"=0; expires=Fri, 31 Dec 1999 23:59:59 GMT;"+p + "domain="+sso2Domain+";");
    document.cookie = sName+"=0; expires=Fri, 31 Dec 1999 23:59:59 GMT;"+p + "domain="+sso2Domain+";";
    alert('Delete Cookie');
}