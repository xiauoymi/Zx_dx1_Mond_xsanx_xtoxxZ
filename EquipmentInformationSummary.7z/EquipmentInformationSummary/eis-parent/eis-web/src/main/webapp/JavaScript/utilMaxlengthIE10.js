function getMaxLength(element) {
    if (isValidElementMaxLength(element)) {
        return element.value.length < element.maxLength;
    }
    return getMaxLengthByHtml(element);
}

function isValidElementMaxLength(element) {
    var resultOfParsing = "" + parseInt(element.maxlength) + "";
    if (resultOfParsing === "NaN") {
        return false
    } else {
        return true;
    }
}

function getMaxLengthByHtml(element) {
    var valueFromMaxLengthVarUntilEnd = getSubstringFromMaxLengthVariableUntilEndOfString(element);
    var varMaxLength = getVariableMaxLength(valueFromMaxLengthVarUntilEnd);

    return getValueOfMaxLengthVariable(varMaxLength);
}

function getValueOfMaxLengthVariable(variable){
    return variable.substr(variable.indexOf("=") + 1, variable.length);
}
function getVariableMaxLength(valueFromMaxLengthVarUntilEnd){
    return valueFromMaxLengthVarUntilEnd.substr(0, valueFromMaxLengthVarUntilEnd.indexOf(" "));
}

function getSubstringFromMaxLengthVariableUntilEndOfString(element) {
    var elementHTML = $(element).attr('outerHTML');
    var locatePositionForMaxLengthVar = $(element).attr('outerHTML').toLowerCase().indexOf("maxlength=");
    return elementHTML.substr(locatePositionForMaxLengthVar, elementHTML.length);
}