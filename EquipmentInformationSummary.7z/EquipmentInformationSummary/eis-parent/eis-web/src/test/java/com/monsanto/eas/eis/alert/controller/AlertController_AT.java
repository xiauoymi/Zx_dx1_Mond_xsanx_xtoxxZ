/*
 AlertController_AT was created on Feb 9, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.eas.eis.logon.hibernateMappings.Role;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.w3c.dom.Document;

import java.util.HashSet;

/**
 * Filename:    $RCSfile: AlertController_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 15:41:21 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class AlertController_AT extends EISTestCase {
  private GenericDAO userDao = new HibernateDAO<User, Long>(EISHibernateUtil.getHibernateFactory(), User.class);

  public void testlookupProjectsInDetailedDesignStateForAUser() throws Exception {
//     Criteria criteria = userDao.createCriteria();
//    criteria.add(Restrictions.eq("userId", "RRMALL").ignoreCase());
//    User user = (User) criteria.uniqueResult();
//    MockUCCHelper helper = new MockUCCHelper(null);
//    helper.setSessionParameter(EISConstants.LOGIN_USER, user);
//    helper.getSessionParameter(EISConstants.LOGIN_USER);
//    helper.setRequestParameterValue(EISConstants.METHOD, "lookupProjectsByProjectStatusForAUser");
//    HashSet<Role> roles = new HashSet<Role>();
//    roles.add(new Role(new Long(12), "eis_user"));
//    AlertController controller = new AlertController();
//    controller.run(helper);
//    Document xmlDoc = helper.getXML();
//    assertXpathEvaluatesTo("1", "//count", xmlDoc);
//    assertXpathEvaluatesTo("01 Testing 1 - 00012121", "//projectName[1]", xmlDoc);
//    assertXpathEvaluatesTo("377150", "//projectId[1]", xmlDoc);
  }
}