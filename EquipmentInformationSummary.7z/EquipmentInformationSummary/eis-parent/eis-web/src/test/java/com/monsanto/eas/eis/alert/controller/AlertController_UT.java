/*
 AlertController_UT was created on Feb 5, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.controller;

import com.monsanto.eas.eis.alert.mock.MockUCCHelperForAlert;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateSessionForReports;
import com.monsanto.eas.eis.equipment.service.*;
import com.monsanto.eas.eis.equipment.service.mock.MockCostScheduleService;
import com.monsanto.eas.eis.equipment.service.mock.MockElectricalService;
import com.monsanto.eas.eis.equipment.service.mock.MockMechanicalService;
import com.monsanto.eas.eis.equipment.service.mock.MockProcessService;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.projects.*;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.mocks.MockEquipmentServiceImpl;
import com.monsanto.eas.eis.projects.mocks.MockProjectServiceImpl;
import com.monsanto.eas.eis.projects.services.UserService;
import com.monsanto.eas.eis.projects.services.mock.MockUserService;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.ElectricalConstants;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: AlertController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 15:31:29 $
 *
 * @author rrmall
 * @version $Revision: 1.5 $
 */
public class AlertController_UT extends XMLTestCase {

  private EISDAOFactory mockDaoFactory;
  private ProjectsController pc;
  private MockProjectServiceImpl projectsService;
  private ProcessService processService;
  private EquipmentService equipmentService;
  private ElectricalService electricalService;
  private CostScheduleService costScheduleService;
  UserService userService;
  MechanicalService mechanicalService;
  AlertController ac;

  protected void setUp() throws Exception {
    super.setUp();
    MockProjectServiceImpl projectService = new MockProjectServiceImpl(new MockHibernateSessionForReports(null));
    processService = new MockProcessService();
    equipmentService = new MockEquipmentServiceImpl();
    electricalService = new MockElectricalService();
    costScheduleService = new MockCostScheduleService();
    mechanicalService = new MockMechanicalService();
    userService = new MockUserService(true, false, false, null, null);
    ac = new AlertController(projectService, processService, equipmentService,
        electricalService, costScheduleService, mechanicalService, userService);
  }

  public void testlookupProjectsInDetailedDesignStateForAUser_ReturnsAListWith2Projects() throws Exception {
    MockUCCHelperForAlert helper = new MockUCCHelperForAlert("hasRoles");
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupProjectsByProjectStatusForAUser");
    ac.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "//count", xmlDoc);
    assertXpathEvaluatesTo("Test Project - 111", "//projectName[1]", xmlDoc);
    assertXpathEvaluatesTo("1", "//projectId[1]", xmlDoc);
  }

   public void testlookupProjectNotInDetailedDesignStateForAUser_ReturnsAnEmptyList() throws Exception {
    MockUCCHelperForAlert helper = new MockUCCHelperForAlert("hasRolesButProjectsNotInDetailedDesign");
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupProjectsByProjectStatusForAUser");
    ac.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("0", "//count", xmlDoc);
     assertXpathEvaluatesTo("", "//projectId", xmlDoc);
  }

  public void testlookupProjectsForAUser_ReturnsAnEmptyList() throws Exception {
    MockUCCHelperForAlert helper = new MockUCCHelperForAlert(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupProjectsByProjectStatusForAUser");
    ac.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("0", "//count", xmlDoc);
  }

  public void testLookupAllRefDataForProjectAndEquipmentXML_XMLReturnedIsWellFormed() throws Exception {
    MockUCCHelperForAlert helper = new MockUCCHelperForAlert("hasRoles");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "2");
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupAllRefDataForProjectAndEquipmentXML");
    ac.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
    assertXpathExists("//editAccess", xmlDoc);
    assertXpathExists("//processRole", xmlDoc);
    assertXpathExists("//mechanicalEngineerRole", xmlDoc);
    assertXpathExists("//areaSelected", xmlDoc);
    assertXpathExists("//unitMeasureId", xmlDoc);
    assertXpathExists("//areas", xmlDoc);
    assertXpathEvaluatesTo("12", "//areas/area/id[1]", xmlDoc);
    assertXpathEvaluatesTo("code 2 - desc 2", "//areas/area/areaCodeDescription[1]", xmlDoc);
    assertXpathEvaluatesTo("true", "//editAccess", xmlDoc);
    assertXpathEvaluatesTo("false", "//processRole", xmlDoc);
    assertXpathEvaluatesTo("false", "//mechanicalEngineerRole", xmlDoc);
    assertXpathEvaluatesTo("1", "//areaSelected", xmlDoc);
    assertXpathEvaluatesTo("1", "//unitMeasureId", xmlDoc);
  }

  public void testLookupAllRefDataForEquipmentXML_XMLReturnedIsWellFormed() throws Exception {
      MockUCCHelperForAlert helper = new MockUCCHelperForAlert("hasRoles");
      ac.run(helper);
      List<EquipmentType> equipmentTypes = (List<EquipmentType>) helper.getRequestAttributeValue(EISConstants.EQUIPMENT_TYPES);
      assertEquals(2, equipmentTypes.size());
      List<FieldEquipmentType> fieldEquipTypes = (List<FieldEquipmentType>)helper.getRequestAttributeValue(EISConstants.FIELD_EQUIPMENT_TYPES);
      assertEquals(3, fieldEquipTypes.size());
      List<GasType> gasTypes = (List<GasType>)helper.getRequestAttributeValue(EISConstants.GAS_TYPES);
      assertEquals(2, gasTypes.size());
    List<WaterType> waterTypes = (List<WaterType>)helper.getRequestAttributeValue(EISConstants.WATER_TYPES);
    assertEquals(2, waterTypes.size());
    List<DustType> dustTypes = (List<DustType>)helper.getRequestAttributeValue(EISConstants.DUST_TYPES);
    assertEquals(2, dustTypes.size());
List<ElectricalInput> inputTypes = (List<ElectricalInput>)helper.getRequestAttributeValue(ElectricalConstants.ELECTRICAL_INPUTS);
    assertEquals(2, inputTypes.size());
    List<ElectricalOutput> outputTypes = (List<ElectricalOutput>)helper.getRequestAttributeValue(ElectricalConstants.ELECTRICAL_OUTPUTS);
    assertEquals(2, outputTypes.size());
    List<OtherMeasurement> otherMeasurements = (List<OtherMeasurement>)helper.getRequestAttributeValue(ElectricalConstants.OTHER_MEASUREMENTS);
    assertEquals(4, otherMeasurements.size());
    List<FundingSource> fundingSources = (List<FundingSource>)helper.getRequestAttributeValue(EISConstants.FUNDING_SOURCES);
    assertEquals(2, fundingSources.size());
    List<PurchaseScope> purchaseScopes = (List<PurchaseScope>)helper.getRequestAttributeValue(EISConstants.PURCHASE_SCOPES);
    assertEquals(1, purchaseScopes.size());
    assertTrue(helper.wasSentTo("/WEB-INF/jsp/home.jspx"));
    
    }

  public List getGetListWithDataInCorrectSortOrder() {
      Object[] result = new Object[20];
        List<Object[]> changeHistoryList = new ArrayList<Object[]>();
        result[0] = new Long("1");
        result[1] = "description";
        result[2] = "22";
        result[3] = "33";
        result[4] = new Date();
        result[5] = "RRMALL";
        result[6] =  new Long("4");
        result[7] = "EIS_EQUIPMENT";
        result[8] = null;
        result[9] = null;
        result[10] = "SSCLIN";
        result[11] = "description";
        changeHistoryList.add(result);
        result = new Object[20];
        result[0] = new Long("2");
        result[1] = "comments";
        result[2] = "equipment works";
        result[3] = "equipment works fine";
        result[4] = new Date();
        result[5] = "RRMALL";
        result[6] =  new Long("4");
        result[7] = "EIS_EQUIPMENT";
        result[8] = null;
        result[9] = null;
        result[10] = null;
        result[11] = "comments";
        changeHistoryList.add(result);
    return changeHistoryList;
  }

  public User getUser(boolean setRoles){
    User user = new User(new Long(123), "RRMALL", "testFirst1", "testLast1", null, null);
    if (setRoles){
      Projects project = new Projects();
      project.setId(new Long(1));
      project.setProjNumber("111");
      project.setProjName("Test Project");
      project.setProjStatus(new ProjectStatus(null, EISConstants.PROJECT_STATUS_DETAILED_DESIGN));
      List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
      projUserRoles.add(new ProjectUserRole(project, user, new ProjectRole(null, EISConstants.ELECTRICAL_ENGINEER, null), false));
      projUserRoles.add(new ProjectUserRole(project, user, new ProjectRole(null, EISConstants.MECHANICAL_DESIGNER, null), false));
      projUserRoles.add(new ProjectUserRole(project, user, new ProjectRole(null, EISConstants.PROCESS_ENGINEER, null), false));
      user.setProjUserRoles(projUserRoles);
    }
    return user;
  }
}