/*
 AlertDataSource_UT was created on Feb 5, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.controller.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.alert.datasource.AlertDataSource;
import com.monsanto.eas.eis.alert.domain.Alert;
import com.monsanto.eas.eis.alert.mock.MockProjectsDAOImplForAlert;
import com.monsanto.eas.eis.alert.mock.MockUCCHelperForAlert;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateSessionForReports;
import com.monsanto.eas.eis.audit.dao.mock.MockSqlQueryForReports;
import com.monsanto.eas.eis.audit.service.MockAuditServiceImpl;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.mocks.MockProjectServiceImpl;
import com.monsanto.eas.eis.util.EISConstants;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: AlertDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 15:31:30 $
 *
 * @author rrmall
 * @version $Revision: 1.4 $
 */
public class AlertDataSource_UT extends TestCase {
  private List dataSet = new ArrayList();

    public void testGetTotalRecords_CalledBeforeGetData_ReturnUnknownRecordCount() throws Exception {
   MockUCCHelper helper = new MockUCCHelperForAlert("hasRoles");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockAuditServiceImpl auditService = new MockAuditServiceImpl();
    setReturnDataSetForProject();
    MockHibernateSessionForReports hibernateSessionForReports = new MockHibernateSessionForReports(dataSet);
    ProjectsService projectService = new MockProjectServiceImpl(hibernateSessionForReports);
    MockProjectsDAOImplForAlert mockProjectDao = new MockProjectsDAOImplForAlert(hibernateSessionForReports, true);
    AlertDataSource dataSource = new AlertDataSource(helper, mockProjectDao, projectService, auditService);
    assertEquals(DataSource.UNKNOWN_RECORD_COUNT, dataSource.getTotalRecords());
  }

   public void testGetData_ProjectInDetailedDesignState_ChangesListReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelperForAlert("hasRoles");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockAuditServiceImpl auditService = new MockAuditServiceImpl();
    setReturnDataSetForProject();
    MockHibernateSessionForReports hibernateSessionForReports = new MockHibernateSessionForReports(dataSet);
    ProjectsService projectService = new MockProjectServiceImpl(hibernateSessionForReports);
    MockProjectsDAOImplForAlert mockProjectDao = new MockProjectsDAOImplForAlert(hibernateSessionForReports, true);
    AlertDataSource dataSource = new AlertDataSource(helper, mockProjectDao, projectService, auditService);
    List<? extends XmlObject> data = dataSource.getData("equipmentNumber", "desc", 0, 25);
    assertEquals(2, data.size());
    assertEquals(2, dataSource.getTotalRecords());
    Alert alert = (Alert)data.get(0);
    assertEquals(new Integer(11), alert.getEquipmentId());
    assertEquals("Equipment Name 1", alert.getEquipmentName());
    assertEquals("Equipment Number 1", alert.getEquipmentNumber());
    assertEquals(new Integer(1), alert.getProcessNotVerified());
    assertEquals(new Integer(2), alert.getMechanicalNotVerified());
    assertEquals(new Integer(3), alert.getElectricalNotVerified());
    assertEquals(new Integer(2), alert.getProjectId());
    alert = (Alert)data.get(1);
    assertEquals(new Integer(22), alert.getEquipmentId());
    assertEquals("Equipment Name 2", alert.getEquipmentName());
    assertEquals("Equipment Number 2", alert.getEquipmentNumber());
    assertEquals(new Integer(21), alert.getProcessNotVerified());
    assertEquals(new Integer(22), alert.getMechanicalNotVerified());
    assertEquals(new Integer(23), alert.getElectricalNotVerified());
    assertEquals(new Integer(2), alert.getProjectId());
    MockSqlQueryForReports sqlQuery = (MockSqlQueryForReports)hibernateSessionForReports.getSqlQueryForReports();
    assertEquals("select * from (select row_.*, rownum rownum_  from ( select tranApprovalPerEquipment.processNotVerified, tranApprovalPerEquipment.mechanicalNotVerified, tranApprovalPerEquipment.electricalNotVerified, equip.id as id, equip.name as name, equip.equipment_number as equipmentNumber, p.id as projectId from eis.eis_projects p inner join eis.eis_equipment equip on equip.projects_id = p.id  inner join (select approvalCount.* from ( select sum(decode(ata.process, null, 1, 0)) as processNotVerified, sum(decode(ata.mechanical,null, 1, 0)) as mechanicalNotVerified, sum(decode(ata.electrical,null, 1, 0))  as electricalNotVerified, e.id as id from eis.eis_equipment e,  eis.audit_transaction_approval ata  where ata.change_datetime IN ( SELECT MAX(tranapproval.change_datetime) FROM eis.audit_transaction_approval tranapproval,eis.eis_equipment e1  WHERE tranapproval.equipment_id = e1.id\n" +
        "AND e1.id = e.id  GROUP BY tranapproval.column_name ) and e.projects_id = 1  and nvl(e.is_deleted, 'N') <> 'Y' group by e.id) approvalCount where (approvalCount.processNotVerified > 0 or approvalCount.mechanicalNotVerified > 0 or approvalCount.electricalNotVerified > 0))tranApprovalPerEquipment on tranApprovalPerEquipment.id = equip.id  where p.id = 1 order by equipmentNumber desc) row_ where rownum <=25) where rownum_ > 0", sqlQuery.getSqlQueryStringForReports());
  }

   public void testGetData_ProjectNotInDetailedDesignState_ChangesListReturnedIsEmpty() throws Exception {
    MockUCCHelper helper = new MockUCCHelperForAlert("hasRoles");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockAuditServiceImpl auditService = new MockAuditServiceImpl();
    MockHibernateSessionForReports hibernateSessionForReports = new MockHibernateSessionForReports(new ArrayList());
    ProjectsService projectService = new MockProjectServiceImpl(hibernateSessionForReports);
    MockProjectsDAOImplForAlert mockProjectDao = new MockProjectsDAOImplForAlert(hibernateSessionForReports, true);
    AlertDataSource dataSource = new AlertDataSource(helper, mockProjectDao, projectService, auditService);
    List<? extends XmlObject> data = dataSource.getData("equipmentNumber", "desc", 0, 25);
    assertEquals(0, data.size());
    MockSqlQueryForReports sqlQuery = (MockSqlQueryForReports)hibernateSessionForReports.getSqlQueryForReports();
    assertEquals("select * from (select row_.*, rownum rownum_  from ( select tranApprovalPerEquipment.processNotVerified, tranApprovalPerEquipment.mechanicalNotVerified, tranApprovalPerEquipment.electricalNotVerified, equip.id as id, equip.name as name, equip.equipment_number as equipmentNumber, p.id as projectId from eis.eis_projects p inner join eis.eis_equipment equip on equip.projects_id = p.id  inner join (select approvalCount.* from ( select sum(decode(ata.process, null, 1, 0)) as processNotVerified, sum(decode(ata.mechanical,null, 1, 0)) as mechanicalNotVerified, sum(decode(ata.electrical,null, 1, 0))  as electricalNotVerified, e.id as id from eis.eis_equipment e,  eis.audit_transaction_approval ata  where ata.change_datetime IN ( SELECT MAX(tranapproval.change_datetime) FROM eis.audit_transaction_approval tranapproval,eis.eis_equipment e1  WHERE tranapproval.equipment_id = e1.id\n" +
        "AND e1.id = e.id  GROUP BY tranapproval.column_name ) and e.projects_id = 1  and nvl(e.is_deleted, 'N') <> 'Y' group by e.id) approvalCount where (approvalCount.processNotVerified > 0 or approvalCount.mechanicalNotVerified > 0 or approvalCount.electricalNotVerified > 0))tranApprovalPerEquipment on tranApprovalPerEquipment.id = equip.id  where p.id = 1 order by equipmentNumber desc) row_ where rownum <=25) where rownum_ > 0", sqlQuery.getSqlQueryStringForReports());
  }

  private void setReturnDataSetForProject(){
    Object[] result = new Object[10];
        result[0] = new Integer(1);
        result[1] = new Integer(2);
        result[2] = new Integer(3);
        result[3] = new Integer(11);
        result[4] = "Equipment Name 1";
        result[5] = "Equipment Number 1";
        result[6] = new Integer(2);

        dataSet.add(result);
        result = new Object[10];
         result[0] = new Integer(21);
        result[1] = new Integer(22);
        result[2] = new Integer(23);
        result[3] = new Integer(22);
        result[4] = "Equipment Name 2";
        result[5] = "Equipment Number 2";
        result[6] = new Integer(2);

        dataSet.add(result);
  }
}