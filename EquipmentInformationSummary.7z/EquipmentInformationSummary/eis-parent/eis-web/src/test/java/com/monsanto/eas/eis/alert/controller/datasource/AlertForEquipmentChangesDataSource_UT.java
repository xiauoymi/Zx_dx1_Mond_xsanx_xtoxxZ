/*
 AlertForEquipmentChangesDataSource_UT was created on Feb 12, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.controller.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.alert.domain.AlertForEquipment;
import com.monsanto.eas.eis.alert.mock.MockProjectsDAOImplForEquipmentAddDeleteAlert;
import com.monsanto.eas.eis.alert.mock.MockUCCHelperForAlert;
import com.monsanto.eas.eis.alert.datasource.AlertForEquipmentChangesDataSource;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateSessionForReports;
import com.monsanto.eas.eis.audit.dao.mock.MockSqlQueryForReports;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.eas.eis.equipment.datasource.search.EquipmentSearchDataSource;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.projects.dao.ProjectsDAO;
import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.mocks.MockEquipmentDAO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: AlertForEquipmentChangesDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-03-04 22:17:23 $
 *
 * @author rrmall
 * @version $Revision: 1.7 $
 */
public class AlertForEquipmentChangesDataSource_UT extends EISTestCase {
   private List dataSet = new ArrayList();

   public void testGetTotalRecords_CalledBeforeGetData_ReturnUnknownRecordCount() throws Exception {
     MockUCCHelper helper = new MockUCCHelperForAlert("hasRoles");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockHibernateSessionForReports hibernateSessionForReports = new MockHibernateSessionForReports(setReturnDataSetForProject());
    MockProjectsDAOImplForEquipmentAddDeleteAlert mockProjectDao = new MockProjectsDAOImplForEquipmentAddDeleteAlert(hibernateSessionForReports, true);
    AlertForEquipmentChangesDataSource dataSource = new AlertForEquipmentChangesDataSource(helper, mockProjectDao);
    assertEquals(DataSource.UNKNOWN_RECORD_COUNT, dataSource.getTotalRecords());
  }

  public void testGetTotalRecordsForEquipmentChanges() throws Exception {
     MockUCCHelper helper = new MockUCCHelperForAlert("hasRoles");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockHibernateSessionForReports hibernateSessionForReports = new MockHibernateSessionForReports(setReturnDataSetForProject());
    MockProjectsDAOImplForEquipmentAddDeleteAlert mockProjectDao = new MockProjectsDAOImplForEquipmentAddDeleteAlert(hibernateSessionForReports, true);
    AlertForEquipmentChangesDataSource dataSource = new AlertForEquipmentChangesDataSource(helper, mockProjectDao);
    List<? extends XmlObject> data = dataSource.getData("equipmentNumber", "desc", 0, 25);
    assertEquals(2, dataSource.getTotalRecords());
  }

  public void testGetDataForEquipmentsAddedAndDeletedFromAProject_ProjectInDetailedDesignState_ChangesListReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelperForAlert("hasRoles");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockHibernateSessionForReports hibernateSessionForReports = new MockHibernateSessionForReports(setReturnDataSetForProject());
    MockProjectsDAOImplForEquipmentAddDeleteAlert mockProjectDao = new MockProjectsDAOImplForEquipmentAddDeleteAlert(hibernateSessionForReports, true);
    AlertForEquipmentChangesDataSource dataSource = new AlertForEquipmentChangesDataSource(helper, mockProjectDao);
    List<? extends XmlObject> data = dataSource.getData("equipmentNumber", "desc", 0, 25);
    assertEquals(2, data.size());
    AlertForEquipment alert = (AlertForEquipment)data.get(0);
    assertEquals(new Integer(1), alert.getId());
    assertEquals("11.11", alert.getEquipmentNumber());
//    assertEquals(new Date(), alert.getDateModified());
    assertEquals("I", alert.getAddedOrDeleted());
    assertEquals("I Am TestUser1", alert.getModifiedBy());
    assertEquals(new Integer(2), alert.getProjectId());

    alert = (AlertForEquipment)data.get(1);
    assertEquals(new Integer(2), alert.getId());
    assertEquals("22.22", alert.getEquipmentNumber());
//    assertEquals(new Date(), alert.getDateModified());
    assertEquals("D", alert.getAddedOrDeleted());
    assertEquals("I Am TestUser2", alert.getModifiedBy());
    assertEquals(new Integer(3), alert.getProjectId());

    MockSqlQueryForReports sqlQuery = (MockSqlQueryForReports)hibernateSessionForReports.getSqlQueryForReports();
    assertEquals("select * from (select row_.*, rownum rownum_  from ( select equipment.id as id, equipment.equipment_number as equipmentNumber,   h.change_datetime dateModified, h.operation_type addedOrDeleted,   t.audit_requestor modifiedBy,    equipment.projects_id projectId    from eis.audit_header_view_ins_del h,       eis.eis_equipment equipment,       eis.audit_transaction t,       eis.eis_user u   where h.key_value = to_char(equipment.id)   and h.table_name = 'EIS_EQUIPMENT'   and h.operation_type in ('I', 'D')   and h.change_datetime between (systimestamp - 20) and systimestamp    and h.change_datetime >= (select max(h1.change_datetime) from eis.audit_header h1  left outer join eis.audit_detail d1 on d1.audit_header_id = h1.audit_header_id where key_value = '1' and d1.column_name = 'STATUS_ID' and d1.new_value = (select id from eis.eis_proj_status where status_name = 'Detailed Design'))  and t.audit_transaction_id = h.audit_transaction_id    and t.audit_requestor = u.user_id   and equipment.id in (select id from eis.eis_equipment eq where eq.projects_id  = 1) order by equipmentNumber desc) row_ where rownum <=25) where rownum_ > 0", sqlQuery.getSqlQueryStringForReports());

  }

  private List setReturnDataSetForProject(){
    Object[] result = new Object[10];
        result[0] = new Integer(1);
        result[1] = new String("11.11");
        result[2] = new Date();
        result[3] = new String("I");
        result[4] = "I Am TestUser1";
        result[5] = new Integer(2);
        dataSet.add(result);
        result = new Object[10];
       result[0] = new Integer(2);
        result[1] = new String("22.22");
        result[2] = new Date();
        result[3] = new String("D");
        result[4] = "I Am TestUser2";
        result[5] = new Integer(3);
        dataSet.add(result);
    return dataSet;
  }

//  public void testAlertForEquipmentChanges() throws Exception {
//    MockUCCHelper helper = new MockUCCHelperForAlert("hasRoles");
//    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "231902");
//    AlertForEquipmentChangesDataSource dataSource = new AlertForEquipmentChangesDataSource(helper, new ProjectsDAOImpl());
//    dataSource.getData("equipmentNumber", "asc", 0, 25);
//  }
//
//  public void testAlertForEquipmentChangesfjksfnklsdnflsdf() throws Exception {
//    MockUCCHelper helper = new MockUCCHelperForAlert("hasRoles");
//    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "11051");
//    AlertForEquipmentChangesDataSource dataSource = new AlertForEquipmentChangesDataSource(helper, new ProjectsDAOImpl());
//    List<? extends XmlObject> data = dataSource.getData("equipmentNumber", "asc", 0, 25);
//    assertTrue(data.size()> 0);
//  }

}