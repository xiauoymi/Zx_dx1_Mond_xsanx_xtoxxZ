/*
 AlertForProjectStatusAndRoleChangesDataSource_UT was created on Aug 5, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.controller.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.alert.datasource.AlertForProjectStatusAndRoleChangesDataSource;
import com.monsanto.eas.eis.alert.domain.AlertForProjectRoleAndStatus;
import com.monsanto.eas.eis.alert.mock.MockProjectsDAOImplForEquipmentAddDeleteAlert;
import com.monsanto.eas.eis.alert.mock.MockUCCHelperForAlert;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateSessionForReports;
import com.monsanto.eas.eis.audit.dao.mock.MockSqlQueryForReports;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.EISConstants;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class AlertForProjectStatusAndRoleChangesDataSource_UT extends TestCase {
  private List dataSet = new ArrayList();

  public void testGetTotalRecords_CalledBeforeGetData_ReturnUnknownRecordCount() throws Exception {
    MockUCCHelper helper = new MockUCCHelperForAlert("hasRoles");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockHibernateSessionForReports hibernateSessionForReports = new MockHibernateSessionForReports(
        setReturnDataSetForProject());
    MockProjectsDAOImplForEquipmentAddDeleteAlert mockProjectDao = new MockProjectsDAOImplForEquipmentAddDeleteAlert(
        hibernateSessionForReports, true);
    AlertForProjectStatusAndRoleChangesDataSource dataSource = new AlertForProjectStatusAndRoleChangesDataSource(helper, mockProjectDao);
    assertEquals(DataSource.UNKNOWN_RECORD_COUNT, dataSource.getTotalRecords());
  }

  public void testGetTotalRecordsForProjectStatusAndRoleChanges() throws Exception {
    MockUCCHelper helper = new MockUCCHelperForAlert("hasRoles");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockHibernateSessionForReports hibernateSessionForReports = new MockHibernateSessionForReports(
        setReturnDataSetForProject());
    MockProjectsDAOImplForEquipmentAddDeleteAlert mockProjectDao = new MockProjectsDAOImplForEquipmentAddDeleteAlert(
        hibernateSessionForReports, true);
    AlertForProjectStatusAndRoleChangesDataSource dataSource = new AlertForProjectStatusAndRoleChangesDataSource(helper, mockProjectDao);
    List<? extends XmlObject> data = dataSource.getData("equipmentNumber", "desc", 0, 25);
    assertEquals(1, dataSource.getTotalRecords());
  }

  public void testGetDataForProjectStatusAndRoleChanges_ProjectInDetailedDesignState_ChangesListReturned() throws
      Exception {
    MockUCCHelper helper = new MockUCCHelperForAlert("hasRoles");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockHibernateSessionForReports hibernateSessionForReports = new MockHibernateSessionForReports(
        setReturnDataSetForProject());
    MockProjectsDAOImplForEquipmentAddDeleteAlert mockProjectDao = new MockProjectsDAOImplForEquipmentAddDeleteAlert(
        hibernateSessionForReports, true);
    AlertForProjectStatusAndRoleChangesDataSource dataSource = new AlertForProjectStatusAndRoleChangesDataSource(helper, mockProjectDao);
    List<? extends XmlObject> data = dataSource.getData("equipmentNumber", "desc", 0, 25);
    assertEquals(1, data.size());
    assertEquals(1, dataSource.getTotalRecords());
    AlertForProjectRoleAndStatus alert = (AlertForProjectRoleAndStatus) data.get(0);
    assertEquals(new Integer(1), alert.getId());
    assertEquals("1.1.11", alert.getProjectNumber());
    assertEquals(new Date(), alert.getDateModified());
    assertEquals("EIS_PROJECTS", alert.getTableName());
    assertEquals("Test User", alert.getModifiedBy());

    MockSqlQueryForReports sqlQuery = (MockSqlQueryForReports) hibernateSessionForReports.getSqlQueryForReports();
    assertEquals(
        "SELECT modifiedby, change_datetime AS changeDateTime, psv.TABLE_NAME AS tablename, p.proj_number projectnumber, p.id id FROM eis.audit_proj_status_view psv, eis.eis_projects p WHERE psv.TABLE_NAME = 'EIS_PROJECTS' AND psv.key_value IN('1','null','null','null') AND psv.key_value = to_char(p.id) UNION select t.audit_requestor modifiedBy, innerQuery.* from  ( select max(change_datetime) AS changeDateTime, psv.TABLE_NAME AS tablename, p.proj_number projectnumber, p.id as id FROM eis.AUD_PROJ_STAT_ROLE_CHG_VIEW psv,         eis.eis_proj_user_role pur, eis.eis_projects p WHERE psv.TABLE_NAME = 'EIS_PROJ_USER_ROLE' AND psv.key_value IN('1','null','null','null') AND psv.key_value = to_char(pur.id)        AND pur.project_id = p.id group by p.id, psv.TABLE_NAME, p.proj_number, p.id        )innerQuery left outer join eis.audit_header h on h.change_datetime = innerQuery.changeDateTime left outer join eis.audit_transaction t on t.audit_transaction_id = h.audit_transaction_id order by equipmentNumber desc",
        sqlQuery.getSqlQueryStringForReports());

  }

  private List setReturnDataSetForProject() {
    Object[] result = new Object[10];

    result[0] = new String("Test User");
    result[1] = new Date();
    result[2] = new String("EIS_PROJECTS");
    result[3] = new String("1.1.11");
    result[4] = new Integer(1);
    dataSet.add(result);
    return dataSet;
  }
}