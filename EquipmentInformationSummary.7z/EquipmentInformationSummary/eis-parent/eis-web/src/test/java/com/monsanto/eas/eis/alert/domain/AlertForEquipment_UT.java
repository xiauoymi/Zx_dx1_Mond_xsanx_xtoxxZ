/*
 AlertForEquipment_UT was created on Feb 12, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.domain;

import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import com.monsanto.XMLUtil.DOMUtil;

import java.util.Date;

/**
 * Filename:    $RCSfile: AlertForEquipment_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-18 19:19:35 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class AlertForEquipment_UT extends XMLTestCase {
  public void testAlertForEquipment_ReturnsNewObject() throws Exception {
    AlertForEquipment alert = new AlertForEquipment();
    assertNotNull(alert);
  }
  
  public void testToXml_VerifyXml() throws Exception {
    AlertForEquipment alert = createAnAlert();
    Document xmlDoc = DOMUtil.stringToXML(alert.toXml());
    assertXpathEvaluatesTo("1", "//alertForEquipmentAddDelete/id", xmlDoc);
    assertXpathEvaluatesTo("11.11", "//alertForEquipmentAddDelete/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("I", "//alertForEquipmentAddDelete/addedOrDeleted", xmlDoc);
    assertXpathEvaluatesTo("Test User", "//alertForEquipmentAddDelete/modifiedBy", xmlDoc);
    assertXpathEvaluatesTo("2", "//alertForEquipmentAddDelete/projectId", xmlDoc);
  }

  private AlertForEquipment createAnAlert() {
    return new AlertForEquipment(new Integer(1), "11.11", new Date(), "I", "Test User", new Integer(2));
  }
}