/*
 AlertForProjectRoleAndStatus_UT was created on Feb 17, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.domain;

import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import com.monsanto.XMLUtil.DOMUtil;

import java.util.Date;

/**
 * Filename:    $RCSfile: AlertForProjectRoleAndStatus_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-24 18:49:44 $
 *
 * @author rrmall
 * @version $Revision: 1.3 $
 */
public class AlertForProjectRoleAndStatus_UT extends XMLTestCase {
  public void testAlertForProjectRoleAndStatus_ReturnsNewObject() throws Exception {
    AlertForProjectRoleAndStatus alert = new AlertForProjectRoleAndStatus();
    assertNotNull(alert);
  }

  public void testToXml_StatusChange_VerifyXml() throws Exception {
    AlertForProjectRoleAndStatus alert = createAnAlert();
    Document xmlDoc = DOMUtil.stringToXML(alert.toXml());
    assertXpathEvaluatesTo("1", "//alertForProjectRoleStatus/id", xmlDoc);
    assertXpathEvaluatesTo("1.1.11", "//alertForProjectRoleStatus/projectNumber", xmlDoc);
    assertXpathEvaluatesTo("Project Status changed", "//alertForProjectRoleStatus/description", xmlDoc);
    assertXpathEvaluatesTo("Test User", "//alertForProjectRoleStatus/modifiedBy", xmlDoc);
  }

  public void testToXml_ProjectRoleChange_VerifyXml() throws Exception {
    AlertForProjectRoleAndStatus alert = createAnAlertForRoleChange();
    Document xmlDoc = DOMUtil.stringToXML(alert.toXml());
    assertXpathEvaluatesTo("1", "//alertForProjectRoleStatus/id", xmlDoc);
    assertXpathEvaluatesTo("1.1.11", "//alertForProjectRoleStatus/projectNumber", xmlDoc);
    assertXpathEvaluatesTo("Project role(s) changed", "//alertForProjectRoleStatus/description", xmlDoc);
    assertXpathEvaluatesTo("Test User", "//alertForProjectRoleStatus/modifiedBy", xmlDoc);
  }

  private AlertForProjectRoleAndStatus createAnAlert() {
    return new AlertForProjectRoleAndStatus(new Integer(1), "1.1.11", "EIS_PROJECTS", new Date(), "Test User");
  }

  private AlertForProjectRoleAndStatus createAnAlertForRoleChange() {
    return new AlertForProjectRoleAndStatus(new Integer(1), "1.1.11", "EIS_PROJ_USER_ROLE", new Date(), "Test User");
  }
}
