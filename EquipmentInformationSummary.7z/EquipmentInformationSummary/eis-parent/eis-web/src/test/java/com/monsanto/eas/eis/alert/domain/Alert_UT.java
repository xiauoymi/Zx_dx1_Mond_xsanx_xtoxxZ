/*
 Alert_UT was created on Feb 6, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.domain;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.eis.util.EISConstants;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: Alert_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-19 21:12:10 $
 *
 * @author rrmall
 * @version $Revision: 1.4 $
 */
public class Alert_UT extends XMLTestCase {
  public void testAlert_ReturnsNewObject() throws Exception {
    Alert alert = new Alert();
    assertNotNull(alert);
  }
  public void testToXml_VerifyXml() throws Exception {
    Alert alert = createAnAlert();
    Document xmlDoc = DOMUtil.stringToXML(alert.toXml());
    assertXpathEvaluatesTo("1", "//alert/id", xmlDoc);
    assertXpathEvaluatesTo("11.11", "//alert/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Test Equipment", "//alert/equipmentName", xmlDoc);
    assertXpathEvaluatesTo("10", "//alert/processNotVerified", xmlDoc);
    assertXpathEvaluatesTo("11", "//alert/mechanicalNotVerified", xmlDoc);
    assertXpathEvaluatesTo("12", "//alert/electricalNotVerified", xmlDoc);
    assertXpathEvaluatesTo("2", "//alert/projectId", xmlDoc);
  }

  private Alert createAnAlert() {
    return new Alert(new Integer(1), "11.11", "Test Equipment", new Integer(10), new Integer(11),
        new Integer(12), new Integer(2));
  }
//
//  public void testCreatetest() throws Exception {
//      String s = EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", "mcas", "CipherValue.hex", "KeyValue.hex");
//      System.out.println("s = " + s);
//
//  }


}