/*
 MockCriteriaForAlert was created on Feb 10, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.mock;

import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;

/**
 * Filename:    $RCSfile: MockCriteriaForAlert.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 15:41:21 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class MockCriteriaForAlert extends MockCriteria {
      private FetchMode fetchmode;
      private boolean userHasProjectsInDesignStateAndIsInOneOfTheRequiredRoles;

  public MockCriteriaForAlert(boolean userHasProjectsInDesignStateAndIsInOneOfTheRequiredRoles) {
    this.userHasProjectsInDesignStateAndIsInOneOfTheRequiredRoles = userHasProjectsInDesignStateAndIsInOneOfTheRequiredRoles;
  }

  public List list() throws HibernateException {
    if (userHasProjectsInDesignStateAndIsInOneOfTheRequiredRoles){
        List<Projects> projectList = new ArrayList<Projects>();
        Projects project = new Projects("1", "Project Test 1", new Date(), new Date(),
            new ProjectStatus(new Long(2), "Detailed Design"), null, null, null, null, null, null, "RRMALL",
            new Date());
        project.setId(new Long(1));
        projectList.add(project);
        project = new Projects("2", "Project Test 2", new Date(), new Date(),
            new ProjectStatus(new Long(2), "Detailed Design"), null, null, null, null, null, null, "RRMALL", new Date());
        project.setId(new Long(2));
        projectList.add(project);
        return projectList;
      }else{
      return new ArrayList<Projects>();
    }
  }

  public Criteria add(Criterion criterion) {
    return super.add(criterion);
  }

  public Criteria setFetchMode(String s, FetchMode fetchMode) throws HibernateException {
        this.fetchmode = fetchMode;
        return super.setFetchMode(s, fetchMode);
      }

      public FetchMode getFetchmode() {
        return fetchmode;
      }

      public boolean wasListCalled() {
        return true;
      }
    }