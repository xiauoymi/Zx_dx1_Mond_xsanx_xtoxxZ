/*
 MockCriteriaForAlert was created on Feb 5, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.mock;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Criterion;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.eas.eis.logon.hibernateMappings.Role;
import com.monsanto.eas.eis.logon.hibernateMappings.User;

import java.util.List;
import java.util.Set;
import java.util.HashSet;

/**
 * Filename:    $RCSfile: MockCriteriaForAlertToGetUser.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 15:41:21 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class MockCriteriaForAlertToGetUser extends MockCriteria {
  private boolean wasUniqueResultCalled = false;

  public Object uniqueResult() throws HibernateException {
    Set<Role> roles = new HashSet<Role>();
    roles.add(new Role(new Long(1), null));
    roles.add(new Role(new Long(2), null));
    wasUniqueResultCalled = true;
    return new User(new Long(123), null, "testFirst1", "testLast1", null, null);
  }

  public Criteria add(Criterion criterion) {
    return super.add(criterion);
  }

  public boolean getWasUniqueResultCalled() {
    return wasUniqueResultCalled;
  }
}