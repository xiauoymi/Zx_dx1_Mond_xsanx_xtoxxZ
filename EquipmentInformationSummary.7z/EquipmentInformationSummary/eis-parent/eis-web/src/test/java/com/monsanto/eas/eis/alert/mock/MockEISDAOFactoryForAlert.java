/*
 MockEISDAOFactoryForAlert was created on Feb 10, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.mock;

import com.monsanto.eas.eis.projects.EISDAOFactoryImpl;
import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.mocks.*;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateSessionForReports;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import com.monsanto.wst.hibernate.mock.MockHibernateFactory;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Criterion;

import java.util.List;

/**
 * Filename:    $RCSfile: MockEISDAOFactoryForAlert.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 15:41:21 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class MockEISDAOFactoryForAlert extends EISDAOFactoryImpl {
  public MockEISDAOFactoryForAlert(MockHibernateSessionForReports session, boolean doesUserMatchCriteria) {
    super(new MockHibernateFactory(),
        new MockProjectsDAOImplForAlert(session, doesUserMatchCriteria),
        new MockProjectStatusDAOImpl(session),
        new MockUnitMeasureDAOImpl(session),
        new MockLocationDAOImpl(session),
        new MockCropDAOImpl(session),
        new MockAreaDAOImpl(session),
        new MockEquipmentTypeDAOImpl(session),
        new MockEquipmentDAO(new Equipment()));
  }
}