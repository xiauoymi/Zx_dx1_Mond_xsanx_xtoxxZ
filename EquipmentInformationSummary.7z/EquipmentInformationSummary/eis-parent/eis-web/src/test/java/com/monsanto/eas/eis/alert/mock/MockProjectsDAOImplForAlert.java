/*
 MockProjectsDaoImplForAlert was created on Feb 10, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.mock;

import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateFactoryForReports;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateSessionForReports;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.HibernateFactory;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.FetchMode;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;

/**
 * Filename:    $RCSfile: MockProjectsDAOImplForAlert.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 15:41:21 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
  public class MockProjectsDAOImplForAlert extends ProjectsDAOImpl {
  private MockHibernateSessionForReports session;
  private boolean doesUserMatchCriteria;

  public MockProjectsDAOImplForAlert(
     MockHibernateSessionForReports session, boolean doesUserMatchCriteria) {
    this.session = session;
    this.doesUserMatchCriteria = doesUserMatchCriteria;
    }

    public Criteria getCriteria() {
      return new MockCriteriaForAlert(doesUserMatchCriteria);
    }

  protected HibernateFactory getHibernate() {
//    setReturnDataSetForProject();
    return new MockHibernateFactoryForReports(session.getDataSet());
  }

//   private void setReturnDataSetForProject(){
//    Object[] result = new Object[10];
//        result[0] = new Integer(1);
//        result[1] = new Integer(2);
//        result[2] = new Integer(3);
//        result[3] = new Integer(11);
//        result[4] = "Equipment Name 1";
//        result[5] = "Equipment Number 1";
//        dataSet.add(result);
//        result = new Object[10];
//         result[0] = new Integer(21);
//        result[1] = new Integer(22);
//        result[2] = new Integer(23);
//        result[3] = new Integer(22);
//        result[4] = "Equipment Name 2";
//        result[5] = "Equipment Number 2";
//        dataSet.add(result);
//  }
}
