/*
 MockProjectsDAOImplForEquipmentAddDeleteAlert was created on Feb 12, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.mock;

import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateSessionForReports;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateFactoryForReports;
import com.monsanto.wst.hibernate.HibernateFactory;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;

import org.hibernate.Criteria;

/**
 * Filename:    $RCSfile: MockProjectsDAOImplForEquipmentAddDeleteAlert.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 15:41:21 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class MockProjectsDAOImplForEquipmentAddDeleteAlert extends ProjectsDAOImpl {
  private MockHibernateSessionForReports session;
  private boolean doesUserMatchCriteria;

  public MockProjectsDAOImplForEquipmentAddDeleteAlert(
     MockHibernateSessionForReports session, boolean doesUserMatchCriteria) {
    this.session = session;
    this.doesUserMatchCriteria = doesUserMatchCriteria;
    }

    public Criteria getCriteria() {
      return new MockCriteriaForAlert(doesUserMatchCriteria);
    }

  public HibernateFactory getHibernate() {
    return new MockHibernateFactoryForReports(session.getDataSet());
  }
}
