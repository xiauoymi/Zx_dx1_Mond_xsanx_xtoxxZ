/*
 MockProjectsDAOImplForProjectStatusAndRoleAlert was created on Feb 16, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.mock;

import com.monsanto.eas.eis.audit.dao.mock.MockHibernateSessionForReports;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateFactoryForReports;
import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.wst.hibernate.HibernateFactory;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;

import org.hibernate.Criteria;

/**
 * Filename:    $RCSfile: MockProjectsDAOImplForProjectStatusAndRoleAlert.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 15:41:21 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class MockProjectsDAOImplForProjectStatusAndRoleAlert extends ProjectsDAOImpl {
  private MockHibernateSessionForReports session;
  private boolean doesUserMatchCriteria;
  private List dataSet = new ArrayList();

  public MockProjectsDAOImplForProjectStatusAndRoleAlert(
     MockHibernateSessionForReports session, boolean doesUserMatchCriteria) {
    this.session = session;
    this.doesUserMatchCriteria = doesUserMatchCriteria;
    }

    public Criteria getCriteria() {
      return new MockCriteriaForAlert(doesUserMatchCriteria);
    }

  public HibernateFactory getHibernate() {
    return new MockHibernateFactoryForReports(session.getDataSet());
  }

   public void setReturnDataSetForProject(List dataSet){
//      Object[] result = new Object[20];
//        result[0] = new Integer("1");
//        result[1] = "1.1.22";
//        result[2] = "STATUS_ID";
//        result[4] = "RRMALL";
//        result[3] = new Date();
//       dataSet.add(result);
//        result = new Object[20];
//        result[0] = new Integer("2");
//        result[1] = "1.1.33";
//        result[2] = "PROJ_ROLE_ID";
//        result[4] = "RRMALL";
//        result[3] = new Date();
//       dataSet.add(result);
  }
}