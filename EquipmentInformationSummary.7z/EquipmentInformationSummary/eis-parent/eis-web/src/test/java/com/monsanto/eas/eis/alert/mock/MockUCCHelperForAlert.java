/*
 MockUCCHelperForAlert was created on Feb 5, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.alert.mock;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.projects.domain.ProjectUserRole;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.ProjectRole;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;

import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockUCCHelperForAlert.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 15:41:21 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class MockUCCHelperForAlert extends MockUCCHelper {
  private  String userHasRoles;
  public MockUCCHelperForAlert(String hasRoles) {
    super(hasRoles);
    userHasRoles = hasRoles;
  }


  public String getAuthenticatedUserID() {
    return "RRMALL";
  }

  public Object getSessionParameter(String s) {
    if ("hasRoles".equalsIgnoreCase(userHasRoles)){
      User user = new User(new Long(123), "RRMALL", "testFirst1", "testLast1", null, null);
      Projects project = new Projects();
      project.setId(new Long(1));
      project.setProjNumber("111");
      project.setProjName("Test Project");
      project.setProjStatus(new ProjectStatus(null, EISConstants.PROJECT_STATUS_DETAILED_DESIGN));
      List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
      projUserRoles.add(new ProjectUserRole(project, user, new ProjectRole(null, EISConstants.ELECTRICAL_ENGINEER, null), false));
      projUserRoles.add(new ProjectUserRole(project, user, new ProjectRole(null, EISConstants.MECHANICAL_DESIGNER, null), false));
      projUserRoles.add(new ProjectUserRole(project, user, new ProjectRole(null, EISConstants.PROCESS_ENGINEER, null), false));
      user.setProjUserRoles(projUserRoles);
      super.setSessionParameter(EISConstants.USER, user);
      return super.getSessionParameter(EISConstants.USER);
    }
    if ("hasRolesButProjectsNotInDetailedDesign".equalsIgnoreCase(userHasRoles)){
      User user = new User(new Long(123), "RRMALL", "testFirst1", "testLast1", null, null);
      Projects project = new Projects();
      project.setId(new Long(1));
      project.setProjNumber("111");
      project.setProjName("Test Project");
      project.setProjStatus(new ProjectStatus(null, "Design"));
      List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
      projUserRoles.add(new ProjectUserRole(project, user, new ProjectRole(null, EISConstants.ELECTRICAL_ENGINEER, null), false));
      projUserRoles.add(new ProjectUserRole(project, user, new ProjectRole(null, EISConstants.MECHANICAL_DESIGNER, null), false));
      projUserRoles.add(new ProjectUserRole(project, user, new ProjectRole(null, EISConstants.PROCESS_ENGINEER, null), false));
      user.setProjUserRoles(projUserRoles);
      super.setSessionParameter(EISConstants.USER, user);
      return super.getSessionParameter(EISConstants.USER);
    }

     if ("hasRolesButProjectsStatusNotACriteria".equalsIgnoreCase(userHasRoles)){
      User user = new User(new Long(123), "RRMALL", "testFirst1", "testLast1", null, null);
      Projects project = new Projects();
      project.setId(new Long(1));
      project.setProjNumber("111");
      project.setProjName("Test Project");
      project.setProjStatus(new ProjectStatus(null, "Design"));
      List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
      projUserRoles.add(new ProjectUserRole(project, user, new ProjectRole(null, EISConstants.ELECTRICAL_ENGINEER, null), false));
      projUserRoles.add(new ProjectUserRole(project, user, new ProjectRole(null, EISConstants.MECHANICAL_DESIGNER, null), false));
      projUserRoles.add(new ProjectUserRole(project, user, new ProjectRole(null, EISConstants.PROCESS_ENGINEER, null), false));
      user.setProjUserRoles(projUserRoles);
      super.setSessionParameter(EISConstants.USER, user);
      return super.getSessionParameter(EISConstants.USER);
    }

      User user = new User(new Long(123), "RRMALL", "testFirst1", "testLast1", null, null);
      List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
      user.setProjUserRoles(projUserRoles);      
      super.setSessionParameter(EISConstants.USER, user);
      return super.getSessionParameter(EISConstants.USER);
  }
}