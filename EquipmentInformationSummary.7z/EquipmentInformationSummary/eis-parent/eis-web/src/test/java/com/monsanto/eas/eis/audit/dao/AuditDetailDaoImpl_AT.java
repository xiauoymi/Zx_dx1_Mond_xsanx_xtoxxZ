/*
 AuditDetailDaoImpl_AT was created on Jan 26, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao;

import com.monsanto.eas.eis.audit.domain.ChangeHistory;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.eas.eis.projects.Projects_AT_TestCaseHelper;
import com.monsanto.eas.eis.projects.services.UserService;
import com.monsanto.eas.eis.projects.services.UserServiceImpl;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.hibernate.HibernateFactory;

/**
 * Filename:    $RCSfile: AuditDetailDaoImpl_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 17:38:24 $
 *
 * @author rrmall
 * @version $Revision: 1.7 $
 */
public class AuditDetailDaoImpl_AT extends EISTestCase {
  private AuditDetailDao dao;

  public void testGetChangeHistoryForProjectInDetailedDesignEquipmentHasChanges_ChangeHistoryDetailsRetrieved() throws Exception {
    HibernateFactory hibernateFactory = EISHibernateUtil.getHibernateFactory();
    dao = new AuditDetailDaoImpl(hibernateFactory);
    Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
    int startIndex = 0;
    int maxResults = 25;
    hibernateFactory.beginTransaction();
    equipment.getProjects().setProjStatus(new ProjectStatus(new Long(2), "Detailed Design"));
    equipment.setEquipmentNumber("Test 1234");
    equipment.setDescription("Test 1234 description");
    hibernateFactory.commitTransaction();

    hibernateFactory.beginTransaction();
    PaginatedResult results = dao.lookupAuditDetailsByCriteria(equipment.getProjects().getId().toString(), equipment,
        "RRMALL", "columnName", "desc", startIndex, maxResults);
    assertNotNull(results);
    assertEquals(2, results.getTotalRecords());
    assertNotNull(results.getData());
    ChangeHistory change = (ChangeHistory) results.getData().get(0);
    assertEquals("00.123.W12", change.getOldValue());
    assertEquals("Test 1234", change.getNewValue());
    assertFalse(change.getIsElectricalVerified());
    assertFalse(change.getIsMechanicalVerified());
    assertFalse(change.getIsProcessVerified());
    change = (ChangeHistory) results.getData().get(1);
    assertEquals("My Equipment Description", change.getOldValue());
    assertEquals("Test 1234 description", change.getNewValue());
    assertNotNull(change.getTabName());
    assertFalse(change.getIsElectricalVerified());
    assertFalse(change.getIsMechanicalVerified());
    assertFalse(change.getIsProcessVerified());
  }

  public void testGetChangeHistoryForProjectNotInDetailedDesignEquipmentHasChanges_ChangeHistoryDetailsRetrievedIsEmpty() throws Exception {
     HibernateFactory hibernateFactory = EISHibernateUtil.getHibernateFactory();
     dao = new AuditDetailDaoImpl(hibernateFactory);
     Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
     int startIndex = 0;
     int maxResults = 25;
     hibernateFactory.beginTransaction();
     equipment.setEquipmentNumber("Test 1234");
     equipment.setDescription("Test 1234 description");
     hibernateFactory.commitTransaction();

     hibernateFactory.beginTransaction();
     PaginatedResult results = dao.lookupAuditDetailsByCriteria(equipment.getProjects().getId().toString(), equipment,
         "RRMALL", "columnName", "desc", startIndex, maxResults);
     assertNotNull(results);
     assertEquals(0, results.getTotalRecords());
     assertEquals(0, results.getData().size());
   }

  public void testdfgjdlkgjdklfjg() throws Exception {
     UserService service = new UserServiceImpl();
    service.lookupUsersByName("scott");
  }
}