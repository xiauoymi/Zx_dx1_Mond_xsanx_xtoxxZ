/*
 AuditDetailDaoImpl_UT was created on Jan 26, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao;

import com.monsanto.eas.eis.audit.dao.mock.*;
import com.monsanto.eas.eis.audit.domain.ChangeHistory;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.sql.Timestamp;

/**
 * Filename:    $RCSfile: AuditDetailDaoImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 15:45:13 $
 *
 * @author rrmall
 * @version $Revision: 1.11 $
 */
public class AuditDetailDaoImpl_UT extends TestCase {
    int startIndex = 0;
    int maxResults = 25;

  public void testSearchDetailEntriesByCriteria_DetailIdIsSetInCriteria_ListReturnedSortOrderIsCorrect() throws Exception {
    MockAuditDetailDao detailDao = new MockAuditDetailDao(new MockHibernateFactoryForReports(getGetListWithDataInCorrectSortOrder()));
    MockEquipmentServiceImplForAudit equipmentService = new MockEquipmentServiceImplForAudit();
    Equipment equipment = equipmentService.lookupEquipment(new Long(1));

    PaginatedResult result = detailDao.lookupAuditDetailsByCriteria("1", equipment, "RRMALL", "columnName", "desc",
        startIndex, maxResults);
    MockHibernateFactoryForReports hibernate = (MockHibernateFactoryForReports) detailDao.getHibernateFactory();
    MockHibernateSessionForReports mockSessionForReports = hibernate.getHibernateSessionForReports();
    MockSqlQueryForReports mockSQLQueryForReports = (MockSqlQueryForReports)mockSessionForReports.getSqlQueryForReports();
    assertEquals("select * from (select row_.*, rownum rownum_  from (select d.audit_detail_id as id, eis.get_column_header('EIS', h.table_name, d.column_name, h.key_value, cref.column_description) as columnName, eis.get_reference_value('EIS', h.table_name, d.column_name, d.old_value) as oldValue, eis.get_reference_value('EIS', h.table_name, d.column_name, d.new_value) as newValue, h.change_datetime as changeDateTime, t.audit_requestor as auditRequestor, t.audit_transaction_id as transactionId, eis.get_tab_name('EIS', h.table_name, d.column_name) as tabName, tranApproval.process as process, tranApproval.mechanical as mechanical, tranApproval.electrical as electrical, eis.get_component_number('EIS', h.table_name, d.column_name, h.key_value) as componentNumber from (select h.key_value,  d.column_name, max(h.change_datetime) last_change from eis.audit_header h inner join eis.audit_detail d on d.audit_header_id = h.audit_header_id where h.key_value in ('1','2','12','15','6','7','8','9','10','11','12','14','12') and h.change_datetime >= (SELECT max(h2.change_datetime) FROM eis.audit_detail d1, eis.audit_header h2 WHERE h2.key_value = '1' AND d1.column_name = 'STATUS_ID' AND d1.new_value in (SELECT status.id FROM eis.eis_proj_status status WHERE status.status_name = 'Detailed Design') AND d1.audit_header_id = h2.audit_header_id)AND  d.column_name != 'IS_DELETED' AND d.old_value IS NOT NULL group by h.key_value, d.column_name) lastchanges inner join eis.audit_header h on h.key_value = lastchanges.key_value and h.change_datetime = lastchanges.last_change  and h.operation_type in ('U', 'D') inner join eis.audit_detail d on h.audit_header_id = d.audit_header_id and d.column_name = lastchanges.column_name left outer join eis.audit_transaction t on t.audit_transaction_id = h.audit_transaction_id left outer join eis.audit_transaction_approval tranApproval on tranApproval.audit_detail_id = d.audit_detail_id left outer join eis.eis_column_name_ref cref on  cref.column_name = d.column_name and cref.table_name = h.table_name order by columnName desc) row_ where rownum <=25) where rownum_ >0",
        mockSQLQueryForReports.getSqlQueryStringForReports());
    assertEquals(2, result.getTotalRecords());
    ChangeHistory change = (ChangeHistory)result.getData().get(0);
    assertEquals("description", change.getColumnName());
    assertEquals("22", change.getOldValue());
    assertEquals("33", change.getNewValue());
    assertEquals("description", change.getColumnName());
    assertEquals(new Timestamp(1234L), change.getChangeTime());
    assertEquals("EIS_EQUIPMENT", change.getTabName());
    assertFalse(change.getIsProcessVerified());
    assertFalse(change.getIsMechanicalVerified());
    assertTrue(change.getIsElectricalVerified());
    change = (ChangeHistory)result.getData().get(1);
    assertEquals("comments", change.getColumnName());
    assertEquals("equipment works", change.getOldValue());
    assertEquals("equipment works fine", change.getNewValue());
    assertEquals(new Timestamp(5678L), change.getChangeTime());
    assertEquals("EIS_EQUIPMENT", change.getTabName());
    assertFalse(change.getIsProcessVerified());
    assertFalse(change.getIsMechanicalVerified());
    assertFalse(change.getIsElectricalVerified());
  }

  public void testSearchDetailEntriesByCriteria_DetailIdIsSetInCriteria_ButProcessMechanicalElectricalHasVerifiedChange_ListReturnedIsEmpty() throws Exception {
    startIndex = 25;
    MockAuditDetailDao detailDao = new MockAuditDetailDao(new MockHibernateFactoryForReports(getGetListWithDataWithAllChangeVerified()));
    MockEquipmentServiceImplForAudit equipmentService = new MockEquipmentServiceImplForAudit();
    Equipment equipment = equipmentService.lookupEquipment(new Long(1));

    PaginatedResult result = detailDao.lookupAuditDetailsByCriteria("1", equipmentService.lookupEquipment(new Long(1)), "RRMALL", "columnName", "desc",
        startIndex, maxResults);
    MockHibernateFactoryForReports hibernate = (MockHibernateFactoryForReports) detailDao.getHibernateFactory();
    MockHibernateSessionForReports mockSessionForReports = hibernate.getHibernateSessionForReports();
    MockSqlQueryForReports mockSQLQueryForReports = (MockSqlQueryForReports)mockSessionForReports.getSqlQueryForReports();
    assertEquals("select * from (select row_.*, rownum rownum_  from (select d.audit_detail_id as id, eis.get_column_header('EIS', h.table_name, d.column_name, h.key_value, cref.column_description) as columnName, eis.get_reference_value('EIS', h.table_name, d.column_name, d.old_value) as oldValue, eis.get_reference_value('EIS', h.table_name, d.column_name, d.new_value) as newValue, h.change_datetime as changeDateTime, t.audit_requestor as auditRequestor, t.audit_transaction_id as transactionId, eis.get_tab_name('EIS', h.table_name, d.column_name) as tabName, tranApproval.process as process, tranApproval.mechanical as mechanical, tranApproval.electrical as electrical, eis.get_component_number('EIS', h.table_name, d.column_name, h.key_value) as componentNumber from (select h.key_value,  d.column_name, max(h.change_datetime) last_change from eis.audit_header h inner join eis.audit_detail d on d.audit_header_id = h.audit_header_id where h.key_value in ('1','2','12','15','6','7','8','9','10','11','12','14','12') and h.change_datetime >= (SELECT max(h2.change_datetime) FROM eis.audit_detail d1, eis.audit_header h2 WHERE h2.key_value = '1' AND d1.column_name = 'STATUS_ID' AND d1.new_value in (SELECT status.id FROM eis.eis_proj_status status WHERE status.status_name = 'Detailed Design') AND d1.audit_header_id = h2.audit_header_id)AND  d.column_name != 'IS_DELETED' AND d.old_value IS NOT NULL group by h.key_value, d.column_name) lastchanges inner join eis.audit_header h on h.key_value = lastchanges.key_value and h.change_datetime = lastchanges.last_change  and h.operation_type in ('U', 'D') inner join eis.audit_detail d on h.audit_header_id = d.audit_header_id and d.column_name = lastchanges.column_name left outer join eis.audit_transaction t on t.audit_transaction_id = h.audit_transaction_id left outer join eis.audit_transaction_approval tranApproval on tranApproval.audit_detail_id = d.audit_detail_id left outer join eis.eis_column_name_ref cref on  cref.column_name = d.column_name and cref.table_name = h.table_name order by columnName desc) row_ where rownum <=50) where rownum_ >25",
        mockSQLQueryForReports.getSqlQueryStringForReports().replaceAll("\n", "").replaceAll("   ", ""));
    assertEquals(0, result.getData().size());
  }

  public void testSearchDetailEntriesByCriteria_DetailIdIsSetInCriteria_DataReturnedIsNotInProperFormat_ListReturnedIsEmpty() throws Exception {
    PaginatedResult result = null;
    startIndex = 0;
    MockAuditDetailDao detailDao = new MockAuditDetailDao(new MockHibernateFactoryForReports(getGetListWithDataNotInProperFormat()));
    MockEquipmentServiceImplForAudit equipmentService = new MockEquipmentServiceImplForAudit();
    Equipment equipment = equipmentService.lookupEquipment(new Long(1));

    try{
     result = detailDao.lookupAuditDetailsByCriteria("1", equipmentService.lookupEquipment(new Long(1)), "RRMALL", "columnName", "desc",
         startIndex, maxResults);
      fail("Should Not have displayed this message\n");
    }catch(RuntimeException e){
//      assertEquals("java.lang.ClassCastException: java.lang.String cannot be cast to java.sql.Timestamp", e.getMessage());
    }
    MockHibernateFactoryForReports hibernate = (MockHibernateFactoryForReports) detailDao.getHibernateFactory();
    MockHibernateSessionForReports mockSessionForReports = hibernate.getHibernateSessionForReports();
    MockSqlQueryForReports mockSQLQueryForReports = (MockSqlQueryForReports)mockSessionForReports.getSqlQueryForReports();
    assertEquals("select * from (select row_.*, rownum rownum_  from (select d.audit_detail_id as id, eis.get_column_header('EIS', h.table_name, d.column_name, h.key_value, cref.column_description) as columnName, eis.get_reference_value('EIS', h.table_name, d.column_name, d.old_value) as oldValue, eis.get_reference_value('EIS', h.table_name, d.column_name, d.new_value) as newValue, h.change_datetime as changeDateTime, t.audit_requestor as auditRequestor, t.audit_transaction_id as transactionId, eis.get_tab_name('EIS', h.table_name, d.column_name) as tabName, tranApproval.process as process, tranApproval.mechanical as mechanical, tranApproval.electrical as electrical, eis.get_component_number('EIS', h.table_name, d.column_name, h.key_value) as componentNumber from (select h.key_value,  d.column_name, max(h.change_datetime) last_change from eis.audit_header h inner join eis.audit_detail d on d.audit_header_id = h.audit_header_id where h.key_value in ('1','2','12','15','6','7','8','9','10','11','12','14','12') and h.change_datetime >= (SELECT max(h2.change_datetime) FROM eis.audit_detail d1, eis.audit_header h2 WHERE h2.key_value = '1' AND d1.column_name = 'STATUS_ID' AND d1.new_value in (SELECT status.id FROM eis.eis_proj_status status WHERE status.status_name = 'Detailed Design') AND d1.audit_header_id = h2.audit_header_id)AND  d.column_name != 'IS_DELETED' AND d.old_value IS NOT NULL group by h.key_value, d.column_name) lastchanges inner join eis.audit_header h on h.key_value = lastchanges.key_value and h.change_datetime = lastchanges.last_change  and h.operation_type in ('U', 'D') inner join eis.audit_detail d on h.audit_header_id = d.audit_header_id and d.column_name = lastchanges.column_name left outer join eis.audit_transaction t on t.audit_transaction_id = h.audit_transaction_id left outer join eis.audit_transaction_approval tranApproval on tranApproval.audit_detail_id = d.audit_detail_id left outer join eis.eis_column_name_ref cref on  cref.column_name = d.column_name and cref.table_name = h.table_name order by columnName desc) row_ where rownum <=25) where rownum_ >0",
        mockSQLQueryForReports.getSqlQueryStringForReports().replaceAll("\n", "").replaceAll("   ", ""));
    assertTrue(result == null);
  }

  public void testSearchDetailEntriesByCriteria_ProcessHasNoDesignCapacityUnit_QueryReturnedHasDifferentSetOfIds_ListReturnedIsEmpty() throws Exception {
    MockAuditDetailDao detailDao = new MockAuditDetailDao(new MockHibernateFactoryForReports(new ArrayList()));
    MockEquipmentServiceImplForAudit equipmentService = new MockEquipmentServiceImplForAudit();
    Equipment equipment = equipmentService.lookupEquipment(new Long(1));

    equipment.getProcess().setDesignCapacityUnit(null);
    PaginatedResult result = detailDao.lookupAuditDetailsByCriteria("1", equipment, "RRMALL", "columnName", "desc",
           startIndex, maxResults);
      MockHibernateFactoryForReports hibernate = (MockHibernateFactoryForReports) detailDao.getHibernateFactory();
      MockHibernateSessionForReports mockSessionForReports = hibernate.getHibernateSessionForReports();
      MockSqlQueryForReports mockSQLQueryForReports = (MockSqlQueryForReports)mockSessionForReports.getSqlQueryForReports();
      assertEquals("select * from (select row_.*, rownum rownum_  from (select d.audit_detail_id as id, eis.get_column_header('EIS', h.table_name, d.column_name, h.key_value, cref.column_description) as columnName, eis.get_reference_value('EIS', h.table_name, d.column_name, d.old_value) as oldValue, eis.get_reference_value('EIS', h.table_name, d.column_name, d.new_value) as newValue, h.change_datetime as changeDateTime, t.audit_requestor as auditRequestor, t.audit_transaction_id as transactionId, eis.get_tab_name('EIS', h.table_name, d.column_name) as tabName, tranApproval.process as process, tranApproval.mechanical as mechanical, tranApproval.electrical as electrical, eis.get_component_number('EIS', h.table_name, d.column_name, h.key_value) as componentNumber from (select h.key_value,  d.column_name, max(h.change_datetime) last_change from eis.audit_header h inner join eis.audit_detail d on d.audit_header_id = h.audit_header_id where h.key_value in ('1','2','15','6','7','8','9','10','11','12','14','12') and h.change_datetime >= (SELECT max(h2.change_datetime) FROM eis.audit_detail d1, eis.audit_header h2 WHERE h2.key_value = '1' AND d1.column_name = 'STATUS_ID' AND d1.new_value in (SELECT status.id FROM eis.eis_proj_status status WHERE status.status_name = 'Detailed Design') AND d1.audit_header_id = h2.audit_header_id)AND  d.column_name != 'IS_DELETED' AND d.old_value IS NOT NULL group by h.key_value, d.column_name) lastchanges inner join eis.audit_header h on h.key_value = lastchanges.key_value and h.change_datetime = lastchanges.last_change  and h.operation_type in ('U', 'D') inner join eis.audit_detail d on h.audit_header_id = d.audit_header_id and d.column_name = lastchanges.column_name left outer join eis.audit_transaction t on t.audit_transaction_id = h.audit_transaction_id left outer join eis.audit_transaction_approval tranApproval on tranApproval.audit_detail_id = d.audit_detail_id left outer join eis.eis_column_name_ref cref on  cref.column_name = d.column_name and cref.table_name = h.table_name order by columnName desc) row_ where rownum <=25) where rownum_ >0",
          mockSQLQueryForReports.getSqlQueryStringForReports());
    assertEquals(0, result.getData().size());
  }

  public List getGetListWithDataWithAllChangeVerified() {
     Object[] result = new Object[20];
         List<Object[]> changeHistoryList = new ArrayList<Object[]>();
         result[0] = new Long("1");
         result[1] = "description";
         result[2] = "22";
         result[3] = "33";
         result[4] = new Timestamp(1234L);
         result[5] = "RRMALL";
         result[6] =  new Long("4");
         result[7] = "EIS_EQUIPMENT";
         result[8] = "SSCLIN";
         result[9] = "SSCLIN";
         result[10] = "SSCLIN";
         result[11] = "description";
         changeHistoryList.add(result);
         result = new Object[20];
         result[0] = new Long("2");
         result[1] = "comments";
         result[2] = "equipment works";
         result[3] = "equipment works fine";
         result[4] = new Timestamp(5678L);
         result[5] = "RRMALL";
         result[6] =  new Long("4");
         result[7] = "EIS_EQUIPMENT";
         result[8] = "SSCLIN";
         result[9] = "SSCLIN";
         result[10] = "SSCLIN";
         result[11] = "comments";
         changeHistoryList.add(result);
     return changeHistoryList;
   }

  public List getGetListWithDataInCorrectSortOrder() {
      Object[] result = new Object[20];
        List<Object[]> changeHistoryList = new ArrayList<Object[]>();
        result[0] = new Long("1");
        result[1] = "description";
        result[2] = "22";
        result[3] = "33";
        result[4] = new Timestamp(1234L);
        result[5] = "RRMALL";
        result[6] =  new Long("4");
        result[7] = "EIS_EQUIPMENT";
        result[8] = null;
        result[9] = null;
        result[10] = "SSCLIN";
        result[11] = "description";
        changeHistoryList.add(result);
        result = new Object[20];
        result[0] = new Long("2");
        result[1] = "comments";
        result[2] = "equipment works";
        result[3] = "equipment works fine";
        result[4] = new Timestamp(5678L);
        result[5] = "RRMALL";
        result[6] =  new Long("4");
        result[7] = "EIS_EQUIPMENT";
        result[8] = null;
        result[9] = null;
        result[10] = null;
        result[11] = "comments";
        changeHistoryList.add(result);
    return changeHistoryList;
  }

   public List getGetListWithDataNotInProperFormat() {
      Object[] result = new Object[20];
        List<Object[]> changeHistoryList = new ArrayList<Object[]>();
        result[0] = new Long("1");
        result[1] = "description";
        result[2] = "22";
        result[3] = "33";
        result[4] = "Jan 22 2009";
        result[5] = "RRMALL";
        result[6] =  new Long("4");
        result[7] = "EIS_EQUIPMENT";
        result[8] = null;
        result[9] = null;
        result[10] = "SSCLIN";
        result[11] = "description";
     changeHistoryList.add(result);
    return changeHistoryList;
  }

}
