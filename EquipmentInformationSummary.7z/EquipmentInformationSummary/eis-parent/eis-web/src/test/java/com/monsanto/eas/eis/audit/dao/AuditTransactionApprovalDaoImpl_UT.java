/*
 AuditTransactionApprovalDaoImpl_UT was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao;

import junit.framework.TestCase;
import com.monsanto.eas.eis.audit.dao.mock.*;
import com.monsanto.eas.eis.audit.domain.AuditTransactionApproval;
import com.monsanto.eas.eis.audit.domain.AuditTransaction;
import com.monsanto.eas.eis.audit.domain.AuditDetail;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.wst.hibernate.mock.MockCriteria;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.sql.Timestamp;

/**
 * Filename:    $RCSfile: AuditTransactionApprovalDaoImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-23 19:25:15 $
 *
 * @author rrmall
 * @version $Revision: 1.5 $
 */
public class AuditTransactionApprovalDaoImpl_UT extends TestCase {
  public void testSearchApprovalByCriteria_TransactionIdIsSetInCriteria_VerifyCriteriaObject() throws Exception {
    MockAuditTransactionApprovalDao dao = new MockAuditTransactionApprovalDao();
    String transactionId = "123";
    dao.findByCriteria(transactionId, null, null);
    MockCriteria criteria = dao.getMockCriteria();
    assertTrue(dao.getWasFindByCriteriaCalled());
    assertEquals("id=123",criteria.getCriteria().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testSearchApprovalByCriteria_DetailIdIsSetInCriteria_VerifyCriteriaObject() throws Exception {
    MockAuditTransactionApprovalDao dao = new MockAuditTransactionApprovalDao();
    String detailId = "222";
    dao.findByCriteria(null, new Long(detailId), null);
    MockCriteria criteria = dao.getMockCriteria();
    assertTrue(dao.getWasFindByCriteriaCalled());
    assertEquals("detail.id=222",criteria.getCriteria().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testInsertEntryIntoTransactionApproval_EntriesInserted() throws Exception {
    Equipment equipment = new Equipment();
    equipment.setId(new Long(1));
    AuditTransactionApproval approval = new AuditTransactionApproval(new Long(1), new AuditTransaction(new Long(11), "RRMALL"),
        new AuditDetail(new Long(22), null, "description", "old desc", "new desc"),
        new User(new Long(1), "SSCLIN", null, null, null, null),
        new User(new Long(2), "SSCLIN", null, null, null, null),
        new User(new Long(3), "SSCLIN", null, null, null, null), equipment, new Date(2009,1,2), "description");
    MockAuditTransactionApprovalDao dao = new MockAuditTransactionApprovalDao();
    AuditTransactionApproval approvalSaved = dao.save(approval);
    assertEquals(new Long (1), approvalSaved.getId());
    assertEquals(new Long (11), approvalSaved.getTransaction().getId());
    assertEquals(new Long (1), approvalSaved.getEquipment().getId());
    assertEquals(new Long (1), approvalSaved.getProcessApprover().getId());
    assertEquals(new Long (2), approvalSaved.getMechanicalApprover().getId());
    assertEquals(new Long (3), approvalSaved.getElectricalApprover().getId());
    assertEquals(new Date(2009, 1, 2), approvalSaved.getChangeDateTime());
    assertTrue(dao.getWasApprovalEntrySaveCalled());
  }

  public void testLookupAllRecentChangesToAnEquipmentAndRelatedEntitiesNotInApproval_ChangesExist_ListReturned() throws Exception {
    MockAuditTransactionApprovalDao approvalDao = new MockAuditTransactionApprovalDao(new MockHibernateFactoryForReports(getGetListWithData()));
    MockEquipmentServiceImplForAudit equipmentService = new MockEquipmentServiceImplForAudit();
    Equipment equipment = equipmentService.lookupEquipment(new Long(1));
    equipment.getProjects().setId(new Long(12));
    List results = approvalDao.lookupAllChangesForAnEquipmentNotInTransactionApproval(equipment);
    MockHibernateFactoryForReports hibernate = (MockHibernateFactoryForReports) approvalDao.getHibernateFactory();
    MockHibernateSessionForReports mockSessionForReports = hibernate.getHibernateSessionForReports();
    MockSqlQueryForReports mockSQLQueryForReports = (MockSqlQueryForReports)mockSessionForReports.getSqlQueryForReports();
    assertEquals("SELECT h.audit_transaction_id tranId, d.audit_detail_id detailid, MAX(h.change_datetime) lastChange, d.column_name columnName FROM eis.audit_header h INNER JOIN eis.audit_detail d ON d.audit_header_id = h.audit_header_id WHERE h.key_value IN ('1','2','12','15','6','7','8','9','10','11','12','14','12') AND h.change_datetime >=  (SELECT MAX(h2.change_datetime)  FROM eis.audit_detail d1, eis.audit_header h2 WHERE h2.key_value = to_char(12)  AND d1.column_name = 'STATUS_ID' AND d1.new_value IN    (SELECT status.id FROM eis.eis_proj_status status WHERE status.status_name = 'Detailed Design') AND d1.audit_header_id = h2.audit_header_id) AND d.column_name != 'IS_DELETED' AND d.old_value IS NOT NULL     and not exists ( select ata.audit_detail_id     from eis.audit_transaction_approval ata where ata.audit_detail_id = d.audit_detail_id ) GROUP BY h.key_value, h.audit_transaction_id, d.column_name, d.audit_detail_id",
        mockSQLQueryForReports.getSqlQueryStringForReports());
    assertEquals(2, results.size());
    Object[] result = (Object[]) results.get(0);
    assertEquals(new Long(1), result[0]);
    assertEquals(new Long(2), result[1]);
    assertEquals(new Timestamp(1234L), result[2]);
    assertEquals("NAME", result[3]);
    result = (Object[]) results.get(1);
    assertEquals(new Long(3), result[0]);
    assertEquals(new Long(4), result[1]);
    assertEquals(new Timestamp(5678L), result[2]);
    assertEquals("DESCRIPTION", result[3]);
    assertTrue(approvalDao.getWasLookupAllChangesCalled());
  }


  public void testLookupAllRecentChangesToAnEquipmentAndRelatedEntitiesNotInApproval_NoChangesToEquipment_EmptyListReturned() throws Exception {
    MockAuditTransactionApprovalDao approvalDao = new MockAuditTransactionApprovalDao(new MockHibernateFactoryForReports(new ArrayList<Object[]>()));
    MockEquipmentServiceImplForAudit equipmentService = new MockEquipmentServiceImplForAudit();
    Equipment equipment = equipmentService.lookupEquipment(new Long(1));
    equipment.getProjects().setId(new Long(12));
    List results = approvalDao.lookupAllChangesForAnEquipmentNotInTransactionApproval(equipment);
    MockHibernateFactoryForReports hibernate = (MockHibernateFactoryForReports) approvalDao.getHibernateFactory();
    MockHibernateSessionForReports mockSessionForReports = hibernate.getHibernateSessionForReports();
    MockSqlQueryForReports mockSQLQueryForReports = (MockSqlQueryForReports)mockSessionForReports.getSqlQueryForReports();
    assertEquals("SELECT h.audit_transaction_id tranId, d.audit_detail_id detailid, MAX(h.change_datetime) lastChange, d.column_name columnName FROM eis.audit_header h INNER JOIN eis.audit_detail d ON d.audit_header_id = h.audit_header_id WHERE h.key_value IN ('1','2','12','15','6','7','8','9','10','11','12','14','12') AND h.change_datetime >=  (SELECT MAX(h2.change_datetime)  FROM eis.audit_detail d1, eis.audit_header h2 WHERE h2.key_value = to_char(12)  AND d1.column_name = 'STATUS_ID' AND d1.new_value IN    (SELECT status.id FROM eis.eis_proj_status status WHERE status.status_name = 'Detailed Design') AND d1.audit_header_id = h2.audit_header_id) AND d.column_name != 'IS_DELETED' AND d.old_value IS NOT NULL     and not exists ( select ata.audit_detail_id     from eis.audit_transaction_approval ata where ata.audit_detail_id = d.audit_detail_id ) GROUP BY h.key_value, h.audit_transaction_id, d.column_name, d.audit_detail_id",
        mockSQLQueryForReports.getSqlQueryStringForReports());
    assertEquals(0, results.size());
  }

  public List<Object[]> getGetListWithData() {
    List<Object[]> list = new ArrayList<Object[]>();
    Object[] result = new Object[5];
    result[0] = new Long(1);
    result[1] = new Long(2);
    result[2] = new Timestamp(1234L);
    result[3] = new String("NAME");
    list.add(result);
    result = new Object[5];
    result[0] = new Long(3);
    result[1] = new Long(4);
    result[2] = new Timestamp(5678L);
    result[3] = new String("DESCRIPTION");
    list.add(result);
    return list;
  }
}