/*
 AuditTransactionImpl_UT was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao;

import com.monsanto.eas.eis.audit.dao.mock.MockAuditTransactionDao;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AuditTransactionDaoImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-01-27 18:27:32 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class AuditTransactionDaoImpl_UT extends TestCase {
  public void testFindTransactionByCriteria_UserIdIsSet_VerifyCriteriaObject() throws Exception {
    MockAuditTransactionDao auditTransactionDao = new MockAuditTransactionDao();
    String auditRequestor = "TESTUSER";
    auditTransactionDao.findByCriteria(null, auditRequestor);
    MockCriteria criteria = auditTransactionDao.getMockCriteria();
    assertTrue(auditTransactionDao.wasFindByCriteriaCalled());
    assertTrue(criteria.wasListCalled());
    assertEquals("audit_requestor=TESTUSER", criteria.getCriteria().get(0).toString());
    assertEquals("id asc", criteria.getOrderings().get(0).toString());
  }

  public void testFindTransactionByCriteria_TransactionIdIsSet_VerifyCriteriaObject() throws Exception {
    MockAuditTransactionDao auditTransactionDao = new MockAuditTransactionDao();
    auditTransactionDao.findByCriteria(new Long(1234), null);
    MockCriteria criteria = auditTransactionDao.getMockCriteria();
    assertTrue(auditTransactionDao.wasFindByCriteriaCalled());
    assertTrue(criteria.wasListCalled());
    assertEquals("id=1234", criteria.getCriteria().get(0).toString());
    assertEquals("id asc", criteria.getOrderings().get(0).toString());
   }

  public void testFindTransactionByCriteria_TransactionIdAndUserIdIsSet_VerifyCriteriaObject() throws Exception {
    MockAuditTransactionDao auditTransactionDao = new MockAuditTransactionDao();
    auditTransactionDao.findByCriteria(new Long(1234), "TESTUSER");
    MockCriteria criteria = auditTransactionDao.getMockCriteria();
    assertTrue(auditTransactionDao.wasFindByCriteriaCalled());
    assertTrue(criteria.wasListCalled());
    assertEquals("id=1234", criteria.getCriteria().get(0).toString());
    assertEquals("audit_requestor=TESTUSER", criteria.getCriteria().get(1).toString());
    assertEquals("id asc", criteria.getOrderings().get(0).toString());
   }
}