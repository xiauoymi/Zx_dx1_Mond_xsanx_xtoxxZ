/*
 AuditTransactionDao_AT was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao;

import com.monsanto.eas.eis.audit.domain.AuditTransaction;
import com.monsanto.eas.eis.audit.domain.AuditHeader;
import com.monsanto.eas.eis.audit.domain.AuditDetail;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.eas.eis.equipment.service.EquipmentService;
import com.monsanto.eas.eis.equipment.service.EquipmentServiceImpl;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.projects.domain.Equipment;

import java.util.List;

/**
 * Filename:    $RCSfile: AuditTransactionDao_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-23 19:25:15 $
 *
 * @author rrmall
 * @version $Revision: 1.3 $
 */
public class AuditTransactionDao_AT extends EISTestCase {
  private AuditTransactionDao dao;
  protected void setUp() throws Exception{
    super.setUp();
  }

  public void testGetDetailsForATransaction_AuditHeaderDetailsRetrieved() throws Exception {
    dao = new AuditTransactionDaoImpl(EISHibernateUtil.getHibernateFactory());
    List<AuditTransaction> transactions = dao.findByCriteria(new Long(10024), "");
    assertNotNull(transactions);
    AuditTransaction transaction = transactions.get(0);
    assertEquals(new Long(10024), transaction.getId());
    assertEquals("VRBETHI", transaction.getAudit_requestor());
  }

  public void testGetDetailsForATransaction_UserIDIsSetInCriteria_AuditHeadersRetrieved() throws Exception {
    dao = new AuditTransactionDaoImpl(EISHibernateUtil.getHibernateFactory());
    List<AuditTransaction> transactions = dao.findByCriteria(null, "RRMALL");
    assertNotNull(transactions);
    assertTrue(transactions.size() > 1);
    AuditTransaction transaction = transactions.get(0);
    assertEquals(new Long(10504), transaction.getId());
    assertEquals("RRMALL", transaction.getAudit_requestor());
    List<AuditHeader> headers = transaction.getHeaders();
    assertEquals(1, headers.size());
    AuditHeader header = headers.get(0);
    assertNotNull(header);
    assertEquals(new Long(10505), header.getId());
    assertEquals("U", header.getOperation_type());
    assertEquals("2008-12-19 13:01:23.340471", header.getChangeDateTime().toString());
    assertEquals("EIS_FIELD_EQUIPMENT_TYPE", header.getTable_name());
    assertEquals(transaction.getId(), header.getTransaction().getId());
    List<AuditDetail> details = header.getDetailList();
    assertNotNull(details);
    assertEquals(0, details.size());
  }


   public void testGetDetailsForATransaction_UserIDIsSetInCriteria_AuditHeaderAndDetailsAreRetrieved() throws Exception {
    dao = new AuditTransactionDaoImpl(EISHibernateUtil.getHibernateFactory());
    List<AuditTransaction> transactions = dao.findByCriteria(new Long(10475), "SSPATI1");
    assertNotNull(transactions);
    assertTrue(transactions.size() >= 1);
    AuditTransaction transaction = transactions.get(0);
    assertEquals(new Long(10475), transaction.getId());
    assertEquals("SSPATI1", transaction.getAudit_requestor());
    List<AuditHeader> headers = transaction.getHeaders();
    assertEquals(1, headers.size());
    AuditHeader header = headers.get(0);
    assertNotNull(header);
    assertEquals(new Long(10476), header.getId());
    assertEquals("U", header.getOperation_type());
    assertEquals("2008-12-19 12:38:36.431849", header.getChangeDateTime().toString());
    assertEquals("EIS_EQUIPMENT", header.getTable_name());
    assertEquals(transaction.getId(), header.getTransaction().getId());
    List<AuditDetail> details = header.getDetailList();
    assertNotNull(details);
    assertEquals(2, details.size());
     AuditDetail detail = details.get(0);
     assertEquals("AREA_ID", detail.getColumn_name());
     assertEquals("1", detail.getOld_value());
     assertEquals("11", detail.getNew_value());
  }
}