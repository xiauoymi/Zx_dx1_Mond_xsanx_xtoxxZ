/*
 MockAuditDetailDao was created on Jan 26, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao.mock;

import com.monsanto.eas.eis.audit.dao.AuditDetailDaoImpl;
import com.monsanto.eas.eis.audit.domain.AuditDetail;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.wst.hibernate.HibernateFactory;

/**
 * Filename:    $RCSfile: MockAuditDetailDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-23 19:26:08 $
 *
 * @author rrmall
 * @version $Revision: 1.5 $
 */
public class MockAuditDetailDao extends AuditDetailDaoImpl {
  private boolean wasLookupAuditDetailByCriteriaCalled = false;
  private String sortKey = "";
  private String sortDir = "";
  private HibernateFactory hibernateFactory;
  private boolean wasFindByPrimaryKeyCalled = false;


  public MockAuditDetailDao() {
  } 

  public MockAuditDetailDao(HibernateFactory hibernate) {
    super(hibernate);
    this.hibernateFactory = hibernate;
  }

  public HibernateFactory getHibernateFactory() {
    return hibernateFactory;
  }

  public PaginatedResult lookupAuditDetailsByCriteria(String projectId, Equipment equipment, String userId,
                                                      String sKey, String sDir, int startIndex, int maxResults) {
    wasLookupAuditDetailByCriteriaCalled = true;
    sortKey = sKey;
    sortDir = sDir;
    return super.lookupAuditDetailsByCriteria(projectId, equipment, userId, sKey, sDir, startIndex, maxResults);
  }

  public boolean isWasLookupAuditDetailByCriteriaCalled() {
    return wasLookupAuditDetailByCriteriaCalled;
  }

  public String getSortKey() {
    return sortKey;
  }

  public String getSortDir() {
    return sortDir;
  }


  public boolean isWasFindByPrimaryKeyCalled() {
    return wasFindByPrimaryKeyCalled;
  }

  public AuditDetail findByPrimaryKey(Long id) {
    wasFindByPrimaryKeyCalled = true;
    return super.findByPrimaryKey(id);
  }

}