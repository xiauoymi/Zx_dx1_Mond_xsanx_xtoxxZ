/*
 MockAuditTransactionApprovalDao was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao.mock;

import com.monsanto.eas.eis.audit.dao.AuditTransactionApprovalDaoImpl;
import com.monsanto.eas.eis.audit.domain.AuditTransactionApproval;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.HibernateFactory;

import java.util.List;

/**
 * Filename:    $RCSfile: MockAuditTransactionApprovalDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-23 19:26:08 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class MockAuditTransactionApprovalDao  extends AuditTransactionApprovalDaoImpl {
  private MockCriteria criteria;
  private boolean wasFindByCriteriaCalled = false;
  private boolean wasApprovalEntrySaveCalled = false;
  private boolean wasLookupAllChangesCalled = false;
  private HibernateFactory hibernateFactory;


  public MockAuditTransactionApprovalDao() {
  }

 public MockAuditTransactionApprovalDao(HibernateFactory hibernate) {
   super(hibernate);
    this.hibernateFactory = hibernate;
  }

  public HibernateFactory getHibernateFactory() {
    return hibernateFactory;
  }

  public List<AuditTransactionApproval> findByCriteria(String id, Long auditDetailId, Long auditTransactionId) {
    wasFindByCriteriaCalled = true;
    return super.findByCriteria(id, auditDetailId, auditTransactionId);
  }

  public AuditTransactionApproval save(AuditTransactionApproval approval){
    wasApprovalEntrySaveCalled = true;
    return approval;
    //return super.save(approval);
  }

  protected MockCriteria getCriteria(){
    criteria = new MockCriteria();
    return criteria;
  }

  public boolean getWasFindByCriteriaCalled() {
    return wasFindByCriteriaCalled;
  }

  public MockCriteria getMockCriteria() {
    return criteria;
  }

  public boolean getWasApprovalEntrySaveCalled() {
    return wasApprovalEntrySaveCalled;
  }

  public boolean getWasLookupAllChangesCalled() {
    return wasLookupAllChangesCalled;
  }

  public List lookupAllChangesForAnEquipmentNotInTransactionApproval(Equipment equipment) {
    wasLookupAllChangesCalled = true;
    return super.lookupAllChangesForAnEquipmentNotInTransactionApproval(equipment);
  }
}