/*
 MockAuditTransactionDao was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao.mock;

import com.monsanto.eas.eis.audit.dao.AuditTransactionDaoImpl;
import com.monsanto.eas.eis.audit.domain.AuditTransaction;
import com.monsanto.wst.hibernate.mock.MockCriteria;

import java.util.List;

/**
 * Filename:    $RCSfile: MockAuditTransactionDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-01-27 18:27:32 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class MockAuditTransactionDao extends AuditTransactionDaoImpl {
  private MockCriteria mockCriteria;
  private boolean findByCriteriaCalled = false;

  public List<AuditTransaction> findByCriteria(Long id, String auditRequestor) {
    findByCriteriaCalled = true;
    return super.findByCriteria(id, auditRequestor);
  }

  protected MockCriteria getCriteria(){
    mockCriteria = new MockCriteria();
    return mockCriteria;
  }

  public MockCriteria getMockCriteria() {
    return mockCriteria;
  }

  public boolean wasFindByCriteriaCalled() {
    return findByCriteriaCalled;
  }
}