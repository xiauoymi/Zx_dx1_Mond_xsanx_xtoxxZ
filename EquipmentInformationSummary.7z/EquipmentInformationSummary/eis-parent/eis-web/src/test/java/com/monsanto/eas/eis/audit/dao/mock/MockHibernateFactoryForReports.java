/*
 MockHibernateFactoryForReports was created on Jan 27, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao.mock;

import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.eas.eis.audit.dao.AuditDetailDaoImpl_UT;

import java.util.*;
import java.sql.Connection;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import org.hibernate.*;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.type.Type;
import org.hibernate.stat.SessionStatistics;
import org.hibernate.cfg.Configuration;

/**
 * Filename:    $RCSfile: MockHibernateFactoryForReports.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-01-27 18:27:32 $
*
* @author rrmall
* @version $Revision: 1.1 $
*/
public class MockHibernateFactoryForReports implements HibernateFactory {
   private MockHibernateSessionForReports hibernateSessionForReports = null;
   private List dataSet = new ArrayList();

   public MockHibernateFactoryForReports(List dataSet) {
     this.dataSet = dataSet;
   }

   public void closeSessionFactory() {
   }

   public MockHibernateSessionForReports getSession() {
     setHibernateSessionForReports(new MockHibernateSessionForReports(dataSet));
     return getHibernateSessionForReports();
   }

   public MockHibernateSessionForReports getHibernateSessionForReports() {
     return hibernateSessionForReports;
   }

   public void closeSession() {
   }

   public void beginTransaction() {
   }

   public void commitTransaction() {
   }

   public void rollbackTransaction() {
   }

   public Transaction getThreadTransaction() {
     return null;
   }

   public Session getThreadSession() {
     return null;
   }

   public Configuration getConfiguration() {
     return null;
   }

   public void setHibernateSessionForReports(
       MockHibernateSessionForReports hibernateSessionForReports) {
     this.hibernateSessionForReports = hibernateSessionForReports;
   }
 }
