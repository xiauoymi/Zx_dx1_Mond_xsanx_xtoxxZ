/*
 MockHibernateSessionForReports was created on Jan 27, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.dao.mock;

import org.hibernate.*;
import org.hibernate.stat.SessionStatistics;

import java.util.List;
import java.util.ArrayList;
import java.sql.Connection;
import java.io.Serializable;

import com.monsanto.wst.hibernate.mock.MockCriteria;

/**
 * Filename:    $RCSfile: MockHibernateSessionForReports.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-17 15:39:48 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class MockHibernateSessionForReports implements Session{
    private static SQLQuery sqlQueryForReports = null;

  public List getDataSet() {
    return dataSet;
  }

  private List dataSet = new ArrayList();

    public MockHibernateSessionForReports(List dataSet) {
      this.dataSet = dataSet;
    }

    public EntityMode getEntityMode() {
      return null;
    }

    public Session getSession(EntityMode entityMode) {
      return null;
    }

    public void flush() throws HibernateException {
    }

    public void setFlushMode(FlushMode flushMode) {
    }

    public FlushMode getFlushMode() {
      return null;
    }

    public void setCacheMode(CacheMode cacheMode) {
    }

    public CacheMode getCacheMode() {
      return null;
    }

    public SessionFactory getSessionFactory() {
      return null;
    }

    public Connection connection() throws HibernateException {
      return null;
    }

    public Connection close() throws HibernateException {
      return null;
    }

    public void cancelQuery() throws HibernateException {
    }

    public boolean isOpen() {
      return false;
    }

    public boolean isConnected() {
      return false;
    }

    public boolean isDirty() throws HibernateException {
      return false;
    }

    public Serializable getIdentifier(Object object) throws HibernateException {
      return null;
    }

    public boolean contains(Object object) {
      return false;
    }

    public void evict(Object object) throws HibernateException {
    }

    public Object load(Class theClass, Serializable id, LockMode lockMode) throws HibernateException {
      return null;
    }

    public Object load(String entityName, Serializable id, LockMode lockMode) throws HibernateException {
      return null;
    }

    public Object load(Class theClass, Serializable id) throws HibernateException {
      return null;
    }

    public Object load(String entityName, Serializable id) throws HibernateException {
      return null;
    }

    public void load(Object object, Serializable id) throws HibernateException {
    }

    public void replicate(Object object, ReplicationMode replicationMode) throws HibernateException {
    }

    public void replicate(String entityName, Object object, ReplicationMode replicationMode) throws HibernateException {
    }

    public Serializable save(Object object) throws HibernateException {
      return null;
    }

    public Serializable save(String entityName, Object object) throws HibernateException {
      return null;
    }

    public void saveOrUpdate(Object object) throws HibernateException {
    }

    public void saveOrUpdate(String entityName, Object object) throws HibernateException {
    }

    public void update(Object object) throws HibernateException {
    }

    public void update(String entityName, Object object) throws HibernateException {
    }

    public Object merge(Object object) throws HibernateException {
      return null;
    }

    public Object merge(String entityName, Object object) throws HibernateException {
      return null;
    }

    public void persist(Object object) throws HibernateException {
    }

    public void persist(String entityName, Object object) throws HibernateException {
    }

    public void delete(Object object) throws HibernateException {
    }

    public void delete(String entityName, Object object) throws HibernateException {
    }

    public void lock(Object object, LockMode lockMode) throws HibernateException {
    }

    public void lock(String entityName, Object object, LockMode lockMode) throws HibernateException {
    }

    public void refresh(Object object) throws HibernateException {
    }

    public void refresh(Object object, LockMode lockMode) throws HibernateException {
    }

    public LockMode getCurrentLockMode(Object object) throws HibernateException {
      return null;
    }

    public Transaction beginTransaction() throws HibernateException {
      return null;
    }

    public Transaction getTransaction() {
      return null;
    }

    public Criteria createCriteria(Class persistentClass) {
      return new MockCriteria();
    }

    public Criteria createCriteria(Class persistentClass, String alias) {
      return null;
    }

    public Criteria createCriteria(String entityName) {
      return null;
    }

    public Criteria createCriteria(String entityName, String alias) {
      return null;
    }

    public Query createQuery(String queryString) throws HibernateException {
      return null;
    }

    public SQLQuery createSQLQuery(String queryString) throws HibernateException {
      sqlQueryForReports = new MockSqlQueryForReports(queryString, dataSet);
      return sqlQueryForReports;
    }

    public SQLQuery getSqlQueryForReports() {
      return sqlQueryForReports;
    }

    public Query createFilter(Object collection, String queryString) throws HibernateException {
      return null;
    }

    public Query getNamedQuery(String queryName) throws HibernateException {
      return null;
    }

    public void clear() {
    }

    public Object get(Class clazz, Serializable id) throws HibernateException {
      return null;
    }

    public Object get(Class clazz, Serializable id, LockMode lockMode) throws HibernateException {
      return null;
    }

    public Object get(String entityName, Serializable id) throws HibernateException {
      return null;
    }

    public Object get(String entityName, Serializable id, LockMode lockMode) throws HibernateException {
      return null;
    }

    public String getEntityName(Object object) throws HibernateException {
      return null;
    }

    public Filter enableFilter(String filterName) {
      return null;
    }

    public Filter getEnabledFilter(String filterName) {
      return null;
    }

    public void disableFilter(String filterName) {
    }

    public SessionStatistics getStatistics() {
      return null;
    }

    public void setReadOnly(Object entity, boolean readOnly) {
    }

    public Connection disconnect() throws HibernateException {
      return null;
    }

    public void reconnect() throws HibernateException {
    }

    public void reconnect(Connection connection) throws HibernateException {
    }
  }
