/*
 AuditDataSource_AT was created on Jan 14, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import com.monsanto.eas.eis.projects.Projects_AT_TestCaseHelper;
import com.monsanto.eas.eis.projects.dao.*;
import com.monsanto.eas.eis.audit.domain.ChangeHistory;
import com.monsanto.eas.eis.audit.dao.AuditDetailDaoImpl;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;

import java.util.List;
import java.util.Random;

import org.w3c.dom.Document;
import static org.custommonkey.xmlunit.XMLAssert.assertXpathEvaluatesTo;

/**
 * Filename:    $RCSfile: AuditDataSource_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-11 17:43:58 $
 *
 * @author rrmall
 * @version $Revision: 1.4 $
 */
public class AuditDataSource_AT extends EISTestCase {
 public void testGetData_ProjectIsNotInDetailedDesignState_ChangesListReturnedIsEmpty() throws Exception {
    Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
    MockUCCHelper helper = new MockUCCHelper(null);
   Projects project = equipment.getProjects();
   helper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, equipment.getId());
//   helper.setRequestParameterValue(EISConstants.PROJECT_ID, "377150");
//    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "486550");
    AuditDataSource dataSource = new AuditDataSource(helper);
    List<? extends XmlObject> data = dataSource.getData("oldValue", "desc", 0, 25);
    assertEquals(0, data.size());
  }

  public void testGetData_ProjectIsInDetailedDesignStateAndEquipmentHasChangesInIt_ChangesListIsReturned() throws Exception {
//    Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
//    HibernateFactory hibernate = EISHibernateUtil.getHibernateFactory();
//    hibernate.beginTransaction();
//    Projects project = equipment.getProjects();
//    project.setProjStatus(new ProjectStatus(new Long(2), "Detailed Design"));
//    ProjectsDAO  projDao = new ProjectsDAOImpl();
//    projDao.save(project);
//    hibernate.commitTransaction();
//
//    hibernate.beginTransaction();
//    equipment.setDescription("Test updated this description");
//    EquipmentDAO equipmentDao = new EquipmentDAOImpl();
//    equipmentDao.save(equipment);
//    hibernate.commitTransaction();
//    hibernate.beginTransaction();
//
//    MockUCCHelper helper = new MockUCCHelper(null);
//    helper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
//    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, equipment.getId());
//
//    AuditDataSource dataSource = new AuditDataSource(helper);
//
//    List<? extends XmlObject> data = dataSource.getData("oldValue", "desc", 0, 0);
//    assertEquals(4, data.size());
//    ChangeHistory change = (ChangeHistory) data.get(0);
//    Document xmlDoc = DOMUtil.stringToXML(change.toXml());
//    assertXpathEvaluatesTo("364775", "//changeHistory/auditDetailId", xmlDoc);
//    assertXpathEvaluatesTo("364749", "//changeHistory/auditTransactionId", xmlDoc);
//    assertXpathEvaluatesTo("Instrument", "//changeHistory/tableName", xmlDoc);
//    assertXpathEvaluatesTo("description", "//changeHistory/columnName", xmlDoc);
//    assertXpathEvaluatesTo("22", "//changeHistory/oldValue", xmlDoc);
//    assertXpathEvaluatesTo("33", "//changeHistory/newValue", xmlDoc);
//    assertXpathEvaluatesTo("true", "//changeHistory/processVerified", xmlDoc);
//    assertXpathEvaluatesTo("true", "//changeHistory/mechanicalVerified", xmlDoc);
//    assertXpathEvaluatesTo("true", "//changeHistory/electricalVerified", xmlDoc);
//    assertXpathEvaluatesTo("/eis/data/equipment?method=updateVerificationForEquipmentChange&auditDetailId=1&auditTransactionId=4", "//changeHistory/updateUserVerifiedUrl", xmlDoc);
  }
}