/*
 AuditDataSource_UT was created on Jan 23, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.audit.service.MockAuditServiceImpl;
import com.monsanto.eas.eis.audit.domain.ChangeHistory;
import com.monsanto.eas.eis.projects.mocks.MockEquipmentServiceImpl;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.controller.DataSource;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: AuditDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-19 21:12:10 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class AuditDataSource_UT extends TestCase {

  public AuditDataSource_UT(String name) {
    super(name);
  }

  public void testGetData_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockAuditServiceImpl auditService = new MockAuditServiceImpl();
    MockEquipmentServiceImpl equipmentService = new MockEquipmentServiceImpl();
    AuditDataSource ds = new AuditDataSource(helper, auditService, equipmentService);
    List data = ds.getData("columnName", "desc", 0, 0);
    assertEquals(2, data.size());

    ChangeHistory change = (ChangeHistory)data.get(0);
    assertEquals(new Long(1), change.getAuditDetailId());
    assertEquals("description", change.getColumnName());
    assertEquals("22", change.getOldValue());
    assertEquals("33", change.getNewValue());
    assertEquals("RRMALL", change.getAuditRequestor());
    assertEquals(new Long(4), change.getTransactionId());
    assertEquals("EIS_EQUIPMENT", change.getTabName());

    change = (ChangeHistory)data.get(1);
    assertEquals(new Long(2), change.getAuditDetailId());
    assertEquals("comments", change.getColumnName());
    assertEquals("equipment works", change.getOldValue());
    assertEquals("equipment works fine", change.getNewValue());
    assertEquals("RRMALL", change.getAuditRequestor());
    assertEquals(new Long(4), change.getTransactionId());
    assertEquals("EIS_EQUIPMENT", change.getTabName());
  }

  public void testGetTotalRecords_ReturnsUnknownResultCount() throws Exception {
     MockUCCHelper helper = new MockUCCHelper(null);
     helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
     helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
     MockAuditServiceImpl auditService = new MockAuditServiceImpl();
     MockEquipmentServiceImpl equipmentService = new MockEquipmentServiceImpl();
     AuditDataSource ds = new AuditDataSource(helper, auditService, equipmentService);
     int records = ds.getTotalRecords();
     assertEquals(DataSource.UNKNOWN_RECORD_COUNT, records);
   }

    public void testGetData_SortKeyIsColumnName_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    MockAuditServiceImpl auditService = new MockAuditServiceImpl();
    MockEquipmentServiceImpl equipmentService = new MockEquipmentServiceImpl();
    AuditDataSource ds = new AuditDataSource(helper, auditService, equipmentService);
    List data = ds.getData("columnName", "desc", 0, 0);
    int records = ds.getTotalRecords();
    assertEquals(2, records);
    ChangeHistory change = (ChangeHistory)data.get(0);
    assertEquals("description", change.getColumnName());
    change = (ChangeHistory)data.get(1);
    assertEquals("comments", change.getColumnName());  
  }
}