/*
 AuditDetail was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.domain;

import junit.framework.TestCase;
import org.w3c.dom.Document;
import static org.custommonkey.xmlunit.XMLAssert.assertXpathEvaluatesTo;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * Filename:    $RCSfile: AuditDetail_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-05 16:16:30 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class AuditDetail_UT extends TestCase {

  public void testCreateAuditDetail() throws Exception {
    AuditDetail detail = new AuditDetail(new Long(1), new AuditHeader(), "CROP_NAME", "John Doe", "Jane Doe");
    assertNotNull(detail);
    assertEquals(new Long(1), detail.getId());
    assertEquals("CROP_NAME", detail.getColumn_name());
    assertEquals("John Doe", detail.getOld_value());
    assertEquals("Jane Doe", detail.getNew_value());
  }

  public void testToXML() throws Exception {
    AuditDetail detail = new AuditDetail(new Long(1), new AuditHeader(), "CROP_NAME", "John Doe", "Jane Doe");
    assertNotNull(detail);
    Document xmlDoc = DOMUtil.stringToXML(detail.toXml());
    assertXpathEvaluatesTo("CROP_NAME", "//auditDetail/columnName", xmlDoc);
    assertXpathEvaluatesTo("John Doe", "//auditDetail/oldValue", xmlDoc);
    assertXpathEvaluatesTo("Jane Doe", "//auditDetail/newValue", xmlDoc);
  }
}