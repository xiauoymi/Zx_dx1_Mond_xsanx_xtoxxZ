/*
 AuditHeader_UT was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.domain;

import junit.framework.TestCase;

import java.util.Calendar;

/**
 * Filename:    $RCSfile: AuditHeader_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-01-27 18:27:32 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class AuditHeader_UT extends TestCase {
  public void testCreateAuditHeader() throws Exception {
    Calendar calendar = Calendar.getInstance();
    AuditHeader header = new AuditHeader(new Long(1), "U", calendar.getTime(), "EQUIPMENT_TYPE", "222", new AuditTransaction());
    assertNotNull(header);
    assertEquals(new Long(1), header.getId());
    assertEquals("U", header.getOperation_type());
    assertEquals("EQUIPMENT_TYPE", header.getTable_name());
    assertEquals("222", header.getKeyForTable());
    assertEquals(calendar.getTime(), header.getChangeDateTime());
  }
}