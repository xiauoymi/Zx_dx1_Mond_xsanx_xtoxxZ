/*
 AuditTransactionApproval was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.domain;

import junit.framework.TestCase;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.projects.domain.Equipment;

import java.util.Date;

/**
 * Filename:    $RCSfile: AuditTransactionApproval_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 15:31:30 $
 *
 * @author rrmall
 * @version $Revision: 1.3 $
 */
public class AuditTransactionApproval_UT extends TestCase {
  public void testCreateAuditTransactionApproval_ObjectCreated() throws Exception {
    AuditTransaction transaction = new AuditTransaction();
    transaction.setId(new Long(11));
    AuditDetail auditDetail = new AuditDetail();
    auditDetail.setId(new Long(22));
    Equipment equipment = new Equipment();
    equipment.setId(new Long(33));
    AuditTransactionApproval tranApproval = new AuditTransactionApproval(new Long(1), transaction, auditDetail, null, null, null,
        equipment, new Date(2009,1,22), "TEST COLUMN");
    assertNotNull(tranApproval);
    assertEquals(new Long(1), tranApproval.getId());
    assertEquals(new Long(11), tranApproval.getTransaction().getId());
    assertEquals(new Long(22), tranApproval.getDetail().getId());
    assertEquals(new Long(33), tranApproval.getEquipment().getId());
    assertEquals(new Date(2009,1,22), tranApproval.getChangeDateTime());
    assertNotNull("TEST COLUMN", tranApproval.getColumnName());
    assertNull(tranApproval.getProcessApprover());
    assertNull(tranApproval.getMechanicalApprover());
    assertNull(tranApproval.getElectricalApprover());
  }
}