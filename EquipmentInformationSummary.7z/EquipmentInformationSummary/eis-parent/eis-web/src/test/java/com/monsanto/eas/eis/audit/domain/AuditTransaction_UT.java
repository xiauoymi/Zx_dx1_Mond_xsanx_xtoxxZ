/*
 Transaction_UT was created on Dec 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.domain;

import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: AuditTransaction_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-01-27 18:27:32 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class AuditTransaction_UT extends TestCase {

  public void testCreateTransactionObject() throws Exception {
    AuditTransaction transaction = new AuditTransaction();
    AuditHeader header = new AuditHeader();
    List<AuditHeader> headers = new ArrayList<AuditHeader> ();
    headers.add(header);
    transaction.setHeaders(headers);
    transaction.setAudit_requestor("RRMALL");
    assertNotNull(transaction);
    assertEquals("RRMALL", transaction.getAudit_requestor());
    assertEquals(1, transaction.getHeaders().size());
  }
}