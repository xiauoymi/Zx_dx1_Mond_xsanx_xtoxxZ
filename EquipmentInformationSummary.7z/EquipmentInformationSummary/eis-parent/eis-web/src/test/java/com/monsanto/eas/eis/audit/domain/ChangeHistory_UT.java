/*
 ChangeHistory_UT was created on Jan 27, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.domain;

import junit.framework.TestCase;
import com.monsanto.eas.eis.projects.domain.DesignCapacityUnit;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import static org.custommonkey.xmlunit.XMLAssert.assertXpathEvaluatesTo;

import java.util.Date;
import java.sql.Timestamp;

/**
 * Filename:    $RCSfile: ChangeHistory_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 15:31:30 $
 *
 * @author rrmall
 * @version $Revision: 1.3 $
 */
public class ChangeHistory_UT extends TestCase {

  public void testCreateChangeHistoryObject_ReturnsNewObject() throws Exception {
    ChangeHistory change = new ChangeHistory();
    assertNotNull(change);
  }
  public void testToXml_VerifyXml() throws Exception {
    Object[] result = new Object[20];
    createNewDBResultObject(result);
    ChangeHistory change = new ChangeHistory(result);
    Document xmlDoc = DOMUtil.stringToXML(change.toXml());
    assertXpathEvaluatesTo("1", "//changeHistory/auditDetailId", xmlDoc);
    assertXpathEvaluatesTo("4", "//changeHistory/auditTransactionId", xmlDoc);
    assertXpathEvaluatesTo("Details", "//changeHistory/tabName", xmlDoc);
    assertXpathEvaluatesTo("1.2.345VA", "//changeHistory/componentNumber", xmlDoc);
    assertXpathEvaluatesTo("description", "//changeHistory/columnName", xmlDoc);
    assertXpathEvaluatesTo("22", "//changeHistory/oldValue", xmlDoc);
    assertXpathEvaluatesTo("33", "//changeHistory/newValue", xmlDoc);
    assertXpathEvaluatesTo("true", "//changeHistory/processVerified", xmlDoc);
    assertXpathEvaluatesTo("true", "//changeHistory/mechanicalVerified", xmlDoc);
    assertXpathEvaluatesTo("true", "//changeHistory/electricalVerified", xmlDoc);
    assertXpathEvaluatesTo("/eis/data/equipment/details?method=updateVerificationForEquipmentChange&auditDetailId=1&auditTransactionId=4", "//changeHistory/updateUserVerifiedUrl", xmlDoc);
  }

  public void testToXml_NullValues_VerifyXml() throws Exception {
    Object[] result = new Object[20];
    createNewDBResultObject(result);
    result[8]=null;
    result[9]=null;
    result[10]=null;
      ChangeHistory change = new ChangeHistory(result);
    Document xmlDoc = DOMUtil.stringToXML(change.toXml());
    assertXpathEvaluatesTo("1", "//changeHistory/auditDetailId", xmlDoc);
    assertXpathEvaluatesTo("4", "//changeHistory/auditTransactionId", xmlDoc);
    assertXpathEvaluatesTo("Details", "//changeHistory/tabName", xmlDoc);
    assertXpathEvaluatesTo("Dec 31, 1969", "//changeHistory/changeDateTime", xmlDoc);
    assertXpathEvaluatesTo("1.2.345VA", "//changeHistory/componentNumber", xmlDoc);
    assertXpathEvaluatesTo("description", "//changeHistory/columnName", xmlDoc);
    assertXpathEvaluatesTo("22", "//changeHistory/oldValue", xmlDoc);
    assertXpathEvaluatesTo("33", "//changeHistory/newValue", xmlDoc);
    assertXpathEvaluatesTo("false", "//changeHistory/processVerified", xmlDoc);
    assertXpathEvaluatesTo("false", "//changeHistory/mechanicalVerified", xmlDoc);
    assertXpathEvaluatesTo("false", "//changeHistory/electricalVerified", xmlDoc);
    assertXpathEvaluatesTo("/eis/data/equipment/details?method=updateVerificationForEquipmentChange&auditDetailId=1&auditTransactionId=4", "//changeHistory/updateUserVerifiedUrl", xmlDoc);
  }

  public void testToXml_DateReturnedIsNull_VerifyXml() throws Exception {
    Object[] result = new Object[20];
    createNewDBResultObject(result);
    result[4]=null;
    ChangeHistory change = new ChangeHistory(result);
    Document xmlDoc = DOMUtil.stringToXML(change.toXml());
    assertXpathEvaluatesTo("1", "//changeHistory/auditDetailId", xmlDoc);
    assertXpathEvaluatesTo("4", "//changeHistory/auditTransactionId", xmlDoc);
    assertXpathEvaluatesTo("Details", "//changeHistory/tabName", xmlDoc);
    assertXpathEvaluatesTo("1.2.345VA", "//changeHistory/componentNumber", xmlDoc);
    assertXpathEvaluatesTo("", "//changeHistory/changeDateTime", xmlDoc);
    assertXpathEvaluatesTo("description", "//changeHistory/columnName", xmlDoc);
    assertXpathEvaluatesTo("22", "//changeHistory/oldValue", xmlDoc);
    assertXpathEvaluatesTo("33", "//changeHistory/newValue", xmlDoc);
    assertXpathEvaluatesTo("true", "//changeHistory/processVerified", xmlDoc);
    assertXpathEvaluatesTo("true", "//changeHistory/mechanicalVerified", xmlDoc);
    assertXpathEvaluatesTo("true", "//changeHistory/electricalVerified", xmlDoc);
    assertXpathEvaluatesTo("/eis/data/equipment/details?method=updateVerificationForEquipmentChange&auditDetailId=1&auditTransactionId=4", "//changeHistory/updateUserVerifiedUrl", xmlDoc);
  }

  private void createNewDBResultObject(Object[] result) {
    result[0] = new Long("1");
    result[1] = "description";
    result[2] = "22";
    result[3] = "33";
    result[4] = new Timestamp(1234L);
    result[5] = "RRMALL";
    result[6] =  new Long("4");
    result[7] = "Details";
    result[8] = "SSCLIN";
    result[9] = "SSCLIN";
    result[10] = "SSCLIN";
    result[11] = "1.2.345VA";
  }
}