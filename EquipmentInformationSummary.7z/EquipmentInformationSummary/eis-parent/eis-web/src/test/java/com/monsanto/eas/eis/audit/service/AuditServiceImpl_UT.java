/*
 AuditServiceImpl_UT was created on Jan 27, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.service;

import junit.framework.TestCase;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.domain.Process;
import com.monsanto.eas.eis.projects.mocks.MockEquipmentServiceImpl;
import com.monsanto.eas.eis.audit.dao.mock.MockAuditDetailDao;
import com.monsanto.eas.eis.audit.dao.mock.MockAuditTransactionDao;
import com.monsanto.eas.eis.audit.dao.mock.MockAuditTransactionApprovalDao;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateFactoryForReports;
import com.monsanto.eas.eis.audit.domain.ChangeHistory;
import com.monsanto.eas.eis.audit.domain.AuditTransactionApproval;
import com.monsanto.eas.eis.audit.domain.AuditDetail;
import com.monsanto.eas.eis.logon.hibernateMappings.User;

import java.util.*;
import java.sql.Timestamp;

/**
 * Filename:    $RCSfile: AuditServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-23 19:25:15 $
 *
 * @author rrmall
 * @version $Revision: 1.7 $
 */
public class AuditServiceImpl_UT extends TestCase {
  private Long id;

  public void testCreate() throws Exception {
    AuditService service = new AuditServiceImpl();
    assertNotNull(service);
  }

  public void testLookupAuditEntriesByCriteria_ReturnsList() throws Exception {
    MockAuditDetailDao detailDao = new MockAuditDetailDao(new MockHibernateFactoryForReports(getGetListWithDataInCorrectSortOrder()));
    MockAuditTransactionDao transactionDao = new MockAuditTransactionDao();
    MockAuditTransactionApprovalDao approvalDao = new MockAuditTransactionApprovalDao();
    AuditService service = new AuditServiceImpl(detailDao, transactionDao, approvalDao);
    MockEquipmentServiceImpl equipmentService = new MockEquipmentServiceImpl();
    int startIndex = 0;
    int maxResults = 25;
    PaginatedResult list = service.lookupChangeHistoryByCriteria("1", equipmentService.lookupEquipment(new Long(2)), "testser", "columnName", "asc",
        startIndex, maxResults);
    assertEquals(2, list.getData().size());
    ChangeHistory change = (ChangeHistory)list.getData().get(0);
    assertEquals(new Long(1), change.getAuditDetailId());
    assertEquals("description", change.getColumnName());
    assertTrue(approvalDao.getWasApprovalEntrySaveCalled());
  }

  public void testupdateProcessVerifiedForEquipmentChange_ReturnsList() throws Exception {
    MockAuditDetailDao detailDao = new MockAuditDetailDao(new MockHibernateFactoryForReports(getGetListWithDataInCorrectSortOrder()));
    MockAuditTransactionDao transactionDao = new MockAuditTransactionDao();
    MockAuditTransactionApprovalDaoForVerification approvalDao = new MockAuditTransactionApprovalDaoForVerification();
    AuditService service = new AuditServiceImpl(detailDao, transactionDao, approvalDao);
    service.updateVerificationForEquipmentChange("1", "2", "processVerified", new User(new Long(1), "RRMALL", null, null, null,
        null));
    assertTrue(approvalDao.getWasEntrySaved());
  }
  
   public void testupdateMechanicalVerifiedForEquipmentChange_ReturnsList() throws Exception {
    MockAuditDetailDao detailDao = new MockAuditDetailDao(new MockHibernateFactoryForReports(getGetListWithDataInCorrectSortOrder()));
    MockAuditTransactionDao transactionDao = new MockAuditTransactionDao();
    MockAuditTransactionApprovalDaoForVerification approvalDao = new MockAuditTransactionApprovalDaoForVerification();
    AuditService service = new AuditServiceImpl(detailDao, transactionDao, approvalDao);
    service.updateVerificationForEquipmentChange("1", "2", "mechanicalVerified", new User(new Long(1), "RRMALL", null, null,
        null, null));
    assertTrue(approvalDao.getWasEntrySaved());
  }

  public void testupdateElectricalVerifiedForEquipmentChange_ReturnsList() throws Exception {
    MockAuditDetailDao detailDao = new MockAuditDetailDao(new MockHibernateFactoryForReports(getGetListWithDataInCorrectSortOrder()));
    MockAuditTransactionDao transactionDao = new MockAuditTransactionDao();
    MockAuditTransactionApprovalDaoForVerification approvalDao = new MockAuditTransactionApprovalDaoForVerification();
    AuditService service = new AuditServiceImpl(detailDao, transactionDao, approvalDao);
    service.updateVerificationForEquipmentChange("1", "2", "electricalVerified", new User(new Long(1), "RRMALL", null, null,
        null, null));
    assertTrue(approvalDao.getWasEntrySaved());
  }

   public void testInsertChangeHistoryIntoApprovalTableForAllProjectsThatAUserBelongsTo() throws Exception {
     MockAuditDetailDao detailDao = new MockAuditDetailDao(new MockHibernateFactoryForReports(new ArrayList()));
     MockAuditTransactionDao transactionDao = new MockAuditTransactionDao();
     MockAuditTransactionApprovalDao approvalDao = new MockAuditTransactionApprovalDao(new MockHibernateFactoryForReports(getGetDataForApproval()));
     AuditService service = new AuditServiceImpl(detailDao, transactionDao, approvalDao);
     Projects project = getProjectWithEquipments();
     service.insertChangeHistoryEntriesForEachProject(project);
     assertTrue(detailDao.isWasFindByPrimaryKeyCalled());
     assertTrue(approvalDao.getWasApprovalEntrySaveCalled());
  }

  private Projects getProjectWithEquipments(){
    Projects p  = new Projects();
    p.setId(new Long(1));
   Location region = new Location();
    Location country = new Location();
    Location countryCanada = new Location();

    Location state = new Location();
    Location stateTexas = new Location();


    Location city = new Location();
    Location cityBoston = new Location();

    region.setId(new Long(1));
    region.setName("North America");


    country.setId(2L);
    countryCanada.setId(22L);
    country.setName("USA");
    countryCanada.setName("Canada");
    country.setParentLocation(region);
    countryCanada.setParentLocation(region);
    region.addChildLocation(country);
    region.addChildLocation(country);


    state.setId(3L);
    stateTexas.setId(33L);
    state.setName("AL");
    stateTexas.setName("TX");
    state.setParentLocation(country);
    stateTexas.setParentLocation(country);
    country.addChildLocation(state);
    country.addChildLocation(stateTexas);

    city.setId(4L);
    cityBoston.setId(44L);
    city.setName("Abbeville");
    cityBoston.setName("Boston");
    city.setParentLocation(state);
    cityBoston.setParentLocation(state);
    state.addChildLocation(city);
    state.addChildLocation(cityBoston);


      List<Equipment> equipmentList = new ArrayList<Equipment>();
      p.setProjName("ForEquipmentList");
      Equipment equipment = new Equipment();
      equipment.setId(1L);
      equipment.setEquipmentNumber("E001");
      equipment.setName("Equipment1");
      equipment.setDescription("Equipment 1");
      Area area = new Area();
      area.setId(1L);
      area.setAreaCode("1");
      equipment.setArea(area);
      equipmentList.add(equipment);
      EquipmentType equipmentType = new EquipmentType(1L, "parent", "p");
      EquipmentType subType1 = new EquipmentType(1L, "parent", "p");
      equipment.setEquipmentType(equipmentType);
      equipment.setSubTypeOne(subType1);
      p.setEquipments(equipmentList);
      Process process = new Process();
      process.setId(new Long(2));
      process.setEquipment(equipment);
      equipment.setProcess(process);
      Purchasing purchasing = new Purchasing();
      purchasing.setId(new Long(2));
      purchasing.setEquipment(equipment);
      equipment.setPurchasing(purchasing);
      Mechanical mechanical = new Mechanical();
      mechanical.setId(new Long(3));
      mechanical.setEquipment(equipment);
      equipment.setMechanical(mechanical);
      CostSchedule cost = new CostSchedule();
      cost.setId(new Long(4));
      equipment.setCostSchedule(cost);
      Electrical electrical = new Electrical();
      electrical.setId(new Long(5));
      electrical.setEquipment(equipment);
      equipment.setElectrical(electrical);
      cost.setEquipment(equipment);
      Set<Motor> motorSet = new HashSet<Motor>();
      Set<Instrument> instrumentSet = new HashSet<Instrument>();
      Set<Accessory> accessorySet = new HashSet<Accessory>();
      equipment.setMotors(motorSet);
      equipment.setInstruments(instrumentSet);
      equipment.setAccessories(accessorySet);
       equipment.setProjects(p);
      return p;
  }

  public List getGetListWithDataInCorrectSortOrder() {
      Object[] result = new Object[20];
        List<Object[]> changeHistoryList = new ArrayList<Object[]>();
        result[0] = new Long("1");
        result[1] = "description";
        result[2] = "22";
        result[3] = "33";
        result[4] = new Timestamp(1234L);
        result[5] = "RRMALL";
        result[6] =  new Long("4");
        result[7] = "EIS_EQUIPMENT";
        result[8] = null;
        result[9] = null;
        result[10] = "SSCLIN";
        result[11] = "description";
        changeHistoryList.add(result);
        result = new Object[20];
        result[0] = new Long("2");
        result[1] = "comments";
        result[2] = "equipment works";
        result[3] = "equipment works fine";
        result[4] = new Timestamp(5678L);
        result[5] = "RRMALL";
        result[6] =  new Long("4");
        result[7] = "EIS_EQUIPMENT";
        result[8] = null;
        result[9] = null;
        result[10] = null;
        result[11] = "comments";
        changeHistoryList.add(result);
    return changeHistoryList;
  }

  public List getGetDataForApproval() {
    List<Object[]> list = new ArrayList<Object[]>();
    Object[] result = new Object[5];
    result[0] = new Long(1);
    result[1] = new Long(2);
    result[2] = new Timestamp(1234L);
    result[3] = new String("NAME");
    list.add(result);
    result = new Object[5];
    result[0] = new Long(3);
    result[1] = new Long(4);
    result[2] = new Timestamp(5678L);
    result[3] = new String("DESCRIPTION");
    list.add(result);
    return list;
  }

  private class MockAuditTransactionApprovalDaoForVerification extends MockAuditTransactionApprovalDao {
    private boolean wasEntrySaved = false;

    public List<AuditTransactionApproval> findByCriteria(String id, Long auditDetailId, Long auditTransactionId) {
      List<AuditTransactionApproval> approvalList = new ArrayList<AuditTransactionApproval>();
      AuditTransactionApproval approval = new AuditTransactionApproval(new Long(1), null, new AuditDetail(new Long(2), null, "description", "oldValue", "newValue"),
          null, null, null, null, null, null);
      approval = new AuditTransactionApproval(new Long(1), null, new AuditDetail(new Long(3), null, "comments", "oldChange", "newChange"),
          null, null, null, null, null, null);
      approvalList.add(approval);
      return approvalList;
    }

    public AuditTransactionApproval save(AuditTransactionApproval approval) {
      wasEntrySaved = true;
      return approval;
    }

    public boolean getWasEntrySaved() {
      return wasEntrySaved;
    }
  }
}