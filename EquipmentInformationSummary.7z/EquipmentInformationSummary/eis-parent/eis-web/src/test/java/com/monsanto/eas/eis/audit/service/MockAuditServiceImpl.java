/*
 MockAuditServiceImpl was created on Jan 23, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.audit.service;

import com.monsanto.eas.eis.audit.service.AuditService;
import com.monsanto.eas.eis.audit.domain.ChangeHistory;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.logon.hibernateMappings.User;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.sql.Timestamp;

/**
 * Filename:    $RCSfile: MockAuditServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 15:31:30 $
 *
 * @author rrmall
 * @version $Revision: 1.6 $
 */
public class MockAuditServiceImpl implements AuditService {
  private Object[] result = null;
  private boolean wasUpdateVerificationForEquipmentChangeCalled = false;

  public PaginatedResult lookupChangeHistoryByCriteria(String projectId, Equipment equipment, String userId,
                                                       String sortKey, String sortDir, int startIndex, int maxResults) {
    List<ChangeHistory> changeHistoryList= createChangeHistoryEntry();
    return new PaginatedResult(changeHistoryList.size(), changeHistoryList);
  }

  private List<ChangeHistory> createChangeHistoryEntry() {
    List<ChangeHistory> changeHistoryList = new ArrayList<ChangeHistory>();
    result = new Object[20];
    result[0] = new Long("1");
    result[1] = "description";
    result[2] = "22";
    result[3] = "33";
    result[4] = new Timestamp(1234L);
    result[5] = "RRMALL";
    result[6] =  new Long("4");
    result[7] = "EIS_EQUIPMENT";
    result[8] = "SSCLIN";
    result[9] = "SSCLIN";
    result[10] = "SSCLIN";
    result[11] = "description";
    changeHistoryList.add(new ChangeHistory(result));
    result[0] = new Long("2");
    result[1] = "comments";
    result[2] = "equipment works";
    result[3] = "equipment works fine";
    result[4] = new Timestamp(5678L);
    result[5] = "RRMALL";
    result[6] =  new Long("4");
    result[7] = "EIS_EQUIPMENT";
    result[8] = "SSCLIN";
    result[9] = "SSCLIN";
    result[10] = "SSCLIN";
    result[11] = "comments";
    changeHistoryList.add(new ChangeHistory(result));
    return changeHistoryList;
  }

  public void updateVerificationForEquipmentChange(String detailId, String tranId, String changeVerifiedColumn,
                                                   User user) {
    wasUpdateVerificationForEquipmentChangeCalled = true;
  }

  public PaginatedResult getListOfChangesNotApprovedForAnEquipment(String projectId, String userId,
                                                                   String sortKey, String sortDir, int startIndex,
                                                                   int maxResults) {
    return null;
  }

  public boolean getWasUpdateVerificationForEquipmentChangeCalled() {
    return wasUpdateVerificationForEquipmentChangeCalled;
  }

  public void insertChangeHistoryEntriesForEachProject(Projects project) {
  }
}