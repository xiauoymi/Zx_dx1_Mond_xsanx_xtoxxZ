/*
 AutosaveController_AT was created on Dec 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.autosave;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.eas.eis.projects.Projects_AT_TestCaseHelper;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;

/**
 * Filename:    $RCSfile: AutosaveController_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-23 20:43:28 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class AutosaveController_AT extends EISTestCase {

  public void testAutosaveField() throws Exception {
    Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "autosaveField");
    helper.setRequestParameterValue("className", "motor");
    helper.setRequestParameterValue("primaryKey", equipment.getMotors().iterator().next().getId());
    helper.setRequestParameterValue("fieldName", "motorVoltage");
    helper.setRequestParameterValue("fieldValue", "23");
    assertEquals(new Integer(200), equipment.getMotors().iterator().next().getMotorVoltage());

    AutosaveController controller = new AutosaveController();
    controller.run(helper);

    GenericDAO<Equipment, Long> dao = new HibernateDAO<Equipment, Long>(EISHibernateUtil.getHibernateFactory(),
        Equipment.class);
    Equipment updatedEquipment = dao.findByPrimaryKey(equipment.getId());
    assertEquals(new Integer(23), updatedEquipment.getMotors().iterator().next().getMotorVoltage());    
  }
}