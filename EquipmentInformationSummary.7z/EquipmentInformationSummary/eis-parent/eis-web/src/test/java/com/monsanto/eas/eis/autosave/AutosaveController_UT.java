/*
 AutosaveController_UT was created on Dec 9, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.autosave;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.equipment.service.ProcessServiceImpl;
import com.monsanto.eas.eis.equipment.service.ProcessService;
import com.monsanto.eas.eis.equipment.service.mock.MockProcessService;
import com.monsanto.wst.hibernate.mock.MockDAO;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: AutosaveController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-01-23 14:43:36 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class AutosaveController_UT extends TestCase {
//  public void testStartAutosaveSession() throws Exception {
//    MockUCCHelper helper = new MockUCCHelper(null);
//    helper.setRequestParameterValue("method", "startAutosaveSession");
//    AutosaveController controller = new AutosaveController();
//    controller.run(helper);
//  }

  public void testAutosaveField_FieldIsInteger_VerifyObject() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "autosaveField");
    helper.setRequestParameterValue("className", "accessory");
    helper.setRequestParameterValue("primaryKey", "123");
    helper.setRequestParameterValue("fieldName", "quantity");
    helper.setRequestParameterValue("fieldValue", "23");
    List<Object> list = new ArrayList<Object>();
    Accessory accessory = new Accessory();
    accessory.setId(new Long(123));
    list.add(accessory);
    list.add(new Accessory());
    AutosaveControllerOverridesHibenateDao controller = new AutosaveControllerOverridesHibenateDao(list);
    controller.run(helper);
    assertEquals("ok", helper.getResponse().toString());
    MockDAOOverridesSave dao = controller.getDao();
    assertTrue(dao.wasFindByPrimaryKeyCalled());
    Object savedObject = dao.getSavedObject();
    assertEquals(Projects.class.getPackage().getName() + "." + "Accessory",
        savedObject.getClass().getName().toString());
    Accessory acce = (Accessory) savedObject;
    assertEquals(new Long(123), acce.getId());
    assertEquals(new Integer(23), acce.getQuantity());
  }

  public void testAutosaveField_FieldIsbooleanTrue_VerifyObject() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "autosaveField");
    helper.setRequestParameterValue("className", "instrument");
    helper.setRequestParameterValue("primaryKey", "234");
    helper.setRequestParameterValue("fieldName", "purchasedWithEquipment");
    helper.setRequestParameterValue("fieldValue", "true");
    List<Object> list = new ArrayList<Object>();
    Instrument instrument = new Instrument();
    instrument.setId(new Long(234));
    list.add(instrument);
    list.add(new Instrument());
    AutosaveControllerOverridesHibenateDao controller = new AutosaveControllerOverridesHibenateDao(list);
    controller.run(helper);
    MockDAOOverridesSave dao = controller.getDao();
    assertTrue(dao.wasFindByPrimaryKeyCalled());
    Object savedObject = dao.getSavedObject();
    assertEquals(Projects.class.getPackage().getName() + "." + "Instrument",
        savedObject.getClass().getName().toString());
    Instrument inst = (Instrument) savedObject;
    assertEquals(new Long(234), inst.getId());
    assertTrue(inst.isPurchasedWithEquipment());
  }

  public void testAutosaveField_FieldIsbooleanY_VerifyObject() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "autosaveField");
    helper.setRequestParameterValue("className", "instrument");
    helper.setRequestParameterValue("primaryKey", "234");
    helper.setRequestParameterValue("fieldName", "purchasedWithEquipment");
    helper.setRequestParameterValue("fieldValue", "Y");
    List<Object> list = new ArrayList<Object>();
    Instrument instrument = new Instrument();
    instrument.setId(new Long(234));
    list.add(instrument);
    list.add(new Instrument());
    AutosaveControllerOverridesHibenateDao controller = new AutosaveControllerOverridesHibenateDao(list);
    controller.run(helper);
    MockDAOOverridesSave dao = controller.getDao();
    assertTrue(dao.wasFindByPrimaryKeyCalled());
    Object savedObject = dao.getSavedObject();
    assertEquals(Projects.class.getPackage().getName() + "." + "Instrument",
        savedObject.getClass().getName().toString());
    Instrument inst = (Instrument) savedObject;
    assertEquals(new Long(234), inst.getId());
    assertTrue(inst.isPurchasedWithEquipment());
  }

  public void testAutosaveField_FieldIsbooleanFalse_VerifyObject() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "autosaveField");
    helper.setRequestParameterValue("className", "instrument");
    helper.setRequestParameterValue("primaryKey", "234");
    helper.setRequestParameterValue("fieldName", "purchasedWithEquipment");
    helper.setRequestParameterValue("fieldValue", "false");
    List<Object> list = new ArrayList<Object>();
    Instrument instrument = new Instrument();
    instrument.setId(new Long(234));
    list.add(instrument);
    list.add(new Instrument());
    AutosaveControllerOverridesHibenateDao controller = new AutosaveControllerOverridesHibenateDao(list);
    controller.run(helper);
    MockDAOOverridesSave dao = controller.getDao();
    assertTrue(dao.wasFindByPrimaryKeyCalled());
    Object savedObject = dao.getSavedObject();
    assertEquals(Projects.class.getPackage().getName() + "." + "Instrument",
        savedObject.getClass().getName().toString());
    Instrument inst = (Instrument) savedObject;
    assertEquals(new Long(234), inst.getId());
    assertFalse(inst.isPurchasedWithEquipment());
  }

  public void testAutosaveField_FieldIsLong_VerifyObject() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "autosaveField");
    helper.setRequestParameterValue("className", "instrument");
    helper.setRequestParameterValue("primaryKey", "234");
    helper.setRequestParameterValue("fieldName", "range");
    helper.setRequestParameterValue("fieldValue", "999999");
    List<Object> list = new ArrayList<Object>();
    Instrument instrument = new Instrument();
    instrument.setId(new Long(234));
    list.add(instrument);
    list.add(new Instrument());
    AutosaveControllerOverridesHibenateDao controller = new AutosaveControllerOverridesHibenateDao(list);
    controller.run(helper);
    MockDAOOverridesSave dao = controller.getDao();
    assertTrue(dao.wasFindByPrimaryKeyCalled());
    Object savedObject = dao.getSavedObject();
    assertEquals(Projects.class.getPackage().getName() + "." + "Instrument",
        savedObject.getClass().getName().toString());
    Instrument inst = (Instrument) savedObject;
    assertEquals(new Long(234), inst.getId());
    assertEquals(new Long(999999).toString(), inst.getRange());
  }

  public void testAutosaveField_FieldIsDate_VerifyObject() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "autosaveField");
    helper.setRequestParameterValue("className", "purchasing");
    helper.setRequestParameterValue("primaryKey", "234");
    helper.setRequestParameterValue("fieldName", "actualDeliveryDate");
    helper.setRequestParameterValue("fieldValue", "Dec 05, 2008");
    List<Object> list = new ArrayList<Object>();
    Purchasing purchasing = new Purchasing();
    purchasing.setId(new Long(234));
    list.add(purchasing);
    list.add(new Purchasing());
    AutosaveControllerOverridesHibenateDao controller = new AutosaveControllerOverridesHibenateDao(list);
    controller.run(helper);
    MockDAOOverridesSave dao = controller.getDao();
    assertTrue(dao.wasFindByPrimaryKeyCalled());
    Object savedObject = dao.getSavedObject();
    assertEquals(Projects.class.getPackage().getName() + "." + "Purchasing",
        savedObject.getClass().getName().toString());
    Purchasing pur = (Purchasing) savedObject;
    assertEquals(new Long(234), pur.getId());
    assertEquals("Dec 05, 2008", ConvertUtil.toString(pur.getActualDeliveryDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
  }

  public void testAutosaveField_FieldIsEmpty_Autosaved() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "autosaveField");
    helper.setRequestParameterValue("className", "instrument");
    helper.setRequestParameterValue("primaryKey", "234");
    helper.setRequestParameterValue("fieldName", "instDescription");
    helper.setRequestParameterValue("fieldValue", "");
    List<Object> list = new ArrayList<Object>();
    Instrument instrument = new Instrument();
    instrument.setId(new Long(234));
    list.add(instrument);
    list.add(new Instrument());
    AutosaveControllerOverridesHibenateDao controller = new AutosaveControllerOverridesHibenateDao(list);
    controller.run(helper);
    MockDAOOverridesSave dao = controller.getDao();
    assertTrue(dao.wasFindByPrimaryKeyCalled());
    Object savedObject = dao.getSavedObject();
    assertEquals(Projects.class.getPackage().getName() + "." + "Instrument",
        savedObject.getClass().getName().toString());
    Instrument inst = (Instrument) savedObject;
    assertEquals(new Long(234), inst.getId());
    assertNull(inst.getInstDescription());
  }

  public void testAutosaveField_FieldIsAnObject_Autosaved() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "autosaveField");
    helper.setRequestParameterValue("className", "instrument");
    helper.setRequestParameterValue("primaryKey", "234");
    helper.setRequestParameterValue("fieldName", "ioTypeId");
    helper.setRequestParameterValue("fieldValue", "12");
    List<Object> list = new ArrayList<Object>();
    Instrument instrument = new Instrument();
    instrument.setId(new Long(234));
    list.add(instrument);
    list.add(new Instrument());
    AutosaveControllerOverridesHibenateDao controller = new AutosaveControllerOverridesHibenateDao(list);
    controller.run(helper);
    MockDAOOverridesSave dao = controller.getDao();
    assertTrue(dao.wasFindByPrimaryKeyCalled());
    Object savedObject = dao.getSavedObject();
    assertEquals(Projects.class.getPackage().getName() + "." + "Instrument",
        savedObject.getClass().getName().toString());
    Instrument inst = (Instrument) savedObject;
    assertEquals(new Long(234), inst.getId());
    assertEquals(new Long(12), inst.getIoType().getId());
  }

  public void testAutosaveProcessFieldEquipmentType_PfeSaved() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "autosaveProcessFieldEquipmentType");
    helper.setRequestParameterValue("processId", "1111");
    helper.setRequestParameterValue("fieldName", "bellType");
    helper.setRequestParameterValue("fieldValue", "12");
    AutosaveControllerOverridesHibenateDao controller = new AutosaveControllerOverridesHibenateDao(null);
    controller.run(helper);
    ProcessFieldEquipmentType pfe = (ProcessFieldEquipmentType) helper.getRequestAttributeValue("pfe");
    assertEquals(new Long(4444), pfe.getId());
    assertEquals("12", pfe.getValue());
    assertEquals("ok", helper.getResponse().toString());
  }

  private class AutosaveControllerOverridesHibenateDao extends AutosaveController {
    private List<Object> list;
    private MockDAOOverridesSave dao;
    private ProcessService processService;

    private AutosaveControllerOverridesHibenateDao(List<Object> list) {
      this.list = list;
    }

    protected MockDAOOverridesSave getHibernateDao(Class<?> clazz) {
      this.dao = new MockDAOOverridesSave(list);
      return this.dao;
    }

    //protected for testing
    protected ProcessService getProcessService() {
      processService = new MockProcessService();
      return processService;
    }

    public MockDAOOverridesSave getDao() {
      return dao;
    }
  }

  private class MockDAOOverridesSave extends MockDAO<Object, Long> {
    private Object savedObject;

    public MockDAOOverridesSave(List<Object> list) {
      super(list);
    }

    public Object save(Object o) {
      this.savedObject = o;
      return o;
    }

    public Object getSavedObject() {
      return savedObject;
    }
  }
}