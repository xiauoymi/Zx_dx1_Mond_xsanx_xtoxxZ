/*
 EISController_UT was created on Sep 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.controller;

import junit.framework.TestCase;
import com.monsanto.securityinterfaces.Test.MockSystemSecurityProxySetUser;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.util.EISConstants;

import java.io.IOException;

/**
 * Filename:    $RCSfile: EISController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-09-30 17:32:03 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class EISController_UT extends TestCase {

  public void testRun_NoCacheIsSet() throws Exception {
    EISController controller = new MockEISController();
    MockUCCHelper helper = new MockUCCHelper(null);
    controller.run(helper);
    String cacheControl = helper.getHeader("Cache-Control");
    assertEquals("no-cache", cacheControl);
  }

  public void testRun_ActiveIndexIsSet() throws Exception {
    EISController controller = new MockEISController();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.ACTIVE_TAB_INDEX, "1");
    controller.run(helper);
    assertEquals("1", helper.getRequestAttributeValue(EISConstants.ACTIVE_TAB_INDEX));
  }

  private class MockEISController extends EISController {
    protected void notSpecified(UCCHelper helper) throws IOException {
    }
  }
}