/*
 MockXMLDataSource was created on Oct 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.controller;

import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Filename:    $RCSfile: MockXMLDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-15 14:28:34 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class MockXMLDataSource implements XmlDataSource {
  public static final String NUM_RECORDS = "numRecords";
  private final List<XmlObject> list;

  public MockXMLDataSource(UCCHelper helper) throws IOException {
    int numRecords = Integer.parseInt(helper.getRequestParameterValue(NUM_RECORDS));
    list = new ArrayList<XmlObject>(numRecords);
    for (int i = 0; i < numRecords; i++) {
      list.add(new MockXmlObject(i));
    }
  }

  public List<? extends XmlObject> getData(String sortKey, String sortDir, int startIndex, int maxResults) throws IOException {
    return list.subList(startIndex, startIndex + maxResults);
  }

  public int getTotalRecords() {
    return DataSource.UNKNOWN_RECORD_COUNT;
  }
}