/*
 XmlDataPaginationController_UT was created on Oct 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.HashMap;

/**
 * Filename:    $RCSfile: XmlDataPaginationController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-15 14:28:34 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class XmlDataPaginationController_UT extends XMLTestCase {
  public static final int NUM_TESTS_RECORDS = 1000;
  private static final String TOTAL_RECORDS_XPATH = "/ResultSet/totalRecords";
  private static final String OUTER_ELEMENT_XPATH = "/ResultSet";

  public void testNoDataNoResults() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    HashMap<String, String> myInitParams = new HashMap<String, String>();
    myInitParams.put(XmlDataPaginationController.DATA_SOURCE_CLASSNAME, MockXMLDataSource.class.getName());
    helper.setInitParameters(myInitParams);
    helper.setRequestParameterValue(MockXMLDataSource.NUM_RECORDS, "0");
    UseCaseController controller = new XmlDataPaginationController();
    controller.run(helper);
    Document resultDoc = helper.getXML();
    assertXpathExists(TOTAL_RECORDS_XPATH, resultDoc);
    assertXpathExists(OUTER_ELEMENT_XPATH, resultDoc);
    assertXpathNotExists(OUTER_ELEMENT_XPATH + "/mock", resultDoc);
  }

  public void testNoPagesQueriesNone() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    HashMap<String, String> myInitParams = new HashMap<String, String>();
    myInitParams.put(XmlDataPaginationController.DATA_SOURCE_CLASSNAME, MockDataSourceWithWorkDoneByDB.class.getName());
    helper.setInitParameters(myInitParams);
    helper.setRequestParameterValue(MockXMLDataSource.NUM_RECORDS, Integer.toString(NUM_TESTS_RECORDS));
    EISController controller = new XmlDataPaginationController();
    controller.run(helper);
    Document resultDoc = helper.getXML();
    assertXpathExists(TOTAL_RECORDS_XPATH, resultDoc);
    assertXpathEvaluatesTo("20", TOTAL_RECORDS_XPATH, resultDoc);
    assertXpathExists(OUTER_ELEMENT_XPATH, resultDoc);
    assertXpathNotExists(OUTER_ELEMENT_XPATH + "/mock", resultDoc);
  }

  public void testQueryFirstPage() throws Exception {
    int testRowsPerPage = 10;
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    HashMap<String, String> myInitParams = new HashMap<String, String>();
    myInitParams.put(XmlDataPaginationController.DATA_SOURCE_CLASSNAME, MockXMLDataSource.class.getName());
    helper.setInitParameters(myInitParams);
    helper.setRequestParameterValue(MockXMLDataSource.NUM_RECORDS, Integer.toString(NUM_TESTS_RECORDS));
    helper.setRequestParameterValue(XmlDataPaginationController.START_INDEX, 0);
    helper.setRequestParameterValue(XmlDataPaginationController.ROWS_PER_PAGE, testRowsPerPage);
    UseCaseController controller = new XmlDataPaginationController();
    controller.run(helper);
    Document resultDoc = helper.getXML();
    assertXpathEvaluatesTo(Integer.toString(testRowsPerPage), "count(" + OUTER_ELEMENT_XPATH + "/mock)", resultDoc);
    assertXpathExists(TOTAL_RECORDS_XPATH, resultDoc);
    assertXpathEvaluatesTo("10", TOTAL_RECORDS_XPATH, resultDoc);
    assertXpathExists(OUTER_ELEMENT_XPATH + "/mock[text()='0']", resultDoc);
    assertXpathNotExists(OUTER_ELEMENT_XPATH + "/mock[text()='25']", resultDoc);
  }

  public void testQueryOtherPage() throws Exception {
    int testRowsPerPage = 10;
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    HashMap<String, String> myInitParams = new HashMap<String, String>();
    myInitParams.put(XmlDataPaginationController.DATA_SOURCE_CLASSNAME, MockXMLDataSource.class.getName());
    helper.setInitParameters(myInitParams);
    helper.setRequestParameterValue(MockXMLDataSource.NUM_RECORDS, Integer.toString(NUM_TESTS_RECORDS));
    helper.setRequestParameterValue(XmlDataPaginationController.START_INDEX, 20);
    helper.setRequestParameterValue(XmlDataPaginationController.ROWS_PER_PAGE, testRowsPerPage);
    UseCaseController controller = new XmlDataPaginationController();
    controller.run(helper);
    Document resultDoc = helper.getXML();
    assertXpathEvaluatesTo(Integer.toString(testRowsPerPage), "count(" + OUTER_ELEMENT_XPATH + "/mock)", resultDoc);
    assertXpathNotExists(OUTER_ELEMENT_XPATH + "/mock[text()='0']", resultDoc);
    assertXpathExists(OUTER_ELEMENT_XPATH + "/mock[text()='25']", resultDoc);
  }

  public void testDifferentPageSize() throws Exception {
    int testRowsPerPage = 50;
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    HashMap<String, String> myInitParams = new HashMap<String, String>();
    myInitParams.put(XmlDataPaginationController.DATA_SOURCE_CLASSNAME, MockXMLDataSource.class.getName());
    helper.setInitParameters(myInitParams);
    helper.setRequestParameterValue(MockXMLDataSource.NUM_RECORDS, Integer.toString(NUM_TESTS_RECORDS));
    helper.setRequestParameterValue(XmlDataPaginationController.START_INDEX, 0);
    helper.setRequestParameterValue(XmlDataPaginationController.ROWS_PER_PAGE, testRowsPerPage);
    UseCaseController controller = new XmlDataPaginationController();
    controller.run(helper);
    Document resultDoc = helper.getXML();
    assertXpathEvaluatesTo(Integer.toString(testRowsPerPage), "count(" + OUTER_ELEMENT_XPATH + "/mock)", resultDoc);
    assertXpathExists(TOTAL_RECORDS_XPATH, resultDoc);
    assertXpathExists(OUTER_ELEMENT_XPATH + "/mock[text()='0']", resultDoc);
    assertXpathExists(OUTER_ELEMENT_XPATH + "/mock[text()='25']", resultDoc);
  }

  public static class MockDataSourceWithWorkDoneByDB extends MockXMLDataSource {
    public MockDataSourceWithWorkDoneByDB(UCCHelper helper) throws IOException {
      super(helper);
    }

    public int getTotalRecords() {
      return 20;
    }
  }

}