package com.monsanto.eas.eis.criteria;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 19, 2008
 * Time: 10:14:54 AM
 * To change this template use File | Settings | File Templates.
 */
public class CriteriaTestUtil {

}
