/*
 AccessoryBuilder_UT was created on Nov 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.projects.domain.Accessory;
import com.monsanto.eas.eis.projects.domain.Electrical;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Purchasing;
import com.monsanto.eas.eis.util.AccessoryConstants;
import com.monsanto.eas.eis.util.ConvertUtil;
import junit.framework.TestCase;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Filename:    $RCSfile: AccessoryBuilder_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $ On:	$Date:
 * 2008/12/16 23:47:03 $
 *
 * @author sspati1
 * @version $Revision: 1.14 $
 */
public class AccessoryBuilder_UT extends TestCase {
  public void testCreate() throws Exception {
    AccessoryBuilder builder = new AccessoryBuilder();
    assertNotNull(builder);
  }

  public void testCreateAccessoryListFromRequest_NewEquipmentNoAccessory_ReturnsEmptyList() throws Exception {
    AccessoryBuilder builder = new AccessoryBuilder();
    Equipment equipment = new Equipment();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AccessoryConstants.HAS_ACCESSORIES_DATA_CHANGED, "");
    Set<Accessory> accessories = builder.createAccessoryListFromRequest(equipment, helper);
    assertTrue(accessories.isEmpty());
  }

  public void testCreateAccessoryListFromRequest_NewEquipmentNewAccessories_ReturnsList() throws Exception {
    AccessoryBuilder builder = new AccessoryBuilder();
    Equipment equipment = new Equipment();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AccessoryConstants.HAS_ACCESSORIES_DATA_CHANGED, "true");
    setAccessoriesInHelper(helper);
    setElectricalDataInHelper(helper);
    setPurchasingDataInHelper(helper);
    Set<Accessory> accessories = builder.createAccessoryListFromRequest(equipment, helper);
    assertEquals(2, accessories.size());
    Iterator<Accessory> iterator = accessories.iterator();
    Accessory accessory1 = iterator.next();
    if (accessory1.getAccessoryName().equalsIgnoreCase("Acce Name 1")) {
      assertAccessory1(accessory1);
      assertAccessory2(iterator.next());
    } else {
      Iterator<Accessory> iterator1 = accessories.iterator();
      assertAccessory2(iterator1.next());
      assertAccessory1(iterator1.next());
    }
  }

  public void testCreateAccessoryListFromRequest_ExistingAccessoryDataHasNotChanged_ReturnList() throws Exception {
    AccessoryBuilder builder = new AccessoryBuilder();
    Equipment equipment = new Equipment();
    Set<Accessory> existingAccessories = new HashSet<Accessory>();
    Accessory accessory1 = new Accessory();
    accessory1.setId(new Long(123));
    existingAccessories.add(accessory1);
    Accessory accessory2 = new Accessory();
    accessory2.setId(new Long(234));
    existingAccessories.add(accessory2);
    equipment.setAccessories(existingAccessories);
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AccessoryConstants.HAS_ACCESSORIES_DATA_CHANGED, "");
    Set<Accessory> accessories = builder.createAccessoryListFromRequest(equipment, helper);
    assertEquals(2, accessories.size());
    assertTrue(accessories.contains(accessory1));
    assertTrue(accessories.contains(accessory2));
  }

  public void testCreateAccessoryListFromRequest_ExistingAccessoryDataHasChanged_ReturnsListExistingAccessoriesAreFlaggedAsDeleted() throws
      Exception {
    AccessoryBuilderOverridesFlaggedAsDeleted builder = new AccessoryBuilderOverridesFlaggedAsDeleted();
    Equipment equipment = new Equipment();
    Set<Accessory> existingAccessories = new HashSet<Accessory>();
    Accessory existing1 = new Accessory();
    existing1.setId(new Long(123));
    existingAccessories.add(existing1);
    Accessory existing2 = new Accessory();
    existing2.setId(new Long(124));
    existingAccessories.add(existing2);
    equipment.setAccessories(existingAccessories);
    MockUCCHelper helper = new MockUCCHelper(null);
    setAccessoriesInHelper(helper);
    setElectricalDataInHelper(helper);
    setPurchasingDataInHelper(helper);
    helper.setRequestParameterValue(AccessoryConstants.HAS_ACCESSORIES_DATA_CHANGED, "true");
    Set<Accessory> accessories = builder.createAccessoryListFromRequest(equipment, helper);
    assertEquals(2, accessories.size());
    existingAccessories = builder.getExistingAccessories();
    assertEquals(2, existingAccessories.size());
    for(Accessory acce: existingAccessories){
      assertTrue(acce.isDeleted());
    }
  }

  public void testValidateRequiredFields_VerifyList() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AccessoryConstants.ACCE_SEQUENCE_NUMBER, new String[]{"AA", "A", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_DESGINATOR_ID, new String[]{"12", "23", ""});
    AccessoryBuilder builder = new AccessoryBuilder();
    List<String> stringList = builder.validateRequiredFields(helper);
    assertEquals(3, stringList.size());
    assertEquals("Designator for row 3", stringList.get(0));
    assertEquals("Sequence Number for row 2 should be at least 2 characters long", stringList.get(1));
    assertEquals("Sequence Number for row 3", stringList.get(2));
  }

  private void assertAccessory2(Accessory accessory) {
    assertEquals(new Long(2222), accessory.getId());
    assertEquals("", accessory.getAccessoryName());
    assertNull(accessory.getAutoManual());
    assertNull(accessory.getAccessoryDesignator());
    assertEquals("", accessory.getSequenceNumber());
    assertEquals("", accessory.getAcceDescription());
    assertEquals("", accessory.getComments());
    assertTrue(accessory.isPurchasedWithEquipment());
    assertEquals(new Integer(1), accessory.getQuantity());
    assertFalse(accessory.isCompAirReqd());
    assertFalse(accessory.isGasReqd());
    assertFalse(accessory.isWaterReqd());
    assertEquals("", accessory.getUtilityFlowrate());
    assertFalse(accessory.isCompAirReqd());
    assertNull(accessory.getSize());

    Electrical electrical = accessory.getElectrical();
    assertEquals(new Long(4444), electrical.getId());
    assertFalse(electrical.isProofOfPositionReq());
    assertFalse(electrical.isSolenoidReq());
    assertFalse(electrical.isLocalPushButtonReq());
    assertNull(electrical.getInput());
    assertNull(electrical.getInputQty());
    assertNull(electrical.getOutput());
    assertNull(electrical.getOutputQty());
    assertEquals("", electrical.getHmiDisplay());
    assertNull(electrical.getOtherMeasurement());
    assertEquals("", electrical.getCommunications());
    assertNull(electrical.getVoltage());

    Purchasing purchasing = accessory.getPurchasing();
    assertEquals(new Long(3333), purchasing.getId());
    assertNull(purchasing.getVendor());
    assertNull(purchasing.getRtpNumber());
    assertNull(purchasing.getPoNumber());
    assertNull(purchasing.getLineNumber());
    assertNull(purchasing.getPoLineAmount());
//    assertNull(purchasing.getPoLineQuantity());
//    assertNull(purchasing.getPoLineValue());
    assertNull(purchasing.getCoAmount());
    assertNull(purchasing.getOriginalShipDate());
    assertNull(purchasing.getRevisedShipDate());
    assertNull(purchasing.getActualDeliveryDate());
    assertFalse(purchasing.isExportDocuments());
  }

  private void assertAccessory1(Accessory accessory) {
    assertNull(accessory.getId());
    assertEquals("Acce Name 1", accessory.getAccessoryName());
    assertEquals(new Long(11), accessory.getAutoManual().getId());
    assertEquals(new Long(13), accessory.getAccessoryDesignator().getId());
    assertEquals("15", accessory.getSequenceNumber());
    assertEquals("Acce Desc 1", accessory.getAcceDescription());
    assertEquals("Acce Comments 1", accessory.getComments());
    assertFalse(accessory.isPurchasedWithEquipment());
    assertEquals(new Integer(17), accessory.getQuantity());
    assertTrue(accessory.isCompAirReqd());
    assertTrue(accessory.isGasReqd());
    assertFalse(accessory.isWaterReqd());
    assertEquals("19", accessory.getUtilityFlowrate());
    assertTrue(accessory.isCompAirReqd());
    assertEquals(new Integer(21), accessory.getSize());

    Electrical electrical = accessory.getElectrical();
    assertNull(electrical.getId());
    assertTrue(electrical.isProofOfPositionReq());
    assertTrue(electrical.isSolenoidReq());
    assertTrue(electrical.isLocalPushButtonReq());
//    assertEquals(new Long(1), electrical.getInput().getId());
//    assertEquals(new Integer(10), electrical.getInputQty());
//    assertEquals(new Long(1), electrical.getOutput().getId());
//    assertEquals(new Integer(20), electrical.getOutputQty());
    assertEquals("HMI Display", electrical.getHmiDisplay());
    assertEquals(new Long(1), electrical.getOtherMeasurement().getId());
    assertEquals("Communications", electrical.getCommunications());
    assertEquals(new Integer(100), electrical.getVoltage());

    Purchasing purchasing = accessory.getPurchasing();
    assertNull(purchasing.getId());
    assertEquals("My Vendor", purchasing.getVendor());
    assertEquals(new Integer(123), purchasing.getRtpNumber());
    assertEquals(new Long(123), purchasing.getPoNumber());
    assertEquals(new Integer(123), purchasing.getLineNumber());
    assertNull(purchasing.getPoLineAmount());
//    assertNull(purchasing.getPoLineQuantity());
//    assertNull(purchasing.getPoLineValue());
    assertNull(purchasing.getCoAmount());
    assertNull(purchasing.getOriginalShipDate());
    assertNull(purchasing.getRevisedShipDate());
    assertEquals("Oct 29, 2008",
        ConvertUtil.toString(purchasing.getActualDeliveryDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertFalse(purchasing.isExportDocuments());
  }

  private void setPurchasingDataInHelper(MockUCCHelper helper) {
    helper.setRequestParameterValue(AccessoryConstants.ACCE_PURCHASING_ID, new String[]{"", "3333"});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_VENDOR, new String[]{"My Vendor", "This should not count"});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_RTP_NUMBER, new String[]{"123", "234"});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_PO_NUMBER, new String[]{"123", "234"});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_LINE_NUMBER, new String[]{"123", "234"});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_ACTUAL_DELIVERY_DATE,
        new String[]{"Oct 29, 2008", "Oct 29, 2009"});
  }

  private void setElectricalDataInHelper(MockUCCHelper helper) {
    helper.setRequestParameterValue(AccessoryConstants.ACCE_ELECT_ID, new String[]{"", "4444"});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_PROOF_OF_POSITION_REQUIRED, new String[]{"true", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_SOLENOID_REQUIRED, new String[]{"true", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_LOCAL_PUSH_BUTTON_REQUIRED, new String[]{"true", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_INPUT_ID, new String[]{"1", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_INPUT_QUANTITY, new String[]{"10", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_OUTPUT_ID, new String[]{"1", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_OUTPUT_QUANTITY, new String[]{"20", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_HMI_DISPLAY, new String[]{"HMI Display", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_OTHER_MEASUREMENT_ID, new String[]{"1", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_COMMUNICATIONS, new String[]{"Communications", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_VOLTAGE, new String[]{"100", ""});
    helper.setRequestParameterValue(AccessoryConstants.BID_PACKAGE, new String[]{"1212", ""});
  }

  private void setAccessoriesInHelper(MockUCCHelper helper) {
    helper.setRequestParameterValue(AccessoryConstants.ACCE_ID, new String[]{"", "2222"});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_NAME, new String[]{"Acce Name 1", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_AUTO_MANUAL_ID, new String[]{"11", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_DESGINATOR_ID, new String[]{"13", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_SEQUENCE_NUMBER, new String[]{"15", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_DESCRIPTION, new String[]{"Acce Desc 1", ""});
    helper
        .setRequestParameterValue(AccessoryConstants.ACCE_COMMENTS, new String[]{"Acce Comments 1", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_PURCHASED_WITH_EQUIP, new String[]{"", "true"});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_QUANTITY, new String[]{"17", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_COMP_AIR_REQD, new String[]{"true", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_GAS_REQD, new String[]{"true", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_WATER_REQD, new String[]{"false", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_UTILITY_FLOWRATE, new String[]{"19", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_SELF_CLEANING, new String[]{"false", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_SIZE, new String[]{"21", ""});
    helper.setRequestParameterValue(AccessoryConstants.DELETED_ACCESSORY_IDS, "123, 124, ");
  }

  private class AccessoryBuilderOverridesFlaggedAsDeleted extends AccessoryBuilder {
    private Set<Accessory> existingAccessories;

    //protected for testing
    protected void flagAccessoriesThatWereDeleted(Equipment equipment, String deletedAccessoryIds) {
      super.flagAccessoriesThatWereDeleted(equipment, deletedAccessoryIds);
      this.existingAccessories = equipment.getAccessories();
    }

    public Set<Accessory> getExistingAccessories() {
      return existingAccessories;
    }
  }
}