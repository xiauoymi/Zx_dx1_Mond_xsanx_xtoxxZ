/*
 CostScheduleBuilder_UT was created on Nov 10, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.projects.domain.CostSchedule;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.util.CostScheduleConstants;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.equipment.service.mock.MockCostScheduleService;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: CostScheduleBuilder_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-22 14:17:42 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class CostScheduleBuilder_UT extends TestCase {

  public void testCreate() throws Exception {
    BaseBuilder builder = new CostScheduleBuilder();
    assertNotNull(builder);
  }

  public void testCreateCostScheduleFromRequest_NewCostScheduleHasChanges_BuildCostSchedule() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(CostScheduleConstants.HAS_COST_SCHEDULED_DATA_CHANGED, "true");
    helper.setRequestParameterValue(CostScheduleConstants.CS_SCHEDULED_SPECIFICATION, "Sep 27, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_SCHEDULED_QUOTE, "Sep 28, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_SCHEDULED_PURCHASE, "Sep 29, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_DRAWING_TURNAROUNDTIME, "13");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_FABRICATION_TIME, "14");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_SHIPPING, "Sep 30, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_SPEC_ISSED, "Oct 01, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_RTQ_ENTERED, "Oct 02, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_RTP_ENTERED, "Oct 03, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_PREL_DRAWING_ISSUED, "Oct 04, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_APPROVAL_DRAWING, "Oct 05, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_FINAL_DRAWING, "Oct 06, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_IOM_RECEIVED, "Oct 07, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_SOURCE, "Lease");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_COST, "100");
    helper.setRequestParameterValue(CostScheduleConstants.CS_FUNDING_SOURCE_ID, "12");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_MECH_HRS, "40");
    helper.setRequestParameterValue(CostScheduleConstants.CS_ESCALATION_FACTOR, "1.234");
    CostScheduleBuilder builder = new CostScheduleBuilder(new MockCostScheduleService());
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null, null, null);
    CostSchedule costSchedule = builder.createCostScheduleFromRequest(equipment, helper);
    assertNull(costSchedule.getId());
    assertEquals("Sep 27, 2008", ConvertUtil.toString(costSchedule.getscheduledSpecificationDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Sep 28, 2008", ConvertUtil.toString(costSchedule.getScheduledQuoteDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Sep 29, 2008", ConvertUtil.toString(costSchedule.getScheduledPurchaseDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("13", costSchedule.getDrawingTurnaroundTime().toString());
    assertEquals("14", costSchedule.getEstiamtedFabricationTime().toString());
    assertEquals("Sep 30, 2008", ConvertUtil.toString(costSchedule.getEstiamtedShippingDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 01, 2008", ConvertUtil.toString(costSchedule.getSpecIssuedDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 02, 2008", ConvertUtil.toString(costSchedule.getRtqEnteredDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 03, 2008", ConvertUtil.toString(costSchedule.getRtpEnteredDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 04, 2008", ConvertUtil.toString(costSchedule.getPrelDrawingIssuedDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 05, 2008", ConvertUtil.toString(costSchedule.getApprovalDrawingDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 06, 2008", ConvertUtil.toString(costSchedule.getFinalDrawingDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 07, 2008", ConvertUtil.toString(costSchedule.getIomReceivedDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Lease", costSchedule.getEstimatedSource());
    assertEquals("100", costSchedule.getEstimatedCost().toString());
    assertEquals("12", costSchedule.getFundingSource().getId().toString());
    assertEquals("40", costSchedule.getEstimatedMechHours().toString());
    assertEquals("1.234", costSchedule.getEscalationFactor().toString());
  }

  public void testCreateCostScheduleFromRequest_ExistingCostScheduleHasChanges_BuildCostSchedule() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(CostScheduleConstants.HAS_COST_SCHEDULED_DATA_CHANGED, "true");
    helper.setRequestParameterValue(CostScheduleConstants.CS_SCHEDULED_SPECIFICATION, "Sep 27, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_SCHEDULED_QUOTE, "Sep 28, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_SCHEDULED_PURCHASE, "Sep 29, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_DRAWING_TURNAROUNDTIME, "13");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_FABRICATION_TIME, "14");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_SHIPPING, "Sep 30, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_SPEC_ISSED, "Oct 01, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_RTQ_ENTERED, "Oct 02, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_RTP_ENTERED, "Oct 03, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_PREL_DRAWING_ISSUED, "Oct 04, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_APPROVAL_DRAWING, "Oct 05, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_FINAL_DRAWING, "Oct 06, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_IOM_RECEIVED, "Oct 07, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_SOURCE, "Lease");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_COST, "100");
    helper.setRequestParameterValue(CostScheduleConstants.CS_FUNDING_SOURCE_ID, "12");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_MECH_HRS, "40");
    helper.setRequestParameterValue(CostScheduleConstants.CS_ESCALATION_FACTOR, "4.567");

    CostScheduleBuilder builder = new CostScheduleBuilder(new MockCostScheduleService());
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null, null, null);
    CostSchedule costSchedule1 = new CostSchedule();
    costSchedule1.setId(new Long(123));
    equipment.setCostSchedule(costSchedule1);
    CostSchedule costSchedule = builder.createCostScheduleFromRequest(equipment, helper);
    assertEquals(new Long(123), costSchedule.getId());
    assertEquals("Sep 27, 2008",
        ConvertUtil.toString(costSchedule.getscheduledSpecificationDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Sep 28, 2008",
        ConvertUtil.toString(costSchedule.getScheduledQuoteDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Sep 29, 2008",
        ConvertUtil.toString(costSchedule.getScheduledPurchaseDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("13", costSchedule.getDrawingTurnaroundTime().toString());
    assertEquals("14", costSchedule.getEstiamtedFabricationTime().toString());
    assertEquals("Sep 30, 2008", ConvertUtil.toString(costSchedule.getEstiamtedShippingDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 01, 2008", ConvertUtil.toString(costSchedule.getSpecIssuedDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 02, 2008", ConvertUtil.toString(costSchedule.getRtqEnteredDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 03, 2008", ConvertUtil.toString(costSchedule.getRtpEnteredDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 04, 2008", ConvertUtil.toString(costSchedule.getPrelDrawingIssuedDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 05, 2008", ConvertUtil.toString(costSchedule.getApprovalDrawingDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 06, 2008", ConvertUtil.toString(costSchedule.getFinalDrawingDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 07, 2008", ConvertUtil.toString(costSchedule.getIomReceivedDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Lease", costSchedule.getEstimatedSource());
    assertEquals("100", costSchedule.getEstimatedCost().toString());
    assertEquals("12", costSchedule.getFundingSource().getId().toString());
    assertEquals("40", costSchedule.getEstimatedMechHours().toString());
    assertEquals("4.567", costSchedule.getEscalationFactor().toString());
  }

  public void testCreateCostScheduleFromRequest_CostScheduleIsNullHasNoChanges_ReturnNewCostSchedule() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(CostScheduleConstants.HAS_COST_SCHEDULED_DATA_CHANGED, "");
    CostScheduleBuilder builder = new CostScheduleBuilder(new MockCostScheduleService());
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null, null, null);
    equipment.setId(new Long(123));
    CostSchedule costScheduleFromRequest = builder.createCostScheduleFromRequest(equipment, helper);
    assertNull(costScheduleFromRequest.getId());
    assertEquals(equipment, costScheduleFromRequest.getEquipment());
  }

  public void testCreateCostScheduleFromRequest_CostScheduleIsNotNullHasNoChanges_ReturnExistingCostSchedule() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(CostScheduleConstants.HAS_COST_SCHEDULED_DATA_CHANGED, "");
    CostScheduleBuilder builder = new CostScheduleBuilder(new MockCostScheduleService());
    CostSchedule exisingCostSchedule = new CostSchedule();
    exisingCostSchedule.setId(new Long(234));
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null, null, null);
    equipment.setId(new Long(123));
    equipment.setCostSchedule(exisingCostSchedule);
    CostSchedule costScheduleFromRequest = builder.createCostScheduleFromRequest(equipment, helper);
    assertEquals(exisingCostSchedule, costScheduleFromRequest);
  }
}