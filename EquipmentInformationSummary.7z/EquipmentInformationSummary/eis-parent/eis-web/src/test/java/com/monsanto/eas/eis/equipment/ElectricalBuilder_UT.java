package com.monsanto.eas.eis.equipment;

import junit.framework.TestCase;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.equipment.ElectricalBuilder;
import com.monsanto.eas.eis.equipment.service.mock.MockElectricalService;
import com.monsanto.eas.eis.util.ElectricalConstants;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 24, 2008 Time: 12:24:34 PM To change this template use File |
 * Settings | File Templates.
 */
public class ElectricalBuilder_UT extends TestCase {

  public void testCreateElectricalFromRequest_NewElectricalHasChanges_ReturnsElectrical() throws Exception {
    ElectricalBuilder electricalBuilder = new ElectricalBuilder(new MockElectricalService());
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ElectricalConstants.HAS_ELECTRICAL_DATA_CHANGED, "true");
    helper.setRequestParameterValue(ElectricalConstants.PROOF_OF_POSITION_REQUIRED, "true");
    helper.setRequestParameterValue(ElectricalConstants.SOLENOID_REQUIRED, "true");
    helper.setRequestParameterValue(ElectricalConstants.LOCAL_PUSH_BUTTON_REQUIRED, "true");
    helper.setRequestParameterValue(ElectricalConstants.HMI_DISPLAY, "HMI Display");
    helper.setRequestParameterValue(ElectricalConstants.OTHER_MEASURMENT, "1");
    helper.setRequestParameterValue(ElectricalConstants.COMMUNICATIONS, "Communications");
    helper.setRequestParameterValue(ElectricalConstants.VOLTAGE, "100");

    Electrical electrical = new Electrical();

    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null,null, null);
    equipment.setElectrical(electrical);
    electrical = electricalBuilder.createElectricalFromRequest(equipment, helper);

    assertNotNull(electrical);
    assertTrue(electrical.isProofOfPositionReq());
    assertTrue(electrical.isSolenoidReq());
    assertTrue(electrical.isLocalPushButtonReq());
    assertNull(electrical.getInput());
    assertNull(electrical.getInputQty());
    assertNull(electrical.getOutput());
    assertNull(electrical.getOutputQty());
    assertEquals("HMI Display", electrical.getHmiDisplay());
    assertEquals(new Long(1), electrical.getOtherMeasurement().getId());
    assertEquals("Communications", electrical.getCommunications());
    assertEquals(new Integer(100), electrical.getVoltage());

    assertEquals(2, electrical.getInputQuantity().size());
    for(ElectricalInputQuantity in: electrical.getInputQuantity()){
      if(new Long(1).equals(in.getId())){
        assertNull(in.getId());
        assertEquals(new Long(1), in.getInput().getId());
        assertEquals("AI", in.getInput().getInput());
        assertNull(in.getInputQty());
        assertFalse(in.isChecked());
      }
    }

    assertEquals(2, electrical.getOutputQuantity().size());
    for(ElectricalOutputQuantity ou: electrical.getOutputQuantity()){
      if(new Long(3).equals(ou.getId())){
        assertEquals(new Long(3), ou.getOutput().getId());
        assertEquals("AO", ou.getOutput().getOutput());
        assertNull(ou.getOutputQty());
        assertFalse(ou.isChecked());
      }
    }
  }

  public void testCreateElectricalFromRequest_NewElectricalHasNoChanges_ReturnsNewElectrical() throws Exception {
    ElectricalBuilder electricalBuilder = new ElectricalBuilder(new MockElectricalService());
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ElectricalConstants.HAS_ELECTRICAL_DATA_CHANGED, "");
    Electrical electrical = new Electrical();
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null,null, null);
    equipment.setId(new Long(345));
    electrical = electricalBuilder.createElectricalFromRequest(equipment, helper);
    assertNotNull(electrical);
    assertNull(electrical.getId());
    assertEquals(equipment, electrical.getEquipment());

    assertEquals(2, electrical.getInputQuantity().size());
    for(ElectricalInputQuantity in: electrical.getInputQuantity()){
      if(new Long(1).equals(in.getInput().getId())){
        assertNull(in.getId());
        assertEquals(new Long(1), in.getInput().getId());
        assertEquals("AI", in.getInput().getInput());
        assertNull(in.getInputQty());
        assertFalse(in.isChecked());
      }
    }

    assertEquals(2, electrical.getOutputQuantity().size());
    for(ElectricalOutputQuantity ou: electrical.getOutputQuantity()){
      if(new Long(3).equals(ou.getOutput().getId())){
        assertEquals(new Long(3), ou.getOutput().getId());
        assertEquals("AO", ou.getOutput().getOutput());
        assertNull(ou.getOutputQty());
        assertFalse(ou.isChecked());
      }
    }
  }

  public void testCreateElectricalFromRequest_ExistingElectricalHasNoChanges_ReturnsExistingElectrical() throws Exception {
    ElectricalBuilder electricalBuilder = new ElectricalBuilder(new MockElectricalService());
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ElectricalConstants.HAS_ELECTRICAL_DATA_CHANGED, "");
    Electrical existingElectrical = new Electrical();
    existingElectrical.setId(new Long(234));
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null,null, null);
    equipment.setElectrical(existingElectrical);
    Electrical electrical = electricalBuilder.createElectricalFromRequest(equipment, helper);
    assertEquals(existingElectrical, electrical);
  }

  public void testCreateElectricalFromRequest_ExisitingElectricalHasChanges_ReturnsElectrical() throws Exception {
    ElectricalBuilder electricalBuilder = new ElectricalBuilder(new MockElectricalService());
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ElectricalConstants.HAS_ELECTRICAL_DATA_CHANGED, "true");
    helper.setRequestParameterValue(ElectricalConstants.PROOF_OF_POSITION_REQUIRED, "true");
    helper.setRequestParameterValue(ElectricalConstants.SOLENOID_REQUIRED, "true");
    helper.setRequestParameterValue(ElectricalConstants.LOCAL_PUSH_BUTTON_REQUIRED, "true");
    helper.setRequestParameterValue(ElectricalConstants.HMI_DISPLAY, "HMI Display");
    helper.setRequestParameterValue(ElectricalConstants.OTHER_MEASURMENT, "1");
    helper.setRequestParameterValue(ElectricalConstants.COMMUNICATIONS, "Communications");
    helper.setRequestParameterValue(ElectricalConstants.VOLTAGE, "100");
    helper.setRequestParameterValue("InputCheckbox1", "true");
    helper.setRequestParameterValue("OutputCheckbox3", "true");
    helper.setRequestParameterValue("InputQuantity1", "20");
    helper.setRequestParameterValue("OutputQuantity3", "30");
    Electrical existingElectrical = new Electrical();
    existingElectrical.setId(new Long(234));
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null,null, null);
    equipment.setElectrical(existingElectrical);
    Electrical electrical = electricalBuilder.createElectricalFromRequest(equipment, helper);
    assertNotNull(electrical);
    assertNull(electrical.getInput());
    assertNull(electrical.getInputQty());
    assertNull(electrical.getOutput());
    assertNull(electrical.getOutputQty());
    assertTrue(electrical.isProofOfPositionReq());
    assertTrue(electrical.isSolenoidReq());
    assertTrue(electrical.isLocalPushButtonReq());
    assertEquals("HMI Display", electrical.getHmiDisplay());
    assertEquals(new Long(1), electrical.getOtherMeasurement().getId());
    assertEquals("Communications", electrical.getCommunications());
    assertEquals(new Integer(100), electrical.getVoltage());

    assertEquals(2, electrical.getInputQuantity().size());
    for(ElectricalInputQuantity in: electrical.getInputQuantity()){
      if(new Long(1).equals(in.getInput().getId())){
        assertNotNull(in.getId());
        assertEquals(new Long(1), in.getInput().getId());
        assertNotNull(in.getInput().getInput());
        assertEquals(new Integer(20), in.getInputQty());
        assertTrue(in.isChecked());
      }
    }

    assertEquals(2, electrical.getOutputQuantity().size());
    for(ElectricalOutputQuantity ou: electrical.getOutputQuantity()){
      if(new Long(3).equals(ou.getOutput().getId())){
        assertNotNull(ou.getId());
        assertEquals(new Long(3), ou.getOutput().getId());
        assertNotNull(ou.getOutput().getOutput());
        assertEquals(new Integer(30), ou.getOutputQty());
        assertTrue(ou.isChecked());
      }
    }
  }
}
