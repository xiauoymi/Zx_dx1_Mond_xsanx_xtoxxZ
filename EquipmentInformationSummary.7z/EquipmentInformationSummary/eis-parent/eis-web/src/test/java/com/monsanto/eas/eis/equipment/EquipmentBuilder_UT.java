package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.projects.mocks.MockEISDAOFactory;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Area;
import com.monsanto.eas.eis.projects.domain.EquipmentType;
import com.monsanto.eas.eis.projects.mocks.MockAreaDAOImpl;
import com.monsanto.eas.eis.projects.mocks.MockEquipmentDAO;
import com.monsanto.eas.eis.projects.mocks.MockEquipmentTypeDAOImpl;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import junit.framework.TestCase;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Nov 6, 2008 Time: 6:37:17 PM To change this template use File | Settings
 * | File Templates.
 */
public class EquipmentBuilder_UT extends TestCase {
  private MockEISDAOFactory daoFactory;
  EquipmentBuilder equipmentBuilder;

  protected void setUp() throws Exception {
    super.setUp();
    daoFactory = new MockEISDAOFactory(new MockHibernateSession());
    equipmentBuilder = new EquipmentBuilder(daoFactory);
  }

  public void testCreateEquipmentFromparameters_NewEquipmentHasChanges_ReturnsEquipment() throws IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_AREA, "1");
    helper.setRequestParameterValue(EISConstants.PROCESS_LINE_NUMBER, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TAG_NUMBER, "111");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TYPE_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_SUB_TYPE_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_NAME, "Equipment Name");
    helper.setRequestParameterValue(EISConstants.EXISTING_EQUIPMENT_NUMBER, "10.0.B1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_DESCRIPTION, "Equipment Description");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_SOLE_SOURCE, "true");
    helper.setRequestParameterValue(EISConstants.EXISTING_EQUIPMENT_MODIFICATION, "false");
    helper.setRequestParameterValue(EISConstants.STANDARD_EQUIPMENT, "false");
    Equipment equipment = equipmentBuilder.createEquipmentFromParameters(helper);
    assertNotNull(equipment);
    assertTrue(((MockAreaDAOImpl) daoFactory.getAreaDAOImpl()).wasFindByPrimaryKeyCalled());
    assertTrue(((MockEquipmentTypeDAOImpl) daoFactory.getEquipmentTypeDAOImpl()).wasFindByPrimaryKeyCalled());
    assertEquals("0.1.111C", equipment.getEquipmentNumber());
    assertNull(equipment.getId());
    assertEquals("Equipment Name", equipment.getName());
    assertEquals("10.0.B1", equipment.getExistingEquipmentNumber());
    assertEquals("Equipment Description", equipment.getDescription());
    assertEquals(new Long(1), equipment.getArea().getId());
    assertEquals(new Long(1), equipment.getEquipmentType().getId());
    assertEquals("1", equipment.getProcessLineNumber());
    assertEquals("111", equipment.getEquipmentTagNumber());
    assertEquals(new Long(1), equipment.getSubType().getId());
    assertEquals(new Long(1), equipment.getProjects().getId());
  }

  public void testCreateEquipmentFromParameters_ExistingEquipmentHasChanges_ReturnsEquipment() throws IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_AREA, "1");
    helper.setRequestParameterValue(EISConstants.PROCESS_LINE_NUMBER, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TAG_NUMBER, "111");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TYPE_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_SUB_TYPE_ID, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_NAME, "Equipment Name");
    helper.setRequestParameterValue(EISConstants.EXISTING_EQUIPMENT_NUMBER, "10.0.B1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_DESCRIPTION, "Equipment Description");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_SOLE_SOURCE, "true");
    helper.setRequestParameterValue(EISConstants.EXISTING_EQUIPMENT_MODIFICATION, "false");
    helper.setRequestParameterValue(EISConstants.STANDARD_EQUIPMENT, "false");

    Equipment equipment = equipmentBuilder.createEquipmentFromParameters(helper);
    assertNotNull(equipment);
    assertTrue(((MockEquipmentDAO) daoFactory.getEquipmentDAOImpl()).wasFindByPrimaryKeyCalled());
    assertTrue(((MockAreaDAOImpl) daoFactory.getAreaDAOImpl()).wasFindByPrimaryKeyCalled());
    assertTrue(((MockEquipmentTypeDAOImpl) daoFactory.getEquipmentTypeDAOImpl()).wasFindByPrimaryKeyCalled());
    assertTrue(((MockEquipmentDAO) daoFactory.getEquipmentDAOImpl()).wasFindByPrimaryKeyCalled());
    assertEquals("0.1.111C", equipment.getEquipmentNumber());
    assertEquals(new Long(1), equipment.getId());
    assertEquals("Equipment Name", equipment.getName());
    assertEquals("10.0.B1", equipment.getExistingEquipmentNumber());
    assertEquals("Equipment Description", equipment.getDescription());
    assertEquals(new Long(1), equipment.getArea().getId());
    assertEquals(new Long(1), equipment.getEquipmentType().getId());
    assertEquals("1", equipment.getProcessLineNumber());
    assertEquals("111", equipment.getEquipmentTagNumber());
    assertEquals(new Long(1), equipment.getSubType().getId());
  }

  public void testvalidate_ReturnsRequireFieldsList_WithZeroSize() throws IOException {
    Equipment eqipment = new Equipment();
    eqipment.setArea(new Area(new Long(12), null, null));
    eqipment.setEquipmentType(new EquipmentType(new Long(13), null, null));
    eqipment.setProcessLineNumber("1");
    eqipment.setEquipmentTagNumber("111");
    eqipment.setName("New Name");
    List<String> requiredFieldsList = equipmentBuilder.validate(eqipment);
    assertEquals(0, requiredFieldsList.size());
  }

  public void testvalidate_WithMissingRequiredFields_ReturnsRequireFieldsList_WithSizeGreaterThanZero() throws
      IOException {
    Equipment eqipment = new Equipment();
    eqipment.setArea(null);
    eqipment.setEquipmentType(null);
    eqipment.setProcessLineNumber(null);
    eqipment.setEquipmentTagNumber(null);
    eqipment.setName(null);
    List<String> requiredFieldsList = equipmentBuilder.validate(eqipment);
    assertEquals(5, requiredFieldsList.size());
    assertEquals("Area is a required field", requiredFieldsList.get(0));
    assertEquals("Equipment Type is a required field", requiredFieldsList.get(1));
    assertEquals("Process Line # is a required field", requiredFieldsList.get(2));
    assertEquals("Equipment Tag # is a required field", requiredFieldsList.get(3));
    assertEquals("Name is a required field", requiredFieldsList.get(4));
  }

  public void testValidateAllFieldsLength_WithValidLengths_ReturnsListWithZeroSize() throws IOException {
    Equipment eqipment = new Equipment();
    eqipment.setEquipmentTagNumber("111");
    List<String> list = equipmentBuilder.validateAllFieldsLength(eqipment);
    assertEquals(0, list.size());
  }

  public void testValidateAllFieldsLength_WithInValidLengths_ReturnsListWithSizeGreaterThanZero() throws IOException {
    Equipment eqipment = new Equipment();
    eqipment.setEquipmentTagNumber("1");
    List<String> list = equipmentBuilder.validateAllFieldsLength(eqipment);
    assertEquals(1, list.size());
    assertEquals("Equipment Tag # has an invalid minimum length", list.get(0));
  }
}
