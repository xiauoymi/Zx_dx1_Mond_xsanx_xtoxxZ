package com.monsanto.eas.eis.equipment;

import com.monsanto.eas.eis.projects.domain.EquipmentType;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Area;
import org.w3c.dom.Document;
import org.custommonkey.xmlunit.XMLTestCase;

import javax.xml.transform.TransformerException;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 19, 2008
 * Time: 8:54:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class EquipmentTestUtil {

  public static EquipmentType getEquipmentType(Long id) {
    EquipmentType equipmentType = new EquipmentType();
    equipmentType.setId(id);
    return equipmentType;
  }

  public static Equipment getEquipmentForTest() {
    Equipment equipment = new Equipment();
    EquipmentType equipmentType = new EquipmentType(1L,"parent","p");
    EquipmentType equipmentSubtype1 = new EquipmentType(1L,"parent","p");
    EquipmentType equipmentSubtype2 = new EquipmentType(1L,"parent","p");
    equipment.setId(1L);
    equipment.setEquipmentNumber("E001");
    equipment.setName("Equipment1");
    equipment.setDescription("Equipment 1");
    Area area = new Area();
    area.setId(1L);
    area.setAreaCode("1");
    equipment.setArea(area);
    equipment.setEquipmentType(equipmentType);
    equipment.setSubTypeOne(equipmentSubtype1);
    return equipment;
  }

  public static void assertXMLDocumentWhenEquipmentExists(Document equipmentListXML) throws TransformerException {
    XMLTestCase tc = new XMLTestCase();
    XMLTestCase.assertNotNull(equipmentListXML);

//    NodeList list = XPathAPI.selectNodeList(equipmentListXML, "EquipmentList/Equipment/EquipmentNumber");
//    Node node = list.item(0);
//    String value = DOMUtil.getTextValue(node);
//    assertEquals("E001", value);
//    list = equipmentListXML.getElementsByTagName("EquipmentID");
//    node =  list.item(0);
//    value = DOMUtil.getTextValue(node);
//    assertEquals("1", value);
//    list = equipmentListXML.getElementsByTagName("Name");
//    node =  list.item(0);
//    value = DOMUtil.getTextValue(node);
//    assertEquals("Equipment1", value);
//    list = equipmentListXML.getElementsByTagName("Description");
//    node =  list.item(0);
//    value = DOMUtil.getTextValue(node);
//    assertEquals("Equipment 1", value);
//    list = equipmentListXML.getElementsByTagName("Area");
//    node =  list.item(0);
//    value = DOMUtil.getTextValue(node);
//    assertEquals("1", value);
//    list = equipmentListXML.getElementsByTagName("UpdatedDate");
//    node =  list.item(0);
//    value = DOMUtil.getTextValue(node);
//    assertEquals("", value);  // todo: assert with an updated date

    //these are values used in getEquipmentForTest
    tc.assertXpathEvaluatesTo("1", "count(//equipments)", equipmentListXML);
    tc.assertXpathEvaluatesTo("1", "//equipments/equipment[1]/id", equipmentListXML);
    tc.assertXpathEvaluatesTo("E001", "//equipments/equipment[1]/equipmentNumber/", equipmentListXML);
    tc.assertXpathEvaluatesTo("Equipment1", "//equipments/equipment[1]/name/", equipmentListXML);
    tc.assertXpathEvaluatesTo("Equipment 1", "//equipments/equipment[1]/description/", equipmentListXML);
    tc.assertXpathEvaluatesTo("1", "//equipments/equipment[1]/area/areaCode/", equipmentListXML);
    tc.assertXpathEvaluatesTo("", "//equipments/equipment[1]/modifiedDate/", equipmentListXML); // todo: assert with an updated date
  }

  public static void assertXMLDocumentWhenEquipmentNotExists(Document resultDoc) throws TransformerException {
    XMLTestCase tc = new XMLTestCase();
    XMLTestCase.assertNotNull(resultDoc);
    tc.assertXpathExists("/EquipmentList", resultDoc);
    tc.assertXpathNotExists("/EquipmentList/Equipment", resultDoc);
    tc.assertXpathNotExists("/EquipmentList/Equipment/EquipmentID", resultDoc);
    tc.assertXpathNotExists("/EquipmentList/Equipment/EquipmentNumber", resultDoc);
    tc.assertXpathNotExists("/EquipmentList/Equipment/Name", resultDoc);
    tc.assertXpathNotExists("/EquipmentList/Equipment/Description", resultDoc);
    tc.assertXpathNotExists("/EquipmentList/Equipment/Area", resultDoc);
  }

//  public static void assertXMLDocumentWhenEquipmentDetailExists(Document equipmentDetail) throws TransformerException {
//    XMLTestCase tc = new XMLTestCase();
//    XMLTestCase.assertNotNull(equipmentDetail);
//    tc.assertXpathExists("/EquipmentList", equipmentDetail);
//    tc.assertXpathExists("/EquipmentList/Equipment/AreaDescription", equipmentDetail);
//    tc.assertXpathExists("/EquipmentList/Equipment/EquipmentType", equipmentDetail);
//    tc.assertXpathExists("/EquipmentList/Equipment/ProcessLineNumber", equipmentDetail);
//    tc.assertXpathExists("/EquipmentList/Equipment/SubTypeOne", equipmentDetail);
//    tc.assertXpathExists("/EquipmentList/Equipment/EquipmentTagNumber", equipmentDetail);
//    tc.assertXpathExists("/EquipmentList/Equipment/SubTypeTwo", equipmentDetail);
//    tc.assertXpathExists("/EquipmentList/Equipment/Suffix", equipmentDetail);
//    tc.assertXpathExists("/EquipmentList/Equipment/Name", equipmentDetail);
//    tc.assertXpathExists("/EquipmentList/Equipment/Description", equipmentDetail);
//    tc.assertXpathExists("/EquipmentList/Equipment/EquipmentNumber", equipmentDetail);
//    tc.assertXpathExists("/EquipmentList/Equipment/Description", equipmentDetail);
//
//    tc.assertXpathEvaluatesTo("e-number", "/EquipmentList/Equipment/EquipmentNumber/text()", equipmentDetail);
//    tc.assertXpathEvaluatesTo("e-name", "/EquipmentList/Equipment/Name/text()", equipmentDetail);
//    tc.assertXpathEvaluatesTo("e-description", "/EquipmentList/Equipment/Description/text()", equipmentDetail);
//    tc.assertXpathEvaluatesTo("Area Description", "/EquipmentList/Equipment/AreaDescription/text()", equipmentDetail);
//    tc.assertXpathEvaluatesTo("equipment_type", "/EquipmentList/Equipment/EquipmentType/text()", equipmentDetail);
//    tc.assertXpathEvaluatesTo("0", "/EquipmentList/Equipment/ProcessLineNumber/text()", equipmentDetail);
//    tc.assertXpathEvaluatesTo("sub_type_one", "/EquipmentList/Equipment/SubTypeOne/text()", equipmentDetail);
//    tc.assertXpathEvaluatesTo("sub_type_two", "/EquipmentList/Equipment/SubTypeTwo/text()", equipmentDetail);
//    tc.assertXpathEvaluatesTo("suffix", "/EquipmentList/Equipment/Suffix/text()", equipmentDetail);
//    tc.assertXpathEvaluatesTo("000-000", "/EquipmentList/Equipment/EquipmentTagNumber/text()", equipmentDetail);
//    //tc.assertXpathEvaluatesTo("e-number", "/EquipmentList/Equipment/EquipmentNumber/text()", equipmentDetail);
//  }

}
