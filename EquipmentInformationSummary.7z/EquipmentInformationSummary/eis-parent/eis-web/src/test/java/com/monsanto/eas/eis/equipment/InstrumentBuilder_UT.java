/*
 IntrumentBuilder_UT was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Instrument;
import com.monsanto.eas.eis.projects.domain.Purchasing;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.util.InstrumentConstants;
import junit.framework.TestCase;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Filename:    $RCSfile: InstrumentBuilder_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-01-27 14:25:08 $
 *
 * @author sspati1
 * @version $Revision: 1.14 $
 */
public class InstrumentBuilder_UT extends TestCase {
  public void testCreate() throws Exception {
    InstrumentBuilder builder = new InstrumentBuilder();
    assertNotNull(builder);
  }

  public void testCreateInstrumentListFromRequest_NewEquipmentNoIntruments_ReturnsEmptyList() throws Exception {
    InstrumentBuilder builder = new InstrumentBuilder();
    Equipment equipment = new Equipment();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(InstrumentConstants.HAS_INTRUMENTS_DATA_CHANGED, "");
    Set<Instrument> instruments = builder.createIntrumentListFromRequest(equipment, helper);
    assertTrue(instruments.isEmpty());
  }

  public void testCreateInstrumentListFromRequest_NewEquipmentNewIntruments_ReturnsList() throws Exception {
    InstrumentBuilder builder = new InstrumentBuilder();
    Equipment equipment = new Equipment();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(InstrumentConstants.HAS_INTRUMENTS_DATA_CHANGED, "true");
    setPurchasingDataInHelper(helper);
    setInstrumentsInHelper(helper);
    Set<Instrument> instruments = builder.createIntrumentListFromRequest(equipment, helper);
    assertIntruments(instruments);
  }

  public void testCreateInstrumentListFromRequest_ExistingInstrumentDataHasNotChanged_ReturnList() throws Exception {
    InstrumentBuilder builder = new InstrumentBuilder();
    Equipment equipment = new Equipment();
    Set<Instrument> existingInstruments = new HashSet<Instrument>();
    Instrument instrument1 = new Instrument();
    instrument1.setId(new Long(123));
    existingInstruments.add(instrument1);
    Instrument instrument2 = new Instrument();
    instrument2.setId(new Long(234));
    existingInstruments.add(instrument2);
    equipment.setInstruments(existingInstruments);
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(InstrumentConstants.HAS_INTRUMENTS_DATA_CHANGED, "");
    Set<Instrument> instruments = builder.createIntrumentListFromRequest(equipment, helper);
    assertEquals(2, instruments.size());
    assertTrue(instruments.contains(instrument1));
    assertTrue(instruments.contains(instrument2));
    assertFalse(instrument1.isDeleted());
    assertFalse(instrument2.isDeleted());
  }

  public void testCreateInstrumentListFromRequest_ExistingInstrumentDataHasChanged_ReturnsListExistingInstrumentsAreFlaggedAsDeleted() throws
      Exception {
    MockInstrumentBuilderOverridesFlaggedAsDeleted builder = new MockInstrumentBuilderOverridesFlaggedAsDeleted();
    Equipment equipment = new Equipment();
    Set<Instrument> existingInstruments = new HashSet<Instrument>();
    Instrument instrument1 = new Instrument();
    instrument1.setId(new Long(123));
    existingInstruments.add(instrument1);
    Instrument instrument2 = new Instrument();
    instrument2.setId(new Long(124));
    existingInstruments.add(instrument2);
    equipment.setInstruments(existingInstruments);
    MockUCCHelper helper = new MockUCCHelper(null);
    setPurchasingDataInHelper(helper);
    setInstrumentsInHelper(helper);
    helper.setRequestParameterValue(InstrumentConstants.HAS_INTRUMENTS_DATA_CHANGED, "true");
    Set<Instrument> instruments = builder.createIntrumentListFromRequest(equipment, helper);
    assertEquals(2, instruments.size());
    existingInstruments = builder.getExistingInstruments();
    assertEquals(2, existingInstruments.size());
    for (Instrument inst : existingInstruments) {
      assertTrue(inst.isDeleted());
    }
  }

  private void setInstrumentsInHelper(MockUCCHelper helper) {
    helper.setRequestParameterValue(InstrumentConstants.INSTRUMENT_ID, new String[]{"", "2222"});
    helper.setRequestParameterValue(InstrumentConstants.INST_PURCHASED_WITH_EQUIP, new String[]{"", "true"});
    helper.setRequestParameterValue(InstrumentConstants.DESIGNATOR_FIRST_CHAR_ID, new String[]{"1", ""});
    helper.setRequestParameterValue(InstrumentConstants.DESIGNATOR_SECOND_CHAR_ID, new String[]{"2", ""});
    helper.setRequestParameterValue(InstrumentConstants.INST_SEQUENCE_NUMBER, new String[]{"22", "33"});
    helper.setRequestParameterValue(InstrumentConstants.INST_DESCRIPTION,
        new String[]{"This is my description", "This is my description 2"});
    helper.setRequestParameterValue(InstrumentConstants.IO_TYPE_ID, new String[]{"4", ""});
    helper.setRequestParameterValue(InstrumentConstants.ALARM_POINTS, new String[]{"1000", "2000"});
    helper.setRequestParameterValue(InstrumentConstants.ALARM_POINTS_QUANTITY, new String[]{"5", ""});
    helper.setRequestParameterValue(InstrumentConstants.INST_TYPE_ID, new String[]{"6", ""});
    helper.setRequestParameterValue(InstrumentConstants.INST_VOLTS, new String[]{"300", ""});
    helper.setRequestParameterValue(InstrumentConstants.INST_RANGE, new String[]{"40000", ""});
    helper.setRequestParameterValue(InstrumentConstants.INST_UNITS, new String[]{"watts", "watts 1"});
    helper.setRequestParameterValue(InstrumentConstants.INST_ESTIMATED_COST, new String[]{"99999", ""});
    helper.setRequestParameterValue(InstrumentConstants.INST_ACTUAL_COST, new String[]{"123456",""});
    helper.setRequestParameterValue(InstrumentConstants.INST_COMMENTS,
        new String[]{"These are my comments", "These are my comments 2"});
    helper.setRequestParameterValue(InstrumentConstants.INST_BID_PACAKAGE,
        new String[]{"1212", ""});
    helper.setRequestParameterValue(InstrumentConstants.INST_MANUFACTURER,
        new String[]{"manu 1", "manu 2"});
    helper.setRequestParameterValue(InstrumentConstants.INST_MODEL_NUMBER,
        new String[]{"model1", "model2"});
    helper.setRequestParameterValue(InstrumentConstants.DELETED_INSTRUMENT_IDS, "123, 124,");
  }

  private void setPurchasingDataInHelper(MockUCCHelper helper) {
    helper.setRequestParameterValue(InstrumentConstants.INST_PURCHASING_ID, new String[]{"", "3333"});
    helper
        .setRequestParameterValue(InstrumentConstants.INST_VENDOR, new String[]{"My Vendor", "This should not count"});
    helper.setRequestParameterValue(InstrumentConstants.INST_RTP_NUMBER, new String[]{"123", "234"});
    helper.setRequestParameterValue(InstrumentConstants.INST_PO_NUMBER, new String[]{"123", "234"});
    helper.setRequestParameterValue(InstrumentConstants.INST_LINE_NUMBER, new String[]{"123", "234"});
    helper.setRequestParameterValue(InstrumentConstants.INST_ACTUAL_DELIVERY_DATE,
        new String[]{"Oct 29, 2008", "Oct 29, 2009"});
  }

  private void assertIntruments(Set<Instrument> instruments) {
    assertEquals(2, instruments.size());
    Iterator<Instrument> iterator = instruments.iterator();
    Instrument instrument = iterator.next();
    if ("22".equals(instrument.getSequenceNumber())) {
      assertInstrument1(instrument);
      instrument = iterator.next();
      assertInstrument2(instrument);
    } else {
      assertInstrument2(instrument);
      instrument = iterator.next();
      assertInstrument1(instrument);
    }
  }

  private void assertInstrument2(Instrument instrument) {
    Purchasing purchasing;
    assertEquals(new Long(2222), instrument.getId());
    assertNull(instrument.getDesignatorFirstChar());
    assertNull(instrument.getDesignatorSecondChar());
    assertEquals("33", instrument.getSequenceNumber());
    assertEquals("This is my description 2", instrument.getInstDescription());
    assertEquals("", instrument.getBidPackage());
    assertNull(instrument.getIoType());
    assertEquals("2000", instrument.getAlarmPoints());
    assertNull(instrument.getAlarmPointsQuantity());
    assertNull(instrument.getVolts());
    assertEquals("", instrument.getRange());
    assertEquals("watts 1", instrument.getUnits());
    purchasing = instrument.getPurchasing();
    assertEquals(new Long(3333), purchasing.getId());
    assertNull(purchasing.getVendor());
    assertNull(purchasing.getRtpNumber());
    assertNull(purchasing.getPoNumber());
    assertNull(purchasing.getLineNumber());
    assertNull(purchasing.getPoLineAmount());
//    assertNull(purchasing.getPoLineQuantity());
//    assertNull(purchasing.getPoLineValue());
    assertNull(purchasing.getCoAmount());
    assertNull(purchasing.getOriginalShipDate());
    assertNull(purchasing.getRevisedShipDate());
    assertNull(purchasing.getActualDeliveryDate());
    assertFalse(purchasing.isExportDocuments());
  }

  private void assertInstrument1(Instrument instrument) {
    assertNull(instrument.getId());
    assertEquals(new Long(1), instrument.getDesignatorFirstChar().getId());
    assertEquals(new Long(2), instrument.getDesignatorSecondChar().getId());
    assertEquals("22", instrument.getSequenceNumber());
    assertEquals("This is my description", instrument.getInstDescription());
    assertEquals(new Long(4), instrument.getIoType().getId());
    assertEquals("1000", instrument.getAlarmPoints());
    assertEquals(new Integer(5), instrument.getAlarmPointsQuantity());
    assertEquals(new Integer(300), instrument.getVolts());
    assertEquals(new Long(40000).toString(), instrument.getRange());
    assertEquals("watts", instrument.getUnits());
    assertEquals("These are my comments", instrument.getComments());
    assertEquals("1212", instrument.getBidPackage());
    assertEquals("manu 1", instrument.getManufacturer());
    assertEquals("model1", instrument.getModelNumber());
    assertEquals("99999", instrument.getEstimatedCost().toString());
    assertEquals("123456", instrument.getActualCost().toString());
    Purchasing purchasing = instrument.getPurchasing();
    assertNull(purchasing.getId());
    assertEquals("My Vendor", purchasing.getVendor());
    assertEquals(new Integer(123), purchasing.getRtpNumber());
    assertEquals(new Long(123), purchasing.getPoNumber());
    assertEquals(new Integer(123), purchasing.getLineNumber());
    assertNull(purchasing.getPoLineAmount());
//    assertNull(purchasing.getPoLineQuantity());
//    assertNull(purchasing.getPoLineValue());
    assertNull(purchasing.getCoAmount());
    assertNull(purchasing.getOriginalShipDate());
    assertNull(purchasing.getRevisedShipDate());
    assertEquals("Oct 29, 2008",
        ConvertUtil.toString(purchasing.getActualDeliveryDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertFalse(purchasing.isExportDocuments());
  }

  private class MockInstrumentBuilderOverridesFlaggedAsDeleted extends InstrumentBuilder {
    private Set<Instrument> existingInstruments;

    //protected for testing
    protected void flagInstrumentsThatWereDeleted(Equipment equipment, String deletedInstrumentIds) {
      super.flagInstrumentsThatWereDeleted(equipment, deletedInstrumentIds);
      this.existingInstruments = equipment.getInstruments();
    }

    public Set<Instrument> getExistingInstruments() {
      return existingInstruments;
    }
  }
}