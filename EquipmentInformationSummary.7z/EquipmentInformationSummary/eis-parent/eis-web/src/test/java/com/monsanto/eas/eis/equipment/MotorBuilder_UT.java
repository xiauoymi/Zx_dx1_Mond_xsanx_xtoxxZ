/*
 MotorBuilder_UT was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Motor;
import com.monsanto.eas.eis.util.MotorConstants;
import junit.framework.TestCase;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Filename:    $RCSfile: MotorBuilder_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-02-16 18:21:46 $
 *
 * @author sspati1
 * @version $Revision: 1.10 $
 */
public class MotorBuilder_UT extends TestCase {

  public void testCreate() throws Exception {
    MotorBuilder builder = new MotorBuilder();
    assertNotNull(builder);
  }

  public void testCreateMotorListFromRequest_NewEquipmentNoMotors_ReturnsEmptyList() throws Exception {
    MotorBuilder builder = new MotorBuilder();
    Equipment equipment = new Equipment();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(MotorConstants.HAS_MOTORS_DATA_CHANGED, "");
    Set<Motor> motors = builder.createMotorListFromRequest(equipment, helper);
    assertTrue(motors.isEmpty());
  }

  public void testCreateMotorListFromRequest_NewEquipmentNewMotors_ReturnsList() throws Exception {
    MotorBuilder builder = new MotorBuilder();
    Equipment equipment = new Equipment();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(MotorConstants.HAS_MOTORS_DATA_CHANGED, "true");
    setupMotorsInHelper(helper);
    Set<Motor> motors = builder.createMotorListFromRequest(equipment, helper);
    assertEquals(2, motors.size());
    assertMotors(motors);
  }

  public void testCreateMotorListFromRequest_ExistingMotorDataHasNotChanged_ReturnsList() throws Exception {
    MotorBuilder builder = new MotorBuilder();
    Equipment equipment = new Equipment();
    Set<Motor> existingMotors = new HashSet<Motor>();
    Motor motor = new Motor();
    motor.setId(new Long(123));
    existingMotors.add(motor);
    equipment.setMotors(existingMotors);
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(MotorConstants.HAS_MOTORS_DATA_CHANGED, "");
    Set<Motor> motors = builder.createMotorListFromRequest(equipment, helper);
    assertTrue(motors.contains(motor));
    assertEquals(1, motors.size());
  }

  public void testCreateMotorListFromRequest_MotorDataHasChanged_ReturnsListExistingMotorsFlagedAsDeleted() throws
      Exception {
    MotorBuilderOverridesFlaggedAsDeleted builder = new MotorBuilderOverridesFlaggedAsDeleted();
    Equipment equipment = new Equipment();
    Set<Motor> existingMotors = new HashSet<Motor>();
    Motor motor = new Motor();
    motor.setId(new Long(123));
    motor.setDeleted(false);
    existingMotors.add(motor);
    motor = new Motor();
    motor.setId(new Long(124));
    motor.setDeleted(false);
    existingMotors.add(motor);
    equipment.setMotors(existingMotors);
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(MotorConstants.HAS_MOTORS_DATA_CHANGED, "true");
    setupMotorsInHelper(helper);
    Set<Motor> motors = builder.createMotorListFromRequest(equipment, helper);
    assertEquals(2, motors.size());
    assertMotors(motors);
    existingMotors = builder.getExistingMotors();
    assertEquals(2, existingMotors.size());
    for (Motor existingMotor : existingMotors) {
      assertTrue(existingMotor.isDeleted());
    }
  }

  private void setupMotorsInHelper(MockUCCHelper helper) {
    helper.setRequestParameterValue(MotorConstants.MOTOR_ID,
        new String[]{"1111", ""});
    helper.setRequestParameterValue(MotorConstants.COMPONENT_DESIGNATOR_ID,
        new String[]{"12", "13"});
    helper.setRequestParameterValue(MotorConstants.MOTOR_SEQUENCE_NUMBER,
        new String[]{"WE", "RT"});
    helper.setRequestParameterValue(MotorConstants.COMPONENT_NAME,
        new String[]{"Motor Component Name 1", "Motor Component Name 2"});
    helper.setRequestParameterValue(MotorConstants.FLA, new String[]{"2", "22"});
    helper.setRequestParameterValue(MotorConstants.MOTOR_VOLTAGE, new String[]{"200", "201"});
    helper.setRequestParameterValue(MotorConstants.PHASE, new String[]{"3", "33"});
    helper.setRequestParameterValue(MotorConstants.FREQUENVY, new String[]{"3", "34"});
    helper.setRequestParameterValue(MotorConstants.RPM, new String[]{"4", "44"});
    helper.setRequestParameterValue(MotorConstants.STARTER_ID, new String[]{"6", "66"});
    helper.setRequestParameterValue(MotorConstants.DESIGN_STATUS_ID, new String[]{"7", "77"});
    helper.setRequestParameterValue(MotorConstants.MOTOR_COMMENTS,
        new String[]{"These are my comments 1", "These are my comments 2"});
    helper.setRequestParameterValue(MotorConstants.LOAD_VALUE_TYPE_ID, new String[]{"8", "88"});
    helper.setRequestParameterValue(MotorConstants.LOAD_VALUE_QUANTITY, new String[]{"9", "99"});
    helper.setRequestParameterValue(MotorConstants.IO_CABINET, new String[]{"IO Cabinet 1", "IO Cabinet 2"});
    helper.setRequestParameterValue(MotorConstants.POWER_SOURCE, new String[]{"Electrical", "Motor"});
    helper.setRequestParameterValue(MotorConstants.LOAD_DISCONNECT_REQUIRED, new String[]{"true", "false"});
    helper.setRequestParameterValue(MotorConstants.STARTER_SIZE, new String[]{"Size 500", "Size 501"});
    helper.setRequestParameterValue(MotorConstants.BID_PACKAGE, new String[]{"1212", "2323"});
    helper.setRequestParameterValue(MotorConstants.MOTOR_BRAKE, new String[]{"true", "false"});

   helper.setRequestParameterValue(MotorConstants.DELETED_MOTOR_IDS, "123, 124, ");
  }

  private void assertMotors(Set<Motor> motors) {
    Iterator<Motor> motorIterator = motors.iterator();
    Motor motor1 = motorIterator.next();
    if (motor1.getComponentDesignator().getId().toString().equals("13")) {
      motor1 = motorIterator.next();
    } else {
      assertMotor2(motor1);
      motor1 = motorIterator.next();
      assertMotor1(motor1);
    }
  }

  private void assertMotor2(Motor motor1) {
    assertEquals("1111", motor1.getId().toString());
    assertTrue(motor1.isLoadDisconnectRequired());
  }

  private void assertMotor1(Motor motor1) {
    assertNull(motor1.getId());
    assertEquals("13", motor1.getComponentDesignator().getId().toString());
    assertEquals("RT", motor1.getSequenceNumber());
    assertEquals("Motor Component Name 2", motor1.getComponentName());
    assertEquals("22.0", motor1.getFla().toString());
    assertEquals("201", motor1.getMotorVoltage().toString());
    assertEquals("33", motor1.getPhase().toString());
    assertEquals("34", motor1.getFrequency().toString());
    assertEquals("44", motor1.getRpm().toString());
    assertEquals("77", motor1.getDesignStatus().getId().toString());
    assertEquals("These are my comments 2", motor1.getComments());
    assertEquals("88", motor1.getLoadValueType().getId().toString());
    assertEquals("99.0", motor1.getLoadValueQuantity().toString());
    assertEquals("Motor", motor1.getPowerSource());
    assertEquals("IO Cabinet 2", motor1.getIoCabinet());
    assertFalse(motor1.isLoadDisconnectRequired());
    assertEquals("Size 501", motor1.getStarterSize());
    assertFalse(motor1.isMotorBrake());
  }

  private class MotorBuilderOverridesFlaggedAsDeleted extends MotorBuilder {
    private Set<Motor> existingMotors;

    //protected for testing
    protected void flagMotorsThatWereDeleted(Equipment equipment, String deletedMotorIds) {
      super.flagMotorsThatWereDeleted(equipment, deletedMotorIds);
      this.existingMotors = equipment.getMotors();
    }

    public Set<Motor> getExistingMotors() {
      return existingMotors;
    }
  }
}