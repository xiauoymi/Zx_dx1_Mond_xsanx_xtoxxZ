/*
 ProcessBuilder_UT was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.equipment.service.ProcessServiceImpl;
import com.monsanto.eas.eis.equipment.service.mock.MockProcessService;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.domain.Process;
import com.monsanto.eas.eis.util.ProcessConstants;
import com.monsanto.wst.hibernate.mock.MockDAO;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

/**
 * Filename:    $RCSfile: ProcessBuilder_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-20 22:32:58 $
 *
 * @author sspati1
 * @version $Revision: 1.9 $
 */
public class ProcessBuilder_UT extends TestCase {
  ProcessBuilder builder;

  protected void setUp() throws Exception {
    builder = new ProcessBuilder(new MockProcessService());
  }

  public void testUpdateProcessFromRequest_NewProcessHasChanges_ReturnsProcess() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED, "true");
    setupProcessInHelper(helper);
    Equipment eqipment = new Equipment();
    eqipment.setEquipmentType(new EquipmentType(new Long(123), null, null));
    eqipment.setProcess(null);
    com.monsanto.eas.eis.projects.domain.Process process = builder.createProcessFromRequest(eqipment, helper);
    assertNull(process.getId());
    assertEquals("Ear Corn", process.getProductType());
    assertNull(process.getProductDensity());
    assertNull(process.getDesignCapacity());
    assertEquals(new Long(1), process.getDesignCapacityUnit().getId());
    assertFalse(process.isCompAirRequired());
    assertEquals("5", process.getCompAirPressure().toString());
    assertEquals("56", process.getCompAirFlowrate().toString());
    assertTrue(process.isGasRequired());
    assertEquals("23", process.getGasPressure().toString());
    assertEquals("33", process.getGasFlowrate().toString());
    assertEquals("1", process.getGasType().getId().toString());
    assertFalse(process.isWaterRequired());
    assertEquals("43", process.getWaterPressure().toString());
    assertEquals("12", process.getWaterFlowrate().toString());
    assertEquals("1", process.getWaterType().getId().toString());
    assertTrue(process.isDustPickupRequired());
    assertEquals("44", process.getDuctSize().toString());
    assertEquals("22", process.getDuctFlowrate().toString());
    assertEquals("1", process.getDustType().getId().toString());
    assertEquals("BH", process.getBaghouseCyclone().toString());
    assertEquals("65", process.getDustPickupVelocity().toString());
    assertEquals("These are my remarks", process.getProcessRemarks());
    assertFalse(process.isSpecificationRequired());    
  }

  public void testUpdateProcessFromRequest_ProcessHasNoChangesProcessIsNull_ReturnsNewProcess() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED, "");
    setupProcessInHelper(helper);
    Equipment eqipment = new Equipment();
    eqipment.setEquipmentType(new EquipmentType(new Long(123), null, null));
    eqipment.setId(new Long(234));
    eqipment.setProcess(null);
    com.monsanto.eas.eis.projects.domain.Process process = builder.createProcessFromRequest(eqipment, helper);
    assertNull(process.getId());
    assertEquals(eqipment, process.getEquipment());
  }

  public void testUpdateProcessFromRequest_EquipmentTypeNotSetProcessHasNoChangesProcessIsNull_ReturnsNewProcess() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED, "");
    setupProcessInHelper(helper);
    Equipment eqipment = new Equipment();
    eqipment.setId(new Long(234));
    eqipment.setProcess(null);
    com.monsanto.eas.eis.projects.domain.Process process = builder.createProcessFromRequest(eqipment, helper);
    assertNull(process.getId());
    assertEquals(0, process.getProcessFieldEquipmentTypes().size());
    assertEquals(eqipment, process.getEquipment());
  }

  public void testUpdateProcessFromRequest_EquipmentTypeSetProcessHasNoChanges_ReturnsNewProcessWithPfes() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED, "");
    setupProcessInHelper(helper);
    Equipment eqipment = new Equipment();
    eqipment.setId(new Long(234));
    eqipment.setEquipmentType(new EquipmentType(new Long(123), null, null));
    eqipment.setProcess(null);
    com.monsanto.eas.eis.projects.domain.Process process = builder.createProcessFromRequest(eqipment, helper);
    assertNull(process.getId());
    assertEquals(3, process.getProcessFieldEquipmentTypes().size());
    assertEquals(eqipment, process.getEquipment());
  }

  public void testUpdateProcessFromRequest_EquipmentTypeSetProcessHasNoChanges_ReturnsNewProcessWithNoPfes() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED, "");
    setupProcessInHelper(helper);
    Equipment eqipment = new Equipment();
    eqipment.setId(new Long(234));
    eqipment.setEquipmentType(new EquipmentType(new Long(345), null, null));
    eqipment.setProcess(null);
    com.monsanto.eas.eis.projects.domain.Process process = builder.createProcessFromRequest(eqipment, helper);
    assertNull(process.getId());
    assertEquals(0, process.getProcessFieldEquipmentTypes().size());
    assertEquals(eqipment, process.getEquipment());
  }

  public void testUpdateProcessFromRequest_ProcessHasNoChangesProcessIsNotNull_ReturnsExisitingProcess() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED, "");
    setupProcessInHelper(helper);
    Equipment eqipment = new Equipment();
    eqipment.setEquipmentType(new EquipmentType(new Long(123), null, null));
    Process existingProcess = new Process();
    existingProcess.setId(new Long(123));
    existingProcess.setEquipment(eqipment);
    eqipment.setProcess(existingProcess);
    com.monsanto.eas.eis.projects.domain.Process process = builder.createProcessFromRequest(eqipment, helper);
    assertEquals(existingProcess, process);
  }

  public void testUpdateProcessFromRequest_NewProcessHasChangesWithPfes_ReturnsProcessWithPfes() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED, "true");
    setupProcessInHelper(helper);
    Equipment eqipment = new Equipment();
    eqipment.setEquipmentType(new EquipmentType(new Long(123), null, null));
    eqipment.setProcess(null);
    helper.setRequestParameterValue("testFE1", "testFE Value 1");
    helper.setRequestParameterValue("testFE2", "testFE Value 2");
    com.monsanto.eas.eis.projects.domain.Process process = builder.createProcessFromRequest(eqipment, helper);
    assertNull(process.getId());
    assertEquals("Ear Corn", process.getProductType());
    assertNull(process.getProductDensity());
    assertNull(process.getDesignCapacity());
    assertEquals(new Long(1), process.getDesignCapacityUnit().getId());
    assertFalse(process.isCompAirRequired());
    assertEquals("5", process.getCompAirPressure().toString());
    assertEquals("56", process.getCompAirFlowrate().toString());
    assertTrue(process.isGasRequired());
    assertEquals("23", process.getGasPressure().toString());
    assertEquals("33", process.getGasFlowrate().toString());
    assertEquals("1", process.getGasType().getId().toString());
    assertFalse(process.isWaterRequired());
    assertEquals("43", process.getWaterPressure().toString());
    assertEquals("12", process.getWaterFlowrate().toString());
    assertEquals("1", process.getWaterType().getId().toString());
    assertTrue(process.isDustPickupRequired());
    assertEquals("44", process.getDuctSize().toString());
    assertEquals("22", process.getDuctFlowrate().toString());
    assertEquals("1", process.getDustType().getId().toString());
    assertEquals("BH", process.getBaghouseCyclone().toString());
    assertEquals("65", process.getDustPickupVelocity().toString());
    assertEquals("These are my remarks", process.getProcessRemarks());
    assertFalse(process.isSpecificationRequired());
    List<ProcessFieldEquipmentType> updatedPfes = process.getProcessFieldEquipmentTypes();
    assertEquals(3, updatedPfes.size());
    assertNull(updatedPfes.get(0).getId());
    assertEquals("testFE Value 1", updatedPfes.get(0).getValue());
    assertNull(updatedPfes.get(1).getId());
    assertEquals("testFE Value 2", updatedPfes.get(1).getValue());
    assertNull(updatedPfes.get(2).getValue());
    assertNull(updatedPfes.get(2).getId());
  }

  public void testUpdateProcessFromRequest_ExistingProcessHasChanges_ReturnsProcess() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED, "true");
    setupProcessInHelper(helper);
    Process existingProcess = new Process();
    existingProcess.setId(new Long(2L));
    Equipment eqipment = new Equipment();
    eqipment.setEquipmentType(new EquipmentType(new Long(123), null, null));
    existingProcess.setEquipment(eqipment);
    eqipment.setProcess(existingProcess);
    com.monsanto.eas.eis.projects.domain.Process process = builder.createProcessFromRequest(eqipment, helper);
    assertEquals(new Long(2L), process.getId());
    assertEquals("Ear Corn", process.getProductType());
    assertNull(process.getProductDensity());
    assertNull(process.getDesignCapacity());
    assertEquals(new Long(1), process.getDesignCapacityUnit().getId());
    assertFalse(process.isCompAirRequired());
    assertEquals("5", process.getCompAirPressure().toString());
    assertEquals("56", process.getCompAirFlowrate().toString());
    assertTrue(process.isGasRequired());
    assertEquals("23", process.getGasPressure().toString());
    assertEquals("33", process.getGasFlowrate().toString());
    assertEquals("1", process.getGasType().getId().toString());
    assertFalse(process.isWaterRequired());
    assertEquals("43", process.getWaterPressure().toString());
    assertEquals("12", process.getWaterFlowrate().toString());
    assertEquals("1", process.getWaterType().getId().toString());
    assertTrue(process.isDustPickupRequired());
    assertEquals("44", process.getDuctSize().toString());
    assertEquals("22", process.getDuctFlowrate().toString());
    assertEquals("1", process.getDustType().getId().toString());
    assertEquals("BH", process.getBaghouseCyclone().toString());
    assertEquals("65", process.getDustPickupVelocity().toString());
    assertEquals("These are my remarks", process.getProcessRemarks());
    assertFalse(process.isSpecificationRequired());
  }

  public void testUpdateProcessFromRequest_ExistingProcessNoHasChanges_ReturnsProcess() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED, "");
    setupProcessInHelper(helper);
    Process existingProcess = new Process();
    existingProcess.setId(new Long(2L));
    List<ProcessFieldEquipmentType> pfes = new ArrayList<ProcessFieldEquipmentType>();
    pfes.add(new ProcessFieldEquipmentType(new Long(11), existingProcess, new FieldEquipmentType(), "value 1"));
    pfes.add(new ProcessFieldEquipmentType(new Long(12), existingProcess, new FieldEquipmentType(), "value 2"));
    existingProcess.setProcessFieldEquipmentTypes(pfes);
    Equipment eqipment = new Equipment();
    eqipment.setEquipmentType(new EquipmentType(new Long(123), null, null));
    existingProcess.setEquipment(eqipment);
    eqipment.setProcess(existingProcess);
    com.monsanto.eas.eis.projects.domain.Process process = builder.createProcessFromRequest(eqipment, helper);
    assertEquals(new Long(2L), process.getId());
    assertEquals(2, process.getProcessFieldEquipmentTypes().size());
    assertEquals(new Long(11), process.getProcessFieldEquipmentTypes().get(0).getId());
    assertEquals("value 1", process.getProcessFieldEquipmentTypes().get(0).getValue());
    assertEquals(new Long(12), process.getProcessFieldEquipmentTypes().get(1).getId());
    assertEquals("value 2", process.getProcessFieldEquipmentTypes().get(1).getValue());
  }

  public void testUpdateProcessFromRequest_ExistingProcessHasChangesHasPfes_VerifyPfes() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED, "true");
    setupProcessInHelper(helper);
    Process existingProcess = getExistingProcess();
    Equipment equipment = new Equipment();
    equipment.setEquipmentType(new EquipmentType(new Long(123), null, null));
    existingProcess.setEquipment(equipment);
    equipment.setProcess(existingProcess);
    helper.setRequestParameterValue("testFE1", "testFE Value 1");
    helper.setRequestParameterValue("testFE2", "testFE Value 2");
    com.monsanto.eas.eis.projects.domain.Process process = builder.createProcessFromRequest(equipment, helper);
    assertEquals(new Long(2L), process.getId());
    assertEquals("Ear Corn", process.getProductType());
    assertNull(process.getProductDensity());
    assertNull(process.getDesignCapacity());
    assertEquals(new Long(1), process.getDesignCapacityUnit().getId());
    assertFalse(process.isCompAirRequired());
    assertEquals("5", process.getCompAirPressure().toString());
    assertEquals("56", process.getCompAirFlowrate().toString());
    assertTrue(process.isGasRequired());
    assertEquals("23", process.getGasPressure().toString());
    assertEquals("33", process.getGasFlowrate().toString());
    assertEquals("1", process.getGasType().getId().toString());
    assertFalse(process.isWaterRequired());
    assertEquals("43", process.getWaterPressure().toString());
    assertEquals("12", process.getWaterFlowrate().toString());
    assertEquals("1", process.getWaterType().getId().toString());
    assertTrue(process.isDustPickupRequired());
    assertEquals("44", process.getDuctSize().toString());
    assertEquals("22", process.getDuctFlowrate().toString());
    assertEquals("1", process.getDustType().getId().toString());
    assertEquals("BH", process.getBaghouseCyclone().toString());
    assertEquals("65", process.getDustPickupVelocity().toString());
    assertEquals("These are my remarks", process.getProcessRemarks());
    assertFalse(process.isSpecificationRequired());
    //todo assert that existing pfes are marked as deleted
//    List<ProcessFieldEquipmentType> existingPfes = equipment.getProcess().getProcessFieldEquipmentTypes();
//    assertEquals(1, existingPfes.size());
//    assertTrue(existingPfes.get(0).isDeleted());
    List<ProcessFieldEquipmentType> updatedPfes = process.getProcessFieldEquipmentTypes();
    assertEquals(3, updatedPfes.size());
    assertEquals("testFE Value 1", updatedPfes.get(0).getValue());
    assertEquals("testFE Value 2", updatedPfes.get(1).getValue());
    assertNull(updatedPfes.get(2).getValue());
  }

  private Process getExistingProcess() {
    Process existingProcess = new Process();
    existingProcess.setId(new Long(2L));
    ArrayList<ProcessFieldEquipmentType> pfes = new ArrayList<ProcessFieldEquipmentType>();
    pfes.add(new ProcessFieldEquipmentType());
    existingProcess.setProcessFieldEquipmentTypes(pfes);
    return existingProcess;
  }

  private void setupProcessInHelper(MockUCCHelper helper) {
    helper.setRequestParameterValue(ProcessConstants.PRODUCT_TYPE, "Ear Corn");
    helper.setRequestParameterValue(ProcessConstants.PRODUCT_DENSITY, "");
    helper.setRequestParameterValue(ProcessConstants.DESIGN_CAPACITY, "");
    helper.setRequestParameterValue(ProcessConstants.DESIGN_CAPACITY_UNIT, "12");
    helper.setRequestParameterValue(ProcessConstants.COMP_AIR_REQUIRED, "");
    helper.setRequestParameterValue(ProcessConstants.COMP_AIR_PRESSURE, "5");
    helper.setRequestParameterValue(ProcessConstants.COMP_AIR_FLOWRATE, "56");
    helper.setRequestParameterValue(ProcessConstants.GAS_REQUIRED, "on");
    helper.setRequestParameterValue(ProcessConstants.GAS_PRESSURE, "23");
    helper.setRequestParameterValue(ProcessConstants.GAS_FLOWRATE, "33");
    helper.setRequestParameterValue(ProcessConstants.GAS_TYPE, "1");
    helper.setRequestParameterValue(ProcessConstants.WATER_REQUIRED, "");
    helper.setRequestParameterValue(ProcessConstants.WATER_PRESSURE, "43");
    helper.setRequestParameterValue(ProcessConstants.WATER_FLOWRATE, "12");
    helper.setRequestParameterValue(ProcessConstants.WATER_TYPE, "1");
    helper.setRequestParameterValue(ProcessConstants.DUST_PICKUP_REQUIRED, "on");
    helper.setRequestParameterValue(ProcessConstants.DUCT_SIZE, "44");
    helper.setRequestParameterValue(ProcessConstants.DIST_FLOWRATE, "22");
    helper.setRequestParameterValue(ProcessConstants.DUST_TYPE, "1");
    helper.setRequestParameterValue(ProcessConstants.BAGHOUSE_CYCLONE, "BH");
    helper.setRequestParameterValue(ProcessConstants.DUST_PICKUP_VELOCITY, "65");
    helper.setRequestParameterValue(ProcessConstants.PROCESS_REMARKS, "These are my remarks");
    helper.setRequestParameterValue(ProcessConstants.SPECIFICATION_REQUIRED, "");
  }
}