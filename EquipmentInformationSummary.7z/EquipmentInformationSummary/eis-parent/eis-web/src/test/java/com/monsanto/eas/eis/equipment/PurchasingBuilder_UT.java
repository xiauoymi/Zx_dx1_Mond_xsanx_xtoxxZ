package com.monsanto.eas.eis.equipment;

import junit.framework.TestCase;

import java.io.IOException;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.logon.mock.MockUCCHelperEIS;
import com.monsanto.eas.eis.util.PurchasingConstants;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.projects.domain.Purchasing;
import com.monsanto.eas.eis.projects.domain.Equipment;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 28, 2008 Time: 1:29:39 PM To change this template use File |
 * Settings | File Templates.
 */
public class PurchasingBuilder_UT extends TestCase {

  public void testCreatePurchasingFromRequest_NewPurchasingHasChanged_ReturnsPurchasing() throws IOException {
    PurchasingBuilder purchasingBuilder = new PurchasingBuilder();
    MockUCCHelper helper = new MockUCCHelperEIS(null);
    helper.setRequestParameterValue(PurchasingConstants.HAS_PURCHASING_DATA_CHANGED, "true");
    helper.setRequestParameterValue(PurchasingConstants.VENDOR, "My Vendor");
    helper.setRequestParameterValue(PurchasingConstants.RTP_NUMBER, "123");
    helper.setRequestParameterValue(PurchasingConstants.PO_NUMBER, "123");
    helper.setRequestParameterValue(PurchasingConstants.LINE_NUMBER, "123");
    helper.setRequestParameterValue(PurchasingConstants.PO_LINE_AMOUNT, "123");
    helper.setRequestParameterValue(PurchasingConstants.PO_LINE_QUANTITY, "10");
    helper.setRequestParameterValue(PurchasingConstants.PO_LINE_VALUE, "123");
    helper.setRequestParameterValue(PurchasingConstants.CO_AMOUNT, "123");
    helper.setRequestParameterValue(PurchasingConstants.ORIGINAL_SHIP_DATE, "Oct 27, 2008");
    helper.setRequestParameterValue(PurchasingConstants.REVISED_SHIP_DATE, "Oct 28, 2008");
    helper.setRequestParameterValue(PurchasingConstants.ACTUAL_DELIVERY_DATE, "Oct 29, 2008");
    helper.setRequestParameterValue(PurchasingConstants.EXPORT_DOCUMENTS, "true");
    Purchasing purchasing = null;
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null,null, null);
    purchasing = purchasingBuilder.createPurchasingFromRequest(equipment, helper);

    assertEquals("My Vendor", purchasing.getVendor());
    assertEquals(new Integer(123), purchasing.getRtpNumber());
    assertEquals(new Long(123), purchasing.getPoNumber());
    assertEquals(new Integer(123), purchasing.getLineNumber());
    assertEquals(new Long(123), purchasing.getPoLineAmount());
    assertEquals(new Integer(10), purchasing.getPoLineQuantity());
    assertEquals(new Long(123), purchasing.getPoLineValue());
    assertEquals(new Long(123), purchasing.getCoAmount());
    assertEquals("Oct 27, 2008", ConvertUtil.toString(purchasing.getOriginalShipDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 28, 2008", ConvertUtil.toString(purchasing.getRevisedShipDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 29, 2008", ConvertUtil.toString(purchasing.getActualDeliveryDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals(true, purchasing.isExportDocuments());
  }

  public void testCreatePurchasingFromRequest_ExistingPurchasingHasChanged_ReturnsPurchasing() throws IOException {
    PurchasingBuilder purchasingBuilder = new PurchasingBuilder();
    MockUCCHelper helper = new MockUCCHelperEIS(null);
    helper.setRequestParameterValue(PurchasingConstants.HAS_PURCHASING_DATA_CHANGED, "true");
    helper.setRequestParameterValue(PurchasingConstants.VENDOR, "My Vendor");
    helper.setRequestParameterValue(PurchasingConstants.RTP_NUMBER, "123");
    helper.setRequestParameterValue(PurchasingConstants.PO_NUMBER, "123");
    helper.setRequestParameterValue(PurchasingConstants.LINE_NUMBER, "123");
    helper.setRequestParameterValue(PurchasingConstants.PO_LINE_AMOUNT, "123");
    helper.setRequestParameterValue(PurchasingConstants.PO_LINE_QUANTITY, "10");
    helper.setRequestParameterValue(PurchasingConstants.PO_LINE_VALUE, "123");
    helper.setRequestParameterValue(PurchasingConstants.CO_AMOUNT, "123");
    helper.setRequestParameterValue(PurchasingConstants.ORIGINAL_SHIP_DATE, "Oct 27, 2008");
    helper.setRequestParameterValue(PurchasingConstants.REVISED_SHIP_DATE, "Oct 28, 2008");
    helper.setRequestParameterValue(PurchasingConstants.ACTUAL_DELIVERY_DATE, "Oct 29, 2008");
    helper.setRequestParameterValue(PurchasingConstants.EXPORT_DOCUMENTS, "true");
    Purchasing purchasing = new Purchasing();
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null,null, null);
    equipment.setPurchasing(purchasing);
    purchasing = purchasingBuilder.createPurchasingFromRequest(equipment, helper);

    assertEquals("My Vendor", purchasing.getVendor());
    assertEquals(new Integer(123), purchasing.getRtpNumber());
    assertEquals(new Long(123), purchasing.getPoNumber());
    assertEquals(new Integer(123), purchasing.getLineNumber());
    assertEquals(new Long(123), purchasing.getPoLineAmount());
    assertEquals(new Integer(10), purchasing.getPoLineQuantity());
    assertEquals(new Long(123), purchasing.getPoLineValue());
    assertEquals(new Long(123), purchasing.getCoAmount());
    assertEquals("Oct 27, 2008", ConvertUtil.toString(purchasing.getOriginalShipDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 28, 2008", ConvertUtil.toString(purchasing.getRevisedShipDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 29, 2008", ConvertUtil.toString(purchasing.getActualDeliveryDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals(true, purchasing.isExportDocuments());
  }

  public void testCreatePurchasingFromRequest_NewPurchasingIsNullNoChanges_ReturnsNewPurchasing() throws IOException {
    PurchasingBuilder purchasingBuilder = new PurchasingBuilder();
    MockUCCHelper helper = new MockUCCHelperEIS(null);
    helper.setRequestParameterValue(PurchasingConstants.HAS_PURCHASING_DATA_CHANGED, "");
    Purchasing purchasing = null;
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null,null, null);
    equipment.setId(new Long(123));
    purchasing = purchasingBuilder.createPurchasingFromRequest(equipment, helper);
    assertNull(purchasing.getId());
    assertEquals(equipment, purchasing.getEquipment());
  }

  public void testCreatePurchasingFromRequest_NewPurchasingIsNotNullNoChanges_ReturnsExisitingPurchasing() throws IOException {
    PurchasingBuilder purchasingBuilder = new PurchasingBuilder();
    MockUCCHelper helper = new MockUCCHelperEIS(null);
    helper.setRequestParameterValue(PurchasingConstants.HAS_PURCHASING_DATA_CHANGED, "");
    Purchasing existingPurchasing = new Purchasing();
    existingPurchasing.setId(new Long(234));
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null,null, null);
    equipment.setId(new Long(123));
    equipment.setPurchasing(existingPurchasing);
    Purchasing purchasing = purchasingBuilder.createPurchasingFromRequest(equipment, helper);
    assertEquals(existingPurchasing, purchasing);
  }

}
