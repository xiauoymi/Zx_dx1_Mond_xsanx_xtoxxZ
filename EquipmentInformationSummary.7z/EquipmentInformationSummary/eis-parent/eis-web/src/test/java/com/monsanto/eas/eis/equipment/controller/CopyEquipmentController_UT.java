/*
 CopyEquipmentController_UT was created on Feb 5, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.equipment.service.EquipmentService;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.domain.Area;
import com.monsanto.eas.eis.projects.domain.EquipmentType;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.mocks.MockEquipmentServiceImpl;
import com.monsanto.eas.eis.projects.mocks.MockProjectServiceImpl;
import com.monsanto.eas.eis.util.CopyEquipmentConstants;
import com.monsanto.eas.eis.util.EISConstants;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.List;

/**
 * Filename:    $RCSfile: CopyEquipmentController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: sspati1 $    	 On:	$Date: 2009-02-20 17:45:54 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class CopyEquipmentController_UT extends XMLTestCase {
  public void testSetupSearchForEquipmentsToCopy_VerifyResponse() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "setupSearchForEquipmentsToCopy");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "123");
    helper.setRequestParameterValue(EISConstants.COPY_FROM_MASTER, "true");
    helper.setRequestParameterValue(EISConstants.SAVE_SUCCESSFUL_MSG, "success msg");
    ProjectsService projectService = new MockProjectServiceImpl(null);
    EquipmentService equipmentService = new MockEquipmentServiceImpl();
    CopyEquipmentController controller = new CopyEquipmentController(projectService, equipmentService);
    controller.run(helper);
    assertEquals("success msg", helper.getRequestAttributeValue(EISConstants.SAVE_SUCCESSFUL_MSG));
    Projects project = (Projects) helper.getRequestAttributeValue(EISConstants.PROJECT_DETAIL);
    assertEquals(new Long(123), project.getId());
    assertEquals(new Long(12345), helper.getRequestAttributeValue(CopyEquipmentConstants.COPY_FROM_PROJECT_ID));
    assertEquals("name", project.getProjName());
    assertEquals("12345678", project.getProjNumber());
    List<EquipmentType> types = (List<EquipmentType>) helper.getRequestAttributeValue(EISConstants.EQUIPMENT_TYPES);
    assertEquals(2, types.size());
    assertEquals("Conveyor", types.get(0).getName());
    List<Area> areas = (List<Area>) helper.getRequestAttributeValue(EISConstants.EQUIPMENT_AREAS);
    assertEquals(2, areas.size());
    assertEquals("desc 1", areas.get(0).getDescription());
    assertTrue(helper.wasSentTo(CopyEquipmentConstants.SEARCH_EQUIPMENTS_TO_COPY_JSP));
  }

  public void testSetupSearchForEquipmentsToCopy_DontCopyFromMaster_VerifyResponse() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "setupSearchForEquipmentsToCopy");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "123");
    helper.setRequestParameterValue(EISConstants.COPY_FROM_MASTER, "false");
    helper.setRequestParameterValue(EISConstants.SAVE_SUCCESSFUL_MSG, "success msg");
    ProjectsService projectService = new MockProjectServiceImpl(null);
    EquipmentService equipmentService = new MockEquipmentServiceImpl();
    CopyEquipmentController controller = new CopyEquipmentController(projectService, equipmentService);
    controller.run(helper);
    assertEquals("success msg", helper.getRequestAttributeValue(EISConstants.SAVE_SUCCESSFUL_MSG));
    Projects project = (Projects) helper.getRequestAttributeValue(EISConstants.PROJECT_DETAIL);
    assertEquals(new Long(123), project.getId());
    assertEquals(new Long(123), helper.getRequestAttributeValue(CopyEquipmentConstants.COPY_FROM_PROJECT_ID));
    assertEquals("name", project.getProjName());
    assertEquals("12345678", project.getProjNumber());
    List<EquipmentType> types = (List<EquipmentType>) helper.getRequestAttributeValue(EISConstants.EQUIPMENT_TYPES);
    assertEquals(2, types.size());
    assertEquals("Conveyor", types.get(0).getName());
    List<Area> areas = (List<Area>) helper.getRequestAttributeValue(EISConstants.EQUIPMENT_AREAS);
    assertEquals(2, areas.size());
    assertEquals("desc 1", areas.get(0).getDescription());
    assertTrue(helper.wasSentTo(CopyEquipmentConstants.SEARCH_EQUIPMENTS_TO_COPY_JSP));
  }

  public void testSetupEquipmentsToCopy_VerifyResponse() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "setupEquipmentsToCopy");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "123");
    helper.setRequestParameterValue(EISConstants.COPY_FROM_MASTER, "true");
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_ID_TO_COPY, "234");
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_QUANTITY, "55");
    ProjectsService projectService = new MockProjectServiceImpl(null);
    EquipmentService equipmentService = new MockEquipmentServiceImpl();
    CopyEquipmentController controller = new CopyEquipmentController(projectService, equipmentService);
    controller.run(helper);
    Projects project = (Projects) helper.getRequestAttributeValue(EISConstants.PROJECT_DETAIL);
    assertEquals(new Long(123), project.getId());
    assertEquals("name", project.getProjName());
    assertEquals("12345678", project.getProjNumber());
    assertEquals("234", helper.getRequestAttributeValue(CopyEquipmentConstants.EQUIPMENT_ID_TO_COPY));
    assertEquals("55", helper.getRequestAttributeValue(CopyEquipmentConstants.EQUIPMENT_QUANTITY));
    assertEquals("true", helper.getRequestAttributeValue(EISConstants.COPY_FROM_MASTER));
    assertTrue(helper.wasSentTo(CopyEquipmentConstants.EDIT_EQUIPMENTS_BEFORE_COPYING_JSP));
  }

  public void testLookupRefDataForEditEquipmentsBeforeCopyingXML_VerifyResponse() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForEditEquipmentsBeforeCopyingXML");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "123");
    ProjectsService projectService = new MockProjectServiceImpl(null);
    EquipmentService equipmentService = new MockEquipmentServiceImpl();
    CopyEquipmentController controller = new CopyEquipmentController(projectService, equipmentService);
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//areas)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//area)", xmlDoc);
    assertXpathEvaluatesTo("13", "//area[1]/id", xmlDoc);
    assertXpathEvaluatesTo("code 1 - desc 1", "//area[1]/areaCodeDescription", xmlDoc);
    assertXpathEvaluatesTo("12", "//area[2]/id", xmlDoc);
    assertXpathEvaluatesTo("code 2 - desc 2", "//area[2]/areaCodeDescription", xmlDoc);
  }

  public void testCopyEquipmentsToProject_RequiredDataMissingAndInvalidLength_VerifyErrors() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "copyEquipmentsToProject");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "123");
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_ID_TO_COPY, "234");
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_NAME, new String[]{"name 1", ""});
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_AREA, new String[]{"", "22"});
    helper.setRequestParameterValue(CopyEquipmentConstants.PROCESS_LINE_NUMBER, new String[]{"2", ""});
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_TAG_NUMBER, new String[]{"2", ""});
    ProjectsService projectService = new MockProjectServiceImpl(null);
    EquipmentService equipmentService = new MockEquipmentServiceImpl();
    CopyEquipmentControllerOverridesClearHiberateSession controller = new CopyEquipmentControllerOverridesClearHiberateSession(
        projectService, equipmentService);
    controller.run(helper);

    assertTrue(controller.isHibernateSessionCleared());
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("", "//successMsg", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//errors/error)", xmlDoc);
    assertXpathEvaluatesTo("Required Fields:", "//errors/error[1]/errorHeader", xmlDoc);
    assertXpathEvaluatesTo("4", "count(//errors/error[1]/errorMsg)", xmlDoc);
    assertXpathEvaluatesTo("On row 1: Equipment Area is a required field", "//errors/error[1]/errorMsg[1]", xmlDoc);
    assertXpathEvaluatesTo("On row 2: Equipment Name is a required field", "//errors/error[1]/errorMsg[2]", xmlDoc);
    assertXpathEvaluatesTo("On row 2: Process Line Number is a required field", "//errors/error[1]/errorMsg[3]",
        xmlDoc);
    assertXpathEvaluatesTo("On row 2: Equipment Tag Number is a required field", "//errors/error[1]/errorMsg[4]",
        xmlDoc);
    assertXpathEvaluatesTo("Fields with invalid length:", "//errors/error[2]/errorHeader", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//errors/error[2]/errorMsg)", xmlDoc);
    assertXpathEvaluatesTo("On row 1: Equipment Tag Number has an invalid minimum length",
        "//errors/error[2]/errorMsg[1]", xmlDoc);
    assertXpathEvaluatesTo("On row 2: Equipment Tag Number has an invalid minimum length",
        "//errors/error[2]/errorMsg[2]", xmlDoc);
  }

  public void testCopyEquipmentsToProject_DataWithInvalidLength_VerifyErrors() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "copyEquipmentsToProject");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "123");
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_ID_TO_COPY, "234");
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_NAME, new String[]{"name 1", "name 2"});
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_AREA, new String[]{"11", "22"});
    helper.setRequestParameterValue(CopyEquipmentConstants.PROCESS_LINE_NUMBER, new String[]{"2", "4"});
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_TAG_NUMBER, new String[]{"2", "333"});
    ProjectsService projectService = new MockProjectServiceImpl(null);
    EquipmentService equipmentService = new MockEquipmentServiceImpl();
    CopyEquipmentControllerOverridesClearHiberateSession controller = new CopyEquipmentControllerOverridesClearHiberateSession(
        projectService, equipmentService);
    controller.run(helper);

    assertTrue(controller.isHibernateSessionCleared());
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("", "//successMsg", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/error)", xmlDoc);
    assertXpathEvaluatesTo("Fields with invalid length:", "//errors/error[1]/errorHeader", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/error[1]/errorMsg)", xmlDoc);
    assertXpathEvaluatesTo("On row 1: Equipment Tag Number has an invalid minimum length",
        "//errors/error[1]/errorMsg[1]", xmlDoc);
  }

  public void testCopyEquipmentsToProject_RequiredDataMissing_VerifyErrors() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "copyEquipmentsToProject");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "123");
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_ID_TO_COPY, "234");
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_NAME, new String[]{"name 1", "name 2"});
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_AREA, new String[]{"11", "22"});
    helper.setRequestParameterValue(CopyEquipmentConstants.PROCESS_LINE_NUMBER, new String[]{"", "4"});
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_TAG_NUMBER, new String[]{"233", "333"});
    ProjectsService projectService = new MockProjectServiceImpl(null);
    EquipmentService equipmentService = new MockEquipmentServiceImpl();
    CopyEquipmentControllerOverridesClearHiberateSession controller = new CopyEquipmentControllerOverridesClearHiberateSession(
        projectService, equipmentService);
    controller.run(helper);

    assertTrue(controller.isHibernateSessionCleared());
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("", "//successMsg", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/error)", xmlDoc);
    assertXpathEvaluatesTo("Required Fields:", "//errors/error[1]/errorHeader", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/error[1]/errorMsg)", xmlDoc);
    assertXpathEvaluatesTo("On row 1: Process Line Number is a required field", "//errors/error[1]/errorMsg[1]",
        xmlDoc);
  }

  public void testCopyEquipmentsToProject_HasNoErrors_VerifyDataWasSaved() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "copyEquipmentsToProject");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "12345");
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_ID_TO_COPY, "2");
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_NAME, new String[]{"name 1", "name 2"});
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_AREA, new String[]{"11", "22"});
    helper.setRequestParameterValue(CopyEquipmentConstants.PROCESS_LINE_NUMBER, new String[]{"2", "4"});
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_TAG_NUMBER, new String[]{"222", "333"});
    ProjectsService projectService = new MockProjectServiceImpl(null);
    MockEquipmentServiceImpl equipmentService = new MockEquipmentServiceImpl();
    CopyEquipmentController controller = new CopyEquipmentController(projectService, equipmentService);
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("2 Equipment Item(s) successfully saved", "//successMsg", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors)", xmlDoc);
    assertXpathEvaluatesTo("0", "count(//errors/error)", xmlDoc);

    List<Equipment> equipments = equipmentService.getSavedEquipments();
    assertEquals(2, equipments.size());
    Equipment equipment = equipments.get(0);
    assertEquals("name 1", equipment.getName());
    assertEquals(new Long(11), equipment.getArea().getId());
    assertEquals("2", equipment.getProcessLineNumber());
    assertEquals("222", equipment.getEquipmentTagNumber());
    assertEquals("code 1.2.222W", equipment.getEquipmentNumber());
    assertEquals("Test engineer", equipment.getMechanical().getEngineer());
    assertEquals(new Long(12345), equipment.getProjects().getId());

    equipment = equipments.get(1);
    assertEquals("name 2", equipment.getName());
    assertEquals(new Long(22), equipment.getArea().getId());
    assertEquals("4", equipment.getProcessLineNumber());
    assertEquals("333", equipment.getEquipmentTagNumber());
    assertEquals("code 1.4.333W", equipment.getEquipmentNumber());
    assertEquals("Test engineer", equipment.getMechanical().getEngineer());
    assertEquals(new Long(12345), equipment.getProjects().getId());
  }

  private class CopyEquipmentControllerOverridesClearHiberateSession extends CopyEquipmentController {
    private boolean hibernateSessionCleared;

    public CopyEquipmentControllerOverridesClearHiberateSession(
        ProjectsService projectService, EquipmentService equipmentService) {
      super(projectService, equipmentService);
    }

    //protected for testing

    public void clearHibernateSession() {
      this.hibernateSessionCleared = true;
    }

    public boolean isHibernateSessionCleared() {
      return hibernateSessionCleared;
    }
  }
}