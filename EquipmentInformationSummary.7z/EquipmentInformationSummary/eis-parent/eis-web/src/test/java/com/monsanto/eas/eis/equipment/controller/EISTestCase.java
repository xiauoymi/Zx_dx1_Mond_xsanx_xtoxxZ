/*
 EISTestCase was created on Dec 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.controller;

import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.hibernate.HibernateFactory;
import org.custommonkey.xmlunit.XMLTestCase;

/**
 * Filename:    $RCSfile: EISTestCase.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-15 19:34:25 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class EISTestCase extends XMLTestCase {
  private HibernateFactory hibernate;

  protected void setUp() throws Exception {
    super.setUp();
    hibernate = EISHibernateUtil.getHibernateFactory();
    hibernate.beginTransaction();
  }

  protected void tearDown() throws Exception {
    super.tearDown();
    hibernate.rollbackTransaction();
  }

  public void testTrue() throws Exception {
    assertTrue(true);
  }
}
