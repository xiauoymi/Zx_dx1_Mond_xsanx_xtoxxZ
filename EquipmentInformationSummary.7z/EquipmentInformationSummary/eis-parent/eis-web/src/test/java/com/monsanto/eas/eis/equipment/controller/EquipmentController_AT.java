package com.monsanto.eas.eis.equipment.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.projects.*;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.domain.Process;
import com.monsanto.eas.eis.projects.services.ProjectsServiceImpl;
import com.monsanto.eas.eis.util.*;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.Restrictions;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Sep 3, 2008 Time: 4:36:32 PM To change this template use File | Settings
 * | File Templates.
 */
public class EquipmentController_AT extends EISTestCase {
  private EquipmentController ec;

  protected void setUp() throws Exception {
    super.setUp();
    ec = new EquipmentController();
  }

  /**
   * Test Case for submitting add Equipment
   */
  public void testSaveEquipment_NewEquipmentAllRequiredFieldsEntered_EquipmentAndAssociationsSaved() throws
      IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED, true);
    helper.setRequestParameterValue(InstrumentConstants.HAS_INTRUMENTS_DATA_CHANGED, true);
    helper.setRequestParameterValue(MotorConstants.HAS_MOTORS_DATA_CHANGED, true);
    Projects project = Projects_AT_TestCaseHelper.setupProject();

    String projectId = project.getId().toString();
    Area area = project.getCrop().getAreas().get(0);
    EquipmentType et = Projects_AT_TestCaseHelper.findEquipmentTypeByName("Conveyor");
    EquipmentType subTypeOne = et.getSubEquipmentTypes().get(0);

    GasType gasType = Projects_AT_TestCaseHelper.findGasTypeByType("Natural Gas");
    WaterType waterType = Projects_AT_TestCaseHelper.findWaterTypeByType("Potable");
    DustType dustType = Projects_AT_TestCaseHelper.findDustTypeByType("White");
    List<FieldEquipmentType> feList = Projects_AT_TestCaseHelper.lookupAllFieldEquipmentTypes(et.getId());

    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, projectId);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_AREA, String.valueOf(area.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.PROCESS_LINE_NUMBER, "0");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TAG_NUMBER, "123");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TYPE_ID, String.valueOf(et.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_NAME, "Equip Name");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_SUB_TYPE_ID, String.valueOf(subTypeOne.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_DESCRIPTION, "My Equip Desc");

    helper.setRequestParameterValue(ProcessConstants.PRODUCT_TYPE, "Ear Corn");
    helper.setRequestParameterValue(ProcessConstants.PRODUCT_DENSITY, "");
    helper.setRequestParameterValue(ProcessConstants.DESIGN_CAPACITY, "");
    helper.setRequestParameterValue(ProcessConstants.COMP_AIR_REQUIRED, "");
    helper.setRequestParameterValue(ProcessConstants.COMP_AIR_PRESSURE, "5");
    helper.setRequestParameterValue(ProcessConstants.COMP_AIR_FLOWRATE, "56");
    helper.setRequestParameterValue(ProcessConstants.GAS_REQUIRED, "on");
    helper.setRequestParameterValue(ProcessConstants.GAS_PRESSURE, "23");
    helper.setRequestParameterValue(ProcessConstants.GAS_FLOWRATE, "33");
    helper.setRequestParameterValue(ProcessConstants.GAS_TYPE, gasType.getId());
    helper.setRequestParameterValue(ProcessConstants.WATER_REQUIRED, "");
    helper.setRequestParameterValue(ProcessConstants.WATER_PRESSURE, "43");
    helper.setRequestParameterValue(ProcessConstants.WATER_FLOWRATE, "12");
    helper.setRequestParameterValue(ProcessConstants.WATER_TYPE, waterType.getId());
    helper.setRequestParameterValue(ProcessConstants.DUST_PICKUP_REQUIRED, "on");
    helper.setRequestParameterValue(ProcessConstants.DUCT_SIZE, "44");
    helper.setRequestParameterValue(ProcessConstants.DIST_FLOWRATE, "22");
    helper.setRequestParameterValue(ProcessConstants.DUST_TYPE, dustType.getId());
    helper.setRequestParameterValue(ProcessConstants.BAGHOUSE_CYCLONE, "BH");
    helper.setRequestParameterValue(ProcessConstants.DUST_PICKUP_VELOCITY, "65");
    helper.setRequestParameterValue(ProcessConstants.PROCESS_REMARKS, "These are my remarks");
    helper.setRequestParameterValue(ProcessConstants.SPECIFICATION_REQUIRED, "");

    setMotorDataInHelper(helper);
    setInstrumentsInHelper(helper);

    for (FieldEquipmentType fe : feList) {
      if (fe.getFieldType().getType().equalsIgnoreCase("text")) {
        helper.setRequestParameterValue(fe.getName(), "22");
      } else if (fe.getFieldType().getType().equalsIgnoreCase("textarea")) {
        helper.setRequestParameterValue(fe.getName(), "22 comments");
      } else if (fe.getFieldType().getType().equalsIgnoreCase("select")) {
        List<ListValue> listValues = fe.getListValues();
        helper.setRequestParameterValue(fe.getName(), listValues.get(0).getId().toString());
      } else if (fe.getFieldType().getType().equalsIgnoreCase("checkbox")) {
        helper.setRequestParameterValue(fe.getName(), "on");
      } else if (fe.getFieldType().getType().equalsIgnoreCase("radio")) {
        helper.setRequestParameterValue(fe.getName(), "y");
      }
    }

    ec.run(helper);

    List<Equipment> equipments = Projects_AT_TestCaseHelper.findEquipmentByCriteria(Long.valueOf(projectId));
    assertEquals(1, equipments.size());
    Equipment eqipment = equipments.get(0);
    assertNotNull(eqipment.getId());
    assertEquals("0", eqipment.getProcessLineNumber());
    assertEquals(area, eqipment.getArea());
    assertEquals(et, eqipment.getEquipmentType());
    assertEquals(subTypeOne, eqipment.getSubType());
    assertEquals("123", eqipment.getEquipmentTagNumber());
    assertEquals("Equip Name", eqipment.getName());
    assertEquals("My Equip Desc", eqipment.getDescription());
    assertEquals("1.0.123C", eqipment.getEquipmentNumber());

    Process process = eqipment.getProcess();
    assertNotNull(process.getId());
    assertEquals("Ear Corn", process.getProductType());
    assertNull(process.getProductDensity());
    assertNull(process.getDesignCapacity());
    assertFalse(process.isCompAirRequired());
    assertEquals("5", process.getCompAirPressure().toString());
    assertEquals("56", process.getCompAirFlowrate().toString());
    assertTrue(process.isGasRequired());
    assertEquals("23", process.getGasPressure().toString());
    assertEquals("33", process.getGasFlowrate().toString());
    assertEquals(gasType.getId(), process.getGasType().getId());
    assertFalse(process.isWaterRequired());
    assertEquals("43", process.getWaterPressure().toString());
    assertEquals("12", process.getWaterFlowrate().toString());
    assertEquals(waterType.getId(), process.getWaterType().getId());
    assertTrue(process.isDustPickupRequired());
    assertEquals("44", process.getDuctSize().toString());
    assertEquals("22", process.getDuctFlowrate().toString());
    assertEquals(dustType.getId(), process.getDustType().getId());
    assertEquals("BH", process.getBaghouseCyclone().toString());
    assertEquals("65", process.getDustPickupVelocity().toString());
    assertEquals("These are my remarks", process.getProcessRemarks());
    assertFalse(process.isSpecificationRequired());
    assertEquals(feList.size(), process.getProcessFieldEquipmentTypes().size());

    List<ProcessFieldEquipmentType> processFieldEquipmentTypes = process.getProcessFieldEquipmentTypes();
    for (ProcessFieldEquipmentType pfe : processFieldEquipmentTypes) {
      if (pfe.getFieldEquipmentType().getFieldType().getType().equalsIgnoreCase("text")) {
        assertEquals(pfe.getValue(), "22");
      } else if (pfe.getFieldEquipmentType().getFieldType().getType().equalsIgnoreCase("textarea")) {
        assertEquals(pfe.getValue(), "22 comments");
      } else if (pfe.getFieldEquipmentType().getFieldType().getType().equalsIgnoreCase("select")) {
        List<ListValue> listValues = pfe.getFieldEquipmentType().getListValues();
        assertEquals(pfe.getValue(), listValues.get(0).getId().toString());
      } else if (pfe.getFieldEquipmentType().getFieldType().getType().equalsIgnoreCase("checkbox")) {
        assertEquals(pfe.getValue(), "on");
      } else if (pfe.getFieldEquipmentType().getFieldType().getType().equalsIgnoreCase("radio")) {
        assertEquals(pfe.getValue(), "y");
      }
    }
    assertEquals(2, eqipment.getMotors().size());
    assertMotorData(eqipment.getMotors());
    assertInstrumentData(eqipment);

    //Projects_AT_TestCaseHelper.deleteTestProject(project.getProjName());
    EISDAOFactory daoFactory = new EISDAOFactoryImpl(EISHibernateUtil.getHibernateFactory());
    ProjectsServiceImpl projectService = new ProjectsServiceImpl(daoFactory);
    ProjectsController spc = new ProjectsController();
    MockUCCHelper deleteHelper = new MockUCCHelper(null);
    deleteHelper.setRequestParameterValue("method", "deleteProject");
    deleteHelper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
    spc.run(deleteHelper);
  }

  public void testSaveEquipment_UpdateEquipmentAllRequiredFieldsEntered_EquipmentAndAssociationsSaved() throws
      IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ProcessConstants.HAS_PROCESS_DATA_CHANGED, true);
    helper.setRequestParameterValue(InstrumentConstants.HAS_INTRUMENTS_DATA_CHANGED, true);
    helper.setRequestParameterValue(MotorConstants.HAS_MOTORS_DATA_CHANGED, true);

    Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
    Projects project = equipment.getProjects();
    GasType gasType = Projects_AT_TestCaseHelper.findGasTypeByType("Natural Gas");
    WaterType waterType = Projects_AT_TestCaseHelper.findWaterTypeByType("Potable");
    DustType dustType = Projects_AT_TestCaseHelper.findDustTypeByType("White");
    List<FieldEquipmentType> feList = Projects_AT_TestCaseHelper.lookupAllFieldEquipmentTypes(equipment.getEquipmentType().getId());

    String projectId = String.valueOf(project.getId().longValue());
    String equiopmentId = String.valueOf(equipment.getId().longValue());
    Area area = project.getCrop().getAreas().get(0);
    EquipmentType et = Projects_AT_TestCaseHelper.findEquipmentTypeByName("Conveyor");
    EquipmentType subTypeOne = et.getSubEquipmentTypes().get(0);

    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, projectId);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, equiopmentId);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_AREA, String.valueOf(area.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.PROCESS_LINE_NUMBER, "1");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TAG_NUMBER, "234");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TYPE_ID, String.valueOf(et.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_NAME, "Equip Name New");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_SUB_TYPE_ID, String.valueOf(subTypeOne.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_DESCRIPTION, "My Equip Desc New");

    helper.setRequestParameterValue(ProcessConstants.PRODUCT_TYPE, "Ear Corn New");
    helper.setRequestParameterValue(ProcessConstants.PRODUCT_DENSITY, "22");
    helper.setRequestParameterValue(ProcessConstants.DESIGN_CAPACITY, "33");
    helper.setRequestParameterValue(ProcessConstants.COMP_AIR_REQUIRED, "on");
    helper.setRequestParameterValue(ProcessConstants.COMP_AIR_PRESSURE, "6");
    helper.setRequestParameterValue(ProcessConstants.COMP_AIR_FLOWRATE, "66");
    helper.setRequestParameterValue(ProcessConstants.GAS_REQUIRED, "");
    helper.setRequestParameterValue(ProcessConstants.GAS_PRESSURE, "24");
    helper.setRequestParameterValue(ProcessConstants.GAS_FLOWRATE, "34");
    helper.setRequestParameterValue(ProcessConstants.GAS_TYPE, gasType.getId());
    helper.setRequestParameterValue(ProcessConstants.WATER_REQUIRED, "on");
    helper.setRequestParameterValue(ProcessConstants.WATER_PRESSURE, "44");
    helper.setRequestParameterValue(ProcessConstants.WATER_FLOWRATE, "13");
    helper.setRequestParameterValue(ProcessConstants.WATER_TYPE, waterType.getId());
    helper.setRequestParameterValue(ProcessConstants.DUST_PICKUP_REQUIRED, "");
    helper.setRequestParameterValue(ProcessConstants.DUCT_SIZE, "45");
    helper.setRequestParameterValue(ProcessConstants.DIST_FLOWRATE, "23");
    helper.setRequestParameterValue(ProcessConstants.DUST_TYPE, dustType.getId());
    helper.setRequestParameterValue(ProcessConstants.BAGHOUSE_CYCLONE, "CC");
    helper.setRequestParameterValue(ProcessConstants.DUST_PICKUP_VELOCITY, "66");
    helper.setRequestParameterValue(ProcessConstants.PROCESS_REMARKS, "These are my remarks New");
    helper.setRequestParameterValue(ProcessConstants.SPECIFICATION_REQUIRED, "Y");

    setMotorDataInHelper(helper);
    setInstrumentsInHelper(helper);

    for (FieldEquipmentType fe : feList) {
      if (fe.getFieldType().getType().equalsIgnoreCase("text")) {
        helper.setRequestParameterValue(fe.getName(), "23");
      } else if (fe.getFieldType().getType().equalsIgnoreCase("textarea")) {
        helper.setRequestParameterValue(fe.getName(), "23 comments");
      } else if (fe.getFieldType().getType().equalsIgnoreCase("select")) {
        List<ListValue> listValues = fe.getListValues();
        helper.setRequestParameterValue(fe.getName(), listValues.get(1).getId().toString());
      } else if (fe.getFieldType().getType().equalsIgnoreCase("checkbox")) {
        helper.setRequestParameterValue(fe.getName(), "on");
      } else if (fe.getFieldType().getType().equalsIgnoreCase("radio")) {
        helper.setRequestParameterValue(fe.getName(), "n");
      }
    }

    ec.run(helper);

    List<Equipment> equipments = Projects_AT_TestCaseHelper.findEquipmentByCriteria(Long.valueOf(projectId));
    assertEquals(1, equipments.size());
    Equipment updatedEquipment = equipments.get(0);
    assertEquals(equipment.getId(), updatedEquipment.getId());
    assertEquals("1", updatedEquipment.getProcessLineNumber());
    assertEquals(area, updatedEquipment.getArea());
    assertEquals(et, updatedEquipment.getEquipmentType());
    assertEquals(subTypeOne, updatedEquipment.getSubType());
    assertEquals("234", updatedEquipment.getEquipmentTagNumber());
    assertEquals("Equip Name New", updatedEquipment.getName());
    assertEquals("My Equip Desc New", updatedEquipment.getDescription());
    assertEquals("1.1.234C", updatedEquipment.getEquipmentNumber());

    Process process = updatedEquipment.getProcess();
    assertEquals(equipment.getProcess().getId(), process.getId());
    assertEquals("Ear Corn New", process.getProductType());
    assertEquals("22.0", process.getProductDensity().toString());
    assertEquals("33", process.getDesignCapacity().toString());
    assertTrue(process.isCompAirRequired());
    assertEquals("6", process.getCompAirPressure().toString());
    assertEquals("66", process.getCompAirFlowrate().toString());
    assertFalse(process.isGasRequired());
    assertEquals("24", process.getGasPressure().toString());
    assertEquals("34", process.getGasFlowrate().toString());
    assertEquals(gasType.getId(), process.getGasType().getId());
    assertTrue(process.isWaterRequired());
    assertEquals("44", process.getWaterPressure().toString());
    assertEquals("13", process.getWaterFlowrate().toString());
    assertEquals(waterType.getId(), process.getWaterType().getId());
    assertFalse(process.isDustPickupRequired());
    assertEquals("45", process.getDuctSize().toString());
    assertEquals("23", process.getDuctFlowrate().toString());
    assertEquals(dustType.getId(), process.getDustType().getId());
    assertEquals("CC", process.getBaghouseCyclone().toString());
    assertEquals("66", process.getDustPickupVelocity().toString());
    assertEquals("These are my remarks New", process.getProcessRemarks());
    assertTrue(process.isSpecificationRequired());

    assertEquals(feList.size(), process.getProcessFieldEquipmentTypes().size());
    List<ProcessFieldEquipmentType> processFieldEquipmentTypes = process.getProcessFieldEquipmentTypes();
    for (ProcessFieldEquipmentType pfe : processFieldEquipmentTypes) {
      if (pfe.getFieldEquipmentType().getFieldType().getType().equalsIgnoreCase("text")) {
        assertEquals(pfe.getValue(), "23");
      } else if (pfe.getFieldEquipmentType().getFieldType().getType().equalsIgnoreCase("textarea")) {
        assertEquals(pfe.getValue(), "23 comments");
      } else if (pfe.getFieldEquipmentType().getFieldType().getType().equalsIgnoreCase("select")) {
        List<ListValue> listValues = pfe.getFieldEquipmentType().getListValues();
        assertEquals(pfe.getValue(), listValues.get(1).getId().toString());
      } else if (pfe.getFieldEquipmentType().getFieldType().getType().equalsIgnoreCase("checkbox")) {
        assertEquals(pfe.getValue(), "on");
      } else if (pfe.getFieldEquipmentType().getFieldType().getType().equalsIgnoreCase("radio")) {
        assertEquals(pfe.getValue(), "n");
      }
    }

    assertEquals(2, equipment.getMotors().size());
    assertMotorData(equipment.getMotors());
    assertInstrumentData(equipment);
    Projects_AT_TestCaseHelper.deleteTestProject(project.getId());
  }

  public void testSaveEquipment_AllRequiredFieldsEntered_EquipmentAndMechanicalSaved() throws Exception {
    Projects project = Projects_AT_TestCaseHelper.setupProject();
    Area area = project.getCrop().getAreas().get(0);
    EquipmentType et = Projects_AT_TestCaseHelper.findEquipmentTypeByName("Conveyor");

    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.HAS_MECHANICAL_DATA_CHANGED, true);

    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_AREA, String.valueOf(area.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.PROCESS_LINE_NUMBER, "0");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TAG_NUMBER, "123");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TYPE_ID, String.valueOf(et.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_NAME, "Equip Name");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_DESCRIPTION, "My Equip Desc");

    helper.setRequestParameterValue(EISConstants.ENGINEER, "Engineer");
    helper.setRequestParameterValue(EISConstants.MODEL_NUMBER, "12345");
    helper.setRequestParameterValue(EISConstants.SHIPPING_WEIGHT, "100");
    helper.setRequestParameterValue(EISConstants.PURCHASE_SCOPE, "6618");
    helper.setRequestParameterValue(EISConstants.OPERATING_WEIGHT, "100");
    helper.setRequestParameterValue(EISConstants.SOLE_SOURCE, "on");
    helper.setRequestParameterValue(EISConstants.DYNAMIC_LOAD, "100abc");
    helper.setRequestParameterValue(EISConstants.SERIAL_NUMBER, "12345");
    helper.setRequestParameterValue(EISConstants.BID_PACKAGE_ONE, "Bid Pack One");
    helper.setRequestParameterValue(EISConstants.WORK_DESCRIPTION_ONE, "Work Desc One");
    helper.setRequestParameterValue(EISConstants.BID_PACKAGE_TWO, "Bid Pack Two");
    helper.setRequestParameterValue(EISConstants.WORK_DESCRIPTION_TWO, "Work Desc Two");

    ec.run(helper);

    List<Equipment> equipments = Projects_AT_TestCaseHelper.findEquipmentByCriteria(project.getId());
    assertEquals(1, equipments.size());
    Equipment equipment = equipments.get(0);
    assertNotNull(equipment.getId());
    assertEquals("0", equipment.getProcessLineNumber());
    assertEquals(area, equipment.getArea());
    assertEquals(et, equipment.getEquipmentType());
    assertEquals("123", equipment.getEquipmentTagNumber());
    assertEquals("Equip Name", equipment.getName());
    assertEquals("My Equip Desc", equipment.getDescription());
    assertEquals("1.0.123C", equipment.getEquipmentNumber());

    Mechanical mechanical = equipment.getMechanical();
    assertEquals("Engineer", mechanical.getEngineer());
    assertEquals("12345", mechanical.getModelNumber());
    assertEquals(new Integer(100), mechanical.getShippingWeight());
    assertEquals("Monsanto", mechanical.getPurchaseScope().getPurchaseScopeName());
    assertEquals(new Integer(100), mechanical.getOperatingWeight());
    assertEquals("100abc", mechanical.getDynLoad());
    assertEquals("12345", mechanical.getSerialNumber());
    assertEquals("Bid Pack One", mechanical.getBidPackageOne());
    assertEquals("Work Desc One", mechanical.getWorkDescriptionOne());
    assertEquals("Bid Pack Two", mechanical.getBidPackageTwo());
    assertEquals("Work Desc Two", mechanical.getWorkDescriptionTwo());

    ProjectsController spc = new ProjectsController();
    MockUCCHelper deleteHelper = new MockUCCHelper(null);
    deleteHelper.setRequestParameterValue("method", "deleteProject");
    deleteHelper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
    spc.run(deleteHelper);
  }

  public void testSaveEquipment_AllRequiredFieldsEntered_EquipmentAndElectricalSaved() throws Exception {
    Projects project = Projects_AT_TestCaseHelper.setupProject();
    Area area = project.getCrop().getAreas().get(0);
    EquipmentType et = Projects_AT_TestCaseHelper.findEquipmentTypeByName("Conveyor");

    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(ElectricalConstants.HAS_ELECTRICAL_DATA_CHANGED, true);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_AREA, String.valueOf(area.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.PROCESS_LINE_NUMBER, "0");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TAG_NUMBER, "123");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TYPE_ID, String.valueOf(et.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_NAME, "Equip Name");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_DESCRIPTION, "My Equip Desc");

    helper.setRequestParameterValue(ElectricalConstants.PROOF_OF_POSITION_REQUIRED, "true");
    helper.setRequestParameterValue(ElectricalConstants.SOLENOID_REQUIRED, "true");
    helper.setRequestParameterValue(ElectricalConstants.LOCAL_PUSH_BUTTON_REQUIRED, "true");
    helper.setRequestParameterValue(ElectricalConstants.INPUT, "1189");
    helper.setRequestParameterValue(ElectricalConstants.INPUT_QUANTITY, "10");
    helper.setRequestParameterValue(ElectricalConstants.OUTPUT, "1191");
    helper.setRequestParameterValue(ElectricalConstants.OUTPUT_QUANTITY, "20");
    helper.setRequestParameterValue(ElectricalConstants.HMI_DISPLAY, "HMI Display");
    helper.setRequestParameterValue(ElectricalConstants.OTHER_MEASURMENT, "1193");
    helper.setRequestParameterValue(ElectricalConstants.COMMUNICATIONS, "Communications");
    helper.setRequestParameterValue(ElectricalConstants.VOLTAGE, "100");

//    List<ElectricalInput> inputs = Projects_AT_TestCaseHelper.lookupAllElectricalInputs();
//    for(ElectricalInput in: inputs){
//      helper.setRequestParameterValue(ElectricalConstants.VOLTAGE, "100");
//
//    }

    ec.run(helper);

    List<Equipment> equipments = Projects_AT_TestCaseHelper.findEquipmentByCriteria(Long.valueOf(project.getId()));
    assertEquals(1, equipments.size());
    Equipment equipment = equipments.get(0);
    Electrical electrical = equipment.getElectrical();
    assertTrue(electrical.isProofOfPositionReq());
    assertTrue(electrical.isSolenoidReq());
    assertTrue(electrical.isLocalPushButtonReq());

    assertEquals(2, electrical.getInputQuantity().size());
    assertEquals(2, electrical.getOutputQuantity().size());

    assertNull(electrical.getInput());
    assertNull(electrical.getOutput());

    assertEquals("HMI Display", electrical.getHmiDisplay());
    assertEquals("Level", electrical.getOtherMeasurement().getMeasurement());
    assertEquals("Communications", electrical.getCommunications());
    assertEquals(new Integer(100), electrical.getVoltage());

    ProjectsController spc = new ProjectsController();
    MockUCCHelper deleteHelper = new MockUCCHelper(null);
    deleteHelper.setRequestParameterValue("method", "deleteProject");
    deleteHelper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
    spc.run(deleteHelper);
  }

  public void testSaveEquipment_NewEquipmentAllRequiredFieldsEntered_EquipmentAndAccessoriesSaved() throws Exception {
    Projects project = Projects_AT_TestCaseHelper.setupProject();
    Area area = project.getCrop().getAreas().get(0);
    EquipmentType et = Projects_AT_TestCaseHelper.findEquipmentTypeByName("Conveyor");

    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AccessoryConstants.HAS_ACCESSORIES_DATA_CHANGED, true);

    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_AREA, String.valueOf(area.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.PROCESS_LINE_NUMBER, "0");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TAG_NUMBER, "123");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TYPE_ID, String.valueOf(et.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_NAME, "Equip Name");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_DESCRIPTION, "My Equip Desc");

    helper.setRequestParameterValue(AccessoryConstants.HAS_ACCESSORIES_DATA_CHANGED, "true");
    helper.setRequestParameterValue(AccessoryConstants.DELETED_ACCESSORY_IDS, "");

    AccessoryDesignator designator = Projects_AT_TestCaseHelper.lookupAllAccessoryDesignators().get(0);
    AutoManual autoManual = Projects_AT_TestCaseHelper.lookupAllAutoManuals().get(0);

    helper.setRequestParameterValue(AccessoryConstants.ACCE_ID, new String[]{"", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_NAME, new String[]{"Acce Name 1", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_AUTO_MANUAL_ID,
        new String[]{autoManual.getId().toString(), ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_DESGINATOR_ID,
        new String[]{designator.getId().toString(), designator.getId().toString()});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_SEQUENCE_NUMBER, new String[]{"00", "16"});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_DESCRIPTION, new String[]{"Acce Desc 1", ""});
    helper
        .setRequestParameterValue(AccessoryConstants.ACCE_COMMENTS, new String[]{"Acce Comments 1", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_PURCHASED_WITH_EQUIP, new String[]{"", "true"});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_QUANTITY, new String[]{"17", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_COMP_AIR_REQD, new String[]{"true", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_GAS_REQD, new String[]{"true", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_WATER_REQD, new String[]{"false", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_UTILITY_FLOWRATE, new String[]{"19", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_SELF_CLEANING, new String[]{"false", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_SIZE, new String[]{"21", ""});

    helper.setRequestParameterValue(AccessoryConstants.ACCE_ELECT_ID, new String[]{"", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_PROOF_OF_POSITION_REQUIRED, new String[]{"true", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_SOLENOID_REQUIRED, new String[]{"true", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_LOCAL_PUSH_BUTTON_REQUIRED, new String[]{"true", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_INPUT_ID, new String[]{"1189", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_INPUT_QUANTITY, new String[]{"10", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_OUTPUT_ID, new String[]{"1191", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_OUTPUT_QUANTITY, new String[]{"20", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_HMI_DISPLAY, new String[]{"HMI Display", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_OTHER_MEASUREMENT_ID, new String[]{"1193", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_COMMUNICATIONS, new String[]{"Communications", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_VOLTAGE, new String[]{"100", ""});
    helper.setRequestParameterValue(AccessoryConstants.BID_PACKAGE, new String[]{"123", "456"});

    helper.setRequestParameterValue(AccessoryConstants.ACCE_PURCHASING_ID, new String[]{"", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_VENDOR, new String[]{"My Vendor", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_RTP_NUMBER, new String[]{"123", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_PO_NUMBER, new String[]{"123", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_LINE_NUMBER, new String[]{"123", ""});
    helper.setRequestParameterValue(AccessoryConstants.ACCE_ACTUAL_DELIVERY_DATE, new String[]{"Oct 29, 2008", ""});

    ec.run(helper);

    List<Equipment> equipments = Projects_AT_TestCaseHelper.findEquipmentByCriteria(project.getId());
    assertEquals(1, equipments.size());
    Equipment equipment = equipments.get(0);
    Set<Accessory> accessories = equipment.getAccessories();
    assertEquals(2, accessories.size());
    for (Accessory accessory : accessories) {
      if ("Acce Name 1".equalsIgnoreCase(accessory.getAccessoryName())) {
        assertAccessory(designator, autoManual, accessory);
      }
    }
    ProjectsController spc = new ProjectsController();
    MockUCCHelper deleteHelper = new MockUCCHelper(null);
    deleteHelper.setRequestParameterValue("method", "deleteProject");
    deleteHelper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
    spc.run(deleteHelper);
  }

  private void assertAccessory(AccessoryDesignator designator, AutoManual autoManual, Accessory accessory) {
    assertEquals("Acce Name 1", accessory.getAccessoryName());
    assertEquals(autoManual.getId(), accessory.getAutoManual().getId());
    assertEquals(designator.getId(), accessory.getAccessoryDesignator().getId());
    assertEquals("00", accessory.getSequenceNumber());
    assertEquals("Acce Desc 1", accessory.getAcceDescription());
    assertEquals("Acce Comments 1", accessory.getComments());
    assertFalse(accessory.isPurchasedWithEquipment());
    assertEquals(new Integer(17), accessory.getQuantity());
    assertTrue(accessory.isCompAirReqd());
    assertTrue(accessory.isGasReqd());
    assertFalse(accessory.isWaterReqd());
    assertEquals("19", accessory.getUtilityFlowrate());
    assertTrue(accessory.isCompAirReqd());
    assertEquals(new Integer(21), accessory.getSize());

    Electrical electrical = accessory.getElectrical();
    assertTrue(electrical.isProofOfPositionReq());
    assertTrue(electrical.isSolenoidReq());
    assertTrue(electrical.isLocalPushButtonReq());
//    assertEquals(new Long(1189), electrical.getInput().getId());
//    assertEquals(new Integer(10), electrical.getInputQty());
//    assertEquals(new Long(1191), electrical.getOutput().getId());
//    assertEquals(new Integer(20), electrical.getOutputQty());
    assertEquals("HMI Display", electrical.getHmiDisplay());
    assertEquals(new Long(1193), electrical.getOtherMeasurement().getId());
    assertEquals("Communications", electrical.getCommunications());
    assertEquals(new Integer(100), electrical.getVoltage());

    Purchasing purchasing = accessory.getPurchasing();
    assertEquals("My Vendor", purchasing.getVendor());
    assertEquals(new Integer(123), purchasing.getRtpNumber());
    assertEquals(new Long(123), purchasing.getPoNumber());
    assertEquals(new Integer(123), purchasing.getLineNumber());
    assertNull(purchasing.getPoLineAmount());
//    assertNull(purchasing.getPoLineQuantity());
//    assertNull(purchasing.getPoLineValue());
    assertNull(purchasing.getCoAmount());
    assertNull(purchasing.getOriginalShipDate());
    assertNull(purchasing.getRevisedShipDate());
    assertEquals("Oct 29, 2008",
        ConvertUtil.toString(purchasing.getActualDeliveryDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertFalse(purchasing.isExportDocuments());
  }

  public void testLookupEquipmentSubTypes_ReturnsList() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupEquipmentSubTypes");
    helper.setRequestParameterValue(EquipmentConstants.EQUIPMENT_TYPE, "5");
    ec.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//types)", xmlDoc);
    assertXpathExists("//type", xmlDoc);
  }

  public void testSaveEquipment_AllRequiredFieldsEntered_EnteredWithPurchasing_EquipmentSaved() throws IOException,
      TransformerException {
    Projects project = Projects_AT_TestCaseHelper.setupProject();
    Area area = project.getCrop().getAreas().get(0);
    EquipmentType et = Projects_AT_TestCaseHelper.findEquipmentTypeByName("Conveyor");

    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(PurchasingConstants.HAS_PURCHASING_DATA_CHANGED, true);

    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_AREA, String.valueOf(area.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.PROCESS_LINE_NUMBER, "0");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TAG_NUMBER, "123");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TYPE_ID, String.valueOf(et.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_NAME, "Equip Name");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_DESCRIPTION, "My Equip Desc");

    helper.setRequestParameterValue(PurchasingConstants.VENDOR, "My Vendor");
    helper.setRequestParameterValue(PurchasingConstants.SOLE_SOURCE, "true");
    helper.setRequestParameterValue(PurchasingConstants.RTP_NUMBER, "123");
    helper.setRequestParameterValue(PurchasingConstants.PO_NUMBER, "123");
    helper.setRequestParameterValue(PurchasingConstants.LINE_NUMBER, "123");
    helper.setRequestParameterValue(PurchasingConstants.PO_LINE_AMOUNT, "123");
    helper.setRequestParameterValue(PurchasingConstants.PO_LINE_QUANTITY, "10");
    helper.setRequestParameterValue(PurchasingConstants.PO_LINE_VALUE, "123");
    helper.setRequestParameterValue(PurchasingConstants.CO_AMOUNT, "123");
    helper.setRequestParameterValue(PurchasingConstants.ORIGINAL_SHIP_DATE, "Oct 27, 2008");
    helper.setRequestParameterValue(PurchasingConstants.REVISED_SHIP_DATE, "Oct 28, 2008");
    helper.setRequestParameterValue(PurchasingConstants.ACTUAL_DELIVERY_DATE, "Oct 29, 2008");
    helper.setRequestParameterValue(PurchasingConstants.EXPORT_DOCUMENTS, "true");

    ec.run(helper);

    List<Equipment> equipments = Projects_AT_TestCaseHelper.findEquipmentByCriteria(project.getId());
    assertEquals(1, equipments.size());
    Equipment equipment = equipments.get(0);
    Purchasing purchasing = equipment.getPurchasing();

    assertEquals("My Vendor", purchasing.getVendor());
    assertEquals(new Integer(123), purchasing.getRtpNumber());
    assertEquals(new Long(123), purchasing.getPoNumber());
    assertEquals(new Integer(123), purchasing.getLineNumber());
    assertEquals(new Long(123), purchasing.getPoLineAmount());
    assertEquals(new Integer(10), purchasing.getPoLineQuantity());
    assertEquals(new Long(123), purchasing.getPoLineValue());
    assertEquals(new Long(123), purchasing.getCoAmount());
    assertEquals("Oct 27, 2008",
        ConvertUtil.toString(purchasing.getOriginalShipDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 28, 2008",
        ConvertUtil.toString(purchasing.getRevisedShipDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 29, 2008",
        ConvertUtil.toString(purchasing.getActualDeliveryDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals(true, purchasing.isExportDocuments());

    ProjectsController spc = new ProjectsController();
    MockUCCHelper deleteHelper = new MockUCCHelper(null);
    deleteHelper.setRequestParameterValue("method", "deleteProject");
    deleteHelper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
    spc.run(deleteHelper);
  }

  public void testSaveEquipment_AllRequiredFieldsEntered_EnteredWithCostSchedule_EquipmentSaved() throws IOException,
      TransformerException {
    Projects project = Projects_AT_TestCaseHelper.setupProject();
    Area area = project.getCrop().getAreas().get(0);
    EquipmentType et = Projects_AT_TestCaseHelper.findEquipmentTypeByName("Conveyor");

    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(CostScheduleConstants.HAS_COST_SCHEDULED_DATA_CHANGED, true);

    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_AREA, String.valueOf(area.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.PROCESS_LINE_NUMBER, "0");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TAG_NUMBER, "123");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_TYPE_ID, String.valueOf(et.getId().longValue()));
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_NAME, "Equip Name");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_DESCRIPTION, "My Equip Desc");

    List<FundingSource> fundingSources = Projects_AT_TestCaseHelper.lookupAllFundingSources();

    helper.setRequestParameterValue(CostScheduleConstants.CS_SCHEDULED_SPECIFICATION, "Sep 27, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_SCHEDULED_QUOTE, "Sep 28, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_SCHEDULED_PURCHASE, "Sep 29, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_DRAWING_TURNAROUNDTIME, "13");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_FABRICATION_TIME, "14");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_SHIPPING, "Sep 30, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_SPEC_ISSED, "Oct 01, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_RTQ_ENTERED, "Oct 02, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_RTP_ENTERED, "Oct 03, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_PREL_DRAWING_ISSUED, "Oct 04, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_APPROVAL_DRAWING, "Oct 05, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_FINAL_DRAWING, "Oct 06, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_IOM_RECEIVED, "Oct 07, 2008");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_SOURCE, "Lease");
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_COST, "100");
    helper.setRequestParameterValue(CostScheduleConstants.CS_FUNDING_SOURCE_ID, fundingSources.get(0).getId());
    helper.setRequestParameterValue(CostScheduleConstants.CS_EST_MECH_HRS, "40");
    helper.setRequestParameterValue(CostScheduleConstants.CS_ESCALATION_FACTOR, "3.456");

    ec.run(helper);

    List<Equipment> equipments = Projects_AT_TestCaseHelper.findEquipmentByCriteria(project.getId());
    assertEquals(1, equipments.size());
    Equipment equipment = equipments.get(0);
    CostSchedule costSchedule = equipment.getCostSchedule();

    assertNotNull(costSchedule.getId());
    assertEquals("Sep 27, 2008",
        ConvertUtil.toString(costSchedule.getscheduledSpecificationDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Sep 28, 2008",
        ConvertUtil.toString(costSchedule.getScheduledQuoteDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Sep 29, 2008",
        ConvertUtil.toString(costSchedule.getScheduledPurchaseDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("13", costSchedule.getDrawingTurnaroundTime().toString());
    assertEquals("14", costSchedule.getEstiamtedFabricationTime().toString());
    assertEquals("Sep 30, 2008",
        ConvertUtil.toString(costSchedule.getEstiamtedShippingDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 01, 2008",
        ConvertUtil.toString(costSchedule.getSpecIssuedDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 02, 2008",
        ConvertUtil.toString(costSchedule.getRtqEnteredDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 03, 2008",
        ConvertUtil.toString(costSchedule.getRtpEnteredDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 04, 2008",
        ConvertUtil.toString(costSchedule.getPrelDrawingIssuedDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 05, 2008",
        ConvertUtil.toString(costSchedule.getApprovalDrawingDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 06, 2008",
        ConvertUtil.toString(costSchedule.getFinalDrawingDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Oct 07, 2008",
        ConvertUtil.toString(costSchedule.getIomReceivedDate(), ConvertUtil.PROJECTS_DATE_FORMAT));
    assertEquals("Lease", costSchedule.getEstimatedSource());
    assertEquals("100", costSchedule.getEstimatedCost().toString());
    assertEquals(fundingSources.get(0).getId(), costSchedule.getFundingSource().getId());
    assertEquals("40", costSchedule.getEstimatedMechHours().toString());
    assertEquals("3.456", costSchedule.getEscalationFactor().toString());

    ProjectsController spc = new ProjectsController();
    MockUCCHelper deleteHelper = new MockUCCHelper(null);
    deleteHelper.setRequestParameterValue("method", "deleteProject");
    deleteHelper.setRequestParameterValue(EISConstants.PROJECT_ID, project.getId());
    spc.run(deleteHelper);
  }

  private void setMotorDataInHelper(MockUCCHelper helper) {
    List<MotorDesignStatus> dsList = Projects_AT_TestCaseHelper.lookupAllDesignStatus();
    List<MotorLoadValueType> lvList = Projects_AT_TestCaseHelper.lookupAllLoadValueTypes();
    List<ComponentDesignator> cdList = Projects_AT_TestCaseHelper.lookupAllComponentDesignators();

    helper.setRequestParameterValue(MotorConstants.DELETED_MOTOR_IDS, "");
    helper.setRequestParameterValue(MotorConstants.HAS_MOTORS_DATA_CHANGED, "true");
    helper.setRequestParameterValue(MotorConstants.MOTOR_ID, new String[]{"", ""});
    helper
        .setRequestParameterValue(MotorConstants.COMPONENT_DESIGNATOR_ID, new String[]{cdList.get(0).getId().toString(),
            cdList.get(1).getId().toString()});
    helper.setRequestParameterValue(MotorConstants.MOTOR_SEQUENCE_NUMBER, new String[]{"WE", "RT"});
    helper.setRequestParameterValue(MotorConstants.COMPONENT_NAME,
        new String[]{"Motor Component Name 1", "Motor Component Name 2"});
    helper.setRequestParameterValue(MotorConstants.FLA, new String[]{"2", "22"});
    helper.setRequestParameterValue(MotorConstants.MOTOR_VOLTAGE, new String[]{"200", "201"});
    helper.setRequestParameterValue(MotorConstants.PHASE, new String[]{"3", "3"});
    helper.setRequestParameterValue(MotorConstants.FREQUENVY, new String[]{"3", "34"});
    helper.setRequestParameterValue(MotorConstants.RPM, new String[]{"4", "44"});
    helper.setRequestParameterValue(MotorConstants.DESIGN_STATUS_ID,
        new String[]{dsList.get(0).getId().toString(), dsList.get(1).getId().toString()});
    helper.setRequestParameterValue(MotorConstants.MOTOR_COMMENTS,
        new String[]{"These are my comments 1", "These are my comments 2"});
    helper.setRequestParameterValue(MotorConstants.LOAD_VALUE_TYPE_ID,
        new String[]{lvList.get(0).getId().toString(), lvList.get(0).getId().toString()});
    helper.setRequestParameterValue(MotorConstants.LOAD_VALUE_QUANTITY, new String[]{"9", "99"});
    helper.setRequestParameterValue(MotorConstants.IO_CABINET, new String[]{"IO C 1", "IO C 2"});
    helper.setRequestParameterValue(MotorConstants.POWER_SOURCE, new String[]{"Electrical", "Motor"});
    helper.setRequestParameterValue(MotorConstants.LOAD_DISCONNECT_REQUIRED, new String[]{"true", "false"});
    helper.setRequestParameterValue(MotorConstants.STARTER_SIZE, new String[]{"500", "501"});
    helper.setRequestParameterValue(MotorConstants.MOTOR_BRAKE, new String[]{"true", "false"});
    helper.setRequestParameterValue(MotorConstants.BID_PACKAGE, new String[]{"123", "456"});
  }

  private void assertMotorData(Set<Motor> motorList) {
    for (Motor motor : motorList) {
      if ("WE".equalsIgnoreCase(motor.getSequenceNumber())) {
        assertMotor1(motor);
      }
    }
  }

  private void assertMotor1(Motor motor) {
    assertNotNull(motor.getId());
    assertNotNull(motor.getComponentDesignator().getId());
    assertEquals("WE", motor.getSequenceNumber());
    assertEquals("Motor Component Name 1", motor.getComponentName());
    assertEquals("Motor Component Name 1", motor.getComponentName());
    assertEquals("2.0", motor.getFla().toString());
    assertEquals("200", motor.getMotorVoltage().toString());
    assertEquals("3", motor.getPhase().toString());
    assertEquals("3", motor.getFrequency().toString());
    assertEquals("4", motor.getRpm().toString());
    assertNotNull(motor.getDesignStatus().getId());
    assertEquals("These are my comments 1", motor.getComments());
    assertNotNull(motor.getLoadValueType().getId());
    assertEquals("9.0", motor.getLoadValueQuantity().toString());
    assertEquals("Electrical", motor.getPowerSource());
    assertEquals("IO C 1", motor.getIoCabinet());
    assertTrue(motor.isLoadDisconnectRequired());
    assertEquals("500", motor.getStarterSize());
  }

  private void setInstrumentsInHelper(MockUCCHelper helper) {
    List<InstrumentDesignator> designatorsForFirstChar = Projects_AT_TestCaseHelper
        .lookupAllInstrumentDesignatorsForFirstChar();
    List<InstrumentDesignator> designatorsForSecondChar = Projects_AT_TestCaseHelper
        .lookupAllInstrumentDesignatorsForSecondChar();
    List<IOType> ioTypes = Projects_AT_TestCaseHelper.lookupAllIoTypes();
    helper.setRequestParameterValue(InstrumentConstants.DELETED_INSTRUMENT_IDS, "");
    helper.setRequestParameterValue(InstrumentConstants.HAS_INTRUMENTS_DATA_CHANGED, "true");
    helper.setRequestParameterValue(InstrumentConstants.INSTRUMENT_ID, new String[]{"", ""});
    helper.setRequestParameterValue(InstrumentConstants.DESIGNATOR_FIRST_CHAR_ID, new String[]{
        designatorsForFirstChar.get(0).getId().toString(), designatorsForFirstChar.get(1).getId().toString()});
    helper.setRequestParameterValue(InstrumentConstants.DESIGNATOR_SECOND_CHAR_ID, new String[]{
        designatorsForSecondChar.get(0).getId().toString(), designatorsForSecondChar.get(1).getId().toString()});
    helper.setRequestParameterValue(InstrumentConstants.INST_SEQUENCE_NUMBER, new String[]{"22", "33"});
    helper.setRequestParameterValue(InstrumentConstants.INST_DESCRIPTION,
        new String[]{"This is my description", "This is my description 2"});
    helper.setRequestParameterValue(InstrumentConstants.IO_TYPE_ID,
        new String[]{ioTypes.get(0).getId().toString(), ioTypes.get(1).getId().toString()});
    helper.setRequestParameterValue(InstrumentConstants.ALARM_POINTS, new String[]{"1000", "2000"});
    helper.setRequestParameterValue(InstrumentConstants.ALARM_POINTS_QUANTITY, new String[]{"5", "6"});
    helper.setRequestParameterValue(InstrumentConstants.INST_VOLTS, new String[]{"300", "400"});
    helper.setRequestParameterValue(InstrumentConstants.INST_RANGE, new String[]{"40000", "50000"});
    helper.setRequestParameterValue(InstrumentConstants.INST_UNITS, new String[]{"watts", "watts 1"});
    helper.setRequestParameterValue(InstrumentConstants.INST_COMMENTS,
        new String[]{"These are my comments", "These are my comments 2"});
      helper.setRequestParameterValue(InstrumentConstants.INST_BID_PACAKAGE,
        new String[]{"123", "456"});
    helper.setRequestParameterValue(InstrumentConstants.INST_PURCHASED_WITH_EQUIP, new String[]{"", "true"});
    helper.setRequestParameterValue(InstrumentConstants.INST_PURCHASING_ID, new String[]{"", ""});
    helper
        .setRequestParameterValue(InstrumentConstants.INST_VENDOR, new String[]{"My Vendor", "This should not count"});
    helper.setRequestParameterValue(InstrumentConstants.INST_RTP_NUMBER, new String[]{"123", "234"});
    helper.setRequestParameterValue(InstrumentConstants.INST_PO_NUMBER, new String[]{"123", "234"});
    helper.setRequestParameterValue(InstrumentConstants.INST_LINE_NUMBER, new String[]{"123", "234"});
    helper.setRequestParameterValue(InstrumentConstants.INST_ACTUAL_DELIVERY_DATE,
        new String[]{"Oct 29, 2008", "Oct 29, 2009"});
  }

  private void assertInstrumentData(Equipment eqipment) {
    Set<Instrument> instruments = eqipment.getInstruments();
    assertEquals(2, instruments.size());
    Iterator<Instrument> iterator = instruments.iterator();
    Instrument instrument = iterator.next();
    if ("22".equalsIgnoreCase(instrument.getSequenceNumber())) {
      assertInstrument1(instrument);
      instrument = iterator.next();
      assertInstrument2(instrument);
    } else {
      assertInstrument2(instrument);
      instrument = iterator.next();
      assertInstrument1(instrument);
    }
  }

  private void assertInstrument2(Instrument instrument) {
    assertNotNull(instrument.getDesignatorFirstChar().getId());
    assertNotNull(instrument.getDesignatorSecondChar().getId());
    assertEquals("33", instrument.getSequenceNumber());
    assertEquals("This is my description 2", instrument.getInstDescription());
    assertNotNull(instrument.getIoType().getId());
    assertEquals("2000", instrument.getAlarmPoints());
    assertEquals(new Integer(6), instrument.getAlarmPointsQuantity());
    assertEquals(new Integer(400), instrument.getVolts());
    assertEquals("50000", instrument.getRange());
    assertEquals("watts 1", instrument.getUnits());
    assertEquals("These are my comments 2", instrument.getComments());
  }

  private void assertInstrument1(Instrument instrument) {
    assertNotNull(instrument.getDesignatorFirstChar().getId());
    assertNotNull(instrument.getDesignatorSecondChar().getId());
    assertEquals("22", instrument.getSequenceNumber());
    assertEquals("This is my description", instrument.getInstDescription());
    assertNotNull(instrument.getIoType().getId());
    assertEquals("1000", instrument.getAlarmPoints());
    assertEquals(new Integer(5), instrument.getAlarmPointsQuantity());
    assertEquals(new Integer(300), instrument.getVolts());
    assertEquals("40000", instrument.getRange());
    assertEquals("watts", instrument.getUnits());
    assertEquals("These are my comments", instrument.getComments());
  }
}
