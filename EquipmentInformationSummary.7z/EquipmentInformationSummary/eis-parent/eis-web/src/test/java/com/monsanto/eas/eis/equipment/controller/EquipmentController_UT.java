package com.monsanto.eas.eis.equipment.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.eas.eis.equipment.*;
import com.monsanto.eas.eis.equipment.ProcessBuilder;
import com.monsanto.eas.eis.equipment.mock.*;
import com.monsanto.eas.eis.equipment.service.EquipmentService;
import com.monsanto.eas.eis.equipment.service.mock.MockElectricalService;
import com.monsanto.eas.eis.projects.EISDAOFactory;
import com.monsanto.eas.eis.projects.mocks.MockEISDAOFactory;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.mocks.MockEquipmentServiceImpl;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EquipmentConstants;
import com.monsanto.eas.eis.audit.service.MockAuditServiceImpl;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.*;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Sep 3, 2008 Time: 9:53:57 AM To change this template use File | Settings
 * | File Templates.
 */
public class EquipmentController_UT extends XMLTestCase {
  private EISDAOFactory mockDaoFactory;
  private EquipmentService equipmentService;
  private EquipmentController ec;
  private EquipmentBuilder equipmentBuilder;
  private ProcessBuilder processBuilder;
  private MotorBuilder motorBuilder;
  private InstrumentBuilder instrumentBuilder;
  private AccessoryBuilder accessoryBuilder;
  private MechanicalBuilder mechanicalBuilder;
  private ElectricalBuilder electricalBuilder;
  private PurchasingBuilder purchasingBuilder;
  private CostScheduleBuilder costScheduleBuilder;

  protected void setUp() throws Exception {
    super.setUp();
    mockDaoFactory = new MockEISDAOFactory(new MockHibernateSession());
    equipmentService = new MockEquipmentServiceImpl(mockDaoFactory);
    equipmentBuilder = new MockEquipmentBuilder(new ArrayList<String>(), new ArrayList<String>());
    mechanicalBuilder = new MockMechanicalBuilder();
    processBuilder = new MockProcessBuilder();
    motorBuilder = new MockMotorBuilder(new ArrayList<String>());
    instrumentBuilder = new MockInstrumentBuilder(new ArrayList<String>());
    accessoryBuilder = new MockAccessoryBuilder(new ArrayList<String>());
    electricalBuilder = new MockElectricalBuilder();
    purchasingBuilder = new MockPurchasingBuilder();
    costScheduleBuilder = new MockCostScheduleBuilder();
    ec = new EquipmentController(equipmentService, equipmentBuilder, processBuilder, mechanicalBuilder, motorBuilder,
        instrumentBuilder, accessoryBuilder, electricalBuilder, purchasingBuilder, costScheduleBuilder, null, null);
  }

  public void testSaveEquipment_EquimentRequiredFieldsEntered_EquipmentSaved() throws
      IOException, TransformerException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "789");
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    ec.run(helper);
    assertTrue(((MockEquipmentServiceImpl) equipmentService).wasEquipmentSaved());
    assertNull(helper.getRequestAttributeValue(EISConstants.REQUIRED_FIELDS));

    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//equipmentId)", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipmentId", xmlDoc);
    assertXpathEvaluatesTo("0", "count(//errors/error)", xmlDoc);
  }

  public void testSaveEquipment_NoErrors_VerifyEquipmentIsCreatedAndSAvedProperly() throws
      IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "789");
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    MockEquipmentServiceImpl equipmentService = new MockEquipmentServiceImpl();
    EquipmentController ec1 = new EquipmentController(
        equipmentService, equipmentBuilder, processBuilder, mechanicalBuilder, motorBuilder,
        instrumentBuilder, accessoryBuilder, electricalBuilder, purchasingBuilder, costScheduleBuilder, null, null);
    ec1.run(helper);
    assertTrue(((MockEquipmentServiceImpl) equipmentService).wasEquipmentSaved());
    Equipment equipment = equipmentService.getSavedEquipment();
    assertEquals(new Long(111), equipment.getProcess().getId());
    assertEquals(1, equipment.getMotors().size());
    assertEquals(new Long(222), equipment.getMotors().iterator().next().getId());
    assertEquals(1, equipment.getInstruments().size());
    assertEquals(new Long(333), equipment.getInstruments().iterator().next().getId());
    assertEquals(1, equipment.getAccessories().size());
    assertEquals(new Long(444), equipment.getAccessories().iterator().next().getId());
    assertEquals(new Long(666), equipment.getMechanical().getId());
    assertEquals(new Long(777), equipment.getElectrical().getId());
    assertEquals(new Long(999), equipment.getPurchasing().getId());
    assertEquals(new Long(123), equipment.getCostSchedule().getId());
  }

  public void testSaveEquipment_DetailsRequiredFieldsMissing_EquipmentNotSaved() throws
      IOException, TransformerException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "789");
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    MockEquipmentServiceImpl equipmentService = new MockEquipmentServiceImpl();
    List<String> errors = new ArrayList<String>();
    errors.add("Error 1");
    errors.add("Error 2");
    equipmentBuilder = new MockEquipmentBuilder(errors, new ArrayList<String>());
    MockEquipmentControllerOverridingClearHibernateSession controllerOverridingClearHibernateSession = new MockEquipmentControllerOverridingClearHibernateSession(
        equipmentService, equipmentBuilder, processBuilder, mechanicalBuilder, motorBuilder,
        instrumentBuilder, accessoryBuilder, electricalBuilder, purchasingBuilder, costScheduleBuilder);
    controllerOverridingClearHibernateSession.run(helper);
    assertFalse(((MockEquipmentServiceImpl) equipmentService).wasEquipmentSaved());
    assertTrue(controllerOverridingClearHibernateSession.isHibernateSessionWasCleared());

    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//equipmentId)", xmlDoc);
    assertXpathEvaluatesTo("456", "//equipmentId", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/error)", xmlDoc);
    assertXpathEvaluatesTo("Details Required Fields:", "//errors/error/errorHeader", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//errors/error/errorMsg)", xmlDoc);
    assertXpathEvaluatesTo("Error 1", "//errors/error/errorMsg[1]", xmlDoc);
    assertXpathEvaluatesTo("Error 2", "//errors/error/errorMsg[2]", xmlDoc);
  }

  public void testSaveEquipment_DetailsHasInvalidLengthErrors_EquipmentNotSaved() throws
      IOException, TransformerException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "789");
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    MockEquipmentServiceImpl equipmentService = new MockEquipmentServiceImpl();
    List<String> errors = new ArrayList<String>();
    errors.add("Error 1");
    errors.add("Error 2");
    equipmentBuilder = new MockEquipmentBuilder(new ArrayList<String>(), errors);
    MockEquipmentControllerOverridingClearHibernateSession controllerOverridingClearHibernateSession = new MockEquipmentControllerOverridingClearHibernateSession(
        equipmentService, equipmentBuilder, processBuilder, mechanicalBuilder, motorBuilder,
        instrumentBuilder, accessoryBuilder, electricalBuilder, purchasingBuilder, costScheduleBuilder);
    controllerOverridingClearHibernateSession.run(helper);
    assertFalse(((MockEquipmentServiceImpl) equipmentService).wasEquipmentSaved());
    assertTrue(controllerOverridingClearHibernateSession.isHibernateSessionWasCleared());

    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//equipmentId)", xmlDoc);
    assertXpathEvaluatesTo("456", "//equipmentId", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/error)", xmlDoc);
    assertXpathEvaluatesTo("Details Fields with invalid length:", "//errors/error/errorHeader", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//errors/error/errorMsg)", xmlDoc);
    assertXpathEvaluatesTo("Error 1", "//errors/error/errorMsg[1]", xmlDoc);
    assertXpathEvaluatesTo("Error 2", "//errors/error/errorMsg[2]", xmlDoc);
  }

  public void testSaveEquipment_MotorHasErrors_EquipmentNotSaved() throws
      IOException, TransformerException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "789");
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    MockEquipmentServiceImpl equipmentService = new MockEquipmentServiceImpl();
    List<String> errors = new ArrayList<String>();
    errors.add("Error 1");
    errors.add("Error 2");
    motorBuilder = new MockMotorBuilder(errors);
    MockEquipmentControllerOverridingClearHibernateSession controllerOverridingClearHibernateSession = new MockEquipmentControllerOverridingClearHibernateSession(
        equipmentService, equipmentBuilder, processBuilder, mechanicalBuilder, motorBuilder,
        instrumentBuilder, accessoryBuilder, electricalBuilder, purchasingBuilder, costScheduleBuilder);
    controllerOverridingClearHibernateSession.run(helper);
    assertFalse(((MockEquipmentServiceImpl) equipmentService).wasEquipmentSaved());
    assertTrue(controllerOverridingClearHibernateSession.isHibernateSessionWasCleared());

    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//equipmentId)", xmlDoc);
    assertXpathEvaluatesTo("456", "//equipmentId", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/error)", xmlDoc);
    assertXpathEvaluatesTo("Motor Required Fields:", "//errors/error/errorHeader", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//errors/error/errorMsg)", xmlDoc);
    assertXpathEvaluatesTo("Error 1", "//errors/error/errorMsg[1]", xmlDoc);
    assertXpathEvaluatesTo("Error 2", "//errors/error/errorMsg[2]", xmlDoc);
  }

  public void testSaveEquipment_InstrumentHasErrors_EquipmentNotSaved() throws
      IOException, TransformerException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "789");
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    MockEquipmentServiceImpl equipmentService = new MockEquipmentServiceImpl();
    List<String> errors = new ArrayList<String>();
    errors.add("Error 1");
    errors.add("Error 2");
    instrumentBuilder = new MockInstrumentBuilder(errors);
    MockEquipmentControllerOverridingClearHibernateSession controllerOverridingClearHibernateSession = new MockEquipmentControllerOverridingClearHibernateSession(
        equipmentService, equipmentBuilder, processBuilder, mechanicalBuilder, motorBuilder,
        instrumentBuilder, accessoryBuilder, electricalBuilder, purchasingBuilder, costScheduleBuilder);
    controllerOverridingClearHibernateSession.run(helper);
    assertFalse(((MockEquipmentServiceImpl) equipmentService).wasEquipmentSaved());
    assertTrue(controllerOverridingClearHibernateSession.isHibernateSessionWasCleared());

    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//equipmentId)", xmlDoc);
    assertXpathEvaluatesTo("456", "//equipmentId", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/error)", xmlDoc);
    assertXpathEvaluatesTo("Instrument Required Fields:", "//errors/error/errorHeader", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//errors/error/errorMsg)", xmlDoc);
    assertXpathEvaluatesTo("Error 1", "//errors/error/errorMsg[1]", xmlDoc);
    assertXpathEvaluatesTo("Error 2", "//errors/error/errorMsg[2]", xmlDoc);
  }

  public void testSaveEquipment_AccessoryHasErrors_EquipmentNotSaved() throws
      IOException, TransformerException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "789");
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_EQUIPMENT);
    MockEquipmentServiceImpl equipmentService = new MockEquipmentServiceImpl();
    List<String> errors = new ArrayList<String>();
    errors.add("Error 1");
    errors.add("Error 2");
    accessoryBuilder = new MockAccessoryBuilder(errors);
    MockEquipmentControllerOverridingClearHibernateSession controllerOverridingClearHibernateSession = new MockEquipmentControllerOverridingClearHibernateSession(
        equipmentService, equipmentBuilder, processBuilder, mechanicalBuilder, motorBuilder,
        instrumentBuilder, accessoryBuilder, electricalBuilder, purchasingBuilder, costScheduleBuilder);
    controllerOverridingClearHibernateSession.run(helper);
    assertFalse(((MockEquipmentServiceImpl) equipmentService).wasEquipmentSaved());
    assertTrue(controllerOverridingClearHibernateSession.isHibernateSessionWasCleared());

    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//equipmentId)", xmlDoc);
    assertXpathEvaluatesTo("456", "//equipmentId", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/error)", xmlDoc);
    assertXpathEvaluatesTo("Accessory Required Fields:", "//errors/error/errorHeader", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//errors/error/errorMsg)", xmlDoc);
    assertXpathEvaluatesTo("Error 1", "//errors/error/errorMsg[1]", xmlDoc);
    assertXpathEvaluatesTo("Error 2", "//errors/error/errorMsg[2]", xmlDoc);
  }

  public void testLookupEquipmentSubTypes_ReturnXmlDoc() throws IOException, ParserException {
    StringBuffer xmlStr = new StringBuffer("<types>");
    xmlStr.append("<type><id>112</id><description>Belt</description></type>");
    xmlStr.append("<type><id>111</id><description>Screw</description></type>");
    xmlStr.append("</types>");
    Document expectedDoc = DOMUtil.stringToXML(xmlStr.toString());
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.LOOK_UP_EQUIP_SUB_TYPES);
    helper.setRequestParameterValue(EquipmentConstants.EQUIPMENT_TYPE, "1");
    ec.run(helper);
    Document resultDoc = helper.getXML();
    assertXMLEqual(expectedDoc, resultDoc);
  }

  public void testLookupEquipmentXml_XmlIsReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.LOOKUP_EQUIPMENT_XML);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    ec.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("00.123.W12", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Equipment Name", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("Equipment Description", "//equipment/description", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/modifiedDate", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("0", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Area Description", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("0", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("123", "//equipment/equipmentTagNumber", xmlDoc);
    assertXpathEvaluatesTo("null", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("W", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("equipment_type", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("null", "//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathEvaluatesTo("W", "//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathEvaluatesTo("sub_type_one", "//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/motors", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/instruments", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/accessories", xmlDoc);
    assertXpathEvaluatesTo("false", "//equipment/existingEquipmentModification", xmlDoc);
    assertXpathEvaluatesTo("false", "//equipment/standardEquipment", xmlDoc);
    assertXpathEvaluatesTo("false", "//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testLookupProcessXml_XmlIsReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.LOOKUP_PROCESS_XML);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    ec.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//process)", xmlDoc);
    assertXpathEvaluatesTo("2", "//process/processId", xmlDoc);
    assertXpathEvaluatesTo("Ear Corn", "//process/productType", xmlDoc);
    assertXpathEvaluatesTo("45.0", "//process/productDensity", xmlDoc);
    assertXpathEvaluatesTo("5000", "//process/designCapacity", xmlDoc);
    assertXpathEvaluatesTo("false", "//process/compAirRequired", xmlDoc);
    assertXpathEvaluatesTo("90", "//process/compAirPressure", xmlDoc);
    assertXpathEvaluatesTo("100", "//process/compAirFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/gasRequired", xmlDoc);
    assertXpathEvaluatesTo("2", "//process/gasType/gasTypeId", xmlDoc);
    assertXpathEvaluatesTo("25", "//process/gasPressure", xmlDoc);
    assertXpathEvaluatesTo("5", "//process/gasFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/waterRequired", xmlDoc);
    assertXpathEvaluatesTo("50", "//process/waterPressure", xmlDoc);
    assertXpathEvaluatesTo("10", "//process/waterFlowrate", xmlDoc);
    assertXpathEvaluatesTo("3", "//process/waterType/waterTypeId", xmlDoc);
    assertXpathEvaluatesTo("false", "//process/dustPickupRequired", xmlDoc);
    assertXpathEvaluatesTo("20", "//process/dustPickupVelocity", xmlDoc);
    assertXpathEvaluatesTo("4", "//process/dustType/dustTypeId", xmlDoc);
    assertXpathEvaluatesTo("BH#", "//process/baghouseCyclone", xmlDoc);
    assertXpathEvaluatesTo("6", "//process/ductSize", xmlDoc);
    assertXpathEvaluatesTo("500", "//process/ductFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/specificationRequired", xmlDoc);
    assertXpathEvaluatesTo("These are my remarks", "//process/processRemarks", xmlDoc);
    assertXpathEvaluatesTo("", "//process/processFieldEquipmentTypes", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
  }

  public void testLookupElectricalXml_ReturnsXml() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.LOOKUP_ELECTRICAL_XML);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockElectricalService electricalService = new MockElectricalService();
    ec = new EquipmentController(equipmentService, equipmentBuilder, processBuilder, mechanicalBuilder, motorBuilder,
        instrumentBuilder, accessoryBuilder, electricalBuilder, purchasingBuilder, costScheduleBuilder, null,
        electricalService);
    ec.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//electrical)", xmlDoc);
    assertXpathEvaluatesTo("4", "//electrical/electId", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/proofOfPositionReq", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/solenoidReq", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/localPushButtonReq", xmlDoc);
    assertXpathEvaluatesTo("1", "//electrical/inputId", xmlDoc);
    assertXpathEvaluatesTo("10", "//electrical/inputQty", xmlDoc);
    assertXpathEvaluatesTo("1", "//electrical/outputId", xmlDoc);
    assertXpathEvaluatesTo("20", "//electrical/outputQty", xmlDoc);
    assertXpathEvaluatesTo("HMI Display", "//electrical/hmiDisplay", xmlDoc);
    assertXpathEvaluatesTo("3", "//electrical/otherMeasurementId", xmlDoc);
    assertXpathEvaluatesTo("Communications", "//electrical/communications", xmlDoc);
    assertXpathEvaluatesTo("100", "//electrical/voltage", xmlDoc);

    assertXpathEvaluatesTo("2", "count(//inputQuantities/inputQuantity)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//outputQuantities/outputQuantity)", xmlDoc);

    assertXpathEvaluatesTo("11", "//inputQuantityId1", xmlDoc);
    assertXpathEvaluatesTo("true", "//inputIdChecked1", xmlDoc);
    assertXpathEvaluatesTo("1", "//inputId1", xmlDoc);
    assertXpathEvaluatesTo("10", "//inputQty1", xmlDoc);

    assertXpathEvaluatesTo("12", "//inputQuantityId2", xmlDoc);
    assertXpathEvaluatesTo("false", "//inputIdChecked2", xmlDoc);
    assertXpathEvaluatesTo("2", "//inputId2", xmlDoc);
    assertXpathEvaluatesTo("20", "//inputQty2", xmlDoc);

    assertXpathEvaluatesTo("13", "//outputQuantityId1", xmlDoc);
    assertXpathEvaluatesTo("false", "//outputIdChecked1", xmlDoc);
    assertXpathEvaluatesTo("1", "//outputId1", xmlDoc);
    assertXpathEvaluatesTo("30", "//outputQty1", xmlDoc);

    assertXpathEvaluatesTo("14", "//outputQuantityId3", xmlDoc);
    assertXpathEvaluatesTo("true", "//outputIdChecked3", xmlDoc);
    assertXpathEvaluatesTo("3", "//outputId3", xmlDoc);
    assertXpathEvaluatesTo("40", "//outputQty3", xmlDoc);
  }

  public void testLookupCostScheduleXml_ReturnsXml() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.LOOKUP_COST_SCHEDULE_XML);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    ec.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//costSchedule)", xmlDoc);
    assertXpathEvaluatesTo("123", "//costSchedule/costScheduleId", xmlDoc);
    assertXpathEvaluatesTo("Sep 24, 2008", "//costSchedule/scheduledSpecificationDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 25, 2008", "//costSchedule/scheduledQuoteDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 26, 2008", "//costSchedule/scheduledPurchaseDate", xmlDoc);
    assertXpathEvaluatesTo("11", "//costSchedule/drawingTurnaroundTime", xmlDoc);
    assertXpathEvaluatesTo("12", "//costSchedule/estiamtedFabricationTime", xmlDoc);
    assertXpathEvaluatesTo("Sep 27, 2008", "//costSchedule/estiamtedShippingDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 28, 2008", "//costSchedule/specIssuedDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 29, 2008", "//costSchedule/rtqEnteredDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 30, 2008", "//costSchedule/rtpEnteredDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 01, 2008", "//costSchedule/prelDrawingIssuedDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 02, 2008", "//costSchedule/approvalDrawingDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 03, 2008", "//costSchedule/finalDrawingDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 04, 2008", "//costSchedule/iomReceivedDate", xmlDoc);
    assertXpathEvaluatesTo("13", "//costSchedule/estimatedCost", xmlDoc);
    assertXpathEvaluatesTo("estimated source", "//costSchedule/estimatedSource", xmlDoc);
    assertXpathEvaluatesTo("22", "//costSchedule/fundingSourceId", xmlDoc);
    assertXpathEvaluatesTo("15", "//costSchedule/estimatedMechHours", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
  }

  public void testDeleteEquipment_ReturnsOk() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EquipmentConstants.METHOD_DELETE_EQUIPMENT);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    ec.run(helper);
    assertTrue(((MockEquipmentServiceImpl) equipmentService).wasDeleteEquipmentCalled());
    String response = helper.getResponse();
    assertEquals("ok", response);
  }

  public void testLookupPurchasingXml_ReturnsXml() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.LOOKUP_PURCHASING_XML);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    ec.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//purchasing)", xmlDoc);
    assertXpathEvaluatesTo("1", "//purchasing/purchaseId", xmlDoc);
    assertXpathEvaluatesTo("My Vendor", "//purchasing/vendor", xmlDoc);
    assertXpathEvaluatesTo("123", "//purchasing/rtpNumber", xmlDoc);
    assertXpathEvaluatesTo("123", "//purchasing/poNumber", xmlDoc);
    assertXpathEvaluatesTo("123", "//purchasing/lineNumber", xmlDoc);
    assertXpathEvaluatesTo("123", "//purchasing/poLineAmount", xmlDoc);
    assertXpathEvaluatesTo("10", "//purchasing/poLineQuantity", xmlDoc);
    assertXpathEvaluatesTo("123", "//purchasing/poLineValue", xmlDoc);
    assertXpathEvaluatesTo("123", "//purchasing/coAmount", xmlDoc);
    assertXpathEvaluatesTo("Oct 27, 2008", "//purchasing/originalShipDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 28, 2008", "//purchasing/revisedShipDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 29, 2008", "//purchasing/actualDeliveryDate", xmlDoc);
    assertXpathEvaluatesTo("true", "//purchasing/exportDocuments", xmlDoc);
  }

   public void testUpdateVerificationForEquipmentChange_ReturnsXml() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.UPDATE_VERIFICATION_FOR_CHANGE_METHOD);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
     User logonUser = (User) helper.getSessionParameter(EISConstants.LOGIN_USER);
    helper.setRequestParameterValue(EISConstants.AUDIT_DETAIL_ID, "11");
    helper.setRequestParameterValue(EISConstants.AUDIT_TRANSACTION_ID, "22");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_CHANGE_VERIFIED_COLUMN, "processVerified");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_CHANGE_VERIFIED_CHECKED_UNCHECKED, "true");

     MockAuditServiceImpl auditService = new MockAuditServiceImpl();
    ec = new EquipmentController(equipmentService, equipmentBuilder, processBuilder, mechanicalBuilder, motorBuilder,
        instrumentBuilder, accessoryBuilder, electricalBuilder, purchasingBuilder, costScheduleBuilder, auditService,
        null);
    ec.run(helper);
     assertTrue(auditService.getWasUpdateVerificationForEquipmentChangeCalled());
  }

  private Date getDate(int numDaysToAdd) {
    Calendar cal = Calendar.getInstance();
    cal.set(Calendar.YEAR, 2008);
    cal.set(Calendar.MONTH, 8);
    cal.set(Calendar.DATE, 23);
    cal.add(Calendar.DATE, numDaysToAdd);
    return cal.getTime();
  }

  private class MockEquipmentControllerOverridingClearHibernateSession extends EquipmentController {
    private boolean hibernateSessionWasCleared;

    public MockEquipmentControllerOverridingClearHibernateSession(
        EquipmentService equipmentService, EquipmentBuilder equipmentBuilder, ProcessBuilder processBuilder,
        MechanicalBuilder mechanicalBuilder, MotorBuilder motorBuilder, InstrumentBuilder instrumentBuilder,
        AccessoryBuilder accessoryBuilder, ElectricalBuilder electricalBuilder, PurchasingBuilder purchasingBuilder,
        CostScheduleBuilder costScheduleBuilder) {
      super(equipmentService, equipmentBuilder, processBuilder, mechanicalBuilder, motorBuilder, instrumentBuilder,
          accessoryBuilder,
          electricalBuilder, purchasingBuilder, costScheduleBuilder, null, null);
    }

    //protected for testing
    protected void clearHibernateSession() {
      this.hibernateSessionWasCleared = true;
    }

    public boolean isHibernateSessionWasCleared() {
      return hibernateSessionWasCleared;
    }
  }
}


