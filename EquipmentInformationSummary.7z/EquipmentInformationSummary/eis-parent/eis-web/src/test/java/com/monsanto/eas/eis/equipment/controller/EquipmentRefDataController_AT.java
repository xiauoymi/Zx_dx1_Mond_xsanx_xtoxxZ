/*
 EquipmentRefDataController_AT was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.CopyEquipmentConstants;
import com.monsanto.eas.eis.equipment.controller.EquipmentRefDataController;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: EquipmentRefDataController_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-10 16:55:42 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class EquipmentRefDataController_AT extends EISTestCase{

  public void testlookupRefDataForMotorXML_ReturnsXMLDoc() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForMotorXML");
    EquipmentRefDataController controller = new EquipmentRefDataController();
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
  }

  public void testlookupRefDataForProcessDetailsTabXML_ReturnsXMLDoc() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForProcessDetailsTabXML");
    helper.setRequestParameterValue("equipmentTypeId", "7");
    helper.setRequestParameterValue("unitMeasureId", "1");
    EquipmentRefDataController controller = new EquipmentRefDataController();
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
  }


  public void testlookupRefDataForProcessTabXML_ReturnsXMLDoc() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForProcessXML");
    helper.setRequestParameterValue("unitMeasureId", "1");
    EquipmentRefDataController controller = new EquipmentRefDataController();
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
  }

  public void testLookupRefDataForInstrumentXml_ReturnsXmlDoc() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForInstrumentXML");
    EquipmentRefDataController controller = new EquipmentRefDataController();
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
  }

  public void testsdf() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "copyEquipmentsToProject");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "557050");
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_ID_TO_COPY, "570755");
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_NAME, new String[]{"name 1", "name 2"});
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_AREA, new String[]{"2", "3"});
    helper.setRequestParameterValue(CopyEquipmentConstants.PROCESS_LINE_NUMBER, new String[]{"2", "4"});
    helper.setRequestParameterValue(CopyEquipmentConstants.EQUIPMENT_TAG_NUMBER, new String[]{"222", "333"});
    CopyEquipmentController controller = new CopyEquipmentController();
    controller.run(helper);
    
  }
}