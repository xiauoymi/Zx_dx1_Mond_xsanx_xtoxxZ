/*
 EquipmentRefDataController_UT was created on Oct 20, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.equipment.service.mock.*;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.projects.mocks.MockEquipmentServiceImpl;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: EquipmentRefDataController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $
 * On:	$Date: 2009-01-21 18:28:35 $
 *
 * @author sspati1
 * @version $Revision: 1.15 $
 */
public class EquipmentRefDataController_UT extends XMLTestCase {

  public void testlookupRefDataForMechanicalXML_ReturnsXMLDoc() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForMechanicalXML");
    EquipmentRefDataController controller = new EquipmentRefDataController(null, null, null, null,
        null, null, new MockMechanicalService(), null);
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//purchaseScopes)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//purchaseScope)", xmlDoc);
    assertXpathEvaluatesTo("1", "//purchaseScope[1]/id", xmlDoc);
    assertXpathEvaluatesTo("Contractor", "//purchaseScope[1]/purchaseScopeName", xmlDoc);
  }

  public void testlookupRefDataForMotorXML_ReturnsXMLDoc() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForMotorXML");
    EquipmentRefDataController controller = new EquipmentRefDataController(new MockMotorService(), null, null, null,
        new MockProcessService(), null, null, null);
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//designStatuses)", xmlDoc);
    assertXpathEvaluatesTo("3", "count(//designStatus)", xmlDoc);
    assertXpathEvaluatesTo("3", "//designStatus[1]/id", xmlDoc);
    assertXpathEvaluatesTo("Preliminary", "//designStatus[1]/name", xmlDoc);
    assertXpathEvaluatesTo("4", "//designStatus[2]/id", xmlDoc);
    assertXpathEvaluatesTo("Mechanical Confirmed", "//designStatus[2]/name", xmlDoc);
    assertXpathEvaluatesTo("5", "//designStatus[3]/id", xmlDoc);
    assertXpathEvaluatesTo("Electrical Confirmed", "//designStatus[3]/name", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//loadValueTypes)", xmlDoc);
    assertXpathEvaluatesTo("4", "count(//loadValueType)", xmlDoc);
    assertXpathEvaluatesTo("5", "//loadValueType[1]/id", xmlDoc);
    assertXpathEvaluatesTo("Horsepower", "//loadValueType[1]/name", xmlDoc);
    assertXpathEvaluatesTo("6", "//loadValueType[2]/id", xmlDoc);
    assertXpathEvaluatesTo("kVA", "//loadValueType[2]/name", xmlDoc);
    assertXpathEvaluatesTo("7", "//loadValueType[3]/id", xmlDoc);
    assertXpathEvaluatesTo("Horsepower 2", "//loadValueType[3]/name", xmlDoc);
    assertXpathEvaluatesTo("8", "//loadValueType[4]/id", xmlDoc);
    assertXpathEvaluatesTo("kVA 2", "//loadValueType[4]/name", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//componentDesignators)", xmlDoc);
    assertXpathEvaluatesTo("3", "count(//componentDesignator)", xmlDoc);
    assertXpathEvaluatesTo("12", "//componentDesignator[1]/id", xmlDoc);
    assertXpathEvaluatesTo("MA - FVNR Across Line Starter", "//componentDesignator[1]/name", xmlDoc);
    assertXpathEvaluatesTo("13", "//componentDesignator[2]/id", xmlDoc);
    assertXpathEvaluatesTo("MR - FVR Reversing Starter", "//componentDesignator[2]/name", xmlDoc);
    assertXpathEvaluatesTo("14", "//componentDesignator[3]/id", xmlDoc);
    assertXpathEvaluatesTo("MU - Unidentifed", "//componentDesignator[3]/name", xmlDoc);
  }

  public void testLookupRefDataForInstrumentXml_ReturnsXmlDoc() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForInstrumentXML");
    EquipmentRefDataController controller = new EquipmentRefDataController(null, new MockInstrumentService(), null,
        null,
        new MockProcessService(), null, null, null);
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//instrumentDesignatorsForFirstChar)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//refData/instrumentDesignatorsForFirstChar/instrumentDesignator)", xmlDoc);
    assertXpathEvaluatesTo("11", "//refData/instrumentDesignatorsForFirstChar/instrumentDesignator[1]/id", xmlDoc);
    assertXpathEvaluatesTo("A - Analyzer", "//refData/instrumentDesignatorsForFirstChar/instrumentDesignator[1]/name",
        xmlDoc);
    assertXpathEvaluatesTo("1", "count(//refData/instrumentDesignatorsForSecondChar)", xmlDoc);
    assertXpathEvaluatesTo("3", "count(//refData/instrumentDesignatorsForSecondChar/instrumentDesignator)", xmlDoc);
    assertXpathEvaluatesTo("13", "//refData/instrumentDesignatorsForSecondChar/instrumentDesignator[1]/id", xmlDoc);
    assertXpathEvaluatesTo("I - Indicating",
        "//refData/instrumentDesignatorsForSecondChar/instrumentDesignator[1]/name", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//refData/ioTypes)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//refData/ioTypes/ioType)", xmlDoc);
    assertXpathEvaluatesTo("16", "//refData/ioTypes/ioType[1]/id", xmlDoc);
    assertXpathEvaluatesTo("Analog", "//refData/ioTypes/ioType[1]/name", xmlDoc);
  }

  public void testLookupRefDataForElectricalXml_ReturnsXmlDoc() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForElectricalXML");
    EquipmentRefDataController controller = new EquipmentRefDataController(null, null, new MockElectricalService(),
        null,
        new MockProcessService(), null, null, null);
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//inputs)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//input)", xmlDoc);
    assertXpathEvaluatesTo("1", "//refData/inputs/electricalInput[1]/id", xmlDoc);
    assertXpathEvaluatesTo("AI", "//refData/inputs/electricalInput[1]/input", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//outputs)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//output)", xmlDoc);
    assertXpathEvaluatesTo("3", "//refData/outputs/electricalOutput[1]/id", xmlDoc);
    assertXpathEvaluatesTo("AO", "//refData/outputs/electricalOutput[1]/output", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//otherMeasurements)", xmlDoc);
    assertXpathEvaluatesTo("4", "count(//otherMeasurement)", xmlDoc);
    assertXpathEvaluatesTo("5", "//refData/otherMeasurements/otherMeasurement[1]/id", xmlDoc);
    assertXpathEvaluatesTo("Level", "//refData/otherMeasurements/otherMeasurement[1]/measurement", xmlDoc);
  }

  public void testLookupRefDataForAccessoryXml_ReturnsXmlDoc() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForAccessoryXML");
    EquipmentRefDataController controller = new EquipmentRefDataController(null, null, new MockElectricalService(),
        new MockAccessoryService(),
        new MockProcessService(), null, null, null);
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//accessoryDesignators)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//accessoryDesignator)", xmlDoc);
    assertXpathEvaluatesTo("11", "//refData/accessoryDesignators/accessoryDesignator[1]/id", xmlDoc);
    assertXpathEvaluatesTo("AD1 - ADES 1", "//refData/accessoryDesignators/accessoryDesignator[1]/name", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//autoManuals)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//autoManual)", xmlDoc);
    assertXpathEvaluatesTo("22", "//refData/autoManuals/autoManual[1]/id", xmlDoc);
    assertXpathEvaluatesTo("AU", "//refData/autoManuals/autoManual[1]/name", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//inputs)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//input)", xmlDoc);
    assertXpathEvaluatesTo("1", "//refData/inputs/electricalInput[1]/id", xmlDoc);
    assertXpathEvaluatesTo("AI", "//refData/inputs/electricalInput[1]/input", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//outputs)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//output)", xmlDoc);
    assertXpathEvaluatesTo("3", "//refData/outputs/electricalOutput[1]/id", xmlDoc);
    assertXpathEvaluatesTo("AO", "//refData/outputs/electricalOutput[1]/output", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//otherMeasurements)", xmlDoc);
    assertXpathEvaluatesTo("4", "count(//otherMeasurement)", xmlDoc);
    assertXpathEvaluatesTo("5", "//refData/otherMeasurements/otherMeasurement[1]/id", xmlDoc);
    assertXpathEvaluatesTo("Level", "//refData/otherMeasurements/otherMeasurement[1]/measurement", xmlDoc);
  }

  public void testLookupRefDataForProcessXml_ReturnsXmlDoc() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForProcessXML");
    helper.setRequestParameterValue("unitMeasureId", "12");
    EquipmentRefDataController controller = new EquipmentRefDataController(null, null, new MockElectricalService(),
        new MockAccessoryService(), new MockProcessService(), null, null, new MockEquipmentServiceImpl());
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//fieldEquipmentTypes)", xmlDoc);
    assertXpathEvaluatesTo("3", "count(//fieldEquipmentType)", xmlDoc);

    assertXpathEvaluatesTo("12", "//refData/fieldEquipmentTypes/fieldEquipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("text", "//refData/fieldEquipmentTypes/fieldEquipmentType/fieldType", xmlDoc);
    assertXpathEvaluatesTo("testFE1", "//fieldEquipmentType/name", xmlDoc);
    assertXpathEvaluatesTo("My Comments", "//fieldEquipmentType/label", xmlDoc);
    assertXpathEvaluatesTo("Integer", "//fieldEquipmentType/dataType", xmlDoc);
    assertXpathEvaluatesTo("3", "//fieldEquipmentType/size", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//refData/fieldEquipmentTypes/fieldEquipmentType[1]/listValues)", xmlDoc);
    assertXpathEvaluatesTo("0", "count(//refData/fieldEquipmentTypes/fieldEquipmentType[1]/listValue)", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//gasTypes)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//gasType)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//waterTypes)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//waterType)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//dustTypes)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//dustType)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//equipmentTypes)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//equipmentType)", xmlDoc);
    assertXpathEvaluatesTo("C", "//refData/equipmentTypes/equipmentType[1]/typeCode", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//refData/equipmentTypes/equipmentType[1]/designCapacityUnits)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//refData/equipmentTypes/equipmentType[1]/designCapacityUnits/designCapacityUnit)", xmlDoc);
    assertXpathEvaluatesTo("123", "//refData/equipmentTypes/equipmentType[1]/designCapacityUnits/designCapacityUnit/id", xmlDoc);
    assertXpathEvaluatesTo("unit name 1", "//refData/equipmentTypes/equipmentType[1]/designCapacityUnits/designCapacityUnit/unitName", xmlDoc);
    assertXpathEvaluatesTo("D", "//refData/equipmentTypes/equipmentType[2]/typeCode", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//refData/equipmentTypes/equipmentType[2]/designCapacityUnits)", xmlDoc);
    assertXpathEvaluatesTo("0", "count(//refData/equipmentTypes/equipmentType[2]/designCapacityUnits/designCapacityUnit)", xmlDoc);
  }

  public void testLookupRefDataForProcessDetailsTabXml_ReturnsXmlDoc() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForProcessDetailsTabXML");
    helper.setRequestParameterValue("unitMeasureId", "12");
    helper.setRequestParameterValue("equipmentTypeId", "13");
    EquipmentRefDataController controller = new EquipmentRefDataController(null, null, new MockElectricalService(),
        new MockAccessoryService(), new MockProcessService(), null, null, null);
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData/designCapacityUnits)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//refData/designCapacityUnits/designCapacityUnit)", xmlDoc);
    assertXpathEvaluatesTo("1", "//refData/designCapacityUnits/designCapacityUnit[1]/id", xmlDoc);
    assertXpathEvaluatesTo("unit name 1", "//refData/designCapacityUnits/designCapacityUnit[1]/unitName", xmlDoc);
  }

  public void testLookupRefDataForCostScheduleXml_ReturnsXmlDoc() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForCostScheduleXML");
    EquipmentRefDataController controller = new EquipmentRefDataController(null, null, null,
        null, null, new MockCostScheduleService(), null, null);
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//fundingSources)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//fundingSource)", xmlDoc);
    assertXpathEvaluatesTo("12", "//refData/fundingSources/fundingSource[1]/id", xmlDoc);
    assertXpathEvaluatesTo("Lease", "//refData/fundingSources/fundingSource[1]/source", xmlDoc);
  }
}