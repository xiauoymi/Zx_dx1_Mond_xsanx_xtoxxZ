package com.monsanto.eas.eis.equipment.dao;

import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.mocks.MockDisciplineSearchDAO;
import com.monsanto.eas.eis.util.EquipmentConstants;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.wst.hibernate.mock.MockHibernateFactory;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 9, 2008
 * Time: 2:58:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class DisciplineSearchDAOImpl_UT extends TestCase {

  public void testFindBySearchCriteria_AllSearchCriteriaPassed_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeId = "1";
    String aradId = "4";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String sortKey = "equipmentNumber";
    String sortDir = "asc";

    MockDisciplineSearchDAO equipmentDAO = new MockDisciplineSearchDAO(new MockHibernateFactory(), Equipment.class);
    PaginatedResult result = equipmentDAO.findBySearchCriteria(equipmentDAO.createCriteria(), projectID,
        equipmentNumber, equipmentName, processLine, equipmentTypeId,
        aradId, vendor, sortKey, sortDir, 1, 5);
    assertEquals(10, result.getTotalRecords());
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(8, criteria.getCriteria().size());
    assertEquals("eq.projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=4", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(3).toString());
    assertEquals("eq.equipmentNumber like %777%", criteria.getCriteria().get(4).toString());
    assertEquals("eq.name like %Name1%", criteria.getCriteria().get(5).toString());
    assertEquals("eq.processLineNumber like %11%", criteria.getCriteria().get(6).toString());
    assertEquals("eq.isDeleted=false", criteria.getCriteria().get(7).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("eq.equipmentNumber asc", criteria.getOrderings().get(0).toString());

    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_MaxResultIsGreaterThanTotalRecords_SetMaxResultsIsEqualToTotalRecords() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeId = "1";
    String aradId = "4";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String sortKey = "equipmentNumber";
    String sortDir = "asc";

    MockDisciplineSearchDAO equipmentDAO = new MockDisciplineSearchDAO(new MockHibernateFactory(), Equipment.class);
    PaginatedResult result = equipmentDAO.findBySearchCriteria(equipmentDAO.createCriteria(), projectID,
        equipmentNumber, equipmentName, processLine, equipmentTypeId,
        aradId, vendor, sortKey, sortDir, 1, 11);
    assertEquals(10, result.getTotalRecords());
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(10, criteria.getMaxResult());
    assertEquals(8, criteria.getCriteria().size());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_EquipmentNumberNotSetSortByAreaCode_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "";
    String equipmentTypeID = "1";
    String areaID = "4";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String sortKey = "area";
    String sortDir = "desc";

    MockDisciplineSearchDAO equipmentDAO = new MockDisciplineSearchDAO(new MockHibernateFactory(), Equipment.class);
    PaginatedResult result = equipmentDAO.findBySearchCriteria(equipmentDAO.createCriteria(), projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, sortKey, sortDir, 1, 5);
    assertEquals(10, result.getTotalRecords());
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(7, criteria.getCriteria().size());
    assertEquals("eq.projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=4", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(3).toString());
    assertEquals("eq.name like %Name1%", criteria.getCriteria().get(4).toString());
    assertEquals("eq.processLineNumber like %11%", criteria.getCriteria().get(5).toString());
    assertEquals("eq.isDeleted=false", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("a.areaCode desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_EquipmentNameNotSetSortByEquipmentNumber_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeID = "1";
    String areaID = "4";
    String equipmentName = "";
    String processLine = "11";
    String vendor = "test vendor";
    String sortKey = "equipmentNumber";
    String sortDir = "desc";

    MockDisciplineSearchDAO equipmentDAO = new MockDisciplineSearchDAO(new MockHibernateFactory(), Equipment.class);
    PaginatedResult result = equipmentDAO.findBySearchCriteria(equipmentDAO.createCriteria(), projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, sortKey, sortDir, 1, 5);
    assertEquals(10, result.getTotalRecords());
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(7, criteria.getCriteria().size());
    assertEquals("eq.projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=4", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(3).toString());
    assertEquals("eq.equipmentNumber like %777%", criteria.getCriteria().get(4).toString());
    assertEquals("eq.processLineNumber like %11%", criteria.getCriteria().get(5).toString());
    assertEquals("eq.isDeleted=false", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("eq.equipmentNumber desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_EquipmentTypeNotSetSortByEquipmentType_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeID = "";
    String areaID = "4";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String sortKey = EquipmentConstants.EQUIPMENT_TYPE;
    String sortDir = "asc";

    MockDisciplineSearchDAO equipmentDAO = new MockDisciplineSearchDAO(new MockHibernateFactory(), Equipment.class);
    PaginatedResult result = equipmentDAO.findBySearchCriteria(equipmentDAO.createCriteria(), projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, sortKey, sortDir, 1, 5);
    assertEquals(10, result.getTotalRecords());
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(7, criteria.getCriteria().size());
    assertEquals("eq.projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=4", criteria.getCriteria().get(1).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(2).toString());
    assertEquals("eq.equipmentNumber like %777%", criteria.getCriteria().get(3).toString());
    assertEquals("eq.name like %Name1%", criteria.getCriteria().get(4).toString());
    assertEquals("eq.processLineNumber like %11%", criteria.getCriteria().get(5).toString());
    assertEquals("eq.isDeleted=false", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("et.name asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_ProcessLineNotSetSortByVendor_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeID = "1";
    String areaID = "4";
    String equipmentName = "Name1";
    String processLine = "";
    String vendor = "test vendor";
    String sortKey = "equipmentVendor";
    String sortDir = "asc";

    MockDisciplineSearchDAO equipmentDAO = new MockDisciplineSearchDAO(new MockHibernateFactory(), Equipment.class);
    PaginatedResult result = equipmentDAO.findBySearchCriteria(equipmentDAO.createCriteria(), projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, sortKey, sortDir, 1, 5);
    assertEquals(10, result.getTotalRecords());
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(7, criteria.getCriteria().size());
    assertEquals("eq.projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=4", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(3).toString());
    assertEquals("eq.equipmentNumber like %777%", criteria.getCriteria().get(4).toString());
    assertEquals("eq.name like %Name1%", criteria.getCriteria().get(5).toString());
    assertEquals("eq.isDeleted=false", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("pu.vendor asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_AreaIdNotSetSortByArea_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeID = "1";
    String areaID = "";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String sortKey = EquipmentConstants.AREA;
    String sortDir = "desc";

    MockDisciplineSearchDAO equipmentDAO = new MockDisciplineSearchDAO(new MockHibernateFactory(), Equipment.class);
    PaginatedResult result = equipmentDAO.findBySearchCriteria(equipmentDAO.createCriteria(), projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, sortKey, sortDir, 1, 5);
    assertEquals(10, result.getTotalRecords());
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(7, criteria.getCriteria().size());
    assertEquals("eq.projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(1).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(2).toString());
    assertEquals("eq.equipmentNumber like %777%", criteria.getCriteria().get(3).toString());
    assertEquals("eq.name like %Name1%", criteria.getCriteria().get(4).toString());
    assertEquals("eq.processLineNumber like %11%", criteria.getCriteria().get(5).toString());
    assertEquals("eq.isDeleted=false", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("a.areaCode desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
 }

  public void testFindBySearchCriteria_AreaIdNotSetSortByVendor_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeID = "1";
    String areaID = "";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String sortKey = "equipmentVendor";
    String sortDir = "desc";

    MockDisciplineSearchDAO equipmentDAO = new MockDisciplineSearchDAO(new MockHibernateFactory(), Equipment.class);
    PaginatedResult result = equipmentDAO.findBySearchCriteria(equipmentDAO.createCriteria(), projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, sortKey, sortDir, 1, 5);
    assertEquals(10, result.getTotalRecords());
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(7, criteria.getCriteria().size());
    assertEquals("eq.projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(1).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(2).toString());
    assertEquals("eq.equipmentNumber like %777%", criteria.getCriteria().get(3).toString());
    assertEquals("eq.name like %Name1%", criteria.getCriteria().get(4).toString());
    assertEquals("eq.processLineNumber like %11%", criteria.getCriteria().get(5).toString());
    assertEquals("eq.isDeleted=false", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("pu.vendor desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
 }
}
