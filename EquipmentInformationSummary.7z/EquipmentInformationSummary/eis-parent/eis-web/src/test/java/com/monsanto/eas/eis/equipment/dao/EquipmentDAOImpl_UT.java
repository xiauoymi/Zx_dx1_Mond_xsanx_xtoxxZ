/*
 EquipmentDAOImpl_UT was created on Oct 31, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.dao;

import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.mocks.MockEquipmentDAO;
import com.monsanto.eas.eis.util.EquipmentConstants;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: EquipmentDAOImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $ On:	$Date:
 * 2008/12/15 14:28:34 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public class EquipmentDAOImpl_UT extends TestCase {

  public void testFindBySearchCriteria_AllSearchCriteriaPassed_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeId = "1";
    String aradId = "4";
    String equipmentName = "Name1";
    String processLine = "11";
    String existingEquipmentNumber = "10.0.B1";
    String vendor = "test vendor";
    String sortKey = "equipmentNumber";
    String sortDir = "asc";
    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    PaginatedResult result = equipmentDAO
        .findBySearchCriteria(projectID, equipmentNumber, equipmentName, processLine, equipmentTypeId,
            aradId, vendor, existingEquipmentNumber, sortKey, sortDir, 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(10, result.getTotalRecords());
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(8, criteria.getCriteria().size());
    assertEquals("projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=4", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("equipmentNumber like %777%", criteria.getCriteria().get(3).toString());
    assertEquals("name like %Name1%", criteria.getCriteria().get(4).toString());
    assertEquals("processLineNumber like %11%", criteria.getCriteria().get(5).toString());
    assertEquals("existingEquipmentNumber like %10.0.B1%", criteria.getCriteria().get(6).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(7).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("equipmentNumber asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_MaxResultsIsGreaterThanTotalRecords_MaxResultsIsEqualToTotalRecords() throws
      Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeId = "1";
    String aradId = "4";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String existingEquipmentNumber = "10.0.B1";
    String sortKey = "equipmentNumber";
    String sortDir = "asc";
    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    PaginatedResult result = equipmentDAO
        .findBySearchCriteria(projectID, equipmentNumber, equipmentName, processLine, equipmentTypeId,
            aradId, vendor, existingEquipmentNumber, sortKey, sortDir, 1, 11);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(10, result.getTotalRecords());
    assertEquals(1, criteria.getFirstResult());
    assertEquals(10, criteria.getMaxResult());
    assertEquals(8, criteria.getCriteria().size());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_AllSearchCriteriaPassedSortByMotors_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeId = "1";
    String aradId = "4";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String existingEquipmentNumber = "10.0.B1";
    String sortKey = "motors";
    String sortDir = "asc";

    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    equipmentDAO.findBySearchCriteria(projectID, equipmentNumber, equipmentName, processLine, equipmentTypeId,
        aradId, vendor, existingEquipmentNumber, sortKey, sortDir, 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(8, criteria.getCriteria().size());
    assertEquals("projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=4", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("equipmentNumber like %777%", criteria.getCriteria().get(3).toString());
    assertEquals("name like %Name1%", criteria.getCriteria().get(4).toString());
    assertEquals("processLineNumber like %11%", criteria.getCriteria().get(5).toString());
    assertEquals("existingEquipmentNumber like %10.0.B1%", criteria.getCriteria().get(6).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(7).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("motors asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_EquipmentNumberNotSetSortByAreaCode_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "";
    String equipmentTypeID = "1";
    String areaID = "4";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String existingEquipmentNumber = "10.0.B1";
    String sortKey = "area";
    String sortDir = "desc";

    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    equipmentDAO.findBySearchCriteria(projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, existingEquipmentNumber, sortKey, sortDir, 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(7, criteria.getCriteria().size());
    assertEquals("projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=4", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("name like %Name1%", criteria.getCriteria().get(3).toString());
    assertEquals("processLineNumber like %11%", criteria.getCriteria().get(4).toString());
    assertEquals("existingEquipmentNumber like %10.0.B1%", criteria.getCriteria().get(5).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("a.areaCode desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_EquipmentNameNotSetSortByEquipmentNumber_VerifyHibernateCriteria() throws
      Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeID = "1";
    String areaID = "4";
    String equipmentName = "";
    String processLine = "11";
    String vendor = "test vendor";
    String existingEquipmentNumber = "10.0.B1";
    String sortKey = "equipmentNumber";
    String sortDir = "desc";

    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    equipmentDAO.findBySearchCriteria(projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, existingEquipmentNumber, sortKey, sortDir, 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(7, criteria.getCriteria().size());
    assertEquals("projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=4", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("equipmentNumber like %777%", criteria.getCriteria().get(3).toString());
    assertEquals("processLineNumber like %11%", criteria.getCriteria().get(4).toString());
    assertEquals("existingEquipmentNumber like %10.0.B1%", criteria.getCriteria().get(5).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("equipmentNumber desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_EquipmentTypeNotSetSortByEquipmentType_VerifyHibernateCriteria() throws
      Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeID = "";
    String areaID = "4";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String existingEquipmentNumber = "10.0.B1";
    String sortKey = EquipmentConstants.EQUIPMENT_TYPE;
    String sortDir = "asc";

    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    equipmentDAO.findBySearchCriteria(projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, existingEquipmentNumber, sortKey, sortDir, 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(7, criteria.getCriteria().size());
    assertEquals("projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=4", criteria.getCriteria().get(1).toString());
    assertEquals("equipmentNumber like %777%", criteria.getCriteria().get(2).toString());
    assertEquals("name like %Name1%", criteria.getCriteria().get(3).toString());
    assertEquals("processLineNumber like %11%", criteria.getCriteria().get(4).toString());
    assertEquals("existingEquipmentNumber like %10.0.B1%", criteria.getCriteria().get(5).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("et.name asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_ProcessLineNotSetSortByVendor_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeID = "1";
    String areaID = "4";
    String equipmentName = "Name1";
    String processLine = "";
    String vendor = "test vendor";
    String existingEquipmentNumber = "10.0.B1";
    String sortKey = "equipmentVendor";
    String sortDir = "asc";

    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    equipmentDAO.findBySearchCriteria(projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, existingEquipmentNumber, sortKey, sortDir, 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(7, criteria.getCriteria().size());
    assertEquals("projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=4", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("equipmentNumber like %777%", criteria.getCriteria().get(3).toString());
    assertEquals("name like %Name1%", criteria.getCriteria().get(4).toString());
    assertEquals("existingEquipmentNumber like %10.0.B1%", criteria.getCriteria().get(5).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("pu.vendor asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_AreaIdNotSetSortByArea_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeID = "1";
    String areaID = "";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String existingEquipmentNumber = "10.0.B1";
    String sortKey = EquipmentConstants.AREA;
    String sortDir = "desc";

    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    equipmentDAO.findBySearchCriteria(projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, existingEquipmentNumber, sortKey, sortDir, 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(7, criteria.getCriteria().size());
    assertEquals("projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(1).toString());
    assertEquals("equipmentNumber like %777%", criteria.getCriteria().get(2).toString());
    assertEquals("name like %Name1%", criteria.getCriteria().get(3).toString());
    assertEquals("processLineNumber like %11%", criteria.getCriteria().get(4).toString());
    assertEquals("existingEquipmentNumber like %10.0.B1%", criteria.getCriteria().get(5).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("a.areaCode desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_VendorNotSetSortByInstruments_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeID = "1";
    String areaID = "4";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "";
    String existingEquipmentNumber = "10.0.B1";
    String sortKey = "instruments";
    String sortDir = "desc";

    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    equipmentDAO.findBySearchCriteria(projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, existingEquipmentNumber, sortKey, sortDir, 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(7, criteria.getCriteria().size());
    assertEquals("projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=4", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("equipmentNumber like %777%", criteria.getCriteria().get(3).toString());
    assertEquals("name like %Name1%", criteria.getCriteria().get(4).toString());
    assertEquals("processLineNumber like %11%", criteria.getCriteria().get(5).toString());
    assertEquals("existingEquipmentNumber like %10.0.B1%", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("instruments desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_AreaIdNotSetSortByVendor_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeID = "1";
    String areaID = "";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String existingEquipmentNumber = "10.0.B1";
    String sortKey = "equipmentVendor";
    String sortDir = "desc";

    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    equipmentDAO.findBySearchCriteria(projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, existingEquipmentNumber, sortKey, sortDir, 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(7, criteria.getCriteria().size());
    assertEquals("projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(1).toString());
    assertEquals("equipmentNumber like %777%", criteria.getCriteria().get(2).toString());
    assertEquals("name like %Name1%", criteria.getCriteria().get(3).toString());
    assertEquals("processLineNumber like %11%", criteria.getCriteria().get(4).toString());
    assertEquals("existingEquipmentNumber like %10.0.B1%", criteria.getCriteria().get(5).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("pu.vendor desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_ExistingEquipmentNumberNotSetSortByVendor_VerifyHibernateCriteria() throws Exception {
    String projectID = "1";
    String equipmentNumber = "777";
    String equipmentTypeID = "1";
    String areaID = "1";
    String equipmentName = "Name1";
    String processLine = "11";
    String vendor = "test vendor";
    String existingEquipmentNumber = "";
    String sortKey = "equipmentVendor";
    String sortDir = "desc";

    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    equipmentDAO.findBySearchCriteria(projectID, equipmentNumber, equipmentName, processLine, equipmentTypeID,
        areaID, vendor, existingEquipmentNumber, sortKey, sortDir, 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(7, criteria.getCriteria().size());
    assertEquals("projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("a.id=1", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("equipmentNumber like %777%", criteria.getCriteria().get(3).toString());
    assertEquals("name like %Name1%", criteria.getCriteria().get(4).toString());
    assertEquals("processLineNumber like %11%", criteria.getCriteria().get(5).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(6).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("pu.vendor desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindByPrimaryKey_VerifyJoins() throws Exception {
    Equipment eq = new Equipment();
    eq.setId(new Long(234));
    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(eq);
    Equipment eqipment = equipmentDAO.findByPrimaryKey(new Long(234));
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("id=234", criteria.getCriteria().get(0).toString());
    assertEquals(4, criteria.getFetchModes().size());
    assertEquals("motors-JOIN", criteria.getFetchModes().get(0));
    assertEquals("instruments-JOIN", criteria.getFetchModes().get(1));
    assertEquals("accessories-JOIN", criteria.getFetchModes().get(2));
    assertEquals("process.processFieldEquipmentTypes-JOIN", criteria.getFetchModes().get(3));
    assertEquals(eq, eqipment);
  }

  public void testClearHibernateSession_ClearsHibernateSession() throws Exception {
    assertTrue(true);
    //todo assert that session is cleared. Need to modify MockHibernateSession
  }

//  public void testsdf() throws Exception {
//    EquipmentDAO dso = new EquipmentDAOImpl();
//    List<Equipment> list = dso
//        .findBySearchCriteria("156350", null, null, null, null, null, null, "equipmentNumber", "asc");
//
//    Equipment equipment = dso.findByPrimaryKey(new Long(187100));
//  }

}