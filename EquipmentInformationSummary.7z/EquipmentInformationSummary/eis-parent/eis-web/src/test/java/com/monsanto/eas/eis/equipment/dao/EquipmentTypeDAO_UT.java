package com.monsanto.eas.eis.equipment.dao;

import com.monsanto.eas.eis.projects.domain.EquipmentType;
import com.monsanto.eas.eis.equipment.EquipmentTestUtil;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import junit.framework.TestCase;
import org.hibernate.Criteria;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 17, 2008
 * Time: 2:28:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class EquipmentTypeDAO_UT extends TestCase {

  // this tests the equals and hashCode method of EquipmentType
  public void testEqualsAndHashCodeInProjects_For2EquipmentTypesWithSameIDs() throws Exception {
    EquipmentType equipmentType1 = EquipmentTestUtil.getEquipmentType(1L);
    EquipmentType equipmentType2 = EquipmentTestUtil.getEquipmentType(1L);
    assertTrue(equipmentType1.equals(equipmentType2));
    assertTrue(equipmentType1.hashCode() == equipmentType2.hashCode());
  }

  // this tests the equals and hashCode method of EquipmentType
  public void testEqualsAndHashCodeInProjects_For2EquipmentTypesWithDifferentIDs() throws Exception {
    EquipmentType equipmentType1 = EquipmentTestUtil.getEquipmentType(1L);
    EquipmentType equipmentType2 = EquipmentTestUtil.getEquipmentType(2L);
    assertFalse(equipmentType1.equals(equipmentType2));
    assertFalse(equipmentType1.hashCode() == equipmentType2.hashCode());
  }
}
