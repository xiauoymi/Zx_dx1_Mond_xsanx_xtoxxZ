/*
 AccessoryDataSource_UT was created on Nov 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.equipment.datasource.mock.MockDAOWithTotalRecords;
import com.monsanto.eas.eis.projects.domain.Accessory;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.util.AccessoryConstants;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.ElectricalConstants;
import com.monsanto.eas.eis.util.PurchasingConstants;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.mock.MockDAO;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: AccessoryDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-02-13 15:36:16 $
 *
 * @author sspati1
 * @version $Revision: 1.9 $
 */
public class AccessoryDataSource_UT extends TestCase {

  public void testGetData_EquipmentNotInSessionIdIsEmpty_EmptyListIsReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "");
    GenericDAO<Accessory, Long> accessoryDao = new MockDAO<Accessory, Long>(null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    List<? extends XmlObject> data = ds.getData(AccessoryConstants.ACCE_NAME, "desc", 0, 0);
    int totalRecords = ds.getTotalRecords();
    assertEquals(0, totalRecords);
    assertEquals(0, data.size());
    MockCriteria criteria = (MockCriteria) accessoryDao.createCriteria();
    assertFalse(criteria.wasListCalled());
  }

  public void testGetTotalRecords_ReturnsUnknownResultCount() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    Equipment equipment = new Equipment();
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    GenericDAO<Accessory, Long> accessoryDao = new MockDAO<Accessory, Long>(null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    int records = ds.getTotalRecords();
    assertEquals(DataSource.UNKNOWN_RECORD_COUNT, records);
  }

  public void testGetData_SortKeyIsAutoManualId_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(AccessoryConstants.ACCE_AUTO_MANUAL_ID, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("autoManua.value asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsAccessoryDesignatorId_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(AccessoryConstants.ACCE_DESGINATOR_ID, "desc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("acccessoryDesignato.typeCode desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsProofOfPosition_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(ElectricalConstants.PROOF_OF_POSITION_REQUIRED, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("electrica.proofOfPositionReq asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsSolenoidReq_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(ElectricalConstants.SOLENOID_REQUIRED, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("electrica.solenoidReq asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsLocal_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(ElectricalConstants.LOCAL_PUSH_BUTTON_REQUIRED, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("electrica.localPushButtonReq asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsInputQty_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(ElectricalConstants.INPUT_QUANTITY, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("electrica.inputQty asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsInputId_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(ElectricalConstants.INPUT_ID, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("input.input asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsOutputId_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(ElectricalConstants.OUTPUT_ID, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("output.output asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsOutputQty_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(ElectricalConstants.OUTPUT_QUANTITY, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("electrica.outputQty asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsOtherMeasurementId_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(ElectricalConstants.OTHER_MEASUREMENT_ID, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("otherMeasurement.measurement asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsHmiDisplay_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(ElectricalConstants.HMI_DISPLAY, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("electrica.hmiDisplay asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsCommunications_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(ElectricalConstants.COMMUNICATIONS, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("electrica.communications asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsVoltage_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(ElectricalConstants.VOLTAGE, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("electrica.voltage asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsVendor_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(PurchasingConstants.VENDOR, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("purchasin.vendor asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsRtpNumber_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(PurchasingConstants.RTP_NUMBER, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("purchasin.rtpNumber asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsPoNumber_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(PurchasingConstants.PO_NUMBER, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("purchasin.poNumber asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsLineNumber_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(PurchasingConstants.LINE_NUMBER, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("purchasin.lineNumber asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsDeliveryDate_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Accessory, Long> accessoryDao = new MockDAOWithTotalRecords<Accessory, Long>(
        null);
    BaseDisciplineDataSource ds = new AccessoryDataSource(helper, accessoryDao);
    ds.getData(PurchasingConstants.ACTUAL_DELIVERY_DATE, "asc", 1, 5);
    int records = ds.getTotalRecords();
    assertEquals(10, records);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) accessoryDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("purchasin.actualDeliveryDate asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }
}