/*
 InstrumentDataSource_AT was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.Projects_AT_TestCaseHelper;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.equipment.datasource.InstrumentDataSource;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: InstrumentDataSource_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-15 19:34:04 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class InstrumentDataSource_AT extends EISTestCase {
  public void testGetData_ReturnsList() throws Exception {
    Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, equipment.getId());
    InstrumentDataSource ds = new InstrumentDataSource(helper);
    List<? extends XmlObject> data = ds.getData("sequenceNumber", "asc", 0, 2);
    assertEquals(2, data.size());

    Projects project = equipment.getProjects();
    Projects_AT_TestCaseHelper.deleteTestProject(project.getId());
  }
}