/*
 InstrumentDataSource_UT was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.equipment.datasource.mock.MockDAOWithTotalRecords;
import com.monsanto.eas.eis.projects.domain.Instrument;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.InstrumentConstants;
import com.monsanto.eas.eis.util.MotorConstants;
import com.monsanto.eas.eis.util.PurchasingConstants;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: InstrumentDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-02-13 15:36:16 $
 *
 * @author sspati1
 * @version $Revision: 1.11 $
 */
public class InstrumentDataSource_UT extends TestCase {

  public void testCreate() throws Exception {
    InstrumentDataSource ds = new InstrumentDataSource((UCCHelper) null, (GenericDAO<Instrument, Long>) null);
    assertNotNull(ds);
  }

  public void testGetData_EquipmentNotInSessionEquipmentIdIsEmpty_EmptyListIsReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "");
    GenericDAO<Instrument, Long> instrumentDao = new MockDAOWithTotalRecords<Instrument, Long>(null);
    BaseDisciplineDataSource ds = new InstrumentDataSource(helper, instrumentDao);
    List<? extends XmlObject> data = ds.getData(MotorConstants.STARTER_ID, "desc", 0, 6);
    assertEquals(0, data.size());
    int totalRecords = ds.getTotalRecords();
    assertEquals(0, totalRecords);
    MockCriteria criteria = (MockCriteria) instrumentDao.createCriteria();
    assertFalse(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsSequenceNum_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Instrument, Long> instrumentDao = new MockDAOWithTotalRecords<Instrument, Long>(null);
    BaseDisciplineDataSource ds = new InstrumentDataSource(helper, instrumentDao);
    ds.getData("sequenceNumber", "asc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) instrumentDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("sequenceNumber asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsDescription_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Instrument, Long> instrumentDao = new MockDAOWithTotalRecords<Instrument, Long>(null);
    BaseDisciplineDataSource ds = new InstrumentDataSource(helper, instrumentDao);
    ds.getData("description", "desc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) instrumentDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("description desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsDesignatorFirstChar_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Instrument, Long> instrumentDao = new MockDAOWithTotalRecords<Instrument, Long>(null);
    BaseDisciplineDataSource ds = new InstrumentDataSource(helper, instrumentDao);
    ds.getData(InstrumentConstants.DESIGNATOR_FIRST_CHAR_ID, "desc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) instrumentDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("designatorFirstCha.typeCode desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsDesignatorSecondChar_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Instrument, Long> instrumentDao = new MockDAOWithTotalRecords<Instrument, Long>(null);
    BaseDisciplineDataSource ds = new InstrumentDataSource(helper, instrumentDao);
    ds.getData(InstrumentConstants.DESIGNATOR_SECOND_CHAR_ID, "desc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) instrumentDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("designatorSecondCha.typeCode desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsIoType_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Instrument, Long> instrumentDao = new MockDAOWithTotalRecords<Instrument, Long>(null);
    BaseDisciplineDataSource ds = new InstrumentDataSource(helper, instrumentDao);
    ds.getData(InstrumentConstants.IO_TYPE_ID, "desc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) instrumentDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("ioTyp.type desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsInstrumentType_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Instrument, Long> instrumentDao = new MockDAOWithTotalRecords<Instrument, Long>(null);
    BaseDisciplineDataSource ds = new InstrumentDataSource(helper, instrumentDao);
    ds.getData(InstrumentConstants.INST_TYPE_ID, "asc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) instrumentDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsVendor_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Instrument, Long> instrumentDao = new MockDAOWithTotalRecords<Instrument, Long>(null);
    BaseDisciplineDataSource ds = new InstrumentDataSource(helper, instrumentDao);
    ds.getData(PurchasingConstants.VENDOR, "asc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) instrumentDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("purchasin.vendor asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsRtpNumber_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Instrument, Long> instrumentDao = new MockDAOWithTotalRecords<Instrument, Long>(null);
    BaseDisciplineDataSource ds = new InstrumentDataSource(helper, instrumentDao);
    ds.getData(PurchasingConstants.RTP_NUMBER, "asc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) instrumentDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("purchasin.rtpNumber asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsPoNumber_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Instrument, Long> instrumentDao = new MockDAOWithTotalRecords<Instrument, Long>(null);
    BaseDisciplineDataSource ds = new InstrumentDataSource(helper, instrumentDao);
    ds.getData(PurchasingConstants.PO_NUMBER, "asc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) instrumentDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("purchasin.poNumber asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsLineNumber_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Instrument, Long> instrumentDao = new MockDAOWithTotalRecords<Instrument, Long>(null);
    BaseDisciplineDataSource ds = new InstrumentDataSource(helper, instrumentDao);
    ds.getData(PurchasingConstants.LINE_NUMBER, "asc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) instrumentDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("purchasin.lineNumber asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsDeliveryDate_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Instrument, Long> instrumentDao = new MockDAOWithTotalRecords<Instrument, Long>(null);
    BaseDisciplineDataSource ds = new InstrumentDataSource(helper, instrumentDao);
    ds.getData(PurchasingConstants.ACTUAL_DELIVERY_DATE, "asc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) instrumentDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("purchasin.actualDeliveryDate asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }
}