/*
 MotorDataSource_AT was created on Oct 20, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.eas.eis.equipment.service.EquipmentService;
import com.monsanto.eas.eis.equipment.service.EquipmentServiceImpl;
import com.monsanto.eas.eis.projects.Projects_AT_TestCaseHelper;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.services.ProjectsServiceImpl;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.domain.Process;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;

import java.util.List;
import java.util.ArrayList;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Order;
import org.hibernate.Criteria;

/**
 * Filename:    $RCSfile: MotorDataSource_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $ On:	$Date:
 * 2008/12/15 19:34:04 $
 *
 * @author sspati1
 * @version $Revision: 1.12 $
 */
public class MotorDataSource_AT extends EISTestCase {
  public void testGetData_ReturnsList() throws Exception {
    Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, equipment.getId());
    BaseDisciplineDataSource ds = new MotorDataSource(helper);
    List<? extends XmlObject> data = ds.getData("componentName", "desc", 0, 4);
    assertEquals(2, data.size());

    Projects project = equipment.getProjects();
    Projects_AT_TestCaseHelper.deleteTestProject(project.getId());
  }

  
//  public void testsdfsd() throws Exception {
//    com.monsanto.eas.eis.projects.domain.Process process1 = new Process();
//    List<ProcessFieldEquipmentType> list1 = new ArrayList<ProcessFieldEquipmentType>();
//    list1.add(new ProcessFieldEquipmentType(process1, new FieldEquipmentType(new FieldType(), "bellType", null, 0, null, null, null, 0), "bell 1"));
//    list1.add(new ProcessFieldEquipmentType(process1, new FieldEquipmentType(new FieldType(), "carType", null, 0, null, null, null, 0), "car 1"));
//    process1.setProcessFieldEquipmentTypes(list1);
//
//    Process process2 = new Process();
//    List<ProcessFieldEquipmentType> list2 = new ArrayList<ProcessFieldEquipmentType>();
//    list2.add(new ProcessFieldEquipmentType(process2, new FieldEquipmentType(new FieldType(), "bellType", null, 0, null, null, null, 0), "bell 2"));
//    list2.add(new ProcessFieldEquipmentType(process2, new FieldEquipmentType(new FieldType(), "carType", null, 0, null, null, null, 0), "car 2"));
//    process2.setProcessFieldEquipmentTypes(list2);
//
//    GenericDAO<ProcessFieldEquipmentType, Long> dao = new HibernateDAO<ProcessFieldEquipmentType, Long>(EISHibernateUtil.getHibernateFactory(), ProcessFieldEquipmentType.class);
//    Criteria criteria = dao.createCriteria();
//    criteria.createAlias("process", "pr");
//    criteria.createAlias("pr.equipment", "eq");
//    criteria.add(Restrictions.eq("eq.projects.id", new Long(377150)));
//    criteria.createAlias("fieldEquipmentType", "ft");
//    criteria.add(Restrictions.eq("ft.name", "bellType"));
//    criteria.addOrder(Order.asc("value"));
//    List<ProcessFieldEquipmentType> list = criteria.list();
//
//  }

//  public void testdfgfd() throws Exception {
//    ProjectsService service = new ProjectsServiceImpl();
//    Projects project = service.lookupProjectById(new Long(432550));
//    project.getEquipments();
//
//    EquipmentService eq = new EquipmentServiceImpl();
//    Equipment eqipment = eq.lookupEquipment(new Long("465250"));
//
//    MockUCCHelper helper = new MockUCCHelper(null);
//    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "465250");
//    BaseDisciplineDataSource ds = new MotorDataSource(helper);
//    List<? extends XmlObject> data = ds.getData("componentName", "desc", 0, 25);
//    assertEquals(25, data.size());
//
//  }
}