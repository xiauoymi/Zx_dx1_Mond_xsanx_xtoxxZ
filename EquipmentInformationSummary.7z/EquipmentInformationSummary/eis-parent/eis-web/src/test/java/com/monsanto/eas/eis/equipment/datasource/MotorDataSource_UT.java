/*
 MotorDataSource_UT was created on Oct 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.equipment.datasource.mock.MockDAOWithTotalRecords;
import com.monsanto.eas.eis.projects.domain.Motor;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.MotorConstants;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: MotorDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-13 15:36:16 $
 *
 * @author sspati1
 * @version $Revision: 1.10 $
 */
public class MotorDataSource_UT extends TestCase {

  public void testGetData_EquipmentNotInSessionIdIsEmpty_EmptyListIsReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "");
    GenericDAO<Motor, Long> motorDao = new MockDAOWithTotalRecords<Motor, Long>(null);
    BaseDisciplineDataSource ds = new MotorDataSource(helper, motorDao);
    List<? extends XmlObject> data = ds.getData(MotorConstants.STARTER_ID, "desc", 0, 0);
    assertEquals(0, data.size());
    int totalRecords = ds.getTotalRecords();
    assertEquals(0, totalRecords);
    MockCriteria criteria = (MockCriteria) motorDao.createCriteria();
    assertFalse(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsStarterId_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Motor, Long> motorDao = new MockDAOWithTotalRecords<Motor, Long>(null);
    BaseDisciplineDataSource ds = new MotorDataSource(helper, motorDao);
    ds.getData(MotorConstants.STARTER_ID, "desc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) motorDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("starte.starter desc", criteria.getOrderings().get(0).toString() );
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsDesignStatusId_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Motor, Long> motorDao = new MockDAOWithTotalRecords<Motor, Long>(null);

    BaseDisciplineDataSource ds = new MotorDataSource(helper, motorDao);
    ds.getData(MotorConstants.DESIGN_STATUS_ID, "asc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) motorDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("designStatu.status asc", criteria.getOrderings().get(0).toString() );
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsLoadValueTypeId_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Motor, Long> motorDao = new MockDAOWithTotalRecords<Motor, Long>(null);

    BaseDisciplineDataSource ds = new MotorDataSource(helper, motorDao);
    ds.getData(MotorConstants.LOAD_VALUE_TYPE_ID, "desc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) motorDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("loadValueTyp.type desc", criteria.getOrderings().get(0).toString() );
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsComponentDesignatorId_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Motor, Long> motorDao = new MockDAOWithTotalRecords<Motor, Long>(null);

    BaseDisciplineDataSource ds = new MotorDataSource(helper, motorDao);
    ds.getData(MotorConstants.COMPONENT_DESIGNATOR_ID, "desc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) motorDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("componentDesignato.typeCode desc", criteria.getOrderings().get(0).toString() );
    assertTrue(criteria.wasListCalled());
  }

  public void testGetData_SortKeyIsTest_VerifyCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "1");
    MockDAOWithTotalRecords<Motor, Long> motorDao = new MockDAOWithTotalRecords<Motor, Long>(null);

    BaseDisciplineDataSource ds = new MotorDataSource(helper, motorDao);
    ds.getData("test", "desc", 1, 5);
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) motorDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("e.id=1", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("test desc", criteria.getOrderings().get(0).toString() );
    assertTrue(criteria.wasListCalled());
  }
}