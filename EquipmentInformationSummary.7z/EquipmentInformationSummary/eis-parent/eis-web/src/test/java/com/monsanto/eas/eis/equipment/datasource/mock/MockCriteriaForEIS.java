/*
 MockCriteriaWithTotalRecords was created on Dec 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.mock;

import com.monsanto.wst.hibernate.mock.MockCriteria;
import org.hibernate.HibernateException;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockCriteriaForEIS.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-13 15:36:16 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public class MockCriteriaForEIS extends MockCriteria {
  private int firstResult;
  private int maxResult;
  private List<String> fetchModes = new ArrayList<String>();
  private Object uniqueResult;
  private List list;

  public MockCriteriaForEIS(Object uniqueResult, List list) {
    this.uniqueResult = uniqueResult;
    this.list = list;
  }

  public Object uniqueResult() throws HibernateException {
    return this.uniqueResult;
  }

  public Criteria setFirstResult(int i) {
    this.firstResult = i;
    return super.setFirstResult(i);
  }

  public Criteria setMaxResults(int i) {
    this.maxResult = i;
    return super.setMaxResults(i);
  }

  public int getFirstResult() {
    return firstResult;
  }

  public int getMaxResult() {
    return maxResult;
  }

  public Criteria setFetchMode(String s, FetchMode fetchMode) throws HibernateException {
    this.fetchModes.add(s + "-" + fetchMode);
    return super.setFetchMode(s, fetchMode);
  }

  public List<String> getFetchModes() {
    return fetchModes;
  }

  public List list() throws HibernateException {
    if(list == null){
      return super.list();      
    }else{
      return list;
    }
  }
}