/*
 MockDAOWithTotalRecords was created on Dec 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.mock;

import com.monsanto.wst.hibernate.mock.MockDAO;
import org.hibernate.Criteria;

import java.util.List;

/**
 * Filename:    $RCSfile: MockDAOWithTotalRecords.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-13 15:36:16 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class MockDAOWithTotalRecords<T, T1> extends MockDAO<T, Long> {
  MockCriteriaForEIS criteria = null;
  private List<T> list;

  public MockDAOWithTotalRecords(List<T> list) {
    super(list);
    this.list = list;
  }

  public Criteria createCriteria() {
    criteria = new MockCriteriaForEIS(new Integer(10), list);
    return this.criteria;
  }

  public MockCriteriaForEIS getMockCriteria() {
    return criteria;
  }
}
