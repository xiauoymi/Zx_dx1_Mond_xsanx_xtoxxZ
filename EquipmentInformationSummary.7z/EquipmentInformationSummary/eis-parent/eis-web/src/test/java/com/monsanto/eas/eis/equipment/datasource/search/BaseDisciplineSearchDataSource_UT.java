/*
 EquipmentSearchDataSource_UT was created on Oct 31, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.projects.domain.Electrical;
import com.monsanto.eas.eis.projects.mocks.MockDisciplineSearchDAO;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EquipmentConstants;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: BaseDisciplineSearchDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * sspati1 $    	 On:	$Date: 2008-12-23 20:43:34 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class BaseDisciplineSearchDataSource_UT extends TestCase {
  public void testGetData_PassRequestParameters_DaoMethodCalledWithCorrectParameters() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null, Electrical.class);
    BaseDisciplineSearchDataSource ds = new ElectricalSearchDataSource(helper, equipmentSearchDAO);
    ds.getData("testSortKey", "testSortDir", 1, 5);
    assertEquals(10, ds.getTotalRecords());
    assertEquals(1, equipmentSearchDAO.getStartIndex());
    assertEquals(5, equipmentSearchDAO.getmaxResults());
    assertTrue(equipmentSearchDAO.wasFindBySearchCriteriaCalled());
    assertEquals("1", equipmentSearchDAO.getProjectId());
    assertEquals("1", equipmentSearchDAO.getEquipmentType());
    assertEquals("2", equipmentSearchDAO.getAreaId());
    assertEquals("3", equipmentSearchDAO.getProcessLineNum());
    assertEquals("4", equipmentSearchDAO.getEquipmentNumber());
    assertEquals("5", equipmentSearchDAO.getEquipmentName());
    assertEquals("6", equipmentSearchDAO.getVendor());
    assertEquals("testSortKey", equipmentSearchDAO.getSortKey());
    assertEquals("testSortDir", equipmentSearchDAO.getSortDir());
  }

  public void testGetData_MaxResultsIsGreaterThanTotalRecords() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null, Electrical.class);
    BaseDisciplineSearchDataSource ds = new ElectricalSearchDataSource(helper, equipmentSearchDAO);
    ds.getData("testSortKey", "testSortDir", 1, 5);
    assertEquals(10, ds.getTotalRecords());
    assertEquals(1, equipmentSearchDAO.getStartIndex());
    assertEquals(5, equipmentSearchDAO.getmaxResults());
    assertTrue(equipmentSearchDAO.wasFindBySearchCriteriaCalled());
    assertEquals("1", equipmentSearchDAO.getProjectId());
    assertEquals("1", equipmentSearchDAO.getEquipmentType());
    assertEquals("2", equipmentSearchDAO.getAreaId());
    assertEquals("3", equipmentSearchDAO.getProcessLineNum());
    assertEquals("4", equipmentSearchDAO.getEquipmentNumber());
    assertEquals("5", equipmentSearchDAO.getEquipmentName());
    assertEquals("6", equipmentSearchDAO.getVendor());
    assertEquals("testSortKey", equipmentSearchDAO.getSortKey());
    assertEquals("testSortDir", equipmentSearchDAO.getSortDir());
  }

  public void testGetTotalRecords_WhenCalledBeforeGetDataReturnUnknownRecordCount() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null, Electrical.class);
    BaseDisciplineSearchDataSource ds = new ElectricalSearchDataSource(helper, equipmentSearchDAO);
    assertEquals(DataSource.UNKNOWN_RECORD_COUNT, ds.getTotalRecords());
  }
}