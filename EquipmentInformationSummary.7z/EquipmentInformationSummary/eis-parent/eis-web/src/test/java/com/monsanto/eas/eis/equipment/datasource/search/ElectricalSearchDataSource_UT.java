/*
 ElectricalSearchDataSource_Ut was created on Oct 31, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.equipment.datasource.mock.MockDAOWithTotalRecords;
import com.monsanto.eas.eis.projects.domain.Electrical;
import com.monsanto.eas.eis.projects.domain.ElectricalInputQuantity;
import com.monsanto.eas.eis.projects.domain.ElectricalOutputQuantity;
import com.monsanto.eas.eis.projects.domain.ElectricalInputOutput;
import com.monsanto.eas.eis.projects.mocks.MockDisciplineSearchDAO;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EquipmentConstants;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.mock.MockDAO;
import junit.framework.TestCase;
import org.hibernate.Criteria;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: ElectricalSearchDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-02-13 15:36:16 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public class ElectricalSearchDataSource_UT extends TestCase {
  public void testGetData_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null, Electrical.class);
    BaseDisciplineSearchDataSource ds = new ElectricalSearchDataSource(helper, equipmentSearchDAO);
    ds.getData("testSortKey", "testSortDir", 1, 5);
    assertEquals(10, ds.getTotalRecords());
    assertEquals(1, equipmentSearchDAO.getStartIndex());
    assertEquals(5, equipmentSearchDAO.getmaxResults());
    assertTrue(equipmentSearchDAO.wasFindBySearchCriteriaCalled());
    assertEquals("1", equipmentSearchDAO.getProjectId());
    assertEquals("1", equipmentSearchDAO.getEquipmentType());
    assertEquals("2", equipmentSearchDAO.getAreaId());
    assertEquals("3", equipmentSearchDAO.getProcessLineNum());
    assertEquals("4", equipmentSearchDAO.getEquipmentNumber());
    assertEquals("5", equipmentSearchDAO.getEquipmentName());
    assertEquals("6", equipmentSearchDAO.getVendor());
    assertEquals("testSortKey", equipmentSearchDAO.getSortKey());
    assertEquals("testSortDir", equipmentSearchDAO.getSortDir());
  }

  public void testGetData_SortByOtherMeasurement_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null, Electrical.class);
    BaseDisciplineSearchDataSource ds = new ElectricalSearchDataSource(helper, equipmentSearchDAO);
    ds.getData("otherMeasurementId", "asc", 1, 5);
    assertEquals(10, ds.getTotalRecords());
    assertEquals(1, equipmentSearchDAO.getStartIndex());
    assertEquals(5, equipmentSearchDAO.getmaxResults());
    assertTrue(equipmentSearchDAO.wasFindBySearchCriteriaCalled());
    assertEquals("1", equipmentSearchDAO.getProjectId());
    assertEquals("1", equipmentSearchDAO.getEquipmentType());
    assertEquals("2", equipmentSearchDAO.getAreaId());
    assertEquals("3", equipmentSearchDAO.getProcessLineNum());
    assertEquals("4", equipmentSearchDAO.getEquipmentNumber());
    assertEquals("5", equipmentSearchDAO.getEquipmentName());
    assertEquals("6", equipmentSearchDAO.getVendor());
    assertEquals("otherMeasuremen.measurement", equipmentSearchDAO.getSortKey());
    assertEquals("asc", equipmentSearchDAO.getSortDir());
  }

  public void testGetData_SortByInputId_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null, Electrical.class);

    MockDAOWithTotalRecords<ElectricalInputQuantity, Long> inputQuantityDao = getElectricalInputDao();
    MockDAOWithTotalRecords<ElectricalOutputQuantity, Long> outputQuantityDao = getElectricalOutputDao();
    
    BaseDisciplineSearchDataSource ds = new ElectricalSearchDataSourceOverridesInputOutputDao(helper, inputQuantityDao, outputQuantityDao);
    List<? extends XmlObject> data = ds.getData("inputId123", "asc", 1, 5);
    assertEquals(2, data.size());
    assertEquals(new Long(1234), ((Electrical) data.get(0)).getId());
    assertEquals(new Long(2345), ((Electrical) data.get(1)).getId());
    assertEquals(10, ds.getTotalRecords());
    assertFalse(equipmentSearchDAO.wasFindBySearchCriteriaCalled());

    MockCriteriaForEIS criteria = inputQuantityDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(1, criteria.getOrderings().size());
    assertEquals("checked asc", criteria.getOrderings().get(0).toString());
    assertEquals(8, criteria.getCriteria().size());
    assertEquals("eq.projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("input.id=123", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("a.id=2", criteria.getCriteria().get(3).toString());
    assertEquals("pu.vendor like %6%", criteria.getCriteria().get(4).toString());
    assertEquals("eq.equipmentNumber like %4%", criteria.getCriteria().get(5).toString());
    assertEquals("eq.name like %5%", criteria.getCriteria().get(6).toString());
    assertEquals("eq.processLineNumber like %3%", criteria.getCriteria().get(7).toString());
  }

  public void testGetData_SortByInputQty_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null, Electrical.class);

    MockDAOWithTotalRecords<ElectricalInputQuantity, Long> inputQuantityDao = getElectricalInputDao();
    MockDAOWithTotalRecords<ElectricalOutputQuantity, Long> outputQuantityDao = getElectricalOutputDao();

    BaseDisciplineSearchDataSource ds = new ElectricalSearchDataSourceOverridesInputOutputDao(helper, inputQuantityDao, outputQuantityDao);
    List<? extends XmlObject> data = ds.getData("inputQty123", "desc", 1, 5);
    assertEquals(2, data.size());
    assertEquals(new Long(1234), ((Electrical) data.get(0)).getId());
    assertEquals(new Long(2345), ((Electrical) data.get(1)).getId());
    assertEquals(10, ds.getTotalRecords());
    assertFalse(equipmentSearchDAO.wasFindBySearchCriteriaCalled());

    MockCriteriaForEIS criteria = inputQuantityDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(1, criteria.getOrderings().size());
    assertEquals("inputQty desc", criteria.getOrderings().get(0).toString());
    assertEquals(8, criteria.getCriteria().size());
    assertEquals("eq.projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("input.id=123", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("a.id=2", criteria.getCriteria().get(3).toString());
    assertEquals("pu.vendor like %6%", criteria.getCriteria().get(4).toString());
    assertEquals("eq.equipmentNumber like %4%", criteria.getCriteria().get(5).toString());
    assertEquals("eq.name like %5%", criteria.getCriteria().get(6).toString());
    assertEquals("eq.processLineNumber like %3%", criteria.getCriteria().get(7).toString());
  }

  public void testGetData_SortByOutoutId_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null, Electrical.class);

    MockDAOWithTotalRecords<ElectricalInputQuantity, Long> inputQuantityDao = getElectricalInputDao();
    MockDAOWithTotalRecords<ElectricalOutputQuantity, Long> outputQuantityDao = getElectricalOutputDao();

    BaseDisciplineSearchDataSource ds = new ElectricalSearchDataSourceOverridesInputOutputDao(helper, inputQuantityDao, outputQuantityDao);
    List<? extends XmlObject> data = ds.getData("outputId123", "desc", 1, 5);
    assertEquals(2, data.size());
    assertEquals(new Long(3456), ((Electrical) data.get(0)).getId());
    assertEquals(new Long(4567), ((Electrical) data.get(1)).getId());
    assertEquals(10, ds.getTotalRecords());
    assertFalse(equipmentSearchDAO.wasFindBySearchCriteriaCalled());

    MockCriteriaForEIS criteria = outputQuantityDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(1, criteria.getOrderings().size());
    assertEquals("checked desc", criteria.getOrderings().get(0).toString());
    assertEquals(8, criteria.getCriteria().size());
    assertEquals("eq.projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("output.id=123", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("a.id=2", criteria.getCriteria().get(3).toString());
    assertEquals("pu.vendor like %6%", criteria.getCriteria().get(4).toString());
    assertEquals("eq.equipmentNumber like %4%", criteria.getCriteria().get(5).toString());
    assertEquals("eq.name like %5%", criteria.getCriteria().get(6).toString());
    assertEquals("eq.processLineNumber like %3%", criteria.getCriteria().get(7).toString());
  }

  public void testGetData_SortByOutoutQty_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null, Electrical.class);

    MockDAOWithTotalRecords<ElectricalInputQuantity, Long> inputQuantityDao = getElectricalInputDao();
    MockDAOWithTotalRecords<ElectricalOutputQuantity, Long> outputQuantityDao = getElectricalOutputDao();

    BaseDisciplineSearchDataSource ds = new ElectricalSearchDataSourceOverridesInputOutputDao(helper, inputQuantityDao, outputQuantityDao);
    List<? extends XmlObject> data = ds.getData("outputQty123", "desc", 1, 5);
    assertEquals(2, data.size());
    assertEquals(new Long(3456), ((Electrical) data.get(0)).getId());
    assertEquals(new Long(4567), ((Electrical) data.get(1)).getId());
    assertEquals(10, ds.getTotalRecords());
    assertFalse(equipmentSearchDAO.wasFindBySearchCriteriaCalled());

    MockCriteriaForEIS criteria = outputQuantityDao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(1, criteria.getOrderings().size());
    assertEquals("outputQty desc", criteria.getOrderings().get(0).toString());
    assertEquals(8, criteria.getCriteria().size());
    assertEquals("eq.projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("output.id=123", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("a.id=2", criteria.getCriteria().get(3).toString());
    assertEquals("pu.vendor like %6%", criteria.getCriteria().get(4).toString());
    assertEquals("eq.equipmentNumber like %4%", criteria.getCriteria().get(5).toString());
    assertEquals("eq.name like %5%", criteria.getCriteria().get(6).toString());
    assertEquals("eq.processLineNumber like %3%", criteria.getCriteria().get(7).toString());
  }

  private MockDAOWithTotalRecords<ElectricalOutputQuantity, Long> getElectricalOutputDao() {
    Electrical electrical;
    List<ElectricalOutputQuantity> outputs = new ArrayList<ElectricalOutputQuantity>();
    electrical = new Electrical();
    electrical.setId(new Long(3456));
    outputs.add(new ElectricalOutputQuantity(null, null, null, electrical, false));
    electrical = new Electrical();
    electrical.setId(new Long(4567));
    outputs.add(new ElectricalOutputQuantity(null, null, null, electrical, false));
    MockDAOWithTotalRecords<ElectricalOutputQuantity, Long> outputQuantityDao = new MockDAOWithTotalRecords<ElectricalOutputQuantity, Long>(outputs);
    return outputQuantityDao;
  }

  private MockDAOWithTotalRecords<ElectricalInputQuantity, Long> getElectricalInputDao() {
    List<ElectricalInputQuantity> inputs = new ArrayList<ElectricalInputQuantity>();
    Electrical electrical = new Electrical();
    electrical.setId(new Long(1234));
    inputs.add(new ElectricalInputQuantity(null, null, null, electrical, false));
    electrical = new Electrical();
    electrical.setId(new Long(2345));
    inputs.add(new ElectricalInputQuantity(null, null, null, electrical, false));
    MockDAOWithTotalRecords<ElectricalInputQuantity, Long> inputQuantityDao = new MockDAOWithTotalRecords<ElectricalInputQuantity, Long>(inputs);
    return inputQuantityDao;
  }

  private class ElectricalSearchDataSourceOverridesInputOutputDao extends ElectricalSearchDataSource {
    MockDAOWithTotalRecords<ElectricalInputQuantity, Long> inputQuantityDao;
    MockDAOWithTotalRecords<ElectricalOutputQuantity, Long> outputQuantityDao;

    public ElectricalSearchDataSourceOverridesInputOutputDao(UCCHelper helper,
                                                            MockDAOWithTotalRecords<ElectricalInputQuantity, Long> inputQuantityDao,
                                                            MockDAOWithTotalRecords<ElectricalOutputQuantity, Long> outputQuantityDao ) {
      this(helper);
      this.inputQuantityDao = inputQuantityDao;
      this.outputQuantityDao = outputQuantityDao;
    }

    public ElectricalSearchDataSourceOverridesInputOutputDao(UCCHelper helper) {
      super(helper);
    }

    //protected for testing only
    protected GenericDAO<ElectricalInputQuantity, Long> getElectricalInputQuantityDao() {
      return inputQuantityDao;
    }

    // /protected for testing only
    protected GenericDAO<ElectricalOutputQuantity, Long> getElectricalOutputQuantityDao() {
      return outputQuantityDao;
    }
  }
}