/*
 EquipmentDataSource_UT was created on Oct 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.controller.DataSource;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.mocks.MockEquipmentDAO;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EquipmentConstants;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: EquipmentSearchDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $
 * On:	$Date: 2008-12-27 05:11:36 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class EquipmentSearchDataSource_UT extends TestCase {

  public void testGetTotalRecords_CalledBeforeGetData_ReturnUnknownRecordCount() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    EquipmentSearchDataSource ds = new EquipmentSearchDataSource(helper, equipmentDAO);
    assertEquals(DataSource.UNKNOWN_RECORD_COUNT, ds.getTotalRecords());
  }

  public void testGetData_removeFromSessionNotSet_EquipmentNotRemovedFromSession() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "3");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "6");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, "4");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 2 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 7 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 7 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EXISTING_EQUIPMENT_NUMBER, " 8 ");
    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    EquipmentSearchDataSource ds = new EquipmentSearchDataSource(helper, equipmentDAO);
    ds.getData("testSortKey", "testSortDir", 1, 5);
    assertFalse(equipmentDAO.isHibernateSessionCleared());
  }

  public void testGetData_PassRequestParameters_DaoMethodCalledWithCorrectParameters() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EXISTING_EQUIPMENT_NUMBER, " 8 ");
    MockEquipmentDAO equipmentDAO = new MockEquipmentDAO(new Integer(10));
    EquipmentSearchDataSource ds = new EquipmentSearchDataSource(helper, equipmentDAO);
    ds.getData("testSortKey", "testSortDir", 1, 5);
    assertEquals(10, ds.getTotalRecords());
    MockCriteriaForEIS mockCriteria = (MockCriteriaForEIS) equipmentDAO.getMockCriteria();
    assertEquals(1, mockCriteria.getFirstResult());
    assertEquals(5, mockCriteria.getMaxResult());
    assertTrue(equipmentDAO.wasFindBySearchCriteriaCalled());
    assertEquals("1", equipmentDAO.getProjectId());
    assertEquals("1", equipmentDAO.getEquipmentType());
    assertEquals("2", equipmentDAO.getAreaId());
    assertEquals("3", equipmentDAO.getProcessLineNum());
    assertEquals("4", equipmentDAO.getEquipmentNumber());
    assertEquals("5", equipmentDAO.getEquipmentName());
    assertEquals("6", equipmentDAO.getVendor());
    assertEquals("8", equipmentDAO.getExistingEquipmentNumber());
    assertEquals("testSortKey", equipmentDAO.getSortKey());
    assertEquals("testSortDir", equipmentDAO.getSortDir());
  }
}