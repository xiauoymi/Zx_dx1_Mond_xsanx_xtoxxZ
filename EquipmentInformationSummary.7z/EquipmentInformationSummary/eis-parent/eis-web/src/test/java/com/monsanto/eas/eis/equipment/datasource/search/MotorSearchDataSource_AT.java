/*
 MotorSearchDataSource_AT was created on Oct 31, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.eas.eis.projects.Projects_AT_TestCaseHelper;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.services.ProjectsServiceImpl;
import com.monsanto.eas.eis.projects.services.UserService;
import com.monsanto.eas.eis.projects.services.UserServiceImpl;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EquipmentConstants;
import com.monsanto.eas.eis.logon.hibernateMappings.User;

import java.util.List;

/**
 * Filename:    $RCSfile: MotorSearchDataSource_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-02-13 15:36:16 $
 *
 * @author sspati1
 * @version $Revision: 1.12 $
 */
public class MotorSearchDataSource_AT extends EISTestCase {

  public void testGetData() throws Exception {
    Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, equipment.getProjects().getId());
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, equipment.getEquipmentType().getId());
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, equipment.getArea().getId());
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, equipment.getProcessLineNumber());
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, equipment.getEquipmentNumber());
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, equipment.getName());
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, equipment.getPurchasing().getVendor());
    BaseDisciplineSearchDataSource ds = new MotorSearchDataSource(helper);
    List<Motor> data = (List<Motor>) ds.getData("equipmentVendor", "desc", 0, 2);
    assertEquals(2, data.size());
  }
}