/*
 ProcessSearchDataSource_UT was created on Nov 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAO;
import com.monsanto.eas.eis.projects.domain.FieldEquipmentType;
import com.monsanto.eas.eis.projects.domain.Process;
import com.monsanto.eas.eis.projects.domain.ProcessFieldEquipmentType;
import com.monsanto.eas.eis.projects.mocks.MockDisciplineSearchDAO;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EquipmentConstants;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.hibernate.mock.MockDAO;
import junit.framework.TestCase;
import org.hibernate.Criteria;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: ProcessSearchDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-02-11 15:18:07 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class ProcessSearchDataSource_UT extends TestCase {

  public void testGetData_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null,
        com.monsanto.eas.eis.projects.domain.Process.class);
    BaseDisciplineSearchDataSource ds = new ProcessSearchDataSourceOverridesFetDao(helper, equipmentSearchDAO);
    ds.getData("testSortKey", "testSortDir", 1, 5);
    assertEquals(1, equipmentSearchDAO.getStartIndex());
    assertEquals(5, equipmentSearchDAO.getmaxResults());
    assertTrue(equipmentSearchDAO.wasFindBySearchCriteriaCalled());
    assertEquals("1", equipmentSearchDAO.getProjectId());
    assertEquals("1", equipmentSearchDAO.getEquipmentType());
    assertEquals("2", equipmentSearchDAO.getAreaId());
    assertEquals("3", equipmentSearchDAO.getProcessLineNum());
    assertEquals("4", equipmentSearchDAO.getEquipmentNumber());
    assertEquals("5", equipmentSearchDAO.getEquipmentName());
    assertEquals("6", equipmentSearchDAO.getVendor());
    assertEquals("testSortKey", equipmentSearchDAO.getSortKey());
    assertEquals("testSortDir", equipmentSearchDAO.getSortDir());
  }

  public void testGetData_SortByGasTypeId_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null,
        com.monsanto.eas.eis.projects.domain.Process.class);
    BaseDisciplineSearchDataSource ds = new ProcessSearchDataSourceOverridesFetDao(helper, equipmentSearchDAO);
    ds.getData("gasTypeId", "desc", 1, 5);
    assertEquals(1, equipmentSearchDAO.getStartIndex());
    assertEquals(5, equipmentSearchDAO.getmaxResults());
    assertTrue(equipmentSearchDAO.wasFindBySearchCriteriaCalled());
    assertEquals("1", equipmentSearchDAO.getProjectId());
    assertEquals("1", equipmentSearchDAO.getEquipmentType());
    assertEquals("2", equipmentSearchDAO.getAreaId());
    assertEquals("3", equipmentSearchDAO.getProcessLineNum());
    assertEquals("4", equipmentSearchDAO.getEquipmentNumber());
    assertEquals("5", equipmentSearchDAO.getEquipmentName());
    assertEquals("6", equipmentSearchDAO.getVendor());
    assertEquals("gasTyp.type", equipmentSearchDAO.getSortKey());
    assertEquals("desc", equipmentSearchDAO.getSortDir());
  }

  public void testGetData_SortByWaterTypeId_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null,
        com.monsanto.eas.eis.projects.domain.Process.class);
    BaseDisciplineSearchDataSource ds = new ProcessSearchDataSourceOverridesFetDao(helper, equipmentSearchDAO);
    ds.getData("waterTypeId", "desc", 1, 5);
    assertEquals(1, equipmentSearchDAO.getStartIndex());
    assertEquals(5, equipmentSearchDAO.getmaxResults());
    assertTrue(equipmentSearchDAO.wasFindBySearchCriteriaCalled());
    assertEquals("1", equipmentSearchDAO.getProjectId());
    assertEquals("1", equipmentSearchDAO.getEquipmentType());
    assertEquals("2", equipmentSearchDAO.getAreaId());
    assertEquals("3", equipmentSearchDAO.getProcessLineNum());
    assertEquals("4", equipmentSearchDAO.getEquipmentNumber());
    assertEquals("5", equipmentSearchDAO.getEquipmentName());
    assertEquals("6", equipmentSearchDAO.getVendor());
    assertEquals("waterTyp.type", equipmentSearchDAO.getSortKey());
    assertEquals("desc", equipmentSearchDAO.getSortDir());
  }

  public void testGetData_SortByDustTypeId_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null,
        com.monsanto.eas.eis.projects.domain.Process.class);
    BaseDisciplineSearchDataSource ds = new ProcessSearchDataSourceOverridesFetDao(helper, equipmentSearchDAO);
    ds.getData("dustTypeId", "desc", 1, 5);
    assertEquals(1, equipmentSearchDAO.getStartIndex());
    assertEquals(5, equipmentSearchDAO.getmaxResults());
    assertTrue(equipmentSearchDAO.wasFindBySearchCriteriaCalled());
    assertEquals("1", equipmentSearchDAO.getProjectId());
    assertEquals("1", equipmentSearchDAO.getEquipmentType());
    assertEquals("2", equipmentSearchDAO.getAreaId());
    assertEquals("3", equipmentSearchDAO.getProcessLineNum());
    assertEquals("4", equipmentSearchDAO.getEquipmentNumber());
    assertEquals("5", equipmentSearchDAO.getEquipmentName());
    assertEquals("6", equipmentSearchDAO.getVendor());
    assertEquals("dustTyp.type", equipmentSearchDAO.getSortKey());
    assertEquals("desc", equipmentSearchDAO.getSortDir());
  }

  public void testGetData_SortByDesignCapacityUnitId_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null,
        com.monsanto.eas.eis.projects.domain.Process.class);
    BaseDisciplineSearchDataSource ds = new ProcessSearchDataSourceOverridesFetDao(helper, equipmentSearchDAO);
    ds.getData("designCapacityUnitId", "desc", 1, 5);
    assertEquals(1, equipmentSearchDAO.getStartIndex());
    assertEquals(5, equipmentSearchDAO.getmaxResults());
    assertTrue(equipmentSearchDAO.wasFindBySearchCriteriaCalled());
    assertEquals("1", equipmentSearchDAO.getProjectId());
    assertEquals("1", equipmentSearchDAO.getEquipmentType());
    assertEquals("2", equipmentSearchDAO.getAreaId());
    assertEquals("3", equipmentSearchDAO.getProcessLineNum());
    assertEquals("4", equipmentSearchDAO.getEquipmentNumber());
    assertEquals("5", equipmentSearchDAO.getEquipmentName());
    assertEquals("6", equipmentSearchDAO.getVendor());
    assertEquals("designCapacityUni.unitName", equipmentSearchDAO.getSortKey());
    assertEquals("desc", equipmentSearchDAO.getSortDir());
  }

  public void testGetData_DynamicField_VerifyProcesList() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 11 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 777 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " Name1 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " test vendor ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null,
        com.monsanto.eas.eis.projects.domain.Process.class);
    ProcessSearchDataSourceReturnsFieldEquipmentType ds = new ProcessSearchDataSourceReturnsFieldEquipmentType(helper, equipmentSearchDAO);
    List<? extends XmlObject> data = ds.getData("bellType", "desc", 1, 5);
    assertEquals(3, data.size());
    assertEquals(new Long(1234), ((com.monsanto.eas.eis.projects.domain.Process) data.get(0)).getId());
    MockPfeDAO<ProcessFieldEquipmentType, Long> pfeDao = ds.getPfeDao();
    MockCriteriaForEIS criteria = pfeDao.getCriteria();

    assertEquals(10, ds.getTotalRecords());
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());

    assertEquals(1, criteria.getOrderings().size());
    assertEquals("value desc", criteria.getOrderings().get(0).toString());
    assertEquals(8, criteria.getCriteria().size());
    assertEquals("eq.projects.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("ft.name=bellType", criteria.getCriteria().get(1).toString());
    assertEquals("et.id=1", criteria.getCriteria().get(2).toString());
    assertEquals("a.id=2", criteria.getCriteria().get(3).toString());
    assertEquals("pu.vendor like %test vendor%", criteria.getCriteria().get(4).toString());
    assertEquals("eq.equipmentNumber like %777%", criteria.getCriteria().get(5).toString());
    assertEquals("eq.name like %Name1%", criteria.getCriteria().get(6).toString());
    assertEquals("eq.processLineNumber like %11%", criteria.getCriteria().get(7).toString());
  }

  private class ProcessSearchDataSourceReturnsFieldEquipmentType extends ProcessSearchDataSource {
    MockPfeDAO<ProcessFieldEquipmentType, Long> pfeDao;

    public ProcessSearchDataSourceReturnsFieldEquipmentType(UCCHelper helper,
                                               DisciplineSearchDAO<Process, Long> disciplineSearchDAO) {
      super(helper, disciplineSearchDAO);
    }

    //protected for testing
    protected GenericDAO<ProcessFieldEquipmentType, Long> getProcessFieldEquipmentTypeDao() {
      pfeDao = new MockPfeDAO<ProcessFieldEquipmentType, Long>();
      return pfeDao;
    }

    public MockPfeDAO<ProcessFieldEquipmentType, Long> getPfeDao() {
      return pfeDao;
    }//protected for testing

    protected GenericDAO<FieldEquipmentType, Long> getFieldEquipmentTypeDao() {
      return new MockFetDAO<FieldEquipmentType, Long>(null, null);
    }
  }

  private class MockFetDAO<T, T1> extends HibernateDAO<FieldEquipmentType, Long> {

    public MockFetDAO(HibernateFactory hibernate, Class<? extends FieldEquipmentType> persistentClass) {
      super(hibernate, persistentClass);
    }

    public Criteria createCriteria() {
      return new MockCriteriaForEIS(new FieldEquipmentType(), null);
    }
  }

  private class MockPfeDAO<T, T1> extends MockDAO<ProcessFieldEquipmentType, Long> {
    MockCriteriaForEIS criteria;

    public Criteria createCriteria() {
      criteria = new MockCriteriaForEIS(10, null);
      List<ProcessFieldEquipmentType> pfes = new ArrayList<ProcessFieldEquipmentType>();
      Process process = new Process();
      process.setId(new Long(1234));
      pfes.add(new ProcessFieldEquipmentType(new Long(1111), process, null, null));
      pfes.add(new ProcessFieldEquipmentType(new Long(2222), process, null, null));
      pfes.add(new ProcessFieldEquipmentType(new Long(3333), process, null, null));
      criteria.setResults(pfes);
      return criteria;
    }

    public MockCriteriaForEIS getCriteria() {
      return criteria;
    }
  }

  private class ProcessSearchDataSourceOverridesFetDao extends ProcessSearchDataSource {
    public ProcessSearchDataSourceOverridesFetDao(
        UCCHelper helper, DisciplineSearchDAO disciplineSearchDAO) {
      super(helper, disciplineSearchDAO);
    }

    //protected for testing
    protected GenericDAO<FieldEquipmentType, Long> getFieldEquipmentTypeDao() {
      return new MockDAO<FieldEquipmentType, Long>();
    }
  }
}