/*
 PurchasingSearchDataSource_UT was created on Dec 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.datasource.search;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.projects.domain.Purchasing;
import com.monsanto.eas.eis.projects.mocks.MockDisciplineSearchDAO;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.util.EquipmentConstants;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: PurchasingSearchDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-15 14:28:34 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class PurchasingSearchDataSource_UT extends TestCase {
 public void testGetData_VerifySearchCriteria() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_TYPE, "1");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_AREA, "2");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_PROCESS_LINE, " 3 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NUMBER, " 4 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_EQUIPMENT_NAME, " 5 ");
    helper.setRequestParameterValue(EquipmentConstants.SEARCH_VENDOR, " 6 ");
    MockDisciplineSearchDAO equipmentSearchDAO = new MockDisciplineSearchDAO(null, Purchasing.class);
    BaseDisciplineSearchDataSource ds = new PurchasingSearchDataSource(helper, equipmentSearchDAO);
    ds.getData("testSortKey", "testSortDir", 1, 5);
   assertEquals(1, equipmentSearchDAO.getStartIndex());
   assertEquals(5, equipmentSearchDAO.getmaxResults());
    assertTrue(equipmentSearchDAO.wasFindBySearchCriteriaCalled());
    assertEquals("1", equipmentSearchDAO.getProjectId());
    assertEquals("1", equipmentSearchDAO.getEquipmentType());
    assertEquals("2", equipmentSearchDAO.getAreaId());
    assertEquals("3", equipmentSearchDAO.getProcessLineNum());
    assertEquals("4", equipmentSearchDAO.getEquipmentNumber());
    assertEquals("5", equipmentSearchDAO.getEquipmentName());
    assertEquals("6", equipmentSearchDAO.getVendor());
    assertEquals("testSortKey", equipmentSearchDAO.getSortKey());
    assertEquals("testSortDir", equipmentSearchDAO.getSortDir());
  }
}