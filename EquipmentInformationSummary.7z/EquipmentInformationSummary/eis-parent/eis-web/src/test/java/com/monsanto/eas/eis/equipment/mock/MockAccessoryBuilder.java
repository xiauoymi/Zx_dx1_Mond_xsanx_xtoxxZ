/*
 MockAccessoryBuilder was created on Nov 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.mock;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.equipment.AccessoryBuilder;
import com.monsanto.eas.eis.projects.domain.Accessory;
import com.monsanto.eas.eis.projects.domain.Equipment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

/**
 * Filename:    $RCSfile: MockAccessoryBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-22 14:17:42 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class MockAccessoryBuilder extends AccessoryBuilder {
  private List<String> errorListForRequiredFields;

  public MockAccessoryBuilder(List<String> errorListForRequiredFields) {
    this.errorListForRequiredFields = errorListForRequiredFields;
  }

  public Set<Accessory> createAccessoryListFromRequest(Equipment equipment, UCCHelper helper) throws IOException {
    Set<Accessory> list = new HashSet<Accessory>();
    Accessory inst = new Accessory();
    inst.setId(new Long(444));
    list.add(inst);
    return list;
  }

  public List<String> validateRequiredFields(UCCHelper helper) throws IOException {
    return errorListForRequiredFields;
  }
}