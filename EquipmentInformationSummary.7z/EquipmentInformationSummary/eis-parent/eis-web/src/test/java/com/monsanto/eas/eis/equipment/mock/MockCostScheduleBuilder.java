/*
 MockCostScheduleBuilder was created on Nov 10, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.mock;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.equipment.CostScheduleBuilder;
import com.monsanto.eas.eis.projects.domain.CostSchedule;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.FundingSource;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

/**
 * Filename:    $RCSfile: MockCostScheduleBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-15 19:33:50 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public class MockCostScheduleBuilder extends CostScheduleBuilder {
  public CostSchedule createCostScheduleFromRequest(Equipment equipment, UCCHelper helper) throws IOException {
    FundingSource source = new FundingSource(new Long(22));
    source.setSource("Lease");
    return new CostSchedule(new Long(123), getDate(1), getDate(2), getDate(3), new Integer(11),
        new Integer(12), getDate(4), getDate(5), getDate(6), getDate(7), getDate(8), getDate(9), getDate(10),
        getDate(11),
        new Long(13), "estimated source", source, new Integer(15), null);
  }

  private Date getDate(int numDaysToAdd) {
    Calendar cal = Calendar.getInstance();
    cal.set(Calendar.YEAR, 2008);
    cal.set(Calendar.MONTH, 8);
    cal.set(Calendar.DATE, 23);
    cal.add(Calendar.DATE, numDaysToAdd);
    return cal.getTime();
  }
}