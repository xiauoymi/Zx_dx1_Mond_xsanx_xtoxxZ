/*
 MockEquipmentBuilder was created on Dec 19, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.mock;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.equipment.EquipmentBuilder;
import com.monsanto.eas.eis.projects.domain.Equipment;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: MockEquipmentBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-22 14:17:42 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class MockEquipmentBuilder extends EquipmentBuilder {
  private List<String> errorList;
  private List<String> errorListForInvalidLength;
  private Equipment equipment;

  public MockEquipmentBuilder(List<String> errorListForRequiredFields, List<String> errorListForInvalidLength) {
    super(null);
    this.errorList = errorListForRequiredFields;
    this.errorListForInvalidLength = errorListForInvalidLength;
  }

  public Equipment createEquipmentFromParameters(UCCHelper helper) throws IOException {
    Equipment equipment = new Equipment();
    equipment.setId(new Long(456));
    this.equipment = equipment;
    return equipment;
  }

  public List<String> validate(Equipment equipment) throws IOException {
    return errorList;
  }

  public List<String> validateAllFieldsLength(Equipment equipment) throws IOException {
    return errorListForInvalidLength;
  }

  public Equipment getEquipment() {
    return equipment;
  }
}