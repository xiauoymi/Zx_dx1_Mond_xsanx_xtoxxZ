/*
 MockInstrumentBuilder was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.mock;

import com.monsanto.eas.eis.equipment.InstrumentBuilder;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Instrument;
import com.monsanto.ServletFramework.UCCHelper;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.io.IOException;

/**
 * Filename:    $RCSfile: MockInstrumentBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2008-12-27 05:11:35 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public class MockInstrumentBuilder extends InstrumentBuilder {
  private List<String> errorListForRequiredFields;

  public MockInstrumentBuilder(List<String> errorListForRequiredFields) {
    this.errorListForRequiredFields = errorListForRequiredFields;
  }

  public Set<Instrument> createIntrumentListFromRequest(Equipment equipment, UCCHelper helper) throws IOException {
    Set<Instrument> list = new HashSet<Instrument>();
    Instrument inst = new Instrument();
    inst.setId(new Long(333));
    list.add(inst);
    return list;
  }

  public List<String> validateRequiredFields(UCCHelper helper) throws IOException {
    return errorListForRequiredFields;
  }

}