/*
 MockMechanicalBuilder was created on Dec 19, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.mock;

import com.monsanto.eas.eis.equipment.MechanicalBuilder;
import com.monsanto.eas.eis.projects.domain.Mechanical;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * Filename:    $RCSfile: MockMechanicalBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-22 14:17:42 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class MockMechanicalBuilder extends MechanicalBuilder {
  public Mechanical createMechanicalFromRequest(Equipment equipment, UCCHelper helper) throws IOException {
    Mechanical mechanical = new Mechanical();
    mechanical.setId(new Long(666));
    return mechanical;
  }
}