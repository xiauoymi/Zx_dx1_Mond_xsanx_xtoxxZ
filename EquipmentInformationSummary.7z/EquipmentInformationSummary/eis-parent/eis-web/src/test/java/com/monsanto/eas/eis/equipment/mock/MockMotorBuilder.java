/*
 MockMotorBuilder was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.mock;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.equipment.MotorBuilder;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.Motor;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Filename:    $RCSfile: MockMotorBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2008-12-22 14:17:42 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class MockMotorBuilder extends MotorBuilder {
  private List<String> errorListForRequiredFields;

  public MockMotorBuilder(List<String> errorListForRequiredFields) {
    this.errorListForRequiredFields = errorListForRequiredFields;
  }

  public Set<Motor> createMotorListFromRequest(Equipment equipment, UCCHelper helper) throws IOException {
    Set<Motor> motors = new HashSet<Motor>();
    Motor motor = new Motor();
    motor.setId(new Long(222));
    motors.add(motor);
    return motors;
  }

  public List<String> validateRequiredFields(UCCHelper helper) throws IOException {
    return errorListForRequiredFields;
  }
}