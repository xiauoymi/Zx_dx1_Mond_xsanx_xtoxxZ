/*
 AccessoryServiceImpl_UT was created on Nov 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.domain.AccessoryDesignator;
import com.monsanto.eas.eis.projects.domain.AutoManual;
import com.monsanto.wst.hibernate.mock.MockDAO;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: AccessoryServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2008-12-11 19:20:45 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class AccessoryServiceImpl_UT extends TestCase {
  public void testCreate() throws Exception {
    AccessoryService service = new AccessoryServiceImpl();
    assertNotNull(service);
  }

  public void testLookupAllAccessoryDesignators_ReturnsList() throws Exception {
    MockDAO<AccessoryDesignator, Long> designatorDao = new MockDAO<AccessoryDesignator, Long>(getDesignators());
    MockDAO<AutoManual, Long> autoDao = new MockDAO<AutoManual, Long>(getAutoManual());
    AccessoryService service = new AccessoryServiceImpl(designatorDao, autoDao);
    List<AccessoryDesignator> list = service.lookupAllAccessoryDesignators();
    assertEquals(2, list.size());
    assertEquals(new Long(11), list.get(0).getId());
    assertEquals("typeCode", designatorDao.getSortKey());
    assertTrue(designatorDao.getSortOrder());
  }

  public void testLookupAllAutoManuals_ReturnsList() throws Exception {
    MockDAO<AccessoryDesignator, Long> designatorDao = new MockDAO<AccessoryDesignator, Long>(getDesignators());
    MockDAO<AutoManual, Long> autoDao = new MockDAO<AutoManual, Long>(getAutoManual());
    AccessoryService service = new AccessoryServiceImpl(designatorDao, autoDao);
    List<AutoManual> list = service.lookupAllAutoManuals();
    assertEquals(2, list.size());
    assertEquals(new Long(22), list.get(0).getId());
    assertEquals("value", autoDao.getSortKey());
    assertTrue(autoDao.getSortOrder());
  }

  private List<AutoManual> getAutoManual() {
    List<AutoManual> list = new ArrayList<AutoManual>();
    AutoManual autoManual = new AutoManual(new Long(22));
    autoManual.setValue("AU");
    list.add(autoManual);
    autoManual = new AutoManual(new Long(23));
    autoManual.setValue("MA");
    list.add(autoManual);
    return list;
  }

  private List<AccessoryDesignator> getDesignators() {
    List<AccessoryDesignator> list = new ArrayList<AccessoryDesignator>();
    list.add(new AccessoryDesignator(new Long(11), "ADES 1", "AD1"));
    list.add(new AccessoryDesignator(new Long(12), "ADES 2", "AD2"));
    return list;
  }
}