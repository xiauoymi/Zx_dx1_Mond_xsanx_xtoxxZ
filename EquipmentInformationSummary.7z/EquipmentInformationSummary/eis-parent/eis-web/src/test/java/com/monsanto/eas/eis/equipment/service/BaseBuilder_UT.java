/*
 BaseBuilder_UT was created on Nov 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import junit.framework.TestCase;
import com.monsanto.eas.eis.equipment.BaseBuilder;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile: BaseBuilder_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-11-07 17:23:21 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class BaseBuilder_UT extends TestCase {

  public void testGetDouble_VerifyReturnValues() throws Exception {
    BaseBuilder builder = new BaseBuilder();
    assertNull(builder.getDouble(null));
    assertNull(builder.getDouble(" "));
    assertEquals(new Double(2), builder.getDouble("2"));
  }

  public void testGetInteger_VerifyReturnValues() throws Exception {
    BaseBuilder builder = new BaseBuilder();
    assertNull(builder.getInteger(null));
    assertNull(builder.getInteger(" "));
    assertEquals(new Integer(2), builder.getInteger("2"));
  }
  
  public void testGetLong_VerifyReturnValues() throws Exception {
    BaseBuilder builder = new BaseBuilder();
    assertNull(builder.getLong(null));
    assertNull(builder.getLong(" "));
    assertNull(builder.getLong("Please Select"));
    assertEquals(new Long(2), builder.getLong("2"));
  }

  public void testGetBool_VerifyReturnValues() throws Exception {
    BaseBuilder builder = new BaseBuilder();
    assertFalse(builder.getBool(null));
    assertFalse(builder.getBool(" "));
    assertFalse(builder.getBool("false"));
    assertTrue(builder.getBool("true"));
  }

  public void testIsCheckboxChecked_VerifyReturnValues() throws Exception {
    BaseBuilder builder = new BaseBuilder();
    assertFalse(builder.isCheckboxChecked(null));
    assertFalse(builder.isCheckboxChecked(" "));
    assertTrue(builder.isCheckboxChecked("on"));
    assertTrue(builder.isCheckboxChecked("ON"));
  }

  public void testIsRadioButtonChecked_VerifyReturnValues() throws Exception {
    BaseBuilder builder = new BaseBuilder();
    assertFalse(builder.isRadioButtonChecked(null));
    assertFalse(builder.isRadioButtonChecked(" "));
    assertFalse(builder.isRadioButtonChecked("n"));
    assertFalse(builder.isRadioButtonChecked("N"));
    assertTrue(builder.isRadioButtonChecked("y"));
  }
}