/*
 CostScheduleServiceImpl_UT was created on Nov 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import junit.framework.TestCase;
import com.monsanto.eas.eis.projects.domain.FundingSource;
import com.monsanto.wst.hibernate.mock.MockDAO;

import java.util.List;

import org.hibernate.Criteria;

/**
 * Filename:    $RCSfile: CostScheduleServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-11-10 16:29:50 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class CostScheduleServiceImpl_UT extends TestCase {
  public void testCreate() throws Exception {
    CostScheduleService service = new CostScheduleServiceImpl();
    assertNotNull(service);
  }

  public void testLookupAllFundingSources_ReturnsList() throws Exception {
    MockDAO<FundingSource, Long> dao = new MockDAO<FundingSource, Long>();
    CostScheduleService service = new CostScheduleServiceImpl(dao);
    service.lookupAllFundingSources();
    assertTrue(dao.wasFindAllCalled());
    assertEquals("source", dao.getSortKey());
    assertTrue(dao.getSortOrder());
  }

  public void testLookupFundingSourceById_ReturnsFundingSource() throws Exception {
    MockDAO<FundingSource, Long> dao = new MockDAO<FundingSource, Long>();
    CostScheduleService service = new CostScheduleServiceImpl(dao);
    service.lookupFundingSourceById(new Long(123));
    assertTrue(dao.wasFindByPrimaryKeyCalled());
  }
}