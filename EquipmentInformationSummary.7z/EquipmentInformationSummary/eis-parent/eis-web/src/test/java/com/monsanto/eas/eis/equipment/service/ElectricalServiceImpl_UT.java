package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.mock.MockDAO;
import junit.framework.TestCase;
import org.hibernate.Criteria;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 23, 2008 Time: 4:11:20 PM To change this template use File |
 * Settings | File Templates.
 */
public class ElectricalServiceImpl_UT extends TestCase {
  MockDAO<ElectricalInput, Long> inputDao;
  MockDAO<ElectricalOutput, Long> outputDao;
  MockDAO<OtherMeasurement, Long> otherMeasurementDao;
  MockDAOInputQuantityDao<ElectricalInputQuantity, Long> inputQuantityDao;
  MockDAOOutputQuantityDao<ElectricalOutputQuantity, Long> outputQuantityDao;
  ElectricalService electricalService;


  protected void setUp() throws Exception {
    super.setUp();
    inputDao = new MockDAO<ElectricalInput, Long>(getInputs());
    outputDao = new MockDAO<ElectricalOutput, Long>(getOutputs());
    otherMeasurementDao = new MockDAO<OtherMeasurement, Long>(getOtherMeasurements());
    inputQuantityDao = new MockDAOInputQuantityDao<ElectricalInputQuantity, Long>(new ElectricalInputQuantity(new Long(1234), null, null, null, false));
    outputQuantityDao = new MockDAOOutputQuantityDao<ElectricalOutputQuantity, Long>(new ElectricalOutputQuantity(new Long(2345), null, null, null, false));
    electricalService = new ElectricalServiceImpl(inputDao, outputDao, otherMeasurementDao, null, inputQuantityDao, outputQuantityDao);
  }

  public void testLookupAllInputs_ReturnsList() throws Exception {
    List<ElectricalInput> inputs = electricalService.lookupAllInputs();
    assertEquals("input", inputDao.getSortKey());
    assertTrue(inputDao.getSortOrder());
    assertEquals(2, inputs.size());
  }


  public void testLookupAllOutputs_ReturnsList() throws Exception {
    List<ElectricalOutput> outputs = electricalService.lookupAllOutputs();
    assertEquals("output", outputDao.getSortKey());
    assertTrue(outputDao.getSortOrder());
    assertEquals(2, outputs.size());
  }

  public void testLookupAllOtherMeasurements_ReturnsList() throws Exception {
    List<OtherMeasurement> outputs = electricalService.lookupAllOtherMeasurements();
    assertEquals("measurement", otherMeasurementDao.getSortKey());
    assertTrue(otherMeasurementDao.getSortOrder());
    assertEquals(2, outputs.size());
  }

  public void testLookupElectricalInput_ReturnsElectricalInput() throws Exception {
    GenericDAO<ElectricalInput, Long> inputDao = new MockDAO<ElectricalInput, Long>(getSingleElectricalInput());
    ElectricalService service = new ElectricalServiceImpl(inputDao, null, null, null, null, null);
    ElectricalInput electricalInput = service.lookupElectricalInput(1L);
    assertNotNull(electricalInput);
  }

  public void testLookupElectricalOutput_ReturnsElectricalOutput() throws Exception {
    GenericDAO<ElectricalOutput, Long> outputDao = new MockDAO<ElectricalOutput, Long>(getSingleElectricalOutput());
    ElectricalService service = new ElectricalServiceImpl(null, outputDao, null, null, null, null);
    ElectricalOutput electricalOutput = service.lookupElectricalOutput(1L);
    assertNotNull(electricalOutput);
  }

  public void testLookupOtherMeasurement_ReturnsOtherMeasurement() throws Exception {
    GenericDAO<OtherMeasurement, Long> otherMeasurementDao = new MockDAO<OtherMeasurement, Long>(
        getSingleOtherMeasurement());
    ElectricalService service = new ElectricalServiceImpl(null, null, otherMeasurementDao, null, null, null);
    OtherMeasurement otherMeasurement = service.lookupOtherMeasurement(1L);
    assertNotNull(otherMeasurement);
  }

  public void testLookupElectricalInputQuantity_ReturnsElectricalInputQuantity() throws Exception {
    ElectricalInputQuantity inputQuantity = electricalService
        .lookupInputQuantityByInputForElectrical(new Long(123), new Long(234));
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) inputQuantityDao.getCriteria();
    assertEquals(2, criteria.getCriteria().size());
    assertEquals("input.id=123", criteria.getCriteria().get(0).toString());
    assertEquals("electrical.id=234", criteria.getCriteria().get(1).toString());
    assertEquals(new Long(1234), inputQuantity.getId());
  }

  public void testLookupElectricalOutputQuantity_ReturnsElectricalOutputQuantity() throws Exception {
    ElectricalOutputQuantity outputQuantity = electricalService
        .lookupInputQuantityByOutputForElectrical(new Long(123), new Long(234));
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) outputQuantityDao.getCriteria();
    assertEquals(2, criteria.getCriteria().size());
    assertEquals("output.id=123", criteria.getCriteria().get(0).toString());
    assertEquals("electrical.id=234", criteria.getCriteria().get(1).toString());
    assertEquals(new Long(2345), outputQuantity.getId());
   }

  private List<ElectricalInput> getInputs() {
    List<ElectricalInput> inputList = new ArrayList<ElectricalInput>();
    ElectricalInput inputOne = new ElectricalInput();
    inputOne.setId(1L);
    ElectricalInput inputTwo = new ElectricalInput();
    inputTwo.setId(2L);
    inputList.add(inputOne);
    inputList.add(inputTwo);
    return inputList;
  }

  private List<ElectricalOutput> getOutputs() {
    List<ElectricalOutput> outputList = new ArrayList<ElectricalOutput>();
    ElectricalOutput outputOne = new ElectricalOutput();
    outputOne.setId(1L);
    outputList.add(outputOne);
    ElectricalOutput outputTwo = new ElectricalOutput();
    outputTwo.setId(2L);
    outputList.add(outputTwo);
    return outputList;
  }

  private List<OtherMeasurement> getOtherMeasurements() {
    List<OtherMeasurement> otherMeasurementList = new ArrayList<OtherMeasurement>();
    OtherMeasurement otherMeasurementOne = new OtherMeasurement();
    otherMeasurementOne.setId(1L);
    otherMeasurementList.add(otherMeasurementOne);
    OtherMeasurement otherMeasurementTwo = new OtherMeasurement();
    otherMeasurementTwo.setId(2L);
    otherMeasurementList.add(otherMeasurementTwo);
    return otherMeasurementList;
  }

  private List<ElectricalInput> getSingleElectricalInput() {
    List<ElectricalInput> inputList = new ArrayList<ElectricalInput>();
    ElectricalInput inputOne = new ElectricalInput();
    inputOne.setId(1L);
    inputList.add(inputOne);
    return inputList;
  }

  private List<ElectricalOutput> getSingleElectricalOutput() {
    List<ElectricalOutput> outputList = new ArrayList<ElectricalOutput>();
    ElectricalOutput outputOne = new ElectricalOutput();
    outputOne.setId(1L);
    outputList.add(outputOne);
    return outputList;
  }

  private List<OtherMeasurement> getSingleOtherMeasurement() {
    List<OtherMeasurement> otherMeasurementList = new ArrayList<OtherMeasurement>();
    OtherMeasurement otherMeasurementOne = new OtherMeasurement();
    otherMeasurementOne.setId(1L);
    otherMeasurementList.add(otherMeasurementOne);
    return otherMeasurementList;
  }


  public void testLookupElectrical_ReturnsElectrical() throws Exception {
    MockElectricalDao electricalDao = new MockElectricalDao();
    ElectricalService service = new ElectricalServiceImpl(null, null, null, electricalDao, null, null);
    Electrical electrical = service.lookupElectrical(1L);
    MockCriteriaForEIS criteria = electricalDao.getMockCriteria();
    assertEquals("id=1", criteria.getCriteria().get(0).toString());
    assertEquals(2, criteria.getFetchModes().size());
    assertEquals("inputQuantity-JOIN", criteria.getFetchModes().get(0));
    assertEquals("outputQuantity-JOIN", criteria.getFetchModes().get(1));
    assertEquals(0, criteria.getOrderings().size());
  }

  private Electrical getElectrical() {
    return null;
  }

  private class MockElectricalDao extends MockDAO<Electrical, Long> {
    MockCriteriaForEIS mockCriteriaForEIS = new MockCriteriaForEIS(new Electrical(), null);

    public MockCriteriaForEIS createCriteria() {
      return mockCriteriaForEIS;
    }

    public MockCriteriaForEIS getMockCriteria() {
      return mockCriteriaForEIS;
    }

    public void setMockCriteria(MockCriteria mockCriteria) {
      super.setMockCriteria(mockCriteria);
    }
  }

  private class MockDAOInputQuantityDao<T, T1> extends MockDAO<ElectricalInputQuantity, Long> {
    MockCriteriaForEIS criteria;
    private ElectricalInputQuantity uniqueResult;

    public MockDAOInputQuantityDao(ElectricalInputQuantity uniqueResult) {
      this.uniqueResult = uniqueResult;
    }

    public Criteria createCriteria() {
      criteria = new MockCriteriaForEIS(uniqueResult, null);
      return criteria;
    }

    public MockCriteriaForEIS getCriteria() {
      return criteria;
    }
  }

  private class MockDAOOutputQuantityDao<T, T1> extends MockDAO<ElectricalOutputQuantity, Long> {
    MockCriteriaForEIS criteria;
    private ElectricalOutputQuantity uniqueResult;

    public MockDAOOutputQuantityDao(ElectricalOutputQuantity uniqueResult) {
      this.uniqueResult = uniqueResult;
    }

    public Criteria createCriteria() {
      criteria = new MockCriteriaForEIS(uniqueResult, null);
      return criteria;
    }

    public MockCriteriaForEIS getCriteria() {
      return criteria;
    }
  }
}
