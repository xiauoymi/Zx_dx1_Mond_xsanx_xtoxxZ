package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.projects.EISDAOFactory;
import com.monsanto.eas.eis.projects.EISDAOFactoryImpl;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.mocks.*;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import com.monsanto.wst.hibernate.mock.MockHibernateFactory;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Sep 4, 2008 Time: 6:59:15 PM To change this template use File | Settings
 * | File Templates.
 */
public class EquipmentServiceImpl_UT extends XMLTestCase {
  private MockEISDAOFactory mockEISDAOFactory;
  private EquipmentService equipmentService;

  protected void setUp() throws Exception {
    super.setUp();
    mockEISDAOFactory = new MockEISDAOFactory(new MockHibernateSession());
    equipmentService = new EquipmentServiceImpl(mockEISDAOFactory);
  }

  public void testlookupAllParentEquipmentTypes_VerifyCriteria() throws Exception {
    equipmentService.lookupAllParentEquipmentTypes();
    MockDAO<EquipmentType, Long> typeDAOImpl = (MockDAO<EquipmentType, Long>) mockEISDAOFactory
        .getEquipmentTypeDAOImpl();
    MockCriteria criteria = (MockCriteria) typeDAOImpl.createCriteria();
    assertEquals("parentEquipmentType is null", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("typeCode asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testLookupEquipmentSubTypes_VerifyXmlDoc() throws IOException, TransformerException {
    Document xmlDoc = equipmentService.lookupEquipmentSubTypes(1L);
    assertXpathEvaluatesTo("1", "count(//types)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//type)", xmlDoc);
    assertXpathEvaluatesTo("112", "//type[1]/id", xmlDoc);
    assertXpathEvaluatesTo("Belt", "//type[1]/description", xmlDoc);
    assertXpathEvaluatesTo("111", "//type[2]/id", xmlDoc);
    assertXpathEvaluatesTo("Screw", "//type[2]/description", xmlDoc);
  }

  public void testLookupEquipmentSubTypes_NoSubtypes_VerifyXmlDoc() throws IOException, TransformerException {
    Document xmlDoc = equipmentService.lookupEquipmentSubTypes(2L);
    assertXpathEvaluatesTo("1", "count(//types)", xmlDoc);
    assertXpathEvaluatesTo("0", "count(//type)", xmlDoc);
  }

  public void testLookupEquipmet() throws Exception {
    Equipment equipment = equipmentService.lookupEquipment(1L);
    assertNotNull(equipment);
    MockEquipmentDAO mockEquipmentDAO = (MockEquipmentDAO) mockEISDAOFactory.getEquipmentDAOImpl();
    assertTrue(mockEquipmentDAO.wasFindByPrimaryKeyCalled());
    assertEquals(equipment.getName(), "e-name");
    assertEquals(equipment.getDescription(), "e-description");
    assertEquals(equipment.getArea().getDescription(), "Area Description");
    assertEquals(equipment.getProcessLineNumber(), "0");
    assertEquals(equipment.getEquipmentNumber(), "0.0.123W");
    assertEquals(equipment.getEquipmentTagNumber(), "000");
    assertEquals(equipment.getEquipmentType().getName(), "equipment_type");
    assertEquals(equipment.getSubType().getName(), "sub_type_one");
  }

  public void testGetAreasAsList_WasMethodCalled() throws Exception {
    List areasList = equipmentService.lookupAllAreas();
    MockAreaDAOImpl mockAreaDAO = (MockAreaDAOImpl) mockEISDAOFactory.getAreaDAOImpl();
    assertTrue(mockAreaDAO.wasFindAllCalled());
    assertNotNull(areasList);
    assertTrue(areasList.size() > 0);
  }

  public void testSaveEquipment_EquipmentMergedAndSaved() throws Exception {
    Projects projects = new Projects();
    Equipment equipment = new Equipment();
    equipment.setId(1L);
    projects.getEquipments().add(equipment);
    equipment = new Equipment();
    equipment.setId(2L);
    projects.getEquipments().add(equipment);
    equipment = new Equipment("00.123.W12", "0.000.1W1", "Equipment Name", "Equipment Description",
        new Area(null, "0", "Area Description"), "0", "123",
        new EquipmentType(null, "equipment_type", "W"), new EquipmentType(null, "sub_type_one", "W"),
        projects);

    MockEquipmentServiceImplForSave service = new MockEquipmentServiceImplForSave(mockEISDAOFactory);
    equipment = service.saveEquipment(equipment);
    assertTrue(service.isMergeCalled());
    MockEquipmentDAO equipmentDAO = (MockEquipmentDAO) mockEISDAOFactory.getEquipmentDAOImpl();
    assertTrue(equipmentDAO.wasSaved(equipment));
  }

  public void testDeleteEquipment() throws Exception {
    String equipmentId = "1";
    equipmentService.deleteEquipment(equipmentId);
    assertTrue(((MockEquipmentDAO) mockEISDAOFactory.getEquipmentDAOImpl()).wasDeleteCalled());
  }

  public void testLookupAreaById_WasFindByPrimaryCalled() throws Exception {
    equipmentService.lookupAreaById(new Long(12));
    assertTrue(((MockAreaDAOImpl) mockEISDAOFactory.getAreaDAOImpl()).wasFindByPrimaryKeyCalled());
  }

  public void testLookupEquipmentByCriteria() throws Exception {
    MockEISDAOFactoryForSearchCriteria mockEISDAOFactory1 = new MockEISDAOFactoryForSearchCriteria(new MockHibernateSession());
   equipmentService = new EquipmentServiceImpl(mockEISDAOFactory1);
    equipmentService.findBySearchCriteria("1", "0.2.223A", "", "", "", "", "", "", "", "", 0, 25);
    assertTrue(((MockEquipmentDAO) mockEISDAOFactory1.getEquipmentDAOImpl()).wasFindBySearchCriteriaCalled());
  }

  private class MockEquipmentServiceImplForSave extends EquipmentServiceImpl {
    private boolean mergeCalled;
    private boolean searchByCriteriaCalled;

    private MockEquipmentServiceImplForSave(EISDAOFactory daoFactory) {
      super(daoFactory);
    }//protected for testing

    protected Equipment mergeEquipmentWithDB(Equipment equipment) {
      this.mergeCalled = true;
      return equipment;
    }

    public boolean isMergeCalled() {
      return mergeCalled;
    }

    public PaginatedResult findBySearchCriteria(String projectId, String equipmentNumber, String equipmentName,
                                                String processLineNum, String equipmentTypeId, String areaId,
                                                String vendor,
                                                String existingEquipmentNumber, String sortKey, String sortDir,
                                                int startIndex, int maxResults) {
      this.searchByCriteriaCalled = true;
      return super.findBySearchCriteria(projectId, equipmentNumber, equipmentName, processLineNum,
        equipmentTypeId, areaId, vendor, existingEquipmentNumber, sortKey, sortDir, startIndex, maxResults);
    }

    public boolean isSearchByCriteriaCalled() {
      return searchByCriteriaCalled;
    }
  }

  public class MockEISDAOFactoryForSearchCriteria extends EISDAOFactoryImpl {
  public MockEISDAOFactoryForSearchCriteria(MockHibernateSession session) {
    super(new MockHibernateFactory(),
        new MockProjectsDAOImpl(session),
        new MockProjectStatusDAOImpl(session),
        new MockUnitMeasureDAOImpl(session),
        new MockLocationDAOImpl(session),
        new MockCropDAOImpl(session),
        new MockAreaDAOImpl(session),
        new MockEquipmentTypeDAOImpl(session),
        new MockEquipmentDAO(new Integer(8)));
  }
}
}
