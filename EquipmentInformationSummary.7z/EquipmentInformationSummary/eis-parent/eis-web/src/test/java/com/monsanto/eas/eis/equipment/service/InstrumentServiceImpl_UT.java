/*
 InstrumentServiceImpl_UT was created on Oct 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import junit.framework.TestCase;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.equipment.service.InstrumentService;
import com.monsanto.eas.eis.equipment.service.InstrumentServiceImpl;

import java.util.List;

/**
 * Filename:    $RCSfile: InstrumentServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2009-01-21 18:28:35 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public class InstrumentServiceImpl_UT extends TestCase {
  InstrumentService service;
  GenericDAO<InstrumentDesignator, Long> designatorDao;
  MockDAO<IOType, Long> ioTypeDao;

  protected void setUp() throws Exception {
    designatorDao = new MockDAO<InstrumentDesignator, Long>(null);
    ioTypeDao = new MockDAO<IOType, Long>(null);
    service = new InstrumentServiceImpl(designatorDao, ioTypeDao);
  }

  public void testCreate() throws Exception {
    InstrumentService insService = new InstrumentServiceImpl(
        (GenericDAO< InstrumentDesignator, Long>) null,
        (GenericDAO< IOType, Long>) null);
    assertNotNull(insService);
  }

  public void testLookupAllInstrumentDesignatorForFirstChar_VerifyCriteria() throws Exception {
    List<InstrumentDesignator> list = service.lookupAllInstrumentDesignatorsForFirstChar();
    MockCriteria criteria = (MockCriteria) designatorDao.createCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("charNum=1", criteria.getCriteria().get(0).toString());
    assertEquals("typeCode asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testLookupAllInstrumentDesignatorForSecondChar_VerifyCriteria() throws Exception {
    List<InstrumentDesignator> list = service.lookupAllInstrumentDesignatorsForSecondChar();
    MockCriteria criteria = (MockCriteria) designatorDao.createCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("charNum=2", criteria.getCriteria().get(0).toString());
    assertEquals("typeCode asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
 }

  public void testLookupAllIOTypes_VerifyCriteria() throws Exception {
    List<IOType> list = service.lookupAllIOTypes();
    assertEquals("type", ioTypeDao.getSortKey());
    assertTrue(ioTypeDao.getSortOrder());
  }

}