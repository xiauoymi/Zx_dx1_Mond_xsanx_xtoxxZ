package com.monsanto.eas.eis.equipment.service;

import junit.framework.TestCase;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.eas.eis.projects.domain.PurchaseScope;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Dec 8, 2008 Time: 5:18:21 PM To change this template use File | Settings
 * | File Templates.
 */
public class MechanicalServiceImpl_UT extends TestCase {
  private MockDAO<PurchaseScope, Long> purchaseScopeDao;
  MechanicalService mechanicalService;

  protected void setUp() throws Exception {
    super.setUp();
    purchaseScopeDao = new MockDAO<PurchaseScope, Long>(getPurchaseScopes());
    mechanicalService = new MechanicalServiceImpl(purchaseScopeDao);
  }

  public void testLookupAllPurchaseScopes_RetunsList() throws Exception {
    List<PurchaseScope> list = mechanicalService.lookupAllPurchaseScopes();
    assertEquals("purchaseScopeName", purchaseScopeDao.getSortKey());
    assertTrue(purchaseScopeDao.getSortOrder());
    assertEquals(1, list.size());
  }

  public void testLookupPurchaseScopeBuId_ReturnsPurchaseScope() throws Exception {
    PurchaseScope ps = mechanicalService.lookupPurchaseScopeById(1L);
    assertNotNull(ps);
    assertEquals(new Long(1), ps.getId());
    assertEquals("Contractor", ps.getPurchaseScopeName());
  }

  private List<PurchaseScope> getPurchaseScopes() {
    List<PurchaseScope> list = new ArrayList<PurchaseScope>();
    PurchaseScope ps1 = new PurchaseScope(new Long(1));
    ps1.setPurchaseScopeName("Contractor");
    list.add(ps1);
    return list;
  }
}
