/*
 MotorServiceImpl_UT was created on Oct 20, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import junit.framework.TestCase;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.eas.eis.projects.domain.MotorDesignStatus;
import com.monsanto.eas.eis.projects.domain.MotorLoadValueType;
import com.monsanto.eas.eis.projects.domain.ComponentDesignator;
import com.monsanto.eas.eis.equipment.service.MotorService;
import com.monsanto.eas.eis.equipment.service.MotorServiceImpl;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MotorServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-01-20 22:41:39 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class MotorServiceImpl_UT extends TestCase {

  MockDAO<MotorDesignStatus, Long> designStatusDao;
  MockDAO<MotorLoadValueType, Long> loadValueTypeDao;
  MockDAO<ComponentDesignator, Long> compDesignatorDao;
  MotorService service;

  protected void setUp() throws Exception {

    designStatusDao = new MockDAO<MotorDesignStatus, Long>(getDesignStatus());
    loadValueTypeDao = new MockDAO<MotorLoadValueType, Long>(getLoadValyeTypes());
    compDesignatorDao = new MockDAO<ComponentDesignator, Long>(null);
    service = new MotorServiceImpl(designStatusDao, loadValueTypeDao, compDesignatorDao);
  }

  public void testCreate() throws Exception {
    MotorService service = new MotorServiceImpl((GenericDAO< MotorDesignStatus, Long>) null,
                          (GenericDAO< MotorLoadValueType, Long>) null,
                          (GenericDAO<ComponentDesignator, Long>) null);
    assertNotNull(service);
  }

  public void testLookupAllDesignStatus_ReturnsList() throws Exception {
    List<MotorDesignStatus> list = service.lookupAllDesignStatus();
    assertEquals("status", designStatusDao.getSortKey());
    assertFalse(designStatusDao.getSortOrder());
    assertEquals(3, list.size());
  }

  public void testLookupAllLoadValueTypes_ReturnsList() throws Exception {
    List<MotorLoadValueType> list = service.lookupAllLoadValyeTypes();
    assertEquals("type", loadValueTypeDao.getSortKey());
    assertTrue(loadValueTypeDao.getSortOrder());
    assertEquals(4, list.size());
  }

  public void testLookupAllLComponentDesignators_ReturnsList() throws Exception {
    List<ComponentDesignator> list = service.lookupAllComponentDesignators();
    assertEquals("value", compDesignatorDao.getSortKey());
    assertTrue(compDesignatorDao.getSortOrder());
  }

  private List<MotorLoadValueType> getLoadValyeTypes() {
    List<MotorLoadValueType> list = new ArrayList<MotorLoadValueType>();
    list.add(new MotorLoadValueType(new Long(5)));
    list.add(new MotorLoadValueType(new Long(6)));
    list.add(new MotorLoadValueType(new Long(7)));
    list.add(new MotorLoadValueType(new Long(8)));
    return list;
  }

  private List<MotorDesignStatus> getDesignStatus() {
    List<MotorDesignStatus> list = new ArrayList<MotorDesignStatus>();
    list.add(new MotorDesignStatus(new Long(3)));
    list.add(new MotorDesignStatus(new Long(4)));
    list.add(new MotorDesignStatus(new Long(5)));
    return list;
  }


}