/*
 ProcessServiceImpl_UT was created on Sep 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service;

import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.mock.MockDAO;
import junit.framework.TestCase;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: ProcessServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-02-11 15:18:05 $
 *
 * @author sspati1
 * @version $Revision: 1.10 $
 */
public class ProcessServiceImpl_UT extends TestCase {
  ProcessService service;
  MockDAO<GasType, Long> gasTypeDao;
  MockDAO<WaterType, Long> waterTypeDao;
  MockDAO<DustType, Long> dustTypeDao;
  MockDAO<FieldEquipmentType, Long> feTypeDao;
  MockPFEDAO<ProcessFieldEquipmentType, Long> pfeDao;
  MockDAO<DesignCapacityUnit, Long> designCapacityUnitDao;
  private MockDAO<EquipmentType, Long> equipmentTypeDao;
  private MockDAO<UnitMeasure, Long> unitMeasureDao;

  protected void setUp() throws Exception {
    super.setUp();
    gasTypeDao = new MockDAO<GasType, Long>(getGasTypes());
    waterTypeDao = new MockDAO<WaterType, Long>(getWaterTypes());
    dustTypeDao = new MockDAO<DustType, Long>(getDustTypes());
    feTypeDao = new MockDAO<FieldEquipmentType, Long>(getFieldEquipmentTypes());
    pfeDao = new MockPFEDAO<ProcessFieldEquipmentType, Long>(null, ProcessFieldEquipmentType.class);
    designCapacityUnitDao = new MockDAO<DesignCapacityUnit, Long>(getDesignCapacityUnits());
    equipmentTypeDao = new MockDAO<EquipmentType, Long>(getEquipmentTypes());
    unitMeasureDao = new MockDAO<UnitMeasure, Long>(getUnitMeasures());
    service = new ProcessServiceImpl(gasTypeDao, waterTypeDao, dustTypeDao, feTypeDao, designCapacityUnitDao,
        equipmentTypeDao, unitMeasureDao, pfeDao);
  }

  public void testLookupAllGasTypes() throws Exception {
    service.lookupAllGasTypes();
    assertTrue(gasTypeDao.wasFindAllCalled());
    assertEquals("type", gasTypeDao.getSortKey());
    assertTrue(gasTypeDao.getSortOrder());
  }

  public void testLookupGasTypeById() throws Exception {
    service.lookupGasTypeById(Long.valueOf(1));
    assertTrue(gasTypeDao.wasFindByPrimaryKeyCalled());
  }

  public void testLookupAllWaterTypes() throws Exception {
    service.lookupAllWaterTypes();
    assertTrue(waterTypeDao.wasFindAllCalled());
    assertEquals("type", waterTypeDao.getSortKey());
    assertTrue(waterTypeDao.getSortOrder());
  }

  public void testLookupWaterTypeById() throws Exception {
    service.lookupWaterTypeById((Long) null);
    assertTrue(waterTypeDao.wasFindByPrimaryKeyCalled());
  }

  public void testLookupAllDustTypes() throws Exception {
    service.lookupAllDustTypes();
    assertTrue(dustTypeDao.wasFindAllCalled());
    assertEquals("type", dustTypeDao.getSortKey());
    assertTrue(dustTypeDao.getSortOrder());
  }

  public void testLookupDustTypeById() throws Exception {
    service.lookupDustTypeById((Long) null);
    assertTrue(dustTypeDao.wasFindByPrimaryKeyCalled());
  }

  public void testLookupDesignCapacityUnitsByEquipmentTypeAndUnitMeasure_ReturnsList() throws Exception {
    List<DesignCapacityUnit> designCapacityUnits = service
        .lookupDesignCapacityUnitsByEquipmentTypeAndUnitMeasure(new Long(11), new Long(111));
    assertEquals(1, designCapacityUnits.size());
  }

  public void testLookupDesignCapacityUnitsByEquipmentTypeAndUnitMeasure_EquipmentTypeIdIsNull_ReturnsEmptyList() throws
      Exception {
    List<DesignCapacityUnit> designCapacityUnits = service
        .lookupDesignCapacityUnitsByEquipmentTypeAndUnitMeasure(null, new Long(12));
    assertEquals(0, designCapacityUnits.size());
  }

  public void testLookupDesignCapacityUnitsByEquipmentTypeAndUnitMeasure_UnitMeasureIdIsNull_ReturnsEmptyList() throws
      Exception {
    List<DesignCapacityUnit> designCapacityUnits = service
        .lookupDesignCapacityUnitsByEquipmentTypeAndUnitMeasure(new Long(12), null);
    assertEquals(0, designCapacityUnits.size());
  }

  public void testLookupUnitMeausreById() throws Exception {
    service.lookupUnitMeasureById((Long) null);
    assertTrue(unitMeasureDao.wasFindByPrimaryKeyCalled());
  }

  public void testLookupDesignCapacityUnitById() throws Exception {
    service.lookupDesignCapacityUnitById((Long) null);
    assertTrue(designCapacityUnitDao.wasFindByPrimaryKeyCalled());
  }

  public void testLookupAllFieldEquipmentTypes_EquipmentTypeIdIsNotNull_VerifyCriteria() throws Exception {
    service.lookupAllFieldEquipmentTypes(new Long(23));
    MockCriteria criteria = feTypeDao.getMockCriteria();
    assertTrue(criteria.wasListCalled());
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("equipmentType.id=23", criteria.getCriteria().get(0).toString());
    List<Order> orders = criteria.getOrderings();
    assertEquals("equipmentType asc", orders.get(0).toString());
    assertEquals("order asc", orders.get(1).toString());
  }

  public void testLookupAllFieldEquipmentTypes_EquipmentTypeIdIsNull_VerifyCriteria() throws Exception {
    service.lookupAllFieldEquipmentTypes(null);
    MockCriteria criteria = feTypeDao.getMockCriteria();
    assertTrue(criteria.wasListCalled());
    assertEquals(0, criteria.getCriteria().size());
    List<Order> orders = criteria.getOrderings();
    assertEquals("equipmentType asc", orders.get(0).toString());
    assertEquals("order asc", orders.get(1).toString());
  }

  public void testLookupProcessFieldEquipmentTypeByFieldName_VerifyCriteria() throws Exception {
    ProcessFieldEquipmentType processFieldEquipmentType = service
        .lookupProcessFieldEquipmentTypeByFieldName(new Long(123), "bellType");
    MockCriteria criteria = pfeDao.getMockCriteria();
    assertEquals(new Long(234), processFieldEquipmentType.getId());
    assertEquals(2, criteria.getCriteria().size());
    assertEquals("ft.name=bellType", criteria.getCriteria().get(0).toString());
    assertEquals("process.id=123", criteria.getCriteria().get(1).toString());
  }

  private List<GasType> getGasTypes() {
    List<GasType> types = new ArrayList<GasType>();
    GasType type = new GasType(Long.valueOf("1"));
    type.setType("Natural Gas");
    types.add(type);
    type = new GasType(Long.valueOf("2"));
    type.setType("Propane");
    types.add(type);
    return types;
  }

  private List<WaterType> getWaterTypes() {
    List<WaterType> types = new ArrayList<WaterType>();
    WaterType type = new WaterType(Long.valueOf("1"));
    type.setType("Process");
    types.add(type);
    type = new WaterType(Long.valueOf("2"));
    type.setType("Unprocessed");
    types.add(type);
    return types;
  }

  private List<DustType> getDustTypes() {
    List<DustType> types = new ArrayList<DustType>();
    DustType type = new DustType(Long.valueOf("1"));
    type.setType("Red Dust");
    types.add(type);
    type = new DustType(Long.valueOf("2"));
    type.setType("Blue Dust");
    types.add(type);
    return types;
  }

  private List<FieldEquipmentType> getFieldEquipmentTypes() {
    List<FieldEquipmentType> types = new ArrayList<FieldEquipmentType>();
    types.add(new FieldEquipmentType());
    types.add(new FieldEquipmentType());
    types.add(new FieldEquipmentType());
    return types;
  }

  private List<DesignCapacityUnit> getDesignCapacityUnits() {
    List<DesignCapacityUnit> types = new ArrayList<DesignCapacityUnit>();
    types.add(new DesignCapacityUnit(Long.valueOf("1")));
    types.add(new DesignCapacityUnit(Long.valueOf("2")));
    return types;
  }

  private List<EquipmentType> getEquipmentTypes() {
    List<EquipmentType> types = new ArrayList<EquipmentType>();
    EquipmentType type = new EquipmentType(new Long(11), null, null);
    List<DesignCapacityUnit> dcus = new ArrayList<DesignCapacityUnit>();
    DesignCapacityUnit dcu = new DesignCapacityUnit(new Long(123));
    dcu.setUnitMeasure(new UnitMeasure(new Long(111), "unit measure 1"));
    dcus.add(dcu);
    dcu = new DesignCapacityUnit(new Long(124));
    dcu.setUnitMeasure(new UnitMeasure(new Long(222), "unit measure 2"));
    dcus.add(dcu);
    type.setDesignCapacityUnits(dcus);
    types.add(type);
    types.add(new EquipmentType(new Long(12), null, null));
    return types;
  }

  private List<UnitMeasure> getUnitMeasures() {
    List<UnitMeasure> types = new ArrayList<UnitMeasure>();
    types.add(new UnitMeasure(new Long(111), null));
    types.add(new UnitMeasure(new Long(222), null));
    return types;
  }

  private class MockPFEDAO<T, T1> extends HibernateDAO<ProcessFieldEquipmentType, Long> {
    MockCriteria criteria;

    public MockPFEDAO(HibernateFactory hibernate, Class<? extends ProcessFieldEquipmentType> persistentClass) {
      super(hibernate, persistentClass);
    }

    public Criteria createCriteria() {
      criteria = new MockCriteriaForEIS(
          new ProcessFieldEquipmentType(new Long(234), null, null, null), null);
      return criteria;
    }

    public MockCriteria getMockCriteria() {
      return criteria;
    }
  }
}