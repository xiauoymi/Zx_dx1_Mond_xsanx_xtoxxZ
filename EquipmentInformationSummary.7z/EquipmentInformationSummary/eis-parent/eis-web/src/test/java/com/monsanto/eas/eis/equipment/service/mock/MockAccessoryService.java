/*
 MockAccessoryService was created on Nov 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service.mock;

import com.monsanto.eas.eis.equipment.service.AccessoryService;
import com.monsanto.eas.eis.projects.domain.AccessoryDesignator;
import com.monsanto.eas.eis.projects.domain.AutoManual;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockAccessoryService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-11 19:20:45 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class MockAccessoryService implements AccessoryService {
  public List<AccessoryDesignator> lookupAllAccessoryDesignators() {
    return getDesignators();
  }

  public List<AutoManual> lookupAllAutoManuals() {
    return getAutoManual();
  }

  private List<AutoManual> getAutoManual() {
    List<AutoManual> list = new ArrayList<AutoManual>();
    AutoManual autoManual = new AutoManual(new Long(22));
    autoManual.setValue("AU");
    list.add(autoManual);
    autoManual = new AutoManual(new Long(23));
    autoManual.setValue("MA");
    list.add(autoManual);
    return list;
  }

  private List<AccessoryDesignator> getDesignators() {
    List<AccessoryDesignator> list = new ArrayList<AccessoryDesignator>();
    list.add(new AccessoryDesignator(new Long(11), "ADES 1", "AD1"));
    list.add(new AccessoryDesignator(new Long(12), "ADES 2", "AD2"));
    return list;
  }
}