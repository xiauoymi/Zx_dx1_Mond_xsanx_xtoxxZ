/*
 MockCostScheduleService was created on Nov 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service.mock;

import com.monsanto.eas.eis.equipment.service.CostScheduleService;
import com.monsanto.eas.eis.projects.domain.FundingSource;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockCostScheduleService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2008-12-15 19:34:04 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public class MockCostScheduleService implements CostScheduleService {
  public List<FundingSource> lookupAllFundingSources() {
    List<FundingSource> list = new ArrayList<FundingSource>();
    FundingSource source = new FundingSource(new Long(12));
    source.setSource("Lease");
    list.add(source);
    source = new FundingSource(new Long(12));
    source.setSource("Capital");
    list.add(source);
    return list;
  }

  public FundingSource lookupFundingSourceById(Long id) {
    FundingSource source = new FundingSource(id);
    source.setSource("Capital");
    return source;
  }
}