package com.monsanto.eas.eis.equipment.service.mock;

import com.monsanto.eas.eis.equipment.service.ElectricalService;
import com.monsanto.eas.eis.projects.domain.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 23, 2008 Time: 5:55:00 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockElectricalService implements ElectricalService {
  public List<ElectricalInput> lookupAllInputs() {
    List<ElectricalInput> electricalInputs = new ArrayList<ElectricalInput>();
    ElectricalInput electricalInputOne = new ElectricalInput(1L);
    electricalInputOne.setInput("AI");
    ElectricalInput electricalInputTwo = new ElectricalInput(2L);
    electricalInputTwo.setInput("DI");
    electricalInputs.add(electricalInputOne);
    electricalInputs.add(electricalInputTwo);
    return electricalInputs;
  }

  public List<ElectricalOutput> lookupAllOutputs() {
    List<ElectricalOutput> electricalOutputs = new ArrayList<ElectricalOutput>();
    ElectricalOutput electricalOutputOne = new ElectricalOutput(3L);
    electricalOutputOne.setOutput("AO");
    ElectricalOutput electricalOutputTwo = new ElectricalOutput(4L);
    electricalOutputTwo.setOutput("DO");
    electricalOutputs.add(electricalOutputOne);
    electricalOutputs.add(electricalOutputTwo);
    return electricalOutputs;
  }

  public List<OtherMeasurement> lookupAllOtherMeasurements() {
    List<OtherMeasurement> otherMeasurementList = new ArrayList<OtherMeasurement>();
    OtherMeasurement otherMeasurementOne = new OtherMeasurement(5L);
    otherMeasurementOne.setMeasurement("Level");
    OtherMeasurement otherMeasurementTwo = new OtherMeasurement(6L);
    otherMeasurementTwo.setMeasurement("Temperature");
    OtherMeasurement otherMeasurementThree = new OtherMeasurement(7L);
    otherMeasurementThree.setMeasurement("Flow");
    OtherMeasurement otherMeasurementFour = new OtherMeasurement(8L);
    otherMeasurementFour.setMeasurement("Pressure");
    otherMeasurementList.add(otherMeasurementOne);
    otherMeasurementList.add(otherMeasurementTwo);
    otherMeasurementList.add(otherMeasurementThree);
    otherMeasurementList.add(otherMeasurementFour);
    return otherMeasurementList;
  }

  public ElectricalInput lookupElectricalInput(Long id) {
    ElectricalInput electricalInputOne = new ElectricalInput(1L);
    electricalInputOne.setInput("AI");
    return electricalInputOne;
  }

  public ElectricalOutput lookupElectricalOutput(Long id) {
    ElectricalOutput electricalOutputOne = new ElectricalOutput(1L);
    electricalOutputOne.setOutput("AO");
    return electricalOutputOne;
  }

  public OtherMeasurement lookupOtherMeasurement(Long id) {
    OtherMeasurement otherMeasurementOne = new OtherMeasurement(1L);
    otherMeasurementOne.setMeasurement("Level");
    return otherMeasurementOne;
  }

  public Electrical lookupElectrical(Long id) {
    Set<ElectricalInputQuantity> inputQuantities = new HashSet<ElectricalInputQuantity>();
    Set<ElectricalOutputQuantity> outputQuantities = new HashSet<ElectricalOutputQuantity>();
    Electrical electrical = new Electrical(null, true, true, true, null, new Integer(10), null, new Integer(20),
        "HMI Display", new OtherMeasurement(new Long(3)), "Communications", new Integer(100), createEquipment());
    electrical.setId(4L);
    ElectricalInput input = new ElectricalInput();
    input.setId(1L);
    electrical.setInput(input);
    ElectricalInputQuantity inputQuantity = new ElectricalInputQuantity(new Long(11), input, new Integer(10), electrical,
        true);
    inputQuantities.add(inputQuantity);
    ElectricalInput input1 = new ElectricalInput();
    input1.setId(2L);
    inputQuantity = new ElectricalInputQuantity(new Long(12), input1, new Integer(20), electrical, false);
    inputQuantities.add(inputQuantity);
    electrical.setInputQuantity(inputQuantities);

    ElectricalOutput output = new ElectricalOutput();
    output.setId(1L);
    electrical.setOutput(output);
    ElectricalOutputQuantity outputQuantity = new ElectricalOutputQuantity(new Long(13), output, new Integer(30), electrical,
        false);
    outputQuantities.add(outputQuantity);
    ElectricalOutput output1 = new ElectricalOutput();
    output1.setId(3L);
    outputQuantity = new ElectricalOutputQuantity(new Long(14), output1, new Integer(40), electrical, true);
    outputQuantities.add(outputQuantity);
    electrical.setOutputQuantity(outputQuantities);
    return electrical;
  }

  public ElectricalInputQuantity lookupInputQuantityByInputForElectrical(Long inputId, Long electricalId) {
    if (electricalId == null) {
      return null;
    }
    ElectricalInput input = new ElectricalInput(inputId);
    input.setInput("AI1");
    return new ElectricalInputQuantity(new Long(1234), input, null, null, false);
  }

  public ElectricalOutputQuantity lookupInputQuantityByOutputForElectrical(Long outputId, Long electricalId) {
    if (electricalId == null) {
      return null;
    }
    ElectricalOutput output = new ElectricalOutput(outputId);
    output.setOutput("AO1");
    return new ElectricalOutputQuantity(new Long(2345), output, null, null, false);
  }

  private Equipment createEquipment() {
    Equipment equipment = new Equipment("10.0.B0", "0.000.1W1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);
    Set<Motor> motors = new HashSet<Motor>();
    motors.add(new Motor());
    equipment.setMotors(motors);
    Set<Instrument> instruments = new HashSet<Instrument>();
    instruments.add(new Instrument());
    equipment.setInstruments(instruments);
    return equipment;
  }
}
