/*
 MockInstrumentService was created on Oct 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service.mock;

import com.monsanto.eas.eis.equipment.service.InstrumentService;
import com.monsanto.eas.eis.projects.domain.IOType;
import com.monsanto.eas.eis.projects.domain.InstrumentDesignator;
import com.monsanto.eas.eis.projects.domain.InstrumentType;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockInstrumentService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $
 * On:	$Date: 2009-01-21 18:28:35 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public class MockInstrumentService implements InstrumentService {
  public List<InstrumentDesignator> lookupAllInstrumentDesignatorsForFirstChar() {
    List<InstrumentDesignator> list = new ArrayList<InstrumentDesignator>();
    list.add(new InstrumentDesignator(new Long(11), "Analyzer", "A"));
    list.add(new InstrumentDesignator(new Long(12), "Voltage", "V"));
    return list;
  }

  public List<InstrumentDesignator> lookupAllInstrumentDesignatorsForSecondChar() {
    List<InstrumentDesignator> list = new ArrayList<InstrumentDesignator>();
    list.add(new InstrumentDesignator(new Long(13), "Indicating", "I"));
    list.add(new InstrumentDesignator(new Long(14), "Recording", "R"));
    list.add(new InstrumentDesignator(new Long(15), "Controlling", "C"));
    return list;
  }

  public List<IOType> lookupAllIOTypes() {
    List<IOType> list = new ArrayList<IOType>();
    IOType type = new IOType(new Long(16));
    type.setType("Analog");
    list.add(type);
    type = new IOType(new Long(17));
    type.setType("Discrete");
    list.add(type);
    return list;
  }

}