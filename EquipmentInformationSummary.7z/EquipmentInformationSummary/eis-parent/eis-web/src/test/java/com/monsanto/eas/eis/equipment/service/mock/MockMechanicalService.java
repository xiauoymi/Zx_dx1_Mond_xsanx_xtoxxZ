package com.monsanto.eas.eis.equipment.service.mock;

import com.monsanto.eas.eis.equipment.service.MechanicalService;
import com.monsanto.eas.eis.projects.domain.PurchaseScope;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Dec 8, 2008 Time: 6:25:43 PM To change this template use File | Settings
 * | File Templates.
 */
public class MockMechanicalService implements MechanicalService {
  public List<PurchaseScope> lookupAllPurchaseScopes() {
    List<PurchaseScope> list = new ArrayList<PurchaseScope>();
    PurchaseScope ps = new PurchaseScope(new Long(1));
    ps.setPurchaseScopeName("Contractor");
    list.add(ps);
    return list;
  }

  public PurchaseScope lookupPurchaseScopeById(Long id) {
    PurchaseScope ps = new PurchaseScope(new Long(1));
    ps.setPurchaseScopeName("Contractor");
    return ps;  
  }
}
