/*
 MockMotorService was created on Oct 20, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service.mock;

import com.monsanto.eas.eis.equipment.service.MotorService;
import com.monsanto.eas.eis.projects.domain.ComponentDesignator;
import com.monsanto.eas.eis.projects.domain.MotorDesignStatus;
import com.monsanto.eas.eis.projects.domain.MotorLoadValueType;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockMotorService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $ On:	$Date:
 * 2008/12/09 01:38:54 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class MockMotorService implements MotorService {

  public List<MotorDesignStatus> lookupAllDesignStatus() {
    List<MotorDesignStatus> list = new ArrayList<MotorDesignStatus>();
    MotorDesignStatus ds = new MotorDesignStatus(new Long(3));
    ds.setStatus("Preliminary");
    list.add(ds);
    ds = new MotorDesignStatus(new Long(4));
    ds.setStatus("Mechanical Confirmed");
    list.add(ds);
    ds = new MotorDesignStatus(new Long(5));
    ds.setStatus("Electrical Confirmed");
    list.add(ds);
    return list;
  }

  public List<MotorLoadValueType> lookupAllLoadValyeTypes() {
    List<MotorLoadValueType> list = new ArrayList<MotorLoadValueType>();
    MotorLoadValueType lv = new MotorLoadValueType(new Long(5));
    lv.setType("Horsepower");
    list.add(lv);
    lv = new MotorLoadValueType(new Long(6));
    lv.setType("kVA");
    list.add(lv);
    lv = new MotorLoadValueType(new Long(7));
    lv.setType("Horsepower 2");
    list.add(lv);
    lv = new MotorLoadValueType(new Long(8));
    lv.setType("kVA 2");
    list.add(lv);
    return list;
  }

  public List<ComponentDesignator> lookupAllComponentDesignators() {
    List<ComponentDesignator> list = new ArrayList<ComponentDesignator>();
    list.add(new ComponentDesignator(new Long(12), "FVNR Across Line Starter", "MA"));
    list.add(new ComponentDesignator(new Long(13), "FVR Reversing Starter", "MR"));
    list.add(new ComponentDesignator(new Long(14), "Unidentifed", "MU"));
    return list;
  }
}