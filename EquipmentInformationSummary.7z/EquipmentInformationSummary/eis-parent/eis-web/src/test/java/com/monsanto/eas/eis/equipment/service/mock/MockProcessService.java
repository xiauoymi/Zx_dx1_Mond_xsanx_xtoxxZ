/*
 MockProcessService was created on Oct 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.equipment.service.mock;

import com.monsanto.eas.eis.equipment.service.ProcessService;
import com.monsanto.eas.eis.projects.domain.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockProcessService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $ On:	$Date:
 * 2008/10/23 19:51:06 $
 *
 * @author sspati1
 * @version $Revision: 1.13 $
 */
public class MockProcessService implements ProcessService {
  public List<GasType> lookupAllGasTypes() {
    return getGasTypes();
  }

  public List<WaterType> lookupAllWaterTypes() {
    return getWaterTypes();
  }

  public List<DustType> lookupAllDustTypes() {
    return getDustTypes();
  }

  public List<FieldEquipmentType> lookupAllFieldEquipmentTypes(Long equipmentTypeId) {
    if (equipmentTypeId == null || equipmentTypeId.toString().equalsIgnoreCase("123")) {
      return getFieldEquipmentTypes();
    } else {
      return new ArrayList<FieldEquipmentType>();
    }
  }

  public List<DesignCapacityUnit> lookupAllDesignCapacityUnits() {
    return getDesignCapacityUnits();
  }

  public GasType lookupGasTypeById(Long id) {
    return getGasTypes().get(0);
  }

  public WaterType lookupWaterTypeById(Long id) {
    return getWaterTypes().get(0);
  }

  public DustType lookupDustTypeById(Long id) {
    return getDustTypes().get(0);
  }

  public DesignCapacityUnit lookupDesignCapacityUnitById(Long id) {
    return getDesignCapacityUnits().get(0);
  }

  public UnitMeasure lookupUnitMeasureById(Long id) {
    return getUnitMeasures().get(0);
  }

  public List<DesignCapacityUnit> lookupDesignCapacityUnitsByEquipmentTypeAndUnitMeasure(Long equipmentTypeId,
                                                                                         Long unitMeasureId) {
    return getDesignCapacityUnits();
  }

  public ProcessFieldEquipmentType lookupProcessFieldEquipmentTypeByFieldName(Long processId, String fieldName) {
    return new ProcessFieldEquipmentType(new Long(4444), null, null, null);
  }

  private List<GasType> getGasTypes() {
    List<GasType> types = new ArrayList<GasType>();
    GasType type = new GasType(Long.valueOf("1"));
    type.setType("Natural Gas");
    types.add(type);
    type = new GasType(Long.valueOf("2"));
    type.setType("Propane");
    types.add(type);
    return types;
  }

  private List<WaterType> getWaterTypes() {
    List<WaterType> types = new ArrayList<WaterType>();
    WaterType type = new WaterType(Long.valueOf("1"));
    type.setType("Process");
    types.add(type);
    type = new WaterType(Long.valueOf("2"));
    type.setType("Unprocessed");
    types.add(type);
    return types;
  }

  private List<DustType> getDustTypes() {
    List<DustType> types = new ArrayList<DustType>();
    DustType type = new DustType(Long.valueOf("1"));
    type.setType("Red Dust");
    types.add(type);
    type = new DustType(Long.valueOf("2"));
    type.setType("Blue Dust");
    types.add(type);
    return types;
  }

  private List<DesignCapacityUnit> getDesignCapacityUnits() {
    List<DesignCapacityUnit> types = new ArrayList<DesignCapacityUnit>();
    DesignCapacityUnit dcu = new DesignCapacityUnit(Long.valueOf("1"));
    dcu.setUnitName("unit name 1");
    types.add(dcu);
    dcu = new DesignCapacityUnit(Long.valueOf("2"));
    dcu.setUnitName("unit name 2");
    types.add(dcu);
    return types;
  }

  private List<UnitMeasure> getUnitMeasures() {
    List<UnitMeasure> types = new ArrayList<UnitMeasure>();
    types.add(new UnitMeasure(Long.valueOf("111"), "Unit Measure 1"));
    types.add(new UnitMeasure(Long.valueOf("222"), "Unit Measure 2"));
    return types;
  }

  private List<FieldEquipmentType> getFieldEquipmentTypes() {
    List<FieldEquipmentType> types = new ArrayList<FieldEquipmentType>();
    FieldType ft = new FieldType();
    ft.setType("text");
    FieldEquipmentType fet = new FieldEquipmentType(ft, "testFE1", "My Comments", 3, "Integer",
        new EquipmentType(new Long(12), "Sheller", "S"), new ArrayList<ListValue>(), 0);
    types.add(fet);
    fet = new FieldEquipmentType(ft, "testFE2", "My Comments", 3, "Integer",
        new EquipmentType(new Long(12), "Sheller", "S"), new ArrayList<ListValue>(), 0);
    types.add(fet);
    ft = new FieldType();
    ft.setType("select");
    fet = new FieldEquipmentType(ft, "testFE3", "My Comments", 3, "Integer",
        new EquipmentType(new Long(12), "Sheller", "S"), new ArrayList<ListValue>(), 0);
    types.add(fet);
    return types;
  }

}