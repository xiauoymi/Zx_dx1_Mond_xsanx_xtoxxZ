package com.monsanto.eas.eis.importdata;

import junit.framework.TestCase;
import com.monsanto.eas.eis.projects.dao.LocationDAO;
import com.monsanto.eas.eis.projects.dao.LocationDAOImpl;
import com.monsanto.eas.eis.logon.hibernateMappings.User;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Feb 10, 2009
 * Time: 11:35:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class LoadUserData_AT extends TestCase {

  public void testLoadLocationData_OneRegion() throws Exception{
    UserLoaderImpl locationLoader = new UserLoaderImpl(new UserDataReaderImpl());
    locationLoader.loadLocationData();
    System.out.println("Done");
  }

}
