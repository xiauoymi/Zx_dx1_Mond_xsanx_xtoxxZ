package com.monsanto.eas.eis.importdata;

import java.util.List;
import java.io.InputStream;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jan 30, 2009
 * Time: 3:55:57 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LocationDataReader {
  List<LocationInfo> getData(String inputFilePath);
}
