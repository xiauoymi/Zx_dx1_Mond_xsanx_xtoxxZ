package com.monsanto.eas.eis.importdata;

import com.monsanto.spreadsheet.MultisheetWorkbook;
import com.monsanto.spreadsheet.ContentSet;
import com.monsanto.spreadsheet.EmptyFileException;
import com.monsanto.spreadsheet.xmlspreadsheet.XMLSpreadsheet;
import com.monsanto.spreadsheet.xmlspreadsheet.XMLContentSet;
import com.monsanto.spreadsheet.exception.SpreadsheetException;

import java.util.List;
import java.util.ArrayList;
import java.io.IOException;

import org.apache.commons.lang.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jan 30, 2009
 * Time: 3:56:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationDataReaderImpl implements LocationDataReader {
  public List<LocationInfo> getData(String inputFilePath) {
    List<LocationInfo> locationInfoList = new ArrayList();
    LocationInfo locationInfo;
    try {
      MultisheetWorkbook spreadsheet = new XMLSpreadsheet(new XMLContentSet());
      ContentSet content = spreadsheet.getContent(inputFilePath, false, 0);
      while(content.next()){
        String worldArea = content.getString(0);
        String country = content.getString(1);
        String state = content.getString(2);
        String city = content.getString(3);
        String plantCode = content.getString(4);
        String plantName = content.getString(5);
        if(!StringUtils.isEmpty(worldArea) && !StringUtils.isEmpty(country) && !StringUtils.isEmpty(state) && !StringUtils.isEmpty(city) &&
            !city.equalsIgnoreCase("#N/A") && !city.equalsIgnoreCase("0") && !state.equalsIgnoreCase("#N/A") && !state.equalsIgnoreCase("0")
            && !country.equalsIgnoreCase("#N/A") && !country.equalsIgnoreCase("0") && !worldArea.equalsIgnoreCase("#N/A") && !worldArea.equalsIgnoreCase("0"))   {
          locationInfo = new LocationInfo(worldArea, country, state, city, plantCode, plantName);
          locationInfoList.add(locationInfo);
        }
      }
    } catch (EmptyFileException e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    } catch (IOException e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    } catch (SpreadsheetException e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    }

    return locationInfoList;  //To change body of implemented methods use File | Settings | File Templates.
  }
}
