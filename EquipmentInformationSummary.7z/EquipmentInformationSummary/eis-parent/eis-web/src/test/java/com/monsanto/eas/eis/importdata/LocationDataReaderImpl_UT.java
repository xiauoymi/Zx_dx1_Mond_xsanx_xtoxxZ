package com.monsanto.eas.eis.importdata;

import junit.framework.TestCase;

import java.util.List;
import java.net.URL;

import com.monsanto.wst.commonutils.resources.ResourceUtils;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jan 30, 2009
 * Time: 3:24:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationDataReaderImpl_UT extends TestCase {

  public void testReadData()throws Exception{
//    LocationDataReader locationData = new LocationDataReaderImpl();
//    URL url = this.getClass().getResource("Location_Data_3.xlsx");
//    List<LocationInfo> locationInfo = locationData.getData(url.getPath());
//    int size = locationInfo.size();
//    assertEquals(26,size);
  }
}
