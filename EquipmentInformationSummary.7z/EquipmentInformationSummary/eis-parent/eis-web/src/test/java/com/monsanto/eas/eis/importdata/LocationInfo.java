package com.monsanto.eas.eis.importdata;

/**
 * Created by IntelliJ IDEA.
 * User: vrbethi
 * Date: Jan 30, 2009
 * Time: 3:51:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationInfo {
  private String worldArea;
  private String country;
  private String state;
  private String city;

  public LocationInfo(String worldArea, String country, String state, String city, String plantCode, String plantName) {
    //To change body of created methods use File | Settings | File Templates.
    this.worldArea = worldArea;
    this.country = country;
    this.state = state;
    this.city = city;
  }

  public String getWorldArea() {
    return worldArea;
  }

  public String getCountry() {
    return country;
  }

  public String getState() {
    return state;
  }

  public String getCity() {
    return city;
  }
}
