package com.monsanto.eas.eis.importdata;

import junit.framework.TestCase;

import java.util.List;
import java.util.ArrayList;

import com.monsanto.eas.eis.projects.dao.LocationDAO;
import com.monsanto.eas.eis.projects.dao.LocationDAOImpl;
import com.monsanto.eas.eis.projects.domain.Location;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Feb 2, 2009
 * Time: 11:23:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class LocationLaoderImpl_UT extends TestCase {

  public void testLoadLocationData_OneRegion() throws Exception{
//    LocationDataReader locationDataReader = new MockLocationDataReaderImpl();
//    LocationDAO locationDAO = new MockLocationDAOImplLoadData();
//    LocationLoader locationLoader = new LocationLoaderImpl(locationDataReader,locationDAO);
//    locationLoader.loadLocationData();
//    List<Location> locationList = ((MockLocationDAOImplLoadData) locationDAO).getLocationList();
//    assertEquals("North America",locationList.get(0).getName());
//    assertEquals(3,locationList.size());

  }

  class MockLocationDataReaderImpl extends LocationDataReaderImpl{
    public List<LocationInfo> getData(String inputFilePath) {
      List<LocationInfo> locationList = new ArrayList();
      locationList.add(new LocationInfo("North America","USA","Missouri","St.louis","1000","Main Campus"));
      locationList.add(new LocationInfo("North America","USA","Missouri","Chesterfield","1001","Chesterfield Campus"));
      locationList.add(new LocationInfo("Europe Africa","Belgium","Antwerpen","ANTWERPEN","1001","Chesterfield Campus"));
      locationList.add(new LocationInfo("Asia Pacific","Pakistan","Punjab","LAHORE","1001","Chesterfield Campus"));
      locationList.add(new LocationInfo("Asia Pacific","Philippines","South Cotabato","GENERAL SANTOS CITY","1001","Chesterfield Campus"));
      locationList.add(new LocationInfo("Asia Pacific","Malaysia","Johor PASIR GUDANG","JOHOR","1001","Chesterfield Campus"));
      locationList.add(new LocationInfo("Asia Pacific","India","Dadra und Nagar Hav","SILVASSA","1001","Chesterfield Campus"));
      locationList.add(new LocationInfo("Asia Pacific","India","Andra Pradesh","ELURU","1001","Chesterfield Campus"));
      return locationList;
    }
  }

  class MockLocationDAOImplLoadData extends LocationDAOImpl{
    private List<Location> locationList= new ArrayList();
    private Location location;

    public Location save(Location location) {
      this.location = location;
      locationList.add(location);
      return null;    //To change body of overridden methods use File | Settings | File Templates.
    }

    public Location getLocation() {
      return location;
    }

    public List<Location> getLocationList() {
      return locationList;
    }
  }
}
