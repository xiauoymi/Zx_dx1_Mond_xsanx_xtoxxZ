package com.monsanto.eas.eis.importdata;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Feb 2, 2009
 * Time: 11:29:09 AM
 * To change this template use File | Settings | File Templates.
 */
public interface LocationLoader {
  void loadLocationData();
}
