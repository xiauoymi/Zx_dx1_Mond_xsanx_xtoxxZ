package com.monsanto.eas.eis.importdata;

import com.monsanto.eas.eis.projects.dao.LocationDAO;
import com.monsanto.eas.eis.projects.domain.Location;
import com.monsanto.wst.hibernate.HibernateFactoryImpl;
import com.monsanto.wst.hibernate.HibernateFactory;

import java.util.List;
import java.util.ArrayList;
import java.net.URL;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Feb 2, 2009
 * Time: 11:29:16 AM
 * To change this template use File | Settings | File Templates.
 */
public class LocationLoaderImpl implements LocationLoader {
  private LocationDataReader locationDataReader;
  private LocationDAO locationDAO;
  private Location parentLocationONe;

  public LocationLoaderImpl(LocationDataReader locationDataReader, LocationDAO locationDAO) {
    this.locationDataReader = locationDataReader;
    this.locationDAO = locationDAO;
  }

  public void loadLocationData() {
    HibernateFactory instance = HibernateFactoryImpl.getInstance("eis");
    instance.beginTransaction();
    List<Location> processedData = locationDAO.findByRegion();
    URL url = this.getClass().getResource("Location_Data_2.xlsx");
    List<LocationInfo> data = locationDataReader.getData(url.getPath());
//    List<Location> processedData = new ArrayList();
    for(int i=0; i<data.size();i++){
      LocationInfo locationInfo = data.get(i);
      Location location = new Location();
      location.setName(locationInfo.getWorldArea());
      addNodeIfNotPresent(processedData, location);
      List<Location> countryList = addChild(processedData, locationInfo.getWorldArea(), locationInfo.getCountry());
      List<Location> stateList = addChild(countryList, locationInfo.getCountry(), locationInfo.getState());
      addChild(stateList,locationInfo.getState(),locationInfo.getCity());
    }

    for(int i=0;i<processedData.size();i++){
      parentLocationONe = processedData.get(i);
      Location parentLocation = locationDAO.save(parentLocationONe);
      List<Location> childLocationList = parentLocation.getChildLocations();
      saveChildren(parentLocation, childLocationList);
    }
    instance.commitTransaction();
  }

  private void saveChildren(Location parentLocation, List<Location> childLocationList) {
    for(int j=0;j<childLocationList.size();j++){
      Location childLocation = childLocationList.get(j);
      childLocation.setParentLocation(parentLocation);
      locationDAO.save(childLocation);
      if(childLocation.getChildLocations()!=null){
        saveChildren(childLocation, childLocation.getChildLocations());
      }
    }
  }

  private List<Location> addChild(List<Location> processedData, String parentName, String childName) {
    for(int j=0; j<processedData.size(); j++){
      Location parentLocation = processedData.get(j);
      if(parentLocation.getName().equalsIgnoreCase(parentName)){
        List<Location> childLocationList = parentLocation.getChildLocations();
        Location countryLocation = new Location();
        countryLocation.setName(childName);
        addNodeIfNotPresent(childLocationList,countryLocation);
        return childLocationList;
      }
    }
    return null;
  }

  private void addNodeIfNotPresent(List<Location> processedData, Location location) {
    if(!processedData.contains(location)){
      processedData.add(location);
    }
  }
}
