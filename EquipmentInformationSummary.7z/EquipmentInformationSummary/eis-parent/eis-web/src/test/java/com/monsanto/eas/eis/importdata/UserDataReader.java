package com.monsanto.eas.eis.importdata;


import com.monsanto.eas.eis.logon.hibernateMappings.User;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Feb 10, 2009
 * Time: 10:36:03 AM
 * To change this template use File | Settings | File Templates.
 */
public interface UserDataReader {
  List<User> getData(String path);
}
