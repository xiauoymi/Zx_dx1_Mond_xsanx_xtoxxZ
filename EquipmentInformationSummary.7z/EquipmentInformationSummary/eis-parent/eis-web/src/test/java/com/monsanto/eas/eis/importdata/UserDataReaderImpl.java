package com.monsanto.eas.eis.importdata;

import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.spreadsheet.MultisheetWorkbook;
import com.monsanto.spreadsheet.ContentSet;
import com.monsanto.spreadsheet.EmptyFileException;
import com.monsanto.spreadsheet.exception.SpreadsheetException;
import com.monsanto.spreadsheet.xmlspreadsheet.XMLSpreadsheet;
import com.monsanto.spreadsheet.xmlspreadsheet.XMLContentSet;

import java.util.List;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.io.IOException;

import org.apache.commons.lang.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Feb 10, 2009
 * Time: 10:53:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class UserDataReaderImpl implements UserDataReader{
  public List<User> getData(String path) {
    List<User> userList = new ArrayList();
    try {
      MultisheetWorkbook spreadsheet = new XMLSpreadsheet(new XMLContentSet());
      ContentSet content = spreadsheet.getContent(path, false, 0);
      while(content.next()){
        String userName = content.getString(0);
        String[] strings = userName.split(" ");
        User user= new User();
//        user.setFirstName(strings[0]);
//    /    user.setLastName(strings[1]);
        userList.add(user);
      }
    } catch (EmptyFileException e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    } catch (IOException e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    } catch (SpreadsheetException e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    }

    return userList;  //To change body of implemented methods use File | Settings | File Templates.

  }
}
