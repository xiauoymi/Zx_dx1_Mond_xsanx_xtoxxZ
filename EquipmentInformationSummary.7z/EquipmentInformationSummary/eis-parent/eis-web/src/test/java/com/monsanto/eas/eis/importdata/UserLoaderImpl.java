package com.monsanto.eas.eis.importdata;

import com.monsanto.eas.eis.projects.dao.LocationDAO;
import com.monsanto.eas.eis.projects.domain.Location;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.logon.hibernateMappings.Role;
import com.monsanto.eas.eis.logon.hibernateMappings.UserRole;
import com.monsanto.eas.eis.logon.hibernateMappings.UserRoleId;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.hibernate.HibernateFactoryImpl;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.PeoplePicker.PeopleService;
import com.monsanto.PeoplePicker.PersonInfo;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.net.URL;

/**
 * Created by IntelliJ IDEA.
 * User: VRBETHI
 * Date: Feb 2, 2009
 * Time: 11:29:16 AM
 * To change this template use File | Settings | File Templates.
 */
public class UserLoaderImpl implements LocationLoader {
  GenericDAO<User, Long> userDao;
  private UserDataReader userDataReader;

  public UserLoaderImpl(UserDataReader userDataReader) {
    this.userDao = new HibernateDAO<User, Long>(EISHibernateUtil.getHibernateFactory(), User.class);
    this.userDataReader= userDataReader;
  }

  public void loadLocationData() {
    HibernateFactory instance = HibernateFactoryImpl.getInstance("eis");
    instance.beginTransaction();
    List<User> users = userDao.findAll();
    URL url = this.getClass().getResource("UserData.xlsx");
    List<User> data = userDataReader.getData(url.getPath());
    for(int i=0; i<data.size();i++){
      User user = setUserId(data, i);
      if(!users.contains(user)){
         users.add(user);
      }


//      Set<Role> roleSet = user.getRoles();
//      roleSet.add(new Role(new Long(8),user.getUserId()));

//      List<UserRole> roleList = user.getUserRoles();
//      roleList.add(new UserRole(new UserRoleId(user,new Role())));
    }
    for(int i=0;i<users.size();i++){
      User user = users.get(i);
      userDao.save(user);
    }
    instance.commitTransaction();
  }

  private User setUserId(List<User> data, int i) {
    User user = data.get(i);
    PeopleService svc = new PeopleService();
    try {
      PersonInfo[] person = svc.GetPeople(user.getLastName(), user.getFirstName(), "", "", "", "", "");
      if(person==null || (person!=null && person.length==0)){
//        user.setUserId("UNKWN");
      } else if(person!=null && person.length>1){
//   /       user.setUserId("MTO");
      } else if(person.length==1){
//        user.setUserId(person[0].getUserId());
      }else{
//        user.setUserId("UNKWN");
      }
    } catch (Exception e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    }
    return user;
  }
}