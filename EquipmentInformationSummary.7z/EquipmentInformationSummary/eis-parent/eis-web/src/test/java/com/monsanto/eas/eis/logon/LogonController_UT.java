package com.monsanto.eas.eis.logon;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.logon.controller.LogonController;
import com.monsanto.eas.eis.logon.hibernateMappings.Role;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.logon.mock.MockUCCHelperEIS;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.projects.services.UserService;
import com.monsanto.eas.eis.projects.services.mock.MockUserService;
import com.monsanto.eas.eis.alert.controller.AlertController;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import junit.framework.TestCase;
import org.hibernate.Criteria;

import java.io.IOException;
import java.util.HashSet;

/**
 * Created by IntelliJ IDEA. User: AFHYAT Date: Jul 22, 2008 Time: 1:22:27 PM To change this template use File |
 * Settings | File Templates.
 */
public class LogonController_UT extends TestCase {

  protected void setUp() throws Exception {
    super.setUp();
  }

  public void testRun_UserExistsAndAuthorized_ForwardToHomePage() throws IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    HashSet<Role> roles = new HashSet<Role>();
    roles.add(new Role(new Long(12), "eis_user"));
    User user = new User(new Long(123), "testId", "testFirst", "testLast", roles, null);
    UserService userService = new MockUserService(false, false, false, null, user);
    MockLogonController controller = new MockLogonController(userService);
    controller.run(helper);
    MockAlertController alertController = (MockAlertController) controller.getMockAlertController();
    assertTrue(alertController.isWasRunCalled());
    assertFalse(helper.wasSentTo("/WEB-INF/jsp/home.jspx"));
    User logonUser = (User) helper.getSessionParameter(EISConstants.LOGIN_USER);
    assertEquals("testId", logonUser.getUserId());
  }

  public void testRun_UserExistsButNotAuthorized_ForwardToUnAutorizedPage() throws IOException {
    MockUCCHelper helper = new MockUCCHelperEIS(null);
    HashSet<Role> roles = new HashSet<Role>();
    User user = new User(new Long(123), "testId", "testFirst", "testLast", roles, null);
    UserService userService = new MockUserService(false, false, false, null, user);
    LogonController controller = new LogonController(userService);
    controller.run(helper);
    assertTrue(helper.wasSentTo("/WEB-INF/jsp/unauthorizedUser.jspx"));
    assertNull(helper.getSessionParameter(EISConstants.LOGIN_USER));
  }

  public void testRun_UserDoesNotExist_ForwardToUnAutorizedPage() throws IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    UserService userService = new MockUserService(false, false, false, null, null);
    LogonController controller = new LogonController(userService);
    controller.run(helper);
    assertTrue(helper.wasSentTo("/WEB-INF/jsp/unauthorizedUser.jspx"));
    assertNull(helper.getSessionParameter(EISConstants.LOGIN_USER));
  }

  public void testRun_UserExistButErrorOccured_ForwardToErrorPage() throws IOException {
    MockUCCHelper helper = new MockUCCHelperEIS(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "error");
    HashSet<Role> roles = new HashSet<Role>();
    roles.add(new Role(new Long(12), "eis_user"));
    User user = new User(new Long(123), "testId", "testFirst", "testLast", roles, null);
    UserService userService = new MockUserService(false, false, false, null, user);
    LogonController controller = new LogonController(userService);
    controller.run(helper);
    assertTrue(helper.wasSentTo(EISConstants.ERROR_JSP));
    assertNotNull(helper.getSessionParameter(EISConstants.LOGIN_USER));
  }

  private class MockUserDAO<T, T1> extends HibernateDAO<User, Long> {
    User user;
    MockCriteriaForEIS criteria;

    private MockUserDAO(HibernateFactory hibernateFactory, Class<? extends User> aClass, User user) {
      super(hibernateFactory, aClass);
      this.user = user;
    }

    public Criteria createCriteria() {
      criteria = new MockCriteriaForEIS(user, null);
      return criteria;
    }

    public MockCriteriaForEIS getCriteria() {
      return criteria;
    }
  }

  private class MockLogonController extends LogonController {
    MockAlertController mockAlertController;

    private MockLogonController(UserService userService) {
      super(userService);
    }
    //protected onlt for testing
    protected AlertController getAlertController() {
      mockAlertController = new MockAlertController();
      return mockAlertController;
    }

    public MockAlertController getMockAlertController() {
      return mockAlertController;
    }
  }

  private class MockAlertController extends AlertController {
    private boolean wasRunCalled;

    protected void notSpecified(UCCHelper helper) throws IOException {
      this.wasRunCalled = true;
    }

    public boolean isWasRunCalled() {
      return wasRunCalled;
    }
  }
}
