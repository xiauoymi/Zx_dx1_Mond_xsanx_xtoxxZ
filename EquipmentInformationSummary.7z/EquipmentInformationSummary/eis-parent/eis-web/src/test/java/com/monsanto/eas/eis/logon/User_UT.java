/*
 User_UT was created on Jan 21, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.logon;

import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.logon.hibernateMappings.Role;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.XMLUtil.DOMUtil;

import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;

import org.w3c.dom.Document;
import org.custommonkey.xmlunit.XMLTestCase;

/**
 * Filename:    $RCSfile: User_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-03-25 15:19:05 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class User_UT extends XMLTestCase {

  public void testIsAuthorized_HasAccess_ReturnsTrue() throws Exception {
    Set<Role> roles = new HashSet<Role>();
    roles.add(new Role(new Long(11), "eis_test"));
    roles.add(new Role(new Long(12), "eis_user"));
    User user = new User(null, "testId", null, null, roles, null);
    assertTrue(user.getIsAuthorized());
  }

  public void testIsAuthorized_NoAccess_ReturnsFalse() throws Exception {
    Set<Role> roles = new HashSet<Role>();
    roles.add(new Role(new Long(11), "eis_test"));
    roles.add(new Role(new Long(12), "eis_user1"));
    User user = new User(null, "testId", null, null, roles, null);
//    assertFalse(user.getIsAuthorized());
  }

  public void testGetIsProcessTeamLead_IsLead_ReturnsTrue() throws Exception {
    Set<Role> roles = new HashSet<Role>();
    roles.add(new Role(new Long(11), "eis_test"));
    roles.add(new Role(new Long(12), "eis_team_lead"));
    User user = new User(null, "testId", null, null, roles, null);
    assertTrue(user.getIsProcessTeamLead());
  }

  public void testGetIsProcessTeamLead_IsNotLead_ReturnsFalse() throws Exception {
    Set<Role> roles = new HashSet<Role>();
    roles.add(new Role(new Long(11), "eis_test"));
    roles.add(new Role(new Long(12), "eis_user1"));
    User user = new User(null, "testId", null, null, roles, null);
    assertFalse(user.getIsProcessTeamLead());
  }

  public void testEquals_SameUserId_ReturnsTrue() throws Exception {
    User user1 = new User(null, "testId", null, null, null, null);
    User user2 = new User(null, "testId", null, null, null, null);
    assertTrue(user1.equals(user2));
  }
  
  public void testEquals_UserIdNotSame_ReturnsTrue() throws Exception {
    User user1 = new User(null, "testId", null, null, null, null);
    User user2 = new User(null, "testId1", null, null, null, null);
    assertFalse(user1.equals(user2));
  }

  public void testToXml_VerifyXml() throws Exception {
    User user = new User(new Long(123), "testId", "testFirst", "testLast", null, null);
    Document xmlDoc = DOMUtil.stringToXML(user.toXml());
    assertXpathEvaluatesTo("1", "count(//user)", xmlDoc);
    assertXpathEvaluatesTo("123", "//user/userId", xmlDoc);
    assertXpathEvaluatesTo("testLast, testFirst", "//user/name", xmlDoc);
  }

  public void testDoesUserHaveEditAccessToThisProject_HasEditAccessToThisProject_ReturnsTrue() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    ProjectRole projRole = new ProjectRole(null, null, new AccessType(null, "edit"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    User user = new User(new Long(123), "testId", "testFirst", "testLast", null, projUserRoles);
    Projects thisProject = new Projects();
    thisProject.setId(new Long(123));
    boolean hasAccess = user.doesUserHaveEditAccessToThisProject(thisProject);
    assertTrue(hasAccess);
  }

  public void testDoesUserHaveEditAccessToThisProject_HasViewAndEditAccessToThisProject_ReturnsTrue() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    ProjectRole projRole = new ProjectRole(null, null, new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    projRole = new ProjectRole();
    projRole = new ProjectRole(null, null, new AccessType(null, "edit"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    User user = new User(new Long(123), "testId", "testFirst", "testLast" ,null, projUserRoles);
    Projects thisProject = new Projects();
    thisProject.setId(new Long(123));
    boolean hasAccess = user.doesUserHaveEditAccessToThisProject(thisProject);
    assertTrue(hasAccess);
  }

  public void testDoesUserHaveEditAccessToThisProject_DoesNotHaveEditAccessToThisProject_ReturnsFalse() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    ProjectRole projRole = new ProjectRole(null, null, new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    User user = new User(new Long(123), "testId", "testFirst", "testLast", null, projUserRoles);
    Projects thisProject = new Projects();
    thisProject.setId(new Long(123));
    boolean hasAccess = user.doesUserHaveEditAccessToThisProject(thisProject);
    assertFalse(hasAccess);
  }

  public void testDoesUserHaveEditAccessToThisProject_DoesNotHaveAccessToThisProject_ReturnsFalse() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    ProjectRole projRole = new ProjectRole(null, null, new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    User user = new User(new Long(123), "testId", "testFirst", "testLast", null, projUserRoles);
    Projects thisProject = new Projects();
    thisProject.setId(new Long(1234));
    boolean hasAccess = user.doesUserHaveEditAccessToThisProject(thisProject);
    assertFalse(hasAccess);
  }

  public void testIsUserInMechanicalEngineerRoleForThisProject_HasTheRole_ReturnsTrue() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    ProjectRole projRole = new ProjectRole(null, "mechanical engineer", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    User user = new User(new Long(345), "testId", "testFirst", "testLast", null, projUserRoles);
    Projects thisProject = new Projects();
    thisProject.setId(new Long(123));
    boolean hasAccess = user.isUserInMechanicalEngineerRoleForThisProject(thisProject);
    assertTrue(hasAccess);
  }

  public void testIsUserInMechanicalEngineerRoleForThisProject_DoesNotHaveThisRole_ReturnsFalse() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    ProjectRole projRole = new ProjectRole(null, "not mech eng", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    User user = new User(new Long(345), "testId", "testFirst", "testLast", null, projUserRoles);
    Projects thisProject = new Projects();
    thisProject.setId(new Long(1234));
    boolean hasAccess = user.isUserInMechanicalEngineerRoleForThisProject(thisProject);
    assertFalse(hasAccess);
  }

  public void testIsUserInMechanicalEngineerRoleForThisProject_DoesNotHaveAccessToThisProjectAtAll_ReturnsFalse() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    ProjectRole projRole = new ProjectRole(null, null, new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    User user = new User(new Long(345), "testId", "testFirst", "testLast", null, projUserRoles);
    Projects thisProject = new Projects();
    thisProject.setId(new Long(1234));
    boolean hasAccess = user.isUserInMechanicalEngineerRoleForThisProject(thisProject);
    assertFalse(hasAccess);
  }

  public void testDoesUserHaveEditAccessToThisProject_HasAProcessRole_ReturnsTrue() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    ProjectRole projRole = new ProjectRole(null, "process engineer", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    User user = new User(new Long(345), "testId", "testFirst", "testLast", null, projUserRoles);
    Projects thisProject = new Projects();
    thisProject.setId(new Long(123));
    boolean hasAccess = user.isUserInProcessRoleForThisProject(thisProject);
    assertTrue(hasAccess);
  }

  public void testDoesUserHaveEditAccessToThisProject_DoesNotHaveAProcessRole_ReturnsFalse() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    ProjectRole projRole = new ProjectRole(null, "not process eng", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    User user = new User(new Long(345), "testId", "testFirst", "testLast", null, projUserRoles);
    Projects thisProject = new Projects();
    thisProject.setId(new Long(1234));
    boolean hasAccess = user.isUserInProcessRoleForThisProject(thisProject);
    assertFalse(hasAccess);
  }

  public void testDoesUserHaveEditAccessToThisProject_DoesNotHaveAccessToThisProjectAtAll_ReturnsFalse() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    ProjectRole projRole = new ProjectRole(null, null, new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    User user = new User(new Long(345), "testId", "testFirst", "testLast", null, projUserRoles);
    Projects thisProject = new Projects();
    thisProject.setId(new Long(1234));
    boolean hasAccess = user.isUserInProcessRoleForThisProject(thisProject);
    assertFalse(hasAccess);
  }

  public void testLookupProjectsByRolesAndStatus_NullStatusPassed_ReturnsProjects() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    ProjectRole projRole = new ProjectRole(null, "role 1", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));

    project = new Projects();
    project.setId(new Long(234));
    projRole = new ProjectRole(null, "role3", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));

    project = new Projects();
    project.setId(new Long(345));
    projRole = new ProjectRole(null, "role2", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));

    User user = new User(new Long(345), "testId", "testFirst", "testLast", null, projUserRoles);
    String[] roleNames = new String[3];
    roleNames[0] = "role 1";
    roleNames[1] = "role2";
    roleNames[2] = "ROLE 3";
    List<Projects> projects = user.lookupProjectsByRolesAndStatus(roleNames, null);
    assertEquals(2, projects.size());
    assertEquals(new Long(123), projects.get(0).getId());
    assertEquals(new Long(345), projects.get(1).getId());
  }

  public void testLookupProjectsByRolesAndStatus_EmptyStatusPassed_ReturnsProjects() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    ProjectRole projRole = new ProjectRole(null, "role 1", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));

    project = new Projects();
    project.setId(new Long(234));
    projRole = new ProjectRole(null, "role3", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));

    project = new Projects();
    project.setId(new Long(345));
    projRole = new ProjectRole(null, "role2", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));

    User user = new User(new Long(345), "testId", "testFirst", "testLast", null, projUserRoles);
    String[] roleNames = new String[3];
    roleNames[0] = "role 1";
    roleNames[1] = "role2";
    roleNames[2] = "ROLE 3";
    List<Projects> projects = user.lookupProjectsByRolesAndStatus(roleNames, "");
    assertEquals(2, projects.size());
    assertEquals(new Long(123), projects.get(0).getId());
    assertEquals(new Long(345), projects.get(1).getId());
  }

  public void testLookupProjectsByRolesAndStatus_StatusPassed_ReturnsProjects() throws Exception {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(new Long(123));
    project.setProjStatus(new ProjectStatus(null, "STATUS 1"));
    ProjectRole projRole = new ProjectRole(null, "role 1", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    projRole = new ProjectRole(null, "role2", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));

    project = new Projects();
    project.setId(new Long(234));
    project.setProjStatus(new ProjectStatus(null, "status 1"));
    projRole = new ProjectRole(null, "role3", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));

    project = new Projects();
    project.setId(new Long(345));
    project.setProjStatus(new ProjectStatus(null, "STATUS 2"));
    projRole = new ProjectRole(null, "role2", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));

    User user = new User(new Long(345), "testId", "testFirst", "testLast", null, projUserRoles);
    String[] roleNames = new String[3];
    roleNames[0] = "role 1";
    roleNames[1] = "role2";
    roleNames[2] = "ROLE 3";
    List<Projects> projects = user.lookupProjectsByRolesAndStatus(roleNames, "STATUS 1");
    assertEquals(1, projects.size());
    assertEquals(new Long(123), projects.get(0).getId());
  }
}