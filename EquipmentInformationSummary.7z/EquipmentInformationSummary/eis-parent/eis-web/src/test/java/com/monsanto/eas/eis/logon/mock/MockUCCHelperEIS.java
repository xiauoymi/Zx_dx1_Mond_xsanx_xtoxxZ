package com.monsanto.eas.eis.logon.mock;

import com.monsanto.ServletFramework.Test.MockUCCHelper;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 20, 2008 Time: 9:22:34 AM To change this template use File |
 * Settings | File Templates.
 */
public class MockUCCHelperEIS extends MockUCCHelper {

    public MockUCCHelperEIS(String s) {
      super(s);
    }

    public String getAuthenticatedUserID() {
      return "testId";
    }
  }


