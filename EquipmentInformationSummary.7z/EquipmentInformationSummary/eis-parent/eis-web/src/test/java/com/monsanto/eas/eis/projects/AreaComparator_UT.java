/*
 AreaComparator_UT was created on Feb 6, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects;

import com.monsanto.eas.eis.projects.domain.Area;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AreaComparator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-10 16:56:08 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class AreaComparator_UT extends TestCase {
  public void testCompare_AreaAreNull_ReturnsNegativeOne() throws Exception {
    AreaComparator comparator = new AreaComparator();
    assertEquals(-1, comparator.compare(null, null));
  }

  public void testCompare_ReturnsNegativeOne() throws Exception {
    Area area1 = new Area(null, "area 1", null);
    Area area2 = new Area(null, "area 2", null);
    AreaComparator comparator = new AreaComparator();
    assertEquals(-1, comparator.compare(area1, area2));
  }

  public void testCompare_RetursnsOne() throws Exception {
    Area area1 = new Area(null, "area 1", null);
    Area area2 = new Area(null, "area 2", null);
    AreaComparator comparator = new AreaComparator();
    assertEquals(1, comparator.compare(area2, area1));
  }

  public void testCompare_RetursnsZero() throws Exception {
    Area area1 = new Area(null, "area 1", null);
    Area area2 = new Area(null, "area 1", null);
    AreaComparator comparator = new AreaComparator();
    assertEquals(0, comparator.compare(area2, area1));
  }
}