package com.monsanto.eas.eis.projects;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: vvvelu
 * Date: Oct 5, 2008
 * Time: 5:11:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class GenerateRandomProjectNumber {

  public static List<String> randomList() {
    List<String> list = new ArrayList<String>(36);
    list.add("A");
    list.add("B");
    list.add("C");
    list.add("D");
    list.add("E");
    list.add("F");
    list.add("G");
    list.add("H");
    list.add("I");
    list.add("J");
    list.add("K");
    list.add("L");
    list.add("M");
    list.add("N");
    list.add("O");
    list.add("P");
    list.add("Q");
    list.add("R");
    list.add("S");
    list.add("T");
    list.add("U");
    list.add("V");
    list.add("W");
    list.add("X");
    list.add("Y");
    list.add("Z");
    list.add("0");
    list.add("1");
    list.add("2");
    list.add("3");
    list.add("4");
    list.add("5");
    list.add("6");
    list.add("7");
    list.add("8");
    list.add("9");
    return list;
  }

  public static String chooseRandomFromList(List<String> list) {
    int maxRandom = list.size() - 1;
    int randomIndex = (int) Math.round(Math.random() * maxRandom);
    return list.get(randomIndex);
  }

  public static String createRandomWithEightChars() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(chooseRandomFromList(randomList()));
    stringBuffer.append(chooseRandomFromList(randomList()));
    stringBuffer.append(chooseRandomFromList(randomList()));
    stringBuffer.append(chooseRandomFromList(randomList()));
    stringBuffer.append(chooseRandomFromList(randomList()));
    stringBuffer.append(chooseRandomFromList(randomList()));
    stringBuffer.append(chooseRandomFromList(randomList()));
    stringBuffer.append(chooseRandomFromList(randomList()));
    return stringBuffer.toString();
  }


}
