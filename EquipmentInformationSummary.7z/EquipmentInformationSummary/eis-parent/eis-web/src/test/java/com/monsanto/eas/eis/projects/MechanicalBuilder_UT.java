package com.monsanto.eas.eis.projects;

import junit.framework.TestCase;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.projects.domain.Mechanical;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.equipment.MechanicalBuilder;
import com.monsanto.eas.eis.equipment.service.mock.MockMechanicalService;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 20, 2008 Time: 9:36:22 AM To change this template use File |
 * Settings | File Templates.
 */
public class MechanicalBuilder_UT extends TestCase {

  public void testCreateMechanicalFromRequest_NewMechanicalHasChanges_VerifyMechanical() throws Exception {
    MechanicalBuilder mechanicalBuilder = new MechanicalBuilder(new MockMechanicalService());
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.HAS_MECHANICAL_DATA_CHANGED, "true");
    helper.setRequestParameterValue(EISConstants.ENGINEER, "Mech Engineer");
    helper.setRequestParameterValue(EISConstants.MODEL_NUMBER, "MDLNBR123");
    helper.setRequestParameterValue(EISConstants.SHIPPING_WEIGHT, "100");
    helper.setRequestParameterValue(EISConstants.PURCHASE_SCOPE, "1");
    helper.setRequestParameterValue(EISConstants.OPERATING_WEIGHT, "100");
    helper.setRequestParameterValue(EISConstants.SOLE_SOURCE, "on");
    helper.setRequestParameterValue(EISConstants.DYNAMIC_LOAD, "ABC123");
    helper.setRequestParameterValue(EISConstants.SERIAL_NUMBER, "SRL123");
    helper.setRequestParameterValue(EISConstants.BID_PACKAGE_ONE, "Bid Pack One");
    helper.setRequestParameterValue(EISConstants.WORK_DESCRIPTION_ONE, "Work Desc One");
    helper.setRequestParameterValue(EISConstants.BID_PACKAGE_TWO, "Bid Pack Two");
    helper.setRequestParameterValue(EISConstants.WORK_DESCRIPTION_TWO, "Work Desc Two");
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null,null, null);
    Mechanical mechanical = mechanicalBuilder.createMechanicalFromRequest(equipment, helper);
    assertNotNull(mechanical);
    assertEquals("Mech Engineer", mechanical.getEngineer());
    assertEquals("MDLNBR123", mechanical.getModelNumber());
    assertEquals(new Integer(100), mechanical.getShippingWeight());
    assertEquals("Contractor", mechanical.getPurchaseScope().getPurchaseScopeName());
    assertEquals(new Integer(100), mechanical.getOperatingWeight());
//    assertEquals(new Integer(100), mechanical.getDynamicLoad());
    assertEquals("SRL123", mechanical.getSerialNumber());
    assertEquals("ABC123", mechanical.getDynLoad());
    assertEquals("Bid Pack One", mechanical.getBidPackageOne());
    assertEquals("Work Desc One", mechanical.getWorkDescriptionOne());
    assertEquals("Bid Pack Two", mechanical.getBidPackageTwo());
    assertEquals("Work Desc Two", mechanical.getWorkDescriptionTwo());
  }

  public void testCreateMechanicalFromRequest_MechanicalIsNullHasNoChanges_ReturnsNewMechanical() throws Exception {
    MechanicalBuilder mechanicalBuilder = new MechanicalBuilder(new MockMechanicalService());
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.HAS_MECHANICAL_DATA_CHANGED, "");
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null,null, null);
    equipment.setId(new Long(123));
    Mechanical mechanical = mechanicalBuilder.createMechanicalFromRequest(equipment, helper);
    assertNotNull(mechanical);
    assertNull(mechanical.getId());
    assertEquals(equipment, mechanical.getEquipment());
  }

  public void testCreateMechanicalFromRequest_MechanicalIsNotNullHasNoChanges_ReturnsExistingMechanical() throws Exception {
    MechanicalBuilder mechanicalBuilder = new MechanicalBuilder(new MockMechanicalService());
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.HAS_MECHANICAL_DATA_CHANGED, "");
    Mechanical existingMechanical = new Mechanical();
    existingMechanical.setId(new Long(345));
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null,null, null);
    equipment.setId(new Long(123));
    equipment.setMechanical(existingMechanical);
    Mechanical mechanical = mechanicalBuilder.createMechanicalFromRequest(equipment, helper);
    assertEquals(existingMechanical, mechanical);
  }

  public void testCreateMechanicalFromRequest_ExistingMechanicalHasChanges_VerifyMechanical() throws Exception {
    MechanicalBuilder mechanicalBuilder = new MechanicalBuilder(new MockMechanicalService());
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.HAS_MECHANICAL_DATA_CHANGED, "true");
    helper.setRequestParameterValue(EISConstants.ENGINEER, "Mech Engineer");
    helper.setRequestParameterValue(EISConstants.MODEL_NUMBER, "MDLNBR123");
    helper.setRequestParameterValue(EISConstants.SHIPPING_WEIGHT, "100");
    helper.setRequestParameterValue(EISConstants.PURCHASE_SCOPE, "1");
    helper.setRequestParameterValue(EISConstants.OPERATING_WEIGHT, "100");
    helper.setRequestParameterValue(EISConstants.SOLE_SOURCE, "on");
    helper.setRequestParameterValue(EISConstants.DYNAMIC_LOAD, "ABC123");
    helper.setRequestParameterValue(EISConstants.SERIAL_NUMBER, "SRL123");
    helper.setRequestParameterValue(EISConstants.BID_PACKAGE_ONE, "Bid Pack One");
    helper.setRequestParameterValue(EISConstants.WORK_DESCRIPTION_ONE, "Work Desc One");
    helper.setRequestParameterValue(EISConstants.BID_PACKAGE_TWO, "Bid Pack Two");
    helper.setRequestParameterValue(EISConstants.WORK_DESCRIPTION_TWO, "Work Desc Two");
    Equipment equipment = new Equipment("0.000.1W", "0.000.1W1", "Equipment Name", null, null, null, null, null,null, null);
    Mechanical existingMechanical = new Mechanical();
    existingMechanical.setId(new Long(345));
    equipment.setMechanical(existingMechanical); 
    Mechanical mechanical = mechanicalBuilder.createMechanicalFromRequest(equipment, helper);
    assertNotNull(mechanical);
    assertEquals(new Long(345), mechanical.getId());
    assertEquals("Mech Engineer", mechanical.getEngineer());
    assertEquals("MDLNBR123", mechanical.getModelNumber());
    assertEquals(new Integer(100), mechanical.getShippingWeight());
    assertEquals("Contractor", mechanical.getPurchaseScope().getPurchaseScopeName());
    assertEquals(new Integer(100), mechanical.getOperatingWeight());
    assertEquals("ABC123", mechanical.getDynLoad());
    assertEquals("SRL123", mechanical.getSerialNumber());
    assertEquals("Bid Pack One", mechanical.getBidPackageOne());
    assertEquals("Work Desc One", mechanical.getWorkDescriptionOne());
    assertEquals("Bid Pack Two", mechanical.getBidPackageTwo());
    assertEquals("Work Desc Two", mechanical.getWorkDescriptionTwo());
  }

}
