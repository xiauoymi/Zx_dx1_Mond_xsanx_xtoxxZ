/*
 MockProjectBuilder was created on Jan 1, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects;

import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: MockProjectBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2009-01-01 23:33:35 $
 *
 * @author SSPATI1
 * @version $Revision: 1.1 $
 */
public class MockProjectBuilder extends ProjectBuilder{
  private Projects project;
  private List<String> requiredFieldsList;
  private List<String> fieldLengthErrorList;

  public MockProjectBuilder(Projects project, List<String> requiredFieldsList, List<String> fieldLengthErrorList){
    this.project = project;
    this.requiredFieldsList = requiredFieldsList;
    this.fieldLengthErrorList = fieldLengthErrorList;
  }

  public Projects createProjectFromParameterData(UCCHelper helper, boolean isCopy) throws IOException {
    return project;
  }

  public List<String> validateRequiredFields(UCCHelper helper) throws IOException {
    return requiredFieldsList;
  }

  public List<String> validateAllFieldsLength(UCCHelper helper) throws IOException {
    return fieldLengthErrorList;
  }
}