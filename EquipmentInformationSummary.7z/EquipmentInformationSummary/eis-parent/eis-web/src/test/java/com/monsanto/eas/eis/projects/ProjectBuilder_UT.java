/*
 ProjectBuilder_UT was created on Sep 26, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects;

import junit.framework.TestCase;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.ProjectUserRole;
import com.monsanto.eas.eis.projects.mocks.MockProjectServiceImpl;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;

import java.io.IOException;
import java.util.List;
import java.util.HashSet;
import java.util.Date;

/**
 * Filename:    $RCSfile: ProjectBuilder_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: SSPATI1 $    	 On:	$Date: 2009-01-01 23:33:09 $
 *
 * @author VRBETHI
 * @version $Revision: 1.14 $
 */
public class ProjectBuilder_UT extends TestCase {
  private ProjectBuilder projectBuilder;
  private MockProjectServiceImpl mockProjectService;

  protected void setUp() throws Exception {
    super.setUp();
    mockProjectService = new MockProjectServiceImpl(new MockHibernateSession());
    projectBuilder = new ProjectBuilder(mockProjectService, new MockProjectPeopleBuilder());
  }

  public void testCreateProjectFromParameterData_NewProjectPassOnlyRequiredFields_VerifyProject() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SUBMIT_CREATE_PROJECT);

    helper.setRequestParameterValue(EISConstants.PROJECT_NAME, "TEST_INSERT_PROJECT");
    helper.setRequestParameterValue(EISConstants.PROJECT_NUMBER, "77777777");
    helper.setRequestParameterValue(EISConstants.PROJECT_STATUS_ID, "1");
    helper.setRequestParameterValue(EISConstants.UNIT_MEASURE_ID, "2");
    helper.setRequestParameterValue(EISConstants.LOCATION_ID, "3");
    helper.setRequestParameterValue(EISConstants.COUNTRY_ID, "4");
    helper.setRequestParameterValue(EISConstants.STATE_ID, "5");
    helper.setRequestParameterValue(EISConstants.CITY_ID, "6");
    helper.setRequestParameterValue(EISConstants.CROP_ID, "7");

    Projects project = projectBuilder.createProjectFromParameterData(helper,false);
    assertNull(project.getId());
    assertEquals("TEST_INSERT_PROJECT", project.getProjName());
    assertEquals("77777777", project.getProjNumber());
    assertEquals(new Long(1), project.getProjStatus().getId());
    assertEquals(new Long(2), project.getUnitMeasure().getId());
    assertEquals(new Long(3), project.getRegion().getId());
    assertEquals(new Long(4), project.getCountry().getId());
    assertEquals(new Long(5), project.getState().getId());
    assertEquals(new Long(6), project.getCity().getId());
    assertEquals(new Long(7), project.getCrop().getId());
    assertEquals("EIS_USER", project.getCreatedUser());
    assertEquals(new Date(), project.getCreatedDate());
    assertEquals(4, project.getUserRoles().size());
  }

  public void testCreateProjectFromParameterData_ExistingProjectPassAllFields_VerifyProject() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);

    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SUBMIT_CREATE_PROJECT);

    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "123");
    helper.setRequestParameterValue(EISConstants.PROJECT_NAME, "TEST_INSERT_PROJECT");
    helper.setRequestParameterValue(EISConstants.PROJECT_NUMBER, "77777777");
    helper.setRequestParameterValue(EISConstants.STARTUP_DATE, "Sep 18, 2008");
    helper.setRequestParameterValue(EISConstants.AR_APPROVAL_DATE, "Sep 19, 2008");
    helper.setRequestParameterValue(EISConstants.PROJECT_STATUS_ID, "1");
    helper.setRequestParameterValue(EISConstants.UNIT_MEASURE_ID, "2");
    helper.setRequestParameterValue(EISConstants.LOCATION_ID, "3");
    helper.setRequestParameterValue(EISConstants.COUNTRY_ID, "4");
    helper.setRequestParameterValue(EISConstants.STATE_ID, "5");
    helper.setRequestParameterValue(EISConstants.CITY_ID, "6");
    helper.setRequestParameterValue(EISConstants.CROP_ID, "7");

    Projects project = projectBuilder.createProjectFromParameterData(helper,false);
    assertEquals(new Long(123), project.getId());
    assertEquals("TEST_INSERT_PROJECT", project.getProjName());
    assertEquals("77777777", project.getProjNumber());
    assertEquals("Sep 18, 2008", project.getStartupDate());
    assertEquals("Sep 19, 2008", project.getArApprovalDate());
    assertEquals(new Long(1), project.getProjStatus().getId());
    assertEquals(new Long(2), project.getUnitMeasure().getId());
    assertEquals(new Long(3), project.getRegion().getId());
    assertEquals(new Long(4), project.getCountry().getId());
    assertEquals(new Long(5), project.getState().getId());
    assertEquals(new Long(6), project.getCity().getId());
    assertEquals(new Long(7), project.getCrop().getId());
    assertEquals("VVVELU", project.getUpdatedUser());
//    assertEquals(new Date(), project.getUpdatedDate());
    assertEquals(4, project.getUserRoles().size());
 }

  public void testValidateRequiredFields_NotAllRequiredFieldsEntered_RequiredFieldsListIsNotEmpty() throws IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_NAME, "");
    helper.setRequestParameterValue(EISConstants.PROJECT_NUMBER, "");
    helper.setRequestParameterValue(EISConstants.PROJECT_STATUS_ID, "");
    helper.setRequestParameterValue(EISConstants.UNIT_MEASURE_ID, "");
    helper.setRequestParameterValue(EISConstants.LOCATION_ID, "");
    helper.setRequestParameterValue(EISConstants.COUNTRY_ID, "");
    helper.setRequestParameterValue(EISConstants.STATE_ID, "");
    helper.setRequestParameterValue(EISConstants.CITY_ID, "");
    helper.setRequestParameterValue(EISConstants.CROP_ID, "");

    List<String> requiredFieldsList = projectBuilder.validateRequiredFields(helper);
    assertEquals(9, requiredFieldsList.size());
    assertEquals("Project Name is a required field", requiredFieldsList.get(0));
    assertEquals("Project Number is a required field", requiredFieldsList.get(1));
    assertEquals("Region is a required field", requiredFieldsList.get(2));
    assertEquals("Country is a required field", requiredFieldsList.get(3));
    assertEquals("State is a required field", requiredFieldsList.get(4));
    assertEquals("City is a required field", requiredFieldsList.get(5));
    assertEquals("Crop is a required field", requiredFieldsList.get(6));
    assertEquals("English/Metric is a required field", requiredFieldsList.get(7));
    assertEquals("Status is a required field", requiredFieldsList.get(8));
  }


  public void testValidateRequiredFields_AllRequiredFieldsEntered_RequiredFieldsListIsEmpty() throws IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SUBMIT_CREATE_PROJECT);
    helper.setRequestParameterValue(EISConstants.PROJECT_NAME, "TEST_INSERT_PROJECT");
    helper.setRequestParameterValue(EISConstants.PROJECT_NUMBER, "77777777");
    helper.setRequestParameterValue(EISConstants.PROJECT_STATUS_ID, "1");
    helper.setRequestParameterValue(EISConstants.UNIT_MEASURE_ID, "1");
    helper.setRequestParameterValue(EISConstants.LOCATION_ID, "1");
    helper.setRequestParameterValue(EISConstants.COUNTRY_ID, "1");
    helper.setRequestParameterValue(EISConstants.STATE_ID, "1");
    helper.setRequestParameterValue(EISConstants.CITY_ID, "1");
    helper.setRequestParameterValue(EISConstants.CROP_ID, "1");

    List<String> requiredFieldsList = projectBuilder.validateRequiredFields(helper);
    assertTrue(requiredFieldsList.isEmpty());
  }

  public void testValidateAllFieldsLength_EnterInvalidLength_InvalidLengthListIsNotEmpty() throws IOException {
    MockUCCHelper helper = new MockUCCHelper(null);

    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SUBMIT_CREATE_PROJECT);
    helper.setRequestParameterValue(EISConstants.PROJECT_NAME, "TEST_INSERT_PROJECT");
    helper.setRequestParameterValue(EISConstants.PROJECT_NUMBER, "777");
    helper.setRequestParameterValue(EISConstants.PROJECT_STATUS_ID, "1");
    helper.setRequestParameterValue(EISConstants.UNIT_MEASURE_ID, "1");
    helper.setRequestParameterValue(EISConstants.LOCATION_ID, "1");
    helper.setRequestParameterValue(EISConstants.COUNTRY_ID, "1");
    helper.setRequestParameterValue(EISConstants.STATE_ID, "1");
    helper.setRequestParameterValue(EISConstants.CITY_ID, "1");
    helper.setRequestParameterValue(EISConstants.CROP_ID, "1");

    List<String> invalidFieldLengthList = projectBuilder.validateAllFieldsLength(helper);
    assertEquals(1, invalidFieldLengthList.size());
    assertEquals("Project Number is required to be 8 characters", invalidFieldLengthList.get(0));
  }

  private class MockProjectPeopleBuilder extends ProjectPeopleBuilder {
    public Projects setupProjectPeople(Projects project, UCCHelper helper) throws IOException {
      HashSet<ProjectUserRole> projUserRoles = new HashSet<ProjectUserRole>();
      projUserRoles.add(new ProjectUserRole());
      projUserRoles.add(new ProjectUserRole());
      projUserRoles.add(new ProjectUserRole());
      projUserRoles.add(new ProjectUserRole());
      project.setUserRoles(projUserRoles);
      return project;
    }
  }
}