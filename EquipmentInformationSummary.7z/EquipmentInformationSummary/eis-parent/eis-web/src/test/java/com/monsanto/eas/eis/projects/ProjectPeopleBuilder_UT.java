package com.monsanto.eas.eis.projects;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.projects.domain.ProjectRole;
import com.monsanto.eas.eis.projects.domain.ProjectUserRole;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.hibernate.mock.MockDAO;
import junit.framework.TestCase;
import org.hibernate.Criteria;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Nov 15, 2008 Time: 1:48:33 PM To change this template use File |
 * Settings | File Templates.
 */
public class ProjectPeopleBuilder_UT extends TestCase {
  public void testSetupProjectPeople_ExistingProjectUserRolesAreFlaggedAsDeleted() throws Exception {
    MockDAO<ProjectRole, Long> projRoles = new MockDAO<ProjectRole, Long>();
    ProjectPeopleBuilder builder = new ProjectPeopleBuilder(projRoles);
    MockUCCHelper helper = new MockUCCHelper(null);
    Projects project = new Projects();
    project.setId(new Long(123));
    HashSet<ProjectUserRole> existingUserRoles = new HashSet<ProjectUserRole>();
    ProjectUserRole projUserRole1 = new ProjectUserRole();
    existingUserRoles.add(projUserRole1);
    ProjectUserRole projUserRole2 = new ProjectUserRole();
    existingUserRoles.add(projUserRole2);
    project.setUserRoles(existingUserRoles);

    Projects updatedProject = builder.setupProjectPeople(project, helper);
    assertEquals(project, updatedProject);
    assertTrue(projUserRole1.isDeleted());
    assertTrue(projUserRole2.isDeleted());
  }

  public void testSetupProjectPeople_UserIdsAreNull_NoUserRolesAreSet() throws Exception {
    MockDAO<ProjectRole, Long> projRoles = new MockDAO<ProjectRole, Long>();
    ProjectPeopleBuilder builder = new ProjectPeopleBuilder(projRoles);
    Projects project = new Projects();
    MockUCCHelper helper = new MockUCCHelper(null);
    Projects updatedProject = builder.setupProjectPeople(project, helper);
    assertEquals(0, updatedProject.getUserRoles().size());
  }

  public void testSetupProjectPeople_UserIdsAreSetForOneRole_UserRolesAreSetAndLookRoleWasCalled() throws Exception {
    ProjectRole projRole = new ProjectRole();
    projRole.setId(new Long(234));
    MockProjRoleDao projRoleDao = new MockProjRoleDao(null, ProjectRole.class, projRole);
    ProjectPeopleBuilder builder = new ProjectPeopleBuilder(projRoleDao);
    Projects project = new Projects();
    MockUCCHelper helper = new MockUCCHelper(null);

    helper.setRequestParameterValue(EISConstants.PROJECT_SPONSOR_ID, new String[]{"1", "2"});
    helper.setRequestParameterValue(EISConstants.IS_LEAD_PROJECT_SPONSOR, new String[]{"false", "true"});

    Projects updatedProject = builder.setupProjectPeople(project, helper);

    MockCriteriaForEIS criteria = projRoleDao.getCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("name=Project Sponsor", criteria.getCriteria().get(0).toString());
    Set<ProjectUserRole> userRoles = updatedProject.getUserRoles();
    assertEquals(2, userRoles.size());
    Iterator<ProjectUserRole> iterator = userRoles.iterator();
    ProjectUserRole projUserRole = iterator.next();
    if (projUserRole.getUser().getId().equals(new Long(1))) {
      assertProjUserRole1(projUserRole);
      projUserRole = iterator.next();
      assertProjUserRole2(projUserRole);
    } else {
      assertProjUserRole2(projUserRole);
      projUserRole = iterator.next();
      assertProjUserRole1(projUserRole);
    }
  }

  public void testSetupProjectPeople_OneUserIdSetForOneRole_SingleUserIsLeadIsTrue() throws Exception {
    ProjectRole projRole = new ProjectRole();
    projRole.setId(new Long(234));
    MockProjRoleDao projRoleDao = new MockProjRoleDao(null, ProjectRole.class, projRole);
    ProjectPeopleBuilder builder = new ProjectPeopleBuilder(projRoleDao);
    Projects project = new Projects();
    MockUCCHelper helper = new MockUCCHelper(null);

    helper.setRequestParameterValue(EISConstants.PROJECT_SPONSOR_ID, new String[]{"1"});
    helper.setRequestParameterValue(EISConstants.IS_LEAD_PROJECT_SPONSOR, new String[]{"false"});

    Projects updatedProject = builder.setupProjectPeople(project, helper);

    MockCriteriaForEIS criteria = projRoleDao.getCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("name=Project Sponsor", criteria.getCriteria().get(0).toString());
    Set<ProjectUserRole> userRoles = updatedProject.getUserRoles();
    assertEquals(1, userRoles.size());
    Iterator<ProjectUserRole> iterator = userRoles.iterator();
    ProjectUserRole projUserRole = iterator.next();
    assertEquals(new Long(1), projUserRole.getUser().getId());
    assertEquals(new Long(234), projUserRole.getProjRole().getId());
    assertFalse(projUserRole.getIsLead());
  }

  private void assertProjUserRole2(ProjectUserRole projUserRole) {
    assertEquals(new Long(2), projUserRole.getUser().getId());
    assertEquals(new Long(234), projUserRole.getProjRole().getId());
    assertTrue(projUserRole.getIsLead());
  }

  private void assertProjUserRole1(ProjectUserRole projUserRole) {
    assertEquals(new Long(1), projUserRole.getUser().getId());
    assertEquals(new Long(234), projUserRole.getProjRole().getId());
    assertFalse(projUserRole.getIsLead());
  }

  public void testSetupProjectPeople_UserIdsAreSetForALlRoles_UserRolesAreSet() throws Exception {
    ProjectRole projRole = new ProjectRole();
    projRole.setId(new Long(234));
    MockProjRoleDao projRoleDao = new MockProjRoleDao(null, ProjectRole.class, projRole);
    ProjectPeopleBuilder builder = new ProjectPeopleBuilder(projRoleDao);
    Projects project = new Projects();
    MockUCCHelper helper = new MockUCCHelper(null);

    helper.setRequestParameterValue(EISConstants.PROJECT_SPONSOR_ID, new String[]{"1", "2"});
    helper.setRequestParameterValue(EISConstants.IS_LEAD_PROJECT_SPONSOR, new String[]{"false", "true"});
    helper.setRequestParameterValue(EISConstants.LEAD_PROCESS_ID, new String[]{"3", "4"});
    helper.setRequestParameterValue(EISConstants.IS_LEAD_PROCESS_LEAD, new String[]{"true", "true"});
    helper.setRequestParameterValue(EISConstants.PROJECT_MANAGER_ID, new String[]{"", "5"});
    helper.setRequestParameterValue(EISConstants.IS_LEAD_PROJECT_MANAGER, new String[]{"false", "false"});
    helper.setRequestParameterValue(EISConstants.LEAD_MECH_ENGR_ID, new String[]{"6", ""});
    helper.setRequestParameterValue(EISConstants.IS_LEAD_MECH_ENGR_LEAD, new String[]{"", "true"});
    helper.setRequestParameterValue(EISConstants.MANUFACTURE_REP_ID, new String[]{"7", "8"});
    helper.setRequestParameterValue(EISConstants.IS_LEAD_MANUFACTURE_REP, new String[]{"false", ""});
    helper.setRequestParameterValue(EISConstants.LEAD_MECH_DESIGNER_ID, new String[]{"9", "10", "11"});
    helper.setRequestParameterValue(EISConstants.IS_LEAD_MECH_DESIGNER_LEAD, new String[]{"false", "true", "true"});
    helper.setRequestParameterValue(EISConstants.LOCATION_MANAGER_ID, new String[]{"12"});
    helper.setRequestParameterValue(EISConstants.IS_LEAD_LOCATION_MANAGER, new String[]{"false"});
    helper.setRequestParameterValue(EISConstants.LEAD_ELECT_ENGR_ID, new String[]{""});
    helper.setRequestParameterValue(EISConstants.IS_LEAD_ELECT_ENGR_LEAD, new String[]{"false"});
    helper.setRequestParameterValue(EISConstants.PROJECT_BUYER_ID, new String[]{"13"});
    helper.setRequestParameterValue(EISConstants.IS_LEAD_PROJECT_BUYER, new String[]{"true"});
    helper.setRequestParameterValue(EISConstants.LEAD_ELECT_DESIGNER_ID, new String[]{"14", "15"});
    helper.setRequestParameterValue(EISConstants.IS_LEAD_ELECT_DESIGNER_LEAD, new String[]{"false", "true"});
    helper.setRequestParameterValue(EISConstants.PROJECT_ENGR_ID, new String[]{"16"});
    helper.setRequestParameterValue(EISConstants.IS_PROJECT_ENGR_LEAD, new String[]{"false"});
    helper.setRequestParameterValue(EISConstants.PROJECT_CONTROLS_ID, new String[]{"17"});
    helper.setRequestParameterValue(EISConstants.IS_PROJECT_CONTROLS_LEAD, new String[]{"true"});

    Projects updatedProject = builder.setupProjectPeople(project, helper);

    Set<ProjectUserRole> userRoles = updatedProject.getUserRoles();
    assertEquals(17, userRoles.size());
  }

  private class MockProjRoleDao extends HibernateDAO<ProjectRole, Long> {
    ProjectRole projRole;
    MockCriteriaForEIS criteria;

    private MockProjRoleDao(HibernateFactory hibernateFactory, Class<? extends ProjectRole> aClass,
                            ProjectRole projRole) {
      super(hibernateFactory, aClass);
      this.projRole = projRole;
    }

    public Criteria createCriteria() {
      criteria = new MockCriteriaForEIS(projRole, null);
      return criteria;
    }

    public MockCriteriaForEIS getCriteria() {
      return criteria;
    }
  }
}
