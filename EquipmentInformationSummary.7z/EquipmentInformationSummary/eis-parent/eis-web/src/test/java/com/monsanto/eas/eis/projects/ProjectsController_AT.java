package com.monsanto.eas.eis.projects;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.EISConstants;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by IntelliJ IDEA. User: VVVELU Date: Aug 5, 2008 Time: 1:10:59 PM
 */
public class ProjectsController_AT extends EISTestCase {
  com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl pDAO;

  protected void setUp() throws Exception {
    super.setUp();
    pDAO = new ProjectsDAOImpl();
  }

  public void testRun_forCreateProject() throws Exception {

    ProjectsController pc = new ProjectsController();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "create");
    pc.run(helper);

    assertTrue(helper.wasSentTo(EISConstants.WEB_INF_JSP_PROJECTS_CREATE_PROJECT_JSP));

    Map refData = (HashMap) helper.getRequestAttributeValue(EISConstants.CREATE_PROJECT_REF_DATA);
    assertNotNull(refData);

    List<ProjectStatus> projectStatus = (List<ProjectStatus>) refData.get(EISConstants.PROJECT_STATUS);
    assertNotNull(projectStatus);
    assertTrue(projectStatus.size() > 0);

    List<UnitMeasure> unitMeasure = (List<UnitMeasure>) refData.get(EISConstants.UNIT_MEASURE);
    assertNotNull(unitMeasure);
    assertTrue(unitMeasure.size() > 0);

    List<Location> location = (List<Location>) refData.get(EISConstants.LOCATION);
    assertNotNull(location);
    assertTrue(location.size() > 0);

    List<Crop> crop = (List<Crop>) refData.get(EISConstants.CROP);
    assertNotNull(crop);
    assertTrue(crop.size() > 0);
  }

  /**
   * test case to test the insert functionality for projects This test inserts the project and deletes the project right
   * after the test
   *
   * @exception IOException
   */
  public void testRun_submitCreateProject() throws IOException, TransformerException {
    ProjectsController pc = new ProjectsController();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SUBMIT_CREATE_PROJECT);
    String projectNumber = GenerateRandomProjectNumber.createRandomWithEightChars();
    helper.setRequestParameterValue(EISConstants.PROJECT_NAME, "TEST_INSERT_PROJECT " + projectNumber);
    helper.setRequestParameterValue(EISConstants.PROJECT_NUMBER, projectNumber);
    helper.setRequestParameterValue(EISConstants.STARTUP_DATE, "Dec 16, 2008");
    helper.setRequestParameterValue(EISConstants.AR_APPROVAL_DATE, "Dec 16, 2008");

    helper.setRequestParameterValue(EISConstants.PROJECT_STATUS_ID, "1");
    helper.setRequestParameterValue(EISConstants.UNIT_MEASURE_ID, "1");
    helper.setRequestParameterValue(EISConstants.LOCATION_ID, "1");
    helper.setRequestParameterValue(EISConstants.COUNTRY_ID, "3");
    helper.setRequestParameterValue(EISConstants.STATE_ID, "7");
    helper.setRequestParameterValue(EISConstants.CITY_ID, "9");
    helper.setRequestParameterValue(EISConstants.CROP_ID, "1");
    pc.run(helper);

    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//projectId)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/)", xmlDoc);
    assertXpathEvaluatesTo("0", "count(//errors/error)", xmlDoc);
  }

  public void testRun_list_location_xml_areLocationsSorted() throws Exception {
    ProjectsController pc = new ProjectsController();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.LIST_LOCATION_XML);
    helper.setRequestParameterValue(EISConstants.LOCATION_ID, "1");
    pc.run(helper);
    Document doc = helper.getXML();
    NodeList list = XPathAPI.selectNodeList(doc, "/options/option/id");
    NodeList descriptionList = XPathAPI.selectNodeList(doc, "/options/option/description");
    String valueOfFirstIdNode = DOMUtil.getTextValue(list.item(1));
    String valueOfFirstDescriptionNode = DOMUtil.getTextValue(descriptionList.item(1));
    String valueOfSecondIdNode = DOMUtil.getTextValue(list.item(2));
    String valueOfSecondtDescriptionNode = DOMUtil.getTextValue(descriptionList.item(2));
    assertNotNull(doc);
    assertEquals("566373", valueOfFirstIdNode);
    assertEquals("Canada", valueOfFirstDescriptionNode);
    assertEquals("3", valueOfSecondIdNode);
    assertEquals("USA", valueOfSecondtDescriptionNode);
  }
}