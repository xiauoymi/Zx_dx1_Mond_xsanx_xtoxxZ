package com.monsanto.eas.eis.projects;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.equipment.service.*;
import com.monsanto.eas.eis.equipment.service.mock.MockCostScheduleService;
import com.monsanto.eas.eis.equipment.service.mock.MockElectricalService;
import com.monsanto.eas.eis.equipment.service.mock.MockMechanicalService;
import com.monsanto.eas.eis.equipment.service.mock.MockProcessService;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.mocks.*;
import com.monsanto.eas.eis.projects.services.UserService;
import com.monsanto.eas.eis.projects.services.mock.MockUserService;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.controller.EISController;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.hibernate.Session;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: VVVELU Date: Jul 29, 2008 Time: 4:37:15 PM
 */
public class ProjectsController_UT extends XMLTestCase {
  private EISDAOFactory mockDaoFactory;
  private ProjectsController pc;
  private MockProjectServiceImpl projectsService;
  private MockHibernateSession session = new MockHibernateSession();
  private ProjectsUtility projectsUtility;
  private ProcessService processService;
  private EquipmentService equipmentService;
  private ElectricalService electricalService;
  private CostScheduleService costScheduleService;
  private ProjectBuilder projectBuilder;
  MechanicalService mechanicalService;

  protected void setUp() throws Exception {
    super.setUp();
    mockDaoFactory = new MockEISDAOFactory(session);
    projectsService = new MockProjectServiceImpl(session);
    projectsUtility = new ProjectsUtility(mockDaoFactory);
    processService = new MockProcessService();
    equipmentService = new MockEquipmentServiceImpl();
    electricalService = new MockElectricalService();
    costScheduleService = new MockCostScheduleService();
    mechanicalService = new MockMechanicalService();
    UserService userService = new MockUserService(true, false, false, null, null);
    Projects project = new Projects();
    project.setProjStatus(new ProjectStatus(new Long(1), "Design"));
    projectBuilder = new MockProjectBuilder(project, new ArrayList<String>(), new ArrayList<String>());
    pc = new ProjectsController(projectsService, projectsUtility, processService, equipmentService,
        electricalService, costScheduleService, mechanicalService, projectBuilder, userService);
  }

  public void testRun_checkReferenceData_toCreateProject() throws IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "create");
    pc.run(helper);

    assertTrue(helper.wasSentTo(EISConstants.WEB_INF_JSP_PROJECTS_CREATE_PROJECT_JSP));

    Map refData = (Map) helper.getRequestAttributeValue(EISConstants.CREATE_PROJECT_REF_DATA);
    assertNotNull(refData);
    List<ProjectStatus> projectStatus = (List<ProjectStatus>) refData.get(EISConstants.PROJECT_STATUS);
    assertNotNull(projectStatus);
    assertTrue(projectStatus.size() > 0);
    assertTrue(((MockProjectStatusDAOImpl) mockDaoFactory.getProjectStatusDAOImpl()).wasFindAllExcludingDeleteCalled());

    List<UnitMeasure> unitMeasure = (List<UnitMeasure>) refData.get(EISConstants.UNIT_MEASURE);
    assertNotNull(unitMeasure);
    assertTrue(unitMeasure.size() > 0);
    assertTrue(((MockUnitMeasureDAOImpl) mockDaoFactory.getUnitMeasureDAOImpl()).wasFindAllForSortCalled());

    List<Location> location = (List<Location>) refData.get(EISConstants.LOCATION);
    assertNotNull(location);
    assertTrue(location.size() > 0);
    MockLocationDAOImpl locationDAO = (MockLocationDAOImpl) mockDaoFactory.getLocationDAOImpl();
    assertTrue(locationDAO.wasFindByRegionCalled());

    List<Crop> crop = (List<Crop>) refData.get(EISConstants.CROP);
    assertNotNull(crop);
    assertTrue(crop.size() > 0);
    assertTrue(((MockCropDAOImpl) mockDaoFactory.getCropDAOImpl()).wasFindAllForSortCalled());
  }

  public void testDeleteProject_WasDeleteCalled() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "deleteProject");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "771");
    pc.run(helper);
    assertTrue(projectsService.wasDeleteProjectsCalled());
    assertEquals("ok", helper.getResponse());
  }

  public void testRun_ArchiveProjects_WasArchiveCalled() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "archiveProjects");
    helper.setRequestParameterValue("projectIds", "771,772");
    pc.run(helper);
    assertTrue(projectsService.wasArchiveProjectsCalled());
  }

  public void testEditDetail_RequestAttributesAreSet() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "edit_project");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "123");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "3");
    pc.run(helper);
    assertEquals("123", helper.getRequestAttributeValue(EISConstants.PROJECT_ID));
    Projects project = (Projects) helper.getRequestAttributeValue(EISConstants.PROJECT_DETAIL);
    assertEquals("12345678", project.getProjNumber());
    assertTrue((Boolean) helper.getRequestAttributeValue(EISConstants.DOES_PROJECT_HAVE_EQUIPMENTS));
    assertNull(helper.getRequestAttributeValue(EISConstants.EQUIPMENT_ID));
    List<EquipmentType> types = (List<EquipmentType>) helper.getRequestAttributeValue(EISConstants.EQUIPMENT_TYPES);
    assertEquals(2, types.size());
    assertEquals("Conveyor", types.get(0).getName());
    List<Area> areas = (List<Area>) helper.getRequestAttributeValue(EISConstants.EQUIPMENT_AREAS);
    assertEquals(2, areas.size());
    List<FundingSource> fundingSources = (List<FundingSource>) helper
        .getRequestAttributeValue(EISConstants.FUNDING_SOURCES);
    assertEquals(2, fundingSources.size());
    assertEquals("Lease", fundingSources.get(0).getSource());
    List<GasType> gasTypes = (List<GasType>) helper.getRequestAttributeValue(EISConstants.GAS_TYPES);
    assertEquals(2, gasTypes.size());
    assertEquals("Natural Gas", gasTypes.get(0).getType());
    List<WaterType> waterTypes = (List<WaterType>) helper.getRequestAttributeValue(EISConstants.WATER_TYPES);
    assertEquals(2, waterTypes.size());
    assertEquals("Process", waterTypes.get(0).getType());
    List<DustType> dustTypes = (List<DustType>) helper.getRequestAttributeValue(EISConstants.DUST_TYPES);
    assertEquals(2, dustTypes.size());
    assertEquals("Red Dust", dustTypes.get(0).getType());
    List<FieldEquipmentType> fieldEquipmentTypes = (List<FieldEquipmentType>) helper
        .getRequestAttributeValue(EISConstants.FIELD_EQUIPMENT_TYPES);
    assertEquals(3, fieldEquipmentTypes.size());
    assertEquals("testFE1", fieldEquipmentTypes.get(0).getName());

    assertEquals("true", helper.getRequestAttributeValue(EISConstants.USER_HAS_EDIT_ACCESS_TO_THIS_PROJECT).toString());
    assertEquals("false",
        helper.getRequestAttributeValue(EISConstants.IS_USER_IN_PROCESS_ROLE_FOR_THIS_PROJECT).toString());
    assertEquals("false",
        helper.getRequestAttributeValue(EISConstants.IS_USER_IN_MECHANICAL_ENG_ROLE_FOR_THIS_PROJECT).toString());

    assertTrue(helper.wasSentTo(EISConstants.WEB_INF_JSP_PROJECTS_PROJECT_DETAIL_JSP));
  }

  public void testRun_projectDetail_RequestAttributesAreSet() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "project_detail");
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "123");
    helper.setRequestParameterValue(EISConstants.EQUIPMENT_ID, "3");
    helper.setRequestParameterValue(EISConstants.PROJECT_SAVE_MSG, "Proj save msg");
    helper.setRequestParameterValue(EISConstants.LOAD_ALL_EQUIPMENT_LIST, "true");
    pc.run(helper);
    assertEquals("123", helper.getRequestAttributeValue(EISConstants.PROJECT_ID));
    Projects project = (Projects) helper.getRequestAttributeValue(EISConstants.PROJECT_DETAIL);
    assertEquals("12345678", project.getProjNumber());
    assertNull(helper.getRequestAttributeValue(EISConstants.EQUIPMENT_ID));
    List<EquipmentType> types = (List<EquipmentType>) helper.getRequestAttributeValue(EISConstants.EQUIPMENT_TYPES);
    assertEquals(2, types.size());
    assertEquals("Conveyor", types.get(0).getName());
    List<Area> areas = (List<Area>) helper.getRequestAttributeValue(EISConstants.EQUIPMENT_AREAS);
    assertEquals(2, areas.size());
    List<FundingSource> fundingSources = (List<FundingSource>) helper
        .getRequestAttributeValue(EISConstants.FUNDING_SOURCES);
    assertEquals(2, fundingSources.size());
    assertEquals("Lease", fundingSources.get(0).getSource());
    List<GasType> gasTypes = (List<GasType>) helper.getRequestAttributeValue(EISConstants.GAS_TYPES);
    assertEquals(2, gasTypes.size());
    assertEquals("Natural Gas", gasTypes.get(0).getType());
    List<WaterType> waterTypes = (List<WaterType>) helper.getRequestAttributeValue(EISConstants.WATER_TYPES);
    assertEquals(2, waterTypes.size());
    assertEquals("Process", waterTypes.get(0).getType());
    List<DustType> dustTypes = (List<DustType>) helper.getRequestAttributeValue(EISConstants.DUST_TYPES);
    assertEquals(2, dustTypes.size());
    assertEquals("Red Dust", dustTypes.get(0).getType());
    List<FieldEquipmentType> fieldEquipmentTypes = (List<FieldEquipmentType>) helper
        .getRequestAttributeValue(EISConstants.FIELD_EQUIPMENT_TYPES);
    assertEquals(3, fieldEquipmentTypes.size());
    assertEquals("testFE1", fieldEquipmentTypes.get(0).getName());

    assertEquals("true", helper.getRequestAttributeValue(EISConstants.USER_HAS_EDIT_ACCESS_TO_THIS_PROJECT).toString());
    assertEquals("false",
        helper.getRequestAttributeValue(EISConstants.IS_USER_IN_PROCESS_ROLE_FOR_THIS_PROJECT).toString());
    assertEquals("false",
        helper.getRequestAttributeValue(EISConstants.IS_USER_IN_MECHANICAL_ENG_ROLE_FOR_THIS_PROJECT).toString());
    assertEquals("Proj save msg", helper.getRequestAttributeValue(EISConstants.PROJECT_SAVE_MSG));
    assertEquals("true", helper.getRequestAttributeValue(EISConstants.LOAD_ALL_EQUIPMENT_LIST));

    assertTrue(helper.wasSentTo(EISConstants.WEB_INF_JSP_PROJECTS_PROJECT_DETAIL_JSP));
  }

  public void testRun_GetLocationsAsXML() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.LIST_LOCATION_XML);
    helper.setRequestParameterValue(EISConstants.LOCATION_ID, "1");
    pc.run(helper);
    Document xml = helper.getXML();
    assertNotNull(xml);
    assertTrue(projectsService.wasGetLocationsAsXMLCalled());
  }

  public void testSubmitProject_NoErrors_ProjectIsSaved() throws IOException, TransformerException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SUBMIT_CREATE_PROJECT);
    pc.run(helper);
    assertTrue(((MockProjectsDAOImpl) mockDaoFactory.getProjectsDAOImpl()).wasSaveCalled());
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//projectId)", xmlDoc);
    assertXpathEvaluatesTo("", "//projectId", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/)", xmlDoc);
    assertXpathEvaluatesTo("0", "count(//errors/error)", xmlDoc);
  }

  public void testSubmitProject_ProjectNumberExists_ProjectNotSavedVerifyResponse() throws IOException,
      TransformerException {
    MockUCCHelper helper1 = new MockUCCHelper(null);
    helper1.setRequestParameterValue(EISConstants.METHOD, EISConstants.SUBMIT_CREATE_PROJECT);

    helper1.setRequestParameterValue(EISConstants.PROJECT_NAME, "TEST_PROJECT_NAME");
    helper1.setRequestParameterValue(EISConstants.PROJECT_NUMBER, "12345678");
    helper1.setRequestParameterValue(EISConstants.STARTUP_DATE, "Dec 16, 2008");
    helper1.setRequestParameterValue(EISConstants.AR_APPROVAL_DATE, "Dec 16, 2008");
    helper1.setRequestParameterValue(EISConstants.LOCATION_MANAGER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_STATUS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.UNIT_MEASURE_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LOCATION_ID, "1");
    helper1.setRequestParameterValue(EISConstants.COUNTRY_ID, "1");
    helper1.setRequestParameterValue(EISConstants.STATE_ID, "1");
    helper1.setRequestParameterValue(EISConstants.CITY_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_BUYER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_SPONSOR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_CONTROLS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_PROCESS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.MANUFACTURE_REP_ID, "1");
    helper1.setRequestParameterValue(EISConstants.CROP_ID, "1");

    helper1.setRequestParameterValue(EISConstants.PROJECT_MANAGER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_MECH_ENGR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_MECH_DESIGNER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_ELECT_ENGR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_ELECT_DESIGNER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.OPERATION, "");

    final MockProjectsServiceForExistingProject mockProjectsServiceForExistingProject = new MockProjectsServiceForExistingProject(
        session);
    MockProjectsControllerOverridesClearHibernateSession pcWithExistingProject = new MockProjectsControllerOverridesClearHibernateSession(
        mockDaoFactory,
        mockProjectsServiceForExistingProject, projectsUtility, processService, equipmentService,
        electricalService, costScheduleService, mechanicalService, projectBuilder);
    pcWithExistingProject.run(helper1);
    assertTrue(pcWithExistingProject.isClearHibernateSessionWasCalled());
    Document xmlDoc = helper1.getXML();
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//projectId)", xmlDoc);
    assertXpathEvaluatesTo("", "//projectId", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/error)", xmlDoc);
    assertXpathEvaluatesTo("Project Number entered already exists.", "//errors/error/errorHeader", xmlDoc);
    assertXpathEvaluatesTo("Please enter a unique Project Number", "//errors/error/errorMsg", xmlDoc);
  }

  public void testSubmitProject_RequiredFieldsNotEntered_ProjectNotSavedVerifyResponse() throws IOException,
      TransformerException {
    MockUCCHelper helper1 = new MockUCCHelper(null);
    helper1.setRequestParameterValue(EISConstants.METHOD, EISConstants.SUBMIT_CREATE_PROJECT);

    helper1.setRequestParameterValue(EISConstants.PROJECT_NAME, "TEST_PROJECT_NAME");
    helper1.setRequestParameterValue(EISConstants.PROJECT_NUMBER, "12345678");
    helper1.setRequestParameterValue(EISConstants.STARTUP_DATE, "Dec 16, 2008");
    helper1.setRequestParameterValue(EISConstants.AR_APPROVAL_DATE, "Dec 16, 2008");
    helper1.setRequestParameterValue(EISConstants.LOCATION_MANAGER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_STATUS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.UNIT_MEASURE_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LOCATION_ID, "1");
    helper1.setRequestParameterValue(EISConstants.COUNTRY_ID, "1");
    helper1.setRequestParameterValue(EISConstants.STATE_ID, "1");
    helper1.setRequestParameterValue(EISConstants.CITY_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_BUYER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_SPONSOR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_CONTROLS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_PROCESS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.MANUFACTURE_REP_ID, "1");
    helper1.setRequestParameterValue(EISConstants.CROP_ID, "1");

    helper1.setRequestParameterValue(EISConstants.PROJECT_MANAGER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_MECH_ENGR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_MECH_DESIGNER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_ELECT_ENGR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_ELECT_DESIGNER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.OPERATION, "");

    List<String> requiredFieldsErrorList = new ArrayList<String>();
    requiredFieldsErrorList.add("Error 1");
    requiredFieldsErrorList.add("Error 2");
    MockProjectsControllerOverridesClearHibernateSession pcWithExistingProject = new MockProjectsControllerOverridesClearHibernateSession(
        mockDaoFactory, projectsService, projectsUtility, processService, equipmentService,
        electricalService, costScheduleService, mechanicalService, new MockProjectBuilder(new Projects(),
            requiredFieldsErrorList, new ArrayList<String>()));
    pcWithExistingProject.run(helper1);
    assertTrue(pcWithExistingProject.isClearHibernateSessionWasCalled());
    Document xmlDoc = helper1.getXML();
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//projectId)", xmlDoc);
    assertXpathEvaluatesTo("", "//projectId", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/error)", xmlDoc);
    assertXpathEvaluatesTo("Required Fields:", "//errors/error/errorHeader", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//errors/error/errorMsg)", xmlDoc);
    assertXpathEvaluatesTo("Error 1", "//errors/error/errorMsg[1]", xmlDoc);
    assertXpathEvaluatesTo("Error 2", "//errors/error/errorMsg[2]", xmlDoc);
  }

  public void testSubmitProject_FieldsHaveInvalidLengths_ProjectNotSavedVerifyResponse() throws IOException,
      TransformerException {
    MockUCCHelper helper1 = new MockUCCHelper(null);
    helper1.setRequestParameterValue(EISConstants.METHOD, EISConstants.SUBMIT_CREATE_PROJECT);

    helper1.setRequestParameterValue(EISConstants.PROJECT_NAME, "TEST_PROJECT_NAME");
    helper1.setRequestParameterValue(EISConstants.PROJECT_NUMBER, "12345678");
    helper1.setRequestParameterValue(EISConstants.STARTUP_DATE, "Dec 16, 2008");
    helper1.setRequestParameterValue(EISConstants.AR_APPROVAL_DATE, "Dec 16, 2008");
    helper1.setRequestParameterValue(EISConstants.LOCATION_MANAGER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_STATUS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.UNIT_MEASURE_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LOCATION_ID, "1");
    helper1.setRequestParameterValue(EISConstants.COUNTRY_ID, "1");
    helper1.setRequestParameterValue(EISConstants.STATE_ID, "1");
    helper1.setRequestParameterValue(EISConstants.CITY_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_BUYER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_SPONSOR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_CONTROLS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_PROCESS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.MANUFACTURE_REP_ID, "1");
    helper1.setRequestParameterValue(EISConstants.CROP_ID, "1");

    helper1.setRequestParameterValue(EISConstants.PROJECT_MANAGER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_MECH_ENGR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_MECH_DESIGNER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_ELECT_ENGR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_ELECT_DESIGNER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.OPERATION, "");

    List<String> invalidLengthsErrorList = new ArrayList<String>();
    invalidLengthsErrorList.add("Error 3");
    invalidLengthsErrorList.add("Error 4");
    MockProjectsControllerOverridesClearHibernateSession pcWithExistingProject = new MockProjectsControllerOverridesClearHibernateSession(
        mockDaoFactory, projectsService, projectsUtility, processService, equipmentService,
        electricalService, costScheduleService, mechanicalService, new MockProjectBuilder(new Projects(),
            new ArrayList<String>(), invalidLengthsErrorList));
    pcWithExistingProject.run(helper1);
    assertTrue(pcWithExistingProject.isClearHibernateSessionWasCalled());
    Document xmlDoc = helper1.getXML();
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//projectId)", xmlDoc);
    assertXpathEvaluatesTo("", "//projectId", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/error)", xmlDoc);
    assertXpathEvaluatesTo("Project Fields with invalid length:", "//errors/error/errorHeader", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//errors/error/errorMsg)", xmlDoc);
    assertXpathEvaluatesTo("Error 3", "//errors/error/errorMsg[1]", xmlDoc);
    assertXpathEvaluatesTo("Error 4", "//errors/error/errorMsg[2]", xmlDoc);
  }

  public void testSubmitProjectSaveAs_NewProjectCreatedVerifyResponse() throws IOException,
      TransformerException {
    MockUCCHelper helper1 = new MockUCCHelper(null);
    helper1.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_AS);

    helper1.setRequestParameterValue(EISConstants.PROJECT_NAME, "TEST_PROJECT_NAME");
    helper1.setRequestParameterValue(EISConstants.PROJECT_NUMBER, "11223344");
    helper1.setRequestParameterValue(EISConstants.STARTUP_DATE, "Dec 16, 2008");
    helper1.setRequestParameterValue(EISConstants.AR_APPROVAL_DATE, "Dec 16, 2008");
    helper1.setRequestParameterValue(EISConstants.LOCATION_MANAGER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_STATUS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.UNIT_MEASURE_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LOCATION_ID, "1");
    helper1.setRequestParameterValue(EISConstants.COUNTRY_ID, "1");
    helper1.setRequestParameterValue(EISConstants.STATE_ID, "1");
    helper1.setRequestParameterValue(EISConstants.CITY_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_BUYER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_SPONSOR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_CONTROLS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_PROCESS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.MANUFACTURE_REP_ID, "1");
    helper1.setRequestParameterValue(EISConstants.CROP_ID, "1");

    helper1.setRequestParameterValue(EISConstants.PROJECT_MANAGER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_MECH_ENGR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_MECH_DESIGNER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_ELECT_ENGR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_ELECT_DESIGNER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.OPERATION, "");


    final MockProjectsServiceForSaveAs mockProjectsServiceForExistingProject = new MockProjectsServiceForSaveAs(
        session);
    MockProjectsControllerOverridesClearHibernateSession pcWithExistingProject = new MockProjectsControllerOverridesClearHibernateSession(
        mockDaoFactory,
        mockProjectsServiceForExistingProject, projectsUtility, processService, equipmentService,
        electricalService, costScheduleService, mechanicalService, projectBuilder);
    pcWithExistingProject.run(helper1);
    Document xmlDoc = helper1.getXML();
    DOMUtil.outputXML(xmlDoc);
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//projectId)", xmlDoc);
    assertXpathEvaluatesTo("", "//projectId", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/)", xmlDoc);
    assertXpathEvaluatesTo("0", "count(//errors/error)", xmlDoc);
  }


   public void testSubmitProjectSaveAs_SourceProjectIsInIdleStatePurchasingCostScheduleNotCopied_VerifyResponse() throws IOException,
      TransformerException {
    MockUCCHelper helper1 = new MockUCCHelper(null);
    helper1.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_AS);

    helper1.setRequestParameterValue(EISConstants.PROJECT_NAME, "TEST_PROJECT_NAME");
    helper1.setRequestParameterValue(EISConstants.PROJECT_NUMBER, "11223344");
    helper1.setRequestParameterValue(EISConstants.STARTUP_DATE, "Dec 16, 2008");
    helper1.setRequestParameterValue(EISConstants.AR_APPROVAL_DATE, "Dec 16, 2008");
    helper1.setRequestParameterValue(EISConstants.LOCATION_MANAGER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_STATUS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.UNIT_MEASURE_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LOCATION_ID, "1");
    helper1.setRequestParameterValue(EISConstants.COUNTRY_ID, "1");
    helper1.setRequestParameterValue(EISConstants.STATE_ID, "1");
    helper1.setRequestParameterValue(EISConstants.CITY_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_BUYER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_SPONSOR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.PROJECT_CONTROLS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_PROCESS_ID, "1");
    helper1.setRequestParameterValue(EISConstants.MANUFACTURE_REP_ID, "1");
    helper1.setRequestParameterValue(EISConstants.CROP_ID, "1");

    helper1.setRequestParameterValue(EISConstants.PROJECT_MANAGER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_MECH_ENGR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_MECH_DESIGNER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_ELECT_ENGR_ID, "1");
    helper1.setRequestParameterValue(EISConstants.LEAD_ELECT_DESIGNER_ID, "1");
    helper1.setRequestParameterValue(EISConstants.OPERATION, "");


    final MockProjectsServiceForSaveAs mockProjectsServiceForExistingProject = new MockProjectsServiceForSaveAs(
        session);
    MockProjectsControllerOverridesClearHibernateSession pcWithExistingProject = new MockProjectsControllerOverridesClearHibernateSession(
        mockDaoFactory,
        mockProjectsServiceForExistingProject, projectsUtility, processService, equipmentService,
        electricalService, costScheduleService, mechanicalService, projectBuilder);
    pcWithExistingProject.run(helper1);
    Document xmlDoc = helper1.getXML();
    DOMUtil.outputXML(xmlDoc);
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//projectId)", xmlDoc);
    assertXpathEvaluatesTo("", "//projectId", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/)", xmlDoc);
    assertXpathEvaluatesTo("0", "count(//errors/error)", xmlDoc);
  }

  public void testSaveAsFromExistingProject() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, EISConstants.SAVE_AS_BY_ID);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "1234");
    helper.setRequestParameterValue(EISConstants.PROJECT_NUMBER, "11223344");

    final MockProjectsServiceForSaveAs mockProjectsServiceForExistingProject = new MockProjectsServiceForSaveAs(
        session);
    EISController pcWithExistingProject = new MockProjectsControllerOverridesClearHibernateSession(
        mockDaoFactory,
        mockProjectsServiceForExistingProject, projectsUtility, processService, equipmentService,
        electricalService, costScheduleService, mechanicalService, projectBuilder);
    pcWithExistingProject.run(helper);
    Document xmlDoc = helper.getXML();
    DOMUtil.outputXML(xmlDoc);
    assertXpathEvaluatesTo("1", "count(//response)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//projectId)", xmlDoc);
    assertXpathExists("//projectId", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//errors/)", xmlDoc);
    assertXpathNotExists("//errors/error", xmlDoc);
  }

  //todo should have a failure condition test as well for saveAs (conflicting projectNumber, etc)

  private static class MockProjectsServiceForExistingProject extends MockProjectServiceImpl {
    private MockProjectsServiceForExistingProject(Session session) {
      super(session);
    }

    public boolean doesProjectExist(String projectId, String projectNumber) {
      return true;
    }
  }

  private static class MockProjectsServiceForSaveAs extends MockProjectServiceImpl {
    private MockProjectsServiceForSaveAs(Session session) {
      super(session);
    }

    public boolean doesProjectExist(String projectId, String projectNumber) {
      return false;
    }
  }

  private class MockProjectsControllerOverridesClearHibernateSession extends ProjectsController {
    private boolean clearHibernateSessionWasCalled;

    public MockProjectsControllerOverridesClearHibernateSession(
        EISDAOFactory mockDaoFactory,
        ProjectsService projectService, ProjectsUtility projectsUtility,
        ProcessService processService, EquipmentService equipmentService, ElectricalService electricalService,
        CostScheduleService costScheduleService, MechanicalService mechanicalService, ProjectBuilder projectBuilder) {
      super(projectService, projectsUtility, processService, equipmentService, electricalService,
          costScheduleService,
          mechanicalService, projectBuilder, null);
    }

    //protected only for testing
    protected void clearHibernateSession() {
      this.clearHibernateSessionWasCalled = true;
    }

    public boolean isClearHibernateSessionWasCalled() {
      return clearHibernateSessionWasCalled;
    }
  }
}
