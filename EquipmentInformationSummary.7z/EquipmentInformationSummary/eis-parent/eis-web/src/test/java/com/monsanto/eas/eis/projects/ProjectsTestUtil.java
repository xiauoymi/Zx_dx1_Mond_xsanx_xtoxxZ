package com.monsanto.eas.eis.projects;

import org.w3c.dom.Document;
import org.custommonkey.xmlunit.XMLTestCase;

import javax.xml.transform.TransformerException;

/**
 * Created by IntelliJ IDEA.
 * User: vvvelu
 * Date: Sep 27, 2008
 * Time: 4:53:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProjectsTestUtil {

  public static void assertXMLDocumentWhenProjectExists(Document projectDetailXML) throws TransformerException {

    XMLTestCase tc = new XMLTestCase();
    XMLTestCase.assertNotNull(projectDetailXML);
    tc.assertXpathExists("/response", projectDetailXML);
    tc.assertXpathExists("/response/PROJECT_NUMBER", projectDetailXML);
    tc.assertXpathExists("/response/PROJECT_NAME", projectDetailXML);
    tc.assertXpathExists("/response/CROP", projectDetailXML);
    tc.assertXpathExists("/response/PROJECT_LOCATION", projectDetailXML);
    tc.assertXpathExists("/response/UNIT_MEASURE", projectDetailXML);
    tc.assertXpathExists("/response/STATUS", projectDetailXML);
//    tc.assertXpathExists("/response/REVISION_NUMBER", projectDetailXML);
//    tc.assertXpathExists("/response/REVISION_DESCRIPTION", projectDetailXML);
    tc.assertXpathExists("/response/PROJECT_SPONSOR", projectDetailXML);
    tc.assertXpathExists("/response/LEAD_PROCESS", projectDetailXML);
    tc.assertXpathExists("/response/MANUFACTURE_REP", projectDetailXML);
    tc.assertXpathExists("/response/LEAD_MECH_ENGR", projectDetailXML);
    tc.assertXpathExists("/response/LOCATION_MANAGER", projectDetailXML);
    tc.assertXpathExists("/response/LEAD_MECH_DESIGNER", projectDetailXML);
    tc.assertXpathExists("/response/PROJECT_BUYER", projectDetailXML);
    tc.assertXpathExists("/response/PROJECT_CONTROLS", projectDetailXML);
    tc.assertXpathExists("/response/LEAD_ELECT_DESIGNER", projectDetailXML);
    tc.assertXpathExists("/response/STARTUP_DATE", projectDetailXML);
    tc.assertXpathExists("/response/AR_APPROVAL_DATE", projectDetailXML);
    tc.assertXpathExists("/response/LEAD_ELECT_ENGR", projectDetailXML);

    tc.assertXpathEvaluatesTo("12345678", "/response/PROJECT_NUMBER/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("name", "/response/PROJECT_NAME/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("CROP", "/response/CROP/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("Abbeville, AL", "/response/PROJECT_LOCATION/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("British", "/response/UNIT_MEASURE/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("active", "/response/STATUS/text()", projectDetailXML);
//    tc.assertXpathEvaluatesTo("22", "/response/REVISION_NUMBER/text()", projectDetailXML);
//    tc.assertXpathEvaluatesTo("Revision Description", "/response/REVISION_DESCRIPTION/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("firstName, lastName", "/response/PROJECT_SPONSOR/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("firstName, lastName", "/response/LEAD_PROCESS/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("firstName, lastName", "/response/MANUFACTURE_REP/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("firstName, lastName", "/response/LEAD_MECH_ENGR/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("firstName, lastName", "/response/LOCATION_MANAGER/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("firstName, lastName", "/response/LEAD_MECH_DESIGNER/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("firstName, lastName", "/response/PROJECT_CONTROLS/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("firstName, lastName", "/response/LEAD_ELECT_DESIGNER/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("firstName, lastName", "/response/PROJECT_BUYER/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("firstName, lastName", "/response/LEAD_ELECT_ENGR/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("Sep 18, 2008", "/response/STARTUP_DATE/text()", projectDetailXML);
    tc.assertXpathEvaluatesTo("Sep 18, 2008", "/response/AR_APPROVAL_DATE/text()", projectDetailXML);


  }

}
