package com.monsanto.eas.eis.projects;

import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.dao.EquipmentDAO;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.domain.Process;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Order;

import java.util.*;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Sep 3, 2008 Time: 5:10:04 PM To change this template use File | Settings
 * | File Templates.
 */
public class Projects_AT_TestCaseHelper {
  private static HibernateFactory hibernate = EISHibernateUtil.getHibernateFactory();
  private static EISDAOFactory daoFactory = new EISDAOFactoryImpl(hibernate);
  private static ProjectsDAOImpl pDAO = new ProjectsDAOImpl();

  private Projects_AT_TestCaseHelper() {
  }


  public static Projects setupProject() {       
    String projName = "TEST_DELETE_PROJECT_FINAL";
    String projNumber = "55555555";
    Date startupDate = new Date();
    Date arApprovalDate = new Date();

    //ProjectStatusDAOImpl projStatusDAOImpl = new ProjectStatusDAOImpl();
    ProjectStatus projStatus = daoFactory.getProjectStatusDAOImpl().findByPrimaryKey((long) 1);

    //HibernateDAO<UnitMeasure, Long> umDAOImpl = new HibernateDAO<UnitMeasure, Long>(hibernate, UnitMeasure.class);
    UnitMeasure unitMeasure = daoFactory.getUnitMeasureDAOImpl().findByPrimaryKey((long) 1);

    //LocationDAOImpl lDAOImpl = new LocationDAOImpl();

    Location region = daoFactory.getLocationDAOImpl().findByPrimaryKey((long) 1);
    Location country = daoFactory.getLocationDAOImpl().findByPrimaryKey((long) 566937);
    Location state = daoFactory.getLocationDAOImpl().findByPrimaryKey((long) 566978);
    Location city = daoFactory.getLocationDAOImpl().findByPrimaryKey((long) 566979);

    //CropDAOImpl cDAOImpl = new  CropDAOImpl();
    Crop c = daoFactory.getCropDAOImpl().findByPrimaryKey((long) 1);
    
    Projects p = new Projects(projNumber, projName, startupDate, arApprovalDate, projStatus,
        unitMeasure, region, country, state, city, c,
        "RAM", new Date());
    ProjectsDAOImpl pdi = new ProjectsDAOImpl();
    p = pdi.save(p);
    return p;
  }

  public static Equipment setupProjectAndEquipmentAndAssociations() {
    Projects project = setupProject();
    String equipmentNumber = "00.123.W12"; // TODO: Generate this randomly
    String equipmentName = "My Equipment Name";
    String equipmentDescription = "My Equipment Description";
    String processLineNumber = "0";
    String equipmentTagNumber = "123";
    EquipmentType equipmentType = findEquipmentTypeByName("Conveyor");
    EquipmentType subTypeOne = findEquipmentTypeByName("Belt");
    Area area = findAreaById(1L);
    Equipment equipment = new Equipment(equipmentNumber, "0.000.1W1", equipmentName, equipmentDescription, area, processLineNumber,
        equipmentTagNumber, equipmentType, subTypeOne, project);
    Process process = new Process(null, "Ear Corn", new Double(45), new Integer(5000), null, false, new Integer(90),
        new Integer(100), true, findGasTypeByType("Propane"), new Integer(25), new Integer(5), true,
        new Integer(50), new Integer(10), findWaterTypeByType("Processed"), false, new Integer(20),
        findDustTypeByType("Red"), "BH#", new Integer(6), new Integer(500), true, "These are my remarks",
        "123");
    ArrayList<ProcessFieldEquipmentType> pfes = new ArrayList<ProcessFieldEquipmentType>();
    List<FieldEquipmentType> fets = lookupAllFieldEquipmentTypes(equipmentType.getId());
    for(FieldEquipmentType fet: fets){
      pfes.add(new ProcessFieldEquipmentType(null, process, fet, "test fe value"));
    }
    process.setProcessFieldEquipmentTypes(pfes);
    process.setEquipment(equipment);
    equipment.setProcess(process);
    equipment.setMotors(getMotors(equipment));
    equipment.setInstruments(getInstruments(equipment));
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("test vendor");
    equipment.setPurchasing(purchasing);
    Electrical electrical = new Electrical();
    equipment.setElectrical(electrical);
    equipment.setCostSchedule(new CostSchedule());
    Mechanical mechanical = new Mechanical();
    equipment.setMechanical(mechanical);
    equipment = daoFactory.getEquipmentDAOImpl().save(equipment);
    return equipment;
  }

  public static void deleteTestProject(Long projectId) {
    ProjectsDAOImpl projectDAO = daoFactory.getProjectsDAOImpl();
    Projects project = projectDAO.findByPrimaryKey(projectId);
    ProjectStatus ps = findProjectStatusByName("Deleted");
    project.setProjStatus(ps);
    daoFactory.getProjectsDAOImpl().save(project);
  }

  public static Set<Motor> getMotors(Equipment equipment) {
    Set<Motor> list = new HashSet<Motor>();
    list.add(new Motor(null, lookupAllComponentDesignators().get(0), "WE", "Motor Component Name 1", new Double(2),
        new Integer(200),
        new Integer(3), new Integer(3), new Integer(4), lookupAllDesignStatus().get(0),
        "These are my comments 1", lookupAllLoadValueTypes().get(0), new Double(9),
        "Electrical", "IO C 1", true, "500", equipment, "1212"));
    list.add(new Motor(null, lookupAllComponentDesignators().get(1), "RT", "Motor Component Name 2", new Double(2),
        new Integer(200),
        new Integer(3), new Integer(3), new Integer(4), lookupAllDesignStatus().get(1),
        "These are my comments 2", lookupAllLoadValueTypes().get(1), new Double(9),
        "Motor", "IO C 2", true, "501", equipment, "1212"));
    return list;
  }

  public static Set<Instrument> getInstruments(Equipment equipment) {
    Set<Instrument> list = new HashSet<Instrument>();
    list.add(new Instrument(null, lookupAllInstrumentDesignatorsForFirstChar().get(0), lookupAllInstrumentDesignatorsForSecondChar().get(0),
        "XY", "This is my description", lookupAllIoTypes().get(0),
        "Alarm 1", new Integer(7), new Integer(22),
        "XXXX", "watts", "These are my comments", false, new Purchasing(), equipment, null, null, "1212", null, null));
    list.add(new Instrument(null, lookupAllInstrumentDesignatorsForFirstChar().get(1), lookupAllInstrumentDesignatorsForSecondChar().get(1),
        "UV", "This is my description 2", lookupAllIoTypes().get(1),
        "Alarm 2", new Integer(8), new Integer(23),
        "XXXX", "watts 2", "These are my comments 2", true, new Purchasing(), equipment, null, null, null, null, null));
    return list;
  }

  public static Projects findProjectByPrimaryKey(Long id) {
    Projects p = null;
    p = pDAO.findByPrimaryKey(id);
    return p;
  }

  public static List<Equipment> findEquipmentByCriteria(Long projectId) {
    EquipmentDAO dao = daoFactory.getEquipmentDAOImpl();
    Criteria criteria = dao.createCriteria();
    criteria.createAlias("projects", "p");
    criteria.add(Restrictions.eq("p.id", projectId));
    return criteria.list();
  }

  public static EquipmentType findEquipmentTypeByName(String name) {
    EquipmentType et = new EquipmentType();
    et.setName(name);
    List<EquipmentType> list = daoFactory.getEquipmentTypeDAOImpl().findByExample(et, new String[0]);
    return list.get(0);
  }

  public static ProjectStatus findProjectStatusByName(String name) {
    ProjectStatus et = new ProjectStatus();
    et.setName("Deleted");
    List<ProjectStatus> list = daoFactory.getProjectStatusDAOImpl().findByExample(et, new String[0]);
    return list.get(0);
  }

  public static Area findAreaById(Long id) {
    return daoFactory.getAreaDAOImpl().findByPrimaryKey(id);
  }

  public static GasType findGasTypeByType(String type) {
    GenericDAO<GasType, Long> dao = new HibernateDAO<GasType, Long>(hibernate, GasType.class);
    Criteria criteria = dao.createCriteria();
    criteria.add(Restrictions.eq("type", type));
    List list = criteria.list();
    if (list.isEmpty()) {
      return null;
    } else {
      return (GasType) list.get(0);
    }
  }

  public static WaterType findWaterTypeByType(String type) {
    GenericDAO<WaterType, Long> dao = new HibernateDAO<WaterType, Long>(hibernate, WaterType.class);
    Criteria criteria = dao.createCriteria();
    criteria.add(Restrictions.eq("type", type));
    List list = criteria.list();
    if (list.isEmpty()) {
      return null;
    } else {
      return (WaterType) list.get(0);
    }
  }

  public static DustType findDustTypeByType(String type) {
    GenericDAO<DustType, Long> dao = new HibernateDAO<DustType, Long>(hibernate, DustType.class);
    Criteria criteria = dao.createCriteria();
    criteria.add(Restrictions.eq("type", type));
    List list = criteria.list();
    if (list.isEmpty()) {
      return null;
    } else {
      return (DustType) list.get(0);
    }
  }

  public static List<FieldEquipmentType> lookupAllFieldEquipmentTypes(Long equipmentTypeId) {
    GenericDAO<FieldEquipmentType, Long> dao = new HibernateDAO<FieldEquipmentType, Long>(hibernate, FieldEquipmentType.class);
    Criteria criteria = dao.createCriteria();
    criteria.add(Restrictions.eq("equipmentType.id", equipmentTypeId));
    return criteria.list();
  }

  public static List<ComponentDesignator> lookupAllComponentDesignators() {
    GenericDAO<ComponentDesignator, Long> dao = new HibernateDAO<ComponentDesignator, Long>(hibernate, ComponentDesignator.class);
    return dao.findAll();
  }


  public static List<MotorDesignStatus> lookupAllDesignStatus() {
    GenericDAO<MotorDesignStatus, Long> dao = new HibernateDAO<MotorDesignStatus, Long>(hibernate,
        MotorDesignStatus.class);
    return dao.findAll();
  }

  public static List<MotorLoadValueType> lookupAllLoadValueTypes() {
    GenericDAO<MotorLoadValueType, Long> dao = new HibernateDAO<MotorLoadValueType, Long>(hibernate,
        MotorLoadValueType.class);
    return dao.findAll();
  }

  public static List<InstrumentDesignator> lookupAllInstrumentDesignatorsForFirstChar() {
    GenericDAO<InstrumentDesignator, Long> dao = new HibernateDAO<InstrumentDesignator, Long>(hibernate,
        InstrumentDesignator.class);
    Criteria criteria = dao.createCriteria();
    criteria.add(Restrictions.eq("charNum", 1));
    criteria.addOrder(Order.asc("typeCode"));
    return criteria.list();
  }

  public static List<InstrumentDesignator> lookupAllInstrumentDesignatorsForSecondChar() {
    GenericDAO<InstrumentDesignator, Long> dao = new HibernateDAO<InstrumentDesignator, Long>(hibernate,
        InstrumentDesignator.class);
    Criteria criteria = dao.createCriteria();
    criteria.add(Restrictions.eq("charNum", 2));
    criteria.addOrder(Order.asc("typeCode"));
    return criteria.list();
  }

  public static List<IOType> lookupAllIoTypes() {
    GenericDAO<IOType, Long> dao = new HibernateDAO<IOType, Long>(hibernate,
        IOType.class);
    return dao.findAll();
  }

  public static List<AutoManual> lookupAllAutoManuals() {
    GenericDAO<AutoManual, Long> dao = new HibernateDAO<AutoManual, Long>(hibernate,
        AutoManual.class);
    return dao.findAll();
  }

  public static List<AccessoryDesignator> lookupAllAccessoryDesignators() {
    GenericDAO<AccessoryDesignator, Long> dao = new HibernateDAO<AccessoryDesignator, Long>(hibernate,
        AccessoryDesignator.class);
    return dao.findAll();
  }

  public static List<FundingSource> lookupAllFundingSources() {
    GenericDAO<FundingSource, Long> dao = new HibernateDAO<FundingSource, Long>(hibernate,
        FundingSource.class);
    return dao.findAll();
  }

  public static List<ElectricalInput> lookupAllElectricalInputs() {
    GenericDAO<ElectricalInput, Long> dao = new HibernateDAO<ElectricalInput, Long>(hibernate,
        ElectricalInput.class);
    return dao.findAll();
  }

  public static List<ElectricalOutput> lookupAllElectricalOutputs() {
    GenericDAO<ElectricalOutput, Long> dao = new HibernateDAO<ElectricalOutput, Long>(hibernate,
        ElectricalOutput.class);
    return dao.findAll();
  }

}
