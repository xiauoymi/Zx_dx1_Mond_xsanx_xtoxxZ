package com.monsanto.eas.eis.projects.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.projects.services.mock.MockUserService;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Nov 19, 2008 Time: 9:11:14 AM To change this template use File |
 * Settings | File Templates.
 */
public class ProjectRefDataController_UT extends XMLTestCase {

  public void testLookupRefDataForProjectPeople_VerifyXml() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupRefDataForProjectPeople");
    ArrayList<User> users = new ArrayList<User>();
    users.add(new User(new Long(123), null, "testFirst1", "testLast1", null, null));
    users.add(new User(new Long(234), null, "testFirst2", "testLast2", null, null));
    ProjectRefDataController controller = new ProjectRefDataController(new MockUserService(false, false, false, users, null));
    controller.run(helper);
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//refData/projectUsers)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//refData/projectUsers/user)", xmlDoc);
    assertXpathEvaluatesTo("123", "//refData/projectUsers/user/userId", xmlDoc);
    assertXpathEvaluatesTo("testLast1, testFirst1", "//refData/projectUsers/user/name", xmlDoc);
  }
}
