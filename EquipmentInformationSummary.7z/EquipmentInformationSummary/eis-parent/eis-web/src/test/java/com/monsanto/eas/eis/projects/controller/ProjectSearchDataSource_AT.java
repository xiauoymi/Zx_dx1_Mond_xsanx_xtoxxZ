/*
 ProjectSearchDataSource_AT was created on Nov 24, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.projects.Projects_AT_TestCaseHelper;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.Util.StringUtils;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: ProjectSearchDataSource_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-15 19:34:04 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public class ProjectSearchDataSource_AT extends EISTestCase {

  public void testGetData_VerifyResults() throws Exception {
    Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("projectNumber", equipment.getProjects().getProjNumber());
    ProjectSearchDataSource ds = new ProjectSearchDataSource(helper);
    List<? extends XmlObject> data = ds.getData("projNumber", "asc", 0, 1);
    assertTrue(data.size() > 0);
    Projects_AT_TestCaseHelper.deleteTestProject(equipment.getProjects().getId());
  }
}