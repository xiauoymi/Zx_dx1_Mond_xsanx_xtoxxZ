/*
 ProjectSearhDataSource_UT was created on Nov 24, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.controller;

import junit.framework.TestCase;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.dao.mock.MockProjectsDAOImplWithCriteria;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.controller.DataSource;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile: ProjectSearchDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-15 14:28:34 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class ProjectSearchDataSource_UT extends TestCase {

  public void testGetTotalRecords_CalledBeforeGetData_ReturnsUmknownRecordCount() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    MockProjectsDAOImplWithCriteria dao = new MockProjectsDAOImplWithCriteria();
    ProjectSearchDataSource ds = new ProjectSearchDataSource(helper, dao);
    assertEquals(DataSource.UNKNOWN_RECORD_COUNT, ds.getTotalRecords());
  }

  public void testGetData_ActiveProjects() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("projectNumber", " num ");
    helper.setRequestParameterValue("location", " 1 ");
    helper.setRequestParameterValue("country", " 2 ");
    helper.setRequestParameterValue("state", " 3 ");
    helper.setRequestParameterValue("city", " 4 ");
    helper.setRequestParameterValue("crop", " 5 ");
    helper.setRequestParameterValue("status", " 6 ");
    MockProjectsDAOImplWithCriteria dao = new MockProjectsDAOImplWithCriteria();
    ProjectSearchDataSource ds = new ProjectSearchDataSource(helper, dao);
    ds.getData("testSortKey", "testSortDir", 1, 5);
    assertEquals(1, dao.getStartIndex());
    assertEquals(5, dao.getmaxResults());
    assertTrue(dao.wasFindBySearchCriteriaCalled());
    assertEquals("num", dao.getProjectNumber());
    assertEquals("1", dao.getRegionId());
    assertEquals("2", dao.getCountryId());
    assertEquals("3", dao.getStateId());
    assertEquals("4", dao.getCityId());
    assertEquals("5", dao.getCropID());
    assertEquals("6", dao.getStatusID());
    assertTrue(dao.isActiveProjects());
    assertEquals("testSortKey", dao.getSortKey());
    assertEquals("testSortDir", dao.getSortDir());
  }

  public void testGetData_archivedProjects() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("archived", "true");
    helper.setRequestParameterValue("projectNumber", " num ");
    helper.setRequestParameterValue("location", " 1 ");
    helper.setRequestParameterValue("country", " 2 ");
    helper.setRequestParameterValue("state", " 3 ");
    helper.setRequestParameterValue("city", " 4 ");
    helper.setRequestParameterValue("crop", " 5 ");
    helper.setRequestParameterValue("status", " 6 ");
    MockProjectsDAOImplWithCriteria dao = new MockProjectsDAOImplWithCriteria();
    ProjectSearchDataSource ds = new ProjectSearchDataSource(helper, dao);
    ds.getData("testSortKey", "testSortDir", 1, 5);
    assertEquals(1, dao.getStartIndex());
    assertEquals(5, dao.getmaxResults());
    assertTrue(dao.wasFindBySearchCriteriaCalled());
    assertEquals("num", dao.getProjectNumber());
    assertEquals("1", dao.getRegionId());
    assertEquals("2", dao.getCountryId());
    assertEquals("3", dao.getStateId());
    assertEquals("4", dao.getCityId());
    assertEquals("5", dao.getCropID());
    assertEquals("6", dao.getStatusID());
    assertFalse(dao.isActiveProjects());
    assertEquals("testSortKey", dao.getSortKey());
    assertEquals("testSortDir", dao.getSortDir());
  }
}