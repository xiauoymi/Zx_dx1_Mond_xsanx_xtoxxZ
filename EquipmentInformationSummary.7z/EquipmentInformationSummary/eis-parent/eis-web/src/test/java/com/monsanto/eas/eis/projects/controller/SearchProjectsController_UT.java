package com.monsanto.eas.eis.projects.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.eis.projects.EISDAOFactory;
import com.monsanto.eas.eis.projects.mocks.MockEISDAOFactory;
import com.monsanto.eas.eis.projects.mocks.MockProjectServiceImpl;
import com.monsanto.eas.eis.projects.ProjectsUtility;
import com.monsanto.eas.eis.projects.domain.Crop;
import com.monsanto.eas.eis.projects.domain.Location;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: afhyat Date: Sep 2, 2008 Time: 11:28:08 AM To change this template use File |
 * Settings | File Templates.
 */
public class SearchProjectsController_UT extends XMLTestCase {

  private EISDAOFactory mockDaoFactory;
  private SearchProjectsController spc;
  private MockUCCHelper helper;
  private MockProjectServiceImpl projectsService;
  private ProjectsUtility projectUtility;

  protected void setUp() throws Exception {
    super.setUp();
    MockHibernateSession session = new MockHibernateSession();
    mockDaoFactory = new MockEISDAOFactory(session);
    helper = new MockUCCHelper(null);
    projectsService = new MockProjectServiceImpl(session);
    projectUtility = new MockProjectsUtility();
    spc = new SearchProjectsController(mockDaoFactory, projectsService, projectUtility);
  }

  public void testNonSpecified_RequestParamtersSetInHelper() throws IOException {
    helper.setRequestParameterValue(EISConstants.CANCEL_PROJECT_CREATION, "cancel project success");
    spc.run(helper);
    List<Location> locationList = (List<Location>) helper.getRequestAttributeValue(EISConstants.PROJECT_LOCATION_LIST);
    List<Crop> cropList = (List<Crop>) helper.getRequestAttributeValue(EISConstants.PROJECT_CROP_LIST);
    List<ProjectStatus> statusList = (List<ProjectStatus>) helper
        .getRequestAttributeValue(EISConstants.PROJECT_STATUS_LIST);
    assertEquals(2, locationList.size());
    assertEquals("loc 1", locationList.get(0).getName());
    assertEquals("loc 2", locationList.get(1).getName());
    assertEquals(2, cropList.size());
    assertEquals("crop 1", cropList.get(0).getName());
    assertEquals("crop 2", cropList.get(1).getName());
    assertEquals(1, statusList.size());
    assertEquals("New", statusList.get(0).getName());
    assertEquals("cancel project success", helper.getRequestAttributeValue(EISConstants.CANCEL_PROJECT_CREATION));
    assertTrue(helper.wasSentTo(EISConstants.WEB_INF_JSP_PROJECTS_PROJECTS_LIST_JSP));
  }

  public void testLookupProjectStatusAsXml_VerifyXml() throws Exception {
    MockProjectServiceImpl projectService = new MockProjectServiceImpl(new MockHibernateSession());
    SearchProjectsController pc = new SearchProjectsController(null, projectService, null);
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupProjectStatusXml");
    helper.setRequestParameterValue("archivedStatus", "true");
    pc.run(helper);
    assertFalse(projectService.wasAllActiveProjectStatusCalled());
    assertTrue(projectService.wasAllInActiveProjectStatusCalled());
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//refData/projectStatus)", xmlDoc);
  }

  public void testLookupProjectLocationXml_VerifyXml() throws Exception {
    MockProjectServiceImpl projectService = new MockProjectServiceImpl(new MockHibernateSession());
    SearchProjectsController pc = new SearchProjectsController(null, projectService, null);
    helper.setRequestParameterValue("locationId", "1");
    helper.setRequestParameterValue(EISConstants.METHOD, "lookupProjectLocationXml");
    pc.run(helper);
    assertTrue(projectService.wasLookupChildLocationsCalled());
    Document xmlDoc = helper.getXML();
    assertXpathEvaluatesTo("1", "count(//refData)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//refData/location)", xmlDoc);
  }

  private void assertEqualsForRequestAttributes() throws IOException {
    assertEquals("xxx2", helper.getRequestParameterValue("projectNumber"));
    //assertEquals("xxx2", helper.getRequestAttributeValue("PROJECT_NUMBER"));
    assertEquals("1", helper.getRequestParameterValue("location"));
    assertEquals("08/12/2008", helper.getRequestParameterValue("startDateFrom"));
    assertEquals("09/12/2008", helper.getRequestParameterValue("startDateTo"));
    assertEquals("1", helper.getRequestParameterValue("crop"));
    assertEquals("2", helper.getRequestParameterValue("status"));
  }

  private class MockProjectsUtility extends ProjectsUtility {
    public List<Location> getLocations() {
      List<Location> list = new ArrayList<Location>();
      list.add(new Location(null, "loc 1"));
      list.add(new Location(null, "loc 2"));
      return list;
    }

    public List<Crop> getCropsList() {
      List<Crop> list = new ArrayList<Crop>();
      list.add(new Crop(null, "crop 1", null));
      list.add(new Crop(null, "crop 2", null));
      return list;
    }

    @Override
    public Projects saveProject(Projects projects) {
      return projects;
    }
  }
}
