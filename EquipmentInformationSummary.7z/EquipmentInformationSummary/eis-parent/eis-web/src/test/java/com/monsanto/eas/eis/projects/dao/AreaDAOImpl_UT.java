package com.monsanto.eas.eis.projects.dao;

import junit.framework.TestCase;
import com.monsanto.eas.eis.projects.domain.Area;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 15, 2008
 * Time: 4:39:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class AreaDAOImpl_UT extends TestCase {

  // this tests the equals and hashCode method of Areas
  public void testEqualsAndHashCodeInProjects_For2AreasWithSameIDs() throws Exception {
    Area area1 = new Area();
    area1.setId(1L);
    Area area2 = new Area();
    area2.setId(1L);
    assertTrue(area1.equals(area2));
    assertTrue(area1.hashCode() == area2.hashCode());
  }

  // this tests the equals and hashCode method of Projects
  public void testEqualsAndHashCodeInProjects_For2AreasWithDifferentIDs() throws Exception {
    Area area1 = new Area();
    area1.setId(1L);
    Area area2 = new Area();
    area2.setId(2L);
    assertFalse(area1.equals(area2));
    assertFalse(area1.hashCode() == area2.hashCode());
  }

}
