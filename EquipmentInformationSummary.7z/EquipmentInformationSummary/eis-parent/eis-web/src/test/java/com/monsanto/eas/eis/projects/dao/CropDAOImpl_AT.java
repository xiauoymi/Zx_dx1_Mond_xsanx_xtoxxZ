package com.monsanto.eas.eis.projects.dao;

import com.monsanto.eas.eis.projects.domain.Crop;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import junit.framework.TestCase;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Aug 5, 2008
 * Time: 1:26:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropDAOImpl_AT extends EISTestCase {
  private GenericDAO<Crop, Long> cropDAOImpl;

  protected void setUp() throws Exception {
    super.setUp();
    cropDAOImpl = new HibernateDAO<Crop, Long>(EISHibernateUtil.getHibernateFactory(), Crop.class);
  }

  public void testFindAll() {
    List<Crop> crop = cropDAOImpl.findAll();
    assertNotNull(crop);
    assertTrue(crop.size() > 0);
  }

  public void testFindByPrimaryKey() {
    Crop crop = cropDAOImpl.findByPrimaryKey(new Long(1));
    assertNotNull(crop);
    assertTrue(crop.getName().equals("Corn"));
  }

}
