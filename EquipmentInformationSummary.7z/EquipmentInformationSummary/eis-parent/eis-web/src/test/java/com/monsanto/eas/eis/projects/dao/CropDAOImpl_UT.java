package com.monsanto.eas.eis.projects.dao;

import com.monsanto.eas.eis.projects.domain.Crop;
import com.monsanto.eas.eis.projects.mocks.MockCropDAOImpl;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import junit.framework.TestCase;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Aug 4, 2008
 * Time: 8:01:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropDAOImpl_UT extends TestCase {
  private MockCropDAOImpl dao;
  private MockHibernateSession session;

  protected void setUp() throws Exception {
    super.setUp();
    session = new MockHibernateSession();
    dao = new MockCropDAOImpl(session);
  }

  public void testFindByPrimaryKey(){
    Long testID = (long) 1;
    Crop crop = dao.findByPrimaryKey(testID);
    assertNotNull(crop);
    assertNotNull(crop.getId());
    assertNotNull(crop.getName());
    assertEquals(testID, session.getLoadID());
    assertEquals(Crop.class, session.getLoadClass());

   }

  public void testFindAll() {
    List<Crop> crops = dao.findAll();
    Class loadClass = session.getLoadClass();
    assertEquals(Crop.class,loadClass);
    assertTrue(session.getMockHibernateCriteria().wasListCalled());
    for(Crop crop:crops){
      assertNotNull(crop);
      assertNotNull(crop.getName());
    }
  }

    // this tests the equals and hashCode method of Crop
  public void testEqualsInProjectStatus_For2CropssWithSameIDs() throws Exception {
    Crop crop1 = new Crop();
    crop1.setId(1L);
    Crop crop2 = new Crop();
    crop2.setId(1L);
    assertTrue(crop1.equals(crop2));
    assertTrue(crop1.hashCode() == crop2.hashCode());
  }

  // this tests the equals and hashCode method of Crop
  public void testEqualsInProjectStatus_For2ProjectStatusesWithDifferentIDs() throws Exception {
    Crop crop1 = new Crop();
    crop1.setId(1L);
    Crop crop2 = new Crop();
    crop2.setId(2L);
    assertFalse(crop1.equals(crop2));
    assertFalse(crop1.hashCode() == crop2.hashCode());
  }

}
