package com.monsanto.eas.eis.projects.dao;

import com.monsanto.eas.eis.projects.domain.Location;
import com.monsanto.eas.eis.projects.mocks.MockLocationDAOImpl;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.criteria.InExpressionInspector;
import junit.framework.TestCase;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.InExpression;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Aug 6, 2008
 * Time: 5:35:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationDAOImpl_UT extends TestCase {

   private MockLocationDAOImpl dao;
  private MockHibernateSession session;

  protected void setUp() throws Exception {
    super.setUp();
    session = new MockHibernateSession();
    dao = new MockLocationDAOImpl(session);
  }

  public void testFindByPrimaryKey(){
    Long testID = new Long(1);
    Location location = dao.findByPrimaryKey(testID);
    assertEquals(testID, session.getLoadID());
    assertEquals(Location.class, session.getLoadClass());
    assertNotNull(location.getName());
    assertNotNull(location.getId());
    
   }

  public void testFindAll() {
    List<Location> list = dao.findAll();
    Class loadClass = session.getLoadClass();
    assertEquals(Location.class,loadClass);
    assertTrue(session.getMockHibernateCriteria().wasListCalled());
    assertNotNull(list);
  }

  public void testFindByRegion_ToTestInCriteria() throws Exception{
     dao.findByRegion();
    Criteria critTemp = session.createCriteria(Location.class);
    MockCriteria criteria = (MockCriteria) critTemp;
    List<Criterion> criteriaList = criteria.getCriteria();
    Long[] regionIds_test1 = new Long[] {1L, 2L};
    Long[] regionIds_test2 = new Long[] {1L, 2L, 3L};
    assertInCriteriaIsValid(criteriaList,  "id", regionIds_test1, false);
    assertInCriteriaIsValid(criteriaList,  "id", regionIds_test2, true);
  }

  // this tests the equals and hashCode method of Location
  public void testEqualsInLocation_For2LocationsWithSameIDs() throws Exception {
    Location loc1 = new Location();
    loc1.setId(1L);
    Location loc2 = new Location();
    loc2.setId(1L);
    assertTrue(loc1.equals(loc2));
    assertTrue(loc1.hashCode() == loc2.hashCode());
  }

  // this tests the equals and hashCode method of Location
  public void testEqualsInLocation_For2LocationsWithDifferentIDs() throws Exception {
    Location loc1 = new Location();
    loc1.setId(1L);
    Location loc2 = new Location();
    loc2.setId(2L);
    assertFalse(loc1.equals(loc2));
    assertFalse(loc1.hashCode() == loc2.hashCode());
  }

  /**
   * TODO: This code has been copied from ProjectsDAOImpl_UT. I believe this method could be moved to shared area.
   * @param criteriaList
   * @param propertyName
   * @param values
   * @param hasCriteriaNotToBeFound
   */
  private void assertInCriteriaIsValid(List<Criterion> criteriaList, String propertyName, Object values[],
                                          boolean hasCriteriaNotToBeFound) {
    InExpressionInspector inspector = new InExpressionInspector();
    boolean invalidCriterionFound = false;
    for (Criterion crit : criteriaList) {
      InExpression inCrit = (InExpression) crit;

      // assert for property name
      String currPropertyName = inspector.getPropertyName(inCrit);
      assertTrue("Invalid property name found: " + propertyName, currPropertyName.equals(propertyName));

      // assert for property values
      Object currValues[] = inspector.getValues(inCrit);

      ArrayList currValuesList = (ArrayList)Arrays.asList(currValues);
      ArrayList valuesList = (ArrayList)Arrays.asList(values);
      valuesList.removeAll(currValuesList);
      if(valuesList.size() > 0)
        invalidCriterionFound = true;
      if(hasCriteriaNotToBeFound)
        assertTrue("Could not find any invalid criterion for " + propertyName, invalidCriterionFound);
      else
        assertFalse("Found " + valuesList.size() + " invalid critierion for " + propertyName, invalidCriterionFound);
    }
  }
  

}
