package com.monsanto.eas.eis.projects.dao;

import com.monsanto.eas.eis.projects.EISDAOFactory;
import com.monsanto.eas.eis.projects.EISDAOFactoryImpl;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 18, 2008
 * Time: 3:48:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProjectStatusDAOImpl_AT extends EISTestCase {

  private ProjectStatusDAOImpl projectStatusDAOImpl;
  EISDAOFactory daoFactory;

  protected void setUp() throws Exception {
    super.setUp();
    daoFactory = new EISDAOFactoryImpl(EISHibernateUtil.getHibernateFactory());
    projectStatusDAOImpl = new ProjectStatusDAOImpl();
  }
  public void testFindAllExcludingDelete() throws Exception {
    List<ProjectStatus> statusList = projectStatusDAOImpl.findAllExcludingDelete();
    assertNotNull(statusList);
    assertTrue(statusList.size() == 4);
  }
}
