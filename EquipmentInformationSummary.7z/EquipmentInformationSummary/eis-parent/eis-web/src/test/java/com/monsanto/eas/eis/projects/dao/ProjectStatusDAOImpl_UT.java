package com.monsanto.eas.eis.projects.dao;

import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.mock.MockHibernateFactory;
import com.monsanto.wst.hibernate.criteria.NotExpressionInspector;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import junit.framework.TestCase;

import java.util.List;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.NotExpression;
import org.hibernate.criterion.Example;
import org.hibernate.Criteria;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Aug 6, 2008
 * Time: 6:06:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProjectStatusDAOImpl_UT extends TestCase {

   private ProjectStatusDAOImpl dao;
  private MockHibernateSession session;

  protected void setUp() throws Exception {
    super.setUp();
    MockHibernateFactory mockHibernateFactory = new MockHibernateFactory();
    session = (MockHibernateSession) mockHibernateFactory.getSession();
    dao = new ProjectStatusDAOImpl(mockHibernateFactory);
  }
//
//  public void testFindByPrimaryKey(){
//    Long testID = new Long(1);
//    ProjectStatus ps = dao.findByPrimaryKey(testID);
//    assertEquals(testID, session.getLoadID());
//    assertEquals(ProjectStatus.class, session.getLoadClass());
//    assertNotNull(ps.getName());
//    assertNotNull(ps.getId());
//   }

  public void testFindAll() {
    List<ProjectStatus> list =  dao.findAll();
    Class loadClass = session.getLoadClass();
    assertEquals(ProjectStatus.class,loadClass);
    assertTrue(session.getMockHibernateCriteria().wasListCalled());
    assertNotNull(list);
  }

  // this tests the equals and hashCode method of ProjectStatus
  public void testEqualsInProjectStatus_For2ProjectStatusesWithSameIDs() throws Exception {
    ProjectStatus projectStatus1 = new ProjectStatus();
    projectStatus1.setId(1L);
    ProjectStatus projectStatus2 = new ProjectStatus();
    projectStatus2.setId(1L);
    assertTrue(projectStatus1.equals(projectStatus2));
    assertTrue(projectStatus1.hashCode() == projectStatus2.hashCode());
  }

  // this tests the equals and hashCode method of ProjectStatus
  public void testEqualsInProjectStatus_For2ProjectStatusesWithDifferentIDs() throws Exception {
    ProjectStatus projectStatus1 = new ProjectStatus();
    projectStatus1.setId(1L);
    ProjectStatus projectStatus2 = new ProjectStatus();
    projectStatus2.setId(2L);
    assertFalse(projectStatus1.equals(projectStatus2));
    assertFalse(projectStatus1.hashCode() == projectStatus2.hashCode());
  }

  public void testFindAllExcludingDelete() throws Exception {
    dao.findAllExcludingDelete();
    Criteria critTemp = session.createCriteria(ProjectStatus.class);
    ProjectStatus statusDeleted = new ProjectStatus();
    statusDeleted.setId(5L);
    assertCriteria(critTemp);
  }

  private void assertCriteria(Criteria critTemp) {
    MockCriteria criteria = (MockCriteria) critTemp;
    List<Criterion> criteriaList = criteria.getCriteria();
    assertNotNull(criteriaList);
    assertTrue(criteriaList.size() == 1);
    NotExpressionInspector inspector = new NotExpressionInspector();
    Object status = inspector.getCriterion((NotExpression) criteriaList.get(0));
    Example ex = (Example)status;
    System.out.println(ex.toString());  //todo : assert with an ExampleInspector
  }

}
