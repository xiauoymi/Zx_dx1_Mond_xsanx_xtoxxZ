package com.monsanto.eas.eis.projects.dao;

import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.*;
import com.monsanto.eas.eis.projects.services.ProjectsServiceImpl;
import com.monsanto.eas.eis.projects.services.UserService;
import com.monsanto.eas.eis.projects.services.UserServiceImpl;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.eas.eis.audit.service.AuditService;
import com.monsanto.eas.eis.audit.service.AuditServiceImpl;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.alert.domain.AlertForProjectRoleAndStatus;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.dao.GenericDAO;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Aug 5, 2008
 * Time: 1:33:43 PM
 */

public class ProjectsDAOImpl_AT extends EISTestCase {
  private ProjectsDAOImpl projectsDAOImpl;
  private HibernateFactory factory;
  EISDAOFactory daoFactory;
  ProjectsServiceImpl psi;


  protected void setUp() throws Exception {
    super.setUp();
    factory = EISHibernateUtil.getHibernateFactory();
    projectsDAOImpl = new ProjectsDAOImpl();
    daoFactory = new EISDAOFactoryImpl(factory);
    psi = new ProjectsServiceImpl(daoFactory);
  }

  public void testFindByPrimaryKey() {
    Projects p = setUpProject(false);
    saveProject(p);
    Long projectId = null;
    projectId = p.getId();
    Projects project = projectsDAOImpl.findByPrimaryKey(projectId);
    assertNotNull(project);
    assertEquals(project.getId(), p.getId());
    assertEquals(project.getProjName(), p.getProjName());
    String projectIdStringValue = String.valueOf(projectId);
    //psi.deleteProjects(new String[] {projectIdStringValue});
    projectsDAOImpl.delete(project);
  }

  public void testFindAll() {
    List<Projects> projects = null;
    projects = projectsDAOImpl.findAll();
    assertNotNull(projects);
    assertTrue(projects.size() > 0);
    for(Projects p:projects) {
      assertNotNull(p);
    }
  }

  public void testSave_insert(){
    //System.out.println("enterin testSave_insert()");
    Projects p = setUpProject(false);
    saveProject(p);
    Projects insertedProject = projectsDAOImpl.findByPrimaryKey(p.getId());
    assertNotNull(insertedProject);
    String projectIdStringValue = String.valueOf(p.getId());
    //psi.deleteProjects(new String[] {projectIdStringValue});
    projectsDAOImpl.delete(insertedProject);

    //projectsDAOImpl.delete(p);
  }
  
  public void testSave_update() {
    Projects p = setUpProject(false);
    saveProject(p);
    //Projects insertedProject = findByName("TEST_NAME");
    Projects insertedProject = projectsDAOImpl.findByPrimaryKey(p.getId());
    Projects updatedProject = insertedProject;
    String newProjectName = insertedProject.getProjName()+"CHANGED";
    updatedProject.setProjName(newProjectName);
    saveProject(updatedProject);
    updatedProject = projectsDAOImpl.findByPrimaryKey(insertedProject.getId());
    assertEquals(updatedProject.getProjName(), newProjectName);
    //projectsDAOImpl.delete(p);
    String projectIdStringValue = String.valueOf(updatedProject.getId());
    //psi.deleteProjects(new String[] {projectIdStringValue});
    projectsDAOImpl.delete(updatedProject);

  }

  public void testDelete() {
    Projects p = setUpProject(false);
    saveProject(p);
    projectsDAOImpl.delete(p);
    Projects deletedProject = projectsDAOImpl.findByPrimaryKey(p.getId());
    //assertTrue(Projects_AT_TestCaseHelper.findProjectByName(p.getProjName()).getProjStatus().getAccessoryName().equals("Deleted"));
    assertEquals("Deleted", deletedProject.getProjStatus().getName());
  }

  private Projects setUpProject(boolean testFailure) {

    //String projNumber = "11223344";
    String projNumber = GenerateRandomProjectNumber.createRandomWithEightChars();
    String projName = "TEST_NAME "+projNumber;
    Date startupDate = new Date();
    Date arApprovalDate = new Date();

    //ProjectStatusDAOImpl projStatusDAOImpl = new ProjectStatusDAOImpl();
    ProjectStatus projStatus = daoFactory.getProjectStatusDAOImpl().findByPrimaryKey((long)1);
    //System.out.println("ProjectStatus Name: "+ projStatus.getAccessoryName());

    //HibernateDAO<UnitMeasure, Long> umDAOImpl = new HibernateDAO<UnitMeasure, Long>(factory, UnitMeasure.class);
    UnitMeasure unitMeasure = daoFactory.getUnitMeasureDAOImpl().findByPrimaryKey((long)1);
    //System.out.println("UnitMeasure Name: "+ unitMeasure.getAccessoryName());

    //LocationDAOImpl lDAOImpl = new LocationDAOImpl();
    Location region = daoFactory.getLocationDAOImpl().findByPrimaryKey((long)1);
    Location country = daoFactory.getLocationDAOImpl().findByPrimaryKey((long)3);
    Location state = daoFactory.getLocationDAOImpl().findByPrimaryKey((long)7);
    Location city = daoFactory.getLocationDAOImpl().findByPrimaryKey((long)9);
    //System.out.println("Location Name: "+location.getAccessoryName());

    //CropDAOImpl cDAOImpl = new  CropDAOImpl();
    Crop c =  daoFactory.getCropDAOImpl().findByPrimaryKey((long)1);
    //System.out.println("Crop Name: "+ c.getAccessoryName());

    Projects p = null;
    if(!testFailure)  {
      p = new Projects(projNumber, projName, startupDate, arApprovalDate, projStatus,
                              unitMeasure, region, country, state, city, c,
          "RAM", new Date());
    } else {
      p = new Projects(projNumber, projName, startupDate, arApprovalDate, projStatus,
                              unitMeasure, null, country, state, city, c,
          "RAM", new Date());
    }

   return p;
  }

  private void saveProject(Projects p){
    projectsDAOImpl.save(p);

  }

  public void testForAProjectGetChangeOfStatusAndRoleChangeForAProject_ProjectNotInDetailedDesign_ListReturned(){
    HibernateFactory hibernateFactory = EISHibernateUtil.getHibernateFactory();
    Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
    int startIndex = 0;
    int maxResults = 25;
    UserService userService = new UserServiceImpl();
    User user = userService.lookupUserByLogonId("SSCLIN");

    List<ProjectUserRole> projUserRoles = setUpProjectAndEquipmentsForAlert(hibernateFactory, equipment, user);

    hibernateFactory.beginTransaction();
   List<AlertForProjectRoleAndStatus> resultSet = projectsDAOImpl.lookupAllStatusAndRoleChangesInAllProjectsForAUser(projUserRoles,
       "projectNumber", "asc");
    assertEquals(2, resultSet.size());
    AlertForProjectRoleAndStatus roleAndStatusChange = resultSet.get(0);
    assertEquals("EIS_PROJECTS", roleAndStatusChange.getTableName());
    assertEquals("55555555", roleAndStatusChange.getProjectNumber());
    roleAndStatusChange = resultSet.get(1);
    assertEquals("EIS_PROJ_USER_ROLE", roleAndStatusChange.getTableName());
    assertEquals("55555555", roleAndStatusChange.getProjectNumber());
  }


  public void testForAProjectGetListOfEquipmentsForWhichChangeHasNotBeenVerified_ProjectNotInDetailedDesign_ListReturned(){
    HibernateFactory hibernateFactory = EISHibernateUtil.getHibernateFactory();
    Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
    UserService userService = new UserServiceImpl();
    User user = userService.lookupUserByLogonId("SSCLIN");

    List<ProjectUserRole> projUserRoles = setUpProjectAndEquipmentsForAlert(hibernateFactory, equipment, user);

    hibernateFactory.beginTransaction();
    Projects projects = equipment.getProjects();
    String projectId = projects.getId().toString();
    Projects project = new ProjectsDAOImpl().findByPrimaryKey(projects.getId());
    PaginatedResult resultSet = projectsDAOImpl.lookupVerificationsNotApprovedForAnEquipment(
        project.getId().toString(),
        user.getId().toString(), "equipmentNumber", "asc", 0, 25);
    assertEquals(0, resultSet.getTotalRecords());
//    List<Alert> equipmentChangesNotVerifiedList = new ArrayList<Alert>();
//    Alert alertForEquipmentChangesNotVerified = equipmentChangesNotVerifiedList.get(0);
//    assertEquals("STATUS_ID", alertForEquipmentChangesNotVerified.getEquipmentName());
//    assertEquals("55555555", alertForEquipmentChangesNotVerified.getEquipmentNumber());
//    assertEquals(new Integer(1), alertForEquipmentChangesNotVerified.getMechanicalNotVerified());
//    assertEquals(new Integer(1),alertForEquipmentChangesNotVerified.getElectricalNotVerified());
//    assertEquals(new Integer(1),alertForEquipmentChangesNotVerified.getProcessNotVerified());
//
//    alertForEquipmentChangesNotVerified = equipmentChangesNotVerifiedList.get(1);
//    assertEquals("STATUS_ID", alertForEquipmentChangesNotVerified.getEquipmentName());
//    assertEquals("55555555", alertForEquipmentChangesNotVerified.getEquipmentNumber());
//    assertEquals(new Integer(1),alertForEquipmentChangesNotVerified.getMechanicalNotVerified());
//    assertEquals(new Integer(1),alertForEquipmentChangesNotVerified.getElectricalNotVerified());
//    assertEquals(new Integer(1),alertForEquipmentChangesNotVerified.getProcessNotVerified());
  }

  public void testForAProjectGetListOfEquipmentsAddedOrDeleted_ProjectNotInDetailedDesign_ListReturned(){
    HibernateFactory hibernateFactory = EISHibernateUtil.getHibernateFactory();
    Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
    UserService userService = new UserServiceImpl();
    User user = userService.lookupUserByLogonId("SSCLIN");

    List<ProjectUserRole> projUserRoles = setUpProjectAndEquipmentsForAlert(hibernateFactory, equipment, user);


    hibernateFactory.beginTransaction();
    Projects projects = equipment.getProjects();
    Projects project = new ProjectsDAOImpl().findByPrimaryKey(projects.getId());
    Equipment newEquipment = new Equipment();
    newEquipment.setName("Test New");
    newEquipment.setProjects(project);
    hibernateFactory.commitTransaction();

    hibernateFactory.beginTransaction();
    PaginatedResult resultSet = projectsDAOImpl.lookupAllEquipmentsAddedAndDeleted(
        project.getId().toString(),
        "equipmentNumber", "asc", 0, 25);
    assertEquals(0, resultSet.getTotalRecords());
//    List<Alert> equipmentChangesNotVerifiedList = new ArrayList<Alert>();
//    Alert alertForEquipmentChangesNotVerified = equipmentChangesNotVerifiedList.get(0);
//    assertEquals("STATUS_ID", alertForEquipmentChangesNotVerified.getEquipmentName());
//    assertEquals("55555555", alertForEquipmentChangesNotVerified.getEquipmentNumber());
//    assertEquals(new Integer(1), alertForEquipmentChangesNotVerified.getMechanicalNotVerified());
//    assertEquals(new Integer(1),alertForEquipmentChangesNotVerified.getElectricalNotVerified());
//    assertEquals(new Integer(1),alertForEquipmentChangesNotVerified.getProcessNotVerified());
//
//    alertForEquipmentChangesNotVerified = equipmentChangesNotVerifiedList.get(1);
//    assertEquals("STATUS_ID", alertForEquipmentChangesNotVerified.getEquipmentName());
//    assertEquals("55555555", alertForEquipmentChangesNotVerified.getEquipmentNumber());
//    assertEquals(new Integer(1),alertForEquipmentChangesNotVerified.getMechanicalNotVerified());
//    assertEquals(new Integer(1),alertForEquipmentChangesNotVerified.getElectricalNotVerified());
//    assertEquals(new Integer(1),alertForEquipmentChangesNotVerified.getProcessNotVerified());
  }

  private List<ProjectUserRole> setUpProjectAndEquipmentsForAlert(HibernateFactory hibernateFactory,
                                                                  Equipment equipment, User user) {
    GenericDAO<ProjectUserRole, Long> projUserRoleDao = new HibernateDAO<ProjectUserRole, Long>(hibernateFactory, ProjectUserRole.class);
    GenericDAO<ProjectRole, Long> projectRoleDao = new HibernateDAO<ProjectRole, Long>(hibernateFactory, ProjectRole.class);

    hibernateFactory.beginTransaction();
    Projects project = equipment.getProjects();
    ProjectStatus status = new ProjectStatus();
    status.setName("Detailed Design");
    List<ProjectStatus> list = daoFactory.getProjectStatusDAOImpl().findByExample(status, new String[0]);
    project.setProjStatus(list.get(0));

    equipment.setEquipmentNumber("Test 1234");
    equipment.setDescription("Test 1234 description");
    hibernateFactory.commitTransaction();

    hibernateFactory.beginTransaction();
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();

    List<ProjectRole> roleList = projectRoleDao
        .findByExample(new ProjectRole(null, EISConstants.ELECTRICAL_ENGINEER, null), new String[0]);
    ProjectUserRole projectUserRole = new ProjectUserRole(project, user, roleList.get(0), false);
    projUserRoles.add(projectUserRole);
    projUserRoleDao.save(projectUserRole);

    roleList = projectRoleDao
        .findByExample(new ProjectRole(null, EISConstants.MECHANICAL_DESIGNER, null), new String[0]);
    projectUserRole = new ProjectUserRole(project, user, roleList.get(0), false);
    projUserRoles.add(projectUserRole);
    projUserRoleDao.save(projectUserRole);


    roleList = projectRoleDao
        .findByExample(new ProjectRole(null, EISConstants.PROCESS_ENGINEER, null), new String[0]);
    projectUserRole = new ProjectUserRole(project, user, roleList.get(0), false);
    projUserRoles.add(projectUserRole);
    projUserRoleDao.save(projectUserRole);

    hibernateFactory.commitTransaction();

    hibernateFactory.beginTransaction();
    roleList = projectRoleDao
        .findByExample(new ProjectRole(null, EISConstants.MECHANICAL_ENGINEER, null), new String[0]);
    projectUserRole = new ProjectUserRole(project, user, roleList.get(0), false);
    projUserRoles.add(projectUserRole);
    projUserRoleDao.save(projectUserRole);

    AuditService service = new AuditServiceImpl();
    service.insertChangeHistoryEntriesForEachProject(project);
    hibernateFactory.commitTransaction();


    return projUserRoles;
  }


}
