package com.monsanto.eas.eis.projects.dao;

import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.mocks.MockProjectStatusDAOImpl;
import com.monsanto.eas.eis.projects.dao.mock.MockProjectsDAOImplWithCriteria;
import com.monsanto.eas.eis.projects.dao.mock.MockProjectsDAOImplWithCriteriaForReports;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateFactoryForReports;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateSessionForReports;
import com.monsanto.eas.eis.audit.dao.mock.MockSqlQueryForReports;
import com.monsanto.eas.eis.alert.domain.Alert;
import com.monsanto.eas.eis.alert.domain.AlertForProjectRoleAndStatus;
import com.monsanto.eas.eis.alert.domain.AlertForEquipment;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.wst.hibernate.mock.MockHibernateFactory;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import junit.framework.TestCase;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;


/**
 * Created by IntelliJ IDEA. User: VVVELU Date: Aug 4, 2008 Time: 6:02:59 PM To change this template use File | Settings
 * | File Templates.
 */
public class ProjectsDAOImpl_UT extends TestCase {
  private ProjectsDAO pdao;
  private MockHibernateFactory hibernate;
  private MockHibernateSession session;

  private static final long TEST_CROP_ID = 1L;
  private static final long TEST_LOCATION_ID = 2L;
  private static final long TEST_COUNTRY_ID = 3L;
  private static final long TEST_STATE_ID = 4L;
  private static final long TEST_CITY_ID = 5L;
  private static final long TEST_STATUS_ID = 6L;
  private MockProjectStatusDAOImpl mockProjectStatusDAO;

  protected void setUp() throws Exception {
    super.setUp();
    hibernate = new MockHibernateFactory();
    session = (MockHibernateSession) hibernate.getSession();
    mockProjectStatusDAO = new MockProjectStatusDAOImpl(session);
    pdao = new ProjectsDAOImpl(hibernate,
        mockProjectStatusDAO
    );
  }

  public void testFindBySearchCriteria_ForAllValuesGivenActiveProjects_VerifyCriteriaAddAndListWasCalled() {
    String testProjName = "test";

    MockProjectsDAOImplWithCriteria dao = new MockProjectsDAOImplWithCriteria();
    PaginatedResult result = dao
        .findBySearchCriteria(testProjName, Long.toString(TEST_LOCATION_ID), Long.toString(TEST_COUNTRY_ID),
            Long.toString(TEST_STATE_ID), Long.toString(TEST_CITY_ID),
            Long.toString(TEST_CROP_ID), Long.toString(TEST_STATUS_ID), true, "projNumber", "asc", 1, 5);
    assertEquals(10, result.getTotalRecords());
    MockCriteriaForEIS criteria = dao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(8, criteria.getCriteria().size());
    assertEquals("cr.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("re.id=2", criteria.getCriteria().get(1).toString());
    assertEquals("co.id=3", criteria.getCriteria().get(2).toString());
    assertEquals("st.id=4", criteria.getCriteria().get(3).toString());
    assertEquals("ci.id=5", criteria.getCriteria().get(4).toString());
    assertEquals("ps.id<>5", criteria.getCriteria().get(5).toString());
    assertEquals("ps.id=6", criteria.getCriteria().get(6).toString());
    assertEquals("projNumber like %test%", criteria.getCriteria().get(7).toString());
    assertEquals("projNumber asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_MaxResultsIsGreaterThanTotalRecords_MaxResultsIsEqualToTotalRecords() {
    String testProjName = "test";

    MockProjectsDAOImplWithCriteria dao = new MockProjectsDAOImplWithCriteria();
    PaginatedResult result = dao
        .findBySearchCriteria(testProjName, Long.toString(TEST_LOCATION_ID), Long.toString(TEST_COUNTRY_ID),
            Long.toString(TEST_STATE_ID), Long.toString(TEST_CITY_ID),
            Long.toString(TEST_CROP_ID), Long.toString(TEST_STATUS_ID), true, "projNumber", "asc", 1, 11);
    assertEquals(10, result.getTotalRecords());
    MockCriteriaForEIS criteria = dao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(10, criteria.getMaxResult());
    assertEquals(8, criteria.getCriteria().size());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_ForAllValuesGivenArchivedProjects_VerifyCriteriaAddAndListWasCalled() {
    String testProjName = "test";

    MockProjectsDAOImplWithCriteria dao = new MockProjectsDAOImplWithCriteria();
    dao.findBySearchCriteria(testProjName, Long.toString(TEST_LOCATION_ID), Long.toString(TEST_COUNTRY_ID),
        Long.toString(TEST_STATE_ID), Long.toString(TEST_CITY_ID),
        Long.toString(TEST_CROP_ID), null, false, "projNumber", "asc", 1, 5);
    MockCriteriaForEIS criteria = dao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(8, criteria.getCriteria().size());
    assertEquals("cr.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("re.id=2", criteria.getCriteria().get(1).toString());
    assertEquals("co.id=3", criteria.getCriteria().get(2).toString());
    assertEquals("st.id=4", criteria.getCriteria().get(3).toString());
    assertEquals("ci.id=5", criteria.getCriteria().get(4).toString());
    assertEquals("ps.id<>5", criteria.getCriteria().get(5).toString());
    assertEquals("ps.id in (3, 4)", criteria.getCriteria().get(6).toString());
    assertEquals("projNumber like %test%", criteria.getCriteria().get(7).toString());
    assertEquals("projNumber asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_NoStatusActiveProjects_VerifyCriteriaAddAndListWasCalled() {
    String testProjName = "test";

    MockProjectsDAOImplWithCriteria dao = new MockProjectsDAOImplWithCriteria();
    dao.findBySearchCriteria(testProjName, Long.toString(TEST_LOCATION_ID), Long.toString(TEST_COUNTRY_ID),
        Long.toString(TEST_STATE_ID), Long.toString(TEST_CITY_ID),
        Long.toString(TEST_CROP_ID), null, true, "projNumber", "asc", 1, 5);
    MockCriteriaForEIS criteria = dao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(8, criteria.getCriteria().size());
    assertEquals("cr.id=1", criteria.getCriteria().get(0).toString());
    assertEquals("re.id=2", criteria.getCriteria().get(1).toString());
    assertEquals("co.id=3", criteria.getCriteria().get(2).toString());
    assertEquals("st.id=4", criteria.getCriteria().get(3).toString());
    assertEquals("ci.id=5", criteria.getCriteria().get(4).toString());
    assertEquals("ps.id<>5", criteria.getCriteria().get(5).toString());
    assertEquals("ps.id in (1, 2)", criteria.getCriteria().get(6).toString());
    assertEquals("projNumber like %test%", criteria.getCriteria().get(7).toString());
    assertEquals("projNumber asc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_SortByCity_VerifyCriteriaAddAndListWasCalled() {
    MockProjectsDAOImplWithCriteria dao = new MockProjectsDAOImplWithCriteria();
    dao.findBySearchCriteria(null, null, null, null, null, null, null, true, "cityName", "desc", 1, 5);
    MockCriteriaForEIS criteria = dao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(2, criteria.getCriteria().size());
    assertEquals("ps.id<>5", criteria.getCriteria().get(0).toString());
    assertEquals("ps.id in (1, 2)", criteria.getCriteria().get(1).toString());
    assertEquals("ci.name desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_SortByStatus_VerifyCriteriaAddAndListWasCalled() {
    MockProjectsDAOImplWithCriteria dao = new MockProjectsDAOImplWithCriteria();
    dao.findBySearchCriteria(null, null, null, null, null, null, null, true, "projStatusName", "desc", 1, 5);
    MockCriteriaForEIS criteria = dao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(2, criteria.getCriteria().size());
    assertEquals("ps.id<>5", criteria.getCriteria().get(0).toString());
    assertEquals("ps.id in (1, 2)", criteria.getCriteria().get(1).toString());
    assertEquals("ps.name desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testFindBySearchCriteria_SortByStartupDate_VerifyCriteriaAddAndListWasCalled() {
    MockProjectsDAOImplWithCriteria dao = new MockProjectsDAOImplWithCriteria();
    dao.findBySearchCriteria(null, null, null, null, null, null, null, true, "startupDate", "desc", 1, 5);
    MockCriteriaForEIS criteria = dao.getMockCriteria();
    assertEquals(1, criteria.getFirstResult());
    assertEquals(5, criteria.getMaxResult());
    assertEquals(2, criteria.getCriteria().size());
    assertEquals("ps.id<>5", criteria.getCriteria().get(0).toString());
    assertEquals("ps.id in (1, 2)", criteria.getCriteria().get(1).toString());
    assertEquals("startupDate desc", criteria.getOrderings().get(0).toString());
    assertTrue(criteria.wasListCalled());
  }

  public void testDeleteProjects_ForGivenProjectIDs_WasDeleteCalled() throws Exception {
    Projects project = new Projects();
    project.setId(1L);
    pdao.delete(project);
    assertTrue(mockProjectStatusDAO.wasFindByPrimaryKeyCalled());
  }

  public void testLookupAllVerificationsNotApprovedForAProject_ProjectIsInDetailDesign_ListReturned() throws Exception{
    MockHibernateFactoryForReports mockHibernateFactory = new MockHibernateFactoryForReports(
        getGetListWithDataInCorrectSortOrder());
    MockProjectsDAOImplWithCriteriaForReports projectDaoForReports = new MockProjectsDAOImplWithCriteriaForReports(
        mockHibernateFactory);
    PaginatedResult result = projectDaoForReports.lookupVerificationsNotApprovedForAnEquipment("1", "RRMALL", "equipmentNumber", "asc", 0, 25);
     MockHibernateFactoryForReports hibernate = (MockHibernateFactoryForReports) projectDaoForReports.getHibernateFactory();
    MockHibernateSessionForReports mockSessionForReports = hibernate.getHibernateSessionForReports();
    MockSqlQueryForReports mockSQLQueryForReports = (MockSqlQueryForReports) mockSessionForReports.getSqlQueryForReports();
    assertEquals("select * from (select row_.*, rownum rownum_  from ( select tranApprovalPerEquipment.processNotVerified, tranApprovalPerEquipment.mechanicalNotVerified, tranApprovalPerEquipment.electricalNotVerified, equip.id as id, equip.name as name, equip.equipment_number as equipmentNumber, p.id as projectId from eis.eis_projects p inner join eis.eis_equipment equip on equip.projects_id = p.id  inner join (select approvalCount.* from ( select sum(decode(ata.process, null, 1, 0)) as processNotVerified, sum(decode(ata.mechanical,null, 1, 0)) as mechanicalNotVerified, sum(decode(ata.electrical,null, 1, 0))  as electricalNotVerified, e.id as id from eis.eis_equipment e,  eis.audit_transaction_approval ata  where ata.change_datetime IN ( SELECT MAX(tranapproval.change_datetime) FROM eis.audit_transaction_approval tranapproval,eis.eis_equipment e1  WHERE tranapproval.equipment_id = e1.idAND e1.id = e.id  GROUP BY tranapproval.column_name ) and e.projects_id = 1  and nvl(e.is_deleted, 'N') <> 'Y' group by e.id) approvalCount where (approvalCount.processNotVerified > 0 or approvalCount.mechanicalNotVerified > 0 or approvalCount.electricalNotVerified > 0))tranApprovalPerEquipment on tranApprovalPerEquipment.id = equip.id  where p.id = 1 order by equipmentNumber asc) row_ where rownum <=25) where rownum_ > 0",
        mockSQLQueryForReports.getSqlQueryStringForReports().replaceAll("\n", "").replaceAll("   ", ""));
    assertEquals(2, result.getTotalRecords());
    Alert alert = (Alert)result.getData().get(0);
    assertEquals(new Integer(11), alert.getEquipmentId());
    assertEquals("Equipment Name 1", alert.getEquipmentName());
    assertEquals("Equipment Number 1", alert.getEquipmentNumber());
    assertEquals(new Integer(1), alert.getProcessNotVerified());
    assertEquals(new Integer(2), alert.getMechanicalNotVerified());
    assertEquals(new Integer(3), alert.getElectricalNotVerified());
  }


  public void testLookupAllEquipmentAddedAndDeletedInAProject_ProjectIsInDetailDesign_ListReturned() throws Exception{
    MockHibernateFactoryForReports mockHibernateFactory = new MockHibernateFactoryForReports(
        getGetListWithDataForEquipmentAddedAndDeletedInCorrectSortOrder());
    MockProjectsDAOImplWithCriteriaForReports projectDaoForReports = new MockProjectsDAOImplWithCriteriaForReports(
        mockHibernateFactory);
    PaginatedResult result = projectDaoForReports.lookupAllEquipmentsAddedAndDeleted("1", "equipmentNumber", "asc", 0, 25);
     MockHibernateFactoryForReports hibernate = (MockHibernateFactoryForReports) projectDaoForReports.getHibernateFactory();
    MockHibernateSessionForReports mockSessionForReports = hibernate.getHibernateSessionForReports();
    MockSqlQueryForReports mockSQLQueryForReports = (MockSqlQueryForReports) mockSessionForReports.getSqlQueryForReports();
    assertEquals("select * from (select row_.*, rownum rownum_  from ( select equipment.id as id, equipment.equipment_number as equipmentNumber,h.change_datetime dateModified, h.operation_type addedOrDeleted,t.audit_requestor modifiedBy, equipment.projects_id projectId from eis.audit_header_view_ins_del h, eis.eis_equipment equipment, eis.audit_transaction t, eis.eis_user uwhere h.key_value = to_char(equipment.id)and h.table_name = 'EIS_EQUIPMENT'and h.operation_type in ('I', 'D')and h.change_datetime between (systimestamp - 20) and systimestamp and h.change_datetime >= (select max(h1.change_datetime) from eis.audit_header h1  left outer join eis.audit_detail d1 on d1.audit_header_id = h1.audit_header_id where key_value = '1' and d1.column_name = 'STATUS_ID' and d1.new_value = (select id from eis.eis_proj_status where status_name = 'Detailed Design'))  and t.audit_transaction_id = h.audit_transaction_id and t.audit_requestor = u.user_idand equipment.id in (select id from eis.eis_equipment eq where eq.projects_id  = 1) order by equipmentNumber asc) row_ where rownum <=25) where rownum_ > 0",
        mockSQLQueryForReports.getSqlQueryStringForReports().replaceAll("\n", "").replaceAll("   ", ""));
    assertEquals(2, result.getTotalRecords());
    AlertForEquipment alert = (AlertForEquipment)result.getData().get(0);
    assertEquals(new Integer(1), alert.getId());
    assertEquals("1.1.111", alert.getEquipmentNumber());
    assertEquals("I", alert.getAddedOrDeleted());
    assertEquals("TEST 1", alert.getModifiedBy());
    alert = (AlertForEquipment)result.getData().get(1);
    assertEquals(new Integer(2), alert.getId());
    assertEquals("1.1.222", alert.getEquipmentNumber());
    assertEquals("D", alert.getAddedOrDeleted());
    assertEquals("TEST 1", alert.getModifiedBy());
  }


  public void testLookupAllEquipmentAddedAndDeletedInAProject_ProjectIsInDetailDesign_NoEquipmentsAddedOrDleted_EmptyListReturned() throws Exception{
    MockHibernateFactoryForReports mockHibernateFactory = new MockHibernateFactoryForReports(
        new ArrayList());
    MockProjectsDAOImplWithCriteriaForReports projectDaoForReports = new MockProjectsDAOImplWithCriteriaForReports(
        mockHibernateFactory);
    PaginatedResult result = projectDaoForReports.lookupAllEquipmentsAddedAndDeleted("1", "equipmentNumber", "asc", 0, 25);
     MockHibernateFactoryForReports hibernate = (MockHibernateFactoryForReports) projectDaoForReports.getHibernateFactory();
    MockHibernateSessionForReports mockSessionForReports = hibernate.getHibernateSessionForReports();
    MockSqlQueryForReports mockSQLQueryForReports = (MockSqlQueryForReports) mockSessionForReports.getSqlQueryForReports();
    assertEquals("select * from (select row_.*, rownum rownum_  from ( select equipment.id as id, equipment.equipment_number as equipmentNumber,h.change_datetime dateModified, h.operation_type addedOrDeleted,t.audit_requestor modifiedBy, equipment.projects_id projectId from eis.audit_header_view_ins_del h, eis.eis_equipment equipment, eis.audit_transaction t, eis.eis_user uwhere h.key_value = to_char(equipment.id)and h.table_name = 'EIS_EQUIPMENT'and h.operation_type in ('I', 'D')and h.change_datetime between (systimestamp - 20) and systimestamp and h.change_datetime >= (select max(h1.change_datetime) from eis.audit_header h1  left outer join eis.audit_detail d1 on d1.audit_header_id = h1.audit_header_id where key_value = '1' and d1.column_name = 'STATUS_ID' and d1.new_value = (select id from eis.eis_proj_status where status_name = 'Detailed Design'))  and t.audit_transaction_id = h.audit_transaction_id and t.audit_requestor = u.user_idand equipment.id in (select id from eis.eis_equipment eq where eq.projects_id  = 1) order by equipmentNumber asc) row_ where rownum <=25) where rownum_ > 0",
        mockSQLQueryForReports.getSqlQueryStringForReports().replaceAll("\n", "").replaceAll("   ", ""));
    List resultList = result.getData();
    assertEquals(0, resultList.size());
  }

  private List getGetListWithDataForEquipmentAddedAndDeletedInCorrectSortOrder() {
    Object[] result = new Object[10];
        List<Object[]> alertList = new ArrayList<Object[]>();
        result[0] = new Integer(1);
        result[1] = new String("1.1.111");
        result[2] = new Date();
        result[3] = new String("I");
        result[4] = "TEST 1";
        alertList.add(result);
        result = new Object[20];
        result[0] = new Integer(2);
        result[1] = new String("1.1.222");
        result[2] = new Date();
        result[3] = new String("D");
        result[4] = "TEST 1";
        alertList.add(result);
    return alertList;
  }


  public void testlookupAllStatusAndRoleChangesInAllProjectsForAUser_ListReturned() throws Exception{
    MockHibernateFactoryForReports mockHibernateFactory = new MockHibernateFactoryForReports(
        getGetListWithDataForProjectRoleAndStatus());
    MockProjectsDAOImplWithCriteriaForReports projectDaoForReports = new MockProjectsDAOImplWithCriteriaForReports(
        mockHibernateFactory);
     User user = new User(new Long(123), "RRMALL", "testFirst1", "testLast1", null, null);
    Projects project = new Projects();
    project.setId(new Long(1));
    project.setProjNumber("111");
    project.setProjName("Test Project");
    project.setProjStatus(new ProjectStatus(null, EISConstants.PROJECT_STATUS_DETAILED_DESIGN));
     List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    ProjectUserRole projectUserRole = new ProjectUserRole(project, user,
        new ProjectRole(new Long(2), EISConstants.ELECTRICAL_ENGINEER, null), false);
    projectUserRole.setId(new Long(2));
    projUserRoles.add(projectUserRole);
    projectUserRole = new ProjectUserRole(project, user, new ProjectRole(new Long(3),
        EISConstants.MECHANICAL_DESIGNER, null), false);
    projectUserRole.setId(new Long(3));
    projUserRoles.add(projectUserRole);
    projectUserRole = new ProjectUserRole(project, user, new ProjectRole(new Long(4),
        EISConstants.PROCESS_ENGINEER, null), false);
    projectUserRole.setId(new Long(4));
    projUserRoles.add(projectUserRole);
    List<AlertForProjectRoleAndStatus> result = projectDaoForReports.lookupAllStatusAndRoleChangesInAllProjectsForAUser(projUserRoles,
        "projectNumber", "asc");
     MockHibernateFactoryForReports hibernate = (MockHibernateFactoryForReports) projectDaoForReports.getHibernateFactory();
    MockHibernateSessionForReports mockSessionForReports = hibernate.getHibernateSessionForReports();
    MockSqlQueryForReports mockSQLQueryForReports = (MockSqlQueryForReports) mockSessionForReports.getSqlQueryForReports();
//    assertEquals("SELECT modifiedby, change_datetime AS changeDateTime, psv.TABLE_NAME AS tablename, p.proj_number projectnumber, p.id id FROM eis.audit_proj_status_view psv, eis.eis_projects p WHERE psv.TABLE_NAME = 'EIS_PROJECTS' AND psv.key_value IN('1','2','3','4') AND psv.key_value = to_char(p.id) UNION select t.audit_requestor modifiedBy, innerQuery.* from  ( select max(change_datetime) AS changeDateTime, psv.TABLE_NAME AS tablename, p.proj_number projectnumber, p.id as id FROM eis.AUD_PROJ_STAT_ROLE_CHG_VIEW psv,eis.eis_proj_user_role pur, eis.eis_projects p WHERE psv.TABLE_NAME = 'EIS_PROJ_USER_ROLE' AND psv.key_value IN('1','2','3','4') AND psv.key_value = to_char(pur.id)  AND pur.project_id = p.id group by p.id, psv.TABLE_NAME, p.proj_number, p.id  )innerQuery left outer join eis.audit_header h on h.change_datetime = innerQuery.changeDateTime left outer join eis.audit_transaction t on t.audit_transaction_id = h.audit_transaction_id",
     //   mockSQLQueryForReports.getSqlQueryStringForReports().replaceAll("\n", "").replaceAll("   ", ""));
    AlertForProjectRoleAndStatus alert = result.get(0);
    assertEquals(new Integer(1), alert.getId());
    assertEquals("1.1.22", alert.getProjectNumber());
    assertEquals("STATUS_ID", alert.getTableName());
    assertEquals("RRMALL", alert.getModifiedBy());
    alert = result.get(1);
    assertEquals(new Integer(2), alert.getId());
    assertEquals("1.1.33", alert.getProjectNumber());
    assertEquals("PROJ_ROLE_ID", alert.getTableName());
    assertEquals("RRMALL", alert.getModifiedBy());
  }

  public void testlookupAllStatusAndRoleChangesInAllProjectsForAUser_NoChangesFound_EmptyListReturned() throws Exception{
    MockHibernateFactoryForReports mockHibernateFactory = new MockHibernateFactoryForReports(
        new ArrayList());
    MockProjectsDAOImplWithCriteriaForReports projectDaoForReports = new MockProjectsDAOImplWithCriteriaForReports(
        mockHibernateFactory);
     User user = new User(new Long(123), "RRMALL", "testFirst1", "testLast1", null, null);
    Projects project = new Projects();
    project.setId(new Long(1));
    project.setProjNumber("111");
    project.setProjName("Test Project");
    project.setProjStatus(new ProjectStatus(null, EISConstants.PROJECT_STATUS_DETAILED_DESIGN));
     List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
     ProjectUserRole projectUserRole = new ProjectUserRole(project, user,
        new ProjectRole(new Long(2), EISConstants.ELECTRICAL_ENGINEER, null), false);
    projectUserRole.setId(new Long(2));
    projUserRoles.add(projectUserRole);
    projectUserRole = new ProjectUserRole(project, user, new ProjectRole(new Long(3),
        EISConstants.MECHANICAL_DESIGNER, null), false);
    projectUserRole.setId(new Long(3));
    projUserRoles.add(projectUserRole);
    projectUserRole = new ProjectUserRole(project, user, new ProjectRole(new Long(4),
        EISConstants.PROCESS_ENGINEER, null), false);
    projectUserRole.setId(new Long(4));
    projUserRoles.add(projectUserRole);
    List<AlertForProjectRoleAndStatus> result = projectDaoForReports.lookupAllStatusAndRoleChangesInAllProjectsForAUser(projUserRoles,
        "projectNumber", "asc");
     MockHibernateFactoryForReports hibernate = (MockHibernateFactoryForReports) projectDaoForReports.getHibernateFactory();
    MockHibernateSessionForReports mockSessionForReports = hibernate.getHibernateSessionForReports();
    MockSqlQueryForReports mockSQLQueryForReports = (MockSqlQueryForReports) mockSessionForReports.getSqlQueryForReports();
  //  assertEquals("SELECT modifiedby, change_datetime AS changeDateTime, psv.TABLE_NAME AS tablename, p.proj_number projectnumber, p.id id FROM eis.audit_proj_status_view psv, eis.eis_projects p WHERE psv.TABLE_NAME = 'EIS_PROJECTS' AND psv.key_value IN('1','2','3','4') AND psv.key_value = to_char(p.id) UNION select t.audit_requestor modifiedBy, innerQuery.* from  ( select max(change_datetime) AS changeDateTime, psv.TABLE_NAME AS tablename, p.proj_number projectnumber, p.id as id FROM eis.AUD_PROJ_STAT_ROLE_CHG_VIEW psv,eis.eis_proj_user_role pur, eis.eis_projects p WHERE psv.TABLE_NAME = 'EIS_PROJ_USER_ROLE' AND psv.key_value IN('1','2','3','4') AND psv.key_value = to_char(pur.id)  AND pur.project_id = p.id group by p.id, psv.TABLE_NAME, p.proj_number, p.id  )innerQuery left outer join eis.audit_header h on h.change_datetime = innerQuery.changeDateTime left outer join eis.audit_transaction t on t.audit_transaction_id = h.audit_transaction_id",
 //       mockSQLQueryForReports.getSqlQueryStringForReports().replaceAll("\n", "").replaceAll("   ", ""));
    assertEquals(0, result.size());
  }

  public List getGetListWithDataInCorrectSortOrder() {
      Object[] result = new Object[10];
        List<Object[]> alertList = new ArrayList<Object[]>();
        result[0] = new Integer(1);
        result[1] = new Integer(2);
        result[2] = new Integer(3);
        result[3] = new Integer(11);
        result[4] = "Equipment Name 1";
        result[5] = "Equipment Number 1";
        alertList.add(result);
        result = new Object[20];
         result[0] = new Integer(21);
        result[1] = new Integer(22);
        result[2] = new Integer(23);
        result[3] = new Integer(22);
        result[4] = "Equipment Name 2";
        result[5] = "Equipment Number 2";
        alertList.add(result);
    return alertList;
  }

  private List getGetListWithDataForProjectRoleAndStatus() {
      Object[] result = new Object[20];
        List<Object[]> projectStatusRoleChangeList = new ArrayList<Object[]>();
        result[4] = new Integer("1");
        result[3] = "1.1.22";
        result[2] = "STATUS_ID";
        result[1] = new Date();
        result[0] = "RRMALL";
        projectStatusRoleChangeList.add(result);
        result = new Object[20];
        result[4] = new Integer("2");
        result[3] = "1.1.33";
        result[2] = "PROJ_ROLE_ID";
        result[1] = new Date();
        result[0] = "RRMALL";
        projectStatusRoleChangeList.add(result);
    return projectStatusRoleChangeList;
  }
}
