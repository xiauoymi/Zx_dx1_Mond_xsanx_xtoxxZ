package com.monsanto.eas.eis.projects.dao;

import com.monsanto.eas.eis.projects.domain.UnitMeasure;
import com.monsanto.eas.eis.projects.mocks.MockUnitMeasureDAOImpl;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import junit.framework.TestCase;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Aug 6, 2008
 * Time: 6:09:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class UnitMeasureDAOImpl_UT extends TestCase {
  private MockUnitMeasureDAOImpl dao;
  private MockHibernateSession session;

  protected void setUp() throws Exception {
    super.setUp();
    session = new MockHibernateSession();
    dao = new MockUnitMeasureDAOImpl(session);
  }

  public void testFindByPrimaryKey(){
    Long testID = new Long(1);
    UnitMeasure um = dao.findByPrimaryKey(testID);
    assertEquals(testID, session.getLoadID());
    assertEquals(UnitMeasure.class, session.getLoadClass());
    assertNotNull(um.getName());
    assertNotNull(um.getId());
   }

  public void testFindAll() {
    List<UnitMeasure> list =  dao.findAll();
    Class loadClass = session.getLoadClass();
    assertEquals(UnitMeasure.class,loadClass);
    assertTrue(session.getMockHibernateCriteria().wasListCalled());
    assertNotNull(list) ;
  }



}
