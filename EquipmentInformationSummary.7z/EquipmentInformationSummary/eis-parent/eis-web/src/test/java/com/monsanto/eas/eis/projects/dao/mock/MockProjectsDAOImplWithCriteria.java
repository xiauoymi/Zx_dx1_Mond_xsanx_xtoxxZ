/*
 MockProjectsDAOImplWithCriteria was created on Dec 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.dao.mock;

import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import org.hibernate.Criteria;

/**
 * Filename:    $RCSfile: MockProjectsDAOImplWithCriteria.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-11 15:18:06 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class MockProjectsDAOImplWithCriteria extends ProjectsDAOImpl {
  private MockCriteriaForEIS mockCriteria;

  //used only for testing
  public Criteria getCriteria() {
    mockCriteria = new MockCriteriaForEIS(new Integer(10), null);
    return mockCriteria;
  }

  public MockCriteriaForEIS getMockCriteria() {
    return mockCriteria;
  }

  private boolean wasFindBySearchCriteriaCalled;
  private String projectNumber;
  private String regionId;
  private String countryId;
  private String stateId;
  private String cityId;
  private String cropID;
  private String statusID;
  private boolean activeProjects;
  private String sortKey;
  private String sortDir;
  private int startIndex;
  private int maxResults;

  public PaginatedResult findBySearchCriteria(String projectNumber, String regionId, String countryId, String stateId,
                                              String cityId, String cropID, String statusID, boolean activeProjects,
                                              String sortKey, String sortDir, int startIndex, int maxResults) {
    this.projectNumber = projectNumber;
    this.regionId = regionId;
    this.countryId = countryId;
    this.stateId = stateId;
    this.cityId = cityId;
    this.cropID = cropID;
    this.statusID = statusID;
    this.activeProjects = activeProjects;
    this.sortKey = sortKey;
    this.sortDir = sortDir;
    this.startIndex = startIndex;
    this.maxResults = maxResults;
    this.wasFindBySearchCriteriaCalled = true;
    return super.findBySearchCriteria(projectNumber, regionId, countryId, stateId, cityId, cropID, statusID,
        activeProjects, sortKey, sortDir, startIndex, maxResults);
  }

  public boolean wasFindBySearchCriteriaCalled() {
    return wasFindBySearchCriteriaCalled;
  }

  public String getProjectNumber() {
    return projectNumber;
  }

  public String getRegionId() {
    return regionId;
  }

  public String getCountryId() {
    return countryId;
  }

  public String getStateId() {
    return stateId;
  }

  public String getCityId() {
    return cityId;
  }

  public String getCropID() {
    return cropID;
  }

  public String getStatusID() {
    return statusID;
  }

  public boolean isActiveProjects() {
    return activeProjects;
  }

  public String getSortKey() {
    return sortKey;
  }

  public String getSortDir() {
    return sortDir;
  }

  public int getStartIndex() {
    return startIndex;
  }

  public int getmaxResults() {
    return maxResults;
  }
}