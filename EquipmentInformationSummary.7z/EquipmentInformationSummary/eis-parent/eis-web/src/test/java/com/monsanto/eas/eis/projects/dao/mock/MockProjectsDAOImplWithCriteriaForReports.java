/*
 MockProjectsDAOImplWithCriteriaForReports was created on Feb 10, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.dao.mock;

import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateFactoryForReports;

/**
 * Filename:    $RCSfile: MockProjectsDAOImplWithCriteriaForReports.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-11 19:49:26 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class MockProjectsDAOImplWithCriteriaForReports extends ProjectsDAOImpl {
  private MockHibernateFactoryForReports hibernateFactory;

  public MockProjectsDAOImplWithCriteriaForReports(MockHibernateFactoryForReports hibernate) {
    super(hibernate, null);
    this.hibernateFactory = hibernate;
  }

  public PaginatedResult lookupVerificationsNotApprovedForAnEquipment(String projectId, String userId, String sortKey,
                                                                      String sortDir, int startIndex, int maxResults) {
    return super
        .lookupVerificationsNotApprovedForAnEquipment(projectId, userId, sortKey, sortDir, startIndex, maxResults);
  }

  public MockHibernateFactoryForReports getHibernateFactory() {
    return hibernateFactory;
  }
}