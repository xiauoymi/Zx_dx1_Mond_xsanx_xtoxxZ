package com.monsanto.eas.eis.projects.datasource;

import junit.framework.TestCase;
import com.monsanto.eas.eis.controller.XmlObject;
import com.monsanto.eas.eis.util.EISConstants;
import com.monsanto.eas.eis.projects.domain.ProjectUserRole;
import com.monsanto.eas.eis.projects.mocks.MockProjectServiceImpl;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.hibernate.HibernateFactory;

import java.util.List;

import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Dec 17, 2008 Time: 6:01:56 PM To change this template use File |
 * Settings | File Templates.
 */
public class ProjectUserRoleDataSource_UT extends TestCase {

  public void testGetData_ProjectIdIsBlank_ReturnsEmptyList() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ROLE, "testRole 1");
   ProjectUserRoleDataSource projectUserRoleDataSource = new ProjectUserRoleDataSource(helper,
        new MockProjectServiceImpl((Session)null));
    List<? extends XmlObject> data = projectUserRoleDataSource.getData(null, null, 0, 0);
    assertNotNull(data);
    assertEquals(0, data.size());
  }

  public void testGetData_ProjectIdIsNotBlank_ReturnsList() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(EISConstants.PROJECT_ID, "234");
    helper.setRequestParameterValue(EISConstants.PROJECT_ROLE, "testRole 1");
   ProjectUserRoleDataSource projectUserRoleDataSource = new ProjectUserRoleDataSource(helper,
        new MockProjectServiceImpl((Session)null));
    List<? extends XmlObject> data = projectUserRoleDataSource.getData(null, null, 0, 0);
    assertNotNull(data);
    assertEquals(2, data.size());
    assertEquals(new Long(234), ((ProjectUserRole) data.get(0)).getProject().getId());
    assertEquals("testRole 1", ((ProjectUserRole) data.get(0)).getProjRole().getName());
  }
}
