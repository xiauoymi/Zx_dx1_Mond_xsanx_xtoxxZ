/*
 AccessoryDesignator_UT was created on Nov 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.custommonkey.xmlunit.XMLTestCase;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * Filename:    $RCSfile: AccessoryDesignator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-11-05 14:18:15 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class AccessoryDesignator_UT extends XMLTestCase {

  public void testToXml_VerifyXml() throws Exception {
    AccessoryDesignator designator = new AccessoryDesignator(new Long(12), "ADES", "AD");
    Document xmlDoc = DOMUtil.stringToXML(designator.toXml());
    assertXpathEvaluatesTo("1", "count(//accessoryDesignator)", xmlDoc);
    assertXpathEvaluatesTo("12", "//accessoryDesignator/id", xmlDoc);
    assertXpathEvaluatesTo("AD - ADES", "//accessoryDesignator/name", xmlDoc);
  }
}