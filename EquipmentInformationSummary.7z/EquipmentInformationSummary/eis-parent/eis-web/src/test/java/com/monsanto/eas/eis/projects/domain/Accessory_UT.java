/*
 Accessory_UT was created on Nov 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile: Accessory_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date:
 * 2009/01/30 22:13:29 $
 *
 * @author sspati1
 * @version $Revision: 1.17 $
 */
public class Accessory_UT extends XMLTestCase {

  public void testToXml() throws Exception {
    AutoManual autoManual = new AutoManual(new Long(17));
    autoManual.setValue("AT");
    Integer estimatedCost = new Integer(18);
    Integer actualCost = new Integer(19);
    Accessory accessory = new Accessory(null, true, "ACCE NAME", new AccessoryDesignator(new Long(12), "ADES", "AD"),
        "13", new Integer(14), "ACCE DESC", "ACCE COMMENTS", false, true, true, "ACCE UT FLOWRATE",
        true, new Integer(16), autoManual, createElectrical(), createPurchasing(),
        createEquipment(), estimatedCost, actualCost, "1212");
    accessory.setId(new Long(11));
    Document xmlDoc = DOMUtil.stringToXML(accessory.toXml());
    assertXpathEvaluatesTo("1", "count(//accessory)", xmlDoc);
    assertXpathEvaluatesTo("11", "//accessory/acceId", xmlDoc);
    assertXpathEvaluatesTo("ACCE NAME", "//accessory/accessoryName", xmlDoc);
    assertXpathEvaluatesTo("true", "//accessory/purchasedWithEquipment", xmlDoc);
    assertXpathEvaluatesTo("12", "//accessory/accessoryDesignator/accessoryDesignatorId", xmlDoc);
    assertXpathEvaluatesTo("AD", "//accessory/accessoryDesignator/accessoryDesignatorTypeCode", xmlDoc);
    assertXpathEvaluatesTo("13", "//accessory/sequenceNumber", xmlDoc);
    assertXpathEvaluatesTo("14", "//accessory/quantity", xmlDoc);
    assertXpathEvaluatesTo("ACCE DESC", "//accessory/acceDescription", xmlDoc);
    assertXpathEvaluatesTo("ACCE COMMENTS", "//accessory/comments", xmlDoc);
    assertXpathEvaluatesTo("false", "//accessory/compAirReqd", xmlDoc);
    assertXpathEvaluatesTo("true", "//accessory/gasReqd", xmlDoc);
    assertXpathEvaluatesTo("true", "//accessory/waterReqd", xmlDoc);
    assertXpathEvaluatesTo("ACCE UT FLOWRATE", "//accessory/utilityFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//accessory/selfCleaning", xmlDoc);
    assertXpathEvaluatesTo("16", "//accessory/size", xmlDoc);
    assertXpathEvaluatesTo("17", "//accessory/autoManualId", xmlDoc);
    assertXpathEvaluatesTo("18", "//accessory/estimatedCost", xmlDoc);
    assertXpathEvaluatesTo("19", "//accessory/actualCost", xmlDoc);
    assertXpathEvaluatesTo("1212", "//accessory/bidPackage", xmlDoc);


    assertXpathEvaluatesTo("1", "count(//electrical)", xmlDoc);
    assertXpathEvaluatesTo("4", "//electrical/electId", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/proofOfPositionReq", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/solenoidReq", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/localPushButtonReq", xmlDoc);
    assertXpathEvaluatesTo("1", "//electrical/inputId", xmlDoc);
    assertXpathEvaluatesTo("10", "//electrical/inputQty", xmlDoc);
    assertXpathEvaluatesTo("2", "//electrical/outputId", xmlDoc);
    assertXpathEvaluatesTo("20", "//electrical/outputQty", xmlDoc);
    assertXpathEvaluatesTo("HMI Display", "//electrical/hmiDisplay", xmlDoc);
    assertXpathEvaluatesTo("3", "//electrical/otherMeasurementId", xmlDoc);
    assertXpathEvaluatesTo("Communications", "//electrical/communications", xmlDoc);
    assertXpathEvaluatesTo("100", "//electrical/voltage", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//purchasing)", xmlDoc);
    assertXpathEvaluatesTo("123", "//purchasing/purchaseId", xmlDoc);
    assertXpathEvaluatesTo("vendor information", "//purchasing/vendor", xmlDoc);
    assertXpathEvaluatesTo("12", "//purchasing/rtpNumber", xmlDoc);
    assertXpathEvaluatesTo("13", "//purchasing/poNumber", xmlDoc);
    assertXpathEvaluatesTo("14", "//purchasing/lineNumber", xmlDoc);
    assertXpathEvaluatesTo("15", "//purchasing/poLineAmount", xmlDoc);
    assertXpathEvaluatesTo("16", "//purchasing/poLineQuantity", xmlDoc);
    assertXpathEvaluatesTo("17", "//purchasing/poLineValue", xmlDoc);
    assertXpathEvaluatesTo("18", "//purchasing/coAmount", xmlDoc);
    assertXpathEvaluatesTo("Sep 25, 2008", "//purchasing/originalShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 26, 2008", "//purchasing/revisedShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 27, 2008", "//purchasing/actualDeliveryDate", xmlDoc);
    assertXpathEvaluatesTo("false", "//purchasing/exportDocuments", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testToXml_NullValues_VerifyXml() throws Exception {
    Accessory accessory = new Accessory(null, false, null, null, null, null, null, null, false, false, false, null,
        false, null, null, createElectrical(), createPurchasing(), createEquipment(), null, null, null);
    Document xmlDoc = DOMUtil.stringToXML(accessory.toXml());
    assertXpathEvaluatesTo("1", "count(//accessory)", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/acceId", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/accessoryName", xmlDoc);
    assertXpathEvaluatesTo("false", "//accessory/purchasedWithEquipment", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/accessoryDesignator/accessoryDesignatorId", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/accessoryDesignator/accessoryDesignatorTypeCode", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/sequenceNumber", xmlDoc);
    assertXpathEvaluatesTo("1", "//accessory/quantity", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/acceDescription", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/comments", xmlDoc);
    assertXpathEvaluatesTo("false", "//accessory/compAirReqd", xmlDoc);
    assertXpathEvaluatesTo("false", "//accessory/gasReqd", xmlDoc);
    assertXpathEvaluatesTo("false", "//accessory/waterReqd", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/utilityFlowrate", xmlDoc);
    assertXpathEvaluatesTo("false", "//accessory/selfCleaning", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/size", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/autoManualId", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/estimatedCost", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/actualCost", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/bidPackage", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//purchasing)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//electrical)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
  }

  public void testCreateCopy() throws Exception {
    AutoManual autoManual = new AutoManual(new Long(17));
    autoManual.setValue("AT");
     Integer estimatedCost = new Integer(18);
    Integer actualCost = new Integer(19);
    Accessory accessory = new Accessory(null, true, "ACCE NAME", new AccessoryDesignator(new Long(12), "ADES", "AD"),
        "13", new Integer(14), "ACCE DESC", "ACCE COMMENTS", false, true, true, "ACCE UT FLOWRATE",
        true, new Integer(16), autoManual, createElectrical(), createPurchasing(),
        createEquipment(), estimatedCost, actualCost, "1212");
    accessory.setId(new Long(11));
    Accessory copyOfAccessory = accessory.createCopy();
    Document xmlDoc = DOMUtil.stringToXML(copyOfAccessory.toXml());
    assertXpathEvaluatesTo("1", "count(//accessory)", xmlDoc);
    assertXpathEvaluatesTo("", "//accessory/acceId", xmlDoc);
    assertXpathEvaluatesTo("ACCE NAME", "//accessory/accessoryName", xmlDoc);
    assertXpathEvaluatesTo("true", "//accessory/purchasedWithEquipment", xmlDoc);
    assertXpathEvaluatesTo("12", "//accessory/accessoryDesignator/accessoryDesignatorId", xmlDoc);
    assertXpathEvaluatesTo("AD", "//accessory/accessoryDesignator/accessoryDesignatorTypeCode", xmlDoc);
    assertXpathEvaluatesTo("13", "//accessory/sequenceNumber", xmlDoc);
    assertXpathEvaluatesTo("14", "//accessory/quantity", xmlDoc);
    assertXpathEvaluatesTo("ACCE DESC", "//accessory/acceDescription", xmlDoc);
    assertXpathEvaluatesTo("ACCE COMMENTS", "//accessory/comments", xmlDoc);
    assertXpathEvaluatesTo("false", "//accessory/compAirReqd", xmlDoc);
    assertXpathEvaluatesTo("true", "//accessory/gasReqd", xmlDoc);
    assertXpathEvaluatesTo("true", "//accessory/waterReqd", xmlDoc);
    assertXpathEvaluatesTo("ACCE UT FLOWRATE", "//accessory/utilityFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//accessory/selfCleaning", xmlDoc);
    assertXpathEvaluatesTo("16", "//accessory/size", xmlDoc);
    assertXpathEvaluatesTo("17", "//accessory/autoManualId", xmlDoc);
    assertXpathEvaluatesTo("18", "//accessory/estimatedCost", xmlDoc);
    assertXpathEvaluatesTo("19", "//accessory/actualCost", xmlDoc);
    assertXpathEvaluatesTo("1212", "//accessory/bidPackage", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//electrical)", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/electId", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/proofOfPositionReq", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/solenoidReq", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/localPushButtonReq", xmlDoc);
    assertXpathEvaluatesTo("1", "//electrical/inputId", xmlDoc);
    assertXpathEvaluatesTo("10", "//electrical/inputQty", xmlDoc);
    assertXpathEvaluatesTo("2", "//electrical/outputId", xmlDoc);
    assertXpathEvaluatesTo("20", "//electrical/outputQty", xmlDoc);
    assertXpathEvaluatesTo("HMI Display", "//electrical/hmiDisplay", xmlDoc);
    assertXpathEvaluatesTo("3", "//electrical/otherMeasurementId", xmlDoc);
    assertXpathEvaluatesTo("Communications", "//electrical/communications", xmlDoc);
    assertXpathEvaluatesTo("100", "//electrical/voltage", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//purchasing)", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/purchaseId", xmlDoc);
    assertXpathEvaluatesTo("vendor information", "//purchasing/vendor", xmlDoc);
    assertXpathEvaluatesTo("12", "//purchasing/rtpNumber", xmlDoc);
    assertXpathEvaluatesTo("13", "//purchasing/poNumber", xmlDoc);
    assertXpathEvaluatesTo("14", "//purchasing/lineNumber", xmlDoc);
    assertXpathEvaluatesTo("15", "//purchasing/poLineAmount", xmlDoc);
    assertXpathEvaluatesTo("16", "//purchasing/poLineQuantity", xmlDoc);
    assertXpathEvaluatesTo("17", "//purchasing/poLineValue", xmlDoc);
    assertXpathEvaluatesTo("18", "//purchasing/coAmount", xmlDoc);
    assertXpathEvaluatesTo("Sep 25, 2008", "//purchasing/originalShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 26, 2008", "//purchasing/revisedShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 27, 2008", "//purchasing/actualDeliveryDate", xmlDoc);
    assertXpathEvaluatesTo("false", "//purchasing/exportDocuments", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  private Electrical createElectrical() {
    ElectricalInput input = new ElectricalInput();
    input.setId(1L);
    ElectricalOutput output = new ElectricalOutput();
    output.setId(2L);
    OtherMeasurement otherMeasurement = new OtherMeasurement();
    otherMeasurement.setId(3L);
    Electrical electrical = new Electrical(null, true, true, true, input, new Integer(10), output, new Integer(20),
        "HMI Display", otherMeasurement, "Communications", new Integer(100), createEquipment());
    electrical.setId(4L);
    return electrical;
  }

  private Purchasing createPurchasing() {
    Purchasing purchasing = new Purchasing(new Long(123), "vendor information", new Integer(12), new Long(13),
        new Integer(14), new Long(15), new Integer(16), new Long(17), new Long(18), getDate(2), getDate(3),
        getDate(4), false);
    purchasing.setEquipment(createEquipment());
    return purchasing;
  }

  private Equipment createEquipment() {
    Equipment equipment = new Equipment("10.0.B0", "0.000.1W1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);
    Set<Motor> motors = new HashSet<Motor>();
    motors.add(new Motor());
    equipment.setMotors(motors);
    Set<Instrument> instruments = new HashSet<Instrument>();
    instruments.add(new Instrument());
    equipment.setInstruments(instruments);
    return equipment;
  }

  private Date getDate(int numDaysToAdd) {
    Calendar cal = Calendar.getInstance();
    cal.set(Calendar.YEAR, 2008);
    cal.set(Calendar.MONTH, 8);
    cal.set(Calendar.DATE, 23);
    cal.add(Calendar.DATE, numDaysToAdd);
    return cal.getTime();
  }

  public void testGetAccessoryAndRelatedIds() throws Exception {
    AutoManual autoManual = new AutoManual(new Long(17));
    autoManual.setValue("AT");
     Integer estimatedCost = new Integer(17);
    Integer actualCost = new Integer(18);
    Accessory accessory = new Accessory(null, true, "ACCE NAME", new AccessoryDesignator(new Long(12), "ADES", "AD"),
        "13", new Integer(14), "ACCE DESC", "ACCE COMMENTS", false, true, true, "ACCE UT FLOWRATE",
        true, new Integer(16), autoManual, createElectrical(), createPurchasing(),
        createEquipment(), estimatedCost, actualCost, "1212");
    accessory.setId(new Long(11));
    assertEquals("'11','12','4','3','1','2','123'", accessory.getAccessoryAndRelatedIds());
  }

  public void testGetAccessoryAndRelatedIds_SomeRelatedObjectsAreNull() throws Exception {
    AutoManual autoManual = new AutoManual(new Long(17));
    autoManual.setValue("AT");
     Integer estimatedCost = new Integer(18);
    Integer actualCost = new Integer(19);
    Accessory accessory = new Accessory(null, true, "ACCE NAME", null,
        "13", new Integer(14), "ACCE DESC", "ACCE COMMENTS", false, true, true, "ACCE UT FLOWRATE",
        true, new Integer(16), autoManual, null, createPurchasing(),
        createEquipment(), estimatedCost, actualCost, "1212");
    accessory.setId(new Long(11));
    assertEquals("'11','123'", accessory.getAccessoryAndRelatedIds());
  }
}