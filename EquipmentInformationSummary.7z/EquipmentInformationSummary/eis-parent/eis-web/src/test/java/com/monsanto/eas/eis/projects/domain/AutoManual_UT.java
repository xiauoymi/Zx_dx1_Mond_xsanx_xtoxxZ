/*
 AutoManual_UT was created on Nov 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: AutoManual_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-11 19:20:45 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class AutoManual_UT extends XMLTestCase {

  public void testToXml_VerifyXml() throws Exception {
    AutoManual autoManual = new AutoManual(new Long(12));
    autoManual.setValue("AT");
    Document xmlDoc = DOMUtil.stringToXML(autoManual.toXml());
    assertXpathEvaluatesTo("1", "count(//autoManual)", xmlDoc);
    assertXpathEvaluatesTo("12", "//autoManual/id", xmlDoc);
    assertXpathEvaluatesTo("AT", "//autoManual/name", xmlDoc);
  }
}