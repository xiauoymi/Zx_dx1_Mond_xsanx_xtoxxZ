/*
 BeltTypeDescription_UT was created on Dec 10, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import junit.framework.TestCase;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class BeltTypeDescription_UT extends TestCase {
  public void testCreate_ObjectNotNull() throws Exception {
    BeltTypeDescription beltTypeDesc = new BeltTypeDescription();
    assertNotNull(beltTypeDesc);
  }

  public void testConstructor_ValuesSet() throws Exception {
    BeltTypeDescription beltTypeDesc = new BeltTypeDescription(new Long(1), "CRS", "Conveyor Round Set", new FieldEquipmentType());

  }
}