/*
 CostSchedule_UT was created on Oct 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile: CostSchedule_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $ On:	$Date:
 * 2009/01/30 18:44:00 $
 *
 * @author sspati1
 * @version $Revision: 1.12 $
 */
public class CostSchedule_UT extends XMLTestCase {

  public void testToXml_VerifyXml() throws Exception {
    FundingSource source = new FundingSource(new Long(22));
    source.setSource("Lease");
    CostSchedule costSchedule = new CostSchedule(new Long(123), getDate(1), getDate(2), getDate(3), new Integer(11),
        new Integer(12), getDate(4), getDate(5), getDate(6), getDate(7), getDate(8), getDate(9), getDate(10),
        getDate(11),
        new Long(13), "estimated source", source, new Integer(15), null);
    costSchedule.setEquipment(createEquipment());
    Document xmlDoc = DOMUtil.stringToXML(costSchedule.toXml());
    assertXpathEvaluatesTo("1", "count(//costSchedule)", xmlDoc);
    assertXpathEvaluatesTo("123", "//costSchedule/costScheduleId", xmlDoc);
    assertXpathEvaluatesTo("Sep 24, 2008", "//costSchedule/scheduledSpecificationDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 25, 2008", "//costSchedule/scheduledQuoteDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 26, 2008", "//costSchedule/scheduledPurchaseDate", xmlDoc);
    assertXpathEvaluatesTo("11", "//costSchedule/drawingTurnaroundTime", xmlDoc);
    assertXpathEvaluatesTo("12", "//costSchedule/estiamtedFabricationTime", xmlDoc);
    assertXpathEvaluatesTo("Sep 27, 2008", "//costSchedule/estiamtedShippingDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 28, 2008", "//costSchedule/specIssuedDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 29, 2008", "//costSchedule/rtqEnteredDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 30, 2008", "//costSchedule/rtpEnteredDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 01, 2008", "//costSchedule/prelDrawingIssuedDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 02, 2008", "//costSchedule/approvalDrawingDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 03, 2008", "//costSchedule/finalDrawingDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 04, 2008", "//costSchedule/iomReceivedDate", xmlDoc);
    assertXpathEvaluatesTo("13", "//costSchedule/estimatedCost", xmlDoc);
    assertXpathEvaluatesTo("estimated source", "//costSchedule/estimatedSource", xmlDoc);
    assertXpathEvaluatesTo("22", "//costSchedule/fundingSourceId", xmlDoc);
    assertXpathEvaluatesTo("15", "//costSchedule/estimatedMechHours", xmlDoc);
    assertXpathEvaluatesTo("15", "//costSchedule/purchasing/poLineAmount", xmlDoc);
    assertXpathEvaluatesTo("18", "//costSchedule/purchasing/coAmount", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/escaltionFactor", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testToXml_ValuesAreNullAndInvertingBooleans() throws Exception {
    CostSchedule costSchedule = new CostSchedule();
    Equipment equipment = createEquipment();
    equipment.setPurchasing(new Purchasing());
    costSchedule.setEquipment(equipment);
    Document xmlDoc = DOMUtil.stringToXML(costSchedule.toXml());
    assertXpathEvaluatesTo("1", "count(//costSchedule)", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/costScheduleId", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/scheduledSpecificationDate", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/scheduledQuoteDate", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/scheduledPurchaseDate", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/drawingTurnaroundTime", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/estiamtedFabricationTime", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/estiamtedShippingDate", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/specIssuedDate", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/rtqEnteredDate", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/rtpEnteredDate", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/prelDrawingIssuedDate", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/approvalDrawingDate", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/finalDrawingDate", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/iomReceivedDate", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/estimatedCost", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/estimatedSource", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/fundingSourceId", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/estimatedMechHours", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/purchasing/poLineAmount", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/purchasing/coAmount", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/escaltionFactor", xmlDoc);


    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
  }

  public void testCreateCopy() throws Exception {
    FundingSource source = new FundingSource(new Long(22));
    source.setSource("Lease");
    CostSchedule costSchedule = new CostSchedule(new Long(123), getDate(1), getDate(2), getDate(3), new Integer(11),
        new Integer(12), getDate(4), getDate(5), getDate(6), getDate(7), getDate(8), getDate(9), getDate(10),
        getDate(11),
        new Long(13), "estimated source", source, new Integer(15), new Double(2.45));
    costSchedule.setEquipment(createEquipment());
    CostSchedule copyOfCostSchedule = costSchedule.createCopy();
    Document xmlDoc = DOMUtil.stringToXML(copyOfCostSchedule.toXml());
    assertXpathEvaluatesTo("1", "count(//costSchedule)", xmlDoc);
    assertXpathEvaluatesTo("", "//costSchedule/costScheduleId", xmlDoc);
    assertXpathEvaluatesTo("Sep 24, 2008", "//costSchedule/scheduledSpecificationDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 25, 2008", "//costSchedule/scheduledQuoteDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 26, 2008", "//costSchedule/scheduledPurchaseDate", xmlDoc);
    assertXpathEvaluatesTo("11", "//costSchedule/drawingTurnaroundTime", xmlDoc);
    assertXpathEvaluatesTo("12", "//costSchedule/estiamtedFabricationTime", xmlDoc);
    assertXpathEvaluatesTo("Sep 27, 2008", "//costSchedule/estiamtedShippingDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 28, 2008", "//costSchedule/specIssuedDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 29, 2008", "//costSchedule/rtqEnteredDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 30, 2008", "//costSchedule/rtpEnteredDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 01, 2008", "//costSchedule/prelDrawingIssuedDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 02, 2008", "//costSchedule/approvalDrawingDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 03, 2008", "//costSchedule/finalDrawingDate", xmlDoc);
    assertXpathEvaluatesTo("Oct 04, 2008", "//costSchedule/iomReceivedDate", xmlDoc);
    assertXpathEvaluatesTo("13", "//costSchedule/estimatedCost", xmlDoc);
    assertXpathEvaluatesTo("estimated source", "//costSchedule/estimatedSource", xmlDoc);
    assertXpathEvaluatesTo("22", "//costSchedule/fundingSourceId", xmlDoc);
    assertXpathEvaluatesTo("15", "//costSchedule/estimatedMechHours", xmlDoc);
    assertXpathEvaluatesTo("15", "//costSchedule/purchasing/poLineAmount", xmlDoc);
    assertXpathEvaluatesTo("18", "//costSchedule/purchasing/coAmount", xmlDoc);
    assertXpathEvaluatesTo("2.45", "//costSchedule/escalationFactor", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  private Equipment createEquipment() {
    Equipment equipment = new Equipment("10.0.B0", "0.000.1W1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    Purchasing purchasing = new Purchasing(new Long(123), "vendor information", new Integer(12), new Long(13),
        new Integer(14), new Long(15), new Integer(16), new Long(17), new Long(18), getDate(2), getDate(3),
        getDate(4), false);
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);
    Set<Motor> motors = new HashSet<Motor>();
    motors.add(new Motor());
    equipment.setMotors(motors);
    Set<Instrument> instruments = new HashSet<Instrument>();
    instruments.add(new Instrument());
    equipment.setInstruments(instruments);
    return equipment;
  }

  private Date getDate(int numDaysToAdd) {
    Calendar cal = Calendar.getInstance();
    cal.set(Calendar.YEAR, 2008);
    cal.set(Calendar.MONTH, 8);
    cal.set(Calendar.DATE, 23);
    cal.add(Calendar.DATE, numDaysToAdd);
    return cal.getTime();
  }
}