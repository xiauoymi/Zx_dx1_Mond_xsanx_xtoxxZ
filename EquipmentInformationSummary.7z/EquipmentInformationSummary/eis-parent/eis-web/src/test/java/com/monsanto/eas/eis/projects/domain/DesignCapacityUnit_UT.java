/*
 DesignCapacityUnit_UT was created on Jan 20, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: DesignCapacityUnit_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-01-20 16:41:35 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class DesignCapacityUnit_UT extends XMLTestCase {
  public void testToXml_VerifyXml() throws Exception {
    DesignCapacityUnit type = new DesignCapacityUnit(new Long(12));
    type.setUnitName("Unit Name 1");
    Document xmlDoc = DOMUtil.stringToXML(type.toXml());
    assertXpathEvaluatesTo("1", "count(//designCapacityUnit)", xmlDoc);
    assertXpathEvaluatesTo("12", "//designCapacityUnit/id", xmlDoc);
    assertXpathEvaluatesTo("Unit Name 1", "//designCapacityUnit/unitName", xmlDoc);
  }
}