/*
 ElectricalInputQuantity_UT was created on Feb 2, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import java.util.Set;
import java.util.HashSet;

import org.w3c.dom.Document;
import org.custommonkey.xmlunit.XMLTestCase;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * Filename:    $RCSfile: ElectricalInputQuantity_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-12 20:42:42 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class ElectricalInputQuantity_UT extends XMLTestCase {

 public void testToXml() throws Exception {
    ElectricalInput input = new ElectricalInput(new Long(234));
    ElectricalInputQuantity inputQuantity = new ElectricalInputQuantity(new Long(123), input, new Integer(345), null, true);
    Document xmlDoc = DOMUtil.stringToXML(inputQuantity.toXml());
    assertXpathEvaluatesTo("1", "count(//inputQuantity)", xmlDoc);
    assertXpathEvaluatesTo("123", "//inputQuantityId234", xmlDoc);
    assertXpathEvaluatesTo("true", "//inputIdChecked234", xmlDoc);
    assertXpathEvaluatesTo("234", "//inputId234", xmlDoc);
    assertXpathEvaluatesTo("345", "//inputQty234", xmlDoc);
 }
}