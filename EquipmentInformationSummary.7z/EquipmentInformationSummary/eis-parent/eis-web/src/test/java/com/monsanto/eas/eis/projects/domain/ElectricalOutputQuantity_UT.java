/*
 ElectricalOutputQuantity_UT was created on Feb 2, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import com.monsanto.XMLUtil.DOMUtil;

import java.util.Set;
import java.util.HashSet;

/**
 * Filename:    $RCSfile: ElectricalOutputQuantity_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-12 20:42:42 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class ElectricalOutputQuantity_UT extends XMLTestCase {
  public void testToXml() throws Exception {
    ElectricalOutput output = new ElectricalOutput(new Long(234));
    ElectricalOutputQuantity outputQuantity = new ElectricalOutputQuantity(new Long(123), output, new Integer(345), null, true);
    Document xmlDoc = DOMUtil.stringToXML(outputQuantity.toXml());
    assertXpathEvaluatesTo("1", "count(//outputQuantity)", xmlDoc);
    assertXpathEvaluatesTo("123", "//outputQuantityId234", xmlDoc);
    assertXpathEvaluatesTo("true", "//outputIdChecked234", xmlDoc);
    assertXpathEvaluatesTo("234", "//outputId234", xmlDoc);
    assertXpathEvaluatesTo("345", "//outputQty234", xmlDoc);
  }
}