package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 23, 2008 Time: 11:13:40 AM To change this template use File |
 * Settings | File Templates.
 */
public class Electrical_UT extends XMLTestCase {

  public void testEquals_ReturnsTrue() throws Exception {
    Electrical elec1 = new Electrical();
    elec1.setId(new Long(11));
    Electrical elec2 = new Electrical();
    elec2.setId(new Long(11));
    assertTrue(elec1.equals(elec2));
  }

  public void testEquals_ReturnsFalse() throws Exception {
    Electrical elec1 = new Electrical();
    elec1.setId(new Long(11));
    Electrical elec2 = new Electrical();
    elec2.setId(new Long(12));
    assertFalse(elec1.equals(elec2));
  }

  public void testToXml() throws Exception {
    ElectricalInput input = new ElectricalInput();
    input.setId(1L);
    ElectricalOutput output = new ElectricalOutput();
    output.setId(2L);
    OtherMeasurement otherMeasurement = new OtherMeasurement();
    otherMeasurement.setId(3L);
    Set<ElectricalInputQuantity> inputQuantities = new HashSet<ElectricalInputQuantity>();
    Set<ElectricalOutputQuantity> outputQuantities = new HashSet<ElectricalOutputQuantity>();

    Electrical electrical = new Electrical(null, true, true, true, input, new Integer(10), output, new Integer(20),
        "HMI Display", otherMeasurement, "Communications", new Integer(100), createEquipment());
    electrical.setId(4L);
    ElectricalInputQuantity inputQuantity = new ElectricalInputQuantity(new Long(11),
        new ElectricalInput(new Long(123)), new Integer(10), electrical, true);
    inputQuantities.add(inputQuantity);
    inputQuantity = new ElectricalInputQuantity(new Long(12), new ElectricalInput(new Long(234)), new Integer(20),
        electrical, false);
    inputQuantities.add(inputQuantity);
    electrical.setInputQuantity(inputQuantities);

    ElectricalOutputQuantity outputQuantity = new ElectricalOutputQuantity(new Long(13),
        new ElectricalOutput(new Long(345)), new Integer(30), electrical,
        false);
    outputQuantities.add(outputQuantity);
    outputQuantity = new ElectricalOutputQuantity(new Long(14), new ElectricalOutput(new Long(456)), new Integer(40),
        electrical, true);
    outputQuantities.add(outputQuantity);
    electrical.setOutputQuantity(outputQuantities);


    Document xmlDoc = DOMUtil.stringToXML(electrical.toXml());
    assertXpathEvaluatesTo("1", "count(//electrical)", xmlDoc);
    assertXpathEvaluatesTo("4", "//electrical/electId", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/proofOfPositionReq", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/solenoidReq", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/localPushButtonReq", xmlDoc);
    assertXpathEvaluatesTo("1", "//electrical/inputId", xmlDoc);
    assertXpathEvaluatesTo("10", "//electrical/inputQty", xmlDoc);
    assertXpathEvaluatesTo("2", "//electrical/outputId", xmlDoc);
    assertXpathEvaluatesTo("20", "//electrical/outputQty", xmlDoc);
    assertXpathEvaluatesTo("HMI Display", "//electrical/hmiDisplay", xmlDoc);
    assertXpathEvaluatesTo("3", "//electrical/otherMeasurementId", xmlDoc);
    assertXpathEvaluatesTo("Communications", "//electrical/communications", xmlDoc);
    assertXpathEvaluatesTo("100", "//electrical/voltage", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathEvaluatesTo("2", "count(//inputQuantities/inputQuantity)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//outputQuantities/outputQuantity)", xmlDoc);

    assertXpathEvaluatesTo("11", "//inputQuantityId123", xmlDoc);
    assertXpathEvaluatesTo("true", "//inputIdChecked123", xmlDoc);
    assertXpathEvaluatesTo("123", "//inputId123", xmlDoc);
    assertXpathEvaluatesTo("10", "//inputQty123", xmlDoc);

    assertXpathEvaluatesTo("12", "//inputQuantityId234", xmlDoc);
    assertXpathEvaluatesTo("false", "//inputIdChecked234", xmlDoc);
    assertXpathEvaluatesTo("234", "//inputId234", xmlDoc);
    assertXpathEvaluatesTo("20", "//inputQty234", xmlDoc);

    assertXpathEvaluatesTo("13", "//outputQuantityId345", xmlDoc);
    assertXpathEvaluatesTo("false", "//outputIdChecked345", xmlDoc);
    assertXpathEvaluatesTo("345", "//outputId345", xmlDoc);
    assertXpathEvaluatesTo("30", "//outputQty345", xmlDoc);

    assertXpathEvaluatesTo("14", "//outputQuantityId456", xmlDoc);
    assertXpathEvaluatesTo("true", "//outputIdChecked456", xmlDoc);
    assertXpathEvaluatesTo("456", "//outputId456", xmlDoc);
    assertXpathEvaluatesTo("40", "//outputQty456", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testToXmlWithoutEquipment_VerifyXml() throws Exception {
    ElectricalInput input = new ElectricalInput();
    input.setId(1L);
    ElectricalOutput output = new ElectricalOutput();
    output.setId(2L);
    OtherMeasurement otherMeasurement = new OtherMeasurement();
    otherMeasurement.setId(3L);
    Electrical electrical = new Electrical(null, true, true, true, input, new Integer(10), output, new Integer(20),
        "HMI Display", otherMeasurement, "Communications", new Integer(100), null);
    electrical.setId(4L);
    Document xmlDoc = DOMUtil.stringToXML(electrical.toXmlWithoutEquipment());
    assertXpathEvaluatesTo("1", "count(//electrical)", xmlDoc);
    assertXpathEvaluatesTo("4", "//electrical/electId", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/proofOfPositionReq", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/solenoidReq", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/localPushButtonReq", xmlDoc);
    assertXpathEvaluatesTo("1", "//electrical/inputId", xmlDoc);
    assertXpathEvaluatesTo("10", "//electrical/inputQty", xmlDoc);
    assertXpathEvaluatesTo("2", "//electrical/outputId", xmlDoc);
    assertXpathEvaluatesTo("20", "//electrical/outputQty", xmlDoc);
    assertXpathEvaluatesTo("HMI Display", "//electrical/hmiDisplay", xmlDoc);
    assertXpathEvaluatesTo("3", "//electrical/otherMeasurementId", xmlDoc);
    assertXpathEvaluatesTo("Communications", "//electrical/communications", xmlDoc);
    assertXpathEvaluatesTo("100", "//electrical/voltage", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/inputQuantities", xmlDoc);

    assertXpathEvaluatesTo("0", "count(//equipment)", xmlDoc);
  }

  public void testToXml_AllValuesAreNull() throws Exception {
    Electrical electrical = new Electrical(null, false, false, false, null, null, null, null, null, null, null, null,
        createEquipment());

    Document xmlDoc = DOMUtil.stringToXML(electrical.toXml());
    assertXpathEvaluatesTo("1", "count(//electrical)", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/id", xmlDoc);
    assertXpathEvaluatesTo("false", "//electrical/proofOfPositionReq", xmlDoc);
    assertXpathEvaluatesTo("false", "//electrical/solenoidReq", xmlDoc);
    assertXpathEvaluatesTo("false", "//electrical/localPushButtonReq", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/inputId", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/inputQty", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/outputId", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/outputQty", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/hmiDisplay", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/otherMeasurementId", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/communications", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/voltage", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/inputQuantities", xmlDoc);
  }

  public void testCreateCopy() throws Exception {
    ElectricalInput input = new ElectricalInput();
    input.setId(1L);
    ElectricalOutput output = new ElectricalOutput();
    output.setId(2L);
    OtherMeasurement otherMeasurement = new OtherMeasurement();
    otherMeasurement.setId(3L);
    Electrical electrical = new Electrical(new Long(234), true, true, true, input, new Integer(10), output,
        new Integer(20),
        "HMI Display", otherMeasurement, "Communications", new Integer(100), createEquipment());
    Electrical copyOfElectrical = electrical.createCopy();
    Document xmlDoc = DOMUtil.stringToXML(copyOfElectrical.toXml());
    assertXpathEvaluatesTo("1", "count(//electrical)", xmlDoc);
    assertXpathEvaluatesTo("", "//electrical/electId", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/proofOfPositionReq", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/solenoidReq", xmlDoc);
    assertXpathEvaluatesTo("true", "//electrical/localPushButtonReq", xmlDoc);
    assertXpathEvaluatesTo("1", "//electrical/inputId", xmlDoc);
    assertXpathEvaluatesTo("10", "//electrical/inputQty", xmlDoc);
    assertXpathEvaluatesTo("2", "//electrical/outputId", xmlDoc);
    assertXpathEvaluatesTo("20", "//electrical/outputQty", xmlDoc);
    assertXpathEvaluatesTo("HMI Display", "//electrical/hmiDisplay", xmlDoc);
    assertXpathEvaluatesTo("3", "//electrical/otherMeasurementId", xmlDoc);
    assertXpathEvaluatesTo("Communications", "//electrical/communications", xmlDoc);
    assertXpathEvaluatesTo("100", "//electrical/voltage", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  private Equipment createEquipment() {
    Equipment equipment = new Equipment("10.0.B0", "0.000.1W1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);
    Set<Motor> motors = new HashSet<Motor>();
    motors.add(new Motor());
    equipment.setMotors(motors);
    Set<Instrument> instruments = new HashSet<Instrument>();
    instruments.add(new Instrument());
    equipment.setInstruments(instruments);
    return equipment;
  }

  public void testGetElectricalAndRelatedIds() throws Exception {
    ElectricalInput input = new ElectricalInput();
    input.setId(1L);
    ElectricalOutput output = new ElectricalOutput();
    output.setId(2L);
    OtherMeasurement otherMeasurement = new OtherMeasurement();
    otherMeasurement.setId(3L);
    Set<ElectricalInputQuantity> inputQuantities = new HashSet<ElectricalInputQuantity>();
    Set<ElectricalOutputQuantity> outputQuantities = new HashSet<ElectricalOutputQuantity>();

    Electrical electrical = new Electrical(null, true, true, true, input, new Integer(10), output, new Integer(20),
        "HMI Display", otherMeasurement, "Communications", new Integer(100), createEquipment());
    electrical.setId(4L);
    ElectricalInputQuantity inputQuantity = new ElectricalInputQuantity(null, input, new Integer(10), electrical,
        false);
    inputQuantities.add(inputQuantity);
    ElectricalInput input1 = new ElectricalInput();
    input1.setId(2L);
    inputQuantity = new ElectricalInputQuantity(null, input1, new Integer(20), electrical, false);
    inputQuantities.add(inputQuantity);
    electrical.setInputQuantity(inputQuantities);

    ElectricalOutputQuantity outputQuantity = new ElectricalOutputQuantity(null, output, new Integer(30), electrical,
        false);
    outputQuantities.add(outputQuantity);
    ElectricalOutput output1 = new ElectricalOutput();
    output1.setId(3L);
    outputQuantity = new ElectricalOutputQuantity(null, output1, new Integer(40), electrical, false);
    outputQuantities.add(outputQuantity);
    electrical.setOutputQuantity(outputQuantities);

    assertEquals("'4','3','1','2'", electrical.getElectricalAndRelatedIds());
  }

  public void testGetElectricalAndRelatedIds_AllValuesAreNull() throws Exception {
    Electrical electrical = new Electrical(null, false, false, false, null, null, null, null, null,
        new OtherMeasurement(), null, null, createEquipment());
    electrical.setId(new Long(1));
    assertEquals("'1'", electrical.getElectricalAndRelatedIds());
  }


}
