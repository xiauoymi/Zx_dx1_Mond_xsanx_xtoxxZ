/*
 Equipment_UT was created on Sep 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.projects.domain.mock.MockEquipment;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.mock.MockDAO;
import org.custommonkey.xmlunit.XMLTestCase;
import org.hibernate.Criteria;
import org.w3c.dom.Document;

import java.util.*;

/**
 * Filename:    $RCSfile: Equipment_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date:
 * 2008/12/04 20:18:26 $
 *
 * @author sspati1
 * @version $Revision: 1.21 $
 */
public class Equipment_UT extends XMLTestCase {

  public void testToXml_VerifyXml() throws Exception {
    Equipment equipment = new MockEquipment("10.0.B0", "10.0.B1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    equipment.setEquipmentSoleSource(true);
    equipment.setExistingEquipmentModification(true);
    equipment.setStandardEquipment(true);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);
    Set<Motor> motors = new HashSet<Motor>();
    motors.add(new Motor());
    equipment.setMotors(motors);
    Set<Instrument> instruments = new HashSet<Instrument>();
    instruments.add(new Instrument());
    equipment.setInstruments(instruments);
    Set<Accessory> accessories = new HashSet<Accessory>();
    accessories.add(new Accessory());
    equipment.setAccessories(accessories);
    Document xmlDoc = DOMUtil.stringToXML(equipment.toXml());
    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("10.0.B1", "//equipment/existingEquipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("This is a blower", "//equipment/description", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/modifiedDate", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("ABC123", "//equipment/equipmentTagNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("3", "//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathEvaluatesTo("H", "//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Conveyor", "//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/motors", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/instruments", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/accessories", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/existingEquipmentModification", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/standardEquipment", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testToXml_NoMotorsNoInstrumentNoAccessories_VerifyXml() throws Exception {
    Equipment equipment = new MockEquipmentWithNoMotorsInstrumentsAccessories("10.0.B0", "10.0.B1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    equipment.setEquipmentSoleSource(true);
    equipment.setExistingEquipmentModification(true);
    equipment.setStandardEquipment(true);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);
    Set<Motor> motors = new HashSet<Motor>();
    motors.add(new Motor());
    equipment.setMotors(motors);
    Set<Instrument> instruments = new HashSet<Instrument>();
    instruments.add(new Instrument());
    equipment.setInstruments(instruments);
    Set<Accessory> accessories = new HashSet<Accessory>();
    accessories.add(new Accessory());
    equipment.setAccessories(accessories);
    Document xmlDoc = DOMUtil.stringToXML(equipment.toXml());
    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("10.0.B1", "//equipment/existingEquipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("This is a blower", "//equipment/description", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/modifiedDate", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("ABC123", "//equipment/equipmentTagNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("3", "//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathEvaluatesTo("H", "//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Conveyor", "//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);
    assertXpathEvaluatesTo("false", "//equipment/motors", xmlDoc);
    assertXpathEvaluatesTo("false", "//equipment/instruments", xmlDoc);
    assertXpathEvaluatesTo("false", "//equipment/accessories", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/existingEquipmentModification", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/standardEquipment", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testToXml_AreaAndEquipmentTypesAreNull() throws Exception {
    Equipment equipment = new MockEquipment("10.0.B0", "10.0.B1", "Blower", null, null, "234", "ABC123",
        null, null, null);
    equipment.setEquipmentSoleSource(false);
    equipment.setExistingEquipmentModification(false);
    equipment.setStandardEquipment(false);
    equipment.setPurchasing(new Purchasing());
    equipment.setId(new Long(5));
    equipment.setMotors(new HashSet<Motor>());
    equipment.setInstruments(new HashSet<Instrument>());
    equipment.setAccessories(new HashSet<Accessory>());
    Document xmlDoc = DOMUtil.stringToXML(equipment.toXml());
    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("5", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("10.0.B1", "//equipment/existingEquipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/description", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/modifiedDate", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("ABC123", "//equipment/equipmentTagNumber", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/equipmentVendor", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/motors", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/instruments", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/accessories", xmlDoc);
    assertXpathEvaluatesTo("false", "//equipment/existingEquipmentModification", xmlDoc);
    assertXpathEvaluatesTo("false", "//equipment/standardEquipment", xmlDoc);
    assertXpathEvaluatesTo("false", "//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testToXmlWihtBasicFields_VerifyXml() throws Exception {
    Equipment equipment = new Equipment("10.0.B0", "10.0.B1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    equipment.setId(new Long(5));
    equipment.setEquipmentSoleSource(true);
    equipment.setExistingEquipmentModification(true);
    equipment.setStandardEquipment(true);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);
    Document xmlDoc = DOMUtil.stringToXML(equipment.toXmlWithBasicFields());
    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("5", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("10.0.B1", "//equipment/existingEquipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testToXmlWihtBasicFields_WithNullValues_VerifyXml() throws Exception {
    Equipment equipment = new Equipment("", "", "", null, null, "", "",
        null, null, null);
    equipment.setEquipmentSoleSource(false);
    equipment.setExistingEquipmentModification(false);
    equipment.setStandardEquipment(false);
    equipment.setPurchasing(new Purchasing());
    equipment.setId(new Long(5));
    Document xmlDoc = DOMUtil.stringToXML(equipment.toXmlWithBasicFields());
    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("5", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/existingEquipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testCopyData_VerifyData() throws Exception {
    Equipment equipment = new MockEquipment("10.0.B0", "10.0.B1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    equipment.setEquipmentSoleSource(true);
    equipment.setExistingEquipmentModification(true);
    equipment.setStandardEquipment(true);

    MockProcess process = new MockProcess();
    equipment.setProcess(process);

    MockElectrical electrical = new MockElectrical();
    equipment.setElectrical(electrical);

    MockMechanical mechanical = new MockMechanical();
    equipment.setMechanical(mechanical);

    MockPurchasing purchasing = new MockPurchasing();
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);

    MockCostSchedule costSchedule = new MockCostSchedule();
    equipment.setCostSchedule(costSchedule);

    MockMotor motor = new MockMotor();
    Equipment eqipment = new Equipment();
    eqipment.setName("Old name");
    motor.setEquipment(eqipment);
    HashSet<Motor> motors = new HashSet<Motor>();
    motors.add(motor);
    equipment.setMotors(motors);

    MockInstrument instrument = new MockInstrument();
    instrument.setEquipment(eqipment);
    HashSet<Instrument> instruments = new HashSet<Instrument>();
    instruments.add(instrument);
    equipment.setInstruments(instruments);

    MockAccessorry accessory = new MockAccessorry();
    accessory.setEquipment(eqipment);
    HashSet<Accessory> accessories = new HashSet<Accessory>();
    accessories.add(accessory);
    equipment.setAccessories(accessories);

    Equipment copyOfEquipment = equipment.createCopy();
    Document xmlDoc = DOMUtil.stringToXML(copyOfEquipment.toXml());
    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("This is a blower", "//equipment/description", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/modifiedDate", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("ABC123", "//equipment/equipmentTagNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("3", "//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathEvaluatesTo("H", "//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Conveyor", "//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/motors", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/instruments", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/accessories", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/existingEquipmentModification", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/standardEquipment", xmlDoc);
    assertXpathEvaluatesTo("true", "//equipment/equipmentSoleSource", xmlDoc);

    assertNull(copyOfEquipment.getId());

    assertTrue(process.isCreateCopyWasCalled());
    assertTrue(electrical.isCreateCopyWasCalled());
    assertTrue(mechanical.isCreateCopyWasCalled());
    assertTrue(purchasing.isCreateCopyWasCalled());
    assertTrue(costSchedule.isCreateCopyWasCalled());
    assertTrue(motor.isCreateCopyWasCalled());
    assertNull(equipment.getMotors().iterator().next().getEquipment().getId());
    assertEquals("Blower", equipment.getMotors().iterator().next().getEquipment().getName());
    assertTrue(instrument.isCreateCopyWasCalled());
    assertNull(equipment.getInstruments().iterator().next().getEquipment().getId());
    assertEquals("Blower", equipment.getInstruments().iterator().next().getEquipment().getName());
    assertTrue(accessory.isCreateCopyWasCalled());
    assertNull(equipment.getAccessories().iterator().next().getEquipment().getId());
    assertEquals("Blower", equipment.getAccessories().iterator().next().getEquipment().getName());
  }

  public void testGetEquipmentAndRelatedIds_AllRelatedObjectsAreSet_CommaSeperatedIdsReturned() throws Exception {
  Equipment equipment = new MockEquipment("10.0.B0", "10.0.B1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    equipment.setEquipmentSoleSource(true);
    equipment.setExistingEquipmentModification(true);
    equipment.setStandardEquipment(true);
    equipment.setId(new Long(1));
    Process process = new Process();
    process.setId(new Long(2));
    equipment.setProcess(process);
    Electrical electrical = new Electrical();
    electrical.setId(new Long(3));
    equipment.setElectrical(electrical);
    Mechanical mechanical = new Mechanical();
    mechanical.setId(new Long(3));
    equipment.setMechanical(mechanical);
    CostSchedule cost = new CostSchedule();
    cost.setId(new Long(4));
    equipment.setCostSchedule(cost);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    purchasing.setId(new Long(5));
    equipment.setPurchasing(purchasing);
    Set<Motor> treeSetMotors = new TreeSet<Motor>();
    Motor motor = new Motor();
    motor.setId(new Long(6));
    treeSetMotors.add(motor);
    motor = new Motor();
    motor.setId(new Long(66));
    treeSetMotors.add(motor);
    equipment.setMotors(treeSetMotors);

    Set<Instrument> instruments = new TreeSet<Instrument>();
    Instrument inst = new Instrument();
    inst.setId(new Long(7));
    instruments.add(inst);
    inst = new Instrument();
    inst.setId(new Long(77));
    instruments.add(inst);
    equipment.setInstruments(instruments);

    Set<Accessory> accessories = new TreeSet<Accessory>();
    Accessory accessory = new Accessory();
    accessory.setId(new Long(8));
    accessories.add(accessory);
    accessory = new Accessory();
    accessory.setId(new Long(88));
    accessories.add(accessory);
    equipment.setAccessories(accessories);
    assertEquals("'1','2','3','3','4','5','6','66','7','77','8','88'", equipment.getEquipmentAndRelatedIds());
  }

  public void testGetEquipmentAndRelatedIds_AllRelatedObjectsAreSet_MotorInstrumentAccessoryAreEmpty_CommaSeperatedIdsReturned() throws Exception {
  Equipment equipment = new MockEquipment("10.0.B0", "10.0.B1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    equipment.setEquipmentSoleSource(true);
    equipment.setExistingEquipmentModification(true);
    equipment.setStandardEquipment(true);
    equipment.setId(new Long(1));
    Process process = new Process();
    process.setId(new Long(2));
    equipment.setProcess(process);
    Electrical electrical = new Electrical();
    electrical.setId(new Long(3));
    equipment.setElectrical(electrical);
    Mechanical mechanical = new Mechanical();
    mechanical.setId(new Long(3));
    equipment.setMechanical(mechanical);
    CostSchedule cost = new CostSchedule();
    cost.setId(new Long(4));
    equipment.setCostSchedule(cost);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    purchasing.setId(new Long(5));
    equipment.setPurchasing(purchasing);
    assertEquals("'1','2','3','3','4','5'", equipment.getEquipmentAndRelatedIds());
  }

  private class MockEquipmentWithNoMotorsInstrumentsAccessories extends Equipment {
    public MockEquipmentWithNoMotorsInstrumentsAccessories(String equipmentNumber, String existingEquipmentNumber,
                                                           String name, String description,
                                                           Area area, String processLineNumber,
                                                           String equipmentTagNumber, EquipmentType equipmentType,
                                                           EquipmentType subType,
                                                           Projects p) {
      super(equipmentNumber, existingEquipmentNumber, name, description, area, processLineNumber, equipmentTagNumber, equipmentType, subType, p);
    }

    //protected only for testing
    protected GenericDAO<Motor, Long> getMotorDao() {
      return new MockDAOForEquipment<Motor, Long>();
    }

    protected GenericDAO<Instrument, Long> getInstrumentDao() {
      return new MockDAOForEquipment<Instrument, Long>();
    }

    protected GenericDAO<Accessory, Long> getAccessoryDao() {
      return new MockDAOForEquipment<Accessory, Long>();
    }

    private class MockDAOForEquipment<T, T1> extends MockDAO {

      public Criteria createCriteria() {
        return new MockCriteriaForEIS(new Integer(0), null);
      }
    }
  }

  private class MockProcess extends Process {
    private boolean createCopyWasCalled;

    public Process createCopy() throws CloneNotSupportedException {
      this.createCopyWasCalled = true;
      return this;
    }

    public boolean isCreateCopyWasCalled() {
      return createCopyWasCalled;
    }
  }

  private class MockElectrical extends Electrical {
    private boolean createCopyWasCalled;

    public Electrical createCopy() throws CloneNotSupportedException {
      this.createCopyWasCalled = true;
      return this;
    }

    public boolean isCreateCopyWasCalled() {
      return createCopyWasCalled;
    }
  }

  private class MockMechanical extends Mechanical {
    private boolean createCopyWasCalled;

    public Mechanical createCopy() throws CloneNotSupportedException {
      this.createCopyWasCalled = true;
      return this;
    }

    public boolean isCreateCopyWasCalled() {
      return createCopyWasCalled;
    }
  }

  private class MockPurchasing extends Purchasing {
    private boolean createCopyWasCalled;

    public Purchasing createCopy() throws CloneNotSupportedException {
      this.createCopyWasCalled = true;
      return this;
    }

    public boolean isCreateCopyWasCalled() {
      return createCopyWasCalled;
    }
  }

  private class MockCostSchedule extends CostSchedule {
    private boolean createCopyWasCalled;

    public CostSchedule createCopy() throws CloneNotSupportedException {
      this.createCopyWasCalled = true;
      return this;
    }

    public boolean isCreateCopyWasCalled() {
      return createCopyWasCalled;
    }
  }

  private class MockMotor extends Motor {
    private boolean createCopyWasCalled;

    public Motor createCopy() throws CloneNotSupportedException {
      this.createCopyWasCalled = true;
      return this;
    }

    public boolean isCreateCopyWasCalled() {
      return createCopyWasCalled;
    }
  }

  private class MockInstrument extends Instrument {
    private boolean createCopyWasCalled;

    public Instrument createCopy() throws CloneNotSupportedException {
      this.createCopyWasCalled = true;
      return this;
    }

    public boolean isCreateCopyWasCalled() {
      return createCopyWasCalled;
    }
  }

  private class MockAccessorry extends Accessory {
    private boolean createCopyWasCalled;

    public Accessory createCopy() throws CloneNotSupportedException {
      this.createCopyWasCalled = true;
      return this;
    }

    public boolean isCreateCopyWasCalled() {
      return createCopyWasCalled;
    }
  }
}