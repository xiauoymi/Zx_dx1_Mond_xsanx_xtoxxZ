/*
 FieldEquipmentType_UT was created on Nov 20, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile: FieldEquipmentType_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vvvelu $    	 On:	$Date: 2008-12-16 16:40:33 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class FieldEquipmentType_UT extends XMLTestCase {

  public void testToXml_WithoitListValues_VerifyXml() throws Exception {
    FieldType ft = new FieldType();
    ft.setType("text");
    FieldEquipmentType type = new FieldEquipmentType(ft, "comments", "My Comments", 3, "Integer",
        new EquipmentType(new Long(12), "Sheller", "S"), new ArrayList<ListValue>(), 2);
    Document xmlDoc = DOMUtil.stringToXML(type.toXml());
    assertXpathEvaluatesTo("1", "count(//fieldEquipmentType)", xmlDoc);
    assertXpathEvaluatesTo("12", "//fieldEquipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("text", "//fieldEquipmentType/fieldType", xmlDoc);
    assertXpathEvaluatesTo("comments", "//fieldEquipmentType/name", xmlDoc);
    assertXpathEvaluatesTo("My Comments", "//fieldEquipmentType/label", xmlDoc);
    assertXpathEvaluatesTo("Integer", "//fieldEquipmentType/dataType", xmlDoc);
    assertXpathEvaluatesTo("3", "//fieldEquipmentType/size", xmlDoc);
    assertXpathEvaluatesTo("2", "//fieldEquipmentType/precision", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//listValues)", xmlDoc);
    assertXpathEvaluatesTo("0", "count(//listValues/listValue)", xmlDoc);
  }

  public void testToXml_WithValues_VerifyXml() throws Exception {
    FieldType ft = new FieldType();
    ft.setType("select");
    ArrayList<ListValue> listValues = new ArrayList<ListValue>();
    listValues.add(new ListValue(new Long(11), "Value One"));
    listValues.add(new ListValue(new Long(22), "Value Two"));
    FieldEquipmentType type = new FieldEquipmentType(ft, "comments", "My Comments", 3, "Integer",
        new EquipmentType(new Long(12), "Sheller", "S"), listValues, 0);
    Document xmlDoc = DOMUtil.stringToXML(type.toXml());
    assertXpathEvaluatesTo("1", "count(//fieldEquipmentType)", xmlDoc);
    assertXpathEvaluatesTo("12", "//fieldEquipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("select", "//fieldEquipmentType/fieldType", xmlDoc);
    assertXpathEvaluatesTo("comments", "//fieldEquipmentType/name", xmlDoc);
    assertXpathEvaluatesTo("My Comments", "//fieldEquipmentType/label", xmlDoc);
    assertXpathEvaluatesTo("Integer", "//fieldEquipmentType/dataType", xmlDoc);
    assertXpathEvaluatesTo("3", "//fieldEquipmentType/size", xmlDoc);
    assertXpathEvaluatesTo("0", "//fieldEquipmentType/precision", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//listValues)", xmlDoc);
    assertXpathEvaluatesTo("2", "count(//listValues/listValue)", xmlDoc);
    assertXpathEvaluatesTo("11", "//fieldEquipmentType/listValues/listValue/id", xmlDoc);
    assertXpathEvaluatesTo("Value One", "//fieldEquipmentType/listValues/listValue/value", xmlDoc);
    assertXpathEvaluatesTo("22", "//fieldEquipmentType/listValues/listValue[2]/id", xmlDoc);
    assertXpathEvaluatesTo("Value Two", "//fieldEquipmentType/listValues/listValue[2]/value", xmlDoc);
  }
}