/*
 FieldType_UT was created on Oct 8, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: FieldType_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-10-09 18:12:37 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class FieldType_UT extends TestCase {
  public void testIsValueNotNull_ForText() throws Exception {
    FieldType ft = new FieldType();
    ft.setType("text");
    assertFalse(ft.isValueNotNull(null));
    assertFalse(ft.isValueNotNull(""));
    assertFalse(ft.isValueNotNull(" "));
    assertTrue(ft.isValueNotNull("12"));
  }

  public void testIsValueNotNull_ForTextarea() throws Exception {
    FieldType ft = new FieldType();
    ft.setType("textarea");
    assertFalse(ft.isValueNotNull(null));
    assertFalse(ft.isValueNotNull(""));
    assertFalse(ft.isValueNotNull(" "));
    assertTrue(ft.isValueNotNull("12"));
  }

  public void testIsValueNotNull_ForSelect() throws Exception {
    FieldType ft = new FieldType();
    ft.setType("select");
    assertFalse(ft.isValueNotNull(null));
    assertFalse(ft.isValueNotNull(""));
    assertFalse(ft.isValueNotNull(" "));
    assertTrue(ft.isValueNotNull("12"));
  }

  public void testIsValueNotNull_ForCheckbox() throws Exception {
    FieldType ft = new FieldType();
    ft.setType("select");
    assertFalse(ft.isValueNotNull(null));
    assertFalse(ft.isValueNotNull(""));
    assertFalse(ft.isValueNotNull(" "));
    assertTrue(ft.isValueNotNull("12"));
    assertTrue(ft.isValueNotNull("on"));
    assertTrue(ft.isValueNotNull("ON"));
  }

  public void testIsValueNotNull_ForRadio() throws Exception {
    FieldType ft = new FieldType();
    ft.setType("select");
    assertFalse(ft.isValueNotNull(null));
    assertFalse(ft.isValueNotNull(""));
    assertFalse(ft.isValueNotNull(" "));
    assertTrue(ft.isValueNotNull("12"));
    assertTrue(ft.isValueNotNull("n"));
    assertTrue(ft.isValueNotNull("Y"));
  }
}