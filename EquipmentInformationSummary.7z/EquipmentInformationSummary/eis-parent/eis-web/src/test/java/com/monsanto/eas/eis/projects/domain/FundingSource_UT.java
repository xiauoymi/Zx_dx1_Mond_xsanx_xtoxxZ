/*
 FundingSource_UT was created on Dec 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: FundingSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-15 19:33:50 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class FundingSource_UT extends XMLTestCase {

  public void testToXml_VerifyXml() throws Exception {
    FundingSource type = new FundingSource(new Long(12));
    type.setSource("TYPE 1");
    Document xmlDoc = DOMUtil.stringToXML(type.toXml());
    assertXpathEvaluatesTo("1", "count(//fundingSource)", xmlDoc);
    assertXpathEvaluatesTo("12", "//fundingSource/id", xmlDoc);
    assertXpathEvaluatesTo("TYPE 1", "//fundingSource/source", xmlDoc);
  }
}