/*
 InstrumentDesignator_UT was created on Oct 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.custommonkey.xmlunit.XMLTestCase;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * Filename:    $RCSfile: InstrumentDesignator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-10-27 17:23:02 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class InstrumentDesignator_UT extends XMLTestCase {

  public void testToXml_VerifyXml() throws Exception {
    InstrumentDesignator designator = new InstrumentDesignator(new Long(123), "Analyzer", "A");
    Document xmlDoc = DOMUtil.stringToXML(designator.toXml());
    assertXpathEvaluatesTo("1", "count(//instrumentDesignator)", xmlDoc);
    assertXpathEvaluatesTo("123", "//instrumentDesignator/id", xmlDoc);
    assertXpathEvaluatesTo("A - Analyzer", "//instrumentDesignator/name", xmlDoc);
  }
}