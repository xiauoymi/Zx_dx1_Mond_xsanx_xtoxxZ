/*
 Instrument_UT was created on Oct 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile: Instrument_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date:
 * 2008/10/24 20:09:54 $
 *
 * @author sspati1
 * @version $Revision: 1.16 $
 */
public class Instrument_UT extends XMLTestCase {

  public void testToXml_VerifyXml() throws Exception {
    Integer estimatedCost = new Integer(18);
    Integer actualCost = new Integer(19);
    Instrument inst = new Instrument(null, new InstrumentDesignator(new Long(1L), null, "S"),
        new InstrumentDesignator(new Long(2L),
            null, "B"),
        "XY", "This is my description", new IOType(new Long(3L)),
        "Alarm 1", new Integer(11), new Integer(22),
        "range2", "watts", "These are my comments", true, createPurchasing(), createEquipment(), estimatedCost, actualCost,
        "1212", "manu 1", "model num");
    inst.setId(new Long(123));
    Document xmlDoc = DOMUtil.stringToXML(inst.toXml());
    assertXpathEvaluatesTo("1", "count(//instrument)", xmlDoc);
    assertXpathEvaluatesTo("123", "//instrument/instrumentId", xmlDoc);
    assertXpathEvaluatesTo("1", "//instrument/designatorFirstCharId", xmlDoc);
    assertXpathEvaluatesTo("S", "//instrument/designatorFirstCharTypeCode", xmlDoc);
    assertXpathEvaluatesTo("2", "//instrument/designatorSecondCharId", xmlDoc);
    assertXpathEvaluatesTo("B", "//instrument/designatorSecondCharTypeCode", xmlDoc);
    assertXpathEvaluatesTo("XY", "//instrument/sequenceNumber", xmlDoc);
    assertXpathEvaluatesTo("This is my description", "//instrument/instDescription", xmlDoc);
    assertXpathEvaluatesTo("3", "//instrument/ioTypeId", xmlDoc);
    assertXpathEvaluatesTo("Alarm 1", "//instrument/alarmPoints", xmlDoc);
    assertXpathEvaluatesTo("11", "//instrument/alarmPointsQuantity", xmlDoc);
    assertXpathEvaluatesTo("22", "//instrument/volts", xmlDoc);
    assertXpathEvaluatesTo("range2", "//instrument/range", xmlDoc);
    assertXpathEvaluatesTo("watts", "//instrument/units", xmlDoc);
    assertXpathEvaluatesTo("18", "//instrument/estimatedCost", xmlDoc);
    assertXpathEvaluatesTo("19", "//instrument/actualCost", xmlDoc);

    assertXpathEvaluatesTo("These are my comments", "//instrument/comments", xmlDoc);
    assertXpathEvaluatesTo("1212", "//instrument/bidPackage", xmlDoc);
    assertXpathEvaluatesTo("manu 1", "//instrument/manufacturer", xmlDoc);
    assertXpathEvaluatesTo("model num", "//instrument/modelNumber", xmlDoc);
    assertXpathEvaluatesTo("true", "//instrument/purchasedWithEquipment", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//purchasing)", xmlDoc);
    assertXpathEvaluatesTo("123", "//purchasing/purchaseId", xmlDoc);
    assertXpathEvaluatesTo("vendor information", "//purchasing/vendor", xmlDoc);
//    assertXpathEvaluatesTo("false", "//purchasing/purchaseSoleSource", xmlDoc);
    assertXpathEvaluatesTo("12", "//purchasing/rtpNumber", xmlDoc);
    assertXpathEvaluatesTo("13", "//purchasing/poNumber", xmlDoc);
    assertXpathEvaluatesTo("14", "//purchasing/lineNumber", xmlDoc);
    assertXpathEvaluatesTo("15", "//purchasing/poLineAmount", xmlDoc);
    assertXpathEvaluatesTo("16", "//purchasing/poLineQuantity", xmlDoc);
    assertXpathEvaluatesTo("17", "//purchasing/poLineValue", xmlDoc);
    assertXpathEvaluatesTo("18", "//purchasing/coAmount", xmlDoc);
    assertXpathEvaluatesTo("Sep 25, 2008", "//purchasing/originalShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 26, 2008", "//purchasing/revisedShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 27, 2008", "//purchasing/actualDeliveryDate", xmlDoc);
    assertXpathEvaluatesTo("false", "//purchasing/exportDocuments", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testToXml_WithNullValues_VerifyXml() throws Exception {
    Instrument inst = new Instrument(null, null, null, null, null, null, null, null, null, null, null,
        null, false, createPurchasing(), createEquipment(), null, null, null, null, null);
    Document xmlDoc = DOMUtil.stringToXML(inst.toXml());
    assertXpathEvaluatesTo("1", "count(//instrument)", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/instrumentId", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/designatorFirstCharId", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/designatorFirstCharTypeCode", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/designatorSecondCharId", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/designatorSecondCharTypeCode", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/sequenceNumber", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/instDescription", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/ioTypeId", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/alarmPoints", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/alarmPointsQuantity", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/volts", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/range", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/units", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/comments", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/bidPackage", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/manufacturer", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/modelNumber", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/estimatedCost", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/actualCost", xmlDoc);
    assertXpathEvaluatesTo("false", "//instrument/purchasedWithEquipment", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//purchasing)", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
  }

  public void testCreateCopy() throws Exception {
    Instrument inst = new Instrument(new Long(234), new InstrumentDesignator(new Long(1L), null, "S"),
        new InstrumentDesignator(new Long(2L),
            null, "B"),
        "XY", "This is my description", new IOType(new Long(3L)),
        "Alarm 1", new Integer(11), new Integer(22),
        "range2", "watts", "These are my comments", true, createPurchasing(), createEquipment(), new Integer(23), new Integer(24),
        "1212", "manu 1", "model num");
    inst.setId(new Long(123));
    Instrument copyOfInstrument = inst.createCopy();
    Document xmlDoc = DOMUtil.stringToXML(copyOfInstrument.toXml());
    assertXpathEvaluatesTo("1", "count(//instrument)", xmlDoc);
    assertXpathEvaluatesTo("", "//instrument/instrumentId", xmlDoc);
    assertXpathEvaluatesTo("1", "//instrument/designatorFirstCharId", xmlDoc);
    assertXpathEvaluatesTo("S", "//instrument/designatorFirstCharTypeCode", xmlDoc);
    assertXpathEvaluatesTo("2", "//instrument/designatorSecondCharId", xmlDoc);
    assertXpathEvaluatesTo("B", "//instrument/designatorSecondCharTypeCode", xmlDoc);
    assertXpathEvaluatesTo("XY", "//instrument/sequenceNumber", xmlDoc);
    assertXpathEvaluatesTo("This is my description", "//instrument/instDescription", xmlDoc);
    assertXpathEvaluatesTo("3", "//instrument/ioTypeId", xmlDoc);
    assertXpathEvaluatesTo("Alarm 1", "//instrument/alarmPoints", xmlDoc);
    assertXpathEvaluatesTo("11", "//instrument/alarmPointsQuantity", xmlDoc);
    assertXpathEvaluatesTo("22", "//instrument/volts", xmlDoc);
    assertXpathEvaluatesTo("range2", "//instrument/range", xmlDoc);
    assertXpathEvaluatesTo("watts", "//instrument/units", xmlDoc);
    assertXpathEvaluatesTo("These are my comments", "//instrument/comments", xmlDoc);
    assertXpathEvaluatesTo("1212", "//instrument/bidPackage", xmlDoc);
    assertXpathEvaluatesTo("manu 1", "//instrument/manufacturer", xmlDoc);
    assertXpathEvaluatesTo("model num", "//instrument/modelNumber", xmlDoc);
    assertXpathEvaluatesTo("true", "//instrument/purchasedWithEquipment", xmlDoc);
    assertXpathEvaluatesTo("23", "//instrument/estimatedCost", xmlDoc);
    assertXpathEvaluatesTo("24", "//instrument/actualCost", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//purchasing)", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/purchaseId", xmlDoc);
    assertXpathEvaluatesTo("vendor information", "//purchasing/vendor", xmlDoc);
//    assertXpathEvaluatesTo("false", "//purchasing/purchaseSoleSource", xmlDoc);
    assertXpathEvaluatesTo("12", "//purchasing/rtpNumber", xmlDoc);
    assertXpathEvaluatesTo("13", "//purchasing/poNumber", xmlDoc);
    assertXpathEvaluatesTo("14", "//purchasing/lineNumber", xmlDoc);
    assertXpathEvaluatesTo("15", "//purchasing/poLineAmount", xmlDoc);
    assertXpathEvaluatesTo("16", "//purchasing/poLineQuantity", xmlDoc);
    assertXpathEvaluatesTo("17", "//purchasing/poLineValue", xmlDoc);
    assertXpathEvaluatesTo("18", "//purchasing/coAmount", xmlDoc);
    assertXpathEvaluatesTo("Sep 25, 2008", "//purchasing/originalShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 26, 2008", "//purchasing/revisedShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 27, 2008", "//purchasing/actualDeliveryDate", xmlDoc);
    assertXpathEvaluatesTo("false", "//purchasing/exportDocuments", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  private Purchasing createPurchasing() {
    Purchasing purchasing = new Purchasing(new Long(123), "vendor information", new Integer(12), new Long(13),
        new Integer(14), new Long(15), new Integer(16), new Long(17), new Long(18), getDate(2), getDate(3),
        getDate(4), false);
    purchasing.setEquipment(null);
    return purchasing;
  }

  private Equipment createEquipment() {
    Equipment equipment = new Equipment("10.0.B0", "0.000.1W1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);
    Set<Motor> motors = new HashSet<Motor>();
    motors.add(new Motor());
    equipment.setMotors(motors);
    Set<Instrument> instruments = new HashSet<Instrument>();
    instruments.add(new Instrument());
    equipment.setInstruments(instruments);
    return equipment;
  }

  private Date getDate(int numDaysToAdd) {
    Calendar cal = Calendar.getInstance();
    cal.set(Calendar.YEAR, 2008);
    cal.set(Calendar.MONTH, 8);
    cal.set(Calendar.DATE, 23);
    cal.add(Calendar.DATE, numDaysToAdd);
    return cal.getTime();
  }

  public void testGetInstrumentAndRelatedIds(){
     Instrument inst = new Instrument(null, new InstrumentDesignator(new Long(1L), null, "S"),
        new InstrumentDesignator(new Long(2L),
            null, "B"),
        "XY", "This is my description", new IOType(new Long(3L)),
        "Alarm 1", new Integer(11), new Integer(22),
        "range2", "watts", "These are my comments", true, createPurchasing(), createEquipment(), null, null, "1212",
         null, null);
    inst.setId(new Long(222));
    assertEquals("'222','1','2','3','123'", inst.getInstrumentAndRelatedIds());
  }

   public void testGetInstrumentAndRelatedIds_SomeObjectsAreNull(){
     Instrument inst = new Instrument(null, new InstrumentDesignator(new Long(1L), null, "S"),
        new InstrumentDesignator(new Long(2L),
            null, "B"),
        "XY", "This is my description", null,
        "Alarm 1", new Integer(11), new Integer(22),
        "range2", "watts", "These are my comments", true, null, createEquipment(), null, null, null, null, null);
    inst.setId(new Long(222));
    assertEquals("'222','1','2'", inst.getInstrumentAndRelatedIds());
  }
}