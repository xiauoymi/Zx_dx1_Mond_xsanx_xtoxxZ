package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 13, 2008 Time: 4:33:20 PM To change this template use File |
 * Settings | File Templates.
 */
public class Mechanical_UT extends XMLTestCase {

  public void testToXml_VerifyXml() throws Exception {
    PurchaseScope ps = new PurchaseScope(new Long(1));
    ps.setPurchaseScopeName("Contractor");
    Mechanical mechanical = new Mechanical("Mechanical Engineer", "EIS MDL 123456", 12345, ps, 54321,
        "SER 1234", "25ABC", createEquipment());
    Document xmlDoc = DOMUtil.stringToXML(mechanical.toXml());
    DOMUtil.outputXML(xmlDoc);
    assertXpathEvaluatesTo("1", "count(//mechanical)", xmlDoc);
    assertXpathEvaluatesTo("", "//mechanical/mechId", xmlDoc);
    assertXpathEvaluatesTo("Mechanical Engineer", "//mechanical/engineer", xmlDoc);
    assertXpathEvaluatesTo("EIS MDL 123456", "//mechanical/modelNumber", xmlDoc);
    assertXpathEvaluatesTo("12345", "//mechanical/shippingWeight", xmlDoc);
    assertXpathEvaluatesTo("Contractor", "//mechanical/purchaseScopeName", xmlDoc);
    assertXpathEvaluatesTo("54321", "//mechanical/operatingWeight", xmlDoc);
    assertXpathEvaluatesTo("25ABC", "//mechanical/dynamicLoad", xmlDoc);
    assertXpathEvaluatesTo("SER 1234", "//mechanical/serialNumber", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testToXml_ValuesAreNullAndInvertingBooleans() throws Exception {
    Mechanical mechanical = new Mechanical(null, null, null, null, null,
        null, null, createEquipment());
    Document xmlDoc = DOMUtil.stringToXML(mechanical.toXml());
    assertXpathEvaluatesTo("1", "count(//mechanical)", xmlDoc);
    assertXpathEvaluatesTo("", "//mechanical/mechId", xmlDoc);
    assertXpathEvaluatesTo("", "//mechanical/engineer", xmlDoc);
    assertXpathEvaluatesTo("", "//mechanical/modelNumber", xmlDoc);
    assertXpathEvaluatesTo("", "//mechanical/shippingWeight", xmlDoc);
    assertXpathEvaluatesTo("", "//mechanical/purchaseScopeName", xmlDoc);
    assertXpathEvaluatesTo("", "//mechanical/operatingWeight", xmlDoc);
    assertXpathEvaluatesTo("", "//mechanical/dynamicLoad", xmlDoc);
    assertXpathEvaluatesTo("", "//mechanical/serialNumber", xmlDoc);
  }

  public void testCreateCopy() throws Exception {
    PurchaseScope ps = new PurchaseScope(new Long(1));
    ps.setPurchaseScopeName("Contractor");
    Mechanical mechanical = new Mechanical("Mechanical Engineer", "EIS MDL 123456", 12345, ps, 54321,
        "SER 1234", "123ABC", createEquipment());
    mechanical.setId(new Long(123));
    Mechanical copyOfMechanical = mechanical.createCopy();
    Document xmlDoc = DOMUtil.stringToXML(copyOfMechanical.toXml());
    DOMUtil.outputXML(xmlDoc);
    assertXpathEvaluatesTo("1", "count(//mechanical)", xmlDoc);
    assertXpathEvaluatesTo("", "//mechanical/mechId", xmlDoc);
    assertXpathEvaluatesTo("Mechanical Engineer", "//mechanical/engineer", xmlDoc);
    assertXpathEvaluatesTo("EIS MDL 123456", "//mechanical/modelNumber", xmlDoc);
    assertXpathEvaluatesTo("12345", "//mechanical/shippingWeight", xmlDoc);
    assertXpathEvaluatesTo("Contractor", "//mechanical/purchaseScopeName", xmlDoc);
    assertXpathEvaluatesTo("54321", "//mechanical/operatingWeight", xmlDoc);
//    assertXpathEvaluatesTo("1234", "//mechanical/dynamicLoad", xmlDoc);
    assertXpathEvaluatesTo("SER 1234", "//mechanical/serialNumber", xmlDoc);
    assertXpathEvaluatesTo("123ABC", "//mechanical/dynamicLoad", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  private Equipment createEquipment() {
    Equipment equipment = new Equipment("10.0.B0", "0.000.1W1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);
    Set<Motor> motors = new HashSet<Motor>();
    motors.add(new Motor());
    equipment.setMotors(motors);
    Set<Instrument> instruments = new HashSet<Instrument>();
    instruments.add(new Instrument());
    equipment.setInstruments(instruments);
    return equipment;
  }

  public void testGetMechanicalAndItsRelatedIds() throws Exception {
    PurchaseScope ps = new PurchaseScope(new Long(1));
    ps.setPurchaseScopeName("Contractor");
    Mechanical mechanical = new Mechanical("Mechanical Engineer", "EIS MDL 123456", 12345, ps, 54321,
        "SER 1234", null, createEquipment());
    mechanical.setId(new Long(1));
    assertEquals("'1','1'", mechanical.getMechanicalAndRelatedIds());
  }

  public void testGetMechanicalAndItsRelatedIds_ValuesAreNull() throws Exception {
    Mechanical mechanical = new Mechanical(null, null, null, new PurchaseScope(), null,
        null, null, createEquipment());
    mechanical.setId(new Long(1));
    assertEquals("'1'", mechanical.getMechanicalAndRelatedIds());
  }
}
