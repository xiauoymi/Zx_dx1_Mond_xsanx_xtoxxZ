/*
 Motor_UT was created on Oct 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile: Motor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date:
 * 2008/10/27 17:22:46 $
 *
 * @author sspati1
 * @version $Revision: 1.12 $
 */
public class Motor_UT extends XMLTestCase {

  public void testToXml() throws Exception {

    MotorDesignStatus ds = new MotorDesignStatus(new Long(7));
    MotorLoadValueType lv = new MotorLoadValueType(new Long(8));
    Motor motor = new Motor(new Long(1), new ComponentDesignator(new Long(123), "Unidentifed", "MU"),
        new String("WE"), "Motor Component Name", new Double(2),
        new Integer(200),
        new Integer(3), new Integer(3), new Integer(4), ds, "These are my comments", lv, new Double(9),
        "Electrical", "IO Cabinet", true, "Size 500", createEquipment(), "4545");
    motor.setMotorBrake(true);
    Document xmlDoc = DOMUtil.stringToXML(motor.toXml());
    assertXpathEvaluatesTo("1", "count(//motor)", xmlDoc);
    assertXpathEvaluatesTo("1", "//motor/motorId", xmlDoc);
    assertXpathEvaluatesTo("123", "//motor/componentDesignatorId", xmlDoc);
    assertXpathEvaluatesTo("MU", "//motor/componentDesignatorTypeCode", xmlDoc);
    assertXpathEvaluatesTo("WE", "//motor/sequenceNumber", xmlDoc);
    assertXpathEvaluatesTo("Motor Component Name", "//motor/componentName", xmlDoc);
    assertXpathEvaluatesTo("2.0", "//motor/fla", xmlDoc);
    assertXpathEvaluatesTo("200", "//motor/motorVoltage", xmlDoc);
    assertXpathEvaluatesTo("3", "//motor/phase", xmlDoc);
    assertXpathEvaluatesTo("3", "//motor/frequency", xmlDoc);
    assertXpathEvaluatesTo("4", "//motor/rpm", xmlDoc);
    assertXpathEvaluatesTo("7", "//motor/designStatusId", xmlDoc);
    assertXpathEvaluatesTo("These are my comments", "//motor/comments", xmlDoc);
    assertXpathEvaluatesTo("8", "//motor/loadValueTypeId", xmlDoc);
    assertXpathEvaluatesTo("9.0", "//motor/loadValueQuantity", xmlDoc);
    assertXpathEvaluatesTo("Electrical", "//motor/powerSource", xmlDoc);
    assertXpathEvaluatesTo("IO Cabinet", "//motor/ioCabinet", xmlDoc);
    assertXpathEvaluatesTo("true", "//motor/loadDisconnectRequired", xmlDoc);
    assertXpathEvaluatesTo("Size 500", "//motor/starterSize", xmlDoc);
    assertXpathEvaluatesTo("true", "//motor/motorBrake", xmlDoc);
    assertXpathEvaluatesTo("4545", "//motor/bidPackage", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testToXml_AllValuesAreNull() throws Exception {
    Motor motor = new Motor(null, null, null, null, null, null, null, null, null, null, null, null, null, null,
        null, false, null, createEquipment(), null);
    motor.setMotorBrake(false);
    Document xmlDoc = DOMUtil.stringToXML(motor.toXml());
    assertXpathEvaluatesTo("1", "count(//motor)", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/motorId", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/componentDesignatorId", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/componentDesignatorTypeCode", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/sequenceNumber", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/componentName", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/fla", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/motorVoltage", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/phase", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/frequency", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/rpm", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/starterId", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/designStatusId", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/comments", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/loadValueTypeId", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/loadValueQuantity", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/powerSource", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/ioCabinet", xmlDoc);
    assertXpathEvaluatesTo("false", "//motor/loadDisconnectRequired", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/starterSize", xmlDoc);
    assertXpathEvaluatesTo("false", "//motor/motorBrake", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/bidPackage", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
  }

  public void testCreateCopy() throws Exception {
    MotorDesignStatus ds = new MotorDesignStatus(new Long(7));
    MotorLoadValueType lv = new MotorLoadValueType(new Long(8));
    Motor motor = new Motor(new Long(1), new ComponentDesignator(new Long(123), "Unidentifed", "MU"),
        new String("WE"), "Motor Component Name", new Double(2),
        new Integer(200),
        new Integer(3), new Integer(3), new Integer(4), ds, "These are my comments", lv, new Double(9),
        "Electrical", "IO Cabinet", true, "Size 500", createEquipment(), "123ABC");
    motor.setMotorBrake(true);
    Motor copyOfMotor = motor.createCopy();
    Document xmlDoc = DOMUtil.stringToXML(copyOfMotor.toXml());
    assertXpathEvaluatesTo("1", "count(//motor)", xmlDoc);
    assertXpathEvaluatesTo("", "//motor/motorId", xmlDoc);
    assertXpathEvaluatesTo("123", "//motor/componentDesignatorId", xmlDoc);
    assertXpathEvaluatesTo("MU", "//motor/componentDesignatorTypeCode", xmlDoc);
    assertXpathEvaluatesTo("WE", "//motor/sequenceNumber", xmlDoc);
    assertXpathEvaluatesTo("Motor Component Name", "//motor/componentName", xmlDoc);
    assertXpathEvaluatesTo("2.0", "//motor/fla", xmlDoc);
    assertXpathEvaluatesTo("200", "//motor/motorVoltage", xmlDoc);
    assertXpathEvaluatesTo("3", "//motor/phase", xmlDoc);
    assertXpathEvaluatesTo("3", "//motor/frequency", xmlDoc);
    assertXpathEvaluatesTo("4", "//motor/rpm", xmlDoc);
    assertXpathEvaluatesTo("7", "//motor/designStatusId", xmlDoc);
    assertXpathEvaluatesTo("These are my comments", "//motor/comments", xmlDoc);
    assertXpathEvaluatesTo("8", "//motor/loadValueTypeId", xmlDoc);
    assertXpathEvaluatesTo("9.0", "//motor/loadValueQuantity", xmlDoc);
    assertXpathEvaluatesTo("Electrical", "//motor/powerSource", xmlDoc);
    assertXpathEvaluatesTo("IO Cabinet", "//motor/ioCabinet", xmlDoc);
    assertXpathEvaluatesTo("true", "//motor/loadDisconnectRequired", xmlDoc);
    assertXpathEvaluatesTo("Size 500", "//motor/starterSize", xmlDoc);
    assertXpathEvaluatesTo("123ABC", "//motor/bidPackage", xmlDoc);
    assertXpathEvaluatesTo("true", "//motor/motorBrake", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  private Equipment createEquipment() {
    Equipment equipment = new Equipment("10.0.B0", "0.000.1W1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);
    Set<Motor> motors = new HashSet<Motor>();
    motors.add(new Motor());
    equipment.setMotors(motors);
    Set<Instrument> instruments = new HashSet<Instrument>();
    instruments.add(new Instrument());
    equipment.setInstruments(instruments);
    return equipment;
  }

  public void testGetMotorAndRelatedIds() throws Exception {
    MotorDesignStatus ds = new MotorDesignStatus(new Long(7));
    MotorLoadValueType lv = new MotorLoadValueType(new Long(8));
    Motor motor = new Motor(new Long(1), new ComponentDesignator(new Long(123), "Unidentifed", "MU"),
        new String("WE"), "Motor Component Name", new Double(2),
        new Integer(200),
        new Integer(3), new Integer(3), new Integer(4), ds, "These are my comments", lv, new Double(9),
        "Electrical", "IO Cabinet", true, "Size 500", createEquipment(), "4545");
    motor.setMotorBrake(true);
    assertEquals("'1','8','123','7'", motor.getMotorAndRelatedIds());
  }

  public void testGetMotorAndRelatedIds_SomeRelatedObjectsAreNull() throws Exception {
    MotorDesignStatus ds = new MotorDesignStatus(new Long(7));
    MotorLoadValueType lv = null;
    Motor motor = new Motor(new Long(1), null,
        new String("WE"), "Motor Component Name", new Double(2),
        new Integer(200),
        new Integer(3), new Integer(3), new Integer(4), ds, "These are my comments", lv, new Double(9),
        "Electrical", "IO Cabinet", true, "Size 500", createEquipment(), "4545");
    motor.setMotorBrake(true);
    assertEquals("'1','7'", motor.getMotorAndRelatedIds());
  }

}