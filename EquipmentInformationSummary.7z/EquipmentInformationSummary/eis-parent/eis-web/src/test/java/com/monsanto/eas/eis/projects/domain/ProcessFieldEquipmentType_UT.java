/*
 ProcessFieldEquipmentType_UT was created on Oct 8, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * Filename:    $RCSfile: ProcessFieldEquipmentType_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-10 16:55:42 $
 *
 * @author sspati1
 * @version $Revision: 1.9 $
 */
public class ProcessFieldEquipmentType_UT extends XMLTestCase {

  public void testToXml_ValueIsNotNull_VerifyXml() throws Exception {
    FieldType type = new FieldType();
    type.setType("text");
    ProcessFieldEquipmentType pfe = new ProcessFieldEquipmentType(null, null, new FieldEquipmentType(type, "testName", null, 0, null, null, null, 0), "test value");
    Document xmlDoc = DOMUtil.stringToXML(pfe.toXml());
    assertXpathEvaluatesTo("1", "count(//testName)", xmlDoc);
    assertXpathEvaluatesTo("", "//testName/@id", xmlDoc);
    assertXpathEvaluatesTo("text", "//testName/@fieldEquipmentType", xmlDoc);
    assertXpathEvaluatesTo("test value", "//testName", xmlDoc);
  }

  public void testToXml_ValueIsNull_VerifyXml() throws Exception {
    FieldType type = new FieldType();
    type.setType("text");
    ProcessFieldEquipmentType pfe = new ProcessFieldEquipmentType(null, null, new FieldEquipmentType(type, "testName", null, 0, null, null, null, 0), "test value");
    Document xmlDoc = DOMUtil.stringToXML(pfe.toXml());
    assertXpathEvaluatesTo("1", "count(//testName)", xmlDoc);
    assertXpathEvaluatesTo("", "//testName/@id", xmlDoc);
    assertXpathEvaluatesTo("text", "//testName/@fieldEquipmentType", xmlDoc);
    assertXpathEvaluatesTo("test value", "//testName", xmlDoc);
  }

  public void testCreateCopy() throws Exception {
    FieldType type = new FieldType();
    type.setType("text");
    ProcessFieldEquipmentType pfe = new ProcessFieldEquipmentType(new Long(12), null, new FieldEquipmentType(type, "testName", null, 0, null, null, null, 0), "test value");
    ProcessFieldEquipmentType copyOfPfe = pfe.createCopy();
    Document xmlDoc = DOMUtil.stringToXML(copyOfPfe.toXml());
    assertXpathEvaluatesTo("1", "count(//testName)", xmlDoc);
    assertXpathEvaluatesTo("", "//testName/@id", xmlDoc);
    assertXpathEvaluatesTo("text", "//testName/@fieldEquipmentType", xmlDoc);
    assertXpathEvaluatesTo("test value", "//testName", xmlDoc);

  }
  
}