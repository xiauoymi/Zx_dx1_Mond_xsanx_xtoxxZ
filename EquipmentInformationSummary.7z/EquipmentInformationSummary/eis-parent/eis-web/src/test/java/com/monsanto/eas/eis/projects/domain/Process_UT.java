/*
 Process_UT was created on Sep 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Filename:    $RCSfile: Process_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date:
 * 2008/10/13 15:58:24 $
 *
 * @author sspati1
 * @version $Revision: 1.19 $
 */
public class Process_UT extends XMLTestCase {

  public void testToXml() throws Exception {
    WaterType waterType = new WaterType(Long.valueOf("3"));
    waterType.setType("Process");
    DustType type = new DustType(Long.valueOf("4"));
    type.setType("Red Dust");
    GasType gasType = new GasType(Long.valueOf(2));
    gasType.setType("Propane");
    Process process = new Process(null, "Ear Corn", new Double(45), new Integer(5000),
        new DesignCapacityUnit(new Long(12)), false, new Integer(90),
        new Integer(100), true, gasType, new Integer(25), new Integer(5), true,
        new Integer(50), new Integer(10), waterType, false, new Integer(20),
        type, "BH#", new Integer(6), new Integer(500), true,
        "These are my remarks", "123");
    process.setEquipment(createEquipment());
    Document xmlDoc = DOMUtil.stringToXML(process.toXml());
    assertXpathEvaluatesTo("1", "count(//process)", xmlDoc);
    assertXpathEvaluatesTo("", "//process/processId", xmlDoc);
    assertXpathEvaluatesTo("Ear Corn", "//process/productType", xmlDoc);
    assertXpathEvaluatesTo("45.0", "//process/productDensity", xmlDoc);
    assertXpathEvaluatesTo("5000", "//process/designCapacity", xmlDoc);
    assertXpathEvaluatesTo("12", "//process/designCapacityUnitId", xmlDoc);
    assertXpathEvaluatesTo("false", "//process/compAirRequired", xmlDoc);
    assertXpathEvaluatesTo("90", "//process/compAirPressure", xmlDoc);
    assertXpathEvaluatesTo("100", "//process/compAirFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/gasRequired", xmlDoc);
    assertXpathEvaluatesTo("2", "//process/gasType/gasTypeId", xmlDoc);
    assertXpathEvaluatesTo("25", "//process/gasPressure", xmlDoc);
    assertXpathEvaluatesTo("5", "//process/gasFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/waterRequired", xmlDoc);
    assertXpathEvaluatesTo("50", "//process/waterPressure", xmlDoc);
    assertXpathEvaluatesTo("10", "//process/waterFlowrate", xmlDoc);
    assertXpathEvaluatesTo("3", "//process/waterType/waterTypeId", xmlDoc);
    assertXpathEvaluatesTo("false", "//process/dustPickupRequired", xmlDoc);
    assertXpathEvaluatesTo("20", "//process/dustPickupVelocity", xmlDoc);
    assertXpathEvaluatesTo("4", "//process/dustType/dustTypeId", xmlDoc);
    assertXpathEvaluatesTo("BH#", "//process/baghouseCyclone", xmlDoc);
    assertXpathEvaluatesTo("6", "//process/ductSize", xmlDoc);
    assertXpathEvaluatesTo("500", "//process/ductFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/specificationRequired", xmlDoc);
    assertXpathEvaluatesTo("These are my remarks", "//process/processRemarks", xmlDoc);
    assertXpathEvaluatesTo("", "//process/processFieldEquipmentTypes", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testToXml_ValuesAreNullAndInvertingBoolans() throws Exception {
    Process process = new Process(null, null, null, null, null, true, null,
        null, true, null, null, null, false, null, null, null, true, null, null, null, null, null, false, null,
        null);
    process.setEquipment(createEquipment());
    Document xmlDoc = DOMUtil.stringToXML(process.toXml());
    assertXpathEvaluatesTo("1", "count(//process)", xmlDoc);
    assertXpathEvaluatesTo("", "//process/processId", xmlDoc);
    assertXpathEvaluatesTo("", "//process/productType", xmlDoc);
    assertXpathEvaluatesTo("", "//process/productDensity", xmlDoc);
    assertXpathEvaluatesTo("", "//process/designCapacity", xmlDoc);
    assertXpathEvaluatesTo("", "//process/designCapacityUnitId", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/compAirRequired", xmlDoc);
    assertXpathEvaluatesTo("", "//process/compAirPressure", xmlDoc);
    assertXpathEvaluatesTo("", "//process/compAirFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/gasRequired", xmlDoc);
    assertXpathEvaluatesTo("", "//process/gasType/gasTypeId", xmlDoc);
    assertXpathEvaluatesTo("", "//process/gasPressure", xmlDoc);
    assertXpathEvaluatesTo("", "//process/gasFlowrate", xmlDoc);
    assertXpathEvaluatesTo("false", "//process/waterRequired", xmlDoc);
    assertXpathEvaluatesTo("", "//process/waterPressure", xmlDoc);
    assertXpathEvaluatesTo("", "//process/waterFlowrate", xmlDoc);
    assertXpathEvaluatesTo("", "//process/waterType/waterTypeId", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/dustPickupRequired", xmlDoc);
    assertXpathEvaluatesTo("", "//process/dustPickupVelocity", xmlDoc);
    assertXpathEvaluatesTo("", "//process/dustType/dustTypeId", xmlDoc);
    assertXpathEvaluatesTo("", "//process/baghouseCyclone", xmlDoc);
    assertXpathEvaluatesTo("", "//process/ductSize", xmlDoc);
    assertXpathEvaluatesTo("", "//process/ductFlowrate", xmlDoc);
    assertXpathEvaluatesTo("false", "//process/specificationRequired", xmlDoc);
    assertXpathEvaluatesTo("", "//process/processRemarks", xmlDoc);
    assertXpathEvaluatesTo("", "//process/processFieldEquipmentTypes", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
  }

  public void testToXml_ProcessFeildEquipmentTypesIsSet() throws Exception {
    WaterType waterType = new WaterType(Long.valueOf("3"));
    waterType.setType("Process");
    Process process = new Process(null, "Ear Corn", new Double(45), new Integer(5000),
        new DesignCapacityUnit(new Long(12)), false, new Integer(90),
        new Integer(100), true, new GasType(Long.valueOf(2)), new Integer(25), new Integer(5), true,
        new Integer(50), new Integer(10), waterType, false, new Integer(20),
        new DustType(Long.valueOf("4")), "BH#", new Integer(6), new Integer(500), true,
        "These are my remarks", "");
    process.setId(new Long(1));
    process.setEquipment(createEquipment());
    List<ProcessFieldEquipmentType> pfes = new ArrayList<ProcessFieldEquipmentType>();
    pfes.add(getPfe("text", new Long(12)));
    pfes.add(getPfe("textarea", new Long(12)));
    pfes.add(getPfe("checkbox", new Long(12)));
    pfes.add(getPfe("select", new Long(12)));
    pfes.add(getPfe("radio", new Long(12)));
    process.setProcessFieldEquipmentTypes(pfes);
    Document xmlDoc = DOMUtil.stringToXML(process.toXml());
    assertXpathEvaluatesTo("1", "count(//process)", xmlDoc);
    assertXpathEvaluatesTo("1", "//process/processId", xmlDoc);
    assertXpathEvaluatesTo("Ear Corn", "//process/productType", xmlDoc);
    assertXpathEvaluatesTo("45.0", "//process/productDensity", xmlDoc);
    assertXpathEvaluatesTo("5000", "//process/designCapacity", xmlDoc);
    assertXpathEvaluatesTo("12", "//process/designCapacityUnitId", xmlDoc);
    assertXpathEvaluatesTo("false", "//process/compAirRequired", xmlDoc);
    assertXpathEvaluatesTo("90", "//process/compAirPressure", xmlDoc);
    assertXpathEvaluatesTo("100", "//process/compAirFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/gasRequired", xmlDoc);
    assertXpathEvaluatesTo("2", "//process/gasType/gasTypeId", xmlDoc);
    assertXpathEvaluatesTo("25", "//process/gasPressure", xmlDoc);
    assertXpathEvaluatesTo("5", "//process/gasFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/waterRequired", xmlDoc);
    assertXpathEvaluatesTo("50", "//process/waterPressure", xmlDoc);
    assertXpathEvaluatesTo("10", "//process/waterFlowrate", xmlDoc);
    assertXpathEvaluatesTo("3", "//process/waterType/waterTypeId", xmlDoc);
    assertXpathEvaluatesTo("false", "//process/dustPickupRequired", xmlDoc);
    assertXpathEvaluatesTo("20", "//process/dustPickupVelocity", xmlDoc);
    assertXpathEvaluatesTo("4", "//process/dustType/dustTypeId", xmlDoc);
    assertXpathEvaluatesTo("BH#", "//process/baghouseCyclone", xmlDoc);
    assertXpathEvaluatesTo("6", "//process/ductSize", xmlDoc);
    assertXpathEvaluatesTo("500", "//process/ductFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/specificationRequired", xmlDoc);
    assertXpathEvaluatesTo("These are my remarks", "//process/processRemarks", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//process/processFieldEquipmentTypes)", xmlDoc);
    assertXpathEvaluatesTo("5", "count(//process/processFieldEquipmentTypes/testName)", xmlDoc);
    assertXpathEvaluatesTo("12", "//process/processFieldEquipmentTypes/testName[1]/@id", xmlDoc);
    assertXpathEvaluatesTo("text",
        "//process/processFieldEquipmentTypes/testName[1]/@fieldEquipmentType", xmlDoc);
    assertXpathEvaluatesTo("test value",
        "//process/processFieldEquipmentTypes/testName[1]/", xmlDoc);
    assertXpathEvaluatesTo("12", "//process/processFieldEquipmentTypes/testName[2]/@id", xmlDoc);
    assertXpathEvaluatesTo("textarea",
        "//process/processFieldEquipmentTypes/testName[2]/@fieldEquipmentType", xmlDoc);
    assertXpathEvaluatesTo("test value", "//process/processFieldEquipmentTypes/testName[2]",
        xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
  }

  public void testCreateCopy() throws Exception {
    WaterType waterType = new WaterType(Long.valueOf("3"));
    waterType.setType("Process");
    Process process = new Process(null, "Ear Corn", new Double(45), new Integer(5000), new DesignCapacityUnit(new Long(12)), false, new Integer(90),
        new Integer(100), true, new GasType(Long.valueOf(2)), new Integer(25), new Integer(5), true,
        new Integer(50), new Integer(10), waterType, false, new Integer(20),
        new DustType(Long.valueOf("4")), "BH#", new Integer(6), new Integer(500), true,
        "These are my remarks", "");
    process.setId(new Long(1));
    process.setEquipment(createEquipment());
    List<ProcessFieldEquipmentType> pfes = new ArrayList<ProcessFieldEquipmentType>();
    pfes.add(getPfe("text", new Long(12)));
    pfes.add(getPfe("textarea", new Long(12)));
    pfes.add(getPfe("checkbox", new Long(12)));
    pfes.add(getPfe("select", new Long(12)));
    pfes.add(getPfe("radio", new Long(12)));
    process.setProcessFieldEquipmentTypes(pfes);
    Process copyOfProcess = process.createCopy();
    Document xmlDoc = DOMUtil.stringToXML(copyOfProcess.toXml());
    assertXpathEvaluatesTo("1", "count(//process)", xmlDoc);
    assertXpathEvaluatesTo("", "//process/processId", xmlDoc);
    assertXpathEvaluatesTo("Ear Corn", "//process/productType", xmlDoc);
    assertXpathEvaluatesTo("45.0", "//process/productDensity", xmlDoc);
    assertXpathEvaluatesTo("5000", "//process/designCapacity", xmlDoc);
    assertXpathEvaluatesTo("12", "//process/designCapacityUnitId", xmlDoc);
    assertXpathEvaluatesTo("false", "//process/compAirRequired", xmlDoc);
    assertXpathEvaluatesTo("90", "//process/compAirPressure", xmlDoc);
    assertXpathEvaluatesTo("100", "//process/compAirFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/gasRequired", xmlDoc);
    assertXpathEvaluatesTo("2", "//process/gasType/gasTypeId", xmlDoc);
    assertXpathEvaluatesTo("25", "//process/gasPressure", xmlDoc);
    assertXpathEvaluatesTo("5", "//process/gasFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/waterRequired", xmlDoc);
    assertXpathEvaluatesTo("50", "//process/waterPressure", xmlDoc);
    assertXpathEvaluatesTo("10", "//process/waterFlowrate", xmlDoc);
    assertXpathEvaluatesTo("3", "//process/waterType/waterTypeId", xmlDoc);
    assertXpathEvaluatesTo("false", "//process/dustPickupRequired", xmlDoc);
    assertXpathEvaluatesTo("20", "//process/dustPickupVelocity", xmlDoc);
    assertXpathEvaluatesTo("4", "//process/dustType/dustTypeId", xmlDoc);
    assertXpathEvaluatesTo("BH#", "//process/baghouseCyclone", xmlDoc);
    assertXpathEvaluatesTo("6", "//process/ductSize", xmlDoc);
    assertXpathEvaluatesTo("500", "//process/ductFlowrate", xmlDoc);
    assertXpathEvaluatesTo("true", "//process/specificationRequired", xmlDoc);
    assertXpathEvaluatesTo("These are my remarks", "//process/processRemarks", xmlDoc);
    assertXpathEvaluatesTo("1", "count(//process/processFieldEquipmentTypes)", xmlDoc);
    assertXpathEvaluatesTo("5", "count(//process/processFieldEquipmentTypes/testName)", xmlDoc);
    assertXpathEvaluatesTo("", "//process/processFieldEquipmentTypes/testName[1]/@id", xmlDoc);
    assertXpathEvaluatesTo("text",
        "//process/processFieldEquipmentTypes/testName[1]/@fieldEquipmentType", xmlDoc);
    assertXpathEvaluatesTo("test value",
        "//process/processFieldEquipmentTypes/testName[1]/", xmlDoc);
    assertXpathEvaluatesTo("", "//process/processFieldEquipmentTypes/testName[2]/@id", xmlDoc);
    assertXpathEvaluatesTo("textarea",
        "//process/processFieldEquipmentTypes/testName[2]/@fieldEquipmentType", xmlDoc);
    assertXpathEvaluatesTo("test value", "//process/processFieldEquipmentTypes/testName[2]",
        xmlDoc);

    List<ProcessFieldEquipmentType> processFieldEquipmentTypes = copyOfProcess.getProcessFieldEquipmentTypes();
    for(ProcessFieldEquipmentType pfe: processFieldEquipmentTypes){
      assertNull(pfe.getProcess().getId());
      assertEquals("Ear Corn", pfe.getProcess().getProductType());
    }
    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
  }

  private ProcessFieldEquipmentType getPfe(String fieldType, Long id) {
    FieldType type = new FieldType();
    type.setType(fieldType);
    return new ProcessFieldEquipmentType(id, null,
        new FieldEquipmentType(type, "testName", null, 0, null, null, null, 0), "test value");
  }

  private Equipment createEquipment() {
    Equipment equipment = new Equipment("10.0.B0", "0.000.1W1", "Blower", "This is a blower",
        new Area(Long.valueOf("1"), "2", "Dryer"), "234", "ABC123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);
    Set<Motor> motors = new HashSet<Motor>();
    motors.add(new Motor());
    equipment.setMotors(motors);
    Set<Instrument> instruments = new HashSet<Instrument>();
    instruments.add(new Instrument());
    equipment.setInstruments(instruments);
    return equipment;
  }

  public void testGetIdsOfProcessAndRelatedEntities() throws Exception {
    WaterType waterType = new WaterType(Long.valueOf("3"));
    waterType.setType("Process");
    Process process = new Process(null, "Ear Corn", new Double(45), new Integer(5000), new DesignCapacityUnit(new Long(12)), false, new Integer(90),
        new Integer(100), true, new GasType(Long.valueOf(2)), new Integer(25), new Integer(5), true,
        new Integer(50), new Integer(10), waterType, false, new Integer(20),
        new DustType(Long.valueOf("4")), "BH#", new Integer(6), new Integer(500), true,
        "These are my remarks", "");
    process.setId(new Long(1));
    process.setEquipment(createEquipment());
    String ids = process.getProcessAndItsRelatedsIds();
    assertEquals("'1','12'", ids);
  }

  public void testGetIdsOfProcessAndRelatedEntities_EntitiesHaveNullIds() throws Exception {
    WaterType waterType = new WaterType();
    waterType.setType("Process");
    Process process = new Process(null, "Ear Corn", new Double(45), new Integer(5000), new DesignCapacityUnit(), false, new Integer(90),
        new Integer(100), true, new GasType(), new Integer(25), new Integer(5), true,
        new Integer(50), new Integer(10), waterType, false, new Integer(20),
        new DustType(), "BH#", new Integer(6), new Integer(500), true,
        "These are my remarks", "");
    process.setId(new Long(1));
    process.setEquipment(createEquipment());
    String ids = process.getProcessAndItsRelatedsIds();
    assertEquals("'1'", ids);
  }
}