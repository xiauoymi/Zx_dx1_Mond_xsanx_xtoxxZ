/*
 ProjectUserRole_UT was created on Dec 31, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: ProjectUserRole_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-11 15:18:06 $
 *
 * @author SSPATI1
 * @version $Revision: 1.2 $
 */
public class ProjectUserRole_UT extends XMLTestCase {

  public void testToXml_VerifyXml() throws Exception {
    Projects project = new Projects();
    project.setId(new Long(123));
    User user = new User(new Long(234), null, null, null, null, null);
    ProjectUserRole projUserRole = new ProjectUserRole(project, user, null, false);
    Document xmlDoc = DOMUtil.stringToXML(projUserRole.toXml());
    assertXpathEvaluatesTo("1", "count(//projectUserRole)", xmlDoc);
    assertXpathEvaluatesTo("234", "//projectUserRole/userId", xmlDoc);
    assertXpathEvaluatesTo("false", "//projectUserRole/isLead", xmlDoc);
  }
}