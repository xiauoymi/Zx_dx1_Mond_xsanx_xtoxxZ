package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.util.EISConstants;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.HashSet;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Nov 19, 2008 Time: 11:24:47 AM To change this template use File |
 * Settings | File Templates.
 */
public class Projects_UT extends XMLTestCase {

  public void testToXml() throws Exception {
    Area area = new Area(1L, "0", "description");
    List<Area> areaList = new ArrayList<Area>();
    areaList.add(area);
    Crop crop = new Crop(null, "Corn", areaList);
    crop.setId(1L);
    ProjectStatus projectStatus = new ProjectStatus(null, "New");
    projectStatus.setId(1L);
    UnitMeasure unitMeasure = new UnitMeasure(null, "English");
    unitMeasure.setId(1L);
    Location region = new Location(null, "North America");
    region.setId(1L);
    Location country = new Location(null, "USA");
    country.setId(2L);
    Location state = new Location(null, "Alabama");
    state.setId(3L);
    Location city = new Location(null, "Babbie");
    city.setId(4L);
    String projName = "EIS Corn";
    String projNumber = "12345678";
//    String revisionNumber = "AA";
//    String revisionDescription = "Revision Description";
    Date startupDate = ConvertUtil.toDate("Dec 16, 2008", ConvertUtil.PROJECTS_DATE);
    Date arApprovalDate = ConvertUtil.toDate("Dec 16, 2008", ConvertUtil.PROJECTS_DATE);
    Date createdDate = new Date();
    String createdUser = "vvvelu";

    Projects project = new Projects(projNumber, projName, startupDate, arApprovalDate, projectStatus, unitMeasure,
        region, country, state,
        city, crop, createdUser, createdDate
    );
    project.setId(1L);
    project.setMaster(true);
    Document xmlDoc = DOMUtil.stringToXML(project.toXml());
    assertXpathEvaluatesTo("1", "count(//project)", xmlDoc);
    assertXpathEvaluatesTo("1", "//project/projectId", xmlDoc);
    assertXpathEvaluatesTo("12345678", "//project/projNumber", xmlDoc);
    assertXpathEvaluatesTo("EIS Corn", "//project/projName", xmlDoc);
    assertXpathEvaluatesTo("Dec 16, 2008", "//project/startupDate", xmlDoc);
    assertXpathEvaluatesTo("Dec 16, 2008", "//project/arApprovalDate", xmlDoc);
    assertXpathEvaluatesTo("true", "//project/isMaster", xmlDoc);
    assertXpathEvaluatesTo("1", "//project/projStatusId", xmlDoc);
    assertXpathEvaluatesTo("New", "//project/projStatusName", xmlDoc);

    assertXpathEvaluatesTo("1", "//project/unitMeasureId", xmlDoc);
    assertXpathEvaluatesTo("English", "//project/unitMeasureName", xmlDoc);

    assertXpathEvaluatesTo("1", "//project/regionId", xmlDoc);
    assertXpathEvaluatesTo("North America", "//project/regionName", xmlDoc);

    assertXpathEvaluatesTo("2", "//project/countryId", xmlDoc);
    assertXpathEvaluatesTo("USA", "//project/countryName", xmlDoc);

    assertXpathEvaluatesTo("3", "//project/stateId", xmlDoc);
    assertXpathEvaluatesTo("Alabama", "//project/stateName", xmlDoc);

    assertXpathEvaluatesTo("4", "//project/cityId", xmlDoc);
    assertXpathEvaluatesTo("Babbie", "//project/cityName", xmlDoc);

    assertXpathEvaluatesTo("1", "//project/cropId", xmlDoc);
    assertXpathEvaluatesTo("Corn", "//project/cropName", xmlDoc);

//    assertXpathEvaluatesTo("AA", "//project/revisionNumber", xmlDoc);
//    assertXpathEvaluatesTo("Revision Description", "//project/revisionDescription", xmlDoc);
  }

  // this tests the equals and hashCode method of Projects
  public void testEqualsAndHashCodeInProjects_For2ProjectsWithSameIDs() throws Exception {
    Projects project1 = new Projects();
    project1.setId(1L);
    Projects project2 = new Projects();
    project2.setId(1L);
    assertTrue(project1.equals(project2));
    assertTrue(project1.hashCode() == project2.hashCode());
  }

  // this tests the equals and hashCode method of Projects
  public void testEqualsAndHashCodeInProjects_For2ProjectsWithDifferentIDs() throws Exception {
    Projects project1 = new Projects();
    project1.setId(1L);
    Projects project2 = new Projects();
    project2.setId(2L);
    assertFalse(project1.equals(project2));
    assertFalse(project1.hashCode() == project2.hashCode());
  }

  public void testToXml_WithProjectPeople() throws Exception {
    Area area = new Area(1L, "0", "description");
    List<Area> areaList = new ArrayList<Area>();
    areaList.add(area);
    Crop crop = new Crop(null, "Corn", areaList);
    crop.setId(1L);
    ProjectStatus projectStatus = new ProjectStatus(null, "New");
    projectStatus.setId(1L);
    UnitMeasure unitMeasure = new UnitMeasure(null, "English");
    unitMeasure.setId(1L);
    Location region = new Location(null, "North America");
    region.setId(1L);
    Location country = new Location(null, "USA");
    country.setId(2L);
    Location state = new Location(null, "Alabama");
    state.setId(3L);
    Location city = new Location(null, "Babbie");
    city.setId(4L);
    String projName = "EIS Corn";
    String projNumber = "12345678";
//    String revisionNumber = "AA";
//    String revisionDescription = "Revision Description";
    Date startupDate = ConvertUtil.toDate("Dec 16, 2008", ConvertUtil.PROJECTS_DATE);
    Date arApprovalDate = ConvertUtil.toDate("Dec 16, 2008", ConvertUtil.PROJECTS_DATE);
    Date createdDate = new Date();
    String createdUser = "vvvelu";


    Projects project = new Projects(projNumber, projName, startupDate, arApprovalDate, projectStatus, unitMeasure,
        region, country, state,
        city, crop, createdUser, createdDate
    );
    project.setId(1L);
    project.setMaster(false);

    Document xmlDoc = DOMUtil.stringToXML(project.toXml());
    assertXpathEvaluatesTo("1", "count(//project)", xmlDoc);
    assertXpathEvaluatesTo("1", "//project/projectId", xmlDoc);
    assertXpathEvaluatesTo("12345678", "//project/projNumber", xmlDoc);
    assertXpathEvaluatesTo("EIS Corn", "//project/projName", xmlDoc);
    assertXpathEvaluatesTo("Dec 16, 2008", "//project/startupDate", xmlDoc);
    assertXpathEvaluatesTo("Dec 16, 2008", "//project/arApprovalDate", xmlDoc);
    assertXpathEvaluatesTo("false", "//project/isMaster", xmlDoc);
    assertXpathEvaluatesTo("1", "//project/projStatusId", xmlDoc);
    assertXpathEvaluatesTo("New", "//project/projStatusName", xmlDoc);

    assertXpathEvaluatesTo("1", "//project/unitMeasureId", xmlDoc);
    assertXpathEvaluatesTo("English", "//project/unitMeasureName", xmlDoc);

    assertXpathEvaluatesTo("1", "//project/regionId", xmlDoc);
    assertXpathEvaluatesTo("North America", "//project/regionName", xmlDoc);

    assertXpathEvaluatesTo("2", "//project/countryId", xmlDoc);
    assertXpathEvaluatesTo("USA", "//project/countryName", xmlDoc);

    assertXpathEvaluatesTo("3", "//project/stateId", xmlDoc);
    assertXpathEvaluatesTo("Alabama", "//project/stateName", xmlDoc);

    assertXpathEvaluatesTo("4", "//project/cityId", xmlDoc);
    assertXpathEvaluatesTo("Babbie", "//project/cityName", xmlDoc);

    assertXpathEvaluatesTo("1", "//project/cropId", xmlDoc);
    assertXpathEvaluatesTo("Corn", "//project/cropName", xmlDoc);
  }

  public void testGetProjectUserRoles() throws Exception {
    Projects project = new Projects();
    HashSet<ProjectUserRole> projUserRoles = new HashSet<ProjectUserRole>();
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.PROJECT_ENGINEER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.PROJECT_ENGINEER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.PROCESS_ENGINEER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.PROCESS_ENGINEER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.MECHANICAL_ENGINEER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.MECHANICAL_ENGINEER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.MECHANICAL_ENGINEER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.MECHANICAL_DESIGNER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.MECHANICAL_DESIGNER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.MECHANICAL_DESIGNER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.MECHANICAL_DESIGNER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.ELECTRICAL_ENGINEER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.ELECTRICAL_ENGINEER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.ELECTRICAL_ENGINEER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.ELECTRICAL_DESIGNER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.ELECTRICAL_DESIGNER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.ELECTRICAL_DESIGNER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.ELECTRICAL_DESIGNER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.PROJECT_SPONSOR, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.PROJECT_SPONSOR, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.PROJECT_MANAGER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.MANUFACTURING_REPRESENTATIVE, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.MANUFACTURING_REPRESENTATIVE, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.MANUFACTURING_REPRESENTATIVE, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.MANUFACTURING_REPRESENTATIVE, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.LOCATION_MANAGER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.LOCATION_MANAGER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.PROJECT_BUYER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.PROJECT_BUYER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.PROJECT_BUYER, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.PROJECT_CONTROLS, null), false));
    projUserRoles.add(new ProjectUserRole(project, null, new ProjectRole(null, EISConstants.PROJECT_CONTROLS, null), false));
    project.setUserRoles(projUserRoles);

    List<ProjectUserRole> roles = project.getProjectUserRoles(EISConstants.PROJECT_SPONSOR);
    assertEquals(2, roles.size());

    roles = project.getProjectSponsor();
    assertEquals(2, roles.size());

    roles = project.getProjectManager();
    assertEquals(1, roles.size());

    roles = project.getProjectControls();
    assertEquals(2, roles.size());

    roles = project.getProjectBuyer();
    assertEquals(3, roles.size());

    roles = project.getElectricalDesigner();
    assertEquals(4, roles.size());

    roles = project.getElectricalEngr();
    assertEquals(3, roles.size());

    roles = project.getMechanicalDesigner();
    assertEquals(4, roles.size());

    roles = project.getMechanicalEngr();
    assertEquals(3, roles.size());

    roles = project.getManufacturingRep();
    assertEquals(4, roles.size());

    roles = project.getProcessEngr();
    assertEquals(2, roles.size());

    roles = project.getProjEngr();
    assertEquals(2, roles.size());
  }

}
