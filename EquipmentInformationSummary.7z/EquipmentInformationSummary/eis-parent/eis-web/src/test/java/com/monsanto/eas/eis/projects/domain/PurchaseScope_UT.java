package com.monsanto.eas.eis.projects.domain;

import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Dec 8, 2008 Time: 5:05:53 PM To change this template use File | Settings
 * | File Templates.
 */
public class PurchaseScope_UT extends XMLTestCase {

  public void testToXml() throws Exception {
    PurchaseScope ps = new PurchaseScope(new Long(1));
    ps.setPurchaseScopeName("Contractor");
    Document xmlDoc = DOMUtil.stringToXML(ps.toXml());
    assertXpathEvaluatesTo("1", "count(//purchaseScope)", xmlDoc);
    assertXpathEvaluatesTo("1", "//purchaseScope/id", xmlDoc);
    assertXpathEvaluatesTo("Contractor", "//purchaseScope/purchaseScopeName", xmlDoc);

  }
}
