/*
 Purchasing_UT was created on Oct 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.*;

/**
 * Filename:    $RCSfile: Purchasing_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-10 16:55:42 $
 *
 * @author sspati1
 * @version $Revision: 1.14 $
 */
public class Purchasing_UT extends XMLTestCase {

  public void testToXml_VerifyXml() throws Exception {
    Purchasing purchasing = new Purchasing(new Long(123), "vendor information", new Integer(12), new Long(13),
        new Integer(14), new Long(15), new Integer(16), new Long(17), new Long(18), getDate(2), getDate(3),
        getDate(4), false);
    purchasing.setEquipment(createEquipment());
    Document xmlDoc = DOMUtil.stringToXML(purchasing.toXml());
    assertXpathEvaluatesTo("1", "count(//purchasing)", xmlDoc);
    assertXpathEvaluatesTo("123", "//purchasing/purchaseId", xmlDoc);
    assertXpathEvaluatesTo("vendor information", "//purchasing/vendor", xmlDoc);
    assertXpathEvaluatesTo("12", "//purchasing/rtpNumber", xmlDoc);
    assertXpathEvaluatesTo("13", "//purchasing/poNumber", xmlDoc);
    assertXpathEvaluatesTo("false", "//purchasing/purchaseSoleSource", xmlDoc);
    assertXpathEvaluatesTo("14", "//purchasing/lineNumber", xmlDoc);
    assertXpathEvaluatesTo("15", "//purchasing/poLineAmount", xmlDoc);
    assertXpathEvaluatesTo("16", "//purchasing/poLineQuantity", xmlDoc);
    assertXpathEvaluatesTo("17", "//purchasing/poLineValue", xmlDoc);
    assertXpathEvaluatesTo("18", "//purchasing/coAmount", xmlDoc);
    assertXpathEvaluatesTo("Sep 25, 2008", "//purchasing/originalShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 26, 2008", "//purchasing/revisedShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 27, 2008", "//purchasing/actualDeliveryDate", xmlDoc);
    assertXpathEvaluatesTo("false", "//purchasing/exportDocuments", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  public void testToXmlWithoutEquipment_VerifyXml() throws Exception {
    Purchasing purchasing = new Purchasing(new Long(123), "vendor information", new Integer(12), new Long(13),
        new Integer(14), new Long(15), new Integer(16), new Long(17), new Long(18), getDate(2), getDate(3),
        getDate(4), false);
    Document xmlDoc = DOMUtil.stringToXML(purchasing.toXmlWithoutEquipment());
    assertXpathEvaluatesTo("1", "count(//purchasing)", xmlDoc);
    assertXpathEvaluatesTo("123", "//purchasing/purchaseId", xmlDoc);
    assertXpathEvaluatesTo("vendor information", "//purchasing/vendor", xmlDoc);
    assertXpathEvaluatesTo("12", "//purchasing/rtpNumber", xmlDoc);
    assertXpathEvaluatesTo("13", "//purchasing/poNumber", xmlDoc);
    assertXpathEvaluatesTo("14", "//purchasing/lineNumber", xmlDoc);
    assertXpathEvaluatesTo("15", "//purchasing/poLineAmount", xmlDoc);
    assertXpathEvaluatesTo("16", "//purchasing/poLineQuantity", xmlDoc);
    assertXpathEvaluatesTo("17", "//purchasing/poLineValue", xmlDoc);
    assertXpathEvaluatesTo("18", "//purchasing/coAmount", xmlDoc);
    assertXpathEvaluatesTo("Sep 25, 2008", "//purchasing/originalShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 26, 2008", "//purchasing/revisedShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 27, 2008", "//purchasing/actualDeliveryDate", xmlDoc);
    assertXpathEvaluatesTo("false", "//purchasing/exportDocuments", xmlDoc);
    assertXpathEvaluatesTo("false", "//purchasing/purchaseSoleSource", xmlDoc);

    assertXpathEvaluatesTo("0", "count(//equipment)", xmlDoc);
  }

  public void testToXml_FieldsAreNull_verifyXml() throws Exception {
    Purchasing purchasing = new Purchasing();
    purchasing.setEquipment(createEquipment());
    Document xmlDoc = DOMUtil.stringToXML(purchasing.toXml());
    assertXpathEvaluatesTo("1", "count(//purchasing)", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/id", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/vendor", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/rtpNumber", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/poNumber", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/lineNumber", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/poLineAmount", xmlDoc);
    assertXpathEvaluatesTo("1", "//purchasing/poLineQuantity", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/poLineValue", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/coAmount", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/originalShipDate", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/revisedShipDate", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/actualDeliveryDate", xmlDoc);
    assertXpathEvaluatesTo("false", "//purchasing/exportDocuments", xmlDoc);
  }

  public void testCreateCopy() throws Exception {
        Purchasing purchasing = new Purchasing(new Long(123), "vendor information", new Integer(12), new Long(13),
        new Integer(14), new Long(15), new Integer(16), new Long(17), new Long(18), getDate(2), getDate(3),
        getDate(4), false);
    purchasing.setEquipment(createEquipment());
    Purchasing copyOfPurchasing = purchasing.createCopy();
    Document xmlDoc = DOMUtil.stringToXML(copyOfPurchasing.toXml());
    assertXpathEvaluatesTo("1", "count(//purchasing)", xmlDoc);
    assertXpathEvaluatesTo("", "//purchasing/purchaseId", xmlDoc);
    assertXpathEvaluatesTo("vendor information", "//purchasing/vendor", xmlDoc);
    assertXpathEvaluatesTo("12", "//purchasing/rtpNumber", xmlDoc);
    assertXpathEvaluatesTo("13", "//purchasing/poNumber", xmlDoc);
    assertXpathEvaluatesTo("14", "//purchasing/lineNumber", xmlDoc);
    assertXpathEvaluatesTo("15", "//purchasing/poLineAmount", xmlDoc);
    assertXpathEvaluatesTo("16", "//purchasing/poLineQuantity", xmlDoc);
    assertXpathEvaluatesTo("17", "//purchasing/poLineValue", xmlDoc);
    assertXpathEvaluatesTo("18", "//purchasing/coAmount", xmlDoc);
    assertXpathEvaluatesTo("Sep 25, 2008", "//purchasing/originalShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 26, 2008", "//purchasing/revisedShipDate", xmlDoc);
    assertXpathEvaluatesTo("Sep 27, 2008", "//purchasing/actualDeliveryDate", xmlDoc);
    assertXpathEvaluatesTo("false", "//purchasing/exportDocuments", xmlDoc);

    assertXpathEvaluatesTo("1", "count(//equipment)", xmlDoc);
    assertXpathEvaluatesTo("", "//equipment/id", xmlDoc);
    assertXpathEvaluatesTo("10.0.B0", "//equipment/equipmentNumber", xmlDoc);
    assertXpathEvaluatesTo("Blower", "//equipment/name", xmlDoc);
    assertXpathEvaluatesTo("1", "//equipment/area/areaId", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/area/areaCode", xmlDoc);
    assertXpathEvaluatesTo("Dryer", "//equipment/area/areaDescription", xmlDoc);
    assertXpathEvaluatesTo("234", "//equipment/processLineNumber", xmlDoc);
    assertXpathEvaluatesTo("2", "//equipment/equipmentType/equipmentTypeId", xmlDoc);
    assertXpathEvaluatesTo("F", "//equipment/equipmentType/equipmentTypeCode", xmlDoc);
    assertXpathEvaluatesTo("Sheller", "//equipment/equipmentType/equipmentTypeName", xmlDoc);
    assertXpathEvaluatesTo("this is a vendor", "//equipment/equipmentVendor", xmlDoc);

    assertXpathNotExists("//equipment/description", xmlDoc);
    assertXpathNotExists("//equipment/modifiedDate", xmlDoc);
    assertXpathNotExists("//equipment/equipmentTagNumber", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeId", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeCode", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSubType/equipmentSubTypeName", xmlDoc);
    assertXpathNotExists("//equipment/motors", xmlDoc);
    assertXpathNotExists("//equipment/instruments", xmlDoc);
    assertXpathNotExists("//equipment/accessories", xmlDoc);
    assertXpathNotExists("//equipment/existingEquipmentModification", xmlDoc);
    assertXpathNotExists("//equipment/standardEquipment", xmlDoc);
    assertXpathNotExists("//equipment/equipmentSoleSource", xmlDoc);
  }

  private Date getDate(int numDaysToAdd) {
    Calendar cal = Calendar.getInstance();
    cal.set(Calendar.YEAR, 2008);
    cal.set(Calendar.MONTH, 8);
    cal.set(Calendar.DATE, 23);
    cal.add(Calendar.DATE, numDaysToAdd);
    return cal.getTime();
  }

  private Equipment createEquipment() {
    Equipment equipment = new Equipment("10.0.B0", "0.000.1W1", "Blower", "This is a blower", new Area(Long.valueOf("1"), "2", "Dryer"), "234", "123",
        new EquipmentType(Long.valueOf("2"), "Sheller", "F"), new EquipmentType(Long.valueOf("3"), "Conveyor", "H"),
        null);
    Purchasing purchasing = new Purchasing();
    purchasing.setVendor("this is a vendor");
    equipment.setPurchasing(purchasing);
    Set<Motor> motors = new HashSet
        <Motor>();
    motors.add(new Motor());
    equipment.setMotors(motors);
    Set<Instrument> instruments = new HashSet<Instrument>();
    instruments.add(new Instrument());
    equipment.setInstruments(instruments);
    return equipment;
  }

}