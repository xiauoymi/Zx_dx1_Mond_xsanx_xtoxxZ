/*
 MockEquipment was created on Dec 19, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.domain.mock;

import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.mock.MockDAO;
import org.hibernate.Criteria;

/**
 * Filename:    $RCSfile: MockEquipment.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-11 15:18:07 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */

public class MockEquipment extends Equipment {
  public MockEquipment(String equipmentNumber, String existingEquipmentNumber, String name, String description,
                       Area area, String processLineNumber,
                       String equipmentTagNumber, EquipmentType equipmentType, EquipmentType subType,
                       Projects p) {
    super(equipmentNumber, existingEquipmentNumber, name, description, area, processLineNumber, equipmentTagNumber, equipmentType, subType, p);
  }

  protected GenericDAO<Motor, Long> getMotorDao() {
    return new MockDAOForEquipment<Motor, Long>();
  }

  protected GenericDAO<Instrument, Long> getInstrumentDao() {
    return new MockDAOForEquipment<Instrument, Long>();
  }

  protected GenericDAO<Accessory, Long> getAccessoryDao() {
    return new MockDAOForEquipment<Accessory, Long>();
  }

  private class MockDAOForEquipment<T, T1> extends MockDAO {

    public Criteria createCriteria() {
      return new MockCriteriaForEIS(new Integer(10), null);
    }
  }
}