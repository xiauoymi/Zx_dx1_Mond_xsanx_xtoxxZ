package com.monsanto.eas.eis.projects.mocks;

import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.eas.eis.projects.domain.Area;
import org.hibernate.Session;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: vvvelu
 * Date: Sep 2, 2008
 * Time: 4:42:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockAreaDAOImpl extends MockDAO<Area, Long> {
  private Session session;
  private boolean wasFindByPrimaryKeyCalled;
  private boolean wasFindAllCalled;

  public MockAreaDAOImpl(Session session) {
     this.session = session;
   }

  protected Session getHibernateSession() {
    return session;
  }
  

  public Area findByPrimaryKey(Long Id) {
    wasFindByPrimaryKeyCalled = true;
    Area a = (Area)getHibernateSession().load(Area.class, Id);
    a= new Area(null, "0", "description");
    a.setId(Id);
    return a;
  }

  public List<Area> findAll() {
    wasFindAllCalled = true;
    ArrayList areasList = new ArrayList();
    Area a = new Area();
    a.setId(1L);
    areasList.add(a);
    return areasList;
  }

  public boolean wasFindAllCalled() {
    return wasFindAllCalled;
  }

  public boolean wasFindByPrimaryKeyCalled() {
    return wasFindByPrimaryKeyCalled;
  }
}
