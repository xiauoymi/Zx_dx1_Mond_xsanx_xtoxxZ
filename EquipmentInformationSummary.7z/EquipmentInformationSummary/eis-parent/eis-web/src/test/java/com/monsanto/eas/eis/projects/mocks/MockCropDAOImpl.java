package com.monsanto.eas.eis.projects.mocks;

import com.monsanto.eas.eis.projects.domain.Crop;
import com.monsanto.eas.eis.projects.domain.Area;
import com.monsanto.eas.eis.projects.domain.EquipmentType;
import com.monsanto.wst.hibernate.mock.MockDAO;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Aug 4, 2008
 * Time: 7:41:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockCropDAOImpl extends MockDAO<Crop, Long> {
 private Session session;


  private boolean wasFindAllCalled;
  private boolean wasFindByPrimaryKeyCalled;
  private boolean wasFindAllForSortCalled;

  public MockCropDAOImpl(Session session) {
     this.session = session;
   }


  protected Session getHibernateSession() {
    return session;
  }

  public Crop findByPrimaryKey(Long Id) {
    wasFindByPrimaryKeyCalled = true;
    Crop c = (Crop)getHibernateSession().load(Crop.class, Id);
    List<Area> areaList = new ArrayList<Area>(1);
    areaList.add(new Area());
    List<EquipmentType> equipmentTypeList = new ArrayList<EquipmentType>(1);
    equipmentTypeList.add(new EquipmentType());
    c= new Crop(null, "name", areaList);
    c.setId(Id);
    return c;
  }

  public List<Crop> findAll() {
    wasFindAllCalled = true;
    List<Crop> crops = null;
    crops = getHibernateSession().createCriteria(Crop.class).list();
    crops = new ArrayList<Crop>(1);
    crops.add(new Crop(null, "name1", null));
    return crops;
  }

  public List<Crop> findAll(String property, boolean isAscending) {
    wasFindAllForSortCalled = true;
    List<Crop> crops = null;
    crops = getHibernateSession().createCriteria(Crop.class).list();
    crops = new ArrayList<Crop>(1);
    crops.add(new Crop(null, "name", null));
    return crops;
  }

  public boolean wasFindAllCalled() {
    return wasFindAllCalled;
  }

  public boolean wasFindByPrimaryKeyCalled() {
    return wasFindByPrimaryKeyCalled;
  }

  public boolean wasFindAllForSortCalled() {
    return wasFindAllForSortCalled;
  }
}
