/*
 MockEquipmentSearchDAO was created on Oct 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.mocks;

import com.monsanto.eas.eis.projects.dao.DisciplineSearchDAOImpl;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import org.hibernate.Criteria;

/**
 * Filename:    $RCSfile: MockDisciplineSearchDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-11 15:18:07 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class MockDisciplineSearchDAO extends DisciplineSearchDAOImpl {
  private String projectId;
  private String equipmentNumber;
  private String equipmentType;
  private String vendor;
  private String areaId;
  private String equipmentName;
  private String sortKey;
  private String sortDir;
  private boolean findBySearchCriteriaCalled;
  private MockCriteria mockCriteria;
  private String processLineNum;
  private int startIndex;
  private int maxResults;

  public MockDisciplineSearchDAO(HibernateFactory hibernate, Class persistentClass) {
    super(hibernate, persistentClass);
  }
  
  public PaginatedResult findBySearchCriteria(Criteria criteria, String projectId, String equipmentNumber,
                                              String equipmentName,
                                              String processLineNum, String equipmentTypeId,
                                              String areaId, String vendor,
                                              String sortKey, String sortDir, int startIndex, int maxResults) {
    this.startIndex = startIndex;
    this.maxResults = maxResults;
    this.findBySearchCriteriaCalled = true;
    this.projectId = projectId;
    this.equipmentNumber = equipmentNumber;
    this.equipmentType = equipmentTypeId;
    this.vendor = vendor;
    this.areaId = areaId;
    this.equipmentName = equipmentName;
    this.processLineNum = processLineNum;
    this.sortKey = sortKey;
    this.sortDir = sortDir;
    return super.findBySearchCriteria(criteria, projectId, equipmentNumber,
        equipmentName, processLineNum, equipmentTypeId, areaId, vendor, sortKey, sortDir, startIndex, maxResults);
  }

  public Criteria createCriteria() {
    mockCriteria = new MockCriteriaForEIS(new Integer(10), null);
    return mockCriteria;
  }

  public MockCriteria getMockCriteria() {
    return mockCriteria;
  }

  public String getProjectId() {
    return projectId;
  }

  public String getEquipmentNumber() {
    return equipmentNumber;
  }

  public String getEquipmentType() {
    return equipmentType;
  }

  public String getVendor() {
    return vendor;
  }

  public String getProcessLineNum() {
    return processLineNum;
  }

  public String getAreaId() {
    return areaId;
  }

  public String getEquipmentName() {
    return equipmentName;
  }

  public String getSortKey() {
    return sortKey;
  }

  public String getSortDir() {
    return sortDir;
  }

  public int getStartIndex() {
    return startIndex;
  }

  public int getmaxResults() {
    return maxResults;
  }

  public boolean wasFindBySearchCriteriaCalled() {
    return findBySearchCriteriaCalled;
  }
}