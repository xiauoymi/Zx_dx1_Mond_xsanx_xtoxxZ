package com.monsanto.eas.eis.projects.mocks;

import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.mocks.*;
import com.monsanto.eas.eis.projects.EISDAOFactoryImpl;
import com.monsanto.wst.hibernate.mock.MockHibernateFactory;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
/*
 MockEISDAOFactory was created on Aug 21, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class MockEISDAOFactory extends EISDAOFactoryImpl {
  public MockEISDAOFactory(MockHibernateSession session) {
    super(new MockHibernateFactory(),
        new MockProjectsDAOImpl(session),
        new MockProjectStatusDAOImpl(session),
        new MockUnitMeasureDAOImpl(session),
        new MockLocationDAOImpl(session),
        new MockCropDAOImpl(session),
        new MockAreaDAOImpl(session),
        new MockEquipmentTypeDAOImpl(session),
        new MockEquipmentDAO(new Equipment()));
  }
}
