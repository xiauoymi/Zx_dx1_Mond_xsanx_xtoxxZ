package com.monsanto.eas.eis.projects.mocks;

import com.monsanto.eas.eis.projects.dao.EquipmentDAOImpl;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.domain.Process;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import org.hibernate.Criteria;

import java.util.Set;
import java.util.HashSet;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Sep 2, 2008 Time: 4:44:17 PM To change this template use File | Settings
 * | File Templates.
 */
public class MockEquipmentDAO extends EquipmentDAOImpl {

  private boolean wasSaved;
  private boolean wasFindByPrimaryKeyCalled;
  private boolean wasDeleteCalled;
  private boolean findBySearchCriteriaCalled;
  private String projectId;
  private String equipmentNumber;
  private String equipmentType;
  private String vendor;
  private String areaId;
  private String equipmentName;
  private String processLineNum;
  private String sortKey;
  private String sortDir;
  private MockCriteria mockCriteria;
  private boolean hibernateSessionCleared;
  private Object uniqueResult;
  private String existingEquipmentNumber;

  public MockEquipmentDAO(Object uniqueResult) {
    this.uniqueResult = uniqueResult;
  }

  public Equipment save(Equipment e) {
    wasSaved = true;
    return e;
  }

  public void delete(Equipment equipment) {
    wasDeleteCalled = true;
  }

  public boolean wasSaved(Equipment p) {
    return wasSaved;
  }

  public Equipment findByPrimaryKey(Long aLong) {
    wasFindByPrimaryKeyCalled = true;
    //remove suffix
    Equipment equipment = new Equipment("0.0.123W", "0.000.1W1", "e-name", "e-description",
        new Area(null, "0", "Area Description"), "0", "000", new EquipmentType(
        null, "equipment_type", "W"),
        new EquipmentType(null, "sub_type_one", "W"), new Projects());
    equipment.setId(aLong);
    WaterType waterType = new WaterType(Long.valueOf("3"));
    waterType.setType("Process");
    DustType type = new DustType(Long.valueOf("4"));
    type.setType("Red Dust");
    GasType gasType = new GasType(Long.valueOf(2));
    gasType.setType("Propane");
    Process process = new Process(null, "Ear Corn", new Double(45), new Integer(5000), new DesignCapacityUnit(new Long(12)), false, new Integer(90),
        new Integer(100), true, gasType, new Integer(25), new Integer(5), true,
        new Integer(50), new Integer(10), waterType, false, new Integer(20),
        type, "BH#", new Integer(6), new Integer(500), true,
        "These are my remarks", "123");
    process.setId(Long.valueOf(4));
    equipment.setProcess(process);
    equipment.setMotors(getMotors());
    ElectricalInput electricalInput = new ElectricalInput(1L);
    electricalInput.setInput("AI");
    ElectricalOutput electricalOutput = new ElectricalOutput(2L);
    electricalOutput.setOutput("AO");
    OtherMeasurement otherMeasurement = new OtherMeasurement(3L);
    otherMeasurement.setMeasurement("Level");
    Electrical electrical =  new Electrical(null, true, true, true, electricalInput, new Integer(10), electricalOutput,
                                            new Integer(20), "HMI Display", otherMeasurement, "Communications", new Integer(100), null);
    electrical.setId(4L);
    
    equipment.setElectrical(electrical);
    Purchasing purchasing = new Purchasing(new Long(1), "My Vendor", new Integer(123), new Long(123), new Integer(123), new Long(123),
                                            new Integer(10), new Long(123), new Long(123),
                                            ConvertUtil.toDate("Oct 27, 2008", ConvertUtil.PROJECTS_DATE),
                                            ConvertUtil.toDate("Oct 28, 2008", ConvertUtil.PROJECTS_DATE),
                                            ConvertUtil.toDate("Oct 29, 2008", ConvertUtil.PROJECTS_DATE), true);
    equipment.setPurchasing(purchasing);
    purchasing.setEquipment(equipment);
    super.findByPrimaryKey(aLong);
    return equipment;
  }

  public PaginatedResult findBySearchCriteria(String projectId, String equipmentNumber, String equipmentName,
                                              String processLineNum, String equipmentTypeId,
                                              String areaId, String vendor,
                                              String existingEquipmentNumber, String sortKey, String sortDir,
                                              int startIndex, int maxResults) {
    this.existingEquipmentNumber = existingEquipmentNumber;
    this.findBySearchCriteriaCalled = true;
    this.projectId = projectId;
    this.equipmentNumber = equipmentNumber;
    this.equipmentType = equipmentTypeId;
    this.vendor = vendor;
    this.areaId = areaId;
    this.equipmentName = equipmentName;
    this.processLineNum = processLineNum;
    this.sortKey = sortKey;
    this.sortDir = sortDir;
    return super.findBySearchCriteria(projectId, equipmentNumber,
      equipmentName, processLineNum, equipmentTypeId, areaId, vendor, existingEquipmentNumber, sortKey, sortDir, startIndex, maxResults);
  }

  public void clearHibernateSession() {
    this.hibernateSessionCleared = true;
  }

  public Criteria createCriteria() {
    return new MockCriteriaForEIS(8, null);
  }

  private Set<Motor> getMotors() {
    Set<Motor> motors = new HashSet<Motor>();
    MotorDesignStatus ds = new MotorDesignStatus(new Long(7));
    MotorLoadValueType lv = new MotorLoadValueType(new Long(8));
    ComponentDesignator cd = new ComponentDesignator(new Long(9), null, null);
    motors.add(new Motor(new Long(1), cd, "WE", "Motor Component Name", new Double(2),
        new Integer(200),
        new Integer(3), new Integer(3), new Integer(4), ds, "These are my comments", lv, new Double(9),
        "Electrical", "IO Cabinet", true, "Size 500", null, "1212"));
    return motors;
  }

  public boolean wasFindByPrimaryKeyCalled() {
    return wasFindByPrimaryKeyCalled;
  }

  public boolean wasDeleteCalled() {
    return wasDeleteCalled;
  }
  
  protected Criteria getCriteria() {
    mockCriteria = new MockCriteriaForEIS(this.uniqueResult, null);
    return mockCriteria;
  }

  public MockCriteria getMockCriteria() {
    return mockCriteria;
  }

  public String getProjectId() {
    return projectId;
  }

  public String getEquipmentNumber() {
    return equipmentNumber;
  }

  public String getEquipmentType() {
    return equipmentType;
  }

  public String getVendor() {
    return vendor;
  }

  public String getProcessLineNum() {
    return processLineNum;
  }

  public String getAreaId() {
    return areaId;
  }

  public String getEquipmentName() {
    return equipmentName;
  }

  public String getSortKey() {
    return sortKey;
  }

  public String getSortDir() {
    return sortDir;
  }

  public String getExistingEquipmentNumber() {
    return existingEquipmentNumber;
  }

  public boolean wasFindBySearchCriteriaCalled() {
    return findBySearchCriteriaCalled;
  }

  public boolean isHibernateSessionCleared() {
    return hibernateSessionCleared;
  }
}
