package com.monsanto.eas.eis.projects.mocks;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.eas.eis.equipment.service.EquipmentService;
import com.monsanto.eas.eis.projects.EISDAOFactory;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.domain.Process;
import com.monsanto.eas.eis.projects.domain.mock.MockEquipment;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.*;


/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Sep 4, 2008 Time: 6:44:31 PM To change this template use File | Settings
 * | File Templates.
 */
public class MockEquipmentServiceImpl implements EquipmentService {
  EISDAOFactory daoFactory;
  private boolean getAreasAsListCalled;
  private boolean getEquipmentsAsXMLBasedOnSearchCriteriaCalled;
  private boolean getEquipmentTypeAsListCalled;
  private boolean wasGenerateEquipmentNumberCalled;
  private boolean wasAreaFindByPrimaryKeyCalled;
  private boolean wasEquipmentTypeFindByPrimaryKeyCalled;
  private boolean wasGetEquipmentCalled;
  private boolean equipmentSaved;
  private boolean wasDeleteEquipmentCalled;
  private Equipment savedEquipment;
  private List<Equipment> savedEquipments = new ArrayList<Equipment>();

  public MockEquipmentServiceImpl() {
    this(new MockEISDAOFactory(new MockHibernateSession()));
  }

  public MockEquipmentServiceImpl(EISDAOFactory daoFactory) {
    this.daoFactory = daoFactory;
  }

  //TODO: This method will be not used to add Equipment
  public Equipment addEquipment(Map equipDataMap) {
    //To change body of implemented methods use File | Settings | File Templates.
    wasGenerateEquipmentNumberCalled = true;
    wasAreaFindByPrimaryKeyCalled = true;
    wasEquipmentTypeFindByPrimaryKeyCalled = true;
    Equipment equipment = new Equipment();
    equipment.setId(1L);
    return equipment;
  }

  public void deleteEquipment(String equipmentId) {
    wasDeleteEquipmentCalled = true;
    Equipment equipment = new Equipment();
    equipment.setId(1L);
    daoFactory.getEquipmentDAOImpl().delete(equipment);
  }

  public Equipment saveEquipment(Equipment equipment) {
    savedEquipments.add(equipment);
    equipmentSaved = true;
    equipment.setId(1L);
    this.savedEquipment = equipment;
    return equipment;
  }

  public Document lookupEquipmentSubTypes(Long Id) throws IOException {
    StringBuffer xmlStr = new StringBuffer("<types>");
    xmlStr.append("<type><id>112</id><description>Belt</description></type>");
    xmlStr.append("<type><id>111</id><description>Screw</description></type>");
    xmlStr.append("</types>");
    try {
      return DOMUtil.stringToXML(xmlStr.toString());
    } catch (ParserException e) {
      throw new RuntimeException("Error getting subtypes");
    }
  }

  public Equipment lookupEquipment(Long equipmentId) {
    wasGetEquipmentCalled = true;
    Equipment equipment = null;
    if (equipmentId != null && equipmentId.equals(1L)) {
      equipment = new MockEquipment("00.123.W12", "00.123.W13", "Equipment Name", "Equipment Description",
          new Area(null, "0", "Area Description"), "0", "123",
          new EquipmentType(null, "equipment_type", "W"), new EquipmentType(null, "sub_type_one", "W"),
          new Projects());
      equipment.setId(1L);
      WaterType waterType = new WaterType(Long.valueOf("3"));
      waterType.setType("Process");
      DustType type = new DustType(Long.valueOf("4"));
      type.setType("Red Dust");
      GasType gasType = new GasType(Long.valueOf(2));
      gasType.setType("Propane");
      Process process = new Process(null, "Ear Corn", new Double(45), new Integer(5000),
          new DesignCapacityUnit(new Long(12)), false,
          new Integer(90),
          new Integer(100), true, gasType, new Integer(25), new Integer(5), true,
          new Integer(50), new Integer(10), waterType, false, new Integer(20),
          type, "BH#", new Integer(6), new Integer(500), true,
          "These are my remarks", "123");
      process.setId(Long.valueOf(2));
      equipment.setProcess(process);
      process.setEquipment(equipment);

      OtherMeasurement otherMeasurement = new OtherMeasurement(3l);
      otherMeasurement.setMeasurement("Level");
      Electrical electrical = new Electrical(null, true, true, true, null, new Integer(10), null,
          new Integer(20), "HMI Display", otherMeasurement, "Communications", new Integer(100), equipment);
      electrical.setId(4L);

      setInputAndOutputForElectrical(electrical);

      equipment.setElectrical(electrical);
      Purchasing purchasing = new Purchasing(new Long(1), "My Vendor", new Integer(123), new Long(123),
          new Integer(123), new Long(123),
          new Integer(10), new Long(123), new Long(123),
          ConvertUtil.toDate("Oct 27, 2008", ConvertUtil.PROJECTS_DATE),
          ConvertUtil.toDate("Oct 28, 2008", ConvertUtil.PROJECTS_DATE),
          ConvertUtil.toDate("Oct 29, 2008", ConvertUtil.PROJECTS_DATE), true);
      equipment.setPurchasing(purchasing);
      purchasing.setEquipment(equipment);
      FundingSource source = new FundingSource(new Long(22));
      source.setSource("Lease");
      CostSchedule costSchedule = new CostSchedule(new Long(123), getDate(1), getDate(2), getDate(3), new Integer(11),
          new Integer(12), getDate(4), getDate(5), getDate(6), getDate(7), getDate(8), getDate(9), getDate(10),
          getDate(11),
          new Long(13), "estimated source", source, new Integer(15), null);
      equipment.setCostSchedule(costSchedule);
      costSchedule.setEquipment(equipment);
      Mechanical mechanical = new Mechanical(null, null, null, new PurchaseScope(), null, null, "123ABC", equipment);
      mechanical.setId(new Long(4));
      equipment.setMechanical(mechanical);
    }else if(equipmentId != null && equipmentId.equals(2L)) {
      equipment = new MockEquipment("00.123.W12", "00.123.W13", "Equipment Name", "Equipment Description",
          new Area(new Long(1), "0", "Area Description"), "0", "123",
          new EquipmentType(null, "equipment_type", "W"), new EquipmentType(null, "sub_type_one", "W"),
          new Projects());
      equipment.setId(1L);
      WaterType waterType = new WaterType(Long.valueOf("3"));
      waterType.setType("Process");
      DustType type = new DustType(Long.valueOf("4"));
      type.setType("Red Dust");
      GasType gasType = new GasType(Long.valueOf(2));
      gasType.setType("Propane");
      Process process = new Process(null, "Ear Corn", new Double(45), new Integer(5000),
          new DesignCapacityUnit(new Long(12)), false,
          new Integer(90),
          new Integer(100), true, gasType, new Integer(25), new Integer(5), true,
          new Integer(50), new Integer(10), waterType, false, new Integer(20),
          type, "BH#", new Integer(6), new Integer(500), true,
          "These are my remarks", "456");
      process.setId(Long.valueOf(2));
      equipment.setProcess(process);
      process.setEquipment(equipment);
      OtherMeasurement otherMeasurement = new OtherMeasurement(3l);
      otherMeasurement.setMeasurement("Level");
      Electrical electrical = new Electrical(null, true, true, true, null, new Integer(10), null,
          new Integer(20), "HMI Display", null, "Communications", new Integer(100), equipment);
      electrical.setId(4L);
      setInputAndOutputForElectrical(electrical);
      equipment.setElectrical(electrical);
      Mechanical mechanical = new Mechanical("Test engineer", "222", new Integer(2), null, new Integer(3),
          "22223", null, equipment);
      mechanical.setId(new Long(222));
      equipment.setMechanical(mechanical);
      Purchasing purchasing = new Purchasing(new Long(1), "My Vendor", new Integer(123), new Long(123),
          new Integer(123), new Long(123),
          new Integer(10), new Long(123), new Long(123),
          ConvertUtil.toDate("Oct 27, 2008", ConvertUtil.PROJECTS_DATE),
          ConvertUtil.toDate("Oct 28, 2008", ConvertUtil.PROJECTS_DATE),
          ConvertUtil.toDate("Oct 29, 2008", ConvertUtil.PROJECTS_DATE), true);
      equipment.setPurchasing(purchasing);
      purchasing.setEquipment(equipment);
      FundingSource source = new FundingSource(new Long(22));
      source.setSource("Lease");
      CostSchedule costSchedule = new CostSchedule(new Long(123), getDate(1), getDate(2), getDate(3), new Integer(11),
          new Integer(12), getDate(4), getDate(5), getDate(6), getDate(7), getDate(8), getDate(9), getDate(10),
          getDate(11),
          new Long(13), "estimated source", source, new Integer(15), null);
      equipment.setCostSchedule(costSchedule);
      costSchedule.setEquipment(equipment);
    }else if(equipmentId != null && equipmentId.equals(3L)) {
      equipment = new MockEquipment("00.123.W12", "00.123.W13", "Equipment Name", "Equipment Description",
          new Area(null, "0", "Area Description"), "0", "123",
          new EquipmentType(null, "equipment_type", "W"), new EquipmentType(null, "sub_type_one", "W"),
          new Projects());
      equipment.setId(1L);
      WaterType waterType = new WaterType(Long.valueOf("3"));
      waterType.setType("Process");
      DustType type = new DustType(Long.valueOf("4"));
      type.setType("Red Dust");
      GasType gasType = new GasType(Long.valueOf(2));
      gasType.setType("Propane");
      Process process = new Process(null, "Ear Corn", new Double(45), new Integer(5000),
          null, false,
          new Integer(90),
          new Integer(100), true, gasType, new Integer(25), new Integer(5), true,
          new Integer(50), new Integer(10), waterType, false, new Integer(20),
          type, "BH#", new Integer(6), new Integer(500), true,
          "These are my remarks", "789");
      process.setId(Long.valueOf(2));
      equipment.setProcess(process);
      process.setEquipment(equipment);
      OtherMeasurement otherMeasurement = new OtherMeasurement(3l);
      otherMeasurement.setMeasurement("Level");
      Electrical electrical = new Electrical(null, true, true, true, null, new Integer(10), null,
          new Integer(20), "HMI Display", null, "Communications", new Integer(100), equipment);
      electrical.setId(4L);
      setInputAndOutputForElectrical(electrical);
      equipment.setElectrical(electrical);
      Mechanical mechanical = new Mechanical("Test engineer", "222", new Integer(2), null, new Integer(3),
          "22223", null, equipment);
      mechanical.setId(new Long(222));
      equipment.setMechanical(mechanical);
      Purchasing purchasing = new Purchasing(new Long(1), "My Vendor", new Integer(123), new Long(123),
          new Integer(123), new Long(123),
          new Integer(10), new Long(123), new Long(123),
          ConvertUtil.toDate("Oct 27, 2008", ConvertUtil.PROJECTS_DATE),
          ConvertUtil.toDate("Oct 28, 2008", ConvertUtil.PROJECTS_DATE),
          ConvertUtil.toDate("Oct 29, 2008", ConvertUtil.PROJECTS_DATE), true);
      equipment.setPurchasing(purchasing);
      purchasing.setEquipment(equipment);
      FundingSource source = new FundingSource(new Long(22));
      source.setSource("Lease");
      CostSchedule costSchedule = new CostSchedule(new Long(123), getDate(1), getDate(2), getDate(3), new Integer(11),
          new Integer(12), getDate(4), getDate(5), getDate(6), getDate(7), getDate(8), getDate(9), getDate(10),
          getDate(11),
          new Long(13), "estimated source", source, new Integer(15), null);
      equipment.setCostSchedule(costSchedule);
      costSchedule.setEquipment(equipment);
    }
    return equipment;
  }

  public List<Area> lookupAllAreas() {
    getAreasAsListCalled = true;
    return new ArrayList<Area>();
  }

  private void setInputAndOutputForElectrical(Electrical electrical){
    Set<ElectricalInputQuantity> inputQuantities = new HashSet<ElectricalInputQuantity>();
    Set<ElectricalOutputQuantity> outputQuantities = new HashSet<ElectricalOutputQuantity>();
    ElectricalInputQuantity inputQuantity = new ElectricalInputQuantity(new Long(11),
        new ElectricalInput(new Long(123)), new Integer(10), electrical, true);
    inputQuantities.add(inputQuantity);
    inputQuantity = new ElectricalInputQuantity(new Long(12), new ElectricalInput(new Long(234)), new Integer(20),
        electrical, false);
    inputQuantities.add(inputQuantity);
    electrical.setInputQuantity(inputQuantities);

    ElectricalOutputQuantity outputQuantity = new ElectricalOutputQuantity(new Long(13),
        new ElectricalOutput(new Long(345)), new Integer(30), electrical,
        false);
    outputQuantities.add(outputQuantity);
    outputQuantity = new ElectricalOutputQuantity(new Long(14), new ElectricalOutput(new Long(456)), new Integer(40),
        electrical, true);
    outputQuantities.add(outputQuantity);
    electrical.setOutputQuantity(outputQuantities);
  }

  public List<EquipmentType> lookupAllParentEquipmentTypes() {
    getEquipmentTypeAsListCalled = true;
    List<EquipmentType> list = new ArrayList<EquipmentType>();
    EquipmentType type = new EquipmentType(new Long(11), "Conveyor", "C");
    list.add(type);
    List<DesignCapacityUnit> dcus = new ArrayList<DesignCapacityUnit>();
    DesignCapacityUnit dcu = new DesignCapacityUnit(new Long(123));
    dcu.setUnitName("unit name 1");
    dcu.setUnitMeasure(new UnitMeasure(new Long(111), "unit measure 1"));
    dcus.add(dcu);
    dcu = new DesignCapacityUnit(new Long(124));
    dcu.setUnitName("unit name 2");
    dcu.setUnitMeasure(new UnitMeasure(new Long(222), "unit measure 2"));
    dcus.add(dcu);
    type.setDesignCapacityUnits(dcus);
    list.add(new EquipmentType(new Long(12), "Drill", "D"));
    return list;
  }

  public Area lookupAreaById(Long areaId) {
    return new Area(areaId, "code 1", "desc 1");
  }

  public PaginatedResult findBySearchCriteria(String projectId, String equipmentNumber, String equipmentName,
                                              String processLineNum, String equipmentTypeId, String areaId,
                                              String vendor, String existingEquipmentNumber, String sortKey,
                                              String sortDir, int startIndex,
                                              int maxResults) {

    ArrayList<Equipment> equipmentList = new ArrayList<Equipment>();
        Equipment equipment = new Equipment();
      equipment.setId(1L);
      equipment.setEquipmentNumber("E001");
      equipment.setName("Equipment1");
      equipment.setDescription("Equipment 1");
      Process process = new Process();
    equipment.setProcess(process);
    Purchasing purchasing = new Purchasing();
    equipment.setPurchasing(purchasing);
    Electrical electrical = new Electrical();
    equipment.setElectrical(electrical);
    Mechanical mechanical = new Mechanical();
    equipment.setMechanical(mechanical);
    CostSchedule cs = new CostSchedule();
    equipment.setCostSchedule(cs);

      Area area = new Area();
      area.setId(1L);
      area.setAreaCode("1");
      equipment.setArea(area);
      equipmentList.add(equipment);          
    return new PaginatedResult(25, equipmentList);
  }

  public boolean wasGetAreasAsListCalled() {
    return getAreasAsListCalled;
  }

  public boolean wasGetEquipmentsAsXMLBasedOnSearchCriteriaCalled() {
    return getEquipmentsAsXMLBasedOnSearchCriteriaCalled;
  }

  public boolean wasGetEquipmentTypeAsListCalled() {
    return getEquipmentTypeAsListCalled;
  }

  public boolean wasGenerateEquipmentNumberCalled() {
    return wasGenerateEquipmentNumberCalled;
  }

  public boolean wasAreaFindByPrimaryKeyCalled() {
    return wasAreaFindByPrimaryKeyCalled;
  }

  public boolean wasEquipmentTypeFindByPrimaryKeyCalled() {
    return wasEquipmentTypeFindByPrimaryKeyCalled;
  }

  public boolean wasGetEquipmentCalled() {
    return wasGetEquipmentCalled;
  }

  public boolean wasEquipmentSaved() {
    return equipmentSaved;
  }

  public boolean wasDeleteEquipmentCalled() {
    return wasDeleteEquipmentCalled;
  }

  public Equipment getSavedEquipment() {
    return savedEquipment;
  }

  public List<Equipment> getSavedEquipments() {
    return savedEquipments;
  }

  private Date getDate(int numDaysToAdd) {
    Calendar cal = Calendar.getInstance();
    cal.set(Calendar.YEAR, 2008);
    cal.set(Calendar.MONTH, 8);
    cal.set(Calendar.DATE, 23);
    cal.add(Calendar.DATE, numDaysToAdd);
    return cal.getTime();
  }


}
