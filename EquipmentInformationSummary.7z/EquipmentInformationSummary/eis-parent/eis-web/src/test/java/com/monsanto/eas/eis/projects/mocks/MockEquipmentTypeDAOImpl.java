package com.monsanto.eas.eis.projects.mocks;

import com.monsanto.eas.eis.projects.domain.EquipmentType;
import com.monsanto.wst.hibernate.mock.MockDAO;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Sep 2, 2008 Time: 4:43:34 PM To change this template use File | Settings
 * | File Templates.
 */
public class MockEquipmentTypeDAOImpl extends MockDAO<EquipmentType, Long> {
  private Session session;
  private boolean wasFindByPrimaryKeyCalled;

  public MockEquipmentTypeDAOImpl(Session session) {
    this.session = session;
  }

  protected Session getHibernateSession() {
    return session;
  }

  public List<EquipmentType> findAll() {
    List<EquipmentType> list = new ArrayList<EquipmentType>();
    list.add(new EquipmentType(new Long(11), "Blower", "B"));
    list.add(new EquipmentType(new Long(12), "Fan", "F"));
    return list;
  }

  public EquipmentType findByPrimaryKey(Long id) {
    wasFindByPrimaryKeyCalled = true;
    EquipmentType et = new EquipmentType(new Long(1L), "Conveyor", "C");
    if (id.equals(new Long(1L))){
      List<EquipmentType> subTypes = new ArrayList<EquipmentType>();
      subTypes.add(new EquipmentType(new Long(111), "Screw", "S"));
      subTypes.add(new EquipmentType(new Long(112), "Belt", "B"));
      et.setSubEquipmentTypes(subTypes);
    }
    return et;
  }

  public boolean wasFindByPrimaryKeyCalled() {
    return wasFindByPrimaryKeyCalled;
  }
}
