package com.monsanto.eas.eis.projects.mocks;

import com.monsanto.eas.eis.projects.domain.Location;
import com.monsanto.eas.eis.projects.dao.LocationDAOImpl;
import org.hibernate.Session;
import org.hibernate.Criteria;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Aug 6, 2008
 * Time: 12:46:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockLocationDAOImpl extends LocationDAOImpl {

  private Session session;


  private boolean wasFindAllCalled;
  private boolean wasFindByPrimaryKeyCalled;
  private boolean wasFindByRegionCalled;


    public MockLocationDAOImpl(Session session) {
       this.session = session;
     }


    protected Session getHibernateSession() {
      return session;
    }

  public Location findByPrimaryKey(Long Id) {
   wasFindByPrimaryKeyCalled = true;
   Location location = (Location) getHibernateSession().load(Location.class, Id);
   location = new Location(null, "Parent");
   location.setId(1L);
   Location childLocationOne = new Location(null, "childLocation_one");
   childLocationOne.setId(2L);
   location.addChildLocation(childLocationOne);
   Location childLocationTwo = new Location(null, "childLocation_two");
   childLocationTwo.setId(3L);
   location.addChildLocation(childLocationTwo);
   return location;
  }

  public List<Location> findAll() {
    wasFindAllCalled = true;
    List<Location> list = getHibernateSession().createCriteria(Location.class).list();
    list = new ArrayList<Location>(1);
    list.add(new Location(null, "name"));
    return list;
  }

  public List<Location> findByRegion() {
     wasFindByRegionCalled = true;
    Criteria criteria = getHibernateSession().createCriteria(Location.class);
    List<Location> locationList = new ArrayList<Location>(1);
    Location location1 = new Location(null, "Name1");
    location1.setId(1L);
    locationList.add(location1);
    Location location2 = new Location(null, "Name2");
    location1.setId(2L);
    locationList.add(location2);
    return locationList;
  }

  public boolean wasFindAllCalled() {
    return wasFindAllCalled;
  }

  public boolean wasFindByPrimaryKeyCalled() {
    return wasFindByPrimaryKeyCalled;
  }

  public boolean wasFindByRegionCalled() {
    return wasFindByRegionCalled;
  }
}
