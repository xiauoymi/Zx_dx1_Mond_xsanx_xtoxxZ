package com.monsanto.eas.eis.projects.mocks;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.dao.ProjectsDAO;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.alert.domain.AlertForProjectRoleAndStatus;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import org.hibernate.Session;
import org.w3c.dom.Document;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: afhyat Date: Sep 9, 2008 Time: 1:26:27 PM To change this template use File | Settings
 * | File Templates.
 */
public class MockProjectServiceImpl implements ProjectsService {
  private boolean wasEqipmentListCalled = false;
  private boolean wasGetEquipmentXML;
  private ProjectsDAO projectsDAO;

  private boolean getProjectsAsListCalled;
  private boolean deleteProjectsCalled;
  private boolean archiveProjectsCalled;
  private boolean wasGetLocationsAsXML;
  private boolean getProjectStatusesAsListExcludingDeleteCalled;
  private boolean wasAllActiveProjectStatusCalled;
  private boolean wasAllInActiveProjectStatusCalled;
  private boolean wasGetCropCalled;
  private boolean wasGetUnitMeasureCalled;
  private boolean wasGetProjectStatusCalled;
  private boolean wasGetLocationCalled;

  private Session session;
  private boolean wasLookupChildLocationsCalled;
  private boolean getArchivedProjectsCalled;
  private boolean wasLookupChangeInStatusAndRolesForAllProjectsForAUserCalled = false;

  public MockProjectServiceImpl(Session session) {
    projectsDAO = new MockProjectsDAOImpl(session);
    this.session = session;
  }

  public Document getEquipmentsAsXML(String projectId) {
    Document document = null;
    if (projectId != null) {
      wasGetEquipmentXML = true;
      document = DOMUtil.newDocument();
    }
    return document;
  }

  public boolean wasGetEquipmentListCalled() {
    return wasEqipmentListCalled;
  }

  public boolean wasGetEquipmentListXMLCalled() {
    return wasGetEquipmentXML;
  }

  public List<Projects> getActiveProjectsAsList() {
    List<Projects> projectsList = null;
    getProjectsAsListCalled = true;
    projectsList = new ArrayList<Projects>();
    Projects project = new Projects();
    project.setId(1L);
    ProjectStatus status = new ProjectStatus();
    status.setId(1L);
    project.setProjStatus(status);
    projectsList.add(project);
    return projectsList;
  }

  public Document getLocationsAsXML(Long locationId) {
    Document document = null;
    if (locationId != null) {
      wasGetLocationsAsXML = true;
      document = DOMUtil.newDocument();
    }
    return document;

  }


  public List<ProjectStatus> getAllActiveProjectStatus() {
    wasAllActiveProjectStatusCalled = true;
    ProjectStatus ps = new ProjectStatus();
    ps.setId(1L);
    ps.setName("New");
    List<ProjectStatus> projectStatusList = new ArrayList<ProjectStatus>();
    projectStatusList.add(ps);
    return projectStatusList;
  }


  public List<ProjectStatus> getAllInActiveProjectStatus() {
    wasAllInActiveProjectStatusCalled = true;
    ProjectStatus ps = new ProjectStatus();
    ps.setId(1L);
    ps.setName("Completed");
    List<ProjectStatus> projectStatusList = new ArrayList<ProjectStatus>();
    projectStatusList.add(ps);
    return projectStatusList;

  }

  //TODO: To be implemented
  public List<ProjectStatus> getProjectStatuses(boolean isArchivedStatus) {
    if (isArchivedStatus) {
      wasAllInActiveProjectStatusCalled = true;
    } else {
      wasAllActiveProjectStatusCalled = true;
    }
    List<ProjectStatus> list = new ArrayList<ProjectStatus>();
    list.add(new ProjectStatus());
    list.add(new ProjectStatus());
    return list;
  }

  public boolean doesProjectExist(String projectId, String projectNumber) {
    return false;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public List<ProjectStatus> getProjectStatusesAsListExcludingDelete() {
    getProjectStatusesAsListExcludingDeleteCalled = true;
    ProjectStatus ps = new ProjectStatus();
    ps.setId(1L);
    ps.setName("New");
    List<ProjectStatus> projectStatusList = new ArrayList<ProjectStatus>();
    projectStatusList.add(ps);
    return projectStatusList;
  }

  public void deleteProject(Long projectId) {
    deleteProjectsCalled = true;
    Projects project = new Projects();
    project.setId(1L);
    projectsDAO.delete(project);
  }

  public void archiveProjects(String[] projectIDs) {
    archiveProjectsCalled = true;
    Projects project = new Projects();
    project.setId(1L);
    projectsDAO.archive(project);
  }

  public Projects lookupProjectById(Long id) {
    Projects project = getProject();
    project.setId(id);
    List<Area> areas = new ArrayList<Area>();
    areas.add(new Area(new Long(12), "code 2", "desc 2"));
    areas.add(new Area(new Long(13), "code 1", "desc 1"));
    project.setCrop(new Crop(new Long(22), "crop 1", areas));
    HashSet<ProjectUserRole> roles = new HashSet<ProjectUserRole>();
    roles.add(new ProjectUserRole(project, null, new ProjectRole(null, "testRole 1", null), false));
    roles.add(new ProjectUserRole(project, null, new ProjectRole(null, "testRole 2", null), false));
    roles.add(new ProjectUserRole(project, null, new ProjectRole(null, "testRole 1", null), false));
    roles.add(new ProjectUserRole(project, null, new ProjectRole(null, "testRole 3", null), false));
    project.setUserRoles(roles);
    return project;
  }

  public Crop lookupCropById(Long id) {
    return new Crop(id, "crop 1", null);
  }

  public Location lookupLocationById(Long id) {
    return new Location(id, "loc 1");
  }

  public ProjectStatus lookupStatusById(Long id) {
    return new ProjectStatus(id, "status 1");
  }

  public UnitMeasure lookupUnitMeasureById(Long id) {
    return new UnitMeasure(id, "Unit 1");
  }

  public List<Location> lookupChildLocations(Long locationId) {
    this.wasLookupChildLocationsCalled = true;
    List<Location> list = new ArrayList<Location>();
    list.add(new Location());
    list.add(new Location());
    return list;
  }

  public boolean wasGetProjectsAsListCalled() {
    return getProjectsAsListCalled;
  }

  public boolean wasDeleteProjectsCalled() {
    return deleteProjectsCalled;
  }

  public boolean wasArchiveProjectsCalled() {
    return archiveProjectsCalled;
  }

  public boolean wasGetLocationsAsXMLCalled() {
    return wasGetLocationsAsXML;
  }

  public boolean wasGetProjectStatusesAsListExcludingDeleteCalled() {
    return getProjectStatusesAsListExcludingDeleteCalled;
  }

  public boolean wasGetArchivedProjectsCalled() {
    return getArchivedProjectsCalled;
  }

  public boolean wasAllActiveProjectStatusCalled() {
    return wasAllActiveProjectStatusCalled;
  }

  public boolean wasAllInActiveProjectStatusCalled() {
    return wasAllInActiveProjectStatusCalled;
  }

  public boolean wasGetCropCalled() {
    return wasGetCropCalled;
  }

  public boolean wasGetUnitMeasureCalled() {
    return wasGetUnitMeasureCalled;
  }

  public boolean wasGetProjectStatusCalled() {
    return wasGetProjectStatusCalled;
  }

  public boolean isWasGetLocationCalled() {
    return wasGetLocationCalled;
  }


  public boolean wasGetLocationCalled() {
    return wasGetLocationCalled = true;
  }

  public boolean wasLookupChildLocationsCalled() {
    return wasLookupChildLocationsCalled;
  }

  private Projects getProject() {
    Location region = new Location();
    Location country = new Location();
    Location countryCanada = new Location();

    Location state = new Location();
    Location stateTexas = new Location();


    Location city = new Location();
    Location cityBoston = new Location();

    region.setId(new Long(1));
    region.setName("North America");


    country.setId(2L);
    countryCanada.setId(22L);
    country.setName("USA");
    countryCanada.setName("Canada");
    country.setParentLocation(region);
    countryCanada.setParentLocation(region);
    region.addChildLocation(country);
    region.addChildLocation(country);


    state.setId(3L);
    stateTexas.setId(33L);
    state.setName("AL");
    stateTexas.setName("TX");
    state.setParentLocation(country);
    stateTexas.setParentLocation(country);
    country.addChildLocation(state);
    country.addChildLocation(stateTexas);

    city.setId(4L);
    cityBoston.setId(44L);
    city.setName("Abbeville");
    cityBoston.setName("Boston");
    city.setParentLocation(state);
    cityBoston.setParentLocation(state);
    state.addChildLocation(city);
    state.addChildLocation(cityBoston);
    Projects p = new Projects();

    List<Equipment> equipmentList = new ArrayList<Equipment>();
    p.setId((new Long(1)));
    p.setProjName("name");
    p.setProjNumber("12345678");
    p.setStartupDate(ConvertUtil.toDate("09/18/2008", ConvertUtil.SHORT_DATE));
    p.setArApprovalDate(ConvertUtil.toDate("09/18/2008", ConvertUtil.SHORT_DATE));
    ProjectStatus ps = new ProjectStatus(null, "active");
    ps.setId(1L);
    //p.setProjStatus(new ProjectStatus("active"));
    p.setProjStatus(ps);
    UnitMeasure unitMeasure = new UnitMeasure(null, "British");
    unitMeasure.setId(1L);
    //p.setUnitMeasure(new UnitMeasure("British"));
    p.setUnitMeasure(unitMeasure);
    p.setRegion(region);
    p.setCountry(country);
    p.setState(state);
    p.setCity(city);

    //TODO: Crop is set with null values for Areas and EquipmentTypes.
    //TODO: It should be set with non-null values
    List<Area> areaList = new ArrayList<Area>(1);
    areaList.add(new Area(null, "1", "description"));
    List<EquipmentType> equipmentTypeList = new ArrayList<EquipmentType>(1);
    equipmentTypeList.add(new EquipmentType());

    Crop c = new Crop(null, "CROP", areaList);
    c.setId(1L);
    p.setCrop(c);
    Equipment equipment = new Equipment();
    equipment.setId(1L);
    equipment.setEquipmentNumber("E001");
    equipment.setName("Equipment1");
    equipment.setDescription("Equipment 1");
    Area area = new Area();
    area.setId(1L);
    area.setAreaCode("1");
    equipment.setArea(area);
    equipmentList.add(equipment);
    EquipmentType equipmentType = new EquipmentType(1L, "parent", "p");
    EquipmentType subType1 = new EquipmentType(1L, "parent", "p");
    equipment.setEquipmentType(equipmentType);
    equipment.setSubTypeOne(subType1);
    equipment.setElectrical(new Electrical());
    p.setEquipments(equipmentList);

    return p;

  }

  public boolean doesProjectHaveEquipments(Long id) {
    return true;
  }

  public Projects lookupMasterProjectForThisProject(Projects project) {
    Projects p = new Projects();
    p.setId(new Long(12345));
    return p;
  }

  public Projects lookupProjectByIdForAlert(Long id) {
    return null;
  }
}
