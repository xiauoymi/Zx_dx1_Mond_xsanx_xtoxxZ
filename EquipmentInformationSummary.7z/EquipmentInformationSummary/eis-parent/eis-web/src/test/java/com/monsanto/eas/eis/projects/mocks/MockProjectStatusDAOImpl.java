package com.monsanto.eas.eis.projects.mocks;

import com.monsanto.eas.eis.projects.dao.ProjectStatusDAOImpl;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Aug 6, 2008
 * Time: 11:46:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class MockProjectStatusDAOImpl extends ProjectStatusDAOImpl {
  private Session session;


  private boolean wasFindAllCalled;
  private boolean wasFindByPrimaryKeyCalled;
  private boolean wasFindByExampleCalled;
  private boolean findAllExcludingDeleteCalled;
  private boolean wasFindAllActiveStatusCalled;

  private boolean wasFindAllInActiveStatusCalled;


  public MockProjectStatusDAOImpl(Session session) {
      this.session = session;
    }


   protected Session getHibernateSession() {
     return session;
   }

  public ProjectStatus findByPrimaryKey(Long Id) {
    wasFindByPrimaryKeyCalled = true;
    ProjectStatus ps = (ProjectStatus) getHibernateSession().load(ProjectStatus.class, Id);
    ps = new ProjectStatus(null, "name");
    ps.setId(Id);
    return ps;
  }

  public List<ProjectStatus> findAll() {

    wasFindAllCalled = true;
    List<ProjectStatus> list = getHibernateSession().createCriteria(ProjectStatus.class).list();
    list = new ArrayList<ProjectStatus>(1);
    list.add(new ProjectStatus(null, "name"));
    return list;
  }

  public boolean wasFindAllCalled() {
    return wasFindAllCalled;
  }

  public boolean wasFindByPrimaryKeyCalled() {
    return wasFindByPrimaryKeyCalled;
  }

  public List<ProjectStatus> findByExample(ProjectStatus ex, String[] prop) {
    wasFindByExampleCalled = true;
    List l = getHibernateSession().createCriteria(ProjectStatus.class).list();
    ProjectStatus ps = new ProjectStatus();
    ps.setName("Deleted");
    List<ProjectStatus> list = new ArrayList<ProjectStatus>();
    list.add(ps);
    return list;
  }

  public List<ProjectStatus> findAllActiveStatus() {
    wasFindAllActiveStatusCalled = true;
    ProjectStatus ps = new ProjectStatus();
    ps.setName("New");
    ps.setId(1L);
    List<ProjectStatus> list = new ArrayList<ProjectStatus>();
    list.add(ps);
    return list;

  }

  public List<ProjectStatus> findAllInActiveStatus() {
    wasFindAllInActiveStatusCalled = true;
    ProjectStatus ps = new ProjectStatus();
    ps.setId(1L);
    ps.setName("Completed");
    List<ProjectStatus> list = new ArrayList<ProjectStatus>();
    list.add(ps);
    return list;

  }


  public List<ProjectStatus> findAllExcludingDelete() {
    findAllExcludingDeleteCalled = true;
    ProjectStatus ps = new ProjectStatus();
    ps.setId(1L);
    ps.setName("New");
    List<ProjectStatus> projectStatusList = new ArrayList<ProjectStatus>();
    projectStatusList.add(ps);
    return projectStatusList;
  }

  public boolean wasFindAllExcludingDeleteCalled() {
    return findAllExcludingDeleteCalled;
  }

  public boolean wasFindAllActiveStatusCalled() {
    return wasFindAllActiveStatusCalled;
  }

  public boolean wasFindAllInActiveStatusCalled() {
    return wasFindAllInActiveStatusCalled;
  }

  
}
