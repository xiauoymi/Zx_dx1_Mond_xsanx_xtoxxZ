package com.monsanto.eas.eis.projects.mocks;

import com.monsanto.eas.eis.projects.dao.ProjectsDAOImpl;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.util.ConvertUtil;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import org.hibernate.Criteria;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: VVVELU Date: Aug 4, 2008 Time: 6:08:22 PM To change this template use File | Settings
 * | File Templates.
 */
public class MockProjectsDAOImpl extends ProjectsDAOImpl {
  private Session session;


  private boolean wasFindAllCalled;
  private boolean wasFindByPrimaryKeyCalled;
  private boolean wasSaveCalled;
  private boolean wasDeleteCalled;
  private boolean findBySearchCriteriaCalled;
  private boolean findByProjectStatusActiveCalled;
  private boolean wasArchiveProjectsCalled;
  private boolean getArchivedProjectsCalled;
  private MockCriteriaForEIS criteria;

  public MockProjectsDAOImpl(Session session) {
    this.session = session;
  }

  protected Session getHibernateSession() {
    return session;
  }

  //used only for testing
  public Criteria getCriteria() {
    Projects project = new Projects();
    project.setId(new Long(234));
    criteria = new MockCriteriaForEIS(project, null);
    return criteria;
  }

  public void archive(Projects project) {
//    super.archive(project);
    wasArchiveProjectsCalled = true;
  }

  public Projects findByPrimaryKey(Long id) {
    Location region = new Location();
    Location country = new Location();
    Location countryCanada = new Location();

    Location state = new Location();
    Location stateTexas = new Location();


    Location city = new Location();
    Location cityBoston = new Location();

    region.setId(new Long(1));
    region.setName("North America");


    country.setId(2L);
    countryCanada.setId(22L);
    country.setName("USA");
    countryCanada.setName("Canada");
    country.setParentLocation(region);
    countryCanada.setParentLocation(region);
    region.addChildLocation(country);
    region.addChildLocation(country);


    state.setId(3L);
    stateTexas.setId(33L);
    state.setName("AL");
    stateTexas.setName("TX");
    state.setParentLocation(country);
    stateTexas.setParentLocation(country);
    country.addChildLocation(state);
    country.addChildLocation(stateTexas);

    city.setId(4L);
    cityBoston.setId(44L);
    city.setName("Abbeville");
    cityBoston.setName("Boston");
    city.setParentLocation(state);
    cityBoston.setParentLocation(state);
    state.addChildLocation(city);
    state.addChildLocation(cityBoston);


    Projects p = null;
    if (id != null && id == 777) {
      List<Equipment> equipmentList = new ArrayList<Equipment>();
      p = new Projects();
      p.setId(id);
      p.setProjName("ForEquipmentList");
      Equipment equipment = new Equipment();
      equipment.setId(1L);
      equipment.setEquipmentNumber("E001");
      equipment.setName("Equipment1");
      equipment.setDescription("Equipment 1");
      Area area = new Area();
      area.setId(1L);
      area.setAreaCode("1");
      equipment.setArea(area);
      equipmentList.add(equipment);
      EquipmentType equipmentType = new EquipmentType(1L, "parent", "p");
      EquipmentType subType1 = new EquipmentType(1L, "parent", "p");
      equipment.setEquipmentType(equipmentType);
      equipment.setSubTypeOne(subType1);
      p.setEquipments(equipmentList);
      wasFindByPrimaryKeyCalled = true;
      return p;
    }
    if (id != null && (id == 771 || id == 772)) {
      List<Equipment> equipmentList = new ArrayList<Equipment>();
      p = new Projects();
      p.setId(id);
      p.setProjName("ForDeleteProject");
      Crop crop = new Crop();
      crop.setName("EIS Corn");
      crop.setId(1L);
      p.setCrop(crop);
      wasFindByPrimaryKeyCalled = true;
      return p;
    }
    wasFindByPrimaryKeyCalled = true;
    p = (Projects) getHibernateSession().load(Projects.class, id);

    if (p == null)
      p = new Projects();

    List<Equipment> equipmentList = new ArrayList<Equipment>();
    p.setId((new Long(1)));
    p.setProjName("name");
    p.setProjNumber("12345678");
    p.setStartupDate(ConvertUtil.toDate("09/18/2008", ConvertUtil.SHORT_DATE));
    p.setArApprovalDate(ConvertUtil.toDate("09/18/2008", ConvertUtil.SHORT_DATE));
    ProjectStatus ps = new ProjectStatus(null, "active");
    ps.setId(1L);
    //p.setProjStatus(new ProjectStatus("active"));
    p.setProjStatus(ps);
    UnitMeasure unitMeasure = new UnitMeasure(null, "British");
    unitMeasure.setId(1L);
    //p.setUnitMeasure(new UnitMeasure("British"));
    p.setUnitMeasure(unitMeasure);
    p.setRegion(region);
    p.setCountry(country);
    p.setState(state);
    p.setCity(city);

    //TODO: Crop is set with null values for Areas and EquipmentTypes.
    //TODO: It should be set with non-null values
    List<Area> areaList = new ArrayList<Area>(1);
    areaList.add(new Area(null, "1", "description"));
    List<EquipmentType> equipmentTypeList = new ArrayList<EquipmentType>(1);
    equipmentTypeList.add(new EquipmentType());

    Crop c = new Crop(null, "CROP", areaList);
    c.setId(1L);
    p.setCrop(c);
    Equipment equipment = new Equipment();
    equipment.setId(1L);
    equipment.setEquipmentNumber("E001");
    equipment.setName("Equipment1");
    equipment.setDescription("Equipment 1");
    Area area = new Area();
    area.setId(1L);
    area.setAreaCode("1");
    equipment.setArea(area);
    equipmentList.add(equipment);
    EquipmentType equipmentType = new EquipmentType(1L, "parent", "p");
    EquipmentType subType1 = new EquipmentType(1L, "parent", "p");
    equipment.setEquipmentType(equipmentType);
    equipment.setSubTypeOne(subType1);
    p.setEquipments(equipmentList);

    return p;
  }

  public Projects save(Projects p) {
    wasSaveCalled = true;
    return p;
//    return super.save(p);
  }

  public void delete(Projects p) {
    wasDeleteCalled = true;
  }


  public List<Projects> findAll() {
    wasFindAllCalled = true;
    List<Projects> listResult = new ArrayList<Projects>(2);
    Criteria criteria = getHibernateSession().createCriteria(Projects.class);
    List list = criteria.list();
    listResult.add(new Projects());
    listResult.add(new Projects());
    return listResult;

  }

  public List<Projects> findByProjectStatusActive() {
    findByProjectStatusActiveCalled = true;
    Criteria criteria = getHibernateSession().createCriteria(Projects.class);
    List<Projects> listResult = new ArrayList<Projects>();
    Projects project = new Projects();
    project.setId(new Long(1));
    System.out.println("ID : " + project.getId()); // strange that this line returns null.   Needs to be fixed
    project.setProjName("Project" + 1L);
    project.setStartupDate(new Date());
    //TODO: 09/19/08: REGION COUNTRY STATE CITY HAVE BEEN SET UP.
    Location region = new Location();
    Location country = new Location();
    Location state = new Location();
    Location city = new Location();
    region.setId(new Long(1));
    region.setName("North America");
    country.setId(2L);
    country.setName("USA");
    state.setId(3L);
    state.setName("Alabama");
    city.setId(4L);
    city.setName("Abbeville");
    project.setRegion(region);
    project.setCountry(country);
    project.setState(state);
    project.setCity(city);
    ProjectStatus projectStatus = new ProjectStatus();
    projectStatus.setId(new Long(1));
    projectStatus.setName("New");
    project.setProjStatus(projectStatus);
    listResult.add(project);

    project = new Projects();
    project.setId(new Long(2));
    project.setProjName("Project" + 2L);
    project.setStartupDate(new Date());
    //TODO: NOTE: 09/19/08. Projects table changed to have Region, Country, State and City
    project.setRegion(region);
    project.setCountry(country);
    project.setState(state);
    project.setCity(city);

    projectStatus = new ProjectStatus();
    projectStatus.setId(new Long(2));
    projectStatus.setName("In Progress");
    project.setProjStatus(projectStatus);
    listResult.add(project);
    return listResult;
  }

//  public void delete(String[] projectIDs) {
//    super.delete(projectIDs);
//    wasDeleteCalledWithProjectIDs =  true;
//  }

  //String countryId, String stateId, String cityId,
  public PaginatedResult findBySearchCriteria(String projectNumber, String regionId, String countryId, String stateId,
                                             String cityId,
                                             String cropID, String statusID, boolean activeProjects, String sortKey,
                                             String sortDir, int startIndex, int maxResults) {
    findBySearchCriteriaCalled = true;
    Criteria criteria = getHibernateSession().createCriteria(Projects.class);
//    List<Projects> listResult = criteria.list();   // commented out as it causes a NullPointerException
    List<Projects> listResult = new ArrayList<Projects>();
    Projects project = new Projects();
    project.setId(new Long(1));
    System.out.println("ID : " + project.getId());
    project.setProjName("Project" + 1L);
    project.setStartupDate(new Date());
    Location region = new Location();
    Location country = new Location();
    Location state = new Location();
    Location city = new Location();
    region.setId(new Long(1));
    region.setName("North America");
    country.setId(2L);
    country.setName("USA");
    state.setId(3L);
    state.setName("Alabama");
    city.setId(4L);
    city.setName("Abbeville");
    project.setRegion(region);
    project.setCountry(country);
    project.setState(state);
    project.setCity(city);
    ProjectStatus projectStatus = new ProjectStatus();
    projectStatus.setId(new Long(1));
    projectStatus.setName("New");
    project.setProjStatus(projectStatus);
    listResult.add(project);

    project = new Projects();
    project.setId(new Long(2));
    project.setProjName("Project" + 2L);
    project.setStartupDate(new Date());
    project.setRegion(region);
    project.setCountry(country);
    project.setState(state);
    project.setCity(city);

    projectStatus = new ProjectStatus();
    projectStatus.setId(new Long(2));
    projectStatus.setName("In Progress");
    project.setProjStatus(projectStatus);
    listResult.add(project);
    return new PaginatedResult(10, listResult);
  }


  public boolean wasFindAllCalled() {
    return wasFindAllCalled;
  }

  public boolean wasFindByPrimaryKeyCalled() {
    return wasFindByPrimaryKeyCalled;
  }

  public boolean wasSaveCalled() {
    return wasSaveCalled;
  }

  public boolean wasDeleteCalled() {
    return wasDeleteCalled;
  }

  public boolean wasfindBySearchCriteriaCalled() {
    return findBySearchCriteriaCalled;
  }

  public boolean wasFindByProjectStatusActiveCalled() {
    return findByProjectStatusActiveCalled;
  }

  public boolean wasArchiveProjectsCalled() {
    return wasArchiveProjectsCalled;
  }

  public boolean wasGetArchivedProjectsCalled() {
    return getArchivedProjectsCalled;
  }

  public MockCriteriaForEIS getMockCriteria(){
    return criteria;
  }
}
