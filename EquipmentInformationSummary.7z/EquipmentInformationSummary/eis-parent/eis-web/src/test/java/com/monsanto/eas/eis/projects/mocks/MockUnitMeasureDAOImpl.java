package com.monsanto.eas.eis.projects.mocks;

import com.monsanto.eas.eis.projects.domain.UnitMeasure;
import com.monsanto.wst.hibernate.mock.MockDAO;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Aug 6, 2008
 * Time: 12:39:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockUnitMeasureDAOImpl extends MockDAO<UnitMeasure, Long> {
  private Session session;


  private boolean wasFindAllCalled;
  private boolean wasFindByPrimaryKeyCalled;
  private boolean wasFindAllForSortCalled;


  public MockUnitMeasureDAOImpl(Session session) {
      this.session = session;
    }


   protected Session getHibernateSession() {
     return session;
   }

  public UnitMeasure findByPrimaryKey(Long Id) {
    wasFindByPrimaryKeyCalled = true;
   UnitMeasure um = (UnitMeasure) getHibernateSession().load(UnitMeasure.class, Id);
    um = new UnitMeasure(null, "name");
    um.setId(1L);
    return um;
  }

  public List<UnitMeasure> findAll() {
    wasFindAllCalled = true;
    List<UnitMeasure> list = getHibernateSession().createCriteria(UnitMeasure.class).list();
    list = new ArrayList<UnitMeasure>(1);
    list.add(new UnitMeasure(null, "name"));
    return list;
  }


  public List<UnitMeasure> findAll(String property, boolean isAscending) {
    wasFindAllForSortCalled = true;
    List<UnitMeasure> list = getHibernateSession().createCriteria(UnitMeasure.class).list();
    list = new ArrayList<UnitMeasure>(1);
    list.add(new UnitMeasure(null, "name"));
    return list;
  }



  public boolean wasFindAllCalled() {
    return wasFindAllCalled;
  }

  public boolean wasFindByPrimaryKeyCalled() {
    return wasFindByPrimaryKeyCalled;
  }

  public boolean wasFindAllForSortCalled() {
    return wasFindAllForSortCalled;
  }

}
