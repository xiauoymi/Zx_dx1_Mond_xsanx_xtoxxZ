/*
 ProjectServiceImpl_AT was created on Feb 20, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.services;

import com.monsanto.eas.eis.equipment.controller.EISTestCase;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.Projects_AT_TestCaseHelper;
import com.monsanto.eas.eis.projects.domain.Equipment;
import com.monsanto.eas.eis.projects.domain.ProjectStatus;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.hibernate.HibernateFactory;

/**
 * Filename:    $RCSfile: ProjectServiceImpl_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-02-20 18:30:48 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class ProjectServiceImpl_AT extends EISTestCase {
   public void testGetListOfEquipmentsForAProject_ProjectWithListOfEquipmentsReturned() throws Exception {
     HibernateFactory hibernateFactory = EISHibernateUtil.getHibernateFactory();
     Equipment equipment = Projects_AT_TestCaseHelper.setupProjectAndEquipmentAndAssociations();
     ProjectsService service = new ProjectsServiceImpl();
     hibernateFactory.beginTransaction();
     Projects projects = equipment.getProjects();
     projects.setProjStatus(new ProjectStatus(new Long(2), "Detailed Design"));
     hibernateFactory.commitTransaction();
     hibernateFactory.beginTransaction();
     Projects project = service.lookupProjectByIdForAlert(equipment.getProjects().getId());
     assertNotNull(project);
     assertEquals("Detailed Design", project.getProjStatus().getName());
     assertEquals(1, project.getEquipments().size());
  }
}