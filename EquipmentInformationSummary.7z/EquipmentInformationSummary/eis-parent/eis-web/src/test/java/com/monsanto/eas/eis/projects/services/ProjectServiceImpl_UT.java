package com.monsanto.eas.eis.projects.services;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.projects.EISDAOFactory;
import com.monsanto.eas.eis.projects.ProjectsService;
import com.monsanto.eas.eis.projects.dao.*;
import com.monsanto.eas.eis.projects.domain.*;
import com.monsanto.eas.eis.projects.mocks.*;
import com.monsanto.eas.eis.alert.domain.AlertForProjectRoleAndStatus;
import com.monsanto.eas.eis.alert.mock.MockProjectsDAOImplForProjectStatusAndRoleAlert;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateFactoryForReports;
import com.monsanto.eas.eis.audit.dao.mock.MockHibernateSessionForReports;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.dao.GenericDAO;
import org.apache.xpath.XPathAPI;
import org.custommonkey.xmlunit.XMLTestCase;
import org.hibernate.Criteria;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: afhyat Date: Sep 9, 2008 Time: 2:08:18 PM To change this template use File | Settings
 * | File Templates.
 */
public class ProjectServiceImpl_UT extends XMLTestCase {

  EISDAOFactory mockEISDAOFactory;
  ProjectsService projectService;
  private MockProjectsDAOImpl mockProjectsDAO;
  private MockProjectStatusDAOImpl mockProjectStatusDAO;
  private MockCropDAOImpl mockCropDAO;
  private MockUnitMeasureDAOImpl mockUnitMeasureDAO;
  private MockLocationDAOImpl mockLocationDAO;

  protected void setUp() throws Exception {
    super.setUp();
    MockHibernateSession session = new MockHibernateSession();
    mockEISDAOFactory = new MockEISDAOFactory(session);
    projectService = new ProjectsServiceImpl(mockEISDAOFactory);
    mockProjectsDAO = (MockProjectsDAOImpl) mockEISDAOFactory.getProjectsDAOImpl();
    mockProjectStatusDAO = (MockProjectStatusDAOImpl) mockEISDAOFactory.getProjectStatusDAOImpl();
    mockCropDAO = (MockCropDAOImpl) mockEISDAOFactory.getCropDAOImpl();
    mockUnitMeasureDAO = (MockUnitMeasureDAOImpl) mockEISDAOFactory.getUnitMeasureDAOImpl();
    mockLocationDAO = (MockLocationDAOImpl) mockEISDAOFactory.getLocationDAOImpl();
  }

  public void testDeleteProject_WasDeleteCalled() throws Exception {
    projectService.deleteProject(new Long(12));
    assertTrue(mockProjectsDAO.wasDeleteCalled());
  }

  public void testArchiveProjects_WasArchiveCalled() throws Exception {
    String[] projectIDs = {"771", "772"};
    projectService.archiveProjects(projectIDs);
    assertTrue(mockProjectsDAO.wasArchiveProjectsCalled());
  }

  public void testGetLocationsAsXML() throws Exception {
    Document doc = projectService.getLocationsAsXML(1L);
    DOMUtil.outputXML(doc);
    NodeList list = XPathAPI.selectNodeList(doc, "/options/option/id");
    NodeList descriptionList = XPathAPI.selectNodeList(doc, "/options/option/description");
    String valueOfFirstIdNode = DOMUtil.getTextValue(list.item(1));
    String valueOfFirstDescriptionNode = DOMUtil.getTextValue(descriptionList.item(1));
    String valueOfSecondIdNode = DOMUtil.getTextValue(list.item(2));
    String valueOfSecondtDescriptionNode = DOMUtil.getTextValue(descriptionList.item(2));
    assertNotNull(doc);
    assertEquals("2", valueOfFirstIdNode);
    assertEquals("childLocation_one", valueOfFirstDescriptionNode);
    assertEquals("3", valueOfSecondIdNode);
    assertEquals("childLocation_two", valueOfSecondtDescriptionNode);

    assertNotNull(doc);
  }

  public void testLookupChildLocations_VerifyCorrectMethodWasCalled() throws Exception {
    List<Location> locationList = projectService.lookupChildLocations(1L);
    assertEquals(2, locationList.size());
  }

  public void testLookupProjectById() throws Exception {
    Projects project = projectService.lookupProjectById(new Long("1"));
    assertEquals(new Long(234), project.getId());
    MockCriteriaForEIS criteria = mockProjectsDAO.getMockCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("id=1", criteria.getCriteria().get(0).toString());
    List<String> fetchModes = criteria.getFetchModes();
    assertEquals(1, fetchModes.size());
    assertEquals("userRoles-JOIN", fetchModes.get(0));
//    assertEquals("equipments-JOIN", fetchModes.get(1));
  }

  public void testDoesProjectHasEquipments_ReturnsTrue() throws Exception {
    MockProjectServiceOverridesGetEquipmentDaoCriteria service = new MockProjectServiceOverridesGetEquipmentDaoCriteria(
        8, null);
    boolean bool = service.doesProjectHaveEquipments(new Long("1"));
    MockCriteriaForEIS criteria = service.getEquipmentCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("projects.id=1", criteria.getCriteria().get(0).toString());
    assertTrue(bool);
  }

  public void testDoesProjectHasEquipments_ReturnsFalse() throws Exception {
    ProjectsService service = new MockProjectServiceOverridesGetEquipmentDaoCriteria(0, null);
    boolean bool = service.doesProjectHaveEquipments(new Long("1"));
    assertFalse(bool);
  }

  public void testDoesProjectExist_WithProjectId_ReturnsFalse() throws Exception {
    boolean doesProjectExist = projectService.doesProjectExist("12", "121212");
    assertFalse(doesProjectExist);
    MockCriteriaForEIS criteria = mockProjectsDAO.getMockCriteria();
    assertEquals(3, criteria.getCriteria().size());
    assertEquals("projNumber=121212", criteria.getCriteria().get(0).toString());
    assertEquals("id<>12", criteria.getCriteria().get(1).toString());
    assertEquals("ps.id<>5", criteria.getCriteria().get(2).toString());
  }

  public void testLookupMasterProjectForThisProject_WithProjectId_VerifyCriteria() throws Exception {
    Projects project = new Projects();
    project.setCrop(new Crop(new Long(22), null, null));
    Projects masterProject = new Projects();
    masterProject.setId(new Long(1111));
    MockProjectServiceOverridesGetEquipmentDaoCriteria service = new MockProjectServiceOverridesGetEquipmentDaoCriteria(0, masterProject);
    Projects masterProjectForThisProject = service.lookupMasterProjectForThisProject(project);
    assertEquals(new Long(1111), masterProjectForThisProject.getId());
    MockCriteriaForEIS criteria = service.getProjectCriteria();
    assertEquals(2, criteria.getCriteria().size());
    assertEquals("crop.id=22", criteria.getCriteria().get(0).toString());
    assertEquals("isMaster=true", criteria.getCriteria().get(1).toString());
  }

  public void testDoesProjectExist_WithProjectId_ReturnsTrue() throws Exception {
    projectService = new MockProjectServiceImplOverridesGetProjectCriteria(mockEISDAOFactory);
    boolean doesProjectExist = projectService.doesProjectExist("12", "121212");
    assertTrue(doesProjectExist);
  }

  public void testDoesProjectExist_WithoutProjectId_ReturnsFalse() throws Exception {
    boolean doesProjectExist = projectService.doesProjectExist("", "121212");
    assertFalse(doesProjectExist);
    MockCriteriaForEIS criteria = mockProjectsDAO.getMockCriteria();
    assertEquals(2, criteria.getCriteria().size());
    assertEquals("projNumber=121212", criteria.getCriteria().get(0).toString());
    assertEquals("ps.id<>5", criteria.getCriteria().get(1).toString());
  }

   public void testLookupProjectByIdForAlert() throws Exception {
    Projects project = projectService.lookupProjectByIdForAlert(new Long("1"));
    assertEquals(new Long(234), project.getId());
    MockCriteriaForEIS criteria = mockProjectsDAO.getMockCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("id=1", criteria.getCriteria().get(0).toString());
    List<String> fetchModes = criteria.getFetchModes();
    assertEquals(1, fetchModes.size());
    assertEquals("equipments-JOIN", fetchModes.get(0));
  }
 
  public void testGetAllActiveProjectStatus() {
    List<ProjectStatus> list = projectService.getAllActiveProjectStatus();
    assertTrue(mockProjectStatusDAO.wasFindAllActiveStatusCalled());
  }

  public void testGetAllInActiveProjectStatus() {
    List<ProjectStatus> list = projectService.getAllInActiveProjectStatus();
    assertTrue(mockProjectStatusDAO.wasFindAllInActiveStatusCalled());
  }

  public void testListProjectsStatusAsXML_ReturnsActiveProjects() {
    projectService.getProjectStatuses(true);
    assertTrue(mockProjectStatusDAO.wasFindAllInActiveStatusCalled());
  }

  public void testListProjectsStatusAsXML_ReturnsInActiveProjects() {
    projectService.getProjectStatuses(false);
    assertTrue(mockProjectStatusDAO.wasFindAllActiveStatusCalled());

  }

  public void testGetCrop_ReturnsCrop() {
    Crop crop = projectService.lookupCropById(1L);
    assertTrue(mockCropDAO.wasFindByPrimaryKeyCalled());
    assertNotNull(crop);
  }

  public void testGetLocation_ReturnsLocation() {
    Location location = projectService.lookupLocationById(1L);
    assertTrue(mockLocationDAO.wasFindByPrimaryKeyCalled());
    assertNotNull(location);
  }

  public void testGetUnitMeasure_ReturnsUnitMeasure() {
    UnitMeasure unitMeasure = projectService.lookupUnitMeasureById(1L);
    assertTrue(mockUnitMeasureDAO.wasFindByPrimaryKeyCalled());
    assertNotNull(unitMeasure);
  }

  public void testGetProjectStatus_ReturnsProjectStatus() {
    ProjectStatus projectStatus = projectService.lookupStatusById(1L);
    assertTrue(mockProjectStatusDAO.wasFindByPrimaryKeyCalled());
    assertNotNull(projectStatus);
  }

  private class MockProjectServiceImplOverridesGetProjectCriteria extends ProjectsServiceImpl {
    public MockProjectServiceImplOverridesGetProjectCriteria(EISDAOFactory eisDAOFactory) {
      super(eisDAOFactory);
    }

    //protected for testing only
    protected Criteria getProjectDaoCriteria() {
      MockCriteria crtieria = new MockCriteria();
      List list = new ArrayList();
      list.add(new Projects());
      list.add(new Projects());
      crtieria.setResults(list);
      return crtieria;
    }
  }

  private class MockProjectServiceOverridesGetEquipmentDaoCriteria extends ProjectsServiceImpl {
    private int totalRecords;
    MockCriteriaForEIS equipmentCriteria;
    MockCriteriaForEIS projectCriteria;
    private Projects masterProject;

    private MockProjectServiceOverridesGetEquipmentDaoCriteria(int totalRecords, Projects masterProject) {
      this.totalRecords = totalRecords;
      this.masterProject = masterProject;
    }

    //protected for testing only
    protected Criteria getProjectDaoCriteria() {
      projectCriteria = new MockCriteriaForEIS(masterProject, null);
      return projectCriteria;
    }

    //protected for testing only
    protected Criteria getEquipmentDaoCriteria() {
      equipmentCriteria = new MockCriteriaForEIS(this.totalRecords, null);
      return equipmentCriteria;
    }

    public MockCriteriaForEIS getEquipmentCriteria() {
      return equipmentCriteria;
    }

    public MockCriteriaForEIS getProjectCriteria() {
      return projectCriteria;
    }
  }

  private class MockProjectDAO extends ProjectsDAOImpl {
    public MockProjectDAO(MockHibernateFactoryForReports mockHibernateFactoryForReports) {
    }

    public List<AlertForProjectRoleAndStatus> lookupAllStatusAndRoleChangesInAllProjectsForAUser(
        List<ProjectUserRole> projectUserRoles, String sortKey, String sortDir) {
      return super.lookupAllStatusAndRoleChangesInAllProjectsForAUser(projectUserRoles, sortKey, sortDir);
    }
  }

  private class MockEISDAOFactoryForReports implements EISDAOFactory {
    private MockHibernateSessionForReports session;

    public MockEISDAOFactoryForReports(
        MockHibernateSessionForReports session) {
      this.session = session;
    }

    public HibernateFactory getHibernateFactory() {
      return null;
    }

    public ProjectsDAOImpl getProjectsDAOImpl() {
      return new MockProjectsDAOImplForProjectStatusAndRoleAlert(
          session
          , true);

    }

    public ProjectStatusDAOImpl getProjectStatusDAOImpl() {
      return null;
    }

    public GenericDAO<UnitMeasure, Long> getUnitMeasureDAOImpl() {
      return null;
    }

    public LocationDAOImpl getLocationDAOImpl() {
      return null;
    }

    public GenericDAO<Crop, Long> getCropDAOImpl() {
      return null;
    }

    public GenericDAO<Area, Long> getAreaDAOImpl() {
      return null;
    }

    public GenericDAO<EquipmentType, Long> getEquipmentTypeDAOImpl() {
      return null;
    }

    public EquipmentDAO getEquipmentDAOImpl() {
      return null;
    }
  }
}
