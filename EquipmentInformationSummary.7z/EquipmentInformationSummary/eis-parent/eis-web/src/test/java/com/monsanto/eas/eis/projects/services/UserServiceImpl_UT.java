/*
 UserServiceImpl_UT was created on Jan 5, 2009 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.services;

import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.logon.hibernateMappings.Role;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.logon.hibernateMappings.UserRole;
import com.monsanto.eas.eis.logon.hibernateMappings.UserRoleId;
import com.monsanto.eas.eis.projects.domain.AccessType;
import com.monsanto.eas.eis.projects.domain.ProjectRole;
import com.monsanto.eas.eis.projects.domain.ProjectUserRole;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.services.mock.MockUserDAO;
import com.monsanto.eas.eis.projects.services.mock.MockUserRoleDao;
import com.monsanto.eas.eis.util.EISHibernateUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.hibernate.HibernateDAO;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: UserServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2009-02-16 15:01:58 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class UserServiceImpl_UT extends TestCase {

  public void testDoesUserHaveEditAccessToThisProject_UserNotNull_ReturnTrue() throws Exception {
    MockUserDAO<User, Long> userDao = new MockUserDAO<User, Long>(null, User.class, getProjectUser(
        new Long(234)));
    UserService service = new UserServiceImpl(userDao, null);
    Projects project = new Projects();
    project.setId(new Long(234));
    assertTrue(service.doesUserHaveEditAccessToThisProject("testId", project));
  }

  public void testDoesUserHaveEditAccessToThisProject_UserNotNull_ReturnFalse() throws Exception {
    MockUserDAO<User, Long> userDao = new MockUserDAO<User, Long>(null, User.class, getProjectUser(
        new Long(456)));
    UserService service = new UserServiceImpl(userDao, null);
    Projects project = new Projects();
    project.setId(new Long(234));
    assertFalse(service.doesUserHaveEditAccessToThisProject("testId", project));
  }

  public void testDoesUserHaveEditAccessToThisProject_UserIsNull_ReturnFalse() throws Exception {
    MockUserDAO<User, Long> userDao = new MockUserDAO<User, Long>(null, User.class, null);
    UserService service = new UserServiceImpl(userDao, null);
    Projects project = new Projects();
    project.setId(new Long(234));
    assertFalse(service.doesUserHaveEditAccessToThisProject("testId", project));
  }

  public void testIsUserInProcessRoleForThisProject_UserNotNull_ReturnTrue() throws Exception {
    MockUserDAO<User, Long> userDao = new MockUserDAO<User, Long>(null, User.class, getProjectUser(
        new Long(234)));
    UserService service = new UserServiceImpl(userDao, null);
    Projects project = new Projects();
    project.setId(new Long(234));
    assertTrue(service.isUserInProcessRoleForThisProject("testId", project));
  }

  public void testIsUserInProcessRoleForThisProject_UserIsNull_ReturFalse() throws Exception {
    MockUserDAO<User, Long> userDao = new MockUserDAO<User, Long>(null, User.class, null);
    UserService service = new UserServiceImpl(userDao, null);
    Projects project = new Projects();
    project.setId(new Long(234));
    assertFalse(service.isUserInProcessRoleForThisProject("testId", project));
  }

  public void testIsUserInMechanicalEngineerRoleForThisProject_UserNotNull_ReturnTrue() throws Exception {
    MockUserDAO<User, Long> userDao = new MockUserDAO<User, Long>(null, User.class, getProjectUser(
        new Long(234)));
    UserService service = new UserServiceImpl(userDao, null);
    Projects project = new Projects();
    project.setId(new Long(234));
    assertTrue(service.isUserInMechanicalEngineerRoleForThisProject("testId", project));
  }

  public void testIsUserInMechanicalEngineerRoleForThisProject_UserIsNull_ReturFalse() throws Exception {
    MockUserDAO<User, Long> userDao = new MockUserDAO<User, Long>(null, User.class, null);
    UserService service = new UserServiceImpl(userDao, null);
    Projects project = new Projects();
    project.setId(new Long(234));
    assertFalse(service.isUserInMechanicalEngineerRoleForThisProject("testId", project));
  }

  public void testLookupAllUsersWithProjectUserRole_VerifyCriteria() throws Exception {
    List<Object> userRoles = new ArrayList<Object>();
    UserRoleId id1 = new UserRoleId(new User(new Long(12), "testId1", null, null, null, null),
        new Role(new Long(121), "role 1"));
    UserRoleId id2 = new UserRoleId(new User(new Long(13), "testId2", null, null, null, null),
        new Role(new Long(131), "role 2"));
    userRoles.add(new UserRole(id1));
    userRoles.add(new UserRole(id2));
    MockUserRoleDao<UserRole, Long> userRoleDao = new MockUserRoleDao<UserRole, Long>(null, UserRole.class, userRoles);
    UserService service = new UserServiceImpl(null, userRoleDao);
    List<User> users = service.lookupAllUsersWithProjectUserRole();
    MockCriteriaForEIS criteria = (MockCriteriaForEIS) userRoleDao.getCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("r.roleName=eis_proj_user", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getOrderings().size());
    assertEquals("u.lastName asc", criteria.getOrderings().get(0).toString());
    assertEquals(2, users.size());
    assertEquals(new Long(12), users.get(0).getId());
    assertEquals("testId1", users.get(0).getUserId());
    assertEquals(new Long(13), users.get(1).getId());
    assertEquals("testId2", users.get(1).getUserId());
  }

  public void testLookupUserById_VerifyCriteria() throws Exception {
    MockUserDAO<User, Long> userDao = new MockUserDAO<User, Long>(null, User.class, getProjectUser(
        new Long(234)));
    UserService service = new UserServiceImpl(userDao, null);
    User user = service.lookupUserByLogonId("testId");
    MockCriteriaForEIS criteria = userDao.getCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("userId=testId", criteria.getCriteria().get(0).toString());
    assertEquals(1, criteria.getFetchModes().size());
    assertEquals("projUserRoles-JOIN", criteria.getFetchModes().get(0));
    assertEquals(new Long(123), user.getId());
    assertEquals("testId", user.getUserId());
    assertEquals("testFirst", user.getFirstName());
    assertEquals("testLast", user.getLastName());
  }

  private User getProjectUser(Long projectId) {
    List<ProjectUserRole> projUserRoles = new ArrayList<ProjectUserRole>();
    Projects project = new Projects();
    project.setId(projectId);
    ProjectRole projRole = new ProjectRole(null, "Non process eng", new AccessType(null, "view"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    projRole = new ProjectRole();
    projRole = new ProjectRole(null, "Process Engineer", new AccessType(null, "edit"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    projRole = new ProjectRole(null, "Mechanical Engineer", new AccessType(null, "edit"));
    projUserRoles.add(new ProjectUserRole(project, null, projRole, false));
    return new User(new Long(123), "testId", "testFirst", "testLast", null, projUserRoles);
  }

//  public void testLookupUserByFirstName() throws Exception {
//    HibernateFactory hibernateFactory = EISHibernateUtil.getHibernateFactory();
//    //hibernateFactory.beginTransaction();
//    UserService service = new UserServiceImpl();
//    service.lookupUsersByName("scott");
//    hibernateFactory.commitTransaction();
//
//  }

}