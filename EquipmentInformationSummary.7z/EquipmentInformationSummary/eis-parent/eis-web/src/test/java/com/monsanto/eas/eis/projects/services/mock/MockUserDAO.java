/*
 MockUserDAO was created on Jan 5, 2009 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.services.mock;

import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import org.hibernate.Criteria;

/**
 * Filename:    $RCSfile: MockUserDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-11 15:18:53 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class MockUserDAO<T, T1> extends HibernateDAO<User, Long> {
  User user;
  MockCriteriaForEIS criteria;

  public MockUserDAO(HibernateFactory hibernateFactory, Class<? extends User> aClass, User user) {
    super(hibernateFactory, aClass);
    this.user = user;
  }

  public Criteria createCriteria() {
    criteria = new MockCriteriaForEIS(user, null);
    return criteria;
  }

  public MockCriteriaForEIS getCriteria() {
    return criteria;
  }
}