/*
 MockUserRoleDao was created on Feb 10, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.services.mock;

import com.monsanto.eas.eis.logon.hibernateMappings.UserRole;
import com.monsanto.eas.eis.equipment.datasource.mock.MockCriteriaForEIS;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import org.hibernate.Criteria;
import java.util.List;

/**
 * Filename:    $RCSfile: MockUserRoleDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-11 15:18:53 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class MockUserRoleDao<T, T1> extends HibernateDAO<UserRole, Long> {
  List<Object> userRoles;
  MockCriteriaForEIS criteria;

  public MockUserRoleDao(HibernateFactory hibernateFactory, Class<? extends UserRole> aClass, List<Object> userRoles) {
    super(hibernateFactory, aClass);
    this.userRoles = userRoles;
  }

  public Criteria createCriteria() {
    criteria = new MockCriteriaForEIS(null, userRoles);
    return criteria;
  }

  public MockCriteriaForEIS getCriteria() {
    return criteria;
  }
}