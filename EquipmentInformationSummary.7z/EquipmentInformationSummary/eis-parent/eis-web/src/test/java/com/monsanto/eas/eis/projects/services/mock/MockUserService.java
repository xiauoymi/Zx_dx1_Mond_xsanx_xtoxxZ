/*
 MockUserService was created on Jan 5, 2009 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.projects.services.mock;

import com.monsanto.eas.eis.projects.services.UserService;
import com.monsanto.eas.eis.projects.domain.Projects;
import com.monsanto.eas.eis.projects.domain.PaginatedResult;
import com.monsanto.eas.eis.logon.hibernateMappings.User;

import java.util.List;

/**
 * Filename:    $RCSfile: MockUserService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-16 15:01:58 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class MockUserService implements UserService {
  private boolean userHasAccessToThisProject;
  private boolean userInProcessRoleForThisProject;
  private boolean userInMechanicalEngineerRoleForThisProject;
  private List<User> usersWithProjectUserRole;
  private User user;

  public MockUserService(boolean userHasAccessToThisProject, boolean isUserInProcessRoleForThisProject,
                         boolean userInMechanicalEngineerRoleForThisProject, List<User> usersWithProjectUserRole,
                         User user) {
    this.userHasAccessToThisProject = userHasAccessToThisProject;
    userInProcessRoleForThisProject = isUserInProcessRoleForThisProject;
    this.userInMechanicalEngineerRoleForThisProject = userInMechanicalEngineerRoleForThisProject;
    this.usersWithProjectUserRole = usersWithProjectUserRole;
    this.user = user;
  }

  public boolean doesUserHaveEditAccessToThisProject(String userId, Projects project) {
    return userHasAccessToThisProject;
  }

  public boolean isUserInProcessRoleForThisProject(String userId, Projects project) {
    return userInProcessRoleForThisProject;
  }

  public boolean isUserInMechanicalEngineerRoleForThisProject(String userId, Projects project) {
    return userInMechanicalEngineerRoleForThisProject;
  }

  public List<User> lookupAllUsersWithProjectUserRole() {
    return this.usersWithProjectUserRole;
  }

  public User lookupUserByLogonId(String userId) {
    return user;
  }

  public PaginatedResult lookupUsersByName(String userName) {
    return null;
  }
}