/*
 SessionTimeoutFilter_UT was created on Feb 17, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.servlet;

import com.monsanto.ServletFramework.Test.MockHttpServletRequest;
import com.monsanto.ServletFramework.Test.MockHttpServletResponse;
import com.monsanto.ServletFramework.Test.MockHttpSession;
import com.monsanto.eas.eis.logon.hibernateMappings.User;
import com.monsanto.eas.eis.util.EISConstants;
import junit.framework.TestCase;

import javax.servlet.*;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Filename:    $RCSfile: SessionTimeoutFilter_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-17 19:30:32 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class SessionTimeoutFilter_UT extends TestCase {

  public void testDoFilter_UserInSessionIsNull_ForwardedToLogon() throws Exception {
    SessionTimeoutFilter filter = new SessionTimeoutFilter();
    MockFilterChain filterChain = new MockFilterChain();
    MockHttpServletRequestForEIS request = new MockHttpServletRequestForEIS(new MockHttpSession());
    filter.doFilter(request, new MockHttpServletResponse(), filterChain);
    SessionTimeoutFilter_UT.MockHttpServletRequestForEIS.MockRequestDispatcher requestDispatcher = request
        .getMockRequestDispatcher();
    assertEquals("/servlet/logon", requestDispatcher.getPath());
    assertTrue(requestDispatcher.wasForwarded);
  }

  public void testDoFilter_UserInSessionIsNotNull_DoFilterOnFilterChain() throws Exception {
    SessionTimeoutFilter filter = new SessionTimeoutFilter();
    MockFilterChain filterChain = new MockFilterChain();
    MockHttpSession session = new MockHttpSession();
    session.setAttribute(EISConstants.LOGIN_USER, new User());
    MockHttpServletRequestForEIS request = new MockHttpServletRequestForEIS(session);
    filter.doFilter(request, new MockHttpServletResponse(), filterChain);
    SessionTimeoutFilter_UT.MockHttpServletRequestForEIS.MockRequestDispatcher requestDispatcher = request
        .getMockRequestDispatcher();
    assertNull(requestDispatcher);
    assertTrue(filterChain.doFilterWasCalled);
  }

  private class MockFilterChain implements FilterChain {
    private boolean doFilterWasCalled;

    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse) throws IOException,
        ServletException {
      this.doFilterWasCalled = true;
    }

    public boolean isDoFilterWasCalled() {
      return doFilterWasCalled;
    }
  }

  private class MockHttpServletRequestForEIS extends MockHttpServletRequest {
    private MockRequestDispatcher mockRequestDispatcher;

    public MockHttpServletRequestForEIS(HttpSession httpSession) {
      super(httpSession);
    }

    public RequestDispatcher getRequestDispatcher(String path) {
      this.mockRequestDispatcher = new MockRequestDispatcher(path);
      return mockRequestDispatcher;
    }

    public MockRequestDispatcher getMockRequestDispatcher() {
      return mockRequestDispatcher;
    }

    private class MockRequestDispatcher implements RequestDispatcher {
      private boolean wasForwarded;
      private String path;

      public MockRequestDispatcher(String path) {
        this.path = path;
      }

      public void forward(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        this.wasForwarded = true;
      }

      public void include(ServletRequest request, ServletResponse response) throws ServletException, IOException {
      }

      public boolean isWasForwarded() {
        return wasForwarded;
      }

      public String getPath() {
        return path;
      }

    }
  }
}