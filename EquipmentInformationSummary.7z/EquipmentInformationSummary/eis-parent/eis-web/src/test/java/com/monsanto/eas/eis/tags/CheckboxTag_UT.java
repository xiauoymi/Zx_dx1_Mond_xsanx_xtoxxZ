/*
 CheckboxTag_UT was created on Dec 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.tags;

import com.monsanto.eas.eis.tags.mock.MockJspContext;
import com.monsanto.eas.eis.tags.mock.MockJspWriter;
import org.custommonkey.xmlunit.XMLTestCase;

/**
 * Filename:    $RCSfile: CheckboxTag_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-01-07 14:20:53 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class CheckboxTag_UT extends XMLTestCase {

  public void testDoTag_IsEditableOnlyRequiredFields_VerifyOutput() throws Exception {
    CheckboxTag tag = new CheckboxTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(true);
    tag.setId("testId");
    tag.setName("testName");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("1", "count(//wellFormedXML/input)", result);

    assertXpathEvaluatesTo("checkbox", "//wellFormedXML/input[1]/@type", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/input[1]/@name", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/input/@id", result);

    assertXpathEvaluatesTo("0", "count(//wellFormedXML/input/@class)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/input/@checked)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/input/@disabled)", result);
  }

  public void testDoTag_IsEditableWithAllFields_VerifyOutput() throws Exception {
    CheckboxTag tag = new CheckboxTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setId("testId");
    tag.setName("testName");
    tag.setClassName("testClassName");
    tag.setChecked(true);
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("1", "count(//wellFormedXML/input)", result);

    assertXpathEvaluatesTo("checkbox", "//wellFormedXML/input[1]/@type", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/input[1]/@name", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/input/@id", result);

    assertXpathEvaluatesTo("testClassName", "//wellFormedXML/input/@class", result);
    assertXpathEvaluatesTo("checked", "//wellFormedXML/input/@checked", result);
    assertXpathEvaluatesTo("disabled", "//wellFormedXML/input/@disabled", result);
  }

  public void testDoTag_IsNotEditableOnlyRequiredFields_VerifyOutput() throws Exception {
    CheckboxTag tag = new CheckboxTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setId("testId");
    tag.setName("testName");
    tag.setChecked(false);
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("1", "count(//wellFormedXML/input)", result);

    assertXpathEvaluatesTo("checkbox", "//wellFormedXML/input[1]/@type", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/input[1]/@name", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/input/@id", result);

    assertXpathEvaluatesTo("0", "count(//wellFormedXML/input/@class)", result);
    assertXpathEvaluatesTo("disabled", "//wellFormedXML/input/@disabled", result);
  }

  public void testDoTag_IsNotEditableWithAllFields_VerifyOutput() throws Exception {
    CheckboxTag tag = new CheckboxTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setId("testId");
    tag.setName("testName");
    tag.setClassName("testClassName");
    tag.setChecked(true);
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("1", "count(//wellFormedXML/input)", result);

    assertXpathEvaluatesTo("checkbox", "//wellFormedXML/input[1]/@type", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/input[1]/@name", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/input/@id", result);

    assertXpathEvaluatesTo("testClassName", "//wellFormedXML/input/@class", result);
    assertXpathEvaluatesTo("checked", "//wellFormedXML/input/@checked", result);
    assertXpathEvaluatesTo("disabled", "//wellFormedXML/input/@disabled", result);
  }

  public void testDoTag_IsNotEditableIsReadonlyAndChecked_VerifyOutput() throws Exception {
    CheckboxTag tag = new CheckboxTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setReadonly(true);
    tag.setChecked(true);
    tag.setId("testId");
    tag.setName("testName");
    tag.setClassName("testClassName");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/input)", result);

    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("1", "count(//wellFormedXML/span)", result);

    assertXpathEvaluatesTo("", "//wellFormedXML/span[1]", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/span[1]/@id", result);
  }
}
