/*
 RadioButtonTag_UT was created on Dec 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.tags;

import com.monsanto.eas.eis.tags.mock.MockJspContext;
import com.monsanto.eas.eis.tags.mock.MockJspWriter;
import org.custommonkey.xmlunit.XMLTestCase;

/**
 * Filename:    $RCSfile: RadioButtonTag_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-01-07 14:20:53 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class RadioButtonTag_UT extends XMLTestCase {

  public void testDoTag_IsEditableOnlyRequiredFields_VerifyOutput() throws Exception {
    RadioButtonTag tag = new RadioButtonTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(true);
    tag.setLabels(" Yes, No ");
    tag.setValues(" Y , N ");
    tag.setId("testId");
    tag.setName("testName");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("2", "count(//wellFormedXML/label)", result);

    assertXpathEvaluatesTo("1", "count(//wellFormedXML/label[1]/input)", result);
    assertXpathEvaluatesTo("Yes", "//wellFormedXML/label[1]/em", result);
    assertXpathEvaluatesTo("radio", "//wellFormedXML/label[1]/input[1]/@type", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/label[1]/input[1]/@name", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[1]/input[1]/@checked)", result);
    assertXpathEvaluatesTo("Y", "//wellFormedXML/label[1]/input[1]/@value", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/label[1]/input/@id", result);

    assertXpathEvaluatesTo("1", "count(//wellFormedXML/label[2]/input)", result);
    assertXpathEvaluatesTo("No", "//wellFormedXML/label[2]/em", result);
    assertXpathEvaluatesTo("radio", "//wellFormedXML/label[2]/input[1]/@type", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/label[2]/input[1]/@name", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[2]/input[1]/@checked)", result);
    assertXpathEvaluatesTo("N", "//wellFormedXML/label[2]/input[1]/@value", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/label[2]/input/@id", result);

    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[1]/input/@class)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[1]/input/@checked)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[1]/input/@disabled)", result);
  }

  public void testDoTag_IsEditableWithAllFields_VerifyOutput() throws Exception {
    RadioButtonTag tag = new RadioButtonTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(true);
    tag.setLabels(" Yes, No ");
    tag.setValues(" Y , N ");
    tag.setId("testId");
    tag.setName("testName");
    tag.setClassName("testClassName");
    tag.setValueToBeChecked(" N ");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("2", "count(//wellFormedXML/label)", result);

    assertXpathEvaluatesTo("1", "count(//wellFormedXML/label[1]/input)", result);
    assertXpathEvaluatesTo("Yes", "//wellFormedXML/label[1]/em", result);
    assertXpathEvaluatesTo("radio", "//wellFormedXML/label[1]/input[1]/@type", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/label[1]/input[1]/@name", result);
    assertXpathEvaluatesTo("Y", "//wellFormedXML/label[1]/input[1]/@value", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[1]/input[1]/@checked)", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/label[1]/input/@id", result);
    assertXpathEvaluatesTo("testClassName", "//wellFormedXML/label[1]/input/@class)", result);

    assertXpathEvaluatesTo("1", "count(//wellFormedXML/label[2]/input)", result);
    assertXpathEvaluatesTo("No", "//wellFormedXML/label[2]/em", result);
    assertXpathEvaluatesTo("radio", "//wellFormedXML/label[2]/input[1]/@type", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/label[2]/input[1]/@name", result);
    assertXpathEvaluatesTo("checked", "//wellFormedXML/label[2]/input[1]/@checked", result);
    assertXpathEvaluatesTo("N", "//wellFormedXML/label[2]/input[1]/@value", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/label[2]/input/@id", result);
    assertXpathEvaluatesTo("testClassName", "//wellFormedXML/label[2]/input/@class)", result);

    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[1]/input/@disabled)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[2]/input/@disabled)", result);
  }

  public void testDoTag_IsNotEditableOnlyRequiredFields_VerifyOutput() throws Exception {
    RadioButtonTag tag = new RadioButtonTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setLabels(" Yes, No ");
    tag.setValues(" Y , N ");
    tag.setId("testId");
    tag.setName("testName");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("2", "count(//wellFormedXML/label)", result);

    assertXpathEvaluatesTo("1", "count(//wellFormedXML/label[1]/input)", result);
    assertXpathEvaluatesTo("Yes", "//wellFormedXML/label[1]/em", result);
    assertXpathEvaluatesTo("radio", "//wellFormedXML/label[1]/input[1]/@type", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/label[1]/input[1]/@name", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[1]/input[1]/@checked)", result);
    assertXpathEvaluatesTo("Y", "//wellFormedXML/label[1]/input[1]/@value", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/label[1]/input/@id", result);
    assertXpathEvaluatesTo("disabled", "//wellFormedXML/label[1]/input/@disabled", result);

    assertXpathEvaluatesTo("1", "count(//wellFormedXML/label[2]/input)", result);
    assertXpathEvaluatesTo("No", "//wellFormedXML/label[2]/em", result);
    assertXpathEvaluatesTo("radio", "//wellFormedXML/label[2]/input[1]/@type", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/label[2]/input[1]/@name", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[2]/input[1]/@checked)", result);
    assertXpathEvaluatesTo("N", "//wellFormedXML/label[2]/input[1]/@value", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/label[2]/input/@id", result);
    assertXpathEvaluatesTo("disabled", "//wellFormedXML/label[2]/input/@disabled", result);

    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[1]/input/@class)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[1]/input/@checked)", result);
  }

  public void testDoTag_IsNotEditableWithAllFields_VerifyOutput() throws Exception {
    RadioButtonTag tag = new RadioButtonTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setLabels(" Yes, No ");
    tag.setValues(" Y , N ");
    tag.setId("testId");
    tag.setName("testName");
    tag.setClassName("testClassName");
    tag.setValueToBeChecked(" N ");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("2", "count(//wellFormedXML/label)", result);

    assertXpathEvaluatesTo("1", "count(//wellFormedXML/label[1]/input)", result);
    assertXpathEvaluatesTo("Yes", "//wellFormedXML/label[1]/em", result);
    assertXpathEvaluatesTo("radio", "//wellFormedXML/label[1]/input[1]/@type", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/label[1]/input[1]/@name", result);
    assertXpathEvaluatesTo("Y", "//wellFormedXML/label[1]/input[1]/@value", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label[1]/input[1]/@checked)", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/label[1]/input/@id", result);
    assertXpathEvaluatesTo("testClassName", "//wellFormedXML/label[1]/input/@class)", result);
    assertXpathEvaluatesTo("disabled", "//wellFormedXML/label[1]/input/@disabled", result);

    assertXpathEvaluatesTo("1", "count(//wellFormedXML/label[2]/input)", result);
    assertXpathEvaluatesTo("No", "//wellFormedXML/label[2]/em", result);
    assertXpathEvaluatesTo("radio", "//wellFormedXML/label[2]/input[1]/@type", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/label[2]/input[1]/@name", result);
    assertXpathEvaluatesTo("checked", "//wellFormedXML/label[2]/input[1]/@checked", result);
    assertXpathEvaluatesTo("N", "//wellFormedXML/label[2]/input[1]/@value", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/label[2]/input/@id", result);
    assertXpathEvaluatesTo("testClassName", "//wellFormedXML/label[2]/input/@class)", result);
    assertXpathEvaluatesTo("disabled", "//wellFormedXML/label[2]/input/@disabled", result);
  }

  public void testDoTag_IsNotEditableIsReadonly_VerifyOutput() throws Exception {
    RadioButtonTag tag = new RadioButtonTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setReadonly(true);
    tag.setLabels(" Yes, No ");
    tag.setValues(" Y , N ");
    tag.setId("testId");
    tag.setName("testName");
    tag.setClassName("testClassName");
    tag.setValueToBeChecked(" N ");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label)", result);
    
    assertXpathEvaluatesTo("1", "count(//wellFormedXML/span)", result);
    assertXpathEvaluatesTo("N", "//wellFormedXML/span[1]", result);
  }
  
  public void testDoTag_IsNotEditableIsReadonlyNoValueToBeChecked_VerifyOutput() throws Exception {
    RadioButtonTag tag = new RadioButtonTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setReadonly(true);
    tag.setLabels(" Yes, No ");
    tag.setValues(" Y , N ");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/label)", result);

    assertXpathEvaluatesTo("1", "count(//wellFormedXML/span)", result);
    assertXpathEvaluatesTo("", "//wellFormedXML/span[1]", result);
  }
}