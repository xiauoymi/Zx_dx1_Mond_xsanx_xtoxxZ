/*
 SelectTag_UT was created on Dec 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.tags;

import com.monsanto.eas.eis.tags.mock.MockJspContext;
import com.monsanto.eas.eis.tags.mock.MockJspWriter;
import com.monsanto.eas.eis.projects.domain.EquipmentType;
import org.custommonkey.xmlunit.XMLTestCase;
import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: SelectTag_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-01-07 14:20:53 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class SelectTag_UT extends XMLTestCase {

  public void testDoTag_IsEditableOnlyRequiredFields_VerifyOutput() throws Exception {
    SelectTag tag = new SelectTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(true);
    tag.setId("testId");
    tag.setName("testName");
    List<Object> list = new ArrayList<Object>();
    list.add(new EquipmentType(new Long(12), "type 1", null));
    list.add(new EquipmentType(new Long(13), "type 2", null));
    tag.setIdValueList(list);
    tag.setIdProperty("id");
    tag.setValueProperty("name");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("1", "count(//wellFormedXML/select)", result);

    assertXpathEvaluatesTo("testId", "//wellFormedXML/select/@id", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/select/@name", result);
    assertXpathEvaluatesTo("3", "count(//wellFormedXML/select/option)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/option[1]/@value)", result);
    assertXpathEvaluatesTo("", "//wellFormedXML/select/option[1]/", result);
    assertXpathEvaluatesTo("12", "//wellFormedXML/select/option[2]/@value", result);
    assertXpathEvaluatesTo("type 1", "//wellFormedXML/select/option[2]/", result);
    assertXpathEvaluatesTo("13", "//wellFormedXML/select/option[3]/@value", result);
    assertXpathEvaluatesTo("type 2", "//wellFormedXML/select/option[3]/", result);

    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/@class)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/@onchange)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/@disabled)", result);
  }

  public void testDoTag_IsEditableWithAllFields_VerifyOutput() throws Exception {
    SelectTag tag = new SelectTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(true);
    tag.setId("testId");
    tag.setName("testName");
    List<Object> list = new ArrayList<Object>();
    list.add(new EquipmentType(new Long(12), "type 1", null));
    list.add(new EquipmentType(new Long(13), "type 2", null));
    tag.setIdValueList(list);
    tag.setIdProperty("id");
    tag.setValueProperty("name");
    tag.setIdToBeSelected("13");
    tag.setDefaultOption("Please Select");
    tag.setClassName("testClassName");
    tag.setOnchange("return onchange();");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("1", "count(//wellFormedXML/select)", result);

    assertXpathEvaluatesTo("testId", "//wellFormedXML/select/@id", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/select/@name", result);
    assertXpathEvaluatesTo("3", "count(//wellFormedXML/select/option)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/option[1]/@selected)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/option[1]/@value)", result);
    assertXpathEvaluatesTo("Please Select", "//wellFormedXML/select/option[1]/", result);

    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/option[2]/@selected)", result);
    assertXpathEvaluatesTo("12", "//wellFormedXML/select/option[2]/@value", result);
    assertXpathEvaluatesTo("type 1", "//wellFormedXML/select/option[2]/", result);

    assertXpathEvaluatesTo("selected", "//wellFormedXML/select/option[3]/@selected", result);
    assertXpathEvaluatesTo("13", "//wellFormedXML/select/option[3]/@value", result);
    assertXpathEvaluatesTo("type 2", "//wellFormedXML/select/option[3]/", result);

    assertXpathEvaluatesTo("testClassName", "//wellFormedXML/select/@class", result);
    assertXpathEvaluatesTo("return onchange();", "//wellFormedXML/select/@onchange", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/@disabled)", result);
  }

  public void testDoTag_IsNotEditableOnlyRequiredFields_VerifyOutput() throws Exception {
    SelectTag tag = new SelectTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setId("testId");
    tag.setName("testName");
    List<Object> list = new ArrayList<Object>();
    list.add(new EquipmentType(new Long(12), "type 1", null));
    list.add(new EquipmentType(new Long(13), "type 2", null));
    tag.setIdValueList(list);
    tag.setIdProperty("id");
    tag.setValueProperty("name");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("1", "count(//wellFormedXML/select)", result);

    assertXpathEvaluatesTo("testId", "//wellFormedXML/select/@id", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/select/@name", result);
    assertXpathEvaluatesTo("3", "count(//wellFormedXML/select/option)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/option[1]/@value)", result);
    assertXpathEvaluatesTo("disabled", "//wellFormedXML/select/@disabled", result);
    assertXpathEvaluatesTo("", "//wellFormedXML/select/option[1]/", result);
    assertXpathEvaluatesTo("12", "//wellFormedXML/select/option[2]/@value", result);
    assertXpathEvaluatesTo("type 1", "//wellFormedXML/select/option[2]/", result);
    assertXpathEvaluatesTo("13", "//wellFormedXML/select/option[3]/@value", result);
    assertXpathEvaluatesTo("type 2", "//wellFormedXML/select/option[3]/", result);

    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/@class)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/@onchange)", result);
  }

  public void testDoTag_IsNotEditableWithAllFields_VerifyOutput() throws Exception {
    SelectTag tag = new SelectTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setId("testId");
    tag.setName("testName");
    List<Object> list = new ArrayList<Object>();
    list.add(new EquipmentType(new Long(12), "type 1", null));
    list.add(new EquipmentType(new Long(13), "type 2", null));
    tag.setIdValueList(list);
    tag.setIdProperty("id");
    tag.setValueProperty("name");
    tag.setIdToBeSelected("13");
    tag.setDefaultOption("Please Select");
    tag.setClassName("testClassName");
    tag.setOnchange("return onchange();");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("1", "count(//wellFormedXML/select)", result);

    assertXpathEvaluatesTo("testId", "//wellFormedXML/select/@id", result);
    assertXpathEvaluatesTo("testName", "//wellFormedXML/select/@name", result);
    assertXpathEvaluatesTo("disabled", "//wellFormedXML/select/@disabled", result);
    assertXpathEvaluatesTo("3", "count(//wellFormedXML/select/option)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/option[1]/@selected)", result);
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/option[1]/@value)", result);
    assertXpathEvaluatesTo("Please Select", "//wellFormedXML/select/option[1]/", result);

    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select/option[2]/@selected)", result);
    assertXpathEvaluatesTo("12", "//wellFormedXML/select/option[2]/@value", result);
    assertXpathEvaluatesTo("type 1", "//wellFormedXML/select/option[2]/", result);

    assertXpathEvaluatesTo("selected", "//wellFormedXML/select/option[3]/@selected", result);
    assertXpathEvaluatesTo("13", "//wellFormedXML/select/option[3]/@value", result);
    assertXpathEvaluatesTo("type 2", "//wellFormedXML/select/option[3]/", result);

    assertXpathEvaluatesTo("testClassName", "//wellFormedXML/select/@class", result);
    assertXpathEvaluatesTo("return onchange();", "//wellFormedXML/select/@onchange", result);
  }

  public void testDoTag_IsNotEditableWithReadOnly_VerifyOutput() throws Exception {
    SelectTag tag = new SelectTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setReadonly(true);
    tag.setId("testId");
    tag.setName("testName");
    List<Object> list = new ArrayList<Object>();
    list.add(new EquipmentType(new Long(12), "type 1", null));
    list.add(new EquipmentType(new Long(13), "type 2", null));
    tag.setIdValueList(list);
    tag.setIdProperty("id");
    tag.setValueProperty("name");
    tag.setIdToBeSelected("13");
    tag.setDefaultOption("Please Select");
    tag.setClassName("testClassName");
    tag.setOnchange("return onchange();");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select)", result);

    assertXpathEvaluatesTo("1", "count(//wellFormedXML/span)", result);
    assertXpathEvaluatesTo("type 2", "//wellFormedXML/span[1]", result);
  }

  public void testDoTag_IsNotEditableWithReadOnlyWithNoIdToBeSelected_VerifyOutput() throws Exception {
    SelectTag tag = new SelectTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setReadonly(true);
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("0", "count(//wellFormedXML/select)", result);

    assertXpathEvaluatesTo("1", "count(//wellFormedXML/span)", result);
    assertXpathEvaluatesTo("", "//wellFormedXML/span[1]", result);
  }
}