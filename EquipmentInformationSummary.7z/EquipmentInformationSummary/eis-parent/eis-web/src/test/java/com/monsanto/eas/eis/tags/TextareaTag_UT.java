/*
 TextareaTag_UT was created on Dec 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.tags;

import com.monsanto.eas.eis.tags.mock.MockJspContext;
import com.monsanto.eas.eis.tags.mock.MockJspWriter;
import org.custommonkey.xmlunit.XMLTestCase;

/**
 * Filename:    $RCSfile: TextareaTag_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-01-07 14:20:53 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class TextareaTag_UT extends XMLTestCase {
  public void testDoTag_IsEditableOnlyRequiredFields_VerifyOutput() throws Exception {
    TextareaTag tag = new TextareaTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(true);
    tag.setId("testId");
    tag.setName("testName");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    assertXpathEvaluatesTo("1", "count(//textarea)", result);
    assertXpathEvaluatesTo("testName", "//textarea[1]/@name", result);
    assertXpathEvaluatesTo("testId", "//textarea/@id", result);
    assertXpathEvaluatesTo("", "//textarea/", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@class)", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@cols)", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@rows)", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@maxLength)", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@onkeypress)", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@onpaste)", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@disabled)", result);
  }

  public void testDoTag_IsEditableWithAllFields_VerifyOutput() throws Exception {
    TextareaTag tag = new TextareaTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(true);
    tag.setId("testId");
    tag.setName("testName");
    tag.setValue("testValue");
    tag.setClassName("testClassName");
    tag.setMaxlength("5");
    tag.setCols("50");
    tag.setRows("4");
    tag.setOnkeypress("return onkeyClick();");
    tag.setOnpaste("return onpasteClick();");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    assertXpathEvaluatesTo("1", "count(//textarea)", result);

    assertXpathEvaluatesTo("testName", "//textarea[1]/@name", result);
    assertXpathEvaluatesTo("testId", "//textarea/@id", result);
    assertXpathEvaluatesTo("testClassName", "//textarea/@class", result);
    assertXpathEvaluatesTo("testValue", "//textarea/", result);
    assertXpathEvaluatesTo("50", "//textarea/@cols", result);
    assertXpathEvaluatesTo("4", "//textarea/@rows", result);
    assertXpathEvaluatesTo("5", "//textarea/@maxLength", result);
    assertXpathEvaluatesTo("return onkeyClick();", "//textarea/@onkeypress", result);
    assertXpathEvaluatesTo("return onpasteClick();", "//textarea/@onpaste", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@disabled)", result);
  }

  public void testDoTag_IsNotEditableOnlyRequiredFields_VerifyOutput() throws Exception {
    TextareaTag tag = new TextareaTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setId("testId");
    tag.setName("testName");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    assertXpathEvaluatesTo("1", "count(//textarea)", result);
    assertXpathEvaluatesTo("testName", "//textarea[1]/@name", result);
    assertXpathEvaluatesTo("testId", "//textarea/@id", result);
    assertXpathEvaluatesTo("", "//textarea/", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@class)", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@cols)", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@rows)", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@maxLength)", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@onkeypress)", result);
    assertXpathEvaluatesTo("0", "count(//textarea/@onpaste)", result);
    assertXpathEvaluatesTo("disabled", "//textarea/@disabled", result);
  }

  public void testDoTag_IsNotEditableWithAllFields_VerifyOutput() throws Exception {
    TextareaTag tag = new TextareaTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setId("testId");
    tag.setName("testName");
    tag.setClassName("testClassName");
    tag.setValue("testValue");
    tag.setCols("50");
    tag.setRows("4");
    tag.setMaxlength("5");
    tag.setOnkeypress("return onkeyClick();");
    tag.setOnpaste("return onpasteClick();");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    assertXpathEvaluatesTo("1", "count(//textarea)", result);

    assertXpathEvaluatesTo("testName", "//textarea[1]/@name", result);
    assertXpathEvaluatesTo("testId", "//textarea/@id", result);
    assertXpathEvaluatesTo("testClassName", "//textarea/@class", result);
    assertXpathEvaluatesTo("testValue", "//textarea/", result);
    assertXpathEvaluatesTo("50", "//textarea/@cols", result);
    assertXpathEvaluatesTo("4", "//textarea/@rows", result);
    assertXpathEvaluatesTo("5", "//textarea/@maxLength", result);
    assertXpathEvaluatesTo("return onkeyClick();", "//textarea/@onkeypress", result);
    assertXpathEvaluatesTo("return onpasteClick();", "//textarea/@onpaste", result);
    assertXpathEvaluatesTo("disabled", "//textarea/@disabled", result);
  }

  public void testDoTag_IsNotEditableButIsReadOnly_VerifyOutput() throws Exception {
    TextareaTag tag = new TextareaTag();
    MockJspContext jspContext = new MockJspContext();
    tag.setJspContext(jspContext);
    tag.setIsEditable(false);
    tag.setReadonly(true);
    tag.setId("testId");
    tag.setName("testName");
    tag.setClassName("testClassName");
    tag.setValue("testValue");
    tag.setCols("50");
    tag.setRows("4");
    tag.setMaxlength("5");
    tag.setOnkeypress("return onkeyClick();");
    tag.setOnpaste("return onpasteClick();");
    tag.doTag();
    String result = ((MockJspWriter) jspContext.getOut()).getResult();
    assertXpathEvaluatesTo("0", "count(//textarea)", result);

    result = "<wellFormedXML>" + result + "</wellFormedXML>";
    assertXpathEvaluatesTo("1", "count(//wellFormedXML/span)", result);

    assertXpathEvaluatesTo("testValue", "//wellFormedXML/span[1]", result);
    assertXpathEvaluatesTo("testId", "//wellFormedXML/span[1]/@id", result);
  }

}