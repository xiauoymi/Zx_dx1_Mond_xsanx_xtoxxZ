/*
 MockJspContext was created on Dec 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.tags.mock;

import javax.el.ELContext;
import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.el.ExpressionEvaluator;
import javax.servlet.jsp.el.VariableResolver;
import java.util.Enumeration;

/**
 * Filename:    $RCSfile: MockJspContext.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-23 20:43:34 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class MockJspContext extends JspContext {

  private final MockJspWriter jspWriter = new MockJspWriter();

  public void setAttribute(String string, Object object) {

  }

  public void setAttribute(String string, Object object, int i) {

  }

  public Object getAttribute(String string) {
    return null;
  }

  public Object getAttribute(String string, int i) {
    return null;
  }

  public Object findAttribute(String string) {
    return null;
  }

  public void removeAttribute(String string) {

  }

  public void removeAttribute(String string, int i) {

  }

  public int getAttributesScope(String string) {
    return 0;
  }

  public Enumeration getAttributeNamesInScope(int i) {
    return null;
  }

  public JspWriter getOut() {
    return jspWriter;
  }

  public ExpressionEvaluator getExpressionEvaluator() {
    return null;
  }

  public VariableResolver getVariableResolver() {
    return null;
  }

  public ELContext getELContext() {
    return null;
  }

}