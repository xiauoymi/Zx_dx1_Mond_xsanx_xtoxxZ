/*
 MockJspWriter was created on Dec 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.tags.mock;

import javax.servlet.jsp.JspWriter;
import java.io.IOException;

/**
 * Filename:    $RCSfile: MockJspWriter.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-12-23 20:43:34 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class MockJspWriter extends JspWriter {
  private String result;

  public MockJspWriter() {
    super(0, true);
  }

  protected MockJspWriter(int i, boolean b) {
    super(i, b);
  }

  public void newLine() throws IOException {

  }

  public void print(boolean b) throws IOException {

  }

  public void print(char c) throws IOException {

  }

  public void print(int i) throws IOException {

  }

  public void print(long l) throws IOException {

  }

  public void print(float v) throws IOException {

  }

  public void print(double v) throws IOException {

  }

  public void print(char[] chars) throws IOException {

  }

  public void print(String string) throws IOException {

  }

  public void print(Object object) throws IOException {

  }

  public void println() throws IOException {

  }

  public void println(boolean b) throws IOException {

  }

  public void println(char c) throws IOException {

  }

  public void println(int i) throws IOException {

  }

  public void println(long l) throws IOException {

  }

  public void println(float v) throws IOException {

  }

  public void println(double v) throws IOException {

  }

  public void println(char[] chars) throws IOException {

  }

  public void println(String string) throws IOException {

  }

  public void println(Object object) throws IOException {

  }

  public void clear() throws IOException {

  }

  public void clearBuffer() throws IOException {

  }

  public void flush() throws IOException {

  }

  public void write(char[] cbuf, int off, int len) throws IOException {

  }

  public void close() throws IOException {

  }

  public int getRemaining() {
    return 0;
  }

  public void write(String str) throws IOException {
    this.result = str;
  }

  public String getResult() {
    return this.result;
  }
}