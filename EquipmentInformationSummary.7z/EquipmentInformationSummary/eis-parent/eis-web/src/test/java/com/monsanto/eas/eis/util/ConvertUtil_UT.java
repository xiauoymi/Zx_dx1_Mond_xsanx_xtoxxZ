/*
 ConvertUtil_UT was created on Oct 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.util;

import junit.framework.TestCase;

import java.util.Date;
import java.util.Calendar;

/**
 * Filename:    $RCSfile: ConvertUtil_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vvvelu $    	 On:	$Date: 2008-12-16 23:47:02 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class ConvertUtil_UT extends TestCase {

  public void testToString_DateIsNull_ReturnsNull() throws Exception {
    assertNull(ConvertUtil.toString(null, null));
  }

  public void testToString_DateIsNotNullFormatIsNull_ReturnsMMddyyyy() throws Exception {
    String dateStr = ConvertUtil.toString(getDate(), null);
    assertEquals("09/23/2008", dateStr);
  }

  public void testToString_DateIsNotNullFormatIsNotNull_ReturnsMMddyyyy() throws Exception {
    String dateStr = ConvertUtil.toString(getDate(), ConvertUtil.DATE_PATTERN_SHORT);
    assertEquals("09/23/2008", dateStr);
  }

  public void testGetCalendarDateAsString() throws Exception {
    //String date = ConvertUtil.getCalendarDateAsString("Jan 01, 2008");
    //assertEquals("02012008", date);
  }


  private Date getDate(){
    Calendar cal = Calendar.getInstance();
    cal.set(Calendar.YEAR, 2008);
    cal.set(Calendar.MONTH, 8);
    cal.set(Calendar.DATE, 23);
    return cal.getTime();
  }
}