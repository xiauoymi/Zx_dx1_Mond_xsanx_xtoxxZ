package com.monsanto.eas.eis.util;

import junit.framework.TestCase;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA. User: vvvelu Date: Oct 29, 2008 Time: 6:06:35 PM To change this template use File |
 * Settings | File Templates.
 */
public class Validator_UT extends TestCase {

  public void testValidateRequiredFieldInARow() throws Exception {
    ArrayList<String> list = new ArrayList<String>();
    Validator.validateRequiredFieldInARow("", "testLabel", false, 0, list, 2);
    assertEquals(1, list.size());
    assertEquals("testLabel for row 3", list.get(0));
    list = new ArrayList<String>();
    Validator.validateRequiredFieldInARow("testValue", "testLabel", false, 0, list, 2);
    assertEquals(0, list.size());
  }

  public void testValidateRequiredFieldInARow_MinLength() throws Exception {
    ArrayList<String> list = new ArrayList<String>();
    Validator.validateRequiredFieldInARow("", "testLabel", true, 8, list, 2);
    assertEquals(1, list.size());
    assertEquals("testLabel for row 3", list.get(0));
    list = new ArrayList<String>();
    Validator.validateRequiredFieldInARow("testValue", "testLabel", true, 8, list, 2);
    assertEquals(0, list.size());
    list = new ArrayList<String>();
    Validator.validateRequiredFieldInARow("testValuetest", "testLabel", true, 8, list, 2);
    assertEquals(0, list.size());
  }

  public void testIsFieldLengthValid() throws Exception {
    assertFalse(Validator.isFieldLengthValid("te", 4));
    assertTrue(Validator.isFieldLengthValid("testtest", 4));
    assertTrue(Validator.isFieldLengthValid("test", 4));
  }

  public void testIsRequiredFieldEmpty() throws Exception {
    assertTrue(Validator.isRequiredFieldEmpty(""));
    assertTrue(Validator.isRequiredFieldEmpty(" "));
    assertFalse(Validator.isRequiredFieldEmpty("test"));
  }
}
