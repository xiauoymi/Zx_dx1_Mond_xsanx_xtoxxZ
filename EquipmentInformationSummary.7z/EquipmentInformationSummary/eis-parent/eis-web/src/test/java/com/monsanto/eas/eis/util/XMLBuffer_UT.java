/*
 XMLBuffer_UT was created on Jan 29, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.eis.util;

import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: XMLBuffer_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-01-30 16:27:33 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class XMLBuffer_UT extends TestCase {
  public void testCreateXMLBuffer() throws Exception {
    XMLBuffer buffer = new XMLBuffer();
    assertNotNull(buffer);
  }

  public void testEscapeSpecialCharactersInString_StringIsEscaped() throws Exception {
    XMLBuffer buffer = new XMLBuffer();
    buffer.appendValue("This is a text with special &' characters");
    assertEquals("This is a text with special &amp;' characters", buffer.toString());
  }
  
  public void testNormalCharacters_OriginalStringIsReturned() throws Exception {
    XMLBuffer buffer = new XMLBuffer();
    buffer.appendValue("This is a text with normal characters");
    assertEquals("This is a text with normal characters", buffer.toString());
  }

  public void testEmptyString_EmptyStringIsReturned() throws Exception {
    XMLBuffer buffer = new XMLBuffer();
    buffer.appendValue("");
    assertEquals("", buffer.toString());
  }

  public void testEmptyString_NullStringIsReturned() throws Exception {
    XMLBuffer buffer = new XMLBuffer();
    buffer.appendValue(null);
    assertEquals("", buffer.toString());
  }
  
   public void testTagAsAString_OriginalStringIsReturned() throws Exception {
    XMLBuffer buffer = new XMLBuffer();
    buffer.append("<purchasing></purchasing>");
    assertEquals("<purchasing></purchasing>", buffer.toString());
  }
}