function addResearchType(){
	obj = document.getElementById("method");
	obj.value = "addResearchType";
	document.forms[0].action="/srwgrequesttracking/servlet/new_request.html";
	document.forms[0].submit();
}
function saveRequestProfile(){
	obj = document.getElementById("method");
	obj.value = "saveRequestProfile";
	document.forms[0].action="/srwgrequesttracking/servlet/new_request.html";
	document.forms[0].submit();
}

function submit(){
	document.forms[0].submit();
}

function cancel(){
	document.forms[0].action="/srwgrequesttracking/servlet/home_page.html";
	document.forms[0].submit();
}

function deleteResearch(tempId){
	var method = document.getElementById("method");
	method.value = "deleteResearchType";
	deleteItem = document.getElementById("deleteItem");
	deleteItem.value = tempId;
	document.forms[0].action="/srwgrequesttracking/servlet/new_request.html";
	document.forms[0].submit();
}
function fillResearchAddress(prefix_from, prefix_to){
	if(document.getElementById("same_address").checked ){
		document.getElementById(prefix_to+"_address_street_one").value = document.getElementById(prefix_from+"_address_street_one").value;
		document.getElementById(prefix_to+"_address_street_two").value = document.getElementById(prefix_from+"_address_street_two").value;
		document.getElementById(prefix_to+"_address_city").value = document.getElementById(prefix_from+"_address_city").value;
		document.getElementById(prefix_to+"_address_state").value = document.getElementById(prefix_from+"_address_state").value;
		document.getElementById(prefix_to+"_address_zip").value = document.getElementById(prefix_from+"_address_zip").value;
		document.getElementById(prefix_to+"_address_country").value = document.getElementById(prefix_from+"_address_country").value;
		document.getElementById(prefix_to+"_address_phone").value = document.getElementById(prefix_from+"_address_phone").value;
		document.getElementById(prefix_to+"_address_fax").value = document.getElementById(prefix_from+"_address_fax").value;
		document.getElementById(prefix_to+"_address_email").value = document.getElementById(prefix_from+"_address_email").value;
	}
	else{
		document.getElementById(prefix_to+"_address_street_one").value = "";
		document.getElementById(prefix_to+"_address_street_two").value = "";
		document.getElementById(prefix_to+"_address_city").value = "";
		document.getElementById(prefix_to+"_address_state").value = "";
		document.getElementById(prefix_to+"_address_zip").value = "";
		document.getElementById(prefix_to+"_address_country").value = "";
		document.getElementById(prefix_to+"_address_phone").value = "";
		document.getElementById(prefix_to+"_address_fax").value = "";
		document.getElementById(prefix_to+"_address_email").value = "";
	}
}

function submitEditRequest(){
	objResearchId = document.getElementById("research_id");
	objResearchTypeId = document.getElementById("research_type");
	objResearchDescription = document.getElementById("research_description");
	window.opener.updateEditedData(objResearchId.value, objResearchTypeId.value, objResearchDescription.value);
	window.close();
}

function cancelEditRequest(){
	window.close();
}

function openPopupWindow(url){
	oWindow = window.open(url,'popup_window','width=400,height=200,resizable=yes, scrollbars=yes');
}

function validateFieldNotEmpty(fieldName, fieldValue) {
  if (fieldValue == null || fieldValue == "") {
    alert("You must enter a value for " + fieldName);
    return false;
  } else {
    return true;
  }
}