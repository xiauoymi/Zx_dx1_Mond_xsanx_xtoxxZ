	var usernameConrolId="";
	var fullnameConrolId="";
	var emailConrolId="";
	function setValuesFromPeoplePicker(arrPeopleData)
	{
		if (!usernameConrolId=="")
			document.getElementById(usernameConrolId).value = arrPeopleData[4];
		if (!fullnameConrolId=="")
			document.getElementById(fullnameConrolId).value = arrPeopleData[1] + ", " + arrPeopleData[2] + " " + arrPeopleData[3];
		if (!emailConrolId=="")
			document.getElementById(emailConrolId).value = arrPeopleData[6] + "@monsanto.com";
		document.getElementById(fullnameConrolId).focus();
	}

	function setPeoplePickerControlIds(usrname,fullname,email) {
		usernameConrolId=usrname;
		fullnameConrolId=fullname;
		emailConrolId=email;
	}

	function strtrim(s) {
	 //Match spaces at beginning and end of text and replace with null strings
		return s.replace(/^\s+/,'').replace(/\s+$/,'');
	}