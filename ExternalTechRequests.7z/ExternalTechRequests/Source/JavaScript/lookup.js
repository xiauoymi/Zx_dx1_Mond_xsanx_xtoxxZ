function getLookupData(context, selectedLookup){
    var lookupId = selectedLookup.options[selectedLookup.selectedIndex].value;
    document.forms[0].action=context+"/servlet/display_lookup.html?selectedLookup=" + lookupId + "";
    document.forms[0].submit();
}

function preUpdateLookup(context,type){
    document.forms[0].action=context+"/servlet/update_lookup.html?process=" + type + "";
    document.forms[0].submit();
}
