/*
 MainConstants was created on Oct 31, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.constants;

/**
 * Filename:    $RCSfile: MainConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-03-27 22:21:48 $
 *
 * @author ffbrac
 * @version $Revision: 1.31 $
 */
public interface MainConstants {
  int MAX_IMPORT_SIZE = 52428800;

  String HOME_PAGE = "/WEB-INF/jsp/HomePage.jspx";
  String ADD_RESEARCH_TYPE = "/WEB-INF/jsp/AddResearchType.jspx";
  String DISPLAY_HISTORY = "/WEB-INF/jsp/displayHistory.jspx";
  String USER_ADMIN = "/WEB-INF/jsp/userAdmin.jspx";
  String SEARCH_REQUEST_PROFILE_PAGE = "/WEB-INF/jsp/SearchRequestProfile.jspx";
  String REQUEST_PAGE = "/WEB-INF/jsp/request.jspx";
  String READONLY_REQUEST_PAGE = "/WEB-INF/jsp/requestReadonly.jspx";
  String LOGINUSER = "user";
  String APPLICATION_NAME = "SRWGRequestTracking";
  String ERRORS_PAGE = "/WEB-INF/jsp/errors.jspx";
  String SECURITY_TEST_PAGE = "/WEB-INF/jsp/securityTest.jspx";
  String ADD_USER_PAGE = "/WEB-INF/jsp/addUser.jspx";
  String EDIT_USER_PAGE = "/WEB-INF/jsp/editUser.jspx";
  String CREATE_LEGAL_PAGE = "/WEB-INF/jsp/createLegal.jspx";
  String ATTACH_LEGAL_PAGE = "/WEB-INF/jsp/attachLegal.jspx";
  String CREATE_SHIPPING_PAGE = "/WEB-INF/jsp/createShipping.jspx";
  String ATTACH_SHIPPING_PAGE = "/WEB-INF/jsp/attachShipping.jspx";
  String ATTACHMENT_PAGE = "/WEB-INF/jsp/attachment.jspx";
  String REVIEW_PAGE = "/WEB-INF/jsp/review.jspx";
  String SEND_TO_COMMITTEE_PAGE = "/WEB-INF/jsp/sendToCommittee.jspx";
  String COMMITTEE_PAGE = "/WEB-INF/jsp/committee.jspx";
  String STATUS_PAGE = "/WEB-INF/jsp/status.jspx";
  String EDIT_ATTACHMENT_PAGE = "/WEB-INF/jsp/editAttachment.jspx";

  String REQUEST_ID_PARAM_NAME = "request_id";
  String AFFILIATION_PARAM_NAME = "affiliation";
  String REQUEST_NUMBER_PARAM_NAME = "request_number";
  String REQUESTOR_NAME_PARAM_NAME = "requestor_name";
  String REQUESTOR_TITLE_PARAM_NAME = "requestor_title";
  String SPONSOR_PARAM_NAME = "sponsor";
  String REGION_PARAM_NAME = "region";
  String DATE_REQUESTED_PARAM_NAME = "date_requested";
  String DATE_NEEDEDBY_PARAM_NAME = "date_neededby";
  String REQUEST_TYPE_PARAM_NAME = "request_type";
  String PURPOSE_PARAM_NAME = "purpose";
  String COMMITTEE_APPROVED_PARAM_NAME = "committee_approved";
  String STATUS_PARAM_NAME = "status";
  String STUDY_LENGTH_PARAM_NAME = "study_length";
  String COMMITTEE_COMMENTS_PARAM_NAME = "committee_comments";
  String STATUS_COMMENTS_PARAM_NAME = "status_comments";
  String FCPA_BOX_PARAM_NAME = "fcpa_box";
  String SHIPTO_PARAM_NAME = "shipto";
  String RESEARCH_PARAM_NAME = "research";
  String REQUEST_RESEARCH_PARAM_NAME = "requestResearch";
  String RESEARCH_DESC_PARAM_NAME = "researchDesc";
  String STATES_PARAM_NAME = "states";

  String REQUEST_PROFILE_ATTRIBUTE_NAME = "requestProfile";
  String HASH_RESEARCH_ATTRIBUTE_NAME = "hashResearch";
  String TEMPLATES_ATTRIBUTE_NAME = "templates";
  String ATTACHMENTS_ATTRIBUTE_NAME = "attachments";
  String SEARCH_RESULTS_ATTRIBUTE = "searchResults";
  String SENDING_ADDRESS = "external.tech.requests@monsanto.com";

  Long STATUS_ID_NEW = new Long(100);
  Long STATUS_ID_IN_REVIEW = new Long(101);
  Long STATUS_ID_APPROVED = new Long(102);
  Long STATUS_ID_SHIPPING = new Long(104);
  Long STATUS_ID_COMPLETE = new Long(103);
  Long COMMITEE_REJECTED_ID = new Long(102);
  Long STATUS_ID_REJECTED = new Long(105);
  Long STATUS_ID_COORDINATOR = new Long(106);

  String SEARCH_PARAMETERS_ATTRIBUTE = "searchParameters";
  String ATTACHMENT_PARAM_NAME = "template";
  String DESCRIPTION_PARAM_NAME = "description";
}