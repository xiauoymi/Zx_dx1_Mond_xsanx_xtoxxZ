/*
 ApplicationContainer was created on Nov 1, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.container;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.administerreferencedata.constants.LookupMapConstants;
import com.monsanto.wst.administerreferencedata.controller.DisplayDBLookupsController;
import com.monsanto.wst.administerreferencedata.controller.PreUpdateLookupController;
import com.monsanto.wst.administerreferencedata.controller.SaveLookupController;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupServiceDBImpl;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.wst.emailtemplate.facade.MessageTemplateFactory;
import com.monsanto.wst.emailtemplate.services.EmailService;
import com.monsanto.wst.emailtemplate.services.MonsantoEmailService;
import com.monsanto.wst.externaltechrequests.controller.*;
import com.monsanto.wst.externaltechrequests.dao.*;
import com.monsanto.wst.externaltechrequests.dao.dbtemplate.DBTemplateLookupDao;
import com.monsanto.wst.externaltechrequests.dao.dbtemplate.DBTemplateLookupReferenceDataDao;
import com.monsanto.wst.externaltechrequests.dao.dbtemplate.DBTemplateRequestDao;
import com.monsanto.wst.externaltechrequests.dao.dbtemplate.DBTemplateRequestSearchDao;
import com.monsanto.wst.externaltechrequests.document.DocumentService;
import com.monsanto.wst.externaltechrequests.document.DocumentumDocumentService;
import com.monsanto.wst.externaltechrequests.document.POSConnectionFactory;
import com.monsanto.wst.externaltechrequests.security.UserFactory;
import com.monsanto.wst.externaltechrequests.security.dbsecurity.DBUserFactory;
import com.monsanto.wst.externaltechrequests.services.*;
import com.monsanto.wst.externaltechrequests.validator.SaveRequestProfileValidator;
import com.monsanto.wst.externaltechrequests.validator.SearchRequestProfileValidator;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactoryImpl;
import com.monsanto.wst.externaltechrequests.workflow.*;
import com.monsanto.wst.factory.AbstractLocatorGenericFactory;
import com.monsanto.wst.factory.BeanInitializationException;
import com.monsanto.wst.validator.HttpValidator;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: ApplicationContainer.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.39 $
 */
public class ApplicationContainer extends AbstractLocatorGenericFactory {
  private static final ObjectInspector objectInspector = new ObjectInspector();
  private final ThreadLocal nonThreadSafeObjects = new ThreadLocal();
  private static final Map servletMap = new HashMap();
  private final Map singletonMap = new HashMap();

  static {
    servletMap.put("/", "homePageController");
    servletMap.put("/servlet/home_page.html", "homePageController");
    servletMap.put("/servlet/new_request.html", "requestController");
    servletMap.put("/servlet/edit_research_type.html", "requestController");
    servletMap.put("/servlet/status_history.html", "requestController");
    servletMap.put("/servlet/search_request.html", "searchRequestController");
    servletMap.put("/servlet/display_lookup.html", "displayLookupController");
    servletMap.put("/servlet/display_lookup.htm", "displayLookupController");
    servletMap.put("/servlet/update_lookup.html", "preUpdateLookupController");
    servletMap.put("/servlet/save_lookup.html", "saveLookupController");

    servletMap.put("/servlet/status.html", "statusController");
    servletMap.put("/servlet/review.html", "reviewController");
    servletMap.put("/servlet/committee.html", "committeeController");
    servletMap.put("/servlet/user_admin.html", "userAdministrationController");
    servletMap.put("/servlet/legal.html", "legalController");
    servletMap.put("/servlet/document/legal.html", "legalController");
    servletMap.put("/servlet/shipping.html", "shippingController");
    servletMap.put("/servlet/attachment.html", "attachmentController");
    servletMap.put("/servlet/document/shipping.html", "shippingController");
    servletMap.put("/servlet/document/shipping", "shippingController");
    servletMap.put("/servlet/document/attachment.html", "attachmentController");
    servletMap.put("/servlet/document/editAttachment.html", "editAttachmentController");
    servletMap.put("/servlet/document/new_request.html", "requestController");
  }

  public ApplicationContainer() {
    super(objectInspector);
  }

  public void addBean(String beanId, Object obj, boolean isSingleton) {
    if (isSingleton) {
      singletonMap.put(beanId, obj);
    } else {
      Map threadSafeMap = (Map) this.nonThreadSafeObjects.get();
      if (threadSafeMap == null) {
        threadSafeMap = new HashMap();
      }
      threadSafeMap.put(beanId, obj);
      this.nonThreadSafeObjects.set(threadSafeMap);
    }
  }

  public Object getBean(String beanId) throws BeanInitializationException {
    Object obj = lookupNonThreadSafeObject(beanId);
    if (obj != null) {
      return obj;
    }
    if (singletonMap.containsKey(beanId)) {
      return singletonMap.get(beanId);
    }
    String controllerBeanId = (String) servletMap.get(beanId);
    if (controllerBeanId != null) {
      return super.getBean(controllerBeanId);
    }
    return super.getBean(beanId);
  }

  private Object lookupNonThreadSafeObject(String beanId) {
    Map nonThreadSafeMap = (Map) this.nonThreadSafeObjects.get();
    if (nonThreadSafeMap != null && nonThreadSafeMap.get(beanId) != null) {
      return nonThreadSafeMap.get(beanId);
    }
    return null;
  }

  public ViewFactory getViewFactory() {
    return new ViewFactoryImpl();
  }

  public HomePageController getHomePageController() {
    return new HomePageController(getViewFactory());
  }

  public RequestController getRequestController() {
    return new RequestController(getRequestService(), getLookupReferenceDataService(), getLookupService(),
        getViewFactory(), getSaveRequestProfileValidator(), getUserFactory(),
        getAttachmentService(), getStatusUpdateService());
  }

  public UserAdministrationController getUserAdministrationController() {
    return new UserAdministrationController(getUserFactory(), getViewFactory());
  }

  public ReviewController getReviewController() {
    return new ReviewController(getRequestSearchService(), getViewFactory(), getStatusUpdateService(),
        getLookupService(),
        getRequestEmailer(), getAttachmentService());
  }

  public CommitteeController getCommitteeController() {
    return new CommitteeController(getRequestSearchService(), getViewFactory(), getStatusUpdateService(),
        getLookupService(),
        getAttachmentService());
  }

  public StatusController getStatusController() {
    return new StatusController(getRequestSearchService(), getViewFactory(), getStatusUpdateService(),
        getLookupService(),
        getAttachmentService(), getLookupReferenceDataService());
  }

  public LegalController getLegalController() {
    return new LegalController(getStatusUpdateService(), getLookupReferenceDataService(),
        getRequestSearchService(),
        getLookupService(),
        getViewFactory(),
        getAttachmentService(), getSequenecLookupService());
  }

  public ShippingController getShippingController() {
    return new ShippingController(getStatusUpdateService(), getLookupReferenceDataService(),
        getRequestSearchService(),
        getLookupService(),
        getViewFactory(),
        getAttachmentService(), getSequenecLookupService());
  }

  public AttachmentController getAttachmentController() {
    return new AttachmentController(
        getStatusUpdateService(), getLookupReferenceDataService(),
        getRequestSearchService(),
        getLookupService(),
        getViewFactory(),
        getAttachmentService(), getSequenecLookupService());
  }

  private SequenceLookupServiceDBImpl getSequenecLookupService() {
    return new SequenceLookupServiceDBImpl(LookupMapConstants.LOOKUP_XML_LOCATION);
  }

  public AttachmentService getAttachmentService() {
    return new DBTemplateDocumentumAttachmentService(getDbTemplate(), getDocumentService());
  }

  public DocumentService getDocumentService() {
    return new DocumentumDocumentService(getPOSConnectionFactory());
  }

  public RequestEmailer getRequestEmailer() {
    return new RequestEmailerImpl(getEmailConfiguration());
  }

  public POSConnectionFactory getPOSConnectionFactory() {
    return new POSConnectionFactoryImpl();
  }

  public SearchRequestController getSearchRequestController() {
    return new SearchRequestController(getLookupReferenceDataService(), getRequestSearchService(),
        getSearchRequestProfileValidator(), getViewFactory());
  }

  public HttpValidator getSaveRequestProfileValidator() {
    return new SaveRequestProfileValidator();
  }

  public HttpValidator getSearchRequestProfileValidator() {
    return new SearchRequestProfileValidator();
  }

  public UseCaseController getDisplayLookupController() {
    return new DisplayDBLookupsController();
  }

  public UseCaseController getPreUpdateLookupController() {
    return new PreUpdateLookupController();
  }

  public UseCaseController getSaveLookupController() {
    return new SaveLookupController();
  }

  public UseCaseController getEditAttachmentController() {
    return new EditAttachmentController(getAttachmentService(), getViewFactory(), getSequenecLookupService());
  }

  public String getDataSourceConfigFile() {
    return "database/dbtemplate-config.xml";
  }

  public DBTemplate getDbTemplate() {
    TransactionManager txManager = (TransactionManager) singletonMap.get("transactionManager");
    return new DBTemplateImpl(txManager, getDBTemplateMappings());
  }

  public LookupDao getLookupDao() {
    return new DBTemplateLookupDao(getDbTemplate());
  }

  public LookupService getLookupService() {
    return new LookupServiceImpl(getLookupDao());
  }

  public LookupReferenceDataDao getLookupReferenceDataDao() {
    return new DBTemplateLookupReferenceDataDao(getDbTemplate());
  }

  public LookupReferenceDataService getLookupReferenceDataService() {
    return new LookupReferenceDataServiceImpl(getLookupReferenceDataDao());
  }

  public StatusUpdateService getStatusUpdateService() {
    return new StatusUpdateServiceImpl(getRequestService(), getEmailService(), getEmailConfiguration());
  }

  public EmailConfiguration getEmailConfiguration() {
    return new DBTemplateEmailConfiguration(getDbTemplate());
  }

  public EmailService getEmailService() {
    return new MonsantoEmailService(getMessageTemplateFactory());
  }

  public MessageTemplateFactory getMessageTemplateFactory() {
    return new MessageTemplateFactoryImpl();
  }

  public RequestDao getRequestDao() {
    return new DBTemplateRequestDao(getDbTemplate());
  }

  public UserFactory getUserFactory() {
    return new DBUserFactory(getDbTemplate());
  }

  public RequestService getRequestService() {
    return new RequestServiceImpl(getRequestDao());
  }

  public RequestSearchDao getRequestSearchDao() {
    return new DBTemplateRequestSearchDao(getDbTemplate());
  }

  public RequestSearchService getRequestSearchService() {
    return new RequestSearchServiceImpl(getRequestSearchDao());
  }

  public String[] getDBTemplateMappings() {
    return new String[]{
        "database/dbTemplate.xml"};
  }

}