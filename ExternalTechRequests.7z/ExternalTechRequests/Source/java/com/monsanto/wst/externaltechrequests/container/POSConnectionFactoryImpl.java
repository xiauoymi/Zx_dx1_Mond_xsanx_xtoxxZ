package com.monsanto.wst.externaltechrequests.container;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.POSClient.XMLPOSConnection;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.securityinterfaces.ClientSecurityProxy;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.wst.externaltechrequests.document.POSConnectionFactory;
/*
 POSConnectionFactoryImpl was created on Feb 1, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
class POSConnectionFactoryImpl implements POSConnectionFactory {
  private ClientSecurityProxy clientProxy;
  private SystemSecurityProxy systemProxy;

  POSConnectionFactoryImpl() {
  }

  public void loadSecurityInformationFromHelper(UCCHelper helper) {
    clientProxy = new KerberosSPNEGOClient(new OSBasedGSSManagerFactory());
    systemProxy = helper.getSystemSecurityProxy();

    if (clientProxy == null || systemProxy == null) {
      throw new NullPointerException("their is a problem with the security configuration");
    }
  }

  public XMLPOSConnection getConnection() throws POSCommunicationException {
    if (clientProxy == null || systemProxy == null) {
      throw new NullPointerException("POSConnectionFactoryImpl not properly initialized");
    }
    return new SecureXMLPOSConnection(clientProxy, systemProxy);
  }
}
