/*
 ApplicationContainer_AT was created on Nov 1, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.container.test;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.administerreferencedata.controller.DisplayDBLookupsController;
import com.monsanto.wst.administerreferencedata.controller.PreUpdateLookupController;
import com.monsanto.wst.administerreferencedata.controller.SaveLookupController;
import com.monsanto.wst.commonutils.EnvironmentUtils;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.dbtemplate.dao.persistentstore.test.mock.MockPersistentStoreTransactionManager;
import com.monsanto.wst.externaltechrequests.container.ApplicationContainer;
import com.monsanto.wst.externaltechrequests.controller.HomePageController;
import com.monsanto.wst.externaltechrequests.controller.RequestController;
import com.monsanto.wst.externaltechrequests.controller.SearchRequestController;
import com.monsanto.wst.externaltechrequests.dao.LookupDao;
import com.monsanto.wst.externaltechrequests.dao.LookupReferenceDataDao;
import com.monsanto.wst.externaltechrequests.dao.RequestDao;
import com.monsanto.wst.externaltechrequests.dao.dbtemplate.DBTemplateLookupDao;
import com.monsanto.wst.externaltechrequests.dao.dbtemplate.DBTemplateLookupReferenceDataDao;
import com.monsanto.wst.externaltechrequests.dao.dbtemplate.DBTemplateRequestDao;
import com.monsanto.wst.externaltechrequests.services.*;
import com.monsanto.wst.externaltechrequests.validator.SaveRequestProfileValidator;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactoryImpl;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.GenericFactory;
import junit.framework.TestCase;
/**
 * Filename:    $RCSfile: ApplicationContainer_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-02-13 17:57:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.10 $
 */
public class ApplicationContainer_AT extends TestCase {
	public void setUp() throws Exception {
		super.setUp();
		String catalinaHome = new EnvironmentUtils().getVariable("CATALINA_HOME");
		System.setProperty("catalina.home", catalinaHome);
		AbstractGenericFactory.clear();
		AbstractGenericFactory.setImplementation("com.monsanto.wst.externaltechrequests.container.ApplicationContainer");
		GenericFactory container = AbstractGenericFactory.getInstance();
		container.addBean("transactionManager", new MockPersistentStoreTransactionManager(), true);
	}
	protected void tearDown() throws Exception {
		super.tearDown();
		System.setProperty("catalina.home", "");
	}
	// test commons
	public void testCreate() throws Exception {
		GenericFactory container = AbstractGenericFactory.getInstance();
		assertNotNull(container);
		assertEquals(ApplicationContainer.class, container.getClass());
	}
	public void testGetDbTemplate() throws Exception {
	    GenericFactory container = AbstractGenericFactory.getInstance();
	    DBTemplate template = (DBTemplate) container.getBean("dbTemplate");
	    assertNotNull(template);
	    assertEquals(DBTemplateImpl.class, template.getClass());
	}
	public void testGetViewFactory() throws Exception {
	    GenericFactory container = AbstractGenericFactory.getInstance();
	    ViewFactory factory = (ViewFactory) container.getBean("viewFactory");
	    assertNotNull(factory);
	    assertEquals(ViewFactoryImpl.class, factory.getClass());
	}
	// test validators
	public void testGetSaveRequestValidator() throws Exception {
	    GenericFactory container = AbstractGenericFactory.getInstance();
	    SaveRequestProfileValidator validator = (SaveRequestProfileValidator) container.getBean("saveRequestProfileValidator");
	    assertNotNull(validator);
	    assertEquals(SaveRequestProfileValidator.class, validator.getClass());
	}
	// test daos and services
	public void testGetLookupDao() throws Exception {
	    GenericFactory container = AbstractGenericFactory.getInstance();
	    LookupDao template = (LookupDao) container.getBean("lookupDao");
	    assertNotNull(template);
	    assertEquals(DBTemplateLookupDao.class, template.getClass());
	}
	public void testGetLookupService() throws Exception {
	    GenericFactory container = AbstractGenericFactory.getInstance();
	    LookupService service = (LookupService) container.getBean("lookupService");
	    assertNotNull(service);
	    assertEquals(LookupServiceImpl.class, service.getClass());
	}
	public void testGetRequestDao() throws Exception {
	    GenericFactory container = AbstractGenericFactory.getInstance();
	    RequestDao template = (RequestDao) container.getBean("requestDao");
	    assertNotNull(template);
	    assertEquals(DBTemplateRequestDao.class, template.getClass());
	}
	public void testGetRequestService() throws Exception {
	    GenericFactory container = AbstractGenericFactory.getInstance();
	    RequestService service = (RequestService) container.getBean("requestService");
	    assertNotNull(service);
	    assertEquals(RequestServiceImpl.class, service.getClass());
	}
	public void testGetLookupReferenceDataDao() throws Exception {
	    GenericFactory container = AbstractGenericFactory.getInstance();
	    LookupReferenceDataDao template = (LookupReferenceDataDao) container.getBean("lookupReferenceDataDao");
	    assertNotNull(template);
	    assertEquals(DBTemplateLookupReferenceDataDao.class, template.getClass());
	}
	public void testGetLookupReferenceDataService() throws Exception {
	    GenericFactory container = AbstractGenericFactory.getInstance();
	    LookupReferenceDataService service = (LookupReferenceDataService) container.getBean("lookupReferenceDataService");
	    assertNotNull(service);
	    assertEquals(LookupReferenceDataServiceImpl.class, service.getClass());
	}
	// test controllers
	public void testGetHomePageController() throws Exception {
		GenericFactory container = AbstractGenericFactory.getInstance();
		UseCaseController controller = (UseCaseController) container.getBean("homePageController");
		assertEquals(HomePageController.class, controller.getClass());
	}
	public void testGetRequestController() throws Exception {
		GenericFactory container = AbstractGenericFactory.getInstance();
		UseCaseController controller = (UseCaseController) container.getBean("requestController");
		assertEquals(RequestController.class, controller.getClass());
	}
	public void testGetSearchRequestController() throws Exception {
		GenericFactory container = AbstractGenericFactory.getInstance();
		UseCaseController controller = (UseCaseController) container.getBean("searchRequestController");
		assertEquals(SearchRequestController.class, controller.getClass());
	}
	public void testGetDisplayLookupController() throws Exception {
	  GenericFactory container = AbstractGenericFactory.getInstance();
	  UseCaseController controller = (UseCaseController) container.getBean("/servlet/display_lookup.html");
	  assertNotNull(controller);
	  assertEquals(DisplayDBLookupsController.class, controller.getClass());
	}

  public void testGetUpdateLookupController() throws Exception {
	  GenericFactory container = AbstractGenericFactory.getInstance();
	  UseCaseController controller = (UseCaseController) container.getBean("/servlet/update_lookup.html");
	  assertNotNull(controller);
	  assertEquals(PreUpdateLookupController.class, controller.getClass());
	}

	public void testGetSaveLookupController() throws Exception {
	  GenericFactory container = AbstractGenericFactory.getInstance();
	  UseCaseController controller = (UseCaseController) container.getBean("/servlet/save_lookup.html");
	  assertNotNull(controller);
	  assertEquals(SaveLookupController.class, controller.getClass());
	}
}