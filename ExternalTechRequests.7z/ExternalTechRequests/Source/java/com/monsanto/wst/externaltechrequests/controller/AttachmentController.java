package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupService;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
import com.monsanto.wst.externaltechrequests.services.LookupReferenceDataService;
import com.monsanto.wst.externaltechrequests.services.LookupService;
import com.monsanto.wst.externaltechrequests.services.RequestSearchService;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateService;
import com.monsanto.wst.view.View;
import org.apache.commons.lang.math.NumberUtils;

import java.io.IOException;
/*
 AttachmentController was created on Feb 2, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class AttachmentController extends RequestAttachmentAbstractController {
  private static final String ATTACH_URL = "/srwgrequesttracking/servlet/attachment.html?method=attachTemplate";

  public AttachmentController(StatusUpdateService statusService, LookupReferenceDataService lookupReferenceDataService,
                         RequestSearchService requestSearchService, LookupService lookupService,
                         ViewFactory viewFactory,
                         AttachmentService attachmentService, SequenceLookupService sequenceLookupService) {
    super(attachmentService, sequenceLookupService, lookupService, lookupReferenceDataService, viewFactory,
        statusService, requestSearchService);
  }

  public void complete(UCCHelper helper) throws IOException {
    notSpecified(helper);
  }

  public void saveTemplate(UCCHelper helper) throws IOException {
    notSpecified(helper);
  }

  public void createNewTemplate(UCCHelper helper) throws IOException {
    notSpecified(helper);
  }

  public void display(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    String attachmentId = helper.getRequestParameterValue("attachmentId");
    if (attachmentId == null) {
      notSpecified(helper);
    } else {
      displayAttachment(helper, NumberUtils.createLong(attachmentId));
    }
  }

  private void displayAttachment(UCCHelper helper, Long attachmentId) throws IOException {
    Attachment attachment = getAttachmentService().getAttachment(attachmentId);
    generate(helper, attachment, "");
  }

  protected DocumentType getDocType() {
    return DocumentType.OTHER;
  }

  protected Privilege[] getPrivsForCreate() {
    return new Privilege[0];
  }

  protected View getAttachView(ViewFactory viewFactory) {
    return viewFactory.getAttachmentView();
  }

  protected View getCreateView(ViewFactory viewFactory) {
    return viewFactory.getCreateLegalAttachmentView();
  }

  protected void updateStatusToComplete(StatusUpdateService statusService, RequestProfile requestProfile,
                                        String modUser) {
    statusService.legalComplete(requestProfile, modUser);
  }

  protected Privilege[] getPrivsForAttach() {
    return new Privilege[]{Privilege.EDIT_OWN, Privilege.CREATE_ANY, Privilege.CREATE_OWN};
  }

  protected String getStatusDescription() {
    return "";
  }

  protected String getURLBaseForSearchResults() {
    return ATTACH_URL;
  }

  protected String getSearchTitle() {
    return "All Requests";
  }
}
