package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.document.AttachmentCollection;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
/*
 AttachmentUtil was created on Feb 14, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class AttachmentUtil {
  private AttachmentUtil() {
  }
  //todo find a better place for this than a util class

  public static void addAttachmentsToRequest(UCCHelper helper, AttachmentService attachmentService,
                                             Long requestIdValue, User user) {
    AttachmentCollection attachments = attachmentService.getAttachments(requestIdValue, user);
    helper.setRequestAttributeValue(MainConstants.ATTACHMENTS_ATTRIBUTE_NAME, attachments);
  }
}
