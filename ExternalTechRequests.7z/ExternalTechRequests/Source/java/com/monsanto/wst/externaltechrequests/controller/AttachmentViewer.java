package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.document.DocumentRetrievalException;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.view.View;
/*
 AttachmentViewer was created on Feb 15, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class AttachmentViewer {
  private final ViewFactory viewFactory;

  public AttachmentViewer(ViewFactory viewFactory) {
    this.viewFactory = viewFactory;
  }

  public void view(UCCHelper helper, Attachment attachment) throws DocumentRetrievalException {
    helper.setRequestAttributeValue("attachmentId", attachment.getMetadata().getId().toString());
    helper.setRequestAttributeValue("content", prepareForRTEControl(attachment.getAttachedFile().getContent()));
    View view = viewFactory.getEditAttachmentView();
    view.renderView(helper);
  }

  private String prepareForRTEControl(byte[] content) {
    String tmpString = new String(content);
    tmpString = replaceDisallowedCharacters(tmpString, (char) 145, "&#39;"); // angled quotes
    tmpString = replaceDisallowedCharacters(tmpString, (char) 146, "&#39;"); // angled quotes
    tmpString = replaceDisallowedCharacters(tmpString, '\'', "&#39;");

    tmpString = replaceDisallowedCharacters(tmpString, (char) 147, "\""); // angled quotes
    tmpString = replaceDisallowedCharacters(tmpString, (char) 148, "\""); // angled quotes
    // regular quotes are ok

    tmpString = replaceDisallowedCharacters(tmpString, (char) 10, " "); // LF
    tmpString = replaceDisallowedCharacters(tmpString, (char) 13, " "); // CR

    return tmpString;
  }

  private String replaceDisallowedCharacters(String orig, char badChar, String goodString) {
    char[] tempChar = new char[2];
    tempChar[0] = '\\';
    tempChar[1] = badChar;
    String badString = new String(tempChar);
    return orig.replaceAll(badString, goodString);
  }
}
