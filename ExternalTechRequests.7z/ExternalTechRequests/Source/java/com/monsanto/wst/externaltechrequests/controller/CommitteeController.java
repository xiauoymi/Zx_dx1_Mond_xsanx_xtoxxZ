package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
import com.monsanto.wst.externaltechrequests.services.LookupService;
import com.monsanto.wst.externaltechrequests.services.LookupServiceException;
import com.monsanto.wst.externaltechrequests.services.RequestSearchService;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateService;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.view.View;

import java.io.IOException;
import java.util.*;
/*
 CommitteeController was created on Feb 7, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class CommitteeController extends ETRAbstractDispatchController {
  private static final Privilege[] allowedPrivs = {Privilege.REVIEW};

  private final RequestSearchService requestSearchService;
  private final ViewFactory viewFactory;
  private final StatusUpdateService statusService;
  private final LookupService lookupService;
  private final AttachmentService attachmentService;
  public static final String COMMENT_PREFIX = "comment_";
  public static final String APPROVE_PREFIX = "approve_";
  public static final String REJECT_PREFIX = "reject_";

  public CommitteeController(RequestSearchService requestSearchService, ViewFactory viewFactory,
                             StatusUpdateService statusService, LookupService lookupService,
                             AttachmentService attachmentService) {
    this.requestSearchService = requestSearchService;
    this.viewFactory = viewFactory;
    this.statusService = statusService;
    this.lookupService = lookupService;
    this.attachmentService = attachmentService;
  }

  //todo there is some sort of SearchingPage abstraction that needs to be refactored out of here, sendToCommittee, legal, shipping, etc.
  protected void notSpecified(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);

    List requests = wrapRequestsWithRequestReviews(
        requestSearchService.getRequestListBySearchCriteria(getSearchCriteria()),
        getComments(helper));
    helper.setRequestAttributeValue(MainConstants.SEARCH_RESULTS_ATTRIBUTE, requests);
    helper.setRequestAttributeValue("actionMethod", "approveOrReject");
    helper.setRequestAttributeValue("title", "Committee Review");
    View view = viewFactory.getCommitteeView();
    view.renderView(helper);
  }

  public void coordinator(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);

    List requests = wrapRequestsWithRequestReviews(
        requestSearchService.getRequestListBySearchCriteria(getCoordinatorSearchCriteria()),
        getComments(helper));
    helper.setRequestAttributeValue(MainConstants.SEARCH_RESULTS_ATTRIBUTE, requests);
    helper.setRequestAttributeValue("actionMethod", "coordinatorApproveOrReject");
    helper.setRequestAttributeValue("title", "SRWG Coordinator Review");
    View view = viewFactory.getCommitteeView();
    view.renderView(helper);
  }

  public void approveOrReject(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);

    try {
      CommitteeAction desiredAction = getDesiredAction(helper, new CommitteeActionFactory());
      if (desiredAction != null) {
        desiredAction.perform(helper.getAuthenticatedUserID());
      }
      notSpecified(helper);
    } catch (LookupServiceException e) {
      logAndRenderErrorMessagesView(e, helper);
    }
  }

  public void coordinatorApproveOrReject(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);

    try {
      CommitteeAction desiredAction = getDesiredAction(helper, new CoordinatorActionFactory());
      if (desiredAction != null) {
        desiredAction.perform(helper.getAuthenticatedUserID());
      }
      coordinator(helper);
    } catch (LookupServiceException e) {
      logAndRenderErrorMessagesView(e, helper);
    }
  }

  private CommitteeAction getDesiredAction(UCCHelper helper, ActionFactory actionFactory) throws LookupServiceException,
      IOException {
    Map comments = getComments(helper);
    Enumeration paramNames = helper.getParameterNames();
    while (paramNames.hasMoreElements()) {
      String paramName = (String) paramNames.nextElement();
      String approveId = getStringAfterPrefix(paramName, APPROVE_PREFIX);
      String rejectId = getStringAfterPrefix(paramName, REJECT_PREFIX);
      if (approveId != null) {
        Long id = new Long(approveId);
        RequestProfile request = lookupService.lookupRequestById(id);
        String comment = (String) comments.get(id);
        return actionFactory.getApproveAction(request, comment);
      } else if (rejectId != null) {
        Long id = new Long(rejectId);
        RequestProfile request = lookupService.lookupRequestById(id);
        String comment = (String) comments.get(id);
        return actionFactory.getRejectAction(request, comment);
      }
    }

    return null;
  }

  private Map getComments(UCCHelper helper) throws IOException {
    Map comments = new HashMap();
    Enumeration paramNames = helper.getParameterNames();
    while (paramNames.hasMoreElements()) {
      String paramName = (String) paramNames.nextElement();
      String idString = getStringAfterPrefix(paramName, COMMENT_PREFIX);
      if (idString != null) {
        comments.put(new Long(idString), helper.getRequestParameterValue(paramName));
      }
    }
    return comments;
  }

  private String getStringAfterPrefix(String base, String prefix) {
    if (base.startsWith(prefix)) {
      return base.substring(prefix.length());
    } else {
      return null;
    }
  }

  private List wrapRequestsWithRequestReviews(List origList, Map comments) {
    List wrappedList = new ArrayList(origList.size());
    for (int i = 0; i < origList.size(); i++) {
      RequestProfile request = (RequestProfile) origList.get(i);
      String comment = (String) comments.get(request.getId());
      wrappedList.add(new RequestReview(request, comment));
    }

    return wrappedList;
  }

  private interface CommitteeAction {
    void perform(String modUser);
  }

  private interface ActionFactory {
    CommitteeAction getApproveAction(RequestProfile request, String comments);

    CommitteeAction getRejectAction(RequestProfile request, String comments);
  }

  private class CommitteeActionFactory implements ActionFactory {
    public CommitteeAction getApproveAction(RequestProfile request, String comments) {
      return new CommitteeApproveAction(request, comments);
    }

    public CommitteeAction getRejectAction(RequestProfile request, String comments) {
      return new CommitteeRejectAction(request, comments);
    }
  }

  private class CoordinatorActionFactory implements ActionFactory {
    public CommitteeAction getApproveAction(RequestProfile request, String comments) {
      return new CoordinatorApproveAction(request, comments);
    }

    public CommitteeAction getRejectAction(RequestProfile request, String comments) {
      //note same as committee rejection, only difference would be in the status history
      return new CommitteeRejectAction(request, comments);
    }
  }

  private class CoordinatorApproveAction implements CommitteeAction {
    private final RequestProfile request;
    private final String comments;

    CoordinatorApproveAction(RequestProfile request, String comments) {
      this.request = request;
      this.comments = comments;
    }

    public void perform(String modUser) {
      statusService.coordinatorComplete(request, comments, modUser);
    }
  }

  private class CommitteeApproveAction implements CommitteeAction {
    private final RequestProfile request;
    private final String comments;

    CommitteeApproveAction(RequestProfile request, String comments) {
      this.request = request;
      this.comments = comments;
    }

    public void perform(String modUser) {
      statusService.commiteeApproval(request, comments, modUser);
    }
  }

  private class CommitteeRejectAction implements CommitteeAction {
    private final RequestProfile request;
    private final String comments;

    CommitteeRejectAction(RequestProfile request, String comments) {
      this.request = request;
      this.comments = comments;
    }

    public void perform(String modUser) {
      statusService.commiteeRejection(request, comments, modUser);
    }
  }

  private void logAndRenderErrorMessagesView(Exception e, UCCHelper helper) {
    if (Logger.isEnabled(Logger.ERROR_LOG)) {
      Logger.log(new LoggableError(e));
    }
    HttpRequestErrors errors = new HttpRequestErrors();
    errors.addError("exception", e.getMessage());
    helper.setRequestAttributeValue("errors", errors);
    View view = viewFactory.getErrorsView();
    view.renderView(helper);
  }

  private RequestSearch getSearchCriteria() {
    return new RequestSearch(MainConstants.STATUS_ID_IN_REVIEW);
  }

  private RequestSearch getCoordinatorSearchCriteria() {
    return new RequestSearch(MainConstants.STATUS_ID_COORDINATOR);
  }

  protected void loadSecurityInfoFromHelper(UCCHelper helper) {
    attachmentService.loadSecurityInfoFromHelper(helper);
  }

}
