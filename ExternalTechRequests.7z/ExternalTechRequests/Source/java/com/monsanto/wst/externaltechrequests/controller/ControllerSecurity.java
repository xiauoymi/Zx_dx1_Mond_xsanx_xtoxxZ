package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.services.LookupService;
import com.monsanto.wst.externaltechrequests.services.LookupServiceException;
/*
 ControllerSecurity was created on Jan 23, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class ControllerSecurity {
  private ControllerSecurity() {
  }

  //todo look at refactoring this
  public static void createLoginUser(UCCHelper helper, LookupService lookupService) throws LookupServiceException {
    String userId = helper.getAuthenticatedUserID().toUpperCase();
    User loginUser = lookupService.lookupLoginUserByUserId(userId);
    helper.setSessionParameter(MainConstants.LOGINUSER, loginUser);
  }

  public static void verifyUserIsAuthorized(UCCHelper helper, Privilege priv) {
    User loginUser = (User) helper.getSessionParameter(MainConstants.LOGINUSER);
    if (!loginUser.hasPrivilege(priv)) {
      throw new UnauthorizedActionException(priv);
    }
  }

  public static void verifyUserIsAuthorized(UCCHelper helper, Privilege[] privs) {
    User loginUser = getCurrentUser(helper);
    boolean privFound = false;
    for (int i = 0; i < privs.length; i++) {
      if (loginUser.hasPrivilege(privs[i])) {
        privFound = true;
      }
    }

    if (!privFound) {
      throw new UnauthorizedActionException(privs);
    }
  }

  public static User getCurrentUser(UCCHelper helper) {
    return (User) helper.getSessionParameter(MainConstants.LOGINUSER);
  }
}
