/*
 DILoginController was created on Nov 1, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.services.LookupService;
import com.monsanto.wst.externaltechrequests.services.LookupServiceException;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.factory.GenericFactory;
import com.monsanto.wst.servletframework.DITransactionalController;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.view.View;

import java.io.IOException;

/**
 * Filename:    $RCSfile: DILoginController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date:
 * 2006/11/28 18:30:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.15 $
 */
public class DILoginController extends DITransactionalController {
  public void run(UCCHelper helper) throws IOException {
    GenericFactory container = getApplicationContext(helper);
    getTransactionManager(helper);

    LookupService lookupService = (LookupService) container.getBean("lookupService");
    ViewFactory viewFactory = (ViewFactory) container.getBean("viewFactory");

    try {
      createLoginUser(helper, lookupService);
      super.run(helper);
    } catch (LookupServiceException e) {
      rejectUser(helper, viewFactory);
    } catch (Exception e) {
      Logger.log(new LoggableError(e));
      redirectToErrorsPage(helper, viewFactory, "Exception:Unknown Error... Please try again later");
    }
  }

  protected void rejectUser(UCCHelper helper, ViewFactory viewFactory) {
    Logger.log(new LoggableError("An unauthorized user attempted to access the system.  User was denied access."));
    redirectToErrorsPage(helper, viewFactory, "Unauthorized User Access... Please contact the system administrator.");
  }

  protected void redirectToErrorsPage(UCCHelper helper, ViewFactory viewFactory, String message) {
    HttpRequestErrors errors = new HttpRequestErrors();
    errors.addError("exception", message);
    helper.setRequestAttributeValue("errors", errors);
    View view = viewFactory.getErrorsView();
    view.renderView(helper);
  }

  protected void createLoginUser(UCCHelper helper, LookupService lookupService) throws LookupServiceException {
    ControllerSecurity.createLoginUser(helper, lookupService);
  }
}