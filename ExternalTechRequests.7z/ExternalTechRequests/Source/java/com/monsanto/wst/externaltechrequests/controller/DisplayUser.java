package com.monsanto.wst.externaltechrequests.controller;
/*
 DisplayUser was created on Jan 10, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class DisplayUser {
  private final String userId;
  private final String name;
  private final String email;
  private final String roleString;

  public DisplayUser(String userId, String name, String email, String roleString) {
    this.userId = userId;
    this.name = name;
    this.email = email;
    this.roleString = roleString;
  }

  public String getUserId() {
    return userId;
  }

  public String getName() {
    return name;
  }

  public String getFullName() {
    return getName();
  }

  public String getEmail() {
    return email;
  }

  public String getRoleString() {
    return roleString;
  }
}
