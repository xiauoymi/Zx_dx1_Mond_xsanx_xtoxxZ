package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.servletframework.AbstractDispatchController;

import java.io.IOException;
/*
 ExternalTechRequestsAbstractDispatchController was created on Feb 20, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public abstract class ETRAbstractDispatchController extends AbstractDispatchController {
  public void run(UCCHelper helper) throws IOException {
    helper.setMaxImportFileSize(MainConstants.MAX_IMPORT_SIZE);
    super.run(helper);
  }
}
