package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupService;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.document.DocumentRetrievalException;
import com.monsanto.wst.externaltechrequests.document.DocumentStorageException;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.model.AttachmentMetadata;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.view.View;
import org.apache.commons.lang.math.NumberUtils;

import java.io.IOException;
import java.io.PrintWriter;
/*
 EditAttachmentController was created on Feb 12, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class EditAttachmentController extends ETRAbstractDispatchController {
  private final AttachmentService attachmentService;
  private final ViewFactory viewFactory;
  private final SequenceLookupService sequenceLookupService;

  public EditAttachmentController(AttachmentService attachmentService, ViewFactory viewFactory,
                                  SequenceLookupService sequenceLookupService) {
    this.attachmentService = attachmentService;
    this.viewFactory = viewFactory;
    this.sequenceLookupService = sequenceLookupService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    attachmentService.loadSecurityInfoFromHelper(helper);
    Attachment attachment = getAttachmentFromHelper(helper);
    try {
      if (attachment == null) {
        logAndRenderErrorMessagesView("Request could not be found", helper);
      } else {
        if (canView(helper, attachment)) {
          displayAttachment(helper, attachment);
        }
      }
    } catch (DocumentRetrievalException e) {
      logAndRenderErrorMessagesView(e, helper);
    }
  }

  public void saveAttachment(UCCHelper helper) throws IOException {
    attachmentService.loadSecurityInfoFromHelper(helper);

    try {
      Attachment attachment = getAttachmentFromHelper(helper);
      String content = helper.getRequestParameterValue("content");
      if (attachment == null) {
        throw new DocumentStorageException("Attachment to edit was not found");
      } else {
        updateExistingAttachment(attachment, helper, content);
      }
    } catch (DocumentStorageException e) {
      logAndRenderErrorMessagesView(e, helper);
    }
  }

  protected Long getSequence() {
    try {
      return new Long(sequenceLookupService.getSequence());
    } catch (GenericLookupBuilderException e) {
      Logger.log(new LoggableError(e));
      return null;
    }
  }

  private void updateExistingAttachment(Attachment attachment, UCCHelper helper, String content) throws IOException,
      DocumentStorageException {
    if (attachment == null) {
      logAndRenderErrorMessagesView("Request could not be found", helper);
    } else {
      if (canUpdate(helper, attachment)) {
        updateAttachment(attachment, content, helper.getAuthenticatedUserID());
        displayClosingPage(helper);
      }
    }
  }

  private void displayClosingPage(UCCHelper helper) throws IOException {
    PrintWriter output = helper.getPrintWriter();
    output.println("<HTML><HEAD><TITLE>Attachment Save</TITLE>");
    output.println("<script language='javascript'>window.close()</script>");
    output.println("</HEAD><BODY><H1>Attachment Saved</H1></BODY></HTML");
    output.close();
  }

  public void delete(UCCHelper helper) throws IOException {
    attachmentService.loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, Privilege.DELETE_ATTACHMENT);
    Attachment attachment = getAttachmentFromHelper(helper);
    if (attachment == null) {
      logAndRenderErrorMessagesView("Request could not be found", helper);
    } else {
      deleteAttachment(attachment);
      displayClosingPage(helper);
    }
  }

  private void deleteAttachment(Attachment attachment) {
    attachmentService.deleteAttachment(attachment);
  }

  private Attachment getAttachmentFromHelper(UCCHelper helper) throws IOException {
    Long attachmentId = NumberUtils.createLong(helper.getRequestParameterValue("attachmentId"));
    if (attachmentId == null) {
      return null;
    } else {
      return attachmentService.getAttachment(attachmentId);
    }
  }

  private boolean canUpdate(UCCHelper helper, Attachment attachment) {
    RequestProfile request = new RequestProfile(attachment.getMetadata().getRequestId());
    User loginUser = (User) helper.getSessionParameter(MainConstants.LOGINUSER);
    if (loginUser == null || !loginUser.canEdit(request)) {
      logAccessDenied(helper, request, "update");
      return false;
    } else {
      return true;
    }
  }

  private boolean canView(UCCHelper helper, Attachment attachment) {
    RequestProfile request = new RequestProfile(attachment.getMetadata().getRequestId());
    User loginUser = (User) helper.getSessionParameter(MainConstants.LOGINUSER);
    if (loginUser == null || !loginUser.canView(request)) {
      logAccessDenied(helper, request, "view");
      return false;
    } else {
      return true;
    }
  }

  private void updateAttachment(Attachment attachment, String content, String modUser)
      throws DocumentStorageException {
    attachmentService.updateAttachment(new UpdatedAttachment(attachment, content), modUser);
  }

  private void logAndRenderErrorMessagesView(String msg, UCCHelper helper) {
    if (Logger.isEnabled(Logger.ERROR_LOG)) {
      Logger.log(new LoggableError(msg));
    }
    HttpRequestErrors errors = new HttpRequestErrors();
    errors.addError(HttpRequestErrors.GLOBAL_ERROR, msg);
    helper.setRequestAttributeValue("errors", errors);
    View view = viewFactory.getErrorsView();
    view.renderView(helper);
  }

  private void logAndRenderErrorMessagesView(Exception e, UCCHelper helper) {
    if (Logger.isEnabled(Logger.ERROR_LOG)) {
      Logger.log(new LoggableError(e));
    }
    HttpRequestErrors errors = new HttpRequestErrors();
    errors.addError("exception", e.getMessage());
    helper.setRequestAttributeValue("errors", errors);
    View view = viewFactory.getErrorsView();
    view.renderView(helper);
  }

  private void logAccessDenied(UCCHelper helper, RequestProfile request, String action) {
    String msg = "Not authorized to " + action + " request # " + request.getRequestNumber();
    if (Logger.isEnabled(Logger.ERROR_LOG)) {
      Logger.log(new LoggableError(msg));
    }
    HttpRequestErrors errors = new HttpRequestErrors();
    errors.addError(HttpRequestErrors.GLOBAL_ERROR, msg);
    helper.setRequestAttributeValue("errors", errors);
    View view = viewFactory.getErrorsView();
    view.renderView(helper);
  }

  public void displayAttachment(UCCHelper helper, Attachment attachment) throws DocumentRetrievalException {
    new AttachmentViewer(viewFactory).view(helper, attachment);
  }

  private class UpdatedAttachment implements Attachment {
    private final Attachment base;
    private final String content;

    UpdatedAttachment(Attachment base, String content) {
      this.base = base;
      this.content = content;
    }

    public AttachmentMetadata getMetadata() {
      return base.getMetadata();
    }

    public AttachedFile getAttachedFile() throws DocumentRetrievalException {
      return new AttachedFile(content.getBytes());
    }
  }
}
