/*
 HomePageController was created on Oct 31, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.view.View;

import java.io.IOException;

/**
 * Filename:    $RCSfile: HomePageController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.7 $
 */
public class HomePageController implements UseCaseController {

  private final ViewFactory viewFactory;

  public HomePageController(ViewFactory viewFactory) {
    this.viewFactory = viewFactory;
  }

  public void run(UCCHelper helper) throws IOException {
    View view = viewFactory.getHomePageView();
    view.renderView(helper);
  }
}