package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupService;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.services.*;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateService;
import com.monsanto.wst.view.View;

import java.io.IOException;

/*
 LegalController was created on Jan 23, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class LegalController extends RequestAttachmentAbstractController {
  public static final String LEGAL_URL = "/srwgrequesttracking/servlet/legal.html?method=attachTemplate";
  private static final String LEGAL_STATUS_DESCRIPTION = "Legal";

  public LegalController(StatusUpdateService statusService, LookupReferenceDataService lookupReferenceDataService,
                         RequestSearchService requestSearchService, LookupService lookupService,
                         ViewFactory viewFactory,
                         AttachmentService attachmentService, SequenceLookupService sequenceLookupService) {
    super(attachmentService, sequenceLookupService, lookupService, lookupReferenceDataService, viewFactory,
        statusService, requestSearchService);
  }

  public void notifySupervisor(UCCHelper helper) throws IOException {
    RequestProfile request;
    try {
      request = getRequestFromHelper(helper);
    } catch (LookupServiceException e) {
      logAndRenderErrorMessagesView(e, helper);
      return;
    }
    getStatusService().legalNotify(request);
    addSuccessMessageToHelper(helper, "Legal supervisor notified.");
    attachTemplate(helper);
  }

  protected View getAttachView(ViewFactory viewFactory) {
    return viewFactory.getAttachLegalView();
  }

  protected View getCreateView(ViewFactory viewFactory) {
    return viewFactory.getCreateLegalAttachmentView();
  }

  protected void updateStatusToComplete(StatusUpdateService statusService, RequestProfile requestProfile,
                                        String modUser) {
    statusService.legalComplete(requestProfile, modUser);
  }

  protected String getStatusDescription() {
    return LEGAL_STATUS_DESCRIPTION;
  }

  protected DocumentType getDocType() {
    return DocumentType.LEGAL;
  }

  protected Privilege[] getPrivsForCreate() {
    return new Privilege[]{Privilege.CREATE_LEGAL};
  }

  protected Privilege[] getPrivsForAttach() {
    return new Privilege[]{Privilege.ATTACH_LEGAL};
  }

  protected String getURLBaseForSearchResults() {
    return LEGAL_URL;
  }

  protected String getSearchTitle() {
    return "Approved Requests needing Legal Review";
  }

}
