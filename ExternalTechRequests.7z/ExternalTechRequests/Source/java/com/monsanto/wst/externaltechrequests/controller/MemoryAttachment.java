package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.model.AttachmentMetadata;
/*
 MemoryAttachment was created on Feb 15, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MemoryAttachment implements Attachment {
  private final AttachmentMetadata meta;
  private final byte[] content;

  public MemoryAttachment(AttachmentMetadata meta, byte[] content) {
    this.meta = meta;
    this.content = content;
  }

  public AttachmentMetadata getMetadata() {
    return meta;
  }

  public AttachedFile getAttachedFile() {
    return new AttachedFile(content);
  }
}
