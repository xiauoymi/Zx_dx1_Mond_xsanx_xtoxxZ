package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.document.DocumentRetrievalException;
import com.monsanto.wst.externaltechrequests.document.MimeTypeFactory;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.model.AttachmentMetadata;
/*
 ModifiableAttachment was created on Feb 14, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class ModifiableAttachment implements Attachment {
  //todo don't like this class name (since not always modifable), try to think of a better one
  private final Attachment base;
  private final boolean updatable;
  private final boolean deletable;

  public ModifiableAttachment(Attachment base, boolean updatable, boolean deletable) {
    this.base = base;
    this.updatable = updatable;
    this.deletable = deletable;
  }

  public AttachmentMetadata getMetadata() {
    return base.getMetadata();
  }

  public AttachedFile getAttachedFile() throws DocumentRetrievalException {
    return base.getAttachedFile();
  }

  public boolean isEditable() {
    MimeTypeFactory mimeFactory = new MimeTypeFactory();
    return mimeFactory.isEditable(base.getMetadata().getMimeType()) && updatable;
  }

  public boolean isDeletable() {
    return deletable;
  }
}
