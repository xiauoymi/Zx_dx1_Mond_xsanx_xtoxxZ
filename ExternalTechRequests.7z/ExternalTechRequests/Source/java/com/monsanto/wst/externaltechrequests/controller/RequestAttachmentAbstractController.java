package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupService;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.document.*;
import com.monsanto.wst.externaltechrequests.model.*;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.services.*;
import com.monsanto.wst.externaltechrequests.utils.search.SearchUtils;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateService;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.view.View;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/*
 RequestAttachmentAbstractController was created on Feb 6, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public abstract class RequestAttachmentAbstractController extends ETRAbstractDispatchController {
  private final AttachmentService attachmentService;
  private final SequenceLookupService sequenceLookupService;
  private final LookupService lookupService;
  private final LookupReferenceDataService lookupReferenceDataService;
  private final ViewFactory viewFactory;
  private final StatusUpdateService statusService;
  private final RequestSearchService requestSearchService;

  protected RequestAttachmentAbstractController(AttachmentService attachmentService,
                                                SequenceLookupService sequenceLookupService,
                                                LookupService lookupService,
                                                LookupReferenceDataService lookupReferenceDataService,
                                                ViewFactory viewFactory,
                                                StatusUpdateService statusService,
                                                RequestSearchService requestSearchService) {
    this.attachmentService = attachmentService;
    this.sequenceLookupService = sequenceLookupService;
    this.lookupService = lookupService;
    this.lookupReferenceDataService = lookupReferenceDataService;
    this.viewFactory = viewFactory;
    this.statusService = statusService;
    this.requestSearchService = requestSearchService;
  }

  protected AttachmentService getAttachmentService() {
    return attachmentService;
  }

  protected void loadSecurityInfoFromHelper(UCCHelper helper) {
    getAttachmentService().loadSecurityInfoFromHelper(helper);
  }

  protected Long getSequence() {
    try {
      return new Long(sequenceLookupService.getSequence());
    } catch (GenericLookupBuilderException e) {
      Logger.log(new LoggableError(e));
      return null;
    }
  }

  private String getFilename(AttachmentMetadata meta, String requestId) {
    MimeTypeFactory mimeFactory = new MimeTypeFactory();
    String requestString = "SRWG_";
    if (requestId != null && requestId.length() > 0) {
      try {
        RequestProfile request = lookupService.lookupRequestById(new Long(requestId));
        requestString = request.getRequestNumber() + '_';
      } catch (LookupServiceException e) {
        // ignore exception, use default
      }
    }

    return mimeFactory.getFilename(requestString + meta.getDescription(),
        meta.getMimeType());
  }

  private void buildReferenceDataLists(UCCHelper helper, DocumentType docType) {
    if (lookupReferenceDataService != null) {
      List regionRefList = lookupReferenceDataService.getRegionRefList();
      List statusRefList = lookupReferenceDataService.getStatusRefList();
      List requestTypeRefList = lookupReferenceDataService.getRequestTypeRefList();

      helper.setRequestAttributeValue("regionRefList", regionRefList);
      helper.setRequestAttributeValue("statusRefList", statusRefList);
      helper.setRequestAttributeValue("requestTypeRefList", requestTypeRefList);
    }

    helper.setRequestAttributeValue(MainConstants.TEMPLATES_ATTRIBUTE_NAME,
        attachmentService.getTemplates(docType));
  }

  protected void logAndRenderErrorMessagesView(Exception e, UCCHelper helper) {
    if (Logger.isEnabled(Logger.ERROR_LOG)) {
      Logger.log(new LoggableError(e));
    }
    HttpRequestErrors errors = new HttpRequestErrors();
    errors.addError("exception", e.getMessage());
    helper.setRequestAttributeValue("errors", errors);
    View view = viewFactory.getErrorsView();
    view.renderView(helper);
  }

  public void saveAttachment(UCCHelper helper) throws IOException {
    Privilege[] allowedPrivs = getPrivsForAttach();
    DocumentType docType = getDocType();
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);

    Long requestId = NumberUtils.createLong(helper.getRequestParameterValue("requestId"));
    String description = helper.getRequestParameterValue("description");
    List files = helper.getClientFiles();
    if (requestId == null || requestId.longValue() == 0 || files == null || files.size() == 0) {
      notSpecified(helper);
    } else {
      //note: only one file is supported right now
      String filename = (String) files.get(0);
      AttachmentMetadata meta = new AttachmentMetadata();
      meta.setId(getSequence());
      meta.setDescription(description);
      meta.setName(filename);
      meta.setAttachmentTypeId(new Long(docType.getId()));
      meta.setMimeType(new MimeTypeFactory().getType(filename));
      meta.setRequestId(requestId);
      Attachment template = new FileAttachment(meta, new File(filename));
      try {
        getAttachmentService().addAttachment(template, helper.getAuthenticatedUserID());
      } catch (DocumentStorageException e) {
        logAndRenderErrorMessagesView(e, helper);
        return;
      }

      attachTemplate(helper);
    }
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, getPrivsForAttach());

    buildReferenceDataLists(helper, getDocType());
    RequestSearch requestSearch = new RequestSearch(getStatusCode());
    List searchResults = requestSearchService.getRequestListBySearchCriteria(requestSearch);
    helper.setRequestAttributeValue("requestSearch", requestSearch);
    helper.setRequestAttributeValue(MainConstants.SEARCH_RESULTS_ATTRIBUTE, searchResults);
    helper.setRequestAttributeValue("searchParameters", new SearchParameters(getSearchTitle(),
        false, true, false, getURLBaseForSearchResults()));
    View view = viewFactory.getSearchRequestProfileView();
    view.renderView(helper);
  }

  protected Long getStatusCode() {
    List statusRefList = lookupReferenceDataService.getStatusRefList();
    for (int i = 0; i < statusRefList.size(); i++) {
      ReferenceData statusRefData = (ReferenceData) statusRefList.get(i);
      if (getStatusDescription().equals(statusRefData.getDescription())) {
        return statusRefData.getId();
      }
    }

    return null;
  }

  protected void generate(UCCHelper helper, Attachment attachment, String requestId) throws IOException {
    AttachedFile attachedDoc;
    try {
      attachedDoc = attachment.getAttachedFile();
    } catch (DocumentRetrievalException e) {
      logAndRenderErrorMessagesView(e, helper);
      return;
    }
    AttachmentMetadata meta = attachment.getMetadata();
    String mimeType = meta.getMimeType();
    byte[] content = prepareContent(attachedDoc.getContent(), requestId);
    String filename = getFilename(meta, requestId);
    if (new MimeTypeFactory().isEditable(mimeType)) {
      try {
        Attachment attachmentInDb = generateInPlace(mimeType, filename, new Long(requestId), content,
            helper.getAuthenticatedUserID());
        displayEditForAttachment(helper, attachmentInDb);
      } catch (DocumentStorageException e) {
        logAndRenderErrorMessagesView(e, helper);
      }
    } else {
      outputRawFile(helper, mimeType, filename, content);
    }
  }

  private void displayEditForAttachment(UCCHelper helper, Attachment attachment) {
    try {
      helper.setRequestAttributeValue("metadata", attachment.getMetadata());
      new AttachmentViewer(viewFactory).view(helper, attachment);
    } catch (DocumentRetrievalException e) {
      logAndRenderErrorMessagesView(e, helper);
    }
  }

  private Attachment generateInPlace(String mimeType, String filename, Long requestId, byte[] content, String modUser)
      throws DocumentStorageException {
    AttachmentMetadata meta = new AttachmentMetadata();
    meta.setId(getSequence());
    meta.setDescription(filename);
    meta.setName(filename);
    meta.setAttachmentTypeId(new Long(getDocType().getId()));
    meta.setMimeType(mimeType);
    meta.setRequestId(requestId);
    Attachment generatedAttachment = new MemoryAttachment(meta, content);
    attachmentService.addAttachment(generatedAttachment, modUser);
    return generatedAttachment;
  }

  private void outputRawFile(UCCHelper helper, String mimeType, String filename,
                             byte[] content) throws IOException {
    helper.setContentType(mimeType);
    helper.setHeader("Content-disposition", "attachment; filename=" + filename);
    OutputStream output = helper.getBinaryStream();
    output.write(content);
    output.close();
  }

  protected byte[] prepareContent(byte[] content, String requestId) {
    SimpleSubstitutor substitutor = new SimpleSubstitutor();
    return substitutor.substitute(content, getParamsForSubstitution(requestId));
  }

  private Map getParamsForSubstitution(String requestIdString) {
    Long requestId;
    try {
      requestId = new Long(requestIdString);
    } catch (NumberFormatException e) {
      return new HashMap();
    }
    try {
      RequestProfile profile = lookupService.lookupRequestById(requestId);
      profile.setRequestResearchEntries(lookupService.lookupResearchRequestListByRequestId(requestId));
      Map params = new HashMap();
      DateFormat df = new SimpleDateFormat("MMMMM d, yyyy");
      params.put("entity", StringUtils.defaultString(profile.getEntity()));
      params.put("affiliation", StringUtils.defaultString(profile.getAffiliation()));
      params.put("requestorContactName", StringUtils.defaultString(profile.getRequestorContactName()));
      params.put("requestorTitle", StringUtils.defaultString(profile.getRequestorTitle()));
      params.put("requestDate", profile.getRequestDate() == null ? "" : df.format(profile.getRequestDate()));
      params.put("requestNumber", StringUtils.defaultString(profile.getRequestNumber()));
      addAddressToParams(params, "research", profile.getShipToAddress());
      addAddressToParams(params, "shipping", profile.getResearchAddress());
      params.put("today", df.format(new Date()));
      addMaterials(profile, params);
      return params;
    } catch (LookupServiceException e) {
      // not able to retreive the request they asked about, just don't do any substutions
      Logger.log(new LoggableError(e));
      return new HashMap();
    }
  }

  private void addAddressToParams(Map params, String addressType, AddressInfo address) {
    if (address != null) {
      params.put(addressType + "Address", translateNewlines(StringUtils.defaultString(address.toString())));
      params.put(addressType + "Phone", StringUtils.defaultString(address.getPhone()));
      params.put(addressType + "Fax", StringUtils.defaultString(address.getFax()));
      params.put(addressType + "Email", StringUtils.defaultString(address.getEmail()));
    } else {
      params.put(addressType + "Address", "");
      params.put(addressType + "Phone", "");
      params.put(addressType + "Fax", "");
      params.put(addressType + "Email", "");
    }
  }

  private void addMaterials(RequestProfile profile, Map params) {
    List researchEntries = profile.getRequestResearchEntries();
    StringBuffer materials = new StringBuffer();
    for (int i = 0; i < researchEntries.size(); i++) {
      RequestResearchType entry = (RequestResearchType) researchEntries.get(i);
      materials.append(entry.getResearchTypeName());
      materials.append(':');
      materials.append(entry.getDescription());
      materials.append("<br>\n");
    }
    params.put("materials", materials.toString());
  }

  public void generateAttachment(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, getPrivsForAttach());

    String requestId = helper.getRequestParameterValue("requestId");
    Long templateId = NumberUtils.createLong(helper.getRequestParameterValue("template"));

    if (requestId == null || templateId == null) {
      notSpecified(helper);
    } else {
      List templates = getAttachmentService().getTemplates(getDocType());
      for (int i = 0; i < templates.size(); i++) {
        Attachment attachment = (Attachment) templates.get(i);
        AttachmentMetadata meta = attachment.getMetadata();
        if (templateId.equals(meta.getId())) {
          generate(helper, attachment, requestId);
        }
      }
//      notSpecified(helper);
    }
  }

  protected RequestProfile getRequestFromHelper(UCCHelper helper) throws IOException, LookupServiceException {
    //todo should replace similar code that does this with a call to this methods
    String requestId = helper.getRequestParameterValue("requestId");
    return lookupService.lookupRequestById(new Long(requestId));
  }

  public void complete(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, getPrivsForAttach());

    String requestId = helper.getRequestParameterValue("requestId");
    if (requestId == null) {
      notSpecified(helper);
    } else {
      RequestProfile requestProfile = getRequestProfile(helper, requestId);
      if (requestProfile != null) {
        buildReferenceDataLists(helper, getDocType());
        updateStatusToComplete(statusService, requestProfile, helper.getAuthenticatedUserID());
        helper.setRequestAttributeValue(MainConstants.REQUEST_PROFILE_ATTRIBUTE_NAME, requestProfile);

        notSpecified(helper);
      }
    }
  }

  private RequestProfile getRequestProfile(UCCHelper helper, String requestId) {
    try {
      return lookupService.lookupRequestById(new Long(requestId));
    } catch (LookupServiceException e) {
      logAndRenderErrorMessagesView(e, helper);
      return null;
    }
  }

  public void saveTemplate(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, getPrivsForCreate());

    String description = helper.getRequestParameterValue("description");
    List files = helper.getClientFiles();
    if (files == null || files.size() == 0) {
      notSpecified(helper);
    } else {
      //note: only one file is supported right now
      String filename = (String) files.get(0);
      AttachmentMetadata meta = new AttachmentMetadata();
      meta.setId(getSequence());
      meta.setDescription(description);
      meta.setName(filename);
      meta.setAttachmentTypeId(new Long(getDocType().getId()));
      meta.setMimeType(new MimeTypeFactory().getType(filename));
      Attachment template = new FileAttachment(meta, new File(filename));
      try {
        getAttachmentService().addTemplate(template, helper.getAuthenticatedUserID());
      } catch (DocumentStorageException e) {
        logAndRenderErrorMessagesView(e, helper);
        return;
      }

      notSpecified(helper);
    }
  }


  public void createNewTemplate(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, getPrivsForCreate());

    View view = getCreateView(viewFactory);
    view.renderView(helper);
  }

  public void attachTemplate(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, getPrivsForAttach());

    String requestId = helper.getRequestParameterValue("requestId");
    if (requestId == null) {
      notSpecified(helper);
    } else {
      RequestProfile requestProfile = null;
      try {
        requestProfile = lookupService.lookupRequestById(new Long(requestId));
      } catch (LookupServiceException e) {
        logAndRenderErrorMessagesView(e, helper);
        return;
      }
      buildReferenceDataLists(helper, getDocType());
      helper.setRequestAttributeValue(MainConstants.REQUEST_PROFILE_ATTRIBUTE_NAME, requestProfile);
      helper.setRequestAttributeValue("requestId", requestId);
      List requestResearchList = lookupService.lookupResearchRequestListByRequestId(new Long(requestId));
      Map map = SearchUtils.buildHashMapFromList(requestResearchList);
      helper.setSessionParameter(MainConstants.HASH_RESEARCH_ATTRIBUTE_NAME, map);
      requestProfile.setRequestResearchEntries(requestResearchList);
      helper.setRequestAttributeValue(MainConstants.REQUEST_PROFILE_ATTRIBUTE_NAME, requestProfile);
      User user = ControllerSecurity.getCurrentUser(helper);
      AttachmentUtil.addAttachmentsToRequest(helper, attachmentService, NumberUtils.createLong(requestId), user);
      View view = getAttachView(viewFactory);
      view.renderView(helper);
    }
  }

  protected abstract View getCreateView(ViewFactory viewFactory);

  protected abstract void updateStatusToComplete(StatusUpdateService statusService, RequestProfile requestProfile,
                                                 String modUser);

  protected abstract String getStatusDescription();

  protected abstract View getAttachView(ViewFactory viewFactory);

  protected abstract DocumentType getDocType();

  protected abstract String getURLBaseForSearchResults();

  protected abstract Privilege[] getPrivsForCreate();

  protected abstract Privilege[] getPrivsForAttach();

  protected abstract String getSearchTitle();

  protected StatusUpdateService getStatusService() {
    return statusService;
  }

  protected void addSuccessMessageToHelper(UCCHelper helper, String msg) {
    HttpRequestMessages messages = new HttpRequestMessages();
    messages.addMessage(msg);
    helper.setRequestAttributeValue("messages", messages);
  }

  private String translateNewlines(String orig) {
    StringBuffer buf = new StringBuffer();
    for (int i = 0; i < orig.length(); i++) {
      char ch = orig.charAt(i);
      if (ch == '\n' || ch == '\r') {
        buf.append("<br>\n");
      } else {
        buf.append(ch);
      }
    }

    return buf.toString();
  }

}
