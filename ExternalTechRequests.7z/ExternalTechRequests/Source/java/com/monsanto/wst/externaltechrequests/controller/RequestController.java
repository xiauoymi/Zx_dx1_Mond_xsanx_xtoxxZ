/*
 RequestController was created on Nov 7, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.commonutils.DataTypeUtil;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.model.*;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.security.UserFactory;
import com.monsanto.wst.externaltechrequests.services.*;
import com.monsanto.wst.externaltechrequests.utils.search.SearchUtils;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateService;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.validator.HttpValidator;

import java.io.IOException;
import java.util.*;

/**
 * Filename:    $RCSfile: RequestController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date:
 * 2006/12/06 14:02:27 $
 *
 * @author ffbrac
 * @version $Revision: 1.54 $
 */
public class RequestController extends ETRAbstractDispatchController {
  //todo there are still several classes that should be identified and extracted from this over-large class
  private final RequestService requestService;
  private final LookupReferenceDataService lookupReferenceDataService;
  private final LookupService lookupService;
  private final AttachmentService attachmentService;
  private final HttpValidator validator;
  private final DataTypeUtil util = new DataTypeUtil();
  private final UserFactory userFactory;
  private final StatusUpdateService statusService;
  private static final String RESEARCH_TYPE_VARIABLE_PREFIX = "researchType_";
  private final RequestViewer requestViewer;


  public RequestController(RequestService requestService, LookupReferenceDataService lookupReferenceDataService,
                           LookupService lookupService, ViewFactory viewFactory, HttpValidator validator,
                           UserFactory userFactory, AttachmentService attachmentService,
                           StatusUpdateService statusService) {

    this.requestService = requestService;
    this.lookupReferenceDataService = lookupReferenceDataService;
    this.lookupService = lookupService;
    this.requestViewer = new RequestViewer(viewFactory);
    this.validator = validator;
    this.userFactory = userFactory;
    this.attachmentService = attachmentService;
    this.statusService = statusService;
  }

  private static final Privilege[] allowedPrivs = {
      Privilege.CREATE_ANY,
      Privilege.CREATE_OWN,
      Privilege.EDIT_OWN,
      Privilege.VIEW_ALL
  };

  protected void notSpecified(UCCHelper helper) throws IOException {
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);
    RequestProfile requestProfile = new RequestProfile();
    viewRequest(helper, requestProfile);
  }

  public void saveRequestProfile(UCCHelper helper) throws IOException {
    User currentUser = ControllerSecurity.getCurrentUser(helper);
    RequestProfile requestProfile = buildRequestProfileObject(helper);
    if (currentUser.canEdit(requestProfile)) {
      editRequest(helper, requestProfile);
    } else if (currentUser.canView(requestProfile)) {
      viewRequest(helper, requestProfile);
    } else {
      logAndRenderErrorMessagesView(new UnauthorizedActionException("Cannot view or edit this request"), helper);
    }
  }

  public void print(UCCHelper helper) throws IOException {
    String requestId = helper.getRequestParameterValue("requestId");
    if (StringUtils.isNullOrEmpty(requestId)) {
      notSpecified(helper);
    } else {
      try {
        RequestProfile requestProfile = lookupService.lookupRequestById(new Long(requestId));
        helper.setRequestAttributeValue("loadJavascript", "window.print(); window.close()");
        viewRequest(helper, requestProfile);
      } catch (LookupServiceException e) {
        logAndRenderErrorMessagesView(e, helper);
      }
    }
  }

  public void addResearchType(UCCHelper helper) throws IOException {
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);
    RequestProfile requestProfile = buildRequestProfileObject(helper);
    updateResearchTypeMap(helper);
    Map hashResearch = getResearchAccumulatorHashMapFromSession(helper);
    List requestResearchList = new ArrayList(hashResearch.values());
    requestProfile.setRequestResearchEntries(requestResearchList);
    helper.setRequestAttributeValue(MainConstants.REQUEST_PROFILE_ATTRIBUTE_NAME, requestProfile);
    renderRequestView(helper, requestProfile);
  }

  public void committeeHistoryDisplay(UCCHelper helper) throws IOException {
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);
    String requestId = helper.getRequestParameterValue("requestId");
    List statusList;
    statusList = lookupService
        .lookupCommitteApprovedRequestListByRequestId(util.convertStringToLongIgnoreNumberFormatException(requestId));
    helper.setRequestAttributeValue("historyList", statusList);
    requestViewer.renderHistoryView(helper);
  }

  public void statusHistoryDisplay(UCCHelper helper) throws IOException {
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);
    String requestId = helper.getRequestParameterValue("requestId");
    List statusList = lookupService
        .lookupStatusRequestListByRequestId(util.convertStringToLongIgnoreNumberFormatException(requestId));
    helper.setRequestAttributeValue("historyList", statusList);
    requestViewer.renderHistoryView(helper);
  }

  public void deleteResearchType(UCCHelper helper) throws IOException {
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);
    Map researchTypeMap = updateResearchTypeMap(helper);
    RequestProfile requestProfile = buildRequestProfileObject(helper);
    requestProfile.setRequestResearchEntries(new ArrayList(researchTypeMap.values()));

    helper.setRequestAttributeValue(MainConstants.REQUEST_PROFILE_ATTRIBUTE_NAME, requestProfile);
    renderRequestView(helper, requestProfile);
  }

  private Map updateResearchTypeMap(UCCHelper helper) throws IOException {
    String id = helper.getRequestParameterValue("deleteItem");
    Map updatedTypeMap = new HashMap();
    Enumeration paramEnumerator = helper.getParameterNames();
    while (paramEnumerator.hasMoreElements()) {
      String paramName = (String) paramEnumerator.nextElement();
      if (paramName.startsWith(RESEARCH_TYPE_VARIABLE_PREFIX)) {
        String index = paramName.substring(RESEARCH_TYPE_VARIABLE_PREFIX.length());
        if (!index.equals(id)) {
          String typeString = helper.getRequestParameterValue(paramName);
          String description = helper.getRequestParameterValue("researchDescription_" + index);

          addResearchToMap(updatedTypeMap, index, typeString, description);
        }
      }
    }

    String typeString = helper.getRequestParameterValue("requestResearch_new");
    String description = helper.getRequestParameterValue("researchDescription_new");
    if (!StringUtils.isNullOrEmpty(typeString) && !StringUtils.isNullOrEmpty(description)) {
      addResearchToMap(updatedTypeMap, Integer.toString(updatedTypeMap.size() + 1), typeString, description);
    }

    helper.setSessionParameter(MainConstants.HASH_RESEARCH_ATTRIBUTE_NAME, updatedTypeMap);
    return updatedTypeMap;
  }

  private void addResearchToMap(Map updatedTypeMap, String index, String typeString, String description
  ) {
    RequestResearchType researchType = new RequestResearchType();
    researchType.setDescription(description);
    researchType.setResearchTypeId(new Long(typeString));
    updatedTypeMap.put(new Long(index), researchType);
  }

  public void editRequestEntry(UCCHelper helper) throws IOException {
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);
    String requestId = helper.getRequestParameterValue("requestId");
    Long requestIdValue = new Long(requestId);
    RequestProfile requestProfile = null;
    try {
      requestProfile = lookupService.lookupRequestById(requestIdValue);
    } catch (LookupServiceException e) {
      logAndRenderErrorMessagesView(e, helper);
      return;
    }
    List requestResearchList = lookupService.lookupResearchRequestListByRequestId(new Long(requestId));
    Map map = SearchUtils.buildHashMapFromList(requestResearchList);
    helper.setSessionParameter(MainConstants.HASH_RESEARCH_ATTRIBUTE_NAME, map);
    requestProfile.setRequestResearchEntries(requestResearchList);
    helper.setRequestAttributeValue(MainConstants.REQUEST_PROFILE_ATTRIBUTE_NAME, requestProfile);
    User user = ControllerSecurity.getCurrentUser(helper);
    AttachmentUtil.addAttachmentsToRequest(helper, attachmentService, requestIdValue, user);
    renderRequestView(helper, requestProfile);
  }

  private void editRequest(UCCHelper helper, RequestProfile requestProfile) throws IOException {
    Map researchTypeMap = updateResearchTypeMap(helper);
    requestProfile.setRequestResearchEntries(new ArrayList(researchTypeMap.values()));
    HttpRequestErrors errors = validator.validate(helper);
    if (errors.isEmpty()) {
      String actionPerformed = null;
      try {
        actionPerformed = saveOrUpdateRequestProfile(requestProfile, helper);
      } catch (LookupServiceException e) {
        logAndRenderErrorMessagesView(e, helper);
      }
      renderOperationSuccessfulView(actionPerformed, helper, requestProfile);
    } else {
      renderValidationErrorsView(helper, errors, requestProfile);
    }
  }

  private void viewRequest(UCCHelper helper, RequestProfile requestProfile) throws IOException {
    buildReferenceDataLists(helper);
    helper.setRequestAttributeValue(MainConstants.REQUEST_PROFILE_ATTRIBUTE_NAME, requestProfile);
    List requestResearchList = lookupService.lookupResearchRequestListByRequestId(requestProfile.getId());
    Map map = SearchUtils.buildHashMapFromList(requestResearchList);
    helper.setSessionParameter(MainConstants.HASH_RESEARCH_ATTRIBUTE_NAME, map);
    requestProfile.setRequestResearchEntries(requestResearchList);
    helper.setRequestAttributeValue(MainConstants.REQUEST_PROFILE_ATTRIBUTE_NAME, requestProfile);

    requestViewer.renderView(helper, requestProfile);
  }


  private String saveOrUpdateRequestProfile(RequestProfile requestProfile, UCCHelper helper) throws
      LookupServiceException {
    String actionPerformed = insertOrUpdateRequestProfile(requestProfile, helper);
    helper.setRequestAttributeValue(MainConstants.REQUEST_PROFILE_ATTRIBUTE_NAME, requestProfile);
    return actionPerformed;
  }

  private void renderOperationSuccessfulView(String action, UCCHelper helper, RequestProfile requestProfile) throws
      IOException {
    addSuccessMessageToHelper(action, helper, requestProfile);
    renderRequestView(helper, requestProfile);
  }

  private String insertOrUpdateRequestProfile(RequestProfile requestProfile, UCCHelper helper) throws
      LookupServiceException {
    Long id;
    String action;
    if (requestProfile.hasBeenSaved()) {
      id = updateRequestProfile(requestProfile, helper);
      action = "updated.";
    } else {
      id = insertRequestProfileObject(requestProfile, helper);
      action = "entered.";
    }
    insertRequestResearchLists(helper, id);
    return action;
  }

  private void addSuccessMessageToHelper(String action, UCCHelper helper, RequestProfile profile) {
    HttpRequestMessages messages = new HttpRequestMessages();
    messages.addMessage("Request # " + profile.getRequestNumber() + " has been successfully " + action);
    helper.setRequestAttributeValue("messages", messages);
  }

  private void renderValidationErrorsView(UCCHelper helper, HttpRequestErrors errors, RequestProfile requestProfile)
      throws IOException {
    helper.setRequestAttributeValue("errors", errors);
    helper.setRequestAttributeValue(MainConstants.REQUEST_PROFILE_ATTRIBUTE_NAME, requestProfile);
    renderRequestView(helper, requestProfile);
  }

  private Long updateRequestProfile(RequestProfile requestProfile, UCCHelper helper) {
    Long id = requestProfile.getId();
    requestProfile.setModUser(getLoginUserId(helper));
    this.requestService.updateRequestProfile(requestProfile);
    this.requestService.updateAddressInfo(requestProfile.getShipToAddress());
    this.requestService.updateAddressInfo(requestProfile.getResearchAddress());
    this.requestService.deleteRequestResearch(id);

    return id;
  }

  private Long insertRequestProfileObject(RequestProfile requestProfile, UCCHelper helper) throws
      LookupServiceException {
    requestProfile.getShipToAddress().setId(lookupService.lookupNextRequestSeq());
    this.requestService.insertAddress(requestProfile.getShipToAddress());
    requestProfile.getResearchAddress().setId(lookupService.lookupNextRequestSeq());
    this.requestService.insertAddress(requestProfile.getResearchAddress());
    requestProfile.setId(this.lookupService.lookupNextRequestSeq());
    requestProfile.setRequestNumber(lookupService.lookupNextRequestGenNumber());
    requestProfile.setModUser(getLoginUserId(helper));
    Long requestId = this.requestService.insertRequestProfile(requestProfile);
    statusService.newRequest(requestProfile, helper.getAuthenticatedUserID());
    return requestId;
  }

  private void insertRequestResearchLists(UCCHelper helper, Long id) throws LookupServiceException {
    Map hashMap = getResearchAccumulatorHashMapFromSession(helper);
    List requestResearchList = new ArrayList(hashMap.values());
    Map newEntriesHash = new HashMap();
    for (int i = 0; i < requestResearchList.size(); i++) {
      RequestResearchType researchEntry = (RequestResearchType) requestResearchList.get(i);
      researchEntry.setId(lookupService.lookupNextRequestSeq());
      researchEntry.setRequestId(id);
      researchEntry.setModUser(getLoginUserId(helper));
      newEntriesHash.put(researchEntry.getId(), researchEntry);
      requestService.insertRequestResearch(researchEntry);
    }
    helper.setSessionParameter(MainConstants.HASH_RESEARCH_ATTRIBUTE_NAME, newEntriesHash);
  }

  private synchronized Map getResearchAccumulatorHashMapFromSession(UCCHelper helper) {
    Map researchAccumulator = (Map) helper.getSessionParameter(MainConstants.HASH_RESEARCH_ATTRIBUTE_NAME);
    if (researchAccumulator == null) {
      researchAccumulator = new HashMap();
      helper.setSessionParameter(MainConstants.HASH_RESEARCH_ATTRIBUTE_NAME, researchAccumulator);
    }
    return researchAccumulator;
  }

  private void logAndRenderErrorMessagesView(Exception e, UCCHelper helper) {
    if (Logger.isEnabled(Logger.ERROR_LOG)) {
      Logger.log(new LoggableError(e));
    }
    HttpRequestErrors errors = new HttpRequestErrors();
    errors.addError("exception", e.getMessage());
    helper.setRequestAttributeValue("errors", errors);
    requestViewer.renderErrorView(helper);
  }

  private void buildReferenceDataLists(UCCHelper helper) {
    List researchTypeRefList = lookupReferenceDataService.getResearchTypeRefList();

    helper.setRequestAttributeValue("regionRefList", lookupReferenceDataService.getRegionRefList());
    helper.setRequestAttributeValue("committeeRefList", lookupReferenceDataService.getCommitteeApprovalRefList());
    helper.setRequestAttributeValue("statusRefList", lookupReferenceDataService.getStatusRefList());
    helper.setRequestAttributeValue("studyLengthRefList", lookupReferenceDataService.getStudyLengthTypeRefList());
    helper.setRequestAttributeValue("requestTypeRefList", lookupReferenceDataService.getRequestTypeRefList());
    helper.setRequestAttributeValue("researchTypeRefList", researchTypeRefList);
    helper.setRequestAttributeValue("states", lookupReferenceDataService.getStates());
    helper.setRequestAttributeValue("users", sortUsers(getUserList()));
    helper.setRequestAttributeValue("sponsors", sortUsers(getSponsorList()));
  }

  private List sortUsers(List userList) {
    List tempList = new ArrayList(userList);
    Collections.sort(tempList, new UserFullNameComparator());
    return tempList;
  }

  private List getUserList() {
    //todo merge this with a similar method in UserAdminController
    List userRefData = userFactory.getAllUsers();
    List userList = new ArrayList(userRefData.size());
    for (int i = 0; i < userRefData.size(); i++) {
      User user = (User) userRefData.get(i);
      userList.add(new DisplayUser(user.getUserId(), user.getFullName(), user.getEmail(), ""));
    }
    return userList;
  }

  private List getSponsorList() {
    //todo merge this with a similar method in UserAdminController and above
    List userRefData = userFactory.getAllSponsors();
    List userList = new ArrayList(userRefData.size());
    for (int i = 0; i < userRefData.size(); i++) {
      User user = (User) userRefData.get(i);
      userList.add(new DisplayUser(user.getUserId(), user.getFullName(), user.getEmail(), ""));
    }
    return userList;
  }

  private RequestResearchType buildRequestResearchType(UCCHelper helper, Long tempId) throws IOException {
    RequestResearchType researchType = new RequestResearchType();
    researchType.setId(tempId);
    buildRequestResearchObject(helper, researchType);
    return researchType;
  }

  private void buildRequestResearchObject(UCCHelper helper, RequestResearchType researchType) throws
      IOException {
    String typeId = helper.getRequestParameterValue(MainConstants.REQUEST_RESEARCH_PARAM_NAME);
    researchType.setResearchTypeId(new Long(typeId));
    researchType.setDescription(helper.getRequestParameterValue(MainConstants.RESEARCH_DESC_PARAM_NAME));
  }

  private void renderRequestView(UCCHelper helper, RequestProfile requestProfile) throws IOException {
    buildReferenceDataLists(helper);
    requestViewer.renderView(helper, requestProfile);
  }

  private String getLoginUserId(UCCHelper helper) {
    return ((User) helper.getSessionParameter(MainConstants.LOGINUSER)).getUserId();
  }

  private RequestProfile buildRequestProfileObject(UCCHelper helper) throws IOException {
    return new RequestProfileBuilder().buildRequestProfileObject(helper);
  }

}