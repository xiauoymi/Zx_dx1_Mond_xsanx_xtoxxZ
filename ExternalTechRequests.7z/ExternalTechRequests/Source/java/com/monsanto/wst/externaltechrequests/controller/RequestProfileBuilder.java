package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.wst.commonutils.DataTypeUtil;
import com.monsanto.wst.externaltechrequests.model.*;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;

import java.io.IOException;
/*
 RequestProfileBuilder was created on Mar 29, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
*/
public class RequestProfileBuilder {
  private final DataTypeUtil util = new DataTypeUtil();

  public RequestProfile buildRequestProfileObject(UCCHelper helper) throws IOException {
    RequestProfile requestProfile = new RequestProfile();
    requestProfile
        .setId(util.convertStringToLongIgnoreNumberFormatException(
            helper.getRequestParameterValue(MainConstants.REQUEST_ID_PARAM_NAME)));
    requestProfile.setAffiliation(helper.getRequestParameterValue(MainConstants.AFFILIATION_PARAM_NAME));
    requestProfile.setRequestNumber(helper.getRequestParameterValue(MainConstants.REQUEST_NUMBER_PARAM_NAME));
    requestProfile.setRequestorContactName(helper.getRequestParameterValue(MainConstants.REQUESTOR_NAME_PARAM_NAME));
    requestProfile.setRequestorTitle(helper.getRequestParameterValue(MainConstants.REQUESTOR_TITLE_PARAM_NAME));
    requestProfile.setSponsor(helper.getRequestParameterValue(MainConstants.SPONSOR_PARAM_NAME));
    requestProfile.setRegion(getRegionRefDataFromHelper(helper, MainConstants.REGION_PARAM_NAME, "")); //todo description
    requestProfile.setRequestDateAsString(helper.getRequestParameterValue(MainConstants.DATE_REQUESTED_PARAM_NAME));
    requestProfile.setNeededDateAsString(helper.getRequestParameterValue(MainConstants.DATE_NEEDEDBY_PARAM_NAME));
    requestProfile.setRequestType(getRequestTypeRefDataFromHelper(helper, MainConstants.REQUEST_TYPE_PARAM_NAME, "")); //todo description
    requestProfile.setPurpose(helper.getRequestParameterValue(MainConstants.PURPOSE_PARAM_NAME));
    requestProfile.setCommitteeApproved(getApprovalRefDataFromHelper(helper, MainConstants.COMMITTEE_APPROVED_PARAM_NAME, "")); //todo description
    requestProfile.setStatus(getStatusRefDataFromHelper(helper, MainConstants.STATUS_PARAM_NAME, "")); //todo description
    requestProfile.setStudyLength(getStudyRefDataFromHelper(helper, MainConstants.STUDY_LENGTH_PARAM_NAME, "")); //todo description

    requestProfile
        .setCommitteeApprovedComments(helper.getRequestParameterValue(MainConstants.COMMITTEE_COMMENTS_PARAM_NAME));
    requestProfile.setStatusComments(helper.getRequestParameterValue(MainConstants.STATUS_COMMENTS_PARAM_NAME));
    requestProfile.setFcpaFlag(helper.getRequestParameterValue(MainConstants.FCPA_BOX_PARAM_NAME));

    AddressInfo shipToAddress = buildAddressInfoObject(helper, MainConstants.SHIPTO_PARAM_NAME);
    AddressInfo researchAddress = buildAddressInfoObject(helper, MainConstants.RESEARCH_PARAM_NAME);

    requestProfile.setShipToAddress(shipToAddress);
    requestProfile.setResearchAddress(researchAddress);
    return requestProfile;
  }

  private AddressInfo buildAddressInfoObject(UCCHelper helper, String prefix) throws IOException {
    AddressInfo address = new AddressInfo();
    String addressId = helper.getRequestParameterValue(prefix + "_address_id");
    if (addressId != null && !StringUtils.isEmpty(addressId)) {
      address.setId(new Long(addressId));
    }

    address.setStreetOne(helper.getRequestParameterValue(prefix + "_address_street_one"));
    address.setStreetTwo(helper.getRequestParameterValue(prefix + "_address_street_two"));
    address.setCity(helper.getRequestParameterValue(prefix + "_address_city"));
    address.setState(helper.getRequestParameterValue(prefix + "_address_state"));
    address.setZipCode(helper.getRequestParameterValue(prefix + "_address_zip"));
    address.setCountry(helper.getRequestParameterValue(prefix + "_address_country"));
    address.setPhone(helper.getRequestParameterValue(prefix + "_address_phone"));
    address.setFax(helper.getRequestParameterValue(prefix + "_address_fax"));
    address.setEmail(helper.getRequestParameterValue(prefix + "_address_email"));
    return address;
  }

  private RegionReferenceData getRegionRefDataFromHelper(UCCHelper helper, String idParam, String descParam) throws IOException {
    Long id = util.convertStringToLongIgnoreNumberFormatException(helper.getRequestParameterValue(idParam));
    String desc = helper.getRequestParameterValue(descParam);
    return new RegionReferenceData(id, desc);
  }

  private RequestTypeReferenceData getRequestTypeRefDataFromHelper(UCCHelper helper, String idParam, String descParam) throws IOException {
    Long id = util.convertStringToLongIgnoreNumberFormatException(helper.getRequestParameterValue(idParam));
    String desc = helper.getRequestParameterValue(descParam);
    return new RequestTypeReferenceData(id, desc);
  }

  private ApprovalReferenceData getApprovalRefDataFromHelper(UCCHelper helper, String idParam, String descParam) throws IOException {
    Long id = util.convertStringToLongIgnoreNumberFormatException(helper.getRequestParameterValue(idParam));
    String desc = helper.getRequestParameterValue(descParam);
    return new ApprovalReferenceData(id, desc);
  }

  private StudyReferenceData getStudyRefDataFromHelper(UCCHelper helper, String idParam, String descParam) throws IOException {
    Long id = util.convertStringToLongIgnoreNumberFormatException(helper.getRequestParameterValue(idParam));
    String desc = helper.getRequestParameterValue(descParam);
    return new StudyReferenceData(id, desc);
  }

  private StatusReferenceData getStatusRefDataFromHelper(UCCHelper helper, String idParam, String descParam) throws IOException {
    Long id = util.convertStringToLongIgnoreNumberFormatException(helper.getRequestParameterValue(idParam));
    String desc = helper.getRequestParameterValue(descParam);
    return new StatusReferenceData(id, desc);
  }
}
