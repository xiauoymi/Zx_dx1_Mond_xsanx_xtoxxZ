package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
/*
 RequestReview was created on Feb 8, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class RequestReview {
  private final RequestProfile request;
  private final String comment;

  public RequestReview(RequestProfile request, String comment) {
    this.request = request;
    this.comment = comment;
  }

  public RequestProfile getRequest() {
    return request;
  }

  public String getComment() {
    return comment;
  }
}
