package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.view.View;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;

import java.io.IOException;
/*
 RequestViewer was created on Mar 29, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
*/
public class RequestViewer {
  private final ViewFactory viewFactory;

  private static final Privilege[] createPrivs = {
      Privilege.CREATE_ANY,
      Privilege.CREATE_OWN
  };

  public RequestViewer(ViewFactory viewFactory) {
    this.viewFactory = viewFactory;
  }

  public void renderView(UCCHelper helper, RequestProfile requestProfile) throws IOException {
    View view = getViewForUser(helper, requestProfile);
    view.renderView(helper);
  }

  public void renderHistoryView(UCCHelper helper) {
    View view = viewFactory.getDisplayHistoryView();
    view.renderView(helper);
  }

  public void renderErrorView(UCCHelper helper) {
    View view = viewFactory.getErrorsView();
    view.renderView(helper);
  }

  private View getViewForUser(UCCHelper helper, RequestProfile requestProfile) throws IOException {
    User user = ControllerSecurity.getCurrentUser(helper);
    if (arePrinting(helper)) {
      return viewFactory.getReadonlyRequestView();
    } else if (user.canEdit(requestProfile)) {
      return viewFactory.getRequestView();
    } else if (user.canView(requestProfile)) {
      return viewFactory.getReadonlyRequestView();
    } else if (requestProfile.getId() == null) {
      ControllerSecurity.verifyUserIsAuthorized(helper, createPrivs);
      return viewFactory.getRequestView();
    } else {
      logUnableToViewRequestErrorToErrorList(requestProfile, helper);
      return viewFactory.getErrorsView();
    }
  }

  private boolean arePrinting(UCCHelper helper) throws IOException {
    return "print".equals(helper.getRequestParameterValue("method"));
  }

  private void logUnableToViewRequestErrorToErrorList(RequestProfile requestProfile, UCCHelper helper) {
    String msg = "Unable to view request: " + requestProfile.getId();
    if (Logger.isEnabled(Logger.ERROR_LOG)) {
      Logger.log(new LoggableError(msg));
    }
    HttpRequestErrors errors = new HttpRequestErrors();
    errors.addError("exception", msg);
    helper.setRequestAttributeValue("errors", errors);
  }
}
