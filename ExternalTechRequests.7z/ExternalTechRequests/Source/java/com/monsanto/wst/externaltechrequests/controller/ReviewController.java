package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
import com.monsanto.wst.externaltechrequests.services.LookupService;
import com.monsanto.wst.externaltechrequests.services.LookupServiceException;
import com.monsanto.wst.externaltechrequests.services.RequestSearchService;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.workflow.EmailException;
import com.monsanto.wst.externaltechrequests.workflow.RequestEmailer;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateService;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.view.View;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/*
 ReviewController was created on Feb 7, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class ReviewController extends ETRAbstractDispatchController {
  private static final Privilege[] allowedPrivs = {Privilege.REVIEW};

  private final RequestSearchService requestSearchService;
  private final ViewFactory viewFactory;
  private final StatusUpdateService statusService;
  private final LookupService lookupService;
  private final RequestEmailer requestEmailer;
  private final AttachmentService attachmentService;

  public ReviewController(RequestSearchService requestSearchService, ViewFactory viewFactory,
                          StatusUpdateService statusService, LookupService lookupService,
                          RequestEmailer requestEmailer,
                          AttachmentService attachmentService) {
    this.requestSearchService = requestSearchService;
    this.viewFactory = viewFactory;
    this.statusService = statusService;
    this.lookupService = lookupService;
    this.requestEmailer = requestEmailer;
    this.attachmentService = attachmentService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);

    List requests = requestSearchService.getRequestListBySearchCriteria(getSearchCriteria());
    helper.setRequestAttributeValue(MainConstants.SEARCH_RESULTS_ATTRIBUTE, requests);
    SearchParameters searchParams = new SearchParameters("Requests for Review", false, true, false,
        SearchRequestController.VIEW_REQUEST_URL);
    helper.setRequestAttributeValue(MainConstants.SEARCH_PARAMETERS_ATTRIBUTE, searchParams);

    View view = viewFactory.getReviewView();
    view.renderView(helper);
  }

  public void committeeReport(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);
    String[] requestIds = helper.getRequestParameterValues("requestIds");
    try {
      if (requestIds != null) {
        List requests = new ArrayList();
        for (int i = 0; i < requestIds.length; i++) {
          requests.add(processRequest(requestIds[i], helper.getAuthenticatedUserID()));
        }
        RequestProfile[] requestProfiles = (RequestProfile[]) requests.toArray(new RequestProfile[requests.size()]);

        requestEmailer.sendRequests("Requests Sent To SRWG Review Committee", requestProfiles, attachmentService);
      }

      addSuccessMessageToHelper(helper, "Requests were sent to SRWG Review Committee");

      notSpecified(helper);
    } catch (LookupServiceException e) {
      logAndRenderErrorMessagesView(e, helper);
    } catch (EmailException e) {
      logAndRenderErrorMessagesView(e, helper);
    }
  }

  protected void loadSecurityInfoFromHelper(UCCHelper helper) {
    attachmentService.loadSecurityInfoFromHelper(helper);
  }

  private void addSuccessMessageToHelper(UCCHelper helper, String msg) {
    HttpRequestMessages messages = new HttpRequestMessages();
    messages.addMessage(msg);
    helper.setRequestAttributeValue("messages", messages);
  }

  private RequestProfile processRequest(String requestId, String modUser) throws LookupServiceException {
    RequestProfile request = lookupService.lookupRequestById(new Long(requestId));
    statusService.sentToCommittee(request, modUser);
    return request;
  }

  private void logAndRenderErrorMessagesView(Exception e, UCCHelper helper) {
    if (Logger.isEnabled(Logger.ERROR_LOG)) {
      Logger.log(new LoggableError(e));
    }
    HttpRequestErrors errors = new HttpRequestErrors();
    errors.addError("exception", e.getMessage());
    helper.setRequestAttributeValue("errors", errors);
    View view = viewFactory.getErrorsView();
    view.renderView(helper);
  }

  private RequestSearch getSearchCriteria() {
    return new RequestSearch(MainConstants.STATUS_ID_NEW);
  }
}
