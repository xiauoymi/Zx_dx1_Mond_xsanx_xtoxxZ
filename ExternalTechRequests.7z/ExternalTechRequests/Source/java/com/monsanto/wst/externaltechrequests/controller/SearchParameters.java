package com.monsanto.wst.externaltechrequests.controller;
/*
 SearchParameters was created on Jan 24, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class SearchParameters {
  private final String title;
  private final boolean showCriteria;
  private final boolean showResults;
  private final boolean showExport;
  private final String baseUrl;

  public SearchParameters(String title,
                          boolean showCriteria, boolean showResults, boolean showExport,
                          String baseUrl) {
    this.title = title;
    this.showCriteria = showCriteria;
    this.showResults = showResults;
    this.showExport = showExport;
    this.baseUrl = baseUrl;
  }

  public String getTitle() {
    return title;
  }

  public boolean isCriteriaShown() {
    return showCriteria;
  }

  public boolean isResultsShown() {
    return showResults;
  }

  public boolean isExportShown() {
    return showExport;
  }

  public String getBaseUrl() {
    return baseUrl;
  }
}
