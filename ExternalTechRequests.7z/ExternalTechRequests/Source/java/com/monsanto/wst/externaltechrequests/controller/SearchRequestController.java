/*
 SearchRequestController was created on Nov 10, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.services.LookupReferenceDataService;
import com.monsanto.wst.externaltechrequests.services.RequestSearchService;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpValidator;
import com.monsanto.wst.view.View;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: SearchRequestController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-03-21 18:29:24 $
 *
 * @author ffbrac
 * @version $Revision: 1.22 $
 */
public class SearchRequestController extends ETRAbstractDispatchController {
  private final LookupReferenceDataService lookupReferenceDataService;
  private final RequestSearchService requestSearchService;
  private final HttpValidator validator;
  private final ViewFactory viewFactory;
  public static final String VIEW_REQUEST_URL = "/srwgrequesttracking/servlet/new_request.html?method=editRequestEntry";

  public SearchRequestController(LookupReferenceDataService lookupReferenceDataService,
                                 RequestSearchService requestSearchService,
                                 HttpValidator validator,
                                 ViewFactory viewFactory) {
    this.lookupReferenceDataService = lookupReferenceDataService;
    this.requestSearchService = requestSearchService;
    this.validator = validator;
    this.viewFactory = viewFactory;
  }

  private static final Privilege[] allowedPrivs = {
      Privilege.VIEW_ALL,
      Privilege.EDIT_OWN,
      Privilege.ATTACH_LEGAL,
      Privilege.ATTACH_SHIPPING,
      Privilege.REVIEW
  };

  protected void notSpecified(UCCHelper helper) throws IOException {
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);
    buildReferenceDataLists(helper);
    List searchResults = requestSearchService.getRequestListBySearchCriteria(new RequestSearch());
    helper.setRequestAttributeValue("requestSearch", new RequestSearch());
    helper.setRequestAttributeValue("searchResults", searchResults);
    helper
        .setRequestAttributeValue(MainConstants.SEARCH_PARAMETERS_ATTRIBUTE, new SearchParameters("Search for Request",
            true, false, false, VIEW_REQUEST_URL));
    View view = viewFactory.getSearchRequestProfileView();
    view.renderView(helper);
  }

  public void exportToExcel(UCCHelper helper) throws IOException {
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);
    buildReferenceDataLists(helper);
    RequestSearch requestSearch = buildSearchData(helper);
    List searchResults = requestSearchService.getRequestListBySearchCriteria(requestSearch);
    Map beans = new HashMap();
    beans.put("searchResults", searchResults);
    XLSTransformer transformer = new XLSTransformer();
    InputStream templateXLS = this.getClass().getResourceAsStream("SearchResults.xls");
    HSSFWorkbook resultXLS = transformer.transformXLS(templateXLS, beans);
    helper.setHeader("Content-Disposition", "attachment;filename=\"SRWGSearchResults.xls\"");
    helper.setContentType("application/vnd.ms-excel");
    resultXLS.write(helper.getBinaryStream());
  }

  private void buildReferenceDataLists(UCCHelper helper) {
    List regionRefList = lookupReferenceDataService.getRegionRefList();
    List statusRefList = lookupReferenceDataService.getStatusRefList();
    List requestTypeRefList = lookupReferenceDataService.getRequestTypeRefList();

    helper.setRequestAttributeValue("regionRefList", regionRefList);
    helper.setRequestAttributeValue("statusRefList", statusRefList);
    helper.setRequestAttributeValue("requestTypeRefList", requestTypeRefList);
  }

  public void searchForRequestProfile(UCCHelper helper) throws IOException {
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);
    HttpRequestErrors errors = validator.validate(helper);
    if (errors.isEmpty()) {
      showSearchResults(helper);
    } else {
      helper.setRequestAttributeValue("errors", errors);
      showErrors(helper);
    }
  }

  private void showSearchResults(UCCHelper helper) throws IOException {
    buildReferenceDataLists(helper);
    RequestSearch requestSearch = buildSearchData(helper);
    List searchResults = requestSearchService.getRequestListBySearchCriteria(requestSearch);
    helper.setRequestAttributeValue("requestSearch", requestSearch);
    helper.setRequestAttributeValue("searchResults", searchResults);
    helper.setRequestAttributeValue(MainConstants.SEARCH_PARAMETERS_ATTRIBUTE,
        new SearchParameters("Search Results", true, true, true,
            VIEW_REQUEST_URL));
    View view = viewFactory.getSearchRequestProfileView();
    view.renderView(helper);
  }

  private void showErrors(UCCHelper helper) throws IOException {
    buildReferenceDataLists(helper);
    RequestSearch requestSearch = buildSearchData(helper);
    helper.setRequestAttributeValue("requestSearch", requestSearch);
    helper.setRequestAttributeValue("searchResults", new ArrayList());
    View view = viewFactory.getSearchRequestProfileView();
    view.renderView(helper);
  }

  private RequestSearch buildSearchData(UCCHelper helper) throws IOException {
    String requestNumber = helper.getRequestParameterValue("request_number");
    String requestorName = helper.getRequestParameterValue("requestor_name");
    String sponsor = StringUtils.toUpperCaseNull(helper.getRequestParameterValue("sponsor"));
    Long region = getLongFromHelper(helper, "region");
    Long requestType = getLongFromHelper(helper, "request_type");
    Long status = getLongFromHelper(helper, "status");
    String description = helper.getRequestParameterValue("description");
    String affiliation = helper.getRequestParameterValue("affiliation");
    String purpose = helper.getRequestParameterValue("purpose");
    String startDate = helper.getRequestParameterValue("start_date");
    String endDate = helper.getRequestParameterValue("end_date");
    String committeeStartDate = helper.getRequestParameterValue("committee_start_date");
    String committeeEndDate = helper.getRequestParameterValue("committee_end_date");

    return new RequestSearch(requestNumber, requestorName, sponsor,
        region, requestType, status, description, affiliation, purpose, startDate, endDate,
        committeeStartDate, committeeEndDate);
  }

  private Long getLongFromHelper(UCCHelper helper, String paramName) throws IOException {
    String paramValue = helper.getRequestParameterValue(paramName);
    if (paramValue == null || paramValue.length() == 0) {
      return null;
    } else {
      return NumberUtils.createLong(paramValue);
    }
  }
}