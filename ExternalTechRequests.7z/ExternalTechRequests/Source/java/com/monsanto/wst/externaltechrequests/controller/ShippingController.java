package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.wst.administerreferencedata.services.SequenceLookupService;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
import com.monsanto.wst.externaltechrequests.services.LookupReferenceDataService;
import com.monsanto.wst.externaltechrequests.services.LookupService;
import com.monsanto.wst.externaltechrequests.services.RequestSearchService;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateService;
import com.monsanto.wst.view.View;
/*
 ShippingController was created on Feb 5, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class ShippingController extends RequestAttachmentAbstractController {
  public static final String SHIPPING_URL = "/srwgrequesttracking/servlet/shipping.html?method=attachTemplate";
  private static final String SHIPPING_STATUS_DESCRIPTION = "Ready To Ship";

  public ShippingController(StatusUpdateService statusService, LookupReferenceDataService lookupReferenceDataService,
                         RequestSearchService requestSearchService, LookupService lookupService,
                         ViewFactory viewFactory,
                         AttachmentService attachmentService, SequenceLookupService sequenceLookupService) {
    super(attachmentService, sequenceLookupService, lookupService, lookupReferenceDataService, viewFactory,
        statusService, requestSearchService);
  }

  protected DocumentType getDocType() {
    return DocumentType.SHIPPING;
  }

  protected Privilege[] getPrivsForCreate() {
    return new Privilege[]{Privilege.CREATE_SHIPPING};
  }

  protected String getURLBaseForSearchResults() {
    return SHIPPING_URL;
  }

  protected Privilege[] getPrivsForAttach() {
    return new Privilege[]{Privilege.ATTACH_SHIPPING};
  }

  protected String getStatusDescription() {
    return SHIPPING_STATUS_DESCRIPTION;
  }

  protected void updateStatusToComplete(StatusUpdateService statusService, RequestProfile requestProfile,
                                        String modUser) {
    statusService.shippingComplete(requestProfile, modUser);
  }

  protected View getCreateView(ViewFactory viewFactory) {
    return viewFactory.getCreateShippingAttachmentView();
  }

  protected View getAttachView(ViewFactory viewFactory) {
    return viewFactory.getAttachShippingView();
  }

  protected String getSearchTitle() {
    return "Requests Ready To Ship";
  }
}
