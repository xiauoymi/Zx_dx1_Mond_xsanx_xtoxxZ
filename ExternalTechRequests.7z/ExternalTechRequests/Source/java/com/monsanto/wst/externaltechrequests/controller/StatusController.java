package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.services.*;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateService;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.view.View;

import java.io.IOException;
import java.util.List;
/*
 StatusController was created on Feb 7, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class StatusController extends ETRAbstractDispatchController {
  private static final Privilege[] allowedPrivs = {Privilege.ADMIN_STATUS};

  private final RequestSearchService requestSearchService;
  private final ViewFactory viewFactory;
  private final StatusUpdateService statusService;
  private final LookupService lookupService;
  private final AttachmentService attachmentService;
  private final LookupReferenceDataService lookupReferenceDataService;
  private static final String STATUS_URL = "/srwgrequesttracking/servlet/status.html?method=editStatus";
  private static final String STATUS_TITLE = "Admin Status Update";

  public StatusController(RequestSearchService requestSearchService, ViewFactory viewFactory,
                          StatusUpdateService statusService, LookupService lookupService,
                          AttachmentService attachmentService,
                          LookupReferenceDataService lookupReferenceDataService) {
    this.requestSearchService = requestSearchService;
    this.viewFactory = viewFactory;
    this.statusService = statusService;
    this.lookupService = lookupService;
    this.attachmentService = attachmentService;
    this.lookupReferenceDataService = lookupReferenceDataService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);

    //todo look at refactoring this next block of code, its duplicated in several different classes
    RequestSearch requestSearch = new RequestSearch();
    List searchResults = requestSearchService.getRequestListBySearchCriteria(requestSearch);
    helper.setRequestAttributeValue("requestSearch", requestSearch);
    helper.setRequestAttributeValue(MainConstants.SEARCH_RESULTS_ATTRIBUTE, searchResults);
    helper.setRequestAttributeValue("searchParameters", new SearchParameters(getSearchTitle(),
        false, true, false, getURLBaseForSearchResults()));
    View view = viewFactory.getSearchRequestProfileView();
    view.renderView(helper);
  }

  public void editStatus(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);
    String requestIdString = helper.getRequestParameterValue("requestId");
    if (requestIdString == null) {
      notSpecified(helper);
    } else {
      displayRequestStatusEditPage(getRequestFromHelper(helper), helper);
    }
  }

  public void saveStatusUpdate(UCCHelper helper) throws IOException {
    loadSecurityInfoFromHelper(helper);
    ControllerSecurity.verifyUserIsAuthorized(helper, allowedPrivs);
    String newStatus = helper.getRequestParameterValue("newStatus");
    if (newStatus != null) {
      try {
        processStatusChange(getRequestFromHelper(helper), new Long(newStatus), helper.getAuthenticatedUserID());
      } catch (NumberFormatException e) {
        // ignore the error and let the normal processing run as if they hadn't mucked with the status code
        Logger.log(new LoggableWarning("Invalid status change attempted: newStatus=" + newStatus));
      }
    }
    notSpecified(helper);
  }

  private void processStatusChange(RequestProfile request, Long newStatus, String modUser) {
    if (MainConstants.STATUS_ID_NEW.equals(newStatus)) {
      statusService.newRequest(request, modUser);
    } else if (MainConstants.STATUS_ID_IN_REVIEW.equals(newStatus)) {
      statusService.sentToCommittee(request, modUser);
    } else if (MainConstants.STATUS_ID_APPROVED.equals(newStatus)) {
      statusService.commiteeApproval(request, "Admin Override", modUser);
    } else if (MainConstants.STATUS_ID_COORDINATOR.equals(newStatus)) {
      statusService.legalComplete(request, modUser);
    } else if (MainConstants.STATUS_ID_SHIPPING.equals(newStatus)) {
      statusService.coordinatorComplete(request, "Admin Override", modUser);
    } else if (MainConstants.STATUS_ID_COMPLETE.equals(newStatus)) {
      statusService.shippingComplete(request, modUser);
    } else if (MainConstants.STATUS_ID_REJECTED.equals(newStatus)) {
      statusService.commiteeRejection(request, "Admin Override", modUser);
    } else {
      // don't know what they were trying to do, ignore the status change
      Logger.log(new LoggableWarning("Invalid status change attempted, status id: " + newStatus));
    }

  }

  private RequestProfile getRequestFromHelper(UCCHelper helper) throws IOException {
    String requestIdString = helper.getRequestParameterValue("requestId");
    try {
      return lookupService.lookupRequestById(new Long(requestIdString));
    } catch (LookupServiceException e) {
      logAndRenderErrorMessagesView(e, helper);
      return null;
    }
  }

  private void displayRequestStatusEditPage(RequestProfile request, UCCHelper helper) {
    helper.setRequestAttributeValue("request", request);
    helper.setRequestAttributeValue("statusRefList", lookupReferenceDataService.getStatusRefList());
    View view = viewFactory.getStatusView();
    view.renderView(helper);
  }

  private void logAndRenderErrorMessagesView(Exception e, UCCHelper helper) {
    //todo this is duplicated in several places - refactor
    if (Logger.isEnabled(Logger.ERROR_LOG)) {
      Logger.log(new LoggableError(e));
    }
    HttpRequestErrors errors = new HttpRequestErrors();
    errors.addError("exception", e.getMessage());
    helper.setRequestAttributeValue("errors", errors);
    View view = viewFactory.getErrorsView();
    view.renderView(helper);
  }

  private String getURLBaseForSearchResults() {
    return STATUS_URL;
  }

  private String getSearchTitle() {
    return STATUS_TITLE;
  }

  protected void loadSecurityInfoFromHelper(UCCHelper helper) {
    attachmentService.loadSecurityInfoFromHelper(helper);
  }
}
