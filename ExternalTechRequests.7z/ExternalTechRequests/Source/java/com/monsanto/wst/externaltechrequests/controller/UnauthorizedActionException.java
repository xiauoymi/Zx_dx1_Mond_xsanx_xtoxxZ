package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.wst.externaltechrequests.security.Privilege;
/*
 UnauthorizedActionException was created on Jan 23, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class UnauthorizedActionException extends RuntimeException {
  public UnauthorizedActionException(Privilege priv) {
    super("User is not authorized for: " + priv.getDescription());
  }

  public UnauthorizedActionException() {
  }

  public UnauthorizedActionException(String message) {
    super(message);
  }

  public UnauthorizedActionException(Throwable cause) {
    super(cause);
  }

  public UnauthorizedActionException(String message, Throwable cause) {
    super(message, cause);
  }

  public UnauthorizedActionException(Privilege[] privs) {
    super(getMessageForPrivs(privs));
  }

  private static String getMessageForPrivs(Privilege[] privs) {
    if (privs == null || privs.length == 0) {
      return "User is not authorized for the requested action";
    } else {
      StringBuffer msg = new StringBuffer("User is not authorized for: ");
      msg.append(privs[0].getDescription());
      for (int i = 1; i < privs.length; i++) {
        msg.append(privs[i]);
        msg.append(", ");
      }

      return msg.toString();
    }
  }
}
