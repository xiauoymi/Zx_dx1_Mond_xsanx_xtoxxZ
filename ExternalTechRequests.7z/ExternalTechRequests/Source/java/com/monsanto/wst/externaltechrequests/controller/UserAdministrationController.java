package com.monsanto.wst.externaltechrequests.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.security.UserFactory;
import com.monsanto.wst.externaltechrequests.security.dbsecurity.Role;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.view.View;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/*
 UserAdministrationController was created on Jan 10, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class UserAdministrationController extends ETRAbstractDispatchController {
  private final ViewFactory viewFactory;
  private final UserFactory userFactory;

  public UserAdministrationController(UserFactory userFactory, ViewFactory viewFactory) {
    this.userFactory = userFactory;
    this.viewFactory = viewFactory;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    verifyAdminPrivs(helper);
    helper.setRequestAttributeValue("userList", getUserList());
    View view = viewFactory.getuserAdministrationView();
    view.renderView(helper);
  }

  private void verifyAdminPrivs(UCCHelper helper) {
    ControllerSecurity.verifyUserIsAuthorized(helper, Privilege.ADMIN_SECURITY);
  }

  private List getUserList() {
    List userRefData = userFactory.getAllUsers();
    List userList = new ArrayList(userRefData.size());
    for (int i = 0; i < userRefData.size(); i++) {
      User user = (User) userRefData.get(i);
      String roleString = formatRoles(user.getRoles());
      userList.add(new DisplayUser(user.getUserId(), user.getFullName(), user.getEmail(), roleString));
    }
    return userList;
  }

  private String formatRoles(List roles) {
    if (roles.isEmpty()) {
      return "-NONE-";
    } else {
      StringBuffer roleString = new StringBuffer(roles.get(0).toString());
      for (int i = 1; i < roles.size(); i++) {
        roleString.append(", ");
        roleString.append(roles.get(i).toString());
      }
      return roleString.toString();
    }
  }

  public void editUser(UCCHelper helper) throws IOException {
    verifyAdminPrivs(helper);
    User currentUser = getSpecifiedUser(helper);
    helper.setRequestAttributeValue("user", currentUser);
    helper.setRequestAttributeValue("roles", getRoles(currentUser));
    View view = viewFactory.getEditUserView();
    view.renderView(helper);
  }

  private List getRoles(User user) {
    List userRoles;
    if (user == null) {
      userRoles = new ArrayList();
    } else {
      userRoles = user.getRoles();
    }
    List allRoles = userFactory.getAllRoles();
    for (int i = 0; i < allRoles.size(); i++) {
      Role role = (Role) allRoles.get(i);
      boolean userHasRole = userRoles.contains(role.getName());
      role.setActive(userHasRole);
    }
    return allRoles;
  }

  private User getSpecifiedUser(UCCHelper helper) throws IOException {
    String userId = helper.getRequestParameterValue("userId");
    return userFactory.getUser(userId);
  }

  public void addUser(UCCHelper helper) {
    verifyAdminPrivs(helper);
    helper.setRequestAttributeValue("roles", getRoles(null));
    View view = viewFactory.getNewUserView();
    view.renderView(helper);
  }

  public void saveUser(UCCHelper helper) throws IOException {
    verifyAdminPrivs(helper);
    String userId = helper.getRequestParameterValue("userId");
    String fullName = helper.getRequestParameterValue("fullName");
    String email = helper.getRequestParameterValue("email");
    String[] roles = helper.getRequestParameterValues("roles");
    userFactory.addUser(userId, fullName, email, roles, helper.getAuthenticatedUserID());

    addSuccessMessageToHelper(helper, "User added: " + userId);

    helper.setRequestAttributeValue("userList", getUserList());
    View view = viewFactory.getuserAdministrationView();
    view.renderView(helper);
  }

  public void updateUser(UCCHelper helper) throws IOException {
    verifyAdminPrivs(helper);
    String userId = helper.getRequestParameterValue("userId");
    String fullName = helper.getRequestParameterValue("fullName");
    String email = helper.getRequestParameterValue("email");
    String[] roles = helper.getRequestParameterValues("roles");
    userFactory.updateUser(userId, fullName, email, roles, helper.getAuthenticatedUserID());

    addSuccessMessageToHelper(helper, "User updated: " + userId);

    helper.setRequestAttributeValue("userList", getUserList());
    View view = viewFactory.getuserAdministrationView();
    view.renderView(helper);
  }

  public void deactivateUser(UCCHelper helper) throws IOException {
    verifyAdminPrivs(helper);
    String userId = helper.getRequestParameterValue("userId");
    userFactory.deactivateUser(userId, helper.getAuthenticatedUserID());

    addSuccessMessageToHelper(helper, "User deactivated: " + userId);

    helper.setRequestAttributeValue("userList", getUserList());
    View view = viewFactory.getuserAdministrationView();
    view.renderView(helper);
  }

  private void addSuccessMessageToHelper(UCCHelper helper, String msg) {
    HttpRequestMessages messages = new HttpRequestMessages();
    messages.addMessage(msg);
    helper.setRequestAttributeValue("messages", messages);
  }
}
