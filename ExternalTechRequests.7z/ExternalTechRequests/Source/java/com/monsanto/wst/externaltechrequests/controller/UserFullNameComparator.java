package com.monsanto.wst.externaltechrequests.controller;

import java.util.Comparator;
/*
 UserFullNameComparator was created on Feb 22, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class UserFullNameComparator implements Comparator {
  public int compare(Object o1, Object o2) {
    DisplayUser user1 = (DisplayUser) o1;
    DisplayUser user2 = (DisplayUser) o2;

    if (user1 == user2) {
      return 0;
    } else {
      String name1 = user1.getFullName();
      if (name1 == null) {
        name1 = "";
      }
      String name2 = user2.getFullName();
      if (name2 == null) {
        name2 = "";
      }
      return name1.compareTo(name2);
    }
  }
}
