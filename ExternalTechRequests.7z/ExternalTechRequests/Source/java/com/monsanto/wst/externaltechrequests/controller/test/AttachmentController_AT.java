package com.monsanto.wst.externaltechrequests.controller.test;

import junit.framework.TestCase;
import com.monsanto.KerberosPOSSecurity.Test.KerberosSecurityATBase;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.Util.FileUtil;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebLink;

import java.io.*;
import java.util.Arrays;
import java.net.MalformedURLException;

import org.xml.sax.SAXException;

/*
 AttachmentController_AT was created on Mar 27, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
 */

public class AttachmentController_AT extends KerberosSecurityATBase {
  public AttachmentController_AT(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    startProxyServer();
  }

  public void testPlaceholder() throws Exception {
    assertTrue(true); // placeholder since the only test that was here is commented out due to a HttpUnit problem
  }

/*
  //todo this test passes is ran alone, but when part o fhte suite it has a GZIP error.  Commented out until new version of HttpUnit/JWebUnit
  // This appears to be a problem with the version of HttpUnit we are using.  When we upgrade, try enabling this test again

  public void testAttachAndRetreiveDocument() throws Exception {
    //note: this test was to capture a bug where certain files were being corrupted when attached and then redownloaded
    //An example was word documents with images embeded.  The problem was due to a bytearray/string/bytearray conversion
    long requestId = createTestRequest();

    try {
      String attachmentUrl = "http://w3devel.kerberos.monsanto.com/srwgrequesttracking/servlet/attachment.html?method=attachTemplate&requestId=" + requestId;
      WebResponse response1 = conversation.getResponse(attachmentUrl);
      WebForm requestForm1 = response1.getForms()[0];
      File testFile = new File("com/monsanto/wst/externaltechrequests/document/test/searchIdea.doc");
      byte[] expectedFile = FileUtil.fileToByteArray(testFile);
      String testDescription = "test description";
      requestForm1.setParameter(MainConstants.DESCRIPTION_PARAM_NAME, testDescription);
      requestForm1.setParameter(MainConstants.ATTACHMENT_PARAM_NAME, testFile);
      requestForm1.submit();

      WebResponse response2 = conversation.getResponse(attachmentUrl);
      WebLink viewLink = response2.getLinkWith(testDescription);
      assertNotNull(viewLink);

      WebResponse response3 = viewLink.click();
      InputStream responseStream = response3.getInputStream();
      try {
        byte[] actualFile = streamToByteArray(responseStream);
//        OutputStream debugOut = new BufferedOutputStream(new FileOutputStream("C:\\TEST_OUT.DOC"));
//        debugOut.write(actualFile);
        assertTrue("Files did not match", Arrays.equals(expectedFile, actualFile));
      } finally {
        responseStream.close();
      }
    } finally {
      //todo delete test request
    }
  }
*/

  private long createTestRequest() throws IOException, SAXException {
    WebResponse response = conversation
        .getResponse("http://w3devel.kerberos.monsanto.com/srwgrequesttracking/servlet/new_request.html");
    WebForm requestForm1 = response.getForms()[0];
    requestForm1.setParameter(MainConstants.REQUESTOR_NAME_PARAM_NAME, "asdgds");
    requestForm1.setParameter(MainConstants.SPONSOR_PARAM_NAME, requestForm1.getOptionValues(MainConstants.SPONSOR_PARAM_NAME)[1]);
    WebResponse response1 = requestForm1.submit();
    WebForm requestForm2 = response1.getForms()[0];
    String expectedRequestNumber = requestForm2.getParameterValue(MainConstants.REQUEST_NUMBER_PARAM_NAME);
    requestForm2.setParameter(MainConstants.REQUESTOR_TITLE_PARAM_NAME, "sgsdg");
    WebResponse finalResponse = requestForm2.submit();
    assertNotNull(finalResponse.getForms()[0].getParameterValue(MainConstants.REQUESTOR_TITLE_PARAM_NAME));
    String requestNumber = finalResponse.getForms()[0].getParameterValue(MainConstants.REQUEST_NUMBER_PARAM_NAME);
    assertNotNull(requestNumber);
    assertEquals(expectedRequestNumber, requestNumber);

    String requestId = finalResponse.getForms()[0].getParameterValue(MainConstants.REQUEST_ID_PARAM_NAME);
    return Long.parseLong(requestId);
  }

  private byte[] streamToByteArray(InputStream responseStream) throws IOException {
    ByteArrayOutputStream outStream = new ByteArrayOutputStream();
    int data = responseStream.read();
    while (data != -1 ) {
      outStream.write(data);
      data = responseStream.read();
    }
    return outStream.toByteArray();
  }
}