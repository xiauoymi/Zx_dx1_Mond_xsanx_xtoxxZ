package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupService;
import com.monsanto.wst.externaltechrequests.controller.AttachmentController;
import com.monsanto.wst.externaltechrequests.dao.test.MockAttachedFile;
import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.model.AttachmentMetadata;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.test.MockAttachmentService;
import com.monsanto.wst.externaltechrequests.security.test.MockPrivilegedUser;
import com.monsanto.wst.externaltechrequests.security.test.MockUser;
import com.monsanto.wst.externaltechrequests.services.LookupReferenceDataService;
import com.monsanto.wst.externaltechrequests.services.LookupService;
import com.monsanto.wst.externaltechrequests.services.RequestSearchService;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupReferenceDataService;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupService;
import com.monsanto.wst.externaltechrequests.services.mock.MockRequestSearchService;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
 AttachmentController_UT was created on Feb 2, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class AttachmentController_UT extends TestCase {
  private static final String TEST_FILENAME = "com/monsanto/wst/externaltechrequests/controller/test/test.doc";
  private static final String TEST_MIME_TYPE = "application/msword";
  private static final String TEST_DESCRIPTION = "Test File";

  private MockStatusUpdateService statusService;
  private LookupReferenceDataService lookupReferenceDataService;
  private LookupService lookupService;
  private RequestSearchService requestSearchService;
  private SequenceLookupService sequenceService;
  private MockAttachmentService attachmentService;
  private ViewFactory viewFactory;

  private MockUCCHelper helper;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper("MOCK");
    attachmentService = new MockAttachmentService();
    viewFactory = new MockViewFactory();
    requestSearchService = new MockRequestSearchService();
    statusService = new MockStatusUpdateService();
    lookupReferenceDataService = new MockLookupReferenceDataService();
    lookupService = new MockLookupService();
    sequenceService = new MockSequenceService();
  }

  public void testNoAttachmentShowsAttachmentPage() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewForSearchPage(view);
    AttachmentController controller = new AttachmentController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  public void testViewAttachment() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    Attachment attachment = new MockAttachment(1, "test.txt", "test desc", DocumentType.LEGAL, 1,
        new MockAttachedFile("Hello".getBytes()));
    attachmentService.addAttachment(attachment, "test");
    helper.setRequestParameterValue("method", "display");
    helper.setRequestParameterValue("attachmentId", attachment.getMetadata().getId());
    AttachmentController controller = new AttachmentController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory, attachmentService, sequenceService);
    attachmentService.clearRead();
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
    assertTrue(attachmentService.wasRead(attachment.getMetadata().getId()));
  }


  public void testWithoutAttachPrivCausesExceptionOnAttach() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForAttachment(view);
    AttachmentController controller = new AttachmentController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory, attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "saveAttachment");

    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception IGNORE) {
      // ignore expected exception
    }
  }

  private List getNewAttachments(List oldItems, List currItems) {
    List newItems = new ArrayList();
    for (int i = 0; i < currItems.size(); i++) {
      Attachment attachment = (Attachment) currItems.get(i);
      AttachmentMetadata meta = attachment.getMetadata();
      assertNotNull(meta);
      if (isNewAttachment(oldItems, attachment)) {
        newItems.add(attachment);
      }
    }

    return newItems;
  }

  public void testAttachWithFile() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForAttachment(view);
    RequestProfile request = new RequestProfile(new Long(12345L));
    Attachment newAttachment = callControllerToAddAttachment(viewFactory, TEST_DESCRIPTION, TEST_FILENAME, request);
    assertNotNull(newAttachment);
    AttachmentMetadata meta = newAttachment.getMetadata();
    assertNotNull(meta);
    assertNotNull(meta.getId());
    assertEquals(request.getId(), meta.getRequestId());
    assertEquals(TEST_DESCRIPTION, meta.getDescription());
    assertNotNull(meta.getAttachmentType());
    assertNotNull(meta.getName());
    assertTrue(meta.getName().length() > 0);
    assertTrue(TEST_FILENAME.indexOf(meta.getName()) >= 0);
    assertEquals(TEST_MIME_TYPE, meta.getMimeType());

    AttachedFile file = newAttachment.getAttachedFile();
    assertNotNull(file);
    byte[] data = file.getContent();
    assertNotNull(data);
    assertTrue(Arrays.equals("Hello".getBytes(), data));
  }

  private Attachment callControllerToAddAttachment(ViewFactory viewFactory, String testDescription,
                                                   String testFilename, RequestProfile request)
      throws IOException {
    Long requestId = request.getId();
    List oldAttachments = attachmentService.getAttachments(requestId, new MockPrivilegedUser("test"))
        .getOtherAttachments();
    AttachmentController controller = new AttachmentController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory, attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "saveAttachment");
    helper.setRequestParameterValue("description", testDescription);
    helper.setRequestParameterValue("requestId", requestId);
    helper.addClientFile(testFilename);
    controller.run(helper);
    List attachments = attachmentService.getAttachments(requestId, new MockPrivilegedUser("test"))
        .getOtherAttachments();
    List newAttachments = getNewAttachments(oldAttachments, attachments);
    assertEquals(1, newAttachments.size());
    return (Attachment) newAttachments.get(0);
  }

  private boolean isNewAttachment(List oldAttachments, Attachment attachment) {
    Long id = attachment.getMetadata().getId();
    for (int i = 0; i < oldAttachments.size(); i++) {
      Attachment oldAttachment = (Attachment) oldAttachments.get(i);
      if (id.equals(oldAttachment.getMetadata().getId())) {
        return false;
      }
    }
    return true;
  }


  private static class MockViewForSearchPage extends MockViewFactory {
    private final View view;

    MockViewForSearchPage(View view) {
      this.view = view;
    }

    public View getSearchRequestProfileView() {
      return view;
    }
  }

  private static class MockViewFactoryForAttachment extends MockViewFactory {
    private final View view;

    MockViewFactoryForAttachment(View view) {
      this.view = view;
    }

    public View getAttachmentView() {
      return view;
    }
  }
}