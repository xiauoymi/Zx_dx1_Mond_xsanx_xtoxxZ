package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.controller.CommitteeController;
import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.test.MockAttachmentService;
import com.monsanto.wst.externaltechrequests.security.test.MockPrivilegedUser;
import com.monsanto.wst.externaltechrequests.security.test.MockUser;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupService;
import com.monsanto.wst.externaltechrequests.services.mock.MockRequestSearchService;
import com.monsanto.wst.externaltechrequests.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/*
 CommitteeController_UT was created on Feb 8, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class CommitteeController_UT extends TestCase {
  private MockUCCHelper helper;
  private MockStatusUpdateService statusService;
  private MockLookupService lookupService;
  private MockAttachmentService attachmentService;

  private static final Long TEST_REQUEST_ID = new Long(1234L);

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper("/test");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    statusService = new MockStatusUpdateService();
    lookupService = new MockLookupService();
    attachmentService = new MockAttachmentService();
  }

  public void testCreate() throws Exception {
    CommitteeController controller = new CommitteeController(new MockRequestSearchService(), new MockViewFactory(),
        statusService, lookupService,
        attachmentService);
    assertNotNull(controller);
  }

  public void testNotAuthorizedCausesException() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    CommitteeController controller = new CommitteeController(new MockRequestSearchService(), new MockViewFactory(),
        statusService, lookupService, attachmentService);
    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception e) {
      // ignore expected
    }
  }

  public void testControllerNotSpecifiedMethod() throws Exception {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForCommitteeView(view);
    List testRequests = new ArrayList();
    testRequests.add(new RequestProfile());
    MockRequestSearchService requestSearchService = new MockRequestSearchService(testRequests);
    CommitteeController controller = new CommitteeController(requestSearchService, viewFactory, statusService,
        lookupService, attachmentService);
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
    assertTrue(view.wasViewRendered());
    RequestSearch search = requestSearchService.getRequestSearch();
    assertNotNull(search);
    assertEquals(MainConstants.STATUS_ID_IN_REVIEW, search.getStatusId());
    List requests = (List) helper.getRequestAttributeValue(MainConstants.SEARCH_RESULTS_ATTRIBUTE);
    assertNotNull(requests);
    assertEquals(1, requests.size());
    assertNotNull(helper.getRequestAttributeValue("title"));
    assertEquals("approveOrReject", helper.getRequestAttributeValue("actionMethod"));
  }

  public void testControllerCoordinatorMethod() throws Exception {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForCommitteeView(view);
    List testRequests = new ArrayList();
    testRequests.add(new RequestProfile());
    MockRequestSearchService requestSearchService = new MockRequestSearchService(testRequests);
    CommitteeController controller = new CommitteeController(requestSearchService, viewFactory, statusService,
        lookupService, attachmentService);
    helper.setRequestParameterValue("method", "coordinator");
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
    assertTrue(view.wasViewRendered());
    RequestSearch search = requestSearchService.getRequestSearch();
    assertNotNull(search);
    assertEquals(MainConstants.STATUS_ID_COORDINATOR, search.getStatusId());
    List requests = (List) helper.getRequestAttributeValue(MainConstants.SEARCH_RESULTS_ATTRIBUTE);
    assertNotNull(requests);
    assertEquals(1, requests.size());
    assertNotNull(helper.getRequestAttributeValue("title"));
    assertEquals("coordinatorApproveOrReject", helper.getRequestAttributeValue("actionMethod"));
  }

  public void testApproveWithoutPrivsFails() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    CommitteeController controller = new CommitteeController(new MockRequestSearchService(), new MockViewFactory(),
        statusService, lookupService, attachmentService);
    helper.setRequestParameterValue("method", "approve");
    helper.setRequestParameterValue("requestId", TEST_REQUEST_ID);
    helper.setRequestParameterValue("comments", "test");
    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception e) {
      // ignore expected
    }
  }

  public void testRejectWithoutPrivsFails() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    CommitteeController controller = new CommitteeController(new MockRequestSearchService(), new MockViewFactory(),
        statusService, lookupService, attachmentService);
    helper.setRequestParameterValue("method", "reject");
    helper.setRequestParameterValue("requestId", TEST_REQUEST_ID);
    helper.setRequestParameterValue("comments", "test");
    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception e) {
      // ignore expected
    }
  }

  public void testReject() throws Exception {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForCommitteeView(view);
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    CommitteeController controller = new CommitteeController(new MockRequestSearchService(), viewFactory,
        statusService, lookupService, attachmentService);
    helper.setRequestParameterValue("method", "approveOrReject");
    helper.setRequestParameterValue("reject_" + TEST_REQUEST_ID, "");
    String testComment = "test";
    helper.setRequestParameterValue("comment_" + TEST_REQUEST_ID, testComment);
    controller.run(helper);
    assertTrue(statusService.isSetToRejected());
    assertEquals(testComment, statusService.getComment());
    assertFalse(helper.wasErrorGenerated());
    assertTrue(view.wasViewRendered());
  }

  public void testApprove() throws Exception {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForCommitteeView(view);
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    CommitteeController controller = new CommitteeController(new MockRequestSearchService(), viewFactory,
        statusService, lookupService, attachmentService);
    helper.setRequestParameterValue("method", "approveOrReject");
    helper.setRequestParameterValue("approve_" + TEST_REQUEST_ID, "");
    String testComment = "test";
    helper.setRequestParameterValue("comment_" + TEST_REQUEST_ID, testComment);
    controller.run(helper);
    assertTrue(statusService.isSetToApproved());
    assertEquals(testComment, statusService.getComment());
    assertFalse(helper.wasErrorGenerated());
    assertTrue(view.wasViewRendered());
  }

  public void testCoordinatorReject() throws Exception {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForCommitteeView(view);
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    CommitteeController controller = new CommitteeController(new MockRequestSearchService(), viewFactory,
        statusService, lookupService, attachmentService);
    helper.setRequestParameterValue("method", "coordinatorApproveOrReject");
    helper.setRequestParameterValue("reject_" + TEST_REQUEST_ID, "");
    String testComment = "test";
    helper.setRequestParameterValue("comment_" + TEST_REQUEST_ID, testComment);
    controller.run(helper);
    assertTrue(statusService.isSetToRejected());
    assertEquals(testComment, statusService.getComment());
    assertFalse(helper.wasErrorGenerated());
    assertTrue(view.wasViewRendered());
  }

  public void testCoordinatorApprove() throws Exception {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForCommitteeView(view);
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    CommitteeController controller = new CommitteeController(new MockRequestSearchService(), viewFactory,
        statusService, lookupService, attachmentService);
    helper.setRequestParameterValue("method", "coordinatorApproveOrReject");
    helper.setRequestParameterValue("approve_" + TEST_REQUEST_ID, "");
    String testComment = "test";
    helper.setRequestParameterValue("comment_" + TEST_REQUEST_ID, testComment);
    controller.run(helper);
    assertTrue(statusService.isSetToShipping());
    assertEquals(testComment, statusService.getComment());
    assertFalse(helper.wasErrorGenerated());
    assertTrue(view.wasViewRendered());
  }

  private class MockViewFactoryForCommitteeView extends MockViewFactory {
    private final View view;

    MockViewFactoryForCommitteeView(View view) {
      this.view = view;
    }

    public View getCommitteeView() {
      return view;
    }
  }
}
