/*
 DILoginController_UT was created on Nov 14, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.securityinterfaces.Test.MockSystemSecurityProxy;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.controller.DILoginController;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.security.test.MockUser;
import com.monsanto.wst.externaltechrequests.services.LookupService;
import com.monsanto.wst.externaltechrequests.services.LookupServiceException;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupService;
import com.monsanto.wst.externaltechrequests.utils.testutils.BaseTestCase;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.test.mock.MockView;

/**
 * Filename:    $RCSfile: DILoginController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-02-23 18:42:24 $
 *
 * @author ffbrac
 * @version $Revision: 1.8 $
 */
public class DILoginController_UT extends BaseTestCase {
  private MockUCCHelper helper;
  private SystemSecurityProxy proxy;

  protected void setUp() throws Exception {
    super.setUp();
    proxy = new MockSystemSecurityProxy();
    helper = new MockUCCHelper("/test", true, proxy);
//    AbstractGenericFactory.setContext("com/monsanto/wst/factory/test/context.xml");
  }

  public void testCreate() throws Exception {
    DILoginController controller = new DILoginController();
    assertNotNull(controller);
  }

  public void testCreateLoginUserAddsUserToSession() throws Exception {
    MockDILoginControllerForVisibility controller = new MockDILoginControllerForVisibility();
    controller.createLoginUser(helper, new MockLookupServiceForUser());
    User user = (User) helper.getSessionParameter(MainConstants.LOGINUSER);
    assertNotNull(user);
    assertEquals(proxy.getUserID(), user.getUserId());
  }

  public void testNullUser() throws Exception {
    MockDILoginControllerForVisibility controller = new MockDILoginControllerForVisibility();
    controller.createLoginUser(helper, new MockLookupServiceForNullUser());
    User user = (User) helper.getSessionParameter(MainConstants.LOGINUSER);
    assertNull(user);
  }

  public void testRejectUserRedirectsToErrorPage() throws Exception {
    MockDILoginControllerForRejectUser controller = new MockDILoginControllerForRejectUser();
    controller.rejectUser(helper, new MockViewFactory());
    assertTrue(controller.wasRedirected());
  }

  public void testRedirectGoesToErrorView() throws Exception {
    MockDILoginControllerForRedirect controller = new MockDILoginControllerForRedirect();
    MockView view = new MockView();
    MockViewFactoryForError mockViewFactory = new MockViewFactoryForError(view);
    controller.redirectToErrorsPage(helper, mockViewFactory, "test message");
    assertTrue(view.wasViewRendered());
  }

  public void testRunWorks() throws Exception {
    DILoginController controller = new MockDILoginControllerForCreateLoginUser();
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
  }

  public void testRunWhenCreateUserFailsWithLookupException() throws Exception {
    MockDILoginControllerCreateLoginUserThrowsLoookupExcep controller = new MockDILoginControllerCreateLoginUserThrowsLoookupExcep();
    controller.run(helper);
    assertTrue(controller.wasRejectUserCalled());
  }

  public void testRunWhenCreateUserFailsWithRuntimeException() throws Exception {
    MockDILoginControllerCreateLoginUserThrowsRuntimeExcep controller = new MockDILoginControllerCreateLoginUserThrowsRuntimeExcep();
    controller.run(helper);
    assertTrue(controller.wasRedirectCalled());
  }

  private class MockDILoginControllerForCreateLoginUser extends DILoginController {
    protected void createLoginUser(UCCHelper helper, LookupService lookupService) throws LookupServiceException {
      // nothing needed for mock
    }
  }

  private class MockDILoginControllerCreateLoginUserThrowsLoookupExcep extends DILoginController {
    private boolean rejectUserCalled = false;

    protected void createLoginUser(UCCHelper helper, LookupService lookupService) throws LookupServiceException {
      throw new LookupServiceException("Mock Exception");
    }

    protected void rejectUser(UCCHelper helper, ViewFactory viewFactory) {
      rejectUserCalled = true;
    }

    public boolean wasRejectUserCalled() {
      return rejectUserCalled;
    }
  }

  private class MockDILoginControllerCreateLoginUserThrowsRuntimeExcep extends DILoginController {
    private boolean redirectCalled = false;

    protected void createLoginUser(UCCHelper helper, LookupService lookupService) throws LookupServiceException {
      throw new RuntimeException("Mock Exception");
    }

    protected void redirectToErrorsPage(UCCHelper helper, ViewFactory viewFactory, String message) {
      redirectCalled = true;
    }

    public boolean wasRedirectCalled() {
      return redirectCalled;
    }
  }

  private class MockDILoginControllerForRedirect extends DILoginController {
    protected void redirectToErrorsPage(UCCHelper helper, ViewFactory viewFactory, String message) {
      super.redirectToErrorsPage(helper, viewFactory, message);
    }
  }

  private class MockDILoginControllerForRejectUser  extends DILoginController {
    private boolean redirected = false;

    protected void rejectUser(UCCHelper helper, ViewFactory viewFactory) {
      super.rejectUser(helper, viewFactory);
    }

    protected void redirectToErrorsPage(UCCHelper helper, ViewFactory viewFactory, String message) {
      redirected = true;
    }

    public boolean wasRedirected() {
      return redirected;
    }
  }

  private class MockDILoginControllerForVisibility extends DILoginController {
    protected void createLoginUser(UCCHelper helper, LookupService lookupService) throws LookupServiceException {
      super.createLoginUser(helper, lookupService);
    }
  }

  private class MockLookupServiceForUser extends MockLookupService {
    public User lookupLoginUserByUserId(String userId) {
      return new MockUser(userId);
    }
  }

  private class MockLookupServiceForNullUser extends MockLookupService {
    public User lookupLoginUserByUserId(String userId) {
      return null;
    }
  }

}