package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupService;
import com.monsanto.wst.externaltechrequests.controller.EditAttachmentController;
import com.monsanto.wst.externaltechrequests.dao.test.MockAttachedFile;
import com.monsanto.wst.externaltechrequests.document.DocumentRetrievalException;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.model.test.MockAttachmentService;
import com.monsanto.wst.externaltechrequests.security.test.MockPrivilegedUser;
import com.monsanto.wst.externaltechrequests.security.test.MockReadonlyUser;
import com.monsanto.wst.externaltechrequests.security.test.MockUser;
import com.monsanto.wst.externaltechrequests.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.io.IOException;

/*
 EditAttachmentController_UT was created on Feb 13, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class EditAttachmentController_UT extends TestCase {
  private MockAttachmentService attachmentService;
  private SequenceLookupService sequenceLookupService;

  protected void setUp() throws Exception {
    super.setUp();
    attachmentService = new MockAttachmentService();
    sequenceLookupService = new MockSequenceService();
  }

  public void testNoAttachmentIdShowsError() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForError(view);
    EditAttachmentController controller = new EditAttachmentController(attachmentService, viewFactory,
        sequenceLookupService);
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  public void testWithAttachmentIdShowsCorrectView() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    verifyViewWorks(helper);
  }

  public void testWithAttachmentIdWithInvalidIdShowsErrorView() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForError(view);
    helper.setRequestParameterValue("attachmentId", "1");
    EditAttachmentController controller = new EditAttachmentController(attachmentService, viewFactory,
        sequenceLookupService);
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  public void testWithAttachmentIdGetsCorrectDocument() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    String expectedContent = "This is a test, <em>This is only a test</em>, please go about your business";
    helper.setRequestParameterValue("attachmentId", "1");
    Attachment attachment = new MockAttachment(1, "test", "test", DocumentType.OTHER, 1,
        new MockAttachedFile(expectedContent));
    attachmentService.addAttachment(attachment, "test");
    EditAttachmentController controller = new EditAttachmentController(attachmentService, new MockViewFactory(),
        sequenceLookupService);
    controller.run(helper);
    assertTrue(attachmentService.wasRead(new Long(1)));
    String content = (String) helper.getRequestAttributeValue("content");
    assertEquals(expectedContent, content);
  }

  public void testSaveUpdatesAttachment() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    verifyUpdateWorks(helper);
  }

  public void testNotViewableCannotView() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockUser("mock"));
    verifyViewFails(helper);
  }

  public void testNotViewableCannotUpdate() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockUser("mock"));
    verifyUpdateFails(helper);
  }

  public void testViewOnlyCanView() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockReadonlyUser("mock"));
    verifyViewWorks(helper);
  }

  public void testViewOnlyCannotUpdate() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockReadonlyUser("mock"));
    verifyUpdateFails(helper);
  }

  public void testEditableCanView() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    verifyViewWorks(helper);
  }

  public void testEditableCanUpdate() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    verifyUpdateWorks(helper);
  }

  public void testDeleteableCanDelete() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    helper.setRequestParameterValue("method", "delete");
    helper.setRequestParameterValue("attachmentId", "1");
    Attachment attachment = new MockAttachment(1, "test", "test", DocumentType.OTHER, 1,
        new MockAttachedFile("Some other content"));
    attachmentService.addAttachment(attachment, "test");
    EditAttachmentController controller = new EditAttachmentController(attachmentService, new MockViewFactory(),
        sequenceLookupService);
    controller.run(helper);
    assertTrue(attachmentService.wasDeleted(new Long(1)));
  }

  public void testNotDeletableCannotDelete() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockUser("mock"));
    helper.setRequestParameterValue("method", "delete");
    helper.setRequestParameterValue("attachmentId", "1");
    Attachment attachment = new MockAttachment(1, "test", "test", DocumentType.OTHER, 1,
        new MockAttachedFile("Some other content"));
    attachmentService.addAttachment(attachment, "test");
    EditAttachmentController controller = new EditAttachmentController(attachmentService, new MockViewFactory(),
        sequenceLookupService);
    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception IGNORE) {
      // ignore expected exception
    }
  }

  private void verifyViewWorks(MockUCCHelper helper) throws IOException {
    String expectedContent = "This is a test, <em>This is only a test</em>, please go about your business";
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForEditAttachment(view);
    helper.setRequestParameterValue("attachmentId", "1");
    Attachment attachment = new MockAttachment(1, "test", "test", DocumentType.OTHER, 1,
        new MockAttachedFile(expectedContent));
    attachmentService.addAttachment(attachment, "test");
    EditAttachmentController controller = new EditAttachmentController(attachmentService, viewFactory,
        sequenceLookupService);
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  private void verifyViewFails(MockUCCHelper helper) throws IOException {
    String expectedContent = "This is a test, <em>This is only a test</em>, please go about your business";
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForError(view);
    helper.setRequestParameterValue("attachmentId", "1");
    Attachment attachment = new MockAttachment(1, "test", "test", DocumentType.OTHER, 1,
        new MockAttachedFile(expectedContent));
    attachmentService.addAttachment(attachment, "test");
    EditAttachmentController controller = new EditAttachmentController(attachmentService, viewFactory,
        sequenceLookupService);
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  private void verifyUpdateWorks(MockUCCHelper helper) throws IOException, DocumentRetrievalException {
    String expectedContent = "This is a <u>different</u> test, <em>This is only a test</em>, please go about your business";
    helper.setRequestParameterValue("method", "saveAttachment");
    helper.setRequestParameterValue("attachmentId", "1");
    helper.setRequestParameterValue("content", expectedContent);
    Attachment attachment = new MockAttachment(1, "test", "test", DocumentType.OTHER, 1,
        new MockAttachedFile("Some other content"));
    attachmentService.addAttachment(attachment, "test");
    EditAttachmentController controller = new EditAttachmentController(attachmentService, new MockViewFactory(),
        sequenceLookupService);
    controller.run(helper);
    assertTrue(attachmentService.wasUpdated(new Long(1)));
    Attachment attachmentAfterUpdate = attachmentService.getAttachment(new Long(1));
    String content = new String(attachmentAfterUpdate.getAttachedFile().getContent());
    assertEquals(expectedContent, content);
  }

  private void verifyUpdateFails(MockUCCHelper helper) throws IOException {
    String expectedContent = "This is a <u>different</u> test, <em>This is only a test</em>, please go about your business";
    helper.setRequestParameterValue("method", "saveAttachment");
    helper.setRequestParameterValue("attachmentId", "1");
    helper.setRequestParameterValue("content", expectedContent);
    Attachment attachment = new MockAttachment(1, "test", "test", DocumentType.OTHER, 1,
        new MockAttachedFile("Some other content"));
    attachmentService.addAttachment(attachment, "test");
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForError(view);
    EditAttachmentController controller = new EditAttachmentController(attachmentService, viewFactory,
        sequenceLookupService);
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  private class MockViewFactoryForEditAttachment extends MockViewFactory {
    private final View view;

    MockViewFactoryForEditAttachment(View view) {
      this.view = view;
    }

    public View getEditAttachmentView() {
      return view;
    }
  }

}