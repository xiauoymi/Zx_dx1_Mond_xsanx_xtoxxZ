/*
 HomePageController_UT was created on Nov 7, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.externaltechrequests.controller.HomePageController;
import com.monsanto.wst.externaltechrequests.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: HomePageController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:57 $
 *
 * @author ffbrac
 * @version $Revision: 1.5 $
 */
public class HomePageController_UT extends TestCase {
  private MockUCCHelper helper;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper("/test");
  }

  public void testCreate() throws Exception {
    HomePageController controller = new HomePageController(null);
    assertNotNull(controller);
  }

  public void testHomePageControllerRunMethod() throws Exception {
    MockViewFactory viewFactory = new MockViewFactory();
    HomePageController controller = new HomePageController(viewFactory);
    controller.run(helper);
    MockView view = (MockView) viewFactory.getHomePageView();
    assertTrue(view.wasViewRendered());
  }
}