package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.document.DocumentRetrievalException;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.document.test.MockDocumentService;
import com.monsanto.wst.externaltechrequests.model.AttachmentMetadata;
import com.monsanto.wst.externaltechrequests.model.RepositoryAttachment;
/*
 MockAttachment was created on Jan 24, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MockAttachment extends RepositoryAttachment {
  private final AttachedFile doc;

  public MockAttachment(long id, String name, String description, DocumentType attachmentType, long requestNumber) {
    this(id, name, description, attachmentType, requestNumber, null, null);
  }

  public MockAttachment(long id, String name, String description, DocumentType attachmentType, long requestNumber,
                        String mimeType) {
    this(id, name, description, attachmentType, requestNumber, mimeType, null);
  }

  public MockAttachment(long id, String name, String description, DocumentType attachmentType, long requestNumber,
                        AttachedFile doc) {
    this(id, name, description, attachmentType, requestNumber, "", doc);
  }

  public MockAttachment(long id, String name, String description, DocumentType attachmentType, long requestNumber,
                        String mimeType, AttachedFile doc) {
    super(createMockMetaData(id, name, description, attachmentType, requestNumber, mimeType),
        new MockDocumentService());
    this.doc = doc;
  }

  private static AttachmentMetadata createMockMetaData(long id, String name, String description,
                                                       DocumentType attachmentType,
                                                       long requestNumber, String mimeType) {
    AttachmentMetadata metadata = new AttachmentMetadata();
    metadata.setId(new Long(id));
    metadata.setName(name);
    metadata.setDescription(description);
    metadata.setRequestId(new Long(requestNumber));
    metadata.setAttachmentTypeId(new Long(attachmentType.getId()));
    metadata.setMimeType(mimeType);
    return metadata;
  }

  public AttachedFile getAttachedFile() throws DocumentRetrievalException {
    if (doc == null) {
      return super.getAttachedFile();
    } else {
      return doc;
    }
  }
}
