package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.wst.administerreferencedata.exception.GenericLookupBuilderException;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupService;
/*
 MockSequenceService was created on Feb 6, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
class MockSequenceService implements SequenceLookupService {
  long id = 0L;

  public String getSequence() throws GenericLookupBuilderException {
    id++;
    return Long.toString(id);
  }
}
