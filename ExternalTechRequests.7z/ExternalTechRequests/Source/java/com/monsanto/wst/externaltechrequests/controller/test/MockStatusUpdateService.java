package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateService;
/*
 MockStatusUpdateService was created on Jan 31, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MockStatusUpdateService implements StatusUpdateService {
  private boolean setToNew;
  private boolean setToSentToCommittee;
  private boolean setToApproved;
  private boolean setToRejected;
  private boolean setToShipping;
  private boolean setToComplete;
  private String lastComment;
  private boolean supervisorNotified;
  private boolean setToCoordinator;

  public MockStatusUpdateService() {
    reset();
  }

  public void newRequest(RequestProfile request, String modUser) {
    setToNew = true;
    setToSentToCommittee = false;
    setToApproved = false;
    setToRejected = false;
    setToCoordinator = false;
    setToShipping = false;
    setToComplete = false;
  }

  public void sentToCommittee(RequestProfile request, String modUser) {
    setToNew = false;
    setToSentToCommittee = true;
    setToApproved = false;
    setToRejected = false;
    setToCoordinator = false;
    setToShipping = false;
    setToComplete = false;
  }

  public void commiteeApproval(RequestProfile request, String comments, String modUser) {
    setToNew = false;
    setToSentToCommittee = false;
    setToApproved = true;
    setToRejected = false;
    setToCoordinator = false;
    setToShipping = false;
    setToComplete = false;
    lastComment = comments;
  }

  public void commiteeRejection(RequestProfile request, String comments, String modUser) {
    setToNew = false;
    setToSentToCommittee = false;
    setToApproved = false;
    setToRejected = true;
    setToCoordinator = false;
    setToShipping = false;
    setToComplete = false;
    lastComment = comments;
  }

  public void legalComplete(RequestProfile request, String modUser) {
    setToNew = false;
    setToSentToCommittee = false;
    setToApproved = false;
    setToRejected = false;
    setToCoordinator = true;
    setToShipping = false;
    setToComplete = false;
  }

  public void legalNotify(RequestProfile request) {
    supervisorNotified = true;
  }

  public void shippingComplete(RequestProfile request, String modUser) {
    setToNew = false;
    setToSentToCommittee = false;
    setToApproved = false;
    setToRejected = false;
    setToCoordinator = false;
    setToShipping = false;
    setToComplete = true;
  }

  public void coordinatorComplete(RequestProfile request, String comments, String modUser) {
    setToNew = false;
    setToSentToCommittee = false;
    setToApproved = false;
    setToRejected = false;
    setToCoordinator = false;
    setToShipping = true;
    setToComplete = false;
    lastComment = comments;
  }

  public boolean isSetToNew() {
    return setToNew;
  }

  public boolean isSetToSentToCommittee() {
    return setToSentToCommittee;
  }

  public boolean isSetToCoordinator() {
    return setToCoordinator;
  }

  public boolean isSetToApproved() {
    return setToApproved;
  }

  public boolean isSetToRejected() {
    return setToRejected;
  }

  public boolean isSetToShipping() {
    return setToShipping;
  }

  public boolean isSetToComplete() {
    return setToComplete;
  }

  public String getComment() {
    return lastComment;
  }

  public void reset() {
    setToNew = false;
    setToSentToCommittee = false;
    setToApproved = false;
    setToRejected = false;
    setToShipping = false;
    setToComplete = false;
    lastComment = null;
    supervisorNotified = false;
  }

  public boolean wasSupervisorNotified() {
    return supervisorNotified;
  }
}
