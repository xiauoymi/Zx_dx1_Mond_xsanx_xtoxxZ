package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.wst.externaltechrequests.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.View;
/*
 MockViewFactoryForError was created on Feb 22, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
class MockViewFactoryForError extends MockViewFactory {
  private final View view;

  MockViewFactoryForError(View view) {
    this.view = view;
  }

  public View getErrorsView() {
    return view;
  }
}
