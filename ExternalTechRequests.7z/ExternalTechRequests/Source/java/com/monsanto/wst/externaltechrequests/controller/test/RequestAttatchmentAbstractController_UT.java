package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.externaltechrequests.controller.RequestAttachmentAbstractController;
import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestResearchType;
import com.monsanto.wst.externaltechrequests.model.test.MockAttachmentService;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.test.MockPrivilegedUser;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
import com.monsanto.wst.externaltechrequests.services.LookupService;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupReferenceDataService;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupService;
import com.monsanto.wst.externaltechrequests.services.mock.MockRequestSearchService;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.view.factory.mock.MockViewFactory;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateService;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/*
 RequestAttatchmentAbstractController_UT was created on Feb 15, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class RequestAttatchmentAbstractController_UT extends TestCase {
  private MockUCCHelper helper;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper("/test");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
  }

  public void testPrepareContentCalledOnGenerate() throws Exception {
    LookupService lookupService = new MockLookupServiceForPrepareContent();
    AttachmentService attachmentService = new MockAttachmentService();
    AttachedFile attachedFile = new AttachedFile("test".getBytes());
    attachmentService
        .addTemplate(new MockAttachment(1, "test", "test", DocumentType.LEGAL, 1, "text/html", attachedFile),
            "test");
    attachmentService
        .addTemplate(new MockAttachment(1, "test", "test", DocumentType.SHIPPING, 1, "text/html", attachedFile),
            "test");
    attachmentService
        .addTemplate(new MockAttachment(1, "test", "test", DocumentType.OTHER, 1, "text/html", attachedFile),
            "test");
    MockAttachmentControllerForPrepareContent controller = new MockAttachmentControllerForPrepareContent(
        attachmentService, lookupService);
    helper.setRequestParameterValue("method", "generateAttachment");
    helper.setRequestParameterValue("requestId", "1");
    helper.setRequestParameterValue("template", "1");
    controller.run(helper);
    assertTrue(controller.wasPrepared());
  }

  public void testPrepareContentParsesCorrectly() throws Exception {
    String beforeString = "Test: ~~requestNumber~~";
    String expectedAfterString = "Test: SRWG-1234";
    LookupService lookupService = new MockLookupServiceForPrepareContent();
    MockAttachmentControllerForVisibility controller = new MockAttachmentControllerForVisibility(
        new MockAttachmentService(),
        lookupService);
    String afterString = new String(controller.prepareContent(beforeString.getBytes(), "1"));
    assertEquals(expectedAfterString, afterString);
  }

  public void testMaterialsIsParsedCorrectly() throws Exception {
    String beforeString = "Test: ~~materials~~";
    String expectedAfterString = "Test: testType:testDesc<br>\n";
    LookupService lookupService = new MockLookupServiceForPrepareContentWithMaterial();
    MockAttachmentControllerForVisibility controller = new MockAttachmentControllerForVisibility(
        new MockAttachmentService(),
        lookupService);
    String afterString = new String(controller.prepareContent(beforeString.getBytes(), "1"));
    assertEquals(expectedAfterString, afterString);
  }

  private class MockLookupServiceForPrepareContent extends MockLookupService {
    public RequestProfile lookupRequestById(Long requestId) {
      RequestProfile request = new RequestProfile(requestId);
      request.setRequestNumber("SRWG-1234");
      return request;
    }
  }

  private class MockLookupServiceForPrepareContentWithMaterial extends MockLookupService {
    public RequestProfile lookupRequestById(Long requestId) {
      RequestProfile request = new RequestProfile(requestId);
      request.setRequestNumber("SRWG-1234");
      return request;
    }


    public List lookupResearchRequestListByRequestId(Long requestId) {
      List researchList = new ArrayList();
      researchList.add(
          new RequestResearchType(new Long(1), new Long(1), new Long(1), "testType", "testDesc", new Date(), "test"));
      return researchList;
    }
  }

  private class MockAttachmentControllerForVisibility extends RequestAttachmentAbstractController {
    protected MockAttachmentControllerForVisibility(AttachmentService attachmentService, LookupService lookupService) {
      super(attachmentService, new MockSequenceService(), lookupService,
          new MockLookupReferenceDataService(), new MockViewFactory(), new MockStatusUpdateService(),
          new MockRequestSearchService());
    }

    public byte[] prepareContent(byte[] content, String requestId) {
      return super.prepareContent(content, requestId);
    }

    protected View getCreateView(ViewFactory viewFactory) {
      return new MockView();
    }

    protected void updateStatusToComplete(StatusUpdateService statusService, RequestProfile requestProfile,
                                          String modUser) {
    }

    protected String getStatusDescription() {
      return null;
    }

    protected View getAttachView(ViewFactory viewFactory) {
      return null;
    }

    protected DocumentType getDocType() {
      return DocumentType.LEGAL;
    }

    protected String getURLBaseForSearchResults() {
      return null;
    }

    protected Privilege[] getPrivsForCreate() {
      return new Privilege[0];
    }

    protected Privilege[] getPrivsForAttach() {
      Privilege[] privs = new Privilege[1];
      privs[0] = Privilege.ATTACH_LEGAL;
      return privs;
    }

    protected String getSearchTitle() {
      return null;
    }
  }

  private class MockAttachmentControllerForPrepareContent extends MockAttachmentControllerForVisibility {
    private boolean prepared = false;

    protected MockAttachmentControllerForPrepareContent(AttachmentService attachmentService,
                                                        LookupService lookupService) {
      super(attachmentService, lookupService);
    }

    public byte[] prepareContent(byte[] content, String requestId) {
      prepared = true;
      return content;
    }

    public boolean wasPrepared() {
      return prepared;
    }
  }
}