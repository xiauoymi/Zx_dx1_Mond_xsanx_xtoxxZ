/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.externaltechrequests.controller.test;

import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebResponse;
import com.monsanto.KerberosPOSSecurity.Test.KerberosSecurityATBase;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;

/**
 * Filename:    $RCSfile: RequestController_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-04-18 15:38:08 $
 *
 * @author jdpoul
 * @version $Revision: 1.9 $
 */
public class RequestController_AT extends KerberosSecurityATBase {
  public RequestController_AT(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    startProxyServer();
  }

  public void testPlaceholder() throws Exception {
     //todo THIS IS JUST A PLACE HOLDER
  }

  //todo FIX THIS TEST NEXT TIME ANYONE TOUCHES THIS CODE
/*  
  we couldn't get the project setup locally without alot of effort due to tomcat 5.0/5.5 issues
  fix this when we go to update the project for the Java 1.5 tomcat issue and then reenable this test

  public void testUpdateRequest_ValidRequestProfile_ValidateRequestNumberPresent() throws Exception {
    WebResponse response = conversation
        .getResponse("http://w3devel.kerberos.monsanto.com/srwgrequesttracking/servlet/new_request.html");
    WebForm requestForm1 = response.getForms()[0];
    requestForm1.setParameter(MainConstants.REQUESTOR_NAME_PARAM_NAME, "asdgds");
    requestForm1.setParameter(MainConstants.SPONSOR_PARAM_NAME, requestForm1.getOptionValues(MainConstants.SPONSOR_PARAM_NAME)[1]);
    WebResponse response1 = requestForm1.submit();
    WebForm requestForm2 = response1.getForms()[0];
    String expectedRequestNumber = requestForm2.getParameterValue(MainConstants.REQUEST_NUMBER_PARAM_NAME);
    requestForm2.setParameter(MainConstants.REQUESTOR_TITLE_PARAM_NAME, "sgsdg");
    try {
      requestForm2.setParameter(MainConstants.REQUEST_NUMBER_PARAM_NAME, "test");
      requestForm1.setParameter(MainConstants.SPONSOR_PARAM_NAME, requestForm1.getOptionValues(MainConstants.SPONSOR_PARAM_NAME)[1]);
      fail("expected Exception");
    } catch (RuntimeException e) {
      assertEquals("com.meterware.httpunit.MissingParameterValueException: Parameter 'request_number' must have the value '"+ expectedRequestNumber+ "'. Attempted to set it to: { test }", e.toString());
    }
    WebResponse finalResponse = requestForm2.submit();
    assertNotNull(finalResponse.getForms()[0].getParameterValue(MainConstants.REQUESTOR_TITLE_PARAM_NAME));
    String requestNumber = finalResponse.getForms()[0].getParameterValue(MainConstants.REQUEST_NUMBER_PARAM_NAME);
    assertNotNull(requestNumber);
    assertEquals(expectedRequestNumber, requestNumber);
  }
*/

}