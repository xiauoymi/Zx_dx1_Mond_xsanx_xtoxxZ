/*
 RequestController_UT was created on Nov 7, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.controller.ModifiableAttachment;
import com.monsanto.wst.externaltechrequests.controller.RequestController;
import com.monsanto.wst.externaltechrequests.document.AttachmentCollection;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.model.test.MockAttachmentService;
import com.monsanto.wst.externaltechrequests.security.test.MockPrivilegedUser;
import com.monsanto.wst.externaltechrequests.security.test.MockReadonlyUser;
import com.monsanto.wst.externaltechrequests.security.test.MockUserFactory;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupReferenceDataService;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupService;
import com.monsanto.wst.externaltechrequests.services.mock.MockRequestService;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.view.factory.mock.MockViewFactory;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpRequestMessages;
import com.monsanto.wst.validator.test.mock.MockHttpValidator;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: RequestController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:57 $
 *
 * @author ffbrac
 * @version $Revision: 1.30 $
 */
public class RequestController_UT extends TestCase {
  private MockUCCHelper helper;

  private MockStatusUpdateService statusService;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper("/test");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    statusService = new MockStatusUpdateService();
  }

  public void testCreate() throws Exception {
    RequestController controller = new RequestController(null, null,
        null, null, null, new MockUserFactory(),
        new MockAttachmentService(), statusService);
    assertNotNull(controller);
  }

  public void testRequestControllerNotSpecifiedMethod() throws Exception {
    MockViewFactory viewFactory = new MockViewFactory();
    MockUserFactory userFactory = new MockUserFactory();
    userFactory.addUser("test", "test", "test", new String[0], "test");
    RequestController controller = new RequestController(new MockRequestService(), new MockLookupReferenceDataService(),
        new MockLookupService(), viewFactory, new MockHttpValidator(), userFactory, new MockAttachmentService(),
        statusService);
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
    MockView view = (MockView) viewFactory.getRequestView();
    assertTrue(view.wasViewRendered());
    List states = (List) helper.getRequestAttributeValue("states");
    assertNotNull(states);
    List users = (List) helper.getRequestAttributeValue("users");
    assertNotNull(users);
  }

  public void testSaveRequestProfile_NewValidProfile_ValidateSuccessMessage() throws Exception {
    RequestController controller = new RequestController(new MockRequestService(), new MockLookupReferenceDataService(),
        new MockLookupService(), new MockViewFactory(), new MockHttpValidator(), new MockUserFactory(),
        new MockAttachmentService(), statusService);
    helper.setRequestParameterValue(MainConstants.REQUEST_NUMBER_PARAM_NAME, "SRWG-2007-0061");
    setupHelperWValidRequestProfileAttributes(helper);
    controller.saveRequestProfile(helper);
    HttpRequestMessages messages = (HttpRequestMessages) helper.getRequestAttributeValue("messages");
    String message = (String) messages.getMessages().get(0);
    assertEquals("Request # SRWG-2007-0061 has been successfully entered.", message);
  }

  public void testSaveRequestProfile_NewValidProfile_UpdatesStatus() throws Exception {
    RequestController controller = new RequestController(new MockRequestService(), new MockLookupReferenceDataService(),
        new MockLookupService(), new MockViewFactory(), new MockHttpValidator(), new MockUserFactory(),
        new MockAttachmentService(),
        statusService);
    helper.setRequestParameterValue(MainConstants.REQUEST_NUMBER_PARAM_NAME, "SRWG-2007-0061");
    setupHelperWValidRequestProfileAttributes(helper);
    controller.saveRequestProfile(helper);
    assertTrue(statusService.isSetToNew());
  }

  public void testSaveRequestProfile_AlreadyPersistedValidProfile_ValidateSuccessMessage() throws Exception {
    RequestController controller = new RequestController(new MockRequestService(), new MockLookupReferenceDataService(),
        new MockLookupService(), new MockViewFactory(), new MockHttpValidator(), new MockUserFactory(),
        new MockAttachmentService(),
        statusService);
    helper.setRequestParameterValue(MainConstants.REQUEST_NUMBER_PARAM_NAME, "SRWG-2007-0061");
    setupHelperWValidRequestProfileAttributes(helper);
    helper.setRequestParameterValue(MainConstants.REQUEST_ID_PARAM_NAME, new Long(1));
    controller.saveRequestProfile(helper);
    HttpRequestMessages messages = (HttpRequestMessages) helper.getRequestAttributeValue("messages");
    String message = (String) messages.getMessages().get(0);
    assertEquals("Request # SRWG-2007-0061 has been successfully updated.", message);
  }

  public void testSaveRequestProfile_HttpValidatorHasErrors_RendersErrorView() throws Exception {
    ViewFactory factory = new MockViewFactory();
    HttpRequestErrors errors = new HttpRequestErrors();
    String exceptionMessage = "exception message";
    String category = "exception";
    errors.addError(category, exceptionMessage);
    MockHttpValidator validator = new MockHttpValidator(errors);
    RequestController controller = new RequestController(new MockRequestService(), new MockLookupReferenceDataService(),
        new MockLookupService(), factory, validator, new MockUserFactory(), new MockAttachmentService(), statusService);
    controller.saveRequestProfile(helper);
    MockView requestView = (MockView) factory.getRequestView();
    assertEquals(exceptionMessage, ((HttpRequestErrors) helper.getRequestAttributeValue("errors")).getError(category));
    assertTrue(requestView.wasViewRendered());
  }

  public void testHasAttachmentsForRequest() throws Exception {
    AttachmentService attachmentService = new MockAttachmentService();
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    ViewFactory viewFactory = new MockViewFactory();
    Attachment attach1 = new MockAttachment(1, "test", "test", DocumentType.LEGAL, 2);
    Attachment attach2 = new MockAttachment(2, "test", "test", DocumentType.SHIPPING, 2);
    Attachment attach3 = new MockAttachment(3, "test", "test", DocumentType.OTHER, 2);
    attachmentService.addAttachment(attach1, "test");
    attachmentService.addAttachment(attach2, "test");
    attachmentService.addAttachment(attach3, "test");
    RequestController controller = new RequestController(new MockRequestService(), new MockLookupReferenceDataService(),
        new MockLookupService(), viewFactory, new MockHttpValidator(), new MockUserFactory(), attachmentService,
        statusService);
    helper.setRequestParameterValue("method", "editRequestEntry");
    helper.setRequestParameterValue("requestId", "2");
    controller.run(helper);
    AttachmentCollection attachments = (AttachmentCollection) helper
        .getRequestAttributeValue(MainConstants.ATTACHMENTS_ATTRIBUTE_NAME);
    assertNotNull(attachments);
    assertEquals(1, attachments.getLegalAttachments().size());
    assertEquals(1, attachments.getShippingAttachments().size());
    assertEquals(1, attachments.getOtherAttachments().size());
  }

  public void testCanEditAndCanDeleteAreBeingSet() throws Exception {
    AttachmentService attachmentService = new MockAttachmentService();
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    ViewFactory viewFactory = new MockViewFactory();
    Attachment attach1 = new MockAttachment(1, "test", "test", DocumentType.LEGAL, 2, "text/html");
    Attachment attach2 = new MockAttachment(2, "test", "test", DocumentType.SHIPPING, 2, "text/html");
    Attachment attach3 = new MockAttachment(3, "test", "test", DocumentType.OTHER, 2, "text/html");
    attachmentService.addAttachment(attach1, "test");
    attachmentService.addAttachment(attach2, "test");
    attachmentService.addAttachment(attach3, "test");
    RequestController controller = new RequestController(new MockRequestService(), new MockLookupReferenceDataService(),
        new MockLookupService(), viewFactory, new MockHttpValidator(), new MockUserFactory(), attachmentService,
        statusService);
    helper.setRequestParameterValue("method", "editRequestEntry");
    helper.setRequestParameterValue("requestId", "2");
    controller.run(helper);
    AttachmentCollection attachments = (AttachmentCollection) helper
        .getRequestAttributeValue(MainConstants.ATTACHMENTS_ATTRIBUTE_NAME);
    assertNotNull(attachments);
    ModifiableAttachment attachment = (ModifiableAttachment) attachments.getLegalAttachments().get(0);
    assertTrue(attachment.isEditable());
    assertTrue(attachment.isDeletable());
  }

  public void testNotEditableWhenWrongMimeType() throws Exception {
    AttachmentService attachmentService = new MockAttachmentService();
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    ViewFactory viewFactory = new MockViewFactory();
    Attachment attach1 = new MockAttachment(1, "test", "test", DocumentType.LEGAL, 2, "something/notunderstood");
    Attachment attach2 = new MockAttachment(2, "test", "test", DocumentType.SHIPPING, 2, "something/notunderstood");
    Attachment attach3 = new MockAttachment(3, "test", "test", DocumentType.OTHER, 2, "something/notunderstood");
    attachmentService.addAttachment(attach1, "test");
    attachmentService.addAttachment(attach2, "test");
    attachmentService.addAttachment(attach3, "test");
    RequestController controller = new RequestController(new MockRequestService(), new MockLookupReferenceDataService(),
        new MockLookupService(), viewFactory, new MockHttpValidator(), new MockUserFactory(), attachmentService,
        statusService);
    helper.setRequestParameterValue("method", "editRequestEntry");
    helper.setRequestParameterValue("requestId", "2");
    controller.run(helper);
    AttachmentCollection attachments = (AttachmentCollection) helper
        .getRequestAttributeValue(MainConstants.ATTACHMENTS_ATTRIBUTE_NAME);
    assertNotNull(attachments);
    ModifiableAttachment attachment = (ModifiableAttachment) attachments.getLegalAttachments().get(0);
    assertFalse(attachment.isEditable());
    assertTrue(attachment.isDeletable());
  }

  public void testViewOnlyRequestShownForViewOnlyUser() throws Exception {
    AttachmentService attachmentService = new MockAttachmentService();
    helper.setSessionParameter("user", new MockReadonlyUser("mock"));
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForReadOnlyRequest(view);
    RequestController controller = new RequestController(new MockRequestService(), new MockLookupReferenceDataService(),
        new MockLookupService(), viewFactory, new MockHttpValidator(), new MockUserFactory(), attachmentService,
        statusService);
    helper.setRequestParameterValue("method", "saveRequestProfile");
    helper.setRequestParameterValue("requestId", "2");
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  public void testPrintDisplayReadOnlyRequestWithJavascript() throws Exception {
    AttachmentService attachmentService = new MockAttachmentService();
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForReadOnlyRequest(view);
    RequestController controller = new RequestController(new MockRequestService(), new MockLookupReferenceDataService(),
        new MockLookupService(), viewFactory, new MockHttpValidator(), new MockUserFactory(), attachmentService,
        statusService);
    helper.setRequestParameterValue("method", "print");
    helper.setRequestParameterValue("requestId", "2");
    controller.run(helper);
    assertTrue(view.wasViewRendered());
    assertNotNull(helper.getRequestAttributeValue("loadJavascript"));
  }

  private void setupHelperWValidRequestProfileAttributes(MockUCCHelper helper) {
    helper.setRequestParameterValue(MainConstants.REQUEST_RESEARCH_PARAM_NAME, "1");
    helper.setRequestParameterValue(MainConstants.RESEARCH_DESC_PARAM_NAME, "testDescr1");
    helper.setRequestParameterValue(MainConstants.REGION_PARAM_NAME, "3");
    helper.setRequestParameterValue(MainConstants.REQUEST_TYPE_PARAM_NAME, "2");
    helper.setRequestParameterValue(MainConstants.COMMITTEE_APPROVED_PARAM_NAME, "1");
    helper.setRequestParameterValue(MainConstants.STATUS_PARAM_NAME, "1");
    helper.setRequestParameterValue(MainConstants.STUDY_LENGTH_PARAM_NAME, "1");
  }

  private class MockViewFactoryForReadOnlyRequest extends MockViewFactory {
    private final View view;

    MockViewFactoryForReadOnlyRequest(View view) {
      this.view = view;
    }

    public View getReadonlyRequestView() {
      return view;
    }
  }
}