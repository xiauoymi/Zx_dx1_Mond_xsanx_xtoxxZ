package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.controller.ReviewController;
import com.monsanto.wst.externaltechrequests.controller.SearchParameters;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.model.test.MockAttachmentService;
import com.monsanto.wst.externaltechrequests.security.test.MockPrivilegedUser;
import com.monsanto.wst.externaltechrequests.security.test.MockUser;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupService;
import com.monsanto.wst.externaltechrequests.services.mock.MockRequestSearchService;
import com.monsanto.wst.externaltechrequests.view.factory.mock.MockViewFactory;
import com.monsanto.wst.externaltechrequests.workflow.test.MockRequestEmailer;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/*
 ReviewController_UT was created on Feb 7, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class ReviewController_UT extends TestCase {
  private MockUCCHelper helper;
  private MockStatusUpdateService statusService;
  private MockRequestEmailer requestEmailer;
  private MockLookupService lookupService;
  private MockAttachmentService attachmentService;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper("/test");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    statusService = new MockStatusUpdateService();
    requestEmailer = new MockRequestEmailer();
    lookupService = new MockLookupService();
    attachmentService = new MockAttachmentService();
  }

  public void testCreate() throws Exception {
    ReviewController controller = new ReviewController(new MockRequestSearchService(), new MockViewFactory(),
        statusService, lookupService, requestEmailer,
        attachmentService);
    assertNotNull(controller);
  }

  public void testControllerNotSpecifiedMethod() throws Exception {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForReviewView(view);
    List testRequests = new ArrayList();
    testRequests.add(new RequestProfile());
    MockRequestSearchService requestSearchService = new MockRequestSearchService(testRequests);
    ReviewController controller = new ReviewController(requestSearchService, viewFactory, statusService, lookupService,
        requestEmailer, attachmentService);
    controller.run(helper);
    assertTrue(view.wasViewRendered());
    RequestSearch search = requestSearchService.getRequestSearch();
    assertNotNull(search);
    assertEquals(MainConstants.STATUS_ID_NEW, search.getStatusId());
    List requests = (List) helper.getRequestAttributeValue(MainConstants.SEARCH_RESULTS_ATTRIBUTE);
    assertNotNull(requests);
    assertEquals(1, requests.size());
    assertEquals(testRequests.get(0), requests.get(0));
    SearchParameters searchParams = (SearchParameters) helper
        .getRequestAttributeValue(MainConstants.SEARCH_PARAMETERS_ATTRIBUTE);
    assertNotNull(searchParams);
    assertNotNull(searchParams.getBaseUrl());
  }

  public void testNotAuthorizedCausesException() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    ReviewController controller = new ReviewController(new MockRequestSearchService(), new MockViewFactory(),
        statusService, lookupService, requestEmailer, attachmentService);
    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception e) {
      // ignore expected
    }
  }

  public void testNotAuthorizedCausesExceptionOnSendToCommittee() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    ReviewController controller = new ReviewController(new MockRequestSearchService(), new MockViewFactory(),
        statusService, lookupService, requestEmailer, attachmentService);
    helper.setRequestParameterValue("method", "committeeReport");
    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception e) {
      // ignore expected
    }
  }

  public void testSendToCommittee() throws Exception {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForReviewView(view);
    MockRequestSearchService requestSearchService = new MockRequestSearchService();
    ReviewController controller = new ReviewController(requestSearchService, viewFactory, statusService, lookupService,
        requestEmailer, attachmentService);
    String[] requestIds = new String[1];
    requestIds[0] = "1234";
    RequestProfile request = new RequestProfile();
    request.setId(new Long(requestIds[0]));
    lookupService.setProfile(request);
    helper.setRequestParameterValue("method", "committeeReport");
    helper.setRequestParameterValue("requestIds", requestIds);
    controller.run(helper);
    assertTrue(view.wasViewRendered());
    assertTrue(statusService.isSetToSentToCommittee());
    assertTrue(requestEmailer.wasEmailSent(requestIds[0]));
  }

  private class MockViewFactoryForReviewView extends MockViewFactory {
    private final View view;

    MockViewFactoryForReviewView(View view) {
      this.view = view;
    }

    public View getReviewView() {
      return view;
    }
  }
}