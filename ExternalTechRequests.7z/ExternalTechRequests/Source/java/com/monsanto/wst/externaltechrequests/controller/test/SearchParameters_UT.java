package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.wst.externaltechrequests.controller.SearchParameters;
import junit.framework.TestCase;

/*
 SearchParameters_UT was created on Jan 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class SearchParameters_UT extends TestCase {
  public void testGetters() throws Exception {
    String testTitle = "Test";
    String testUrl = "www.www.com";
    SearchParameters searchParams = new SearchParameters(testTitle, true, true, true, testUrl);
    assertEquals(testTitle, searchParams.getTitle());
    assertTrue(searchParams.isCriteriaShown());
    assertTrue(searchParams.isResultsShown());
    assertTrue(searchParams.isExportShown());
    assertEquals(testUrl, searchParams.getBaseUrl());
  }
}