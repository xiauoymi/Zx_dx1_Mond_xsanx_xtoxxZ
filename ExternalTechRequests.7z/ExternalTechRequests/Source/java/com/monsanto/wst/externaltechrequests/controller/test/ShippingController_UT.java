package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.administerreferencedata.services.SequenceLookupService;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.controller.ShippingController;
import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.document.AttachmentCollection;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.model.AttachmentMetadata;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.test.MockAttachmentService;
import com.monsanto.wst.externaltechrequests.security.test.MockPrivilegedUser;
import com.monsanto.wst.externaltechrequests.security.test.MockUser;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
import com.monsanto.wst.externaltechrequests.services.LookupReferenceDataService;
import com.monsanto.wst.externaltechrequests.services.LookupService;
import com.monsanto.wst.externaltechrequests.services.RequestSearchService;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupReferenceDataService;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupService;
import com.monsanto.wst.externaltechrequests.services.mock.MockRequestSearchService;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/*
 ShippingController_UT was created on Feb 5, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class ShippingController_UT extends TestCase {
  private static final String TEST_FILENAME = "com/monsanto/wst/externaltechrequests/controller/test/test.doc";
  private static final String TEST_MIME_TYPE = "application/msword";
  private static final String TEST_DESCRIPTION = "Test File";

  private MockUCCHelper helper;
  private MockStatusUpdateService statusService;
  private LookupReferenceDataService lookupReferenceDataService;
  private LookupService lookupService;
  private RequestSearchService requestSearchService;
  private AttachmentService attachmentService;
  private SequenceLookupService sequenceService;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper("MOCK");
    requestSearchService = new MockRequestSearchService();
    statusService = new MockStatusUpdateService();
    lookupReferenceDataService = new MockLookupReferenceDataService();
    lookupService = new MockLookupService();
    attachmentService = new MockAttachmentService();
    sequenceService = new MockSequenceService();
  }

  public void testNotPrivilegedCausesExceptionOnSearchPage() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForSearch(view);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception IGNORE) {
      // ignore expected exception
    }
  }

  public void testLegalPrivilegesCanViewSearchPage() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForSearch(view);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  public void testNotPrivilegedCausesExceptionOnAttachPage() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForAttachShipping(view);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "attachTemplate");
    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception IGNORE) {
      // ignore expected exception
    }
  }

  public void testShippingPrivilegesCanViewAttachPage() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForAttachShipping(view);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "attachTemplate");
    helper.setRequestParameterValue("requestId", "2");
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  public void testShippingPrivilegesShowsQueryIfNoRequestId() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForSearch(view);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "attachTemplate");
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  public void testWithoutCreatePrivCausesExceptionOnCreate() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForCreateShipping(view);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "createNewTemplate");

    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception IGNORE) {
      // ignore expected exception
    }
  }

  public void testWithoutAttachPrivCausesExceptionOnAttach() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForCreateShipping(view);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "saveAttachment");

    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception IGNORE) {
      // ignore expected exception
    }
  }

  private List getNewAttachments(List oldItems, List currItems) {
    List newItems = new ArrayList();
    for (int i = 0; i < currItems.size(); i++) {
      Attachment attachment = (Attachment) currItems.get(i);
      AttachmentMetadata meta = attachment.getMetadata();
      assertNotNull(meta);
      if (isNewAttachment(oldItems, attachment)) {
        newItems.add(attachment);
      }
    }

    return newItems;
  }

  public void testCreateWithFile() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForCreateShipping(view);
    Attachment newAttachment = callControllerToAddTemplate(viewFactory, TEST_DESCRIPTION, TEST_FILENAME);
    assertNotNull(newAttachment);
    AttachmentMetadata meta = newAttachment.getMetadata();
    assertNotNull(meta);
    assertNotNull(meta.getId());
    assertEquals(TEST_DESCRIPTION, meta.getDescription());
    assertNotNull(meta.getAttachmentType());
    assertNotNull(meta.getName());
    assertTrue(meta.getName().length() > 0);
    assertTrue(TEST_FILENAME.indexOf(meta.getName()) >= 0);
    assertEquals(TEST_MIME_TYPE, meta.getMimeType());

    AttachedFile file = newAttachment.getAttachedFile();
    assertNotNull(file);
    byte[] data = file.getContent();
    assertNotNull(data);
    assertTrue(Arrays.equals("Hello".getBytes(), data));
  }

  public void testAttachWithFile() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForCreateShipping(view);
    RequestProfile request = new RequestProfile(new Long(12345L));
    Attachment newAttachment = callControllerToAddAttachment(viewFactory, TEST_DESCRIPTION, TEST_FILENAME, request);
    assertNotNull(newAttachment);
    AttachmentMetadata meta = newAttachment.getMetadata();
    assertNotNull(meta);
    assertNotNull(meta.getId());
    assertEquals(request.getId(), meta.getRequestId());
    assertEquals(TEST_DESCRIPTION, meta.getDescription());
    assertNotNull(meta.getAttachmentType());
    assertNotNull(meta.getName());
    assertTrue(meta.getName().length() > 0);
    assertTrue(TEST_FILENAME.indexOf(meta.getName()) >= 0);
    assertEquals(TEST_MIME_TYPE, meta.getMimeType());

    AttachedFile file = newAttachment.getAttachedFile();
    assertNotNull(file);
    byte[] data = file.getContent();
    assertNotNull(data);
    assertTrue(Arrays.equals("Hello".getBytes(), data));
  }

  private Attachment callControllerToAddTemplate(ViewFactory viewFactory, String testDescription,
                                                 String testFilename) throws
      IOException {
    List oldAttachments = attachmentService.getTemplates(DocumentType.SHIPPING);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "saveTemplate");
    helper.setRequestParameterValue("description", testDescription);
    helper.addClientFile(testFilename);
    controller.run(helper);
    List attachments = attachmentService.getTemplates(DocumentType.SHIPPING);
    List newAttachments = getNewAttachments(oldAttachments, attachments);
    assertEquals(1, newAttachments.size());
    return (Attachment) newAttachments.get(0);
  }

  private Attachment callControllerToAddAttachment(ViewFactory viewFactory, String testDescription,
                                                   String testFilename, RequestProfile request)
      throws IOException {
    Long requestId = request.getId();
    List oldAttachments = attachmentService.getAttachments(requestId, new MockPrivilegedUser("test"))
        .getShippingAttachments();
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "saveAttachment");
    helper.setRequestParameterValue("description", testDescription);
    helper.setRequestParameterValue("requestId", requestId);
    helper.addClientFile(testFilename);
    controller.run(helper);
    List attachments = attachmentService.getAttachments(requestId, new MockPrivilegedUser("test"))
        .getShippingAttachments();
    List newAttachments = getNewAttachments(oldAttachments, attachments);
    assertEquals(1, newAttachments.size());
    return (Attachment) newAttachments.get(0);
  }

  private boolean isNewAttachment(List oldAttachments, Attachment attachment) {
    Long id = attachment.getMetadata().getId();
    for (int i = 0; i < oldAttachments.size(); i++) {
      Attachment oldAttachment = (Attachment) oldAttachments.get(i);
      if (id.equals(oldAttachment.getMetadata().getId())) {
        return false;
      }
    }
    return true;
  }

  public void testWithoutPrivCausesExceptionOnCreateWithFile() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForCreateShipping(view);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "saveTemplate");

    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception IGNORE) {
      // ignore expected exception
    }
  }

  public void testCreatePageWithPrivs() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForCreateShipping(view);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "createNewTemplate");
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  public void testAttachPageHasTemplateList() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForAttachShipping(view);
    Attachment attach1 = new MockAttachment(1, "test", "test", DocumentType.LEGAL, 1);
    Attachment attach2 = new MockAttachment(2, "test", "test", DocumentType.SHIPPING, 2);
    Attachment attach3 = new MockAttachment(3, "test", "test", DocumentType.LEGAL, 3);
    attachmentService.addTemplate(attach1, "test");
    attachmentService.addTemplate(attach2, "test");
    attachmentService.addTemplate(attach3, "test");
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "attachTemplate");
    helper.setRequestParameterValue("requestId", "2");
    controller.run(helper);
    assertTrue(view.wasViewRendered());
    List templates = (List) helper.getRequestAttributeValue(MainConstants.TEMPLATES_ATTRIBUTE_NAME);
    assertNotNull(templates);
    assertEquals(1, templates.size());
    assertEquals(attach2, templates.get(0));
  }

  public void testShippingComplete() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForAttachShipping(view);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "complete");
    helper.setRequestParameterValue("requestId", "1");
    controller.run(helper);

    assertTrue(statusService.isSetToComplete());
  }

  public void testShippingCompleteDoesntUpdateIfNoRequestIdIsSpecified() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForAttachShipping(view);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "complete");
    controller.run(helper);

    assertFalse(statusService.isSetToShipping());
  }

  public void testShippingCompleteNotAllowedIfNotAuthorized() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForAttachShipping(view);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "complete");
    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception IGNORE) {
      // ignore expected exception
    }
  }

  public void testGenerateAttachment() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    MockView view = new MockView();
    ViewFactory viewFactory = new MockViewFactoryForAttachShipping(view);
    Attachment newAttachment = callControllerToAddTemplate(viewFactory, TEST_DESCRIPTION, TEST_FILENAME);
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "generateAttachment");
    helper.setRequestParameterValue("requestId", "1");
    helper.setRequestParameterValue("template", newAttachment.getMetadata().getId().toString());
    ByteArrayOutputStream outputFromController = new ByteArrayOutputStream();
    helper.setBinaryStream(outputFromController);
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
    byte[] data = outputFromController.toByteArray();
    assertNotNull(data);
    assertFalse(data.length == 0);
  }

  public void testHasAttachmentsForRequest() throws Exception {
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    ViewFactory viewFactory = new MockViewFactory();
    Attachment attach1 = new MockAttachment(1, "test", "test", DocumentType.LEGAL, 2);
    Attachment attach2 = new MockAttachment(2, "test", "test", DocumentType.SHIPPING, 2);
    Attachment attach3 = new MockAttachment(3, "test", "test", DocumentType.OTHER, 2);
    attachmentService.addAttachment(attach1, "test");
    attachmentService.addAttachment(attach2, "test");
    attachmentService.addAttachment(attach3, "test");
    ShippingController controller = new ShippingController(statusService, lookupReferenceDataService,
        requestSearchService, lookupService, viewFactory,
        attachmentService, sequenceService);
    helper.setRequestParameterValue("method", "attachTemplate");
    helper.setRequestParameterValue("requestId", "2");
    controller.run(helper);
    AttachmentCollection attachments = (AttachmentCollection) helper
        .getRequestAttributeValue(MainConstants.ATTACHMENTS_ATTRIBUTE_NAME);
    assertNotNull(attachments);
    assertEquals(1, attachments.getLegalAttachments().size());
    assertEquals(1, attachments.getShippingAttachments().size());
    assertEquals(1, attachments.getOtherAttachments().size());
  }

  private static class MockViewFactoryForAttachShipping extends MockViewFactory {
    private final View view;

    MockViewFactoryForAttachShipping(View view) {
      this.view = view;
    }

    public View getAttachShippingView() {
      return view;
    }
  }

  private static class MockViewFactoryForCreateShipping extends MockViewFactory {
    private final View view;

    MockViewFactoryForCreateShipping(View view) {
      this.view = view;
    }

    public View getCreateShippingAttachmentView() {
      return view;
    }

  }

  private static class MockViewFactoryForSearch extends MockViewFactory {
    private final View view;

    MockViewFactoryForSearch(View view) {
      this.view = view;
    }

    public View getSearchRequestProfileView() {
      return view;
    }
  }

}