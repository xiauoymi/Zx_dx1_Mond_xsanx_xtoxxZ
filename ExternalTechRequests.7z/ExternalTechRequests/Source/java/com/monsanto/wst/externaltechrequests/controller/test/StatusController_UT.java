package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.controller.SearchParameters;
import com.monsanto.wst.externaltechrequests.controller.StatusController;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.model.test.MockAttachmentService;
import com.monsanto.wst.externaltechrequests.security.test.MockPrivilegedUser;
import com.monsanto.wst.externaltechrequests.security.test.MockUser;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupReferenceDataService;
import com.monsanto.wst.externaltechrequests.services.mock.MockLookupService;
import com.monsanto.wst.externaltechrequests.services.mock.MockRequestSearchService;
import com.monsanto.wst.externaltechrequests.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/*
 StatusController_UT was created on Feb 9, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class StatusController_UT extends TestCase {
  private MockUCCHelper helper;
  private MockStatusUpdateService statusService;
  private MockLookupService lookupService;
  private MockAttachmentService attachmentService;
  private MockLookupReferenceDataService lookupReferenceDataService;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper("/test");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    statusService = new MockStatusUpdateService();
    lookupService = new MockLookupService();
    attachmentService = new MockAttachmentService();
    lookupReferenceDataService = new MockLookupReferenceDataService();
  }

  public void testCreate() throws Exception {
    StatusController controller = new StatusController(new MockRequestSearchService(), new MockViewFactory(),
        statusService, lookupService,
        attachmentService, lookupReferenceDataService);
    assertNotNull(controller);
  }

  public void testControllerNotSpecifiedMethod() throws Exception {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForSearchView(view);
    List testRequests = new ArrayList();
    testRequests.add(new RequestProfile());
    MockRequestSearchService requestSearchService = new MockRequestSearchService(testRequests);
    StatusController controller = new StatusController(requestSearchService, viewFactory, statusService, lookupService,
        attachmentService, lookupReferenceDataService);
    controller.run(helper);
    assertTrue(view.wasViewRendered());
    RequestSearch search = requestSearchService.getRequestSearch();
    assertNotNull(search);
    List requests = (List) helper.getRequestAttributeValue(MainConstants.SEARCH_RESULTS_ATTRIBUTE);
    assertNotNull(requests);
    assertEquals(1, requests.size());
    assertEquals(testRequests.get(0), requests.get(0));
  }

  public void testNotAuthorizedCausesException() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    StatusController controller = new StatusController(new MockRequestSearchService(), new MockViewFactory(),
        statusService, lookupService, attachmentService, lookupReferenceDataService);
    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception e) {
      // ignore expected
    }
  }

  public void testControllerHasCorrectURL() throws Exception {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForSearchView(view);
    List testRequests = new ArrayList();
    testRequests.add(new RequestProfile());
    MockRequestSearchService requestSearchService = new MockRequestSearchService(testRequests);
    StatusController controller = new StatusController(requestSearchService, viewFactory, statusService, lookupService,
        attachmentService, lookupReferenceDataService);
    controller.run(helper);
    SearchParameters searchParameters = (SearchParameters) helper.getRequestAttributeValue("searchParameters");
    assertNotNull(searchParameters);
    assertTrue(searchParameters.getBaseUrl().indexOf("status.html") >= 0);
    assertTrue(searchParameters.getBaseUrl().indexOf("method=editStatus") >= 0);
    assertNotNull(searchParameters.getTitle());
  }

  public void testEditNotAuthorizedCausesException() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    StatusController controller = new StatusController(new MockRequestSearchService(), new MockViewFactory(),
        statusService, lookupService, attachmentService, lookupReferenceDataService);
    helper.setRequestParameterValue("method", "editStatus");
    helper.setRequestParameterValue("requestId", "123");
    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception e) {
      // ignore expected
    }
  }

  public void testControllerEditStatus() throws Exception {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForStatusView(view);
    List testRequests = new ArrayList();
    testRequests.add(new RequestProfile());
    MockRequestSearchService requestSearchService = new MockRequestSearchService(testRequests);
    StatusController controller = new StatusController(requestSearchService, viewFactory, statusService, lookupService,
        attachmentService, lookupReferenceDataService);
    helper.setRequestParameterValue("method", "editStatus");
    helper.setRequestParameterValue("requestId", "123");
    controller.run(helper);
    assertTrue(view.wasViewRendered());
    RequestProfile request = (RequestProfile) helper.getRequestAttributeValue("request");
    assertNotNull(request);
  }

  public void testControllerCallsNotSpecifiedIfNoRequestId() throws Exception {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForSearchView(view);
    List testRequests = new ArrayList();
    testRequests.add(new RequestProfile());
    MockRequestSearchService requestSearchService = new MockRequestSearchService(testRequests);
    StatusController controller = new StatusController(requestSearchService, viewFactory, statusService, lookupService,
        attachmentService, lookupReferenceDataService);
    helper.setRequestParameterValue("method", "editStatus");
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  public void testControllerSaveStatusUpdate() throws Exception {
    moveRequestToStatus(MainConstants.STATUS_ID_IN_REVIEW);
    assertTrue(statusService.isSetToSentToCommittee());
    statusService.reset();
    moveRequestToStatus(MainConstants.STATUS_ID_NEW);
    assertTrue(statusService.isSetToNew());
    statusService.reset();
    moveRequestToStatus(MainConstants.STATUS_ID_APPROVED);
    assertTrue(statusService.isSetToApproved());
    statusService.reset();
    moveRequestToStatus(MainConstants.STATUS_ID_COORDINATOR);
    assertTrue(statusService.isSetToCoordinator());
    statusService.reset();
    moveRequestToStatus(MainConstants.STATUS_ID_SHIPPING);
    assertTrue(statusService.isSetToShipping());
    statusService.reset();
    moveRequestToStatus(MainConstants.STATUS_ID_COMPLETE);
    assertTrue(statusService.isSetToComplete());
  }

  public void testControllerSaveStatusUpdateRejected() throws Exception {
    moveRequestToStatus(MainConstants.STATUS_ID_REJECTED);
    statusService.isSetToRejected();
  }

  private void moveRequestToStatus(Long status) throws IOException {
    MockView view = new MockView();
    MockViewFactory viewFactory = new MockViewFactoryForSearchView(view);
    List testRequests = new ArrayList();
    testRequests.add(new RequestProfile());
    MockRequestSearchService requestSearchService = new MockRequestSearchService(testRequests);
    StatusController controller = new StatusController(requestSearchService, viewFactory, statusService, lookupService,
        attachmentService, lookupReferenceDataService);
    helper.setRequestParameterValue("method", "saveStatusUpdate");
    helper.setRequestParameterValue("requestId", "123");
    helper.setRequestParameterValue("newStatus", status.toString());
    controller.run(helper);
    assertTrue(view.wasViewRendered());
  }

  public void testSaveUpdateNotAuthorizedCausesException() throws Exception {
    helper.setSessionParameter("user", new MockUser("mock"));
    StatusController controller = new StatusController(new MockRequestSearchService(), new MockViewFactory(),
        statusService, lookupService, attachmentService, lookupReferenceDataService);
    helper.setRequestParameterValue("method", "saveStatusUpdate");
    helper.setRequestParameterValue("requestId", "123");
    helper.setRequestParameterValue("newStatus", "100");
    try {
      controller.run(helper);
      fail("Expected exception not received");
    } catch (Exception e) {
      // ignore expected
    }
  }

  private class MockViewFactoryForSearchView extends MockViewFactory {
    private final View view;

    MockViewFactoryForSearchView(View view) {
      this.view = view;
    }

    public View getSearchRequestProfileView() {
      return view;
    }
  }

  private class MockViewFactoryForStatusView extends MockViewFactory {
    private final View view;

    MockViewFactoryForStatusView(View view) {
      this.view = view;
    }

    public View getStatusView() {
      return view;
    }
  }
}