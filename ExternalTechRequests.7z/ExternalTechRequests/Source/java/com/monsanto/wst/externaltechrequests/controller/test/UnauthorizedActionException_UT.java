package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.wst.externaltechrequests.controller.UnauthorizedActionException;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.utils.testutils.TestUtils;
import junit.framework.TestCase;

/*
 UnauthorizedActionException_UT was created on Jan 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class UnauthorizedActionException_UT extends TestCase {
  public void testNormalConstructorsAreThere() throws Exception {
    TestUtils.verifyAllConstructorsWorkForException(UnauthorizedActionException.class);
  }

  public void testPrivilageConstructorsAreThere() throws Exception {
    Exception ex1 = new UnauthorizedActionException(Privilege.ADMIN_SECURITY);
    assertTrue(ex1.getMessage().indexOf(Privilege.ADMIN_SECURITY.getDescription()) >= 0);

    Privilege[] privs = {Privilege.ADMIN_SECURITY, Privilege.ADMIN_REFDATA};
    Exception ex2 = new UnauthorizedActionException(privs);
    assertTrue(ex2.getMessage().indexOf(Privilege.ADMIN_SECURITY.getDescription()) >= 0);
  }

  public void testNoPrivilegeCallIsOK() throws Exception {
    Privilege[] privs = {};
    Exception ex = new UnauthorizedActionException(privs);
    assertTrue(ex.getMessage().indexOf("not authorized") >= 0);
  }

}