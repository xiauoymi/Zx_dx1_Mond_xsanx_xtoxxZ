package com.monsanto.wst.externaltechrequests.controller.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.externaltechrequests.controller.UserAdministrationController;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.security.test.MockPrivilegedUser;
import com.monsanto.wst.externaltechrequests.security.test.MockUserFactory;
import com.monsanto.wst.externaltechrequests.view.factory.mock.MockViewFactory;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.test.mock.MockView;
import junit.framework.TestCase;

import java.util.List;

/*
 UserAdministrationController_UT was created on Jan 23, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class UserAdministrationController_UT extends TestCase {
  public void testNotSpecified() throws Exception {
    MockView mockView = new MockView();
    UserAdministrationController controller = new UserAdministrationController(new MockUserFactory(),
        new MockViewFactoryForUserAdministrationView(mockView));
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    controller.run(helper);
    List userList = (List) helper.getRequestAttributeValue("userList");
    assertNotNull(userList);
    assertTrue(mockView.wasViewRendered());
  }

  public void testEditUserWithValidUser() throws Exception {
    MockView mockView = new MockView();
    MockUserFactory userFactory = new MockUserFactory();
    String testUser = "abcde";
    userFactory.addUser(testUser, testUser, testUser, new String[0], "test");
    UserAdministrationController controller = new UserAdministrationController(userFactory,
        new MockViewFactoryForEditUserView(mockView));
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    helper.setRequestParameterValue("method", "editUser");
    helper.setRequestParameterValue("userId", testUser);
    controller.run(helper);
    User user = (User) helper.getRequestAttributeValue("user");
    List roleList = (List) helper.getRequestAttributeValue("roles");
    assertNotNull(user);
    assertNotNull(roleList);
    assertTrue(mockView.wasViewRendered());
  }

  public void testAddUser() throws Exception {
    MockView mockView = new MockView();
    MockUserFactory userFactory = new MockUserFactory();
    UserAdministrationController controller = new UserAdministrationController(userFactory,
        new MockViewFactoryForNewUserView(mockView));
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    helper.setRequestParameterValue("method", "addUser");
    controller.run(helper);
    List roleList = (List) helper.getRequestAttributeValue("roles");
    assertNotNull(roleList);
    assertTrue(mockView.wasViewRendered());
  }

  public void testSaveUser() throws Exception {
    MockView mockView = new MockView();
    MockUserFactory userFactory = new MockUserFactory();
    String testUser = "abcde";
    String testFullName = "eeeffffgggg";
    UserAdministrationController controller = new UserAdministrationController(userFactory,
        new MockViewFactoryForUserAdministrationView(mockView));
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    helper.setRequestParameterValue("method", "saveUser");
    helper.setRequestParameterValue("userId", testUser);
    helper.setRequestParameterValue("fullName", testFullName);
    assertNull(userFactory.getUser(testUser));
    controller.run(helper);
    List userList = (List) helper.getRequestAttributeValue("userList");
    assertNotNull(userList);
    assertTrue(mockView.wasViewRendered());
    User user = userFactory.getUser(testUser);
    assertNotNull(user);
    assertEquals(testUser, user.getUserId());
    assertEquals(testFullName, user.getFullName());
  }

  public void testUpdateUser() throws Exception {
    MockView mockView = new MockView();
    MockUserFactory userFactory = new MockUserFactory();
    String testUser = "abcde";
    String testNewFullName = "eeeffffgggg";
    userFactory.addUser(testUser, testUser, testUser, new String[0], "test");
    UserAdministrationController controller = new UserAdministrationController(userFactory,
        new MockViewFactoryForUserAdministrationView(mockView));
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    helper.setRequestParameterValue("method", "updateUser");
    helper.setRequestParameterValue("userId", testUser);
    helper.setRequestParameterValue("fullName", testNewFullName);
    controller.run(helper);
    List userList = (List) helper.getRequestAttributeValue("userList");
    assertNotNull(userList);
    assertTrue(mockView.wasViewRendered());
    User user = userFactory.getUser(testUser);
    assertNotNull(user);
    assertEquals(testUser, user.getUserId());
    assertEquals(testNewFullName, user.getFullName());
  }

  public void testDeactivateUser() throws Exception {
    MockView mockView = new MockView();
    MockUserFactory userFactory = new MockUserFactory();
    String testUser = "abcde";
    userFactory.addUser(testUser, testUser, testUser, new String[0], "test");
    UserAdministrationController controller = new UserAdministrationController(userFactory,
        new MockViewFactoryForUserAdministrationView(mockView));
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setSessionParameter("user", new MockPrivilegedUser("mock"));
    helper.setRequestParameterValue("method", "deactivateUser");
    helper.setRequestParameterValue("userId", testUser);
    assertNotNull(userFactory.getUser(testUser));
    controller.run(helper);
    List userList = (List) helper.getRequestAttributeValue("userList");
    assertNotNull(userList);
    assertTrue(mockView.wasViewRendered());
    assertNull(userFactory.getUser(testUser));
  }

  //todo need to make sure we are testing the situation if a previously deactivated user is attempted to be readded

  private class MockViewFactoryForUserAdministrationView extends MockViewFactory {
    private final View view;

    MockViewFactoryForUserAdministrationView(View view) {
      this.view = view;
    }

    public View getuserAdministrationView() {
      return view;
    }
  }

  private class MockViewFactoryForEditUserView extends MockViewFactory {
    private final View view;

    MockViewFactoryForEditUserView(View view) {
      this.view = view;
    }

    public View getEditUserView() {
      return view;
    }
  }

  private class MockViewFactoryForNewUserView extends MockViewFactory {
    private final View view;

    MockViewFactoryForNewUserView(View view) {
      this.view = view;
    }

    public View getNewUserView() {
      return view;
    }
  }
}