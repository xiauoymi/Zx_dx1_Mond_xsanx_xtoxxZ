package com.monsanto.wst.externaltechrequests.controller.test;

import junit.framework.TestCase;
import com.monsanto.wst.externaltechrequests.controller.DisplayUser;
import com.monsanto.wst.externaltechrequests.controller.UserFullNameComparator;

/*
 UserFullNameComparator_UT was created on Feb 22, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class UserFullNameComparator_UT extends TestCase {
  public void testSameUserIsEqual() throws Exception {
    assertEquals(0, callComparator(null, null));
    DisplayUser testUser = new DisplayUser("test", "test", "Test", "test");
    assertEquals(0, callComparator(testUser, testUser));
  }

  public void testSameNameEquals() throws Exception {
    DisplayUser testUser1 = new DisplayUser("test1", "test", "Test1", "test1");
    DisplayUser testUser2 = new DisplayUser("test2", "test", "Test2", "test2");
    DisplayUser testUser3 = new DisplayUser("test3", "null", "Test3", "test3");
    DisplayUser testUser4 = new DisplayUser("test4", "null", "Test4", "test4");
    assertEquals(0, callComparator(testUser1, testUser2));
    assertEquals(0, callComparator(testUser3, testUser4));
  }

  public void testDifferentNameNotEquals() throws Exception {
    DisplayUser testUser1 = new DisplayUser("test1", "test1", "Test1", "test1");
    DisplayUser testUser2 = new DisplayUser("test2", "test2", "Test2", "test2");
    DisplayUser testUser3 = new DisplayUser("test3", null, "Test3", "test3");
    DisplayUser testUser4 = new DisplayUser("test4", "", "Test4", "test4");
    assertTrue(callComparator(testUser1, testUser2) < 0);
    assertTrue(callComparator(testUser2, testUser1) > 0);
    assertTrue(callComparator(testUser3, testUser1) < 0);
    assertTrue(callComparator(testUser4, testUser1) < 0);
    assertTrue(callComparator(testUser2, testUser3) > 0);
    assertTrue(callComparator(testUser2, testUser4) > 0);
  }

  private int callComparator(DisplayUser user1, DisplayUser user2) {
    return new UserFullNameComparator().compare(user1, user2);
  }
}