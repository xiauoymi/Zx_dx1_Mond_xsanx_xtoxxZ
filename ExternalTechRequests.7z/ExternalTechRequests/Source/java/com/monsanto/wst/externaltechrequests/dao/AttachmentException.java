/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.externaltechrequests.dao;

/**
 * Filename:    $RCSfile: AttachmentException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-26 23:34:22 $
 *
 * @author jdpoul
 * @version $Revision: 1.3 $
 */
public class AttachmentException extends Exception {
  public AttachmentException() {
  }

  public AttachmentException(Throwable cause) {
    super(cause);
  }

  public AttachmentException(String message, Throwable cause) {
    super(message, cause);
  }

  public AttachmentException(String message) {
    super(message);
  }
}