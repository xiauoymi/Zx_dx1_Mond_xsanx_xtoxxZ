package com.monsanto.wst.externaltechrequests.dao;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.externaltechrequests.document.*;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.model.AttachmentMetadata;
import com.monsanto.wst.externaltechrequests.model.RepositoryAttachment;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;

import java.util.ArrayList;
import java.util.List;
/*
 DBTemplateDocumentumAttachmentService was created on Jan 24, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class DBTemplateDocumentumAttachmentService implements AttachmentService {
  public static final String LOOKUP_TEMPLATE_QUERY = "lookupTemplates";
  public static final String LOOKUP_ATTACHMENT_QUERY = "lookupAttachments";
  public static final String LOOKUP_ATTACHMENT_BY_ID_QUERY = "lookupAttachmentById";
  public static final String ADD_TEMPLATE_STATEMENT = "addTemplate";
  public static final String ADD_ATTACHMENT_STATEMENT = "addAttachment";
  public static final String UPDATE_ATTACHMENT_STATEMENT = "updateAttachment";
  public static final String DELETE_ATTACHMENT_STATEMENT = "deleteAttachment";

  private DBTemplate template;
  private DocumentService docService;

  public DBTemplateDocumentumAttachmentService(DBTemplate template, DocumentService docService) {
    if (template == null) {
      throw new NullPointerException("template cannot be null");
    }
    if (docService == null) {
      throw new NullPointerException("docService cannot be null");
    }
    this.template = template;
    this.docService = docService;
  }

  public AttachmentCollection getAttachments(Long requestId, User user) {
    List metadataList = template.executeListResultQuery(LOOKUP_ATTACHMENT_QUERY, requestId);
    return new AttachmentCollection(getAttachmentListFromMetadataList(metadataList), user);
  }

  public void addAttachment(Attachment attachment, String modUser) throws DocumentStorageException {
    attachment.getMetadata().setId(getNextAttachmentId());
    attachment.getMetadata().setModUser(modUser);
    String repositoryId;
    try {
      repositoryId = docService.store(attachment.getMetadata().getId().longValue(), attachment.getAttachedFile());
    } catch (DocumentRetrievalException e) {
      throw new DocumentStorageException(e);
    }
    attachment.getMetadata().setRepositoryId(repositoryId);
    try {
      template.executeInsert(ADD_ATTACHMENT_STATEMENT, attachment.getMetadata());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void updateAttachment(Attachment attachment, String modUser) throws DocumentStorageException {
    try {
      docService.update(attachment.getMetadata().getRepositoryId(), attachment.getAttachedFile());
    } catch (DocumentRetrievalException e) {
      throw new DocumentStorageException(e);
    }
    attachment.getMetadata().setModUser(modUser);
    template.executeUpdate(UPDATE_ATTACHMENT_STATEMENT, attachment.getMetadata());
  }

  public void deleteAttachment(Attachment attachment) {
    try {
      docService.delete(attachment.getMetadata().getRepositoryId());
    } catch (DocumentDeletionException e) {
      Logger.log(new LoggableError(e));
      // ignore the error on delete, maybe its already gone for some other reason -- we still need to delete it from the db
    }
    try {
      template.executeDelete(DELETE_ATTACHMENT_STATEMENT, attachment.getMetadata());
    } catch (Exception e) {
      Logger.log(new LoggableError(e));
      // ignore the error on delete, maybe its already gone for some other reason
    }
  }

  public List getTemplates(DocumentType templateType) {
    List metadataList = template.executeListResultQuery(LOOKUP_TEMPLATE_QUERY, templateType);
    return getAttachmentListFromMetadataList(metadataList);
  }

  public void addTemplate(Attachment attachment, String modUser) throws DocumentStorageException {
    if (attachment == null) {
      throw new DocumentStorageException("attachment cannot be null");
    }
    if (attachment.getMetadata() == null) {
      throw new DocumentStorageException("attachment has no metadata");
    }
    Long id = getNextAttachmentId();
    if (id == null) {
      throw new DocumentStorageException("An id could not be assigned to this attachment");
    }
    attachment.getMetadata().setId(id);
    attachment.getMetadata().setModUser(modUser);
    String repositoryId;
    try {
      repositoryId = docService.store(id.longValue(), attachment.getAttachedFile());
    } catch (DocumentRetrievalException e) {
      throw new DocumentStorageException(e);
    }
    attachment.getMetadata().setRepositoryId(repositoryId);
    template.executeInsert(ADD_TEMPLATE_STATEMENT, attachment.getMetadata());
  }

  public void loadSecurityInfoFromHelper(UCCHelper helper) {
    docService.loadSecurityInfoFromHelper(helper);
  }

  public Attachment getAttachment(Long attachmentId) {
    AttachmentMetadata meta = (AttachmentMetadata) template
        .executeSingleResultQuery(LOOKUP_ATTACHMENT_BY_ID_QUERY,
            attachmentId);
    return getAttachmentFromMetadata(meta);
  }

  private Long getNextAttachmentId() {
    return (Long) template.executeSingleResultQuery("nextSeq");
  }

  private List getAttachmentListFromMetadataList(List metadataList) {
    if (metadataList == null) {
      return new ArrayList();
    }

    List attachmentList = new ArrayList(metadataList.size());
    for (int i = 0; i < metadataList.size(); i++) {
      AttachmentMetadata metadata = (AttachmentMetadata) metadataList.get(i);
      attachmentList.add(getAttachmentFromMetadata(metadata));
    }

    return attachmentList;
  }

  private RepositoryAttachment getAttachmentFromMetadata(AttachmentMetadata metadata) {
    return new RepositoryAttachment(metadata, docService);
  }
}
