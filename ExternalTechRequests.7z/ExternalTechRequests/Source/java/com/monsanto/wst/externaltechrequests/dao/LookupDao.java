/*
 LookupDao was created on Nov 6, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao;

import com.monsanto.wst.externaltechrequests.exception.NoResultsException;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.User;

import java.util.List;

/**
 * Filename:    $RCSfile: LookupDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date:
 * 2006/11/28 18:30:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.14 $
 */
public interface LookupDao {
  Long lookupNextRequestSeq() throws NoResultsException;

  RequestProfile lookupRequestById(Long requestId) throws NoResultsException;

  List lookupResearchRequestListByRequestId(Long requestId);

  List lookupStatusRequestListByRequestId(Long requestId);

  List lookupCommitteApprovedRequestListByRequestId(Long requestId);

  User lookupLoginUserByUserId(String userId) throws NoResultsException;

  String lookupNextRequestGenNumber() throws NoResultsException;

  List lookupUserPrivs(String userId);

  List lookupRolesForUserId(String userId);
}