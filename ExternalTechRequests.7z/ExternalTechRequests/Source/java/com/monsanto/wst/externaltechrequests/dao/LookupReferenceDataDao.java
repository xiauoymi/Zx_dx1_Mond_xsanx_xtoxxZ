/*
 LookupReferenceDataDao was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao;

import java.util.List;

/**
 * Filename:    $RCSfile: LookupReferenceDataDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-30 15:26:03 $
 *
 * @author ffbrac
 * @version $Revision: 1.5 $
 */
public interface LookupReferenceDataDao {
	List getRegionRefList();
	List getCommitteeApprovalRefList();
	List getStatusRefList();
	List getResearchTypeRefList();
	List getRequestTypeRefList();
	List getStudyLengthTypeRefList();
  List getStateRefList();
}