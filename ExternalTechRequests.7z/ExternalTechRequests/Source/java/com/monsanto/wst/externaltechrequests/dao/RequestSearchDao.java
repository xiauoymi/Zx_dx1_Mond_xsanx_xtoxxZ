/*
 RequestSearchDao was created on Nov 15, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao;

import com.monsanto.wst.externaltechrequests.model.RequestSearch;

import java.util.List;

/**
 * Filename:    $RCSfile: RequestSearchDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-11-28 15:22:26 $
 *
 * @author ffbrac
 * @version $Revision: 1.4 $
 */
public interface RequestSearchDao {
	List getRequestListBySearchCriteria(RequestSearch requestSearch);
}