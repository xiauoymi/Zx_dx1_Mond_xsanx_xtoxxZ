/*
 DBTemplateLookupDao was created on Nov 6, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.dbtemplate;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.dao.DBTemplateNoResultsException;
import com.monsanto.wst.externaltechrequests.dao.LookupDao;
import com.monsanto.wst.externaltechrequests.exception.NoResultsException;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.security.dbsecurity.DBUser;
import com.monsanto.wst.externaltechrequests.security.dbsecurity.DBUserFactory;
import com.monsanto.wst.externaltechrequests.security.dbsecurity.UserImpl;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * Filename:    $RCSfile: DBTemplateLookupDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date:
 * 2006/12/14 18:39:01 $
 *
 * @author ffbrac
 * @version $Revision: 1.18 $
 */
public class DBTemplateLookupDao implements LookupDao {
  private final DBTemplate template;

  public DBTemplateLookupDao(DBTemplate template) {
    this.template = template;
  }

  public Long lookupNextRequestSeq() throws NoResultsException {
    Long id = null;
    try {
      id = (Long) template.executeSingleResultQuery("nextSeq");
    } catch (DBTemplateNoResultsException ex) {
      return handleException(id, ex);
    }
    return id;
  }


  public RequestProfile lookupRequestById(Long requestId) throws NoResultsException {
    RequestProfile requestProfile = null;
    try {
      requestProfile = (RequestProfile) template.executeSingleResultQuery("lookupRequestById", requestId);
    } catch (DBTemplateNoResultsException ex) {
      handleException(requestProfile, ex);
    }
    return requestProfile;
  }

  public List lookupResearchRequestListByRequestId(Long requestId) {
    return template.executeListResultQuery("lookupResearchRequestListByRequestId", requestId);
  }

  public List lookupStatusRequestListByRequestId(Long requestId) {
    return template.executeListResultQuery("lookupStatusRequestListByRequestId", requestId);
  }

  public List lookupCommitteApprovedRequestListByRequestId(Long requestId) {
    return template.executeListResultQuery("lookupCommitteeApprovedRequestListByRequestId", requestId);
  }

  public User lookupLoginUserByUserId(String userId) throws NoResultsException {
    try {
      DBUser user = (DBUser) template.executeSingleResultQuery(DBUserFactory.USERLOOKUP_QUERY_NAME, userId);
      return new UserImpl(user, lookupUserPrivs(userId), lookupRolesForUserId(userId));
    } catch (DBTemplateNoResultsException e) {
      throw new NoResultsException("User not found: " + userId, e);
    }
  }

  public List lookupRolesForUserId(String userId) {
    String ROLELOOKUP_QUERY_NAME = "lookupRoleForUser";
    List roleList = template.executeListResultQuery(ROLELOOKUP_QUERY_NAME, userId);
    if (roleList == null) {
      return new ArrayList();
    } else {
      return roleList;
    }
  }

  public String lookupNextRequestGenNumber() throws NoResultsException {
    int year = getCurrentYear();
    Long requestNumber = lookupNextRequestNum(year);
    return createRequestNumber(year, requestNumber);
  }

  protected int getCurrentYear() {
    return new GregorianCalendar().get(Calendar.YEAR);
  }

  public List lookupUserPrivs(String userId) {
    String PRIVLOOKUP_QUERY_NAME = "lookupPrivForUser";
    List privList = template.executeListResultQuery(PRIVLOOKUP_QUERY_NAME, userId);
    if (privList == null) {
      return new ArrayList();
    } else {
      return privList;
    }
  }


  public Long lookupNextRequestNum(int year) throws NoResultsException {
    Long num = null;
    try {
      template.executeUpdate("LockRequestProfileTable", null);
      num = (Long) template.executeSingleResultQuery("nextRequestNumber", new Integer(year));
    } catch (DBTemplateNoResultsException ex) {
      handleException(num, ex);
    }
    return num;
  }


  private String createRequestNumber(int year, Long requestNumber) {
    NumberFormat format = new DecimalFormat("0000");
    return "SRWG-" + year + '-' + format.format(requestNumber.longValue());
  }


  private Long handleException(Object value, Exception e) throws NoResultsException {
    if (Logger.isEnabled(Logger.DEBUG_LOG)) {
      Logger.log(new DebugLogEvent("Unable to find the next seq id: '" + value + "'."));
    }
    throw new NoResultsException("Unable to find the next seq id '" + value + "'.", e);
  }

}