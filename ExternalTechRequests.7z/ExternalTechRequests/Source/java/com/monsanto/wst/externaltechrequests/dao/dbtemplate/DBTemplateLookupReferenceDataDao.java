/*
 DBTemplateLookupReferenceData was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.dbtemplate;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.externaltechrequests.dao.LookupReferenceDataDao;
import com.monsanto.wst.externaltechrequests.model.ReferenceData;
import com.monsanto.wst.externaltechrequests.model.ReferenceDataTableName;

import java.util.List;

/**
 * Filename:    $RCSfile: DBTemplateLookupReferenceDataDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2
 * $    	 On:	$Date: 2007-03-21 18:29:22 $
 *
 * @author ffbrac
 * @version $Revision: 1.9 $
 */
public class DBTemplateLookupReferenceDataDao implements LookupReferenceDataDao {
  private final DBTemplate template;

  public DBTemplateLookupReferenceDataDao(DBTemplate template) {
    this.template = template;
  }

  public List getRegionRefList() {
    return template.executeListResultQuery("referenceData", new ReferenceDataTableName("REGION"));
  }

  public List getCommitteeApprovalRefList() {
    return template.executeListResultQuery("referenceData", new ReferenceDataTableName("COMMITTEE_APPROVED"));
  }

  public List getStatusRefList() {
    return template.executeListResultQuery("referenceData", new ReferenceDataTableName("STATUS"));
  }

  public List getResearchTypeRefList() {
    return template.executeListResultQuery("referenceData", new ReferenceDataTableName("RESEARCH_TYPE"));
  }

  public List getRequestTypeRefList() {
    return template.executeListResultQuery("referenceData", new ReferenceDataTableName("REQUEST_TYPE"));
  }

  public List getStudyLengthTypeRefList() {
    return template.executeListResultQuery("referenceData", new ReferenceDataTableName("STUDY_LENGTH"));
  }

  public List getStateRefList() {
    return template.executeListResultQuery("stateList");
  }

}