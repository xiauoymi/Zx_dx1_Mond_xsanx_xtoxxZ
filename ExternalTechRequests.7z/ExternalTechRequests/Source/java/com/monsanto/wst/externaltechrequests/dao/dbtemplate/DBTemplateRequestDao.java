/*
 DBTemplateRequestDao was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.dbtemplate;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.externaltechrequests.dao.RequestDao;
import com.monsanto.wst.externaltechrequests.model.AddressInfo;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestResearchType;

/**
 * Filename:    $RCSfile: DBTemplateRequestDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.11 $
 */
public class DBTemplateRequestDao implements RequestDao {
  private final DBTemplate template;

  public DBTemplateRequestDao(DBTemplate template) {
    this.template = template;
  }

  public Long insertAddress(AddressInfo addressInfo) {
    template.executeInsert("insertAddress", addressInfo);
    return addressInfo.getId();
  }

  public Long insertRequestProfile(RequestProfile requestProfile) {
    template.executeInsert("insertRequestProfile", requestProfile);
    return requestProfile.getId();
  }

  public Long insertRequestResearch(RequestResearchType requestResearchType) {
    template.executeInsert("insertRequestResearch", requestResearchType);
    return requestResearchType.getId();
  }

  public Long insertStatusResearch(RequestResearchType requestResearchType) {
    template.executeInsert("insertStatusResearch", requestResearchType);
    return requestResearchType.getId();
  }

  public Long insertCommitteeApprovedResearch(RequestResearchType requestResearchType) {
    template.executeInsert("insertCommitteeApprovedResearch", requestResearchType);
    return requestResearchType.getId();
  }

  public Long updateRequestProfile(RequestProfile requestProfile) {
    template.executeUpdate("updateRequestProfile", requestProfile);
    return requestProfile.getId();
  }

  public Long getNextSeq() {
    return (Long) template.executeSingleResultQuery("nextSeq");
  }

  public Long updateAddressInfo(AddressInfo address) {
    template.executeUpdate("updateAddressInfo", address);
    return address.getId();
  }

  public Long deleteRequestResearch(Long id) {
    template.executeDelete("deleteResearchRequest", id);
    return id;
  }
}