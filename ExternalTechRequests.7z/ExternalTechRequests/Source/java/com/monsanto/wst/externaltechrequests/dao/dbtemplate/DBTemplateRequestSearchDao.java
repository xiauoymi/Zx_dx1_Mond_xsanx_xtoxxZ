/*
 DBTemplaterequestSearchDao was created on Nov 15, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.dbtemplate;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.externaltechrequests.dao.RequestSearchDao;
import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.utils.search.SearchUtils;

import java.util.List;

/**
 * Filename:    $RCSfile: DBTemplateRequestSearchDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-28 21:36:38 $
 *
 * @author ffbrac
 * @version $Revision: 1.10 $
 */
public class DBTemplateRequestSearchDao implements RequestSearchDao {
  private final DBTemplate template;

  public DBTemplateRequestSearchDao(DBTemplate template) {
    this.template = template;
  }

  public List getRequestListBySearchCriteria(RequestSearch requestSearch) {
    SearchUtils searchUtils = determineSearchConditions(requestSearch);
    return template.executeListResultQuery("searchForRequests", searchUtils);
  }

  private SearchUtils determineSearchConditions(RequestSearch requestSearch) {
    SearchUtils searchUtils = new SearchUtils();
    searchUtils.addStringValueToWhereCluase("RP.REQUEST_GENERATED_NUM", requestSearch.getRequestGenNumber());
    searchUtils.addStringValueToWhereCluase("RP.REQUESTOR_CONTACT_NAME", requestSearch.getContactName());
    searchUtils.addStringValueToWhereCluase("RP.SPONSOR", requestSearch.getSponsor());
    searchUtils.addStringValueToWhereCluase("RP.AFFILIATION", requestSearch.getAffiliation());
    searchUtils.addLongValueToWhereCluase("RP.REQUEST_TYPE_ID", requestSearch.getRequestTypeId());
    searchUtils.addLongValueToWhereCluase("RP.REGION_ID", requestSearch.getRegionId());
    searchUtils.addLongValueToWhereCluase("RS.STATUS_ID", requestSearch.getStatusId());
    searchUtils
        .addDateValueToWhereCluase("RP.DATE_OF_REQUEST", requestSearch.getStartDate(), requestSearch.getEndDate());
    searchUtils.addDateValueToWhereCluase("RP.DATE_NEEDED_BY", requestSearch.getCommittStartDate(),
        requestSearch.getCommittEndDate());
    searchUtils.addStringValueToWhereCluase("RR.DESCRIPTION", requestSearch.getDescription());
    return searchUtils;
  }
}