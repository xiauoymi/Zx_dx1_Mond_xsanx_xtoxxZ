/*
 DBTemplateLookupDao_UT was created on Nov 6, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.dbtemplate.test;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.externaltechrequests.dao.dbtemplate.DBTemplateLookupDao;
import com.monsanto.wst.externaltechrequests.exception.NoResultsException;
import com.monsanto.wst.externaltechrequests.security.User;
import junit.framework.TestCase;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Filename:    $RCSfile: DBTemplateLookupDao_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.17 $
 */
public class DBTemplateLookupDao_UT extends TestCase {
  private MockDBTemplate template;

  protected void setUp() throws Exception {
    super.setUp();
    template = new MockDBTemplate();
  }

  public void testCreate() throws Exception {
    DBTemplateLookupDao dao = new DBTemplateLookupDao(template);
    assertNotNull(dao);
  }

  public void testLookupNextRequestSeq() throws Exception {
    DBTemplateLookupDao dao = new DBTemplateLookupDao(template);
    Long id = dao.lookupNextRequestSeq();
    assertEquals(new Long("12345"), id);
    assertTrue(template.wasStatementNameCalled("nextSeq"));

  }


  public void testLookupRequestById() throws Exception {
    DBTemplateLookupDao dao = new DBTemplateLookupDao(template);
    dao.lookupRequestById(new Long("100"));
    assertTrue(template.wasStatementNameCalled("lookupRequestById"));

  }

  public void testLookupResearchRequestListByRequestId() throws Exception {
    DBTemplateLookupDao dao = new DBTemplateLookupDao(template);
    dao.lookupResearchRequestListByRequestId(new Long("100"));
    assertTrue(template.wasStatementNameCalled("lookupResearchRequestListByRequestId"));

  }

  public void testLookupStatusRequestListByRequestId() throws Exception {
    DBTemplateLookupDao dao = new DBTemplateLookupDao(template);
    dao.lookupStatusRequestListByRequestId(new Long("100"));
    assertTrue(template.wasStatementNameCalled("lookupStatusRequestListByRequestId"));

  }

  public void testLookupCommitteeApprovedRequestListByRequestId() throws Exception {
    DBTemplateLookupDao dao = new DBTemplateLookupDao(template);
    dao.lookupCommitteApprovedRequestListByRequestId(new Long("100"));
    assertTrue(template.wasStatementNameCalled("lookupCommitteeApprovedRequestListByRequestId"));

  }

  public void testLookupLoginUserByUserId() throws Exception {
    DBTemplateLookupDao dao = new DBTemplateLookupDao(template);
    User user = dao.lookupLoginUserByUserId("100");
    assertNotNull(user);
  }

  public void testLookupNextRequestGenNumber_UsesCurrentYearAndNextRequestID_ConcatenatesCorrectly() throws Exception {
    DBTemplateLookupDao dao = new MockDBTemplateLookupDao(template, 1776);
    assertEquals("SRWG-1776-0012", dao.lookupNextRequestGenNumber());
  }

  public void testGetCurrentYearIsCorrect() throws Exception {
    int expectedYear = new GregorianCalendar().get(Calendar.YEAR);
    int yearFromDao = new MockDBTemplateLookupDaoForVisibility(template).getCurrentYear();
    assertEquals(expectedYear, yearFromDao);
  }

  public class MockDBTemplateLookupDao extends DBTemplateLookupDao {
    private final int year;

    public MockDBTemplateLookupDao(DBTemplate template, int year) {
      super(template);
      this.year = year;
    }

    public Long lookupNextRequestNum(int year) throws NoResultsException {
      return new Long(12);
    }

    protected int getCurrentYear() {
      return year;
    }
  }

  private class MockDBTemplateLookupDaoForVisibility extends DBTemplateLookupDao {
    MockDBTemplateLookupDaoForVisibility(DBTemplate template) {
      super(template);
    }

    protected int getCurrentYear() {
      return super.getCurrentYear();
    }
  }
}