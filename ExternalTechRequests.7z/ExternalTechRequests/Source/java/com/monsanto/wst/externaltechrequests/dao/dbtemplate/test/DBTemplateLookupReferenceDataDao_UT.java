/*
 DBTemplateLookupReferenceDataDao_UT was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.dbtemplate.test;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.externaltechrequests.dao.dbtemplate.DBTemplateLookupReferenceDataDao;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: DBTemplateLookupReferenceDataDao_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-09 20:06:08 $
 *
 * @author ffbrac
 * @version $Revision: 1.4 $
 */
public class DBTemplateLookupReferenceDataDao_UT extends TestCase {
	private MockDBTemplate template;
	protected void setUp() throws Exception {
		super.setUp();
		template = new MockDBTemplate();
	}

	public void testCreate() throws Exception {
		DBTemplateLookupReferenceDataDao dao = new DBTemplateLookupReferenceDataDao(template);
		assertNotNull(dao);
	}
	public void testGetRegionRefList() throws Exception {
		DBTemplateLookupReferenceDataDao dao = new DBTemplateLookupReferenceDataDao(template);
		dao.getRegionRefList();
		assertTrue(template.wasRetrieved());
		assertTrue(template.wasStatementNameCalled("referenceData"));
	}
	public void testGetCommitteeApprovalRefList() throws Exception {
		DBTemplateLookupReferenceDataDao dao = new DBTemplateLookupReferenceDataDao(template);
		dao.getCommitteeApprovalRefList();
		assertTrue(template.wasRetrieved());
		assertTrue(template.wasStatementNameCalled("referenceData"));
	}
	public void testGetRequestTypeRefList() throws Exception {
		DBTemplateLookupReferenceDataDao dao = new DBTemplateLookupReferenceDataDao(template);
		dao.getRequestTypeRefList();
		assertTrue(template.wasRetrieved());
		assertTrue(template.wasStatementNameCalled("referenceData"));
	}
	public void testGetResearchTypeRefList() throws Exception {
		DBTemplateLookupReferenceDataDao dao = new DBTemplateLookupReferenceDataDao(template);
		dao.getResearchTypeRefList();
		assertTrue(template.wasRetrieved());
		assertTrue(template.wasStatementNameCalled("referenceData"));
	}
	public void testGetStatusRefList() throws Exception {
		DBTemplateLookupReferenceDataDao dao = new DBTemplateLookupReferenceDataDao(template);
		dao.getStatusRefList();
		assertTrue(template.wasRetrieved());
		assertTrue(template.wasStatementNameCalled("referenceData"));
	}
	public void testGetStudyLengthTypeRefList() throws Exception {
		DBTemplateLookupReferenceDataDao dao = new DBTemplateLookupReferenceDataDao(template);
		dao.getStudyLengthTypeRefList();
		assertTrue(template.wasRetrieved());
		assertTrue(template.wasStatementNameCalled("referenceData"));
	}
}