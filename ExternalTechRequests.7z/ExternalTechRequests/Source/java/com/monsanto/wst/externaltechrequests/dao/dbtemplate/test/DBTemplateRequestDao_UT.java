/*
 DBTemplateRequestDao_UT was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.dbtemplate.test;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.externaltechrequests.dao.dbtemplate.DBTemplateRequestDao;
import com.monsanto.wst.externaltechrequests.model.AddressInfo;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestResearchType;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: DBTemplateRequestDao_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-09 20:06:08 $
 *
 * @author ffbrac
 * @version $Revision: 1.6 $
 */
public class DBTemplateRequestDao_UT extends TestCase {
	private MockDBTemplate template;
	protected void setUp() throws Exception {
		super.setUp();
		template = new MockDBTemplate();
	}

	public void testCreate() throws Exception {
		DBTemplateRequestDao dao = new DBTemplateRequestDao(template);
		assertNotNull(dao);
	}
	public void testInsertRequestProfile() throws Exception {
		DBTemplateRequestDao dao = new DBTemplateRequestDao(template);
		Long id = dao.insertRequestProfile(new RequestProfile(new Long("100")));
		assertEquals(new Long("100"), id);
		assertTrue(template.wasStatementNameCalled("insertRequestProfile"));

	}
	public void testInsertAddress() throws Exception {
		DBTemplateRequestDao dao = new DBTemplateRequestDao(template);
		Long id = dao.insertAddress(new AddressInfo(new Long("100")));
		assertEquals(new Long("100"), id);
		assertTrue(template.wasStatementNameCalled("insertAddress"));

	}
	public void testInsertRequestResearch() throws Exception {
		DBTemplateRequestDao dao = new DBTemplateRequestDao(template);
		Long id = dao.insertRequestResearch(new RequestResearchType(new Long("100")));
		assertEquals(new Long("100"), id);
		assertTrue(template.wasStatementNameCalled("insertRequestResearch"));

	}
	public void testupdateRequestProfile() throws Exception {
		DBTemplateRequestDao dao = new DBTemplateRequestDao(template);
		Long id = dao.updateRequestProfile(new RequestProfile(new Long("100")));
		assertEquals(new Long("100"), id);
		assertTrue(template.wasStatementNameCalled("updateRequestProfile"));

	}
	public void testUpdateAddressInfo() throws Exception {
		DBTemplateRequestDao dao = new DBTemplateRequestDao(template);
		Long id = dao.updateAddressInfo(new AddressInfo(new Long("100")));
		assertEquals(new Long("100"), id);
		assertTrue(template.wasStatementNameCalled("updateAddressInfo"));

	}
	public void testDeleteRequestResearch() throws Exception {
		DBTemplateRequestDao dao = new DBTemplateRequestDao(template);
		Long id = dao.deleteRequestResearch(new Long("100"));
		assertEquals(new Long("100"), id);
		assertTrue(template.wasStatementNameCalled("deleteResearchRequest"));

	}
}