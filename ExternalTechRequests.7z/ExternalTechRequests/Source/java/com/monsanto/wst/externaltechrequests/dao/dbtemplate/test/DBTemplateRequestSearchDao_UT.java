/*
 DBTemplateRequestSearchDao_UT was created on Nov 15, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.dbtemplate.test;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.externaltechrequests.dao.dbtemplate.DBTemplateRequestSearchDao;
import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.utils.search.SearchUtils;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: DBTemplateRequestSearchDao_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-02-28 21:36:38 $
 *
 * @author ffbrac
 * @version $Revision: 1.7 $
 */
public class DBTemplateRequestSearchDao_UT extends TestCase {
  public void testCreate() throws Exception {
    DBTemplateRequestSearchDao requestSearchDao = new DBTemplateRequestSearchDao(new MockDBTemplate());
    assertNotNull(requestSearchDao);
  }
  public void testGetRequestListBySearchCriteria() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    DBTemplateRequestSearchDao requestSearchDao = new DBTemplateRequestSearchDao(template);
    Object test = requestSearchDao.getRequestListBySearchCriteria(new RequestSearch());
    assertNull(test);
    assertTrue(template.wasStatementNameCalled("searchForRequests"));
  }

  public void testGetRequestListBySearchCriteriaDoesntUseWrongTableForStatus() throws Exception {
    MockDBTemplateForQueryParameters template = new MockDBTemplateForQueryParameters();
    DBTemplateRequestSearchDao requestSearchDao = new DBTemplateRequestSearchDao(template);
    RequestSearch requestSearch = new RequestSearch(new Long(100));
    requestSearchDao.getRequestListBySearchCriteria(requestSearch);
    SearchUtils criteria = (SearchUtils) template.getCriteria();

    assertTrue(criteria.getWhereCluase().indexOf("RP.STATUS_ID") == -1);
    assertTrue(criteria.getWhereCluase().indexOf("RS.STATUS_ID") > 0);
  }

  private class MockDBTemplateForQueryParameters extends MockDBTemplate {
    private Object criteria;

    public List executeListResultQuery(String statementName, Object criteria) {
      this.criteria = criteria;
      return null;
    }

    public Object getCriteria() {
      return criteria;
    }
  }

}