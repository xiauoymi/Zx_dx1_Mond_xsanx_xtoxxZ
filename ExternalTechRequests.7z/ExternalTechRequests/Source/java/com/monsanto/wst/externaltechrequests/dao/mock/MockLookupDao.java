/*
 MockLookupDao was created on Nov 7, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.mock;

import com.monsanto.wst.externaltechrequests.dao.LookupDao;
import com.monsanto.wst.externaltechrequests.exception.NoResultsException;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.security.test.MockUser;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockLookupDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date:
 * 2006/11/28 18:30:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.13 $
 */
public class MockLookupDao implements LookupDao {
  public Long lookupNextRequestSeq() throws NoResultsException {
    return new Long("100");
  }

  public Long lookupNextRequestNum() {
    return new Long("100");
  }

  public String lookupCurrentYear() {
    return "1969";
  }

  public RequestProfile lookupRequestById(Long requestId) throws NoResultsException {
    return new RequestProfile(new Long("100"));
  }

  public List lookupResearchRequestListByRequestId(Long requestId) {
    return new ArrayList();
  }

  public List lookupStatusRequestListByRequestId(Long requestId) {
    return new ArrayList();
  }

  public List lookupCommitteApprovedRequestListByRequestId(Long requestId) {
    return new ArrayList();
  }

  public User lookupLoginUserByUserId(String userId) throws NoResultsException {
    return new MockUser("FFBRAC");
  }

  public String lookupNextRequestGenNumber() {
    return "testMe";
  }

  public List lookupUserPrivs(String userId) {
    return new ArrayList();
  }

  public List lookupRolesForUserId(String userId) {
    return new ArrayList();
  }
}