/*
 MockRequestDao was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.mock;

import com.monsanto.wst.externaltechrequests.dao.RequestDao;
import com.monsanto.wst.externaltechrequests.model.AddressInfo;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestResearchType;

/**
 * Filename:    $RCSfile: MockRequestDao.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-02-09 19:40:43 $
 *
 * @author ffbrac
 * @version $Revision: 1.9 $
 */
public class MockRequestDao implements RequestDao {
	public Long insertAddress(AddressInfo addressInfo) {
		return new Long("100");
	}

	public Long insertRequestProfile(RequestProfile requestProfile) {
		return new Long("100");
	}

	public Long insertRequestResearch(RequestResearchType requestResearchType) {
		return new Long("100");
	}

	public Long insertStatusResearch(RequestResearchType requestResearchType) {
		return new Long("100");
	}

	public Long insertCommitteeApprovedResearch(RequestResearchType requestResearchType) {
		return new Long("100");
	}

	public Long updateRequestProfile(RequestProfile requestProfile) {
		return new Long("100");
	}

	public Long updateAddressInfo(AddressInfo address) {
		return new Long("100");
	}

	public Long deleteRequestResearch(Long id) {
		return new Long("100");
	}

  public Long getNextSeq() {
    return new Long("100");
  }
}