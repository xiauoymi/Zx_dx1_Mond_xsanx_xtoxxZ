/*
 MockLookupDaoEx was created on Nov 7, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.mockfail;

import com.monsanto.wst.externaltechrequests.dao.LookupDao;
import com.monsanto.wst.externaltechrequests.exception.NoResultsException;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.User;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockLookupDaoEx.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.13 $
 */
public class MockLookupDaoEx implements LookupDao {
  public Long lookupNextRequestNum() throws NoResultsException {
    throw new NoResultsException("This is lookupNextRequestNum method....");
  }

  public String lookupCurrentYear() throws NoResultsException {
    throw new NoResultsException("This is lookupCurrentYear method....");
  }

  public RequestProfile lookupRequestById(Long requestId) throws NoResultsException {
    throw new NoResultsException("This is lookupRequestById method....");
  }

  public List lookupResearchRequestListByRequestId(Long requestId) {
    return null;
  }

  public List lookupStatusRequestListByRequestId(Long requestId) {
    return null;
  }

  public List lookupCommitteApprovedRequestListByRequestId(Long requestId) {
    return null;
  }

  public User lookupLoginUserByUserId(String userId) throws NoResultsException {
    throw new NoResultsException("This is lookupLoginUserByUserId method....");
  }

  public Long lookupNextRequestSeq() throws NoResultsException {
    throw new NoResultsException("This is lookupNextRequestSeq method....");
  }

  public String lookupNextRequestGenNumber() throws NoResultsException {
    throw new NoResultsException("This is lookupNextRequestGenNumber method....");
  }

  public List lookupUserPrivs(String userId) {
    return new ArrayList();
  }

  public List lookupRolesForUserId(String userId) {
    return new ArrayList();
  }
}