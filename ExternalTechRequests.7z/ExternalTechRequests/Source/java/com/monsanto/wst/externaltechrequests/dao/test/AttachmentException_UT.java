package com.monsanto.wst.externaltechrequests.dao.test;

import com.monsanto.wst.externaltechrequests.dao.AttachmentException;
import com.monsanto.wst.externaltechrequests.utils.testutils.TestUtils;
import junit.framework.TestCase;

/*
 AttachmentException_UT was created on Jan 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class AttachmentException_UT extends TestCase {
  public void testExceptionClassesHaveAllConstructors() throws Exception {
    TestUtils.verifyAllConstructorsWorkForException(AttachmentException.class);
  }
}