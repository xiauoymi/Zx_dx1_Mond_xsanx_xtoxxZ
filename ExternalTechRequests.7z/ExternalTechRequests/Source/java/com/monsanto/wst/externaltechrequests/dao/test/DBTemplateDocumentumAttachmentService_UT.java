package com.monsanto.wst.externaltechrequests.dao.test;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.externaltechrequests.controller.test.MockAttachment;
import com.monsanto.wst.externaltechrequests.dao.DBTemplateDocumentumAttachmentService;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.document.test.MockDocumentService;
import com.monsanto.wst.externaltechrequests.security.test.MockPrivilegedUser;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
import junit.framework.TestCase;

/*
 DBTemplateDocumentumAttachmentService_UT was created on Jan 24, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class DBTemplateDocumentumAttachmentService_UT extends TestCase {
  private AttachmentService attachmentService;
  private MockDBTemplate template;

  protected void setUp() throws Exception {
    super.setUp();
    template = new MockDBTemplate();
    MockDocumentService docService = new MockDocumentService();
    attachmentService = new DBTemplateDocumentumAttachmentService(template, docService);
  }

  public void testGetTemplateUsesCorrectQuery() throws Exception {
    attachmentService.getTemplates(DocumentType.LEGAL);
    assertTrue(template.wasStatementNameCalled(DBTemplateDocumentumAttachmentService.LOOKUP_TEMPLATE_QUERY));
  }

  public void testAddTemplateUsesCorrectQuery() throws Exception {
    byte[] testDoc = {1, 2, 3, 4, 5, 6, 7, 8};
    MockAttachment mockAttachment = new MockAttachment(1, "test", "test", DocumentType.LEGAL, 1,
        new MockAttachedFile(testDoc));
    attachmentService.addTemplate(mockAttachment, "test");
    assertTrue(template.wasStatementNameCalled(DBTemplateDocumentumAttachmentService.ADD_TEMPLATE_STATEMENT));
  }

  public void testGetAttachmentUsesCorrectQuery() throws Exception {
    attachmentService.getAttachments(new Long(1), new MockPrivilegedUser("test"));
    assertTrue(template.wasStatementNameCalled(DBTemplateDocumentumAttachmentService.LOOKUP_ATTACHMENT_QUERY));
  }

  public void testAddAttachmentUsesCorrectQuery() throws Exception {
    byte[] testDoc = {1, 2, 3, 4, 5, 6, 7, 8};
    MockAttachment mockAttachment = new MockAttachment(1, "test", "test", DocumentType.LEGAL, 1,
        new MockAttachedFile(testDoc));
    attachmentService.addAttachment(mockAttachment, "test");
    assertTrue(template.wasStatementNameCalled(DBTemplateDocumentumAttachmentService.ADD_ATTACHMENT_STATEMENT));
  }

  public void testGetAttachmentByIdUsesCorrectQuery() throws Exception {
    attachmentService.getAttachment(new Long(1));
    assertTrue(template.wasStatementNameCalled(DBTemplateDocumentumAttachmentService.LOOKUP_ATTACHMENT_BY_ID_QUERY));
  }

  public void testUpdateUsesCorrectQuery() throws Exception {
    byte[] testDoc = {1, 2, 3, 4, 5, 6, 7, 8};
    MockAttachment mockAttachment = new MockAttachment(1, "test", "test", DocumentType.LEGAL, 1,
        new MockAttachedFile(testDoc));
    attachmentService.updateAttachment(mockAttachment, "test");
    assertFalse(template.wasStatementNameCalled(DBTemplateDocumentumAttachmentService.ADD_ATTACHMENT_STATEMENT));
    assertTrue(template.wasStatementNameCalled(DBTemplateDocumentumAttachmentService.UPDATE_ATTACHMENT_STATEMENT));
  }

  public void testDeleteUsesCorrectQuery() throws Exception {
    byte[] testDoc = {1, 2, 3, 4, 5, 6, 7, 8};
    MockAttachment mockAttachment = new MockAttachment(1, "test", "test", DocumentType.LEGAL, 1,
        new MockAttachedFile(testDoc));
    attachmentService.deleteAttachment(mockAttachment);
    assertTrue(template.wasStatementNameCalled(DBTemplateDocumentumAttachmentService.DELETE_ATTACHMENT_STATEMENT));
  }


}
