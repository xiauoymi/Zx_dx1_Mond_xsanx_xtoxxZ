/*
 LookupDao_AT was created on Nov 6, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.test;

import com.monsanto.wst.externaltechrequests.dao.LookupDao;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.utils.testutils.DbUnitBaseTransactionTestCase;
import com.monsanto.wst.factory.AbstractGenericFactory;

import java.util.List;

/**
 * Filename:    $RCSfile: LookupDao_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date:
 * 2006/11/28 18:30:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.12 $
 */
public class LookupDao_AT extends DbUnitBaseTransactionTestCase {

  protected String getConfigPath() {
    return "com/monsanto/wst/externaltechrequests/dao/test/dbunit/lookupDao.xml";
  }

  protected void cleanDatabase() {
  }

  public void testLookupRequestById() throws Exception {
    LookupDao dao = (LookupDao) AbstractGenericFactory.getInstance().getBean("lookupDao");
    RequestProfile requestProfile = dao.lookupRequestById(new Long("99999"));
    assertEquals(new Long("99999"), requestProfile.getId());
  }

  public void testLookupResearchRequestListByRequestId() throws Exception {
    LookupDao dao = (LookupDao) AbstractGenericFactory.getInstance().getBean("lookupDao");
    List list = dao.lookupResearchRequestListByRequestId(new Long("99999"));
    assertTrue(list.size() == 1);
  }

  public void testLookupStatusRequestListByRequestId() throws Exception {
    LookupDao dao = (LookupDao) AbstractGenericFactory.getInstance().getBean("lookupDao");
    List list = dao.lookupStatusRequestListByRequestId(new Long("99999"));
    assertTrue(list.size() == 1);
  }

  public void testLookupCommitteeApprovedRequestListByRequestId() throws Exception {
    LookupDao dao = (LookupDao) AbstractGenericFactory.getInstance().getBean("lookupDao");
    List list = dao.lookupCommitteApprovedRequestListByRequestId(new Long("99999"));
    assertTrue(list.size() == 1);
  }

  public void testLookupLoginUserByUserId() throws Exception {
    LookupDao dao = (LookupDao) AbstractGenericFactory.getInstance().getBean("lookupDao");
    User loginUser = dao.lookupLoginUserByUserId("DBUNIT");
    assertEquals("DBUNIT", loginUser.getUserId());
  }


}