/*
 LookupReferenceDataDao_AT was created on Nov 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.test;

import com.monsanto.wst.externaltechrequests.dao.LookupReferenceDataDao;
import com.monsanto.wst.externaltechrequests.utils.testutils.DBTemplateBaseTransactionTestCase;
import com.monsanto.wst.factory.AbstractGenericFactory;

import java.util.List;

/**
 * Filename:    $RCSfile: LookupReferenceDataDao_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-30 15:26:03 $
 *
 * @author ffbrac
 * @version $Revision: 1.4 $
 */
public class LookupReferenceDataDao_AT extends DBTemplateBaseTransactionTestCase {
	public void testGetCommitteeApprovalRefList() throws Exception {
		LookupReferenceDataDao dao = (LookupReferenceDataDao) AbstractGenericFactory.getInstance().getBean("lookupReferenceDataDao");
		List list = dao.getCommitteeApprovalRefList();
		assertTrue(list.size() > 0);
	}

  public void testGetRegionRefList() throws Exception {
		LookupReferenceDataDao dao = (LookupReferenceDataDao) AbstractGenericFactory.getInstance().getBean("lookupReferenceDataDao");
		List list = dao.getRegionRefList();
		assertTrue(list.size() > 0);
	}

  public void testGetRequestTypeRefList() throws Exception {
		LookupReferenceDataDao dao = (LookupReferenceDataDao) AbstractGenericFactory.getInstance().getBean("lookupReferenceDataDao");
		List list = dao.getRequestTypeRefList();
		assertTrue(list.size() > 0);
	}

  public void testGetResearchTypeRefList() throws Exception {
		LookupReferenceDataDao dao = (LookupReferenceDataDao) AbstractGenericFactory.getInstance().getBean("lookupReferenceDataDao");
		List list = dao.getResearchTypeRefList();
		assertTrue(list.size() > 0);
	}

  public void testGetStatusRefList() throws Exception {
		LookupReferenceDataDao dao = (LookupReferenceDataDao) AbstractGenericFactory.getInstance().getBean("lookupReferenceDataDao");
		List list = dao.getStatusRefList();
		assertTrue(list.size() > 0);
	}

  public void testGetStudyLengthTypeRefList() throws Exception {
		LookupReferenceDataDao dao = (LookupReferenceDataDao) AbstractGenericFactory.getInstance().getBean("lookupReferenceDataDao");
		List list = dao.getStudyLengthTypeRefList();
		assertTrue(list.size() > 0);
	}

  public void testGetStateRefList() throws Exception {
		LookupReferenceDataDao dao = (LookupReferenceDataDao) AbstractGenericFactory.getInstance().getBean("lookupReferenceDataDao");
    List list = dao.getStateRefList();
		assertTrue(list.size() >= 50);
	}
}