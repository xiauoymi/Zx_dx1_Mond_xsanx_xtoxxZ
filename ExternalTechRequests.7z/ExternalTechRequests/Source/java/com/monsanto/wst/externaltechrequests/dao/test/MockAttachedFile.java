package com.monsanto.wst.externaltechrequests.dao.test;

import com.monsanto.wst.externaltechrequests.document.AttachedFile;
/*
 MockAttachedFile was created on Jan 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MockAttachedFile extends AttachedFile {
  public MockAttachedFile(byte[] content) {
    super(content);
  }

  public MockAttachedFile(String content) {
    this(content.getBytes());
  }
}
