/*
 RequestDao_AT was created on Nov 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.test;

import com.monsanto.wst.externaltechrequests.dao.RequestDao;
import com.monsanto.wst.externaltechrequests.model.AddressInfo;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestResearchType;
import com.monsanto.wst.externaltechrequests.utils.testutils.DbUnitBaseTransactionTestCase;
import com.monsanto.wst.factory.AbstractGenericFactory;

import java.util.Date;

/**
 * Filename:    $RCSfile: RequestDao_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date:
 * 2006/11/28 15:22:26 $
 *
 * @author ffbrac
 * @version $Revision: 1.10 $
 */
public class RequestDao_AT extends DbUnitBaseTransactionTestCase {
  public void testInsertAddress() throws Exception {
    RequestDao dao = (RequestDao) AbstractGenericFactory.getInstance().getBean("requestDao");
    AddressInfo address = new AddressInfo(new Long("100000"));
    Long id = dao.insertAddress(address);
    assertEquals(new Long("100000"), id);
  }

  public void testInsertRequestProfile() throws Exception {
    RequestDao dao = (RequestDao) AbstractGenericFactory.getInstance().getBean("requestDao");
    RequestProfile request = new RequestProfile(new Long("100000"));
    request.setShipToAddress(new AddressInfo(new Long("100001")));
    request.setResearchAddress(new AddressInfo(new Long("100002")));
    request.setModDate(new Date());
    request.setModUser("FFBRAC");
    request.setRequestNumber("SWRG-2006-000010");
    request.setRequestorContactName("Filip");

    Long id = dao.insertRequestProfile(request);
    assertEquals(new Long("100000"), id);
  }

  public void testInsertRequestResearch() throws Exception {
    RequestDao dao = (RequestDao) AbstractGenericFactory.getInstance().getBean("requestDao");
    RequestResearchType requestResearchType = new RequestResearchType(new Long("100000"));
    requestResearchType.setRequestId(new Long("99999"));
    requestResearchType.setResearchTypeId(new Long("0"));
    requestResearchType.setModDate(new Date());
    requestResearchType.setModUser("FFBRAC");

    Long id = dao.insertRequestResearch(requestResearchType);
    assertEquals(new Long("100000"), id);
  }

  public void testInsertStatusResearch() throws Exception {
    RequestDao dao = (RequestDao) AbstractGenericFactory.getInstance().getBean("requestDao");
    RequestResearchType requestResearchType = new RequestResearchType(new Long("100000"));
    requestResearchType.setRequestId(new Long("99999"));
    requestResearchType.setResearchTypeId(new Long("0"));
    requestResearchType.setModDate(new Date());
    requestResearchType.setModUser("FFBRAC");

    Long id = dao.insertStatusResearch(requestResearchType);
    assertEquals(new Long("100000"), id);
  }

  public void testInsertCommitteeApprovedRequest() throws Exception {
    RequestDao dao = (RequestDao) AbstractGenericFactory.getInstance().getBean("requestDao");
    RequestResearchType requestResearchType = new RequestResearchType(new Long("100000"));
    requestResearchType.setRequestId(new Long("99999"));
    requestResearchType.setResearchTypeId(new Long("0"));
    requestResearchType.setModDate(new Date());
    requestResearchType.setModUser("FFBRAC");

    Long id = dao.insertCommitteeApprovedResearch(requestResearchType);
    assertEquals(new Long("100000"), id);
  }

  public void testUpdateRequestProfile() throws Exception {
    RequestDao dao = (RequestDao) AbstractGenericFactory.getInstance().getBean("requestDao");
    RequestProfile request = new RequestProfile(new Long("99999"));
    request.setShipToAddress(new AddressInfo(new Long("100001")));
    request.setResearchAddress(new AddressInfo(new Long("100002")));
    request.setModDate(new Date());
    request.setModUser("FFBRAC");
    request.setRequestorContactName("Filip");

    Long id = dao.updateRequestProfile(request);
    assertEquals(new Long("99999"), id);
  }

  public void testUpdateAddressInfo() throws Exception {
    RequestDao dao = (RequestDao) AbstractGenericFactory.getInstance().getBean("requestDao");
    AddressInfo address = new AddressInfo(new Long("100001"));
    Long id = dao.updateAddressInfo(address);
    assertEquals(new Long("100001"), id);
  }

  public void testDeleteRequestResearch() throws Exception {
    RequestDao dao = (RequestDao) AbstractGenericFactory.getInstance().getBean("requestDao");
    Long id = dao.deleteRequestResearch(new Long("99999"));
    assertEquals(new Long("99999"), id);
  }

  protected String getConfigPath() {
    return "com/monsanto/wst/externaltechrequests/dao/test/dbunit/requestDao.xml";
  }

  protected void cleanDatabase() {
  }
}