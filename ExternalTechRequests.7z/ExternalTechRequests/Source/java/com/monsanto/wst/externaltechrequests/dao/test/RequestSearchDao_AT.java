/*
 RequestSearchDao_AT was created on Nov 15, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.dao.test;

import com.monsanto.wst.externaltechrequests.dao.RequestSearchDao;
import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.utils.testutils.DbUnitBaseTransactionTestCase;
import com.monsanto.wst.factory.AbstractGenericFactory;

import java.util.List;

/**
 * Filename:    $RCSfile: RequestSearchDao_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-28 21:36:38 $
 *
 * @author ffbrac
 * @version $Revision: 1.8 $
 */
public class RequestSearchDao_AT extends DbUnitBaseTransactionTestCase {
  public void testGetRequestListBySearchCriteria() throws Exception {
    RequestSearchDao dao = (RequestSearchDao) AbstractGenericFactory.getInstance().getBean("requestSearchDao");
    RequestSearch requestSearch = new RequestSearch("test", null, null, null, new Long(0), null, null, null, null,
        "01/01/2005", "03/03/2005", null, null);
    List list = dao.getRequestListBySearchCriteria(requestSearch);

    assertTrue(list.size() == 1);
  }

  protected String getConfigPath() {
    return "com/monsanto/wst/externaltechrequests/dao/test/dbunit/requestDao.xml";
  }

  protected void cleanDatabase() {
  }
}