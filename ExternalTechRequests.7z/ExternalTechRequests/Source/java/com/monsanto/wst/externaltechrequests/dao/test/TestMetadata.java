package com.monsanto.wst.externaltechrequests.dao.test;

import com.monsanto.wst.externaltechrequests.model.AttachmentMetadata;
/*
 TestMetadata was created on Jan 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class TestMetadata extends AttachmentMetadata {
  public TestMetadata(long attachmentID, String name) {
    super.setId(new Long(attachmentID));
    super.setName(name);
  }
}
