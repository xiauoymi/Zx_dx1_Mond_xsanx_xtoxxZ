package com.monsanto.wst.externaltechrequests.dao.test;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.POSClient.XMLPOSConnection;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.document.POSConnectionFactory;
import org.ietf.jgss.GSSException;
/*
 TestPOSConnectionFactory was created on Jan 25, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * This creates a standalone (without a UCCHelper) POSConnectionFactory.  This can then be used in AT
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class TestPOSConnectionFactory implements POSConnectionFactory {
  public XMLPOSConnection getConnection() throws POSCommunicationException {
    try {
      return new SecureXMLPOSConnection(new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()),
          new KerberosStandaloneCredential());
    } catch (GSSException e) {
      throw new POSCommunicationException(e);
    }
  }

  public void loadSecurityInformationFromHelper(UCCHelper helper) {
  }
}
