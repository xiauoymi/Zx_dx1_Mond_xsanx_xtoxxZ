package com.monsanto.wst.externaltechrequests.document;

import com.monsanto.wst.externaltechrequests.controller.ModifiableAttachment;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.model.AttachmentMetadata;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.NullUser;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.User;

import java.util.ArrayList;
import java.util.List;
/*
 AttachmentCollection was created on Feb 5, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class AttachmentCollection {
  private final List legalAttachments;
  private final List shippingAttachments;
  private final List otherAttachments;

  public AttachmentCollection(List attachments) {
    this(attachments, new NullUser());
  }

  public AttachmentCollection(List attachments, User user) {
    if (attachments == null) {
      throw new NullPointerException("attachments cannot be null");
    }

    this.legalAttachments = new ArrayList();
    this.shippingAttachments = new ArrayList();
    this.otherAttachments = new ArrayList();

    for (int i = 0; i < attachments.size(); i++) {
      Attachment attachment = (Attachment) attachments.get(i);
      AttachmentMetadata metadata = attachment.getMetadata();
      DocumentType attachmentType = metadata.getAttachmentType();
      boolean updatable = user.canEdit(new RequestProfile(metadata.getRequestId()));
      boolean deletable = user.hasPrivilege(Privilege.DELETE_ATTACHMENT);
      ModifiableAttachment wrappedAttachment = new ModifiableAttachment(attachment, updatable, deletable);
      if (DocumentType.LEGAL == attachmentType) {
        legalAttachments.add(wrappedAttachment);
      } else if (DocumentType.SHIPPING == attachmentType) {
        shippingAttachments.add(wrappedAttachment);
      } else {
        otherAttachments.add(wrappedAttachment);
      }
    }
  }

  public List getLegalAttachments() {
    return legalAttachments;
  }

  public List getShippingAttachments() {
    return shippingAttachments;
  }

  public List getOtherAttachments() {
    return otherAttachments;
  }


}
