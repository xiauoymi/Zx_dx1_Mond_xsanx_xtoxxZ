package com.monsanto.wst.externaltechrequests.document;
/*
 DocumentDeletionException was created on Jan 25, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class DocumentDeletionException extends Exception {
  public DocumentDeletionException() {
  }

  public DocumentDeletionException(String message) {
    super(message);
  }

  public DocumentDeletionException(Throwable cause) {
    super(cause);
  }

  public DocumentDeletionException(String message, Throwable cause) {
    super(message, cause);
  }
}
