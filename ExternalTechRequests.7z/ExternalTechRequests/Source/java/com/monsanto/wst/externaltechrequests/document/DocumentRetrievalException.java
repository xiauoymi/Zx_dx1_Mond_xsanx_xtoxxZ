package com.monsanto.wst.externaltechrequests.document;
/*
 DocumentRetrievalException was created on Jan 25, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class DocumentRetrievalException extends Exception {
  public DocumentRetrievalException() {
  }

  public DocumentRetrievalException(String message) {
    super(message);
  }

  public DocumentRetrievalException(Throwable cause) {
    super(cause);
  }

  public DocumentRetrievalException(String message, Throwable cause) {
    super(message, cause);
  }
}
