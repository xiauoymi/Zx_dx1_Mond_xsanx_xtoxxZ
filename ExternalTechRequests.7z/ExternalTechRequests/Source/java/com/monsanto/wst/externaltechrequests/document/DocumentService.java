package com.monsanto.wst.externaltechrequests.document;

import com.monsanto.ServletFramework.UCCHelper;

/*
 DocumentService was created on Jan 24, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public interface DocumentService {
  String store(long attachmentID, AttachedFile data) throws DocumentStorageException;
  AttachedFile retreive(String repositoryId) throws DocumentRetrievalException;
  void loadSecurityInfoFromHelper(UCCHelper helper);
  void update(String repoId, AttachedFile data) throws DocumentStorageException;
  void delete(String repoId) throws DocumentDeletionException;
}
