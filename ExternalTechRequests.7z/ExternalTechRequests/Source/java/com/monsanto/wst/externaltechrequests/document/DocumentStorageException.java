package com.monsanto.wst.externaltechrequests.document;
/*
 DocumentStorageException was created on Jan 25, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class DocumentStorageException extends Exception {
  public DocumentStorageException() {
  }

  public DocumentStorageException(String message) {
    super(message);
  }

  public DocumentStorageException(Throwable cause) {
    super(cause);
  }

  public DocumentStorageException(String message, Throwable cause) {
    super(message, cause);
  }
}
