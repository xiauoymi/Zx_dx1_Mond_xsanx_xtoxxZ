/*
 ${NAME} was created on Jan 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
package com.monsanto.wst.externaltechrequests.document;

public class DocumentType {
  private final int id;
  private final String desc;

  public static final DocumentType LEGAL = new DocumentType(1, "LEGAL");
  public static final DocumentType SHIPPING = new DocumentType(2, "SHIPPING");
  public static final DocumentType OTHER = new DocumentType(3, "OTHER");

  private static final DocumentType[] ALL_TYPES = {LEGAL, SHIPPING};

  private DocumentType(int id, String desc) {
    this.id = id;
    this.desc = desc;
  }

  public int getId() {
    return id;
  }

  public String toString() {
    return desc;
  }

  public static DocumentType getDocumentType(long id) {
    for (int i = 0; i < ALL_TYPES.length; i++) {
      DocumentType type = ALL_TYPES[i];
      if (type.id == id) {
        return type;
      }
    }

    return OTHER;
  }
}
