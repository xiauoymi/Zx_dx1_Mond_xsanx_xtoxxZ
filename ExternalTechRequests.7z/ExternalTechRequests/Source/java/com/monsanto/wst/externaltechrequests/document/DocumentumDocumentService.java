package com.monsanto.wst.externaltechrequests.document;

import com.monsanto.POSClient.*;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import org.apache.xerces.impl.dv.util.Base64;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
/*
 DocumentumDocumentService was created on Jan 25, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class DocumentumDocumentService implements DocumentService {
  private static final String POS_INSERT_SERVICE_NAME = "InsertDocumentService";
  private static final String POS_UPDATE_SERVICE_NAME = "UpdateDocumentService";
  private static final String POS_RETRIEVE_SERVICE_NAME = "RetrieveDocumentService";
  private static final String POS_DELETE_SERVICE_NAME = "DeleteDocumentService";

  private static final String OBJECT_ID_XPATH = "/documentManagerResponse/insertDocument/documentDetails/attribute[name='objectId']/value/text()";
  private static final String CONTENTS_XPATH = "/documentManagerResponse/retrieveDocument/documentDetails/attribute[name='contents']/value/text()";

  private static final String ETR_DOC_PREFIX = "ExternalTechRequests-";
  private static final String ETR_DOCUMENTUM_FOLDER = "ExternalTechRequests";

  private final POSConnectionFactory posFactory;

  public DocumentumDocumentService(POSConnectionFactory posFactory) {
    this.posFactory = posFactory;
  }

  public String store(long attachmentID, AttachedFile data) throws DocumentStorageException {
    checkDataIsValid(data);
    String fileName = ETR_DOC_PREFIX + Long.toString(attachmentID);
    String localFilename = writeAttachmentToTemporaryFile(data);
    Document responseDoc = storeDocumentToRepository(localFilename, fileName);
    return getRepositoryIdFromResponseDocument(responseDoc);
  }

  public AttachedFile retreive(String repositoryId) throws DocumentRetrievalException {
    Document inputDocument = buildRetrieveRequest(repositoryId, new ArrayList());
    Document responseDocument = retreiveDocumentFromRepository(inputDocument);
    return extractAttachmentFromDocument(responseDocument);
  }

  public void loadSecurityInfoFromHelper(UCCHelper helper) {
    posFactory.loadSecurityInformationFromHelper(helper);
  }

  public void update(String repoId, AttachedFile data) throws DocumentStorageException {
    checkDataIsValid(data);
    String localFilename = writeAttachmentToTemporaryFile(data);
    Document requestXmlDocument = buildUpdateRequestDocument(repoId);
    updateDocumentInRepository(localFilename, requestXmlDocument);
  }

  public void delete(String repositoryId) throws DocumentDeletionException {
    Document inputDocument = buildDeleteRequest(repositoryId);
    deleteDocumentInRepository(inputDocument);
  }

  private void deleteDocumentInRepository(Document inputDocument) throws DocumentDeletionException {
    try {
      XMLPOSConnection posConn = posFactory.getConnection();
      posConn.callService(POS_DELETE_SERVICE_NAME, inputDocument);
    } catch (POSCommunicationException e) {
      throw new DocumentDeletionException(e);
    } catch (POSException e) {
      throw new DocumentDeletionException(e);
    }
  }

  private void updateDocumentInRepository(String localFilename, Document requestXmlDocument) throws
      DocumentStorageException {
    Document responseDoc;
    try {
      MultipartAttachmentList attachmentList = new MultipartAttachmentList();
      addAttachment(attachmentList, localFilename);
      responseDoc = updateDocument(attachmentList, requestXmlDocument);
    } catch (InvalidMimeTypeException e) {
      throw new DocumentStorageException(e);
    } catch (POSCommunicationException e) {
      throw new DocumentStorageException(e);
    } catch (POSException e) {
      throw new DocumentStorageException(e);
    }

    if (responseDoc == null) {
      throw new DocumentStorageException("Connection to document pos failed");
    }
  }

  private Document retreiveDocumentFromRepository(Document inputDocument) throws DocumentRetrievalException {
    Document responseDocument;
    try {
      XMLPOSConnection posConn = posFactory.getConnection();
      POSResult result = posConn.callService(POS_RETRIEVE_SERVICE_NAME, inputDocument);
      responseDocument = new POSResultDocumentProcessor().getDocument(result);
    } catch (POSCommunicationException e) {
      throw new DocumentRetrievalException(e);
    } catch (POSException e) {
      throw new DocumentRetrievalException(e);
    }
    return responseDocument;
  }

  private String getRepositoryIdFromResponseDocument(Document responseDoc) throws DocumentStorageException {
    String objId;
    try {
      objId = XPathAPI.eval(responseDoc, OBJECT_ID_XPATH).toString();
    } catch (TransformerException e) {
      throw new DocumentStorageException(e);
    }

    if (objId == null || objId.length() == 0) {
      throw new DocumentStorageException("Unable to determine object id of stored document");
    }
    return objId;
  }

  private Document storeDocumentToRepository(String localFilename, String fileName) throws DocumentStorageException {
    Document responseDoc;
    try {
      MultipartAttachmentList attachmentList = new MultipartAttachmentList();
      addAttachment(attachmentList, localFilename);
      Document requestXmlDocument = buildStoreRequestDocument(fileName);
      DOMUtil.outputXML(requestXmlDocument);
      responseDoc = insertDocument(attachmentList, requestXmlDocument);
    } catch (InvalidMimeTypeException e) {
      throw new DocumentStorageException(e);
    } catch (POSCommunicationException e) {
      throw new DocumentStorageException(e);
    } catch (POSException e) {
      throw new DocumentStorageException(e);
    }

    if (responseDoc == null) {
      throw new DocumentStorageException("Connection to document pos failed");
    }

    return responseDoc;
  }

  private void checkDataIsValid(AttachedFile data) throws DocumentStorageException {
    if (data == null || data.getContent() == null || data.getContent().length == 0) {
      throw new DocumentStorageException("An empty attachment cannot be stored");
    }
  }

  private String writeAttachmentToTemporaryFile(AttachedFile data) throws DocumentStorageException {
    String localFilename;
    try {
      File tempFile = File.createTempFile("etr-temp", ".txt");
      localFilename = tempFile.getCanonicalPath();
      writeFile(tempFile, data.getContent());
    } catch (IOException e) {
      throw new DocumentStorageException(e);
    }
    return localFilename;
  }

  private void writeFile(File file, byte[] data) throws IOException {
    OutputStream out = new BufferedOutputStream(new FileOutputStream(file));
    for (int i = 0; i < data.length; i++) {
      out.write(data[i]);
    }
    out.close();
  }

  private Document insertDocument(MultipartAttachmentList attachmentList, Document inputDoc) throws POSException,
      POSCommunicationException {
    XMLPOSConnection posConn = posFactory.getConnection();
    addAttachmentToConnection(attachmentList, posConn);
    POSResult result = posConn.callService(POS_INSERT_SERVICE_NAME, inputDoc);
    return new POSResultDocumentProcessor().getDocument(result);
  }

  private Document updateDocument(MultipartAttachmentList attachmentList, Document requestDoc)
      throws POSCommunicationException, POSException {
    XMLPOSConnection posConn = posFactory.getConnection();
    addAttachmentToConnection(attachmentList, posConn);
    POSResult result = posConn.callService(POS_UPDATE_SERVICE_NAME, requestDoc);
    return new POSResultDocumentProcessor().getDocument(result);
  }

  private void addAttachment(MultipartAttachmentList attachmentList, String fileName) throws InvalidMimeTypeException {
    String mimeType;
    mimeType = new MimeTypeFactory().getType(fileName);
    MultiPartFormAttachment attachment = new MultiPartFormAttachment(fileName, mimeType);
    attachmentList.addAttachment(attachment);
  }

  private void addAttachmentToConnection(MultipartAttachmentList attachmentList, XMLPOSConnection posConn) {
    int numberOfAttachments = attachmentList.getLength();
    for (int i = 0; i < numberOfAttachments; i++) {
      MultiPartFormAttachment attachment = attachmentList.getAttachment(i);
      posConn.addAttachment(attachment);
    }
  }

  private Document buildStoreRequestDocument(String filename) {
    Document insertRequestDoc = DOMUtil.newDocument();
    Node rootNode = DOMUtil.addChildElementWithNS("www.monsanto.com/pos", insertRequestDoc, "insertDocumentRequest");
    DOMUtil.addChildElement(rootNode, "folder", ETR_DOCUMENTUM_FOLDER);
    Element requestDetailsElement = DOMUtil.addChildElement(rootNode, "requestDetails");
    Element insertDocumentElement = DOMUtil.addChildElement(requestDetailsElement, "insertDocument");
    Element documentAttributesElement = DOMUtil.addChildElement(insertDocumentElement, "documentAttributes");
    addAttribute(documentAttributesElement, "name", filename);

    return insertRequestDoc;
  }

  private Document buildUpdateRequestDocument(String repoId) {
    Document updateRequestDoc = DOMUtil.newDocument();
    Node rootNode = DOMUtil.addChildElementWithNS("www.monsanto.com/pos", updateRequestDoc, "updateDocumentRequest");
    DOMUtil.addChildElement(rootNode, "folder", ETR_DOCUMENTUM_FOLDER);
    Element requestDetailsElement = DOMUtil.addChildElement(rootNode, "requestDetails");
    Element insertDocumentElement = DOMUtil.addChildElement(requestDetailsElement, "updateDocument");
    Element documentAttributesElement = DOMUtil.addChildElement(insertDocumentElement, "documentAttributes");
    addAttribute(documentAttributesElement, "objectId", repoId);

    return updateRequestDoc;
  }

  private Document buildRetrieveRequest(String objectId, List requiredAttributes) {
    Document retrieveReqDoc = DOMUtil.newDocument();
    Node rootNode = DOMUtil.addChildElementWithNS("www.monsanto.com/pos", retrieveReqDoc, "retrieveDocumentRequest");
    DOMUtil.addChildElement(rootNode, "folder", ETR_DOCUMENTUM_FOLDER);
    Node requestDetailsNode = DOMUtil.addChildElement(rootNode, "requestDetails");
    Node retrieveDocNode = DOMUtil.addChildElement(requestDetailsNode, "retrieveDocument");
    addDocumentAttributesNode(retrieveDocNode, objectId);
    if (requiredAttributes != null && requiredAttributes.size() > 0) {
      addRequiredAttributesNode(retrieveDocNode, requiredAttributes);
    }
    return retrieveReqDoc;
  }

  private Document buildDeleteRequest(String repositoryId) {
    Document deleteReqDoc = DOMUtil.newDocument();
    Node rootNode = DOMUtil.addChildElementWithNS("www.monsanto.com/pos", deleteReqDoc, "deleteDocumentRequest");
    DOMUtil.addChildElement(rootNode, "folder", ETR_DOCUMENTUM_FOLDER);
    Node requestDetailsNode = DOMUtil.addChildElement(rootNode, "requestDetails");
    Node deleteDocNode = DOMUtil.addChildElement(requestDetailsNode, "deleteDocument");
    addDocumentAttributesNode(deleteDocNode, repositoryId);

    return deleteReqDoc;
  }

  private void addRequiredAttributesNode(Node retrieveDocNode, List requiredAttributes) {
    Node requiredAttrNode = DOMUtil.addChildElement(retrieveDocNode, "requiredAttributes");
    for (int i = 0; i < requiredAttributes.size(); i++) {
      String requiredAttr = (String) requiredAttributes.get(i);
      DOMUtil.addChildElement(requiredAttrNode, "attribute", requiredAttr);
    }
  }

  private void addDocumentAttributesNode(Node retrieveDocNode, String objectId) {
    Node docAttrName = DOMUtil.addChildElement(retrieveDocNode, "queryAttributes");
    addAttribute(docAttrName, "objectId", objectId);
  }

  private void addAttribute(Node node, String name, String value) {
    Node attrName = DOMUtil.addChildElement(node, "attribute");
    DOMUtil.addChildElement(attrName, "name", name);
    DOMUtil.addChildElement(attrName, "value", value);
  }

  private AttachedFile extractAttachmentFromDocument(Document doc) throws DocumentRetrievalException {
    try {
      String encodedContentString = XPathAPI.eval(doc, CONTENTS_XPATH).toString();
      byte[] content = Base64.decode(encodedContentString);
      return new AttachedFile(content);
    } catch (TransformerException e) {
      throw new DocumentRetrievalException(e);
    }
  }
}
