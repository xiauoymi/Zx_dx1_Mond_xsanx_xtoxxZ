package com.monsanto.wst.externaltechrequests.document;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
/*
 MimeTypeFactory was created on Feb 2, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MimeTypeFactory {
  private static final String ALLOWED_FILENAME_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890-_.";

  public static final String PLAIN_TEXT_MIME_TYPE = "text/plain";
  public static final String WORD_MIME_TYPE = "application/msword";
  public static final String EXCEL_MIME_TYPE = "application/vnd.ms-excel";
  public static final String PDF_MIME_TYPE = "application/pdf";
  public static final String RTF_MIME_TYPE = "application/rtf";
  public static final String OUTLOOK_MIME_TYPE = "application/vnd.ms-outlook";
  public static final String POWERPOINT_MIME_TYPE = "application/vnd.ms-powerpoint";
  public static final String PROJECT_MIME_TYPE = "application/vnd.ms-project";
  public static final String WORKS_MIME_TYPE = "application/vnd.ms-works";
  public static final String HELP_MIME_TYPE = "application/winhlp hlp";
  public static final String ACCESS_MIME_TYPE = "application/x-msaccess mdb";
  public static final String PUBLISHER_MIME_TYPE = "application/x-mspublisher pub";
  public static final String WRITE_MIME_TYPE = "application/x-mswrite wri";
  public static final String ZIP_MIME_TYPE = "application/zip zip";
  public static final String AU_MIME_TYPE = "audio/basic au";
  public static final String MIDI_MIME_TYPE = "audio/mid mid";
  public static final String MP3_MIME_TYPE = "audio/mpeg mp3";
  public static final String AIF_MIME_TYPE = "audio/x-aiff aif";
  public static final String WAV_MIME_TYPE = "audio/x-wav wav";
  public static final String BMP_MIME_TYPE = "image/bmp bmp";
  public static final String GIF_MIME_TYPE = "image/gif gif";
  public static final String JPEG_MIME_TYPE = "image/jpeg jpe";
  public static final String TIFF_MIME_TYPE = "image/tiff";
  public static final String HTML_MIME_TYPE = "text/html";
  public static final String MPEG_MIME_TYPE = "video/mpeg";
  public static final String QUCIKTIME_MIME_TYPE = "video/quicktime";
  public static final String AVI_MIME_TYPE = "video/x-msvideo";
  public static final String UNKNOWN_MIME_TYPE = "application/octet-stream";

  private final Map typeMapping;
  private final Map extensionForType;

  public MimeTypeFactory() {
    typeMapping = new HashMap();
    extensionForType = new HashMap();
    addType("txt", PLAIN_TEXT_MIME_TYPE);

    addType("dot", WORD_MIME_TYPE);
    addType("doc", WORD_MIME_TYPE);
    addType("docx", WORD_MIME_TYPE);

    addType("pdf", PDF_MIME_TYPE);

    addType("rtf", RTF_MIME_TYPE);

    addType("xla", EXCEL_MIME_TYPE);
    addType("xlc", EXCEL_MIME_TYPE);
    addType("xlm", EXCEL_MIME_TYPE);
    addType("xlt", EXCEL_MIME_TYPE);
    addType("xlw", EXCEL_MIME_TYPE);
    addType("xls", EXCEL_MIME_TYPE);
    addType("xlsx", EXCEL_MIME_TYPE);

    addType("msg", OUTLOOK_MIME_TYPE);

    addType("pot", POWERPOINT_MIME_TYPE);
    addType("pps", POWERPOINT_MIME_TYPE);
    addType("ppt", POWERPOINT_MIME_TYPE);
    addType("ppt", POWERPOINT_MIME_TYPE);
    addType("pptx", POWERPOINT_MIME_TYPE);

    addType("mpp", PROJECT_MIME_TYPE);

    addType("wcm", WORKS_MIME_TYPE);
    addType("wdb", WORKS_MIME_TYPE);
    addType("wks", WORKS_MIME_TYPE);
    addType("wps", WORKS_MIME_TYPE);

    addType("hlp", HELP_MIME_TYPE);
    addType("mdb", ACCESS_MIME_TYPE);
    addType("pub", PUBLISHER_MIME_TYPE);
    addType("wri", WRITE_MIME_TYPE);
    addType("zip", ZIP_MIME_TYPE);
    addType("au", AU_MIME_TYPE);
    addType("mid", MIDI_MIME_TYPE);
    addType("mp3", MP3_MIME_TYPE);

    addType("aif", AIF_MIME_TYPE);
    addType("aiff", AIF_MIME_TYPE);

    addType("wav", WAV_MIME_TYPE);
    addType("bmp", BMP_MIME_TYPE);
    addType("gif", GIF_MIME_TYPE);

    addType("jpe", JPEG_MIME_TYPE);
    addType("jpeg", JPEG_MIME_TYPE);
    addType("jpg", JPEG_MIME_TYPE);

    addType("tif", TIFF_MIME_TYPE);
    addType("tiff", TIFF_MIME_TYPE);

    addType("htm", HTML_MIME_TYPE);
    addType("html", HTML_MIME_TYPE);

    addType("mp2", MPEG_MIME_TYPE);
    addType("mpa", MPEG_MIME_TYPE);
    addType("mpe", MPEG_MIME_TYPE);
    addType("mpg", MPEG_MIME_TYPE);
    addType("mpv2", MPEG_MIME_TYPE);
    addType("mpeg", MPEG_MIME_TYPE);

    addType("mov", QUCIKTIME_MIME_TYPE);
    addType("qt", QUCIKTIME_MIME_TYPE);

    addType("avi", AVI_MIME_TYPE);
  }

  public String getFilename(String description, String mimeType) {
    StringBuffer filename = cleanFilename(description);
    String ext = getExtensionForType(mimeType);
    if (ext != null) {
      filename.append('.');
      filename.append(ext);
    }
    return filename.toString();
  }

  public String getExtensionForType(String mimeType) {
    return (String) extensionForType.get(mimeType);
  }

  private StringBuffer cleanFilename(String orig) {
    StringBuffer clean = new StringBuffer();

    for (int i = 0; i < orig.length(); i++) {
      char ch = orig.charAt(i);
      if (Character.isSpaceChar(ch)) {
        clean.append('_');
      } else if (ALLOWED_FILENAME_CHARS.indexOf(ch) >= 0) {
        clean.append(ch);
      } else {
        // skip the disallowed character
      }
    }

    return clean;
  }

  public String getType(String filename) {
    String ext = getExtension(filename);
    String type = (String) typeMapping.get(ext);
    if (type == null) {
      return UNKNOWN_MIME_TYPE;
    } else {
      return type;
    }
  }

  public boolean isEditable(String mimeType) {
    return HTML_MIME_TYPE.equals(mimeType) || PLAIN_TEXT_MIME_TYPE.equals(mimeType);
  }

  public String getType(File file) throws IOException {
    return getType(file.getCanonicalPath());
  }

  private void addType(String ext, String mimeType) {
    typeMapping.put(ext, mimeType);
    extensionForType.put(mimeType, ext);
  }

  private String getExtension(String filename) {
    int dotPos = filename.lastIndexOf('.');
    if (dotPos >= 0) {
      return filename.substring(dotPos + 1);
    } else {
      return "";
    }
  }

}
