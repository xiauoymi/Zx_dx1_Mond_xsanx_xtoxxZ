package com.monsanto.wst.externaltechrequests.document;

import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.XMLPOSConnection;
import com.monsanto.ServletFramework.UCCHelper;
/*
 POSConnectionFactory was created on Jan 25, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public interface POSConnectionFactory {
  XMLPOSConnection getConnection() throws POSCommunicationException;
  void loadSecurityInformationFromHelper(UCCHelper helper); //todo need to find a better way than this
}
