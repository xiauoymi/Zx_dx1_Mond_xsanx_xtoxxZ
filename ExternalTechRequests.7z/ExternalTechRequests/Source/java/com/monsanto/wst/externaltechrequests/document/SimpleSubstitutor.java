package com.monsanto.wst.externaltechrequests.document;

import java.util.Iterator;
import java.util.Map;
import java.util.Arrays;
/*
 SimpleSubstitutor was created on Feb 12, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class SimpleSubstitutor {
  public byte[] substitute(byte[] original, Map params) {
    if (isSafeToModify(original)) {
      String currString = new String(original);
      Iterator paramIterator = params.keySet().iterator();
      while (paramIterator.hasNext()) {
        String paramName = (String) paramIterator.next();
        String paramValue = (String) params.get(paramName);
        if (paramValue != null) {
          currString = replace(currString, "~~" + paramName + "~~", paramValue);
        }
      }
      return currString.getBytes();
    } else {
      return original;
    }
  }

  private boolean isSafeToModify(byte[] original) {
    byte[] suspect = new String(original).getBytes();
    return Arrays.equals(original, suspect);
  }

  public String replace(String source, String search, String replace) {
    String newSource = source;
    int pos = newSource.indexOf(search);
    while (pos >= 0) {
      newSource = newSource.substring(0, pos) + replace + newSource.substring(pos + search.length());
      pos = newSource.indexOf(search);
    }

    return newSource;
  }
}
