package com.monsanto.wst.externaltechrequests.document.test;

import com.monsanto.wst.externaltechrequests.controller.test.MockAttachment;
import com.monsanto.wst.externaltechrequests.document.AttachmentCollection;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/*
 AttachmentCollection_UT was created on Feb 5, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class AttachmentCollection_UT extends TestCase {
  public void testNullCollectionThrowsNPE() throws Exception {
    try {
      new AttachmentCollection(null);
      fail("Expected exception not received");
    } catch (NullPointerException IGNORE) {
      // ignore expected exception
    }
  }

  public void testEmptyListResultsInEmptyLists() throws Exception {
    AttachmentCollection coll = new AttachmentCollection(new ArrayList());
    assertEmptyList(coll.getLegalAttachments());
    assertEmptyList(coll.getShippingAttachments());
    assertEmptyList(coll.getOtherAttachments());
  }

  public void testOneLegalAttachment() throws Exception {
    List list = new ArrayList();
    list.add(new MockAttachment(1, "test", "test", DocumentType.LEGAL, 1));
    AttachmentCollection coll = new AttachmentCollection(list);
    assertEquals(1, coll.getLegalAttachments().size());
    assertEmptyList(coll.getShippingAttachments());
    assertEmptyList(coll.getOtherAttachments());
  }

  public void testOneOfEachAttachment() throws Exception {
    List list = new ArrayList();
    list.add(new MockAttachment(1, "test", "test", DocumentType.LEGAL, 1));
    list.add(new MockAttachment(1, "test", "test", DocumentType.SHIPPING, 1));
    list.add(new MockAttachment(1, "test", "test", DocumentType.OTHER, 1));
    AttachmentCollection coll = new AttachmentCollection(list);
    assertEquals(1, coll.getLegalAttachments().size());
    assertEquals(1, coll.getShippingAttachments().size());
    assertEquals(1, coll.getOtherAttachments().size());
  }

  private void assertEmptyList(List list) {
    assertNotNull(list);
    assertTrue(list.isEmpty());
  }
}