package com.monsanto.wst.externaltechrequests.document.test;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.POSClient.XMLPOSConnection;
import com.monsanto.wst.documentutil.documentposutil.DocumentServiceSearchClientUtil;
import com.monsanto.wst.documentutil.documentposutil.DocumentServiceClientUtil;
import com.monsanto.wst.externaltechrequests.dao.test.TestPOSConnectionFactory;
import com.monsanto.wst.externaltechrequests.document.DocumentDeletionException;
import com.monsanto.wst.externaltechrequests.document.DocumentumDocumentService;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/*
 DocumentTestCase was created on Jan 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public abstract class DocumentTestCase extends TestCase {
  private List testDocs;

  protected void setUp() throws Exception {
    String[] objectId = new String[2];
    super.setUp();
   DocumentServiceClientUtil documentServiceClientUtil;
   documentServiceClientUtil = new DocumentServiceClientUtil(new KerberosStandaloneCredential(), "ExternalTechRequests");
   XMLPOSConnection posConn;
   posConn = new SecureXMLPOSConnection(new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), new KerberosStandaloneCredential());
   DocumentServiceSearchClientUtil documentServiceSearchCriteria;
   documentServiceSearchCriteria = new DocumentServiceSearchClientUtil();
   objectId = documentServiceSearchCriteria.searchService(posConn,"com/monsanto/wst/documentutil/documentposutil/xmlresource/newSearchRequest.xml");
   if (objectId.length > 0 && objectId != null)
   {
     for (int i = 0; i < objectId.length; i++)
       documentServiceClientUtil.deleteDocument (objectId[i]);
   }

    testDocs = new ArrayList();
  }

  protected void tearDown() throws Exception {
    super.tearDown();
    deleteTestDocs();
  }

  private void deleteTestDocs() throws DocumentDeletionException {
    for (int i = 0; i < testDocs.size(); i++) {
      String docId = (String) testDocs.get(i);
      DocumentumDocumentService docService = new DocumentumDocumentService(new TestPOSConnectionFactory());
//      docService.delete(docId);
    }
  }

  protected void deleteTestDocOnTeardown(String testDoc) {
    testDocs.add(testDoc);
  }
}