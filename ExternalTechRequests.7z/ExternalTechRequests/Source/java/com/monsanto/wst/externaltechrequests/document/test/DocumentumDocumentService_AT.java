package com.monsanto.wst.externaltechrequests.document.test;

import com.monsanto.wst.externaltechrequests.dao.test.TestPOSConnectionFactory;
import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.document.DocumentService;
import com.monsanto.wst.externaltechrequests.document.DocumentumDocumentService;
import com.monsanto.Util.FileUtil;

import java.util.Arrays;
import java.io.OutputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

/*
 DocumentumDocumentService_AT was created on Jan 25, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class DocumentumDocumentService_AT extends DocumentTestCase {
  public void testStoreAndReceiveDocument() throws Exception {
    byte[] data = "Hello, repository".getBytes();
    AttachedFile testFile = new AttachedFile(data);
    long testAttachmentId = 1234;

    DocumentService docService = new DocumentumDocumentService(new TestPOSConnectionFactory());
    String repoId = docService.store(testAttachmentId, testFile);
    deleteTestDocOnTeardown(repoId);

    AttachedFile retrievedFile = docService.retreive(repoId);
    assertNotNull(retrievedFile);
    assertTrue("The data did not match", Arrays.equals(data, retrievedFile.getContent()));
  }

  public void testStoreUpdateAndReceiveDocument() throws Exception {
    byte[] dataBefore = "Hello, repository".getBytes();
    byte[] dataAfter = "Goodbye, repository".getBytes();
    AttachedFile testFileBefore = new AttachedFile(dataBefore);
    AttachedFile testFileAfter = new AttachedFile(dataAfter);
    long testAttachmentId = 1234;

    DocumentService docService = new DocumentumDocumentService(new TestPOSConnectionFactory());
    String repoId = docService.store(testAttachmentId, testFileBefore);
    deleteTestDocOnTeardown(repoId);
    docService.update(repoId, testFileAfter);

    AttachedFile retrievedFile = docService.retreive(repoId);
    assertNotNull(retrievedFile);
    assertTrue("The data did not match", Arrays.equals(dataAfter, retrievedFile.getContent()));
  }

  public void testStoreAndReceiveWordDocumentWithImage() throws Exception {
    String filename = "com/monsanto/wst/externaltechrequests/document/test/searchIdea.doc";
    byte[] dataBefore = FileUtil.fileToByteArray(filename);
    AttachedFile testFileBefore = new AttachedFile(dataBefore);
    long testAttachmentId = 1234;

    DocumentService docService = new DocumentumDocumentService(new TestPOSConnectionFactory());
    String repoId = docService.store(testAttachmentId, testFileBefore);
    deleteTestDocOnTeardown(repoId);

    AttachedFile retrievedFile = docService.retreive(repoId);
    assertNotNull(retrievedFile);
    assertTrue("The data did not match", Arrays.equals(dataBefore, retrievedFile.getContent()));
  }
}