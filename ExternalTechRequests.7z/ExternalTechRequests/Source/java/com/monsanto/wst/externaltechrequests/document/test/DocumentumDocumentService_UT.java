package com.monsanto.wst.externaltechrequests.document.test;

import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.XMLPOSConnection;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.document.DocumentStorageException;
import com.monsanto.wst.externaltechrequests.document.DocumentumDocumentService;
import com.monsanto.wst.externaltechrequests.document.POSConnectionFactory;
import junit.framework.TestCase;

/*
 DocumentumDocumentService_UT was created on Jan 25, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class DocumentumDocumentService_UT extends TestCase {

  private DocumentumDocumentService docService;

  protected void setUp() throws Exception {
    super.setUp();
    MockPOSConnectionFactory mockFactory = new MockPOSConnectionFactory();
    docService = new DocumentumDocumentService(mockFactory);
  }

  public void testStoreWithNullFileThrowsException() throws Exception {
    try {
      docService.store(1, null);
      fail("Expected exception not received");
    } catch (DocumentStorageException IGNORE) {
      // ignore expected exception
    }
  }

  public void testStoreWithNullDataThrowsException() throws Exception {
    try {
      docService.store(1, new AttachedFile(null));
      fail("Expected exception not received");
    } catch (DocumentStorageException IGNORE) {
      // ignore expected exception
    }
  }

  private class MockPOSConnectionFactory implements POSConnectionFactory {
    public XMLPOSConnection getConnection() throws POSCommunicationException {
      throw new POSCommunicationException("This MOCK is not yet ready for use");
    }

    public void loadSecurityInformationFromHelper(UCCHelper helper) {
    }
  }
}