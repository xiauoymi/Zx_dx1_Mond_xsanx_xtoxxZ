package com.monsanto.wst.externaltechrequests.document.test;

import com.monsanto.wst.externaltechrequests.document.DocumentDeletionException;
import com.monsanto.wst.externaltechrequests.document.DocumentRetrievalException;
import com.monsanto.wst.externaltechrequests.document.DocumentStorageException;
import com.monsanto.wst.externaltechrequests.utils.testutils.TestUtils;
import junit.framework.TestCase;

/*
 Exception_UT was created on Jan 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class Exception_UT extends TestCase {
  public void testExceptionClassesHaveAllConstructors() throws Exception {
    TestUtils.verifyAllConstructorsWorkForException(DocumentDeletionException.class);
    TestUtils.verifyAllConstructorsWorkForException(DocumentStorageException.class);
    TestUtils.verifyAllConstructorsWorkForException(DocumentRetrievalException.class);
  }
}