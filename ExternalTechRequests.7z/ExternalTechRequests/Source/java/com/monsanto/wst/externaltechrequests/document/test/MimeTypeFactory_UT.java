package com.monsanto.wst.externaltechrequests.document.test;

import com.monsanto.wst.externaltechrequests.document.MimeTypeFactory;
import junit.framework.TestCase;

import java.io.File;

/*
 MimeTypeFactory was created on Feb 2, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class MimeTypeFactory_UT extends TestCase {

  public void testTestBasicExtensionsAreCorrectType() throws Exception {
    MimeTypeFactory typeFactory = new MimeTypeFactory();

    assertEquals(MimeTypeFactory.PLAIN_TEXT_MIME_TYPE, typeFactory.getType("test1.txt"));
    assertEquals(MimeTypeFactory.PLAIN_TEXT_MIME_TYPE, typeFactory.getType("c:\\test\\test1.txt"));
    assertEquals(MimeTypeFactory.PLAIN_TEXT_MIME_TYPE, typeFactory.getType(new File("c:\\test\\test1.txt")));
    assertEquals(MimeTypeFactory.WORD_MIME_TYPE, typeFactory.getType("c:\\test\\test1.doc"));
    assertEquals(MimeTypeFactory.WORD_MIME_TYPE, typeFactory.getType("test1.dot"));
    assertEquals(MimeTypeFactory.EXCEL_MIME_TYPE, typeFactory.getType("c:\\test\\test1.xls"));
    assertEquals(MimeTypeFactory.PDF_MIME_TYPE, typeFactory.getType("test1.pdf"));
  }

  public void testUnknownExtensionsReturnsOctetStreamType() throws Exception {
    assertEquals(MimeTypeFactory.UNKNOWN_MIME_TYPE, new MimeTypeFactory().getType("test1.zzx"));
  }

}