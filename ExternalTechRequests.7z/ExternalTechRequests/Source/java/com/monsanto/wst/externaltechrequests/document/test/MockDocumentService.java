package com.monsanto.wst.externaltechrequests.document.test;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.document.DocumentService;

import java.util.HashMap;
import java.util.Map;
/*
 MockDocumentService was created on Jan 24, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MockDocumentService implements DocumentService {
  private final Map attachments;

  public MockDocumentService() {
    this.attachments = new HashMap();
  }

  public String store(long attachmentID, AttachedFile data) {
    String repositoryId = "repo-" + Long.toString(attachmentID);
    attachments.put(repositoryId, data);
    return repositoryId;
  }

  public AttachedFile retreive(String repositoryId) {
    return (AttachedFile) attachments.get(repositoryId);
  }

  public void loadSecurityInfoFromHelper(UCCHelper helper) {
  }

  public void update(String repoId, AttachedFile data) {
    attachments.put(repoId, data);
  }

  public void delete(String repoId) {
  }
}
