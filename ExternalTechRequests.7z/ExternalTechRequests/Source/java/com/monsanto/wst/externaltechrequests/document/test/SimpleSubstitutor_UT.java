package com.monsanto.wst.externaltechrequests.document.test;

import com.monsanto.wst.externaltechrequests.document.SimpleSubstitutor;
import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/*
 SimpleSubstitutor_UT was created on Feb 12, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class SimpleSubstitutor_UT extends TestCase {
  public void testNoSubstitutions() throws Exception {
    byte[] testFile = getTestFile("test1.html");
    SimpleSubstitutor sub = new SimpleSubstitutor();
    byte[] afterFile = sub.substitute(testFile, new HashMap());
    assertTrue(Arrays.equals(testFile, afterFile));
  }

  public void testSubstitutionWorks() throws Exception {
    byte[] testFile = getTestFile("test2.html");
    SimpleSubstitutor sub = new SimpleSubstitutor();
    Map params = new HashMap();
    params.put("name", "world");
    byte[] afterFile = sub.substitute(testFile, params);
    assertTrue(new String(afterFile).indexOf("Hello, world") >= 0);
  }

  public void testMissingParameterThrowsException() throws Exception {
    byte[] testFile = getTestFile("test2.html");
    SimpleSubstitutor sub = new SimpleSubstitutor();
    Map params = new HashMap();
    params.put("no_such_var", "world");
    byte[] afterFile = sub.substitute(testFile, params);
    assertTrue(new String(afterFile).indexOf("Hello, ~~name~~") >= 0);
  }

  private byte[] getTestFile(String filename) throws IOException {
    ByteArrayOutputStream buf = new ByteArrayOutputStream();
    InputStream input = this.getClass().getResourceAsStream(filename);
    int data = input.read();
    while (data != -1) {
      buf.write(data);
      data = input.read();
    }

    input.close();
    return buf.toByteArray();
  }
}