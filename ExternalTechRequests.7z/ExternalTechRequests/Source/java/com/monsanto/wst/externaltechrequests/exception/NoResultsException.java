/*
 NoResultsException was created on Nov 6, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.exception;

/**
 * Filename:    $RCSfile: NoResultsException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $    	 On:	$Date: 2007-01-08 17:25:59 $
 *
 * @author ffbrac
 * @version $Revision: 1.4 $
 */
public class NoResultsException extends Exception  {
	public NoResultsException(String message) {
		super(message);
	}

  public NoResultsException(String message, Throwable cause) {
    super(message, cause);
  }
}