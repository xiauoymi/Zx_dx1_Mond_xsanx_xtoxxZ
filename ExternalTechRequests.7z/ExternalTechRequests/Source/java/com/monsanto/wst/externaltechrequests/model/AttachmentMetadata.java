/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.externaltechrequests.model;

import com.monsanto.wst.externaltechrequests.document.DocumentType;

/**
 * Filename:    $RCSfile: AttachmentMetadata.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author jdpoul
 * @version $Revision: 1.7 $
 */
public class AttachmentMetadata {
  private Long id;
  private String name;
  private String description;
  private DocumentType attachmentType;
  private String repositoryId;
  private Long requestId;
  private String mimeType;
  private String modUser;

  public AttachmentMetadata() {
  }

  public String getMimeType() {
    return mimeType;
  }

  public void setMimeType(String mimeType) {
    this.mimeType = mimeType;
  }

  public Long getRequestId() {
    return requestId;
  }

  public void setAttachmentTypeId(Long attachmentTypeId) {
    if (attachmentTypeId == null) {
      attachmentType = null;
    } else {
      attachmentType = DocumentType.getDocumentType(attachmentTypeId.longValue());
    }
  }

  public DocumentType getAttachmentType() {
    return attachmentType;
  }

  public void setRequestId(Long requestId) {
    this.requestId = requestId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Long getId() {
    return id;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getRepositoryId() {
    return repositoryId;
  }

  public void setRepositoryId(String repositoryId) {
    this.repositoryId = repositoryId;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || !(o instanceof AttachmentMetadata)) {
      return false;
    }

    final AttachmentMetadata that = (AttachmentMetadata) o;

    return !(id != null ? !id.equals(that.id) : that.id != null);

  }

  public int hashCode() {
    return (id == null ? 0 : id.hashCode());
  }

  public String toString() {
    return "[Attachment:" + id + ']';
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public String getModUser() {
    return modUser;
  }
}