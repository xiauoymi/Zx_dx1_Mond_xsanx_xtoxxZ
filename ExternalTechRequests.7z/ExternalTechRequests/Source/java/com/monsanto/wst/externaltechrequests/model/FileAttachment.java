package com.monsanto.wst.externaltechrequests.model;

import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.document.DocumentRetrievalException;

import java.io.*;
/*
 FileAttachment was created on Feb 1, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class FileAttachment implements Attachment {
  private final AttachmentMetadata metadata;
  private final File file;

  public FileAttachment(AttachmentMetadata metadata, File file) {
    this.metadata = metadata;
    this.file = file;
  }

  public AttachmentMetadata getMetadata() {
    return metadata;
  }

  public AttachedFile getAttachedFile() throws DocumentRetrievalException {
    try {
      return new AttachedFile(readFile(file));
    } catch (IOException e) {
      throw new DocumentRetrievalException(e);
    }
  }

  private byte[] readFile(File file) throws IOException {
    ByteArrayOutputStream buf = new ByteArrayOutputStream();
    InputStream input = new BufferedInputStream(new FileInputStream(file));
    int data = input.read();
    while (data != -1) {
      buf.write(data);
      data = input.read();
    }
    return buf.toByteArray();
  }
}
