/*
 ReferenceData was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.model;

import com.monsanto.wst.externaltechrequests.services.LookupReferenceDataService;
import com.monsanto.wst.externaltechrequests.services.LookupReferenceDataServiceImpl;
import com.monsanto.wst.externaltechrequests.dao.LookupReferenceDataDao;

import java.util.Date;

/**
 * Filename:    $RCSfile: ReferenceData.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-03-21 18:29:22 $
 *
 * @author ffbrac
 * @version $Revision: 1.5 $
 */
public class ReferenceData {
  public static final ReferenceData NULL_REFERENCE_DATA = new ReferenceData(new Long(0), "", "N", "", "", new Date()); //todo find usages of this and eliminate them

	private Long id;
	private String data;
	private String active;
	private String description;
	private String modUser;
	private Date modDate;

  public ReferenceData() { //used via reflection
    this(null, null, null, null, null, null);
  }

  public ReferenceData(Long id, String data, String active, String description, String modUser, Date modDate) {
		this.id = id;
		this.data = data;
		this.active = active;
		this.description = description;
		this.modUser = modUser;
		this.modDate = modDate;
	}

  public ReferenceData(Long id, String description) { //todo eliminate uses of this, doesn't populate most fields
    this(id, null, null, description, null, null);
	}

  public ReferenceData(Long id) {
    this(id, null, null, null, null, null);
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setData(String data) {
    this.data = data;
  }
  
  public Long getId() {
		return id;
	}

  public String getData() {
		return data;
	}

  public String getActive() {
		return active;
	}

  public String getDescription() {
		return description;
	}

  public String getModUser() {
		return modUser;
	}

  public Date getModDate() {
		return modDate;
	}

  public String toString() {
    return description;
  }

}