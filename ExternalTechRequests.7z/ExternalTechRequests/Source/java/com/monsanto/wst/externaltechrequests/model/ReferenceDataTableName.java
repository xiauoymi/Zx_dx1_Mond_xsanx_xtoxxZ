package com.monsanto.wst.externaltechrequests.model;
/*
 ReferenceDataTableName was created on Mar 20, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
*/
public class ReferenceDataTableName {
  private String tableName;

  public ReferenceDataTableName(String tableName) {
    this.tableName = tableName;
  }

  public String getTableName() {
    return tableName;
  }
}
