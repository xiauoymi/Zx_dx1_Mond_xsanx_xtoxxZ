package com.monsanto.wst.externaltechrequests.model;

import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.document.DocumentRetrievalException;
import com.monsanto.wst.externaltechrequests.document.DocumentService;
/*
 Attachment was created on Dec 19, 2006 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class RepositoryAttachment implements Attachment {
  private final AttachmentMetadata metadata;
  private final DocumentService docService;

  public RepositoryAttachment(AttachmentMetadata metadata, DocumentService docService) {
    this.metadata = metadata;
    this.docService = docService;
  }

  public AttachmentMetadata getMetadata() {
    return metadata;
  }

  public DocumentService getDocService() {
    return docService;
  }

  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || !(o instanceof Attachment)) {
      return false;
    }

    final RepositoryAttachment that = (RepositoryAttachment) o;
    return metadata.equals(that.metadata);
  }

  public int hashCode() {
    return metadata.hashCode();
  }

  public AttachedFile getAttachedFile() throws DocumentRetrievalException {
    return docService.retreive(metadata.getRepositoryId());
  }
}