/*
 RequestProfile was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.model;

import com.monsanto.wst.commonutils.DataTypeUtil;
import com.monsanto.wst.commonutils.DateFormatException;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.services.LookupReferenceDataService;
import org.apache.commons.lang.StringUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Filename:    $RCSfile: RequestProfile.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date:
 * 2006/12/01 20:20:59 $
 *
 * @author ffbrac
 * @version $Revision: 1.28 $
 */
public class RequestProfile {
  private final SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
  
  //todo need to get rid of these ReferenceData usages and use meaningful classes for each
  private static final String DATE_STRING_FORMAT = "MM/dd/yyyy";
  private Long id;
  private String requestorContactName;
  private String requestorTitle;
  private String sponsor;
  private RegionReferenceData region;
  private StatusReferenceData status;
  private String statusComments;
  private StudyReferenceData studyLength;
  private RequestTypeReferenceData requestType;
  private ApprovalReferenceData committeeApproved;
  private String committeeApprovedComments;
  private Date committeeApprovalDate;
  private Date requestDate;
  private Date neededDate;
  private String fcpaFlag;
  private String affiliation;
  private String purpose;
  private Date modDate;
  private String modUser;
  private AddressInfo shipToAddress;
  private AddressInfo researchAddress;
  private List requestResearchEntries = new ArrayList();
  private final DataTypeUtil util = new DataTypeUtil();
  private final List attachments = new ArrayList();
  private String requestNumber;
  private RequestURLGenerator urlGenerator;

  public RequestProfile() {
    setId(null);
  }

  public RequestProfile(Long id) {
    setId(id);
  }

  public Long getId() {
    return id;
  }

  public List getRequestResearchEntries() {
    return requestResearchEntries;
  }

  public Date getCommitteeApprovalDate() {
    return committeeApprovalDate;
  }

  public void setCommitteeApprovalDate(Date committeeApprovalDate) {
    this.committeeApprovalDate = committeeApprovalDate;
  }

  public void setRequestResearchEntries(List requestResearchEntries) {
    //todo this should be happening from the dbtemplate.xml, but it apparently isn't setup that way, this should be corrected
    this.requestResearchEntries = requestResearchEntries;
  }

  public void addRequestResearchEntry(RequestResearchType requestResearchType) {
    this.requestResearchEntries.add(requestResearchType);
  }

  public void setId(Long id) {
    this.id = id;
    urlGenerator = new RequestURLGenerator(id);
  }

  public String getStatusComments() {
    return statusComments;
  }

  public void setStatusComments(String statusComments) {
    this.statusComments = statusComments;
  }

  public String getCommitteeApprovedComments() {
    return committeeApprovedComments;
  }

  public void setCommitteeApprovedComments(String committeeApprovedComments) {
    this.committeeApprovedComments = committeeApprovedComments;
  }

  public String getRequestNumber() {
    return requestNumber;

  }

  public String getRequestorContactName() {
    return requestorContactName;
  }

  public void setRequestorContactName(String requestorContactName) {
    this.requestorContactName = requestorContactName;
  }

  public String getRequestorTitle() {
    return requestorTitle;
  }

  public void setRequestorTitle(String requestorTitle) {
    this.requestorTitle = requestorTitle;
  }

  public String getSponsor() {
    return sponsor;
  }

  public void setSponsor(String sponsor) {
    this.sponsor = sponsor;
  }

  public RegionReferenceData getRegion() {
    return region;
  }

  public void setRegion(RegionReferenceData region) {
    this.region = region;
  }

  public StatusReferenceData getStatus() {
    return status;
  }

  public void setStatus(StatusReferenceData status) {
    this.status = status;
  }

  public StudyReferenceData getStudyLength() {
    return studyLength;
  }

  public void setStudyLength(StudyReferenceData studyLength) {
    this.studyLength = studyLength;
  }

  public RequestTypeReferenceData getRequestType() {
    return requestType;
  }

  public void setRequestType(RequestTypeReferenceData requestType) {
    this.requestType = requestType;
  }

  public ApprovalReferenceData getCommitteeApproved() {
    return committeeApproved;
  }

  public void setCommitteeApproved(ApprovalReferenceData committeeApproved) {
    this.committeeApproved = committeeApproved;
  }

  public String getRequestDateToString() {
    return (requestDate == null) ? "" : formatter.format(requestDate);
  }

  public String getApprovalDateToString() {
    return (committeeApprovalDate == null) ? "" : formatter.format(committeeApprovalDate);
  }

  public void setRequestDate(Date requestDate) {
    this.requestDate = requestDate;
  }

  public void setRequestDateAsString(String requestDate) {
    this.requestDate = buildDateFromString(requestDate);
  }

  public String getNeededDateToString() {
    if (neededDate != null) {
      SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
      return formatter.format(neededDate);
    }
    return "";
  }

  public Date getNeededDate() {
    return neededDate;
  }

  public Date getRequestDate() {
    return requestDate;
  }

  public void setNeededDate(Date neededDate) {
    this.neededDate = neededDate;
  }

  public void setNeededDateAsString(String neededDate) {
    this.neededDate = buildDateFromString(neededDate);
  }

  public String getFcpaFlag() {
    return fcpaFlag;
  }

  public void setFcpaFlag(String fcpaFlag) {
    this.fcpaFlag = fcpaFlag;
  }

  public String getAffiliation() {
    return affiliation;
  }

  public void setAffiliation(String affiliation) {
    this.affiliation = affiliation;
  }

  public String getPurpose() {
    return purpose;
  }

  public void setPurpose(String purpose) {
    this.purpose = purpose;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public AddressInfo getShipToAddress() {
    return shipToAddress;
  }

  public void setShipToAddress(AddressInfo shipToAddress) {
    this.shipToAddress = shipToAddress;
  }

  public AddressInfo getResearchAddress() {
    return researchAddress;
  }

  public void setResearchAddress(AddressInfo researchAddress) {
    this.researchAddress = researchAddress;
  }


  private Date buildDateFromString(String dateString) {

    try {
      return util.convertStringToDate(dateString, DATE_STRING_FORMAT);
    } catch (DateFormatException e) {
      return null;
    }
  }

  public AttachmentMetadata[] getAttachments() {
    return (AttachmentMetadata[]) attachments.toArray(new AttachmentMetadata[attachments.size()]);
  }

  public void addAttachment(AttachmentMetadata attachmentMetadata) {
    attachments.add(attachmentMetadata);
  }


  public boolean hasBeenSaved() {
    return getId() != null;
  }

  public void setRequestNumber(String requestNumber) {
    this.requestNumber = requestNumber;
  }

  public String getLegalUrl() {
    return urlGenerator.getLegalUrl();
  }

  public String getShippingUrl() {
    return urlGenerator.getShippingUrl();
  }

  public String getUrl() {
    return urlGenerator.getUrl();
  }

  public String getEntity() {
    return (StringUtils.isEmpty(affiliation)) ? requestorContactName : affiliation;
  }
}