/*
 RequestResearchType was created on Nov 14, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.model;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Filename:    $RCSfile: RequestResearchType.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-31 19:15:02 $
 *
 * @author ffbrac
 * @version $Revision: 1.7 $
 */
public class RequestResearchType { //todo this class is used for multiple purposes, this name isn't appropriate and should be changed
	private Long id;
	private Long requestId;
	private Long researchTypeId;
	private String researchTypeName;
	private String description;
	private Date modDate;
	private String modUser;

	public RequestResearchType() {
	}

	public RequestResearchType(Long id) {
		this.id = id;
	}

	public String getResearchTypeName() {
		return researchTypeName;
	}

	public void setResearchTypeName(String researchTypeName) {
		this.researchTypeName = researchTypeName;
	}

	public RequestResearchType(Long id, Long requestId, Long researchTypeId, String description, String modUser, Date modDate) {
		this.id = id;
		this.requestId = requestId;
		this.researchTypeId = researchTypeId;
		this.modUser = modUser;
		this.modDate = modDate;
		this.description = description;
	}

	public RequestResearchType(Long id, Long requestId, Long researchTypeId, String researchTypeName, String description,
	                           Date modDate, String modUser) {
		this.id = id;
		this.requestId = requestId;
		this.researchTypeId = researchTypeId;
		this.researchTypeName = researchTypeName;
		this.description = description;
		this.modDate = modDate;
		this.modUser = modUser;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public Long getResearchTypeId() {
		return researchTypeId;
	}

	public void setResearchTypeId(Long researchTypeId) {
		this.researchTypeId = researchTypeId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getModDate() {
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		return format.format(modDate);
	}

	public void setModDate(Date modDate) {
		this.modDate = modDate;
	}

	public String getModUser() {
		return modUser;
	}

	public void setModUser(String modUser) {
		this.modUser = modUser;
	}
}