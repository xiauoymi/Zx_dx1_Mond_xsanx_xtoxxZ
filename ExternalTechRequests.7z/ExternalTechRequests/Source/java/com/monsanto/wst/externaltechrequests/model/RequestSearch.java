/*
 RequestSearch was created on Nov 15, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.model;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Filename:    $RCSfile: RequestSearch.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-02-28 21:36:38 $
 *
 * @author ffbrac
 * @version $Revision: 1.9 $
 */
public class RequestSearch {
	private final String requestGenNumber;
  private final String contactName;
  private final String sponsor;
	private final Long regionId;
	private final Long requestTypeId;
	private final Long statusId;
	private final String startDate;
	private final String endDate;
	private final String committStartDate;
	private final String committEndDate;
	private final String description;
	private final String affiliation;
  private final String purpose;

  public RequestSearch() {
    this(null, null, null, null, null, null, null, null, null, null, null, null, null);
  }

  public RequestSearch(String requestNumber, String requestorName, String sponsor, Long region, Long requestType,
                       Long status, String description, String affiliation, String purpose, String startDate,
                       String endDate, String committeeStartDate, String committeeEndDate) {

    this.requestGenNumber = requestNumber;
    this.contactName = requestorName;
    this.sponsor = sponsor;
    this.regionId = region;
    this.requestTypeId = requestType;
    this.statusId = status;
    this.description = description;
    this.affiliation = affiliation;
    this.purpose = purpose;
    this.startDate = startDate;
    this.endDate = endDate;
    this.committStartDate = committeeStartDate;
    this.committEndDate = committeeEndDate;
  }

  public RequestSearch(Long statusId) {
    this(null, null, null, null, null, statusId, null, null, null, null, null, null, null);
  }

  public Long getRegionId() {
		return regionId;
	}

	public String getAffiliation() {
		return affiliation;
	}

  public String getCommittStartDate() {
		return committStartDate;
	}

  public String getCommittEndDate() {
		return committEndDate;
	}

  public Long getRequestTypeId() {
		return requestTypeId;
	}

  public Long getStatusId() {
		return statusId;
	}

  public String getStartDate() {
		return startDate;
	}

  public String getEndDate() {
		return endDate;
	}

  public String getRequestGenNumber() {
		return requestGenNumber;
	}

  public String getContactName() {
		return contactName;
	}

  public String getSponsor() {
		return sponsor;
	}

  public String getDescription() {
		return description;
	}

  public String getPurpose() {
    if (purpose == null) {
      return null;
    } else {
      return purpose.trim();
    }
  }

}