package com.monsanto.wst.externaltechrequests.model;
/*
 RequestURLGenerator was created on Feb 20, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class RequestURLGenerator {
  private static String baseURL = "";
  private final Long id;

  public static void setBaseURL(String url) {
    // I don't particularly care for this, but its better than shoving the URL property logic all the way into the RequestProfile object
    // Since RequestProfile is usually created by the DBTemplate framework anyway, this would be difficult
    baseURL = url;
  }

  public RequestURLGenerator(Long id) {
    this.id = id;
  }

  public String getLegalUrl() {
    return baseURL + "legal.html?method=attachTemplate&requestId=" + id;
  }

  public String getShippingUrl() {
    return baseURL + "shipping.html?method=attachTemplate&requestId=" + id;
  }

  public String getUrl() {
    return baseURL + "new_request.html?method=editRequestEntry&requestId=" + id;
  }
}
