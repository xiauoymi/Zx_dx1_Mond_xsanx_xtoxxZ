package com.monsanto.wst.externaltechrequests.model;
/*
 StudyReferenceData was created on Mar 20, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
*/
public class StudyReferenceData extends ReferenceData {
  public StudyReferenceData() {
  }

  public StudyReferenceData(Long id, String description) {
    super(id, description);
  }
}
