/*
 AddressInfo_UT was created on Nov 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.model.test;

import com.monsanto.wst.externaltechrequests.model.AddressInfo;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AddressInfo_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-02-26 19:25:47 $
 *
 * @author ffbrac
 * @version $Revision: 1.7 $
 */
public class AddressInfo_UT extends TestCase {
	public void testCreate() throws Exception {
		AddressInfo address = new AddressInfo();
		assertNotNull(address);
		address = new AddressInfo(new Long("100"));
		assertNotNull(address);
	}
  
  public void testTestGettersAndSetters() throws Exception {
		AddressInfo address = new AddressInfo();
	  	address.setCity("Test");
	  	address.setId(new Long("111"));
	  	address.setState("MO");
	  	address.setStreetOne("Test Street 1");
	  	address.setStreetTwo("Test Street 2");
		address.setZipCode("12345");
		address.setCountry("USA");
		address.setPhone("123");
    address.setFax("456");
    address.setEmail("me@here.com");

		assertEquals(new Long("111"), address.getId());
		assertEquals("Test", address.getCity());
		assertEquals("MO", address.getState());
		assertEquals("Test Street 1", address.getStreetOne());
		assertEquals("Test Street 2", address.getStreetTwo());
		assertEquals("12345", address.getZipCode());
    assertEquals("USA", address.getCountry());
    assertEquals("123", address.getPhone());
		assertEquals("456", address.getFax());
		assertEquals("me@here.com", address.getEmail());
	}

  public void testToString() throws Exception {
    String testStreet1 = "Test Street 1";
    String testStreet2 = "Test Street 2";
    String testCity = "Test";
    String testState = "MO";
    String testZip = "12345";

    AddressInfo fullAddress = new AddressInfo();
    fullAddress.setCity(testCity);
      fullAddress.setId(new Long("111"));
    fullAddress.setState(testState);
    fullAddress.setStreetOne(testStreet1);
    fullAddress.setStreetTwo(testStreet2);
    fullAddress.setZipCode(testZip);
    fullAddress.setCountry("USA");
    fullAddress.setPhone("123");
    fullAddress.setFax("456");
    fullAddress.setEmail("me@here.com");
    assertEquals(testStreet1 + '\n' + testStreet2 + '\n' + testCity + ", " + testState + ' ' + testZip,
        fullAddress.toString());

    AddressInfo paritalAddress = new AddressInfo();
      paritalAddress.setCity(testCity);
      paritalAddress.setId(new Long("111"));
      paritalAddress.setState(testState);
      paritalAddress.setStreetOne(testStreet1);
    paritalAddress.setZipCode("12345");
    assertEquals(testStreet1 + '\n' + testCity + ", " + testState + ' ' + testZip,
        paritalAddress.toString());

    AddressInfo hardlyAnyAddress = new AddressInfo();
      hardlyAnyAddress.setId(new Long("111"));
      hardlyAnyAddress.setStreetOne(testStreet1);
    assertEquals(testStreet1 + '\n',
        hardlyAnyAddress.toString());
  }

}