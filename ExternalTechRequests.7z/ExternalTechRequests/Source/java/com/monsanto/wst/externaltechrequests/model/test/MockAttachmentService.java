package com.monsanto.wst.externaltechrequests.model.test;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.document.AttachmentCollection;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;

import java.util.*;
/*
 MockAttachmentService was created on Jan 24, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MockAttachmentService implements AttachmentService {
  private final Map allAttachments;
  private final Map attachments;
  private final Map templates;
  private final Set readIds;
  private final Set updatedIds;
  private final Set deletedIds;
  private boolean addCalled = false;

  public MockAttachmentService() {
    this.allAttachments = new HashMap();
    this.attachments = new HashMap();
    this.templates = new HashMap();
    this.readIds = new HashSet();
    this.updatedIds = new HashSet();
    this.deletedIds = new HashSet();
  }

  public AttachmentCollection getAttachments(Long requestId, User user) {
    List results = (List) attachments.get(requestId);
    if (results == null) {
      return new AttachmentCollection(new ArrayList(), user);
    } else {
      return new AttachmentCollection(results, user);
    }
  }

  public void addAttachment(Attachment attachment, String modUser) {
    addCalled = true;
    allAttachments.put(attachment.getMetadata().getId(), attachment);
    Long requestId = attachment.getMetadata().getRequestId();
    List curr = (List) attachments.get(requestId);
    if (curr == null) {
      curr = new ArrayList();
    }
    curr.add(attachment);
    attachments.put(requestId, curr);
  }

  public boolean wasAddCalled() {
    return addCalled;
  }

  public void updateAttachment(Attachment attachment, String modUser) {
    addAttachment(attachment, modUser);
    updatedIds.add(attachment.getMetadata().getId());
  }

  public List getTemplates(DocumentType templateType) {
    List results = (List) templates.get(templateType);
    if (results == null) {
      return new ArrayList();
    } else {
      return results;
    }
  }

  public void addTemplate(Attachment attachment, String modUser) {
    DocumentType templateType = attachment.getMetadata().getAttachmentType();
    List curr = getTemplates(templateType);
    curr.add(attachment);
    templates.put(templateType, curr);
  }

  public void deleteAttachment(Attachment attachment) {
    deletedIds.add(attachment.getMetadata().getId());
  }

  public void loadSecurityInfoFromHelper(UCCHelper helper) {
  }

  public Attachment getAttachment(Long attachmentId) {
    readIds.add(attachmentId);
    return (Attachment) allAttachments.get(attachmentId);
  }

  public boolean wasRead(Long id) {
    return readIds.contains(id);
  }

  public void clearRead() {
    readIds.clear();
  }

  public boolean wasUpdated(Long id) {
    return updatedIds.contains(id);
  }

  public boolean wasDeleted(Long id) {
    return deletedIds.contains(id);
  }
}
