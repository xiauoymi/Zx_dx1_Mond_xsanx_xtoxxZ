/*
 ReferenceData_UT was created on Nov 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.model.test;

import com.monsanto.wst.externaltechrequests.model.ReferenceData;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Filename:    $RCSfile: ReferenceData_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-03-21 18:29:24 $
 *
 * @author ffbrac
 * @version $Revision: 1.5 $
 */
public class ReferenceData_UT extends TestCase {
	public void testCreate() throws Exception {
		ReferenceData data = ReferenceData.NULL_REFERENCE_DATA;
		assertNotNull(data);
	}

	public void testGetters() throws Exception {
    Long testId = new Long(1000L);
    String testData = "data";
    String testActive = "Y";
    String testDescription = "test description";
    String testModUser = "FFBRAC";
    Date testDate = new Date();

    ReferenceData data = new ReferenceData(testId, testData, testActive, testDescription, testModUser, testDate);

    assertEquals(testId, data.getId());
    assertEquals(testData, data.getData());
		assertEquals(testActive, data.getActive());
		assertEquals(testDescription, data.getDescription());
		assertEquals(testModUser, data.getModUser());
    assertEquals(testDate, data.getModDate());
	}
}