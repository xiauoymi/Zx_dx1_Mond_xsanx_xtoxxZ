/*
 RequestProfile_UT was created on Nov 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.model.test;

import com.monsanto.wst.externaltechrequests.dao.test.TestMetadata;
import com.monsanto.wst.externaltechrequests.model.ReferenceData;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.ApprovalReferenceData;
import com.monsanto.wst.externaltechrequests.model.RegionReferenceData;
import junit.framework.TestCase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Filename:    $RCSfile: RequestProfile_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date:
 * 2006/12/01 18:36:10 $
 *
 * @author ffbrac
 * @version $Revision: 1.19 $
 */
public class RequestProfile_UT extends TestCase {
  public void testCreate() throws Exception {
    RequestProfile request = new RequestProfile();
    assertNotNull(request);
  }

  public void testSettersAndGetters() throws Exception {
    RequestProfile request = new RequestProfile();
    request.setAffiliation("Affil");
    request.setCommitteeApproved(new ApprovalReferenceData(new Long("100"), "test"));
    request.setFcpaFlag("Y");
    request.setId(new Long("1000"));
    request.setModDate(new Date());
    request.setModUser("ffbrac");
    request.setNeededDate(new Date());
    request.setRequestDate(new Date());
    request.setPurpose("purpose");
    request.setRegion(new RegionReferenceData(new Long("100"), "test"));
    request.setRequestorContactName("Filip");
    request.setRequestorTitle("Filip");

    assertEquals("Affil", request.getAffiliation());
    assertEquals(new Long("100"), request.getCommitteeApproved().getId());
    assertEquals("Y", request.getFcpaFlag());
    assertEquals("ffbrac", request.getModUser());

  }

  public void testSetRequestDateAsStringConvertedProperlyValidInput() throws Exception {
    Calendar calendar = new GregorianCalendar(2006, 11, 22);
    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
    formatter.setCalendar(Calendar.getInstance());
    String stringDate = formatter.format(calendar.getTime());
    RequestProfile profile = new RequestProfile();
    profile.setRequestDateAsString(stringDate);

    assertEquals(calendar.getTime(), profile.getRequestDate());
  }


  public void testSetNeededDateAsStringConvertedProperlyValidInput() throws Exception {
    Calendar calendar = new GregorianCalendar(2006, 11, 22);
    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
    formatter.setCalendar(Calendar.getInstance());
    String stringDate = formatter.format(calendar.getTime());
    RequestProfile profile = new RequestProfile();
    profile.setNeededDateAsString(stringDate);

    assertEquals(calendar.getTime(), profile.getNeededDate());
  }

  public void testSetRequestDateAsStringPassingNull() throws Exception {
    RequestProfile profile = new RequestProfile();
    profile.setRequestDateAsString(null);
    assertEquals(null, profile.getRequestDate());
  }


  public void testSetNeededDateAsStringPassingNull() throws Exception {
    RequestProfile profile = new RequestProfile();
    profile.setNeededDateAsString(null);
    assertEquals(null, profile.getNeededDate());
  }


  public void testGetLegalAttachmentsValidateName() throws Exception {
    RequestProfile profile = new RequestProfile();
    profile.addAttachment(new TestMetadata(1, "testAttach1Name"));
    assertNotNull(profile.getAttachments());
    assertEquals(1, profile.getAttachments().length);
    assertEquals("testAttach1Name", profile.getAttachments()[0].getName());
  }

  public void testGetLegalAttachmentsEmptyIfNoneSet() throws Exception {
    RequestProfile profile = new RequestProfile();
    assertNotNull(profile.getAttachments());
    assertEquals(0, profile.getAttachments().length);
  }

  public void testGetLegalAttachmentsOrderCorrectValidateNameForTwoAttachmentsAdded() throws Exception {
    RequestProfile profile = new RequestProfile();
    profile.addAttachment(new TestMetadata(1, "testAttach1Name"));
    profile.addAttachment(new TestMetadata(2, "testAttach2Name"));
    assertNotNull(profile.getAttachments());
    assertEquals(2, profile.getAttachments().length);
    assertEquals("testAttach1Name", profile.getAttachments()[0].getName());
    assertEquals("testAttach2Name", profile.getAttachments()[1].getName());
  }


  public void testGeneratedRequestNumberIsConcatenatedCorrectly_ValidYearAndReqNum() throws Exception {
    RequestProfile profile = new RequestProfile();
    profile.setRequestNumber("SRWG-2007-0001");
    assertEquals("SRWG-2007-0001", profile.getRequestNumber());
  }

  public void testAlreadyExists_IdSetOnProfile_ValidateTrue() throws Exception {
    RequestProfile profile = new RequestProfile();
    profile.setId(new Long(1));
    assertTrue(profile.hasBeenSaved());
  }
  
  public void testAlreadyExists_NoIdSetOnProfile_ValidateFalse() throws Exception {
    RequestProfile profile = new RequestProfile();
    assertFalse(profile.hasBeenSaved());
  }
}