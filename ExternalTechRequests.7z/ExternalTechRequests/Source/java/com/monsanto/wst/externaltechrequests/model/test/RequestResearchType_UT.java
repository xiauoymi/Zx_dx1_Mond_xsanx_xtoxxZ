/*
 RequestResearchType_UT was created on Nov 14, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.model.test;

import com.monsanto.wst.externaltechrequests.model.RequestResearchType;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Filename:    $RCSfile: RequestResearchType_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ffbrac $    	 On:	$Date: 2006-11-28 15:22:26 $
 *
 * @author ffbrac
 * @version $Revision: 1.3 $
 */
public class RequestResearchType_UT extends TestCase {
	public void testCreate() throws Exception {
		RequestResearchType requestResearch = new RequestResearchType();
		assertNotNull(requestResearch);
	}
	public void testSetterAndGetters() throws Exception {
		RequestResearchType requestResearch = new RequestResearchType();
		requestResearch.setModUser("FFBRAC");
		requestResearch.setModDate(new Date(0));
		requestResearch.setId(new Long("100"));
		requestResearch.setDescription("test");
		requestResearch.setRequestId(new Long("100"));
		requestResearch.setResearchTypeId(new Long("100"));

		assertEquals("FFBRAC", requestResearch.getModUser());
		assertEquals("test", requestResearch.getDescription());
		assertEquals(new Long("100"), requestResearch.getId());
		assertEquals(new Long("100"), requestResearch.getRequestId());
		assertEquals(new Long("100"), requestResearch.getResearchTypeId());
		assertNotNull(requestResearch.getModDate());
	}
}