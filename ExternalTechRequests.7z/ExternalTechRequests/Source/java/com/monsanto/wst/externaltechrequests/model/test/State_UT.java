package com.monsanto.wst.externaltechrequests.model.test;

import com.monsanto.wst.externaltechrequests.model.State;
import junit.framework.TestCase;

/*
 State_UT was created on Jan 29, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class State_UT extends TestCase {
  public void testGetSetState() throws Exception {
    String testAbbr = "MO";
    String testName = "Missouri";
    State st = new State();
    st.setId(testAbbr);
    st.setName(testName);
    assertEquals(testAbbr, st.getId());
    assertEquals(testName, st.getName());
  }
}