package com.monsanto.wst.externaltechrequests.security;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/*
 NullUser was created on Dec 20, 2006 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class NullUser implements User {
  public static final String NULL_USER_ID = "Unknown User";

  public boolean hasPrivilege(Privilege priv) {
    return false;
  }

  public String getUserId() {
    return NULL_USER_ID;
  }

  public String getEmail() {
    return null;
  }

  public boolean canView(RequestProfile request) {
    return false;
  }

  public boolean canEdit(RequestProfile request) {
    return false;
  }

  public Map getPrivileges() {
    return new HashMap();
  }

  public String getFullName() {
    return getUserId();
  }

  public List getRoles() {
    return new ArrayList();
  }
}
