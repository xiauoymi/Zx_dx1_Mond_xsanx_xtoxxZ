package com.monsanto.wst.externaltechrequests.security;
/*
 Privilegex was created on Dec 19, 2006 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class Privilege {
  public static final Privilege ADMIN_REFDATA = new Privilege("AdminReferenceData",
      "Ability to administer reference data");
  public static final Privilege ADMIN_SECURITY = new Privilege("AdminSecurity", "Ability to administer users");
  public static final Privilege CREATE_LEGAL = new Privilege("CreateLegalTemplate",
      "Ability to create new legal templates");
  public static final Privilege ATTACH_LEGAL = new Privilege("AttachLegalTemplate",
      "Ability to assign a legal template to a request");
  public static final Privilege CREATE_SHIPPING = new Privilege("CreateShippingTemplate",
      "Ability to create a new shipping template to a request");
  public static final Privilege ATTACH_SHIPPING = new Privilege("AttachShippingTemplate",
      "Ability to attach shipping information to a request");
  public static final Privilege VIEW_ALL = new Privilege("ViewAllRequests", "Ability to view any request");
  public static final Privilege EDIT_OWN = new Privilege("EditOwnRequests",
      "Ability to view/edit requests assigned to themselves");
  public static final Privilege CREATE_OWN = new Privilege("CreateOwnRequest",
      "Ability to create a new request, assigned to oneself");
  public static final Privilege CREATE_ANY = new Privilege("CreateRequest",
      "Ability to create a new request, assigned to self, or others");
  public static final Privilege REVIEW = new Privilege("Review", "Ability to review, approve or reject new requests");
  public static final Privilege ADMIN_STATUS = new Privilege("AdminStatus",
      "Ability to review, approve or reject new requests");
  public static final Privilege DELETE_ATTACHMENT = new Privilege("DeleteAttachment",
      "Ability to delete attachments from the system");

  private final String code;
  private final String description;

  protected Privilege(String code, String description) {
    this.code = code;
    this.description = description;
  }

  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || !(o instanceof Privilege)) {
      return false;
    }

    final Privilege privilege = (Privilege) o;

    return code.equals(privilege.code);

  }

  public int hashCode() {
    return code.hashCode();
  }

  public String toString() {
    return getPrivCode();
  }

  public String getPrivCode() {
    return code;
  }

  public String getDescription() {
    return description;
  }
}
