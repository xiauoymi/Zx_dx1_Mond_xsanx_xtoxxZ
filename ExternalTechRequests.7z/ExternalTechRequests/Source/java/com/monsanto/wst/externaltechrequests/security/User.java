package com.monsanto.wst.externaltechrequests.security;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;

import java.util.List;
import java.util.Map;

/*
 User was created on Dec 19, 2006 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public interface User {
  boolean hasPrivilege(Privilege priv);
  Map getPrivileges();
  String getFullName();
  List getRoles();
  String getUserId();
  String getEmail();
  boolean canView(RequestProfile request);
  boolean canEdit(RequestProfile request);
}
