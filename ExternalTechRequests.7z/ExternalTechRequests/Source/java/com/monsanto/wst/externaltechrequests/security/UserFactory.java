package com.monsanto.wst.externaltechrequests.security;

import java.util.List;
/*
 UserFactory was created on Dec 20, 2006 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public interface UserFactory {
  User getUser(String userid);
  List getAllUsers();
  List getAllSponsors();  
  void addUser(String userId, String fullName, String email, String[] roles, String modUser);
  void updateUser(String userId, String fullName, String email, String[] roles, String modUser);
  void deactivateUser(String userId, String modUser);
  void reactivateUser(String userId, String modUser);
  List getAllRoles();
}
