package com.monsanto.wst.externaltechrequests.security.dbsecurity;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.dao.DBTemplateNoResultsException;
import com.monsanto.wst.externaltechrequests.dao.LookupDao;
import com.monsanto.wst.externaltechrequests.dao.dbtemplate.DBTemplateLookupDao;
import com.monsanto.wst.externaltechrequests.security.NullUser;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.security.UserFactory;

import java.util.ArrayList;
import java.util.List;
/*
 DBUserFactory was created on Dec 20, 2006 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class DBUserFactory implements UserFactory {
  private final DBTemplate template;
  public static final String USERLOOKUP_QUERY_NAME = "lookupUserByUserID";
  public static final String ADD_USER_QUERY_NAME = "addUser";
  public static final String UPDATE_USER_QUERY_NAME = "updateUser";
  public static final String DEACTIVATE_USER_QUERY_NAME = "deactivateUser";
  public static final String REACTIVATE_USER_QUERY_NAME = "reactivateUser";
  public static final String DELETE_ROLES_QUERY_NAME = "deleteRoles";
  public static final String ADD_ROLE_QUERY_NAME = "addRole";

  public DBUserFactory(DBTemplate template) {
    this.template = template;
  }

  public List lookupUserPrivs(String userId) {
    String PRIVLOOKUP_QUERY_NAME = "lookupPrivForUser";
    List privList = template.executeListResultQuery(PRIVLOOKUP_QUERY_NAME, userId);
    if (privList == null) {
      return new ArrayList();
    } else {
      return privList;
    }
  }

  public User getUser(String userId) {
    try {
      DBUser user = (DBUser) template.executeSingleResultQuery(USERLOOKUP_QUERY_NAME, userId);
      if (user == null) {
        return new NullUser();
      } else {
        return wrapDBUser(user);
      }
    } catch (DBTemplateNoResultsException e) {
      return new NullUser();
    }
  }

  public List getAllUsers() {
    List userList = template.executeListResultQuery("lookupAllUsers");
    List returnList = new ArrayList(userList.size());
    for (int i = 0; i < userList.size(); i++) {
      DBUser dbUser = (DBUser) userList.get(i);
      returnList.add(wrapDBUser(dbUser));
    }

    return returnList;
  }

  public List getAllSponsors() {
    List userList = template.executeListResultQuery("lookupAllSponsors");
    List returnList = new ArrayList(userList.size());
    for (int i = 0; i < userList.size(); i++) {
      DBUser dbUser = (DBUser) userList.get(i);
      returnList.add(wrapDBUser(dbUser));
    }

    return returnList;
  }

  public void addUser(String userId, String fullName, String email, String[] roles, String modUser) {
    DMLTempUser user = new DMLTempUser(userId, fullName, email, modUser);
    template.executeInsert(ADD_USER_QUERY_NAME, user);
    setRoles(userId, roles);
  }

  private void setRoles(String userId, String[] roles) {
    TempDMLRole user = new TempDMLRole(userId, null);
    template.executeDelete(DELETE_ROLES_QUERY_NAME, user);
    if (roles != null) {
      for (int i = 0; i < roles.length; i++) {
        TempDMLRole role = new TempDMLRole(userId, roles[i]);
        template.executeInsert(ADD_ROLE_QUERY_NAME, role);
      }
    }
  }

  public void updateUser(String userId, String fullName, String email, String[] roles, String modUser) {
    DMLTempUser user = new DMLTempUser(userId, fullName, email, modUser);
    template.executeUpdate(UPDATE_USER_QUERY_NAME, user);
    setRoles(userId, roles);
  }

  public void deactivateUser(String userId, String modUser) {
    DMLTempUser user = new DMLTempUser(userId, "", "", modUser);
    template.executeUpdate(DEACTIVATE_USER_QUERY_NAME, user);
  }

  public void reactivateUser(String userId, String modUser) {
    DMLTempUser user = new DMLTempUser(userId, "", "", modUser);
    template.executeUpdate(REACTIVATE_USER_QUERY_NAME, user);
  }

  public List getAllRoles() {
    return template.executeListResultQuery("lookupAllRoles");
  }

  private User wrapDBUser(DBUser dbUser) {
    LookupDao lookupDao = new DBTemplateLookupDao(template);
    String username = dbUser.getUserName();
    List roles = lookupDao.lookupRolesForUserId(username);
    List privs = lookupDao.lookupUserPrivs(username);
    return new UserImpl(dbUser, privs, roles);
  }

  public static class DMLTempUser {
    private String userId;
    private String fullName;
    private String email;
    private String modUser;

    public DMLTempUser(String userId, String fullName, String email, String modUser) {
      this.userId = userId;
      this.fullName = fullName;
      this.email = email;
      this.modUser = modUser;
    }

    public String getUserId() {
      return userId;
    }

    public void setUserId(String userId) {
      this.userId = userId;
    }

    public String getModUser() {
      return modUser;
    }

    public void setModUser(String modUser) {
      this.modUser = modUser;
    }

    public String getFullName() {
      return fullName;
    }

    public void setFullName(String fullName) {
      this.fullName = fullName;
    }

    public String getEmail() {
      return email;
    }

    public void setEmail(String email) {
      this.email = email;
    }
  }

  public static class TempDMLRole {
    private final String userId;
    private final String roleName;

    public TempDMLRole(String userId, String roleName) {
      this.userId = userId;
      this.roleName = roleName;
    }

    public String getUserId() {
      return userId;
    }

    public String getRoleName() {
      return roleName;
    }

    public String toString() {
      return "[UserId=" + userId + ",Role=" + roleName + ']';
    }
  }

}
