package com.monsanto.wst.externaltechrequests.security.dbsecurity;
/*
 Role was created on Jan 17, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class Role {
  private String id;
  private String name;
  private String active;

  private static final String FALSE_STRING = "false";
  private static final String TRUE_STRING = "true";

  public Role() {
    setActive(false);
  }

  public Role(String id, String name) {
    this.id = id;
    this.name = name;
    setActive(false);
  }

  public String getActive() {
    return active;
  }

  public void setActive(String active) {
    this.active = active;
  }

  public void setActive(boolean active) {
    if (active) {
      setActive(TRUE_STRING);
    } else {
      setActive(FALSE_STRING);
    }
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}
