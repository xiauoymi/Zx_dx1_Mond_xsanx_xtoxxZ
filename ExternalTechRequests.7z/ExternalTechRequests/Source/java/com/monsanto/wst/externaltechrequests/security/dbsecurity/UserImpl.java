package com.monsanto.wst.externaltechrequests.security.dbsecurity;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.User;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/*
 UserImpl was created on Jan 9, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class UserImpl implements User {
  private final DBUser user;
  private final List privs;
  private final List roles;

  private final Privilege[] VIEW_PRIVS = {Privilege.CREATE_ANY, Privilege.VIEW_ALL};

  public UserImpl(DBUser user, List privs, List roles) {
    this.user = user;
    this.privs = privs;
    this.roles = roles;
  }

  public String getUserId() {
    return user.getUserName();
  }

  public String getFullName() {
    return user.getName();
  }

  public String getEmail() {
    return user.getEmail();
  }

  public boolean canView(RequestProfile request) {
    if (StringUtils.equalsIgnoreCase(request.getSponsor(), user.getUserName())) {
      return true; // since anyone should be able to view a request assigned to them
    } else {
      return hasPrivilege(VIEW_PRIVS);
    }
  }

  public boolean canEdit(RequestProfile request) {
    if (hasPrivilege(Privilege.EDIT_OWN) && StringUtils.equalsIgnoreCase(request.getSponsor(), user.getUserName())) {
      return true; // since anyone should be able to view a request assigned to them
    } else return hasPrivilege(Privilege.CREATE_ANY);
  }

  public Map getPrivileges() {
    List privs = getPrivilegeList();
    if (privs == null) {
      return new HashMap();
    } else {
      Map privMap = new HashMap(privs.size());
      for (int i = 0; i < privs.size(); i++) {
        privMap.put(privs.get(i).toString(), Boolean.TRUE);
      }
      return privMap;
    }
  }

  public List getRoles() {
    return new ArrayList(roles);
  }

  public boolean hasPrivilege(Privilege priv) {
    List privilegeList = getPrivilegeList();
    return privilegeList.contains(priv) ||
        privilegeList.contains(priv.getPrivCode());
  }

  private boolean hasPrivilege(Privilege[] privs) {
    for (int i = 0; i < privs.length; i++) {
      if (hasPrivilege(privs[i])) {
        return true;
      }
    }

    return false;
  }

  private List getPrivilegeList() {
    return privs;
  }
}
