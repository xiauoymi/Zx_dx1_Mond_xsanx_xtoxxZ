package com.monsanto.wst.externaltechrequests.security.dbsecurity.test;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplateNoResults;
import com.monsanto.wst.externaltechrequests.security.NullUser;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.security.UserFactory;
import com.monsanto.wst.externaltechrequests.security.dbsecurity.DBUserFactory;
import junit.framework.TestCase;

/*
 DBUserFactory_UT was created on Dec 20, 2006 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class DBUserFactory_UT extends TestCase {
  private static final String ADMIN_USERID = "DBUNITADMIN";

  private MockDBTemplate template;

  protected void setUp() throws Exception {
    super.setUp();
    template = new MockDBTemplate();
  }

  public void testCreate() throws Exception {
    UserFactory dao = new DBUserFactory(template);
    assertNotNull(dao);
  }

  public void testUserLookup() throws Exception {
    UserFactory userFactory = new DBUserFactory(template);
    userFactory.getUser(ADMIN_USERID);
    assertTrue(template.wasStatementNameCalled(DBUserFactory.USERLOOKUP_QUERY_NAME));
  }

  public void testReturnsNullUserWhenNoUserReturnedFromQuery() throws Exception {
    UserFactory userFactory = new DBUserFactory(new MockDBTemplateNoResults());
    User user = userFactory.getUser(ADMIN_USERID);
    assertNotNull(user);
    assertTrue(user instanceof NullUser);
    assertEquals("Unknown User", user.getUserId());
    assertNotNull(user.getPrivileges());
    assertEquals("Unknown User", user.getFullName());
    assertNotNull(user.getRoles());
    assertFalse(user.hasPrivilege(Privilege.ADMIN_REFDATA));
  }

  public void testAddNewUser() throws Exception {
    UserFactory userFactory = new DBUserFactory(template);
    String testUserId = "test1234";
    String testFullName = "test full name";
    String testEmail = "test1234@monsanto.com";
    String[] roles = {"A", "B"};
    userFactory.addUser(testUserId, testFullName, testEmail, roles, "test");
    assertTrue(template.wasStatementNameCalled(DBUserFactory.ADD_USER_QUERY_NAME));
    assertTrue(template.wasStatementNameCalled(DBUserFactory.DELETE_ROLES_QUERY_NAME));
    assertTrue(template.wasStatementNameCalled(DBUserFactory.ADD_ROLE_QUERY_NAME));
  }

  public void testUpdateUser() throws Exception {
    UserFactory userFactory = new DBUserFactory(template);
    String testUserId = "test1234";
    String testFullName = "test full name";
    String testEmail = "test1234@monsanto.com";
    String[] testRoles = {"A","B"};
    userFactory.updateUser(testUserId, testFullName, testEmail, testRoles, "test");
    assertTrue(template.wasStatementNameCalled(DBUserFactory.UPDATE_USER_QUERY_NAME));
  }

  public void testDeactivateUser() throws Exception {
    UserFactory userFactory = new DBUserFactory(template);
    String testUserId = "test1234";
    userFactory.deactivateUser(testUserId, "test");
    assertTrue(template.wasStatementNameCalled(DBUserFactory.DEACTIVATE_USER_QUERY_NAME));
  }

  public void testReactivateUser() throws Exception {
    UserFactory userFactory = new DBUserFactory(template);
    String testUserId = "test1234";
    userFactory.reactivateUser(testUserId, "test");
    assertTrue(template.wasStatementNameCalled(DBUserFactory.REACTIVATE_USER_QUERY_NAME));
  }
}