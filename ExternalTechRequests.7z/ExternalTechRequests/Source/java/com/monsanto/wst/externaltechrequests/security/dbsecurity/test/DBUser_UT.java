package com.monsanto.wst.externaltechrequests.security.dbsecurity.test;

import com.monsanto.wst.externaltechrequests.security.dbsecurity.DBUser;
import junit.framework.TestCase;

/*
 DBUser_UT was created on Dec 20, 2006 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class DBUser_UT extends TestCase {
  public void testCreate() throws Exception {
    DBUser user = new DBUser("test");
    assertNotNull(user);
  }
}