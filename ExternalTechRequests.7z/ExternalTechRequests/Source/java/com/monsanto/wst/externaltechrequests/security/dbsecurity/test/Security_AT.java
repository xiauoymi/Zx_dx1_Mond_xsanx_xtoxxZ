package com.monsanto.wst.externaltechrequests.security.dbsecurity.test;

import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.security.UserFactory;
import com.monsanto.wst.externaltechrequests.utils.testutils.DbUnitBaseTransactionTestCase;
import com.monsanto.wst.factory.AbstractGenericFactory;

/*
 DBUserFactory was created on Dec 20, 2006 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class Security_AT extends DbUnitBaseTransactionTestCase {
  private static final String INVALID_USERID = "ThereIsNoUserSuchAsThis";
  private static final String ADMIN_USERID = "DBUNITADMIN";
  private static final String NONADMIN_USERID = "DBUNITNON_ADMIN";
  private static final String NOTACTIVE_USERID = "DBUNITNOTACTIVE";

  private static final Privilege TEST_LOGIN_PRIV = new TestPrivilege("TESTLOGIN", "TESTLOGIN");
  private static final Privilege TEST_ADMIN_PRIV = new TestPrivilege("TESTADMIN", "TESTADMIN");
  private static final long ADMIN_OWNERID = 99997;

  protected String getConfigPath() {
    return "com/monsanto/wst/externaltechrequests/security/dbsecurity/test/security.xml";
  }

  protected void cleanDatabase() {
  }

  public void testNonexistentUserIsNotAuthorizedForAnything() throws Exception {
    UserFactory userFactory = (UserFactory) AbstractGenericFactory.getInstance().getBean("userFactory");
    User testUser = userFactory.getUser(INVALID_USERID);
    assertNotNull(testUser);
    assertFalse(testUser.hasPrivilege(TEST_LOGIN_PRIV));
    assertFalse(testUser.hasPrivilege(TEST_ADMIN_PRIV));
  }

  public void testNotActiveAuthorizedForAnything() throws Exception {
    UserFactory userFactory = (UserFactory) AbstractGenericFactory.getInstance().getBean("userFactory");
    User testUser = userFactory.getUser(NOTACTIVE_USERID);
    assertNotNull(testUser);
    assertFalse(testUser.hasPrivilege(TEST_LOGIN_PRIV));
    assertFalse(testUser.hasPrivilege(TEST_ADMIN_PRIV));
  }

  public void testValidAdminUser() throws Exception {
    UserFactory userFactory = (UserFactory) AbstractGenericFactory.getInstance().getBean("userFactory");
    User testUser = userFactory.getUser(ADMIN_USERID);
    assertNotNull(testUser);
    assertTrue(testUser.hasPrivilege(TEST_LOGIN_PRIV));
    assertTrue(testUser.hasPrivilege(TEST_ADMIN_PRIV));
  }

  public void testValidNonAdminUser() throws Exception {
    UserFactory userFactory = (UserFactory) AbstractGenericFactory.getInstance().getBean("userFactory");
    User testUser = userFactory.getUser(NONADMIN_USERID);
    assertNotNull(testUser);
    assertTrue(testUser.hasPrivilege(TEST_LOGIN_PRIV));
    assertFalse(testUser.hasPrivilege(TEST_ADMIN_PRIV));
  }

  private static class TestPrivilege extends Privilege {
    protected TestPrivilege(String code, String description) {
      super(code, description);
    }
  }
}


