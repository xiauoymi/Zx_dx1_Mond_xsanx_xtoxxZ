package com.monsanto.wst.externaltechrequests.security.dbsecurity.test;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.dbsecurity.DBUser;
import com.monsanto.wst.externaltechrequests.security.dbsecurity.UserImpl;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*
 UserImpl_UT was created on Jan 9, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class UserImpl_UT extends TestCase {
  public void testPrivLookup() throws Exception {
    List testList = new ArrayList();
    testList.add(Privilege.EDIT_OWN);
    UserImpl user = new UserImpl(new DBUser("TEST"), testList, new ArrayList());
    assertNotNull(user);
    assertTrue(user.hasPrivilege(Privilege.EDIT_OWN));
  }

  public void testPrivMapEmptyList() throws Exception {
    UserImpl user = new UserImpl(new DBUser("1234"), new ArrayList(), new ArrayList());
    Map privMap = user.getPrivileges();
    assertNull(privMap.get(Privilege.EDIT_OWN.getPrivCode()));
  }

  public void testPrivMap() throws Exception {
    List privs = new ArrayList();
    privs.add(Privilege.EDIT_OWN);
    UserImpl user = new UserImpl(new DBUser("1234"), privs, new ArrayList());
    Map privMap = user.getPrivileges();
    assertEquals(Boolean.TRUE, privMap.get(Privilege.EDIT_OWN.getPrivCode()));
  }

  public void testWithoutEditOrViewPrivilegeCantViewOrEdit() throws Exception {
    RequestProfile request = new RequestProfile();
    request.setSponsor("test");
    List privs = new ArrayList();
    privs.add(Privilege.REVIEW);
    UserImpl user = new UserImpl(new DBUser("1234"), privs, new ArrayList());
    assertFalse(user.canEdit(request));
    assertFalse(user.canView(request));
  }

  public void testWithViewNotEditPrivilegeCanViewNotEdit() throws Exception {
    RequestProfile request = new RequestProfile();
    request.setSponsor("test");
    List privs = new ArrayList();
    privs.add(Privilege.VIEW_ALL);
    UserImpl user = new UserImpl(new DBUser("1234"), privs, new ArrayList());
    assertFalse(user.canEdit(request));
    assertTrue(user.canView(request));
  }

  public void testWithViewAndEditCanViewAndEdit() throws Exception {
    RequestProfile request = new RequestProfile();
    request.setSponsor("test");
    List privs = new ArrayList();
    privs.add(Privilege.CREATE_ANY);
    privs.add(Privilege.VIEW_ALL);
    UserImpl user = new UserImpl(new DBUser("1234"), privs, new ArrayList());
    assertTrue(user.canEdit(request));
    assertTrue(user.canView(request));
  }

  public void testWithNoOtherPrivsCanViewOwnNotOthers() throws Exception {
    String myUserid = "1234";
    RequestProfile myRequest = new RequestProfile();
    myRequest.setSponsor(myUserid);
    RequestProfile yourRequest = new RequestProfile();
    yourRequest .setSponsor("test");
    List privs = new ArrayList();
    UserImpl user = new UserImpl(new DBUser(myUserid), privs, new ArrayList());
    assertFalse(user.canEdit(myRequest));
    assertTrue(user.canView(myRequest));
    assertFalse(user.canEdit(yourRequest));
    assertFalse(user.canView(yourRequest));
  }

  public void testWithEditOwnPrivCanEditOwnNotOthers() throws Exception {
    String myUserid = "1234";
    RequestProfile myRequest = new RequestProfile();
    myRequest.setSponsor(myUserid);
    RequestProfile yourRequest = new RequestProfile();
    yourRequest .setSponsor("test");
    List privs = new ArrayList();
    privs.add(Privilege.EDIT_OWN);
    UserImpl user = new UserImpl(new DBUser(myUserid), privs, new ArrayList());
    assertTrue(user.canEdit(myRequest));
    assertTrue(user.canView(myRequest));
    assertFalse(user.canEdit(yourRequest));
    assertFalse(user.canView(yourRequest));
  }


}