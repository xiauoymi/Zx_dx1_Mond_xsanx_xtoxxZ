package com.monsanto.wst.externaltechrequests.security.test;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.Privilege;
/*
 MockPrivilegedUser was created on Jan 23, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MockPrivilegedUser extends MockReadonlyUser {
  public MockPrivilegedUser(String userId) {
    super(userId);
  }

  public boolean hasPrivilege(Privilege priv) {
    return true;
  }

  public boolean canEdit(RequestProfile request) {
    return true;
  }
}
