package com.monsanto.wst.externaltechrequests.security.test;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;
/*
 MockReadonlyUser was created on Feb 13, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MockReadonlyUser extends MockUser {
  public MockReadonlyUser(String userId) {
    super(userId);
  }

  public boolean canView(RequestProfile request) {
    return true;
  }
}
