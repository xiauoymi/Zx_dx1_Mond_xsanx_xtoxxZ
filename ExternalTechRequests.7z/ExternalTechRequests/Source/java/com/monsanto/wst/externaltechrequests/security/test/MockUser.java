package com.monsanto.wst.externaltechrequests.security.test;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/*
 MockUser was created on Jan 9, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MockUser implements User {
  private final String userId;

  public MockUser(String userId) {
    this.userId = userId;
  }

  public boolean hasPrivilege(Privilege priv) {
    return false;
  }

  public String getUserId() {
    return userId;
  }

  public String getEmail() {
    return userId + "@monsanto.com";
  }

  public boolean canView(RequestProfile request) {
    return false;
  }

  public boolean canEdit(RequestProfile request) {
    return false;
  }

  public Map getPrivileges() {
    return new HashMap();
  }

  public String getFullName() {
    return userId;
  }

  public List getRoles() {
    return new ArrayList();
  }

}
