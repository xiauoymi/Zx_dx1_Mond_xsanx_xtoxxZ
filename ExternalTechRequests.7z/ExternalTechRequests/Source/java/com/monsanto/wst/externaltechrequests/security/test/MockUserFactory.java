package com.monsanto.wst.externaltechrequests.security.test;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.Privilege;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.security.UserFactory;

import java.util.*;
/*
 MockUserFactory was created on Jan 23, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MockUserFactory implements UserFactory {
  private final Map activeUsers;
  private final Map nonactiveUsers;
  private final String[] allRoles;

  public MockUserFactory() {
    activeUsers = new HashMap();
    nonactiveUsers = new HashMap();
    allRoles = new String[0];
  }

  public User getUser(String userid) {
    return (User) activeUsers.get(userid);
  }

  public List getAllUsers() {
    Iterator userIterator = activeUsers.keySet().iterator();
    List allUsers = new ArrayList();
    while (userIterator.hasNext()) {
      allUsers.add(activeUsers.get(userIterator.next()));
    }
    return allUsers;
  }

  public List getAllSponsors() {
    return getAllUsers();
  }

  public void addUser(String userId, String fullName, String email, String[] roles, String modUser) {
    activeUsers.put(userId, new MockUser(userId, fullName, roles));
  }

  public void updateUser(String userId, String fullName, String email, String[] roles, String modUser) {
    activeUsers.remove(userId);
    addUser(userId, fullName, email, roles, "test");
  }

  private void move(Map from, Map to, String userid) {
    User movingUser = (User) from.get(userid);
    if (movingUser != null) {
      from.remove(userid);
      to.put(userid, movingUser);
    }
  }

  public void deactivateUser(String userId, String modUser) {
    move(activeUsers, nonactiveUsers, userId);
  }

  public void reactivateUser(String userId, String modUser) {
    move(nonactiveUsers, activeUsers, userId);
  }

  public List getAllRoles() {
    return Arrays.asList(allRoles);
  }

  private static class MockUser implements User {
    private final String userId;
    private final String fullName;
    private final String[] roles;

    MockUser(String userId, String fullName, String[] roles) {
      this.userId = userId;
      this.fullName = fullName;
      this.roles = roles;
    }

    public boolean hasPrivilege(Privilege priv) {
      return false;
    }

    public Map getPrivileges() {
      return new HashMap();
    }

    public String getFullName() {
      return fullName;
    }

    public List getRoles() {
      if (roles == null) {
        return new ArrayList();
      } else {
        return Arrays.asList(roles);
      }
    }

    public String getUserId() {
      return userId;
    }

    public String getEmail() {
      return userId + "@monsanto.com";
    }

    public boolean canView(RequestProfile request) {
      return false;
    }

    public boolean canEdit(RequestProfile request) {
      return false;
    }
  }
}
