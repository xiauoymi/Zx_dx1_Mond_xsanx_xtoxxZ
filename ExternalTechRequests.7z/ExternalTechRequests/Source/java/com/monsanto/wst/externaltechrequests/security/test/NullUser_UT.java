package com.monsanto.wst.externaltechrequests.security.test;

import junit.framework.TestCase;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.security.NullUser;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;

/*
 NullUser_UT was created on Feb 22, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class NullUser_UT extends TestCase {
  public void testNullUser() throws Exception {
    User user = new NullUser();
    assertFalse(user.canEdit(new RequestProfile()));
    assertFalse(user.canView(new RequestProfile()));
    assertNull(user.getEmail());
    assertEquals(NullUser.NULL_USER_ID, user.getUserId());
    assertEquals(NullUser.NULL_USER_ID, user.getFullName());
    assertTrue(user.getRoles().isEmpty());
    assertEquals(0, user.getPrivileges().size());
  }
}