package com.monsanto.wst.externaltechrequests.services;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.document.AttachmentCollection;
import com.monsanto.wst.externaltechrequests.document.DocumentStorageException;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.security.User;

import java.util.List;
/*
 AttachmentService was created on Jan 24, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public interface AttachmentService {
  AttachmentCollection getAttachments(Long requestId, User user);

  void addAttachment(Attachment attachment, String modUser) throws DocumentStorageException;

  List getTemplates(DocumentType templateType);

  void addTemplate(Attachment attachment, String modUser) throws DocumentStorageException;

  void loadSecurityInfoFromHelper(UCCHelper helper);

  Attachment getAttachment(Long attachmentId);

  void updateAttachment(Attachment attachment, String modUser) throws DocumentStorageException;

  void deleteAttachment(Attachment attachment);
}
