/*
 LookupReferenceDataServiceImpl was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.services;

import com.monsanto.wst.externaltechrequests.dao.LookupReferenceDataDao;

import java.util.List;

/**
 * Filename:    $RCSfile: LookupReferenceDataServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.6 $
 */
public class LookupReferenceDataServiceImpl implements LookupReferenceDataService {
  private final LookupReferenceDataDao lookupReferenceDataDao;

  public LookupReferenceDataServiceImpl(LookupReferenceDataDao lookupReferenceDataDao) {
    this.lookupReferenceDataDao = lookupReferenceDataDao;
  }

  public List getRegionRefList() {
    return lookupReferenceDataDao.getRegionRefList();
  }

  public List getCommitteeApprovalRefList() {
    return lookupReferenceDataDao.getCommitteeApprovalRefList();
  }

  public List getStatusRefList() {
    return lookupReferenceDataDao.getStatusRefList();
  }

  public List getResearchTypeRefList() {
    return lookupReferenceDataDao.getResearchTypeRefList();
  }

  public List getRequestTypeRefList() {
    return lookupReferenceDataDao.getRequestTypeRefList();
  }

  public List getStudyLengthTypeRefList() {
    return lookupReferenceDataDao.getStudyLengthTypeRefList();
  }

  public List getStates() {
    return lookupReferenceDataDao.getStateRefList();
  }
}