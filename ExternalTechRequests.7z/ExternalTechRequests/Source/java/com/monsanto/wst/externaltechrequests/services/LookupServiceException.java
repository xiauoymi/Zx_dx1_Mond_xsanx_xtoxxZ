/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.externaltechrequests.services;

/**
 * Filename:    $RCSfile: LookupServiceException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-09 20:06:08 $
 *
 * @author jdpoul
 * @version $Revision: 1.2 $
 */
public class LookupServiceException extends Exception {
  public LookupServiceException(String message) {
    super(message);
  }

  public LookupServiceException(String message, Throwable cause) {
    super(message, cause);
  }
}