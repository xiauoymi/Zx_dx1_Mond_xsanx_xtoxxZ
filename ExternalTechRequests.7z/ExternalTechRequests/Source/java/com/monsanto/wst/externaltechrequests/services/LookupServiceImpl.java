/*
 LookupServiceImpl was created on Nov 6, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.services;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.externaltechrequests.dao.LookupDao;
import com.monsanto.wst.externaltechrequests.exception.NoResultsException;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.User;

import java.util.List;

/**
 * Filename:    $RCSfile: LookupServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date:
 * 2007/01/23 20:01:19 $
 *
 * @author ffbrac
 * @version $Revision: 1.14 $
 */
public class LookupServiceImpl implements LookupService {
  private final LookupDao lookupDao;

  public LookupServiceImpl(LookupDao lookupDao) {
    this.lookupDao = lookupDao;
  }

  public Long lookupNextRequestSeq() throws LookupServiceException {
    try {
      return lookupDao.lookupNextRequestSeq();
    } catch (NoResultsException ex) {
      Logger.log(new LoggableError(ex));
      throw new LookupServiceException("Unable to get the next Request identifier.", ex);
    }
  }

  public RequestProfile lookupRequestById(Long requestId) throws LookupServiceException {
    try {
      return lookupDao.lookupRequestById(requestId);
    } catch (NoResultsException ex) {
      Logger.log(new LoggableError(ex));
      throw new LookupServiceException("Unable to retreive the request with id " + requestId + '.', ex);
    }
  }

  public List lookupResearchRequestListByRequestId(Long requestId) {
    return lookupDao.lookupResearchRequestListByRequestId(requestId);
  }

  public List lookupStatusRequestListByRequestId(Long requestId) {
    return lookupDao.lookupStatusRequestListByRequestId(requestId);
  }

  public List lookupCommitteApprovedRequestListByRequestId(Long requestId) {
    return lookupDao.lookupCommitteApprovedRequestListByRequestId(requestId);
  }

  public User lookupLoginUserByUserId(String userId) throws LookupServiceException {
    try {
      return lookupDao.lookupLoginUserByUserId(userId);
    } catch (NoResultsException e) {
      throw new LookupServiceException(
          "User " + userId + " is not authorized to access this system... Please contact the system administrator.", e);
    }
  }

  public String lookupNextRequestGenNumber() throws LookupServiceException {
    try {
      return lookupDao.lookupNextRequestGenNumber();
    } catch (NoResultsException e) {
      Logger.log(new LoggableError(e));
      throw new LookupServiceException("Unable to get the next request number.", e);
    }
  }
}