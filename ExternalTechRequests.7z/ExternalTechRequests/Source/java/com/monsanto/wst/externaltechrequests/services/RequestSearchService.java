/*
 RequestSearchService was created on Nov 15, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.services;

import com.monsanto.wst.externaltechrequests.model.RequestSearch;

import java.util.List;

/**
 * Filename:    $RCSfile: RequestSearchService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.5 $
 */
public interface RequestSearchService {
  List getRequestListBySearchCriteria(RequestSearch requestSearch);
}