/*
 RequestService was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.services;

import com.monsanto.wst.externaltechrequests.model.AddressInfo;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestResearchType;

/**
 * Filename:    $RCSfile: RequestService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date:
 * 2007/02/09 19:40:43 $
 *
 * @author ffbrac
 * @version $Revision: 1.9 $
 */
public interface RequestService {
  Long insertAddress(AddressInfo addressInfo);

  Long insertRequestProfile(RequestProfile requestProfile);

  Long insertRequestResearch(RequestResearchType requestResearchType);

  Long insertRequestStatus(RequestResearchType requestResearchType);

  Long insertRequestCommitteeApproved(RequestResearchType requestResearchType);

  Long updateRequestProfile(RequestProfile requestProfile);

  Long updateAddressInfo(AddressInfo address);

  Long deleteRequestResearch(Long id);

  Long getNextSeq();
}