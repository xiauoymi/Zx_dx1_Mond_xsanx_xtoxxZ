/*
 RequestServiceImpl was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.services;

import com.monsanto.wst.externaltechrequests.dao.RequestDao;
import com.monsanto.wst.externaltechrequests.model.AddressInfo;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestResearchType;

/**
 * Filename:    $RCSfile: RequestServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.10 $
 */
public class RequestServiceImpl implements RequestService {
  private final RequestDao requestDao;

  public RequestServiceImpl(RequestDao requestDao) {
    this.requestDao = requestDao;
  }

  public Long insertAddress(AddressInfo addressInfo) {
    return requestDao.insertAddress(addressInfo);
  }

  public Long insertRequestProfile(RequestProfile requestProfile) {
    return requestDao.insertRequestProfile(requestProfile);
  }

  public Long insertRequestResearch(RequestResearchType requestResearchType) {
    return requestDao.insertRequestResearch(requestResearchType);
  }

  public Long insertRequestStatus(RequestResearchType requestResearchType) {
    return requestDao.insertStatusResearch(requestResearchType);
  }

  public Long insertRequestCommitteeApproved(RequestResearchType requestResearchType) {
    return requestDao.insertCommitteeApprovedResearch(requestResearchType);
  }

  public Long updateRequestProfile(RequestProfile requestProfile) {
    return requestDao.updateRequestProfile(requestProfile);
  }

  public Long updateAddressInfo(AddressInfo address) {
    return requestDao.updateAddressInfo(address);
  }

  public Long deleteRequestResearch(Long id) {
    return requestDao.deleteRequestResearch(id);
  }

  public Long getNextSeq() {
    return requestDao.getNextSeq();
  }

}