/*
 MockLookupReferenceDataService was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.services.mock;

import com.monsanto.wst.externaltechrequests.services.LookupReferenceDataService;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockLookupReferenceDataService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-30 15:26:03 $
 *
 * @author ffbrac
 * @version $Revision: 1.5 $
 */
public class MockLookupReferenceDataService implements LookupReferenceDataService {
	public List getRegionRefList() {
		return new ArrayList();
	}

	public List getCommitteeApprovalRefList() {
		return new ArrayList();
	}

	public List getStatusRefList() {
		return new ArrayList();
	}

	public List getResearchTypeRefList() {
		return new ArrayList();
	}

	public List getRequestTypeRefList() {
		return new ArrayList();
	}

	public List getStudyLengthTypeRefList() {
		return new ArrayList();
	}

  public List getStates() {
    return new ArrayList();
  }
}