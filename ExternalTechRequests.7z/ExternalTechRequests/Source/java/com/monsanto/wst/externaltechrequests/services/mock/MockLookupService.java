/*
 MockLookupService was created on Nov 7, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.services.mock;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.NullUser;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.services.LookupService;
import com.monsanto.wst.externaltechrequests.services.LookupServiceException;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockLookupService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-06 18:03:32 $
 *
 * @author ffbrac
 * @version $Revision: 1.13 $
 */
public class MockLookupService implements LookupService {

  private RequestProfile profile = new RequestProfile(new Long("100"));

  public Long lookupNextRequestSeq() {
    return new Long("100");
  }

  public void setProfile(RequestProfile profile) {
    this.profile = profile;
  }

  public RequestProfile lookupRequestById(Long requestId) {
    return profile;
  }

  public List lookupResearchRequestListByRequestId(Long requestId) {
    return new ArrayList();
  }

  public List lookupStatusRequestListByRequestId(Long requestId) {
    return new ArrayList();
  }

  public List lookupCommitteApprovedRequestListByRequestId(Long requestId) {
    return new ArrayList();
  }

  public User lookupLoginUserByUserId(String userId) {
    return new NullUser();
  }

  public String lookupNextRequestGenNumber() throws LookupServiceException {
    return "SRWG-2007-0061";
  }
}