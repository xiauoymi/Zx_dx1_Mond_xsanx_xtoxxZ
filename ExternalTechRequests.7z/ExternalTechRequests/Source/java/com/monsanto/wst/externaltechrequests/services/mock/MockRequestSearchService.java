/*
 MockRequestSearchService was created on Nov 15, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.services.mock;

import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.services.RequestSearchService;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockRequestSearchService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.6 $
 */
public class MockRequestSearchService implements RequestSearchService {
  private final List results;
  private RequestSearch requestSearch;

  public MockRequestSearchService() {
    this(new ArrayList());
  }

  public MockRequestSearchService(List results) {
    this.results = results;
    this.requestSearch = null;
  }

  public List getRequestListBySearchCriteria(RequestSearch requestSearch) {
    this.requestSearch = requestSearch;
    return results;
  }

  public RequestSearch getRequestSearch() {
    return requestSearch;
  }
}