/*
 LookupReferenceDataServiceImpl_UT was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.services.test;

import com.monsanto.wst.externaltechrequests.dao.mock.MockLookupReferenceDataDao;
import com.monsanto.wst.externaltechrequests.services.LookupReferenceDataService;
import com.monsanto.wst.externaltechrequests.services.LookupReferenceDataServiceImpl;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: LookupReferenceDataServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * kjjohn2 $    	 On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.5 $
 */
public class LookupReferenceDataServiceImpl_UT extends TestCase {
  public void testCreate() throws Exception {
    LookupReferenceDataService lookupImpl = new LookupReferenceDataServiceImpl(null);
    assertNotNull(lookupImpl);
  }

  public void testGetCommitteeApprovalRefList() throws Exception {
    MockLookupReferenceDataDao lookupDao = new MockLookupReferenceDataDao();
    LookupReferenceDataService lookupImpl = new LookupReferenceDataServiceImpl(lookupDao);
    List list = lookupImpl.getCommitteeApprovalRefList();
    assertNotNull(list);
  }

  public void testGetRegionRefList() throws Exception {
    MockLookupReferenceDataDao lookupDao = new MockLookupReferenceDataDao();
    LookupReferenceDataService lookupImpl = new LookupReferenceDataServiceImpl(lookupDao);
    List list = lookupImpl.getRegionRefList();
    assertNotNull(list);
  }

  public void testGetRequestTypeRefList() throws Exception {
    MockLookupReferenceDataDao lookupDao = new MockLookupReferenceDataDao();
    LookupReferenceDataService lookupImpl = new LookupReferenceDataServiceImpl(lookupDao);
    List list = lookupImpl.getRequestTypeRefList();
    assertNotNull(list);
  }

  public void testGetResearchTypeRefList() throws Exception {
    MockLookupReferenceDataDao lookupDao = new MockLookupReferenceDataDao();
    LookupReferenceDataService lookupImpl = new LookupReferenceDataServiceImpl(lookupDao);
    List list = lookupImpl.getResearchTypeRefList();
    assertNotNull(list);
  }

  public void testGetStatusRefList() throws Exception {
    MockLookupReferenceDataDao lookupDao = new MockLookupReferenceDataDao();
    LookupReferenceDataService lookupImpl = new LookupReferenceDataServiceImpl(lookupDao);
    List list = lookupImpl.getStatusRefList();
    assertNotNull(list);
  }

  public void testGetStudyLengthTypeRefList() throws Exception {
    MockLookupReferenceDataDao lookupDao = new MockLookupReferenceDataDao();
    LookupReferenceDataService lookupImpl = new LookupReferenceDataServiceImpl(lookupDao);
    List list = lookupImpl.getStudyLengthTypeRefList();
    assertNotNull(list);
  }

  public void testGetStateRefList() throws Exception {
    MockLookupReferenceDataDao lookupDao = new MockLookupReferenceDataDao();
    LookupReferenceDataService lookupImpl = new LookupReferenceDataServiceImpl(lookupDao);
    List list = lookupImpl.getStates();
    assertNotNull(list);
  }

}