/*
 LookupServiceImpl_UT was created on Nov 7, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.services.test;

import com.monsanto.wst.externaltechrequests.dao.mock.MockLookupDao;
import com.monsanto.wst.externaltechrequests.dao.mockfail.MockLookupDaoEx;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.User;
import com.monsanto.wst.externaltechrequests.services.LookupServiceException;
import com.monsanto.wst.externaltechrequests.services.LookupServiceImpl;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: LookupServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.13 $
 */
public class LookupServiceImpl_UT extends TestCase {
  public void testCreate() throws Exception {
    LookupServiceImpl lookupImpl = new LookupServiceImpl(null);
    assertNotNull(lookupImpl);
  }

  public void testLookupNextRequestSeqSuccess() throws Exception {
    MockLookupDao lookupDao = new MockLookupDao();
    LookupServiceImpl lookupImpl = new LookupServiceImpl(lookupDao);
    Long id = lookupImpl.lookupNextRequestSeq();
    assertEquals(new Long("100"), id);
  }

  public void testLookupNextRequestSeqFail() throws Exception {
    MockLookupDaoEx lookupDao = new MockLookupDaoEx();
    LookupServiceImpl lookupImpl = new LookupServiceImpl(lookupDao);
    try {
      lookupImpl.lookupNextRequestSeq();
      fail();
    } catch (LookupServiceException e) {
      assertEquals("Unable to get the next Request identifier.", e.getMessage());
    }
  }

  public void testLookupRequestById() throws Exception {
    MockLookupDao lookupDao = new MockLookupDao();
    LookupServiceImpl lookupImpl = new LookupServiceImpl(lookupDao);
    RequestProfile requestProfile = lookupImpl.lookupRequestById(new Long("100"));
    assertEquals(new Long("100"), requestProfile.getId());
  }

  public void testLookupRequestByIdFail() throws Exception {
    MockLookupDaoEx lookupDao = new MockLookupDaoEx();
    LookupServiceImpl lookupImpl = new LookupServiceImpl(lookupDao);
    RequestProfile requestProfile = null;
    try {
      requestProfile = lookupImpl.lookupRequestById(new Long("100"));
      fail();
    } catch (LookupServiceException e) {
      assertEquals("Unable to retreive the request with id 100.", e.getMessage());
    } catch (NumberFormatException e) {
      fail();
    }
    assertEquals(null, requestProfile);
  }

  public void testLookupResearchRequestListByRequestId() throws Exception {
    MockLookupDao lookupDao = new MockLookupDao();
    LookupServiceImpl lookupImpl = new LookupServiceImpl(lookupDao);
    List list = lookupImpl.lookupResearchRequestListByRequestId(new Long("100"));
    assertTrue(list.size() == 0);
  }

  public void testLookupStatusRequestListByRequestId() throws Exception {
    MockLookupDao lookupDao = new MockLookupDao();
    LookupServiceImpl lookupImpl = new LookupServiceImpl(lookupDao);
    List list = lookupImpl.lookupStatusRequestListByRequestId(new Long("100"));
    assertTrue(list.size() == 0);
  }

  public void testLookupCommitteApprovedRequestListByRequestId() throws Exception {
    MockLookupDao lookupDao = new MockLookupDao();
    LookupServiceImpl lookupImpl = new LookupServiceImpl(lookupDao);
    List list = lookupImpl.lookupCommitteApprovedRequestListByRequestId(new Long("100"));
    assertTrue(list.size() == 0);
  }

  public void testLookupLoginUserByUserId() throws Exception {
    MockLookupDao lookupDao = new MockLookupDao();
    LookupServiceImpl lookupImpl = new LookupServiceImpl(lookupDao);
    User loginUser = lookupImpl.lookupLoginUserByUserId("FFBRAC");
    assertEquals("FFBRAC", loginUser.getUserId());
  }

  public void testLookupNextRequestGenNumber_MockLookupDao_ReturnsCorrectNumber() throws Exception {
    MockLookupDao lookupDao = new MockLookupDao();
    LookupServiceImpl lookupImpl = new LookupServiceImpl(lookupDao);
    assertEquals("testMe", lookupImpl.lookupNextRequestGenNumber());
  }


  public void testLookupNextRequestGenNumber_ExceptionThrowingMockLookupDao_ThrowsException() throws Exception {
    MockLookupDaoEx lookupDao = new MockLookupDaoEx();
    LookupServiceImpl lookupImpl = new LookupServiceImpl(lookupDao);

    try {
      lookupImpl.lookupNextRequestGenNumber();
      fail();
    } catch (LookupServiceException e) {
      assertEquals("Unable to get the next request number.", e.getMessage());
    }
  }
}