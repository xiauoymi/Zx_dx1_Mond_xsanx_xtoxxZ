/*
 RequestSearchServiceImpl_UT was created on Nov 15, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.services.test;

import com.monsanto.wst.externaltechrequests.dao.mock.MockRequestSearchDao;
import com.monsanto.wst.externaltechrequests.model.RequestSearch;
import com.monsanto.wst.externaltechrequests.services.RequestSearchService;
import com.monsanto.wst.externaltechrequests.services.RequestSearchServiceImpl;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: RequestSearchServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.6 $
 */
public class RequestSearchServiceImpl_UT extends TestCase {
  public void testCreate() throws Exception {
    RequestSearchService implementation = new RequestSearchServiceImpl(null);
    assertNotNull(implementation);
  }

  public void testGetRequestListBySearchCriteria() throws Exception {
    RequestSearchService implementation = new RequestSearchServiceImpl(new MockRequestSearchDao());
    List list = implementation.getRequestListBySearchCriteria(new RequestSearch());
    assertTrue(list.size() == 0);
  }

}