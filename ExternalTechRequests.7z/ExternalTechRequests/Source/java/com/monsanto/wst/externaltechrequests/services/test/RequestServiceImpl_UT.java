/*
 RequestServiceImpl_UT was created on Nov 8, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.services.test;

import com.monsanto.wst.externaltechrequests.dao.mock.MockRequestDao;
import com.monsanto.wst.externaltechrequests.model.AddressInfo;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestResearchType;
import com.monsanto.wst.externaltechrequests.services.RequestService;
import com.monsanto.wst.externaltechrequests.services.RequestServiceImpl;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: RequestServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.7 $
 */
public class RequestServiceImpl_UT extends TestCase {
  public void testCreate() throws Exception {
    RequestService implementation = new RequestServiceImpl(null);
    assertNotNull(implementation);
  }

  public void testInsertAddress() throws Exception {
    RequestService implementation = new RequestServiceImpl(new MockRequestDao());
    Long id = implementation.insertAddress(new AddressInfo());
    assertEquals(new Long("100"), id);
  }

  public void testInsertRequestProfile() throws Exception {
    RequestService implementation = new RequestServiceImpl(new MockRequestDao());
    Long id = implementation.insertRequestProfile(new RequestProfile());
    assertEquals(new Long("100"), id);
  }

  public void testInsertRequestResearch() throws Exception {
    RequestService implementation = new RequestServiceImpl(new MockRequestDao());
    Long id = implementation.insertRequestResearch(new RequestResearchType());
    assertEquals(new Long("100"), id);
  }

  public void testInsertRequestStatus() throws Exception {
    RequestService implementation = new RequestServiceImpl(new MockRequestDao());
    Long id = implementation.insertRequestStatus(new RequestResearchType());
    assertEquals(new Long("100"), id);
  }

  public void testInsertRequestCommitteeApproved() throws Exception {
    RequestService implementation = new RequestServiceImpl(new MockRequestDao());
    Long id = implementation.insertRequestCommitteeApproved(new RequestResearchType());
    assertEquals(new Long("100"), id);
  }

  public void testDeleteRequestResearch() throws Exception {
    RequestService implementation = new RequestServiceImpl(new MockRequestDao());
    Long id = implementation.deleteRequestResearch(new Long("300"));
    assertEquals(new Long("100"), id);
  }

  public void testUpdateAddressInfo() throws Exception {
    RequestService implementation = new RequestServiceImpl(new MockRequestDao());
    Long id = implementation.updateAddressInfo(new AddressInfo(new Long("300")));
    assertEquals(new Long("100"), id);
  }

  public void testUpdateRequestProfile() throws Exception {
    RequestService implementation = new RequestServiceImpl(new MockRequestDao());
    Long id = implementation.updateRequestProfile(new RequestProfile(new Long("300")));
    assertEquals(new Long("100"), id);
  }
}