/*
 ExampleServletLoggerFactory was created on Jul 3, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.servlet;

import com.monsanto.AbstractLogging.LogDevice;
import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Log4JLogging.*;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * <p>Title: ExternalTechRequestsLoggerFactory</p> <p>Description: <p>Copyright: Copyright (c) 2005</p> <p>Company:
 * Monsanto</p>
 *
 * @author Java Framework Code  Generator 2.4
 * @version $Id: ExternalTechRequestsLoggerFactory.java,v 1.5 2007-02-27 19:33:57 kjjohn2 Exp $
 */
public class ExternalTechRequestsLoggerFactory {
  private final String m_cstrAppName = "ExternalTechRequests";
  private final String m_cstrTraceLogPath;
  private final String m_cstrRollingLogPath;

  public ExternalTechRequestsLoggerFactory() {
    String cstrLogFolderName = System.getProperty("catalina.base") + File.separatorChar + "logs";

    m_cstrTraceLogPath = cstrLogFolderName + File.separatorChar + m_cstrAppName + "Trace.log";
    m_cstrRollingLogPath = cstrLogFolderName + File.separatorChar + m_cstrAppName + ".log";
  }

  public synchronized void setupLogging() throws IOException,
      LogRegistrationException {
    Logger.register(new Log4JTraceLog(m_cstrAppName, new Log4JFileLogDevice(m_cstrTraceLogPath)));

    LogDevice AppLogDevice = new Log4JMidnightRollingFileLogDevice(m_cstrRollingLogPath);

    Logger.register(new Log4JDebugLog(m_cstrAppName, AppLogDevice));
    Logger.register(new Log4JInfoLog(m_cstrAppName, AppLogDevice));
    Logger.register(new Log4JWarningLog(m_cstrAppName, AppLogDevice));
    Logger.register(new Log4JErrorLog(m_cstrAppName, AppLogDevice));
  }

  public Document toXML() {
    Logger.traceEntry();

    Document logDocument = DOMUtil.newDocument();
    Element rootElement = DOMUtil.addChildElement(logDocument, "LOGS");
    insertXML(rootElement);

    return (Document) Logger.traceExit(logDocument);
  }

  public void insertXML(Element parentElement) {
    Logger.traceEntry();

    try {
      addLogDeviceToXmlDocument(parentElement, "Rolling Log (Text)", m_cstrRollingLogPath);
      addLogDeviceToXmlDocument(parentElement, "Trace Log", m_cstrTraceLogPath);
    }
    catch (UnsupportedEncodingException uee) {
      Logger.log(new LoggableError(uee));
    }

    Logger.traceExit();
  }

  private void addLogDeviceToXmlDocument(Element parentElement, String deviceName, String filePath)
      throws UnsupportedEncodingException {
    Logger.traceEntry();

    if (filePath != null && (!"".equals(filePath.trim()))) {
      Element deviceElement = DOMUtil.addChildElement(parentElement, "LOG_DEVICE");
      DOMUtil.addChildElement(deviceElement, "DEVICE_NAME", deviceName);
      DOMUtil.addChildElement(deviceElement, "LOCATION", URLEncoder.encode(filePath, "UTF-8"));
    } else {
      throw new IllegalArgumentException("filePath argument cannot be null, blank, or empty.");
    }

    Logger.traceExit();
  }
}
