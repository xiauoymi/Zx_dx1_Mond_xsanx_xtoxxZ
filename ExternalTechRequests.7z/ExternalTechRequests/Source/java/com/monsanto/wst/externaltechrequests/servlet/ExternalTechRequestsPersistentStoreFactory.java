package com.monsanto.wst.externaltechrequests.servlet;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType2;

import java.util.ResourceBundle;

/**
 * <p>Title: ExternalTechRequestsPersistentStoreFactory</p> <p>Description: </p> <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 *
 * @author Java Framework Code  Generator 2.4
 * @version $Id: ExternalTechRequestsPersistentStoreFactory.java,v 1.5 2007-02-27 19:33:57 kjjohn2 Exp $
 */
public class ExternalTechRequestsPersistentStoreFactory {
  private ExternalTechRequestsPersistentStoreFactory() {
  }

  /**
   * Returns a Persistent Store.
   *
   * @param cstrResourceBundleName The name of the resource bundle that points to the correct database.
   *
   * @return A PersistentStore object.
   *
   * @exception WrappingException
   */
  public static PersistentStore getStore(String cstrResourceBundleName) throws WrappingException {
    Logger.traceEntry();


    ResourceBundle bundle = ResourceBundle.getBundle(cstrResourceBundleName);


    PersistentStore RetVal = new PersistentStoreOracleCachedType2(bundle);


    return (PersistentStore) Logger.traceExit(RetVal);
  }
}
