package com.monsanto.wst.externaltechrequests.servlet;


import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCServletHelper;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.wst.externaltechrequests.model.RequestURLGenerator;
import com.monsanto.wst.factory.AbstractGenericFactory;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ResourceBundle;


/**
 * <p>Title: ExternalTechRequestsServlet</p> <p>Description: </p> <p>Copyright: Copyright (c) 2003</p> <p>Company:
 * Monsanto</p>
 *
 * @author Java Framework Code  Generator 2.4
 * @version $Id: ExternalTechRequestsServlet.java,v 1.9 2007-02-27 19:33:57 kjjohn2 Exp $
 */
public class ExternalTechRequestsServlet extends GatewayServlet {
  public static final String s_cstrResourceBundle = "com.monsanto.wst.externaltechrequests.servlet.ExternalTechRequests";

  public ExternalTechRequestsServlet() {
  }

  public void init(ServletConfig servletConfig) throws ServletException {
    super.init(servletConfig);

    AbstractGenericFactory.setImplementation(servletConfig.getInitParameter("container"));

    Logger.traceEntry();

    setBaseURL();

    try {
      ExternalTechRequestsLoggerFactory loggerFactory = new ExternalTechRequestsLoggerFactory();
      loggerFactory.setupLogging();
    }
    catch (LogRegistrationException lre) {
      throw new ServletException(lre);
    }
    catch (IOException ioe) {
      throw new ServletException(ioe);
    }

    Logger.traceExit();
  }

  protected void setBaseURL() {
    try {
      String prefix = EnvironmentHelper.getPropertyPrefix();
      ResourceBundle bundle = ResourceBundle.getBundle(s_cstrResourceBundle);
      RequestURLGenerator.setBaseURL(bundle.getString(prefix + "url"));
    } catch (EnvironmentHelperException e) {
      throw new RuntimeException(e);
    }
  }

  public void destroy() {
    Logger.traceEntry();

    try {
      PersistentStore.registerInstance(null);
    } catch (WrappingException e) {
      // ignore exception on destroy
    }

    super.destroy();

    Logger.traceExit();
  }

  /**
   * This static method will create an instance of the desired PersistentStore based on data within a property file.
   *
   * @param request  - The HttpServlet Request from the servlet container
   * @param response - The HttpServletResponse to be sent back to the servlet container.
   *
   * @exception IOException
   * @exception ServletException
   */
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    Logger.traceEntry();

    UCCHelper helper = new UCCServletHelper(getServletConfig(), request, response);

    try {

      /*  Register the persistent store with this servlet instance.  */
      PersistentStore ps = ExternalTechRequestsPersistentStoreFactory.getStore(s_cstrResourceBundle);
      PersistentStore.registerInstance(ps);

      /*  Pass the doGet along.  */
      super.doGet(request, response);
    }
    catch (WrappingException we) {
      helper.reportError(
          "Error accessing database.  Please notify your technical support contact or try again later.\n" +
              we.toString());
      helper.closeSession();
    }

    Logger.traceExit();
  }
}
