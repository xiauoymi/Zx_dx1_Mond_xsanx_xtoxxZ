package com.monsanto.wst.externaltechrequests.servlet;


import java.io.File;


/**
 * <p>Title: I_ExternalTechRequestsSessionParams</p> <p>Description: This will serve for constants for putting proposal
 * session lists</p> <p>Copyright: Copyright (c) 2003</p> <p>Company: Monsanto</p>
 *
 * @author Java Framework Code  Generator 2.4
 * @version $Id: I_SessionParams.java,v 1.4 2007-02-27 19:33:57 kjjohn2 Exp $
 */
public interface I_SessionParams {
  /*  User roles  */
  String sf_cstrSECURITY_GATEKEEPER = "ExternalTechRequestsSecurityGatekeeper";
  String sf_cstrCURRENT_USER = "ExternalTechRequestsUser";

  /*  Directories.  */
  String sf_cstrCONFIG_DIR = "../Config";     // Properties files
  String sf_cstrLINKFILES_DIR = "../linkfiles";  // Files for temp html links
  String sf_cstrIMPORT_DIR = File.separator + "import";        // Uploaded files
  String sf_cstrJAVASCRIPT_DIR = "../JavaScript"; // JavaScript files
  String sf_cstrSTYLESHEET_DIR = "../Stylesheet"; // Stylesheets
  String sf_cstrHTML_DIR = "../html";       // Static html files
  String sf_cstrXML_SCHEMAS_DIR = "";
}
