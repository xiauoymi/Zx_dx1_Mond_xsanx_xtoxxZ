package com.monsanto.wst.externaltechrequests.servlet.test;

import junit.framework.TestCase;
import com.monsanto.wst.externaltechrequests.servlet.ExternalTechRequestsPersistentStoreFactory;
import com.monsanto.wst.externaltechrequests.servlet.ExternalTechRequestsServlet;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType2;

/*
 ExternalTechRequestsPersistentStoreFactory_UT was created on Feb 22, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class ExternalTechRequestsPersistentStoreFactory_UT extends TestCase {
  public void testUsesType2Driver() throws Exception {
    PersistentStore store = ExternalTechRequestsPersistentStoreFactory.getStore(ExternalTechRequestsServlet.s_cstrResourceBundle);
    assertTrue(store instanceof PersistentStoreOracleCachedType2);
  }
}