package com.monsanto.wst.externaltechrequests.servlet.test;

import com.monsanto.wst.externaltechrequests.model.RequestURLGenerator;
import com.monsanto.wst.externaltechrequests.servlet.ExternalTechRequestsServlet;
import junit.framework.TestCase;
/*
 ExternalTechRequestsServlet_UT was created on Feb 20, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class ExternalTechRequestsServlet_UT extends TestCase {
  public void testURLBuilderIsInitiailized() throws Exception {
    MockETRServletForVisibility servlet = new MockETRServletForVisibility();
    servlet.setBaseURL();
    assertNotNull(new RequestURLGenerator(new Long(1)).getUrl());
  }

  private class MockETRServletForVisibility extends ExternalTechRequestsServlet {
    protected void setBaseURL() {
      super.setBaseURL();
    }
  }
}
