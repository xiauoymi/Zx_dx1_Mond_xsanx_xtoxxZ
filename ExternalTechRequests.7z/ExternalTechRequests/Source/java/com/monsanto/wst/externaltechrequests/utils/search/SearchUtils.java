/*
 SerachUtils was created on Nov 16, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.utils.search;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.externaltechrequests.model.RequestResearchType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: SearchUtils.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date:
 * 2007/01/24 19:37:32 $
 *
 * @author ffbrac
 * @version $Revision: 1.8 $
 */
public class SearchUtils {
  private StringBuffer whereCluase = null;
  private static final String AND = " AND ";

  public SearchUtils() {
    whereCluase = new StringBuffer();
    this.whereCluase.append(" WHERE 0=0 ");
  }

  public void addLongValueToWhereCluase(String tableColumnName, Long value) {
    if (value != null && value.longValue() != 0) {
      whereCluase.append(AND).append(tableColumnName).append(" = ").append(value);
    }
  }

  public void addStringValueToWhereCluase(String tableColumnName, String value) {
    if (value != null && !StringUtils.isEmpty(value)) {
      String replacement = value.replaceAll("'", "''");
      whereCluase.append(AND).append(" LOWER(").append(tableColumnName).append(") LIKE LOWER('%")
          .append(replacement.trim()).append("%')");
    }
  }

  public void addDateValueToWhereCluase(String tableColumnName, String startValue, String endValue) {
    if (!StringUtils.isNullOrEmpty(startValue) && !StringUtils.isNullOrEmpty(endValue)) {
      whereCluase.append(AND).append(tableColumnName).append(" BETWEEN TO_DATE('").append(startValue).
          append("', 'MM/DD/YYYY') AND TO_DATE('").
          append(endValue).append("', 'MM/DD/YYYY')");
    }
  }

  public String getWhereCluase() {
    return whereCluase.toString();
  }

  public void setWhereCluase(StringBuffer whereCluase) {
    this.whereCluase = whereCluase;
  }

  public static Map buildHashMapFromList(List requestResearchList) {
    Map map = new HashMap();
    for (int i = 1; i <= requestResearchList.size(); i++) {
      RequestResearchType requestResearch = (RequestResearchType) requestResearchList.get(i - 1);
      requestResearch.setId(new Long(i));
      map.put(new Long(i), requestResearch);
    }
    return map;
  }
}