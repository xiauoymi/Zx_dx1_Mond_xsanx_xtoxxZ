/*
 BaseTestCase was created on Nov 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.utils.testutils;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: BaseTestCase.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-30 15:26:03 $
 *
 * @author ffbrac
 * @version $Revision: 1.5 $
 */

public abstract class BaseTestCase extends TestCase {
    private TestUtils testUtils;

    /**
     * Sets up the environment.
     *
     * @throws Exception - If unable to setup the environment.
     */
    protected void setUp() throws Exception {
        super.setUp();
        testUtils = new TestUtils(new ObjectInspector());
        testUtils.setupContainer();
        testUtils.setupLogging(MainConstants.APPLICATION_NAME);
    }

    /**
     * Tears down the environment.
     *
     * @throws Exception - If unable to tear down the environment.
     */
    protected void tearDown() throws Exception {
        testUtils.tearDownLogging();
        testUtils.tearDownContainer();
        super.tearDown();
    }

    /**
     * Returns the test utils object.
     *
     * @return USSeedPlanningTestUtils - Object containing test utility methods.
     */
    protected TestUtils getTestUtils() {
        return testUtils;
    }


}
