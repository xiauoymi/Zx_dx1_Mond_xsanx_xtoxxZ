/*
 DBTemplateBaseTransactionTestCase was created on Nov 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.utils.testutils;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Filename:    $RCSfile: DBTemplateBaseTransactionTestCase.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-03 20:24:16 $
 *
 * @author ffbrac
 * @version $Revision: 1.5 $
 */
public abstract class DBTemplateBaseTransactionTestCase extends BaseTestCase {
	/**
	 * This method sets up a transaction to be used by a subclass's tests.
	 *
	 * @throws Exception - If unable to setup the transaction.
	 */
	protected void setUp() throws Exception {
		super.setUp();
		Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection connection = DriverManager.getConnection(
      "jdbc:oracle:thin:@devl-dev.monsanto.com:1521:devl", "ext_tech_req_user", "test_1"); //todo - Why is this hardcoded?
//		Connection connection = DriverManager.getConnection(
//			"jdbc:oracle:thin:@dev01.monsanto.com:1521:comgend", "ext_tech_req", "ext_tech_req123");
//    Connection connection = DriverManager.getConnection(
//        "jdbc:oracle:thin:@localhost:1521:XE", "usseedplanning", "usseedplanning_01");
		getTestUtils().setupTransactionManager(connection);
	}

	/**
	 * This method rolls back the transaction so that nothing is committed to the database.
	 *
	 * @throws Exception - If unable to rollback the transaction.
	 */
	protected void tearDown() throws Exception {
		getTestUtils().rollbackTransaction();
		super.tearDown();
	}
}
