package com.monsanto.wst.externaltechrequests.utils.testutils;/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import org.dbunit.DatabaseTestCase;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.ext.oracle.OracleConnection;
import org.dbunit.operation.DatabaseOperation;
import org.xml.sax.InputSource;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * This class is a base TestCase for setting up the environment when doing integration testing against a database.  It
 * utilizes dbunit to setup and tear down data for the test.
 *
 * @author jdpoul
 * @version $Revision: 1.8 $
 */
public abstract class DbUnitBaseTransactionTestCase extends DatabaseTestCase {
  private TestUtils testUtils;
  private Connection connection;
  private String oldMonCryptJv;

  /**
   * This constructor creates a new jdbc connection that will be used by both dbtemplate and dbunit and caches it for
   * the duration of the test.
   */
  public DbUnitBaseTransactionTestCase() {
  }

  /**
   * Sets up the environment.
   *
   * @throws Exception - If unable to setup the environment.
   */
  protected void setUp() throws Exception {
    oldMonCryptJv = System.getProperty("MONCRYPTJV");
    this.connection = getJdbcConnection();
    testUtils = new TestUtils(new ObjectInspector());
    testUtils.setupLogging(MainConstants.APPLICATION_NAME);
    testUtils.setupContainer();
    testUtils.setupTransactionManager(this.connection);
    cleanDatabase();
    try {
      super.setUp();
    } catch (Exception e) {
      testUtils.rollbackTransaction();
      throw e;
    }
  }

  /**
   * Tears down the environment.
   *
   * @throws Exception - If unable to tear down the environment.
   */
  protected void tearDown() throws Exception {
    testUtils.rollbackTransaction();
    testUtils.tearDownContainer();
    testUtils.tearDownLogging();
    System.setProperty("MONCRYPTJV", oldMonCryptJv);
  }

  /**
   * Returns the test utils object.
   *
   * @return USSeedPlanningTestUtils - Object containing test utility methods.
   */
  protected TestUtils getTestUtils() {
    return testUtils;
  }

  /**
   * This method is used by dbunit to obtain the connection.  In this case we are wrapping the connection in order
   * to keep dbunit from committing the transaction.
   *
   * @return IDatabaseConnection - Object representing the database connection.
   * @throws Exception - If unable to return the connection.
   */
  protected IDatabaseConnection getConnection() throws Exception {
    return new OracleConnection(new DBUnitConnectionInterceptor(connection), "ext_tech_req");
  }

  /**
   * This method returns a new jdbc connectionn with autocommit set to false.
   *
   * @return Connection - Object representing the jdbc connection.
   * @throws ClassNotFoundException - If unable to find the oracle drivers.
   * @throws SQLException - If unable to create the connection.
   */
  private Connection getJdbcConnection() throws ClassNotFoundException, SQLException {
    String password = null;
    try {
      password = EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", "srwgrequesttracking", "CipherValue.hex", "KeyValue.hex");
    } catch (EncryptorException e) {
      e.printStackTrace();
    }

    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection connection = DriverManager.getConnection(
        "jdbc:oracle:thin:@devl-dev.monsanto.com:1521:devl", "ext_tech_req_user", "test_1"); //todo why is this hardcoded?
//		Connection connection = DriverManager.getConnection(
//			"jdbc:oracle:thin:@dev01.monsanto.com:1521:comgend", "ext_tech_req", "ext_tech_req123");
//    Connection connection = DriverManager.getConnection(
//        "jdbc:oracle:thin:@localhost:1521:XE", "usseedplanning", "usseedplanning_01");
    connection.setAutoCommit(false);
    return connection;
  }

  /**
   * This method returns the setup operation used by dbunit, ie. insert setup data.
   *
   * @return DatabaseOperation - Object representing the setup operation.
   * @throws Exception - If unable to setup data.
   */
  protected DatabaseOperation getSetUpOperation()
      throws Exception {
    return DatabaseOperation.INSERT;
  }

  /**
   * This method returns the tear down operation used by dbunit, ie. delete inserted records.
   *
   * @return DatabaseOperation - Object representing the tear down operation.
   * @throws Exception - If unable to setup data.
   */
  protected DatabaseOperation getTearDownOperation()
      throws Exception {
    return DatabaseOperation.NONE;
  }

  /**
   * This method is the abstract method used to determine the location of the dbunit configuration file.
   *
   * @return String - Representing the path to the config file.
   */
  protected abstract String getConfigPath();

  /**
   * This method is the abstract method used to clean up any existing data in the database.  Any deletes that are done
   * in this method (as long as they are using the current transaction) will be rollback when the tests have completed.
   */
  protected abstract void cleanDatabase();

  /**
   * This method returns the data set that should be processed by dbunit.
   *
   * @return IDataSet - Object representing the data set.
   * @throws Exception - If unable to retrieve the data set.
   */
  protected IDataSet getDataSet() throws Exception {
    File file = new ResourceUtils().convertPathToFile(getConfigPath());
    InputSource in = new InputSource(file.getAbsolutePath());
    return new FlatXmlDataSet(in);
  }
}