/*
 TestUtils was created on Nov 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.utils.testutils;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.testutils.JavaBeanTestUtils;
import com.monsanto.wst.dbtemplate.factory.AbstractTransactionManagerFactory;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;
import com.monsanto.wst.dbtemplate.transaction.persistentstore.mock.MockPersistentStoreTransactionManager;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.BeanInitializationException;
import com.monsanto.wst.factory.GenericFactory;

import java.io.FileNotFoundException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;

/**
 * Filename:    $RCSfile: TestUtils.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.9 $
 */

/**
 * Created by IntelliJ IDEA. Date: Sep 6, 2006 Time: 7:09:07 AM <p/> This class represents utility methods for helping
 * in the testing of objects within the US Seed Planning project.
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class TestUtils extends JavaBeanTestUtils {
//  private String oldMonCryptJv = null;

  /**
   * This constructor takes all dependencies.
   *
   * @param objectInspector ObjectInspector object for inspecting objects.
   */
  public TestUtils(ObjectInspector objectInspector) {
    super(objectInspector);
  }

  /**
   * This method sets up the application container for integration/acceptance tests that use the container.
   */
  public void setupContainer() {
    AbstractGenericFactory.clear();
    AbstractGenericFactory
        .setImplementation("com.monsanto.wst.externaltechrequests.container.test.mock.MockApplicationContainer");
  }

  /**
   * This method sets up a transaction manager given the specified jdbc connection.
   *
   * @param connection - Connection object representing the jdbc connection.
   *
   * @exception WrappingException - If unable to setup connection.
   */
  public void setupTransactionManager(Connection connection) throws WrappingException {
    GenericFactory container = AbstractGenericFactory.getInstance();
    TransactionManager txManager = new MockPersistentStoreTransactionManager(connection);
    container.addBean("transactionManager", txManager, true);
  }

  /**
   * This method sets up a transaction manager used with dbtemplate.
   *
   * @exception FileNotFoundException - If unable to find the data source config file.
   */
  public void setupTransactionManager() {
    GenericFactory container = AbstractGenericFactory.getInstance();
//    oldMonCryptJv = System.getProperty("MONCRYPTJV");
//    System.setProperty("MONCRYPTJV", new ResourceUtils().convertPathToFile("database").getAbsolutePath());
    String config = (String) container.getBean("dataSourceConfigFile");
    AbstractTransactionManagerFactory txManagerFactory = AbstractTransactionManagerFactory.newInstance(config);
    TransactionManager txManager = txManagerFactory.getTransactionManager();
    container.addBean("transactionManager", txManager, true);
  }

  /**
   * This method rolls back the current transaction.
   */
  public void rollbackTransaction() {
    try {
      GenericFactory container = AbstractGenericFactory.getInstance();
      TransactionManager txManager = (TransactionManager) container.getBean("transactionManager");
      txManager.rollbackTransaction();
//      if (oldMonCryptJv != null) {
//        System.setProperty("MONCRYPTJV", oldMonCryptJv);
//      }
    } catch (BeanInitializationException e) {
      if (Logger.isEnabled(Logger.DEBUG_LOG)) {
        Logger.log(new DebugLogEvent("The transaction manager was never setup."));
      }
    } catch (IllegalArgumentException e) {
      if (Logger.isEnabled(Logger.DEBUG_LOG)) {
        Logger.log(new DebugLogEvent("The application container was never setup."));
      }
    }
  }

  /**
   * This method tears down the container, clearing it and removing the system property.
   */
  public void tearDownContainer() {
    AbstractGenericFactory.clear();
  }

  public static void verifyAllConstructorsWorkForException(Class exceptionClass) throws NoSuchMethodException,
      IllegalAccessException, InvocationTargetException, InstantiationException {
    Class[] noArg = {};
    Class[] stringArg = {String.class};
    Class[] throwableArg = {Throwable.class};
    Class[] stringAndThrowableArg = {String.class, Throwable.class};

    Object[] noArgValues = {};
    Object[] stringArgValues = {"Test"};
    Object[] throwableArgValues = {new RuntimeException()};
    Object[] stringAndThrowableArgValues = {"Test", new RuntimeException()};

    Class[][] constructros = {noArg, stringArg, throwableArg, stringAndThrowableArg};
    Object[][] values = {noArgValues, stringArgValues, throwableArgValues, stringAndThrowableArgValues};

    for (int i = 0; i < constructros.length; i++) {
      Class[] constructorParams = constructros[i];
      Object[] constructorValues = values[i];
      String msg = getStringForConstructorCall(exceptionClass, constructorParams);
      Constructor constructor;
      try {
        constructor = exceptionClass.getConstructor(constructorParams);
      } catch (NoSuchMethodException e) {
        throw new NoSuchMethodException("Constructor does not exist: " + msg);
      }

      callConstructor(constructor, constructorValues, msg);
    }
  }

  private static void callConstructor(Constructor constructor, Object[] constructorValues, String msg) throws
      IllegalAccessException, InvocationTargetException, InstantiationException {
    try {
      constructor.newInstance(constructorValues);
    } catch (IllegalAccessException e) {
      throw new IllegalAccessException("IllegalAccessException on : " + msg);
    } catch (InvocationTargetException e) {
      throw new InvocationTargetException(e, "InvocationTargetException on : " + msg);
    } catch (InstantiationException e) {
      e.printStackTrace();
      throw new InstantiationException("InstantiationException on : " + msg);
    }
  }

  private static String getStringForConstructorCall(Class exceptionClass, Class[] constructorParams) {
    StringBuffer msg = new StringBuffer(exceptionClass.getName());
    msg.append('(');
    for (int j = 0; j < constructorParams.length; j++) {
      if (j > 0) {
        msg.append(',');
      }
      msg.append(constructorParams[j].getName());
    }
    msg.append(')');
    return msg.toString();
  }
}
