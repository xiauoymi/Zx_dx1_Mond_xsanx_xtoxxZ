/*
 BaseTestCase_UT was created on Nov 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.utils.testutils.test;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.externaltechrequests.container.test.mock.MockApplicationContainer;
import com.monsanto.wst.externaltechrequests.utils.testutils.BaseTestCase;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.XMLGenericFactory;

/**
 * Filename:    $RCSfile: BaseTestCase_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date:
 * 2006/11/13 20:02:37 $
 *
 * @author ffbrac
 * @version $Revision: 1.7 $
 */
public class BaseTestCase_UT extends BaseTestCase {
  protected void tearDown() throws Exception {
    super.tearDown();
    assertFalse(Logger.isEnabled(Logger.DEBUG_LOG));
    AbstractGenericFactory.setContext("com/monsanto/wst/factory/test/context.xml");
    assertEquals(XMLGenericFactory.class, AbstractGenericFactory.getInstance().getClass());
  }

  public void testSetUp() throws Exception {
    assertTrue(Logger.isEnabled(Logger.DEBUG_LOG));
    assertEquals(MockApplicationContainer.class, AbstractGenericFactory.getInstance().getClass());
    assertNotNull(getTestUtils());
  }
}
