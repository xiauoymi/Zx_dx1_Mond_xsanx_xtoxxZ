/*
 DBTemplateBaseTransactionTestCase_UT was created on Nov 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.utils.testutils.test;

import com.monsanto.wst.dbtemplate.transaction.test.mock.MockTransactionManager;
import com.monsanto.wst.externaltechrequests.utils.testutils.DBTemplateBaseTransactionTestCase;
import com.monsanto.wst.factory.AbstractGenericFactory;

/**
 * Filename:    $RCSfile: DBTemplateBaseTransactionTestCase_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-09 20:06:08 $
 *
 * @author ffbrac
 * @version $Revision: 1.4 $
 */
public class DBTemplateBaseTransactionTestCase_UT extends DBTemplateBaseTransactionTestCase {
    protected void tearDown() throws Exception {
        MockTransactionManager txManager = new MockTransactionManager();
        AbstractGenericFactory.getInstance().addBean("transactionManager", txManager, false);
        super.tearDown();
        assertTrue(txManager.isRolledBack());
    }

    public void testSetUpCreatesTransactionManager() throws Exception {
        assertNotNull(AbstractGenericFactory.getInstance().getBean("transactionManager"));
    }
}
