/*
 TestUtils_UT was created on Nov 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.utils.testutils.test;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.externaltechrequests.container.test.mock.MockApplicationContainer;
import com.monsanto.wst.externaltechrequests.utils.testutils.TestUtils;
import com.monsanto.wst.factory.AbstractGenericFactory;
import com.monsanto.wst.factory.GenericFactoryInitializationException;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: TestUtils_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date:
 * 2006/11/28 15:22:26 $
 *
 * @author ffbrac
 * @version $Revision: 1.12 $
 */
public class TestUtils_UT extends TestCase {
  public void testCreate() throws Exception {
    TestUtils testUtils = new TestUtils(new ObjectInspector());
    assertNotNull(testUtils);
  }

  public void testSetupContainer() throws Exception {
    TestUtils testUtils = new TestUtils(new ObjectInspector());
    testUtils.setupContainer();
    try {
      assertEquals(MockApplicationContainer.class, AbstractGenericFactory.getInstance().getClass());
    } finally {
      testUtils.tearDownContainer();
    }
  }

  public void testTearDownContainer() throws Exception {
    TestUtils testUtils = new TestUtils(new ObjectInspector());
    testUtils.setupContainer();
    testUtils.tearDownContainer();
    try {
      AbstractGenericFactory.getInstance().getClass();
      fail("This should have thrown an exception.");
    } catch (GenericFactoryInitializationException e) {
    }
  }

  public void testRollbackTransactionWhenNoTransaction() throws Exception {
    TestUtils testUtils = new TestUtils(new ObjectInspector());
    testUtils.setupContainer();
    testUtils.setupLogging("ExternalTechRequests");
    Logger.enableLogger(Logger.DEBUG_LOG);
    testUtils.rollbackTransaction();

    Logger.disableLogger(Logger.DEBUG_LOG);
    testUtils.rollbackTransaction();
  }

  public void testRollbackTransactionWhenNoApplicationContainer() throws Exception {
    TestUtils testUtils = new TestUtils(new ObjectInspector());
    AbstractGenericFactory.clear();
    System.setProperty("com.monsanto.wst.factory.AbstractGenericFactory", "");
    testUtils.setupLogging("ExternalTechRequests");
    Logger.enableLogger(Logger.DEBUG_LOG);
    AbstractGenericFactory.setContext("com/monsanto/wst/factory/test/context.xml");
    testUtils.rollbackTransaction();

    Logger.disableLogger(Logger.DEBUG_LOG);
    testUtils.rollbackTransaction();
  }
}
