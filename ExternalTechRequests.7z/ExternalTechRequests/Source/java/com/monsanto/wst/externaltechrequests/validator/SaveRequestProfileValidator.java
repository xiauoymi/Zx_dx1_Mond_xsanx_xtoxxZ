/*
 SaveRequestProfileValidator was created on Nov 9, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.validator;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.Util.date.DateUtil;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpValidator;

import java.io.IOException;


/**
 * Filename:    $RCSfile: SaveRequestProfileValidator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-16 23:18:04 $
 *
 * @author ffbrac
 * @version $Revision: 1.12 $
 */
public class SaveRequestProfileValidator implements HttpValidator {


  public HttpRequestErrors validate(UCCHelper helper) throws IOException {
    HttpRequestErrors errors = new HttpRequestErrors();

    validateRequestorNameValue(helper.getRequestParameterValue("requestor_name"), errors);
    validateDateNeededByValue(helper.getRequestParameterValue("date_neededby"), errors);
    validateDateRequestedValue(helper.getRequestParameterValue("date_requested"), errors);
    return errors;
  }

  private void validateRequestorNameValue(String requestorName, HttpRequestErrors errors) {
    if (StringUtils.isNullOrEmpty(requestorName)){
      errors.addError("requestorName", "Requestor/Contact Name is required.");
    }
  }

  private void validateDateRequestedValue(String dateRequested, HttpRequestErrors errors) {
    if (isOptionalDateParameterInvalid(dateRequested)) {
      errors.addError("date_requested","Date Requested field is incorrect. Format:mm/dd/yyyy");
    }
  }

  private void validateDateNeededByValue(String dateNeededBy, HttpRequestErrors errors) {
    if (isOptionalDateParameterInvalid(dateNeededBy)) {
      errors.addError("date_neededby","Date Needed By field is incorrect. Format:mm/dd/yyyy");
    }
  }

  private boolean isOptionalDateParameterInvalid(String dateRequested) {
    return IsNotEmpty(dateRequested) && isNotFormattedCorrectly(dateRequested);
  }

  private boolean isNotFormattedCorrectly(String dateNeededBy) {
    return !DateUtil.isDateStringFormattedCorrectly(dateNeededBy, "MM/dd/yyyy");
  }

  private boolean IsNotEmpty(String dateNeededBy) {
    return !StringUtils.isNullOrEmpty(dateNeededBy);
  }


}