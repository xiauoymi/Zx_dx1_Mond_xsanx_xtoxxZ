/*
 SearchRequestProfileValidator was created on Nov 28, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.validator;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.validator.HttpRequestErrors;
import com.monsanto.wst.validator.HttpValidator;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Filename:    $RCSfile: SearchRequestProfileValidator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-28 21:36:38 $
 *
 * @author ffbrac
 * @version $Revision: 1.5 $
 */
public class SearchRequestProfileValidator implements HttpValidator {
  public HttpRequestErrors validate(UCCHelper helper) throws IOException {
    HttpRequestErrors errors = new HttpRequestErrors();
    validateDateRange(helper, errors, "request_date_incomplete", "start_date", "end_date",
        "You need to enter From and To dates.",
        "Request Date From field is incorrect. Format:mm/dd/yyyy",
        "Request Date To field is incorrect. Format:mm/dd/yyyy");
    validateDateRange(helper, errors, "committee_date_incomplete", "committee_start_date", "committee_end_date",
        "You need to enter From and To dates.",
        "Committe Approval Date From field is incorrect. Format:mm/dd/yyyy",
        "Committe Approval To field is incorrect. Format:mm/dd/yyyy");
    return errors;
  }

  private void validateDateRange(UCCHelper helper, HttpRequestErrors errors, String dateTypeKey, String dateKey1,
                                 String dateKey2, String messageDateType, String messageDate1,
                                 String messageDate2) throws IOException {

    String startDate = helper.getRequestParameterValue(dateKey1);
    String endDate = helper.getRequestParameterValue(dateKey2);

    if (isDateRangeInvalid(startDate, endDate)) {
      errors.addError(dateTypeKey, messageDateType);
    }
    if (isDateInvalid(startDate)) {
      errors.addError(dateKey1, messageDate1);
    }
    if (isDateInvalid(endDate)) {
      errors.addError(dateKey2, messageDate2);
    }
  }

  private boolean isDateInvalid(String date) {
    if (StringUtils.isNullOrEmpty(date)) {
      return false;
    } else {
      return !validateDate(date);
    }
  }

  private boolean isDateRangeInvalid(String startDate, String endDate) {
    return !StringUtils.isNullOrEmpty(startDate) == StringUtils.isNullOrEmpty(endDate);
  }

  private boolean validateDate(String date) {
    try {
      SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
      formatter.setCalendar(Calendar.getInstance());
      formatter.parse(date);
      return true;
    } catch (ParseException pe) {
      return false;
    }
  }
}