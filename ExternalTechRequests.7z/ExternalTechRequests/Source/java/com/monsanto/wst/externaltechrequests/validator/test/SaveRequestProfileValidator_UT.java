/*
 SaveRequestProfileValidator_UT was created on Nov 9, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.validator.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.externaltechrequests.validator.SaveRequestProfileValidator;
import com.monsanto.wst.validator.HttpRequestErrors;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: SaveRequestProfileValidator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: jdpoul $
 * On:	$Date: 2007-01-22 18:37:15 $
 *
 * @author ffbrac
 * @version $Revision: 1.8 $
 */
public class SaveRequestProfileValidator_UT extends TestCase {

  protected void setUp() throws Exception {
    super.setUp();
  }

  public void testCreate() throws Exception {
    SaveRequestProfileValidator validator = new SaveRequestProfileValidator();
    assertNotNull(validator);
  }

  public void testValidateWithErrors() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("date_requested", "01-01-2006");
    helper.setRequestParameterValue("date_neededby", "01-01-2006");
    SaveRequestProfileValidator validator = new SaveRequestProfileValidator();
    HttpRequestErrors errors = validator.validate(helper);
    assertEquals("Requestor/Contact Name is required.", errors.getError("requestorName"));
    assertEquals("Date Requested field is incorrect. Format:mm/dd/yyyy", errors.getError("date_requested"));
    assertEquals("Date Needed By field is incorrect. Format:mm/dd/yyyy", errors.getError("date_neededby"));
  }

  public void testValidateWithNoErrors() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    SaveRequestProfileValidator validator = new SaveRequestProfileValidator();
    helper.setRequestParameterValue("request_number", "test");
    helper.setRequestParameterValue("requestor_name", "test");
    helper.setRequestParameterValue("date_requested", "01/01/2006");
    helper.setRequestParameterValue("date_neededby", "01/01/2006");
    HttpRequestErrors errors = validator.validate(helper);
    assertEquals(true, errors.isEmpty());
  }

  public void testValidateWithNoErrorsEmptyStringDateRequested() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    SaveRequestProfileValidator validator = new SaveRequestProfileValidator();
    helper.setRequestParameterValue("request_number", "test");
    helper.setRequestParameterValue("requestor_name", "test");
    helper.setRequestParameterValue("date_requested", "");
    helper.setRequestParameterValue("date_neededby", "1/1/2006");
    HttpRequestErrors errors = validator.validate(helper);
    assertEquals(true, errors.isEmpty());
  }

  public void testValidateWithNoErrorsEmptyStringDateNeeded() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    SaveRequestProfileValidator validator = new SaveRequestProfileValidator();
    helper.setRequestParameterValue("request_number", "test");
    helper.setRequestParameterValue("requestor_name", "test");
    helper.setRequestParameterValue("date_requested", "1/1/2006");
    helper.setRequestParameterValue("date_neededby", "");
    HttpRequestErrors errors = validator.validate(helper);
    assertEquals(true, errors.isEmpty());
  }
}