/*
 SearchRequestProfileValidator_UT was created on Nov 28, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.validator.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.externaltechrequests.validator.SearchRequestProfileValidator;
import com.monsanto.wst.validator.HttpRequestErrors;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: SearchRequestProfileValidator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-09 20:06:08 $
 *
 * @author ffbrac
 * @version $Revision: 1.3 $
 */
public class SearchRequestProfileValidator_UT extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testCreate() throws Exception {
		SearchRequestProfileValidator validator = new SearchRequestProfileValidator();
		assertNotNull(validator);
	}
	public void testValidateWithErrors() throws Exception {
		MockUCCHelper helper = new MockUCCHelper(null);
		helper.setRequestParameterValue("start_date", "01-01-2006");
		SearchRequestProfileValidator validator = new SearchRequestProfileValidator();
		HttpRequestErrors errors = validator.validate(helper);
		assertEquals("You need to enter From and To dates.", errors.getError("request_date_incomplete"));
		assertEquals("Request Date From field is incorrect. Format:mm/dd/yyyy", errors.getError("start_date"));
	}
	public void testValidateWithNoErrors() throws Exception {
		MockUCCHelper helper = new MockUCCHelper(null);
		SearchRequestProfileValidator validator = new SearchRequestProfileValidator();
		helper.setRequestParameterValue("start_date", "01/01/2006");
		helper.setRequestParameterValue("end_date", "01/01/2006");
		helper.setRequestParameterValue("committee_start_date", "01/01/2006");
		helper.setRequestParameterValue("committee_end_date", "01/01/2006");
		HttpRequestErrors errors = validator.validate(helper);
		assertEquals(true, errors.isEmpty());
	}
}