/*
 ViewFactoryImpl was created on Oct 31, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.view.factory;

import com.monsanto.wst.externaltechrequests.view.jsp.*;
import com.monsanto.wst.view.View;

/**
 * Filename:    $RCSfile: ViewFactoryImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-02-16 22:18:56 $
 *
 * @author ffbrac
 * @version $Revision: 1.23 $
 */
public class ViewFactoryImpl implements ViewFactory{
	public View getHomePageView() {
		return new JspHomeView();
	}

  public View getRequestView() {
    return new JspRequestView();
  }
	public View getSearchRequestProfileView() {
		return new JspSearchRequestView();
	}

	public View getAddResearchTypeView() {
		return new JspAddResearchTypeView();
	}

	public View getDisplayHistoryView() {
		return new JspDisplayHistoryView();
	}

  public View getuserAdministrationView() {
    return new JspUserAdministrationView();
  }

	public View getErrorsView() {
		return new JspErrorsView();
	}

  public View getEditUserView() {
    return new JspEditUserView(); 
  }

  public View getNewUserView() {
    return new JspNewUserView();
  }

  public View getCreateLegalAttachmentView() {
    return new JspCreateLegalAttachmentView();
  }

  public View getAttachLegalView() {
    return new JspAttachLegalView(); 
  }

  public View getCreateShippingAttachmentView() {
    return new JspCreateShippingAttachmentView();
  }

  public View getAttachShippingView() {
    return new JspAttachShippingView();
  }

  public View getAttachmentView() {
    return new JspAttachmentView();
  }

  public View getReviewView() {
    return new JspReviewView();
  }

  public View getCommitteeView() {
    return new JspCommitteeView();
  }

  public View getStatusView() {
    return new JspStatusView(); 
  }

  public View getEditAttachmentView() {
    return new JspEditAttachmentView();
  }

  public View getReadonlyRequestView() {
    return new JspReadonlyRequestView();
  }
}