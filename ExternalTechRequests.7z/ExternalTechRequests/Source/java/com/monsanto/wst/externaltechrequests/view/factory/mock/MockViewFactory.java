/*
 MockViewFactory was created on Oct 31, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.view.factory.mock;

import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.test.mock.MockView;

/**
 * Filename:    $RCSfile: MockViewFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.23 $
 */
public class MockViewFactory implements ViewFactory {
  private final View homePageView = new MockView();
  private final View requestView = new MockView();
  private final View searchRequestView = new MockView();
  private final View addResearchTypeView = new MockView();
  private final View displayHistoryView = new MockView();
  private final View errorsView = new MockView();
  private final View userAdminView = new MockView();
  private final View editUserView = new MockView();
  private final View newUserView = new MockView();
  private final View createLegalView = new MockView();
  private final View attachLegalView = new MockView();
  private final View createShippingView = new MockView();
  private final View attachShippingView = new MockView();
  private final View attachmentView = new MockView();
  private final View reviewView = new MockView();
  private final View committeeView = new MockView();
  private final View statusView = new MockView();
  private final View editAttachmentView = new MockView();
  private final View readOnlyRequestView = new MockView();

  public View getHomePageView() {
    return this.homePageView;
  }

  public View getRequestView() {
    return this.requestView;
  }

  public View getSearchRequestProfileView() {
    return this.searchRequestView;
  }

  public View getAddResearchTypeView() {
    return this.addResearchTypeView;
  }

  public View getDisplayHistoryView() {
    return this.displayHistoryView;
  }

  public View getErrorsView() {
    return this.errorsView;
  }

  public View getuserAdministrationView() {
    return this.userAdminView;
  }

  public View getEditUserView() {
    return this.editUserView;
  }

  public View getNewUserView() {
    return this.newUserView;
  }

  public View getCreateLegalAttachmentView() {
    return this.createLegalView;
  }

  public View getAttachLegalView() {
    return this.attachLegalView;
  }

  public View getCreateShippingAttachmentView() {
    return this.createShippingView;
  }

  public View getAttachShippingView() {
    return this.attachShippingView;
  }

  public View getAttachmentView() {
    return this.attachmentView;
  }

  public View getReviewView() {
    return this.reviewView;
  }

  public View getCommitteeView() {
    return this.committeeView;
  }

  public View getStatusView() {
    return this.statusView;
  }

  public View getEditAttachmentView() {
    return this.editAttachmentView;
  }

  public View getReadonlyRequestView() {
    return this.readOnlyRequestView;
  }

}