/*
 ViewFactoryImpl_UT was created on Oct 31, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.view.factory.test;

import com.monsanto.wst.externaltechrequests.view.factory.ViewFactory;
import com.monsanto.wst.externaltechrequests.view.factory.ViewFactoryImpl;
import com.monsanto.wst.externaltechrequests.view.jsp.*;
import com.monsanto.wst.view.View;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ViewFactoryImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-02-09 21:26:29 $
 *
 * @author ffbrac
 * @version $Revision: 1.10 $
 */
public class ViewFactoryImpl_UT extends TestCase {
	public void testCreate() throws Exception {
		ViewFactory factory = new ViewFactoryImpl();
		assertNotNull(factory);
	}
	public void testHomePageView() throws Exception {
		ViewFactory factory = new ViewFactoryImpl();
		View view = factory.getHomePageView();
		assertNotNull(view);
		assertEquals(JspHomeView.class, view.getClass());
	}
	public void testRequestView() throws Exception {
		ViewFactory factory = new ViewFactoryImpl();
		View view = factory.getRequestView();
		assertNotNull(view);
		assertEquals(JspRequestView.class, view.getClass());
	}
	public void testSearchRequestProfileView() throws Exception {
		ViewFactory factory = new ViewFactoryImpl();
		View view = factory.getSearchRequestProfileView();
		assertNotNull(view);
		assertEquals(JspSearchRequestView.class, view.getClass());
	}
	public void testAddResearchTypeView() throws Exception {
		ViewFactory factory = new ViewFactoryImpl();
		View view = factory.getAddResearchTypeView();
		assertNotNull(view);
		assertEquals(JspAddResearchTypeView.class, view.getClass());
	}
	public void testDisplayHistoryView() throws Exception {
		ViewFactory factory = new ViewFactoryImpl();
		View view = factory.getDisplayHistoryView();
		assertNotNull(view);
		assertEquals(JspDisplayHistoryView.class, view.getClass());
	}
	public void testErrorsView() throws Exception {
		ViewFactory factory = new ViewFactoryImpl();
		View view = factory.getErrorsView();
		assertNotNull(view);
		assertEquals(JspErrorsView.class, view.getClass());
	}
  public void testStatusView() throws Exception {
    ViewFactory factory = new ViewFactoryImpl();
    View view = factory.getStatusView();
    assertNotNull(view);
    assertEquals(JspStatusView.class, view.getClass());
  }
}