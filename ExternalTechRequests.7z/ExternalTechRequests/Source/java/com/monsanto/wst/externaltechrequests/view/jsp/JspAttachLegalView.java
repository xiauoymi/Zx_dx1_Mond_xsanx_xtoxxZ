package com.monsanto.wst.externaltechrequests.view.jsp;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;

import java.io.IOException;
/*
 JspAttachLegalView was created on Jan 23, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class JspAttachLegalView implements View {
  public void renderView(UCCHelper helper) throws ViewRenderingException {
		try {
			helper.forward(MainConstants.ATTACH_LEGAL_PAGE);
		} catch (IOException e) {
			if (Logger.isEnabled(Logger.ERROR_LOG)) {
				Logger.log(new LoggableError(e));
			}
			throw new ViewRenderingException("Unable to render jsp view of Attach Legal Document Page.", e);
		}
	}
}
