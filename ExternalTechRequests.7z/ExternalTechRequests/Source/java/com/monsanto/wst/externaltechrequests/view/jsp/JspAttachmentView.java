package com.monsanto.wst.externaltechrequests.view.jsp;

import com.monsanto.wst.externaltechrequests.constants.MainConstants;
/*
 JspAttachmentView was created on Feb 6, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class JspAttachmentView extends JspView {
  protected String getPagePath() {
    return MainConstants.ATTACHMENT_PAGE;
  }

  protected String getPageDescription() {
    return "Attachment";
  }
}
