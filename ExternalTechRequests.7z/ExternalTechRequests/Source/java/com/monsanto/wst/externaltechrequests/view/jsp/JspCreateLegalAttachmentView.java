package com.monsanto.wst.externaltechrequests.view.jsp;

import com.monsanto.wst.externaltechrequests.constants.MainConstants;
/*
 JspCreateLegalAttachmentView was created on Jan 23, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class JspCreateLegalAttachmentView extends JspView {
  protected String getPagePath() {
    return MainConstants.CREATE_LEGAL_PAGE;
  }

  protected String getPageDescription() {
    return "Create Legal Attachment";
  }
}
