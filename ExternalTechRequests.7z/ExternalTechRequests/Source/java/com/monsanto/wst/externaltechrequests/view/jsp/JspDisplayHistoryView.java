/*
 JspDisplayHistoryView was created on Nov 21, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.view.jsp;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;

import java.io.IOException;

/**
 * Filename:    $RCSfile: JspDisplayHistoryView.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2007-02-27 19:33:58 $
 *
 * @author ffbrac
 * @version $Revision: 1.6 $
 */
public class JspDisplayHistoryView implements View {
  public void renderView(UCCHelper helper) throws ViewRenderingException {
    try {
      helper.forward(MainConstants.DISPLAY_HISTORY);
    } catch (IOException e) {
      if (Logger.isEnabled(Logger.ERROR_LOG)) {
        Logger.log(new LoggableError(e));
      }
      throw new ViewRenderingException("Unable to render jsp view of Display History Page.", e);
    }
  }

}