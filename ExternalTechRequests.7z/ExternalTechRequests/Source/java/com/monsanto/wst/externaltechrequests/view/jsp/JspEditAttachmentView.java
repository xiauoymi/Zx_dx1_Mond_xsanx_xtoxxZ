package com.monsanto.wst.externaltechrequests.view.jsp;

import com.monsanto.wst.externaltechrequests.constants.MainConstants;
/*
 JspEditAttachmentView was created on Feb 12, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class JspEditAttachmentView extends JspView {
  protected String getPagePath() {
    return MainConstants.EDIT_ATTACHMENT_PAGE;
  }

  protected String getPageDescription() {
    return "Edit Attachment";
  }
}
