/*
 JspRequestView was created on Nov 7, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.view.jsp;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;

import java.io.IOException;

/**
 * Filename:    $RCSfile: JspRequestView.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date:
 * 2007/01/09 20:06:08 $
 *
 * @author ffbrac
 * @version $Revision: 1.5 $
 */
public class JspRequestView implements View {
  public void renderView(UCCHelper helper) throws ViewRenderingException {
    try {
      helper.forward(MainConstants.REQUEST_PAGE);
    } catch (IOException e) {
      if (Logger.isEnabled(Logger.ERROR_LOG)) {
        Logger.log(new LoggableError(e));
      }
      throw new ViewRenderingException("Unable to render jsp view of Request Page.", e);
    }
  }
}