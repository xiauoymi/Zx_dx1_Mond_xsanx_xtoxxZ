package com.monsanto.wst.externaltechrequests.view.jsp;

import com.monsanto.wst.externaltechrequests.constants.MainConstants;
/*
 JspReviewView was created on Feb 7, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class JspReviewView extends JspView {
  protected String getPagePath() {
    return MainConstants.REVIEW_PAGE;
  }

  protected String getPageDescription() {
    return "Review";
  }
}
