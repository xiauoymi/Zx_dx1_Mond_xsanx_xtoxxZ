package com.monsanto.wst.externaltechrequests.view.jsp;

import com.monsanto.wst.externaltechrequests.constants.MainConstants;
/*
 JspStatusView was created on Feb 9, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class JspStatusView extends JspView {
  protected String getPagePath() {
    return MainConstants.STATUS_PAGE; 
  }

  protected String getPageDescription() {
    return "Admin Status Edit";
  }
}
