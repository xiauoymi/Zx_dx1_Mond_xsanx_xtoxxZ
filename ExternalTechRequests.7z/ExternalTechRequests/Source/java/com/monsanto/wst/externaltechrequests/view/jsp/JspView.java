package com.monsanto.wst.externaltechrequests.view.jsp;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;

import java.io.IOException;
/*
 JspView was created on Feb 6, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public abstract class JspView implements View {
  public void renderView(UCCHelper helper) throws ViewRenderingException {
    try {
      helper.forward(getPagePath());
    } catch (IOException e) {
      if (Logger.isEnabled(Logger.ERROR_LOG)) {
        Logger.log(new LoggableError(e));
      }
      throw new ViewRenderingException("Unable to render jsp view of " + getPageDescription() + " Page.", e);
    }
  }

  protected abstract String getPagePath();
  protected abstract String getPageDescription();
}
