package com.monsanto.wst.externaltechrequests.view.jsp.test;

import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.view.jsp.JspAttachLegalView;
import com.monsanto.wst.view.View;

/*
 JspAttachLegalView_UT was created on Jan 29, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class JspAttachLegalView_UT extends JspViewTestCase {
  protected View getView() {
    return new JspAttachLegalView();
  }

  protected String getExpectedPage() {
    return MainConstants.ATTACH_LEGAL_PAGE;
  }
}