package com.monsanto.wst.externaltechrequests.view.jsp.test;

import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.view.jsp.JspCreateLegalAttachmentView;
import com.monsanto.wst.view.View;

/*
 JspCreateLegalAttachmentView_UT was created on Jan 29, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class JspCreateLegalAttachmentView_UT extends JspViewTestCase {
  protected View getView() {
    return new JspCreateLegalAttachmentView();
  }

  protected String getExpectedPage() {
    return MainConstants.CREATE_LEGAL_PAGE;
  }
}