/*
 JspDisplayHistoryView_UT was created on Nov 21, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.view.jsp.test;

import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.view.jsp.JspDisplayHistoryView;
import com.monsanto.wst.view.View;

/**
 * Filename:    $RCSfile: JspDisplayHistoryView_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-29 16:29:47 $
 *
 * @author ffbrac
 * @version $Revision: 1.5 $
 */
public class JspDisplayHistoryView_UT extends JspViewTestCase {
  protected View getView() {
    return new JspDisplayHistoryView();
  }

  protected String getExpectedPage() {
    return MainConstants.DISPLAY_HISTORY;
  }
}