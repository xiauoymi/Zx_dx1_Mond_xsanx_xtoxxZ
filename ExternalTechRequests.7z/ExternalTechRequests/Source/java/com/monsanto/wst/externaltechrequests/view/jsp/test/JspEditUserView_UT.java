package com.monsanto.wst.externaltechrequests.view.jsp.test;

import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.view.jsp.JspEditUserView;
import com.monsanto.wst.view.View;

/*
 JspEditUserView_UT was created on Jan 29, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class JspEditUserView_UT extends JspViewTestCase {
  protected View getView() {
    return new JspEditUserView();
  }

  protected String getExpectedPage() {
    return MainConstants.EDIT_USER_PAGE;
  }
}