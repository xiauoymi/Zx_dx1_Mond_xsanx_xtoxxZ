/*
 JspErrorsView_UT was created on Nov 28, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.externaltechrequests.view.jsp.test;

import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.view.jsp.JspErrorsView;
import com.monsanto.wst.view.View;

/**
 * Filename:    $RCSfile: JspErrorsView_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2007-01-29 16:29:47 $
 *
 * @author ffbrac
 * @version $Revision: 1.3 $
 */
public class JspErrorsView_UT extends JspViewTestCase {
  protected View getView() {
    return new JspErrorsView();
  }

  protected String getExpectedPage() {
    return MainConstants.ERRORS_PAGE;
  }
}