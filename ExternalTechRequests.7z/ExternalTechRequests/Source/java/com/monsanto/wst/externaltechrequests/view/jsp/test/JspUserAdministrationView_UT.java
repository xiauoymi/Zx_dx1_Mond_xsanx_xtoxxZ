package com.monsanto.wst.externaltechrequests.view.jsp.test;

import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.view.jsp.JspUserAdministrationView;
import com.monsanto.wst.view.View;

/*
 JspUserAdministrationView_UT was created on Jan 29, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class JspUserAdministrationView_UT extends JspViewTestCase {
  protected View getView() {
    return new JspUserAdministrationView();
  }

  protected String getExpectedPage() {
    return MainConstants.USER_ADMIN;
  }
}