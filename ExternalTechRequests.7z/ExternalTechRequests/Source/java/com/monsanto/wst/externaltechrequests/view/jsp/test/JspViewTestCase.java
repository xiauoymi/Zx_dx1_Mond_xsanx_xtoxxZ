package com.monsanto.wst.externaltechrequests.view.jsp.test;

import com.monsanto.AbstractLogging.IErrorLog;
import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.Test.MockErrorLog;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.view.View;
import com.monsanto.wst.view.ViewRenderingException;
import junit.framework.TestCase;
/*
 JspViewTestCase was created on Jan 29, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public abstract class JspViewTestCase extends TestCase {
  protected abstract View getView();

  protected abstract String getExpectedPage();

  public void testCreate() {
    View view = getView();
    assertNotNull(view);
  }

  public void testRenderView() {
    View view = getView();
    MockUCCHelper helper = new MockUCCHelper(null);
    view.renderView(helper);
    assertEquals(true, helper.wasSentTo(getExpectedPage()));
  }

  public void testExceptionOnForwardThrowsViewExceptionWithoutLogger() throws LogRegistrationException {
    UCCHelper helper = new MockUCCHelperExceptionOnForward();
    View view = getView();
    Logger.register((IErrorLog) null);
    try {
      view.renderView(helper);
      fail("Expected exception not received");
    } catch (ViewRenderingException IGNORE) {
      // ignore expected exception
    }
  }

  public void testExceptionOnForwardThrowsViewExceptionWithLogger() throws LogRegistrationException {
    MockErrorLog logger = new MockErrorLog();
    Logger.register(logger);
    try {
      UCCHelper helper = new MockUCCHelperExceptionOnForward();
      View view = getView();
      try {
        view.renderView(helper);
        fail("Expected exception not received");
      } catch (ViewRenderingException IGNORE) {
        // ignore expected exception
      }

      assertTrue(logger.hasMessageBeenLoggedStartingWith("java.io.IOException"));
    } finally {
      Logger.register((IErrorLog) null);
    }
  }
}
