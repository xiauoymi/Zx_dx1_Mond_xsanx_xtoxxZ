package com.monsanto.wst.externaltechrequests.view.jsp.test;

import com.monsanto.ServletFramework.Test.MockUCCHelper;

import java.io.IOException;
/*
 MockUCCHelperExceptionOnForward was created on Jan 29, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MockUCCHelperExceptionOnForward extends MockUCCHelper {
  public MockUCCHelperExceptionOnForward() {
    super("MOCK");
  }

  public void forward(String cstrTo) throws IOException {
    throw new IOException("MOCK EXCEPTION");
  }
}
