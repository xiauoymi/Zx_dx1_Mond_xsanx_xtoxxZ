package com.monsanto.wst.externaltechrequests.workflow;

import com.monsanto.wst.dbtemplate.DBTemplate;

import java.util.List;
/*
 DBTemplateEmailConfiguration was created on Jan 31, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class DBTemplateEmailConfiguration implements EmailConfiguration {
  public static final String LEGAL_EMAILS_QUERY = "legalEmails";
  public static final String LEGAL_SUPERVISOR_EMAILS_QUERY = "legalSupervisorEmails";
  public static final String SHIPPING_EMAILS_QUERY = "shippingEmails";
  public static final String COORDINATOR_EMAILS_QUERY = "coordinatorEmails";
  public static final String REVIEWER_EMAILS_QUERY = "reviewerEmails";

  private final DBTemplate template;

  public DBTemplateEmailConfiguration(DBTemplate template) {
    this.template = template;
  }

  public List getLegalEmails() {
    return template.executeListResultQuery(LEGAL_EMAILS_QUERY);
  }

  public List getLegalSupervisorEmails() {
    return template.executeListResultQuery(LEGAL_SUPERVISOR_EMAILS_QUERY);
  }

  public List getShippingEmails() {
    return template.executeListResultQuery(SHIPPING_EMAILS_QUERY);
  }

  public List getCoordinatorEmails() {
    return template.executeListResultQuery(COORDINATOR_EMAILS_QUERY);
  }

  public List getReviewerEmails() {
    return template.executeListResultQuery(REVIEWER_EMAILS_QUERY);
  }
}
