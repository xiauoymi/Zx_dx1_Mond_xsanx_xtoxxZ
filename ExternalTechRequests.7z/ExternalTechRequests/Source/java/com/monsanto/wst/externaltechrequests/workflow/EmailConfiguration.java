package com.monsanto.wst.externaltechrequests.workflow;

import java.util.List;
/*
 EmailConfiguration was created on Jan 30, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public interface EmailConfiguration {
  List getLegalEmails();
  List getLegalSupervisorEmails();
  List getShippingEmails();
  List getCoordinatorEmails();
  List getReviewerEmails();
}
