package com.monsanto.wst.externaltechrequests.workflow;

/*
 EmailException was created on Feb 7, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class EmailException extends Exception {
  public EmailException() {
  }

  public EmailException(String message) {
    super(message);
  }

  public EmailException(String message, Throwable cause) {
    super(message, cause);
  }

  public EmailException(Throwable e) {
    super(e);
  }
}
