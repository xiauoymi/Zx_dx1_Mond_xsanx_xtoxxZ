package com.monsanto.wst.externaltechrequests.workflow;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.template.FileMessageTemplate;
import com.monsanto.wst.commonutils.template.MessageTemplate;
import com.monsanto.wst.emailtemplate.facade.MessageTemplateFactory;

import java.util.HashMap;
import java.util.Map;
/*
 MessageTemplateFactoryImpl was created on Jan 31, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MessageTemplateFactoryImpl implements MessageTemplateFactory {
  private static final String PATH = "com/monsanto/wst/externaltechrequests/workflow/";

  private final Map templates;

  public MessageTemplateFactoryImpl() {
    templates = new HashMap();
    templates.put(StatusUpdateServiceImpl.LEGAL_EMAIL_TEMPLATE_ID, PATH + "legal.email");
    templates.put(StatusUpdateServiceImpl.LEGAL_NOTIFY_TEMPLATE_ID, PATH + "legal_notify.email");
    templates.put(StatusUpdateServiceImpl.SHIPPING_EMAIL_TEMPLATE_ID, PATH + "shipping.email");
    templates.put(StatusUpdateServiceImpl.SPONSOR_NEW_EMAIL_TEMPLATE_ID, PATH + "sponsorNew.email");
    templates.put(StatusUpdateServiceImpl.SPONSOR_PENDING_EMAIL_TEMPLATE_ID, PATH + "sponsorPending.email");
    templates.put(StatusUpdateServiceImpl.SPONSOR_APPROVAL_EMAIL_TEMPLATE_ID, PATH + "sponsorApproval.email");
    templates.put(StatusUpdateServiceImpl.SPONSOR_COORDINATOR_EMAIL_TEMPLATE_ID, PATH + "sponsorCoordinator.email");
    templates.put(StatusUpdateServiceImpl.SPONSOR_REJECTION_EMAIL_TEMPLATE_ID, PATH + "sponsorRejection.email");
    templates.put(StatusUpdateServiceImpl.SPONSOR_LEGAL_REVIEW_COMPLETE_TEMPLATE_ID, PATH + "sponsorLegal.email");
    templates.put(StatusUpdateServiceImpl.SPONSOR_COMPLETE_EMAIL_TEMPLATE_ID, PATH + "sponsorComplete.email");
    templates.put(StatusUpdateServiceImpl.COORDINATOR_COMPLETE_EMAIL_TEMPLATE_ID, PATH + "coordinator.email");
    templates.put(StatusUpdateServiceImpl.COORDINATOR_REVIEW_EMAIL_TEMPLATE_ID, PATH + "coordinatorReview.email");
  }

  public MessageTemplate getTemplateById(String templateId) {
    return loadTemplate(lookupFilename(templateId), new ObjectInspector());
  }

  protected MessageTemplate loadTemplate(String filename, ObjectInspector inspector) {
    return new FileMessageTemplate(filename, inspector);
  }

  private String lookupFilename(String templateId) {
    return (String) templates.get(templateId);
  }
}
