package com.monsanto.wst.externaltechrequests.workflow;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
/*
 RequestEmailer was created on Feb 7, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public interface RequestEmailer {
  void sendRequests(String subject, RequestProfile[] requests, AttachmentService attachmentService) throws EmailException;
}
