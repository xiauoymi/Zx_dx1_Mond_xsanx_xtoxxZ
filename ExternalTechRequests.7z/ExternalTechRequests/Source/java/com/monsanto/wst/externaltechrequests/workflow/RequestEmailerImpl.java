package com.monsanto.wst.externaltechrequests.workflow;

import com.monsanto.JavaMail.JavaMailMailDocument;
import com.monsanto.Mail.InvalidFormatException;
import com.monsanto.Mail.MailDocument;
import com.monsanto.Mail.MessageParseException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.document.AttachmentCollection;
import com.monsanto.wst.externaltechrequests.document.DocumentRetrievalException;
import com.monsanto.wst.externaltechrequests.document.MimeTypeFactory;
import com.monsanto.wst.externaltechrequests.model.Attachment;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.security.NullUser;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.*;
import java.util.*;
/*
 RequestEmailerImpl was created on Feb 7, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class RequestEmailerImpl implements RequestEmailer {
  public static final String REVIEW_EMAIL_TEXT = "Attached are the review spreadsheet and any associated request attachment(s)";
  private static final String REPORT_FILENAME = "CommitteeReport.xls";
  private final EmailConfiguration emailConfig;

  public RequestEmailerImpl(EmailConfiguration emailConfig) {
    this.emailConfig = emailConfig;
  }

  public void sendRequests(String subject, RequestProfile[] requests, AttachmentService attachmentService) throws
      EmailException {
    MailDocument doc = buildMailDocument(subject, requests, attachmentService);
    try {
      doc.send();
    } catch (InvalidFormatException e) {
      throw new EmailException(e);
    }
  }

  protected MailDocument buildMailDocument(String subject, RequestProfile[] requests,
                                           AttachmentService attachmentService) throws EmailException {
    try {
      return new JavaMailMailDocument(buldXmlMailDocument(subject, requests, attachmentService));
    } catch (MessageParseException e) {
      throw new EmailException(e);
    }
  }

  protected Document buldXmlMailDocument(String subject, RequestProfile[] requests,
                                         AttachmentService attachmentService) throws EmailException {
    Document emailDoc = DOMUtil.newDocument();
    Element requestElement = DOMUtil.addChildElement(emailDoc, "REQUEST");
    Element headerElement = DOMUtil.addChildElement(requestElement, "HEADER");
    List reviewers = emailConfig.getReviewerEmails();
    addToElements(reviewers, headerElement);
    DOMUtil.addChildElement(headerElement, "FROM", MainConstants.SENDING_ADDRESS);
    DOMUtil.addChildElement(headerElement, "SUBJECT", subject);
    Element bodyElement = DOMUtil.addChildElement(requestElement, "BODY");
    DOMUtil.addChildElement(bodyElement, "CONTENT_TYPE", "text/plain");
    DOMUtil.addChildElement(bodyElement, "LINE", REVIEW_EMAIL_TEXT);
    addAttachments(requests, requestElement, attachmentService);
    return emailDoc;
  }

  private void addAttachments(RequestProfile[] requests, Element requestElement,
                              AttachmentService attachmentService) throws EmailException {
    try {
      addCommitteeReportAttachment(requests, requestElement);
      addAttachmentsFromRequests(requests, attachmentService, requestElement);
    } catch (IOException e) {
      throw new EmailException(e);
    } catch (DocumentRetrievalException e) {
      throw new EmailException(e);
    }
  }

  private void addCommitteeReportAttachment(RequestProfile[] requests, Element requestElement) throws IOException {
    File reportAttachment = getReportAttachment(requests);
    DOMUtil.addChildElement(requestElement, "FILENAME", reportAttachment.getCanonicalPath());
  }

  private void addAttachmentsFromRequests(RequestProfile[] requests, AttachmentService attachmentService,
                                          Element requestElement) throws IOException, DocumentRetrievalException {
    File[] attachments = getAttachments(requests, attachmentService);
    for (int i = 0; i < attachments.length; i++) {
      DOMUtil.addChildElement(requestElement, "FILENAME", attachments[i].getCanonicalPath());
    }
  }

  private void addToElements(List reviewers, Element headerElement) {
    for (int i = 0; i < reviewers.size(); i++) {
      DOMUtil.addChildElement(headerElement, "TO", reviewers.get(i).toString());
    }
  }

  protected File getReportAttachment(RequestProfile[] requests) throws IOException {
//    buildReferenceDataLists(helper);
    List searchResults = Arrays.asList(requests);
    Map beans = new HashMap();
    beans.put("searchResults", searchResults);
    XLSTransformer transformer = new XLSTransformer();
    InputStream templateXLS = RequestEmailerImpl.class.getResourceAsStream(REPORT_FILENAME);
    if (templateXLS == null) {
      throw new IOException("Report Template not found: " + REPORT_FILENAME);
    }
    HSSFWorkbook resultXLS = transformer.transformXLS(templateXLS, beans);
    File reportAttachment = File.createTempFile("SRWG_Review_", ".xls");
    resultXLS.write(new BufferedOutputStream(new FileOutputStream(reportAttachment)));
    resultXLS.write(new BufferedOutputStream(new FileOutputStream("C:\\testreport.xls")));
    return reportAttachment;
  }

  protected File[] getAttachments(RequestProfile[] profiles, AttachmentService attachmentService) throws IOException,
      DocumentRetrievalException {
    List attachments = new ArrayList();
    List profilesForAttachment = new ArrayList();
    findAttachmentsForProfiles(profiles, attachmentService, attachments, profilesForAttachment);
    return findFilesForAttachments(attachments, profilesForAttachment);
  }

  private File[] findFilesForAttachments(List attachments, List profilesForAttachment) throws IOException,
      DocumentRetrievalException {
    MimeTypeFactory mimeFactory = new MimeTypeFactory();
    File[] files = new File[attachments.size()];
    for (int i = 0; i < attachments.size(); i++) {
      RequestProfile profileForAttachment = (RequestProfile) profilesForAttachment.get(i);
      Attachment attachment = (Attachment) attachments.get(i);
      String suffix = '.' + mimeFactory.getExtensionForType(attachment.getMetadata().getMimeType());
      String prefix = profileForAttachment.getRequestNumber() + '-';
      if (prefix == null || prefix.length() < 3) {
        prefix = "SRWG";
      }
      files[i] = File.createTempFile(prefix, suffix);
      FileUtils.writeByteArrayToFile(files[i], attachment.getAttachedFile().getContent());
    }
    return files;
  }

  private void findAttachmentsForProfiles(RequestProfile[] profiles, AttachmentService attachmentService,
                                          List attachments, List profilesForAttachment) {
    for (int i = 0; i < profiles.length; i++) {
      AttachmentCollection profileAttachments = attachmentService.getAttachments(profiles[i].getId(), new NullUser());
      List legal = profileAttachments.getLegalAttachments();
      List shipping = profileAttachments.getShippingAttachments();
      List other = profileAttachments.getOtherAttachments();
      attachments.addAll(legal);
      attachments.addAll(shipping);
      attachments.addAll(other);
      int numberOfAttachments = legal.size() + shipping.size() + other.size();
      addProfileToList(profilesForAttachment, profiles[i], numberOfAttachments);
    }
  }

  private void addProfileToList(List list, RequestProfile profile, int numTimes) {
    for (int i = 0; i < numTimes; i++) {
      list.add(profile);
    }
  }
}
