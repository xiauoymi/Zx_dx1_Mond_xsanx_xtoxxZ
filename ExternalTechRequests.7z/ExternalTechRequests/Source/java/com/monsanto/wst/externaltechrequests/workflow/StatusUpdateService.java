package com.monsanto.wst.externaltechrequests.workflow;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;
/*
 StatusUpdateService was created on Jan 30, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public interface StatusUpdateService {
  void newRequest(RequestProfile request, String modUser);
  void sentToCommittee(RequestProfile request, String modUser);
  void commiteeApproval(RequestProfile request, String comments, String modUser);
  void commiteeRejection(RequestProfile request, String comments, String modUser);
  void legalComplete(RequestProfile request, String modUser);
  void legalNotify(RequestProfile request);
  void shippingComplete(RequestProfile request, String modUser);
  void coordinatorComplete(RequestProfile request, String comments, String modUser);
}
