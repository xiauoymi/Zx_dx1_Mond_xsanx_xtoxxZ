package com.monsanto.wst.externaltechrequests.workflow;

import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.services.EmailService;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestResearchType;
import com.monsanto.wst.externaltechrequests.services.RequestService;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/*
 StatusUpdateServiceImpl was created on Jan 30, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class StatusUpdateServiceImpl implements StatusUpdateService {
  public static final String LEGAL_EMAIL_TEMPLATE_ID = "legal";
  public static final String SHIPPING_EMAIL_TEMPLATE_ID = "shipping";
  public static final String SPONSOR_NEW_EMAIL_TEMPLATE_ID = "sponsor_new";
  public static final String SPONSOR_PENDING_EMAIL_TEMPLATE_ID = "sponsor_pending";
  public static final String SPONSOR_APPROVAL_EMAIL_TEMPLATE_ID = "sponsor_approval";
  public static final String SPONSOR_COORDINATOR_EMAIL_TEMPLATE_ID = "sponsor_coordinator";
  public static final String LEGAL_NOTIFY_TEMPLATE_ID = "legal_notify";
  public static final String SPONSOR_REJECTION_EMAIL_TEMPLATE_ID = "sponsor_rejection";
  public static final String SPONSOR_LEGAL_REVIEW_COMPLETE_TEMPLATE_ID = "sponsor_legal_complete";
  public static final String SPONSOR_COMPLETE_EMAIL_TEMPLATE_ID = "sponsor_complete";
  public static final String COORDINATOR_COMPLETE_EMAIL_TEMPLATE_ID = "coordinator_complete";
  public static final String COORDINATOR_REVIEW_EMAIL_TEMPLATE_ID = "coordinator_review";

  public static final String NEW_STATUS_MESSAGE = "Created";
  public static final String PENDING_STATUS_MESSAGE = "Pending committee approval";
  public static final String APPROVED_STATUS_MESSAGE = "Approved by committee";
  public static final String REJECTED_STATUS_MESSAGE = "Rejected by committee";
  public static final String LEGAL_REVIEW_COMPLETE_STATUS_MESSAGE = "Legal Review Completed";
  public static final String COORDINATOR_REVIEW_COMPLETE_STATUS_MESSAGE = "SRWG Coordinator Review Completed";
  public static final String LEGAL_NOTIFY_STATUS_MESSAGE = "MTA Needs Supervisor Review";
  public static final String COMPLETE_STATUS_MESSAGE = "Shipped";

  public static final long NEW_COMMITTEE_VALUE = 100;
  public static final long PENDING_COMMITTEE_VALUE = 103;
  public static final long APPROVED_COMMITTEE_VALUE = 101;
  public static final long REJECTED_COMMITTEE_VALUE = 102;

  private final EmailService emailer;
  private final EmailConfiguration emailConfig;
  private final RequestService reqService;

  public StatusUpdateServiceImpl(RequestService reqService, EmailService emailer, EmailConfiguration emailConfig) {
    this.emailer = emailer;
    this.emailConfig = emailConfig;
    this.reqService = reqService;
  }

  public void newRequest(RequestProfile request, String modUser) {
    sendNotification(request, getSponsorEmail(request.getSponsor()), SPONSOR_NEW_EMAIL_TEMPLATE_ID,
        getSubject(request, NEW_STATUS_MESSAGE));
    updateStatus(request, MainConstants.STATUS_ID_NEW, NEW_COMMITTEE_VALUE, null, modUser);
  }

  public void sentToCommittee(RequestProfile request, String modUser) {
    sendNotification(request, getSponsorEmail(request.getSponsor()), SPONSOR_PENDING_EMAIL_TEMPLATE_ID,
        getSubject(request, PENDING_STATUS_MESSAGE));
    updateStatus(request, MainConstants.STATUS_ID_IN_REVIEW, PENDING_COMMITTEE_VALUE, null, modUser);
  }

  private String getSponsorEmail(String sponsorUserId) {
    return (sponsorUserId == null || sponsorUserId.length() == 0) ? null : sponsorUserId + "@monsanto.com";
  }

  public void commiteeApproval(RequestProfile request, String comments, String modUser) {
    sendNotification(request, emailConfig.getLegalEmails(), LEGAL_EMAIL_TEMPLATE_ID,
        getSubject(request, APPROVED_STATUS_MESSAGE));
    sendNotification(request, getSponsorEmail(request.getSponsor()), SPONSOR_APPROVAL_EMAIL_TEMPLATE_ID,
        getSubject(request, APPROVED_STATUS_MESSAGE));
    updateStatus(request, MainConstants.STATUS_ID_APPROVED, APPROVED_COMMITTEE_VALUE, comments, modUser);
  }

  public void commiteeRejection(RequestProfile request, String comments, String modUser) {
    sendNotification(request, getSponsorEmail(request.getSponsor()), SPONSOR_REJECTION_EMAIL_TEMPLATE_ID,
        getSubject(request, REJECTED_STATUS_MESSAGE));
    updateStatus(request, MainConstants.STATUS_ID_REJECTED, REJECTED_COMMITTEE_VALUE, comments, modUser);
  }

  public void legalComplete(RequestProfile request, String modUser) {
    sendNotification(request, emailConfig.getCoordinatorEmails(), COORDINATOR_REVIEW_EMAIL_TEMPLATE_ID,
        getSubject(request, LEGAL_REVIEW_COMPLETE_STATUS_MESSAGE));
    sendNotification(request, getSponsorEmail(request.getSponsor()), SPONSOR_LEGAL_REVIEW_COMPLETE_TEMPLATE_ID,
        getSubject(request, LEGAL_REVIEW_COMPLETE_STATUS_MESSAGE));
    updateStatus(request, MainConstants.STATUS_ID_COORDINATOR, APPROVED_COMMITTEE_VALUE, null, modUser);
  }

  public void legalNotify(RequestProfile request) {
    sendNotification(request, emailConfig.getLegalSupervisorEmails(), LEGAL_NOTIFY_TEMPLATE_ID,
        getSubject(request, LEGAL_NOTIFY_STATUS_MESSAGE));
  }

  public void coordinatorComplete(RequestProfile request, String comments, String modUser) {
    sendNotification(request, emailConfig.getShippingEmails(), SHIPPING_EMAIL_TEMPLATE_ID,
        getSubject(request, COORDINATOR_REVIEW_COMPLETE_STATUS_MESSAGE));
    sendNotification(request, getSponsorEmail(request.getSponsor()), SPONSOR_COORDINATOR_EMAIL_TEMPLATE_ID,
        getSubject(request, COORDINATOR_REVIEW_COMPLETE_STATUS_MESSAGE));
    updateStatus(request, MainConstants.STATUS_ID_SHIPPING, APPROVED_COMMITTEE_VALUE, null, modUser);
  }

  public void shippingComplete(RequestProfile request, String modUser) {
    sendNotification(request, emailConfig.getCoordinatorEmails(), COORDINATOR_COMPLETE_EMAIL_TEMPLATE_ID,
        getSubject(request, COMPLETE_STATUS_MESSAGE));
    sendNotification(request, getSponsorEmail(request.getSponsor()), SPONSOR_COMPLETE_EMAIL_TEMPLATE_ID,
        getSubject(request, COMPLETE_STATUS_MESSAGE));
    updateStatus(request, MainConstants.STATUS_ID_COMPLETE, APPROVED_COMMITTEE_VALUE, null, modUser);
  }

  private void updateStatus(RequestProfile request, Long status, long committeeValue, String comments, String modUser) {
    Long reqStatusId = reqService.getNextSeq();
    RequestResearchType statusReqResearchType = new RequestResearchType(reqStatusId, request.getId(),
        status, comments, modUser, new Date());
    Long committeeStatusId = reqService.getNextSeq();
    RequestResearchType committeeReqResearchType = new RequestResearchType(committeeStatusId, request.getId(),
        new Long(committeeValue), comments, modUser, new Date());

    reqService.insertRequestStatus(statusReqResearchType);
    reqService.insertRequestCommitteeApproved(committeeReqResearchType);
  }

  private void sendNotification(RequestProfile request, List rawToAddresses, String templateId, String subject) {
    List toAddresses = cleanAddresses(rawToAddresses);
    if (!toAddresses.isEmpty()) {
      EmailHeaderInfo header = new EmailHeaderInfo((String) toAddresses.get(0), MainConstants.SENDING_ADDRESS, subject);

      for (int i = 1; i < toAddresses.size(); i++) {
        header.addToEmailAddress((String) toAddresses.get(i));
      }

      emailer.sendEmail(templateId, header, request);
    }
  }

  private List cleanAddresses(List addresses) {
    List scrubbed = new ArrayList();
    for (int i = 0; i < addresses.size(); i++) {
      String addr = (String) addresses.get(i);
      if (addr != null && addr.length() > 0 && !addr.startsWith("@")) {
        scrubbed.add(addr);
      }
    }

    return scrubbed;
  }

  private void sendNotification(RequestProfile request, String sponsor, String templateId, String subject) {
    List addresses = new ArrayList(1);
    addresses.add(sponsor);
    sendNotification(request, addresses, templateId, subject);
  }

  private String getSubject(RequestProfile request, String status) {
    return "SRWG Request #" + request.getRequestNumber() + " - " + status;
  }
}
