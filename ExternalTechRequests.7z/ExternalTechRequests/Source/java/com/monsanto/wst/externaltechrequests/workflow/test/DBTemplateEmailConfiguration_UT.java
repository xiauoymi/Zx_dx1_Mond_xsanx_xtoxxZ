package com.monsanto.wst.externaltechrequests.workflow.test;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.externaltechrequests.workflow.DBTemplateEmailConfiguration;
import com.monsanto.wst.externaltechrequests.workflow.EmailConfiguration;
import junit.framework.TestCase;

/*
 DBTemplateEmailConfiguration_UT was created on Jan 31, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class DBTemplateEmailConfiguration_UT extends TestCase {
  public void testGetLegalEmails() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    EmailConfiguration emailConfig = new DBTemplateEmailConfiguration(template);
    emailConfig.getLegalEmails();
    assertTrue(template.wasStatementNameCalled(DBTemplateEmailConfiguration.LEGAL_EMAILS_QUERY));
  }

  public void testGetLegalSupervisorEmails() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    EmailConfiguration emailConfig = new DBTemplateEmailConfiguration(template);
    emailConfig.getLegalSupervisorEmails();
    assertTrue(template.wasStatementNameCalled(DBTemplateEmailConfiguration.LEGAL_SUPERVISOR_EMAILS_QUERY));
  }

  public void testGetShippingEmails() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    EmailConfiguration emailConfig = new DBTemplateEmailConfiguration(template);
    emailConfig.getShippingEmails();
    assertTrue(template.wasStatementNameCalled(DBTemplateEmailConfiguration.SHIPPING_EMAILS_QUERY));
  }

  public void testGetCoordinatorEmails() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    EmailConfiguration emailConfig = new DBTemplateEmailConfiguration(template);
    emailConfig.getCoordinatorEmails();
    assertTrue(template.wasStatementNameCalled(DBTemplateEmailConfiguration.COORDINATOR_EMAILS_QUERY));
  }

  public void testgetReviewerEmails() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    EmailConfiguration emailConfig = new DBTemplateEmailConfiguration(template);
    emailConfig.getReviewerEmails();
    assertTrue(template.wasStatementNameCalled(DBTemplateEmailConfiguration.REVIEWER_EMAILS_QUERY));
  }
}