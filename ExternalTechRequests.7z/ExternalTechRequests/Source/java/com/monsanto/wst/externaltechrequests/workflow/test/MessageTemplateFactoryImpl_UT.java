package com.monsanto.wst.externaltechrequests.workflow.test;

import com.monsanto.wst.commonutils.reflection.ObjectInspector;
import com.monsanto.wst.commonutils.template.MessageTemplate;
import com.monsanto.wst.commonutils.template.SimpleMessageTemplate;
import com.monsanto.wst.externaltechrequests.workflow.MessageTemplateFactoryImpl;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateServiceImpl;
import junit.framework.TestCase;

/*
 MessageTemplateFactoryImpl_UT was created on Jan 31, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class MessageTemplateFactoryImpl_UT extends TestCase {
  public void testFilenamesUsedAreAsExpected() throws Exception {
    assertCorrectTemplateIsReturned(StatusUpdateServiceImpl.LEGAL_EMAIL_TEMPLATE_ID, "legal.email");
    assertCorrectTemplateIsReturned(StatusUpdateServiceImpl.LEGAL_NOTIFY_TEMPLATE_ID, "legal_notify.email");
    assertCorrectTemplateIsReturned(StatusUpdateServiceImpl.SHIPPING_EMAIL_TEMPLATE_ID, "shipping.email");
    assertCorrectTemplateIsReturned(StatusUpdateServiceImpl.SPONSOR_NEW_EMAIL_TEMPLATE_ID, "sponsorNew.email");
    assertCorrectTemplateIsReturned(StatusUpdateServiceImpl.SPONSOR_PENDING_EMAIL_TEMPLATE_ID, "sponsorPending.email");
    assertCorrectTemplateIsReturned(StatusUpdateServiceImpl.SPONSOR_APPROVAL_EMAIL_TEMPLATE_ID,
        "sponsorApproval.email");
    assertCorrectTemplateIsReturned(StatusUpdateServiceImpl.SPONSOR_COORDINATOR_EMAIL_TEMPLATE_ID,
        "sponsorCoordinator.email");
    assertCorrectTemplateIsReturned(StatusUpdateServiceImpl.SPONSOR_REJECTION_EMAIL_TEMPLATE_ID,
        "sponsorRejection.email");
    assertCorrectTemplateIsReturned(StatusUpdateServiceImpl.SPONSOR_LEGAL_REVIEW_COMPLETE_TEMPLATE_ID,
        "sponsorLegal.email");
    assertCorrectTemplateIsReturned(StatusUpdateServiceImpl.SPONSOR_COMPLETE_EMAIL_TEMPLATE_ID,
        "sponsorComplete.email");
    assertCorrectTemplateIsReturned(StatusUpdateServiceImpl.COORDINATOR_COMPLETE_EMAIL_TEMPLATE_ID,
        "coordinator.email");
    assertCorrectTemplateIsReturned(StatusUpdateServiceImpl.COORDINATOR_REVIEW_EMAIL_TEMPLATE_ID,
        "coordinatorReview.email");
  }

  public void testLoadTemplateReturnsTempalte() throws Exception {
    MockMessageTemplateFactoryForVisibility templateFactory = new MockMessageTemplateFactoryForVisibility();
    String filename = "com/monsanto/wst/externaltechrequests/workflow/test/test.email";
    String expectedMsg = "Hello, Template.";
    MessageTemplate msgTemplate = templateFactory.loadTemplate(filename, new ObjectInspector());
    assertNotNull(msgTemplate);
    String msg = msgTemplate.getFormattedMessage(this);
    assertEquals(expectedMsg, msg);
  }


  private void assertCorrectTemplateIsReturned(String templateID, String expectedFilename) {
    MockMessageTemplateFactoryForLoadTemplate templateFactory = new MockMessageTemplateFactoryForLoadTemplate();
    templateFactory.getTemplateById(templateID);
    String filename = templateFactory.getFilename();
    if (filename.indexOf(expectedFilename) < 0) {
      fail("Expected to filename to contain '" + expectedFilename + "', but it was: '" + filename + '\'');
    }
  }

  private static class MockMessageTemplateFactoryForVisibility extends MessageTemplateFactoryImpl {
    protected MessageTemplate loadTemplate(String filename, ObjectInspector inspector) {
      return super.loadTemplate(filename, inspector);
    }
  }

  private static class MockMessageTemplateFactoryForLoadTemplate extends MessageTemplateFactoryImpl {
    private String filename;

    protected MessageTemplate loadTemplate(String filename, ObjectInspector inspector) {
      this.filename = filename;
      return new SimpleMessageTemplate("Mock", inspector);
    }

    public String getFilename() {
      return filename;
    }
  }
}