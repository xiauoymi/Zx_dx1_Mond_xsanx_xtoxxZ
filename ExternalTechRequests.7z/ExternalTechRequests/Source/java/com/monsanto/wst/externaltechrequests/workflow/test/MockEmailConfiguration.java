package com.monsanto.wst.externaltechrequests.workflow.test;

import com.monsanto.wst.externaltechrequests.workflow.EmailConfiguration;

import java.util.List;
/*
 MockEmailConfiguration was created on Feb 7, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MockEmailConfiguration implements EmailConfiguration {
  private final List legalEmails;
  private final List legalSupervisorEmails;
  private final List shippingEmails;
  private final List coordinatorEmails;
  private final List reviewerEmails;

  public MockEmailConfiguration(List legalEmails, List legalSupervisorEmails, List shippingEmails,
                                List coordinatorEmails, List reviewerEmails) {
    this.legalEmails = legalEmails;
    this.legalSupervisorEmails = legalSupervisorEmails;
    this.shippingEmails = shippingEmails;
    this.coordinatorEmails = coordinatorEmails;
    this.reviewerEmails = reviewerEmails;
  }

  public List getLegalEmails() {
    return legalEmails;
  }

  public List getLegalSupervisorEmails() {
    return legalSupervisorEmails;
  }

  public List getShippingEmails() {
    return shippingEmails;
  }

  public List getCoordinatorEmails() {
    return coordinatorEmails;
  }

  public List getReviewerEmails() {
    return reviewerEmails;
  }
}
