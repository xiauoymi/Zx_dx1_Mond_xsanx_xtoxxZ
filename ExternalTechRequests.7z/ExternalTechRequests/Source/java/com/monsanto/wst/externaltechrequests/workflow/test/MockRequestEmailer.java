package com.monsanto.wst.externaltechrequests.workflow.test;

import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
import com.monsanto.wst.externaltechrequests.workflow.RequestEmailer;

import java.util.ArrayList;
import java.util.List;
/*
 MockRequestEmailer was created on Feb 7, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */
public class MockRequestEmailer implements RequestEmailer {
  final List sentRequests = new ArrayList();

  public void sendRequests(String subject, RequestProfile[] requests, AttachmentService attachmentService) {
    for (int i = 0; i < requests.length; i++) {
      sentRequests.add(requests[i]);
    }
  }

  public boolean wasEmailSent(String requestId) {
    for (int i = 0; i < sentRequests.size(); i++) {
      RequestProfile requestProfile = (RequestProfile) sentRequests.get(i);
      if (requestProfile.getId().equals(new Long(requestId))) {
        return true;
      }
    }

    return false;
  }
}
