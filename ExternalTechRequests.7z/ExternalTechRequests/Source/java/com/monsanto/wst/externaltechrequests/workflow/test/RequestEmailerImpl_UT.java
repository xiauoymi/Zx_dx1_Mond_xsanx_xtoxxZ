package com.monsanto.wst.externaltechrequests.workflow.test;

import com.monsanto.Mail.InvalidFormatException;
import com.monsanto.Mail.MailAttachmentIterator;
import com.monsanto.Mail.MailDocument;
import com.monsanto.Mail.MessageParseException;
import com.monsanto.wst.externaltechrequests.controller.test.MockAttachment;
import com.monsanto.wst.externaltechrequests.dao.test.MockAttachedFile;
import com.monsanto.wst.externaltechrequests.document.AttachedFile;
import com.monsanto.wst.externaltechrequests.document.DocumentRetrievalException;
import com.monsanto.wst.externaltechrequests.document.DocumentType;
import com.monsanto.wst.externaltechrequests.model.*;
import com.monsanto.wst.externaltechrequests.model.test.MockAttachmentService;
import com.monsanto.wst.externaltechrequests.services.AttachmentService;
import com.monsanto.wst.externaltechrequests.workflow.EmailConfiguration;
import com.monsanto.wst.externaltechrequests.workflow.EmailException;
import com.monsanto.wst.externaltechrequests.workflow.RequestEmailer;
import com.monsanto.wst.externaltechrequests.workflow.RequestEmailerImpl;
import org.apache.commons.io.FileUtils;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/*
 RequestEmailerImpl_UT was created on Feb 7, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class RequestEmailerImpl_UT extends XMLTestCase {
  private EmailConfiguration emailConfig;
  private MockAttachmentService attachmentService;
  private static final String REVIEWER_ADDR = "kjjohn2@monsanto.com";

  protected void setUp() throws Exception {
    super.setUp();
    List reviewEmailList = new ArrayList();
    reviewEmailList.add(REVIEWER_ADDR);
    emailConfig = new MockEmailConfiguration(new ArrayList(), new ArrayList(), new ArrayList(), new ArrayList(),
        reviewEmailList);
    attachmentService = new MockAttachmentService();
  }

  public void testCallsSendOnMailDoc() throws Exception {
    MockMailDocument mailDoc = new MockMailDocument();
    RequestEmailer emailer = new MockRequestEmailerImplForBuildDocument(emailConfig, mailDoc);
    RequestProfile[] requests = new RequestProfile[1];
    requests[0] = new RequestProfile();
    emailer.sendRequests("test", requests, attachmentService);
    assertTrue(mailDoc.wasSent());
  }

  public void testCorrectMailDocIsGenerated() throws Exception {
    MockRequestEmailerImplForRawXml emailer = new MockRequestEmailerImplForRawXml(emailConfig);
    RequestProfile[] requests = new RequestProfile[1];
    requests[0] = new RequestProfile();
    String testRequestNumber = "TEST1";
    requests[0].setRequestNumber(testRequestNumber);
    String testSubject = "test";
    MailDocument mailDoc = emailer.buildMailDocument(testSubject, requests, attachmentService);
    assertNotNull(mailDoc);
    Document mailXml = emailer.getRaw();
    assertNotNull(mailXml);
    assertXpathEvaluatesTo(testSubject, "/REQUEST/HEADER/SUBJECT/text()", mailXml);
    assertXpathEvaluatesTo(REVIEWER_ADDR, "/REQUEST/HEADER/TO/text()", mailXml);
    assertXpathExists("/REQUEST/FILENAME", mailXml);
    assertXpathExists("/REQUEST/FILENAME[contains(text(), 'mock.xls')]", mailXml);
    assertXpathExists("/REQUEST/FILENAME[contains(text(), 'mock.txt')]", mailXml);
    assertXpathEvaluatesTo("text/plain", "/REQUEST/BODY/CONTENT_TYPE/text()", mailXml);
    assertXpathEvaluatesTo(RequestEmailerImpl.REVIEW_EMAIL_TEXT, "/REQUEST/BODY/LINE[position()=1]/text()", mailXml);
  }

  public void testGetReportAttachment() throws Exception {
    MockRequestEmailerForVisiblity emailer = new MockRequestEmailerForVisiblity(emailConfig);
    RequestProfile[] requests = new RequestProfile[1];
    RequestProfile request = new RequestProfile();
    request.setId(new Long(12345L));
    request.setRequestNumber("SRWG-1234");
    request.setAffiliation("Monsanto Test");
    request.setCommitteeApproved(new ApprovalReferenceData(new Long(1L), "test"));
    request.setCommitteeApprovedComments("Test Comment");
    AddressInfo addressInfo = new AddressInfo();
    addressInfo.setStreetOne("800 N Lindbergh");
    addressInfo.setStreetTwo("1000/F2EE");
    addressInfo.setCity("St. Louis");
    addressInfo.setState("MO");
    addressInfo.setZipCode("63167");
    addressInfo.setPhone("314-694-1000");
    request.setShipToAddress(addressInfo);
    request.addRequestResearchEntry(
        new RequestResearchType(new Long(1L), request.getId(), new Long(1), "Test", "Test", new Date(), "Test"));
    requests[0] = request;

    File rptAttachment = emailer.getReportAttachment(requests);
    assertTrue(rptAttachment.exists());
    try {
      assertTrue(rptAttachment.getCanonicalPath().endsWith(".xls"));
    } finally {
      rptAttachment.delete();
    }
  }

  public void testGetAttachments() throws Exception {
    RequestProfile[] requests = new RequestProfile[1];
    requests[0] = new RequestProfile();
    requests[0].setId(new Long(1L));
    byte[] testBytes = "Testing".getBytes();
    AttachedFile testAttachmentFile = new MockAttachedFile(testBytes);
    Attachment testAttachment = new MockAttachment(1234, "testDoc", "testDoc", DocumentType.OTHER,
        requests[0].getId().longValue(), testAttachmentFile);
    attachmentService.addAttachment(testAttachment, "test");
    MockRequestEmailerForVisiblity emailer = new MockRequestEmailerForVisiblity(emailConfig);
    File[] attachments = emailer.getAttachments(requests, attachmentService);
    assertNotNull(attachments);
    assertTrue(attachments.length > 0);
    try {
      for (int i = 0; i < attachments.length; i++) {
        assertTrue(attachments[i].exists());
        assertTrue(Arrays.equals(testBytes, FileUtils.readFileToByteArray(attachments[i])));
      }
    } finally {
      deleteAll(attachments);
    }
  }

  private void deleteAll(File[] attachments) {
    for (int i = 0; i < attachments.length; i++) {
      attachments[i].delete();
    }
  }

  private static class MockRequestEmailerForVisiblity extends RequestEmailerImpl {
    MockRequestEmailerForVisiblity(EmailConfiguration emailConfig) {
      super(emailConfig);
    }

    public File getReportAttachment(RequestProfile[] requests) throws IOException {
      return super.getReportAttachment(requests);
    }

    public File[] getAttachments(RequestProfile[] profiles, AttachmentService attachmentService) throws IOException,
        DocumentRetrievalException {
      return super.getAttachments(profiles, attachmentService);
    }
  }

  private static class MockRequestEmailerImplForRawXml extends RequestEmailerImpl {
    private Document raw;

    MockRequestEmailerImplForRawXml(EmailConfiguration emailConfig) {
      super(emailConfig);
      raw = null;
    }

    public MailDocument buildMailDocument(String subject, RequestProfile[] requests,
                                          AttachmentService attachmentService) throws EmailException {
      return super.buildMailDocument(subject, requests, attachmentService);
    }

    public Document buldXmlMailDocument(String subject, RequestProfile[] requests,
                                        AttachmentService attachmentService) throws EmailException {
      raw = super.buldXmlMailDocument(subject, requests, attachmentService);
      return raw;
    }

    public Document getRaw() {
      return raw;
    }

    protected File getReportAttachment(RequestProfile[] requests) {
      return new File("mock.xls");
    }

    protected File[] getAttachments(RequestProfile[] profiles, AttachmentService attachmentService) {
      File[] attachments = new File[1];
      attachments[0] = new File("mock.txt");
      return attachments;
    }
  }

  private static class MockRequestEmailerImplForBuildDocument extends RequestEmailerImpl {
    private final MailDocument mailDoc;

    MockRequestEmailerImplForBuildDocument(EmailConfiguration emailConfig, MailDocument mailDoc) {
      super(emailConfig);
      this.mailDoc = mailDoc;
    }

    protected MailDocument buildMailDocument(String subject, RequestProfile[] requests,
                                             AttachmentService attachmentService) {
      return mailDoc;
    }
  }

  private class MockMailDocument implements MailDocument {
    private boolean sent;

    MockMailDocument() {
      sent = false;
    }

    public boolean wasSent() {
      return sent;
    }

    public MailAttachmentIterator getAttachmentIterator() {
      return null;
    }

    public Date getRecievedDate() {
      return null;
    }

    public Document toXML() throws MessageParseException {
      return null;
    }

    public void send() throws InvalidFormatException {
      sent = true;
    }

    public void setAttachmentSavePath(String path) {
    }

    public Document getMessageBody() throws MessageParseException {
      return null;
    }
  }
}