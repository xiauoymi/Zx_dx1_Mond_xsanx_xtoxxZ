package com.monsanto.wst.externaltechrequests.workflow.test;

import com.monsanto.wst.emailtemplate.domain.EmailHeaderInfo;
import com.monsanto.wst.emailtemplate.services.EmailService;
import com.monsanto.wst.externaltechrequests.constants.MainConstants;
import com.monsanto.wst.externaltechrequests.model.AddressInfo;
import com.monsanto.wst.externaltechrequests.model.RequestProfile;
import com.monsanto.wst.externaltechrequests.model.RequestResearchType;
import com.monsanto.wst.externaltechrequests.services.RequestService;
import com.monsanto.wst.externaltechrequests.workflow.EmailConfiguration;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateService;
import com.monsanto.wst.externaltechrequests.workflow.StatusUpdateServiceImpl;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/*
 StatusUpdateService_UT was created on Jan 30, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, Web Solutions, Monsanto
 */

public class StatusUpdateServiceImpl_UT extends TestCase {
  private String sponsorUserId;
  private List testLegalEmailAddrs;
  private List testLegalSupervisorEmailAddrs;
  private List testSponsorEmailAddrs;
  private List testShippingEmailAddrs;
  private List testCoordinatorEmailAddrs;

  private EmailConfiguration emailConfig;

  protected void setUp() throws Exception {
    super.setUp();

    testLegalEmailAddrs = new ArrayList();
    testLegalEmailAddrs.add("test1@monsanto.com");
    testLegalEmailAddrs.add("test2@monsanto.com");

    testLegalSupervisorEmailAddrs = new ArrayList();
    testLegalSupervisorEmailAddrs.add("test1A@monsanto.com");
    testLegalSupervisorEmailAddrs.add("test2A@monsanto.com");

    sponsorUserId = "test3";
    String sponsorEmailAddress = sponsorUserId + "@monsanto.com";
    testSponsorEmailAddrs = new ArrayList();
    testSponsorEmailAddrs.add(sponsorEmailAddress);

    testShippingEmailAddrs = new ArrayList();
    testShippingEmailAddrs.add("test4@monsanto.com");
    testShippingEmailAddrs.add("test5@monsanto.com");
    testShippingEmailAddrs.add("test6@monsanto.com");

    testCoordinatorEmailAddrs = new ArrayList();
    testCoordinatorEmailAddrs.add("test7@monsanto.com");

    emailConfig = new MockEmailConfiguration(testLegalEmailAddrs, testLegalSupervisorEmailAddrs, testShippingEmailAddrs,
        testCoordinatorEmailAddrs, new ArrayList());
  }

  public void testSetToNewSetStatusCorrectly() throws Exception {
    MockRequestService reqService = new MockRequestService();
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(reqService, emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    statusService.newRequest(request, "test");

    assertStatusUpdatedCorrectly(reqService, MainConstants.STATUS_ID_NEW,
        StatusUpdateServiceImpl.NEW_COMMITTEE_VALUE);
  }

  public void testSetToPendingReviewSetStatusCorrectly() throws Exception {
    MockRequestService reqService = new MockRequestService();
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(reqService, emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    statusService.sentToCommittee(request, "test");

    assertStatusUpdatedCorrectly(reqService, MainConstants.STATUS_ID_IN_REVIEW,
        StatusUpdateServiceImpl.PENDING_COMMITTEE_VALUE);
  }

  public void testSetToCommitteeApprovalSetStatusCorrectly() throws Exception {
    MockRequestService reqService = new MockRequestService();
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(reqService, emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    String testComment = "This is a test comment";
    statusService.commiteeApproval(request, testComment, "test");

    assertStatusUpdatedCorrectly(reqService, MainConstants.STATUS_ID_APPROVED,
        StatusUpdateServiceImpl.APPROVED_COMMITTEE_VALUE);
  }

  public void testSetToCommitteeRejectionSetStatusCorrectly() throws Exception {
    MockRequestService reqService = new MockRequestService();
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(reqService, emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    String testComment = "This is a test comment";
    statusService.commiteeRejection(request, testComment, "test");

    assertStatusUpdatedCorrectly(reqService, MainConstants.STATUS_ID_REJECTED,
        StatusUpdateServiceImpl.REJECTED_COMMITTEE_VALUE);
  }

  public void testLegalCompleteSetStatusCorrectly() throws Exception {
    MockRequestService reqService = new MockRequestService();
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(reqService, emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    statusService.legalComplete(request, "test");

    assertStatusUpdatedCorrectly(reqService, MainConstants.STATUS_ID_COORDINATOR,
        StatusUpdateServiceImpl.APPROVED_COMMITTEE_VALUE);
  }

  public void testCoordinatorReviewCompleteSetStatusComplete() throws Exception {
    MockRequestService reqService = new MockRequestService();
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(reqService, emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    statusService.coordinatorComplete(request, "test comment", "test");

    assertStatusUpdatedCorrectly(reqService, MainConstants.STATUS_ID_SHIPPING,
        StatusUpdateServiceImpl.APPROVED_COMMITTEE_VALUE);
  }


  public void testShippingCompleteSetStatusCorrectly() throws Exception {
    MockRequestService reqService = new MockRequestService();
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(reqService, emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    statusService.shippingComplete(request, "test");

    assertStatusUpdatedCorrectly(reqService, MainConstants.STATUS_ID_COMPLETE,
        StatusUpdateServiceImpl.APPROVED_COMMITTEE_VALUE);
  }

  public void testSetToNewSendsSponsorEmail() throws Exception {
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(new MockRequestService(), emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    statusService.newRequest(request, "test");
    assertEquals(1, emailer.getNumEmails());
    EmailData sponsorEmail = null;
    for (int i = 0; i < emailer.getNumEmails(); i++) {
      EmailData currData = emailer.getEmail(i);
      if (currData.getTemplate().equals(StatusUpdateServiceImpl.SPONSOR_NEW_EMAIL_TEMPLATE_ID)) {
        sponsorEmail = currData;
      } else {
        fail("Unexpected email type found: " + currData.getTemplate());
      }
    }

    String testSubject =
        "SRWG Request #" + request.getRequestNumber() + " - " + StatusUpdateServiceImpl.NEW_STATUS_MESSAGE;
    assertSponsorEmailSent(sponsorEmail, testSubject, request);
  }

  public void testSetToPendingReviewSendsSponsorEmail() throws Exception {
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(new MockRequestService(), emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    statusService.sentToCommittee(request, "test");
    assertEquals(1, emailer.getNumEmails());
    EmailData sponsorEmail = null;
    for (int i = 0; i < emailer.getNumEmails(); i++) {
      EmailData currData = emailer.getEmail(i);
      if (currData.getTemplate().equals(StatusUpdateServiceImpl.SPONSOR_PENDING_EMAIL_TEMPLATE_ID)) {
        sponsorEmail = currData;
      } else {
        fail("Unexpected email type found: " + currData.getTemplate());
      }
    }

    String testSubject =
        "SRWG Request #" + request.getRequestNumber() + " - " + StatusUpdateServiceImpl.PENDING_STATUS_MESSAGE;
    assertSponsorEmailSent(sponsorEmail, testSubject, request);
  }

  public void testSetToCommitteeApprovalSendsLegalContactEmailAndSponsor() throws Exception {
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(new MockRequestService(), emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    String testComment = "This is a test comment";
    statusService.commiteeApproval(request, testComment, "test");
    assertEquals(2, emailer.getNumEmails());
    EmailData legalEmail = null;
    EmailData sponsorEmail = null;
    for (int i = 0; i < emailer.getNumEmails(); i++) {
      EmailData currData = emailer.getEmail(i);
      if (currData.getTemplate().equals(StatusUpdateServiceImpl.LEGAL_EMAIL_TEMPLATE_ID)) {
        legalEmail = currData;
      } else if (currData.getTemplate().equals(StatusUpdateServiceImpl.SPONSOR_APPROVAL_EMAIL_TEMPLATE_ID)) {
        sponsorEmail = currData;
      } else {
        fail("Unexpected email type found: " + currData.getTemplate());
      }
    }

    String testSubject =
        "SRWG Request #" + request.getRequestNumber() + " - " + StatusUpdateServiceImpl.APPROVED_STATUS_MESSAGE;

    assertLegalEmailSent(legalEmail, testSubject, request);
    assertSponsorEmailSent(sponsorEmail, testSubject, request);
  }

  public void testLegalNotifySendsEmailToLegalSupervisor() throws Exception {
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(new MockRequestService(), emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    statusService.legalNotify(request);
    assertEquals(1, emailer.getNumEmails());
    EmailData legalSupervisorEmail = null;
    for (int i = 0; i < emailer.getNumEmails(); i++) {
      EmailData currData = emailer.getEmail(i);
      if (currData.getTemplate().equals(StatusUpdateServiceImpl.LEGAL_NOTIFY_TEMPLATE_ID)) {
        legalSupervisorEmail = currData;
      } else {
        fail("Unexpected email type found: " + currData.getTemplate());
      }
    }

    String testSubject =
        "SRWG Request #" + request.getRequestNumber() + " - " + StatusUpdateServiceImpl.LEGAL_NOTIFY_STATUS_MESSAGE;

    assertLegalSupervisorEmailSent(legalSupervisorEmail, testSubject, request);
  }

  public void testSetToCommitteeRejectionSendsSponsorEmail() throws Exception {
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(new MockRequestService(), emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    String testComment = "This is a test comment";
    statusService.commiteeRejection(request, testComment, "test");
    assertEquals(1, emailer.getNumEmails());
    EmailData sponsorEmail = null;
    for (int i = 0; i < emailer.getNumEmails(); i++) {
      EmailData currData = emailer.getEmail(i);
      if (currData.getTemplate().equals(StatusUpdateServiceImpl.SPONSOR_REJECTION_EMAIL_TEMPLATE_ID)) {
        sponsorEmail = currData;
      } else {
        fail("Unexpected email type found: " + currData.getTemplate());
      }
    }

    String testSubject =
        "SRWG Request #" + request.getRequestNumber() + " - " + StatusUpdateServiceImpl.REJECTED_STATUS_MESSAGE;
    assertSponsorEmailSent(sponsorEmail, testSubject, request);
  }

  public void testLegalCompleteSendsCoordinatorAndSponsorEmail() throws Exception {
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(new MockRequestService(), emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    statusService.legalComplete(request, "test");
    assertEquals(2, emailer.getNumEmails());
    EmailData sponsorEmail = null;
    EmailData coordinatorEmail = null;
    for (int i = 0; i < emailer.getNumEmails(); i++) {
      EmailData currData = emailer.getEmail(i);
      if (currData.getTemplate().equals(StatusUpdateServiceImpl.SPONSOR_LEGAL_REVIEW_COMPLETE_TEMPLATE_ID)) {
        sponsorEmail = currData;
      } else if (currData.getTemplate().equals(StatusUpdateServiceImpl.COORDINATOR_REVIEW_EMAIL_TEMPLATE_ID)) {
        coordinatorEmail = currData;
      } else {
        fail("Unexpected email type found: " + currData.getTemplate());
      }
    }

    String testSubject = "SRWG Request #" + request.getRequestNumber() + " - " + StatusUpdateServiceImpl
        .LEGAL_REVIEW_COMPLETE_STATUS_MESSAGE;
    assertSponsorEmailSent(sponsorEmail, testSubject, request);
    assertCoordinatorEmailSent(coordinatorEmail, testSubject, request);
  }

  public void testCoordinatorCompleteSendsShippingAndSponsorEmail() throws Exception {
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(new MockRequestService(), emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    statusService.coordinatorComplete(request, "test", "test");
    assertEquals(2, emailer.getNumEmails());
    EmailData sponsorEmail = null;
    EmailData shippingEmail = null;
    for (int i = 0; i < emailer.getNumEmails(); i++) {
      EmailData currData = emailer.getEmail(i);
      if (currData.getTemplate().equals(StatusUpdateServiceImpl.SPONSOR_COORDINATOR_EMAIL_TEMPLATE_ID)) {
        sponsorEmail = currData;
      } else if (currData.getTemplate().equals(StatusUpdateServiceImpl.SHIPPING_EMAIL_TEMPLATE_ID)) {
        shippingEmail = currData;
      } else {
        fail("Unexpected email type found: " + currData.getTemplate());
      }
    }

    String testSubject = "SRWG Request #" + request.getRequestNumber() + " - " + StatusUpdateServiceImpl
        .COORDINATOR_REVIEW_COMPLETE_STATUS_MESSAGE;
    assertSponsorEmailSent(sponsorEmail, testSubject, request);
    assertShippingEmailSent(shippingEmail, testSubject, request);
  }

  public void testShippingCompleteSendsCoordinatorAndSponsorEmail() throws Exception {
    MockEmailService emailer = new MockEmailService();
    StatusUpdateService statusService = new StatusUpdateServiceImpl(new MockRequestService(), emailer, emailConfig);
    RequestProfile request = new RequestProfile();
    request.setRequestNumber("abc123");
    request.setSponsor(sponsorUserId);
    statusService.shippingComplete(request, "test");
    assertEquals(2, emailer.getNumEmails());
    EmailData sponsorEmail = null;
    EmailData coordinatorEmail = null;
    for (int i = 0; i < emailer.getNumEmails(); i++) {
      EmailData currData = emailer.getEmail(i);
      if (currData.getTemplate().equals(StatusUpdateServiceImpl.SPONSOR_COMPLETE_EMAIL_TEMPLATE_ID)) {
        sponsorEmail = currData;
      } else if (currData.getTemplate().equals(StatusUpdateServiceImpl.COORDINATOR_COMPLETE_EMAIL_TEMPLATE_ID)) {
        coordinatorEmail = currData;
      } else {
        fail("Unexpected email type found: " + currData.getTemplate());
      }
    }

    String testSubject =
        "SRWG Request #" + request.getRequestNumber() + " - " + StatusUpdateServiceImpl.COMPLETE_STATUS_MESSAGE;
    assertSponsorEmailSent(sponsorEmail, testSubject, request);
    assertCoordinatorEmailSent(coordinatorEmail, testSubject, request);
  }

  private void assertStatusUpdatedCorrectly(MockRequestService reqService, Long expectedStatus,
                                            long expectedCommitteeValue) {
    List statusUpdates = reqService.getStatusUpdates();
    assertEquals("Incorrect # of status updates made", 1, statusUpdates.size());
    assertEquals(expectedStatus, ((RequestResearchType) statusUpdates.get(0)).getResearchTypeId());

    List committeeUpdates = reqService.getCommitteeUpdates();
    assertEquals("Incorrect # of committee updates made", 1, committeeUpdates.size());
    assertEquals(expectedCommitteeValue,
        ((RequestResearchType) committeeUpdates.get(0)).getResearchTypeId().longValue());
  }

  private void assertSponsorEmailSent(EmailData sponsorEmail, String testSubject, RequestProfile request) {
    assertNotNull("Sponsor email not found", sponsorEmail);
    assertEquals(testSubject, sponsorEmail.getHeader().getSubject());
    assertAllAddressesInToField("Sponsor address not in to field", testSponsorEmailAddrs,
        sponsorEmail.getHeader().getToEmailAddresses());
    assertEquals(request, sponsorEmail.getMapping());
  }

  private void assertLegalEmailSent(EmailData legalEmail, String testSubject, RequestProfile request) {
    assertNotNull("Legal email not found", legalEmail);
    assertEquals(testSubject, legalEmail.getHeader().getSubject());
    assertAllAddressesInToField("Legal address not in to field", testLegalEmailAddrs,
        legalEmail.getHeader().getToEmailAddresses());
    assertEquals(request, legalEmail.getMapping());
  }

  private void assertLegalSupervisorEmailSent(EmailData legalEmail, String testSubject, RequestProfile request) {
    assertNotNull("Legal Supervisor email not found", legalEmail);
    assertEquals(testSubject, legalEmail.getHeader().getSubject());
    assertAllAddressesInToField("Legal supervisor address not in to field", testLegalSupervisorEmailAddrs,
        legalEmail.getHeader().getToEmailAddresses());
    assertEquals(request, legalEmail.getMapping());
  }

  private void assertShippingEmailSent(EmailData shippingEmail, String testSubject, RequestProfile request) {
    assertNotNull("Shipping email not found", shippingEmail);
    assertEquals(testSubject, shippingEmail.getHeader().getSubject());
    assertAllAddressesInToField("Shipping address not in to field", testShippingEmailAddrs,
        shippingEmail.getHeader().getToEmailAddresses());
    assertEquals(request, shippingEmail.getMapping());
  }

  private void assertCoordinatorEmailSent(EmailData coordinatorEmail, String testSubject, RequestProfile request) {
    assertNotNull("Coordinator email not found", coordinatorEmail);
    assertEquals(testSubject, coordinatorEmail.getHeader().getSubject());
    assertAllAddressesInToField("Coordinator address not in to field", testCoordinatorEmailAddrs,
        coordinatorEmail.getHeader().getToEmailAddresses());
    assertEquals(request, coordinatorEmail.getMapping());
  }

  private void assertAllAddressesInToField(String msg, List expectedList, List actualList) {
    assertEquals(msg, expectedList.size(), actualList.size());
    for (int i = 0; i < expectedList.size(); i++) {
      String currExpectedAddress = (String) expectedList.get(i);
      assertTrue(msg + ':' + currExpectedAddress, actualList.contains(currExpectedAddress));
    }
  }

  private class EmailData {
    private final String template;
    private final EmailHeaderInfo header;
    private final Object mapping;

    EmailData(String template, EmailHeaderInfo header, Object mapping) {
      this.template = template;
      this.header = header;
      this.mapping = mapping;
    }

    public String getTemplate() {
      return template;
    }

    public EmailHeaderInfo getHeader() {
      return header;
    }

    public Object getMapping() {
      return mapping;
    }
  }

  private class MockEmailService implements EmailService {
    private final List emailData = new ArrayList();

    public void sendEmail(String templateId, EmailHeaderInfo headerInfo, Object mapping) {
      emailData.add(new EmailData(templateId, headerInfo, mapping));
    }

    public int getNumEmails() {
      return emailData.size();
    }

    public EmailData getEmail(int num) {
      return (EmailData) emailData.get(num);
    }
  }

  private class MockRequestService implements RequestService {
    private final List researchStatusInserts;
    private final List committeeApprovedInserts;

    MockRequestService() {
      researchStatusInserts = new ArrayList();
      committeeApprovedInserts = new ArrayList();
    }

    public Long insertAddress(AddressInfo addressInfo) {
      return null;
    }

    public Long insertRequestProfile(RequestProfile requestProfile) {
      return null;
    }

    public Long insertRequestResearch(RequestResearchType requestResearchType) {
      return null;
    }

    public Long insertRequestStatus(RequestResearchType requestResearchType) {
      researchStatusInserts.add(requestResearchType);
      return new Long(1);
    }

    public Long insertRequestCommitteeApproved(RequestResearchType requestResearchType) {
      committeeApprovedInserts.add(requestResearchType);
      return new Long(1);
    }

    public Long updateRequestProfile(RequestProfile requestProfile) {
      return null;
    }

    public Long updateAddressInfo(AddressInfo address) {
      return null;
    }

    public Long deleteRequestResearch(Long id) {
      return null;
    }

    public Long getNextSeq() {
      return null;
    }

    public List getStatusUpdates() {
      return researchStatusInserts;
    }

    public List getCommitteeUpdates() {
      return committeeApprovedInserts;
    }
  }
}