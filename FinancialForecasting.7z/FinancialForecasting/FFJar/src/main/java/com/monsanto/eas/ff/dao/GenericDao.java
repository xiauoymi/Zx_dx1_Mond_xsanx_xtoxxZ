/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.ff.dao;

import org.hibernate.Criteria;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Transactional
public interface GenericDao<T, ID extends Serializable> {
  public T findByPrimaryKey(ID id);

  public Collection<T> findAll();

  public Collection<T> findAll(int startIndex, int fetchSize);

  public Collection<T> findByExample(T exampleInstance, String[] excludeProperty);

  public Collection<T> findAll(String key, boolean ascending);

  public T saveOrUpdate(T entity);

  public T merge(T entity);

  public void delete(T entity);

  public Criteria createCriteria();

  Criteria createCriteria(boolean isDeleted);
}
