/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.ff.dao.impl;

import com.monsanto.eas.ff.dao.CountryTypeDao;
import com.monsanto.eas.ff.dao.HibernateDao;
import com.monsanto.eas.ff.model.CountryType;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Repository
public class CountryTypeDaoImpl extends HibernateDao<CountryType, Long> implements CountryTypeDao {
  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, CountryType.class);
  }

  public CountryType lookupByType(String countryType) throws Exception {
    CountryType example = new CountryType();
    example.setType(countryType);
    Collection<CountryType> matchingEntry = findByExample(example, new String[0]);
    if (matchingEntry.isEmpty()) {
      throw new Exception("No country type found with type: " + countryType);
    }
    return matchingEntry.iterator().next();
  }
}