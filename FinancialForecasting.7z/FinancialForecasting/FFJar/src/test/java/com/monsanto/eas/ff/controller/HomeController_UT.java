/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.ff.controller;

import com.monsanto.eas.ff.util.FFConstants;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.servlet.HandlerAdapter;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;

import static org.springframework.test.web.ModelAndViewAssert.assertModelAttributeValues;
import static org.springframework.test.web.ModelAndViewAssert.assertViewName;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:/ffDispatcher-servlet-test.xml", "classpath:/unitTestNoDatabaseContext.xml"})
public class HomeController_UT {
  @Autowired
  private ApplicationContext applicationContext;
  private MockHttpServletRequest request;
  private MockHttpServletResponse response;
  private HandlerAdapter handlerAdapter;
  private HomeController controller;


  @Before
  public void setUp() {
    request = new MockHttpServletRequest();
    response = new MockHttpServletResponse();
    handlerAdapter = applicationContext.getBean(HandlerAdapter.class);
    controller = new HomeController();
  }

  @Test
  public void testGoToHome_GoesToHome() throws Exception {
    request.setMethod("GET");
    final ModelAndView mav = handlerAdapter.handle(request, response, controller);
    assertViewName(mav, FFConstants.HOME_VIEW);
    assertModelAttributeValues(mav, new HashMap<String, Object>());
  }
}