/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.flexjava.filter;

import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Component
public class FlexJavaFilter implements Filter {
  @Override
  public void init(FilterConfig filterConfig) throws ServletException {
  }

  @Override
  public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws
      IOException, ServletException {
    HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
    httpServletRequest.getSession(true).setAttribute("FJ_USER_ID", "SSPATI1");
    filterChain.doFilter(servletRequest, servletResponse);

//    if ("win".equalsIgnoreCase(environment)) {
//      userId = "SSPATI1";
//    } else {
//      Set<Principal> principals = Security.getCurrentSubject().getPrincipals();
//      if (!principals.isEmpty()) {
//        userId = principals.iterator().next().getName();
//        if (userId.indexOf("_monsanto") > 0) {
//          //RRMALL_monsantoT
//          userId = userId.substring(0, userId.indexOf("_"));
//        }
//      }
//    }

  }

  @Override
  public void destroy() {
  }
}