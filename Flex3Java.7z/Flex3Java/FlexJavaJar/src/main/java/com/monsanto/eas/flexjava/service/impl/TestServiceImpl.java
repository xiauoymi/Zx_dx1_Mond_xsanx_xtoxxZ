/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.flexjava.service.impl;

import com.monsanto.eas.flexjava.model.Area;
import com.monsanto.eas.flexjava.service.TestService;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Service
@RemotingDestination(value = "testService")
public class TestServiceImpl implements TestService {

  @RemotingInclude
  public Area lookupAreaById(Long areaId) {
    Area area = new Area();
    area.setId(areaId);
    area.setName("Europe");
    return area;
  }
}