/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.ff.dao;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import java.io.Serializable;
import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class HibernateDao<T, ID extends Serializable> extends HibernateDaoSupport implements GenericDao<T, ID> {
  private Class<? extends T> persistentClass;

  public void setupSessionFactory(SessionFactory sessionFactory, Class<? extends T> persistentClass) {
    this.persistentClass = persistentClass;
    this.setSessionFactory(sessionFactory);
  }

  public T findByPrimaryKey(ID id) {
    return (T) getCurrentSession().get(persistentClass, id);
  }

  public Collection<T> findAll() {
    Criteria criteria = createCriteria(false);
    return criteria.list();
  }

  public Collection<T> findAll(int startIndex, int fetchSize) {
    Criteria criteria = createCriteria(false);
    criteria.setFirstResult(startIndex);
    criteria.setFetchSize(fetchSize);
    return criteria.list();
  }

  public Collection<T> findAll(String key, boolean ascending) {
    Order order = getOrder(key, ascending);
    Criteria criteria = createCriteria(false);
    return criteria.addOrder(order).list();
  }

  public Collection<T> findByExample(T exampleInstance, String[] excludeProperty) {
    Criteria criteria = createCriteria();
    Example example = Example.create(exampleInstance).ignoreCase();
    for (String anExcludeProperty : excludeProperty) {
      example.excludeProperty(anExcludeProperty);
    }
    criteria.add(example);
    return criteria.list();
  }

  public T saveOrUpdate(T entity) {
    getCurrentSession().saveOrUpdate(entity);
    return entity;
  }

  public T merge(T entity) {
    Object object = getCurrentSession().merge(entity);
    return (T) object;
  }

  public void delete(T entity) {
    getCurrentSession().delete(entity);
  }

//  public void beginTransaction() {
//    getCurrentSession().beginTransaction();
//  }
//
//  public void commitTransaction() {
//  }

  public Criteria createCriteria() {
    return getCurrentSession().createCriteria(persistentClass);
  }

  public Criteria createCriteria(boolean isDeleted) {
    Criteria criteria = getCurrentSession().createCriteria(persistentClass);
    if (doesClassHaveIsDeleted()) {
      criteria.add(Restrictions.eq("deleted", isDeleted));
    }
    return criteria;
  }

  private boolean doesClassHaveIsDeleted() {
    try {
      persistentClass.getMethod("isDeleted");
    } catch (NoSuchMethodException e) {
      return false;
    }
    return true;
  }


  private Session getCurrentSession() {
    return getSessionFactory().getCurrentSession();
  }

  private Order getOrder(String key, boolean ascending) {
    Order order;
    if (ascending) {
      order = Order.asc(key);
    } else {
      order = Order.desc(key);
    }
    return order;
  }
}
