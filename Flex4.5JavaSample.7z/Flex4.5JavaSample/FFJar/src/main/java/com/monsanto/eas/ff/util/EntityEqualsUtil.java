/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.ff.util;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.lang.reflect.Field;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class EntityEqualsUtil {
     public static boolean identifierEquals(Object lhs, Object rhs) {
        Class<?> clazz = lhs.getClass();
        validateClassIsEntity(clazz);
        if (rhs == null) return false;
        if (rhs.getClass() != clazz) return false;

        Field field = getIdField(clazz);
        try {
            Object lhsResult = field.get(lhs);
            Object rhsResult = field.get(rhs);

            return lhsResult.equals(rhsResult);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public static int identifierHashCode(Object obj) {
        Class<?> clazz = obj.getClass();
        validateClassIsEntity(clazz);

        Field field = getIdField(clazz);
        try {
            return field.get(obj).hashCode();
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    private static void validateClassIsEntity(Class<?> clazz) {
        if (!clazz.isAnnotationPresent(Entity.class)) {
            throw new RuntimeException("class " + clazz + " does not have @Entity annotation");
        }
    }

    private static Field getIdField(Class<?> clazz) {
        for (Field field : clazz.getDeclaredFields()) {
            if (field.isAnnotationPresent(Id.class)) {
                field.setAccessible(true);
                return field;
            }
        }

        throw new RuntimeException("class " + clazz + " does not have any field with @Id annotation");
    }
}