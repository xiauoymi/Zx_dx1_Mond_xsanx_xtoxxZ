package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;

public class AnalysisFailure {
  private final Product product;
  private final Trait trait;
  private final String reason;

  public AnalysisFailure(Product product, Trait trait, String reason) {
    this.product = product;
    this.trait = trait;
    this.reason = reason;
  }

  public Product getProduct() {
    return product;
  }

  public Trait getTrait() {
    return trait;
  }

  public String getReason() {
    return reason;
  }
}
