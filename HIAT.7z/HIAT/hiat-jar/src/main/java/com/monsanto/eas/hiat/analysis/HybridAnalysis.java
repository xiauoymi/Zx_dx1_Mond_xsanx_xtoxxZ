package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;

import java.util.Collection;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface HybridAnalysis extends Comparable<HybridAnalysis>{
    Long getId();

    Product getProduct();

    Collection<HybridAnalysisDetail> getDetail();

    Trait getTrait();
}
