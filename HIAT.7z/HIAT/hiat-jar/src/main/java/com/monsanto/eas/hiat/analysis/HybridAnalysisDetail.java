package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.Season;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface HybridAnalysisDetail extends Comparable<HybridAnalysisDetail> {
  HybridAnalysisParentDetail getMaleParent();

  HybridAnalysisParentDetail getFemaleParent();

  void setSelected(boolean selected);

  boolean getIsSelected();

  Season getPcm150Season();

  Season getPcm300Season();

  Season getCommercialSeason();
}
