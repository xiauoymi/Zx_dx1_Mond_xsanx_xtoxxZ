package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.AvailabilityDate;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface HybridAnalysisParentDetail extends Comparable<HybridAnalysisParentDetail>{
    Product getProduct();

    Trait getTrait();

    AvailabilityDate getGeneration0Date();

    AvailabilityDate getGeneration1Date();

    AvailabilityDate getGeneration2Date();
}
