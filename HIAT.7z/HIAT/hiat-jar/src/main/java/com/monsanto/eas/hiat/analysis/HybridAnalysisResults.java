package com.monsanto.eas.hiat.analysis;

import java.util.List;

public class HybridAnalysisResults {
  private final List<HybridAnalysis> analysisList;
  private final List<String> errors;

  public HybridAnalysisResults(List<HybridAnalysis> analysisList, List<String> errors) {
    this.analysisList = analysisList;
    this.errors = errors;
  }

  public List<HybridAnalysis> getAnalysisList() {
    return analysisList;
  }

  public List<String> getErrors() {
    return errors;
  }
}
