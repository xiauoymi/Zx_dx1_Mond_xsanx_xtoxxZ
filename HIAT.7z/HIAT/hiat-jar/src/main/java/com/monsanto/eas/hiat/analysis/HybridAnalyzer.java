package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;

import java.util.Collection;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface HybridAnalyzer {
    HybridAnalysisResults analyze(Collection<Product> products, Collection<Trait> traits);
}

