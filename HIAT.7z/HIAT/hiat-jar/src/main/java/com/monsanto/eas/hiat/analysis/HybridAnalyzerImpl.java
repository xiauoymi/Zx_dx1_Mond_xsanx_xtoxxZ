package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisDetailImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisParentDetailImpl;
import com.monsanto.eas.hiat.availability.*;
import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.CodeTraitComparator;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.trait.TraitTree;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HybridAnalyzerImpl implements HybridAnalyzer {
  private final Calculator<Product, InbredAvailabilityInformation> inbredCalc;
  private final Calculator<Trait, List<TraitTree>> traitCalc;
  private final Calculator<ParentBaseTraitCombination, ParentPairCollection> parentCalc;
  private final Calculator<ParentPair, HybridAvailabilityInformation> parentAvailCalc;
  private final Calculator<ParentPairCollection, ParentPair> worstCaseCalc;
  private final ProductService prodService;
  private static final String HYBRID_CALCULATIONS_DATE_SOURCE = "Hybrid Calculations";

  public HybridAnalyzerImpl(Calculator<Product, InbredAvailabilityInformation> inbredCalc,
                            Calculator<Trait, List<TraitTree>> traitCalc,
                            Calculator<ParentBaseTraitCombination, ParentPairCollection> parentCalc,
                            Calculator<ParentPair, HybridAvailabilityInformation> parentAvailCalc,
                            Calculator<ParentPairCollection, ParentPair> worstCaseCalc,
                            ProductService prodService) {
    this.inbredCalc = inbredCalc;
    this.traitCalc = traitCalc;
    this.parentCalc = parentCalc;
    this.parentAvailCalc = parentAvailCalc;
    this.worstCaseCalc = worstCaseCalc;
    this.prodService = prodService;
  }

  public HybridAnalysisResults analyze(Collection<Product> products, Collection<Trait> traits) {
    List<HybridAnalysis> results = new ArrayList<HybridAnalysis>();
    Collection<Product> unqiueBaseProducts = prodService.getUniqueBaseProducts(products);
    List<Product> sortedProducts = sortProducts(unqiueBaseProducts);
    List<Trait> sortedTraits = sortTraits(traits);
    List<String> errors = new ArrayList<String>();
    for (Product product : sortedProducts) {
      for (Trait trait : sortedTraits) {
        HybridAnalysis analysis = analyze(product, trait);
        addResult(results, errors, analysis, product);
      }
    }

    return new HybridAnalysisResults(results, errors);
  }

  private void addResult(List<HybridAnalysis> results, List<String> errors, HybridAnalysis analysis, Product product) {
    if (analysis == null) {
      errors.add(product.getProductName(ProductNameType.TRAITED_PRECOMMERCIAL) + " (incomplete data)");
    } else {
      results.add(analysis);
    }
  }

  private List<Trait> sortTraits(Collection<Trait> unsortedTraits) {
    ArrayList<Trait> traitList = new ArrayList<Trait>(unsortedTraits);
    Collections.sort(traitList, new CodeTraitComparator());
    return traitList;
  }

  private List<Product> sortProducts(Collection<Product> unsortedProducts) {
    ArrayList<Product> productList = new ArrayList<Product>(unsortedProducts);
    Collections.sort(productList, new ManufacturingNameProductComparator());
    return productList;
  }

  private Product getBase(Product product) {
    if (product == null) {
      return null;
    } else {
      return product.getBase();
    }
  }

  protected HybridAnalysis analyze(Product product, Trait trait) {
    Product baseFemale = getBase(product.getFemaleParent());
    Product baseMale = getBase(product.getMaleParent());
    if (baseFemale == null || baseMale == null) {
      return null;
    }

    Collection<HybridAnalysisDetail> details = new ArrayList<HybridAnalysisDetail>();
    List<TraitTree> possibleParentTraits = traitCalc.calculate(trait);
    for (TraitTree traitTree : possibleParentTraits) {
      addDetailForParentPair(baseFemale, baseMale, details, traitTree);
    }

    return new HybridAnalysisImpl(product, trait, details);
  }

  private void addDetailForParentPair(Product baseFemale, Product baseMale, Collection<HybridAnalysisDetail> details, TraitTree traitTree) {
    Trait femaleTrait = traitTree.getFemaleParent();
    Trait maleTrait = traitTree.getMaleParent();
    ParentPairCollection parentPairs = parentCalc.calculate(
            new ParentBaseTraitCombination(baseFemale, femaleTrait, baseMale, maleTrait)
    );

    ParentPair worstCase = worstCaseCalc.calculate(parentPairs);
    if (worstCase == null) {
      addDetailForNoWorstCaseAvailable(baseFemale, baseMale, details, femaleTrait, maleTrait);
    } else {
      AvailabilityDate bestOverallPrimaryDate = calculateBestPrimaryDate(parentPairs);
      addDetailForWorstCase(details, femaleTrait, maleTrait, bestOverallPrimaryDate, worstCase);
    }
  }

  private void addDetailForWorstCase(Collection<HybridAnalysisDetail> details, Trait femaleTrait, Trait maleTrait, AvailabilityDate bestOverallPrimaryDate, ParentPair worstCase) {
    HybridAvailabilityInformation worstCaseAvailability = parentAvailCalc.calculate(worstCase);

    AvailabilityDate seedAvailPCM150Date = worstCaseAvailability.getPcm150Date();
    AvailabilityDate seedAvailPCM300Date = worstCaseAvailability.getPcm300Date();
    AvailabilityDate seedAvailCommDate = worstCaseAvailability.getCommercialDate();

    AvailabilityDate pcm150Date = seedAvailPCM150Date.latest(bestOverallPrimaryDate);
    AvailabilityDate pcm300Date = seedAvailPCM300Date.latest(bestOverallPrimaryDate);

    SeasonCalculator seasonCalc = new SeasonCalculator();
    Date primaryTestingDate = bestOverallPrimaryDate.getExactDate();
    Season pcm150Season = seasonCalc.calculateSeasonForPCM(pcm150Date.getExactDate());
    Season pcm300Season = seasonCalc.calculateSeasonForPCM(pcm300Date.getExactDate());
    Season commSeason = seasonCalc.calculateSeason(seedAvailCommDate.getExactDate(), primaryTestingDate);

    HybridAnalysisParentDetail maleDetail = getParentDetail(worstCase.getMaleParent(), maleTrait);
    HybridAnalysisParentDetail femaleDetail = getParentDetail(worstCase.getFemaleParent(), femaleTrait);

    details.add(new HybridAnalysisDetailImpl(maleDetail, femaleDetail,
            pcm150Season,
            pcm300Season,
            commSeason)
    );
  }

  private void addDetailForNoWorstCaseAvailable(Product baseFemale, Product baseMale, Collection<HybridAnalysisDetail> details, Trait femaleTrait, Trait maleTrait) {
    Collection<Product> femaleCandidates = prodService.getProductByBaseAndTrait(baseFemale, femaleTrait);
    Collection<Product> maleCandidates = prodService.getProductByBaseAndTrait(baseMale, maleTrait);

    Product displayedFemale = getFirstOrNull(femaleCandidates);
    Product displayedMale = getFirstOrNull(maleCandidates);

    HybridAnalysisParentDetail maleDetail = getFailedDetail(displayedMale, maleTrait);
    HybridAnalysisParentDetail femaleDetail = getFailedDetail(displayedFemale, femaleTrait);

    details.add(new HybridAnalysisDetailImpl(
            maleDetail,
            femaleDetail,
            Season.NONE,
            Season.NONE,
            Season.NONE
    ));
  }

  private HybridAnalysisParentDetail getFailedDetail(Product product, Trait trait) {
    if (product == null) {
      return new HybridAnalysisParentDetailImpl(
              null,
              trait,
              AvailabilityDateImpl.getUnknown(HYBRID_CALCULATIONS_DATE_SOURCE),
              AvailabilityDateImpl.getUnknown(HYBRID_CALCULATIONS_DATE_SOURCE),
              AvailabilityDateImpl.getUnknown(HYBRID_CALCULATIONS_DATE_SOURCE)
      );
    } else {
      return getParentDetail(product, trait);
    }
  }

  private Product getFirstOrNull(Collection<Product> products) {
    if (products.isEmpty()) {
      return null;
    } else {
      return products.iterator().next();
    }
  }

  private AvailabilityDate calculateBestPrimaryDate(ParentPairCollection parentPairs) {
    AvailabilityDate bestMaleDate = AvailabilityDateImpl.getUnknown(HYBRID_CALCULATIONS_DATE_SOURCE);
    AvailabilityDate bestFemaleDate = AvailabilityDateImpl.getUnknown(HYBRID_CALCULATIONS_DATE_SOURCE);

    for (ParentPair parentPair : parentPairs.getParentPairs()) {
      AvailabilityDate currMaleDate = getPrimaryDate(parentPair.getMaleParent());
      AvailabilityDate currFemaleDate = getPrimaryDate(parentPair.getFemaleParent());

      bestMaleDate = bestMaleDate.earliest(currMaleDate);
      bestFemaleDate = bestFemaleDate.earliest(currFemaleDate);
    }

    return bestMaleDate.latest(bestFemaleDate);
  }

  private AvailabilityDate getPrimaryDate(Product parent) {
    String primaryDateSource = "Primary Date";
    if (parent == null) {
      return AvailabilityDateImpl.getUnknown(primaryDateSource);
    } else if (parent.isPrimary()) {
      return new AvailabilityDateImpl("Is Primary", getPlaceholdPrimaryTestingDateForPrimaryProducts());
    } else {
      return new AvailabilityDateImpl(primaryDateSource, parent.getPrimaryTestingDate());
    }
  }

  private Date getPlaceholdPrimaryTestingDateForPrimaryProducts() {
    // returns a date in the past, so primary testing date does not affect products that are already primary
    return new GregorianCalendar(1901, Calendar.JANUARY, 1).getTime();
  }

  private HybridAnalysisParentDetail getParentDetail(Product parent, Trait trait) {
    InbredAvailabilityInformation inbredAvail = inbredCalc.calculate(parent);
    return new HybridAnalysisParentDetailImpl(
            parent,
            trait,
            inbredAvail.getG0Date(),
            inbredAvail.getG1Date(),
            inbredAvail.getG2Date()
    );
  }

  private class ManufacturingNameProductComparator implements Comparator<Product> {
    public int compare(Product p1, Product p2) {
      return p1.getProductName(ProductNameType.MANUFACTURING).compareTo(p2.getProductName(ProductNameType.MANUFACTURING));
    }
  }
}

