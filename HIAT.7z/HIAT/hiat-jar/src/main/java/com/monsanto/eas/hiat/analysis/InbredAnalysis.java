package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.HybridAvailabilitySeasonInformation;
import com.monsanto.eas.hiat.availability.InbredAvailabilityInformation;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface InbredAnalysis {
  Product getProduct();

  Trait getTrait();

  Boolean getPrimaryFlag();

  InbredAvailabilityInformation getInbredAvailabilityInfo();

  HybridAvailabilitySeasonInformation getHybridAvailabilityInfo();
}
