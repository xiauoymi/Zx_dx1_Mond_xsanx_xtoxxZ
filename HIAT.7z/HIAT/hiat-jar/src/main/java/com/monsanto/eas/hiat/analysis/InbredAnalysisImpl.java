package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.HybridAvailabilitySeasonInformation;
import com.monsanto.eas.hiat.availability.InbredAvailabilityInformation;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredAnalysisImpl implements InbredAnalysis {
  private final Product product;
  private final Trait trait;
  private final Boolean primaryFlag;
  private final InbredAvailabilityInformation inbredInfo;
  private final HybridAvailabilitySeasonInformation hybridInfo;

  public InbredAnalysisImpl(Product product, Trait trait, Boolean primaryFlag,
                            InbredAvailabilityInformation inbredInfo,
                            HybridAvailabilitySeasonInformation hybridInfo) {
    this.product = product;
    this.trait = trait;
    this.primaryFlag = primaryFlag;
    this.inbredInfo = inbredInfo;
    this.hybridInfo = hybridInfo;
  }

  public Product getProduct() {
    return product;
  }

  public Trait getTrait() {
    return trait;
  }

  public Boolean getPrimaryFlag() {
    return primaryFlag;
  }

  public InbredAvailabilityInformation getInbredAvailabilityInfo() {
    return inbredInfo;
  }

  public HybridAvailabilitySeasonInformation getHybridAvailabilityInfo() {
    return hybridInfo;
  }
}
