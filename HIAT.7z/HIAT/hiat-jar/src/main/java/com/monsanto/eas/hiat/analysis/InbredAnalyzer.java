package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public interface InbredAnalyzer {
  InbredAnalysis analyze(Product product, Trait trait);
}
