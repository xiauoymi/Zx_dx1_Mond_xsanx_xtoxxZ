package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.AvailabilityDate;
import com.monsanto.eas.hiat.availability.HybridAvailabilityInformation;
import com.monsanto.eas.hiat.availability.HybridAvailabilitySeasonInformation;
import com.monsanto.eas.hiat.availability.InbredAvailabilityInformation;
import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.service.ProductService;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredAnalyzerImpl implements InbredAnalyzer {
  private final ProductService productService;
  private final Calculator<Product, InbredAvailabilityInformation> inbredAvailCalc;
  private final Calculator<Product, HybridAvailabilityInformation> hybridAvailCalc;

  public InbredAnalyzerImpl(ProductService productService, Calculator<Product, InbredAvailabilityInformation> inbredAvailCalc, Calculator<Product, HybridAvailabilityInformation> hybridAvailCalc) {
    this.productService = productService;
    this.inbredAvailCalc = inbredAvailCalc;
    this.hybridAvailCalc = hybridAvailCalc;
  }

  public InbredAnalysis analyze(Product product, Trait trait) {
    Collection<Product> products = productService.getProductByBaseAndTrait(product, trait);
    if (products.isEmpty()) {
      return new InbredAnalysisImpl(product, trait, Boolean.FALSE, null, null);
    } else {
      boolean primaryFlag = getPrimaryFlag(products);
      InbredAvailabilityInformation inbredInfo = getInbredInfo(products);
      HybridAvailabilitySeasonInformation hybridInfo = getHybridInfo(products);
      return new InbredAnalysisImpl(product, trait, primaryFlag, inbredInfo, hybridInfo);
    }
  }

  private InbredAvailabilityInformation getInbredInfo(Collection<Product> products) {
    List<InbredAvailabilityInformation> infoList = new ArrayList<InbredAvailabilityInformation>(products.size());
    for (Product product : products) {
      infoList.add(inbredAvailCalc.calculate(product));
    }
    Collections.sort(infoList, new InbredAvailabilityInformationComparator());
    return infoList.get(infoList.size() - 1);
  }

  private HybridAvailabilitySeasonInformation getHybridInfo(Collection<Product> products) {
    List<HybridAvailabilityInformation> infoList = new ArrayList<HybridAvailabilityInformation>(products.size());
    for (Product product : products) {
      infoList.add(hybridAvailCalc.calculate(product));
    }
    Collections.sort(infoList, new HybridAvailabilityInformationComparator());
    Date primaryTestingDate = getPrimaryTestingDate(products);
    return new HybridAvailabilitySeasonInformation(infoList.get(infoList.size() - 1), primaryTestingDate);
  }

  private Date getPrimaryTestingDate(Collection<Product> products) {
    Date earliestDate = null;
    for (Product product : products) {
      if (product.isPrimary() || "CONV".equals(product.getTrait().getCode())) {
        return new Date(); // has a primary, or is conventional, so its available now
      }
      earliestDate = earliest(earliestDate, product.getPrimaryTestingDate());
    }
    return earliestDate;
  }

  private Date earliest(Date date1, Date date2) {
    if (date1 != null && (date2 == null || date1.before(date2))) {
      return date1;
    } else {
      return date2;
    }
  }

  private boolean getPrimaryFlag(Collection<Product> products) {
    for (Product product : products) {
      if (product.isPrimary()) {
        return true;
      }
    }

    return false;
  }

  private static class InbredAvailabilityInformationComparator implements Comparator<InbredAvailabilityInformation> {
    public int compare(InbredAvailabilityInformation o1, InbredAvailabilityInformation o2) {
      if (o1 == o2) {
        return 0;
      } else if (o1 == null || o2 == null) {
        return compareForNulls(o1, o2);
      } else {
        return availabilityDateCompare(o1.getG2Date(), o2.getG2Date());
      }
    }
  }

  private static class HybridAvailabilityInformationComparator implements Comparator<HybridAvailabilityInformation> {
    public int compare(HybridAvailabilityInformation o1, HybridAvailabilityInformation o2) {
      if (o1 == o2) {
        return 0;
      } else if (o1 == null || o2 == null) {
        return compareForNulls(o1, o2);
      } else {
        return availabilityDateCompare(o1.getCommercialDate(), o2.getCommercialDate());
      }
    }
  }

  private static int availabilityDateCompare(AvailabilityDate date1, AvailabilityDate date2) {
    Date o1Date = date1.getExactDate();
    Date o2Date = date2.getExactDate();
    if (o1Date == null || o2Date == null) {
      return compareForNulls(o1Date, o2Date);
    } else {
      return org.apache.commons.lang.time.DateUtils.truncate(o1Date, Calendar.DATE).compareTo(o2Date);
    }
  }

  private static int compareForNulls(Object o1, Object o2) {

    if (o1 == null) {
      return 1;
    } else {
      return -1;
    }
  }
}
