package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.InventoryType;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredProductionDetailImpl {
    private final InventoryType invType;
    private final long quantity;

    public InbredProductionDetailImpl(InventoryType invType, long quantity) {
        this.invType = invType;
        this.quantity = quantity;
    }

    public InventoryType getInvType() {
        return invType;
    }

    public long getQuantity() {
        return quantity;
    }
}
