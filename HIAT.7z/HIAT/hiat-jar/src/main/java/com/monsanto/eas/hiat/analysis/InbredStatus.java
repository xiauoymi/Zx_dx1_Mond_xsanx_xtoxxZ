package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;

import java.util.Collection;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface InbredStatus extends Comparable<InbredStatus>{
    Product getProduct();
    Collection<InbredStatusDetail> getDetail();
}
