package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.dao.InventoryDAO;
import com.monsanto.eas.hiat.dao.ProductionDAO;
import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.service.ProductService;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredStatusAnalyzer {
  private final ProductionDAO productionDao;
  private final InventoryDAO inventoryDAO;
  private final ProductService productService;

  public InbredStatusAnalyzer(
          ProductService productService, InventoryDAO inventoryDao, ProductionDAO productionDao) {
    this.productionDao = productionDao;
    this.productService = productService;
    this.inventoryDAO = inventoryDao;
  }

  public List<InbredStatus> analyze(Collection<Product> products, Collection<Trait> traits) {
    List<InbredStatus> statusList = new ArrayList<InbredStatus>();
    for (Product product : getUniqueBaseProducts(products)) {
      InbredStatus status = processAnalysisForProduct(product, traits);
      addAnalysisIfValid(statusList, status);
    }
    Collections.sort(statusList);
    return statusList;
  }

  private Iterable<? extends Product> getUniqueBaseProducts(Collection<Product> products) {
    return productService.getUniqueBaseProducts(products);
  }

  private void addAnalysisIfValid(Collection<InbredStatus> statusList, InbredStatus status) {
    if (status != null) {
      statusList.add(status);
    }
  }

  private InbredStatus processAnalysisForProduct(Product product, Iterable<Trait> traits) {
    Collection<InbredStatusDetail> details = getDetailsForProductAndTraits(product, traits);
    if (details.isEmpty()) {
      return null;
    } else {
      return new InbredStatusImpl(product, sortTheDetailListByTraitCode(details));
    }
  }

  private Collection<InbredStatusDetail> getDetailsForProductAndTraits(Product product, Iterable<Trait> traits) {
    Collection<InbredStatusDetail> details = new ArrayList<InbredStatusDetail>();
    for (Trait trait : traits) {
      List<InbredStatusDetail> detail = processAnalysisForProductAndTrait(product, trait);
      if (detail.isEmpty()) {
        details.add(new InbredStatusDetailImpl(trait, null, null, null, new HashMap<InventoryType, InventoryEntry>(),
                new HashMap<InventoryType, Collection<ProductionEntry>>(), new HashMap<InventoryType, Collection<ProductionEntry>>()));
      } else {
        details.addAll(detail);
      }
    }
    return details;
  }

  private List<InbredStatusDetail> sortTheDetailListByTraitCode(Collection<InbredStatusDetail> details) {
    List<InbredStatusDetail> inbredStatusDetailArrayList = new ArrayList<InbredStatusDetail>(details);
    Collections.sort(inbredStatusDetailArrayList, new TraitComparator());
    return inbredStatusDetailArrayList;
  }

  private List<InbredStatusDetail> processAnalysisForProductAndTrait(Product product, Trait trait) {

    Collection<Product> traitedProductList = productService.getProductByBaseAndTrait(product, trait);

    List<InbredStatusDetail> detailList = new ArrayList<InbredStatusDetail>();
    for (Product traitedProduct : traitedProductList) {
      Map<InventoryType, InventoryEntry> inventoryQuantities = getInventoryDetails(traitedProduct);
      Map<InventoryType, Collection<ProductionEntry>> allProdQuantities = getProductionDetails(traitedProduct);
      Map<InventoryType, Collection<ProductionEntry>> productionQuantities = filterProdQuantitiesByPlanned(allProdQuantities, false);
      Map<InventoryType, Collection<ProductionEntry>> plannedProductionQuantities = filterProdQuantitiesByPlanned(allProdQuantities, true);
      InbredStatusDetail detail = new InbredStatusDetailImpl(trait, traitedProduct,
              traitedProduct.getHandoffDate(), traitedProduct.getPrimaryTestingDate(),
              inventoryQuantities, productionQuantities, plannedProductionQuantities);
      detailList.add(detail);
    }
    Collections.sort(detailList);
    return detailList;
  }

  private Map<InventoryType, Collection<ProductionEntry>> filterProdQuantitiesByPlanned(
          Map<InventoryType, Collection<ProductionEntry>> allProdQuantities,
          boolean planned) {
    Map<InventoryType, Collection<ProductionEntry>> filteredMap = new HashMap<InventoryType, Collection<ProductionEntry>>();
    for (InventoryType invType : allProdQuantities.keySet()) {
      Collection<ProductionEntry> originalCollection = allProdQuantities.get(invType);
      Collection<ProductionEntry> filteredCollection = getFilteredCollectionByPlanned(planned, originalCollection);
      filteredMap.put(invType, filteredCollection);
    }
    return filteredMap;
  }

  private Collection<ProductionEntry> getFilteredCollectionByPlanned(boolean planned, Collection<ProductionEntry> originalCollection) {
    Collection<ProductionEntry> filteredEntries = new ArrayList<ProductionEntry>();
    for (ProductionEntry prodEntry : originalCollection) {
      if (prodEntry.isPlanned() == planned) {
        filteredEntries.add(prodEntry);
      }
    }
    return filteredEntries;
  }

  private Map<InventoryType, InventoryEntry> getInventoryDetails(Product product) {
    Map<InventoryType, InventoryEntry> inventoryQuanties = new HashMap<InventoryType, InventoryEntry>();
    List<InventoryEntry> results = inventoryDAO.findByProduct(product);
    for (InventoryEntry inv : results) {
      inventoryQuanties.put(inv.getType(), inv);
    }

    return inventoryQuanties;
  }

  private Map<InventoryType, Collection<ProductionEntry>> getProductionDetails(Product product) {
    List<ProductionEntry> results = productionDao.findByProduct(product);
    Map<InventoryType, Collection<ProductionEntry>> productionQuantities = new HashMap<InventoryType, Collection<ProductionEntry>>();
    for (ProductionEntry production : results) {
      InventoryType invType = production.getType();
      Collection<ProductionEntry> entries = productionQuantities.get(invType);
      if (entries == null) {
        entries = new ArrayList<ProductionEntry>();
        productionQuantities.put(invType, entries);
      }
      entries.add(production);
    }

    return productionQuantities;
  }

}