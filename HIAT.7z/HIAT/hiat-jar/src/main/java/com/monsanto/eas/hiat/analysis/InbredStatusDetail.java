package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.*;

import java.util.Collection;
import java.util.Date;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface InbredStatusDetail extends Comparable<InbredStatusDetail>{
    Trait getTrait();
    Date getHandoffDate();
    Date getPrimaryDate();
    long getInventory(InventoryType invType);
    long getProduction(InventoryType invType);
    long getPlannedProduction(InventoryType invType);

  Map<InventoryType, InventoryEntry> getInventoryQuantities();

  Map<InventoryType, Collection<ProductionEntry>> getProductionQuantities();
  Map<InventoryType, Collection<ProductionEntry>> getPlannedProductionQuantities();

  Map<InventoryType, ProductionEntry> getTotalProductionQuantities();
  Map<InventoryType, ProductionEntry> getTotalPlannedProductionQuantities();

  Product getProduct();
}
