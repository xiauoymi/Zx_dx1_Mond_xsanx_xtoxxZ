package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.hibernate.ProductionEntryImpl;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredStatusDetailImpl implements InbredStatusDetail {
  private final Trait trait;
  private final Product product;
  private final Date handoffDate;
  private final Date primaryDate;
  private Map<InventoryType, InventoryEntry> inventoryQuantities;
  private Map<InventoryType, Collection<ProductionEntry>> productionQuantities;
  private Map<InventoryType, Collection<ProductionEntry>> plannedProductionQuantities;

  public InbredStatusDetailImpl(Trait trait, Product product, Date handoffDate, Date primaryDate,
                                  Map<InventoryType, InventoryEntry> inventoryQuantities,
                                  Map<InventoryType, Collection<ProductionEntry>> productionQuantities,
                                  Map<InventoryType, Collection<ProductionEntry>> plannedProductionQuantities) {
    this.trait = trait;
    this.product = product;
    this.handoffDate = handoffDate;
    this.primaryDate = primaryDate;
    this.inventoryQuantities = inventoryQuantities;
    this.productionQuantities = productionQuantities;
    this.plannedProductionQuantities = plannedProductionQuantities;
  }

  public Trait getTrait() {
    return trait;
  }

  public Date getHandoffDate() {
    return handoffDate;
  }

  public Date getPrimaryDate() {
    return primaryDate;
  }

  public long getInventory(InventoryType invType) {
    long totalQty = 0;
    for (InventoryType type : InventoryType.values()) {
      if (type == invType && inventoryQuantities.get(type) != null) {
        totalQty += inventoryQuantities.get(type).getQuantity();
      }
    }

    return totalQty;
  }

  public long getProduction(InventoryType invType) {
    return getProductionFromMap(invType, productionQuantities);
  }

  private long getProductionFromMap(InventoryType invType, Map<InventoryType, Collection<ProductionEntry>> invProdMap) {
    long totalQty = 0;
    Collection<ProductionEntry> prodEntries = invProdMap.get(invType);
    if (prodEntries == null) {
      return 0L;
    } else {
      for (ProductionEntry prodEntry : prodEntries) {
        totalQty += prodEntry.getQuantity();
      }

      return totalQty;
    }
  }

  public long getPlannedProduction(InventoryType invType) {
    return getProductionFromMap(invType, plannedProductionQuantities);
  }

  public Map<InventoryType, InventoryEntry> getInventoryQuantities() {
    return inventoryQuantities;
  }

  public Map<InventoryType, Collection<ProductionEntry>> getProductionQuantities() {
    return productionQuantities;
  }

  public Map<InventoryType, Collection<ProductionEntry>> getPlannedProductionQuantities() {
    return plannedProductionQuantities;
  }

  public Product getProduct() {
    return product;
  }

  public int compareTo(InbredStatusDetail detail) {
    return this.getProduct().getProductName(ProductNameType.TRAITED_PRECOMMERCIAL).compareTo(detail.getProduct().getProductName(ProductNameType.TRAITED_PRECOMMERCIAL));
  }

  public Map<InventoryType, ProductionEntry> getTotalProductionQuantities() {
    return getTotalMap(getProductionQuantities());
  }

  public Map<InventoryType, ProductionEntry> getTotalPlannedProductionQuantities() {
    return getTotalMap(getPlannedProductionQuantities());
  }

  private Map<InventoryType, ProductionEntry> getTotalMap(Map<InventoryType, Collection<ProductionEntry>> collectionMap) {
    Map<InventoryType, ProductionEntry> totalMap = new HashMap<InventoryType, ProductionEntry>();
    for (InventoryType invType : collectionMap.keySet()) {
      totalMap.put(invType, getTotalProductionEntryForInvType(collectionMap, invType));
    }
    return totalMap;
  }

  private ProductionEntry getTotalProductionEntryForInvType(Map<InventoryType, Collection<ProductionEntry>> collectionMap, InventoryType invType) {
    Collection<ProductionEntry> entryCollection = collectionMap.get(invType);
    if (entryCollection.isEmpty()) {
      return null;
    }

    long totalQty = getTotalQuantity(entryCollection);
    Product prod = getFirstProduct(entryCollection);
    boolean isPlanned = getFirstIsPlanned(entryCollection);
    Date latestDate = getLatestDate(entryCollection);

    return new ProductionEntryImpl(latestDate, prod, totalQty, invType, isPlanned);
  }

  private Date getLatestDate(Collection<ProductionEntry> entryCollection) {
    Iterator<ProductionEntry> iterator = entryCollection.iterator();
    ProductionEntry firstEntry = entryCollection.iterator().next();
    Date latestDate = firstEntry.getAvailableDate();
    while (iterator.hasNext()) {
      ProductionEntry currEntry = iterator.next();
      Date currDate = currEntry.getAvailableDate();
      if (isDateBefore(latestDate, currDate)) {
        latestDate = currDate;
      }
    }
    return latestDate;
  }

  private boolean isDateBefore(Date latestDate, Date currDate) {
    return latestDate != null && (currDate == null || latestDate.before(currDate));
  }

  private boolean getFirstIsPlanned(Collection<ProductionEntry> entryCollection) {
    return entryCollection.iterator().next().isPlanned();
  }

  private Product getFirstProduct(Collection<ProductionEntry> entryCollection) {
    return entryCollection.iterator().next().getProduct();
  }

  private long getTotalQuantity(Collection<ProductionEntry> entryCollection) {
    long totalQty = 0L;
    for (ProductionEntry entry : entryCollection) {
      totalQty += entry.getQuantity();
    }
    return totalQty;
  }
}