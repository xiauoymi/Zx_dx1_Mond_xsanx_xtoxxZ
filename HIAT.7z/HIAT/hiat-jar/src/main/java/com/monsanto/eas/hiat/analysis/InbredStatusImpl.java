package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductNameType;

import java.util.Collection;

/**
 * note: natural ordering is not compatible with equals (equals is not redefined, ordering is just needed for consistent display order)
 *
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@SuppressWarnings({"ComparableImplementedButEqualsNotOverridden"})
public class InbredStatusImpl implements InbredStatus {
  private final Product product;
  private final Collection<InbredStatusDetail> detail;

  public InbredStatusImpl(Product product, Collection<InbredStatusDetail> detail) {
    this.product = product;
    this.detail = detail;
  }

  public Product getProduct() {
    return product;
  }

  public Collection<InbredStatusDetail> getDetail() {
    return detail;
  }

  public int compareTo(InbredStatus inbredStatus) {
    return getProduct().getProductName(ProductNameType.BASE_PRECOMMERCIAL).compareTo(inbredStatus.getProduct().getProductName(ProductNameType.BASE_PRECOMMERCIAL));
  }
}
