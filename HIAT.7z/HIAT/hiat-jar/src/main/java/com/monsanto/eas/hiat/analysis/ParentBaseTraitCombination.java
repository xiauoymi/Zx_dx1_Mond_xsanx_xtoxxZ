package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;

public class ParentBaseTraitCombination {
  private final ProductTraitPair female;
  private final ProductTraitPair male;

  private final String key; // used to speed up equals and hashcode

  public ParentBaseTraitCombination(Product baseFemaleProduct, Trait femaleTrait, Product baseMaleProduct, Trait maleTrait) {
    this.female = new ProductTraitPair(baseFemaleProduct, femaleTrait);
    this.male = new ProductTraitPair(baseMaleProduct, maleTrait);
    this.key = this.female.getKey() + "@" + this.male.getKey();
  }

  public Product getBaseFemaleProduct() {
    return female.getBaseProduct();
  }

  public Trait getFemaleTrait() {
    return female.getTrait();
  }

  public Product getBaseMaleProduct() {
    return male.getBaseProduct();
  }

  public Trait getMaleTrait() {
    return male.getTrait();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof ParentBaseTraitCombination)) return false;

    return key.equals(((ParentBaseTraitCombination) o).key);
  }

  @Override
  public int hashCode() {
    return key.hashCode();
  }

  @Override
  public String toString() {
    return "Parents{" + getBaseFemaleProduct() + ":" + getFemaleTrait() + "," + getBaseMaleProduct() + ":" + getMaleTrait() + "}";
  }

}
