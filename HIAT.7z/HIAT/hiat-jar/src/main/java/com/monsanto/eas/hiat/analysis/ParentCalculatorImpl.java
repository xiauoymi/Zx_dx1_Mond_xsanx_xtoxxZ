package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.util.OrderedPair;
import com.monsanto.eas.hiat.util.SetCalculator;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ParentCalculatorImpl implements Calculator<ParentBaseTraitCombination, ParentPairCollection> {
  private Calculator<ProductTraitPair, Collection<Product>> productStatusFilter;

  public ParentCalculatorImpl(Calculator<ProductTraitPair, Collection<Product>> productStatusFilter) {
    this.productStatusFilter = productStatusFilter;
  }

  public ParentPairCollection calculate(ParentBaseTraitCombination parents) {
    Collection<Product> femaleCandidates = productStatusFilter.calculate(new ProductTraitPair(parents.getBaseFemaleProduct(), parents.getFemaleTrait()));
    Collection<Product> maleCandidates = productStatusFilter.calculate(new ProductTraitPair(parents.getBaseMaleProduct(), parents.getMaleTrait()));

    Collection<OrderedPair<Product, Product>> parentsCartesianProduct = SetCalculator.calculateCartesianProduct(femaleCandidates, maleCandidates);
    return convertOrderedCollectionToParentPairCollection(parentsCartesianProduct);
  }

  private ParentPairCollection convertOrderedCollectionToParentPairCollection(Collection<OrderedPair<Product, Product>> parentsCartesianProduct) {
    Collection<ParentPair> parentCollection = new ArrayList<ParentPair>(parentsCartesianProduct.size());
    for (OrderedPair<Product, Product> pair : parentsCartesianProduct) {
      parentCollection.add(new ParentPair(pair.getLeft(), pair.getRight()));
    }
    return new ParentPairCollection(parentCollection);
  }
}
