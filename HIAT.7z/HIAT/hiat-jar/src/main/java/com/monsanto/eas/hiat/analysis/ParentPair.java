package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;

public class ParentPair {
  private final Product femaleParent;
  private final Product maleParent;
  private final String key;

  public ParentPair(Product femaleParent, Product maleParent) {
    this.femaleParent = femaleParent;
    this.maleParent = maleParent;
    this.key = "@" +
            ((femaleParent == null) ? -1L : femaleParent.getId()) + '@' +
            ((maleParent == null) ? -1L : maleParent.getId());
  }

  public Product getFemaleParent() {
    return femaleParent;
  }

  public Product getMaleParent() {
    return maleParent;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof ParentPair)) return false;

    return key.equals(((ParentPair) o).key);
  }

  @Override
  public int hashCode() {
    return key.hashCode();
  }

  @Override
  public String toString() {
    return "{" + femaleParent + "+" + maleParent + "}";
  }
}
