package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.HybridAvailabilityInformation;
import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ParentPairAvailabilityCalculatorImpl implements Calculator<ParentPair, HybridAvailabilityInformation> {
  private final Calculator<Product, HybridAvailabilityInformation> hybridCalc;

  public ParentPairAvailabilityCalculatorImpl(Calculator<Product, HybridAvailabilityInformation> hybridCalc) {
    this.hybridCalc = hybridCalc;
  }

  public HybridAvailabilityInformation calculate(ParentPair pair) {
    HybridAvailabilityInformation maleAvail = getParentsAvailability(pair.getMaleParent());
    HybridAvailabilityInformation femaleAvail = getParentsAvailability(pair.getFemaleParent());
    return maleAvail.latest(femaleAvail);
  }

  private HybridAvailabilityInformation getParentsAvailability(Product parent) {
    return hybridCalc.calculate(parent);
  }
}
