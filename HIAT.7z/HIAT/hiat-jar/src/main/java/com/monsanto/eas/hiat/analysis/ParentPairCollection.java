package com.monsanto.eas.hiat.analysis;

import java.util.Collection;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class ParentPairCollection {
  private final Collection<ParentPair> parentPairs;

  public ParentPairCollection(Collection<ParentPair> parentPairs) {
    this.parentPairs = parentPairs;
  }

  public Collection<ParentPair> getParentPairs() {
    return parentPairs;
  }

  @Override
  public int hashCode() {
    return parentPairs.size();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == this) {
      return true;
    }

    if (!(obj instanceof ParentPairCollection)) {
      return false;
    }

    ParentPairCollection otherCol = (ParentPairCollection) obj;
    return parentPairs.containsAll(otherCol.getParentPairs()) && otherCol.getParentPairs().containsAll(parentPairs);
  }

  @Override
  public String toString() {
    return "ParentPairs:" + parentPairs.toString();
  }
}
