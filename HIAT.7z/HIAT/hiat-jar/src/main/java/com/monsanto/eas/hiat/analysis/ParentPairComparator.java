package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.AvailabilityDate;
import com.monsanto.eas.hiat.availability.HybridAvailabilityInformation;
import com.monsanto.eas.hiat.calculator.Calculator;

import java.util.Comparator;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ParentPairComparator implements Comparator<ParentPair> {
  private final Calculator<ParentPair, HybridAvailabilityInformation> pairAvailabilityCalculator;

  public ParentPairComparator(Calculator<ParentPair, HybridAvailabilityInformation> pairAvailabilityCalculator) {
    this.pairAvailabilityCalculator = pairAvailabilityCalculator;
  }

  public int compare(ParentPair o1, ParentPair o2) {
    AvailabilityDate pair1CommAvail = pairAvailabilityCalculator.calculate(o1).getCommercialDate();
    AvailabilityDate pair2CommAvail = pairAvailabilityCalculator.calculate(o2).getCommercialDate();

    if (pair1CommAvail.equals(pair2CommAvail)) {
      return 0;
    } else if (pair1CommAvail.after(pair2CommAvail)) {
      return 1;
    } else {
      return -1;
    }
  }
}
