package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.calculator.Calculator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ParentWorstCaseCalculatorImpl implements Calculator<ParentPairCollection, ParentPair> {
  private final Comparator<ParentPair> parentComparator;

  public ParentWorstCaseCalculatorImpl(Comparator<ParentPair> parentComparator) {
    this.parentComparator = parentComparator;
  }

  public ParentPair calculate(ParentPairCollection parentPairs) {
    if (parentPairs.getParentPairs().isEmpty()) {
      return null;
    } else {
      List<ParentPair> sortedList = new ArrayList<ParentPair>(parentPairs.getParentPairs());
      Collections.sort(sortedList, parentComparator);
      return sortedList.get(sortedList.size() - 1);
    }
  }

}
