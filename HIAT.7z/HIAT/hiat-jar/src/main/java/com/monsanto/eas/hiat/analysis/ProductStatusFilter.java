package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.InventoryService;
import com.monsanto.eas.hiat.service.ProductionService;
import com.monsanto.eas.hiat.util.CollectionUtil;

import java.util.Collection;
import java.util.ArrayList;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class ProductStatusFilter implements Calculator<ProductTraitPair, Collection<Product>> {
  private final ProductService prodService;
  private final InventoryService invService;
  private final ProductionService productionService;

  public ProductStatusFilter(ProductService prodService, InventoryService invService, ProductionService productionService) {
    this.prodService = prodService;
    this.invService = invService;
    this.productionService = productionService;
  }

  public Collection<Product> calculate(ProductTraitPair input) {
    Product baseProduct = input.getBaseProduct();
    Trait trait = input.getTrait();
    Collection<Product> potentialProducts = prodService.getProductByBaseAndTrait(baseProduct, trait);
    return filterByPrimary(potentialProducts);
  }

  private Collection<Product> filterByPrimary(Iterable<Product> products) {
    Product primaryProduct = findPrimaryProduct(products);
    final boolean hasPrimaryProduct = (primaryProduct != null);
    if (hasPrimaryProduct) {
      return CollectionUtil.singleItemAsCollection(primaryProduct);
    } else {
      return filterActiveByInventory(getActiveProducts(products));
    }
  }

  private Collection<Product> filterActiveByInventory(Collection<Product> activeProducts) {
    Collection<Product> activesWithInventory = new ArrayList<Product>(activeProducts.size());
    for (Product product : activeProducts) {
      if (hasInventoryG0G1G2(product) || hasProductionG0G1G2(product)) {
        activesWithInventory.add(product);
      }
    }

    if (activesWithInventory.isEmpty()) {
      return activeProducts; // none of the products have inventory/production, just use all of them
    } else {
      return activesWithInventory; // since some have inventory/production, only use those
    }
  }

  private boolean hasInventoryG0G1G2(Product product) {
    for (InventoryType invType : InventoryType.values()) {
      if (invService.getInventory(product, invType) > 0) {
        return true;
      }
    }

    return false;
  }

  private boolean hasProductionG0G1G2(Product product) {
    for (InventoryType invType : InventoryType.values()) {
      if (!productionService.findByProduct(product, invType).isEmpty()) {
        return true;
      }
    }

    return false;
  }

  private Collection<Product> getActiveProducts(Iterable<Product> products) {
    Collection<Product> activeProducts = new ArrayList<Product>();
    for (Product product : products) {
      String status = product.getStatus();
      if (status == null || status.toUpperCase().startsWith("ACTIVE") || status.toUpperCase().startsWith("UNKNOWN")) {
        activeProducts.add(product);
      }
    }
    return activeProducts;
  }

  private Product findPrimaryProduct(Iterable<Product> products) {
    for (Product product : products) {
      if (product.isPrimary()) {
        return product;
      }
    }

    return null;
  }
}
