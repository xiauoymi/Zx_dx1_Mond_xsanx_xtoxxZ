package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class ProductTraitPair {
  private final Product baseProduct;
  private final Trait trait;

  private final String key; // used to speed up equals and hashcode

  public ProductTraitPair(Product baseProduct, Trait trait) {
    this.baseProduct = baseProduct;
    this.trait = trait;
    this.key = generateKey(baseProduct, trait);
  }

  private static String generateKey(Product baseProduct, Trait trait) {
    return "@" + generateKeyForProduct(baseProduct) +
            '@' + generateKeyForTrait(trait);
  }

  private static long generateKeyForTrait(Trait trait) {
    return ((trait == null) ? -1L : trait.getId());
  }

  private static long generateKeyForProduct(Product baseProduct) {
    return ((baseProduct == null) ? -1L : baseProduct.getId());
  }

  public Product getBaseProduct() {
    return baseProduct;
  }

  public Trait getTrait() {
    return trait;
  }

  String getKey() {
    return key;
  }

  @Override
  public int hashCode() {
    return key.hashCode();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof ProductTraitPair)) return false;

    return key.equals(((ProductTraitPair) o).key);
  }
}
