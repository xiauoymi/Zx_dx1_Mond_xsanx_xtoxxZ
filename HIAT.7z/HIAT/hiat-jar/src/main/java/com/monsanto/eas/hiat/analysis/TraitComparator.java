package com.monsanto.eas.hiat.analysis;

import java.util.Comparator;

public class TraitComparator implements Comparator<InbredStatusDetail>{
    public int compare(InbredStatusDetail o1, InbredStatusDetail o2) {
      return o1.getTrait().getCode().compareTo(o2.getTrait().getCode());
    }
}
