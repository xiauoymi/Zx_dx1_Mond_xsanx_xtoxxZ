package com.monsanto.eas.hiat.analysis.hibernate;

import com.monsanto.eas.hiat.analysis.HybridAnalysisDetail;
import com.monsanto.eas.hiat.analysis.HybridAnalysisParentDetail;
import com.monsanto.eas.hiat.availability.Season;
import com.monsanto.eas.hiat.availability.SeasonCalculator;
import com.monsanto.eas.hiat.availability.hibernate.AvailabilityDateType;
import com.monsanto.eas.hiat.model.Trait;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@Entity
@Table(schema = "HIAT", name = "HYBRID_ANALYSIS_DETAIL")
@TypeDef(name = "AvailabilityDate", typeClass = AvailabilityDateType.class)
public class HybridAnalysisDetailImpl implements HybridAnalysisDetail {
  private Long id;
  private HybridAnalysisParentDetail maleParentDetail;
  private HybridAnalysisParentDetail femaleParentDetail;
  private boolean isSelected;
  private Season pcm150Season;
  private Season pcm300Season;
  private Season commercialSeason;
  private final SeasonCalculator seasonCalc = new SeasonCalculator();

  public HybridAnalysisDetailImpl() {
    this(null, null,
        Season.NONE,
        Season.NONE,
        Season.NONE
    );
  }

  public HybridAnalysisDetailImpl(HybridAnalysisParentDetail maleParentDetail,
                                  HybridAnalysisParentDetail femaleParentDetail,
                                  Season pcm150Season,
                                  Season pcm300Season, Season commercialSeason) {
    this.id = 0L;
    this.maleParentDetail = maleParentDetail;
    this.femaleParentDetail = femaleParentDetail;
    this.pcm150Season = pcm150Season;
    this.pcm300Season = pcm300Season;
    this.commercialSeason = commercialSeason;
    this.isSelected = false;
  }

  @Transient
  public HybridAnalysisParentDetail getMaleParent() {
    return maleParentDetail;
  }

  @Transient
  public HybridAnalysisParentDetail getFemaleParent() {
    return femaleParentDetail;
  }

  @OneToOne(targetEntity = HybridAnalysisParentDetailImpl.class, cascade = CascadeType.ALL)
  public HybridAnalysisParentDetail getMaleParentDetail() {
    return maleParentDetail;
  }

  public void setMaleParentDetail(HybridAnalysisParentDetail maleParentDetail) {
    this.maleParentDetail = maleParentDetail;
  }

  @OneToOne(targetEntity = HybridAnalysisParentDetailImpl.class, cascade = CascadeType.ALL)
  public HybridAnalysisParentDetail getFemaleParentDetail() {
    return femaleParentDetail;
  }

  public void setFemaleParentDetail(HybridAnalysisParentDetail femaleParentDetail) {
    this.femaleParentDetail = femaleParentDetail;
  }

  @Transient
  public Season getPcm150Season() {
    return pcm150Season;
  }

  @Transient
  public Season getPcm300Season() {
    return pcm300Season;
  }

  @Transient
  public Season getCommercialSeason() {
    return commercialSeason;
  }

  @Column(name = "is_selected")
  @Type(type = "yes_no")
  protected boolean getSelected() {
    return isSelected;
  }

  public void setSelected(boolean selected) {
    isSelected = selected;
  }

  @Transient
  public boolean getIsSelected() {
    return isSelected;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof HybridAnalysisDetail)) return false;

    Trait femailDetailTrait = ((HybridAnalysisDetail) o).getFemaleParent().getTrait();
    Trait maleDetailTrait = ((HybridAnalysisDetail) o).getMaleParent().getTrait();

    return femailDetailTrait.equals(this.femaleParentDetail.getTrait()) &&
        maleDetailTrait.equals(this.maleParentDetail.getTrait());
  }

  @Override
  public int hashCode() {
    int result = this.femaleParentDetail.getTrait().hashCode();
    result = 31 * result + (this.maleParentDetail.getTrait().hashCode());
    return result;
  }

  public int compareTo(HybridAnalysisDetail detail) {
    if (this.getCommercialSeason() != null) {
      return this.getCommercialSeason().compareTo(detail.getCommercialSeason());
    } else {
      return 0;
    }
  }

  @Id
  @SequenceGenerator(name = "hiatSeq", sequenceName = "HIAT.HIBERNATE_SEQUENCE")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hiatSeq")
  @Column(name = "ID")
  protected Long getId() {
    return id;
  }

  protected void setId(Long id) {
    this.id = id;
  }

  protected void setMaleParent(HybridAnalysisParentDetail maleParentDetail) {
    this.maleParentDetail = maleParentDetail;
  }

  protected void setFemaleParent(HybridAnalysisParentDetail femaleParentDetail) {
    this.femaleParentDetail = femaleParentDetail;
  }

  @Column(name = "PCM150DATE")
  protected Date getPcm150Date_date() {
    return seasonCalc.getDateInSeason(pcm150Season);
  }

  protected void setPcm150Date_date(Date date) {
    pcm150Season = seasonCalc.calculateSeasonForPrimaryCommercial(date);
  }

  @Column(name = "PCM300DATE")
  protected Date getPcm300Date_date() {
    return seasonCalc.getDateInSeason(pcm300Season);
  }

  protected void setPcm300Date_date(Date date) {
    pcm300Season = seasonCalc.calculateSeasonForPrimaryCommercial(date);
  }

  @Column(name = "COMMERCIALDATE")
  protected Date getCommericialDate_date() {
    return seasonCalc.getDateInSeason(commercialSeason);
  }

  protected void setCommericialDate_date(Date date) {
    commercialSeason = seasonCalc.calculateSeasonForPrimaryCommercial(date);
  }
}
