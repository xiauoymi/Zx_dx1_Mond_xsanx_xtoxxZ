package com.monsanto.eas.hiat.analysis.hibernate;

import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.analysis.HybridAnalysisDetail;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.hibernate.TraitImpl;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.hibernate.annotations.AccessType;

import javax.persistence.*;
import java.util.Collection;
import java.util.HashSet;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@SuppressWarnings({"CanBeFinal"})
@Entity
@AccessType("field")
@Table(schema = "HIAT", name = "HYBRID_ANALYSIS")
public class HybridAnalysisImpl implements HybridAnalysis {
  @Id
  @SequenceGenerator(name = "hiatSeq", sequenceName = "HIAT.HIBERNATE_SEQUENCE")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hiatSeq")
  @Column(name = "ID")
  private Long id;

  @ManyToOne(targetEntity = ProductImpl.class)
  private Product product;

  @ManyToOne(targetEntity = TraitImpl.class)
  private Trait trait;

  @OneToMany(targetEntity = HybridAnalysisDetailImpl.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "ANALYSIS_ID")
  private Collection<HybridAnalysisDetail> detail;

  public HybridAnalysisImpl() {
    this(null, null, new HashSet<HybridAnalysisDetail>());
  }

  public HybridAnalysisImpl(Product product, Trait trait, Collection<HybridAnalysisDetail> detail) {
    this.product = product;
    this.trait = trait;
    this.detail = detail;
  }

  public Long getId() {
    return id;
  }

  public Product getProduct() {
    return product;
  }

  public Trait getTrait() {
    return trait;
  }

  public Collection<HybridAnalysisDetail> getDetail() {
    return detail;
  }

  @Override
  public boolean equals(Object obj) {
    if (!(obj instanceof HybridAnalysisImpl)) {
      return false;
    }

    HybridAnalysisImpl rhs = (HybridAnalysisImpl) obj;

    return new EqualsBuilder()
            .append(product, rhs.product)
            .append(trait, rhs.trait)
            .isEquals();
  }

  @Override
  public int hashCode() {
    int result = this.product.hashCode();
    result = 31 * result + (this.trait.hashCode());
    return result;
  }

  @Override
  public String toString() {
    return "HybridAnalysisImpl[" + id + ", " + product + ", " + trait + ": " + detail.size() + "]";
  }

  public int compareTo(HybridAnalysis hybridAnalysis) {
    return getTrait().getCode().compareTo(hybridAnalysis.getTrait().getCode());
  }
}
