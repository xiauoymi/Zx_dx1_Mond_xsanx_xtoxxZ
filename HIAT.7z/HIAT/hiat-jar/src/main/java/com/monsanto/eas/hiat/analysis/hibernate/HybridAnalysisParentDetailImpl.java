package com.monsanto.eas.hiat.analysis.hibernate;

import com.monsanto.eas.hiat.analysis.HybridAnalysisParentDetail;
import com.monsanto.eas.hiat.availability.AvailabilityDate;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.hibernate.TraitImpl;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

import javax.persistence.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@SuppressWarnings({"CanBeFinal"})
@Entity
@AccessType("field")
@Table(schema = "HIAT", name = "HYBRID_ANALYSIS_PARENT")
public class HybridAnalysisParentDetailImpl implements HybridAnalysisParentDetail {
  @Id
  @SequenceGenerator(name = "hiatSeq", sequenceName = "HIAT.HIBERNATE_SEQUENCE")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hiatSeq")
  @Column(name = "ID")
  private Long id;

  @ManyToOne(targetEntity = ProductImpl.class)
  private Product product;

  @ManyToOne(targetEntity = TraitImpl.class)
  private Trait trait;

  @Type(type = "com.monsanto.eas.hiat.availability.hibernate.AvailabilityDateType")
  private AvailabilityDate gen0Date;

  @Type(type = "com.monsanto.eas.hiat.availability.hibernate.AvailabilityDateType")
  private AvailabilityDate gen1Date;

  @Type(type = "com.monsanto.eas.hiat.availability.hibernate.AvailabilityDateType")
  private AvailabilityDate gen2Date;

  public HybridAnalysisParentDetailImpl() {
    this(null, null, null, null, null);
  }

  public HybridAnalysisParentDetailImpl(Product product, Trait trait, AvailabilityDate gen0Date, AvailabilityDate gen1Date, AvailabilityDate gen2Date) {
    this.product = product;
    this.trait = trait;
    this.gen0Date = gen0Date;
    this.gen1Date = gen1Date;
    this.gen2Date = gen2Date;
  }

  public Product getProduct() {
    return product;
  }

  public Trait getTrait() {
    return trait;
  }

  public AvailabilityDate getGeneration0Date() {
    return gen0Date;
  }

  public AvailabilityDate getGeneration1Date() {
    return gen1Date;
  }

  public AvailabilityDate getGeneration2Date() {
    return gen2Date;
  }

  public int compareTo(HybridAnalysisParentDetail parentDetail) {
    return this.getGeneration2Date().compareTo(parentDetail.getGeneration2Date());
  }
}
