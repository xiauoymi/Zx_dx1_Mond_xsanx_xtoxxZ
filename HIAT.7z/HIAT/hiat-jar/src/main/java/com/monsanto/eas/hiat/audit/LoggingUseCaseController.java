package com.monsanto.eas.hiat.audit;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.eas.hiat.audit.hibernate.RequestImpl;
import com.monsanto.wst.dao.GenericDAO;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class LoggingUseCaseController implements UseCaseController {
  private final UseCaseController baseController;
  private final GenericDAO<Request, Long> requestDAO;

  public LoggingUseCaseController(UseCaseController baseController, GenericDAO<Request, Long> requestDAO) {
    this.baseController = baseController;
    this.requestDAO = requestDAO;
  }

  public void run(UCCHelper uccHelper) throws IOException {
    logRequest(uccHelper);
    baseController.run(uccHelper);
  }

  private void logRequest(UCCHelper uccHelper) throws IOException {
    String user = trimTo(uccHelper.getAuthenticatedUserID(), 100);
    String controller = trimTo(baseController.getClass().getName(), 2000);
    Map<String,String> paramMap = new HashMap<String,String>();
    Enumeration paramNames = uccHelper.getParameterNames();
    while (paramNames.hasMoreElements()) {
      String paramName = trimTo(paramNames.nextElement().toString(), 255);
      String paramValue = trimTo(uccHelper.getRequestParameterValue(paramName), 2000);
      paramMap.put(paramName, paramValue);
    }
    Request req = new RequestImpl(user, controller, paramMap);

    requestDAO.save(req);
  }

  private String trimTo(String st, int maxLength) {
    if (st == null) {
      return null;
    } else if (st.length() > maxLength) {
      return st.substring(0, maxLength);
    } else {
      return st;
    }
  }
}
