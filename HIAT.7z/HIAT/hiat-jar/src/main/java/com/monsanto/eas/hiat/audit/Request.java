package com.monsanto.eas.hiat.audit;

import java.util.Date;
import java.util.Map;

public interface Request {
  String getUsername();

  String getController();

  Date getAccessTime();

  Map<String, String> getParameters();
}
