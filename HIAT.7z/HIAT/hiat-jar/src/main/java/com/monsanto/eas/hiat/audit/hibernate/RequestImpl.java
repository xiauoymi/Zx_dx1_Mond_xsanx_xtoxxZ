package com.monsanto.eas.hiat.audit.hibernate;

import com.monsanto.eas.hiat.audit.Request;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.CollectionOfElements;

import javax.persistence.*;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@SuppressWarnings({"CanBeFinal"})
@Entity
@Table(schema = "HIAT", name = "REQUEST")
@AccessType("field")
@NoDeleteAllowed
public class RequestImpl implements Request {
  @Id
  @SequenceGenerator(name = "hiatSeq", sequenceName = "HIAT.HIBERNATE_SEQUENCE")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hiatSeq")
  private Long id;

  private String username;

  private String controller;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(columnDefinition = "Timestamp default sysdate", nullable = false)
  @org.hibernate.annotations.Generated(org.hibernate.annotations.GenerationTime.ALWAYS)
  private Date accessTime;


  @CollectionOfElements(fetch = FetchType.EAGER)
  @JoinTable(schema="HIAT", name = "REQUEST_DETAIL", joinColumns = @JoinColumn(name = "REQUEST_ID"))
  @Column(name = "PARAMETER_VALUE", nullable = false
  )
  @org.hibernate.annotations.MapKey(
          columns = {
                  @Column(name = "PARAMETER_NAME")
          }
  )
  private Map<String, String> parameters;

  public RequestImpl(String username, String controller, Map<String, String> parameters) {
    this.username = username;
    this.controller = controller;
    this.parameters = parameters;
  }

  public RequestImpl() {
    this(null, null, new HashMap<String, String>());
  }

  public String getUsername() {
    return username;
  }

  public String getController() {
    return controller;
  }

  public Date getAccessTime() {
    return accessTime;
  }

  public Map<String, String> getParameters() {
    return new HashMap<String,String>(parameters);
  }
}

