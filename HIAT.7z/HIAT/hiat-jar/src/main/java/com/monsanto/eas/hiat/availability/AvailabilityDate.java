package com.monsanto.eas.hiat.availability;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface AvailabilityDate extends Comparable<AvailabilityDate> {
  public Date getExactDate();

  public boolean isDerived();

  AvailabilityDate addGeneration();

  public boolean after(AvailabilityDate otherDate);

  AvailabilityDate latest(AvailabilityDate date2);

  AvailabilityDate earliest(AvailabilityDate date2);

  String getTraceBack();
}

