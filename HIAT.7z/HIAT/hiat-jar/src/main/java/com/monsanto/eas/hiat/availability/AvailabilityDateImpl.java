package com.monsanto.eas.hiat.availability;

import org.apache.commons.lang.time.DateUtils;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.monsanto.eas.hiat.config.HIATConfigurationFactory;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class AvailabilityDateImpl implements AvailabilityDate, Serializable {
  public static final String DERIVIVED_DATE_SUFFIX = "*";
  public static final String AVAILABLE_STRING = "Avail";

  public static final String TRACEBACK_DATE_FORMAT_STRING = "MM/dd/yyyy";

  private static final DateFormat dateFmt = new SimpleDateFormat("MMM-yy");
  private static final DateFormat tracebackFmt = new SimpleDateFormat(TRACEBACK_DATE_FORMAT_STRING);

  private final String dateSource;
  private final Date rawDate;
  private final boolean isDerived;
  private static final String NO_DATE_AVAILABLE_STRING = "";

  public AvailabilityDateImpl(String dateSource, Date rawDate) {
    this(dateSource, rawDate, false);
  }

  public AvailabilityDateImpl(String dateSource, Date rawDate, boolean isDerived) {
    this.dateSource = dateSource;
    this.rawDate = (rawDate == null) ? null : org.apache.commons.lang.time.DateUtils.truncate((Date) rawDate.clone(), Calendar.DATE);
    this.isDerived = isDerived;
  }

  public Date getExactDate() {
    if (rawDate == null) {
      return null;
    } else {
      return (Date) rawDate.clone();
    }
  }

  public static AvailabilityDate getUnknown(String dateSource) {
    return new AvailabilityDateImpl(dateSource, null, false);
  }

  public static AvailabilityDate getNow(String dateSource) {
    return new AvailabilityDateImpl(dateSource, new Date(), false);
  }

  public boolean isDerived() {
    return isDerived;
  }

  @Override
  public String toString() {
    if (rawDate == null) {
      return NO_DATE_AVAILABLE_STRING;
    } else if (isTodayOrPast(rawDate)) {
      return AVAILABLE_STRING;
    } else {
      return dateFmt.format(rawDate) + getDeriviedSuffixIfNeeded();
    }
  }

  public int compareTo(AvailabilityDate otherAvailDate) {
    if (otherAvailDate == null) {
      return -1;
    }

    Date thisDate = getExactDate();
    Date otherDate = otherAvailDate.getExactDate();
    if (thisDate == null || otherDate == null) {
      return compareForNulls(thisDate, otherDate);
    } else {
      return thisDate.compareTo(otherDate);
    }
  }

  private int compareForNulls(Date thisDate, Date otherDate) {
    if (thisDate == otherDate) {
      return 0; // both null
    } else if (thisDate == null) {
      return 1; // thisDate is null, other Date is NOT
    } else {
      return -1; // thisDate is NOT null, other date is
    }
  }

  private String getDeriviedSuffixIfNeeded() {
    String suffix;
    if (isDerived()) {
      suffix = DERIVIVED_DATE_SUFFIX;
    } else {
      suffix = "";
    }
    return suffix;
  }

  private boolean isTodayOrPast(Date rawDate) {
    Date today = new Date();
    return today.after(rawDate);
  }

  @Override
  public boolean equals(Object o) {
    if (!(o instanceof AvailabilityDate)) {
      return false;
    }

    AvailabilityDate that = (AvailabilityDate) o;

    if (rawDate == null) {
      return that.getExactDate() == null;
    } else {
      return rawDate.equals(that.getExactDate());
    }
  }

  @Override
  public int hashCode() {
    return rawDate != null ? rawDate.hashCode() : 0;
  }

  public AvailabilityDate addGeneration() {
    int generationDays = HIATConfigurationFactory.getConfiguration().getDaysBetweenGenerations();
    Date adjustedRawDate = getAdjustedRawDate();
    Date nextGenerationDate = (adjustedRawDate == null) ? null : org.apache.commons.lang.time.DateUtils.addDays(adjustedRawDate, generationDays);
    String generationDateSource;
    if (adjustedRawDate == null || DateUtils.isSameDay(adjustedRawDate, rawDate)) {
      generationDateSource = getTraceBack() + "+" + generationDays + "d";
    } else {
      generationDateSource = getTraceBack() + "-->TODAY+" + generationDays + "d";
    }

    return new AvailabilityDateImpl(generationDateSource, nextGenerationDate, true);
  }

  private Date getAdjustedRawDate() {
    Date today = new Date();
    if (rawDate == null) {
      return null;
    } else if (rawDate.before(today)) {
      return today;
    } else {
      return rawDate;
    }
  }

  public boolean after(AvailabilityDate otherDate) {
    if (rawDate == null) {
      return true;
    } else if (otherDate.getExactDate() == null) {
      return false;
    } else {
      return rawDate.after(otherDate.getExactDate());
    }
  }

  public AvailabilityDate latest(AvailabilityDate date2) {
    if (after(date2)) {
      return this;
    } else {
      return date2;
    }
  }

  public AvailabilityDate earliest(AvailabilityDate date2) {
    if (after(date2)) {
      return date2;
    } else {
      return this;
    }
  }

  public String getTraceBack() {
    if (isDerived) {
      return dateSource;
    } else {
      if (rawDate == null) {
        return dateSource + ":UNKNOWN";
      } else {
        return dateSource + ":" + tracebackFmt.format(rawDate);
      }
    }
  }
}

