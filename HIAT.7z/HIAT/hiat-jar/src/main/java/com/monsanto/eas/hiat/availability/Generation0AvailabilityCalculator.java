package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.service.InventoryService;
import com.monsanto.eas.hiat.service.ProductionService;

public class Generation0AvailabilityCalculator extends StandardGenerationAvailabilityCalculator {
  public Generation0AvailabilityCalculator(GenerationAvailabilityCalculator prevGeneration, InventoryService invService, ProductionService prodService) {
    super(InventoryType.PREFOUNDATION, prevGeneration, invService, prodService);
  }

  @Override
  protected int getMinimumInventoryToBeConsideredAvailable() {
    return 0;
  }
}
