package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.model.Product;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface GenerationAvailabilityCalculator {
  AvailabilityDate getAvailability(Product product);
}
