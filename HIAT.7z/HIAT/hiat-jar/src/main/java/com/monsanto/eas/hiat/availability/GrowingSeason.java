package com.monsanto.eas.hiat.availability;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public enum GrowingSeason {
  NONE, SPRING, WINTER
}
