package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.config.HIATConfigurationFactory;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.service.AvailabilityService;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HybridAvailabilityCalculatorImpl implements Calculator<Product, HybridAvailabilityInformation> {
  private final Calculator<Product, InbredAvailabilityInformation> inbredCalc;
  private final AvailabilityService availService;
  private static final String HYBRID_CALCULATION_DATE_SOURCE = "Hybrid Calculations";

  public HybridAvailabilityCalculatorImpl(Calculator<Product, InbredAvailabilityInformation> inbredCalc, AvailabilityService availService) {
    this.inbredCalc = inbredCalc;
    this.availService = availService;
  }

  public HybridAvailabilityInformation calculate(Product product) {
    if (product == null) {
      return new HybridAvailabilityInformation(
              AvailabilityDateImpl.getUnknown(HYBRID_CALCULATION_DATE_SOURCE),
              AvailabilityDateImpl.getUnknown(HYBRID_CALCULATION_DATE_SOURCE),
              AvailabilityDateImpl.getUnknown(HYBRID_CALCULATION_DATE_SOURCE)
      );
    } else {
      InbredAvailabilityInformation inbredAvailability = inbredCalc.calculate(product);
      HybridAvailabilityInformation gen1Avail = calculateG1AvailabilityInfo(product);
      HybridAvailabilityInformation gen2Avail = calculateG2AvailabilityInfo(product);
      HybridAvailabilityInformation derivedAvailability = calculateDerivedAvailabilityInfo(product, inbredAvailability);

      return gen1Avail.earliest(gen2Avail).earliest(derivedAvailability);
    }
  }

  private HybridAvailabilityInformation calculateDerivedAvailabilityInfo(Product product, InbredAvailabilityInformation inbredAvailability) {
    AvailabilityDate g0Date = inbredAvailability.getG0Date();
    AvailabilityDate g0DateWithPrimary = calculateG0DateWithPrimary(product, g0Date);
    AvailabilityDate calculatedAvailDate = g0DateWithPrimary.addGeneration();
    return new HybridAvailabilityInformation(
            calculatedAvailDate,
            calculatedAvailDate,
            calculatedAvailDate.addGeneration());
  }

  private AvailabilityDate calculateG0DateWithPrimary(Product product, AvailabilityDate g0Date) {
    String primaryDateSource = "Primary Date";
    Date primaryDate = product.getPrimaryTestingDate();
    if (product.isPrimary() || isConventional(product)) {
      return g0Date;
    } else if (primaryDate == null) {
      return AvailabilityDateImpl.getUnknown(primaryDateSource);
    } else {
      return g0Date.latest(new AvailabilityDateImpl(primaryDateSource, primaryDate));
    }
  }

  private boolean isConventional(Product product) {
    return (product.getTrait() == null || "CONV".equals(product.getTrait().getCode())); //todo refactor
  }

  private HybridAvailabilityInformation calculateG1AvailabilityInfo(Product product) {
    HIATConfiguration config = HIATConfigurationFactory.getConfiguration();

    AvailabilityDate pcm150Date = new AvailabilityDateImpl(HYBRID_CALCULATION_DATE_SOURCE, availService.getInventoryAvailabilityDate(product, InventoryType.GENERATION_1, config.getG1MinimumForPCM150()), false);
    AvailabilityDate pcm300Date = new AvailabilityDateImpl(HYBRID_CALCULATION_DATE_SOURCE, availService.getInventoryAvailabilityDate(product, InventoryType.GENERATION_1, config.getG1MinimumForPCM300()), false);
    AvailabilityDate commDate = pcm150Date.addGeneration();

    return new HybridAvailabilityInformation(pcm150Date, pcm300Date, commDate);
  }

  private HybridAvailabilityInformation calculateG2AvailabilityInfo(Product product) {
    HIATConfiguration config = HIATConfigurationFactory.getConfiguration();

    AvailabilityDate pcm150Date = new AvailabilityDateImpl(HYBRID_CALCULATION_DATE_SOURCE, availService.getInventoryAvailabilityDate(product, InventoryType.GENERATION_2, config.getG2MinimumForPCM150()), false);
    AvailabilityDate pcm300Date = new AvailabilityDateImpl(HYBRID_CALCULATION_DATE_SOURCE, availService.getInventoryAvailabilityDate(product, InventoryType.GENERATION_2, config.getG2MinimumForPCM300()), false);
    AvailabilityDate commDate = new AvailabilityDateImpl(HYBRID_CALCULATION_DATE_SOURCE, availService.getInventoryAvailabilityDate(product, InventoryType.GENERATION_2, config.getG2MinimumForCommercial()), false);

    return new HybridAvailabilityInformation(pcm150Date, pcm300Date, commDate);
  }
}
