package com.monsanto.eas.hiat.availability;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HybridAvailabilityInformation {
  private final AvailabilityDate pcm150Date;
  private final AvailabilityDate pcm300Date;
  private final AvailabilityDate commercialDate;

  public HybridAvailabilityInformation(AvailabilityDate pcm150Date, AvailabilityDate pcm300Date, AvailabilityDate commercialDate) {
    this.pcm150Date = pcm150Date;
    this.pcm300Date = pcm300Date;
    this.commercialDate = commercialDate;
  }

  public AvailabilityDate getPcm150Date() {
    return pcm150Date;
  }

  public AvailabilityDate getPcm300Date() {
    return pcm300Date;
  }

  public AvailabilityDate getCommercialDate() {
    return commercialDate;
  }

  public HybridAvailabilityInformation earliest(HybridAvailabilityInformation date2) {
    return new HybridAvailabilityInformation(
            getPcm150Date().earliest(date2.getPcm150Date()),
            getPcm300Date().earliest(date2.getPcm300Date()),
            getCommercialDate().earliest(date2.getCommercialDate())
    );
  }

  public HybridAvailabilityInformation latest(HybridAvailabilityInformation date2) {
    return new HybridAvailabilityInformation(
            getPcm150Date().latest(date2.getPcm150Date()),
            getPcm300Date().latest(date2.getPcm300Date()),
            getCommercialDate().latest(date2.getCommercialDate())
    );
  }

}
