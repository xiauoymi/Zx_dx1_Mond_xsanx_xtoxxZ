package com.monsanto.eas.hiat.availability;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HybridAvailabilitySeasonInformation {
  private static final SeasonCalculator calc = new SeasonCalculator();

  private final HybridAvailabilityInformation baseAvailInfo;
  private final Date primaryTestingDate;

  public HybridAvailabilitySeasonInformation(HybridAvailabilityInformation baseAvailInfo, Date primaryTestingDate) {
    if (baseAvailInfo == null) {
      throw new NullPointerException("Avail info cannot be null");
    }
    this.baseAvailInfo = baseAvailInfo;
    this.primaryTestingDate = primaryTestingDate;
  }

  public Season getPcm150Season() {
    return calc.calculateSeasonForPCM(getExactDate(baseAvailInfo.getPcm150Date()));
  }

  public Season getPcm300Season() {
    return calc.calculateSeasonForPCM(getExactDate(baseAvailInfo.getPcm300Date()));
  }

  public Season getCommercialSeason() {
    return calc.calculateSeason(getExactDate(baseAvailInfo.getCommercialDate()), primaryTestingDate);
  }

  public Date getExactDate(AvailabilityDate availDate) {
    if (availDate == null) {
      return null;
    } else {
      return availDate.getExactDate();
    }
  }
}
