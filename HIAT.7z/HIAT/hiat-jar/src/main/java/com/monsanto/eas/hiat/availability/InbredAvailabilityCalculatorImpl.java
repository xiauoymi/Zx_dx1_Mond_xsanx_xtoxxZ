package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredAvailabilityCalculatorImpl implements Calculator<Product, InbredAvailabilityInformation> {
  private final GenerationAvailabilityCalculator gen0Calc;
  private final GenerationAvailabilityCalculator gen1Calc;
  private final GenerationAvailabilityCalculator gen2Calc;

  public InbredAvailabilityCalculatorImpl(GenerationAvailabilityCalculator gen0Calc, GenerationAvailabilityCalculator gen1Calc, GenerationAvailabilityCalculator gen2Calc) {
    this.gen0Calc = gen0Calc;
    this.gen1Calc = gen1Calc;
    this.gen2Calc = gen2Calc;
  }

  public InbredAvailabilityInformation calculate(Product product) {
    if (product == null) {
      String missingProductDateSource = "No Product";
      return new InbredAvailabilityInformation(
              AvailabilityDateImpl.getUnknown(missingProductDateSource),
              AvailabilityDateImpl.getUnknown(missingProductDateSource),
              AvailabilityDateImpl.getUnknown(missingProductDateSource)
      );
    } else {
      return new InbredAvailabilityInformation(
              getAvailabilityDateFromCalculator(gen0Calc, product),
              getAvailabilityDateFromCalculator(gen1Calc, product),
              getAvailabilityDateFromCalculator(gen2Calc, product)
      );
    }
  }

  private AvailabilityDate getAvailabilityDateFromCalculator(GenerationAvailabilityCalculator calc, Product product) {
    try {
      return calc.getAvailability(product);
    } catch (RuntimeException e) {
//      System.err.println("WARNING: Unable to calculate availability dates for product: " + product);
//      e.printStackTrace();
      return AvailabilityDateImpl.getUnknown("Error: " + e.getMessage());
    }
  }

}
