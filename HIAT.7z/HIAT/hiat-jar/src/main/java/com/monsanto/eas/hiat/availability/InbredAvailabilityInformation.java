package com.monsanto.eas.hiat.availability;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredAvailabilityInformation {
  private final AvailabilityDate g0Date;
  private final AvailabilityDate g1Date;
  private final AvailabilityDate g2Date;

  public InbredAvailabilityInformation(AvailabilityDate g0Date, AvailabilityDate g1Date, AvailabilityDate g2Date) {
    this.g0Date = g0Date;
    this.g1Date = g1Date;
    this.g2Date = g2Date;
  }

  public AvailabilityDate getG0Date() {
    return g0Date;
  }

  public AvailabilityDate getG1Date() {
    return g1Date;
  }

  public AvailabilityDate getG2Date() {
    return g2Date;
  }
}

