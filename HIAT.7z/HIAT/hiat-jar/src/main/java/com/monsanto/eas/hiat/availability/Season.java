package com.monsanto.eas.hiat.availability;

import java.text.DecimalFormat;

public class Season implements Comparable {
  public static final int INVALID_YEAR = 9999;

  private static final String SPRING_STRING = "Spring";
  private static final String WINTER_STRING = "Winter";
  public static final String NOT_AVAILABLE_MESSAGE = "Not Available";

  private final int year;
  private final GrowingSeason growingSeason;

  public static Season NONE = new Season(INVALID_YEAR, GrowingSeason.NONE);

  public Season(int year, GrowingSeason growingSeason) {
    this.year = year;
    this.growingSeason = growingSeason;
  }

  public int getYear() {
    return year;
  }

  public GrowingSeason getGrowingSeason() {
    return growingSeason;
  }

  @Override
  public String toString() {
    switch (growingSeason) {
      case NONE:
        return NOT_AVAILABLE_MESSAGE;
      case SPRING:
        return SPRING_STRING + " " + formatYear(year);
      case WINTER:
        return WINTER_STRING + " " + formatYear(year) + "/" + formatYear(year + 1);
      default:
        return growingSeason.toString() + " " + formatYear(year); // branch would only be followed if they add a new season we don't know anything about to the enum
    }
  }

  public int compareTo(Object o) {
    Season otherSeason = (Season) o;
    int yearCompare = year - otherSeason.year;
    if (yearCompare != 0) {
      return yearCompare;
    } else {
      return growingSeason.compareTo(otherSeason.growingSeason);
    }
  }

  public Season latest(Season otherSeason) {
    if (compareTo(otherSeason) > 0) {
      return this;
    } else {
      return otherSeason;
    }
  }

  @Override
  public boolean equals(Object obj) {
    if (obj instanceof Season) {
      return compareTo(obj) == 0;
    } else {
      return false;
    }
  }

  @Override
  public int hashCode() {
    return year << 2 + growingSeason.ordinal();
  }

  private static String formatYear(int year) {
    return new DecimalFormat("00").format(year % 100);
  }
}
