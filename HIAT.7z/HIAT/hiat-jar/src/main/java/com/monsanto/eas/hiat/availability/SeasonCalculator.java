package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.config.HIATConfigurationFactory;
import org.apache.commons.lang.time.DateUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class SeasonCalculator {
  public Season calculateSeason(Date seedAvailDate, Date primaryTestingDate) {
    // use the worst of the season dictated by the primary testing date, and the season dictated by the availability date
    int expectedYearSeedAvail = getYearForDate(seedAvailDate);
    int expectedYearTesting = getYearForDate(primaryTestingDate);
    Season seedAvalDateSeason = calculateSeasonBasedOnCutoffDates(seedAvailDate,
            getSpringCutoffDate(expectedYearSeedAvail),
            getWinterCutoffDate(expectedYearSeedAvail));
    Season primaryTestingSeason = calculateSeasonBasedOnCutoffDates(primaryTestingDate,
            getSpringCutoffDate(expectedYearTesting),
            getTestingCutoffDate(expectedYearTesting));

    return seedAvalDateSeason.latest(primaryTestingSeason);
  }

  public Season calculateSeasonForPrimaryCommercial(Date date) {
    // product is primary and so testing date doesn't matter
    int expectedYear = getYearForDate(date);
    return calculateSeasonBasedOnCutoffDates(date, getSpringCutoffDate(expectedYear), getWinterCutoffDate(expectedYear));
  }

  public Season calculateSeasonForPCM(Date date) {
    int expectedYear = getYearForDate(date);
    return calculateSeasonBasedOnCutoffDates(date, getSpringCutoffDate(expectedYear), getPCMWinterCutoffDate(expectedYear));
  }

  private Season calculateSeasonBasedOnCutoffDates(Date availDate, Date springCutoff, Date winterCutoff) {
    if (availDate == null) {
      return Season.NONE;
    } else {
      return calculateSeasonBasedOnCutoffDateNotNull(availDate, springCutoff, winterCutoff);
    }
  }

  private Season calculateSeasonBasedOnCutoffDateNotNull(Date availDate, Date springCutoff, Date winterCutoff) {
    int expectedYear = getYearForDate(availDate);
    if (availDate.before(springCutoff)) {
      return new Season(expectedYear, GrowingSeason.SPRING);
    } else if (availDate.before(winterCutoff)) {
      return new Season(expectedYear, GrowingSeason.WINTER);
    } else {
      return new Season(expectedYear + 1, GrowingSeason.SPRING);
    }
  }

  private static int getYearForDate(Date rawDate) {
    if (rawDate == null) {
      return Season.INVALID_YEAR;
    }
    
    Calendar cal = new GregorianCalendar();
    cal.setTime(rawDate);
    return cal.get(Calendar.YEAR);
  }

  public static Date getWinterCutoffDate(int year) {
    HIATConfiguration config = HIATConfigurationFactory.getConfiguration();
    return new GregorianCalendar(year, config.getWinterCutoffMonth(), config.getWinterCutoffDay()).getTime();
  }

  public static Date getTestingCutoffDate(int year) {
    HIATConfiguration config = HIATConfigurationFactory.getConfiguration();
    return new GregorianCalendar(year, config.getTestingCutoffMonth(), config.getTestingCutoffDay()).getTime();
  }

  public static Date getPCMWinterCutoffDate(int year) {
    HIATConfiguration config = HIATConfigurationFactory.getConfiguration();
    return new GregorianCalendar(year, config.getPCMWinterCutoffMonth(), config.getPCMWinterCutoffDay()).getTime();
  }

  public static Date getSpringCutoffDate(int year) {
    HIATConfiguration config = HIATConfigurationFactory.getConfiguration();
    return new GregorianCalendar(year, config.getSpringCutoffMonth(), config.getSpringCutoffDay()).getTime();
  }

  public Date getDateInSeason(Season season) {
    if (season.getGrowingSeason() == GrowingSeason.NONE) {
      return null;
    }

    Date dateToUse;
    if (season.getGrowingSeason() == GrowingSeason.WINTER) {
      dateToUse = getWinterCutoffDate(season.getYear());
    } else {
      dateToUse = getSpringCutoffDate(season.getYear());
    }

    return DateUtils.addDays(dateToUse, -1);
  }
}
