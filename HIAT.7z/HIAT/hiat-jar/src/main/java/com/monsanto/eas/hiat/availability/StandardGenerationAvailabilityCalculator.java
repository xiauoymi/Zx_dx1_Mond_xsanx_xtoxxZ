package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;
import com.monsanto.eas.hiat.service.InventoryService;
import com.monsanto.eas.hiat.service.ProductionService;

import java.util.Collection;
import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class StandardGenerationAvailabilityCalculator implements GenerationAvailabilityCalculator {
  private final InventoryType invType;
  private final GenerationAvailabilityCalculator prevGeneration;
  private final InventoryService invService;
  private final ProductionService prodService;

  public StandardGenerationAvailabilityCalculator(InventoryType invType,
                                                  GenerationAvailabilityCalculator prevGeneration,
                                                  InventoryService invService,
                                                  ProductionService prodService) {
    this.invType = invType;
    this.prevGeneration = prevGeneration;
    this.invService = invService;
    this.prodService = prodService;
  }

  public AvailabilityDate getAvailability(Product product) {
    if (invService.getInventory(product, invType) > getMinimumInventoryToBeConsideredAvailable()) {
      return AvailabilityDateImpl.getNow(invType.getCode() + " Inventory");
    } else {
      Collection<ProductionEntry> productionEntries = prodService.findByProduct(product, invType);
      if (productionEntries.isEmpty()) {
        return getAvailabilityDateForPreviousGeneration(product).addGeneration();
      } else {
        return new AvailabilityDateImpl(invType.getCode() + " Orders", getMaxDate(productionEntries), false);
      }
    }
  }

  protected int getMinimumInventoryToBeConsideredAvailable() {
    return 5;
  }

  protected AvailabilityDate getAvailabilityDateForPreviousGeneration(Product product) {
    return prevGeneration.getAvailability(product);
  }

  private Date getMaxDate(Iterable<ProductionEntry> productionEntries) {
    Date maxDate = null;
    for (ProductionEntry prodEntry : productionEntries) {
      Date prodDate = prodEntry.getAvailableDate();
      if ((maxDate == null) || (maxDate.before(prodDate))) {
        maxDate = prodDate;
      }
    }

    return maxDate;
  }
}

