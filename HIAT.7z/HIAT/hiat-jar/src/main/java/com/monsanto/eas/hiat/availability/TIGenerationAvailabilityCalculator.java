package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.model.Product;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class TIGenerationAvailabilityCalculator implements GenerationAvailabilityCalculator {
  private static final String TI_HANDOFF_DATE_SOURCE = "TI Handoff";

  public AvailabilityDate getAvailability(Product product) {
    Date handoffDate = product.getHandoffDate();
    if (handoffDate == null) {
      return AvailabilityDateImpl.getUnknown(TI_HANDOFF_DATE_SOURCE);
    } else {
      return new AvailabilityDateImpl(TI_HANDOFF_DATE_SOURCE, handoffDate, false);
    }
  }
}
