package com.monsanto.eas.hiat.availability.hibernate;

import com.monsanto.eas.hiat.availability.AvailabilityDate;
import com.monsanto.eas.hiat.availability.AvailabilityDateImpl;
import org.hibernate.HibernateException;
import org.hibernate.usertype.UserType;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;

public class AvailabilityDateType implements UserType {
    public int[] sqlTypes() {
        return new int[]{Types.TIMESTAMP};
    }

    @SuppressWarnings({"RawUseOfParameterizedType"})
    public Class returnedClass() {
        return AvailabilityDate.class;
    }

    public boolean equals(Object x, Object y) throws HibernateException {
        return (x == y) || (x != null && x.equals(y));
    }

    public int hashCode(Object x) throws HibernateException {
        return (x == null) ? 0 : x.hashCode();
    }

    public Object nullSafeGet(ResultSet resultSet, String[] names, Object owner) throws HibernateException, SQLException {
        Date baseDate = resultSet.getDate(names[0]);
        return new AvailabilityDateImpl("saved scenario", baseDate); //todo do we want to save the reason also
    }

    @SuppressWarnings({"AssignmentToNull", "ChainOfInstanceofChecks"})
    public void nullSafeSet(PreparedStatement st, Object value, int index) throws HibernateException, SQLException {
      Date baseDate = getDateBasedOnType(value);
      st.setDate(index, getSqlDateForUtilDate(baseDate));
    }

  private Date getDateBasedOnType(Object value) {
    Date baseDate;
    if (value instanceof AvailabilityDate) {
        baseDate = ((AvailabilityDate) value).getExactDate();
    } else if (value instanceof Date) {
        baseDate = (Date) value;
    } else {
        baseDate = null;
    }
    return baseDate;
  }

  private java.sql.Date getSqlDateForUtilDate(Date baseDate) {
    java.sql.Date sqlDate = (baseDate == null) ? null : new java.sql.Date(baseDate.getTime());
    return sqlDate;
  }

  public Object deepCopy(Object value) throws HibernateException {
        return (value == null) ? null : new AvailabilityDateImpl("saved scenario", ((AvailabilityDate) value).getExactDate()); //todo do we want to save the reason for the date?
    }

    public boolean isMutable() {
        return false;
    }

    public Serializable disassemble(Object value) throws HibernateException {
        return (Serializable) value;
    }

    public Object assemble(Serializable cached, Object owner) throws HibernateException {
        return cached;
    }

    public Object replace(Object original, Object target, Object owner) throws HibernateException {
        return original;
    }
}
