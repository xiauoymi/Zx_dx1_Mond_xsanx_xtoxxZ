package com.monsanto.eas.hiat.calculator;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class CachedCalculator<IN, OUT> implements Calculator<IN, OUT> {
  private final Collection<IN> returnsNull = new HashSet<IN>();
  private final Map<IN, OUT> cachedValues = new HashMap<IN, OUT>();
  private final Calculator<IN, OUT> baseCalculator;

  public CachedCalculator(Calculator<IN, OUT> baseCalculator) {
    this.baseCalculator = baseCalculator;
  }

  public OUT calculate(IN input) {
    if (returnsNull.contains(input)) {
      return null;
    } else {
      OUT value = cachedValues.get(input);
      if (value == null) {
        value = baseCalculator.calculate(input);
        storeValue(input, value);
      }

      return value;
    }
  }

  private void storeValue(IN input, OUT value) {
    if (value == null) {
      returnsNull.add(input);
    } else {
      cachedValues.put(input, value);
    }
  }
}
