package com.monsanto.eas.hiat.calculator;

public interface Calculator<IN, OUT> {
  OUT calculate(IN input);
}
