package com.monsanto.eas.hiat.config;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface HIATConfiguration {
  String HIAT_BEAN_XML = "hiat.xml";

  int getDaysBetweenGenerations();

  int getSpringCutoffMonth();
  int getSpringCutoffDay();

  int getWinterCutoffMonth();
  int getWinterCutoffDay();

  int getPCMWinterCutoffMonth();
  int getPCMWinterCutoffDay();

  int getTestingCutoffMonth();
  int getTestingCutoffDay();

  int getG1MinimumForPCM150();
  int getG1MinimumForPCM300();
  int getG2MinimumForPCM150();
  int getG2MinimumForPCM300();
  int getG2MinimumForCommercial();
}

