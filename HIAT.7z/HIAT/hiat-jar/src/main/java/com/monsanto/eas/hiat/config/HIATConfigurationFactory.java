package com.monsanto.eas.hiat.config;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HIATConfigurationFactory {
  private static HIATConfiguration config = null;

  public static void setConfiguration(HIATConfiguration configParam) {
    synchronized (HIATConfigurationFactory.class) {
      config = configParam;
    }
  }

  public static HIATConfiguration getConfiguration() {
    synchronized (HIATConfigurationFactory.class) {
      if (config == null) {
        throw new RuntimeException("HIAT Configuration has not been set");
      } else {
        return config;
      }
    }
  }
}
