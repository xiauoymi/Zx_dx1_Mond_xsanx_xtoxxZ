package com.monsanto.eas.hiat.config;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@SuppressWarnings({"CanBeFinal", "UnusedDeclaration"})
@Entity
@Table(schema = "HIAT", name = "CONFIG")
@AccessType("field")
@NoDeleteAllowed
public class HIATConfigurationImpl implements HIATConfiguration {
  @Id
  private int id;

  private int daysBetweenGenerations;
  private int springCutoffMonth;
  private int springCutoffDay;
  private int winterPcmCutoffMonth;
  private int winterPcmCutoffDay;
  private int winterCutoffMonth;
  private int winterCutoffDay;
  private int testingCutoffMonth;
  private int testingCutoffDay;
  private int minimumG1QtyForPCM150;
  private int minimumG1QtyForPCM300;
  private int minimumG2QtyForPCM150;
  private int minimumG2QtyForPCM300;
  private int minimumG2QtyForCommercial;

  public int getDaysBetweenGenerations() {
    return daysBetweenGenerations;
  }

  public int getSpringCutoffMonth() {
    return springCutoffMonth - 1; // minus 1 because java date months are 0 offset and people have Jan=1
  }

  public int getSpringCutoffDay() {
    return springCutoffDay;
  }

  public int getWinterCutoffMonth() {
    return winterCutoffMonth - 1; // minus 1 because java date months are 0 offset and people have Jan=1
  }

  public int getWinterCutoffDay() {
    return winterCutoffDay;
  }

  public int getPCMWinterCutoffMonth() {
    return winterPcmCutoffMonth - 1; // minus 1 because java date months are 0 offset and people have Jan=1
  }

  public int getPCMWinterCutoffDay() {
    return winterPcmCutoffDay;
  }

  public int getTestingCutoffMonth() {
    return testingCutoffMonth - 1; // minus 1 because java date months are 0 offset and people have Jan=1
  }

  public int getTestingCutoffDay() {
    return testingCutoffDay;
  }

  public int getG1MinimumForPCM150() {
    return minimumG1QtyForPCM150;
  }

  public int getG1MinimumForPCM300() {
    return minimumG1QtyForPCM300;
  }

  public int getG2MinimumForPCM150() {
    return minimumG2QtyForPCM150;
  }

  public int getG2MinimumForPCM300() {
    return minimumG2QtyForPCM300;
  }

  public int getG2MinimumForCommercial() {
    return minimumG2QtyForCommercial;
  }
}
