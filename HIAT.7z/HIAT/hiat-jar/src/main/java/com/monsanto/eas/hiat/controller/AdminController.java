package com.monsanto.eas.hiat.controller;

import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public abstract class AdminController extends HIATController {
  private static final String NO_ADMIN_PAGE = "/html/noadmin.html";

  protected AdminController(GenericDAO<HIATConfiguration, Long> configDAO) {
    super(configDAO);
  }

  public void run(UCCHelper helper) throws IOException {
    if (isAdmin(helper)) {
      super.run(helper);
    } else {
      helper.forward(NO_ADMIN_PAGE);
    }
  }

}
