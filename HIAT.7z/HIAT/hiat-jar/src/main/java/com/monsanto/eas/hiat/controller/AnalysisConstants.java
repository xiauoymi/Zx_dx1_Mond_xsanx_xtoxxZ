package com.monsanto.eas.hiat.controller;

/**
 * Created by vvvelu Feb 10, 2009 Time: 10:40:13 AM
 */
public class AnalysisConstants {
  public static final String STYLESHEET_HYBRID_ANALYSIS_XSL = "/Stylesheet/downloadHybridAnalysis.xsl";
  public static final String STYLESHEET_INBRED_STATUS_XSL = "/Stylesheet/downloadInbredStatus.xsl";
  public static final String STYLESHEET_INBRED_ANALYSIS_XSL = "/Stylesheet/downloadInbredAnalysis.xsl";

  public static final String EXCEL_CONTENT_TYPE = "application/vnd.ms-excel";

  public static final String METHOD = "method";
  public static final String TRAITS_LIST = "traitsList";
  public static final String PRODUCT_NAME = "productName";
  public static final String SELECTED_TRAITS = "selectedTraits";
  public static final String DISPLAY_ANALYSIS_RESULTS = "displayAnalysisResults";
  public static final String TRUE_STRING = "true";
  public static final String ANALYSIS_LIST = "analysisList";
}
