package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.service.ProductSearchResults;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.TraitService;
import com.monsanto.wst.dao.GenericDAO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public abstract class AnalysisController extends HIATController {
  private final TraitService traitService;
  private final ProductService productService;

  public static final String ERRORS_LIST = "errorsList";
  public static final String ENTER_ATLEAST_ONE_PRODUCT = "Please enter at least one Product to generate analysis";
  public static final String ENTER_ATLEAST_ONE_TRAIT = "Please select at least one Trait to generate analysis";
  public static final String PRODUCT_NAME_TYPES = "productNameTypes";
  public static final String TRAIT = "trait";
  public static final String SELECTED_TRAITS = TRAIT;
  public static final String NO_MATCHING_PRODUCT_FOUND = "No matching product(s) found";
  public static final String MISSING_PRODUCTS = "missingProducts";

  protected AnalysisController(GenericDAO<HIATConfiguration, Long> configDAO, TraitService traitService,
                               ProductService productService) {
    super(configDAO);
    this.traitService = traitService;
    this.productService = productService;
  }

  protected Collection<Trait> getTraitsFromHelper(UCCHelper helper) {
    try {
      String[] traitStrings;
      traitStrings = helper.getRequestParameterValues(AnalysisController.TRAIT);
//      if (traitStrings == null){
//        traitStrings  = helper.getRequestParameterValues(AnalysisController.SELECTED_TRAITS);
//      }
      if (traitStrings == null) {
        return new ArrayList<Trait>(0);
      } else {
        return traitService.lookupSelectedTraits(traitStrings);
      }
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  protected abstract boolean isHybrid();

  protected void notSpecified(UCCHelper helper) throws IOException {
    setReferenceDataAndInputDetailsForAnalysis(helper);
  }

  protected List<String> validateAndSetRequestParameters(Collection<Trait> selectedTraits, ProductSearchResults productResults) throws IOException {
    List<String> errors = new LinkedList<String>();
    boolean areProductNamesEmpty = StringUtils.isNullOrEmpty(productResults.getInputString());
    boolean areTraitsEmpty = selectedTraits.isEmpty();
    if (areProductNamesEmpty) {
      errors.add(ENTER_ATLEAST_ONE_PRODUCT);
    }
    if (areTraitsEmpty) {
      errors.add(ENTER_ATLEAST_ONE_TRAIT);
    }
    if (!areProductNamesEmpty && !areTraitsEmpty && productResults.getResults().isEmpty()) {
      errors.add(NO_MATCHING_PRODUCT_FOUND);
    }

    return errors;
  }

  protected void setReferenceDataAndInputDetailsForAnalysis(UCCHelper helper) {
    try {
      helper.setRequestAttributeValue(AnalysisConstants.TRAITS_LIST, getTraitList());
      helper.setRequestAttributeValue(AnalysisConstants.PRODUCT_NAME, helper.getRequestParameterValue(AnalysisConstants.PRODUCT_NAME));
      Collection<Trait> selectedTraits = getTraitsFromHelper(helper);
      helper.setRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS, selectedTraits);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  protected TraitService getTraitService() {
    return traitService;
  }

  protected ProductService getProductService() {
    return productService;
  }

  protected abstract List<Trait> getTraitList();

  public abstract void generateAnalysis(UCCHelper helper) throws IOException;

  protected ProductSearchResults getProductByNames(UCCHelper helper) {
    try {
      String productNames = helper.getRequestParameterValue(AnalysisConstants.PRODUCT_NAME);
      if (productNames == null) {
        return new ProductSearchResults(productNames);
      } else {
        return productService.lookupProductMatchingInputCriteria(productNames, isHybrid());
      }
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }
}
