package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.config.HIATConfigurationFactory;
import com.monsanto.wst.commonutils.properties.PropertyPlatformLocalizer;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.servletframework.AbstractDispatchController;

import java.io.IOException;
import java.util.Properties;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public abstract class HIATController extends AbstractDispatchController {
  private static final String NO_ACCESS_PAGE = "/html/noaccess.html";
  public static final String USERID_IN_SESSION = "userId";
  private static final String AUTHORIZED_GROUP_PROPERTY_NAME = "authorizedUsersGroup";
  private static final String ADMIN_GROUP_PROPERTY_NAME = "adminUsersGroup";
  public static final String HTML_ERROR_PAGE_JSP = "/html/errorPage.jsp";
  private static final String EXCEPTION = "exception";
  private static final String ADMIN_ATTRIBUTE = "admin";

  protected HIATController(GenericDAO<HIATConfiguration, Long> configDAO) {
    HIATConfiguration hiatConfig = configDAO.findAll().iterator().next();
    HIATConfigurationFactory.setConfiguration(hiatConfig);
  }

  @SuppressWarnings({"CatchGenericClass"})
  public void run(UCCHelper helper) throws IOException {
    if (isUserAuthorized(helper)) {
      helper.setSessionParameter(USERID_IN_SESSION, helper.getAuthenticatedUserID());
      helper.setRequestAttributeValue(ADMIN_ATTRIBUTE, Boolean.toString(isAdmin(helper)));
      helper.setSessionParameter(USERID_IN_SESSION, helper.getAuthenticatedUserID());
      try {
        super.run(helper);
      }
      catch (Exception e) {
        helper.setRequestAttributeValue(EXCEPTION, e);
        helper.forward(HTML_ERROR_PAGE_JSP);
      }
    } else {
      helper.forward(NO_ACCESS_PAGE);
    }
  }

  protected boolean isUserAuthorized(UCCHelper helper) {
//    String requiredGroup = getRequiredGroup();
//    return helper.isUserInRole(requiredGroup);
    return true;
  }

  protected String getRequiredGroup() {
    return getGroupNeededForRole(AUTHORIZED_GROUP_PROPERTY_NAME);
  }

  protected String getAdminGroup() {
    return getGroupNeededForRole(ADMIN_GROUP_PROPERTY_NAME);
  }

  protected boolean isAdmin(UCCHelper helper) {
    String adminGroup = getAdminGroup();
    return helper.isUserInRole(adminGroup);
  }

  private String getGroupNeededForRole(String roleName) {
    String prefix = new PropertyPlatformLocalizer().getPrefix();
    Properties securityProperties = getSecurityProperties();
    String group = getRequiredGroup(prefix, securityProperties, roleName);

    if (group == null) {
      throw new LoginException("Unable to determine authorized user group.  Property not found: " + roleName);
    }

    return group;
  }

  private String getRequiredGroup(String prefix, Properties securityProperties, String roleName) {
    String group = securityProperties.getProperty(roleName);
    if (group == null) {
      group = securityProperties.getProperty(prefix + "." + roleName);
    }
    return group;
  }

  private Properties getSecurityProperties() {
    Properties properties = new Properties();
    try {
      properties.load(HIATController.class.getClassLoader().getResourceAsStream("security.properties"));
    } catch (IOException e) {
      throw new LoginException(e);
    }
    return properties;
  }
}
