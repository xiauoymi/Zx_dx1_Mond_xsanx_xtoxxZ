package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.wst.dao.GenericDAO;

import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HomePageController extends HIATController {
  public static final String HOME_PAGE_LOCATION = "/WEB-INF/jsp/home.jsp";

  protected HomePageController(GenericDAO<HIATConfiguration, Long> configDAO) {
    super(configDAO);
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    helper.forward(HOME_PAGE_LOCATION);
  }
}
