package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.hiat.analysis.*;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisImpl;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.service.ProductSearchResults;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.TraitService;
import com.monsanto.eas.hiat.view.HybridAnalysisXMLGenerator;
import com.monsanto.wst.dao.GenericDAO;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HybridAnalysisController extends AnalysisController {
  private final HybridAnalyzer analyzer;
  private final HybridAnalysisXMLGenerator hybridAnalysisXMLGenerator;
  public static final String WEB_INF_JSP_HYBRIDANALYSIS_PARAM = "/WEB-INF/jsp/hybridanalysis/analysisParameters.jsp";
  public static final String WEB_INF_JSP_HYBRIDANALYSIS_RESULTS = "/WEB-INF/jsp/hybridanalysis/analysisParameters.jsp";
  public static final String POSSIBLE_TRAIT_COMB = "possibleTraitComb";
  public static final String TRAITS_TO_BE_FILTERED = "traitsToBeFiltered";
  public static final String TRAITS_INCLUDED = "traitsIncluded";
  public static final String ALL_POSSIBLE_TRAIT_COMBINATION_VALUES = "allPossibleTraitCombinationValues";
  public static final String SHOW_FILTER_PARENT_TRAITS = "showFilterParentTraits";

  public static final String TRAITS = "TRAITS";
  public static final String TRAIT = "TRAIT";
  public static final String ID = "ID";
  public static final String CODE = "CODE";
  public static final String COMMERCIAL_NAME = "COMM_NAME";

    public HybridAnalysisController(GenericDAO<HIATConfiguration, Long> configDAO,
                                  TraitService traitService,
                                  HybridAnalyzer analyzer,
                                  ProductService productService,
                                  HybridAnalysisXMLGenerator hybridAnalysisXMLGenerator) {
    super(configDAO, traitService, productService);
    this.analyzer = analyzer;
    this.hybridAnalysisXMLGenerator = hybridAnalysisXMLGenerator;
  }

  protected boolean isHybrid() {
    return true;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    super.notSpecified(helper);
    helper.forward(WEB_INF_JSP_HYBRIDANALYSIS_PARAM);
  }

  //todo need to refactor common parts of generateAnalysis and downloadAnalysis
  public void generateAnalysis(UCCHelper helper) throws IOException {
    Collection<Trait> selectedTraits = getTraitsFromHelper(helper);
    ProductSearchResults results = getProductByNames(helper);
    Collection<String> errors = validateAndSetRequestParameters(selectedTraits, results);
    if (errors.isEmpty()) {
      HybridAnalysisResults analysisResults = analyzer.analyze(results.getResults(), selectedTraits);
      Collection<Trait> includedTraits = getIncludedTraits(helper);
      Collection<HybridAnalysis> unfilteredHybridAnalysisList = analysisResults.getAnalysisList();
      Collection<HybridAnalysis> hybridAnalysisList = filterHybridAnalysisBySelectedTraits_Female(unfilteredHybridAnalysisList, includedTraits);
      helper.setRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST, hybridAnalysisList);
      helper.setRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS, AnalysisConstants.TRUE_STRING);
      Collection<String> failures = results.getFailures();
      failures.addAll(analysisResults.getErrors());
      helper.setRequestAttributeValue(MISSING_PRODUCTS, failures);
      helper.setRequestAttributeValue(PRODUCT_NAME_TYPES, ProductNameType.values());
    }
    setTraitFilterCombinations(helper);
    setReferenceDataAndInputDetailsForAnalysis(helper);
    helper.setRequestAttributeValue(ERRORS_LIST, errors);
    helper.forward(WEB_INF_JSP_HYBRIDANALYSIS_RESULTS);
  }

  private List<HybridAnalysis> filterHybridAnalysisBySelectedTraits_Female(Collection<HybridAnalysis> orig,
                                                                          Collection<Trait> includedTraits) {
    List<HybridAnalysis> filtered = new ArrayList<HybridAnalysis>(orig.size());
    for (HybridAnalysis analysis : orig) {
      Product currProduct = analysis.getProduct();
      Trait currTrait = analysis.getTrait();
      Collection<HybridAnalysisDetail> currDetail = filterHybridAnalysisDetailBySelectedTraits_Female(analysis.getDetail(), includedTraits);

      filtered.add(new HybridAnalysisImpl(currProduct, currTrait, currDetail));
    }
    return filtered;
  }

  private Collection<HybridAnalysisDetail> filterHybridAnalysisDetailBySelectedTraits_Female(Collection<HybridAnalysisDetail> orig,
                                                                                             Collection<Trait> includedTraits) {
    Collection<HybridAnalysisDetail> filtered = new ArrayList<HybridAnalysisDetail>(orig.size());
    for (HybridAnalysisDetail detail : orig) {
      HybridAnalysisParentDetail femaleParent = detail.getFemaleParent();
      Trait femaleTrait = femaleParent.getTrait();
      if (includedTraits.contains(femaleTrait)) {
        filtered.add(detail);
      }
    }
    return filtered;
  }

  public void downloadHybridAnalysis(UCCHelper helper) throws IOException {
    ProductSearchResults results = getProductByNames(helper);
    Collection<Trait> selectedTraits = getTraitsFromHelper(helper);
    HybridAnalysisResults analysisResults = analyzer.analyze(results.getResults(), selectedTraits);
    List<HybridAnalysis> unfilteredHybridAnalysisList = analysisResults.getAnalysisList();
    Collection<String> missingProducts = new ArrayList<String>();
    missingProducts.addAll(results.getFailures());
    missingProducts.addAll(analysisResults.getErrors());
    Collection<Trait> includedTraits = getIncludedTraits(helper);
    Collection<HybridAnalysis> hybridAnalysisList = filterHybridAnalysisBySelectedTraits_Female(unfilteredHybridAnalysisList, includedTraits);
    Document document = hybridAnalysisXMLGenerator.getXmlContent(hybridAnalysisList, null, null, false, helper, missingProducts);
    helper.setContentType(AnalysisConstants.EXCEL_CONTENT_TYPE);
    helper.writeToExcel(document, AnalysisConstants.STYLESHEET_HYBRID_ANALYSIS_XSL);
  }

  //todo this method probably belongs in a different controller
  public void getPossibleTraitCombinations(UCCHelper helper) throws IOException {
      String traits = helper.getRequestParameterValue(AnalysisConstants.SELECTED_TRAITS);
      Document doc;
      if(StringUtils.isNullOrEmpty(traits)) {
         doc = DOMUtil.newDocument();
      } else {
        String[] splitTraits = org.apache.commons.lang.StringUtils.split(traits, "_");
        List<Trait> possibleTraitCombinations = getTraitService().calculateTraits(splitTraits);
        doc = getXMLDocumentFromTraitList(possibleTraitCombinations);
      }
      helper.setContentType("text/xml");
      helper.writeXMLDocument(doc);
  }

  private Document getXMLDocumentFromTraitList(List<Trait> possibleTraitCombinations) {
    Document document = DOMUtil.newDocument();
    buildXmlContent(possibleTraitCombinations, document);
    return document;
  }

  //todo this method doesn't belong in this class
  private void buildXmlContent(List<Trait> possibleTraitCombinations, Document document) {
    Element traitsElement = DOMUtil.addChildElement(document, TRAITS);
    for (Trait t : possibleTraitCombinations) {
      Element traitElement = DOMUtil.addChildElement(traitsElement, TRAIT);
      DOMUtil.addChildElement(traitElement, ID, t.getId());
//           DOMUtil.addChildElement(traitElement, CODE, t.getCode());
      DOMUtil.addChildElement(traitElement, COMMERCIAL_NAME, t.getCommercialName());
    }
  }

    private void setTraitFilterCombinations(UCCHelper helper) throws IOException {
        String showFilterParentTraits = helper.getRequestParameterValue(SHOW_FILTER_PARENT_TRAITS);
        helper.setRequestAttributeValue(SHOW_FILTER_PARENT_TRAITS, showFilterParentTraits);
        String[] traitStrings = helper.getRequestParameterValues(AnalysisController.TRAIT);
        if(traitStrings != null) {
            List<Trait> traitsSet = getTraitService().calculateTraits(traitStrings);
            setTraitCombinationsHelper(helper, traitsSet);
        }
    }

    private void setTraitCombinationsHelper(UCCHelper helper, List<Trait> traitsSet) throws IOException {
        // traitsSet Contains all calculated traits. traitsToBeFiltered contains all traits minus deselected traits
        // Find deselected traits
        List<Trait> traitsIncluded = getIncludedTraits(helper);
        StringBuilder sbContainingExcludedTraits = new StringBuilder();
        for(Trait traitExcluded:traitsSet) {
           if(!traitsIncluded.contains(traitExcluded)) {
              sbContainingExcludedTraits.append(traitExcluded.getCode()).append(" ");
           }
        }
        setTraitCombinationsReferenceData(helper, traitsSet, traitsIncluded, sbContainingExcludedTraits);
    }

  private List<Trait> getIncludedTraits(UCCHelper helper) throws IOException {
    String[] traitsToBeIncluded = helper.getRequestParameterValues(POSSIBLE_TRAIT_COMB);
    if (traitsToBeIncluded == null) {
      return new LinkedList<Trait>();
    } else {
      return getTraitService().lookupSelectedTraits(parseTraits(traitsToBeIncluded));
    }
  }

  private String[] parseTraits(String[] traitsToBeIncluded) {
    if (traitsToBeIncluded.length == 1 || traitsToBeIncluded[0].contains("_")) {
      return traitsToBeIncluded[0].split("_");
    } else {
      return traitsToBeIncluded;
    }
  }

  private void setTraitCombinationsReferenceData(UCCHelper helper, List<Trait> allTraits, List<Trait> traitsIncluded, StringBuilder excludedTraits) throws IOException {
        helper.setRequestAttributeValue(TRAITS_TO_BE_FILTERED, excludedTraits.toString().trim());
        helper.setRequestAttributeValue(TRAITS_INCLUDED, traitsIncluded);
        helper.setRequestAttributeValue(ALL_POSSIBLE_TRAIT_COMBINATION_VALUES, allTraits);
    }

  protected List<Trait> getTraitList() {
    return getTraitService().lookupAllActive();
  }
}