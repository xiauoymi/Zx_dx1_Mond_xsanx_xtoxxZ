package com.monsanto.eas.hiat.controller;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class HybridDetailSelectionCriteria {
    private final Product product;
    private final Trait trait;
    private final Trait femaleDetailTrait;
    private final Trait maleDetailTrait;

    public HybridDetailSelectionCriteria(Product product, Trait trait, Trait femaleDetailTrait, Trait maleDetailTrait) {
        this.product = product;
        this.trait = trait;
        this.femaleDetailTrait = femaleDetailTrait;
        this.maleDetailTrait = maleDetailTrait;
    }

    public Product getProduct() {
        return product;
    }

    public Trait getTrait() {
        return trait;
    }

    public Trait getFemaleDetailTrait() {
        return femaleDetailTrait;
    }

    public Trait getMaleDetailTrait() {
        return maleDetailTrait;
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }
}
