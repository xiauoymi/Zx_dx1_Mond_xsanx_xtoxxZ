package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.analysis.InbredAnalysis;
import com.monsanto.eas.hiat.analysis.InbredAnalyzer;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.service.ProductSearchResults;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.TraitService;
import com.monsanto.eas.hiat.view.InbredAnalysisXMLGenerator;
import com.monsanto.wst.dao.GenericDAO;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public class InbredAnalysisController extends AnalysisController {

  public static final String WEB_INF_JSP_INBREDANALYSIS_PARAM = "/WEB-INF/jsp/inbredanalysis/inbredStatusParameters.jsp";
  public static final String INBRED_ANALYSIS_JSP = "/WEB-INF/jsp/inbredanalysis/inbredAnalysisParameters.jsp";
  public static final String INBRED_ANALYSIS_RESULTS = "inbredAnalysisResults";

  private final InbredAnalyzer analyzer;
  private final InbredAnalysisXMLGenerator xmlGenerator;

  protected InbredAnalysisController(GenericDAO<HIATConfiguration, Long> configDAO,
                                     TraitService traitService,
                                     ProductService productService,
                                     InbredAnalyzer analyzer, InbredAnalysisXMLGenerator xmlGenerator) {
    super(configDAO, traitService, productService);
    this.analyzer = analyzer;
    this.xmlGenerator = xmlGenerator;
  }

  protected boolean isHybrid() {
    return false;
  }

  protected List<Trait> getTraitList() {
    return getTraitService().lookupAllTraits();
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    super.notSpecified(helper);
    helper.setRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS, Boolean.FALSE.toString());
    helper.setRequestAttributeValue(AnalysisController.ERRORS_LIST, new LinkedList<String>());
    setReferenceDataAndInputDetailsForAnalysis(helper);
    helper.forward(INBRED_ANALYSIS_JSP);
  }

  public void generateAnalysis(UCCHelper helper) throws IOException {
    setReferenceDataAndInputDetailsForAnalysis(helper);
    Collection<Trait> selectedTraits = getTraitsFromHelper(helper);
    ProductSearchResults results = getProductByNames(helper);
    Collection<String> errors = validateAndSetRequestParameters(selectedTraits, results);
    helper.setRequestAttributeValue(AnalysisController.ERRORS_LIST, errors);
    boolean isValidRequest = errors.isEmpty();
    helper.setRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS, Boolean.toString(isValidRequest));
    helper.setRequestAttributeValue(AnalysisConstants.PRODUCT_NAME, results.getInputString());
    if (isValidRequest) {
      displayResults(helper, results, selectedTraits);
    }
    helper.forward(INBRED_ANALYSIS_JSP);
  }

  private void displayResults(UCCHelper helper, ProductSearchResults results, Collection<Trait> traits) {
    helper.setRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS, Boolean.TRUE.toString());
    List<InbredAnalysis> analysisResultList = getResults(results, traits);
    helper.setRequestAttributeValue(InbredAnalysisController.INBRED_ANALYSIS_RESULTS, analysisResultList);
  }

  private List<InbredAnalysis> getResults(ProductSearchResults results, Collection<Trait> traits) {
    List<InbredAnalysis> analysisResultList = new ArrayList<InbredAnalysis>();
    Collection<Product> uniqueBases = getProductService().getUniqueBaseProducts(results.getResults());
    for (Product product : uniqueBases) {
      for (Trait trait : traits) {
        analysisResultList.add(analyzer.analyze(product, trait));
      }
    }

    return analysisResultList;
  }

  public void downloadInbredAnalysis(UCCHelper helper) throws IOException {
    ProductSearchResults results = getProductByNames(helper);
    Collection<Trait> selectedTraits = getTraitsFromHelper(helper);
    List<InbredAnalysis> analysisResultList = getResults(results, selectedTraits);
    Document document = xmlGenerator.getXmlContent(analysisResultList, results.getFailures());
    helper.setContentType(AnalysisConstants.EXCEL_CONTENT_TYPE);
    helper.writeToExcel(document, AnalysisConstants.STYLESHEET_INBRED_ANALYSIS_XSL);
  }
}
