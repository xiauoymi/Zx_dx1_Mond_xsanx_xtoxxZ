package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.hiat.analysis.InbredStatus;
import com.monsanto.eas.hiat.analysis.InbredStatusAnalyzer;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.service.ProductSearchResults;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.TraitService;
import com.monsanto.eas.hiat.view.InbredStatusXMLGenerator;
import com.monsanto.wst.dao.GenericDAO;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredStatusController extends AnalysisController {
  private final InbredStatusAnalyzer statusAnalyzer;
  private final InbredStatusXMLGenerator xmlGenerator;
  public static final String WEB_INF_JSP_INBREDANALYSIS_PARAM = "/WEB-INF/jsp/inbredanalysis/inbredStatusParameters.jsp";
  public static final String PRODUCT_LIST = "productList";
  public static final String INBRED_STATUS_RESULTS = "inbredAnalysisResults";
  public static final String INVENTORY_TYPES = "inventoryTypes";

  public InbredStatusController(GenericDAO<HIATConfiguration, Long> configDAO,
                                TraitService traitService,
                                InbredStatusAnalyzer inbredStatusAnalyzer,
                                ProductService productService, InbredStatusXMLGenerator xmlGenerator) {
    super(configDAO, traitService, productService);
    this.statusAnalyzer = inbredStatusAnalyzer;
    this.xmlGenerator = xmlGenerator;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    super.notSpecified(helper);
    helper.forward(WEB_INF_JSP_INBREDANALYSIS_PARAM);
  }

  public void generateAnalysis(UCCHelper helper) throws IOException {
    Collection<Trait> selectedTraits = getTraitsFromHelper(helper);
    ProductSearchResults results = getProductByNames(helper);
    Collection<String> errors = validateAndSetRequestParameters(selectedTraits, results);

    if (errors.isEmpty()) {
      analyzeProductTraitCombinationAndSetResultsBackInHelper(helper, selectedTraits);
    }

    setReferenceDataAndInputDetailsForAnalysis(helper);
    helper.setRequestAttributeValue(ERRORS_LIST, errors);
    helper.forward(WEB_INF_JSP_INBREDANALYSIS_PARAM);
  }

  private void analyzeProductTraitCombinationAndSetResultsBackInHelper(UCCHelper helper, Collection<Trait> selectedTraits) throws IOException {
    ProductSearchResults results = getProductByNames(helper);
    Collection<Product> products = results.getResults();
    Collection<InbredStatus> statusResults = statusAnalyzer.analyze(products, selectedTraits);
    setResultsBackInHelper(helper, products, statusResults);
    setMissingProductsInHelper(helper, results.getFailures());
  }

  @SuppressWarnings({"TypeMayBeWeakened"})
  private void setMissingProductsInHelper(UCCHelper helper, Collection<String> failures) {
    helper.setRequestAttributeValue(MISSING_PRODUCTS, failures);
  }

  @SuppressWarnings({"TypeMayBeWeakened"})
  private void setResultsBackInHelper(UCCHelper helper, Collection<Product> namesMatchingCriteria,
                                      Collection<InbredStatus> statusResults) {
    helper.setRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS, AnalysisConstants.TRUE_STRING);
    helper.setRequestAttributeValue(PRODUCT_LIST, namesMatchingCriteria);
    helper.setRequestAttributeValue(INBRED_STATUS_RESULTS, statusResults);
    helper.setRequestAttributeValue(PRODUCT_NAME_TYPES, ProductNameType.values());
    helper.setRequestAttributeValue(INVENTORY_TYPES, InventoryType.values());
  }

  protected boolean isHybrid() {
    return false;
  }

  public void downloadInbredAnalysis(UCCHelper helper) throws IOException {
//    dumpHelper(helper);
    ProductSearchResults results = getProductByNames(helper);
    Collection<Trait> selectedTraits = getTraitsFromHelper(helper);
    Collection<InbredStatus> statusResults = statusAnalyzer.analyze(results.getResults(), selectedTraits);
    Document document = xmlGenerator.getXmlContent(statusResults, results.getFailures());
    DOMUtil.outputXML(document);
    helper.setHeader("Content-disposition", "attachment; filename=inbredStatus.xls");
    helper.setContentType(AnalysisConstants.EXCEL_CONTENT_TYPE);
    helper.writeToExcel(document, AnalysisConstants.STYLESHEET_INBRED_STATUS_XSL);
  }

/*
  private void dumpHelper(UCCHelper helper) throws IOException {
    Enumeration paramNameEnumer = helper.getParameterNames();
    while (paramNameEnumer.hasMoreElements()) {
      String paramName = (String) paramNameEnumer.nextElement();
      System.out.println(paramName + " : " + helper.getRequestParameterValue(paramName));
    }
  }
*/

/*
  public void downloadInbredAnalysis(UCCHelper helper) throws IOException {
    ProductSearchResults results = getProductByNames(helper);
    Collection<Trait> selectedTraits = getTraitsFromHelper(helper);
    Collection<InbredStatus> statusResults = statusAnalyzer.analyze(results.getResults(), selectedTraits);
    helper.setContentType(AnalysisConstants.EXCEL_CONTENT_TYPE);
    helper.setHeader("Content-disposition", "filename=inbredStatus.xls");
    OutputStream output = helper.getBinaryStream();
    try {
      xlsGenerator.generateStatusWorkbook(output, statusResults, results.getFailures());
    } catch (RuntimeException e) {
      e.printStackTrace();
      e.printStackTrace(new PrintStream(output));
    } finally {
      output.close();
    }
  }
*/

  protected List<Trait> getTraitList() {
    return getTraitService().lookupAllTraits();
  }
}

