package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.config.HIATConfigurationFactory;
import com.monsanto.eas.hiat.service.LoadService;
import com.monsanto.wst.dao.GenericDAO;

import java.io.IOException;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ReferencePageController extends HIATController {
  public static final String REFERENCE_PAGE_LOCATION = "/WEB-INF/jsp/reference.jsp";
  public static final String CONFIGURATION = "config";
  public static final String LOAD_DATE = "loadDate";
  private static final String USER_GROUP = "userGroup";
  private static final String ADMIN_GROUP = "adminGroup";
  private final LoadService loadService;

  protected ReferencePageController(GenericDAO<HIATConfiguration, Long> configDAO, LoadService loadService) {
    super(configDAO);
    this.loadService = loadService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    HIATConfiguration config = HIATConfigurationFactory.getConfiguration();
    helper.setRequestAttributeValue(CONFIGURATION, config);
    helper.setRequestAttributeValue(LOAD_DATE, formatLoadDate(loadService.getLastLoadDate()));
    helper.setRequestAttributeValue(USER_GROUP, getRequiredGroup());
    helper.setRequestAttributeValue(ADMIN_GROUP, getAdminGroup());
    helper.forward(REFERENCE_PAGE_LOCATION);
  }

  private static final DateFormat fmt = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
  private String formatLoadDate(Date loadDate) {
    if (loadDate == null) {
      return "UNKNOWN";
    } else {
      return fmt.format(loadDate);
    }
  }
}
