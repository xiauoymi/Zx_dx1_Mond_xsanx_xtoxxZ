package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.controller.constants.ScenarioConstants;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.service.ScenarioService;
import com.monsanto.wst.dao.GenericDAO;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;

import java.io.IOException;
import java.text.ParseException;
import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class SavedScenarioController extends HIATController {
  private static final String SORT_BY_NAME = "name";
  private static final String SORT_BY_USER = "user";
  private static final String SORT_BY_DATE = "date";
  private static final String DEFAULT_SORT_KEY = "user";
  private static final String DEFAULT_SORT_DIR = "asc";
  private final ScenarioService scenarioService;
  private static final Map<String, String[]> sortKeyMap = new HashMap<String, String[]>();

  static {
    sortKeyMap.put(SORT_BY_NAME, new String[]{"name", "saveDate"});
    sortKeyMap.put(SORT_BY_USER, new String[]{"username", "name"});
    sortKeyMap.put(SORT_BY_DATE, new String[]{"saveDate", "username", "name"});
  }

  public SavedScenarioController(GenericDAO<HIATConfiguration, Long> configDAO, ScenarioService scenarioService) {
    super(configDAO);
    this.scenarioService = scenarioService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    List<String> userIdsWithSavedScenarios = this.scenarioService.lookupUserIdsWithSavedScenarios();
    String owner = getUserIdToLookupSavedScenariosFor(helper, userIdsWithSavedScenarios);
    List<Scenario> scenarios = this.scenarioService
        .lookupSavedScenariosByCriteria(owner, null, null, null, getSortKeys(null), null);
    helper.setRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE, scenarios);
    helper.setRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE, userIdsWithSavedScenarios);
    helper.setRequestAttributeValue(ScenarioConstants.OWNER, owner);
    helper.setRequestAttributeValue(ScenarioConstants.SORT_KEY, DEFAULT_SORT_KEY);
    helper.setRequestAttributeValue(ScenarioConstants.SORT_DIR, DEFAULT_SORT_DIR);
    helper.forward(ScenarioConstants.SAVED_SCENARIOS_JSP);
  }

  @SuppressWarnings({"WeakerAccess"})
  public void searchSavedScenariosByCriteria(UCCHelper helper) throws IOException {
    String sortKey = helper.getRequestParameterValue(ScenarioConstants.SORT_KEY);
    String sortOrder = helper.getRequestParameterValue(ScenarioConstants.SORT_DIR);
    String owner = helper.getRequestParameterValue(ScenarioConstants.OWNER);
    String scenarioName = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_NAME);
    Date saveDateFrom = getDate(helper.getRequestParameterValue(ScenarioConstants.SAVE_DATE_FROM));
    Date saveDateTo = getDate(helper.getRequestParameterValue(ScenarioConstants.SAVE_DATE_TO));
    Collection<Scenario> scenarios = this.scenarioService
        .lookupSavedScenariosByCriteria(owner, scenarioName, saveDateFrom, saveDateTo, getSortKeys(sortKey), sortOrder);
    helper.setRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE, scenarios);
    helper.setRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE,
        this.scenarioService.lookupUserIdsWithSavedScenarios());
    helper.setRequestAttributeValue(ScenarioConstants.SORT_KEY, sortKey);
    helper.setRequestAttributeValue(ScenarioConstants.SORT_DIR, sortOrder);
    helper.setRequestAttributeValue(ScenarioConstants.OWNER, owner);
    helper.setRequestAttributeValue(ScenarioConstants.SCENARIO_NAME, scenarioName);
    helper.setRequestAttributeValue(ScenarioConstants.SAVE_DATE_FROM, saveDateFrom);
    helper.setRequestAttributeValue(ScenarioConstants.SAVE_DATE_TO, saveDateTo);
    helper.forward(ScenarioConstants.SAVED_SCENARIOS_JSP);
  }

    public void deleteScenario(UCCHelper helper) throws IOException {
    String idStr = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_IDS_TO_DELTETE);
    String[] ids = StringUtils.isBlank(idStr) ? new String[]{} : idStr.split(",");
    this.scenarioService.deleteScenariosById(ids);
    helper.setRequestAttributeValue(ScenarioConstants.NUM_SCENARIO_DELTETED, ids.length);
    searchSavedScenariosByCriteria(helper);
  }

  private String getUserIdToLookupSavedScenariosFor(UCCHelper helper, Iterable<String> userIdsWithSavedScenarios) {
    for (String userId : userIdsWithSavedScenarios) {
      if (userId.equalsIgnoreCase(helper.getAuthenticatedUserID())) {
        return helper.getAuthenticatedUserID();
      }
    }
    return null;
  }

  private Date getDate(String dateStr) {
    try {
      return DateUtils.parseDate(dateStr, new String[]{ScenarioConstants.DATE_FORMAT});
    } catch (ParseException e) {
      return null;
    }
  }

  private String[] getSortKeys(String key) {
    String[] sortKeys = sortKeyMap.get(key);
    if (sortKeys == null) {
      return sortKeyMap.get(DEFAULT_SORT_KEY);
    }
    return sortKeys;
  }
}
