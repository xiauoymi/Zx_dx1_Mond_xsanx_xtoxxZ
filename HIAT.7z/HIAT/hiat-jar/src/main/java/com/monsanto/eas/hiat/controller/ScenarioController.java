/*
 ScenarioController was created on Mar 2, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.analysis.HybridAnalysisDetail;
import com.monsanto.eas.hiat.analysis.HybridAnalyzer;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.controller.constants.ScenarioConstants;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.service.ProductSearchResults;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.ScenarioService;
import com.monsanto.eas.hiat.service.TraitService;
import com.monsanto.eas.hiat.controller.AnalysisConstants;
import com.monsanto.eas.hiat.util.CollectionUtil;
import com.monsanto.eas.hiat.view.HybridAnalysisXMLGenerator;
import com.monsanto.wst.dao.GenericDAO;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Filename:    $RCSfile: ScenarioController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date:
 * 2009/03/09 14:29:22 $
 *
 * @author sspati1
 * @version $Revision: 1.30 $
 */
public class ScenarioController extends HIATController {
  //todo large class - look at refactoring it - possibly splitting into multiple controllers
  private final ScenarioService scenarioService;
  private final HybridAnalyzer analyzer;
  private final TraitService traitService;
  private final ProductService productService;
  private final HybridAnalysisXMLGenerator xmlGenerator;
  public static final String SAVED_ANALYSIS_LIST_FOR_RERUN = "savedAnalysisListForRerun";

  public ScenarioController(GenericDAO<HIATConfiguration, Long> configDAO,
                            ScenarioService scenarioService, HybridAnalyzer analyzer, TraitService traitService,
                            ProductService productService, HybridAnalysisXMLGenerator xmlGenerator) {
    super(configDAO);
    this.scenarioService = scenarioService;
    this.analyzer = analyzer;
    this.traitService = traitService;
    this.productService = productService;
    this.xmlGenerator = xmlGenerator;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
  }

  public void displaySaveScenarioForm(UCCHelper helper) throws IOException {
    helper.forward(ScenarioConstants.SAVE_SCENARIO_JSP);
  }

  public void saveScenario(UCCHelper helper) throws IOException {
    String scenarioName = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_NAME);
    String scenarioDesc = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_DESC);
    Scenario scenario = scenarioService.lookupScenarioByName(StringUtils.trim(scenarioName));
    if (scenario == null) {
      saveScenarioFromRequest(false, helper);
    } else {
      //todo what does this is code branch indicate
      helper.setRequestAttributeValue(ScenarioConstants.SAVE_SCENARIO_SUCCESSFULL, "false");
      helper.setRequestAttributeValue(ScenarioConstants.SCENARIO_NAME, scenarioName);
      helper.setRequestAttributeValue(ScenarioConstants.SCENARIO_DESC, scenarioDesc);
      setRequestAttributesForRerun(helper);
      helper.setRequestAttributeValue(AnalysisConstants.TRAITS_LIST, traitService.lookupAllTraits());
      helper.setRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS, getSelectedTraitListFromRequest(helper));
      helper.setRequestAttributeValue(AnalysisConstants.PRODUCT_NAME,
              helper.getRequestParameterValue(AnalysisConstants.PRODUCT_NAME));
      helper.setRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST, getListOfHybridAnalysisToSave(helper));
      helper.setRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS, AnalysisConstants.TRUE_STRING);
      helper.forward(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM);
    }
  }

  public void replaceScenario(UCCHelper helper) throws IOException {
    saveScenarioFromRequest(true, helper);
  }

  public void lookupScenario(UCCHelper helper) throws IOException {
    String scenarioId = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_ID);
    lookupScenario(new Long(scenarioId), helper);
  }

  public void rerunScenario(UCCHelper helper) throws IOException {
    String scenarioId = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_ID);
    Scenario scenario = scenarioService.lookupSavedScenariosById(Long.parseLong(scenarioId));
    Collection<Product> productSet = this.productService.lookupProductMatchingInputCriteria(scenario.getProducts(),
            true).getResults();
    Collection<HybridAnalysis> hybridAnalysisList = analyzer.analyze(productSet, scenario.getTraits()).getAnalysisList();
    Collection<HybridAnalysis> savedHybridAnalysisList = scenario.getHybridAnalysis();
    helper.setRequestAttributeValue(ScenarioConstants.IS_RERUN, true);
    helper.setRequestAttributeValue(ScenarioConstants.SCENARIO, scenario);
    helper.setRequestAttributeValue(AnalysisConstants.PRODUCT_NAME, scenario.getProducts());
    helper.setRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS, new ArrayList<Trait>(scenario.getTraits()));
    helper.setRequestAttributeValue(AnalysisConstants.TRAITS_LIST, traitService.lookupAllTraits());
    helper.setRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST, hybridAnalysisList);
    helper.setRequestAttributeValue(SAVED_ANALYSIS_LIST_FOR_RERUN, savedHybridAnalysisList);
    helper.setRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS, AnalysisConstants.TRUE_STRING);

    helper.forward(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM);
  }

  public void displayReplaceOrSaveNewScenarioForm(UCCHelper helper) throws IOException {
    String scenarioName = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_NAME);
    String scenarioDesc = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_DESC);
    String isRerun = helper.getRequestParameterValue(ScenarioConstants.IS_RERUN);
    Scenario scenario = scenarioService.lookupScenarioByName(scenarioName);
    helper.setRequestAttributeValue(ScenarioConstants.IS_RERUN, isRerun);
    helper.setRequestAttributeValue(ScenarioConstants.SCENARIO, scenario);
    helper.setRequestAttributeValue(ScenarioConstants.SCENARIO_DESC, scenarioDesc);
    helper.forward(ScenarioConstants.DUPLICATE_SCENARIO_WARNING_JSP);
  }

  public void displaySaveSuccessfulMessage(UCCHelper helper) throws IOException {
    helper.forward(ScenarioConstants.SAVE_SCENARIO_SUCCESSFULL_JSP);
  }

  public void downloadSavedScenario(UCCHelper helper) throws IOException {
    String scenarioId = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_ID);
    Scenario scenario = scenarioService.lookupSavedScenariosById(new Long(scenarioId));
    Collection<HybridAnalysis> analysisList = new ArrayList<HybridAnalysis>(scenario.getHybridAnalysis());
    String url = helper.requestedURL().substring(0, helper.requestedURL().indexOf("/downloadSavedScenario/scenario"));
    Document document = xmlGenerator.getXmlContent(analysisList, scenario, url, true, helper, new ArrayList<String>(0));

    helper.setContentType(AnalysisConstants.EXCEL_CONTENT_TYPE);
    helper.writeToExcel(document, AnalysisConstants.STYLESHEET_HYBRID_ANALYSIS_XSL);
  }

  public void downloadCurrentValuesForSavedScenario(UCCHelper helper) throws IOException {
    String scenarioId = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_ID);
    Scenario scenario = scenarioService.lookupSavedScenariosById(Long.parseLong(scenarioId));
    Collection<Product> productSet = this.productService.lookupProductMatchingInputCriteria(scenario.getProducts(),
            true).getResults();
    Collection<HybridAnalysis> hybridAnalysisList = analyzer.analyze(productSet, scenario.getTraits()).getAnalysisList();
    Collection<HybridAnalysis> savedHybridAnalysisList = scenario.getHybridAnalysis();

    setSelectedBasedOnSavedAnalysis(hybridAnalysisList, savedHybridAnalysisList);
    String url = helper.requestedURL().substring(0, helper.requestedURL().indexOf("/downloadCurrentValuesForSavedScenario/scenario"));
    Document document = xmlGenerator.getXmlContent(new ArrayList<HybridAnalysis>(hybridAnalysisList), scenario, url, false,
            helper, new ArrayList<String>(0));
    helper.setContentType(AnalysisConstants.EXCEL_CONTENT_TYPE);
    helper.writeToExcel(document, AnalysisConstants.STYLESHEET_HYBRID_ANALYSIS_XSL);
  }

  private void setRequestAttributesForRerun(UCCHelper helper) throws IOException {
    String isRerun = helper.getRequestParameterValue(ScenarioConstants.IS_RERUN);
    if (StringUtils.isNotBlank(isRerun) && "true".equalsIgnoreCase(isRerun)) {
      String scenarioId = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_ID);
      Scenario scenario = this.scenarioService.lookupSavedScenariosById(Long.parseLong(scenarioId));
      Collection<HybridAnalysis> savedHybridAnalysisList = scenario.getHybridAnalysis();
      helper.setRequestAttributeValue(SAVED_ANALYSIS_LIST_FOR_RERUN, savedHybridAnalysisList);
      helper.setRequestAttributeValue(ScenarioConstants.IS_RERUN, isRerun);
      helper.setRequestAttributeValue(ScenarioConstants.SCENARIO, scenario);
    }
  }

  private void lookupScenario(Long scenarioId, UCCHelper helper) throws IOException {
    Scenario scenario = scenarioService.lookupSavedScenariosById(scenarioId);

    if (scenario == null) {
      helper.forward(ScenarioConstants.SCENARIO_ERROR_JSP);
    } else {
      Collection<HybridAnalysis> analysisList = scenario.getHybridAnalysis();
      helper.setRequestAttributeValue(ScenarioConstants.SCENARIO, scenario);
      helper.setRequestAttributeValue(AnalysisConstants.PRODUCT_NAME, scenario.getProducts());
      helper.setRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS, new ArrayList<Trait>(scenario.getTraits()));
      helper.setRequestAttributeValue(AnalysisConstants.TRAITS_LIST, traitService.lookupAllTraits());
      helper.setRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST, analysisList);
      helper.setRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS, AnalysisConstants.TRUE_STRING);
      helper.forward(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM);
    }
  }

  private void saveScenarioFromRequest(boolean replaceScenario, UCCHelper helper) throws IOException {
    String userId = helper.getAuthenticatedUserID();
    String scenarioName = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_NAME);
    String scenarioDesc = helper.getRequestParameterValue(ScenarioConstants.SCENARIO_DESC);
    List<Trait> traitList = getSelectedTraitListFromRequest(helper);
    String productNames = helper.getRequestParameterValue(AnalysisConstants.PRODUCT_NAME);
    Collection<HybridAnalysis> analysisListToSave = getListOfHybridAnalysisToSave(helper);
    Scenario scenario = scenarioService
            .saveOrUpdatedScenario(userId, StringUtils.trim(scenarioName), scenarioDesc, productNames, traitList, analysisListToSave, replaceScenario);
    helper.setRequestAttributeValue(ScenarioConstants.SAVE_SCENARIO_SUCCESSFULL, "true");
    lookupScenario(scenario.getId(), helper);
  }

  private Collection<HybridDetailSelectionCriteria> getSelectedDetails(UCCHelper helper) throws IOException {
    Collection<HybridDetailSelectionCriteria> selectedDetails = new ArrayList<HybridDetailSelectionCriteria>();
    for (String selectedAnalysisIds : getSelectedAnalysisDetailsFromRequest(helper)) {
      String[] ids = StringUtils.deleteWhitespace(selectedAnalysisIds).split(",");
      Product product = productService.lookupProductById(Long.parseLong(ids[0]));
      Trait trait = traitService.lookupTraitById(Long.parseLong(ids[1]));
      Trait femaleDetailTrait = traitService.lookupTraitById(Long.parseLong(ids[2]));
      Trait maleDetailTrait = traitService.lookupTraitById(Long.parseLong(ids[3]));

      selectedDetails.add(new HybridDetailSelectionCriteria(product, trait, femaleDetailTrait, maleDetailTrait));
    }
    return selectedDetails;
  }

  private Collection<HybridAnalysis> getListOfHybridAnalysisToSave(UCCHelper helper) throws IOException {
    Collection<HybridAnalysis> analysisListToSave = getAnalysisListFromHelper(helper);
    Collection<HybridDetailSelectionCriteria> selectedDetails = getSelectedDetails(helper);

    for (HybridAnalysis analysis : analysisListToSave) {
      for (HybridAnalysisDetail detail : analysis.getDetail()) {
        HybridDetailSelectionCriteria detailCriteria = new HybridDetailSelectionCriteria(analysis.getProduct(),
                analysis.getTrait(), detail.getFemaleParent().getTrait(), detail.getMaleParent().getTrait());
        boolean isSelected = selectedDetails.contains(detailCriteria);
        detail.setSelected(isSelected);
      }
    }

    return analysisListToSave;
  }

  private Collection<HybridAnalysis> getAnalysisListFromHelper(UCCHelper helper) throws IOException {
    ProductSearchResults results = getProductListFromRequest(helper);
    Collection<Product> productList = results.getResults();
    Collection<Trait> traitList = getSelectedTraitListFromRequest(helper);
    return analyzer.analyze(productList, traitList).getAnalysisList();
  }

  private String[] getSelectedAnalysisDetailsFromRequest(UCCHelper helper) throws IOException {
    String[] selectedAnalysisDetails = helper
            .getRequestParameterValues(HybridAnalysisXMLGenerator.SELECTED_ANALYSIS_DETAILS_CHKBX);
    selectedAnalysisDetails = selectedAnalysisDetails == null ? new String[]{} : selectedAnalysisDetails;
    return selectedAnalysisDetails;
  }

  private List<Trait> getSelectedTraitListFromRequest(UCCHelper helper) throws IOException {
    String[] traitsEntered = helper.getRequestParameterValues(AnalysisController.SELECTED_TRAITS);
    return this.traitService.lookupSelectedTraits(traitsEntered);
  }

  private ProductSearchResults getProductListFromRequest(UCCHelper helper) throws IOException {
    String productNames = helper.getRequestParameterValue(AnalysisConstants.PRODUCT_NAME);
    return this.productService.lookupProductMatchingInputCriteria(productNames, true);
  }


  private void setSelectedBasedOnSavedAnalysis(Iterable<HybridAnalysis> reranAnalysises, Iterable<HybridAnalysis> savedAnalysises) {
    for (HybridAnalysis reranAnalysis : reranAnalysises) {
      HybridAnalysis savedAnalysis = CollectionUtil.findMatchingInstance(savedAnalysises, reranAnalysis);
      if (savedAnalysis != null) {
        setSelectedBasedOnSavedAnalysisDetail(reranAnalysis, savedAnalysis);
      }
    }
  }

  private void setSelectedBasedOnSavedAnalysisDetail(HybridAnalysis reranAnalysis, HybridAnalysis savedAnalysis) {
    for (HybridAnalysisDetail reranAnalysisDetail : reranAnalysis.getDetail()) {
      HybridAnalysisDetail savedAnalysisDetail = CollectionUtil
              .findMatchingInstance(savedAnalysis.getDetail(), reranAnalysisDetail);

      if (savedAnalysisDetail != null) {
        reranAnalysisDetail.setSelected(savedAnalysisDetail.getIsSelected());
      }
    }
  }

}