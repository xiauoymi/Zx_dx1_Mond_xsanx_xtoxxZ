package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.service.TraitService;
import com.monsanto.wst.dao.GenericDAO;

import java.io.IOException;
import java.util.Collection;
import java.util.LinkedList;

/**
 * Created by VVVELU Jun 2, 2009
 */
public class TraitConfigController extends AdminController{
    private final TraitService traitService;
    public static final String TRAIT_CONFIG_MESSAGE = "traitConfigMessage";
    public static final String SUCCESSFUL_MESSAGE = "Trait Configuration is Successfully Completed";
    public static final String ERRORS_LIST = "errorsList";
    public static final String WEB_INF_JSP_TRAIT_CONFIG = "/WEB-INF/jsp/traitConfig.jsp";
    public static final String ACTIVE_TRAITS_LIST = "activeTraitsList";
    public static final String IN_ACTIVE_TRAITS_LIST = "inActiveTraitsList";
    public static final String TRAITS_TO_BE_ACTIVATED = "traitsToBeActivated";
    public static final String TRAITS_TO_BE_INACTIVATED = "traitsToBeInactivated";
    public static final String INACTIVATE_TRAIT_ERROR_MSG = "Please select a Trait from Inactive Traits to activate";
    public static final String ACTIVATE_TRAIT_ERROR_MSG = "Please select a Trait from Active Traits to Inactivate";
    public static final String IN_ACTIVATE = "inActivate";
    public static final String ACTIVATE = "activate";
    public static final String CONFIG_TYPE = "configType";

    protected TraitConfigController(GenericDAO<HIATConfiguration, Long> configDAO, TraitService traitService) {
        super(configDAO);
        this.traitService = traitService;
    }

    protected void notSpecified(UCCHelper helper) throws IOException {
      setReferenceData(helper);
      helper.forward(WEB_INF_JSP_TRAIT_CONFIG);
    }

    public void configTrait(UCCHelper helper) throws IOException {
        String configType = helper.getRequestParameterValue(CONFIG_TYPE);
        Collection<String> errors = validateInputParameters(helper, configType);
        if(errors.isEmpty()) {
            Trait selectedTrait = getSelectedTrait(helper, configType);
            if(IN_ACTIVATE.equals(configType)) {
              selectedTrait.setActive(false);
            } else {
              selectedTrait.setActive(true);
            }

            traitService.configureTrait(selectedTrait);
            helper.setRequestAttributeValue(TRAIT_CONFIG_MESSAGE, SUCCESSFUL_MESSAGE);
        }
        setReferenceData(helper);
        helper.setRequestAttributeValue(ERRORS_LIST, errors);
        helper.forward(WEB_INF_JSP_TRAIT_CONFIG);
    }

    private Trait getSelectedTrait(UCCHelper helper, String configType) throws IOException {
        String trait = getTraitBasedOnConfigType(helper, configType);
        return traitService.lookupTraitById(Long.valueOf(trait));
    }

    private Collection<String> validateInputParameters(UCCHelper helper, String configType) throws IOException {
        Collection<String> errors = new LinkedList<String>();
        String trait = getTraitBasedOnConfigType(helper, configType);
        if(StringUtils.isNullOrEmpty(trait) && "activate".equals(configType)) {
            errors.add("Please select a Trait from Active Traits to Inactivate");
        }
        
        if(StringUtils.isNullOrEmpty(trait) && "inActivate".equals(configType)) {
            errors.add("Please select a Trait from Inactive Traits to activate");
        }
        return errors;
    }


    private String getTraitBasedOnConfigType(UCCHelper helper, String configType) throws IOException {
        return IN_ACTIVATE.equals(configType) ? getActiveTraitInputValue(helper) : getInActiveTraitInputValue(helper);
    }

    private String getActiveTraitInputValue(UCCHelper helper) throws IOException {
        return helper.getRequestParameterValue(TRAITS_TO_BE_INACTIVATED);
    }

    private String getInActiveTraitInputValue(UCCHelper helper) throws IOException {
        return helper.getRequestParameterValue(TRAITS_TO_BE_ACTIVATED);
    }

    private void setReferenceData(UCCHelper helper) {
      helper.setRequestAttributeValue(ACTIVE_TRAITS_LIST, this.traitService.lookupAllActive());
      helper.setRequestAttributeValue(IN_ACTIVE_TRAITS_LIST, this.traitService.lookupAllInActive());
    }
}
