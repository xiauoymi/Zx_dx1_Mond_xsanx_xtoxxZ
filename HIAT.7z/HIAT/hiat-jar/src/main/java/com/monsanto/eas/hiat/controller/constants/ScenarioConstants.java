/*
 ScenarioConstants was created on Feb 24, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.controller.constants;

/**
 * Filename:    $RCSfile: ScenarioConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-03-23 15:27:59 $
 *
 * @author sspati1
 * @version $Revision: 1.9 $
 */
public interface ScenarioConstants {
  public static final String SORT_KEY = "sortKey";
  public static final String SORT_DIR = "sortDir";
  public static final String DATE_FORMAT = "MM-dd-yyyy";
  public static final String OWNER = "owner";
  public static final String SCENARIO_ID = "scenarioId";
  public static final String SCENARIO_NAME = "scenarioName";
  public static final String SCENARIO_DESC = "scenarioDesc";
  public static final String SAVE_DATE_FROM = "saveDateFrom";
  public static final String SAVE_DATE_TO = "saveDateTo";
  public static final String SCENARIO_LIST_ATTRIBUTE = "scenarios";
  public static final String OWNER_LIST_ATTRIBUTE = "owners";
  public static final String SCENARIO = "scenario";
  public static final String IS_RERUN = "isRerun";
  public static final String SCENARIO_IDS_TO_DELTETE = "scenarioIdsToDelete";
  public static final String NUM_SCENARIO_DELTETED = "numOfScenariosDeleted";
  public static final String SAVE_SCENARIO_SUCCESSFULL = "saveScenarioSuccessfull";
  public static final String SAVED_SCENARIOS_JSP = "/WEB-INF/jsp/scenario/savedscenario.jsp";
  public static final String DUPLICATE_SCENARIO_WARNING_JSP = "/WEB-INF/jsp/scenario/replaceOrSaveNewScenarioFrm.jsp";
  public static final String SAVE_SCENARIO_SUCCESSFULL_JSP = "/WEB-INF/jsp/scenario/saveScenarioSuccessfull.jsp";
  public static final String SAVE_SCENARIO_JSP = "/WEB-INF/jsp/scenario/saveScenarioFrm.jsp";
  public static final String SCENARIO_ERROR_JSP = "/WEB-INF/jsp/scenario/scenarioError.jsp";
}