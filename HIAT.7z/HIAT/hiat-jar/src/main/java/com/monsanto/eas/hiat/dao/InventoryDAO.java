package com.monsanto.eas.hiat.dao;

import com.monsanto.eas.hiat.model.InventoryEntry;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.wst.dao.GenericDAO;

import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface InventoryDAO extends GenericDAO<InventoryEntry, Long> {
    List<InventoryEntry> findByProduct(Product product);

    long getInventory(Product product, InventoryType invType);
}
