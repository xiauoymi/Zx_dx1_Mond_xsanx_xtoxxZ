package com.monsanto.eas.hiat.dao;

import com.monsanto.eas.hiat.model.InventoryEntry;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.wst.dao.GenericDAO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Expression;

import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InventoryDAOImpl implements InventoryDAO {
    private final GenericDAO<InventoryEntry, Long> baseDAO;

    public InventoryDAOImpl(GenericDAO<InventoryEntry, Long> baseDAO) {
        this.baseDAO = baseDAO;
    }

    public InventoryEntry findByPrimaryKey(Long aLong) {
        return baseDAO.findByPrimaryKey(aLong);
    }

    public List<InventoryEntry> findAll() {
        return baseDAO.findAll();
    }

    public List<InventoryEntry> findAll(int startIndex, int fetchSize) {
        return baseDAO.findAll(startIndex, fetchSize);
    }

    public List<InventoryEntry> findByExample(InventoryEntry exampleInstance, String[] excludeProperty) {
        return baseDAO.findByExample(exampleInstance, excludeProperty);
    }

    public InventoryEntry save(InventoryEntry entity) {
        return baseDAO.save(entity);
    }

    public void delete(InventoryEntry entity) {
        baseDAO.delete(entity);
    }

    public void beginTransaction() {
        baseDAO.beginTransaction();
    }

    public void commitTransaction() {
        baseDAO.commitTransaction();
    }

    public Criteria createCriteria() {
        return baseDAO.createCriteria();
    }

    public List<InventoryEntry> findAll(String key, boolean ascending) {
        return baseDAO.findAll(key, ascending);
    }

    public List<InventoryEntry> findByProduct(Product product) {
        Criteria criteria = baseDAO.createCriteria();
        criteria.add(Expression.eq("product", product));
        return criteria.list();
    }

    public long getInventory(Product product, InventoryType invType) {
        Criteria criteria = baseDAO.createCriteria();
        criteria.add(Expression.eq("product", product));
        criteria.add(Expression.eq("inventoryType", invType));
        List<InventoryEntry> inventory = criteria.list(); //todo this seems to be returning duplicates
        long quantityOnHand = 0L;
        for (InventoryEntry entry : inventory) {
            quantityOnHand += entry.getQuantity();
        }

        return quantityOnHand;
    }
}
