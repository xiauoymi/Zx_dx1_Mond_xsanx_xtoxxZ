package com.monsanto.eas.hiat.dao;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;
import com.monsanto.wst.dao.GenericDAO;

import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface ProductionDAO extends GenericDAO<ProductionEntry, Long> {
    List<ProductionEntry> findByProduct(Product product);
    long getProduction(Product product, InventoryType invType);
    long getPlannedProduction(Product product, InventoryType invType);
}
