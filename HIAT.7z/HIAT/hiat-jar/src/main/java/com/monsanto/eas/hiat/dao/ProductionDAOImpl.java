package com.monsanto.eas.hiat.dao;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;
import com.monsanto.wst.dao.GenericDAO;
import org.hibernate.Criteria;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ProductionDAOImpl implements ProductionDAO {
  private final GenericDAO<ProductionEntry, Long> baseDAO;

  public ProductionDAOImpl(GenericDAO<ProductionEntry, Long> baseDAO) {
    this.baseDAO = baseDAO;
  }

  @SuppressWarnings("unchecked")
  public List<ProductionEntry> findByProduct(Product product) {
    Criteria criteria = baseDAO.createCriteria();
    criteria.add(Restrictions.eq("product", product));

    return (List<ProductionEntry>) criteria.list();
  }

  public long getProduction(Product product, InventoryType invType) {
    return getProductionBasedOnInvTypeAndPlanned(product, invType, false);
  }

  public long getPlannedProduction(Product product, InventoryType invType) {
    return getProductionBasedOnInvTypeAndPlanned(product, invType, true);
  }

  @SuppressWarnings({"unchecked", "TypeMayBeWeakened"})
  private long getProductionBasedOnInvTypeAndPlanned(Product product, InventoryType invType, boolean planned) {
    Criteria criteria = baseDAO.createCriteria();
    criteria.add(Expression.eq("product", product));
    criteria.add(Expression.eq("inventoryType", invType));
    criteria.add(Expression.eq("planned", planned));

    List<ProductionEntry> inventory = criteria.list();

    long quantityOnHand = 0L;
    for (ProductionEntry entry : inventory) {
      quantityOnHand += entry.getQuantity();
    }

    return quantityOnHand;
  }

  public ProductionEntry findByPrimaryKey(Long aLong) {
    return baseDAO.findByPrimaryKey(aLong);
  }

  public List<ProductionEntry> findAll() {
    return baseDAO.findAll();
  }

  public List<ProductionEntry> findAll(int startIndex, int fetchSize) {
    return baseDAO.findAll(startIndex, fetchSize);
  }

  public List<ProductionEntry> findByExample(ProductionEntry exampleInstance, String[] excludeProperty) {
    return baseDAO.findByExample(exampleInstance, excludeProperty);
  }

  public ProductionEntry save(ProductionEntry entity) {
    return baseDAO.save(entity);
  }

  public void delete(ProductionEntry entity) {
    baseDAO.delete(entity);
  }

  public void beginTransaction() {
    baseDAO.beginTransaction();
  }

  public void commitTransaction() {
    baseDAO.commitTransaction();
  }

  public Criteria createCriteria() {
    return baseDAO.createCriteria();
  }

  public List<ProductionEntry> findAll(String key, boolean ascending) {
    return baseDAO.findAll(key, ascending);
  }
}
