package com.monsanto.eas.hiat.dao;

import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.wst.dao.GenericDAO;

/**
 * Created by vvvelu Date: Feb 10, 2009 Time: 9:31:42 AM
 */
public interface TraitDAO extends GenericDAO<Trait, Long> {

    Trait getConventional();
}
