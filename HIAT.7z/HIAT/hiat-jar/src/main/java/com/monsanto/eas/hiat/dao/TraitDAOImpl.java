package com.monsanto.eas.hiat.dao;

import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.wst.dao.GenericDAO;
import org.hibernate.Criteria;

import java.util.List;

/**
 * User: vvvelu Date: Feb 10, 2009 Time: 9:33:07 AM 
 */
public class TraitDAOImpl implements TraitDAO {
    private final GenericDAO<Trait, Long> baseDAO;
    private Trait conv = null;

    public TraitDAOImpl(GenericDAO<Trait, Long> baseDAO) {
        this.baseDAO = baseDAO;
    }

    public Trait getConventional() {
        if (conv == null) {
            conv = findByPrimaryKey(0L);
        }

        return conv;
    }

    public Trait findByPrimaryKey(Long aLong) {
        return baseDAO.findByPrimaryKey(aLong);
    }

    public List<Trait> findAll() {
        return baseDAO.findAll();
    }

    public List<Trait> findAll(int startIndex, int fetchSize) {
        return baseDAO.findAll(startIndex, fetchSize);
    }

    public List<Trait> findByExample(Trait exampleInstance, String[] excludeProperty) {
        return baseDAO.findByExample(exampleInstance, excludeProperty);
    }

    public Trait save(Trait entity) {
        return baseDAO.save(entity);
    }

    public void delete(Trait entity) {
        baseDAO.delete(entity);
    }

    public void beginTransaction() {
        baseDAO.beginTransaction();
    }

    public void commitTransaction() {
        baseDAO.commitTransaction();
    }

    public Criteria createCriteria() {
        return baseDAO.createCriteria();
    }

    public List<Trait> findAll(String key, boolean ascending) {
        return baseDAO.findAll(key, ascending);
    }
}
