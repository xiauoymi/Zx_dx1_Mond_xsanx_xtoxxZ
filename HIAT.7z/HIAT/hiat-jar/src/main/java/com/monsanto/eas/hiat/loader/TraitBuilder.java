package com.monsanto.eas.hiat.loader;

import com.monsanto.eas.hiat.model.Trait;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class TraitBuilder {
  private final Collection<Trait> knownTraits = new ArrayList<Trait>();
  private final Map<String, Trait> traitNameMap = new HashMap<String, Trait>();
  private final Map<String, Trait> traitEventMap = new HashMap<String, Trait>();
  private final Collection<TraitParseInfo> unknownTraits = new ArrayList<TraitParseInfo>();

  public TraitBuilder(Collection<TraitParseInfo> traitParseInfo) {
    unknownTraits.addAll(traitParseInfo);
  }

  private void processTraits() {
    processSimpleTraits();

    while (processTraitsWithParents()) {
      // work is occurring in condition method
    }

    if (!unknownTraits.isEmpty()) {
      throw new RuntimeException("One or more parents not found for: " + unknownTraits.iterator().next());
    }
  }

  private boolean processTraitsWithParents() {
    Collection<TraitParseInfo> processedTraits = new ArrayList<TraitParseInfo>();
    for (TraitParseInfo info : unknownTraits) {
      Collection<String> parentNames = info.getParentNames();
      Set<Trait> parents = getParentsFromNames(parentNames);

      final boolean allParentsWereFound = (parents.size() == parentNames.size());
      if (allParentsWereFound) {
        add(new TraitToBeLoaded(info.getCode(), info.getFullName(), info.getCommName(), parents, true));
        processedTraits.add(info);
      }
    }

    unknownTraits.removeAll(processedTraits);
    return !processedTraits.isEmpty();
  }

  private Set<Trait> getParentsFromNames(Collection<String> parentNames) {
    Set<Trait> parents = new HashSet<Trait>();
    for (String parentName : parentNames) {
      addParentFromName(parents, parentName);
    }
    return parents;
  }

  private void addParentFromName(Set<Trait> parents, String parentName) {
    Trait parentFromName = traitNameMap.get(parentName);
    Trait parentFromEvent = traitEventMap.get(parentName);
    if (parentFromName != null) {
      parents.add(parentFromName);
    } else if (parentFromEvent != null) {
      parents.add(parentFromEvent);
    }
  }

  private void processSimpleTraits() {
    Collection<TraitParseInfo> processedTraits = new ArrayList<TraitParseInfo>();
    for (TraitParseInfo info : unknownTraits) {
      if (!info.getFullName().contains(TraitLoader.PARENT_SEPERATOR)) {
        add(new TraitToBeLoaded(info.getCode(), info.getFullName(), info.getCommName(), new HashSet<Trait>(0), true));
        processedTraits.add(info);
      }
    }

    unknownTraits.removeAll(processedTraits);
  }

  private void add(Trait trait) {
    knownTraits.add(trait);
    traitNameMap.put(trait.getCommercialName(), trait);
    traitEventMap.put(trait.getFullName(), trait);
  }

  public Collection<Trait> getKnownTraits() {
    processTraits();
    return knownTraits;
  }

  private static class TraitToBeLoaded implements Trait {
    private final String code;
    private final String fullName;
    private final String commercialName;
    private final Set<Trait> parentTraits;
    private boolean isActive;

    public TraitToBeLoaded(String code, String fullName, String commercialName, Set<Trait> parentTraits, boolean isActive) {
      this.code = code;
      this.fullName = fullName;
      this.commercialName = commercialName;
      this.parentTraits = parentTraits;
      this.isActive = isActive;
    }

    public Long getId() {
      return null;
    }

    public String getCode() {
      return code;
    }

    public String getFullName() {
      return fullName;
    }

    public String getCommercialName() {
      return commercialName;
    }

    public boolean getActive() {
        return isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    public Set<Trait> getParentTraits() {
      return parentTraits;
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == null || !(obj instanceof Trait)) {
        return false;
      }

      Trait trait = (Trait) obj;
      return this.getId().equals(trait.getId());
    }

    @Override
    public int hashCode() {
      return code.hashCode();
    }

    public int compareTo(Object o) {
      return this.getCode().compareTo(((Trait) o).getCode());
    }

    @Override
    public String toString() {
      return "TRAIT:" + code;
    }
  }
}
