package com.monsanto.eas.hiat.loader;

import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.TraitImpl;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import java.io.*;
import java.util.*;


/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class TraitLoader {
  public static String FIELD_SEPERATOR = "\t";
  public static final String PARENT_SEPERATOR = ",";

  private final GenericDAO<Trait, Long> traitDAO;
  private HibernateFactory hibernate;

  public TraitLoader(HibernateFactory hibernate, GenericDAO<Trait, Long> traitDAO) {
    this.hibernate = hibernate;
    this.traitDAO = traitDAO;
  }

  public void loadTraits(InputStream input) throws IOException {
    hibernate.beginTransaction();
    Collection<Trait> traitsToBeLoaded = parseTraits(input);
    Collection<Trait> currentTraits = traitDAO.findAll();
    long id = getMaxId(currentTraits);

    Collection<Trait> missingTraits = getMissingTraits(traitsToBeLoaded, currentTraits);

    // note: we are assuming traits are not changing parents, names, etc from this file - it is only dealing with NEW traits

    Map<String, Trait> traitsByCode = getTraitCodeMap(traitDAO);

    for (Trait trait : missingTraits) {
      id++;
      Set<Trait> parentTraitsRaw = trait.getParentTraits();
      Set<Trait> parentTraits = getParentTraitsFromRawParents(traitsByCode, parentTraitsRaw);
      TraitImpl addedTrait = new TraitImpl(id, trait.getCode(), trait.getFullName(), trait.getCommercialName(), parentTraits, true);
      traitDAO.save(addedTrait);
      traitsByCode.put(addedTrait.getCode(), addedTrait);
    }
//    hibernate.rollbackTransaction();
    hibernate.commitTransaction();
  }

  private Set<Trait> getParentTraitsFromRawParents(Map<String, Trait> traitsByCode, Set<Trait> parentTraitsRaw) {
    Set<Trait> parentTraits = new HashSet<Trait>();
    for (Trait parentRaw : parentTraitsRaw) {
      Trait parent = traitsByCode.get(parentRaw.getCode());
      if (parent == null) {
        throw new RuntimeException("Invalid parent code : " + parentRaw.getCode());
      }
      parentTraits.add(parent);
    }
    return parentTraits;
  }

  private Map<String, Trait> getTraitCodeMap(GenericDAO<Trait, Long> dao) {
    Map<String, Trait> map = new HashMap<String, Trait>();
    for (Trait trait : dao.findAll()) {
      map.put(trait.getCode(), trait);
    }
    return map;
  }

  private long getMaxId(Collection<Trait> traits) {
    long maxId = 0L;
    for (Trait trait : traits) {
      long currId = trait.getId();
      if (currId > maxId) {
        maxId = currId;
      }
    }

    return maxId;
  }

  private Collection<Trait> getMissingTraits(Collection<Trait> traitsToBeLoaded, Collection<Trait> currentTraits) {
    Collection<String> traitCodes = getTraitCodes(currentTraits);

    Collection<Trait> missingTraits = new ArrayList<Trait>();
    for (Trait trait : traitsToBeLoaded) {
      String currCode = trait.getCode();
      if (!traitCodes.contains(currCode)) {
        traitCodes.add(currCode);
        missingTraits.add(trait);
      }
    }

    return missingTraits;
  }

  private Collection<String> getTraitCodes(Collection<Trait> currentTraits) {
    Collection<String> traitCodes = new HashSet<String>();
    for (Trait trait : currentTraits) {
      traitCodes.add(trait.getCode());
    }
    return traitCodes;
  }

  public Collection<Trait> parseTraits(InputStream stream) throws IOException {
    Collection<TraitParseInfo> parsedInfo = parseStream(stream);
    return new TraitBuilder(parsedInfo).getKnownTraits();
  }

  private Collection<TraitParseInfo> parseStream(InputStream stream) throws IOException {
    BufferedReader buf = new BufferedReader(new InputStreamReader(stream));
    try {
      Collection<TraitParseInfo> parsedData = new ArrayList<TraitParseInfo>();
      String data = buf.readLine();
      while (data != null) {
        try {
          parsedData.add(parseLine(data));
          data = buf.readLine();
        } catch (RuntimeException e) {
          throw new TraitParseException("Unable to process line: " + data, e);
        }
      }

      return parsedData;
    } finally {
      buf.close();
    }
  }

  private TraitParseInfo parseLine(String data) {
    String[] fields = data.split(FIELD_SEPERATOR);
    String commName = trimQuotes(fields[0]);
    String parentInfo = trimQuotes(fields[1]);
    String code = trimQuotes(fields[2]);

    return new TraitParseInfo(commName, code, parentInfo, parseParentInfo(parentInfo));
  }

  private String trimQuotes(String field) {
    if (
            (field.startsWith("\"") && field.endsWith("\"")) ||
                    (field.startsWith("\'") && field.endsWith("\'"))
            ) {
      return field.substring(1, field.length() - 1);
    } else {
      return field;
    }
  }

  private Collection<String> parseParentInfo(String parentInfo) {
    return Arrays.asList(parentInfo.split(PARENT_SEPERATOR));
  }

  public static void main(String[] args) throws IOException {
    if (args.length != 1) {
      System.out.println("SYNTAX: java com.monsanto.was.hiat.loader.trait.TraitLoader FILENAME");
      return;
    }

    InputStream input = new FileInputStream(args[0]);

    BeanFactory beanFactory = new XmlBeanFactory(new ClassPathResource(HIATConfiguration.HIAT_BEAN_XML));
    TraitLoader loader = (TraitLoader) beanFactory.getBean("traitLoader");

    loader.loadTraits(input);
  }

}

