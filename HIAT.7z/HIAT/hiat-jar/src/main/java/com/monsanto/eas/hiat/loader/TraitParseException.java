package com.monsanto.eas.hiat.loader;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class TraitParseException extends RuntimeException {
  public TraitParseException(String message, Throwable cause) {
    super(message, cause);
  }
}
