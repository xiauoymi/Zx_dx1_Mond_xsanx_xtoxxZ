package com.monsanto.eas.hiat.loader;

import java.util.Collection;

public class TraitParseInfo {
  private final String commName;
  private final String code;
  private final String fullName;
  private final Collection<String> parentNames;

  public TraitParseInfo(String commName, String code, String fullName, Collection<String> parentNames) {
    this.commName = commName;
    this.code = code;
    this.fullName = fullName;
    this.parentNames = parentNames;
  }

  public String getCommName() {
    return commName;
  }

  public String getCode() {
    return code;
  }

  public Collection<String> getParentNames() {
    return parentNames;
  }

  public String getFullName() {
    return fullName;
  }

  @Override
  public String toString() {
    return "code=" + code + ",commName=" + commName + ",event=" + fullName;
  }
}
