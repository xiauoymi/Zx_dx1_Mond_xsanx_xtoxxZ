package com.monsanto.eas.hiat.model;

import java.util.Comparator;

public class CommercialNameTraitComparator implements Comparator<Trait> {
  public int compare(Trait t1, Trait t2) {
    return t1.getCommercialName().compareTo(t2.getCommercialName());
  }
}
