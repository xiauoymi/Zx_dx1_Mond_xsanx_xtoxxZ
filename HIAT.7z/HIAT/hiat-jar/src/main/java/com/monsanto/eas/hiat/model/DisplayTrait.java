/*
 DisplayTrait was created on Mar 10, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.model;

/**
 * Filename:    $RCSfile: DisplayTrait.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-03-12 21:23:30 $
 *
 * @author RRMALL
 * @version $Revision: 1.1 $
 */
public class DisplayTrait {
  private final Trait trait;
  private boolean isSelected;

  public DisplayTrait(Trait trait, boolean selected) {
    this.trait = trait;
    this.isSelected = selected;
  }

  public Trait getTrait() {
    return trait;
  }

  public boolean isSelected() {
      return isSelected;
  }

  public void setSelected(boolean selected) {
    isSelected = selected;
  }
}