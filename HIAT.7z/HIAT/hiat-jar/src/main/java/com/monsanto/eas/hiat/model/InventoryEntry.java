package com.monsanto.eas.hiat.model;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface InventoryEntry {
  Product getProduct();

  long getQuantity();

  InventoryType getType();

  String getFormattedQuantity();
}
