package com.monsanto.eas.hiat.model;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public enum InventoryType {
  PREFOUNDATION("PFND"), GENERATION_1("GEN1"), GENERATION_2("GEN2");

  private final String xmlTag;

  private InventoryType(String xmlTag) {
    this.xmlTag = xmlTag;
  }

  public String getXmlTag() {
    return xmlTag;
  }

  public String getCode() {
    return xmlTag;
  }
}
