package com.monsanto.eas.hiat.model;

import java.util.Date;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface Product {
  //todo Product and ProductName have a circular dependency -- look at this
    Long getId();

    Trait getTrait();

    String getTraitVersion();

    Product getFemaleParent();

    Product getMaleParent();

    Date getHandoffDate();

    Date getPrimaryTestingDate();

    boolean isPrimary();

  Map<ProductNameType, ProductName> getProductNames();

  String getProductName(ProductNameType nameType);

    Product getBase();

  void setProductNames(Map<ProductNameType, ProductName> productNames); //todo look at this, why is setter needed? (because of the circular dependency which needs to be looked at)

  String getStatus();

    boolean isHybrid();

   public int compareTo(Object o);
}
