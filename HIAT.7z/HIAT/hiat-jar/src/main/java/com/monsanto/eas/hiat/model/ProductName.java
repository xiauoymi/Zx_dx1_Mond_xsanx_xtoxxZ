package com.monsanto.eas.hiat.model;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface ProductName {
    Product getProduct();

    String getName();

    DataSource getSource();

    String getSourceId();

    ProductNameType getType();
}
