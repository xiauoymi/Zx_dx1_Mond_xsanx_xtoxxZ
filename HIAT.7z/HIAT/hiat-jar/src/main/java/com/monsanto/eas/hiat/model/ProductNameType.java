package com.monsanto.eas.hiat.model;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public enum ProductNameType {
    TRAITED_PRECOMMERCIAL,
    BASE_PRECOMMERCIAL,
    MANUFACTURING,
    BASE_MANUFACTURING,
    COMMERCIAL,
    OTHER
}
