package com.monsanto.eas.hiat.model;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface ProductionEntry extends InventoryEntry {
  boolean isPlanned();

  Date getAvailableDate();
}
