package com.monsanto.eas.hiat.model;

import java.util.Set;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface Trait {
    String getCode();

    String getFullName();

    String getCommercialName();

    boolean getActive();

    void setActive(boolean active);

    Set<Trait> getParentTraits();

  Long getId();

  int compareTo(Object o);
}
