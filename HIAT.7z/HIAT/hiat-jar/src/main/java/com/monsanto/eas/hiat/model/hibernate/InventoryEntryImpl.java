package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.InventoryEntry;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.util.NumberFormatUtil;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Index;

import javax.persistence.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@SuppressWarnings({"CanBeFinal"})
@Entity
@Table(schema = "HIAT", name = "INVENTORY_ENTRY")
@AccessType("field")
@NoDeleteAllowed
public class InventoryEntryImpl implements InventoryEntry {
    @Id
    @GeneratedValue
    private long id;

    @ManyToOne(targetEntity = ProductImpl.class)
    @Index(name = "ind_inv_product")
    private Product product;

    private long quantity;

    private InventoryType inventoryType;

    public InventoryEntryImpl() {
        this(null, 0L, null);
    }

    public InventoryEntryImpl(Product product, long quantity, InventoryType inventoryType) {
        this.product = product;
        this.quantity = quantity;
        this.inventoryType = inventoryType;
    }

    public Product getProduct() {
        return product;
    }

    public long getQuantity() {
        return quantity;
    }

   public String getFormattedQuantity() {
     return NumberFormatUtil.format(quantity);
   }

    public InventoryType getType() {
        return inventoryType;
    }
}
