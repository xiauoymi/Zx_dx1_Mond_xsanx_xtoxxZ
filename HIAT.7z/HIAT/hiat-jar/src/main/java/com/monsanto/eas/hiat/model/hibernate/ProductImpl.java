package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductName;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.wst.hibernate.EntityEqualsUtil;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@SuppressWarnings({"CanBeFinal"})
@Entity
@Table(schema = "HIAT", name = "PRODUCT")
@AccessType("field")
@NoDeleteAllowed
public class ProductImpl implements Product, Comparable {
  @Id
  @SequenceGenerator(name = "hiatSeq", sequenceName = "HIAT.HIBERNATE_SEQUENCE")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hiatSeq")
  private Long id;

  @ManyToOne(targetEntity = TraitImpl.class)
  private Trait trait;

  private String traitVersion;
  private Date handoffDate;
  private Date primaryTestingDate;

  @ManyToOne(targetEntity = ProductImpl.class)
  private Product femaleParent;

  @ManyToOne(targetEntity = ProductImpl.class)
  private Product maleParent;

  private boolean isPrimary;

  @ManyToOne(targetEntity = ProductImpl.class)
  @JoinColumn(name = "BASE_PRODUCT")
  private Product base;

  private String status;

  @OneToMany(targetEntity = ProductNameImpl.class, mappedBy = "product",
      fetch = FetchType.LAZY,
      cascade = CascadeType.ALL)
  @MapKey(name = "nameType")
  private Map<ProductNameType, ProductName> productNamesMap = new HashMap<ProductNameType, ProductName>();

  @Type(type = "yes_no")
  private Boolean isHybrid;

  public ProductImpl() {
    this(0L, null, null, null, null, null, null, false, null, null, false);
  }

  public ProductImpl(Long id, String traitVersion, Trait trait, Product femaleParent, Product maleParent,
                     Date handoffDate, Date primaryTestingDate, boolean isPrimary, Product base,
                     String status, boolean isHybrid) {
    this.id = id;
    this.traitVersion = traitVersion;
    this.trait = trait;
    this.femaleParent = femaleParent;
    this.maleParent = maleParent;
    this.handoffDate = handoffDate;
    this.primaryTestingDate = primaryTestingDate;
    this.isPrimary = isPrimary;
    this.base = base;
    this.status = status;
    this.isHybrid = isHybrid;
  }

  public Long getId() {
    return id;
  }

  public String getTraitVersion() {
    return traitVersion == null ? "" : traitVersion;
  }

  public Trait getTrait() {
    return trait;
  }

  public Product getFemaleParent() {
    return femaleParent;
  }

  public Product getMaleParent() {
    return maleParent;
  }

  public Product getBase() {
    if (base == null) {
      return this;
    } else {
      return base;
    }
  }

  public Date getHandoffDate() {
    return handoffDate;
  }

  public Date getPrimaryTestingDate() {
    return primaryTestingDate;
  }

  public boolean isPrimary() {
    return isPrimary;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public boolean isHybrid() {
    return (isHybrid == null) ? false : isHybrid;
  }

  public Map<ProductNameType, ProductName> getProductNames() {
    return productNamesMap;
  }

  public void setProductNames(Map<ProductNameType, ProductName> productNames) {
    this.productNamesMap = productNames;
  }

  @Override
  public boolean equals(Object o) {
    return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
    return EntityEqualsUtil.identifierHashCode(this);
  }

  public String getStatus() {
    return status;
  }

  public String getProductName(ProductNameType nameType) {
    Map<ProductNameType, ProductName> nameMap = getProductNames();
    for (ProductNameType type : nameMap.keySet()) {
      if (nameType == type) {
        return nameMap.get(type).getName();
      }
    }
    return "-"; //todo would we want to return a different name instead?
  }

  public int compareTo(Object o) {
    return this.getId().compareTo(((Product) o).getId());
  }

  @Override
  public String toString() {
    return "PRODUCT-" + getId();
  }
}