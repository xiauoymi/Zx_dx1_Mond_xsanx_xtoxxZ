package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.DataSource;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductName;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.wst.hibernate.EntityEqualsUtil;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Index;

import javax.persistence.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@SuppressWarnings({"CanBeFinal"})
@Entity
@Table(schema = "HIAT", name = "PRODUCT_NAME")
@AccessType("field")
@NoDeleteAllowed
public class ProductNameImpl implements ProductName {
  @Id
  @GeneratedValue
  private Long id;

  @Index(name = "ind_product_name")
  private String name;

  @ManyToOne(targetEntity = ProductImpl.class)
  private Product product;

  private DataSource source;
  private String sourceId;
  private ProductNameType nameType;

  public ProductNameImpl() {
    this(0L, null, null, null, null, null);
  }

  public ProductNameImpl(Long id, String name, Product product, DataSource source, String sourceId, ProductNameType nameType) {
    this.id = id;
    this.name = name;
    this.product = product;
    this.source = source;
    this.sourceId = sourceId;
    this.nameType = nameType;
  }

  public Long getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public Product getProduct() {
    return product;
  }

  public DataSource getSource() {
    return source;
  }

  public String getSourceId() {
    return sourceId;
  }

  public ProductNameType getType() {
    return nameType;
  }

  @Override
  public boolean equals(Object o) {
    return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
    return EntityEqualsUtil.identifierHashCode(this);
  }

  @Override
  public String toString() {
    return getName();
  }


}
