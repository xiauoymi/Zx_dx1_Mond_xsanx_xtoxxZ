package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;
import com.monsanto.eas.hiat.util.NumberFormatUtil;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Index;

import javax.persistence.*;
import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@SuppressWarnings({"CanBeFinal"})
@Entity
@Table(schema = "HIAT", name = "PRODUCTION_ENTRY")
@AccessType("field")
@NoDeleteAllowed
public class ProductionEntryImpl implements ProductionEntry {
  @Id
  @GeneratedValue
  private long id;

  private Date availableDate;

  @ManyToOne(targetEntity = ProductImpl.class)
  @Index(name = "ind_prod_product")
  private Product product;

  private long quantity;
  private InventoryType inventoryType;

  private boolean planned;

  public ProductionEntryImpl() {
    this(null, null, 0L, null, false);
  }

  public ProductionEntryImpl(Date availableDate, Product product, long quantity, InventoryType inventoryType, boolean planned) {
    this.availableDate = availableDate;
    this.product = product;
    this.quantity = quantity;
    this.inventoryType = inventoryType;
    this.planned = planned;
  }

  public Date getAvailableDate() {
    return availableDate;
  }

  public Product getProduct() {
    return product;
  }

  public long getQuantity() {
    return quantity;
  }

  public InventoryType getType() {
    return inventoryType;
  }

  public String getFormattedQuantity() {
    return NumberFormatUtil.format(quantity);
  }

  public boolean isPlanned() {
    return planned;
  }
}
