package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.wst.hibernate.EntityEqualsUtil;
import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@SuppressWarnings({"CanBeFinal"})
@Entity
@Table(schema = "HIAT", name = "TRAIT")
@AccessType("field")
@NoDeleteAllowed
public class TraitImpl implements Trait, Comparable {
  @Id
  @SequenceGenerator(name = "hiatSeq", sequenceName = "HIAT.HIBERNATE_SEQUENCE")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hiatSeq")
  private Long id;
  private String code;
  private String fullName;
  private String commercialName;
  @Type(type = "yes_no")
  private boolean isActive;

  @ManyToMany(targetEntity = TraitImpl.class, cascade = CascadeType.ALL)
  @JoinTable(schema = "HIAT", name = "TRAIT_PARENT_REF",
      joinColumns = @JoinColumn(name = "TRAIT_ID"),
      inverseJoinColumns = @JoinColumn(name = "PARENT_TRAIT_ID")
  )
  private Set<Trait> parentTraits;

  public TraitImpl() {
      this(0L, null, null, null, null,false);
      this.parentTraits = new HashSet<Trait>();
  }

  public TraitImpl(Long id, String code, String fullName, String commercialName, Set<Trait> parentTraits, boolean isActive) {
    this.id = id;
    this.code = code;
    this.fullName = fullName;
    this.commercialName = commercialName;
    this.parentTraits = parentTraits;
    this.isActive = isActive;
  }

  protected TraitImpl(Long id) {
        this.id = id;
    }

  public void setId(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public String getCode() {
    return code;
  }

  public String getFullName() {
    return fullName;
  }

  public String getCommercialName() {
    return commercialName;
  }

  public boolean getActive() {
      return isActive;
  }

  public void setActive(boolean active) {
      this.isActive = active;
  }

  public Set<Trait> getParentTraits() {
    return parentTraits;
  }

  @Override
  public boolean equals(Object o) {
      return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
      return EntityEqualsUtil.identifierHashCode(this);
  }

  @Override
  public String toString() {
    return getFullName();
  }


  public int compareTo(Object o) {
    return this.getCode().compareTo(((Trait)o).getCode());
  }
}
