package com.monsanto.eas.hiat.scenario;

import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.model.Trait;

import java.util.Collection;
import java.util.Date;
import java.util.Set;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface Scenario {
    Long getId();

    String getUsername();

    String getName();
    
    String getDescription();

    Date getSaveDate();

    boolean isOutOfDate();

    Collection<ScenarioDetail> getDetails();

  void setDeleted(boolean deleted);

  boolean isDeleted();

  Collection<Trait> getTraits();

  String getProducts();

  void setDetails(Set<ScenarioDetail> details);

  Collection<HybridAnalysis> getHybridAnalysis(); 
}
