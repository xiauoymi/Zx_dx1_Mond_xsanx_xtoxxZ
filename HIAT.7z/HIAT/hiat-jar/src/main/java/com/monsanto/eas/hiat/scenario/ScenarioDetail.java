package com.monsanto.eas.hiat.scenario;

import com.monsanto.eas.hiat.analysis.HybridAnalysis;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface ScenarioDetail {
  Long getId();

  Scenario getScenario();

  HybridAnalysis getHybridAnalysis();
}
