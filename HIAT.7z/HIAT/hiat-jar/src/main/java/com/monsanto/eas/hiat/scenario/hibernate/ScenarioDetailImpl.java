package com.monsanto.eas.hiat.scenario.hibernate;

import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisImpl;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.scenario.ScenarioDetail;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.AccessType;

import javax.persistence.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@Entity
@Table(schema = "HIAT", name = "SCENARIO_DETAIL")
@AccessType("field")
public class ScenarioDetailImpl implements ScenarioDetail {
  @Id
  @SequenceGenerator(name = "hiatSeq", sequenceName = "HIAT.HIBERNATE_SEQUENCE")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hiatSeq")
  @Column(name = "ID")
  private Long id;

  @ManyToOne(targetEntity = ScenarioImpl.class)
  @JoinColumn(name = "SCENARIO_ID")
  private Scenario scenario;

  @OneToOne(targetEntity = HybridAnalysisImpl.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "HYBRID_ANALYSIS_ID")
  private HybridAnalysis hybridAnalysis;

  public ScenarioDetailImpl() {
  }

  public ScenarioDetailImpl(Scenario scenario, HybridAnalysis hybridAnalysis) {
    this.scenario = scenario;
    this.hybridAnalysis = hybridAnalysis;
  }

  public Long getId() {
    return id;
  }

  public Scenario getScenario() {
    return scenario;
  }

  public HybridAnalysis getHybridAnalysis() {
    return hybridAnalysis;
  }

  public boolean equals(Object o) {
    if (!(o instanceof ScenarioDetail)) return false;
    ScenarioDetail detail = (ScenarioDetail) o;

    return new EqualsBuilder().append(scenario, detail.getScenario())
        .append(hybridAnalysis, detail.getHybridAnalysis())
        .isEquals();

  }

  public int hashCode() {
    return HashCodeBuilder.reflectionHashCode(this);
  }
}
