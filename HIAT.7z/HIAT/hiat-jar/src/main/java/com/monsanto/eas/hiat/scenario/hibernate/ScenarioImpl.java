package com.monsanto.eas.hiat.scenario.hibernate;

import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.TraitImpl;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.scenario.ScenarioDetail;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;
import org.apache.commons.lang.builder.EqualsBuilder;

import javax.persistence.*;
import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@SuppressWarnings({"CanBeFinal"})
@Entity
@Table(schema = "HIAT", name = "SCENARIO")
@AccessType("field")
public class ScenarioImpl implements Scenario {
  @Id
  @SequenceGenerator(name = "hiatSeq", sequenceName = "HIAT.HIBERNATE_SEQUENCE")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hiatSeq")
  @Column(name = "ID")
  private Long id;

  @Column(name = "USERNAME")
  private String username;

  @Column(name = "NAME")
  private String name;

  @Column(name = "DESCRIPTION")
  private String description;

  @Column(name = "SAVEDATE")
  private Date saveDate;

  @Column(name = "OUTOFDATE")
  private boolean outOfDate;

  @Column(name = "PRODUCTS")
  private String products;

  @Column(name = "is_deleted")
  @Type(type = "yes_no")
  private boolean isDeleted;

  @OneToMany(mappedBy = "scenario", targetEntity = ScenarioDetailImpl.class,
      cascade = CascadeType.ALL)
  private Set<ScenarioDetail> details = new HashSet<ScenarioDetail>();

  @ManyToMany(targetEntity = TraitImpl.class)
  @JoinTable(schema = "HIAT", name = "SCENARIO_TRAIT",
      joinColumns = @JoinColumn(name = "SCENARIO_ID", referencedColumnName = "ID"),
      inverseJoinColumns = @JoinColumn(name = "TRAIT_ID", referencedColumnName = "ID")
  )
  private Set<Trait> traits = new HashSet<Trait>();

  public ScenarioImpl() {
    this(null, "", "", null, new Date(), false, null, null, new HashSet<ScenarioDetail>());
  }

  public ScenarioImpl(Long id, String username, String name, String description, Date saveDate,
                      boolean outOfDate, String products, Set<Trait> traits, Set<ScenarioDetail> details) {
    this.id = id;
    this.name = name;
    this.username = username;
    this.description = description;
    this.saveDate = saveDate;
    this.products = products;
    this.traits = traits;
    this.details = details;
    this.outOfDate = outOfDate;
  }

  public Long getId() {
    return id;
  }

  public String getUsername() {
    return username;
  }

  public String getName() {
    return name;
  }

  public String getDescription() {
    return description;
  }

  public Date getSaveDate() {
    return saveDate;
  }

  public boolean isOutOfDate() {
    return outOfDate;
  }

  public void setDeleted(boolean deleted) {
    isDeleted = deleted;
  }

  public boolean isDeleted() {
    return isDeleted;
  }

  public Collection<ScenarioDetail> getDetails() {
    return details;
  }

  public Collection<Trait> getTraits() {
    return traits;
  }

  public String getProducts() {
    return products;
  }

  public void setDetails(Set<ScenarioDetail> details) {
    this.details = details;
  }

  public Collection<HybridAnalysis> getHybridAnalysis() {
    Collection<HybridAnalysis> analysisList = new ArrayList<HybridAnalysis>();
    for (ScenarioDetail detail : getDetails()) {
      analysisList.add(detail.getHybridAnalysis());
    }
    return analysisList;
  }

  @Override
  public String toString() {
    return "[ScenarioImpl, id=" + getId() + ']';
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof ScenarioImpl)) return false;

    ScenarioImpl scenario = (ScenarioImpl) o;

    return new EqualsBuilder()
            .append(name, scenario.name)
            .append(username, scenario.username)
            .isEquals();
  }

  @Override
  public int hashCode() {
    return name != null ? name.hashCode() : 0;
  }
}
