package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface AvailabilityService {
  Date getInventoryAvailabilityDate(Product product, InventoryType invType, long minimumQty);
}
