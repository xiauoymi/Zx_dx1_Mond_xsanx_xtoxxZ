package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class AvailabilityServiceImpl implements AvailabilityService {
  private final InventoryService invService;
  private final ProductionService prodService;

  public AvailabilityServiceImpl(InventoryService invService, ProductionService prodService) {
    this.invService = invService;
    this.prodService =prodService;
  }

  public Date getInventoryAvailabilityDate(Product product, InventoryType invType, long minimumQty) {
    long currentQty = invService.getInventory(product, invType);
    Date currentDate = new Date();

    Collection<ProductionEntry> orders = getSortedListOfOrders(product, invType);
    Iterator<ProductionEntry> orderIterator = orders.iterator();
    while ((currentQty < minimumQty) && orderIterator.hasNext()) {
      ProductionEntry entry = orderIterator.next();

      currentDate = entry.getAvailableDate();
      currentQty += entry.getQuantity();
    }

    if (currentQty >= minimumQty) {
      return currentDate;
    } else {
      return null;
    }
  }

  private Collection<ProductionEntry> getSortedListOfOrders(Product product, InventoryType invType) {
    List<ProductionEntry> orders = new ArrayList<ProductionEntry>(prodService.findByProduct(product, invType));
    Collections.sort(orders, new OrderDateComparator());
    return orders;
  }

  private static class OrderDateComparator implements Comparator<ProductionEntry> {
    public int compare(ProductionEntry o1, ProductionEntry o2) {
      Date o1Date = o1.getAvailableDate();
      Date o2Date = o2.getAvailableDate();
      if (o1Date == null || o2Date == null) {
        return compareForNulls(o1, o2);
      } else {
        return org.apache.commons.lang.time.DateUtils.truncate(o1Date, Calendar.DATE).compareTo(o2Date);
      }
    }

    private int compareForNulls(Object o1, Object o2) {
      if (o1 == o2) {
        return 0;
      } else if (o1 == null) {
        return 1;
      } else {
        return -1;
      }
    }
  }
}
