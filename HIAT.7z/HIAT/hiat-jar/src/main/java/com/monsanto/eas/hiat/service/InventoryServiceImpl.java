package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.dao.InventoryDAO;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InventoryServiceImpl implements InventoryService {
  private final InventoryDAO dao;

  public InventoryServiceImpl(InventoryDAO dao) {
    this.dao = dao;
  }

  public long getInventory(Product product, InventoryType invType) {
    return dao.getInventory(product, invType);
  }
}
