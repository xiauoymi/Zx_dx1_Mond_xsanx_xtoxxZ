package com.monsanto.eas.hiat.service;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface LoadService {
  Date getLastLoadDate();
}
