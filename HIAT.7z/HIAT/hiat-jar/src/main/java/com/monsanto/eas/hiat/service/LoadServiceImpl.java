package com.monsanto.eas.hiat.service;

import com.monsanto.wst.hibernate.HibernateFactory;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class LoadServiceImpl implements LoadService {
  private HibernateFactory hibernate;

  public LoadServiceImpl(HibernateFactory hibernate) {
    this.hibernate = hibernate;
  }

  public Date getLastLoadDate() {
    return (Date) hibernate.getSession().createSQLQuery("select max(endtime) from HIAT.load_info " +
            "where id in (select max(id) from HIAT.load_info where endtime is not null)").uniqueResult();
  }
}
