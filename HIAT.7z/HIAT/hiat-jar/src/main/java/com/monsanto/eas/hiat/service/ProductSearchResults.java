package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.model.Product;

import java.util.Collection;
import java.util.HashSet;

public class ProductSearchResults {
  private final Collection<Product> results;
  private final Collection<String> failures;
  private final String inputString;

  public ProductSearchResults(String inputString) {
    this.inputString = inputString;
    results = new HashSet<Product>();
    failures = new HashSet<String>();
  }

  public String getInputString() {
    return inputString;
  }

  public Collection<Product> getResults() {
    return results;
  }

  public Collection<String> getFailures() {
    return failures;
  }

  public void add(Product product) {
    results.add(product);
  }

  public void addAll(Collection<? extends Product> product) {
    results.addAll(product);
  }

  public void fail(String productName) {
    failures.add(productName);
  }
}
