/*
 ProductServiceImpl was created on Mar 2, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.service;

import com.monsanto.Util.StringUtils;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.ProductNameImpl;
import com.monsanto.wst.dao.GenericDAO;
import org.hibernate.Criteria;
import org.hibernate.criterion.*;

import java.util.*;

/**
 * Filename:    $RCSfile: ProductServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-04-13 19:24:44 $
 *
 * @author rrmall
 * @version $Revision: 1.15 $
 */
public class ProductServiceImpl implements ProductService {
  private final GenericDAO<Product, Long> productDAO;
  private static final String NO_TRACK_VERSION_STRING = "NO-TRACK";
  private static final String INACTIVE_STATUS = "INACTIVE";

  public ProductServiceImpl(GenericDAO<Product, Long> productDAO) {
    this.productDAO = productDAO;
  }

  public ProductSearchResults lookupProductMatchingInputCriteria(String productNamesEntered, boolean isHybrid){
    ProductSearchResults results = new ProductSearchResults(productNamesEntered);
    String[] products = productNamesEntered.split("\\s+");
    for (String product: products){
       DetachedCriteria subQuery = DetachedCriteria.forClass(ProductNameImpl.class);
        subQuery.add(Restrictions.like("name", replaceWildCardBySqlWildCard(product)).ignoreCase())
            .setProjection(Property.forName("product.id"));

      Criteria criteria = productDAO.createCriteria().add(Subqueries.propertyIn("id", subQuery)).
          add(Expression.eq("isHybrid", isHybrid));

      @SuppressWarnings("unchecked")
      Collection<Product> productList = (Collection<Product>) criteria.list();
      if (productList.isEmpty()) {
        results.fail(product);
      } else {
        results.addAll(productList);
      }
    }
    return results;
   }

    public Collection<Product> getUniqueBaseProducts(Collection<Product> products) {
        Set<Product> uniqueBases = new HashSet<Product>();
        for (Product product : products) {
            uniqueBases.add(product.getBase());
        }
        return new ArrayList<Product>(uniqueBases);
    }

    @SuppressWarnings({"TypeMayBeWeakened"})
    private String replaceWildCardBySqlWildCard(String inputCriteria) {
    if (StringUtils.isMatchedByRegExp(inputCriteria, "\\*", false)){
      return StringUtils.replace(inputCriteria, "*", "%");
    }
      return inputCriteria;
    }

  public Product lookupProductById(Long id) {
    return productDAO.findByPrimaryKey(id);
  }

  private final Map<String, Collection<Product>> productByBaseAndTraitCache = new HashMap<String, Collection<Product>>();

  public Collection<Product> getProductByBaseAndTrait(Product product, Trait trait) {
    String key = calculateProductKey(product) + ":" + calculateTraitKey(trait);
    Collection<Product> products = productByBaseAndTraitCache.get(key);
    if (products == null) {
      products = baseGetProductByBaseAndTrait(product, trait);
      productByBaseAndTraitCache.put(key, products);
    }

    return products;
  }

  private static long calculateTraitKey(Trait trait) {
    return ((trait == null) ? 0 : trait.getId());
  }

  private static long calculateProductKey(Product product) {
    return ((product == null) ? 0 : product.getId());
  }

  @SuppressWarnings({"TypeMayBeWeakened"})
  private Collection<Product> baseGetProductByBaseAndTrait(Product product, Trait trait) {
    Criteria criteria = productDAO.createCriteria().add(Restrictions.eq("base", product.getBase()))
        .add(Restrictions.eq("trait", trait))
        .add(Expression.or((Expression.or(Expression.like("status", "Primary"),Expression.like("status", "Primary1"))),
            (Expression.or(Expression.like("status","Active%"), Expression.like("status","UNKNOWN"))))).addOrder(Order.asc("trait"));
    return filterOutInactiveNoTrackProducts(criteria.list());
  }

  private Collection<Product> filterOutInactiveNoTrackProducts(Collection<Product> products) {
    Collection<Product> filteredProducts = new ArrayList<Product>(products.size());
    for (Product product : products) {
      boolean shouldIIncludeThis = !isInactiveNoTrack(product); //todo temp debug variable
      if (shouldIIncludeThis) {
        filteredProducts.add(product);
      }
    }
    return filteredProducts;
  }

  private boolean isInactiveNoTrack(Product product) {
    boolean isNoTrack = NO_TRACK_VERSION_STRING.equalsIgnoreCase(product.getTraitVersion());
    boolean isInactive = INACTIVE_STATUS.equalsIgnoreCase(product.getStatus());
    return isNoTrack && isInactive;
  }
}