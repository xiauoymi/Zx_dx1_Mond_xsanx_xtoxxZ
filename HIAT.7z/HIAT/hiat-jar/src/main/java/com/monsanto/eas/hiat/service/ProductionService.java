package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;

import java.util.Collection;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface ProductionService {
  Collection<ProductionEntry> findByProduct(Product product, InventoryType invType);
}
