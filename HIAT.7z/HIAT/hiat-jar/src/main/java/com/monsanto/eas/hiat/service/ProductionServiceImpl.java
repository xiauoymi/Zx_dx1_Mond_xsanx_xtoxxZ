package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.dao.ProductionDAO;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ProductionServiceImpl implements ProductionService {
  private final ProductionDAO dao;

  public ProductionServiceImpl(ProductionDAO dao) {
    this.dao = dao;
  }

  public Collection<ProductionEntry> findByProduct(Product product, InventoryType invType) {
    Collection<ProductionEntry> entries = new ArrayList<ProductionEntry>();
    for (ProductionEntry entry : dao.findByProduct(product)) {
      if (entry.getType() == invType) {
        entries.add(entry);
      }
    }

    return entries;
  }
}
