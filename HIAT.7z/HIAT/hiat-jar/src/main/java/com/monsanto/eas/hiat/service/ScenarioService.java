/*
 SavedScenarioService was created on Feb 24, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.scenario.Scenario;

import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: ScenarioService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-03-31 17:03:08 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public interface ScenarioService {

  Scenario saveOrUpdatedScenario(String userId, String scenarioName, String scenarioDesc,
                               String productNames, Collection<? extends Trait> traits, Collection<? extends HybridAnalysis> hyrbridAnalysisList, boolean updateScenario);

  List<Scenario> lookupSavedScenariosByCriteria(String userId, String name, Date saveDateFrom, Date saveDateTo,
                                                String[] sortKeys, String sortDir);

  List<String> lookupUserIdsWithSavedScenarios();

  void deleteScenariosById(String[] scenarioIds);

  Scenario lookupScenarioByName(String name);

  Scenario lookupSavedScenariosById(Long scenarioId);


}