/*
 SavedScenarioServiceImpl was created on Feb 24, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.scenario.ScenarioDetail;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioDetailImpl;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioImpl;
import com.monsanto.wst.dao.GenericDAO;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import java.util.*;
import java.text.SimpleDateFormat;

/**
 * Filename:    $RCSfile: ScenarioServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $ On:	$Date:
 * 2009/03/09 14:29:22 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class ScenarioServiceImpl implements ScenarioService {
  private final GenericDAO<Scenario, Long> scenarioDao;

  public ScenarioServiceImpl(GenericDAO<Scenario, Long> scenarioDao) {
    this.scenarioDao = scenarioDao;
  }

  public Scenario lookupSavedScenariosById(Long scenarioId) {
    return this.scenarioDao.findByPrimaryKey(scenarioId);
  }

  public List<Scenario> lookupSavedScenariosByCriteria(String userId, String name, Date saveDateFrom, Date saveDateTo,
                                                       String[] sortKeys, String sortDir) {
    Criteria criteria = this.scenarioDao.createCriteria();
    addEqCriteria("username", userId, criteria);
    addLikeCriteria("name", name, criteria);
    addBetweenDateCriteria("saveDate", saveDateFrom, saveDateTo, criteria);
    addCriteriaForSort(sortKeys, sortDir, criteria);
    return removeDeletedItemsFromList(criteria.list());
  }

    private List<Scenario> removeDeletedItemsFromList(Iterable<Scenario> scenarios) {
        List<Scenario> scrubbedScenarios = new ArrayList<Scenario>();
        for (Scenario scenario : scenarios) {
            if (!scenario.isDeleted()) {
                scrubbedScenarios.add(scenario);
            }
        }
        return scrubbedScenarios;
    }

    public List<String> lookupUserIdsWithSavedScenarios() {
    List<String> userIds = new ArrayList<String>();
    List<Scenario> scenarios = scenarioDao.findAll("username", true);
    for (Scenario scenario : scenarios) {
      if (!userIds.contains(scenario.getUsername())) {
        userIds.add(scenario.getUsername());
      }
    }
    return userIds;
  }

  public void deleteScenariosById(String[] scenarioIds) {
    for (String id : scenarioIds) {
      Scenario scenario = scenarioDao.findByPrimaryKey(new Long(id));
      scenario.setDeleted(true);
      scenarioDao.save(scenario);
    }
  }

  public Scenario lookupScenarioByName(String name) {
    Criteria criteria = this.scenarioDao.createCriteria();
    if (StringUtils.isBlank(name)) {
      return null;
    } else {
      criteria.add(Restrictions.eq("name", name).ignoreCase());
      return (Scenario) criteria.uniqueResult();
    }
  }

  public Scenario saveOrUpdatedScenario(String userId, String scenarioName, String scenarioDesc, String productNames,
                                    Collection<? extends Trait> traits, Collection<? extends HybridAnalysis> hyrbridAnalysisList,
                                    boolean updateScenario) {
    if(updateScenario){
      return replaceScenario(userId, scenarioName, scenarioDesc, productNames, traits, hyrbridAnalysisList);
    }else{
      return saveScenario(userId, scenarioName, scenarioDesc, productNames, traits, hyrbridAnalysisList);
    }
  }

  private Scenario saveScenario(String userId, String scenarioName, String scenarioDesc,
                               String productNames, Collection<? extends Trait> traits, Iterable<? extends HybridAnalysis> hyrbridAnalysisList) {
    Scenario scenario = new ScenarioImpl(null, userId, scenarioName, scenarioDesc, new Date(), false, productNames,
        new HashSet<Trait>(traits), null);
    Set<ScenarioDetail> details = new HashSet<ScenarioDetail>();
    for (HybridAnalysis analysis : hyrbridAnalysisList) {
      ScenarioDetail scenarioDetail = new ScenarioDetailImpl(scenario, analysis);
      details.add(scenarioDetail);
    }
    scenario.setDetails(details);
    return this.scenarioDao.save(scenario);
  }

  private Scenario replaceScenario(String userId, String scenarioName, String scenarioDesc, String productNames,
                                  Collection<? extends Trait> traits, Iterable<? extends HybridAnalysis> hyrbridAnalysisList) {
    Scenario scenario = lookupScenarioByName(scenarioName);
    deleteScenariosById(new String[]{scenario.getId().toString()});
    return saveScenario(userId, scenarioName, scenarioDesc, productNames, traits, hyrbridAnalysisList);
  }


  private void addCriteriaForSort(String[] sortKeys, String sortDir, Criteria criteria) {
      if (sortDir == null || "asc".equalsIgnoreCase(sortDir)) {
        addSortAscending(sortKeys, criteria);
      } else {
        addSortDescending(sortKeys, criteria);
      }
  }

  private void addSortDescending(String[] sortKeys, Criteria criteria) {
    for (String sortKey : sortKeys) {
      criteria.addOrder(Order.desc(sortKey));
    }
  }

  private void addSortAscending(String[] sortKeys, Criteria criteria) {
    for (String sortKey : sortKeys) {
      criteria.addOrder(Order.asc(sortKey));
    }
  }

  private void addEqCriteria(String propertyName, String valueToMatch, Criteria criteria) {
    if (StringUtils.isNotBlank(valueToMatch)) {
      criteria.add(Restrictions.eq(propertyName, valueToMatch).ignoreCase());
    }
  }

  private void addLikeCriteria(String propertyName, String valueToMatch, Criteria criteria) {
    if (StringUtils.isNotBlank(valueToMatch)) {
      criteria.add(Restrictions.ilike(propertyName, "%" + valueToMatch + "%"));
    }
  }

  @SuppressWarnings({"TypeMayBeWeakened"})
  private void addBetweenDateCriteria(String propertyName, Date fromValue, Date toValue, Criteria criteria) {
    if (fromValue != null || toValue != null) {
      Date fromValueToUse = dateOrAlternateIfNull(fromValue, toValue);
      Date toValueToUse = dateOrAlternateIfNull(toValue, fromValue);
      criteria.add(Expression.ge(propertyName, fromValueToUse));
      criteria.add(Expression.lt(propertyName, startOfNextDay(toValueToUse)));
    }
  }

  private Date dateOrAlternateIfNull(Date desiredDate, Date defaultIfNull) {
    if (desiredDate == null) {
      return defaultIfNull;
    } else {
      return desiredDate;
    }
  }

  public static Date startOfNextDay(Date originalDate) { //todo move to a date util class
    if (originalDate == null) {
      return null;
    }

    Calendar cal = Calendar.getInstance();
    cal.setTime(originalDate);
    cal.set(Calendar.HOUR_OF_DAY, 0);
    cal.set(Calendar.MINUTE, 0);
    cal.set(Calendar.SECOND, 0);
    cal.add(Calendar.DATE, 1);
    return cal.getTime();
  }
}