package com.monsanto.eas.hiat.service;

import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.analysis.HybridAnalyzer;
import com.monsanto.eas.hiat.analysis.InbredStatusAnalyzer;
import com.monsanto.eas.hiat.dao.TraitDAO;
import com.monsanto.eas.hiat.model.InventoryEntry;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductName;
import com.monsanto.eas.hiat.model.ProductionEntry;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.view.HybridAnalysisXMLGenerator;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

@SuppressWarnings({"unchecked"})
public class TestInitService {
  //todo move to test hierarcy
  private static final String HIAT_BEAN_XML = "testhiat.xml";
  private static final BeanFactory beanFactoryInstance = new XmlBeanFactory(new ClassPathResource(HIAT_BEAN_XML));

  private Object getBean(String beanId) {
    return beanFactoryInstance.getBean(beanId);
  }

  public HibernateFactory getHibernate() {
    return (HibernateFactory) getBean("hibernate");
  }

  public GenericDAO<Product, Long> initProductDAO() {
    return (GenericDAO<Product, Long>) getBean("productDAO");
  }

  public GenericDAO<InventoryEntry, Long> initInventoryEntryDAO() {
    return (GenericDAO<InventoryEntry, Long>) getBean("inventoryDAOBase");
  }

  public GenericDAO<ProductName, Long> initProductNameDAO() {
    return (GenericDAO<ProductName, Long>) getBean("productNameDAO");
  }

  public GenericDAO<ProductionEntry, Long> initProductionEntryDAO() {
    return (GenericDAO<ProductionEntry, Long>) getBean("productionDAOBase");
  }

  public GenericDAO<HybridAnalysis, Long> initHybridAnalysisDAO() {
    return (GenericDAO<HybridAnalysis, Long>) getBean("hybridAnalysisDAO");
  }

  public TraitDAO initTraitDAO() {
    return (TraitDAO) getBean("traitDAO");
  }

  public UseCaseController getController(String controllerBeanId) {
    return (UseCaseController) getBean(controllerBeanId);
  }

  public GenericDAO<Scenario, Long> initScenarioDAO() {
    return (GenericDAO<Scenario, Long>) getBean("scenarioDAO");
  }

  public ProductService initProductService() {
    return (ProductService) getBean("productService");
  }

  public TraitService initTraitService() {
    return (TraitService) getBean("traitService");
  }

  public InbredStatusAnalyzer initInbredAnalyzer() {
    return (InbredStatusAnalyzer) getBean("inbredAnalyzer");
  }

  public HybridAnalyzer initHybridAnalyzer() {
    return (HybridAnalyzer) getBean("hybridAnalyzer");
  }

  public HybridAnalysisXMLGenerator initHybridXMLGenerator() {
    return (HybridAnalysisXMLGenerator) getBean("hybridXMLGenerator");
  }

  public ScenarioService initScenarioService() {
    return (ScenarioService) getBean("scenarioService");
  }

  public LoadService initLoadService() {
    return (LoadService) getBean("loadService");
  }
}
