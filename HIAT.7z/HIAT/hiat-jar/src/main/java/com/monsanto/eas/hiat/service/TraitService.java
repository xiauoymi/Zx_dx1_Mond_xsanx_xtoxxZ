package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.model.Trait;

import java.util.List;

/**
 * Created by vvvelu Date: Feb 10, 2009 Time: 9:31:42 AM
 */
public interface TraitService {

  List<Trait> lookupAllTraits();

  List<Trait> lookupSelectedTraits(String[] traits);

  Trait lookupTraitById(Long id);

  void configureTrait(Trait trait);

  List<Trait> lookupAllActive();

  List<Trait> lookupAllInActive();

  List<Trait> calculateTraits(String[] traits);
}
