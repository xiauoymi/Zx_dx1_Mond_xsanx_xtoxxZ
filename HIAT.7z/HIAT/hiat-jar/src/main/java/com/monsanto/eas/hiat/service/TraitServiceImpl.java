/*
 TraitServiceImpl was created on Mar 3, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.dao.TraitDAO;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.CommercialNameTraitComparator;
import com.monsanto.eas.hiat.trait.TraitTree;
import com.monsanto.eas.hiat.analysis.TraitComparator;

import java.util.*;

/**
 * Filename:    $RCSfile: TraitServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-04-13 19:24:44 $
 *
 * @author rrmall
 * @version $Revision: 1.11 $
 */
public class TraitServiceImpl implements TraitService {
  private final TraitDAO traitDAO;
  private final Calculator<Trait, List<TraitTree>> traitCalc;

  public TraitServiceImpl(TraitDAO traitDAO, Calculator<Trait, List<TraitTree>> traitCalc) {
    this.traitDAO = traitDAO;
    this.traitCalc = traitCalc;
  }

  public List<Trait> lookupAllTraits() {
    return traitDAO.findAll("code", true);
  }

  public Trait lookupTraitById(Long id) {
    return traitDAO.findByPrimaryKey(id);
  }

  public List<Trait> lookupSelectedTraits(String[] traits) {
    List<Trait> selectedTraits = new ArrayList<Trait>();
    for (String traitId : traits) {
      Trait trait = traitDAO.findByPrimaryKey(Long.valueOf(traitId));
      selectedTraits.add(trait);
    }
    return selectedTraits;
  }

  public void configureTrait(Trait trait) {
    traitDAO.save(trait);

  }

  public List<Trait> lookupAllActive() {
    List<Trait> activeTraits = new ArrayList<Trait>();
    for (Trait trait : lookupAllTraits()) {
      if (trait.getActive()) {
        activeTraits.add(trait);
      }
    }
    return activeTraits;
  }

  public List<Trait> lookupAllInActive() {
    List<Trait> inActiveTraits = new ArrayList<Trait>();
    for (Trait trait : lookupAllTraits()) {
      if (!trait.getActive()) {
        inActiveTraits.add(trait);
      }
    }
    return inActiveTraits;
  }

  public List<Trait> calculateTraits(String[] splitTraits) {
    Set<Trait> traitCombinations = new HashSet<Trait>();
    for (Trait trait : lookupSelectedTraits(splitTraits)) {
      List<TraitTree> possibleParentTraits = traitCalc.calculate(trait);
      traitCombinations.addAll(gatherCalculatedTraits(possibleParentTraits));
    }
    return sortCalculatedTraits(traitCombinations);
  }

  private Collection<Trait> gatherCalculatedTraits(List<TraitTree> possibleParentTraits) {
    Collection<Trait> possibleTraitCombinations = new HashSet<Trait>();
    // note: this might be redundant now, but given their future plans to limit certain traits to male or female only, its probably prudent to leave adding both sides
    for (TraitTree traitTree : possibleParentTraits) {
      possibleTraitCombinations.add(traitTree.getFemaleParent());
      possibleTraitCombinations.add(traitTree.getMaleParent());
    }

    return possibleTraitCombinations;
  }

  private List<Trait> sortCalculatedTraits(Collection<Trait> traitCombinations) {
    List<Trait> sortedTraitCombinations = new ArrayList<Trait>(traitCombinations);
    Collections.sort(sortedTraitCombinations, new CommercialNameTraitComparator());
    return sortedTraitCombinations;
  }


}