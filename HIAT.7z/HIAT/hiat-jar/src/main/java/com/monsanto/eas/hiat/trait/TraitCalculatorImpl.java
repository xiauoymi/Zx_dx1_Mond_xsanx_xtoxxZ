package com.monsanto.eas.hiat.trait;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.dao.TraitDAO;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.util.SetCalculator;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class TraitCalculatorImpl implements Calculator<Trait, List<TraitTree>> {
  private final List<Trait> allTraits;
  private final Trait conventional;

  public TraitCalculatorImpl(TraitDAO traitDAO) {
    allTraits = traitDAO.findAll();
    conventional = traitDAO.getConventional();
  }

  public List<TraitTree> calculate(Trait trait) {
    Collection<Trait> parentTraits = getParentTraitsOrSelf(trait);
    Collection<Set<Trait>> possibleTraitSets = SetCalculator.calculatePowerSet(parentTraits);
    List<TraitTree> pairs = new ArrayList<TraitTree>();
    for (Set<Trait> traitsForPair : possibleTraitSets) {
      TraitTree tree = getTreeForTraits(parentTraits, traitsForPair);
      if (tree != null) {
        pairs.add(tree);
      }
    }

    return pairs;
  }

  private Collection<Trait> getParentTraitsOrSelf(Trait trait) {
    Collection<Trait> parentTraits = trait.getParentTraits();
    if (parentTraits.isEmpty()) {
      parentTraits = new HashSet<Trait>(1);
      parentTraits.add(trait);
    }
    return parentTraits;
  }

  private TraitTree getTreeForTraits(Collection<Trait> allParentTraits, Collection<Trait> parentsTraits) {
    Set<Trait> otherParentsTraits = SetCalculator.minus(allParentTraits, parentsTraits);
    Trait parentFemale = getTraitForParents(parentsTraits);
    Trait parentMale = getTraitForParents(otherParentsTraits);
    if (parentMale != null && parentFemale != null) {
      return new TraitTree(parentFemale, parentMale);
    } else {
      return null;
    }
  }

  private Trait getTraitForParents(Collection<Trait> parentsTraits) {
    if (parentsTraits.isEmpty()) {
      return conventional; // conventional has no parents
    } else if (parentsTraits.size() == 1) {
      return parentsTraits.iterator().next(); // singleton traits are their own parent
    } else {
      return getCompositeTraitBasedOnParents(parentsTraits);
    }
  }

  private Trait getCompositeTraitBasedOnParents(Collection<Trait> parentsTraits) {
    for (Trait trait : allTraits) {
      if (trait.getParentTraits().equals(parentsTraits)) {
        return trait;
      }
    }

    return null;
  }
}