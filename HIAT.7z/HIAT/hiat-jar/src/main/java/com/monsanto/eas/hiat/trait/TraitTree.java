package com.monsanto.eas.hiat.trait;

import com.monsanto.eas.hiat.model.Trait;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class TraitTree {
  private final Trait femaleParent;
  private final Trait maleParent;

  public TraitTree(Trait femaleParent, Trait maleParent) {
    this.femaleParent = femaleParent;
    this.maleParent = maleParent;
  }

  public Trait getFemaleParent() {
    return femaleParent;
  }

  public Trait getMaleParent() {
    return maleParent;
  }


  @Override
  public boolean equals(Object o) {
    if (o == null || getClass() != o.getClass()) return false;
    if (this == o) return true;

    TraitTree traitPair = (TraitTree) o;

    return new EqualsBuilder()
            .append(femaleParent, traitPair.femaleParent)
            .append(maleParent, traitPair.maleParent)
            .isEquals();
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder()
            .append(femaleParent)
            .append(maleParent)
            .toHashCode();
  }

  @Override
  public String toString() {
    return "(" + femaleParent + "+" + maleParent + ")";
  }
}
