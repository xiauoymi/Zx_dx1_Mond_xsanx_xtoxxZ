package com.monsanto.eas.hiat.util;

import java.util.Collection;
import java.util.LinkedList;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class CollectionUtil {
    /**
     * Search a collection for an instance equal to specified instance.  This only makes sense if equal has been
     * overridden, and two items may evaluate as equal, but you still need a specific instance from a collection
     * for some reason.
     * @param coll collection to search in
     * @param targetInstance is the source instance we want to find the corresponding copy of
     * @param <T> Type of target instance
     * @return a corresponding instance from coll that is equal to targetInstance, or null if none
     */
    @SuppressWarnings({"TypeMayBeWeakened"})
    public static <T> T findMatchingInstance(Iterable<? extends T> coll, T targetInstance) {
        for (T canidateInstance : coll) {
            if (canidateInstance.equals(targetInstance)) {
                return canidateInstance;
            }
        }

        return null;
    }

  /**
   * Returns the passed item back inside a collection where the item is the one and only member
   * @param item to be wrapped in a collection
   * @param <T> Type of the item -- the returned collection will be a collection of this type
   * @return a collection containing item, and only that item
   */
  public static <T> Collection<T> singleItemAsCollection(T item) {
    Collection<T> col = new LinkedList<T>();
    col.add(item);
    return col;
  }
}
