/*
 NumberFormatUtil was created on Apr 27, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.util;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class NumberFormatUtil {

  public static String format(long number) {
    return NumberFormat.getInstance(Locale.US).format(number);
  }
}