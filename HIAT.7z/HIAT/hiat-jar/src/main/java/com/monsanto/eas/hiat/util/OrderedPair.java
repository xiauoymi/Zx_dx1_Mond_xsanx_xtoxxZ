package com.monsanto.eas.hiat.util;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class OrderedPair<T, U> {
  private final T left;
  private final U right;

  public OrderedPair(T left, U right) {
    this.left = left;
    this.right = right;
  }

  public T getLeft() {
    return left;
  }

  public U getRight() {
    return right;
  }
}
