package com.monsanto.eas.hiat.util;

import java.util.Comparator;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ReverseComparator<T> implements Comparator<T> {
    private final Comparator<T> baseComparator;

    public ReverseComparator(Comparator<T> baseComparator) {
        this.baseComparator = baseComparator;
    }

    public int compare(T o1, T o2) {
        return baseComparator.compare(o2, o1);
    }
}
