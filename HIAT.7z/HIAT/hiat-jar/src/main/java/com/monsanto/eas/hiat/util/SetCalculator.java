package com.monsanto.eas.hiat.util;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class SetCalculator {
    public static <T> Set<T> minus(Collection<T> orig, Collection<T> subtract) {
        Set<T> resultTraits = new HashSet<T>(orig);
        resultTraits.removeAll(subtract);
        return resultTraits;
    }

    public static <T, U> Collection<OrderedPair<T, U>> calculateCartesianProduct(Iterable<T> collection1, Iterable<U> collection2) {
      Collection<OrderedPair<T, U>> cartesianProduct = new ArrayList<OrderedPair<T,U>>();
      for (T item1 : collection1) {
        for (U item2 : collection2) {
          cartesianProduct.add(new OrderedPair<T, U>(item1, item2));
        }
      }

      return cartesianProduct;
    }

  public static <T> Collection<Set<T>> calculatePowerSet(Collection<T> originalSet) {
        List<T> listOfMembers = new ArrayList<T>(originalSet);
        boolean[] includedMembers = new boolean[listOfMembers.size()];

        Collection<Set<T>> setList = new ArrayList<Set<T>>();
        boolean continueProcessing = init(includedMembers);
        while (continueProcessing) {
            setList.add(getSet(listOfMembers, includedMembers));
            continueProcessing = increment(includedMembers);
        }

        return setList;
    }

    private static <T> Set<T> getSet(List<T> memberList, boolean[] includedMembers) {
        Set<T> calculatedSet = new HashSet<T>();
        for (int i = 0; i < memberList.size(); i++) {
            if (includedMembers[i]) {
                calculatedSet.add(memberList.get(i));
            }
        }

        return calculatedSet;
    }

    private static boolean init(boolean[] binaryArray) {
        for (int i = 0; i < binaryArray.length; i++) {
            binaryArray[i] = false;
        }

        return binaryArray.length != 0;
    }

    private static boolean increment(boolean[] binaryArray) {
        for (int i = 0; i < binaryArray.length; i++) {
            if (!binaryArray[i]) {
                binaryArray[i] = true;
                return true;
            } else {
                binaryArray[i] = false;
            }
        }

        return false;
    }
}
