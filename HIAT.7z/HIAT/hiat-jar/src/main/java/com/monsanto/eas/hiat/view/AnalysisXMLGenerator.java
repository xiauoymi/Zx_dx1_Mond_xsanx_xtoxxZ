package com.monsanto.eas.hiat.view;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.hiat.availability.AvailabilityDate;
import org.apache.commons.lang.time.DateFormatUtils;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class AnalysisXMLGenerator { //todo not much here yet - need to refactor HybridAnalysisXMLGenerator and InbredStatusXMLGenerator
  protected static final String PRODUCT = "PRODUCT";
  protected static final String PRODUCT_INFO = "PRODUCT_INFO";
  protected static final String HYBRID_MFG_NAME = "HYBRID_MFG_NAME";
  protected static final String TRAIT_CODE = "TRAIT_CODE";
  protected static final String MFG_INBRED_FEMALE = "MFG_INBRED_FEMALE";
  protected static final String BASE_INBRED_FEMALE = "BASE_INBRED_FEMALE";
  protected static final String PRE_COMMERCIAL_INBRED = "PRECOMMERCIAL_INBRED";
  protected static final String PLUS1 = "PLUS1";
  protected static final String MFG_INBRED_MALE = "MFG_INBRED_MALE";
  protected static final String BASE_INBRED_MALE = "BASE_INBRED_MALE";
  protected static final String PCM_HYBRID_150_DATE = "PCM_HYBRID_150_DATE";
  protected static final String PCM_HYBRID_300_DATE = "PCM_HYBRID_300_DATE";
  protected static final String COM_HYBRID_DATE = "COM_HYBRID_DATE";
  protected static final String TRAIT_CODE_FEMALE = "TRAIT_CODE_FEMALE";
  protected static final String COMMERCIAL_TRAIT_FEMALE = "COMMERCIAL_TRAIT_FEMALE";
  protected static final String INBRED_FEMALE_TRAIT = "INBRED_FEMALE_TRAIT";
  protected static final String FEMALE_GEN_0_DATE = "FEMALE_GEN_0_DATE";
  protected static final String FEMALE_GEN_1_DATE = "FEMALE_GEN_1_DATE";
  protected static final String FEMALE_GEN_2_DATE = "FEMALE_GEN_2_DATE";
  protected static final String PLUS2 = "PLUS2";
  protected static final String TRAIT_CODE_MALE = "TRAIT_CODE_MALE";
  protected static final String COMMERCIAL_TRAIT_MALE = "COMMERCIAL_TRAIT_MALE";
  protected static final String INBRED_MALE_TRAIT = "INBRED_MALE_TRAIT";
  protected static final String MALE_GEN_0_DATE = "MALE_GEN_0_DATE";
  protected static final String MALE_GEN_1_DATE = "MALE_GEN_1_DATE";
  protected static final String MALE_GEN_2_DATE = "MALE_GEN_2_DATE";
  protected static final String ANALYSIS = "ANALYSIS";
  public static final String DATE_FORMAT = "MM-dd-yy";
  protected static final String MISSING_PRODUCTS_LIST_ELEMENT = "MISSING_PRODUCTS";
  protected static final String MISSING_PRODUCT_ELEMENT = "MISSING_PRODUCT";

  protected void buildMissingProducts(Iterable<String> missingProductList, Node analysis) {
    Element missingListElement = DOMUtil.addChildElement(analysis, MISSING_PRODUCTS_LIST_ELEMENT);
    for (String missingProduct : missingProductList) {
      DOMUtil.addChildElement(missingListElement, MISSING_PRODUCT_ELEMENT, missingProduct);
    }
  }

  protected String getAvailabilityDateAsString(AvailabilityDate dt) {
    return dt == null ? "" : getFormattedDate(dt.getExactDate());
  }

  protected String getFormattedDate(Date date) {
    return (date == null) ? "" : DateFormatUtils.format(date, DATE_FORMAT);
  }
}
