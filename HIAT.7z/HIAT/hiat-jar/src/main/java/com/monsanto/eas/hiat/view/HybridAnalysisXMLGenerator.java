package com.monsanto.eas.hiat.view;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.analysis.HybridAnalysisDetail;
import com.monsanto.eas.hiat.analysis.HybridAnalysisParentDetail;
import com.monsanto.eas.hiat.controller.HybridDetailSelectionCriteria;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.TraitService;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by vvvelu Date: Mar 2, 2009 Time: 10:39:39 AM
 */
public class HybridAnalysisXMLGenerator extends AnalysisXMLGenerator {
  //todo refactor - probably has lot of common code with inbred generator
  private final ProductService productService;
  private final TraitService traitService;
  private static final String SELECT_TO_SAVE = "SELECT_TO_SAVE";
  private static final String SCENARIO_CREATION_DATE = "SCENARIO_CREATION_DATE";
  private static final String SCENARIO_NAME = "SCENARIO_NAME";
  private static final String SCENARIO_DESCRIPTION = "SCENARIO_DESCRIPTION";
  private static final String TARGET_COMM_TRAIT = "TARGET_TRAIT_COMMERCIAL";
  public static final String SELECTED_ANALYSIS_DETAILS_CHKBX = "selectedAnalysisDetailsChkBx";

  public HybridAnalysisXMLGenerator(ProductService productService, TraitService traitService) {
    this.productService = productService;
    this.traitService = traitService;
  }

  public Document getXmlContent(Collection<HybridAnalysis> analysisList, Scenario scenario, String url,
                                boolean isSavedScenario, UCCHelper helper, Collection<String> missingProductList) throws IOException {
    Document document = DOMUtil.newDocument();
    Element analysis = DOMUtil.addChildElement(document, ANALYSIS);
    if (!StringUtils.isNullOrEmpty(url)) {
      buildScenarioLink(scenario, url, analysis);
    }
    buildScenarioDetails(analysis, scenario, isSavedScenario);
    buildHybridAnalysis(getListOfHybridAnalysisToSave(helper, analysisList), analysis);
    buildMissingProducts(missingProductList, analysis);
    return document;
  }

  private void buildScenarioLink(Scenario scenario, String url, Node analysis) {
    StringBuffer sb = new StringBuffer();
    sb.append("<a href=\"").
            append(url).
            append("/servlet/scenario?method=lookupScenario&scenarioId=").
            append(String.valueOf(scenario.getId())).
            append("\"").
            append(">").
            append("Click here to view the scenario").
            append("</a>");
    DOMUtil.addChildElement(analysis, "LINK", sb.toString());
  }

  private void buildScenarioDetails(Node analysis, Scenario scenario, boolean isSavedScenario) {
    if (isSavedScenario) {
      buildNonEmptyScenarioElements(analysis, scenario);
    } else {
      buildEmptyScenarioElements(analysis);
    }
  }

  private void buildEmptyScenarioElements(Node analysis) {

    DOMUtil.addChildElement(analysis, SCENARIO_CREATION_DATE, "");
    DOMUtil.addChildElement(analysis, SCENARIO_NAME, "");
    DOMUtil.addChildElement(analysis, SCENARIO_DESCRIPTION, "");
  }

  private void buildNonEmptyScenarioElements(Node analysis, Scenario scenario) {
    DOMUtil.addChildElement(analysis, SCENARIO_CREATION_DATE, getFormattedDate(scenario.getSaveDate()));
    DOMUtil.addChildElement(analysis, SCENARIO_NAME, scenario.getName());
    DOMUtil.addChildElement(analysis, SCENARIO_DESCRIPTION, scenario.getDescription());
  }


  private void buildHybridAnalysis(Iterable<HybridAnalysis> analysisList, Node analysis) {
    for (HybridAnalysis hybridAnalysis : analysisList) {
      if (hybridAnalysis != null) {
        Element productElement = DOMUtil.addChildElement(analysis, PRODUCT);
        Product product = hybridAnalysis.getProduct();
        Collection<HybridAnalysisDetail> hybridAnalysisDetailsSet = hybridAnalysis.getDetail();
        buildTraitCombinations(productElement, product, hybridAnalysisDetailsSet, hybridAnalysis);
      }
    }
  }

  private void buildTraitCombinations(Node productElement, Product product, Iterable<HybridAnalysisDetail> hybridAnalysisDetailsSet, HybridAnalysis hybridAnalysis) {
    for (HybridAnalysisDetail hybridAnalysisDetail : hybridAnalysisDetailsSet) {
      Element productInfo = DOMUtil.addChildElement(productElement, PRODUCT_INFO);
      DOMUtil.addChildElement(productInfo, HYBRID_MFG_NAME, product.getProductNames().get(ProductNameType.BASE_MANUFACTURING).getName());
      //NOTE: It is noticed that Trait Code to be displayed is not the product's trait code but the trait code of the user selected traited code.
      //Therefore it is changed to selected trait code to be in consistent with front-end display
      DOMUtil.addChildElement(productInfo, TRAIT_CODE, hybridAnalysis.getTrait().getCode());
      DOMUtil.addChildElement(productInfo, TARGET_COMM_TRAIT, hybridAnalysis.getTrait().getCommercialName());
      DOMUtil.addChildElement(productInfo, MFG_INBRED_FEMALE, product.getFemaleParent().getBase().getProductName(ProductNameType.BASE_MANUFACTURING));
      DOMUtil.addChildElement(productInfo, BASE_INBRED_FEMALE, product.getFemaleParent().getBase().getProductName(ProductNameType.BASE_PRECOMMERCIAL));
      DOMUtil.addChildElement(productInfo, PLUS1, "+");
      DOMUtil.addChildElement(productInfo, MFG_INBRED_MALE, product.getMaleParent().getBase().getProductName(ProductNameType.BASE_MANUFACTURING));
      DOMUtil.addChildElement(productInfo, BASE_INBRED_MALE, product.getMaleParent().getBase().getProductName(ProductNameType.BASE_PRECOMMERCIAL));

      DOMUtil.addChildElement(productInfo, PCM_HYBRID_150_DATE, hybridAnalysisDetail.getPcm150Season().toString());
      DOMUtil.addChildElement(productInfo, PCM_HYBRID_300_DATE, hybridAnalysisDetail.getPcm300Season().toString());
      DOMUtil.addChildElement(productInfo, COM_HYBRID_DATE, hybridAnalysisDetail.getCommercialSeason().toString());
      DOMUtil.addChildElement(productInfo, SELECT_TO_SAVE, isSelected(hybridAnalysisDetail.getIsSelected()));

      buildParentInfo(productInfo, hybridAnalysisDetail.getFemaleParent(),
              TRAIT_CODE_FEMALE, COMMERCIAL_TRAIT_FEMALE, INBRED_FEMALE_TRAIT,
              FEMALE_GEN_0_DATE, FEMALE_GEN_1_DATE, FEMALE_GEN_2_DATE);

      DOMUtil.addChildElement(productInfo, PLUS2, "+");

      buildParentInfo(productInfo, hybridAnalysisDetail.getMaleParent(),
              TRAIT_CODE_MALE, COMMERCIAL_TRAIT_MALE, INBRED_MALE_TRAIT,
              MALE_GEN_0_DATE, MALE_GEN_1_DATE, MALE_GEN_2_DATE);
    }
  }

  private void buildParentInfo(Element productInfo, HybridAnalysisParentDetail parent,
                               String traitCodeTag, String commTraitTag, String inbredTraitTag,
                               String gen0DateTag, String gen1DateTag, String gen2DateTag) {
    //todo refactor so XML uses a nested structure (female/trait instead of female_trait) so these parameters become unnecessary
    DOMUtil.addChildElement(productInfo, traitCodeTag, parent.getTrait().getCode());
    DOMUtil.addChildElement(productInfo, commTraitTag, parent.getTrait().getCommercialName());
    DOMUtil.addChildElement(productInfo, inbredTraitTag, parent.getTrait().getFullName());
    DOMUtil.addChildElement(productInfo, gen0DateTag, getAvailabilityDateAsString(parent.getGeneration0Date()));
    DOMUtil.addChildElement(productInfo, gen1DateTag, getAvailabilityDateAsString(parent.getGeneration1Date()));
    DOMUtil.addChildElement(productInfo, gen2DateTag, getAvailabilityDateAsString(parent.getGeneration2Date()));
  }


  private String isSelected(boolean isSelected) {
    return isSelected ? "Yes" : "No";
  }


  private Iterable<HybridAnalysis> getListOfHybridAnalysisToSave(UCCHelper helper, Collection<HybridAnalysis> analysisListToSave) throws IOException {
    Collection<HybridDetailSelectionCriteria> selectedDetails = getSelectedDetails(helper);

    for (HybridAnalysis analysis : analysisListToSave) {
      if (analysis != null) {
        addDetails(selectedDetails, analysis);
      }
    }

    return analysisListToSave;
  }

  private void addDetails(Collection<HybridDetailSelectionCriteria> selectedDetails, HybridAnalysis analysis) {
    for (HybridAnalysisDetail detail : analysis.getDetail()) {
      HybridDetailSelectionCriteria detailCriteria = new HybridDetailSelectionCriteria(analysis.getProduct(),
              analysis.getTrait(), detail.getFemaleParent().getTrait(), detail.getMaleParent().getTrait());
      boolean isSelected = selectedDetails.contains(detailCriteria);
      detail.setSelected(isSelected);
    }
  }

  private String[] getSelectedAnalysisDetailsFromRequest(UCCHelper helper) throws IOException {
    String[] selectedAnalysisDetails = helper
            .getRequestParameterValues(SELECTED_ANALYSIS_DETAILS_CHKBX);
    selectedAnalysisDetails = selectedAnalysisDetails == null ? new String[]{} : selectedAnalysisDetails;
    return selectedAnalysisDetails;
  }

  private Collection<HybridDetailSelectionCriteria> getSelectedDetails(UCCHelper helper) throws IOException {
    Collection<HybridDetailSelectionCriteria> selectedDetails = new ArrayList<HybridDetailSelectionCriteria>();
    for (String selectedAnalysisIds : getSelectedAnalysisDetailsFromRequest(helper)) {
      String[] ids = org.apache.commons.lang.StringUtils.deleteWhitespace(selectedAnalysisIds).split(",");
      Product product = productService.lookupProductById(Long.parseLong(ids[0]));
      Trait trait = traitService.lookupTraitById(Long.parseLong(ids[1]));
      Trait femaleDetailTrait = traitService.lookupTraitById(Long.parseLong(ids[2]));
      Trait maleDetailTrait = traitService.lookupTraitById(Long.parseLong(ids[3]));
      selectedDetails.add(new HybridDetailSelectionCriteria(product, trait, femaleDetailTrait, maleDetailTrait));
    }
    return selectedDetails;
  }
}
