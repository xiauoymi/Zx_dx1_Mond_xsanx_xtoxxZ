package com.monsanto.eas.hiat.view;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.hiat.analysis.InbredAnalysis;
import com.monsanto.eas.hiat.availability.HybridAvailabilitySeasonInformation;
import com.monsanto.eas.hiat.availability.InbredAvailabilityInformation;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.Trait;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.Collection;

public class InbredAnalysisXMLGenerator extends AnalysisXMLGenerator {
  public Document getXmlContent(Collection<InbredAnalysis> analysisCollection, Collection<String> missingProducts) {
    Document document = DOMUtil.newDocument();
    Element results = DOMUtil.addChildElement(document, "RESULTS");
    addAnalysis(results, analysisCollection);
    buildMissingProducts(missingProducts, results);
    return document;
  }

  private void addAnalysis(Element results, Collection<InbredAnalysis> analysisCollection) {
    for (InbredAnalysis analysis : analysisCollection) {
      Element analysisElement = DOMUtil.addChildElement(results, ANALYSIS);
      addNameInfo(analysisElement, analysis.getProduct());
      addPrimaryFlag(analysisElement, analysis.getPrimaryFlag());
      addTraitInfo(analysisElement, analysis.getTrait());
      addInbredInfo(analysisElement, analysis.getInbredAvailabilityInfo());
      addHybridInfo(analysisElement, analysis.getHybridAvailabilityInfo());
    }
  }

  private void addNameInfo(Element analysisElement, Product product) {
    DOMUtil.addChildElement(analysisElement, "BASE_MFG_INBRED", product.getProductName(ProductNameType.BASE_MANUFACTURING));
    DOMUtil.addChildElement(analysisElement, "PRECOMMERCIAL_INBRED", product.getProductName(ProductNameType.BASE_PRECOMMERCIAL));
  }

  private void addPrimaryFlag(Element analysisElement, Boolean primaryFlag) {
    String primaryDisplayValue;
    if (primaryFlag) {
      primaryDisplayValue = "YES";
    } else {
      primaryDisplayValue = "";
    }
    DOMUtil.addChildElement(analysisElement, "HAS_PRIMARY", primaryDisplayValue);
  }

  private void addTraitInfo(Element analysisElement, Trait trait) {
    DOMUtil.addChildElement(analysisElement, "TRAIT_CODE", trait.getCode());
    DOMUtil.addChildElement(analysisElement, "TRAIT_COMMERCIAL", trait.getCommercialName());
    DOMUtil.addChildElement(analysisElement, "EVENT_GROUP", trait.getFullName());
  }

  private void addInbredInfo(Element analysisElement, InbredAvailabilityInformation inbredInfo) {
    if (inbredInfo != null) {
      DOMUtil.addChildElement(analysisElement, "GEN0_DATE", getAvailabilityDateAsString(inbredInfo.getG0Date()));
      DOMUtil.addChildElement(analysisElement, "GEN1_DATE", getAvailabilityDateAsString(inbredInfo.getG1Date()));
      DOMUtil.addChildElement(analysisElement, "GEN2_DATE", getAvailabilityDateAsString(inbredInfo.getG2Date()));
    }
  }

  private void addHybridInfo(Element analysisElement, HybridAvailabilitySeasonInformation hybridInfo) {
    if (hybridInfo != null) {
      DOMUtil.addChildElement(analysisElement, "PCM150_SEASON", hybridInfo.getPcm150Season().toString());
      DOMUtil.addChildElement(analysisElement, "PCM300_SEASON", hybridInfo.getPcm300Season().toString());
      DOMUtil.addChildElement(analysisElement, "COMMERCIAL_SEASON", hybridInfo.getCommercialSeason().toString());
    }
  }

  //todo refactor to use common element names (where applicable)
}
