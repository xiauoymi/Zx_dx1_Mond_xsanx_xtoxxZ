package com.monsanto.eas.hiat.view;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.hiat.analysis.InbredStatus;
import com.monsanto.eas.hiat.analysis.InbredStatusDetail;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.ProductionEntry;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

/**
 * Created by vvvelu Date: Mar 12, 2009 Time: 12:51:37 PM
 */
public class InbredStatusXMLGenerator extends AnalysisXMLGenerator {
  private static final String TRAIT_VERSION = "TRAIT_VERSION";
  private static final String PRODUCT_STATUS = "STATUS";
  private static final String TRAIT_COMMERCIAL = "TRAIT_COMMERCIAL";
  private static final String EVENT_GROUP = "EVENT_GROUP";
  private static final String BASE_MANUFACTURING_FEMALE = "BASE_MFG_INBRED";

  private static final String TRAIT_INTEGRATION = "TI";

  private static final String HAND_OFF_DATE = "HAND_OFF_DATE";
  private static final String PRIMARY_DATE = "PRIMARY_DATE";
  private static final String INV_QTY = "INV_QTY";
  private static final String PROD_QTY = "PROD_QTY";
  private static final String PROD_AVAIL_DATE = "PROD_AVAIL_DATE";
  private static final String PLANNED_PROD_QTY = "PLANNED_PROD_QTY";
  private static final String PLANNED_PROD_AVAIL_DATE = "PLANNED_PROD_AVAIL_DATE";

  public Document getXmlContent(Collection<InbredStatus> statusResults, Collection<String> missingProducts) {
    Document document = DOMUtil.newDocument();
    Element analysis = DOMUtil.addChildElement(document, ANALYSIS);
    buildInbredStatus(statusResults, analysis);
    buildMissingProducts(missingProducts, analysis);
    return document;
  }

  private void buildInbredStatus(Iterable<InbredStatus> analysisResults, Node analysis) {
    for (InbredStatus inbredStatus : analysisResults) {
      Element productElement = DOMUtil.addChildElement(analysis, PRODUCT);

      Collection<InbredStatusDetail> inbredStatusDetailSet = inbredStatus.getDetail();
      buildTraits(inbredStatus, productElement, inbredStatusDetailSet);
    }
  }

  private void buildTraits(InbredStatus inbredStatus, Node productElement,
                           Iterable<InbredStatusDetail> inbredAnalysisDetailSet) {
    Product product = inbredStatus.getProduct();

    for (InbredStatusDetail inbredStatusDetail : inbredAnalysisDetailSet) {
      Product detailProduct = inbredStatusDetail.getProduct();
      Element productInfo = DOMUtil.addChildElement(productElement, PRODUCT_INFO);
      addProduct(product, productInfo);
      addProductDetail(detailProduct, productInfo);
      addTraitInfo(inbredStatusDetail, productInfo);
      addTIToProductInfo(detailProduct, productInfo);
      addGenerationToProductInfo(inbredStatusDetail, InventoryType.PREFOUNDATION, productInfo);
      addGenerationToProductInfo(inbredStatusDetail, InventoryType.GENERATION_1, productInfo);
      addGenerationToProductInfo(inbredStatusDetail, InventoryType.GENERATION_2, productInfo);
    }
  }

  private void addTraitInfo(InbredStatusDetail inbredStatusDetail, Element productInfo) {
    DOMUtil.addChildElement(productInfo, TRAIT_CODE, inbredStatusDetail.getTrait().getCode());
    DOMUtil.addChildElement(productInfo, TRAIT_COMMERCIAL, inbredStatusDetail.getTrait().getCommercialName());
    DOMUtil.addChildElement(productInfo, EVENT_GROUP, inbredStatusDetail.getTrait().getFullName());
  }

  private void addProductDetail(Product detailProduct, Element productInfo) {
    if (detailProduct != null) {
      DOMUtil.addChildElement(productInfo, PRE_COMMERCIAL_INBRED, detailProduct.getProductName(ProductNameType.TRAITED_PRECOMMERCIAL));
      DOMUtil.addChildElement(productInfo, MFG_INBRED_FEMALE, detailProduct.getProductName(ProductNameType.MANUFACTURING));
      DOMUtil.addChildElement(productInfo, TRAIT_VERSION, detailProduct.getTraitVersion());
      DOMUtil.addChildElement(productInfo, PRODUCT_STATUS, detailProduct.getStatus());
    }
  }

  private void addProduct(Product product, Element productInfo) {
    if (product != null) {
      DOMUtil.addChildElement(productInfo, BASE_MANUFACTURING_FEMALE,
              product.getProductName(ProductNameType.BASE_MANUFACTURING));
      DOMUtil.addChildElement(productInfo, BASE_INBRED_FEMALE, product.getProductName(ProductNameType.BASE_PRECOMMERCIAL));
    }
  }

  private void addTIToProductInfo(Product detailProduct, Node productInfo) {
    if (detailProduct != null) {
      Element generation = DOMUtil.addChildElement(productInfo, TRAIT_INTEGRATION);
      DOMUtil.addChildElement(generation, HAND_OFF_DATE, detailProduct.getHandoffDate());
      DOMUtil.addChildElement(generation, PRIMARY_DATE, detailProduct.getPrimaryTestingDate());
    }
  }

  private void addGenerationToProductInfo(InbredStatusDetail inbredStatusDetail,
                                          InventoryType generation,
                                          Node productInfo) {
    if (inbredStatusDetail != null) {
      Element generationElement = DOMUtil.addChildElement(productInfo, generation.getXmlTag());


      addChildElementIfPositive(generationElement, INV_QTY, inbredStatusDetail.getInventory(generation));
      addChildElementIfPositive(generationElement, PROD_QTY, inbredStatusDetail.getProduction(generation));
      DOMUtil.addChildElement(generationElement, PROD_AVAIL_DATE, getAvailableDateForProduct(inbredStatusDetail, generation));
      addChildElementIfPositive(generationElement, PLANNED_PROD_QTY, inbredStatusDetail.getPlannedProduction(generation));
      DOMUtil.addChildElement(generationElement, PLANNED_PROD_AVAIL_DATE, getPlannedAvailableDateForProduct(inbredStatusDetail, generation));
    }
  }

  private void addChildElementIfPositive(Element parentElement, String childElementName, long childElementValue) {
    if (childElementValue > 0) {
      DOMUtil.addChildElement(parentElement, childElementName, childElementValue);
    }
  }


  private Date getAvailableDateForProduct(InbredStatusDetail detail, InventoryType type) {
    //todo look at this - is it being overly cautious
    if (detail.getProductionQuantities() == null) {
      return null;
    } else if (detail.getProductionQuantities().get(type) == null) {
      return null;
    } else {
      return getLatestDate(detail.getProductionQuantities().get(type));
    }
  }

  private Date getPlannedAvailableDateForProduct(InbredStatusDetail detail, InventoryType type) {
    //todo look at this - is it being overly cautious
    if (detail.getProductionQuantities() == null) {
      return null;
    } else if (detail.getPlannedProductionQuantities().get(type) == null) {
      return null;
    } else {
      return getLatestDate(detail.getPlannedProductionQuantities().get(type));
    }
  }

  private Date getLatestDate(Collection<ProductionEntry> productionEntries) {
    if (productionEntries.isEmpty()) {
      return null;
    }

    Iterator<ProductionEntry> prodEntryIterator = productionEntries.iterator();
    Date latestDate = prodEntryIterator.next().getAvailableDate();
    while (prodEntryIterator.hasNext()) {
      Date currDate = prodEntryIterator.next().getAvailableDate();
      latestDate = laterDate(currDate, latestDate);
    }

    return latestDate;
  }

  private static Date laterDate(Date date1, Date date2) {
    if (date1 == null) {
      return null;
    } else if (date2 == null || date2.after(date1)) {
      return date2;
    } else {
      return date1;
    }
  }

}

