package com.monsanto.eas.hiat.view.excel;

import com.monsanto.eas.hiat.analysis.InbredStatusDetail;
import com.monsanto.eas.hiat.model.*;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ExcelExportStatus {
  private String baseMfgInbred;
  private String basePCMInbred;
  private String preCommTraitedInbred;
  private String mfgTraitedInbred;
  private String version;
  private String status;
  private String traitCode;
  private String traitCommercialName;
  private String traitFullName;
  private Date hoDate;
  private Date primaryDate;
  private Long pfndInvQty;
  private Long pfndProdQty;
  private Date pfndProdAvailDate;
  private Long gen1PlanQty;
  private Date gen1PlanAvailDate;
  private Long gen1ProdQty;
  private Date gen1ProdAvailDate;
  private Long gen1InvQty;
  private Long gen2PlanQty;
  private Date gen2PlanAvailDate;
  private Long gen2ProdQty;
  private Date gen2ProdAvailDate;
  private Long gen2InvQty;

  public ExcelExportStatus(InbredStatusDetail detail) {
    if (detail == null) {
      setProdFields(null);
      setDetailFields(null);
    } else {
      setProdFields(detail.getProduct());
      setDetailFields(detail);
    }
  }

  private void setDetailFields(InbredStatusDetail detail) {
    if (detail == null) {
      this.hoDate = null;
      this.primaryDate = null;
      this.pfndInvQty = null;
      this.gen1InvQty = null;
      this.gen2InvQty = null;
      setPfndProd(null);
      setGen1Plan(null);
      setgen1Prod(null);
      setGen2Plan(null);
      setGen2Prod(null);
    } else {
      ProductionEntry pfndEntry = detail.getTotalProductionQuantities().get(InventoryType.PREFOUNDATION);
      ProductionEntry gen1PlanEntry = detail.getTotalProductionQuantities().get(InventoryType.GENERATION_1);
      ProductionEntry gen1ProdEntry = detail.getTotalPlannedProductionQuantities().get(InventoryType.GENERATION_1);
      ProductionEntry gen2PlanEntry = detail.getTotalProductionQuantities().get(InventoryType.GENERATION_2);
      ProductionEntry gen2ProdEntry = detail.getTotalPlannedProductionQuantities().get(InventoryType.GENERATION_2);

      this.hoDate = detail.getHandoffDate();
      this.primaryDate = detail.getPrimaryDate();
      this.pfndInvQty = detail.getInventory(InventoryType.PREFOUNDATION);
      this.gen1InvQty = detail.getInventory(InventoryType.GENERATION_1);
      this.gen2InvQty = detail.getInventory(InventoryType.GENERATION_2);

      setPfndProd(pfndEntry);
      setGen1Plan(gen1PlanEntry);
      setgen1Prod(gen1ProdEntry);
      setGen2Plan(gen2PlanEntry);
      setGen2Prod(gen2ProdEntry);
    }
  }

  private void setProdFields(Product prod) {
    if (prod == null) {
      this.baseMfgInbred = null;
      this.basePCMInbred = null;
      this.preCommTraitedInbred = null;
      this.mfgTraitedInbred = null;
      this.version = null;
      this.status = null;
      setTraitFields(null);
    } else {
      getBaseNames(prod);
      this.preCommTraitedInbred = prod.getProductName(ProductNameType.TRAITED_PRECOMMERCIAL);
      this.mfgTraitedInbred = prod.getProductName(ProductNameType.MANUFACTURING);
      this.version = prod.getTraitVersion();
      this.status = prod.getStatus();
      setTraitFields(prod.getTrait());
    }
  }

  private void getBaseNames(Product prod) {
    Product baseProd = prod.getBase();
    this.baseMfgInbred = baseProd.getProductName(ProductNameType.MANUFACTURING);
    this.basePCMInbred = baseProd.getProductName(ProductNameType.TRAITED_PRECOMMERCIAL);
  }

  private void setTraitFields(Trait trait) {
    if (trait == null) {
      this.traitCode = null;
      this.traitCommercialName = null;
      this.traitFullName = null;
    } else {
      this.traitCode = trait.getCode();
      this.traitCommercialName = trait.getCommercialName();
      this.traitFullName = trait.getFullName();
    }
  }

  private void setGen2Prod(ProductionEntry gen2Prod) {
    if (gen2Prod == null) {
      this.gen2ProdQty = null;
      this.gen2ProdAvailDate = null;
    } else {
      this.gen2ProdQty = gen2Prod.getQuantity();
      this.gen2ProdAvailDate = gen2Prod.getAvailableDate();
    }
  }

  private void setGen2Plan(ProductionEntry gen2Plan) {
    if (gen2Plan == null) {
      this.gen2PlanQty = null;
      this.gen2PlanAvailDate = null;
    } else {
      this.gen2PlanQty = gen2Plan.getQuantity();
      this.gen2PlanAvailDate = gen2Plan.getAvailableDate();
    }
  }

  private void setgen1Prod(ProductionEntry gen1Prod) {
    if (gen1Prod == null) {
      this.gen1ProdQty = null;
      this.gen1ProdAvailDate = null;
    } else {
      this.gen1ProdQty = gen1Prod.getQuantity();
      this.gen1ProdAvailDate = gen1Prod.getAvailableDate();
    }
  }

  private void setGen1Plan(ProductionEntry gen1Plan) {
    if (gen1Plan == null) {
      this.gen1PlanQty = null;
      this.gen1PlanAvailDate = null;
    } else {
      this.gen1PlanQty = gen1Plan.getQuantity();
      this.gen1PlanAvailDate = gen1Plan.getAvailableDate();
    }
  }

  private void setPfndProd(ProductionEntry pfndProd) {
    if (pfndProd == null) {
      this.pfndProdQty = null;
      this.pfndProdAvailDate = null;
    } else {
      this.pfndProdQty = pfndProd.getQuantity();
      this.pfndProdAvailDate = pfndProd.getAvailableDate();
    }
  }

  //ProductionEntry
  public String getBaseMfgInbred() {
    return baseMfgInbred;
  }

  public String getBasePCMInbred() {
    return basePCMInbred;
  }

  public String getPreCommTraitedInbred() {
    return preCommTraitedInbred;
  }

  public String getMfgTraitedInbred() {
    return mfgTraitedInbred;
  }

  public String getVersion() {
    return version;
  }

  public String getStatus() {
    return status;
  }

  public String getTraitCode() {
    return traitCode;
  }

  public String getTraitCommercialName() {
    return traitCommercialName;
  }

  public String getTraitFullName() {
    return traitFullName;
  }

  public Date getHoDate() {
    return hoDate;
  }

  public Date getPrimaryDate() {
    return primaryDate;
  }

  public Long getPfndInvQty() {
    return pfndInvQty;
  }

  public Long getPfndProdQty() {
    return pfndProdQty;
  }

  public Date getPfndProdAvailDate() {
    return pfndProdAvailDate;
  }

  public Long getGen1PlanQty() {
    return gen1PlanQty;
  }

  public Date getGen1PlanAvailDate() {
    return gen1PlanAvailDate;
  }

  public Long getGen1ProdQty() {
    return gen1ProdQty;
  }

  public Date getGen1ProdAvailDate() {
    return gen1ProdAvailDate;
  }

  public Long getGen1InvQty() {
    return gen1InvQty;
  }

  public Long getGen2PlanQty() {
    return gen2PlanQty;
  }

  public Date getGen2PlanAvailDate() {
    return gen2PlanAvailDate;
  }

  public Long getGen2ProdQty() {
    return gen2ProdQty;
  }

  public Date getGen2ProdAvailDate() {
    return gen2ProdAvailDate;
  }

  public Long getGen2InvQty() {
    return gen2InvQty;
  }
}
