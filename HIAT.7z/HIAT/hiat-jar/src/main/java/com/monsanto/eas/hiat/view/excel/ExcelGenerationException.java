package com.monsanto.eas.hiat.view.excel;

public class ExcelGenerationException extends RuntimeException {
  public ExcelGenerationException(Throwable cause) {
    super(cause);
  }
}
