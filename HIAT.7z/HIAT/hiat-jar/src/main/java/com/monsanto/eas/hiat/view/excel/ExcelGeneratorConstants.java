package com.monsanto.eas.hiat.view.excel;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ExcelGeneratorConstants {
  public static final String CONFIDENTIALITY_NOTICE = "MONSANTO CONFIDENTIAL -- This application contains Highly Confidential information which may NOT be released outside of Monsanto without proper authorization.";
  public static final String MISSING_PRODUCTS_MESSAGE = "Products not found:";
}
