package com.monsanto.eas.hiat.view.excel;

import com.monsanto.eas.hiat.analysis.InbredStatus;
import com.monsanto.eas.hiat.analysis.InbredStatusDetail;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredStatusExcelGenerator {
  public static final String TEMPLATE_LOCATION = "com/monsanto/eas/hiat/view/excel/statusTemplate.xls"; //todo
/*
  public void generateStatusWorkbook(OutputStream output, Collection<InbredStatus> statusResults, Collection<String> missingProducts) throws IOException {
    Spreadsheet sheet = new Spreadsheet(output, SHEET_NAME);
    writeHeader(sheet);
    writeSectionHeadings(sheet);
    writeColumnHeadings(sheet);
    int nextRow = writeResultsData(sheet, statusResults);
    writeMissingProducts(sheet, nextRow, missingProducts);
    setColumnWidths(sheet);
    sheet.close();
  }
*/

  public void generateStatusWorkbook(OutputStream output, Collection<InbredStatus> statusList, Collection<String> missingproducts) throws IOException {
    Map<String, Object> paramMap = new HashMap<String, Object>();
    paramMap.put("status", getExportStatus(statusList));
    paramMap.put("missing", missingproducts);
    HSSFWorkbook workbook = createWorkbook(TEMPLATE_LOCATION, paramMap);
    workbook.write(output);
  }

  protected Collection<ExcelExportStatus> getExportStatus(Collection<InbredStatus> inbredStatusCollection) {
    ArrayList<ExcelExportStatus> exportList = new ArrayList<ExcelExportStatus>(inbredStatusCollection.size());
    for (InbredStatus status : inbredStatusCollection) {
      for (InbredStatusDetail detail : status.getDetail()) {
        exportList.add(new ExcelExportStatus(detail));
      }
    }
    return exportList;
  }

  protected HSSFWorkbook createWorkbook(String templateLocation, Map<String, Object> paramMapping) throws IOException {
    XLSTransformer transformer = new XLSTransformer();
    InputStream stream = InbredStatusExcelGenerator.class.getClassLoader().getResourceAsStream(templateLocation);
    if (stream == null) {
      throw new IOException("Could not locate templat: " + templateLocation);
    }

    return transformer.transformXLS(stream, paramMapping);
  }
}

