package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisDetailImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisParentDetailImpl;
import com.monsanto.eas.hiat.availability.*;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.time.DateUtils;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HybridAnalysisDetailImpl_UT extends HIATUnitTest {
  public void testValuesDefaultToNullOrNotAvailable() throws Exception {
    HybridAnalysisDetail detail = new HybridAnalysisDetailImpl();
    assertNull(detail.getFemaleParent());
    assertNull(detail.getMaleParent());
    assertEquals(Season.NONE, detail.getPcm150Season());
    assertEquals(Season.NONE, detail.getPcm300Season());
    assertEquals(Season.NONE, detail.getCommercialSeason());
  }

  public void testValuesAreAsSetInConstructor() throws Exception {
    HybridAnalysisParentDetail testMale = new HybridAnalysisParentDetailImpl();
    HybridAnalysisParentDetail testFemale = new HybridAnalysisParentDetailImpl();
    AvailabilityDate test150Date = getTestDate(2009, 1, 1);
    AvailabilityDate test300Date = getTestDate(2009, 3, 1);
    AvailabilityDate testCommDate =getTestDate(2009, 11, 1);
    HybridAnalysisDetail detail = new HybridAnalysisDetailImpl(testMale, testFemale,
        new SeasonCalculator().calculateSeasonForPrimaryCommercial(test150Date.getExactDate()),
            new SeasonCalculator().calculateSeasonForPrimaryCommercial(test300Date.getExactDate()),
            new SeasonCalculator().calculateSeasonForPrimaryCommercial(testCommDate.getExactDate())
    );
    assertEquals(testMale, detail.getMaleParent());
    assertEquals(testFemale, detail.getFemaleParent());
    assertEquals("Spring 09", detail.getPcm150Season().toString());
    assertEquals("Spring 09", detail.getPcm300Season().toString());
    assertEquals("Spring 10", detail.getCommercialSeason().toString());
  }

    private AvailabilityDate getTestDate(int year, int month, int dayOfMonth) {
        return new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new GregorianCalendar(year, month, dayOfMonth).getTime(), false);
    }

    public void testEquals_MaleAndFemaleParentTraitsAreEqual_ReturnsTrue() throws Exception {
    HybridAnalysisParentDetail maleParentDetail1 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(1L, null, null, null, null, true), null, null, null);
    HybridAnalysisParentDetail femaleParentDetail1 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(2L, null, null, null, null, true), null, null, null);
    HybridAnalysisDetail detail1 = new HybridAnalysisDetailImpl(maleParentDetail1, femaleParentDetail1,
        Season.NONE, Season.NONE, Season.NONE);

    HybridAnalysisParentDetail maleParentDetail2 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(1L, null, null, null, null, true), null, null, null);
    HybridAnalysisParentDetail femaleParentDetail2 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(2L, null, null, null, null, true), null, null, null);
    HybridAnalysisDetail detail2 = new HybridAnalysisDetailImpl(maleParentDetail2, femaleParentDetail2,
        Season.NONE, Season.NONE, Season.NONE);

    assertTrue(detail1.equals(detail2));
  }

  public void testEquals_MaleParentTraitsDontMatch_ReturnsFalse() throws Exception {
    HybridAnalysisParentDetail maleParentDetail1 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(1L, null, null, null, null, true), null, null, null);
    HybridAnalysisParentDetail femaleParentDetail1 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(2L, null, null, null, null, true), null, null, null);
    HybridAnalysisDetail detail1 = new HybridAnalysisDetailImpl(maleParentDetail1, femaleParentDetail1,
        Season.NONE, Season.NONE, Season.NONE);

    HybridAnalysisParentDetail maleParentDetail2 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(3L, null, null, null, null, true), null, null, null);
    HybridAnalysisParentDetail femaleParentDetail2 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(2L, null, null, null, null, true), null, null, null);
    HybridAnalysisDetail detail2 = new HybridAnalysisDetailImpl(maleParentDetail2, femaleParentDetail2,
        Season.NONE, Season.NONE, Season.NONE);

    assertFalse(detail1.equals(detail2));
  }

  public void testEquals_FemaleParentTraitsDontMatch_ReturnsFalse() throws Exception {
    HybridAnalysisParentDetail maleParentDetail1 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(1L, null, null, null, null, true), null, null, null);
    HybridAnalysisParentDetail femaleParentDetail1 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(2L, null, null, null, null, true), null, null, null);
    HybridAnalysisDetail detail1 = new HybridAnalysisDetailImpl(maleParentDetail1, femaleParentDetail1,
        Season.NONE, Season.NONE, Season.NONE);

    HybridAnalysisParentDetail maleParentDetail2 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(1L, null, null, null, null, true), null, null, null);
    HybridAnalysisParentDetail femaleParentDetail2 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(3L, null, null, null, null, true), null, null, null);
    HybridAnalysisDetail detail2 = new HybridAnalysisDetailImpl(maleParentDetail2, femaleParentDetail2,
        Season.NONE, Season.NONE, Season.NONE);

    assertFalse(detail1.equals(detail2));
  }

  public void testEquals_MaleAndFemaleParentTraitsDontMatch_ReturnsFalse() throws Exception {
    HybridAnalysisParentDetail maleParentDetail1 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(1L, null, null, null, null, true), null, null, null);
    HybridAnalysisParentDetail femaleParentDetail1 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(2L, null, null, null, null, true), null, null, null);
    HybridAnalysisDetail detail1 = new HybridAnalysisDetailImpl(maleParentDetail1, femaleParentDetail1,
        Season.NONE, Season.NONE, Season.NONE);

    HybridAnalysisParentDetail maleParentDetail2 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(2L, null, null, null, null, true), null, null, null);
    HybridAnalysisParentDetail femaleParentDetail2 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(1L, null, null, null, null, true), null, null, null);
    HybridAnalysisDetail detail2 = new HybridAnalysisDetailImpl(maleParentDetail2, femaleParentDetail2,
        Season.NONE, Season.NONE, Season.NONE);

    assertFalse(detail1.equals(detail2));
  }

  public void testCompareTo_AvailabilityDateForCommercial_DifferentDatesSameSeason() throws Exception {
    HybridAnalysisParentDetail maleParentDetail1 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(1L, "ABC", null, null, null, true), null, null, null);
    HybridAnalysisParentDetail femaleParentDetail1 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(2L, null, null, null, null, true), null, null, null);
    Date date1 = AvailDateTestUtil.randomFutureDate();
    HybridAnalysisDetail detail1 = new HybridAnalysisDetailImpl(maleParentDetail1, femaleParentDetail1,
        Season.NONE, Season.NONE, new SeasonCalculator().calculateSeasonForPrimaryCommercial(date1));

    HybridAnalysisParentDetail maleParentDetail2 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(2L, "XYZ", null, null, null, true), null, null, null);
    HybridAnalysisParentDetail femaleParentDetail2 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(1L, null, null, null, null, true), null, null, null);
    Date date2 = DateUtils.addDays(date1, 1);
    HybridAnalysisDetail detail2 = new HybridAnalysisDetailImpl(maleParentDetail2, femaleParentDetail2,
        Season.NONE, Season.NONE, new SeasonCalculator().calculateSeasonForPrimaryCommercial(date2));

    assertTrue("Expected " + detail1 + " and " + detail2 + " to compare as the same", detail1.compareTo(detail2) == 0);
  }


  private Date getDate(int year, int month, int day){
    GregorianCalendar calendar = new GregorianCalendar(year, month, day);
    return calendar.getTime();
  }

  public void testCompareTo_AvailabilityDateForCommercial_DifferentSeasons() throws Exception {
    HybridAnalysisParentDetail maleParentDetail1 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(1L, "ABC", null, null, null, true), null, null, null);
    HybridAnalysisParentDetail femaleParentDetail1 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(2L, null, null, null, null, true), null, null, null);
    Date date1 = getDate(2003, Calendar.JANUARY, 1);
    HybridAnalysisDetail detail1 = new HybridAnalysisDetailImpl(maleParentDetail1, femaleParentDetail1,
        Season.NONE, Season.NONE,
            new SeasonCalculator().calculateSeasonForPrimaryCommercial(date1));

    HybridAnalysisParentDetail maleParentDetail2 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(2L, "ABC", null, null, null, true), null, null, null);
    HybridAnalysisParentDetail femaleParentDetail2 = new HybridAnalysisParentDetailImpl(
        null, new MockTrait(1L, null, null, null, null, true), null, null, null);
    Date date2 = getDate(2002, Calendar.AUGUST, 1);
    HybridAnalysisDetail detail2 = new HybridAnalysisDetailImpl(maleParentDetail2, femaleParentDetail2,
        Season.NONE, Season.NONE,
            new SeasonCalculator().calculateSeasonForPrimaryCommercial(date2));

    assertTrue(detail1.compareTo(detail2) > 0);
  }
}