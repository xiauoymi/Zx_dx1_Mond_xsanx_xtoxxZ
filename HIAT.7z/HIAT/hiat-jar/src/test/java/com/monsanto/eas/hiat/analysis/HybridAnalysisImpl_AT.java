package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisDetailImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisParentDetailImpl;
import com.monsanto.eas.hiat.availability.*;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.HIATDatabaseTestCase;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.dao.GenericDAO;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HybridAnalysisImpl_AT extends HIATDatabaseTestCase {
  public void testInitDAO() throws Exception {
    GenericDAO<HybridAnalysis, Long> dao = new TestInitService().initHybridAnalysisDAO();
    assertNotNull(dao);
  }

  public void testNegativeIdDoesntExist() throws Exception {
    GenericDAO<HybridAnalysis, Long> dao = new TestInitService().initHybridAnalysisDAO();
    long testId = -getPositiveId();

    HybridAnalysis analysis = dao.findByPrimaryKey(testId);
    assertNull(analysis);
  }

  public void testAddATraitAndThenFindItAndRemoveIt() throws Exception {
    GenericDAO<HybridAnalysis, Long> dao = new TestInitService().initHybridAnalysisDAO();
    HybridAnalysis addedAnalysis = new HybridAnalysisImpl();
    HybridAnalysisParentDetail testMale = new HybridAnalysisParentDetailImpl(null, getTrait(), null, null, null);
    HybridAnalysisParentDetail testFemale = new HybridAnalysisParentDetailImpl(null, getTrait(), null, null, null);
    AvailabilityDate testPcmDate = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new GregorianCalendar(2010, Calendar.JANUARY, 12).getTime(), false);
    HybridAnalysisDetail testDetail = new HybridAnalysisDetailImpl(testMale, testFemale,
        new SeasonCalculator().calculateSeasonForPrimaryCommercial(testPcmDate.getExactDate()),
            Season.NONE,
            Season.NONE
    );
    addedAnalysis.getDetail().add(testDetail);
    dao.save(addedAnalysis);
    long testId = addedAnalysis.getId();

    try {
      assertNotNull(dao.findByPrimaryKey(testId));
    } finally {
      dao.delete(addedAnalysis);
    }

    assertNull(dao.findByPrimaryKey(testId));
  }

  private Trait getTrait() {
    GenericDAO<Trait, Long> traitDao = new TestInitService().initTraitDAO();
    List<Trait> list = traitDao.findAll();
    return list.get(0);
  }

  private long getPositiveId() {
    long testId = TestUtils.getRandomLong();
    if (testId == 0) {
      return 1;
    } else if (testId > 0) {
      return testId;
    } else {
      return -testId;
    }
  }
}