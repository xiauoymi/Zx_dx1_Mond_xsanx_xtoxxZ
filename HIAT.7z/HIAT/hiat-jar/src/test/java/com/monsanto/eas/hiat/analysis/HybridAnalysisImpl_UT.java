package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisDetailImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisParentDetailImpl;
import com.monsanto.eas.hiat.availability.Season;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.HashSet;
import java.util.Set;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HybridAnalysisImpl_UT extends HIATUnitTest {
  public void testValuesDefaultToNull() throws Exception {
    HybridAnalysis analysis = new HybridAnalysisImpl();
    assertNull(analysis.getProduct());
    assertNotNull(analysis.getDetail());
    assertTrue(analysis.getDetail().isEmpty());
  }

  public void testValuesAreAsSpecifiedInConstructor() throws Exception {
    Product testProduct = new ProductImpl(0L, "TEST", new MockTrait("XYZ"), null, null, null, null, false, null, null, false);
    Set<HybridAnalysisDetail> testDetailSet = new HashSet<HybridAnalysisDetail>();
    HybridAnalysisDetail testDetail = new HybridAnalysisDetailImpl(new HybridAnalysisParentDetailImpl(null, new MockTrait(1L, null, null, null, null, true), null, null, null),
        new HybridAnalysisParentDetailImpl(null, new MockTrait(2L, null, null, null, null, true), null, null, null), Season.NONE, Season.NONE, Season.NONE);
    Trait testTrait = new MockTrait(1L, null, null, null, null, true);
    testDetailSet.add(testDetail);
    HybridAnalysis analysis = new HybridAnalysisImpl(testProduct, testTrait, testDetailSet);
    assertEquals(testProduct, analysis.getProduct());
    assertEquals(testTrait, analysis.getTrait());
    assertEquals(1, analysis.getDetail().size());
    assertTrue(analysis.getDetail().contains(testDetail));
  }

  public void testEquals_ProductAndTraitAreEqual_ReturnsTrue() throws Exception {
    Product testProduct1 = new MockProduct(0L);
    Trait testTrait1 = new MockTrait(0L);
    Set<HybridAnalysisDetail> testDetailSet1 = new HashSet<HybridAnalysisDetail>();
    HybridAnalysis analysis1 = new HybridAnalysisImpl(testProduct1, testTrait1, testDetailSet1);

    Product testProduct2 = new MockProduct(0L);
    Trait testTrait2 = new MockTrait(0L);
    Set<HybridAnalysisDetail> testDetailSet2 = new HashSet<HybridAnalysisDetail>();
    HybridAnalysis analysis2 = new HybridAnalysisImpl(testProduct2, testTrait2, testDetailSet2);

    assertTrue(analysis1.equals(analysis2));
  }

  public void testEquals_TraitNotequal_ReturnsFalse() throws Exception {
    Product testProduct1 = new MockProduct(0L);
    Trait testTrait1 = new MockTrait(0L);
    Set<HybridAnalysisDetail> testDetailSet1 = new HashSet<HybridAnalysisDetail>();
    HybridAnalysis analysis1 = new HybridAnalysisImpl(testProduct1, testTrait1, testDetailSet1);

    Product testProduct2 = new MockProduct(0L);
    Trait testTrait2 = new MockTrait(1L);
    Set<HybridAnalysisDetail> testDetailSet2 = new HashSet<HybridAnalysisDetail>();
    HybridAnalysis analysis2 = new HybridAnalysisImpl(testProduct2, testTrait2, testDetailSet2);

    assertFalse(analysis1.equals(analysis2));
  }

  public void testEquals_ProductNotequal_ReturnsFalse() throws Exception {
    Product testProduct1 = new MockProduct(0L);
    Trait testTrait1 = new MockTrait(0L);
    Set<HybridAnalysisDetail> testDetailSet1 = new HashSet<HybridAnalysisDetail>();
    HybridAnalysis analysis1 = new HybridAnalysisImpl(testProduct1, testTrait1, testDetailSet1);

    Product testProduct2 = new MockProduct(1L);
    Trait testTrait2 = new MockTrait(0L);
    Set<HybridAnalysisDetail> testDetailSet2 = new HashSet<HybridAnalysisDetail>();
    HybridAnalysis analysis2 = new HybridAnalysisImpl(testProduct2, testTrait2, testDetailSet2);

    assertFalse(analysis1.equals(analysis2));
  }

  public void testEquals_ProductAndTraitNotequal_ReturnsFalse() throws Exception {
    Product testProduct1 = new MockProduct(0L);
    Trait testTrait1 = new MockTrait(0L);
    Set<HybridAnalysisDetail> testDetailSet1 = new HashSet<HybridAnalysisDetail>();
    HybridAnalysis analysis1 = new HybridAnalysisImpl(testProduct1, testTrait1, testDetailSet1);

    Product testProduct2 = new MockProduct(1L);
    Trait testTrait2 = new MockTrait(1L);
    Set<HybridAnalysisDetail> testDetailSet2 = new HashSet<HybridAnalysisDetail>();
    HybridAnalysis analysis2 = new HybridAnalysisImpl(testProduct2, testTrait2, testDetailSet2);

    assertFalse(analysis1.equals(analysis2));
  }


   public void testComparetTo_DifferentProductsDifferentTraits() throws Exception {
    Product testProduct1 = new MockProduct(1L);
    Trait testTrait1 = new MockTrait("ABC");
    Set<HybridAnalysisDetail> testDetailSet1 = new HashSet<HybridAnalysisDetail>();
    HybridAnalysis analysis1 = new HybridAnalysisImpl(testProduct1, testTrait1, testDetailSet1);

    Product testProduct2 = new MockProduct(2L);
    Trait testTrait2 = new MockTrait("XYZ");
    Set<HybridAnalysisDetail> testDetailSet2 = new HashSet<HybridAnalysisDetail>();
    HybridAnalysis analysis2 = new HybridAnalysisImpl(testProduct2, testTrait2, testDetailSet2);

    assertTrue(analysis1.compareTo(analysis2) < 0);
  }

   public void testComparetTo_DifferentProductSameTraits() throws Exception {
    Product testProduct1 = new MockProduct(1L);
    Trait testTrait1 = new MockTrait("ABC");
    Set<HybridAnalysisDetail> testDetailSet1 = new HashSet<HybridAnalysisDetail>();
    HybridAnalysis analysis1 = new HybridAnalysisImpl(testProduct1, testTrait1, testDetailSet1);

    Product testProduct2 = new MockProduct(1L);
    Trait testTrait2 = new MockTrait("ABC");
    Set<HybridAnalysisDetail> testDetailSet2 = new HashSet<HybridAnalysisDetail>();
    HybridAnalysis analysis2 = new HybridAnalysisImpl(testProduct2, testTrait2, testDetailSet2);

    assertTrue(analysis1.compareTo(analysis2) == 0);
  }
}