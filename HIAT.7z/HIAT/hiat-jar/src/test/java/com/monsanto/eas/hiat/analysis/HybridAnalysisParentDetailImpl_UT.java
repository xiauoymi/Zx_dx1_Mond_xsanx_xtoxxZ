package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisParentDetailImpl;
import com.monsanto.eas.hiat.availability.AvailDateTestUtil;
import com.monsanto.eas.hiat.availability.AvailabilityDate;
import com.monsanto.eas.hiat.availability.AvailabilityDateImpl;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.util.DateTestUtil;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.GregorianCalendar;
import java.util.HashSet;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HybridAnalysisParentDetailImpl_UT extends HIATUnitTest {
    public void testValuesDefaultToNull() throws Exception {
        HybridAnalysisParentDetail parentDetail = new HybridAnalysisParentDetailImpl();
        assertNull(parentDetail.getTrait());
        assertNull(parentDetail.getGeneration0Date());
        assertNull(parentDetail.getGeneration1Date());
        assertNull(parentDetail.getGeneration2Date());
    }

    public void testValuesAreAsSpecifiedInConstructor() throws Exception {
        Trait testTrait = new MockTrait(1L, "XYZ", "TEST TRAIT", "TESTING", new HashSet<Trait>(), true);
        AvailabilityDate testGen0Date = getTestDate(2009, 1, 1);
        AvailabilityDate testGen1Date = getTestDate(2009, 5, 1);
        AvailabilityDate testGen2Date = getTestDate(2009, 11, 1);
        HybridAnalysisParentDetail parentDetail = new HybridAnalysisParentDetailImpl(null, testTrait, testGen0Date, testGen1Date, testGen2Date);
        assertEquals(testTrait, parentDetail.getTrait());
        DateTestUtil.assertDatesEqual(testGen0Date, parentDetail.getGeneration0Date());
        DateTestUtil.assertDatesEqual(testGen1Date, parentDetail.getGeneration1Date());
        DateTestUtil.assertDatesEqual(testGen2Date, parentDetail.getGeneration2Date());
    }

    private AvailabilityDate getTestDate(int year, int month, int dayOfMonth) {
        return new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new GregorianCalendar(year, month, dayOfMonth).getTime(), false);
    }
}