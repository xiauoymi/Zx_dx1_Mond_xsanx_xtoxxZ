package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.*;
import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.controller.mock.MockTraitCalculator;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.service.MockProductService;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.mock.mock.MockTraitDAO;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import com.monsanto.eas.hiat.trait.TraitTree;
import org.apache.commons.lang.time.DateUtils;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HybridAnalyzerImpl_UT extends HIATUnitTest {
  private final static Trait TEST_TRAIT = new MockTraitDAO().getConventional();
  private final static Trait TEST_DIFFERENT_TRAIT = new MockTrait(999L, "MOCK", "MOCK", "MOCK", new HashSet<Trait>(), true);

  private final static Product TEST_FEMALE_BASE = new MockProduct(1L, "MOCK1", TEST_TRAIT, null, null, null, null, true, null, "Primary", false);
  private final static Product TEST_MALE_BASE = new MockProduct(2L, "MOCK2", TEST_TRAIT, null, null, null, null, true, null, "Primary", false);
  private final static Product TEST_FEMALE = new MockProduct(3L, "MOCK3", TEST_TRAIT, null, null, null, null, true, TEST_FEMALE_BASE, "Primary", false);
  private final static Product TEST_MALE = new MockProduct(4L, "MOCK4", TEST_TRAIT, null, null, null, null, true, TEST_MALE_BASE, "Primary", false);
  private final static Product TEST_PRODUCT = new MockProduct(5L, "MOCK5", TEST_TRAIT, TEST_FEMALE, TEST_MALE, null, null, true, null, "Primary", true);

  private static final AvailabilityDate PRIMARY_AVAIL_DATE = AvailDateTestUtil.getRandomFutureDate();
  private static final Date PRIMARY_DATE = PRIMARY_AVAIL_DATE.getExactDate();

  private final static Product TEST_FEMALE_BASE_NOTPRIMARY = new MockProduct(11L, "MOCK11", TEST_TRAIT, null, null, null, PRIMARY_DATE, false, null, "Active", false);
  private final static Product TEST_MALE_BASE_NOTPRIMARY = new MockProduct(12L, "MOCK12", TEST_TRAIT, null, null, null, PRIMARY_DATE, false, null, "Active", false);
  private final static Product TEST_FEMALE_NOTPRIMARY = new MockProduct(13L, "MOCK13", TEST_TRAIT, null, null, null, PRIMARY_DATE, false, TEST_FEMALE_BASE_NOTPRIMARY, "Active", false);
  private final static Product TEST_MALE_NOTPRIMARY = new MockProduct(14L, "MOCK14", TEST_TRAIT, null, null, null, PRIMARY_DATE, false, TEST_MALE_BASE_NOTPRIMARY, "Active", false);
  private final static Product TEST_PRODUCT_NOTPRIMARY = new MockProduct(15L, "MOCK15", TEST_TRAIT, TEST_FEMALE_NOTPRIMARY, TEST_MALE_NOTPRIMARY, null, PRIMARY_DATE, false, null, "Active", true);

  public void testNoProductsReturnsEmptyList() throws Exception {
    HybridAnalyzer analyzer = new HybridAnalyzerImpl(
            new MockInbredAvailabilityCalculatorConstantDates(),
            new MockTraitCalculator(),
            new MockParentCalculator(),
            null, new MockParentWorstCaseCalculator(),
            new MockProductService());
    List<Trait> testTraits = new ArrayList<Trait>();
    testTraits.add(TEST_TRAIT);
    List<HybridAnalysis> analysisList = analyzer.analyze(new ArrayList<Product>(0), testTraits).getAnalysisList();
    assertNotNull(analysisList);
    assertEquals(0, analysisList.size());
  }

  public void testNoTraitReturnsNoResults() throws Exception {
    HybridAnalyzer analyzer = new HybridAnalyzerImpl(
            new MockInbredAvailabilityCalculatorConstantDates(),
            new MockTraitCalculator(),
            new MockParentCalculator(),
            null, new MockParentWorstCaseCalculator(),
            new MockProductService());
    List<Product> testProducts = new ArrayList<Product>();
    testProducts.add(TEST_PRODUCT);
    List<HybridAnalysis> analysisList = analyzer.analyze(testProducts, new ArrayList<Trait>()).getAnalysisList();
    assertNotNull(analysisList);
    assertEquals(0, analysisList.size());
  }

   private AvailabilityDate getTestDate(int year, int month, int dayOfMonth) {
        return new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new GregorianCalendar(year, month, dayOfMonth).getTime(), false);
    }

  public void testSingleResultIsReturned() throws Exception {
    AvailabilityDate expectedPCM150Date = getTestDate(2009, 1, 1);
    AvailabilityDate expectedPCM300Date = getTestDate(2009,5,4);
    AvailabilityDate expectedCommDate = getTestDate(2009,7,13);
    AvailabilityDate expectedG0Date = AvailDateTestUtil.getRandomFutureDate();
    AvailabilityDate expectedG1Date = AvailDateTestUtil.getRandomFutureDate();
    AvailabilityDate expectedG2Date = AvailDateTestUtil.getRandomFutureDate();

    HybridAnalyzer analyzer = new HybridAnalyzerImpl(
            new MockInbredAvailabilityCalculatorConstantDates(expectedG0Date, expectedG1Date, expectedG2Date),
            new MockTraitCalculator(),
            new MockParentCalculator(),
            new MockParentPairAvailabilityCalculator(expectedPCM150Date, expectedPCM300Date, expectedCommDate),
            new MockParentWorstCaseCalculator(),
            new MockProductService());

    List<Product> testProducts = new ArrayList<Product>();
    testProducts.add(TEST_PRODUCT);
    ArrayList<Trait> testTraits = new ArrayList<Trait>();
    testTraits.add(TEST_TRAIT);
    Collection<HybridAnalysis> analysisList = analyzer.analyze(testProducts, testTraits).getAnalysisList();
    assertNotNull(analysisList);
    assertEquals(1, analysisList.size());

    HybridAnalysis result = analysisList.iterator().next();
    assertNotNull(result);
    assertEquals(TEST_PRODUCT, result.getProduct());
    assertEquals(TEST_TRAIT, result.getTrait());
    Collection<HybridAnalysisDetail> details = result.getDetail();
    assertNotNull(details);
    assertEquals(1, details.size());
    HybridAnalysisDetail detail = details.iterator().next();
    assertNotNull(detail);
    assertEquals("Spring 09", detail.getPcm150Season().toString());
    assertEquals("Winter 09/10", detail.getPcm300Season().toString());
    assertEquals("Winter 09/10", detail.getCommercialSeason().toString());
    //todo add asserts for seasons

    HybridAnalysisParentDetail femaleParentDetail = detail.getFemaleParent();
    assertNotNull(femaleParentDetail);
    assertEquals(TEST_FEMALE_BASE, femaleParentDetail.getProduct());
    assertEquals(TEST_TRAIT, femaleParentDetail.getTrait());
    assertEquals(expectedG0Date, femaleParentDetail.getGeneration0Date());
    assertEquals(expectedG1Date, femaleParentDetail.getGeneration1Date());
    assertEquals(expectedG2Date, femaleParentDetail.getGeneration2Date());

    HybridAnalysisParentDetail maleParentDetail = detail.getMaleParent();
    assertNotNull(femaleParentDetail);
    assertEquals(TEST_MALE_BASE, maleParentDetail.getProduct());
    assertEquals(TEST_TRAIT, maleParentDetail.getTrait());
    assertEquals(expectedG0Date, maleParentDetail.getGeneration0Date());
    assertEquals(expectedG1Date, maleParentDetail.getGeneration1Date());
    assertEquals(expectedG2Date, maleParentDetail.getGeneration2Date());
  }

  public void testHybridAvailabilityConstrainedByEarliestPrimarySetDate() throws Exception {
    AvailabilityDate expectedG0Date = AvailDateTestUtil.getRandomFutureDate();
    AvailabilityDate expectedG1Date = AvailDateTestUtil.getRandomFutureDate();
    AvailabilityDate expectedG2Date = AvailDateTestUtil.getRandomFutureDate();

    Date earlierDate = DateUtils.addDays(PRIMARY_DATE, -100);
    AvailabilityDate earlierAvailabilityDate = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, earlierDate);
    HybridAnalyzer analyzer = new HybridAnalyzerImpl(
            new MockInbredAvailabilityCalculatorConstantDates(expectedG0Date, expectedG1Date, expectedG2Date),
            new MockTraitCalculator(),
            new MockParentCalculator(),
            new MockParentPairAvailabilityCalculator(earlierAvailabilityDate, earlierAvailabilityDate, earlierAvailabilityDate),
            new MockParentWorstCaseCalculator(),
            new MockProductService());

    List<Product> testProducts = new ArrayList<Product>();
    testProducts.add(TEST_PRODUCT_NOTPRIMARY);
    ArrayList<Trait> testTraits = new ArrayList<Trait>();
    testTraits.add(TEST_TRAIT);
    Collection<HybridAnalysis> analysisList = analyzer.analyze(testProducts, testTraits).getAnalysisList();
    assertNotNull(analysisList);
    assertEquals(1, analysisList.size());

    HybridAnalysis result = analysisList.iterator().next();
    assertNotNull(result);
    assertEquals(TEST_PRODUCT_NOTPRIMARY, result.getProduct());
    assertEquals(TEST_TRAIT, result.getTrait());
    Collection<HybridAnalysisDetail> details = result.getDetail();
    assertNotNull(details);
    assertEquals(1, details.size());
    HybridAnalysisDetail detail = details.iterator().next();
    assertNotNull(detail);

    //todo add asserts for seasons

    HybridAnalysisParentDetail femaleParentDetail = detail.getFemaleParent();
    assertNotNull(femaleParentDetail);
    assertEquals(TEST_FEMALE_BASE_NOTPRIMARY, femaleParentDetail.getProduct());
    assertEquals(TEST_TRAIT, femaleParentDetail.getTrait());
    assertEquals(expectedG0Date, femaleParentDetail.getGeneration0Date());
    assertEquals(expectedG1Date, femaleParentDetail.getGeneration1Date());
    assertEquals(expectedG2Date, femaleParentDetail.getGeneration2Date());

    HybridAnalysisParentDetail maleParentDetail = detail.getMaleParent();
    assertNotNull(femaleParentDetail);
    assertEquals(TEST_MALE_BASE_NOTPRIMARY, maleParentDetail.getProduct());
    assertEquals(TEST_TRAIT, maleParentDetail.getTrait());
    assertEquals(expectedG0Date, maleParentDetail.getGeneration0Date());
    assertEquals(expectedG1Date, maleParentDetail.getGeneration1Date());
    assertEquals(expectedG2Date, maleParentDetail.getGeneration2Date());
  }

  public void testAnalysisesAreSortedByMfgHybridNameAndTargetTrait() throws Exception {
    AvailabilityDate expectedG0Date = AvailDateTestUtil.getRandomFutureDate();
    AvailabilityDate expectedG1Date = AvailDateTestUtil.getRandomFutureDate();
    AvailabilityDate expectedG2Date = AvailDateTestUtil.getRandomFutureDate();

    Date earlierDate = DateUtils.addDays(PRIMARY_DATE, -100);
    AvailabilityDate earlierAvailabilityDate = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, earlierDate);

    MockAnalyzerForCaptureAnalysis analyzer = new MockAnalyzerForCaptureAnalysis(
            new MockInbredAvailabilityCalculatorConstantDates(expectedG0Date, expectedG1Date, expectedG2Date),
            new MockTraitCalculator(),
            new MockParentCalculator(),
            new MockParentPairAvailabilityCalculator(earlierAvailabilityDate, earlierAvailabilityDate, earlierAvailabilityDate),
            new MockParentWorstCaseCalculator(),
            new MockProductService());

    Product firstProductInSort = TEST_PRODUCT_NOTPRIMARY;
    Product secondProductInSort = TEST_PRODUCT;
    Trait firstTraitInSort = TEST_TRAIT;
    Trait secondTraitInSort = TEST_DIFFERENT_TRAIT;

    {
      List<Product> testProducts = new ArrayList<Product>();
      testProducts.add(firstProductInSort);
      testProducts.add(secondProductInSort);
      ArrayList<Trait> testTraits = new ArrayList<Trait>();
      testTraits.add(secondTraitInSort);
      testTraits.add(firstTraitInSort);
      analyzer.analyze(testProducts, testTraits);
      assertParamsAreInOrder(analyzer.getAnalysisParams(),firstProductInSort, secondProductInSort, firstTraitInSort, secondTraitInSort);
    }

    analyzer.clearAnalysisParams();

    {
      List<Product> testProducts = new ArrayList<Product>();
      testProducts.add(secondProductInSort);
      testProducts.add(firstProductInSort);
      ArrayList<Trait> testTraits = new ArrayList<Trait>();
      testTraits.add(secondTraitInSort);
      testTraits.add(firstTraitInSort);
      analyzer.analyze(testProducts, testTraits);
      assertParamsAreInOrder(analyzer.getAnalysisParams(),firstProductInSort, secondProductInSort, firstTraitInSort, secondTraitInSort);
    }
  }

  private void assertParamsAreInOrder(List<MockAnalyzerForCaptureAnalysis.AnalysisParams> analysisParams,
                                      Product firstProductInSort, Product secondProductInSort,
                                      Trait firstTraitInSort, Trait secondTraitInSort) {
    assertEquals(4, analysisParams.size());
    assertEquals(firstProductInSort, analysisParams.get(0).getProduct());
    assertEquals(firstTraitInSort, analysisParams.get(0).getTrait());
    assertEquals(firstProductInSort, analysisParams.get(1).getProduct());
    assertEquals(secondTraitInSort, analysisParams.get(1).getTrait());
    assertEquals(secondProductInSort, analysisParams.get(2).getProduct());
    assertEquals(firstTraitInSort, analysisParams.get(2).getTrait());
    assertEquals(secondProductInSort, analysisParams.get(3).getProduct());
    assertEquals(secondTraitInSort, analysisParams.get(3).getTrait());
  }

  private static class MockAnalyzerForCaptureAnalysis extends HybridAnalyzerImpl {
    private final List<AnalysisParams> analysisParams = new ArrayList<AnalysisParams>();

    public MockAnalyzerForCaptureAnalysis(Calculator<Product, InbredAvailabilityInformation> inbredCalc, Calculator<Trait, List<TraitTree>> traitCalc, Calculator<ParentBaseTraitCombination, ParentPairCollection> parentCalc, Calculator<ParentPair, HybridAvailabilityInformation> parentAvailCalc, Calculator<ParentPairCollection, ParentPair> worstCaseCalc, ProductService prodService) {
      super(inbredCalc, traitCalc, parentCalc, parentAvailCalc, worstCaseCalc, prodService);
    }

    @Override
    protected HybridAnalysis analyze(Product product, Trait trait) {
      analysisParams.add(new AnalysisParams(product, trait));
      return null;
    }

    public List<AnalysisParams> getAnalysisParams() {
      return analysisParams;
    }

    public void clearAnalysisParams() {
      analysisParams.clear();
    }

    private static class AnalysisParams {
      private final Product product;
      private final Trait trait;

      private AnalysisParams(Product product, Trait trait) {
        this.product = product;
        this.trait = trait;
      }

      public Product getProduct() {
        return product;
      }

      public Trait getTrait() {
        return trait;
      }
    }
  }

  public static class MockParentCalculator implements Calculator<ParentBaseTraitCombination, ParentPairCollection> {

    public ParentPairCollection calculate(ParentBaseTraitCombination parentCombination) {
      ArrayList<ParentPair> parents = new ArrayList<ParentPair>();
      parents.add(new ParentPair(parentCombination.getBaseFemaleProduct(), parentCombination.getBaseMaleProduct()));
      return new ParentPairCollection(parents);
    }
  }

  public static class MockParentWorstCaseCalculator implements Calculator<ParentPairCollection, ParentPair> {
    public ParentPair calculate(ParentPairCollection parentPairs) {
      if (parentPairs.getParentPairs().isEmpty()) {
        return null;
      } else {
        return parentPairs.getParentPairs().iterator().next();
      }
    }
  }

  public static class MockParentPairAvailabilityCalculator implements Calculator<ParentPair, HybridAvailabilityInformation> {
    private final HybridAvailabilityInformation availInfo;

    public MockParentPairAvailabilityCalculator(
            AvailabilityDate expectedPCM150Date,
            AvailabilityDate expectedPCM300Date,
            AvailabilityDate expectedCommDate) {
      this.availInfo = new HybridAvailabilityInformation(expectedPCM150Date, expectedPCM300Date, expectedCommDate);
    }

    public HybridAvailabilityInformation calculate(ParentPair pair) {
      return availInfo;
    }
  }
}