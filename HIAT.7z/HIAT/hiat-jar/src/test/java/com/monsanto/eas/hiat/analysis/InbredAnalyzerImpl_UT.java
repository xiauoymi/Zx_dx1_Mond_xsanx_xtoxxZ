package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.*;
import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.service.MockProductService;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredAnalyzerImpl_UT extends HIATUnitTest {
  public void testProductDoesntHaveSpecifiedTraitReturnsAnalysisWithNoInbredOrHybridInfo() throws Exception {
    MockProductService productService = new MockProductService();
    Product testBaseProduct = new MockProduct(1L);
    Trait testGoodTrait = new MockTrait(1L);
    Product testTraitedProduct = new MockProduct(2L, "A", testGoodTrait, null, null, null, null, true, testBaseProduct, "ACTIVE", false);
    productService.addMapping(testBaseProduct, testGoodTrait, testTraitedProduct);
    InbredAnalyzer analyzer = new InbredAnalyzerImpl(productService, new MockInbredAvailabilityCalculatorConstantDates(), new MockHybridAvailabilityCalculatorConstantDates());
    Trait testBadTrait = new MockTrait(123321L);
    InbredAnalysis result = analyzer.analyze(testBaseProduct, testBadTrait);
    assertNotNull(result);
    assertNotNull(result.getProduct());
    assertNotNull(result.getTrait());
    assertNotNull(result.getPrimaryFlag());
    assertNull(result.getInbredAvailabilityInfo());
    assertNull(result.getHybridAvailabilityInfo());
  }

  public void testProductHasTraitReturnsCorrectTraitAndProductInfo() throws Exception {
    MockProductService productService = new MockProductService();
    Product testBaseProduct = new MockProduct(1L);
    Trait testTrait = new MockTrait(1L);
    Product testTraitedProduct = new MockProduct(2L, "A", testTrait, null, null, null, null, true, testBaseProduct, "ACTIVE", false);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct);
    InbredAnalyzer analyzer = new InbredAnalyzerImpl(productService, new MockInbredAvailabilityCalculatorConstantDates(), new MockHybridAvailabilityCalculatorConstantDates());
    InbredAnalysis result = analyzer.analyze(testBaseProduct, testTrait);
    assertNotNull(result);
    assertNotNull(result.getProduct());
    assertEquals(new Long(1L), result.getProduct().getId());
    assertEquals(testTrait, result.getTrait());
  }

  public void testHasAProductWithPrimary_PrimaryFlagIsSet() throws Exception {
    MockProductService productService = new MockProductService();
    Product testBaseProduct = new MockProduct(1L);
    Trait testTrait = new MockTrait(1L);
    Product testTraitedProduct1 = new MockProduct(2L, "A1", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct2 = new MockProduct(3L, "A2", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct3 = new MockProduct(4L, "A3", testTrait, null, null, null, null, true, testBaseProduct, "PRIMARY", false);
    Product testTraitedProduct4 = new MockProduct(5L, "A4", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct5 = new MockProduct(6L, "A5", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct1);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct2);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct3);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct4);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct5);
    InbredAnalyzer analyzer = new InbredAnalyzerImpl(productService, new MockInbredAvailabilityCalculatorConstantDates(), new MockHybridAvailabilityCalculatorConstantDates());
    InbredAnalysis result = analyzer.analyze(testBaseProduct, testTrait);
    assertEquals(Boolean.TRUE, result.getPrimaryFlag());
  }

  public void testHasNoProductWithPrimary_PrimaryFlagIsNotSet() throws Exception {
    MockProductService productService = new MockProductService();
    Product testBaseProduct = new MockProduct(1L);
    Trait testTrait = new MockTrait(1L);
    Product testTraitedProduct1 = new MockProduct(2L, "A1", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct2 = new MockProduct(3L, "A2", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct3 = new MockProduct(4L, "A3", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct4 = new MockProduct(5L, "A4", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct5 = new MockProduct(6L, "A5", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct1);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct2);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct3);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct4);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct5);
    InbredAnalyzer analyzer = new InbredAnalyzerImpl(productService, new MockInbredAvailabilityCalculatorConstantDates(), new MockHybridAvailabilityCalculatorConstantDates());
    InbredAnalysis result = analyzer.analyze(testBaseProduct, testTrait);
    assertEquals(Boolean.FALSE, result.getPrimaryFlag());
  }


  public void testReturnsCorrectInbredDateInfo() throws Exception {
    MockProductService productService = new MockProductService();
    Product testBaseProduct = new MockProduct(1L);
    Trait testTrait = new MockTrait(1L);
    Product testTraitedProduct1 = new MockProduct(2L, "A1", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct2 = new MockProduct(3L, "A2", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct3 = new MockProduct(4L, "A3", testTrait, null, null, null, null, true, testBaseProduct, "PRIMARY", false);
    Product testTraitedProduct4 = new MockProduct(5L, "A4", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct5 = new MockProduct(6L, "A5", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct1);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct2);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct3);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct4);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct5);
    AvailabilityDate expectedG0Date = AvailabilityDateImpl.getNow("Mock1");
    AvailabilityDate expectedG1Date = AvailabilityDateImpl.getNow("Mock2");
    AvailabilityDate expectedG2Date = AvailabilityDateImpl.getUnknown("Mock3");
    Calculator<Product, InbredAvailabilityInformation> inbredAvailCalc = new MockInbredAvailabilityCalculatorConstantDates(expectedG0Date, expectedG1Date, expectedG2Date);
    Calculator<Product, HybridAvailabilityInformation> hybridAvailCalc = new MockHybridAvailabilityCalculatorConstantDates();
    InbredAnalyzer analyzer = new InbredAnalyzerImpl(productService, inbredAvailCalc, hybridAvailCalc);
    InbredAnalysis result = analyzer.analyze(testBaseProduct, testTrait);
    assertNotNull(result);
    InbredAvailabilityInformation inbredInfo = result.getInbredAvailabilityInfo();
    assertNotNull(inbredInfo);
    assertEquals(expectedG0Date, inbredInfo.getG0Date());
    assertEquals(expectedG1Date, inbredInfo.getG1Date());
    assertEquals(expectedG2Date, inbredInfo.getG2Date());
  }

  public void testReturnsCorrectHybridDateInfo() throws Exception {
    MockProductService productService = new MockProductService();
    Product testBaseProduct = new MockProduct(1L);
    Trait testTrait = new MockTrait(1L);
    Product testTraitedProduct1 = new MockProduct(2L, "A1", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct2 = new MockProduct(3L, "A2", testTrait, null, null, null, new Date(), false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct3 = new MockProduct(4L, "A3", testTrait, null, null, null, null, true, testBaseProduct, "PRIMARY", false);
    Product testTraitedProduct4 = new MockProduct(5L, "A4", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    Product testTraitedProduct5 = new MockProduct(6L, "A5", testTrait, null, null, null, null, false, testBaseProduct, "ACTIVE", false);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct1);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct2);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct3);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct4);
    productService.addMapping(testBaseProduct, testTrait, testTraitedProduct5);
    AvailabilityDate expectedPCM150Date = AvailabilityDateImpl.getUnknown("Mock1");
    AvailabilityDate expectedPCM300Date = AvailabilityDateImpl.getUnknown("Mock2");
    AvailabilityDate expectedCommDate = AvailabilityDateImpl.getNow("Mock3");
    String expectedCommSeason = new SeasonCalculator().calculateSeasonForPrimaryCommercial(expectedCommDate.getExactDate()).toString();
    Calculator<Product, InbredAvailabilityInformation> inbredAvailCalc = new MockInbredAvailabilityCalculatorConstantDates();
    Calculator<Product, HybridAvailabilityInformation> hybridAvailCalc = new MockHybridAvailabilityCalculatorConstantDates(expectedPCM150Date, expectedPCM300Date, expectedCommDate);
    InbredAnalyzer analyzer = new InbredAnalyzerImpl(productService, inbredAvailCalc, hybridAvailCalc);
    InbredAnalysis result = analyzer.analyze(testBaseProduct, testTrait);
    assertNotNull(result);
    HybridAvailabilitySeasonInformation hybridInfo = result.getHybridAvailabilityInfo();
    assertNotNull(hybridInfo);
    assertEquals(Season.NOT_AVAILABLE_MESSAGE, hybridInfo.getPcm150Season().toString());
    assertEquals(Season.NOT_AVAILABLE_MESSAGE, hybridInfo.getPcm300Season().toString());
    assertEquals(expectedCommSeason, hybridInfo.getCommercialSeason().toString());
  }
}
