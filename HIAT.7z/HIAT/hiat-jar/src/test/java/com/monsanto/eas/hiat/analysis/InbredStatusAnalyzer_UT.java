package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.AvailDateTestUtil;
import com.monsanto.eas.hiat.controller.mock.MockProductServiceConfiguredForNE5112v1;
import com.monsanto.eas.hiat.dao.InventoryDAO;
import com.monsanto.eas.hiat.dao.ProductionDAO;
import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.hibernate.*;
import com.monsanto.eas.hiat.model.mock.MockInventoryDAO;
import com.monsanto.eas.hiat.model.mock.MockProductionDAO;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.util.DateTestUtil;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredStatusAnalyzer_UT extends HIATUnitTest {
  private InbredStatusAnalyzer statusAnalyzer;
  private Trait testTrait1;
  private Trait testTrait2;
  private Trait testTrait3;
  private Product testProduct1;
  private Product testProduct2;
  private Product testProduct4;
  private Product testProduct3;
  private Product base1;

  private static final Date TEST_HANDOFF_DATE = new GregorianCalendar(2009, Calendar.AUGUST, 20).getTime();
  private static final Date TEST_PRIMARY_DATE = new GregorianCalendar(2010, Calendar.MAY, 2).getTime();
  private static final long TEST_INVENTORY_QUANTITY_GEN1 = 123L;
  private static final long TEST_PRODUCTION_QUANTITY_GEN2_PART_1 = 111L;
  private static final long TEST_PRODUCTION_QUANTITY_GEN2_PART_2 = 333L;
  private static final long TEST_PRODUCTION_QUANTITY_GEN2 = TEST_PRODUCTION_QUANTITY_GEN2_PART_1 + TEST_PRODUCTION_QUANTITY_GEN2_PART_2;
  private static final long TEST_PRODUCTION_QUANTITY_GEN2_PLANNED = 884L;
  private static final InventoryType TEST_INVENTORY_TYPE = InventoryType.GENERATION_1;
  private static final InventoryType TEST_PRODUCTION_TYPE = InventoryType.GENERATION_2;
  private static final Date TEST_PRODUCTION_AVAIL_DATE = AvailDateTestUtil.randomFutureDate();
  private static final Date TEST_PRODUCTION_AVAIL_DATE_PLANNED = AvailDateTestUtil.randomFutureDate();

  @Override
  protected void setUp() throws Exception {
    super.setUp();

    testTrait1 = new MockTrait(1L, "TEST", "TEST", "TEST", new HashSet<Trait>(0), true);
    testTrait2 = new MockTrait(2L, "TEST2", "TEST2", "TEST2", new HashSet<Trait>(0), true);
    testTrait3 = new MockTrait(3L, "TEST3", "TEST2", "TEST3", new HashSet<Trait>(0), true);

    base1 = new ProductImpl(1L, "1", new TraitImpl(2L, null, null, null, null, true), null, null, null, null, true, null,
            null, false);
    Product base2 = new ProductImpl(2L, "1", new TraitImpl(1L, null, null, null, null, true), null, null, null, null, true, null,
            null, false);

    testProduct1 = new ProductImpl(0L, "TEST", new MockTrait("TEST"), null, null, null, null, false, base1, null,
            false);
    testProduct2 = new ProductImpl(0L, "TEST2", new MockTrait("TEST2"), null, null, null, null, false, base2, null,
            false);
    testProduct3 = new ProductImpl(0L, "TEST3", new MockTrait("TEST32"), null, null, TEST_HANDOFF_DATE,
            TEST_PRIMARY_DATE, false, null,
            null, false);
    testProduct4 = new ProductImpl(0L, "TEST3", new MockTrait("TEST44"), null, null, TEST_HANDOFF_DATE,
            TEST_PRIMARY_DATE, false, testProduct4,
            null, false);

    List<InventoryEntry> testInventoryList = new ArrayList<InventoryEntry>();
    testInventoryList.add(new InventoryEntryImpl(testProduct3, TEST_INVENTORY_QUANTITY_GEN1, TEST_INVENTORY_TYPE));
    List<ProductionEntry> testProductionList = new ArrayList<ProductionEntry>();
    testProductionList.add(new ProductionEntryImpl(TEST_PRODUCTION_AVAIL_DATE, testProduct3, TEST_PRODUCTION_QUANTITY_GEN2_PART_1, TEST_PRODUCTION_TYPE, false));
    testProductionList.add(new ProductionEntryImpl(TEST_PRODUCTION_AVAIL_DATE, testProduct3, TEST_PRODUCTION_QUANTITY_GEN2_PART_2, TEST_PRODUCTION_TYPE, false));
    testProductionList.add(new ProductionEntryImpl(TEST_PRODUCTION_AVAIL_DATE_PLANNED, testProduct3, TEST_PRODUCTION_QUANTITY_GEN2_PLANNED, TEST_PRODUCTION_TYPE, true));
    InventoryDAO invDAO = new MockInventoryDAO(testInventoryList);
    ProductionDAO prodDAO = new MockProductionDAO(testProductionList);
    statusAnalyzer = new InbredStatusAnalyzer(
            new MockProductServiceConfiguredForNE5112v1(),
            invDAO, prodDAO);
  }

  public void testNoProductsReturnsEmptyList() throws Exception {
    List<Trait> testTraits = new ArrayList<Trait>();
    testTraits.add(testTrait1);
    List<InbredStatus> analysises = statusAnalyzer.analyze(new ArrayList<Product>(), testTraits);
    assertNotNull(analysises);
    assertTrue(analysises.isEmpty());
  }

  public void testNoTraitsCausesNoDetail() throws Exception {
    ArrayList<Product> testProducts = new ArrayList<Product>();
    testProducts.add(testProduct1);
    List<InbredStatus> analysises = statusAnalyzer.analyze(testProducts, new ArrayList<Trait>());
    assertNotNull(analysises);
    assertTrue(analysises.isEmpty());
  }

  public void testSingleProductSingleTraitCausesOneDetail() throws Exception {
    List<Trait> testTraits = new ArrayList<Trait>();
    testTraits.add(testTrait1);
    ArrayList<Product> testProducts = new ArrayList<Product>();
    testProducts.add(testProduct1);
    List<InbredStatus> analysises = statusAnalyzer.analyze(testProducts, testTraits);
    assertNotNull(analysises);
    assertEquals(1, analysises.size());
    InbredStatus status = analysises.get(0);
    assertNotNull(status);
    assertEquals(base1, status.getProduct());
    Collection<InbredStatusDetail> details = status.getDetail();
    assertNotNull(details);
    assertEquals(1, details.size());
    for (InbredStatusDetail detail : details) {
      assertEquals("BASE_MFG", detail.getProduct().getBase().getProductNames().get(ProductNameType.BASE_MANUFACTURING).getName());
      assertEquals("BASE_PRECOMM", detail.getProduct().getProductNames().get(ProductNameType.BASE_PRECOMMERCIAL).getName());
      assertEquals(testTrait1, detail.getTrait());
      assertEquals(0, detail.getInventory(InventoryType.PREFOUNDATION));
      assertEquals(123L, detail.getInventory(InventoryType.GENERATION_1));
      assertEquals(0, detail.getInventory(InventoryType.GENERATION_2));
      assertEquals(0, detail.getProduction(InventoryType.PREFOUNDATION));
      assertEquals(0, detail.getProduction(InventoryType.GENERATION_1));
      assertEquals(TEST_PRODUCTION_QUANTITY_GEN2, detail.getProduction(InventoryType.GENERATION_2));
      assertEquals(TEST_PRODUCTION_QUANTITY_GEN2_PLANNED, detail.getPlannedProduction(InventoryType.GENERATION_2));
    }
  }

  public void testTwoProductTwoTraitCausesFourDetail() throws Exception {
    List<Trait> testTraits = new ArrayList<Trait>();
    testTraits.add(testTrait1);
    testTraits.add(testTrait2);
    ArrayList<Product> testProducts = new ArrayList<Product>();
    testProducts.add(testProduct1);
    testProducts.add(testProduct2);
    List<InbredStatus> analysises = statusAnalyzer.analyze(testProducts, testTraits);
    assertNotNull(analysises);
    assertEquals(testProducts.size(), analysises.size());
    for (InbredStatus status : analysises) {
      assertNotNull(status);
      assertEquals(testTraits.size(), status.getDetail().size());
      Iterator<InbredStatusDetail> inbredAnalysisDetailIterator = status.getDetail().iterator();
      assertEquals(testTrait1, inbredAnalysisDetailIterator.next().getTrait());
      assertEquals(testTrait2, inbredAnalysisDetailIterator.next().getTrait());
    }
  }

  public void testTestProductWithInventoryAndProduction() throws Exception {
    List<Trait> testTraits = new ArrayList<Trait>();
    testTraits.add(testTrait3);
    ArrayList<Product> testProducts = new ArrayList<Product>();
    testProducts.add(testProduct3);
    List<InbredStatus> analysises = statusAnalyzer.analyze(testProducts, testTraits);
    assertNotNull(analysises);
    assertEquals(1, analysises.size());
    InbredStatus status = analysises.get(0);
    assertNotNull(status);
    assertEquals(testProduct3, status.getProduct());
    Collection<InbredStatusDetail> details = status.getDetail();
    assertNotNull(details);
    assertEquals(1, details.size());
    for (InbredStatusDetail detail : details) {
      assertEquals(testTrait3, detail.getTrait());
      assertEquals(0, detail.getInventory(InventoryType.PREFOUNDATION));
      assertEquals(TEST_INVENTORY_QUANTITY_GEN1, detail.getInventory(InventoryType.GENERATION_1));
      assertEquals(0, detail.getInventory(InventoryType.GENERATION_2));
      assertEquals(0, detail.getProduction(InventoryType.PREFOUNDATION));
      assertEquals(0, detail.getProduction(InventoryType.GENERATION_1));
      assertEquals(TEST_PRODUCTION_QUANTITY_GEN2, detail.getProduction(InventoryType.GENERATION_2));
      DateTestUtil.assertDatesEqual(TEST_HANDOFF_DATE, detail.getProduct().getHandoffDate());
      DateTestUtil.assertDatesEqual(TEST_PRIMARY_DATE, detail.getProduct().getPrimaryTestingDate());
    }
  }


  public void testSingleProductSingleTrait_ProductDoesNotHaveMatchingTrait_DetailHasNAForProductNamesAndEmptyInventory() throws Exception {
    List<Trait> testTraits = new ArrayList<Trait>();
    testTraits.add(testTrait1);
    ArrayList<Product> testProducts = new ArrayList<Product>();
    testProducts.add(testProduct4);
    Map<ProductNameType, ProductName> productNames = new HashMap<ProductNameType, ProductName>();
    productNames.put(ProductNameType.BASE_PRECOMMERCIAL, new ProductNameImpl(null, "01DKD2", testProduct4, null, null, null));
    testProduct4.setProductNames(productNames);
    List<InbredStatus> analysises = statusAnalyzer.analyze(testProducts, testTraits);
    assertNotNull(analysises);
    assertEquals(1, analysises.size());
    InbredStatus status = analysises.get(0);
    assertNotNull(status);
    assertEquals(testProduct1, status.getProduct());
    Collection<InbredStatusDetail> details = status.getDetail();
    assertNotNull(details);
    assertEquals(1, details.size());
    for (InbredStatusDetail detail : details) {
      assertEquals(null, detail.getProduct());
      assertEquals(testTrait1, detail.getTrait());
      assertTrue(detail.getInventoryQuantities().isEmpty());
      assertTrue(detail.getProductionQuantities().isEmpty());
      assertTrue(detail.getPlannedProductionQuantities().isEmpty());
    }
  }
}