package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.AvailDateTestUtil;
import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.hibernate.*;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.util.DateTestUtil;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredStatusDetailImpl_UT extends HIATUnitTest {
  private Map<InventoryType, InventoryEntry> inventoryQuantities = new HashMap<InventoryType, InventoryEntry>();
  private Map<InventoryType, Collection<ProductionEntry>> productionQuantities = new HashMap<InventoryType, Collection<ProductionEntry>>();
  private Map<InventoryType, Collection<ProductionEntry>> plannedProductionQuantities = new HashMap<InventoryType, Collection<ProductionEntry>>();
  Product product1 = new ProductImpl(1L, "TEST", new MockTrait("TEST"), null, null, new Date(), new Date(), true, null,
          null, false);
  Product product2 = new ProductImpl(2L, "TEST", new MockTrait("TEST"), null, null, new Date(), new Date(), true, null,
          null, false);

  public void testValuesDefaultToNullOrZero() throws Exception {
    InventoryEntry invEntry = new InventoryEntryImpl(product1, 10, InventoryType.PREFOUNDATION);
    inventoryQuantities.put(InventoryType.PREFOUNDATION, invEntry);
    productionQuantities.put(InventoryType.GENERATION_1, singleEntryCollection(new ProductionEntryImpl(new Date(), null, 22, InventoryType.GENERATION_1, false)));
    InbredStatusDetail detail = new InbredStatusDetailImpl(null, product1, null, null,
            inventoryQuantities, productionQuantities, plannedProductionQuantities);
    assertNull(detail.getTrait());
    assertNull(detail.getHandoffDate());
    assertNull(detail.getPrimaryDate());
    assertEquals(10, detail.getInventory(InventoryType.PREFOUNDATION));
    assertEquals(22, detail.getProduction(InventoryType.GENERATION_1));
  }

  private Collection<ProductionEntry> singleEntryCollection(ProductionEntry productionEntry) {
    Collection<ProductionEntry> coll = new LinkedList<ProductionEntry>();
    coll.add(productionEntry);
    return coll;
  }

  public void testValuesAreAsSetInConstructor() throws Exception {
    long testPreFndInv = 123L;
    long testGen1Prod = 44455L;
    Trait testTrait = new TraitImpl();
    Date testHandoffDate = new GregorianCalendar(2009, 1, 1).getTime();
    Date testPrimaryDate = new GregorianCalendar(2009, 3, 1).getTime();
    InventoryEntry invEntry = new InventoryEntryImpl(product1, testPreFndInv, InventoryType.PREFOUNDATION);
    inventoryQuantities.put(InventoryType.PREFOUNDATION, invEntry);
    productionQuantities.put(InventoryType.GENERATION_1, singleEntryCollection(new ProductionEntryImpl(new Date(), null, testGen1Prod, InventoryType.GENERATION_1, false)));
    InbredStatusDetail detail = new InbredStatusDetailImpl(testTrait, product1, testHandoffDate, testPrimaryDate,
            inventoryQuantities, productionQuantities, plannedProductionQuantities);
    assertEquals(testTrait, detail.getTrait());
    DateTestUtil.assertDatesEqual(testHandoffDate, detail.getHandoffDate());
    DateTestUtil.assertDatesEqual(testPrimaryDate, detail.getPrimaryDate());
    assertEquals(testPreFndInv, detail.getInventory(InventoryType.PREFOUNDATION));
    assertEquals(0, detail.getProduction(InventoryType.PREFOUNDATION));
    assertEquals(0, detail.getInventory(InventoryType.GENERATION_1));
    assertEquals(testGen1Prod, detail.getProduction(InventoryType.GENERATION_1));
  }

  public void testCompareTo_SortedByTraitedPreCommNameForTheProduct() throws Exception {
    long testPreFndInv = 123L;
    long testGen1Prod = 44455L;
    Trait testTrait = new TraitImpl();
    Date testHandoffDate = new GregorianCalendar(2009, 1, 1).getTime();
    Date testPrimaryDate = new GregorianCalendar(2009, 3, 1).getTime();
    InventoryEntry invEntry = new InventoryEntryImpl(product1, testPreFndInv, InventoryType.PREFOUNDATION);
    inventoryQuantities.put(InventoryType.PREFOUNDATION, invEntry);
    productionQuantities.put(InventoryType.GENERATION_1, singleEntryCollection(new ProductionEntryImpl(new Date(), null, testGen1Prod, InventoryType.GENERATION_1, false)));
    InbredStatusDetail detail = new InbredStatusDetailImpl(testTrait, product1, testHandoffDate, testPrimaryDate,
            inventoryQuantities, productionQuantities, plannedProductionQuantities);
    Map<ProductNameType, ProductName> namesMap = new HashMap<ProductNameType, ProductName>();
    namesMap.put(ProductNameType.TRAITED_PRECOMMERCIAL, new ProductNameImpl(111L, "ABC_T1C1", product1, null, null, ProductNameType.TRAITED_PRECOMMERCIAL));
    product1.setProductNames(namesMap);


    long testPreFndInv2 = 111L;
    long testGen1Prod2 = 121212L;
    Trait testTrait2 = new TraitImpl();
    Date testHandoffDate2 = new GregorianCalendar(2009, 1, 1).getTime();
    Date testPrimaryDate2 = new GregorianCalendar(2009, 3, 1).getTime();
    InventoryEntry invEntry2 = new InventoryEntryImpl(product2, testPreFndInv2, InventoryType.PREFOUNDATION);
    inventoryQuantities.put(InventoryType.PREFOUNDATION, invEntry2);
    productionQuantities.put(InventoryType.GENERATION_1, singleEntryCollection(new ProductionEntryImpl(new Date(), null, testGen1Prod2, InventoryType.GENERATION_1, false)));
    InbredStatusDetailImpl detail2 = new InbredStatusDetailImpl(testTrait2, product2, testHandoffDate2,
            testPrimaryDate2,
            inventoryQuantities, productionQuantities, plannedProductionQuantities);
    namesMap = new HashMap<ProductNameType, ProductName>();
    namesMap.put(ProductNameType.TRAITED_PRECOMMERCIAL, new ProductNameImpl(111L, "1_CCC_T1C1", product2, null, null, ProductNameType.TRAITED_PRECOMMERCIAL));
    product2.setProductNames(namesMap);
    assertTrue(detail.compareTo(detail2) > 0);
  }

  public void testCompareTo_SortedByTraitedPreCommNameForTheProduct_Product2DoesNotHaveTraitedPreComm() throws Exception {
    long testPreFndInv = 123L;
    long testGen1Prod = 44455L;
    Trait testTrait = new TraitImpl();
    Date testHandoffDate = new GregorianCalendar(2009, 1, 1).getTime();
    Date testPrimaryDate = new GregorianCalendar(2009, 3, 1).getTime();
    InventoryEntry invEntry = new InventoryEntryImpl(product1, testPreFndInv, InventoryType.PREFOUNDATION);
    inventoryQuantities.put(InventoryType.PREFOUNDATION, invEntry);
    productionQuantities.put(InventoryType.GENERATION_1, singleEntryCollection(new ProductionEntryImpl(new Date(), null, testGen1Prod, InventoryType.GENERATION_1, false)));
    InbredStatusDetail detail = new InbredStatusDetailImpl(testTrait, product1, testHandoffDate, testPrimaryDate,
            inventoryQuantities, productionQuantities, plannedProductionQuantities);
    Map<ProductNameType, ProductName> namesMap = new HashMap<ProductNameType, ProductName>();
    namesMap.put(ProductNameType.TRAITED_PRECOMMERCIAL, new ProductNameImpl(111L, "ABC_T1C1", product1, null, null, ProductNameType.TRAITED_PRECOMMERCIAL));
    product1.setProductNames(namesMap);


    long testPreFndInv2 = 111L;
    long testGen1Prod2 = 121212L;
    Trait testTrait2 = new TraitImpl();
    Date testHandoffDate2 = new GregorianCalendar(2009, 1, 1).getTime();
    Date testPrimaryDate2 = new GregorianCalendar(2009, 3, 1).getTime();
    InventoryEntry invEntry2 = new InventoryEntryImpl(product1, testPreFndInv2, InventoryType.PREFOUNDATION);
    inventoryQuantities.put(InventoryType.PREFOUNDATION, invEntry2);
    productionQuantities.put(InventoryType.GENERATION_1, singleEntryCollection(new ProductionEntryImpl(new Date(), null, testGen1Prod2, InventoryType.GENERATION_1, false)));
    InbredStatusDetailImpl detail2 = new InbredStatusDetailImpl(testTrait2, product2, testHandoffDate2,
            testPrimaryDate2,
            inventoryQuantities, productionQuantities, plannedProductionQuantities);
    namesMap = new HashMap<ProductNameType, ProductName>();
    namesMap.put(ProductNameType.BASE_MANUFACTURING, new ProductNameImpl(111L, "ABC123", product2, null, null, ProductNameType.TRAITED_PRECOMMERCIAL));
    product2.setProductNames(namesMap);
    assertTrue(detail2.compareTo(detail) < 0);
  }

  public void testPlannedProduction() throws Exception {
    long testPreFndInv = 123L;
    long testGen1Prod = 44455L;
    long testGen1ProdPlanned = 9999L;
    Trait testTrait = new TraitImpl();
    Date testHandoffDate = new GregorianCalendar(2009, 1, 1).getTime();
    Date testPrimaryDate = new GregorianCalendar(2009, 3, 1).getTime();
    Date testProdDate = AvailDateTestUtil.randomFutureDate();
    Date testPlannedProdDate = AvailDateTestUtil.randomFutureDate();
    InventoryEntry invEntry = new InventoryEntryImpl(product1, testPreFndInv, InventoryType.PREFOUNDATION);

    inventoryQuantities.put(InventoryType.PREFOUNDATION, invEntry);
    productionQuantities.put(InventoryType.GENERATION_1, singleEntryCollection(new ProductionEntryImpl(testProdDate, null, testGen1Prod, InventoryType.GENERATION_1, false)));
    plannedProductionQuantities.put(InventoryType.GENERATION_1, singleEntryCollection(new ProductionEntryImpl(testPlannedProdDate, null, testGen1ProdPlanned, InventoryType.GENERATION_1, true)));
    InbredStatusDetail detail = new InbredStatusDetailImpl(testTrait, product1, testHandoffDate, testPrimaryDate,
            inventoryQuantities, productionQuantities, plannedProductionQuantities);
    assertEquals(testGen1Prod, detail.getProduction(InventoryType.GENERATION_1));
    assertEquals(testGen1ProdPlanned, detail.getPlannedProduction(InventoryType.GENERATION_1));
    assertEquals(testProdDate, detail.getProductionQuantities().get(InventoryType.GENERATION_1).iterator().next().getAvailableDate());
    assertEquals(testPlannedProdDate, detail.getPlannedProductionQuantities().get(InventoryType.GENERATION_1).iterator().next().getAvailableDate());
  }


}