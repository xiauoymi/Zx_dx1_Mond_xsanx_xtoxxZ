package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.AvailDateTestUtil;
import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.hibernate.ProductNameImpl;
import com.monsanto.eas.hiat.model.hibernate.ProductionEntryImpl;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredStatusImpl_UT extends HIATUnitTest {
  private Map<InventoryType, InventoryEntry> inventoryQuantities = new HashMap<InventoryType, InventoryEntry>();

  public void testValuesDefaultToNull() throws Exception {
    Set<InbredStatusDetail> testDetailSet = new HashSet<InbredStatusDetail>();
    InbredStatus status = new InbredStatusImpl(null, testDetailSet);
    assertNull(status.getProduct());
    assertNotNull(status.getDetail());
    assertTrue(status.getDetail().isEmpty());
  }

  public void testValuesAreAsSpecifiedInConstructor() throws Exception {
    Product testProduct = new ProductImpl(0L, "TEST", new MockTrait("XYZ"), null, null, null, null, false, null,
            null, false);
    Set<InbredStatusDetail> testDetailSet = new HashSet<InbredStatusDetail>();
    Date testProdDate = AvailDateTestUtil.randomFutureDate();
    Date testPlannedProdDate = AvailDateTestUtil.randomFutureDate();
    long testProdQty = 123L;
    long testPlannedProdQty = 456L;
    Collection<ProductionEntry> productionQuantities = new ArrayList<ProductionEntry>();
    productionQuantities.add(new ProductionEntryImpl(testProdDate, testProduct, testProdQty, InventoryType.GENERATION_1, false));
    productionQuantities.add(new ProductionEntryImpl(testPlannedProdDate, testProduct, testPlannedProdQty, InventoryType.GENERATION_1, true));
    InbredStatusDetail testDetail = new InbredStatusDetailImpl(null, testProduct, null, null,
            inventoryQuantities,
            getMapFromSingleGenColl(InventoryType.GENERATION_1, productionQuantities),
            new HashMap<InventoryType, Collection<ProductionEntry>>());
    testDetailSet.add(testDetail);
    InbredStatus status = new InbredStatusImpl(testProduct, testDetailSet);
    assertEquals(testProduct, status.getProduct());
    assertEquals(1, status.getDetail().size());
    assertTrue(status.getDetail().contains(testDetail));
  }

  private Map<InventoryType, Collection<ProductionEntry>> getMapFromSingleGenColl(InventoryType invType, Collection<ProductionEntry> entries) {
    Map<InventoryType, Collection<ProductionEntry>> map = new HashMap<InventoryType, Collection<ProductionEntry>>();
    map.put(invType, entries);
    return map;
  }

  public void testCompareTo() throws Exception {
    Product testProduct = new ProductImpl(1L, "TEST-2", new MockTrait("XYZ"), null, null, null, null, false, null,
            null, false);
    Map<ProductNameType, ProductName> productNameMaps = new HashMap<ProductNameType, ProductName>();
    productNameMaps.put(ProductNameType.BASE_PRECOMMERCIAL, new ProductNameImpl(null, "XYZ123", testProduct, null, null, ProductNameType.TRAITED_PRECOMMERCIAL));
    testProduct.setProductNames(productNameMaps);
    Set<InbredStatusDetail> testDetailSet = new HashSet<InbredStatusDetail>();
    InbredStatusDetail testDetail = new InbredStatusDetailImpl(null, testProduct, null, null,
            inventoryQuantities,
            new HashMap<InventoryType, Collection<ProductionEntry>>(),
            new HashMap<InventoryType, Collection<ProductionEntry>>());
    testDetailSet.add(testDetail);
    InbredStatus analysis1 = new InbredStatusImpl(testProduct, testDetailSet);


    testProduct = new ProductImpl(2L, "TEST-1", new MockTrait("XYZ"), null, null, null, null, false, null,
            null, false);
    productNameMaps = new HashMap<ProductNameType, ProductName>();
    productNameMaps.put(ProductNameType.BASE_PRECOMMERCIAL, new ProductNameImpl(null, "ABC123", testProduct, null, null, ProductNameType.TRAITED_PRECOMMERCIAL));
    testProduct.setProductNames(productNameMaps);
    testDetailSet = new HashSet<InbredStatusDetail>();
    testDetail = new InbredStatusDetailImpl(null, testProduct, null, null,
            inventoryQuantities,
            new HashMap<InventoryType, Collection<ProductionEntry>>(),
            new HashMap<InventoryType, Collection<ProductionEntry>>());
    testDetailSet.add(testDetail);

    InbredStatus analysis2 = new InbredStatusImpl(testProduct, testDetailSet);

    analysis1.compareTo(analysis2);
    assertTrue(analysis1.compareTo(analysis2) > 0);
    assertTrue(analysis2.compareTo(analysis1) < 0);
  }
}