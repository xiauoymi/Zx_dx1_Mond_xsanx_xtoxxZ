package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class MockHybridAnalyzer implements HybridAnalyzer {
    private final List<HybridAnalysis> analysisList;
    private Collection<Product> lastProductListPassed = null;
    private Collection<Trait> listTraitListPassed = null;

    public MockHybridAnalyzer() {
        this (new ArrayList<HybridAnalysis>());
    }

    public MockHybridAnalyzer(List<HybridAnalysis> analysisList) {
        this.analysisList = analysisList;
    }

    public MockHybridAnalyzer(HybridAnalysis analysis) {
        this.analysisList = new ArrayList<HybridAnalysis>();
        this.analysisList.add(analysis);
    }

    public HybridAnalysisResults analyze(Collection<Product> products, Collection<Trait> traits) {
        lastProductListPassed = products;
        listTraitListPassed = traits;
        return new HybridAnalysisResults(analysisList, new ArrayList<String>());
    }

    public Collection<Product> getLastProductListPassed() {
        return lastProductListPassed;
    }

    public Collection<Trait> getLastTraitListPassed() {
        return listTraitListPassed;
    }
}
