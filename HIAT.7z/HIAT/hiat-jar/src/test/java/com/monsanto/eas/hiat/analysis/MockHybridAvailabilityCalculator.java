package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.AvailDateTestUtil;
import com.monsanto.eas.hiat.availability.AvailabilityDateImpl;
import com.monsanto.eas.hiat.availability.HybridAvailabilityInformation;
import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockHybridAvailabilityCalculator implements Calculator<Product, HybridAvailabilityInformation> {
  private final Map<Product, HybridAvailabilityInformation> availMap = new HashMap<Product, HybridAvailabilityInformation>();

  public void addMapping(Product product, HybridAvailabilityInformation availInfo) {
    availMap.put(product, availInfo);
  }

  public HybridAvailabilityInformation calculate(Product product) {
    HybridAvailabilityInformation availInfo = availMap.get(product);
    if (availInfo == null) {
      return new HybridAvailabilityInformation(
              AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE),
              AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE),
              AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE)
      );
    } else {
      return availInfo;
    }
  }
}
