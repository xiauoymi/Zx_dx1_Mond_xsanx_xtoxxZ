package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.HybridAvailabilityInformation;
import com.monsanto.eas.hiat.availability.HybridAvailabilitySeasonInformation;
import com.monsanto.eas.hiat.availability.InbredAvailabilityInformation;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockTrait;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockInbredAnalysis implements InbredAnalysis {
  public Product getProduct() {
    return new MockProduct(123L);
  }

  public Trait getTrait() {
    return new MockTrait(456L);
  }

  public Boolean getPrimaryFlag() {
    return Boolean.TRUE;
  }

  public InbredAvailabilityInformation getInbredAvailabilityInfo() {
    return new InbredAvailabilityInformation(null, null, null);
  }

  public HybridAvailabilitySeasonInformation getHybridAvailabilityInfo() {
    return new HybridAvailabilitySeasonInformation(new HybridAvailabilityInformation(null, null, null), new Date());
  }
}
