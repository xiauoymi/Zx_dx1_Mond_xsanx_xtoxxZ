package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockInbredAnalyzer implements InbredAnalyzer {
  private final InbredAnalysis expectedAnalysis;
  private Product passedProduct = null;
  private Trait passedTrait = null;

  public MockInbredAnalyzer() {
    this(null);
  }

  public MockInbredAnalyzer(InbredAnalysis expectedAnalysis) {
    this.expectedAnalysis = expectedAnalysis;
  }

  public InbredAnalysis getExpectedAnalysis() {
    return expectedAnalysis;
  }

  public Product getPassedProduct() {
    return passedProduct;
  }

  public Trait getPassedTrait() {
    return passedTrait;
  }

  public InbredAnalysis analyze(Product product, Trait trait) {
    this.passedProduct = product;
    this.passedTrait = trait;
    return expectedAnalysis;
  }
}
