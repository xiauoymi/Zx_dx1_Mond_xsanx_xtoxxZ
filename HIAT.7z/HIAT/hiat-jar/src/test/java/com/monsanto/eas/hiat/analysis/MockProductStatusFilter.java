package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.calculator.Calculator;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class MockProductStatusFilter implements Calculator<ProductTraitPair, Collection<Product>> {
  private final Map<ProductTraitPair, Collection<Product>> results = new HashMap<ProductTraitPair, Collection<Product>>();
  private Collection<ProductTraitPair> inputs = new ArrayList<ProductTraitPair>();

  public Collection<Product> calculate(ProductTraitPair input) {
    inputs.add(input);
    Collection<Product> resultForInput = results.get(input);
    return (resultForInput == null) ? new LinkedList<Product>() : resultForInput;
  }

  public Collection<ProductTraitPair> getInputs() {
    return inputs;
  }

  public void addMapping(Product baseProduct, Trait trait, Collection<Product> expectedResults) {
    results.put(new ProductTraitPair(baseProduct, trait), expectedResults);
  }
}
