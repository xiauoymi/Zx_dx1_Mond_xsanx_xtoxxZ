package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.util.CollectionUtil;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ParentCalculatorImpl_UT extends HIATUnitTest {
  private static final Product TEST_BASE_FEMALE = new MockProduct(1L);
  private static final Product TEST_BASE_MALE = new MockProduct(2L);
  private static final Trait TEST_TRAIT_FEMALE = new MockTrait(1L);
  private static final Trait TEST_TRAIT_MALE = new MockTrait(2L);

  public void testMaleAndFemaleArePassedToFilter() throws Exception {
    MockProductStatusFilter mockFilter = new MockProductStatusFilter();
    Calculator<ParentBaseTraitCombination, ParentPairCollection> parentCalculator = new ParentCalculatorImpl(mockFilter);
    parentCalculator.calculate(new ParentBaseTraitCombination(TEST_BASE_FEMALE, TEST_TRAIT_FEMALE, TEST_BASE_MALE, TEST_TRAIT_MALE));
    Collection<ProductTraitPair> inputs = mockFilter.getInputs();
    assertFalse(inputs.isEmpty());
    assertTrue(inputs.contains(new ProductTraitPair(TEST_BASE_FEMALE, TEST_TRAIT_FEMALE)));
    assertTrue(inputs.contains(new ProductTraitPair(TEST_BASE_MALE, TEST_TRAIT_MALE)));
  }

  public void testNoParentsNoResults() throws Exception {
    MockProductStatusFilter mockFilter = new MockProductStatusFilter();
    Calculator<ParentBaseTraitCombination, ParentPairCollection> parentCalculator = new ParentCalculatorImpl(mockFilter);
    ParentPairCollection result = parentCalculator.calculate(new ParentBaseTraitCombination(TEST_BASE_FEMALE, TEST_TRAIT_FEMALE, TEST_BASE_MALE, TEST_TRAIT_MALE));
    assertTrue(result.getParentPairs().isEmpty());
  }

  public void testResultsForOneParentNotTheOtherNoResults() throws Exception {
    Product testFemale1 = new MockProduct(3L, "MOCK", TEST_TRAIT_FEMALE, null, null, null, null, false, TEST_BASE_FEMALE, "Active", false);
    MockProductStatusFilter mockFilter = new MockProductStatusFilter();
    mockFilter.addMapping(TEST_BASE_FEMALE, TEST_TRAIT_FEMALE, CollectionUtil.singleItemAsCollection(testFemale1));
    Calculator<ParentBaseTraitCombination, ParentPairCollection> parentCalculator = new ParentCalculatorImpl(mockFilter);
    ParentPairCollection result = parentCalculator.calculate(new ParentBaseTraitCombination(TEST_BASE_FEMALE, TEST_TRAIT_FEMALE, TEST_BASE_MALE, TEST_TRAIT_MALE));
    assertTrue(result.getParentPairs().isEmpty());
  }

  public void testSingleActiveParentsWithResults() throws Exception {
    Product testFemale1 = new MockProduct(3L, "MOCK", TEST_TRAIT_FEMALE, null, null, null, null, false, TEST_BASE_FEMALE, "Active", false);
    Product testMale1 = new MockProduct(4L, "MOCK", TEST_TRAIT_MALE, null, null, null, null, false, TEST_BASE_MALE, "Active", false);
    MockProductStatusFilter mockFilter = new MockProductStatusFilter();
    mockFilter.addMapping(TEST_BASE_FEMALE, TEST_TRAIT_FEMALE, CollectionUtil.singleItemAsCollection(testFemale1));
    mockFilter.addMapping(TEST_BASE_MALE, TEST_TRAIT_MALE, CollectionUtil.singleItemAsCollection(testMale1));
    Calculator<ParentBaseTraitCombination, ParentPairCollection> parentCalculator = new ParentCalculatorImpl(mockFilter);
    ParentPairCollection result = parentCalculator.calculate(new ParentBaseTraitCombination(TEST_BASE_FEMALE, TEST_TRAIT_FEMALE, TEST_BASE_MALE, TEST_TRAIT_MALE));
    assertFalse(result.getParentPairs().isEmpty());
    assertEquals(1, result.getParentPairs().size());
    ParentPair parentPair = result.getParentPairs().iterator().next();
    assertEquals(testFemale1, parentPair.getFemaleParent());
    assertEquals(testMale1, parentPair.getMaleParent());
  }

  public void testSingleParentCrossNParentHasNResults() throws Exception {
    Product testFemale1 = new MockProduct(3L, "MOCK", TEST_TRAIT_FEMALE, null, null, null, null, false, TEST_BASE_FEMALE, "Active2", false);
    Product testFemale2 = new MockProduct(5L, "MOCK", TEST_TRAIT_FEMALE, null, null, null, null, false, TEST_BASE_FEMALE, "Active", false);
    Product testFemale3 = new MockProduct(6L, "MOCK", TEST_TRAIT_FEMALE, null, null, null, null, false, TEST_BASE_FEMALE, "Active", false);
    Product testMale1 = new MockProduct(4L, "MOCK", TEST_TRAIT_MALE, null, null, null, null, true, TEST_BASE_MALE, "Primary", false);
    Collection<Product> testFemales = new LinkedList<Product>();
    testFemales.add(testFemale1);
    testFemales.add(testFemale2);
    testFemales.add(testFemale3);

    MockProductStatusFilter mockFilter = new MockProductStatusFilter();
    mockFilter.addMapping(TEST_BASE_FEMALE, TEST_TRAIT_FEMALE, testFemales);
    mockFilter.addMapping(TEST_BASE_MALE, TEST_TRAIT_MALE, CollectionUtil.singleItemAsCollection(testMale1));

    Calculator<ParentBaseTraitCombination, ParentPairCollection> parentCalculator = new ParentCalculatorImpl(mockFilter);
    ParentPairCollection result = parentCalculator.calculate(new ParentBaseTraitCombination(TEST_BASE_FEMALE, TEST_TRAIT_FEMALE, TEST_BASE_MALE, TEST_TRAIT_MALE));
    assertFalse(result.getParentPairs().isEmpty());
    assertEquals(3, result.getParentPairs().size());

    Product[] expectedFemales = {testFemale1, testFemale2, testFemale3};
    int i = 0;
    for (ParentPair parentPair : result.getParentPairs()) {
      assertEquals(expectedFemales[i], parentPair.getFemaleParent()); //todo forcing order on result, do we want this?
      assertEquals(testMale1, parentPair.getMaleParent());
      i++;
    }
  }

  public void testMParentCrossNParentHasMNResults() throws Exception {
    Product testFemale1 = new MockProduct(3L, "MOCK", TEST_TRAIT_FEMALE, null, null, null, null, false, TEST_BASE_FEMALE, "Active", false);
    Product testFemale2 = new MockProduct(5L, "MOCK", TEST_TRAIT_FEMALE, null, null, null, null, false, TEST_BASE_FEMALE, "Active", false);
    Product testFemale3 = new MockProduct(6L, "MOCK", TEST_TRAIT_FEMALE, null, null, null, null, false, TEST_BASE_FEMALE, "Active", false);
    Product testMale1 = new MockProduct(4L, "MOCK", TEST_TRAIT_MALE, null, null, null, null, false, TEST_BASE_MALE, "Active", false);
    Product testMale2 = new MockProduct(7L, "MOCK", TEST_TRAIT_MALE, null, null, null, null, false, TEST_BASE_MALE, "Active", false);

    Collection<Product> testFemales = new LinkedList<Product>();
    testFemales.add(testFemale1);
    testFemales.add(testFemale2);
    testFemales.add(testFemale3);

    Collection<Product> testMales = new LinkedList<Product>();
    testMales.add(testMale1);
    testMales.add(testMale2);

    MockProductStatusFilter mockFilter = new MockProductStatusFilter();
    mockFilter.addMapping(TEST_BASE_FEMALE, TEST_TRAIT_FEMALE, testFemales);
    mockFilter.addMapping(TEST_BASE_MALE, TEST_TRAIT_MALE, testMales);

    Calculator<ParentBaseTraitCombination, ParentPairCollection> parentCalculator = new ParentCalculatorImpl(mockFilter);
    ParentPairCollection result = parentCalculator.calculate(new ParentBaseTraitCombination(TEST_BASE_FEMALE, TEST_TRAIT_FEMALE, TEST_BASE_MALE, TEST_TRAIT_MALE));
    assertFalse(result.getParentPairs().isEmpty());
    assertEquals(6, result.getParentPairs().size());

    Collection<ParentPair> expectedPairs = new ArrayList<ParentPair>();
    expectedPairs.add(new ParentPair(testFemale1, testMale1));
    expectedPairs.add(new ParentPair(testFemale2, testMale1));
    expectedPairs.add(new ParentPair(testFemale3, testMale1));
    expectedPairs.add(new ParentPair(testFemale1, testMale2));
    expectedPairs.add(new ParentPair(testFemale2, testMale2));
    expectedPairs.add(new ParentPair(testFemale3, testMale2));

    for (ParentPair parentPair : result.getParentPairs()) {
      assertTrue("Did not find " + parentPair + " in " + expectedPairs, expectedPairs.contains(parentPair));
      expectedPairs.remove(parentPair);
    }
  }

}

