package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.AvailDateTestUtil;
import com.monsanto.eas.hiat.availability.AvailabilityDateImpl;
import com.monsanto.eas.hiat.availability.HybridAvailabilityInformation;
import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.util.HIATUnitTest;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ParentPairAvailabilityCalculatorImpl_UT extends HIATUnitTest {
  private static final Product TEST_MALE = new MockProduct(1L);
  private static final Product TEST_FEMALE = new MockProduct(2L);
  private static final ParentPair TEST_PAIR = new ParentPair(TEST_FEMALE, TEST_MALE);

  public void testNeitherParentAvailableNoAvailability() throws Exception {
    MockHybridAvailabilityCalculator hybridCalc = new MockHybridAvailabilityCalculator();
    Calculator<ParentPair, HybridAvailabilityInformation> calc = new ParentPairAvailabilityCalculatorImpl(hybridCalc);
    HybridAvailabilityInformation result = calc.calculate(TEST_PAIR);
    assertNotNull(result);
    assertEquals(AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE), result.getPcm150Date());
    assertEquals(AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE), result.getPcm300Date());
    assertEquals(AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE), result.getCommercialDate());
  }

  public void testOneParentNotAvailabileNoAvailability() throws Exception {
    HybridAvailabilityInformation testAvailabilityInfo = generateTestAvailabilityInfo();
    MockHybridAvailabilityCalculator hybridCalc = new MockHybridAvailabilityCalculator();
    hybridCalc.addMapping(TEST_MALE, testAvailabilityInfo);
    Calculator<ParentPair, HybridAvailabilityInformation> calc = new ParentPairAvailabilityCalculatorImpl(hybridCalc);
    HybridAvailabilityInformation result = calc.calculate(TEST_PAIR);
    assertNotNull(result);
    assertEquals(AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE), result.getPcm150Date());
    assertEquals(AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE), result.getPcm300Date());
    assertEquals(AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE), result.getCommercialDate());
  }

  public void testBothParentAvailableUseLatestDateForEach() throws Exception {
    HybridAvailabilityInformation baseTestAvailabilityInfo = generateTestAvailabilityInfo();
    MockHybridAvailabilityCalculator hybridCalc = new MockHybridAvailabilityCalculator();

    HybridAvailabilityInformation testAvailabilityInfo1 =
            new HybridAvailabilityInformation(
                    baseTestAvailabilityInfo.getPcm150Date().addGeneration(),
                    baseTestAvailabilityInfo.getPcm300Date(),
                    baseTestAvailabilityInfo.getCommercialDate()
            );
    HybridAvailabilityInformation testAvailabilityInfo2 =
            new HybridAvailabilityInformation(
                    baseTestAvailabilityInfo.getPcm150Date(),
                    baseTestAvailabilityInfo.getPcm300Date().addGeneration(),
                    baseTestAvailabilityInfo.getCommercialDate().addGeneration()
            );

    hybridCalc.addMapping(TEST_MALE, testAvailabilityInfo1);
    hybridCalc.addMapping(TEST_FEMALE, testAvailabilityInfo2);
    Calculator<ParentPair, HybridAvailabilityInformation> calc = new ParentPairAvailabilityCalculatorImpl(hybridCalc);
    HybridAvailabilityInformation result = calc.calculate(TEST_PAIR);
    assertNotNull(result);
    assertEquals(baseTestAvailabilityInfo.getPcm150Date().addGeneration(), result.getPcm150Date());
    assertEquals(baseTestAvailabilityInfo.getPcm300Date().addGeneration(), result.getPcm300Date());
    assertEquals(baseTestAvailabilityInfo.getCommercialDate().addGeneration(), result.getCommercialDate());
  }

  private HybridAvailabilityInformation generateTestAvailabilityInfo() {
    return new HybridAvailabilityInformation(
            AvailDateTestUtil.getRandomFutureDate(),
            AvailDateTestUtil.getRandomFutureDate(),
            AvailDateTestUtil.getRandomFutureDate()
    );
  }
}