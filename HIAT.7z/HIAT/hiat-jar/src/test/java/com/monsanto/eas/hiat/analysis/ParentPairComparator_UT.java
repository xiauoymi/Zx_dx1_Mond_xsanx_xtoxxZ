package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.availability.AvailDateTestUtil;
import com.monsanto.eas.hiat.availability.AvailabilityDate;
import com.monsanto.eas.hiat.availability.AvailabilityDateImpl;
import com.monsanto.eas.hiat.availability.HybridAvailabilityInformation;
import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ParentPairComparator_UT extends HIATUnitTest {
  public void testSameParentsArequal() throws Exception {
    MockParentPairAvailabilityCalculator availCalc = new MockParentPairAvailabilityCalculator();
    Comparator<ParentPair> comparator = new ParentPairComparator(availCalc);
    Product parent1 = new MockProduct(1L);
    Product parent2 = new MockProduct(2L);
    ParentPair pair1 = new ParentPair(parent1, parent2);
    availCalc.addMapping(pair1, new HybridAvailabilityInformation(
            AvailDateTestUtil.getRandomFutureDate(),
            AvailDateTestUtil.getRandomFutureDate(),
            AvailDateTestUtil.getRandomFutureDate()
    ));

    assertEquals(0, comparator.compare(pair1, pair1));
  }

  public void testOrderedByCommAvailDate() throws Exception {
    MockParentPairAvailabilityCalculator availCalc = new MockParentPairAvailabilityCalculator();
    Comparator<ParentPair> comparator = new ParentPairComparator(availCalc);
    Product parent1 = new MockProduct(1L);
    Product parent2 = new MockProduct(2L);
    Product parent3 = new MockProduct(3L);
    ParentPair pair1 = new ParentPair(parent1, parent2);
    ParentPair pair2 = new ParentPair(parent1, parent3);
    AvailabilityDate testAvailDate = AvailDateTestUtil.getRandomFutureDate();
    availCalc.addMapping(pair1, new HybridAvailabilityInformation(
            testAvailDate.addGeneration(),
            testAvailDate.addGeneration(),
            testAvailDate
    ));
    availCalc.addMapping(pair2, new HybridAvailabilityInformation(
            testAvailDate,
            testAvailDate,
            testAvailDate.addGeneration()
    ));

    int result = comparator.compare(pair1, pair2);
    assertTrue("Expected result < 0, but was: " + result, result < 0);
  }

  public void testNoAvailDateIsGreater() throws Exception {
    MockParentPairAvailabilityCalculator availCalc = new MockParentPairAvailabilityCalculator();
    Comparator<ParentPair> comparator = new ParentPairComparator(availCalc);
    Product parent1 = new MockProduct(1L);
    Product parent2 = new MockProduct(2L);
    Product parent3 = new MockProduct(3L);
    ParentPair pair1 = new ParentPair(parent1, parent2);
    ParentPair pair2 = new ParentPair(parent1, parent3);
    AvailabilityDate testAvailDate = AvailDateTestUtil.getRandomFutureDate();
    availCalc.addMapping(pair1, new HybridAvailabilityInformation(
            testAvailDate.addGeneration(),
            testAvailDate.addGeneration(),
            AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE)
    ));
    availCalc.addMapping(pair2, new HybridAvailabilityInformation(
            testAvailDate,
            testAvailDate,
            testAvailDate.addGeneration()
    ));

    int result = comparator.compare(pair1, pair2);
    assertTrue("Expected result > 0, but was: " + result, result > 0);
  }

  public void testTodayAvailDateIsLess() throws Exception {
    MockParentPairAvailabilityCalculator availCalc = new MockParentPairAvailabilityCalculator();
    Comparator<ParentPair> comparator = new ParentPairComparator(availCalc);
    Product parent1 = new MockProduct(1L);
    Product parent2 = new MockProduct(2L);
    Product parent3 = new MockProduct(3L);
    ParentPair pair1 = new ParentPair(parent1, parent2);
    ParentPair pair2 = new ParentPair(parent1, parent3);
    AvailabilityDate testAvailDate = AvailDateTestUtil.getRandomFutureDate();
    availCalc.addMapping(pair1, new HybridAvailabilityInformation(
            testAvailDate.addGeneration(),
            testAvailDate.addGeneration(),
            new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date())
    ));
    availCalc.addMapping(pair2, new HybridAvailabilityInformation(
            testAvailDate,
            testAvailDate,
            testAvailDate.addGeneration()
    ));

    int result = comparator.compare(pair1, pair2);
    assertTrue("Expected result < 0, but was: " + result, result < 0);
  }

  private class MockParentPairAvailabilityCalculator implements Calculator<ParentPair, HybridAvailabilityInformation> {
    private final Map<ParentPair, HybridAvailabilityInformation> availMap = new HashMap<ParentPair, HybridAvailabilityInformation>();

    public void addMapping(ParentPair pair, HybridAvailabilityInformation availDate) {
      availMap.put(pair, availDate);
    }

    public HybridAvailabilityInformation calculate(ParentPair pair) {
      return availMap.get(pair);
    }
  }
}