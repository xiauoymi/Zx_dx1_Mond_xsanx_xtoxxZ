package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ParentWorstCaseCalculatorImpl_UT extends HIATUnitTest {
  public void testNoParentsNullResult() throws Exception {
    MockParentPairComparator parentPairComparator = new MockParentPairComparator();
    Calculator<ParentPairCollection, ParentPair> worstCaseCalc = new ParentWorstCaseCalculatorImpl(parentPairComparator);
    ParentPair result = worstCaseCalc.calculate(new ParentPairCollection(new ArrayList<ParentPair>(0)));
    assertNull(result);
  }

  public void testOneParentThatParentIsTheResult() throws Exception {
    MockParentPairComparator parentPairComparator = new MockParentPairComparator();
    ParentPair testPair1 = new ParentPair(new MockProduct(1L), new MockProduct(2L));
    parentPairComparator.addOrdering(testPair1);
    Calculator<ParentPairCollection, ParentPair> worstCaseCalc = new ParentWorstCaseCalculatorImpl(parentPairComparator);
    Collection<ParentPair> testParents = new ArrayList<ParentPair>();
    testParents.add(testPair1);
    ParentPair result = worstCaseCalc.calculate(new ParentPairCollection(testParents));
    assertEquals(testPair1, result);
  }

  public void testMultipleParentsWorstCommDateIsSelected() throws Exception {
    MockParentPairComparator parentPairComparator = new MockParentPairComparator();
    ParentPair testPair1 = new ParentPair(new MockProduct(11L), new MockProduct(4L));
    ParentPair testPair2 = new ParentPair(new MockProduct(3L), new MockProduct(1L));
    ParentPair testPair3 = new ParentPair(new MockProduct(4L), new MockProduct(1L));
    ParentPair testPair4 = new ParentPair(new MockProduct(5L), new MockProduct(2L));
    parentPairComparator.addOrdering(testPair1);
    parentPairComparator.addOrdering(testPair2);
    parentPairComparator.addOrdering(testPair3);
    parentPairComparator.addOrdering(testPair4);
    Calculator<ParentPairCollection, ParentPair> worstCaseCalc = new ParentWorstCaseCalculatorImpl(parentPairComparator);
    Collection<ParentPair> testParents = new ArrayList<ParentPair>();
    testParents.add(testPair3);
    testParents.add(testPair4);
    testParents.add(testPair1);
    testParents.add(testPair2);
    ParentPair result = worstCaseCalc.calculate(new ParentPairCollection(testParents));
    assertNotNull(result);
    assertEquals(testPair4, result);
  }

  public static class MockParentPairComparator implements Comparator<ParentPair> {
    private List<ParentPair> pairs = new ArrayList<ParentPair>();

    public void addOrdering(ParentPair pair) {
      pairs.add(pair);
    }
    public int compare(ParentPair o1, ParentPair o2) {
      return pairs.indexOf(o1) - pairs.indexOf(o2);
    }
  }
}