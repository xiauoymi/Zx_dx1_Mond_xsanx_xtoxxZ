package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.ProductionEntry;
import com.monsanto.eas.hiat.model.hibernate.ProductionEntryImpl;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.service.InventoryService;
import com.monsanto.eas.hiat.service.MockProductService;
import com.monsanto.eas.hiat.service.ProductionService;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import com.monsanto.eas.hiat.util.CollectionUtil;

import java.util.*;

public class ProductStatusFilter_UT extends HIATUnitTest {
  private static final Product TEST_BASE_PRODUCT = new MockProduct(1L);
  private static final Trait TEST_TRAIT = new MockTrait(1L);

  private MockProductService prodService;
  private MockInventoryServiceByProduct invService;
  private MockProductionServiceByProduct productionService;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    prodService = new MockProductService();
    prodService.add(TEST_BASE_PRODUCT);
    invService = new MockInventoryServiceByProduct();
    productionService = new MockProductionServiceByProduct();
  }

  public void testNoParentsNoResults() throws Exception {
    Calculator<ProductTraitPair, Collection<Product>> parentsCalculator = new ProductStatusFilter(prodService, invService, productionService);
    Collection<Product> filteredProducts = parentsCalculator.calculate(new ProductTraitPair(TEST_BASE_PRODUCT, TEST_TRAIT));
    assertNotNull(filteredProducts);
    assertTrue(filteredProducts.isEmpty());
  }

  public void testSingleActiveParentsWithResults() throws Exception {
    Product testProduct = new MockProduct(3L, "MOCK", TEST_TRAIT, null, null, null, null, false, TEST_BASE_PRODUCT, "Active", false);
    prodService.add(testProduct);
    prodService.addMapping(TEST_BASE_PRODUCT, TEST_TRAIT, testProduct);
    Calculator<ProductTraitPair, Collection<Product>> parentsCalculator = new ProductStatusFilter(prodService, invService, productionService);
    Collection<Product> filteredProducts = parentsCalculator.calculate(new ProductTraitPair(TEST_BASE_PRODUCT, TEST_TRAIT));
    assertNotNull(filteredProducts);
    assertEquals(1, filteredProducts.size());
    Product resultProduct = filteredProducts.iterator().next();
    assertEquals(testProduct, resultProduct);
  }

  public void testInactiveParentIsIgnored() throws Exception {
    Product testProduct = new MockProduct(4L, "MOCK", TEST_TRAIT, null, null, null, null, false, TEST_BASE_PRODUCT, "Inactive", false);
    prodService.add(testProduct);
    prodService.addMapping(TEST_BASE_PRODUCT, TEST_TRAIT, testProduct);
    Calculator<ProductTraitPair, Collection<Product>> parentsCalculator = new ProductStatusFilter(prodService, invService, productionService);
    Collection<Product> filteredProducts = parentsCalculator.calculate(new ProductTraitPair(TEST_BASE_PRODUCT, TEST_TRAIT));
    assertNotNull(filteredProducts);
    assertTrue(filteredProducts.isEmpty());
  }

  public void testSinglePrimaryParentsWithResults() throws Exception {
    Product testProduct = new MockProduct(3L, "MOCK", TEST_TRAIT, null, null, null, null, true, TEST_BASE_PRODUCT, "Primary", false);
    prodService.add(testProduct);
    prodService.addMapping(TEST_BASE_PRODUCT, TEST_TRAIT, testProduct);
    Calculator<ProductTraitPair, Collection<Product>> parentsCalculator = new ProductStatusFilter(prodService, invService, productionService);
    Collection<Product> filteredProducts = parentsCalculator.calculate(new ProductTraitPair(TEST_BASE_PRODUCT, TEST_TRAIT));
    assertNotNull(filteredProducts);
    assertEquals(1, filteredProducts.size());
    Product resultProduct = filteredProducts.iterator().next();
    assertEquals(testProduct, resultProduct);
  }

  public void testMultipleActivesHasMultipleResults() throws Exception {
    Product testProduct1 = new MockProduct(3L, "MOCK", TEST_TRAIT, null, null, null, null, false, TEST_BASE_PRODUCT, "Active2", false);
    Product testProduct2 = new MockProduct(5L, "MOCK", TEST_TRAIT, null, null, null, null, false, TEST_BASE_PRODUCT, "Active", false);
    Product testProduct3 = new MockProduct(6L, "MOCK", TEST_TRAIT, null, null, null, null, false, TEST_BASE_PRODUCT, "Active", false);
    prodService.add(testProduct1);
    prodService.add(testProduct2);
    prodService.add(testProduct3);
    prodService.addMapping(TEST_BASE_PRODUCT, TEST_TRAIT, testProduct1);
    prodService.addMapping(TEST_BASE_PRODUCT, TEST_TRAIT, testProduct2);
    prodService.addMapping(TEST_BASE_PRODUCT, TEST_TRAIT, testProduct3);
    Calculator<ProductTraitPair, Collection<Product>> parentsCalculator = new ProductStatusFilter(prodService, invService, productionService);
    Collection<Product> filteredProducts = parentsCalculator.calculate(new ProductTraitPair(TEST_BASE_PRODUCT, TEST_TRAIT));
    assertNotNull(filteredProducts);
    assertEquals(3, filteredProducts.size());
    assertTrue(filteredProducts.contains(testProduct1));
    assertTrue(filteredProducts.contains(testProduct2));
    assertTrue(filteredProducts.contains(testProduct3));
  }

  public void testMultipleActivesSomeWithG0G1G2InvOnlyThoseAreCounted() throws Exception {
    Product testProduct1 = new MockProduct(3L, "MOCK", TEST_TRAIT, null, null, null, null, false, TEST_BASE_PRODUCT, "Active2", false);
    Product testProduct2 = new MockProduct(5L, "MOCK", TEST_TRAIT, null, null, null, null, false, TEST_BASE_PRODUCT, "Active", false);
    Product testProduct3 = new MockProduct(6L, "MOCK", TEST_TRAIT, null, null, null, null, false, TEST_BASE_PRODUCT, "Active", false);
    prodService.add(testProduct1);
    prodService.add(testProduct2);
    prodService.add(testProduct3);
    prodService.addMapping(TEST_BASE_PRODUCT, TEST_TRAIT, testProduct1);
    prodService.addMapping(TEST_BASE_PRODUCT, TEST_TRAIT, testProduct2);
    prodService.addMapping(TEST_BASE_PRODUCT, TEST_TRAIT, testProduct3);
    invService.addMapping(testProduct1, InventoryType.PREFOUNDATION, 1234L);
    invService.addMapping(testProduct3, InventoryType.GENERATION_2, 1234L);
    Calculator<ProductTraitPair, Collection<Product>> parentsCalculator = new ProductStatusFilter(prodService, invService, productionService);
    Collection<Product> filteredProducts = parentsCalculator.calculate(new ProductTraitPair(TEST_BASE_PRODUCT, TEST_TRAIT));
    assertNotNull(filteredProducts);
    assertEquals(2, filteredProducts.size());
    assertTrue(filteredProducts.contains(testProduct1));
    assertTrue(filteredProducts.contains(testProduct3));
  }
  public void testMultipleActivesSomeWithG0G1G2ProductionOnlyThoseAreCounted() throws Exception {
    Product testProduct1 = new MockProduct(3L, "MOCK", TEST_TRAIT, null, null, null, null, false, TEST_BASE_PRODUCT, "Active2", false);
    Product testProduct2 = new MockProduct(5L, "MOCK", TEST_TRAIT, null, null, null, null, false, TEST_BASE_PRODUCT, "Active", false);
    Product testProduct3 = new MockProduct(6L, "MOCK", TEST_TRAIT, null, null, null, null, false, TEST_BASE_PRODUCT, "Active", false);
    prodService.add(testProduct1);
    prodService.add(testProduct2);
    prodService.add(testProduct3);
    prodService.addMapping(TEST_BASE_PRODUCT, TEST_TRAIT, testProduct1);
    prodService.addMapping(TEST_BASE_PRODUCT, TEST_TRAIT, testProduct2);
    prodService.addMapping(TEST_BASE_PRODUCT, TEST_TRAIT, testProduct3);
    productionService.addMapping(testProduct1, InventoryType.PREFOUNDATION, 1234L);
    productionService.addMapping(testProduct3, InventoryType.GENERATION_2, 1234L);
    Calculator<ProductTraitPair, Collection<Product>> parentsCalculator = new ProductStatusFilter(prodService, invService, productionService);
    Collection<Product> filteredProducts = parentsCalculator.calculate(new ProductTraitPair(TEST_BASE_PRODUCT, TEST_TRAIT));
    assertNotNull(filteredProducts);
    assertEquals(2, filteredProducts.size());
    assertTrue(filteredProducts.contains(testProduct1));
    assertTrue(filteredProducts.contains(testProduct3));
  }

  private static class MockInventoryServiceByProduct implements InventoryService {
    private final Map<String, Long> qtyMap = new HashMap<String, Long>();

    public long getInventory(Product product, InventoryType invType) {
      Long qty = qtyMap.get(getKey(product, invType));
      return (qty == null) ? 0 : qty;
    }

    public void addMapping(Product product, InventoryType invType, long qty) {
      qtyMap.put(getKey(product, invType), qty);
    }

    private String getKey(Product product, InventoryType invType) {
      return product.getId().toString() + "@" + invType.getCode();
    }
  }

  private static class MockProductionServiceByProduct implements ProductionService {
    private final Map<String, Long> qtyMap = new HashMap<String, Long>();

    public void addMapping(Product product, InventoryType invType, long qty) {
      qtyMap.put(getKey(product, invType), qty);
    }

    private String getKey(Product product, InventoryType invType) {
      return product.getId().toString() + "@" + invType.getCode();
    }

    public Collection<ProductionEntry> findByProduct(Product product, InventoryType invType) {
      Long qty = qtyMap.get(getKey(product, invType));
      if (qty == null) {
        return new LinkedList<ProductionEntry>();
      } else {
        return CollectionUtil.singleItemAsCollection((ProductionEntry) new ProductionEntryImpl(new Date(), product, qty, invType, true));
      }
    }
  }

}
