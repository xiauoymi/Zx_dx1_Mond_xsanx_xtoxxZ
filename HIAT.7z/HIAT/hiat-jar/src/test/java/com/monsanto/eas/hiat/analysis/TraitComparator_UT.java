/*
 TraitComparator_UT was created on Apr 23, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.analysis;

import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.hibernate.TraitImpl;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class TraitComparator_UT extends HIATUnitTest {

  public void testCompareDetailsBasedOnTraitCode_DifferentTraits() throws Exception {
    Product product1 = new ProductImpl();
    Trait trait1 = new TraitImpl(1L, "XYZ", "XX-YY-ZZ", "VT3P", null, true);
    Trait trait2 = new TraitImpl(2L, "CONV", "CONV", "CONV", null, true);
    InbredStatusDetail detail1 = new InbredStatusDetailImpl(trait1, product1, new Date(), new Date(),
        new HashMap<InventoryType, InventoryEntry>(), new HashMap<InventoryType, Collection<ProductionEntry>>(),
            new HashMap<InventoryType, Collection<ProductionEntry>>());
    InbredStatusDetail detail2 = new InbredStatusDetailImpl(trait2, product1, new Date(), new Date(),
        new HashMap<InventoryType, InventoryEntry>(), new HashMap<InventoryType, Collection<ProductionEntry>>(),
            new HashMap<InventoryType, Collection<ProductionEntry>>());
    TraitComparator comparator = new TraitComparator();
    assertTrue(comparator.compare(detail1, detail2) > 0);
    assertTrue(comparator.compare(detail2, detail1) < 0);
  }
  
  public void testCompareDetailsBasedOnTraitCode_SameTraits() throws Exception {
    Product product1 = new ProductImpl();
    Trait trait1 = new TraitImpl(1L, "CONV", "CONV", "CONV", null, true);
    Trait trait2 = new TraitImpl(2L, "CONV", "CONV", "CONV", null, true);
    InbredStatusDetail detail1 = new InbredStatusDetailImpl(trait1, product1, new Date(), new Date(),
        new HashMap<InventoryType, InventoryEntry>(), new HashMap<InventoryType, Collection<ProductionEntry>>(),
            new HashMap<InventoryType, Collection<ProductionEntry>>());
    InbredStatusDetail detail2 = new InbredStatusDetailImpl(trait2, product1, new Date(), new Date(),
        new HashMap<InventoryType, InventoryEntry>(), new HashMap<InventoryType, Collection<ProductionEntry>>(),
            new HashMap<InventoryType, Collection<ProductionEntry>>());
    TraitComparator comparator = new TraitComparator();
    assertTrue(comparator.compare(detail1, detail2) == 0);
  }
}