package com.monsanto.eas.hiat.audit;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.hibernate.mock.MockDAO;
import junit.framework.TestCase;

import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class LoggingUseCaseController_UT extends TestCase {
  public void testControllerIsCalled_BaseControllerIsRanAndRequestIsLogged() throws Exception {
    MockController mockController = new MockController();
    MockDAO<Request, Long> mockRequestDAO = new MockDAO<Request, Long>();
    UseCaseController controller = new LoggingUseCaseController(mockController, mockRequestDAO);
    String testUser = "IMATEST";
    UCCHelper helper = new MockUCCHelperForUsername(testUser);
    controller.run(helper);

    assertTrue(mockController.wasRan());
    assertEquals(1, mockRequestDAO.getNumSaved());
  }

  private static class MockController implements UseCaseController {
    private boolean wasRan = false;

    public void run(UCCHelper helper) throws IOException {
      wasRan = true;
    }

    public boolean wasRan() {
      return wasRan;
    }
  }

  private static class MockUCCHelperForUsername extends MockUCCHelper {
    private final String userId;

    public MockUCCHelperForUsername(String userId) {
      super("MOCK");
      this.userId = userId;
    }

    @Override
    public String getAuthenticatedUserID() {
      return userId;
    }

    @Override
    public String getAuthenticatedUserFullName() {
      return userId;
    }

    @Override
    public String getAuthenticatedUserDomain() {
      return "MOCK";
    }
  }
}