package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.config.HIATConfigurationFactory;
import junit.framework.Assert;

import java.util.Calendar;
import java.util.Date;
import java.util.Random;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class AvailDateTestUtil {
  private static final int MILLISEC_PER_DAY = 1000 * 60 * 60 * 24;
  public static final int MIN_DATE_OFFSET = 365;
  public static final int MAX_DATE_OFFSET = 7000;
  public static final Random rand = new Random();
  public static final String TEST_DATE_SOURCE = "Test Date";

  public static AvailabilityDate getNow() {
      return new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date(), false);
  }

  public static AvailabilityDate addMonth(AvailabilityDate availDate, int months) {
    Date adjustedRawDate = org.apache.commons.lang.time.DateUtils.addMonths(availDate.getExactDate(), months);
      return new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, adjustedRawDate, true);
  }

  public static AvailabilityDate subtractGeneration(AvailabilityDate availDate) {
    int daysOffset = -HIATConfigurationFactory.getConfiguration().getDaysBetweenGenerations();
    Date rawAdjustedDate = org.apache.commons.lang.time.DateUtils.addDays(availDate.getExactDate(), daysOffset);
      return new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, rawAdjustedDate, true);
  }

  public static AvailabilityDate getRandomFutureDate() {
      return new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, randomFutureDate(), false);
  }

  public static AvailabilityDate getRandomPastDate() {
      return new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, randomPastDate(), false);
  }

  public static void assertDateOnOrBefore(Date expectedDate, Date actualDate) {
      Assert.assertNotNull("Expected date on or before " + expectedDate + ", but was null", actualDate);
    Assert.assertTrue("Expected date on or before " + expectedDate + ", but was: " + actualDate, !org.apache.commons.lang.time.DateUtils.truncate(actualDate, Calendar.DATE).after(org.apache.commons.lang.time.DateUtils.truncate(expectedDate, Calendar.DATE)));
  }

  public static void assertDateOnOrBefore(AvailabilityDate expectedDate, AvailabilityDate actualDate) {
      assertDateOnOrBefore(expectedDate.getExactDate(), actualDate.getExactDate());
  }

  public static void assertDateEquals(AvailabilityDate expectedDate, AvailabilityDate actualDate) {
      if (expectedDate == null) {
          Assert.assertNull(actualDate);
      } else {
          Assert.assertNotNull("Expected " + expectedDate + ", but was null", actualDate);
          assertDateEquals(expectedDate.getExactDate(), actualDate.getExactDate());
      }
  }

  public static void assertDateEquals(Date expectedDate, Date actualDate) {
    Date expDate = org.apache.commons.lang.time.DateUtils.truncate(expectedDate, Calendar.DATE);
      Assert.assertNotNull("Expected date of " + expDate + ", but was null", actualDate);

    Date actDate = org.apache.commons.lang.time.DateUtils.truncate(actualDate, Calendar.DATE);
      Assert.assertTrue("Expected date of " + expDate + ", but was " + actDate,
              actDate.equals(expDate));
  }

  public static void assertDateOnOrBeforeToday(AvailabilityDate date) {
      Assert.assertNotNull("Expected on or before today, but was null", date);
      assertDateOnOrBeforeToday(date.getExactDate());
  }

  public static void assertDateOnOrBeforeToday(Date date) {
      assertDateOnOrBefore(new Date(), date);
  }

  public static Date randomFutureDate() {
    return org.apache.commons.lang.time.DateUtils.truncate(new Date(new Date().getTime() + getRandomDateOffset(MIN_DATE_OFFSET, MAX_DATE_OFFSET)), Calendar.DATE);
  }

  public static Date randomPastDate() {
    return org.apache.commons.lang.time.DateUtils.truncate(new Date(new Date().getTime() - getRandomDateOffset(MIN_DATE_OFFSET, MAX_DATE_OFFSET)), Calendar.DATE);
  }

  private static long getRandomDateOffset(int minDays, int maxDays) {
      return ((long) minDays + (long) AvailDateTestUtil.rand.nextInt(maxDays - minDays)) * MILLISEC_PER_DAY;
  }
}
