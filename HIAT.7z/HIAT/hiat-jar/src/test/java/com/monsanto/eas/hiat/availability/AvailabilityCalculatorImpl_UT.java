package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.util.HIATUnitTest;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class AvailabilityCalculatorImpl_UT extends HIATUnitTest {
  private static final AvailabilityDate TEST_GEN_0_DATE = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, AvailDateTestUtil.randomFutureDate(), false);
  private static final AvailabilityDate TEST_GEN_1_DATE = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, AvailDateTestUtil.randomFutureDate(), false);
  private static final AvailabilityDate TEST_GEN_2_DATE = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, AvailDateTestUtil.randomFutureDate(), false);

  public void testEachGenerationDateComesFromCorrectCalculator() throws Exception {
    Calculator<Product, InbredAvailabilityInformation> calc = new InbredAvailabilityCalculatorImpl(
            new MockGenerationAvailabilityCalculator(TEST_GEN_0_DATE),
            new MockGenerationAvailabilityCalculator(TEST_GEN_1_DATE),
            new MockGenerationAvailabilityCalculator(TEST_GEN_2_DATE)
    );

    InbredAvailabilityInformation availInfo = calc.calculate(new MockProduct(1L));
    assertNotNull(availInfo);
    assertEquals(TEST_GEN_0_DATE, availInfo.getG0Date());
    assertEquals(TEST_GEN_1_DATE, availInfo.getG1Date());
    assertEquals(TEST_GEN_2_DATE, availInfo.getG2Date());
  }

  public void testExceptionThrowThrowsNotAvailableDateForOnlyBadCalculator() throws Exception {
    Calculator<Product, InbredAvailabilityInformation> calc = new InbredAvailabilityCalculatorImpl(
            new MockGenerationAvailabilityCalculator(TEST_GEN_0_DATE),
            new MockGenerationAvailabilityCalculatorForException(),
            new MockGenerationAvailabilityCalculator(TEST_GEN_2_DATE)
    );

    InbredAvailabilityInformation availInfo = calc.calculate(new MockProduct(1L));
    assertNotNull(availInfo);
    assertEquals(TEST_GEN_0_DATE, availInfo.getG0Date());
    assertEquals(AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE), availInfo.getG1Date());
    assertEquals(TEST_GEN_2_DATE, availInfo.getG2Date());
  }

  private static class MockGenerationAvailabilityCalculatorForException implements GenerationAvailabilityCalculator {
    public AvailabilityDate getAvailability(Product product) {
      throw new RuntimeException("MOCK");
    }
  }
}