package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.util.DateTestUtil;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class AvailabilityDate_UT extends HIATUnitTest {
  public void testExactDateIsTruncatedToDateOnlyAndPreserved() throws Exception {
    Date testDate = new Date();
    AvailabilityDate availDate = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate);
    assertEquals(org.apache.commons.lang.time.DateUtils.truncate(testDate, Calendar.DATE), availDate.getExactDate());
  }

  public void testDerivivedDateHasSuffix() throws Exception {
    AvailabilityDate availDate = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date(), true);
    String dateSt = availDate.toString();
    assertNotNull(dateSt);
    assertTrue(!dateSt.contains(AvailabilityDateImpl.DERIVIVED_DATE_SUFFIX));
  }

  public void testDifferentObjectsWithEqualDatesAreEqual() throws Exception {
    Date testDate1 = new GregorianCalendar(2209, Calendar.JANUARY, 1).getTime();
    Date testDate2 = new GregorianCalendar(2209, Calendar.JANUARY, 1).getTime();
    assertEquals("This test is defective - this was just to to verify the two equal dates were actually equal", testDate1, testDate2);

    AvailabilityDate testAvailDate1 = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate1);
    AvailabilityDate testAvailDate2 = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate2);
    assertEquals(testAvailDate1, testAvailDate2);
    assertEquals(testAvailDate1.hashCode(), testAvailDate2.hashCode());
  }

  public void testDifferentDatesAreDifferent() throws Exception {
    Date testDate1 = new GregorianCalendar(2209, Calendar.JANUARY, 1).getTime();
    Date testDate2 = new GregorianCalendar(2209, Calendar.MARCH, 1).getTime();

    AvailabilityDate testAvailDate1 = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate1);
    AvailabilityDate testAvailDate2 = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate2);
    AvailabilityDate testAvailDate3 = AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE);
    AvailabilityDate testAvailDate4 = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, null);
    assertFalse(testAvailDate1.equals(testAvailDate2));
    assertFalse(testAvailDate2.equals(testAvailDate1));
    assertFalse(testAvailDate1.equals(testAvailDate3));
    assertFalse(testAvailDate3.equals(testAvailDate1));
    assertEquals(testAvailDate3, testAvailDate4);
    assertEquals(testAvailDate3.hashCode(), testAvailDate4.hashCode());
  }

  public void testToStringIsAvailIfDateIsTodayOrPast() throws Exception {
    AvailabilityDate today = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date());
    Date testDate = new GregorianCalendar(2001, Calendar.JANUARY, 2).getTime(); // you'll need to update this test in 2100, otherwise it will start failing :-)
    AvailabilityDate testAvailDate = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate);
    assertEquals(AvailabilityDateImpl.AVAILABLE_STRING, today.toString());
    assertEquals(AvailabilityDateImpl.AVAILABLE_STRING, testAvailDate.toString());
  }

  public void testToStringIsMMM_YY() throws Exception {
    Date testDate = new GregorianCalendar(2099, Calendar.JANUARY, 2).getTime(); // you'll need to update this test in 2100, otherwise it will start failing :-)
    AvailabilityDate testAvailDate = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate);
    assertEquals("Jan-99", testAvailDate.toString());
  }

  public void testDateInThePastCausesCurrentDateToBeUsedForCalculatedDate() throws Exception {
    Date testDate = new GregorianCalendar(1999, Calendar.JANUARY, 2).getTime();
    AvailabilityDate testAvailDate = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate);
    AvailabilityDate todayAvailDate = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date());
    AvailabilityDate testCalcDate = testAvailDate.addGeneration();
    AvailabilityDate testCalcDateFromToday = todayAvailDate.addGeneration();
    DateTestUtil.assertDatesEqual(testCalcDateFromToday, testCalcDate);
  }

  public void testDateTraceBack() throws Exception {
    Date testDate = new GregorianCalendar(2099, Calendar.JANUARY, 2).getTime(); // you'll need to update this test in 2100, otherwise it will start failing :-)
    String testDateReasonString = "testing date traceback";
    AvailabilityDate directDate = new AvailabilityDateImpl(testDateReasonString, testDate);
    AvailabilityDate derivedDate = directDate.addGeneration();

    String traceBackString = directDate.getTraceBack();
    assertTrue("Expected '" + traceBackString + "' to contain '" + testDateReasonString + "'", traceBackString.contains(testDateReasonString));
    assertTrue("Expected '" + traceBackString + "' to contain ':'", traceBackString.contains(":"));
    String dateString = new SimpleDateFormat(AvailabilityDateImpl.TRACEBACK_DATE_FORMAT_STRING).format(testDate);
    assertTrue("Expected '" + traceBackString + "' to contain '" + dateString + "'", traceBackString.contains(testDateReasonString));

    String deriviedTraceBackString = derivedDate.getTraceBack();
    assertTrue("Expected '" + deriviedTraceBackString + "' to contain '" + traceBackString + "'", deriviedTraceBackString.contains(traceBackString));
    assertTrue("Expected '" + deriviedTraceBackString + "' to contain '+'", deriviedTraceBackString.contains("+"));
  }

}