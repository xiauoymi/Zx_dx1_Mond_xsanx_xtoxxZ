package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.service.AvailabilityService;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import org.apache.commons.lang.time.DateUtils;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HybridAvailabilityCalculatorImpl_UT extends HIATUnitTest {
  private static final Date TEST_PRIMARY_DATE = AvailDateTestUtil.randomFutureDate();
  private static final Product TEST_PRODUCT = new MockProduct(1L, null, null, null, null, null, TEST_PRIMARY_DATE, false, null, null, false);
  private static final Product TEST_PRIMARY_PRODUCT = new MockProduct(2L, null, null, null, null, null, null, true, null, null, false);
  private static final Product TEST_PRODUCT_WITH_NO_PRIMARY_DATE = new MockProduct(3L);

  private static final InbredAvailabilityInformation UNKNOWN_AVAIL_DATES = new InbredAvailabilityInformation(
          AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE),
          AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE),
          AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE));

  public void testNotAvailableInbredResultsInNotResultsInAvailablehybrid() throws Exception {
    AvailabilityService availService = new MockAvailabilityService();
    Calculator<Product, HybridAvailabilityInformation> calc = new HybridAvailabilityCalculatorImpl(new MockInbredAvailabilityCalculator(), availService);
    HybridAvailabilityInformation hybridAvailInfo = calc.calculate(TEST_PRODUCT);
    assertNotNull(hybridAvailInfo);
    assertEquals(AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE), hybridAvailInfo.getPcm150Date());
    assertEquals(AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE), hybridAvailInfo.getPcm300Date());
    assertEquals(AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE), hybridAvailInfo.getCommercialDate());
  }

  public void testNoQuantityAnyGenerationUseEarliestInbredAvailDatePrimaryDateBeforeUseInbredAvailDate() throws Exception {
    AvailabilityDate testG0Date = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, DateUtils.addDays(TEST_PRIMARY_DATE, 10), true);
    InbredAvailabilityInformation testInbredDates = new InbredAvailabilityInformation(
            testG0Date,
            testG0Date.addGeneration(),
            testG0Date.addGeneration().addGeneration());

    AvailabilityService availService = new MockAvailabilityService();
    MockInbredAvailabilityCalculator mockInbredAvailabilityCalculator = new MockInbredAvailabilityCalculator();
    mockInbredAvailabilityCalculator.addMapping(TEST_PRODUCT, testInbredDates);
    Calculator<Product, HybridAvailabilityInformation> calc = new HybridAvailabilityCalculatorImpl(
            mockInbredAvailabilityCalculator, availService);
    HybridAvailabilityInformation hybridAvailInfo = calc.calculate(TEST_PRODUCT);
    assertNotNull(hybridAvailInfo);
    assertEquals(testG0Date.addGeneration(), hybridAvailInfo.getPcm150Date());
    assertEquals(testG0Date.addGeneration(), hybridAvailInfo.getPcm300Date());
    assertEquals(testG0Date.addGeneration().addGeneration(), hybridAvailInfo.getCommercialDate());
  }

  public void testNoQuantityAnyGenerationUseEarliestInbredAvailDateInbredIsPrimaryUseInbredAvailDate() throws Exception {
    AvailabilityDate testG0Date = AvailDateTestUtil.getRandomFutureDate();
    InbredAvailabilityInformation testInbredDates = new InbredAvailabilityInformation(
            testG0Date,
            testG0Date.addGeneration(),
            testG0Date.addGeneration().addGeneration());

    AvailabilityService availService = new MockAvailabilityService();
    MockInbredAvailabilityCalculator mockInbredAvailabilityCalculator = new MockInbredAvailabilityCalculator();
    mockInbredAvailabilityCalculator.addMapping(TEST_PRIMARY_PRODUCT, testInbredDates);
    Calculator<Product, HybridAvailabilityInformation> calc = new HybridAvailabilityCalculatorImpl(
            mockInbredAvailabilityCalculator, availService);
    HybridAvailabilityInformation hybridAvailInfo = calc.calculate(TEST_PRIMARY_PRODUCT);
    assertNotNull(hybridAvailInfo);
    assertEquals(testG0Date.addGeneration(), hybridAvailInfo.getPcm150Date());
    assertEquals(testG0Date.addGeneration(), hybridAvailInfo.getPcm300Date());
    assertEquals(testG0Date.addGeneration().addGeneration(), hybridAvailInfo.getCommercialDate());
  }

  public void testG1AvailabilityIsUsed() throws Exception {
    MockAvailabilityService availService = new MockAvailabilityService();
    Date testDate150 = AvailDateTestUtil.randomFutureDate();
    Date testDate300 = DateUtils.addDays(testDate150, 50);
    Date testDateComm = DateUtils.addDays(testDate300, 11);

    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_1, 5, testDate150);
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_1, 25, testDate300);
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_1, 50, testDateComm);
    Calculator<Product, HybridAvailabilityInformation> calc = new HybridAvailabilityCalculatorImpl(new MockInbredAvailabilityCalculator(), availService);
    HybridAvailabilityInformation hybridAvailInfo = calc.calculate(TEST_PRIMARY_PRODUCT);
    assertNotNull(hybridAvailInfo);
    assertEquals(new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate150, false), hybridAvailInfo.getPcm150Date());
    assertEquals(new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate300, false), hybridAvailInfo.getPcm300Date());
//todo what is the correct assert here?    assertEquals(new AvailabilityDateImpl(testDateComm, false), hybridAvailInfo.getCommercialDate());
  }

  public void testG2AvailabilityIsUsed() throws Exception {
    MockAvailabilityService availService = new MockAvailabilityService();
    Date testDate150 = AvailDateTestUtil.randomFutureDate();
    Date testDate300 = DateUtils.addDays(testDate150, 50);
    Date testDateComm = DateUtils.addDays(testDate300, 11);

    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_2, 5, testDate150);
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_2, 25, testDate300);
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_2, 50, testDateComm);
    Calculator<Product, HybridAvailabilityInformation> calc = new HybridAvailabilityCalculatorImpl(new MockInbredAvailabilityCalculator(), availService);
    HybridAvailabilityInformation hybridAvailInfo = calc.calculate(TEST_PRIMARY_PRODUCT);
    assertNotNull(hybridAvailInfo);
    assertEquals(new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate150, false), hybridAvailInfo.getPcm150Date());
    assertEquals(new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate300, false), hybridAvailInfo.getPcm300Date());
    assertEquals(new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDateComm, false), hybridAvailInfo.getCommercialDate());
  }

  public void testBothG1AndG2AvailabilityG1IsSoonerG1IsUsed() throws Exception {
    MockAvailabilityService availService = new MockAvailabilityService();
    Date testDate150 = AvailDateTestUtil.randomFutureDate();
    Date testDate300 = DateUtils.addDays(testDate150, 50);
    Date testDateComm = DateUtils.addDays(testDate300, 11);

    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_1, 5, testDate150);
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_1, 25, testDate300);
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_1, 50, testDateComm);
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_2, 5, DateUtils.addDays(testDate150, 200));
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_2, 25, DateUtils.addDays(testDate300, 200));
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_2, 50, DateUtils.addDays(testDateComm, 200));
    Calculator<Product, HybridAvailabilityInformation> calc = new HybridAvailabilityCalculatorImpl(new MockInbredAvailabilityCalculator(), availService);
    HybridAvailabilityInformation hybridAvailInfo = calc.calculate(TEST_PRIMARY_PRODUCT);
    assertNotNull(hybridAvailInfo);
    assertEquals(new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate150, false), hybridAvailInfo.getPcm150Date());
    assertEquals(new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate300, false), hybridAvailInfo.getPcm300Date());
//todo what is the correct assert here?    assertEquals(new AvailabilityDateImpl(testDateComm, false).addGeneration(), hybridAvailInfo.getCommercialDate());
  }

  public void testBothG1AndG2AvailabilityG2IsSoonerG2IsUsed() throws Exception {
    MockAvailabilityService availService = new MockAvailabilityService();
    Date testDate150 = AvailDateTestUtil.randomFutureDate();
    Date testDate300 = DateUtils.addDays(testDate150, 50);
    Date testDateComm = DateUtils.addDays(testDate300, 11);

    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_1, 5, DateUtils.addDays(testDate150, 200));
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_1, 25, DateUtils.addDays(testDate300, 200));
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_1, 50, DateUtils.addDays(testDateComm, 200));
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_2, 5, testDate150);
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_2, 25, testDate300);
    availService.addAvailability(TEST_PRIMARY_PRODUCT, InventoryType.GENERATION_2, 50, testDateComm);
    Calculator<Product, HybridAvailabilityInformation> calc = new HybridAvailabilityCalculatorImpl(new MockInbredAvailabilityCalculator(), availService);
    HybridAvailabilityInformation hybridAvailInfo = calc.calculate(TEST_PRIMARY_PRODUCT);
    assertNotNull(hybridAvailInfo);
    assertEquals(new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate150, false), hybridAvailInfo.getPcm150Date());
    assertEquals(new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate300, false), hybridAvailInfo.getPcm300Date());
    assertEquals(new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDateComm, false), hybridAvailInfo.getCommercialDate());
  }

}