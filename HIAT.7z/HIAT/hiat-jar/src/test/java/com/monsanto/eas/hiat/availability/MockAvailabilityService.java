package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.service.AvailabilityService;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class MockAvailabilityService implements AvailabilityService {
  private final Map<String, Date> availDates = new HashMap<String, Date>();

  public void addAvailability(Product product, InventoryType invType, long minimumQty, Date availDate) {
    availDates.put(getKey(product, invType, minimumQty), availDate);
  }

  public Date getInventoryAvailabilityDate(Product product, InventoryType invType, long minimumQty) {
    return availDates.get(getKey(product, invType, minimumQty));
  }

  private String getKey(Product product, InventoryType invType, long minimumQty) {
    return product.toString() + ":" + invType.toString() + ">" + minimumQty; 
  }
}
