package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.model.Product;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class MockGenerationAvailabilityCalculator implements GenerationAvailabilityCalculator {
  private final AvailabilityDate availDate;

  public MockGenerationAvailabilityCalculator(AvailabilityDate availDate) {
    this.availDate = availDate;
  }

  public AvailabilityDate getAvailability(Product product) {
    return availDate;
  }
}
