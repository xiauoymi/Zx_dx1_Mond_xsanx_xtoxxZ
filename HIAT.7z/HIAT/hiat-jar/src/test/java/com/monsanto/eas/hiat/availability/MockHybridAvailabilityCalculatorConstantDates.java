package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;

import java.util.Date;

public class MockHybridAvailabilityCalculatorConstantDates implements Calculator<Product, HybridAvailabilityInformation> {
  private final AvailabilityDate pcm150;
  private final AvailabilityDate pcm300;
  private final AvailabilityDate comm;

  public MockHybridAvailabilityCalculatorConstantDates() {
    this(getNow(), getNow(), getNow());
  }

  private static AvailabilityDate getNow() {
    return new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date(), false);
  }

  public MockHybridAvailabilityCalculatorConstantDates(AvailabilityDate pcm150, AvailabilityDate pcm300,
                                                       AvailabilityDate comm) {
    this.pcm150 = pcm150;
    this.pcm300 = pcm300;
    this.comm = comm;
  }

  public HybridAvailabilityInformation calculate(Product input) {
    return new HybridAvailabilityInformation(pcm150, pcm300, comm);
  }
}
