package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;

import java.util.HashMap;
import java.util.Map;

public class MockInbredAvailabilityCalculator implements Calculator<Product, InbredAvailabilityInformation> {
  private final Map<Product, InbredAvailabilityInformation> availMap = new HashMap<Product, InbredAvailabilityInformation>();

  public void addMapping(Product product, InbredAvailabilityInformation availInfo) {
    availMap.put(product, availInfo);
  }

  public InbredAvailabilityInformation calculate(Product product) {
    InbredAvailabilityInformation availInfo = availMap.get(product);
    if (availInfo == null) {
      return new InbredAvailabilityInformation(
              AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE),
              AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE),
              AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE)
      );
    } else {
      return availInfo;
    }
  }
}
