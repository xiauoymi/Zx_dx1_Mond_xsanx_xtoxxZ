package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Product;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockInbredAvailabilityCalculatorConstantDates implements Calculator<Product, InbredAvailabilityInformation> {
  private final AvailabilityDate g0;
  private final AvailabilityDate g1;
  private final AvailabilityDate g2;

  public MockInbredAvailabilityCalculatorConstantDates() {
    this(getNow(), getNow(), getNow());
  }

  private static AvailabilityDate getNow() {
    return new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date(), false);
  }

  public MockInbredAvailabilityCalculatorConstantDates(AvailabilityDate g0, AvailabilityDate g1, AvailabilityDate g2) {
    this.g0 = g0;
    this.g1 = g1;
    this.g2 = g2;
  }

  public InbredAvailabilityInformation calculate(Product product) {
    return new InbredAvailabilityInformation(g0, g1, g2);
  }
}

