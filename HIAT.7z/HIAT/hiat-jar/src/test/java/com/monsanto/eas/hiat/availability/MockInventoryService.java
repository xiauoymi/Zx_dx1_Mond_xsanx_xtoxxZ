package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.service.InventoryService;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class MockInventoryService implements InventoryService {
  private final long qty;

  public MockInventoryService(long qty) {
    this.qty = qty;
  }

  public long getInventory(Product product, InventoryType invType) {
    return qty;
  }
}
