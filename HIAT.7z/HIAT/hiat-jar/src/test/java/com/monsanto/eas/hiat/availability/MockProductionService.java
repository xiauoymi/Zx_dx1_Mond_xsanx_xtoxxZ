package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;
import com.monsanto.eas.hiat.service.ProductionService;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class MockProductionService implements ProductionService {
  private final Collection<ProductionEntry> production;

  public MockProductionService() {
    this(new ArrayList<ProductionEntry>(0));
  }

  public MockProductionService(Collection<ProductionEntry> production) {
    this.production = production;
  }

  public Collection<ProductionEntry> findByProduct(Product product, InventoryType invType) {
    return production;
  }
}
