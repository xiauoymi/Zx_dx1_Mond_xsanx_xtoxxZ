package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class SeasonCalculator_UT extends HIATUnitTest {
  private static final int TEST_YEAR = 2009;

  private static Date LASTYEAR_DATE = new GregorianCalendar(TEST_YEAR - 1, Calendar.JANUARY, 14).getTime();
  private static Date JANUARY_DATE = new GregorianCalendar(TEST_YEAR, Calendar.JANUARY, 14).getTime();
  private static Date JULY_DATE = new GregorianCalendar(TEST_YEAR, Calendar.JULY, 4).getTime();
  private static Date OCTOBER_DATE = new GregorianCalendar(TEST_YEAR, Calendar.OCTOBER, 11).getTime();
  private static Date NOVEMEBER_DATE = new GregorianCalendar(TEST_YEAR, Calendar.NOVEMBER, 11).getTime();

  private static ExpectedResults[] EXPECTED_RESULTS_FROM_TABLE = {
          new ExpectedResults(JANUARY_DATE, JANUARY_DATE, TEST_YEAR, GrowingSeason.SPRING),
          new ExpectedResults(JANUARY_DATE, JULY_DATE, TEST_YEAR, GrowingSeason.WINTER),
          new ExpectedResults(JANUARY_DATE, OCTOBER_DATE, TEST_YEAR, GrowingSeason.WINTER),
          new ExpectedResults(JANUARY_DATE, NOVEMEBER_DATE, TEST_YEAR + 1, GrowingSeason.SPRING),

          new ExpectedResults(JULY_DATE, JANUARY_DATE, TEST_YEAR, GrowingSeason.WINTER),
          new ExpectedResults(JULY_DATE, JULY_DATE, TEST_YEAR, GrowingSeason.WINTER),
          new ExpectedResults(JULY_DATE, OCTOBER_DATE, TEST_YEAR, GrowingSeason.WINTER),
          new ExpectedResults(JULY_DATE, NOVEMEBER_DATE, TEST_YEAR + 1, GrowingSeason.SPRING),

          new ExpectedResults(NOVEMEBER_DATE, JANUARY_DATE, TEST_YEAR + 1, GrowingSeason.SPRING),
          new ExpectedResults(NOVEMEBER_DATE, JULY_DATE, TEST_YEAR + 1, GrowingSeason.SPRING),
          new ExpectedResults(NOVEMEBER_DATE, OCTOBER_DATE, TEST_YEAR + 1, GrowingSeason.SPRING),
          new ExpectedResults(NOVEMEBER_DATE, NOVEMEBER_DATE, TEST_YEAR + 1, GrowingSeason.SPRING),

          new ExpectedResults(OCTOBER_DATE, JANUARY_DATE, TEST_YEAR + 1, GrowingSeason.SPRING),
          new ExpectedResults(OCTOBER_DATE, JULY_DATE, TEST_YEAR + 1, GrowingSeason.SPRING),
          new ExpectedResults(OCTOBER_DATE, OCTOBER_DATE, TEST_YEAR + 1, GrowingSeason.SPRING),
          new ExpectedResults(OCTOBER_DATE, NOVEMEBER_DATE, TEST_YEAR + 1, GrowingSeason.SPRING),

          new ExpectedResults(LASTYEAR_DATE, JANUARY_DATE, TEST_YEAR, GrowingSeason.SPRING),
          new ExpectedResults(LASTYEAR_DATE, JULY_DATE, TEST_YEAR, GrowingSeason.WINTER),
          new ExpectedResults(LASTYEAR_DATE, OCTOBER_DATE, TEST_YEAR, GrowingSeason.WINTER),
          new ExpectedResults(LASTYEAR_DATE, NOVEMEBER_DATE, TEST_YEAR + 1, GrowingSeason.SPRING),

          new ExpectedResults(JANUARY_DATE, LASTYEAR_DATE, TEST_YEAR, GrowingSeason.SPRING),
          new ExpectedResults(JULY_DATE, LASTYEAR_DATE, TEST_YEAR, GrowingSeason.WINTER),
          new ExpectedResults(OCTOBER_DATE, LASTYEAR_DATE, TEST_YEAR + 1, GrowingSeason.SPRING),
          new ExpectedResults(NOVEMEBER_DATE, LASTYEAR_DATE, TEST_YEAR + 1, GrowingSeason.SPRING)
  };

  public void testAvailabilityDatesFromTable() throws Exception {
    SeasonCalculator calculator = new SeasonCalculator();
    for (ExpectedResults expectedResult : EXPECTED_RESULTS_FROM_TABLE) {
      Date seedAvailDate = expectedResult.getSeedAvailabilityDate();
      Date primaryTestingDate = expectedResult.getPrimaryTestingDate();
      GrowingSeason expectedSeason = expectedResult.getExpectedSeason();
      int expectedYear = expectedResult.getExpectedYear();

      String failureMessage = "checking seedAvailabilityDate:" + seedAvailDate +
              " and primaryTestingDate:" + primaryTestingDate;

      Season season = calculator.calculateSeason(seedAvailDate, primaryTestingDate);
      assertEquals(failureMessage, expectedSeason, season.getGrowingSeason());
      assertEquals(failureMessage, expectedYear, season.getYear());
    }
  }

  public void testPrimaryProductDateBeforeSpringCutoffIsSpringThisYear() throws Exception {
    Date testDate = new GregorianCalendar(TEST_YEAR, Calendar.FEBRUARY, 14).getTime();
    Season season = new SeasonCalculator().calculateSeasonForPrimaryCommercial(testDate);
    assertEquals(TEST_YEAR, season.getYear());
    assertEquals(GrowingSeason.SPRING, season.getGrowingSeason());
  }

  public void testPrimaryProductDateAfterSpringCutoffButBeforeWinterCutoffIsWinterThisYear() throws Exception {
    Date testDate = new GregorianCalendar(TEST_YEAR, Calendar.AUGUST, 8).getTime();
    Season season = new SeasonCalculator().calculateSeasonForPrimaryCommercial(testDate);
    assertEquals(TEST_YEAR, season.getYear());
    assertEquals(GrowingSeason.WINTER, season.getGrowingSeason());
  }

  public void testPrimaryProductDateAfterWinterCutoffIsSpringNextYear() throws Exception {
    Date testDate = new GregorianCalendar(TEST_YEAR, Calendar.DECEMBER, 25).getTime();
    Season season = new SeasonCalculator().calculateSeasonForPrimaryCommercial(testDate);
    assertEquals(TEST_YEAR + 1, season.getYear());
    assertEquals(GrowingSeason.SPRING, season.getGrowingSeason());
  }

  public void testPrimaryProductDateOnSpringCutoffDateIsWinterthisYear() throws Exception {
    Date testDate = SeasonCalculator.getSpringCutoffDate(TEST_YEAR);
    Season season = new SeasonCalculator().calculateSeasonForPrimaryCommercial(testDate);
    assertEquals(TEST_YEAR, season.getYear());
    assertEquals(GrowingSeason.WINTER, season.getGrowingSeason());
  }

  private static class ExpectedResults {
    private Date seedAvailabilityDate;
    private Date primaryTestingDate;
    private int expectedYear;
    private GrowingSeason expectedSeason;

    private ExpectedResults(Date seedAvailabilityDate, Date primaryTestingDate, int expectedYear, GrowingSeason expectedSeason) {
      this.seedAvailabilityDate = seedAvailabilityDate;
      this.primaryTestingDate = primaryTestingDate;
      this.expectedYear = expectedYear;
      this.expectedSeason = expectedSeason;
    }

    public Date getSeedAvailabilityDate() {
      return seedAvailabilityDate;
    }

    public Date getPrimaryTestingDate() {
      return primaryTestingDate;
    }

    public int getExpectedYear() {
      return expectedYear;
    }

    public GrowingSeason getExpectedSeason() {
      return expectedSeason;
    }
  }

}