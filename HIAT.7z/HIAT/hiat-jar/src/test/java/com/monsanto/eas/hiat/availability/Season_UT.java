package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.util.HIATUnitTest;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class Season_UT extends HIATUnitTest {
  @SuppressWarnings({"EqualsBetweenInconvertibleTypes"})
  public void testSeasonNotAFrog() throws Exception {
    assertFalse(new Season(2009, GrowingSeason.WINTER).equals("FROG"));
  }

  public void testSameSeasonSameYearAreEqual() throws Exception {
    int testYear = 2010;
    GrowingSeason testSeason = GrowingSeason.WINTER;
    Season testSeason1 = new Season(testYear, testSeason);
    Season testSeason2 = new Season(testYear, testSeason);
    assertEquals(testSeason1, testSeason2);
    assertEquals(0, testSeason1.compareTo(testSeason2));
  }

  public void testSameSeasonDifferentYearAreNotEqual() throws Exception {
    int testYear = 2010;
    GrowingSeason testSeason = GrowingSeason.WINTER;
    Season testSeason1 = new Season(testYear, testSeason);
    Season testSeason2 = new Season(testYear + 1, testSeason);
    assertFalse(testSeason1.equals(testSeason2));
    assertTrue(testSeason1.compareTo(testSeason2) < 0);
    assertTrue(testSeason2.compareTo(testSeason1) > 0);
  }

  public void testDifferentSeasonSameYearAreNotEqual() throws Exception {
    int testYear = 2010;
    Season testSeason1 = new Season(testYear, GrowingSeason.SPRING);
    Season testSeason2 = new Season(testYear, GrowingSeason.WINTER);
    assertFalse(testSeason1.equals(testSeason2));
    assertTrue(testSeason1.compareTo(testSeason2) < 0);
    assertTrue(testSeason2.compareTo(testSeason1) > 0);
  }

  public void testDifferentSeasonDifferentYearAreNotEqualAndOrderIsBasedOnYear() throws Exception {
    int testYear = 2010;
    Season testSeason1 = new Season(testYear, GrowingSeason.WINTER);
    Season testSeason2 = new Season(testYear + 1, GrowingSeason.SPRING);
    assertFalse(testSeason1.equals(testSeason2));
    assertTrue(testSeason1.compareTo(testSeason2) < 0);
    assertTrue(testSeason2.compareTo(testSeason1) > 0);
  }

  public void testSpringDisplayedCorrectly() throws Exception {
    assertEquals("Spring 09", new Season(2009, GrowingSeason.SPRING).toString());
  }

  public void testWinterDisplayedCorrectly() throws Exception {
    assertEquals("Winter 09/10", new Season(2009, GrowingSeason.WINTER).toString());
  }

  public void testNoneDisplayedCorrectly() throws Exception {
    assertEquals(Season.NOT_AVAILABLE_MESSAGE, Season.NONE.toString());
  }
}
