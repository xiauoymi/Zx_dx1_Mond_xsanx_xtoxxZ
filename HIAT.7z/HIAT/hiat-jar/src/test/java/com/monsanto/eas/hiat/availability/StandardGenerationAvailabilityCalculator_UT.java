package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;
import com.monsanto.eas.hiat.model.hibernate.ProductionEntryImpl;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.service.InventoryService;
import com.monsanto.eas.hiat.service.ProductionService;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class StandardGenerationAvailabilityCalculator_UT extends HIATUnitTest {
  private AvailabilityDate testPrevGenDate = AvailDateTestUtil.getRandomFutureDate();
  private GenerationAvailabilityCalculator prevGeneration = new MockGenerationAvailabilityCalculator(testPrevGenDate);
  private InventoryType testInvType = InventoryType.PREFOUNDATION;

  public void testInventoryOnHandUseToday() throws Exception {
    InventoryService invService = new MockInventoryService(123L);
    ProductionService prodService = new MockProductionService();
    Product testProduct = new MockProduct(443322L);
    GenerationAvailabilityCalculator calc = new StandardGenerationAvailabilityCalculator(testInvType, prevGeneration, invService, prodService);
    AvailabilityDate availDate = calc.getAvailability(testProduct);
    assertNotNull(availDate);
    assertFalse(availDate.isDerived());
    AvailDateTestUtil.assertDateOnOrBeforeToday(availDate);
  }

  public void testInventoryOnOrderUseOrderAvailDate() throws Exception {
    InventoryService invService = new MockInventoryService(0L);
    Product testProduct = new MockProduct(443322L);
    AvailabilityDate prodDate = AvailDateTestUtil.getRandomFutureDate();
    ProductionEntry entry = new ProductionEntryImpl(prodDate.getExactDate(), testProduct, 12345L, testInvType, false);
    Collection<ProductionEntry> prodEntries = new ArrayList<ProductionEntry>();
    prodEntries.add(entry);
    ProductionService prodService = new MockProductionService(prodEntries);
    GenerationAvailabilityCalculator calc = new StandardGenerationAvailabilityCalculator(testInvType, prevGeneration, invService, prodService);
    AvailabilityDate availDate = calc.getAvailability(testProduct);
    assertNotNull(availDate);
    assertFalse(availDate.isDerived());
    AvailDateTestUtil.assertDateEquals(prodDate, availDate);
  }

  public void testNoInvOrOrderUsePreviousGenerationPlusAmount() throws Exception {
    InventoryService invService = new MockInventoryService(0L);
    ProductionService prodService = new MockProductionService();
    Product testProduct = new MockProduct(443322L);
    GenerationAvailabilityCalculator calc = new StandardGenerationAvailabilityCalculator(testInvType, prevGeneration, invService, prodService);
    AvailabilityDate availDate = calc.getAvailability(testProduct);
    assertNotNull(availDate);
    assertTrue(availDate.isDerived());
    AvailabilityDate expectedDate = testPrevGenDate.addGeneration();
    AvailDateTestUtil.assertDateEquals(expectedDate, availDate);
  }

}