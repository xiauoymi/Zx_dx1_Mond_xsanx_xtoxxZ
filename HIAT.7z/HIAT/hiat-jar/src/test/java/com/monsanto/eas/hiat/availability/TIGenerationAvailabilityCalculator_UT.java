package com.monsanto.eas.hiat.availability;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.util.HIATUnitTest;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class TIGenerationAvailabilityCalculator_UT extends HIATUnitTest {
  public void testHasHandOffDateThatIsAvailDate() throws Exception {
    AvailabilityDate testHandoffDate = AvailDateTestUtil.getRandomFutureDate();
    Product testProduct = new MockProduct(123L, "", null, null, null, testHandoffDate.getExactDate(), null, false, null, "", false);
    GenerationAvailabilityCalculator calc = new TIGenerationAvailabilityCalculator();
    AvailabilityDate availDate = calc.getAvailability(testProduct);
    assertNotNull(availDate);
    assertEquals(testHandoffDate, availDate);
  }

  public void testNoHandoffDateNoAvailDate() throws Exception {
    Product testProduct = new MockProduct(123L, "", null, null, null, null, null, false, null, "", false);
    GenerationAvailabilityCalculator calc = new TIGenerationAvailabilityCalculator();
    AvailabilityDate availDate = calc.getAvailability(testProduct);
    assertNotNull(availDate);
    assertEquals(AvailabilityDateImpl.getUnknown(AvailDateTestUtil.TEST_DATE_SOURCE), availDate);
  }

}
