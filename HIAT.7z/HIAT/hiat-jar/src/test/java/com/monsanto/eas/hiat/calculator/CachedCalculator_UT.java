package com.monsanto.eas.hiat.calculator;

import junit.framework.TestCase;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class CachedCalculator_UT extends TestCase {
  public void testMultipleCalls_ReturnSameValueAreCached() throws Exception {
    Integer testValue = 314159;
    Integer testInput = 90210;
    MockCalculator calc = new MockCalculator(testValue);
    Calculator<Integer, Integer> cachedCalc = new CachedCalculator<Integer,Integer>(calc);
    assertEquals(0, calc.getNumCalls());
    for (int i = 0; i < 100; i++) {
      assertEquals(testValue, cachedCalc.calculate(testInput));
    }
    assertEquals(1, calc.getNumCalls());
  }

  public void testMultipleCallsForNullResult_ValueIsCached() throws Exception {
    Integer testValue = null;
    Integer testInput = 90210;
    MockCalculator calc = new MockCalculator(testValue);
    Calculator<Integer, Integer> cachedCalc = new CachedCalculator<Integer,Integer>(calc);
    assertEquals(0, calc.getNumCalls());
    for (int i = 0; i < 100; i++) {
      assertEquals(testValue, cachedCalc.calculate(testInput));
    }
    assertEquals(1, calc.getNumCalls());
  }


  private static class MockCalculator implements Calculator<Integer, Integer> {
    private int numCalls = 0;
    private final Integer returnValue;

    public MockCalculator(Integer returnValue) {
      this.returnValue = returnValue;
    }

    public Integer calculate(Integer input) {
      numCalls++;
      return returnValue;
    }

    public int getNumCalls() {
      return numCalls;
    }
  }
}