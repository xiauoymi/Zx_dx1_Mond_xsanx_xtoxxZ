package com.monsanto.eas.hiat.config;

import junit.framework.TestCase;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HIATConfigurationFactory_UT extends TestCase {
  public void testSetAndGetWork() throws Exception {
    HIATConfiguration config = new MockConfiguration();
    HIATConfigurationFactory.setConfiguration(config);
    assertEquals(config, HIATConfigurationFactory.getConfiguration());
  }

  public void testGetWithNullSetThrows() throws Exception {
    HIATConfigurationFactory.setConfiguration(null);
    try {
      HIATConfigurationFactory.getConfiguration();
    } catch (RuntimeException IGNORE) {
      // ignore expected exception
    }
  }

}
