package com.monsanto.eas.hiat.config;

import junit.framework.TestCase;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HIATConfigurationImpl_UT extends TestCase {
  public void testDefaultConstructor_ValuesAreWithDefaultsExceptMonthsWhichAreOffsetByOne() throws Exception {
    HIATConfiguration config = new HIATConfigurationImpl();
    assertEquals(0, config.getDaysBetweenGenerations());
    assertEquals(0, config.getG1MinimumForPCM150());
    assertEquals(0, config.getG1MinimumForPCM300());
    assertEquals(0, config.getG2MinimumForCommercial());
    assertEquals(0, config.getG2MinimumForPCM150());
    assertEquals(0, config.getG2MinimumForPCM300());
    assertEquals(-1, config.getWinterCutoffMonth());
    assertEquals(0, config.getWinterCutoffDay());
    assertEquals(-1, config.getSpringCutoffMonth());
    assertEquals(0, config.getSpringCutoffDay());
    assertEquals(-1, config.getTestingCutoffMonth());
    assertEquals(0, config.getTestingCutoffDay());
  }

}
