package com.monsanto.eas.hiat.config;

import java.util.Calendar;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockConfiguration implements HIATConfiguration {
  public static final int DAYS_BETWEEN_GENERATIONS = 120;
  public static final int SPRING_CUTOFF_MONTH = Calendar.JUNE;
  public static final int SPRING_CUTOFF_DAY = 1;
  public static final int WINTER_CUTOFF_MONTH = Calendar.OCTOBER;
  public static final int WINTER_CUTOFF_DAY = 1;
  public static final int TESTING_CUTOFF_MONTH = Calendar.OCTOBER;
  public static final int TESTING_CUTOFF_DAY = 31;
  public static final int PCM_WINTER_CUTOFF_MONTH = Calendar.OCTOBER;
  public static final int PCM_WINTER_CUTOFF_DAY = 31;
  public static final int MINIMUM_G1_QTY_FOR_PCM150 = 5;
  public static final int MINIMUM_G1_QTY_FOR_PCM300 = 25;
  public static final int MINIMUM_G2_QTY_FOR_PCM150 = 5;
  public static final int MINIMUM_G2_QTY_FOR_PCM300 = 25;
  public static final int MINIMUM_G2_QTY_FOR_COMMERCIAL = 50;

  public int getDaysBetweenGenerations() {
    return DAYS_BETWEEN_GENERATIONS;
  }

  public int getSpringCutoffMonth() {
    return SPRING_CUTOFF_MONTH;
  }

  public int getSpringCutoffDay() {
    return SPRING_CUTOFF_DAY;
  }

  public int getWinterCutoffMonth() {
    return WINTER_CUTOFF_MONTH;
  }

  public int getWinterCutoffDay() {
    return WINTER_CUTOFF_DAY;
  }

  public int getPCMWinterCutoffMonth() {
    return PCM_WINTER_CUTOFF_MONTH;
  }

  public int getPCMWinterCutoffDay() {
    return PCM_WINTER_CUTOFF_DAY;
  }

  public int getTestingCutoffMonth() {
    return TESTING_CUTOFF_MONTH;
  }

  public int getTestingCutoffDay() {
    return TESTING_CUTOFF_DAY;
  }

  public int getG1MinimumForPCM150() {
    return MINIMUM_G1_QTY_FOR_PCM150;
  }

  public int getG1MinimumForPCM300() {
    return MINIMUM_G1_QTY_FOR_PCM300;
  }

  public int getG2MinimumForPCM150() {
    return MINIMUM_G2_QTY_FOR_PCM150;
  }

  public int getG2MinimumForPCM300() {
    return MINIMUM_G2_QTY_FOR_PCM300;
  }

  public int getG2MinimumForCommercial() {
    return MINIMUM_G2_QTY_FOR_COMMERCIAL;
  }
}

