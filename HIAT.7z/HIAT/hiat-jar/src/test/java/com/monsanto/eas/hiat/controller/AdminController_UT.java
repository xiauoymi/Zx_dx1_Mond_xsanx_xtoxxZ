package com.monsanto.eas.hiat.controller;

import junit.framework.TestCase;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import org.junit.Assert;

import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class AdminController_UT extends TestCase {
  public void testIsAuthorizedChecksHelperForGroup() throws Exception {
    MockHelperForGroup helper = new MockHelperForGroup();
    AdminController controller = new MockAdminController();
    String adminGroup = controller.getAdminGroup();
    assertNotNull(adminGroup);
    controller.isAdmin(helper);
    assertEquals(adminGroup, helper.getRoleChecked());
  }

  public void testUserAuthorizedImplIsCalled() throws Exception {
    MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId("MOCK", "testId");
    MockAdminControllerForAuthorization controller = new MockAdminControllerForAuthorization(true);
    controller.run(helper);
    Assert.assertEquals("testId", helper.getSessionParameter(HIATController.USERID_IN_SESSION));
    assertTrue(controller.wasImplementationRan());
  }

  public void testUserNotAuthorizedImplNotCalled() throws Exception {
    MockAdminControllerForAuthorization controller = new MockAdminControllerForAuthorization(false);
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    controller.run(helper);
    assertNull(helper.getSessionParameter(HIATController.USERID_IN_SESSION));
    assertFalse(controller.wasImplementationRan());
  }

  private static class MockAdminControllerForAuthorization extends AdminController {
    private boolean implementationRan = false;
    private final boolean isAdmin;

    public MockAdminControllerForAuthorization(boolean adminAuthorized) {
      super(new MockConfigDAO());
      isAdmin = adminAuthorized;
    }

    @Override
    protected boolean isUserAuthorized(UCCHelper helper) {
      return true;
    }

    @Override
    protected boolean isAdmin(UCCHelper helper) {
      return isAdmin;
    }

    public boolean wasImplementationRan() {
      return implementationRan;
    }

    protected void notSpecified(UCCHelper helper) throws IOException {
      implementationRan = true;
    }
  }

  private static class MockAdminController extends AdminController {
    private boolean implementationRan = false;

    MockAdminController() {
      super(new MockConfigDAO());
    }

    public boolean wasImplementationRan() {
      return implementationRan;
    }

    protected void notSpecified(UCCHelper helper) throws IOException {
      implementationRan = true;
    }
  }

}