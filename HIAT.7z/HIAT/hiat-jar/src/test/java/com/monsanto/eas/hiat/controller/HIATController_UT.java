package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import org.junit.Assert;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HIATController_UT extends HIATUnitTest {
  public void testIsAuthorizedChecksHelperForGroup() throws Exception {
    MockHelperForGroup helper = new MockHelperForGroup();
    HIATController controller = new MockHIATController();
    String requiredGroup = controller.getRequiredGroup();
    assertNotNull(requiredGroup);
    controller.isUserAuthorized(helper);
    assertEquals(requiredGroup, helper.getRoleChecked());
  }

  public void testUserAuthorizedImplIsCalled() throws Exception {
    MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId("MOCK", "testId");
    MockHIATControllerForAuthorization controller = new MockHIATControllerForAuthorization(true);
    controller.run(helper);
    Assert.assertEquals("testId", helper.getSessionParameter(HIATController.USERID_IN_SESSION));
    assertTrue(controller.wasImplementationRan());
  }

  public void testUserNotAuthorizedImplNotCalled() throws Exception {
    MockHIATControllerForAuthorization controller = new MockHIATControllerForAuthorization(false);
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    controller.run(helper);
    assertNull(helper.getSessionParameter(HIATController.USERID_IN_SESSION));
    assertFalse(controller.wasImplementationRan());
  }

  public void testForwardToErrorPage() throws Exception {
    MockHIATControllerThrowsException controller = new MockHIATControllerThrowsException();
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    controller.run(helper);
    assertNull(helper.getSessionParameter(HIATController.USERID_IN_SESSION));
    assertTrue(helper.wasSentTo(HIATController.HTML_ERROR_PAGE_JSP));
  }
}