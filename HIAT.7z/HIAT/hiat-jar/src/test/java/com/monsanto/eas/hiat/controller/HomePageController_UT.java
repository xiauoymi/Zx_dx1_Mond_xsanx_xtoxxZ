package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.util.HIATUnitTest;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HomePageController_UT extends HIATUnitTest {
  public void testHomePageForwardsToHomePage() throws Exception {
    HomePageController controller = new MockHomePageController();
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
    assertTrue(helper.wasSentTo(HomePageController.HOME_PAGE_LOCATION));
  }

  private class MockHomePageController extends HomePageController {
    private MockHomePageController() {
      super(new MockConfigDAO());
    }

    protected boolean isUserAuthorized(UCCHelper helper) {
      return true;
    }
  }
}

