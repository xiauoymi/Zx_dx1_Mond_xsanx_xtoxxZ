package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.eas.hiat.controller.mock.MockHybridAnalysisController;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.HIATDatabaseTestCase;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.eas.hiat.util.AnalysisTestConstants;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.List;

/**
 * Created by vvvelu Date: Feb 10, 2009 Time: 11:43:39 AM
 */
public class HybridAnalysisController_AT extends HIATDatabaseTestCase {
  private UseCaseController controller;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    controller = new MockHybridAnalysisController(new TestInitService().initTraitService(),
            new TestInitService().initHybridAnalyzer(), new TestInitService().initProductService(), new TestInitService().initHybridXMLGenerator());
  }

  public void test_Method_GenerateAnalysis_NoProductsEntered() throws IOException {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, new String[]{"1", "0"});
    controller.run(helper);
    List<String> errorsList = (List<String>) helper.getRequestAttributeValue(AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    List<Trait> selectedTraits = (List<Trait>) helper.getRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS);
    assertEquals(1, selectedTraits.size());
    Trait trait = selectedTraits.get(0);
    assertNotNull(trait);
    String productName = (String) helper.getRequestAttributeValue(AnalysisConstants.PRODUCT_NAME);
    assertEquals(null, productName);
    List<Trait> traits = (List<Trait>) helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST);
    assertNotNull(traits);
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }

  public void test_Method_GenerateAnalysis_NoTraitsSelected() throws IOException {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    //TODO: product name is data dependent. This has to be changed to right one when data is available
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "ABC123");
    controller = new TestInitService().getController("hybridAnalysisController");
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
    List<String> errorsList = (List) helper.getRequestAttributeValue(AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    List<Trait> selectedTraits = (List<Trait>) helper.getRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS);
    assertTrue(selectedTraits.isEmpty());
    String productName = (String) helper.getRequestAttributeValue(AnalysisConstants.PRODUCT_NAME);
    assertEquals("ABC123", productName);
    List<Trait> traits = (List<Trait>) helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST);
    assertNotNull(traits);
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }

  public void test_Method_GenerateAnalysis_NoProductsAvailable_ForTheInputProductName() throws Exception {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "XYZ");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"3"});
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, new String[]{"3", "0"});
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
    List<String> errorsList = (List) helper.getRequestAttributeValue(AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    assertEquals(AnalysisController.NO_MATCHING_PRODUCT_FOUND, errorsList.get(0));
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }

  public void test_Method_GenerateAnalysis_NoProductsAvailable_ForTheInputProductName_WithWildCard() throws Exception {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "XYZ*");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"3"});
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, new String[]{"3", "0"});
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
    List<String> errorsList = (List) helper.getRequestAttributeValue(AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    assertEquals(AnalysisController.NO_MATCHING_PRODUCT_FOUND, errorsList.get(0));
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }


  public void test_Method_DownloadHybridAnalysis() throws IOException {
    setUpProductTraitData(true);
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, getTestProduct().getProductNames().get(
            ProductNameType.BASE_PRECOMMERCIAL));
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{getTestTrait().getId().toString()});
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
  }

  public void testGetPossibleTraitCombinations_ReturnsDocument() throws Exception {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.SELECTED_TRAITS, "1_2_3");
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "getPossibleTraitCombinations");
    controller.run(helper);
    assertNotNull(helper.getXML());
    assertFalse(helper.wasErrorGenerated());
  }

  public void testGenerateAnalysis_NoTraitsToBeFiltered_Unselected_VerifyReferenceData() throws Exception {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "DKC41-61");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"40"});
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, new String[]{"40", "0"});
    controller.run(helper);
    String traitsToBeFiltered = (String) helper.getRequestAttributeValue(HybridAnalysisController.TRAITS_TO_BE_FILTERED);
    List<Trait> traitsIncluded = (List<Trait>) helper.getRequestAttributeValue(HybridAnalysisController.TRAITS_INCLUDED);
    List<Trait> allPossibleTraitCombinations = (List<Trait>) helper.getRequestAttributeValue(HybridAnalysisController.ALL_POSSIBLE_TRAIT_COMBINATION_VALUES);
    assertNotNull(traitsToBeFiltered);
    assertEquals(0, traitsToBeFiltered.length());
    assertNotNull(traitsIncluded);
    assertEquals(2, traitsIncluded.size());
    assertNotNull(allPossibleTraitCombinations);
    assertEquals(2, allPossibleTraitCombinations.size());
  }

  public void testGenerateAnalysis_TraitsToBeFiltered_Unselected_VerifyReferenceData() throws Exception {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "DKC41-61");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"40"});
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, new String[]{"40"});
    controller.run(helper);
    String traitsToBeFiltered = (String) helper.getRequestAttributeValue(HybridAnalysisController.TRAITS_TO_BE_FILTERED);
    List<Trait> traitsIncluded = (List<Trait>) helper.getRequestAttributeValue(HybridAnalysisController.TRAITS_INCLUDED);
    List<Trait> allPossibleTraitCombinations = (List<Trait>) helper.getRequestAttributeValue(HybridAnalysisController.ALL_POSSIBLE_TRAIT_COMBINATION_VALUES);
    assertNotNull(traitsToBeFiltered);
    assertTrue(StringUtils.contains(traitsToBeFiltered, "CONV"));
    assertNotNull(traitsIncluded);
    assertEquals(1, traitsIncluded.size());
    assertNotNull(allPossibleTraitCombinations);
    assertEquals(2, allPossibleTraitCombinations.size());
  }


  public static class MockUCCHelperAlwaysAuthorized extends MockUCCHelper {
    public MockUCCHelperAlwaysAuthorized() {
      super("MOCK");
    }

    @Override
    public boolean isUserInRole(String s) {
      return true;
    }
  }


}