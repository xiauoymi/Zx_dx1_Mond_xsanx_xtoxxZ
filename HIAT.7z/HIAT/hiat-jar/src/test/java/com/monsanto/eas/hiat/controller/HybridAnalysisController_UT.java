package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.analysis.HybridAnalysisDetail;
import com.monsanto.eas.hiat.analysis.HybridAnalysisParentDetail;
import com.monsanto.eas.hiat.analysis.MockHybridAnalyzer;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisDetailImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisParentDetailImpl;
import com.monsanto.eas.hiat.availability.AvailDateTestUtil;
import com.monsanto.eas.hiat.availability.AvailabilityDate;
import com.monsanto.eas.hiat.availability.AvailabilityDateImpl;
import com.monsanto.eas.hiat.availability.SeasonCalculator;
import com.monsanto.eas.hiat.controller.mock.MockHybridAnalysisController;
import com.monsanto.eas.hiat.controller.mock.MockProductServiceConfiguredForNE5112v1;
import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.hibernate.ProductNameImpl;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.mock.mock.MockTraitService;
import com.monsanto.eas.hiat.util.AnalysisTestConstants;
import com.monsanto.eas.hiat.view.mock.MockHybridAnalysisXMLGenerator;
import org.custommonkey.xmlunit.XMLTestCase;

import java.io.IOException;
import java.util.*;

/**
 * Created by vvvelu Date: Feb 10, 2009 Time: 10:30:00 AM
 */
public class HybridAnalysisController_UT extends XMLTestCase {
  private HybridAnalysisController controller;
  private MockHybridAnalyzer analyzer;
  private MockTraitService mockTraitService;
  private MockHybridAnalysisXMLGenerator xmlGenerator;
  private MockProductServiceConfiguredForNE5112v1 productService;

  public void setUp() throws Exception {
    super.setUp();
    analyzer = new MockHybridAnalyzer();
    mockTraitService = new MockTraitService();
    productService = new MockProductServiceConfiguredForNE5112v1();
    xmlGenerator = new MockHybridAnalysisXMLGenerator();
    controller = new MockHybridAnalysisController(mockTraitService, analyzer, productService, xmlGenerator);
  }

  public void testTraitListUsedDoesIncludeInactives() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    controller.run(helper);

    assertTrue(mockTraitService.wasGetActiveTraitsCalled());
    assertFalse(mockTraitService.wasGetAllTraitsCalled());
  }

  public void testGenerateAnalysisCalled_CorrectValuesArePassedToAnalyzer() throws Exception {
    Trait expectedTestTrait = mockTraitService.getTestTrait(3);
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, MockProductServiceConfiguredForNE5112v1.TEST_PRODUCT_1);
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"3"});
    controller.run(helper);

    Collection<Product> lastProductList = analyzer.getLastProductListPassed();
    assertTrue(lastProductList.contains(getTestProducts(productService, MockProductServiceConfiguredForNE5112v1.TEST_PRODUCT_1).get(0)));
    Collection<Trait> lastTraitList = analyzer.getLastTraitListPassed();
    assertNotNull(lastTraitList);
    assertEquals(1, lastTraitList.size());
    assertTrue(lastTraitList.contains(expectedTestTrait));
  }

  public void testGenerateAnalysisCalled_InvalidProductNameIsInErrorList() throws Exception {
    String testErrorProduct = MockProductServiceConfiguredForNE5112v1.PRODUCT_THAT_DOES_NOT_EXIST;
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, MockProductServiceConfiguredForNE5112v1.TEST_PRODUCT_1 + " " + testErrorProduct);
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"3"});
    controller.run(helper);

    @SuppressWarnings("unchecked")
    Collection<String> errorProductList = (Collection<String>) helper.getRequestAttributeValue(AnalysisController.MISSING_PRODUCTS);

    assertNotNull(errorProductList);
    assertEquals(1, errorProductList.size());
    assertTrue("Expected list to contain " + testErrorProduct + " but it was: " + errorProductList, errorProductList.contains(testErrorProduct));
  }

  public void testListReturnedByAnalyzerIsPassedToHelper() throws Exception {
    List<HybridAnalysis> testListExpected = new ArrayList<HybridAnalysis>();
    testListExpected.add(new HybridAnalysisImpl());
    analyzer = new MockHybridAnalyzer(testListExpected);
    mockTraitService = new MockTraitService();
    controller = new MockHybridAnalysisController(mockTraitService, analyzer, productService, null);
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v2");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    controller.run(helper);
    @SuppressWarnings("unchecked")
    List<HybridAnalysis> analysisList = (List<HybridAnalysis>) helper.getRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST);
    assertEquals(testListExpected, analysisList);
  }

  public void test_Method_GenerateAnalysis_Verify_AnalysisDetails() throws Exception {
    List<HybridAnalysis> testListExpected = setupAnalysisDetails();
    analyzer = new MockHybridAnalyzer(testListExpected);
    mockTraitService = new MockTraitService();
    controller = new MockHybridAnalysisController(mockTraitService, analyzer, productService, null);
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v2");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, new String[]{"1", "0"});
    controller.run(helper);
    @SuppressWarnings("unchecked")
    List<HybridAnalysis> analysisList = (List<HybridAnalysis>) helper.getRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST);
    assertEquals(testListExpected, analysisList);

    HybridAnalysis hybridAnalysis = analysisList.get(0);
    Product expectedProduct = hybridAnalysis.getProduct();
    Product testProduct = getTestProductToVerifyAnalysisDetails();
    assertEquals(expectedProduct.getId(), testProduct.getId());
    Trait expectedTrait = hybridAnalysis.getTrait();
    Trait testTrait = getTestTrait();
    assertTrue(expectedTrait.getCode().equals(testTrait.getCode()));
    assertProductForAnalysisDetails(expectedProduct, testProduct);
  }

  private void assertProductForAnalysisDetails(Product expectedProduct, Product testProduct) {
    assertEquals(expectedProduct.getProductNames().get(ProductNameType.BASE_MANUFACTURING).getName(), testProduct.getProductNames().get(ProductNameType.BASE_MANUFACTURING).getName());
    assertEquals(expectedProduct.getFemaleParent().getBase().getProductNames().get(ProductNameType.BASE_PRECOMMERCIAL).getName(), testProduct.getFemaleParent().getBase().getProductNames().get(ProductNameType.BASE_PRECOMMERCIAL).getName());
    assertEquals(expectedProduct.getFemaleParent().getBase().getProductNames().get(ProductNameType.BASE_MANUFACTURING).getName(), testProduct.getFemaleParent().getBase().getProductNames().get(ProductNameType.BASE_MANUFACTURING).getName());
    assertEquals(expectedProduct.getMaleParent().getBase().getProductNames().get(ProductNameType.BASE_PRECOMMERCIAL).getName(), testProduct.getMaleParent().getBase().getProductNames().get(ProductNameType.BASE_PRECOMMERCIAL).getName());
    assertEquals(expectedProduct.getMaleParent().getBase().getProductNames().get(ProductNameType.BASE_MANUFACTURING).getName(), testProduct.getMaleParent().getBase().getProductNames().get(ProductNameType.BASE_MANUFACTURING).getName());
  }


  private List<HybridAnalysis> setupAnalysisDetails() {
    List<HybridAnalysis> testListExpected = new ArrayList<HybridAnalysis>();
    ProductImpl product5 = getTestProductToVerifyAnalysisDetails();

    Trait traitOne = getTestTrait();
    Trait conventionalTrait = getConventionalTrait();
    Set<HybridAnalysisDetail> detail = new HashSet<HybridAnalysisDetail>();

    HybridAnalysisDetail hybridAnalysisDetailForTraitCONV = getHybridAnalysisDetailForCONVTrait(traitOne, conventionalTrait);
    detail.add(hybridAnalysisDetailForTraitCONV);
    HybridAnalysisDetail hybridAnalysisDetailForTraitWHM = getHybridAnalysisDetailForTraitWHM(traitOne,
            conventionalTrait);
    detail.add(hybridAnalysisDetailForTraitWHM);
    HybridAnalysis hybridAnalysis = new HybridAnalysisImpl(product5, traitOne, detail);
    testListExpected.add(hybridAnalysis);
    return testListExpected;
  }

  private HybridAnalysisDetail getHybridAnalysisDetailForTraitWHM(Trait traitOne, Trait conventionalTrait) {
    HybridAnalysisParentDetail femaleDetailForTraitWHM = new HybridAnalysisParentDetailImpl(null, traitOne, getNow(), getNow(), getNow());
    HybridAnalysisParentDetail maleDetailForTraitWHM = new HybridAnalysisParentDetailImpl(null, conventionalTrait, getNow(), getNow(), getNow());

    AvailabilityDate pcm150DateForTraitWHM = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date());
    AvailabilityDate pcm300DateForTraitWHM = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date());
    AvailabilityDate commercialDateForTraitWHM = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date());
    return new HybridAnalysisDetailImpl(maleDetailForTraitWHM, femaleDetailForTraitWHM,
        new SeasonCalculator().calculateSeasonForPrimaryCommercial(pcm150DateForTraitWHM.getExactDate()),
            new SeasonCalculator().calculateSeasonForPrimaryCommercial(pcm300DateForTraitWHM.getExactDate()),
            new SeasonCalculator().calculateSeasonForPrimaryCommercial(commercialDateForTraitWHM.getExactDate()));
  }

  private HybridAnalysisDetail getHybridAnalysisDetailForCONVTrait(Trait traitOne, Trait conventionalTrait) {
    HybridAnalysisParentDetail femaleDetailForTraitCONV = new HybridAnalysisParentDetailImpl(null, conventionalTrait, getNow(), getNow(), getNow());
    HybridAnalysisParentDetail maleDetailForTraitCONV = new HybridAnalysisParentDetailImpl(null, traitOne, getNow(), getNow(), getNow());

    AvailabilityDate pcm150DateForTraitCONV = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date());
    AvailabilityDate pcm300DateForTraitCONV = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date());
    AvailabilityDate commercialDateForTraitCONV = new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date());
    return new HybridAnalysisDetailImpl(maleDetailForTraitCONV, femaleDetailForTraitCONV,
        new SeasonCalculator().calculateSeasonForPrimaryCommercial(pcm150DateForTraitCONV.getExactDate()),
            new SeasonCalculator().calculateSeasonForPrimaryCommercial(pcm300DateForTraitCONV.getExactDate()),
            new SeasonCalculator().calculateSeasonForPrimaryCommercial(commercialDateForTraitCONV.getExactDate()));
  }

  private AvailabilityDate getNow() {
    return new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, new Date(), false);
  }

  private Trait getConventionalTrait() {
    return new MockTrait(0L, "CONV", "CONV", "CONV", null, true);
  }

  private Trait getTestTrait() {
    return new MockTrait(1L, "WHM", "HXCB", "HXCB", null, true);
  }

  private ProductImpl getTestProductToVerifyAnalysisDetails() {
    ProductImpl baseProduct1 = new ProductImpl(7L, "BASE 1", new MockTrait("BASE 1"), null, null, new Date(), new Date(), true, null,
            null, false);
    ProductImpl baseProduct2 = new ProductImpl(8L, "BASE 2", new MockTrait("BASE 2"), null, null, new Date(), new Date(), true, null,
            null, false);

    ProductName baseMfgNameForProd1 = new ProductNameImpl(71L, "HCL119_BASE", baseProduct1, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING);
    ProductName baseMfgNameForProd2 = new ProductNameImpl(81L, "HCL414_BASE", baseProduct2, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING);
    ProductName basePreCommNameForProd1 = new ProductNameImpl(711L, "HCL119NRR1", baseProduct1, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_PRECOMMERCIAL);
    ProductName basePreCommNameForProd2 = new ProductNameImpl(811L, "HCL414NRR1", baseProduct2, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_PRECOMMERCIAL);

    Map<ProductNameType, ProductName> productNamesForProd1 = new HashMap<ProductNameType, ProductName>();
    Map<ProductNameType, ProductName> productNamesForProd2 = new HashMap<ProductNameType, ProductName>();
    productNamesForProd1.put(ProductNameType.BASE_MANUFACTURING, baseMfgNameForProd2);
    productNamesForProd1.put(ProductNameType.BASE_PRECOMMERCIAL, basePreCommNameForProd1);
    baseProduct1.setProductNames(productNamesForProd1);

    productNamesForProd2.put(ProductNameType.BASE_MANUFACTURING, baseMfgNameForProd1);
    productNamesForProd2.put(ProductNameType.BASE_PRECOMMERCIAL, basePreCommNameForProd2);
    baseProduct2.setProductNames(productNamesForProd2);

    ProductImpl product3 = new ProductImpl(3L, "1", new MockTrait("PPTX"), null, null, null, null, false, baseProduct1,
            null, false);
    ProductImpl product4 = new ProductImpl(4L, "1", new MockTrait("QQTX"), null, null, null, null, false, baseProduct2,
            null, false);

    ProductImpl product5 = new ProductImpl(5L, "1", new MockTrait("SSTX"), product3, product4, new Date(), new Date(), true, null,
            null, false);
    ProductName baseMfgNameForProd5 = new ProductNameImpl(51L, "NE5112_v2", product5, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING);
    Map<ProductNameType, ProductName> productNamesForProd5 = new HashMap<ProductNameType, ProductName>();
    productNamesForProd5.put(ProductNameType.BASE_MANUFACTURING, baseMfgNameForProd5);
    product5.setProductNames(productNamesForProd5);
    return product5;
  }

  public void test_Method_GenerateAnalysis_NoProductsEntered() throws IOException {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"3"});
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, new String[]{"3", "0"});
    controller.run(helper);
    @SuppressWarnings("unchecked")
    List<String> errorsList = (List<String>) helper.getRequestAttributeValue(AnalysisController.ERRORS_LIST);
    assertNotNull(errorsList);
    assertEquals(1, errorsList.size());
    assertEquals(AnalysisController.ENTER_ATLEAST_ONE_PRODUCT, errorsList.get(0));
    @SuppressWarnings("unchecked")
    List<Trait> traits = (List<Trait>) helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST);
    assertNotNull(traits);
    assertEquals(3, traits.size());
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_RESULTS));
  }

  public void test_Method_GenerateAnalysis_NoTraitsSelected() throws IOException {
    //NOTE: This test is to verify that errorList is not empty when the user does not select Trait
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "product1 product2");
    controller.run(helper);
    @SuppressWarnings("unchecked")
    List<String> errorsList = (List<String>) helper.getRequestAttributeValue(AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    assertEquals(AnalysisController.ENTER_ATLEAST_ONE_TRAIT, errorsList.get(0));
    @SuppressWarnings("unchecked")
    List<Trait> traits = (List<Trait>) helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST);
    assertNotNull(traits);
    assertEquals(3, traits.size());
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_RESULTS));
  }

  public void test_Method_GenerateAnalysis_NoProductsAvailable_ForTheInputProductName() throws Exception {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "XYZ");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"3"});
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, new String[]{"3", "0"});
    controller.run(helper);
    @SuppressWarnings("unchecked")
    List<String> errorsList = (List) helper.getRequestAttributeValue(AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    assertEquals(AnalysisController.NO_MATCHING_PRODUCT_FOUND, errorsList.get(0));
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_RESULTS));
  }

  public void test_Method_GenerateAnalysis_NoProductsAvailable_ForTheInputProductName_WithWildCard() throws Exception {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "XYZ*");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"3"});
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, new String[]{"3", "0"});
    controller.run(helper);
    @SuppressWarnings("unchecked")
    List<String> errorsList = (List<String>) helper.getRequestAttributeValue(AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    assertEquals(AnalysisController.NO_MATCHING_PRODUCT_FOUND, errorsList.get(0));
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_RESULTS));
  }

  public void testDownloadHybridAnalysisPassesAnalysisListToXmlGenerator() throws Exception {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "downloadHybridAnalysis");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v2");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1", "2"});

    List<HybridAnalysis> testListExpected = new ArrayList<HybridAnalysis>();
    Product testProduct = new MockProduct(1L);
    Trait testTrait = new MockTrait(1L);
    Product testParentM = new MockProduct(2L);
    Product testParentF = new MockProduct(3L);
    Trait testParentTrait1F = new MockTrait(2L);
    Trait testParentTrait1M = new MockTrait(3L);
    Trait testParentTrait2F = new MockTrait(4L);
    Trait testParentTrait2M = new MockTrait(5L);
    Collection<HybridAnalysisDetail> testDetails = new LinkedList<HybridAnalysisDetail>();
    testDetails.add(new HybridAnalysisDetailImpl(
            new HybridAnalysisParentDetailImpl(testParentM, testParentTrait1M, null, null, null),
            new HybridAnalysisParentDetailImpl(testParentF, testParentTrait1F, null, null, null),
            null, null, null));
    testDetails.add(new HybridAnalysisDetailImpl(
            new HybridAnalysisParentDetailImpl(testParentM, testParentTrait2M, null, null, null),
            new HybridAnalysisParentDetailImpl(testParentF, testParentTrait2F, null, null, null),
            null, null, null));
    testListExpected.add(new HybridAnalysisImpl(testProduct, testTrait, testDetails));

    analyzer = new MockHybridAnalyzer(testListExpected);
    controller = new HybridAnalysisController(new MockConfigDAO(), mockTraitService, analyzer, productService, xmlGenerator);
    String[] possibleTraitComb = {
            testParentTrait1F.getId().toString(),
            testParentTrait2F.getId().toString()
    };
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, possibleTraitComb);
    controller.run(helper);

    assertTrue(xmlGenerator.wasGetXmlContentCalled());
    Collection<HybridAnalysis> actualList = xmlGenerator.getAnalysisList();
    assertEquals(1, actualList.size());
    assertEquals(testListExpected, actualList);
  }

  public void testDownloadHybridAnalysisCallsCorrectStylesheet() throws Exception {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "downloadHybridAnalysis");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v2");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1", "2"});
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, new String[]{"1", "2"});

    controller.run(helper);

    assertEquals(AnalysisConstants.STYLESHEET_HYBRID_ANALYSIS_XSL, helper.getStylesheetUsed());
  }

  public void testDownloadHybridAnalysisPassesCorrectParamsToAnalyzer() throws Exception {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "downloadHybridAnalysis");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v2");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1", "2"});
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, new String[]{"1", "2"});

    controller.run(helper);

    assertEquals(1, analyzer.getLastProductListPassed().size());
    Product productPassed = analyzer.getLastProductListPassed().iterator().next();
    assertEquals(new Long(5L), productPassed.getId());

    Collection<Long> passedIds = getIdsFromTraits(analyzer.getLastTraitListPassed());
    assertTrue(passedIds.contains(1L));
    assertTrue(passedIds.contains(2L));
  }

  private Collection<Long> getIdsFromTraits(Collection<Trait> traits) {
    Collection<Long> ids = new ArrayList<Long>(traits.size());
    for (Trait trait : traits) {
      ids.add(trait.getId());
    }

    return ids;
  }

  public void testDownloadHybridAnalysisWithFilteredTraits_FiltersOutTraits() throws Exception {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "downloadHybridAnalysis");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v2");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1", "2"});

    List<HybridAnalysis> testListExpected = new ArrayList<HybridAnalysis>();
    Product testProduct = new MockProduct(1L);
    Trait testTrait = new MockTrait(1L);
    Product testParentM = new MockProduct(2L);
    Product testParentF = new MockProduct(3L);
    Trait testParentTrait1F = new MockTrait(2L);
    Trait testParentTrait1M = new MockTrait(3L);
    Trait testParentTrait2F = new MockTrait(4L);
    Trait testParentTrait2M = new MockTrait(5L);
    Collection<HybridAnalysisDetail> testDetails = new LinkedList<HybridAnalysisDetail>();
    testDetails.add(new HybridAnalysisDetailImpl(
            new HybridAnalysisParentDetailImpl(testParentM, testParentTrait1M, null, null, null),
            new HybridAnalysisParentDetailImpl(testParentF, testParentTrait1F, null, null, null),
            null, null, null));
    testDetails.add(new HybridAnalysisDetailImpl(
            new HybridAnalysisParentDetailImpl(testParentM, testParentTrait2M, null, null, null),
            new HybridAnalysisParentDetailImpl(testParentF, testParentTrait2F, null, null, null),
            null, null, null));
    testListExpected.add(new HybridAnalysisImpl(testProduct, testTrait, testDetails));

    analyzer = new MockHybridAnalyzer(testListExpected);
    controller = new HybridAnalysisController(new MockConfigDAO(), mockTraitService, analyzer, productService, xmlGenerator);
    String[] possibleTraitComb = {
            testParentTrait1F.getId().toString()
    };
    helper.setRequestParameterValue(HybridAnalysisController.POSSIBLE_TRAIT_COMB, possibleTraitComb);
    controller.run(helper);

    assertTrue(xmlGenerator.wasGetXmlContentCalled());
    Collection<HybridAnalysis> actualList = xmlGenerator.getAnalysisList();
    assertEquals(1, actualList.size());
    HybridAnalysis analysis = actualList.iterator().next();
    assertNotNull(analysis);
    Collection<HybridAnalysisDetail> details = analysis.getDetail();
    assertEquals(1, details.size());
    HybridAnalysisDetail detail = details.iterator().next();
    assertNotNull(detail);
  }

  public void testDownloadHybridAnalysisHasMissingProducts() throws Exception {
    List<HybridAnalysis> testListExpected = new ArrayList<HybridAnalysis>();
    testListExpected.add(new HybridAnalysisImpl());
    analyzer = new MockHybridAnalyzer(testListExpected);
    controller = new HybridAnalysisController(new MockConfigDAO(), mockTraitService, analyzer, productService, xmlGenerator);
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "downloadHybridAnalysis");
    String testMissingProduct = MockProductServiceConfiguredForNE5112v1.PRODUCT_THAT_DOES_NOT_EXIST;
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, MockProductServiceConfiguredForNE5112v1.TEST_PRODUCT_1 + " " + testMissingProduct);
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1", "2"});
    controller.run(helper);

    Collection<String> missingProducts = xmlGenerator.getMissingProducts();
    assertNotNull(missingProducts);
    assertEquals(1, missingProducts.size());
    assertTrue(missingProducts.contains(testMissingProduct));
  }

  public void testGetPossibleTraitCombinations_ReturnsDocument() throws Exception {
    MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
    helper.setRequestParameterValue(AnalysisConstants.SELECTED_TRAITS, "1_2_3");
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "getPossibleTraitCombinations");
    controller = new HybridAnalysisController(new MockConfigDAO(), mockTraitService, null, null, null);
    controller.run(helper);
    assertNotNull(helper.getXML());
    assertTrue(mockTraitService.wasCalculateTraitsCalled());
  }


  private List<Product> getTestProducts(ProductService productService, String products) {
    return new ArrayList<Product>(productService.lookupProductMatchingInputCriteria(products, true).getResults());
  }

  public static class MockUCCHelperAlwaysAuthorized extends MockUCCHelper {
    public MockUCCHelperAlwaysAuthorized() {
      super("MOCK");
    }

    @Override
    public boolean isUserInRole(String s) {
      return true;
    }
  }
}