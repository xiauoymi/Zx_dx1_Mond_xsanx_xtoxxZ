package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.analysis.InbredAnalysis;
import com.monsanto.eas.hiat.analysis.InbredAnalyzer;
import com.monsanto.eas.hiat.analysis.MockInbredAnalysis;
import com.monsanto.eas.hiat.analysis.MockInbredAnalyzer;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.controller.mock.MockProductServiceConfiguredForNE5112v1;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.TraitService;
import com.monsanto.eas.hiat.service.mock.mock.MockTraitService;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import com.monsanto.eas.hiat.view.InbredAnalysisXMLGenerator;
import com.monsanto.eas.hiat.view.mock.MockInbredAnalysisXMLGenerator;
import com.monsanto.wst.dao.GenericDAO;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredAnalysisController_UT extends HIATUnitTest {
  private MockTraitService traitService;
  private ProductService productService;


  public void setUp() throws Exception {
    traitService = new MockTraitService();
    productService = new MockProductServiceConfiguredForNE5112v1();
  }

  public void testNoProductsNoTraitEnteredReturnsErrors() throws Exception {
    InbredAnalysisController controller = new InbredAnalysisController(new MockConfigDAO(), traitService, productService, new MockInbredAnalyzer(), new InbredAnalysisXMLGenerator());
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    controller.generateAnalysis(helper);
    assertFalse(helper.wasErrorGenerated());
    assertTrue(helper.wasSentTo(InbredAnalysisController.INBRED_ANALYSIS_JSP));
    assertEquals("false", helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    List<String> errorsList = getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertNotNull(errorsList);
    assertTrue(errorsList.contains(AnalysisController.ENTER_ATLEAST_ONE_PRODUCT));
    assertTrue(errorsList.contains(AnalysisController.ENTER_ATLEAST_ONE_TRAIT));
  }

  public void testParamsAreSentBackWithResults() throws Exception {
    InbredAnalysisController controller = new InbredAnalysisController(new MockConfigDAO(), traitService, productService, new MockInbredAnalyzer(), new InbredAnalysisXMLGenerator());
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    String testProductName = "NE5112_v1";
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, testProductName);
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    controller.generateAnalysis(helper);
    String productNamePassed = getRequestAttributeValue(helper, AnalysisConstants.PRODUCT_NAME);
    assertEquals(testProductName, productNamePassed);
    Collection<Trait> selectedTraits = getRequestAttributeValue(helper, AnalysisConstants.SELECTED_TRAITS);
    assertNotNull(selectedTraits);
    assertEquals(1, selectedTraits.size());
  }

  public void testProductAndTraitEntredPassedToCorrectJSP() throws Exception {
    InbredAnalysisController controller = new InbredAnalysisController(new MockConfigDAO(), traitService, productService, new MockInbredAnalyzer(), new InbredAnalysisXMLGenerator());
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    controller.generateAnalysis(helper);
    assertFalse(helper.wasErrorGenerated());
    assertNoErrorMessages(helper);
    assertEquals("true", helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    assertTrue(helper.wasSentTo(InbredAnalysisController.INBRED_ANALYSIS_JSP));
  }

  public void testCorrectValuesArePassedToAnalyzer() throws Exception {
    MockInbredAnalyzer analyzer = new MockInbredAnalyzer();
    InbredAnalysisController controller = new InbredAnalysisController(new MockConfigDAO(), traitService, productService, analyzer, new InbredAnalysisXMLGenerator());
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    controller.generateAnalysis(helper);
    Product expectedPassedProduct = productService.lookupProductById(2L);
    assertEquals(expectedPassedProduct, analyzer.getPassedProduct());
    Trait expectedPassedTrait = traitService.getTestTrait(1L);
    assertEquals(expectedPassedTrait, analyzer.getPassedTrait());
  }

  public void testCorrectResultIsReturnedFromAnalyzer() throws Exception {
    InbredAnalysis testInbredAnalysis = new MockInbredAnalysis();
    MockInbredAnalyzer analyzer = new MockInbredAnalyzer(testInbredAnalysis);
    InbredAnalysisController controller = new InbredAnalysisController(new MockConfigDAO(), traitService, productService, analyzer, new InbredAnalysisXMLGenerator());
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    controller.generateAnalysis(helper);
    assertFalse(helper.wasErrorGenerated());
    assertNoErrorMessages(helper);
    assertEquals("true", helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));

    List<InbredAnalysis> analysisResultList = getRequestAttributeValue(helper, InbredAnalysisController.INBRED_ANALYSIS_RESULTS);
    assertNotNull(analysisResultList);
    assertEquals(1, analysisResultList.size());
    assertEquals(testInbredAnalysis, analysisResultList.get(0));
  }

  public void testParameterScreen_TraitsArePassedCorrectJSPCalled() throws Exception {
    MockInbredAnalysisControllerForPublicNotSpecified controller = new MockInbredAnalysisControllerForPublicNotSpecified(new MockConfigDAO(), traitService, productService, new MockInbredAnalyzer());
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    controller.notSpecified(helper);
    assertFalse(helper.wasErrorGenerated());
    assertTrue(helper.wasSentTo(InbredAnalysisController.INBRED_ANALYSIS_JSP));
    assertEquals("false", helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    List<String> errorsList = getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertNotNull(errorsList);
    assertTrue(errorsList.isEmpty());

    List<Trait> traits = getRequestAttributeValue(helper, AnalysisConstants.TRAITS_LIST);
    assertNotNull(traits);
    assertFalse(traits.isEmpty());
  }

  public void testDownloadTest() throws Exception {
    InbredAnalysis testInbredAnalysis = new MockInbredAnalysis();
    MockInbredAnalyzer analyzer = new MockInbredAnalyzer(testInbredAnalysis);
    MockInbredAnalysisXMLGenerator xmlGenerator = new MockInbredAnalysisXMLGenerator();
    InbredAnalysisController controller = new InbredAnalysisController(new MockConfigDAO(), traitService, productService, analyzer, xmlGenerator);
    MockUCCHelperForWriteToExcel helper = new MockUCCHelperForWriteToExcel();
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1", "2"});
    controller.downloadInbredAnalysis(helper);
    assertFalse(helper.wasErrorGenerated());
    assertEquals(AnalysisConstants.STYLESHEET_INBRED_ANALYSIS_XSL, helper.getStylesheetUsed());
    assertTrue(xmlGenerator.wasGetXmlContentCalled());
  }

  private void assertNoErrorMessages(UCCHelper helper) {
    List<String> errorsList = getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertNotNull(errorsList);
    assertTrue("Expected no errors, but had: " + errorsList.toString(), errorsList.isEmpty());
  }

  @SuppressWarnings("unchecked")
  private <T> T getRequestAttributeValue(UCCHelper helper, String attributeName) {
    return (T) helper.getRequestAttributeValue(attributeName);
  }

  private static class MockInbredAnalysisControllerForPublicNotSpecified extends InbredAnalysisController {
    protected MockInbredAnalysisControllerForPublicNotSpecified(GenericDAO<HIATConfiguration, Long> configDAO, TraitService traitService, ProductService productService, InbredAnalyzer analyzer) {
      super(configDAO, traitService, productService, analyzer, new InbredAnalysisXMLGenerator());
    }

    @Override
    public void notSpecified(UCCHelper helper) throws IOException {
      super.notSpecified(helper);
    }
  }
}