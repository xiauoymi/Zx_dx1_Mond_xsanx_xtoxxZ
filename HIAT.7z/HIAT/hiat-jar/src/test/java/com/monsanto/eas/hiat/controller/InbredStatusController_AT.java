package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.hiat.analysis.InbredStatus;
import com.monsanto.eas.hiat.analysis.InbredStatusDetail;
import com.monsanto.eas.hiat.controller.mock.MockInbredStatusController;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.HIATDatabaseTestCase;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.eas.hiat.util.AnalysisTestConstants;
import com.monsanto.eas.hiat.util.TestUtil;
import com.monsanto.eas.hiat.view.InbredStatusXMLGenerator;

import java.io.IOException;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * Created by User: vvvelu Date: Feb 10, 2009 Time: 1:03:40 PM
 */
public class InbredStatusController_AT extends HIATDatabaseTestCase {
  MockInbredStatusController inbredAnalysisController;

  public void setUp() throws Exception {
    super.setUp();
    setUpProductTraitData(false);
    inbredAnalysisController = new MockInbredStatusController(new TestInitService().initTraitService(),
            new TestInitService().initInbredAnalyzer(), new TestInitService().initProductService(), new InbredStatusXMLGenerator());
  }

  public void test_Method_DisplayAnalysisParameters() throws IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    inbredAnalysisController.run(helper);
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
    List<Trait> traits = TestUtil.getRequestAttributeValue(helper, AnalysisConstants.TRAITS_LIST);
    assertNotNull(traits);
    assertTrue(traits.size() >= 3);
  }

  public void test_Method_GenerateAnalysis_NoProductsEntered() throws IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    inbredAnalysisController.run(helper);
    List<String> errorsList = TestUtil.getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    assertEquals(AnalysisController.ENTER_ATLEAST_ONE_PRODUCT, errorsList.get(0));
    List<Trait> traits = TestUtil.getRequestAttributeValue(helper, AnalysisConstants.TRAITS_LIST);
    assertNotNull(traits);
    assertTrue(traits.size() >= 3);
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }

  public void test_Method_GenerateAnalysis_NoTraitsSelected() throws IOException {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, getTestProduct().getProductNames().get(ProductNameType.BASE_PRECOMMERCIAL));
    inbredAnalysisController.run(helper);
    List<String> errorsList = TestUtil.getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    assertEquals(AnalysisController.ENTER_ATLEAST_ONE_TRAIT, errorsList.get(0));
    List<Trait> traits = TestUtil.getRequestAttributeValue(helper, AnalysisConstants.TRAITS_LIST);
    assertNotNull(traits);
    assertTrue(traits.size() >= 3);
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }

  public void test_Method_GenerateAnalysis_NoProductsAvailable_ForTheInputProductName() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "XYZ");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"3"});
    inbredAnalysisController.run(helper);
    List<String> errorsList = TestUtil.getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    assertEquals(AnalysisController.NO_MATCHING_PRODUCT_FOUND, errorsList.get(0));
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }

  public void test_Method_GenerateAnalysis_NoProductsAvailable_ForTheInputProductName_WithWildCard() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "XYZ*");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"3"});
    inbredAnalysisController.run(helper);
    List<String> errorsList = TestUtil.getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    assertEquals(AnalysisController.NO_MATCHING_PRODUCT_FOUND, errorsList.get(0));
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }


  public void test_Method_DownloadInbredAnalysis() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    inbredAnalysisController.run(helper);
    assertFalse(helper.wasErrorGenerated());
  }


  public void test_Method_GenerateAnalysis_ValidProductTraitCombination_ResultReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, getTestProduct().getProductNames().get(ProductNameType.BASE_PRECOMMERCIAL));
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{getTestTrait().getId().toString()});
    inbredAnalysisController.run(helper);
    List<String> errorsList = TestUtil.getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertEquals(0, errorsList.size());
    assertEquals("true", helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    List<InbredStatus> analysis = TestUtil.getRequestAttributeValue(helper, InbredStatusController.INBRED_STATUS_RESULTS);
    assertEquals(1, analysis.size());
    assertEquals(getTestProduct().getBase(), analysis.get(0).getProduct());
    Collection<InbredStatusDetail> detailSet = analysis.get(0).getDetail();
    assertEquals(1, detailSet.size());
    InbredStatusDetail detail = detailSet.iterator().next();
    assertEquals(getTestTrait(), detail.getTrait());

    assertEquals(new GregorianCalendar(2009, 2, 2).getTime(), detail.getHandoffDate());
    assertEquals(new GregorianCalendar(2009, 3, 2).getTime(), detail.getPrimaryDate());
    assertEquals(10, detail.getInventory(InventoryType.PREFOUNDATION));
    assertEquals(20, detail.getInventory(InventoryType.GENERATION_1));
    assertEquals(30, detail.getInventory(InventoryType.GENERATION_2));
    assertEquals(2222, detail.getProduction(InventoryType.GENERATION_1));
    assertEquals("2,222", detail.getProductionQuantities().get(InventoryType.GENERATION_1).iterator().next().getFormattedQuantity());
    assertEquals(333, detail.getProduction(InventoryType.GENERATION_2));
    assertEquals(111, detail.getProduction(InventoryType.PREFOUNDATION));
  }
}
