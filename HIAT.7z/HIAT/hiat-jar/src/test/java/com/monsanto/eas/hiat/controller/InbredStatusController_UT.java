package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.hiat.analysis.InbredStatus;
import com.monsanto.eas.hiat.analysis.InbredStatusDetail;
import com.monsanto.eas.hiat.controller.mock.MockInbredStatusAnalyzer;
import com.monsanto.eas.hiat.controller.mock.MockInbredStatusController;
import com.monsanto.eas.hiat.controller.mock.MockProductServiceConfiguredForNE5112v1;
import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.service.mock.mock.MockTraitService;
import com.monsanto.eas.hiat.util.AnalysisTestConstants;
import com.monsanto.eas.hiat.util.DateTestUtil;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import com.monsanto.eas.hiat.util.TestUtil;
import com.monsanto.eas.hiat.view.excel.InbredStatusExcelGenerator;
import com.monsanto.eas.hiat.view.mock.MockInbredStatusXMLGenerator;

import java.io.OutputStream;
import java.util.*;

/**
 * Created by vvvelu Date: Feb 10, 2009 Time: 10:50:12 AM
 */
public class InbredStatusController_UT extends HIATUnitTest {
  private MockInbredStatusController inbredAnalysisController;
  private MockInbredStatusXMLGenerator xmlGenerator;
  private MockInbredStatusAnalyzer analyzer;
  private MockTraitService traitService;

  public void setUp() throws Exception {
    xmlGenerator = new MockInbredStatusXMLGenerator();
    analyzer = new MockInbredStatusAnalyzer();
    traitService = new MockTraitService();
    inbredAnalysisController = new MockInbredStatusController(traitService,
            analyzer, new MockProductServiceConfiguredForNE5112v1(), xmlGenerator);
  }

  public void testTraitListUsedDoesNotIncludeInactives() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    inbredAnalysisController.run(helper);

    assertFalse(traitService.wasGetActiveTraitsCalled());
    assertTrue(traitService.wasGetAllTraitsCalled());
  }


  public void testNotSpecified_ReferenceValuesReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    inbredAnalysisController.run(helper);
    List<Trait> traitList = TestUtil.getRequestAttributeValue(helper, AnalysisConstants.TRAITS_LIST);
    assertEquals(4, traitList.size());
    Trait trait = traitList.get(0);
    assertEquals("WHM", trait.getCode());
    assertEquals("HXCB", trait.getCommercialName());
    assertEquals("HXCB", trait.getFullName());
    assertTrue(trait.getParentTraits().isEmpty());
    trait = traitList.get(1);
    assertEquals("FWM", trait.getCode());
    assertEquals("HXRW", trait.getCommercialName());
    assertEquals("HXRW", trait.getFullName());
    assertTrue(trait.getParentTraits().isEmpty());
    trait = traitList.get(2);
    assertEquals("MSL", trait.getCode());
    assertEquals("HXCB-HXRW", trait.getCommercialName());
    assertEquals("HXCB-HXRW", trait.getFullName());
    assertTrue(trait.getParentTraits().isEmpty());
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }

  public void testGenerateAnalysis_SingleProductEntered_AnalysisListReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "generateAnalysis");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    inbredAnalysisController.run(helper);
    List<Trait> traitList = TestUtil.getRequestAttributeValue(helper, AnalysisConstants.TRAITS_LIST);
    assertEquals(4, traitList.size());
    assertEquals("true", helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    List<InbredStatus> statusResultList = TestUtil.getRequestAttributeValue(helper, InbredStatusController.INBRED_STATUS_RESULTS);
    assertEquals(1, statusResultList.size());
    InbredStatus status = statusResultList.get(0);
    Product product = status.getProduct();
    assertEquals("XYZ", product.getTrait().getCode());
    assertEquals("TEST", product.getTraitVersion());
    assertFalse(product.isPrimary());
    Collection<InbredStatusDetail> detailSet = status.getDetail();
    for (InbredStatusDetail detail : detailSet) {
      assertEquals(new GregorianCalendar(2009, Calendar.JANUARY, 11).getTime(), detail.getHandoffDate());
      assertEquals(new GregorianCalendar(2009, Calendar.MARCH, 1).getTime(), detail.getPrimaryDate());
      Trait trait = detail.getTrait();
      assertEquals("CHC", trait.getCode());
      assertEquals("ABC-DEF", trait.getFullName());
      Map<InventoryType, InventoryEntry> inventoryQuantities = detail.getInventoryQuantities();
      assertEquals(30, inventoryQuantities.get(InventoryType.PREFOUNDATION).getQuantity());
      assertEquals(10, inventoryQuantities.get(InventoryType.GENERATION_1).getQuantity());
      assertEquals(20, inventoryQuantities.get(InventoryType.GENERATION_2).getQuantity());
      Map<InventoryType, Collection<ProductionEntry>> productionQuantities = detail.getProductionQuantities();
      assertEquals(33, productionQuantities.get(InventoryType.PREFOUNDATION).iterator().next().getQuantity());
      assertEquals(11, productionQuantities.get(InventoryType.GENERATION_1).iterator().next().getQuantity());
      assertEquals(22, productionQuantities.get(InventoryType.GENERATION_2).iterator().next().getQuantity());
    }
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }

  public void testGenerateAnalysis_MultipleProductNamesEntered_AnalysisListReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "generateAnalysis");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1\nDKC*");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    inbredAnalysisController.run(helper);
    List<Trait> traitList = TestUtil.getRequestAttributeValue(helper, AnalysisConstants.TRAITS_LIST);
    assertEquals(4, traitList.size());
    assertEquals("true", helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    List<InbredStatus> statusResultList = TestUtil.getRequestAttributeValue(helper, InbredStatusController.INBRED_STATUS_RESULTS);
    assertEquals(2, statusResultList.size());
    InbredStatus status = statusResultList.get(0);
    Product product = status.getProduct();
    assertEquals("XYZ", product.getTrait().getCode());
    assertEquals("TEST", product.getTraitVersion());
    assertFalse(product.isPrimary());
    Collection<InbredStatusDetail> detailSet = status.getDetail();
    for (InbredStatusDetail detail : detailSet) {
      DateTestUtil.assertDatesEqual(new GregorianCalendar(2009, Calendar.JANUARY, 11).getTime(), detail.getHandoffDate());
      DateTestUtil.assertDatesEqual(new GregorianCalendar(2009, Calendar.MARCH, 1).getTime(), detail.getPrimaryDate());
      Trait trait = detail.getTrait();
      assertEquals("CHC", trait.getCode());
      assertEquals("ABC-DEF", trait.getFullName());
      Map<InventoryType, InventoryEntry> inventoryQuantities = detail.getInventoryQuantities();
      assertEquals(30, inventoryQuantities.get(InventoryType.PREFOUNDATION).getQuantity());
      assertEquals(10, inventoryQuantities.get(InventoryType.GENERATION_1).getQuantity());
      assertEquals(20, inventoryQuantities.get(InventoryType.GENERATION_2).getQuantity());
      Map<InventoryType, Collection<ProductionEntry>> productionQuantities = detail.getProductionQuantities();
      assertEquals(33, productionQuantities.get(InventoryType.PREFOUNDATION).iterator().next().getQuantity());
      assertEquals(11, productionQuantities.get(InventoryType.GENERATION_1).iterator().next().getQuantity());
      assertEquals(22, productionQuantities.get(InventoryType.GENERATION_2).iterator().next().getQuantity());
    }

    status = statusResultList.get(1);
    product = status.getProduct();
    assertEquals("DKC1", product.getTrait().getCode());
    assertEquals("DKC112", product.getTraitVersion());
    assertFalse(product.isPrimary());
    detailSet = status.getDetail();
    for (InbredStatusDetail detail : detailSet) {
      assertEquals(new GregorianCalendar(2009, Calendar.FEBRUARY, 11).getTime(), detail.getHandoffDate());
      assertEquals(new GregorianCalendar(2009, Calendar.APRIL, 1).getTime(), detail.getPrimaryDate());
      Trait trait = detail.getTrait();
      assertEquals("CHC", trait.getCode());
      assertEquals("ABC-DEF", trait.getFullName());
      Map<InventoryType, InventoryEntry> inventoryQuantities = detail.getInventoryQuantities();
      assertEquals(333, inventoryQuantities.get(InventoryType.PREFOUNDATION).getQuantity());
      assertEquals(111, inventoryQuantities.get(InventoryType.GENERATION_1).getQuantity());
      assertEquals(222, inventoryQuantities.get(InventoryType.GENERATION_2).getQuantity());
      Map<InventoryType, Collection<ProductionEntry>> productionQuantities = detail.getProductionQuantities();
      assertEquals(303, productionQuantities.get(InventoryType.PREFOUNDATION).iterator().next().getQuantity());
      assertEquals(101, productionQuantities.get(InventoryType.GENERATION_1).iterator().next().getQuantity());
      assertEquals(202, productionQuantities.get(InventoryType.GENERATION_2).iterator().next().getQuantity());
    }
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }


  public void testGenerateAnalysis_InputCriteriaDoesNotProduceAnyResult_AnalysisListReturnedIsEmpty() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "generateAnalysis");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "ABC123");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    inbredAnalysisController.run(helper);
    List<Trait> traitList = TestUtil.getRequestAttributeValue(helper, AnalysisConstants.TRAITS_LIST);
    assertEquals(4, traitList.size());
    assertEquals("true", helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    List<InbredStatus> statusResultList = TestUtil.getRequestAttributeValue(helper, InbredStatusController.INBRED_STATUS_RESULTS);
    assertEquals(0, statusResultList.size());
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }

  public void test_Method_GenerateAnalysis_NoProductsAvailable_ForTheInputProductName() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "XYZ");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"3"});
    inbredAnalysisController.run(helper);
    List<String> errorsList = TestUtil.getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    assertEquals(AnalysisController.NO_MATCHING_PRODUCT_FOUND, errorsList.get(0));
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }

  public void test_Method_GenerateAnalysis_NoProductsAvailable_ForTheInputProductName_WithWildCard() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.GENERATE_ANALYSIS);
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "XYZ*");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"3"});
    inbredAnalysisController.run(helper);
    List<String> errorsList = TestUtil.getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertEquals(1, errorsList.size());
    assertEquals(AnalysisController.NO_MATCHING_PRODUCT_FOUND, errorsList.get(0));
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }


  public void testGenerateAnalysis_ProductNameNotEntered_ErrorListReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "generateAnalysis");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1"});
    inbredAnalysisController.run(helper);
    List<Trait> traitList = TestUtil.getRequestAttributeValue(helper, AnalysisConstants.TRAITS_LIST);
    assertNotNull(traitList);
    assertEquals(4, traitList.size());
    List<String> errorList = TestUtil.getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertEquals(AnalysisController.ENTER_ATLEAST_ONE_PRODUCT, errorList.get(0));
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }

  public void testGenerateAnalysis_TraitsNotSelected_ErrorListReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "generateAnalysis");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "ABC");

    inbredAnalysisController.run(helper);
    List<Trait> traitList = TestUtil.getRequestAttributeValue(helper, AnalysisConstants.TRAITS_LIST);
    assertEquals(4, traitList.size());
    List<String> errorList = TestUtil.getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertEquals(AnalysisController.ENTER_ATLEAST_ONE_TRAIT, errorList.get(0));
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }

  public void testGenerateAnalysis_ProductsOrTraitsNotSelected_ErrorListReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "generateAnalysis");

    inbredAnalysisController.run(helper);
    List<Trait> traitList = TestUtil.getRequestAttributeValue(helper, AnalysisConstants.TRAITS_LIST);
    assertNotNull(traitList);
    assertEquals(4, traitList.size());
    List<String> errorList = TestUtil.getRequestAttributeValue(helper, AnalysisController.ERRORS_LIST);
    assertEquals(AnalysisController.ENTER_ATLEAST_ONE_PRODUCT, errorList.get(0));
    assertEquals(AnalysisController.ENTER_ATLEAST_ONE_TRAIT, errorList.get(1));
    assertTrue(helper.wasSentTo(InbredStatusController.WEB_INF_JSP_INBREDANALYSIS_PARAM));
  }

/* todo need to get test working again after switch to fake-excel export
  public void testDownloadInbredAnalysis() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "downloadInbredAnalysis");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"1", "2"});
    inbredAnalysisController.run(helper);
    Collection<Product> products = new ArrayList<Product>();
    ProductImpl product = new ProductImpl();
    product.setId(2L);
    products.add(product);
    assertEquals(products.size(), analyzer.getProductListPassed().size());
    assertTrue(analyzer.getProductListPassed().contains(product));
    Collection<Trait> traits = new ArrayList<Trait>();
    traits.add(new MockTrait(1L));
    traits.add(new MockTrait(2L));
    assertEquals(traits, analyzer.getTraitListPassed());
    fail("need ot get test working again after switch back to fake-excel export");
//    assertEquals(analyzer.getAnalysisList(), xlsGenerator.getResultsPassedIn());
//    assertTrue(xlsGenerator.wasGenerateStatusWorkbookCalled());
  }
*/

  private class MockInbredStatusExcelGenerator extends InbredStatusExcelGenerator {
    private boolean generateStatusWorkbookCalled = false;
    private Collection<InbredStatus> resultsPassedIn = null;

    @Override
    public void generateStatusWorkbook(OutputStream output, Collection<InbredStatus> statusResults, Collection<String> missingProducts) {
      resultsPassedIn = statusResults;
      generateStatusWorkbookCalled = true;
    }

    public boolean wasGenerateStatusWorkbookCalled() {
      return generateStatusWorkbookCalled;
    }

    public Collection<InbredStatus> getResultsPassedIn() {
      return resultsPassedIn;
    }
  }
}

