package com.monsanto.eas.hiat.controller;

import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.config.MockConfiguration;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.mock.MockDAO;

import java.util.List;
import java.util.ArrayList;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockConfigDAO extends MockDAO<HIATConfiguration, Long> {
  public MockConfigDAO() {
    super(getMockConfigList());
  }

  private static List<HIATConfiguration> getMockConfigList() {
    List<HIATConfiguration> configList = new ArrayList<HIATConfiguration>(1);
    configList.add(new MockConfiguration());
    return configList;
  }
}
