package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
class MockHIATController extends HIATController {
  private boolean implementationRan = false;

  MockHIATController() {
    super(new MockConfigDAO());
  }

  public boolean wasImplementationRan() {
    return implementationRan;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    implementationRan = true;
  }
}
