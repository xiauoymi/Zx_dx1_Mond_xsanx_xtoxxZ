package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
class MockHIATControllerForAuthorization extends HIATController {
  private boolean implementationRan = false;
  private final boolean isAuthorized;

  MockHIATControllerForAuthorization(boolean userAuthorized) {
    super(new MockConfigDAO());
    isAuthorized = userAuthorized;
  }

  @Override
  protected boolean isUserAuthorized(UCCHelper helper) {
    return isAuthorized;
  }

  @Override
  protected boolean isAdmin(UCCHelper helper) {
    return false;
  }

  public boolean wasImplementationRan() {
    return implementationRan;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    implementationRan = true;
  }
}
