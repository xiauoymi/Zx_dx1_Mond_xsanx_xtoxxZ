package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
class MockHIATControllerThrowsException extends HIATController {
  private boolean implementationRan = false;

  MockHIATControllerThrowsException() {
    super(new MockConfigDAO());
  }

  public boolean wasImplementationRan() {
    return implementationRan;
  }

  protected boolean isUserAuthorized(UCCHelper helper) {
    return true;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    if (!implementationRan)
      throw new IOException("exception");
    super.run(helper);
  }
}
