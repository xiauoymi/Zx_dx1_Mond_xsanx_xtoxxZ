package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
class MockHelperForGroup extends MockUCCHelper {
  private String roleChecked;

  public MockHelperForGroup() {
    super("MOCK");
  }

  @Override
  public boolean isUserInRole(String s) {
    this.roleChecked = s;
    return super.isUserInRole(s);
  }

  public String getRoleChecked() {
    return roleChecked;
  }
}
