package com.monsanto.eas.hiat.controller;

import com.monsanto.eas.hiat.service.LoadService;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockLoadService implements LoadService {
  public Date getLastLoadDate() {
    return new Date();
  }
}
