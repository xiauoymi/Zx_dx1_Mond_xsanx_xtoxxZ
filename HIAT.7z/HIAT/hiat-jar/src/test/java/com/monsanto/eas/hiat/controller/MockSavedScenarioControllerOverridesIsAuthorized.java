package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.service.ScenarioService;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class MockSavedScenarioControllerOverridesIsAuthorized extends SavedScenarioController {
  public MockSavedScenarioControllerOverridesIsAuthorized(ScenarioService scenarioService) {
    super(new MockConfigDAO(), scenarioService);
  }

  protected boolean isUserAuthorized(UCCHelper helper) {
    return true;
  }
}
