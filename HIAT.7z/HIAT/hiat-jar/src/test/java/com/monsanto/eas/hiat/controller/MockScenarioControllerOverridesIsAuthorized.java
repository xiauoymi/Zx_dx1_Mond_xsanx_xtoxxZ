package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.analysis.HybridAnalyzer;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.ScenarioService;
import com.monsanto.eas.hiat.service.TraitService;
import com.monsanto.eas.hiat.view.HybridAnalysisXMLGenerator;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class MockScenarioControllerOverridesIsAuthorized extends ScenarioController {
  public MockScenarioControllerOverridesIsAuthorized(ScenarioService scenarioService, HybridAnalyzer analyzer, TraitService traitService, ProductService productService, HybridAnalysisXMLGenerator xmlGenerator) {
    super(new MockConfigDAO(), scenarioService, analyzer, traitService, productService, xmlGenerator);
  }

  protected boolean isUserAuthorized(UCCHelper helper) {
    return true;
  }
}
