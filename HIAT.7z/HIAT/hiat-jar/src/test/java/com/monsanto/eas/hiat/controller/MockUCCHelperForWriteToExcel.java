package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
class MockUCCHelperForWriteToExcel extends MockUCCHelper {
  private String stylesheetUsed = null;

  public MockUCCHelperForWriteToExcel() {
    super("MOCK");
  }

  @Override
  public void writeToExcel(Document document, String s, Map map) throws IOException {
    stylesheetUsed = s;
  }

  @Override
  public void writeToExcel(Document document, String s) throws IOException {
    stylesheetUsed = s;
  }

  @Override
  public String getStylesheetUsed() {
    return stylesheetUsed;
  }
}
