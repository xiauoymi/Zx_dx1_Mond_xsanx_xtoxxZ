/*
 MockUCCHelperOverridesAutheticatedUserId was created on Feb 25, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;

/**
 * Filename:    $RCSfile: MockUCCHelperOverridesAutheticatedUserId.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-02-25 20:12:55 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class MockUCCHelperOverridesAutheticatedUserId extends MockUCCHelper {
  private String authecticatedUserId;

  public MockUCCHelperOverridesAutheticatedUserId(String s, String authecticatedUserId) {
    super(s, authecticatedUserId);
    this.authecticatedUserId = authecticatedUserId;
  }

  public MockUCCHelperOverridesAutheticatedUserId(String s) {
    super(s);
  }

  public String getAuthenticatedUserID() {
    return this.authecticatedUserId;
  }
}