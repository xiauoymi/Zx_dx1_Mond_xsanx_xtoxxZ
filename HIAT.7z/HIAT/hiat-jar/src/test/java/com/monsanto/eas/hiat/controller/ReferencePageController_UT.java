package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.util.HIATUnitTest;

public class ReferencePageController_UT extends HIATUnitTest {
  public void testHomePageForwardsToHomePage() throws Exception {
    ReferencePageController controller = new MockReferencePageController();
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
    HIATConfiguration config = (HIATConfiguration) helper.getRequestAttributeValue(ReferencePageController.CONFIGURATION);
    assertNotNull(config);
    assertTrue(helper.wasSentTo(ReferencePageController.REFERENCE_PAGE_LOCATION));
  }

  private class MockReferencePageController extends ReferencePageController {
    private MockReferencePageController() {
      super(new MockConfigDAO(), new MockLoadService());
    }

    protected boolean isUserAuthorized(UCCHelper helper) {
      return true;
    }
  }
}
