/*
 SavedScenarioController_AT was created on Mar 20, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.eas.hiat.controller.constants.ScenarioConstants;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.hibernate.HIATDatabaseTestCase;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.eas.hiat.controller.AnalysisConstants;
import org.apache.commons.lang.time.DateUtils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: SavedScenarioController_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-04-14 19:13:15 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class SavedScenarioController_AT extends HIATDatabaseTestCase {
  private UseCaseController savedScenarioControler;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    savedScenarioControler = new MockSavedScenarioControllerOverridesIsAuthorized(new TestInitService().initScenarioService());
    saveTestScenario();
  }

  private void saveTestScenario() throws IOException {
    setUpProductTraitData(true);
    MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario test 1");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_DESC, "scenario test desc 1");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, getTestProduct().getProductNames().get(
        ProductNameType.BASE_MANUFACTURING));
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{getTestTrait().getId().toString()});
    helper.setRequestParameterValue("method", "saveScenario");
    UseCaseController scenarioController = new MockScenarioControllerOverridesIsAuthorized(
        new TestInitService().initScenarioService(), new TestInitService().initHybridAnalyzer(),
        new TestInitService().initTraitService(), new TestInitService().initProductService(),
        new TestInitService().initHybridXMLGenerator());
    scenarioController.run(helper);
  }

  public void testNotSpecified_VerifyReposnse() throws Exception {
    MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");
    savedScenarioControler.run(helper);
    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    List<String> owners = (List<String>) helper.getRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE);
    String owner = (String) helper.getRequestAttributeValue(ScenarioConstants.OWNER);
    String sortKey = (String) helper.getRequestAttributeValue(ScenarioConstants.SORT_KEY);
    String sortDir = (String) helper.getRequestAttributeValue(ScenarioConstants.SORT_DIR);
    assertTrue(scenarios.size() >= 1);
    assertTrue(owners.size() >= 1);
    assertEquals("testId", owner);
    assertEquals("user", sortKey);
    assertEquals("asc", sortDir);
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVED_SCENARIOS_JSP));
  }

  private UseCaseController getMockSavedScenarioControllerOverridesIsAuthorized() {
    return new TestInitService().getController("mockSavedScenarioControllerOverridesIsAuthorized");
  }

  public void testSearchSavedScenariosByCriteria_ReturnsScenarios() throws Exception {
    MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SORT_KEY, "user");
    helper.setRequestParameterValue(ScenarioConstants.SORT_DIR, "desc");
    helper.setRequestParameterValue(ScenarioConstants.OWNER, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario test 1");
    SimpleDateFormat sdf = new SimpleDateFormat(ScenarioConstants.DATE_FORMAT);
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_FROM, sdf.format(DateUtils.addDays(new Date(), -1)));
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_TO, sdf.format(DateUtils.addDays(new Date(), 1)));

    helper.setRequestParameterValue(AnalysisConstants.METHOD, "searchSavedScenariosByCriteria");
    savedScenarioControler.run(helper);

    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    List<String> owners = (List<String>) helper.getRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE);
    String owner = (String) helper.getRequestAttributeValue(ScenarioConstants.OWNER);
    String sortKey = (String) helper.getRequestAttributeValue(ScenarioConstants.SORT_KEY);
    String sortDir = (String) helper.getRequestAttributeValue(ScenarioConstants.SORT_DIR);
    assertEquals("scenario test 1", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertEquals(sdf.format(DateUtils.addDays(new Date(), -1)), sdf.format(helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_FROM)));
    assertEquals(sdf.format(DateUtils.addDays(new Date(), 1)), sdf.format(helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_TO)));
    assertEquals(1, scenarios.size());
    assertTrue(owners.size() >= 1);
    assertEquals("testId", owner);
    assertEquals("user", sortKey);
    assertEquals("desc", sortDir);
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVED_SCENARIOS_JSP));
  }

  public void testDeleteScenario_ScenarioIsDeleted() throws Exception {
    MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");

    helper.setRequestParameterValue(ScenarioConstants.SORT_KEY, "user");
    helper.setRequestParameterValue(ScenarioConstants.SORT_DIR, "desc");
    helper.setRequestParameterValue(ScenarioConstants.OWNER, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario test 1");
    SimpleDateFormat sdf = new SimpleDateFormat(ScenarioConstants.DATE_FORMAT);
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_FROM, sdf.format(DateUtils.addDays(new Date(), -1)));
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_TO, sdf.format(DateUtils.addDays(new Date(), 1)));
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "searchSavedScenariosByCriteria");
    savedScenarioControler.run(helper);
    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    assertEquals(1, scenarios.size());

    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_IDS_TO_DELTETE, new String[]{scenarios.get(0).getId().toString()});

    helper.setRequestParameterValue(AnalysisConstants.METHOD, "deleteScenario");
    savedScenarioControler.run(helper);

    assertEquals(1, helper.getRequestAttributeValue(ScenarioConstants.NUM_SCENARIO_DELTETED));

    helper.setRequestParameterValue(ScenarioConstants.SORT_KEY, "user");
    helper.setRequestParameterValue(ScenarioConstants.SORT_DIR, "desc");
    helper.setRequestParameterValue(ScenarioConstants.OWNER, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario test 1");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_FROM, "");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_TO, "");

    helper.setRequestParameterValue(ScenarioConstants.SORT_KEY, "user");
    helper.setRequestParameterValue(ScenarioConstants.SORT_DIR, "desc");
    helper.setRequestParameterValue(ScenarioConstants.OWNER, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario test 1");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_FROM, sdf.format(DateUtils.addDays(new Date(), -1)));
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_TO, sdf.format(DateUtils.addDays(new Date(), 1)));
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "searchSavedScenariosByCriteria");

    UseCaseController controller2 = getMockSavedScenarioControllerOverridesIsAuthorized();
    controller2.run(helper);
    scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    assertEquals(0, scenarios.size());
  }

    }
