package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.controller.constants.ScenarioConstants;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.scenario.ScenarioDetail;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioImpl;
import com.monsanto.eas.hiat.service.ScenarioService;
import com.monsanto.eas.hiat.service.mock.mock.MockScenarioService;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import org.apache.commons.lang.time.DateUtils;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class SavedScenarioController_UT extends HIATUnitTest {
  private MockUCCHelper helper;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelperOverridesAutheticatedUserId("MOCK", "testId");
  }

  public void testNonSpecified_NoUserHasSavedScenarios_VerifyResponse() throws Exception {
    MockScenarioService service = new MockScenarioService(new ArrayList<Scenario>(), new ArrayList<String>());
    SavedScenarioController controller = new MockSavedScenarioController(service);
    controller.run(helper);
    assertNull(service.getName());
    assertNull(service.getUserId());
    assertNull(service.getSaveDataFrom());
    assertNull(service.getSaveDateTo());
    assertEquals(2, service.getSortKeys().length);
    assertEquals("username", service.getSortKeys()[0]);
    assertEquals("name", service.getSortKeys()[1]);
    assertNull(service.getSortDir());
    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    List<String> owners = (List<String>) helper.getRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE);
    assertEquals(0, scenarios.size());
    assertEquals(0, owners.size());
    assertEquals("user", helper.getRequestAttributeValue(ScenarioConstants.SORT_KEY));
    assertEquals("asc", helper.getRequestAttributeValue(ScenarioConstants.SORT_DIR));
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVED_SCENARIOS_JSP));
  }

  public void testNonSpecified_CurrentUserHasSavedScenarios_ReturnsScenariosForCurrentUserInList() throws Exception {
    ArrayList<Scenario> scenarioList = new ArrayList<Scenario>();
    scenarioList.add(new ScenarioImpl(null, null, null, null, new Date(), false, null, null, new HashSet<ScenarioDetail>()
    ));
    scenarioList.add(new ScenarioImpl(null, null, null, null, new Date(), false, null, null, new HashSet<ScenarioDetail>()
    ));
    ArrayList<String> ownerList = new ArrayList<String>();
    ownerList.add("testId1");
    ownerList.add("testId");
    ownerList.add("testId3");
    MockScenarioService service = new MockScenarioService(scenarioList, ownerList);
    SavedScenarioController controller = new MockSavedScenarioController(service);
    controller.run(helper);
    assertNull(service.getName());
    assertEquals("testId", service.getUserId());
    assertNull(service.getSaveDataFrom());
    assertNull(service.getSaveDateTo());
    assertEquals(2, service.getSortKeys().length);
    assertEquals("username", service.getSortKeys()[0]);
    assertEquals("name", service.getSortKeys()[1]);
    assertNull(service.getSortDir());
    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    List<String> owners = (List<String>) helper.getRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE);
    assertEquals(2, scenarios.size());
    assertEquals(3, owners.size());
    assertEquals("testId", helper.getRequestAttributeValue(ScenarioConstants.OWNER));
    assertEquals("user", helper.getRequestAttributeValue(ScenarioConstants.SORT_KEY));
    assertEquals("asc", helper.getRequestAttributeValue(ScenarioConstants.SORT_DIR));
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVED_SCENARIOS_JSP));
  }

  public void testNonSpecified_CurrentUserHasNoSavedScenarios_ReturnsScenariosForAllUsersInList() throws Exception {
    ArrayList<Scenario> scenarioList = new ArrayList<Scenario>();
    scenarioList.add(new ScenarioImpl(null, null, null, null, new Date(), false, null, null, new HashSet<ScenarioDetail>()
    ));
    scenarioList.add(new ScenarioImpl(null, null, null, null, new Date(), false, null, null, new HashSet<ScenarioDetail>()
    ));
    ArrayList<String> ownerList = new ArrayList<String>();
    ownerList.add("testId1");
    ownerList.add("testId2");
    ownerList.add("testId3");
    MockScenarioService service = new MockScenarioService(scenarioList, ownerList);
    SavedScenarioController controller = new MockSavedScenarioController(service);
    controller.run(helper);
    assertNull(service.getName());
    assertNull(service.getUserId());
    assertNull(service.getSaveDataFrom());
    assertNull(service.getSaveDateTo());
    assertEquals(2, service.getSortKeys().length);
    assertEquals("username", service.getSortKeys()[0]);
    assertEquals("name", service.getSortKeys()[1]);
    assertNull(service.getSortDir());
    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    List<String> owners = (List<String>) helper.getRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE);
    assertEquals(2, scenarios.size());
    assertEquals(3, owners.size());
    assertNull(helper.getRequestAttributeValue(ScenarioConstants.OWNER));
    assertEquals("user", helper.getRequestAttributeValue(ScenarioConstants.SORT_KEY));
    assertEquals("asc", helper.getRequestAttributeValue(ScenarioConstants.SORT_DIR));
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVED_SCENARIOS_JSP));
  }

  public void testSearchSavedScenariosByCriteria_NoCriteriaPassed_VerifyResponse() throws Exception {
    helper.setRequestParameterValue("method", "searchSavedScenariosByCriteria");
    helper.setRequestParameterValue(ScenarioConstants.SORT_KEY, "");
    helper.setRequestParameterValue(ScenarioConstants.SORT_DIR, "");
    helper.setRequestParameterValue(ScenarioConstants.OWNER, "");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_FROM, "");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_TO, "");
    MockScenarioService service = new MockScenarioService(new ArrayList<Scenario>(), new ArrayList<String>());
    SavedScenarioController controller = new MockSavedScenarioController(service);
    controller.run(helper);
    assertEquals("", service.getName());
    assertEquals("", service.getUserId());
    assertNull(service.getSaveDataFrom());
    assertNull(service.getSaveDateTo());
    assertEquals(2, service.getSortKeys().length);
    assertEquals("username", service.getSortKeys()[0]);
    assertEquals("name", service.getSortKeys()[1]);
    assertEquals("", service.getSortDir());
    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    List<String> owners = (List<String>) helper.getRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE);
    assertEquals(0, scenarios.size());
    assertEquals(0, owners.size());
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVED_SCENARIOS_JSP));
    assertEquals("", helper.getRequestAttributeValue(ScenarioConstants.SORT_KEY));
    assertEquals("", helper.getRequestAttributeValue(ScenarioConstants.SORT_DIR));
    assertEquals("", helper.getRequestAttributeValue(ScenarioConstants.OWNER));
    assertEquals("", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertNull(helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_FROM));
    assertNull(helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_TO));
  }

  public void testSearchSavedScenariosByCriteria_CriteriaPassed_VerifyResponse() throws Exception {
    helper.setRequestParameterValue("method", "searchSavedScenariosByCriteria");
    helper.setRequestParameterValue(ScenarioConstants.SORT_KEY, "test");
    helper.setRequestParameterValue(ScenarioConstants.SORT_DIR, "asc");
    helper.setRequestParameterValue(ScenarioConstants.OWNER, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario name 1");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_FROM, "09-08-2009");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_TO, "10-09-2009");
    MockScenarioService service = new MockScenarioService(new ArrayList<Scenario>(), new ArrayList<String>());
    SavedScenarioController controller = new MockSavedScenarioController(service);
    controller.run(helper);
    assertEquals("scenario name 1", service.getName());
    assertEquals("testId", service.getUserId());
    assertEquals(parseDate("09-08-2009"), service.getSaveDataFrom());
    assertEquals(parseDate("10-09-2009"), service.getSaveDateTo());
    assertEquals(2, service.getSortKeys().length);
    assertEquals("username", service.getSortKeys()[0]);
    assertEquals("name", service.getSortKeys()[1]);
    assertEquals("asc", service.getSortDir());
    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    List<String> owners = (List<String>) helper.getRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE);
    assertEquals(0, scenarios.size());
    assertEquals(0, owners.size());
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVED_SCENARIOS_JSP));
    assertEquals("test", helper.getRequestAttributeValue(ScenarioConstants.SORT_KEY));
    assertEquals("asc", helper.getRequestAttributeValue(ScenarioConstants.SORT_DIR));
    assertEquals("testId", helper.getRequestAttributeValue(ScenarioConstants.OWNER));
    assertEquals("scenario name 1", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertEquals(parseDate("09-08-2009"), helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_FROM));
    assertEquals(parseDate("10-09-2009"), helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_TO));
  }

  public void testSearchSavedScenariosByCriteria_SortByUser_VerifyResponse() throws Exception {
    helper.setRequestParameterValue("method", "searchSavedScenariosByCriteria");
    helper.setRequestParameterValue(ScenarioConstants.SORT_KEY, "user");
    helper.setRequestParameterValue(ScenarioConstants.SORT_DIR, "asc");
    helper.setRequestParameterValue(ScenarioConstants.OWNER, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario name 1");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_FROM, "09-08-2009");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_TO, "10-09-2009");
    ArrayList<Scenario> scenarioList = new ArrayList<Scenario>();
    scenarioList.add(new ScenarioImpl(null, null, null, null, new Date(), false, null, null, new HashSet<ScenarioDetail>()
    ));
    scenarioList.add(new ScenarioImpl(null, null, null, null, new Date(), false, null, null, new HashSet<ScenarioDetail>()
    ));
    ArrayList<String> ownerList = new ArrayList<String>();
    ownerList.add("testId1");
    ownerList.add("testId2");
    ownerList.add("testId3");
    MockScenarioService service = new MockScenarioService(scenarioList, ownerList);
    SavedScenarioController controller = new MockSavedScenarioController(service);
    controller.run(helper);
    assertEquals("scenario name 1", service.getName());
    assertEquals("testId", service.getUserId());
    assertEquals(parseDate("09-08-2009"), service.getSaveDataFrom());
    assertEquals(parseDate("10-09-2009"), service.getSaveDateTo());
    assertEquals(2, service.getSortKeys().length);
    assertEquals("username", service.getSortKeys()[0]);
    assertEquals("name", service.getSortKeys()[1]);
    assertEquals("asc", service.getSortDir());
    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    List<String> owners = (List<String>) helper.getRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE);
    assertEquals(2, scenarios.size());
    assertEquals(3, owners.size());
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVED_SCENARIOS_JSP));
    assertEquals("user", helper.getRequestAttributeValue(ScenarioConstants.SORT_KEY));
    assertEquals("asc", helper.getRequestAttributeValue(ScenarioConstants.SORT_DIR));
    assertEquals("testId", helper.getRequestAttributeValue(ScenarioConstants.OWNER));
    assertEquals("scenario name 1", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertEquals(parseDate("09-08-2009"), helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_FROM));
    assertEquals(parseDate("10-09-2009"), helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_TO));
  }

  public void testSearchSavedScenariosByCriteria_SortByname_VerifyResponse() throws Exception {
    helper.setRequestParameterValue("method", "searchSavedScenariosByCriteria");
    helper.setRequestParameterValue(ScenarioConstants.SORT_KEY, "name");
    helper.setRequestParameterValue(ScenarioConstants.SORT_DIR, "asc");
    helper.setRequestParameterValue(ScenarioConstants.OWNER, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario name 1");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_FROM, "09-08-2009");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_TO, "10-09-2009");
    MockScenarioService service = new MockScenarioService(new ArrayList<Scenario>(), new ArrayList<String>());
    SavedScenarioController controller = new MockSavedScenarioController(service);
    controller.run(helper);
    assertEquals("scenario name 1", service.getName());
    assertEquals("testId", service.getUserId());
    assertEquals(parseDate("09-08-2009"), service.getSaveDataFrom());
    assertEquals(parseDate("10-09-2009"), service.getSaveDateTo());
    assertEquals(2, service.getSortKeys().length);
    assertEquals("name", service.getSortKeys()[0]);
    assertEquals("saveDate", service.getSortKeys()[1]);
    assertEquals("asc", service.getSortDir());
    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    List<String> owners = (List<String>) helper.getRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE);
    assertEquals(0, scenarios.size());
    assertEquals(0, owners.size());
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVED_SCENARIOS_JSP));
    assertEquals("name", helper.getRequestAttributeValue(ScenarioConstants.SORT_KEY));
    assertEquals("asc", helper.getRequestAttributeValue(ScenarioConstants.SORT_DIR));
    assertEquals("testId", helper.getRequestAttributeValue(ScenarioConstants.OWNER));
    assertEquals("scenario name 1", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertEquals(parseDate("09-08-2009"), helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_FROM));
    assertEquals(parseDate("10-09-2009"), helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_TO));
  }

  public void testSearchSavedScenariosByCriteria_SortBySaveDate_VerifyResponse() throws Exception {
    helper.setRequestParameterValue("method", "searchSavedScenariosByCriteria");
    helper.setRequestParameterValue(ScenarioConstants.SORT_KEY, "date");
    helper.setRequestParameterValue(ScenarioConstants.SORT_DIR, "asc");
    helper.setRequestParameterValue(ScenarioConstants.OWNER, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario name 1");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_FROM, "09-08-2009");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_TO, "10-09-2009");
    MockScenarioService service = new MockScenarioService(new ArrayList<Scenario>(), new ArrayList<String>());
    SavedScenarioController controller = new MockSavedScenarioController(service);
    controller.run(helper);
    assertEquals("scenario name 1", service.getName());
    assertEquals("testId", service.getUserId());
    assertEquals(parseDate("09-08-2009"), service.getSaveDataFrom());
    assertEquals(parseDate("10-09-2009"), service.getSaveDateTo());
    assertEquals(3, service.getSortKeys().length);
    assertEquals("saveDate", service.getSortKeys()[0]);
    assertEquals("username", service.getSortKeys()[1]);
    assertEquals("name", service.getSortKeys()[2]);
    assertEquals("asc", service.getSortDir());
    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    List<String> owners = (List<String>) helper.getRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE);
    assertEquals(0, scenarios.size());
    assertEquals(0, owners.size());
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVED_SCENARIOS_JSP));
    assertEquals("date", helper.getRequestAttributeValue(ScenarioConstants.SORT_KEY));
    assertEquals("asc", helper.getRequestAttributeValue(ScenarioConstants.SORT_DIR));
    assertEquals("testId", helper.getRequestAttributeValue(ScenarioConstants.OWNER));
    assertEquals("scenario name 1", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertEquals(parseDate("09-08-2009"), helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_FROM));
    assertEquals(parseDate("10-09-2009"), helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_TO));
  }

  public void testDeleteScenario_NoIdsToDelete_VerifyResponse() throws Exception {
    helper.setRequestParameterValue("method", "deleteScenario");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_IDS_TO_DELTETE, "");
    helper.setRequestParameterValue(ScenarioConstants.SORT_KEY, "date");
    helper.setRequestParameterValue(ScenarioConstants.SORT_DIR, "asc");
    helper.setRequestParameterValue(ScenarioConstants.OWNER, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario name 1");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_FROM, "09-08-2009");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_TO, "10-09-2009");
    MockScenarioService service = new MockScenarioService(new ArrayList<Scenario>(), new ArrayList<String>());
    SavedScenarioController controller = new MockSavedScenarioController(service);
    controller.run(helper);
    assertEquals("scenario name 1", service.getName());
    assertEquals("testId", service.getUserId());
    assertEquals(parseDate("09-08-2009"), service.getSaveDataFrom());
    assertEquals(parseDate("10-09-2009"), service.getSaveDateTo());
    assertEquals(3, service.getSortKeys().length);
    assertEquals("saveDate", service.getSortKeys()[0]);
    assertEquals("username", service.getSortKeys()[1]);
    assertEquals("name", service.getSortKeys()[2]);
    assertEquals("asc", service.getSortDir());
    assertEquals(0, service.getDeletedIds().length);
    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    List<String> owners = (List<String>) helper.getRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE);
    assertEquals(0, scenarios.size());
    assertEquals(0, owners.size());
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVED_SCENARIOS_JSP));
    assertEquals(0, helper.getRequestAttributeValue(ScenarioConstants.NUM_SCENARIO_DELTETED));
    assertEquals("date", helper.getRequestAttributeValue(ScenarioConstants.SORT_KEY));
    assertEquals("asc", helper.getRequestAttributeValue(ScenarioConstants.SORT_DIR));
    assertEquals("testId", helper.getRequestAttributeValue(ScenarioConstants.OWNER));
    assertEquals("scenario name 1", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertEquals(parseDate("09-08-2009"), helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_FROM));
    assertEquals(parseDate("10-09-2009"), helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_TO));
  }

  public void testDeleteScenario_2IdsToDelete_VerifyResponse() throws Exception {
    helper.setRequestParameterValue("method", "deleteScenario");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_IDS_TO_DELTETE, "1,2");
    helper.setRequestParameterValue(ScenarioConstants.SORT_KEY, "date");
    helper.setRequestParameterValue(ScenarioConstants.SORT_DIR, "asc");
    helper.setRequestParameterValue(ScenarioConstants.OWNER, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario name 1");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_FROM, "09-08-2009");
    helper.setRequestParameterValue(ScenarioConstants.SAVE_DATE_TO, "10-09-2009");
    MockScenarioService service = new MockScenarioService(new ArrayList<Scenario>(), new ArrayList<String>());
    SavedScenarioController controller = new MockSavedScenarioController(service);
    controller.run(helper);
    assertEquals("scenario name 1", service.getName());
    assertEquals("testId", service.getUserId());
    assertEquals(parseDate("09-08-2009"), service.getSaveDataFrom());
    assertEquals(parseDate("10-09-2009"), service.getSaveDateTo());
    assertEquals(3, service.getSortKeys().length);
    assertEquals("saveDate", service.getSortKeys()[0]);
    assertEquals("username", service.getSortKeys()[1]);
    assertEquals("name", service.getSortKeys()[2]);
    assertEquals("asc", service.getSortDir());
    assertEquals(2, service.getDeletedIds().length);
    List<Scenario> scenarios = (List<Scenario>) helper
        .getRequestAttributeValue(ScenarioConstants.SCENARIO_LIST_ATTRIBUTE);
    List<String> owners = (List<String>) helper.getRequestAttributeValue(ScenarioConstants.OWNER_LIST_ATTRIBUTE);
    assertEquals(0, scenarios.size());
    assertEquals(0, owners.size());
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVED_SCENARIOS_JSP));
    assertEquals(2, helper.getRequestAttributeValue(ScenarioConstants.NUM_SCENARIO_DELTETED));
    assertEquals("date", helper.getRequestAttributeValue(ScenarioConstants.SORT_KEY));
    assertEquals("asc", helper.getRequestAttributeValue(ScenarioConstants.SORT_DIR));
    assertEquals("testId", helper.getRequestAttributeValue(ScenarioConstants.OWNER));
    assertEquals("scenario name 1", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertEquals(parseDate("09-08-2009"), helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_FROM));
    assertEquals(parseDate("10-09-2009"), helper.getRequestAttributeValue(ScenarioConstants.SAVE_DATE_TO));
  }

  private Date parseDate(String dateStr) throws ParseException {
    return DateUtils.parseDate(dateStr, new String[]{ScenarioConstants.DATE_FORMAT});
  }

  private class MockSavedScenarioController extends SavedScenarioController {
    private MockSavedScenarioController(ScenarioService scenarioService) {
      super(new MockConfigDAO(), scenarioService);
    }

    protected boolean isUserAuthorized(UCCHelper helper) {
      return true;
    }
  }
}