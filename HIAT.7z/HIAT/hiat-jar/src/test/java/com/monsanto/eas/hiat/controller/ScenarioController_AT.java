package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.hiat.controller.constants.ScenarioConstants;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.HIATDatabaseTestCase;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.eas.hiat.controller.AnalysisConstants;
import com.monsanto.eas.hiat.util.AnalysisTestConstants;

import java.util.ArrayList;

/**
 * Created by vvvelu Date: Mar 18, 2009 Time: 11:12:02 AM
 */
public class ScenarioController_AT extends HIATDatabaseTestCase {
  private MockScenarioControllerOverridesIsAuthorized controller;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
     controller = new MockScenarioControllerOverridesIsAuthorized(
        new TestInitService().initScenarioService(), new TestInitService().initHybridAnalyzer(),
         new TestInitService().initTraitService(), new TestInitService().initProductService(), new TestInitService().initHybridXMLGenerator());
  }

  public void testSaveScenario_ScenarioIsSaved() throws Exception {
    setUpProductTraitData(true);
    MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario test 1");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_DESC, "scenario test desc 1");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, getTestProduct().getProductNames().get(
        ProductNameType.BASE_MANUFACTURING));
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{getTestTrait().getId().toString()});
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "saveScenario");
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
    assertEquals("true", helper.getRequestAttributeValue(ScenarioConstants.SAVE_SCENARIO_SUCCESSFULL));
    Scenario scenario = (Scenario) helper.getRequestAttributeValue(ScenarioConstants.SCENARIO);
    assertNotNull(scenario.getId());
    assertEquals("scenario test 1", scenario.getName());
    assertEquals("scenario test desc 1", scenario.getDescription());
    assertEquals(getTestProduct().getProductNames().get(ProductNameType.BASE_MANUFACTURING).getName(),
        helper.getRequestAttributeValue(AnalysisConstants.PRODUCT_NAME));
    assertEquals(new ArrayList<Trait>(scenario.getTraits()),
        helper.getRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS));
    assertNotNull(helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST));
    assertNotNull(helper.getRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST));
    assertEquals("true", helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }

  public void testReplaceScenario_ScenarioIsReplaced() throws Exception {
    setUpProductTraitData(true);

    MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario test 1");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_DESC, "scenario test desc 1");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, getTestProduct().getProductNames().get(
        ProductNameType.BASE_MANUFACTURING));
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{getTestTrait().getId().toString()});
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "saveScenario");
    controller.run(helper);
    Scenario scenario = (Scenario) helper.getRequestAttributeValue(ScenarioConstants.SCENARIO);

    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario test 1");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_DESC, "scenario test desc 1 updated");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, getTestProduct().getProductNames().get(
        ProductNameType.BASE_MANUFACTURING));
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{getTestTrait().getId().toString()});
    helper.setRequestParameterValue(AnalysisConstants.METHOD, "replaceScenario");
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
    assertEquals("true", helper.getRequestAttributeValue(ScenarioConstants.SAVE_SCENARIO_SUCCESSFULL));
    Scenario replacedScenario = (Scenario) helper.getRequestAttributeValue(ScenarioConstants.SCENARIO);
    assertNotNull(scenario.getId().equals(replacedScenario.getId()));
    assertEquals("scenario test 1", replacedScenario.getName());
    assertEquals("scenario test desc 1 updated", replacedScenario.getDescription());
    assertEquals(getTestProduct().getProductNames().get(ProductNameType.BASE_MANUFACTURING).getName(),
        helper.getRequestAttributeValue(AnalysisConstants.PRODUCT_NAME));
    assertEquals(new ArrayList<Trait>(scenario.getTraits()),
        helper.getRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS));
    assertNotNull(helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST));
    assertNotNull(helper.getRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST));
    assertEquals("true", helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }

  public void testDownloadSavedScenario() throws Exception {
    MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.DOWNLOAD_SAVED_SCENARIO);
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_ID, "433350");
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());
  }

  public void testDownloadCurrentValuesForSavedScenario() throws Exception {
    MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");
    helper.setRequestParameterValue(AnalysisConstants.METHOD,
        AnalysisTestConstants.DOWNLOAD_CURRENT_VALUES_FOR_SAVED_SCENARIO);

    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_ID, "433350");
    controller.run(helper);
    assertFalse(helper.wasErrorGenerated());

  }
}
