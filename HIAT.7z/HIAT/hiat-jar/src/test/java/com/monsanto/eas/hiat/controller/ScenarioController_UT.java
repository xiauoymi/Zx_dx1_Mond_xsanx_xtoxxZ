
/*
 ScenarioController_UT was created on Mar 5, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.analysis.HybridAnalysisDetail;
import com.monsanto.eas.hiat.analysis.MockHybridAnalyzer;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisDetailImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisParentDetailImpl;
import com.monsanto.eas.hiat.availability.Season;
import com.monsanto.eas.hiat.controller.constants.ScenarioConstants;
import com.monsanto.eas.hiat.controller.mock.MockProductServiceConfiguredForNE5112v1;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockScenario;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.scenario.ScenarioDetail;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioDetailImpl;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioImpl;
import com.monsanto.eas.hiat.service.mock.mock.MockScenarioService;
import com.monsanto.eas.hiat.service.mock.mock.MockTraitService;
import com.monsanto.eas.hiat.controller.AnalysisConstants;
import com.monsanto.eas.hiat.util.AnalysisTestConstants;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import com.monsanto.eas.hiat.view.HybridAnalysisXMLGenerator;
import com.monsanto.eas.hiat.view.mock.MockHybridAnalysisXMLGenerator;

import java.util.*;

/**
 * Filename:    $RCSfile: ScenarioController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2009-04-13 21:50:19 $
 *
 * @author sspati1
 * @version $Revision: 1.20 $
 */
public class ScenarioController_UT extends HIATUnitTest {
  public static final String TEST_DOWNLOAD_SAVED_SCENARIO_URL = "http://w3devel.kerberos.monsanto.com:8080/hiat/downloadSavedScenario/scenario?method=downloadSavedScenario";
  public static final String TEST_DOWNLOAD_CURRENT_VALUES_URL = "http://w3devel.kerberos.monsanto.com:8080/hiat/downloadCurrentValuesForSavedScenario/scenario?method=downloadCurrentValuesForSavedScenario";

  public void testDisplaySaveScenarioForm_SentToJsp() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "displaySaveScenarioForm");
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(null, null, null, null, null);
    controller.run(helper);
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVE_SCENARIO_JSP));
  }

  public void testDisplaySaveSuccessfulMessage_SentToJsp() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "displaySaveSuccessfulMessage");
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(null, null, null, null, null);
    controller.run(helper);
    assertTrue(helper.wasSentTo(ScenarioConstants.SAVE_SCENARIO_SUCCESSFULL_JSP));
  }

  public void testDisplayReplaceOrSaveNewScenarioForm_SentToJsp() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "displayReplaceOrSaveNewScenarioForm");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario name 1");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_DESC, "scenario desc 2");
    ArrayList<Scenario> scenarioList = new ArrayList<Scenario>();
    scenarioList.add(new ScenarioImpl(null, null, "scenario name 1", null, new Date(), false, null, null,
        new HashSet<ScenarioDetail>()));
    scenarioList.add(new ScenarioImpl(null, null, "scenario name 2", null, new Date(), false, null, null,
        new HashSet<ScenarioDetail>()));
    MockScenarioService service = new MockScenarioService(scenarioList, null);
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(service, null, null, null, null);
    controller.run(helper);
    assertEquals("scenario desc 2", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_DESC));
    Scenario existingScenario = (Scenario) helper.getRequestAttributeValue(ScenarioConstants.SCENARIO);
    assertEquals("scenario name 1", existingScenario.getName());
    assertTrue(helper.wasSentTo(ScenarioConstants.DUPLICATE_SCENARIO_WARNING_JSP));
  }

  public void testLookupScenario_ScenarioDoesNotExists_VerifyResponse() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "lookupScenario");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_ID, "1234");
    ArrayList<Scenario> scenarioList = new ArrayList<Scenario>();
    HashSet<Trait> traits = new HashSet<Trait>();
    traits.add(new MockTrait(4L));
    traits.add(new MockTrait(5L));
    Set<ScenarioDetail> scenarioDetails = new HashSet<ScenarioDetail>();
    scenarioDetails.add(new ScenarioDetailImpl(null, new HybridAnalysisImpl(new MockProduct(6L), new MockTrait(22L), null)));
    scenarioDetails.add(new ScenarioDetailImpl(null, new HybridAnalysisImpl(new MockProduct(7L), new MockTrait(23L), null)));
    scenarioList.add(new ScenarioImpl(123L, "testId", "scenario name 1", "scenario desc 1", new Date(), false,
        "ne5112_v1 ne5112_v2", traits, scenarioDetails));
    scenarioList.add(new ScenarioImpl(234L, null, "scenario name 2", "scenario desc 2", new Date(), false, null, null,
            new HashSet<ScenarioDetail>()));
    MockScenarioService service = new MockScenarioService(scenarioList, null);
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(service, null,
        new MockTraitService(), null, null);
    controller.run(helper);
    Scenario scenario = (Scenario) helper.getRequestAttributeValue(ScenarioConstants.SCENARIO);
    assertNull(scenario);
    assertTrue(helper.wasSentTo(ScenarioConstants.SCENARIO_ERROR_JSP));
  }

  public void testLookupScenario_ScenarioExists_VerifyResponse() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "lookupScenario");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_ID, "123");
    ArrayList<Scenario> scenarioList = new ArrayList<Scenario>();
    HashSet<Trait> traits = new HashSet<Trait>();
    traits.add(new MockTrait(4L));
    traits.add(new MockTrait(5L));
    Set<ScenarioDetail> scenarioDetails = new HashSet<ScenarioDetail>();
    scenarioDetails.add(new ScenarioDetailImpl(null, new HybridAnalysisImpl(new MockProduct(6L), new MockTrait(22L), null)));
    scenarioDetails.add(new ScenarioDetailImpl(null, new HybridAnalysisImpl(new MockProduct(7L), new MockTrait(23L), null)));
    scenarioList.add(new ScenarioImpl(123L, "testId", "scenario name 1", "scenario desc 1", new Date(), false,
        "ne5112_v1 ne5112_v2", traits, scenarioDetails));
    scenarioList.add(new ScenarioImpl(234L, null, "scenario name 2", "scenario desc 2", new Date(), false, null, null,
            new HashSet<ScenarioDetail>()));
    MockScenarioService service = new MockScenarioService(scenarioList, null);
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(service, null,
        new MockTraitService(), null, null);
    controller.run(helper);
    Scenario scenario = (Scenario) helper.getRequestAttributeValue(ScenarioConstants.SCENARIO);
    assertEquals(123L, scenario.getId().longValue());
    assertEquals("testId", scenario.getUsername());
    assertEquals("scenario name 1", scenario.getName());
    assertEquals("scenario desc 1", scenario.getDescription());
    assertEquals("ne5112_v1 ne5112_v2", scenario.getProducts());
    assertEquals(2, scenario.getTraits().size());

    assertEquals("ne5112_v1 ne5112_v2", helper.getRequestAttributeValue(AnalysisConstants.PRODUCT_NAME));
    List<Trait> selectedTraits = (List<Trait>) helper.getRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS);
    assertEquals(2, selectedTraits.size());
    assertTrue(selectedTraits.contains(new MockTrait(4L)));
    assertTrue(selectedTraits.contains(new MockTrait(5L)));
    List<Trait> allTraits = (List<Trait>) helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST);
    assertEquals(4, allTraits.size());
    List<HybridAnalysis> analysisList = (List<HybridAnalysis>) helper
        .getRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST);
    assertEquals(2, analysisList.size());
    assertTrue(analysisList.contains(new HybridAnalysisImpl(new MockProduct(6L), new MockTrait(22L), null)));
    assertTrue(analysisList.contains(new HybridAnalysisImpl(new MockProduct(7L), new MockTrait(23L), null)));
    assertEquals(AnalysisConstants.TRUE_STRING, helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }

  public void testSaveScenario_ScenarioNameAlreadyExistsNotRerun_ScenarioNotSaved() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "saveScenario");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "   scenario name 1   ");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_DESC, "scenario desc 111");

    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1 NE5112_v2");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"4", "5", "6"});

    //productId, traitId, femaleDetailTraitId, maleDetailTraitId
    helper.setRequestParameterValue(HybridAnalysisXMLGenerator.SELECTED_ANALYSIS_DETAILS_CHKBX,
        new String[]{"2, 4, 3, 14", "2, 4, 0, 4", "3, 5, 0, 4"});
    ArrayList<Scenario> scenarioList = new ArrayList<Scenario>();
    Set<Trait> traits = new HashSet<Trait>();
    traits.add(new MockTrait(11L));
    traits.add(new MockTrait(12L));
    Set<ScenarioDetail> scenarioDetails = new HashSet<ScenarioDetail>();
    scenarioDetails.add(new ScenarioDetailImpl());
    scenarioDetails.add(new ScenarioDetailImpl());
    scenarioDetails.add(new ScenarioDetailImpl());
    scenarioList.add(
        new ScenarioImpl(123L, "testId1", "scenario name 1", "scenario desc 11", new Date(), false, "p1 p2",
            traits, scenarioDetails));
    scenarioList.add(new ScenarioImpl(234L, null, "scenario name 2", null, new Date(), false, null, null,
        new HashSet<ScenarioDetail>()));
    MockScenarioService service = new MockScenarioService(scenarioList, null);
    MockHybridAnalyzer hybridAnalyzer = new MockHybridAnalyzer(getHybridAnalysisList());
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(service, hybridAnalyzer, new MockTraitService(), new MockProductServiceConfiguredForNE5112v1(), null);
    controller.run(helper);
    assertEquals("false", helper.getRequestAttributeValue(ScenarioConstants.SAVE_SCENARIO_SUCCESSFULL));
    assertEquals("   scenario name 1   ", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertEquals("scenario desc 111", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_DESC));

    assertNull(helper.getRequestAttributeValue(ScenarioConstants.IS_RERUN));
    assertNull(helper.getRequestAttributeValue(ScenarioConstants.SCENARIO));
    assertNull(service.getSavedScenario());
    assertNull(service.getReplacedScenario());

    assertEquals("NE5112_v1 NE5112_v2", helper.getRequestAttributeValue(AnalysisConstants.PRODUCT_NAME));
    assertEquals(3, ((List) helper.getRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS)).size());
    assertEquals(4, ((List) helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST)).size());
    assertNumOfHybridDetailsSelected(helper);
    assertEquals(AnalysisConstants.TRUE_STRING, helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }

  public void testSaveScenario_ScenarioNameContainsWhiteSpace_ButSameScenarioNameAlreadyExistsNotRerun_ScenarioNotSaved() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "saveScenario");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario name 1    ");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_DESC, "scenario desc 111");

    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1 NE5112_v2");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"4", "5", "6"});

    //productId, traitId, femaleDetailTraitId, maleDetailTraitId
    helper.setRequestParameterValue(HybridAnalysisXMLGenerator.SELECTED_ANALYSIS_DETAILS_CHKBX,
        new String[]{"2, 4, 3, 14", "2, 4, 0, 4", "3, 5, 0, 4"});
    ArrayList<Scenario> scenarioList = new ArrayList<Scenario>();
    Set<Trait> traits = new HashSet<Trait>();
    traits.add(new MockTrait(11L));
    traits.add(new MockTrait(12L));
    Set<ScenarioDetail> scenarioDetails = new HashSet<ScenarioDetail>();
    scenarioDetails.add(new ScenarioDetailImpl());
    scenarioDetails.add(new ScenarioDetailImpl());
    scenarioDetails.add(new ScenarioDetailImpl());
    scenarioList.add(
        new ScenarioImpl(123L, "testId1", "scenario name 1", "scenario desc 11", new Date(), false, "p1 p2",
            traits, scenarioDetails));
    scenarioList.add(new ScenarioImpl(234L, null, "scenario name 2", null, new Date(), false, null, null,
        new HashSet<ScenarioDetail>()));
    MockScenarioService service = new MockScenarioService(scenarioList, null);
    MockHybridAnalyzer hybridAnalyzer = new MockHybridAnalyzer(getHybridAnalysisList());
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(service, hybridAnalyzer, new MockTraitService(), new MockProductServiceConfiguredForNE5112v1(), null);
    controller.run(helper);
    assertEquals("false", helper.getRequestAttributeValue(ScenarioConstants.SAVE_SCENARIO_SUCCESSFULL));
    assertEquals("scenario name 1    ", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertEquals("scenario desc 111", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_DESC));

    assertNull(helper.getRequestAttributeValue(ScenarioConstants.IS_RERUN));
    assertNull(helper.getRequestAttributeValue(ScenarioConstants.SCENARIO));
    assertNull(service.getSavedScenario());
    assertNull(service.getReplacedScenario());

    assertEquals("NE5112_v1 NE5112_v2", helper.getRequestAttributeValue(AnalysisConstants.PRODUCT_NAME));
    assertEquals(3, ((List) helper.getRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS)).size());
    assertEquals(4, ((List) helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST)).size());
    assertNumOfHybridDetailsSelected(helper);
    assertEquals(AnalysisConstants.TRUE_STRING, helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }

  public void testSaveScenario_ScenarioNameAlreadyExistsIsRerun_ScenarioNotSaved() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "saveScenario");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_ID, "123");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario name 1");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_DESC, "scenario desc 111");
    helper.setRequestParameterValue(ScenarioConstants.IS_RERUN, "true");
    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1 NE5112_v2");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"4", "5", "6"});

    //productId, traitId, femaleDetailTraitId, maleDetailTraitId
    helper.setRequestParameterValue(HybridAnalysisXMLGenerator.SELECTED_ANALYSIS_DETAILS_CHKBX,
        new String[]{"2, 4, 3, 14", "2, 4, 0, 4", "3, 5, 0, 4"});

    ArrayList<Scenario> scenarioList = getTestScenarios();
    MockScenarioService service = new MockScenarioService(scenarioList, null);
    MockHybridAnalyzer hybridAnalyzer = new MockHybridAnalyzer(getHybridAnalysisList());
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(service, hybridAnalyzer, new MockTraitService(), new MockProductServiceConfiguredForNE5112v1(), null);
    controller.run(helper);
    assertEquals("false", helper.getRequestAttributeValue(ScenarioConstants.SAVE_SCENARIO_SUCCESSFULL));
    assertEquals("scenario name 1", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertEquals("scenario desc 111", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_DESC));

    assertEquals("true", helper.getRequestAttributeValue(ScenarioConstants.IS_RERUN).toString());
    Scenario scenario = (Scenario) helper.getRequestAttributeValue(ScenarioConstants.SCENARIO);
    assertNotNull(scenario);
    assertEquals(123L, scenario.getId().longValue());
    assertNull(service.getSavedScenario());
    assertNull(service.getReplacedScenario());
    List<HybridAnalysis> savedAnalysisListForRerun = (List<HybridAnalysis>) helper
        .getRequestAttributeValue(ScenarioController.SAVED_ANALYSIS_LIST_FOR_RERUN);
    assertEquals(2, savedAnalysisListForRerun.size());
    assertTrue(savedAnalysisListForRerun.contains(new HybridAnalysisImpl(new MockProduct(6L), new MockTrait(22L), null)));
    assertTrue(savedAnalysisListForRerun.contains(new HybridAnalysisImpl(new MockProduct(7L), new MockTrait(23L), null)));

    assertEquals("NE5112_v1 NE5112_v2", helper.getRequestAttributeValue(AnalysisConstants.PRODUCT_NAME));
    assertEquals(3, ((List) helper.getRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS)).size());
    assertEquals(4, ((List) helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST)).size());
    assertNumOfHybridDetailsSelected(helper);
    assertEquals(AnalysisConstants.TRUE_STRING, helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }

  public void testSaveScenario_ScenarioNameDoesNotExists_ScenarioSaved() throws Exception {
    MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");
    helper.setRequestParameterValue("method", "saveScenario");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario name 1");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_DESC, "scenario desc 2");

    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1 NE5112_v2");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"4", "5", "6"});

    //productId, traitId, femaleDetailTraitId, maleDetailTraitId
    helper.setRequestParameterValue(HybridAnalysisXMLGenerator.SELECTED_ANALYSIS_DETAILS_CHKBX,
        new String[]{"2, 4, 3, 14", "2, 4, 0, 4", "3, 5, 0, 4"});

    ArrayList<Scenario> scenarioList = new ArrayList<Scenario>();
    Set<Trait> traits = new HashSet<Trait>();
    traits.add(new MockTrait(11L));
    traits.add(new MockTrait(12L));
    Set<ScenarioDetail> scenarioDetails = new HashSet<ScenarioDetail>();
    scenarioDetails.add(new ScenarioDetailImpl());
    scenarioDetails.add(new ScenarioDetailImpl());
    scenarioDetails.add(new ScenarioDetailImpl());
    scenarioList.add(
        new ScenarioImpl(123L, "testId1", "scenario name 11", "scenario desc 11", new Date(), false, "p1 p2",
            traits, scenarioDetails));
    scenarioList.add(new ScenarioImpl(234L, null, "scenario name 2", null, new Date(), false, null, null,
        new HashSet<ScenarioDetail>()));
    MockScenarioService service = new MockScenarioService(scenarioList, null);

    MockHybridAnalyzer hybridAnalyzer = new MockHybridAnalyzer(getHybridAnalysisList());
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(service, hybridAnalyzer,
        new MockTraitService(), new MockProductServiceConfiguredForNE5112v1(), null);

    controller.run(helper);
    assertEquals("true", helper.getRequestAttributeValue(ScenarioConstants.SAVE_SCENARIO_SUCCESSFULL));
    assertNull(helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertNull(service.getReplacedScenario());
    Scenario savedScenario = service.getSavedScenario();
    assertEquals("testId", savedScenario.getUsername());
    assertEquals("scenario name 1", savedScenario.getName());
    assertEquals("scenario desc 2", savedScenario.getDescription());
    assertEquals("NE5112_v1 NE5112_v2", savedScenario.getProducts());
    assertEquals(3, savedScenario.getTraits().size());
    assertTrue(savedScenario.getTraits().contains(new MockTrait(4L)));
    assertTrue(savedScenario.getTraits().contains(new MockTrait(5L)));
    assertTrue(savedScenario.getTraits().contains(new MockTrait(6L)));

    Collection<ScenarioDetail> scenarioDetailCollection = savedScenario.getDetails();
    assertEquals(3, scenarioDetailCollection.size());

    ScenarioDetail scenarioDetail1 = new ScenarioDetailImpl(new MockScenario("scenario name 1", "testId"),
        new HybridAnalysisImpl(new MockProduct(2L), new MockTrait(4L), null));
    assertTrue(scenarioDetailCollection.contains(scenarioDetail1));
    assertTrue(scenarioDetailCollection.contains(new ScenarioDetailImpl(new MockScenario("scenario name 1", "testId"), new HybridAnalysisImpl(new MockProduct(3L),
        new MockTrait(5L), null))));
    assertTrue(scenarioDetailCollection.contains(new ScenarioDetailImpl(new MockScenario("scenario name 1", "testId"), new HybridAnalysisImpl(new MockProduct(4L),
        new MockTrait(6L), null))));

    Scenario scenario = (Scenario) helper.getRequestAttributeValue(ScenarioConstants.SCENARIO);
    assertNotNull(scenario);
    assertEquals(123L, scenario.getId().longValue());
    assertEquals("p1 p2", helper.getRequestAttributeValue(AnalysisConstants.PRODUCT_NAME));
    assertEquals(2, ((List) helper.getRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS)).size());
    assertEquals(4, ((List) helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST)).size());
    List<HybridAnalysis> analysisList = (List<HybridAnalysis>) helper.getRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST);
    assertNotNull(analysisList.size());
    assertEquals(AnalysisConstants.TRUE_STRING, helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }

  public void testReplaceScenario_ScenarioIsReplaced() throws Exception {
    MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");
    helper.setRequestParameterValue("method", "replaceScenario");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_NAME, "scenario name 1");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_DESC, "scenario desc 2");

    helper.setRequestParameterValue(AnalysisConstants.PRODUCT_NAME, "NE5112_v1 NE5112_v2");
    helper.setRequestParameterValue(AnalysisController.SELECTED_TRAITS, new String[]{"4", "5", "6"});

    helper.setRequestParameterValue(HybridAnalysisXMLGenerator.SELECTED_ANALYSIS_DETAILS_CHKBX,
        new String[]{"2, 4, 3, 14", "2, 4, 0, 4", "3, 5, 0, 4"});
    ArrayList<Scenario> scenarioList = new ArrayList<Scenario>();
    Set<Trait> traits = new HashSet<Trait>();
    traits.add(new MockTrait(11L));
    traits.add(new MockTrait(12L));
    Set<ScenarioDetail> scenarioDetails = new HashSet<ScenarioDetail>();
    scenarioDetails.add(new ScenarioDetailImpl());
    scenarioDetails.add(new ScenarioDetailImpl());
    scenarioDetails.add(new ScenarioDetailImpl());
    scenarioList.add(
        new ScenarioImpl(123L, "testId1", "scenario name 11", "scenario desc 11", new Date(), false, "p1 p2",
            traits, scenarioDetails));
    scenarioList
        .add(new ScenarioImpl(234L, null, "scenario name 2", "scenario desc 2", new Date(), false, "p1 p2",
            traits, scenarioDetails));
    MockScenarioService service = new MockScenarioService(scenarioList, null);
    MockHybridAnalyzer hybridAnalyzer = new MockHybridAnalyzer(getHybridAnalysisList());
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(service, hybridAnalyzer,
        new MockTraitService(), new MockProductServiceConfiguredForNE5112v1(), null);
    controller.run(helper);
    assertEquals("true", helper.getRequestAttributeValue(ScenarioConstants.SAVE_SCENARIO_SUCCESSFULL));
   // assertEquals("scenario name 1", helper.getRequestAttributeValue(ScenarioConstants.SCENARIO_NAME));
    assertNull(service.getSavedScenario());
    Scenario replacedScenario = service.getReplacedScenario();
    assertEquals(new Long(234L), replacedScenario.getId());
    assertEquals("scenario name 1", replacedScenario.getName());
    assertEquals("testId", replacedScenario.getUsername());
    assertEquals("scenario name 1", replacedScenario.getName());
    assertEquals("scenario desc 2", replacedScenario.getDescription());
    assertEquals("NE5112_v1 NE5112_v2", replacedScenario.getProducts());
    assertEquals(3, replacedScenario.getTraits().size());
    assertTrue(replacedScenario.getTraits().contains(new MockTrait(4L)));
    assertTrue(replacedScenario.getTraits().contains(new MockTrait(5L)));
    assertTrue(replacedScenario.getTraits().contains(new MockTrait(6L)));
    Collection<ScenarioDetail> scenarioDetailCollection = replacedScenario.getDetails();
    assertEquals(3, scenarioDetailCollection.size());

    assertTrue(scenarioDetailCollection.contains(new ScenarioDetailImpl(new MockScenario("scenario name 1", "testId"), new HybridAnalysisImpl(new MockProduct(2L),
        new MockTrait(4L), null))));
    assertTrue(scenarioDetailCollection.contains(new ScenarioDetailImpl(new MockScenario("scenario name 1", "testId"), new HybridAnalysisImpl(new MockProduct(3L),
        new MockTrait(5L), null))));
    assertTrue(scenarioDetailCollection.contains(new ScenarioDetailImpl(new MockScenario("scenario name 1", "testId"), new HybridAnalysisImpl(new MockProduct(4L),
        new MockTrait(6L), null))));

    Scenario scenario = (Scenario) helper.getRequestAttributeValue(ScenarioConstants.SCENARIO);
    assertNotNull(scenario);
    assertEquals(234L, scenario.getId().longValue());
    assertEquals("p1 p2", helper.getRequestAttributeValue(AnalysisConstants.PRODUCT_NAME));
    assertEquals(2, ((List) helper.getRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS)).size());
    assertEquals(4, ((List) helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST)).size());
    assertNotNull((List) helper.getRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST));
    assertEquals(AnalysisConstants.TRUE_STRING, helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }

  public void testRerunScenario_VerifyResponse() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue("method", "rerunScenario");
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_ID, "123");
    ArrayList<Scenario> scenarioList = getTestScenarios();
    MockScenarioService service = new MockScenarioService(scenarioList, null);
    MockHybridAnalyzer hybridAnalyzer = new MockHybridAnalyzer(getHybridAnalysisList());
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(service, hybridAnalyzer,
        new MockTraitService(), new MockProductServiceConfiguredForNE5112v1(), null);
    controller.run(helper);
    Scenario scenario = (Scenario) helper.getRequestAttributeValue(ScenarioConstants.SCENARIO);
    assertEquals(123L, scenario.getId().longValue());
    assertEquals("testId", scenario.getUsername());
    assertEquals("scenario name 1", scenario.getName());
    assertEquals("scenario desc 1", scenario.getDescription());
    assertEquals("ne5112_v1 ne5112_v2", scenario.getProducts());
    assertEquals(2, scenario.getTraits().size());

    assertEquals("ne5112_v1 ne5112_v2", helper.getRequestAttributeValue(AnalysisConstants.PRODUCT_NAME));
    List<Trait> selectedTraits = (List<Trait>) helper.getRequestAttributeValue(AnalysisConstants.SELECTED_TRAITS);
    assertEquals(2, selectedTraits.size());
    assertTrue(selectedTraits.contains(new MockTrait(4L)));
    assertTrue(selectedTraits.contains(new MockTrait(5L)));
    List<Trait> allTraits = (List<Trait>) helper.getRequestAttributeValue(AnalysisConstants.TRAITS_LIST);
    assertEquals(4, allTraits.size());
    List<HybridAnalysis> analysisList = (List<HybridAnalysis>) helper
        .getRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST);
    assertEquals(3, analysisList.size());
    assertTrue(analysisList.contains(new HybridAnalysisImpl(new MockProduct(2L), new MockTrait(4L), null)));
    assertTrue(analysisList.contains(new HybridAnalysisImpl(new MockProduct(3L), new MockTrait(5L), null)));
    assertTrue(analysisList.contains(new HybridAnalysisImpl(new MockProduct(4L), new MockTrait(6L), null)));

    List<HybridAnalysis> savedAnalysisListForRerun = (List<HybridAnalysis>) helper
        .getRequestAttributeValue(ScenarioController.SAVED_ANALYSIS_LIST_FOR_RERUN);
    assertEquals(2, savedAnalysisListForRerun.size());
    assertTrue(savedAnalysisListForRerun.contains(new HybridAnalysisImpl(new MockProduct(6L), new MockTrait(22L), null)));
    assertTrue(savedAnalysisListForRerun.contains(new HybridAnalysisImpl(new MockProduct(7L), new MockTrait(23L), null)));

    assertEquals(AnalysisConstants.TRUE_STRING, helper.getRequestAttributeValue(AnalysisConstants.DISPLAY_ANALYSIS_RESULTS));
    assertEquals("true", helper.getRequestAttributeValue(ScenarioConstants.IS_RERUN).toString());
    assertTrue(helper.wasSentTo(HybridAnalysisController.WEB_INF_JSP_HYBRIDANALYSIS_PARAM));
  }

  private void assertNumOfHybridDetailsSelected(UCCHelper helper){
    List<HybridAnalysis> analysisList = (List<HybridAnalysis>) helper.getRequestAttributeValue(AnalysisConstants.ANALYSIS_LIST);
    assertEquals(3, analysisList.size());
    Collection<HybridAnalysisDetail> detailSet = analysisList.get(0).getDetail();
    assertEquals(3, detailSet.size());
    int numOfDetailsSelected = 0;
    for(HybridAnalysisDetail detail: detailSet){
      if(detail.getIsSelected()){
        numOfDetailsSelected++;
      }
    }
    assertEquals(2, numOfDetailsSelected);
    detailSet = analysisList.get(1).getDetail();
    assertEquals(2, detailSet.size());
    numOfDetailsSelected = 0;
    for(HybridAnalysisDetail detail: detailSet){
      if(detail.getIsSelected()){
        numOfDetailsSelected++;
      }
    }
    assertEquals(1, numOfDetailsSelected);

    detailSet = analysisList.get(2).getDetail();
    assertEquals(2, detailSet.size());
    numOfDetailsSelected = 0;
    for(HybridAnalysisDetail detail: detailSet){
      if(detail.getIsSelected()){
        numOfDetailsSelected++;
      }
    }
    assertEquals(0, numOfDetailsSelected);

  }

  private List<HybridAnalysis> getHybridAnalysisList() {
    List<HybridAnalysis> analysisList = new ArrayList<HybridAnalysis>();
    Set<HybridAnalysisDetail> details = new HashSet<HybridAnalysisDetail>();
    details.add(new HybridAnalysisDetailImpl(
        new HybridAnalysisParentDetailImpl(null, new MockTrait(14L), null, null, null),
        new HybridAnalysisParentDetailImpl(null, new MockTrait(3L), null, null, null),
        Season.NONE, Season.NONE, Season.NONE));
    details.add(new HybridAnalysisDetailImpl(
        new HybridAnalysisParentDetailImpl(null, new MockTrait(15L), null, null, null),
        new HybridAnalysisParentDetailImpl(null, new MockTrait(4L), null, null, null),
        Season.NONE, Season.NONE, Season.NONE));
    details.add(new HybridAnalysisDetailImpl(
        new HybridAnalysisParentDetailImpl(null, new MockTrait(4L), null, null, null),
        new HybridAnalysisParentDetailImpl(null, new MockTrait(0L), null, null, null),
        Season.NONE, Season.NONE, Season.NONE));
    analysisList.add(new HybridAnalysisImpl(new MockProduct(2L),
        new MockTrait(4L), details));

    details = new HashSet<HybridAnalysisDetail>();
    details.add(new HybridAnalysisDetailImpl(
        new HybridAnalysisParentDetailImpl(null, new MockTrait(15L), null, null, null),
        new HybridAnalysisParentDetailImpl(null, new MockTrait(5L), null, null, null),
        Season.NONE, Season.NONE, Season.NONE));
    details.add(new HybridAnalysisDetailImpl(
        new HybridAnalysisParentDetailImpl(null, new MockTrait(4L), null, null, null),
        new HybridAnalysisParentDetailImpl(null, new MockTrait(0L), null, null, null),
        Season.NONE, Season.NONE, Season.NONE));
    analysisList.add(new HybridAnalysisImpl(new MockProduct(3L),
        new MockTrait(5L), details));

    details = new HashSet<HybridAnalysisDetail>();
    details.add(new HybridAnalysisDetailImpl(
        new HybridAnalysisParentDetailImpl(null, new MockTrait(15L), null, null, null),
        new HybridAnalysisParentDetailImpl(null, new MockTrait(5L), null, null, null),
        Season.NONE, Season.NONE, Season.NONE));
    details.add(new HybridAnalysisDetailImpl(
        new HybridAnalysisParentDetailImpl(null, new MockTrait(4L), null, null, null),
        new HybridAnalysisParentDetailImpl(null, new MockTrait(0L), null, null, null),
        Season.NONE, Season.NONE, Season.NONE));
    analysisList.add(new HybridAnalysisImpl(new MockProduct(4L),
        new MockTrait(6L), details));

    return analysisList;
  }

  public void testDownloadSavedScenario_VerifyResponse() throws Exception {
    MockHelperForDowloadAnalysis helper = new MockHelperForDowloadAnalysis(TEST_DOWNLOAD_SAVED_SCENARIO_URL);

    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.DOWNLOAD_SAVED_SCENARIO);
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_ID, "123");
    ArrayList<Scenario> scenarioList = getTestScenarios();

    MockHybridAnalysisXMLGenerator xmlGenerator = new MockHybridAnalysisXMLGenerator();
    MockScenarioService service = new MockScenarioService(scenarioList, null);
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(service, null, new MockTraitService(), null, xmlGenerator);
    controller.run(helper);
    assertTrue(xmlGenerator.wasGetXmlContentCalled());
  }

  public void testDownloadCurrentValuesForSavedScenario_VerifyResponse() throws Exception {
    MockHelperForDowloadAnalysis helper = new MockHelperForDowloadAnalysis(TEST_DOWNLOAD_CURRENT_VALUES_URL);
    helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.DOWNLOAD_CURRENT_VALUES_FOR_SAVED_SCENARIO);
    helper.setRequestParameterValue(ScenarioConstants.SCENARIO_ID, "123");
    ArrayList<Scenario> scenarioList = getTestScenarios();
    MockHybridAnalyzer hybridAnalyzer = new MockHybridAnalyzer(getHybridAnalysisList());

    MockHybridAnalysisXMLGenerator xmlGenerator = new MockHybridAnalysisXMLGenerator();
    MockScenarioService service = new MockScenarioService(scenarioList, null);
    ScenarioController controller = new MockScenarioControllerOverridesIsAuthorized(service, hybridAnalyzer,
        new MockTraitService(), new MockProductServiceConfiguredForNE5112v1(), xmlGenerator);
    controller.run(helper);
    Collection<Trait> testTraitsExpected = new ArrayList<Trait>(getTestTraits());
    ProductImpl product1 = new ProductImpl(2L, "1", new MockTrait(1L, "SSTX", null, null, null, true), null, null, null, null, false, null,
        null, false);
    assertTrue(hybridAnalyzer.getLastProductListPassed().contains(product1));
    assertTrue(hybridAnalyzer.getLastTraitListPassed().containsAll(testTraitsExpected));
    assertTrue(xmlGenerator.wasGetXmlContentCalled());
  }

  private ArrayList<Scenario> getTestScenarios() {
    ArrayList<Scenario> scenarioList = new ArrayList<Scenario>();
    HashSet<Trait> traits = getTestTraits();
    Set<ScenarioDetail> scenarioDetails = new HashSet<ScenarioDetail>();
    scenarioDetails.add(new ScenarioDetailImpl(null, new HybridAnalysisImpl(new MockProduct(6L),
        new MockTrait(22L), null)));
    scenarioDetails.add(new ScenarioDetailImpl(null, new HybridAnalysisImpl(new MockProduct(7L),
        new MockTrait(23L), null)));
    scenarioList.add(new ScenarioImpl(123L, "testId", "scenario name 1", "scenario desc 1", new Date(), false,
        "ne5112_v1 ne5112_v2", traits, scenarioDetails));
    scenarioList
        .add(new ScenarioImpl(234L, null, "scenario name 2", "scenario desc 2", new Date(), false, null, null,
            new HashSet<ScenarioDetail>()));
    return scenarioList;
  }

  private HashSet<Trait> getTestTraits() {
    HashSet<Trait> traits = new HashSet<Trait>();
    traits.add(new MockTrait(4L));
    traits.add(new MockTrait(5L));
    return traits;
  }


  private static class MockHelperForDowloadAnalysis extends MockUCCHelper {
    private String url;

    public MockHelperForDowloadAnalysis(String url) {
      super("MOCK");
      this.url = url;
    }

    @Override
    public String requestedURL() {
      return url;
    }

  }


}