package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.hiat.controller.mock.MockTraitConfigController;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.HIATDatabaseTestCase;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.eas.hiat.controller.AnalysisConstants;
import com.monsanto.eas.hiat.util.AnalysisTestConstants;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Jun 3, 2009
 * Time: 6:36:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class TraitConfigController_AT extends HIATDatabaseTestCase {

    private MockTraitConfigController controller;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        controller = new MockTraitConfigController(new MockConfigDAO(), new TestInitService().initTraitService());
    }

    public void testConfigTrait_InActivateTrait_TraitUpdated() throws Exception {
        MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");
        helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.CONFIG_TRAIT);
        helper.setRequestParameterValue(TraitConfigController.TRAITS_TO_BE_INACTIVATED, "40");
        helper.setRequestParameterValue(TraitConfigController.CONFIG_TYPE, TraitConfigController.IN_ACTIVATE);
        controller.run(helper);
        Trait trait = new TestInitService().initTraitDAO().findByPrimaryKey(40L);
        List<String> errorsList = (List<String>) helper.getRequestAttributeValue(TraitConfigController.ERRORS_LIST);
        List<Trait> activeTraits = (List<Trait>) helper.getRequestAttributeValue(TraitConfigController.ACTIVE_TRAITS_LIST);
        List<Trait> inActiveTraits = (List<Trait>) helper.getRequestAttributeValue(TraitConfigController.IN_ACTIVE_TRAITS_LIST);
        String successfulMessage = (String) helper.getRequestAttributeValue(TraitConfigController.TRAIT_CONFIG_MESSAGE);
        assertTrue(activeTraits.size() > 0);
        assertTrue(inActiveTraits.size() > 0);
        assertFalse(trait.getActive());
        assertEquals(0, errorsList.size());
        assertEquals(successfulMessage, TraitConfigController.SUCCESSFUL_MESSAGE);
        assertTrue(helper.wasSentTo(TraitConfigController.WEB_INF_JSP_TRAIT_CONFIG));
    }




    public void testConfigTrait_TraitNotSelected_ToInactivate() throws Exception {
        MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");
        helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.CONFIG_TRAIT);
        helper.setRequestParameterValue(TraitConfigController.CONFIG_TYPE, TraitConfigController.IN_ACTIVATE);
        controller.run(helper);
        List<String> errorsList = (List<String>) helper.getRequestAttributeValue(TraitConfigController.ERRORS_LIST);
        List<String> activeTraits = (List<String>) helper.getRequestAttributeValue(TraitConfigController.ACTIVE_TRAITS_LIST);
        List<Trait> inActiveTraits = (List<Trait>) helper.getRequestAttributeValue(TraitConfigController.IN_ACTIVE_TRAITS_LIST);
        assertNotNull(activeTraits);
        assertNotNull(inActiveTraits);
        assertEquals(1, errorsList.size());
        String errorMessage = errorsList.get(0);
        assertEquals(errorMessage, TraitConfigController.INACTIVATE_TRAIT_ERROR_MSG);
        assertTrue(helper.wasSentTo(TraitConfigController.WEB_INF_JSP_TRAIT_CONFIG));
    }

    public void testConfigTrait_TraitNotSelected_ToActivate() throws Exception {
        MockUCCHelper helper = new MockUCCHelperOverridesAutheticatedUserId(null, "testId");
        helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.CONFIG_TRAIT);
        helper.setRequestParameterValue(TraitConfigController.CONFIG_TYPE, TraitConfigController.ACTIVATE);
        controller.run(helper);
        List<String> errorsList = (List<String>) helper.getRequestAttributeValue(TraitConfigController.ERRORS_LIST);
        List<String> activeTraits = (List<String>) helper.getRequestAttributeValue(TraitConfigController.ACTIVE_TRAITS_LIST);
        List<Trait> inActiveTraits = (List<Trait>) helper.getRequestAttributeValue(TraitConfigController.IN_ACTIVE_TRAITS_LIST);
        assertNotNull(activeTraits);
        assertNotNull(inActiveTraits);
        assertEquals(1, errorsList.size());
        String errorMessage = errorsList.get(0);
        assertEquals(errorMessage, TraitConfigController.ACTIVATE_TRAIT_ERROR_MSG);
        assertTrue(helper.wasSentTo(TraitConfigController.WEB_INF_JSP_TRAIT_CONFIG));
    }
}
