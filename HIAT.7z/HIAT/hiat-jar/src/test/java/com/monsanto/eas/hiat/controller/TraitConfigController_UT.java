package com.monsanto.eas.hiat.controller;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.eas.hiat.controller.mock.MockTraitConfigController;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.service.mock.mock.MockTraitService;
import com.monsanto.eas.hiat.controller.AnalysisConstants;
import com.monsanto.eas.hiat.util.AnalysisTestConstants;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Jun 2, 2009
 * Time: 1:03:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class TraitConfigController_UT extends HIATUnitTest {
    MockTraitConfigController controller;
    MockTraitService mockTraitService;

    public void setUp() throws Exception {
        super.setUp();
        mockTraitService = new MockTraitService();
        controller = new MockTraitConfigController(new MockConfigDAO(), mockTraitService);
    }

    public void testNotSpecified_ReferenceDataIsSet() throws Exception {
       MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
        controller.run(helper);
        List<Trait> activeTraits = (List<Trait>) helper.getRequestAttributeValue(TraitConfigController.ACTIVE_TRAITS_LIST);
        List<Trait> inActiveTraits = (List<Trait>) helper.getRequestAttributeValue(TraitConfigController.IN_ACTIVE_TRAITS_LIST);
        assertNotNull(activeTraits);
        assertEquals(3, activeTraits.size());
        assertNotNull(inActiveTraits);
        assertEquals(2, inActiveTraits.size());

    }

    public void testConfigTrait_TraitNotSelected_ToInactivateTrait() throws IOException {
        MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
        helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.CONFIG_TRAIT);
        helper.setRequestParameterValue(TraitConfigController.CONFIG_TYPE, TraitConfigController.IN_ACTIVATE);
        controller.run(helper);
        List<String> errorsList = (List<String>) helper.getRequestAttributeValue(TraitConfigController.ERRORS_LIST);
        List<String> activeTraits = (List<String>) helper.getRequestAttributeValue(TraitConfigController.ACTIVE_TRAITS_LIST);
        List<Trait> inActiveTraits = (List<Trait>) helper.getRequestAttributeValue(TraitConfigController.IN_ACTIVE_TRAITS_LIST);
        assertNotNull(activeTraits);
        assertNotNull(inActiveTraits);
        assertEquals(3, activeTraits.size());
        assertEquals(2, inActiveTraits.size());
        assertEquals(1, errorsList.size());
        assertEquals(TraitConfigController.INACTIVATE_TRAIT_ERROR_MSG, errorsList.get(0));
        assertTrue(helper.wasSentTo(TraitConfigController.WEB_INF_JSP_TRAIT_CONFIG));
    }

    public void testConfigTrait_TraitNotSelected_ToActivateTrait() throws IOException {
        MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
        helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.CONFIG_TRAIT);
        helper.setRequestParameterValue(TraitConfigController.CONFIG_TYPE, TraitConfigController.ACTIVATE);
        controller.run(helper);
        List<String> errorsList = (List<String>) helper.getRequestAttributeValue(TraitConfigController.ERRORS_LIST);
        List<String> activeTraits = (List<String>) helper.getRequestAttributeValue(TraitConfigController.ACTIVE_TRAITS_LIST);
        List<Trait> inActiveTraits = (List<Trait>) helper.getRequestAttributeValue(TraitConfigController.IN_ACTIVE_TRAITS_LIST);
        assertNotNull(activeTraits);
        assertNotNull(inActiveTraits);
        assertEquals(3, activeTraits.size());
        assertEquals(2, inActiveTraits.size());
        assertEquals(1, errorsList.size());
        assertEquals(TraitConfigController.ACTIVATE_TRAIT_ERROR_MSG, errorsList.get(0));
        assertTrue(helper.wasSentTo(TraitConfigController.WEB_INF_JSP_TRAIT_CONFIG));
    }



    public void testConfigTrait_ForInActivateScenario_TraitConfig_Successful() throws Exception {
        MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
        helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.CONFIG_TRAIT);
        helper.setRequestParameterValue(TraitConfigController.TRAITS_TO_BE_INACTIVATED, "1");
        helper.setRequestParameterValue(TraitConfigController.CONFIG_TYPE, TraitConfigController.IN_ACTIVATE);
        controller.run(helper);
        List<String> errorsList = (List<String>) helper.getRequestAttributeValue(TraitConfigController.ERRORS_LIST);
        String successfulMessage = (String) helper.getRequestAttributeValue(TraitConfigController.TRAIT_CONFIG_MESSAGE);
        List<Trait> activeTraits = (List<Trait>) helper.getRequestAttributeValue(TraitConfigController.ACTIVE_TRAITS_LIST);
        List<Trait> inActiveTraits = (List<Trait>) helper.getRequestAttributeValue(TraitConfigController.IN_ACTIVE_TRAITS_LIST);
        assertNotNull(activeTraits);
        assertEquals(3, activeTraits.size());
        assertNotNull(inActiveTraits);
        assertEquals(2, inActiveTraits.size());
        assertEquals(0, errorsList.size());
        assertEquals(successfulMessage, TraitConfigController.SUCCESSFUL_MESSAGE);
        assertTrue(mockTraitService.wasConfigureTraitCalled());
    }


    public void testConfigTrait_ForActivateScenario_TraitConfig_Successful() throws Exception {
        MockUCCHelper helper = new MockUCCHelperAlwaysAuthorized();
        helper.setRequestParameterValue(AnalysisConstants.METHOD, AnalysisTestConstants.CONFIG_TRAIT);
        helper.setRequestParameterValue(TraitConfigController.TRAITS_TO_BE_ACTIVATED, "4");
        helper.setRequestParameterValue(TraitConfigController.CONFIG_TYPE, TraitConfigController.ACTIVATE);
        controller.run(helper);
        List<String> errorsList = (List<String>) helper.getRequestAttributeValue(TraitConfigController.ERRORS_LIST);
        String successfulMessage = (String) helper.getRequestAttributeValue(TraitConfigController.TRAIT_CONFIG_MESSAGE);
        List<Trait> activeTraits = (List<Trait>) helper.getRequestAttributeValue(TraitConfigController.ACTIVE_TRAITS_LIST);
        List<Trait> inActiveTraits = (List<Trait>) helper.getRequestAttributeValue(TraitConfigController.IN_ACTIVE_TRAITS_LIST);
        assertNotNull(activeTraits);
        assertEquals(3, activeTraits.size());
        assertNotNull(inActiveTraits);
        assertEquals(2, inActiveTraits.size());
        assertEquals(0, errorsList.size());
        assertEquals(successfulMessage, TraitConfigController.SUCCESSFUL_MESSAGE);
        assertTrue(mockTraitService.wasConfigureTraitCalled());
    }

    public static class MockUCCHelperAlwaysAuthorized extends MockUCCHelper {
      public MockUCCHelperAlwaysAuthorized() {
        super("MOCK");
      }

      @Override
      public boolean isUserInRole(String s) {
        return true;
      }
    }


}
