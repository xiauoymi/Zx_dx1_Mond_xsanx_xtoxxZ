package com.monsanto.eas.hiat.controller.mock;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.analysis.HybridAnalyzer;
import com.monsanto.eas.hiat.controller.HybridAnalysisController;
import com.monsanto.eas.hiat.controller.MockConfigDAO;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.TraitService;
import com.monsanto.eas.hiat.view.HybridAnalysisXMLGenerator;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Jun 2, 2009
 * Time: 3:52:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockHybridAnalysisController extends HybridAnalysisController {

    public MockHybridAnalysisController(
        TraitService traitService, HybridAnalyzer hybridAnalyzer, ProductService productService,
        HybridAnalysisXMLGenerator hybridAnalysisXmlGenerator) {
      super(new MockConfigDAO(), traitService, hybridAnalyzer, productService, hybridAnalysisXmlGenerator);
    }



    @Override
    protected boolean isUserAuthorized(UCCHelper helper) {
      return true;
    }

}
