/*
 MockInbredStatusAnalyzer was created on Mar 3, 2009 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.controller.mock;

import com.monsanto.eas.hiat.analysis.*;
import com.monsanto.eas.hiat.dao.InventoryDAO;
import com.monsanto.eas.hiat.dao.ProductionDAO;
import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.hibernate.InventoryEntryImpl;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.hibernate.ProductionEntryImpl;
import com.monsanto.eas.hiat.model.mock.MockInventoryDAO;
import com.monsanto.eas.hiat.model.mock.MockProductionDAO;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.service.ProductService;

import java.util.*;

/**
 * Filename:    $RCSfile: MockInbredAnalyzer.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-04-06 18:40:02 $
 *
 * @author rrmall
 * @version $Revision: 1.15 $
 */
public class MockInbredStatusAnalyzer extends InbredStatusAnalyzer {
  private Collection<Product> lastProductListPassed;
  private Collection<Trait> listTraitListPassed;
  List<InbredStatus> statusList;

  public MockInbredStatusAnalyzer() {
    this(new MockProductServiceConfiguredForNE5112v1(), new MockInventoryDAO(), new MockProductionDAO());
  }

  public MockInbredStatusAnalyzer(ProductService productService, InventoryDAO inventoryDao, ProductionDAO productionDao) {
    super(productService, inventoryDao, productionDao);
  }

  public List<InbredStatus> analyze(Collection<Product> products, Collection<Trait> traits) {
    Product testProduct;
    lastProductListPassed = products;
    listTraitListPassed = traits;

    statusList = new ArrayList<InbredStatus>();
    for (Product product : products) {
      Map<ProductNameType, ProductName> names = product.getProductNames();
      ProductName productName = names.get(ProductNameType.BASE_MANUFACTURING);
      if (productName.getName().equalsIgnoreCase("NE5112_v1")) {
        testProduct = new ProductImpl(1L, "TEST", new MockTrait("XYZ"), null, null, null, null, false, null, null, false);
        Trait trait = new MockTrait(2L, "CHC", "ABC-DEF", "AABBCC", null, true);
        Map<InventoryType, InventoryEntry> inventoryQuantities = new HashMap<InventoryType, InventoryEntry>();
        inventoryQuantities.put(InventoryType.GENERATION_1, new InventoryEntryImpl(testProduct, 10, InventoryType.GENERATION_1));
        inventoryQuantities.put(InventoryType.GENERATION_2, new InventoryEntryImpl(testProduct, 20, InventoryType.GENERATION_1));
        inventoryQuantities.put(InventoryType.PREFOUNDATION, new InventoryEntryImpl(testProduct, 30, InventoryType.GENERATION_1));

        Map<InventoryType, Collection<ProductionEntry>> productionQuantities = new HashMap<InventoryType, Collection<ProductionEntry>>();
        productionQuantities.put(InventoryType.GENERATION_1, singleEntryColl(new ProductionEntryImpl(new Date(), new ProductImpl(), 11, InventoryType.GENERATION_1, false)));
        productionQuantities.put(InventoryType.GENERATION_2, singleEntryColl(new ProductionEntryImpl(new Date(), new ProductImpl(), 22, InventoryType.GENERATION_2, false)));
        productionQuantities.put(InventoryType.PREFOUNDATION, singleEntryColl(new ProductionEntryImpl(new Date(), new ProductImpl(), 33, InventoryType.PREFOUNDATION, false)));
        Set<InbredStatusDetail> testDetailSet = new HashSet<InbredStatusDetail>();

        Date testHandoffDate = new GregorianCalendar(2009, Calendar.JANUARY, 11).getTime();
        Date testPrimaryTestingDate = new GregorianCalendar(2009, Calendar.MARCH, 1).getTime();

        InbredStatusDetail testDetail = new InbredStatusDetailImpl(trait, product, testHandoffDate, testPrimaryTestingDate,
                inventoryQuantities, productionQuantities, new HashMap<InventoryType, Collection<ProductionEntry>>());
        testDetailSet.add(testDetail);

        InbredStatus status = new InbredStatusImpl(testProduct, testDetailSet);


        statusList.add(status);
      } else if (productName.getName().equalsIgnoreCase("DKC1121")) {
        testProduct = new ProductImpl(2L, "DKC112", new MockTrait("DKC1"), null, null, null, null, false, null, null, false);
        Trait trait = new MockTrait(2L, "CHC", "ABC-DEF", "AABBCC", null, true);
        Map<InventoryType, InventoryEntry> inventoryQuantities = new HashMap<InventoryType, InventoryEntry>();
        inventoryQuantities.put(InventoryType.GENERATION_1, new InventoryEntryImpl(testProduct, 111, InventoryType.GENERATION_1));
        inventoryQuantities.put(InventoryType.GENERATION_2, new InventoryEntryImpl(testProduct, 222, InventoryType.GENERATION_1));
        inventoryQuantities.put(InventoryType.PREFOUNDATION, new InventoryEntryImpl(testProduct, 333, InventoryType.GENERATION_1));

        Map<InventoryType, Collection<ProductionEntry>> productionQuantities = new HashMap<InventoryType, Collection<ProductionEntry>>();
        productionQuantities.put(InventoryType.GENERATION_1, singleEntryColl(new ProductionEntryImpl(new Date(), new ProductImpl(), 101, InventoryType.GENERATION_1, false)));
        productionQuantities.put(InventoryType.GENERATION_2, singleEntryColl(new ProductionEntryImpl(new Date(), new ProductImpl(), 202, InventoryType.GENERATION_2, false)));
        productionQuantities.put(InventoryType.PREFOUNDATION, singleEntryColl(new ProductionEntryImpl(new Date(), new ProductImpl(), 303, InventoryType.PREFOUNDATION, false)));
        Set<InbredStatusDetail> testDetailSet = new HashSet<InbredStatusDetail>();

        Date testHandoffDate = new GregorianCalendar(2009, Calendar.FEBRUARY, 11).getTime();
        Date testPrimaryTestingDate = new GregorianCalendar(2009, Calendar.APRIL, 1).getTime();

        InbredStatusDetail testDetail = new InbredStatusDetailImpl(trait, product, testHandoffDate, testPrimaryTestingDate,
                inventoryQuantities, productionQuantities, new HashMap<InventoryType, Collection<ProductionEntry>>());
        testDetailSet.add(testDetail);

        InbredStatus status = new InbredStatusImpl(testProduct, testDetailSet);


        statusList.add(status);
      }else if (productName.getName().equalsIgnoreCase("01DKD2")) {
        testProduct = new ProductImpl(2L, "01DKD2", new MockTrait("DKC1"), null, null, null, null, false, null, null, false);
        Trait trait = new MockTrait(2L, "CHC", "ABC-DEF", "AABBCC", null, true);
        Map<InventoryType, InventoryEntry> inventoryQuantities = new HashMap<InventoryType, InventoryEntry>();
        inventoryQuantities.put(InventoryType.GENERATION_1, new InventoryEntryImpl(testProduct, 111, InventoryType.GENERATION_1));
        inventoryQuantities.put(InventoryType.GENERATION_2, new InventoryEntryImpl(testProduct, 222, InventoryType.GENERATION_1));
        inventoryQuantities.put(InventoryType.PREFOUNDATION, new InventoryEntryImpl(testProduct, 333, InventoryType.GENERATION_1));

        Map<InventoryType, Collection<ProductionEntry>> productionQuantities = new HashMap<InventoryType, Collection<ProductionEntry>>();
        productionQuantities.put(InventoryType.GENERATION_1, singleEntryColl(new ProductionEntryImpl(new Date(), new ProductImpl(), 101, InventoryType.GENERATION_1, false)));
        productionQuantities.put(InventoryType.GENERATION_2, singleEntryColl(new ProductionEntryImpl(new Date(), new ProductImpl(), 202, InventoryType.GENERATION_2, false)));
        productionQuantities.put(InventoryType.PREFOUNDATION, singleEntryColl(new ProductionEntryImpl(new Date(), new ProductImpl(), 303, InventoryType.PREFOUNDATION, false)));
        Set<InbredStatusDetail> testDetailSet = new HashSet<InbredStatusDetail>();

        Date testHandoffDate = new GregorianCalendar(2009, Calendar.FEBRUARY, 11).getTime();
        Date testPrimaryTestingDate = new GregorianCalendar(2009, Calendar.APRIL, 1).getTime();

        InbredStatusDetail testDetail = new InbredStatusDetailImpl(trait, null, null, null,
                new HashMap<InventoryType, InventoryEntry>(), new HashMap<InventoryType, Collection<ProductionEntry>>(), new HashMap<InventoryType, Collection<ProductionEntry>>());
        testDetailSet.add(testDetail);

        InbredStatus status = new InbredStatusImpl(testProduct, testDetailSet);


        statusList.add(status);
      }
    }

//    Set<InbredStatusImpl> set = new TreeSet<InbredStatusImpl>();
//    for (InbredStatus analysis: statusList){
//      set.add((InbredStatusImpl)analysis);
//    }
    return statusList;
  }

  private Collection<ProductionEntry> singleEntryColl(ProductionEntry prodEntry) {
    Collection<ProductionEntry> coll = new LinkedList<ProductionEntry>();
    coll.add(prodEntry);
    return coll;
  }

  public Collection<Product> getProductListPassed() {
    return lastProductListPassed;
  }

  public Collection<Trait> getTraitListPassed() {
    return listTraitListPassed;
  }

  public List<InbredStatus> getAnalysisList() {
    return statusList;
  }
}