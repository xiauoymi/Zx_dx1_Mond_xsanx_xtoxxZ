package com.monsanto.eas.hiat.controller.mock;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.eas.hiat.analysis.InbredStatusAnalyzer;
import com.monsanto.eas.hiat.controller.InbredStatusController;
import com.monsanto.eas.hiat.controller.MockConfigDAO;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.TraitService;
import com.monsanto.eas.hiat.view.InbredStatusXMLGenerator;

/**
 * Created by vvvelu Date: Feb 25, 2009 Time: 9:48:18 AM
 */
public class MockInbredStatusController extends InbredStatusController {

  public MockInbredStatusController(TraitService traitService,
                                      InbredStatusAnalyzer inbredStatusAnalyzer, ProductService productService, InbredStatusXMLGenerator xmlGenerator) {
    super(new MockConfigDAO(), traitService, inbredStatusAnalyzer, productService, xmlGenerator);
  }


  protected boolean isUserAuthorized(UCCHelper helper) {
    return true;
  }

}
