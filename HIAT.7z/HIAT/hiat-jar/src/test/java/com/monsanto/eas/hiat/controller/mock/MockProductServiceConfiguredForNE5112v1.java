/*
 MockProductServiceConfiguredForNE5112v1 was created on Mar 3, 2009 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.controller.mock;

import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.hibernate.ProductNameImpl;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.service.ProductSearchResults;
import com.monsanto.eas.hiat.service.ProductServiceImpl;
import com.monsanto.wst.hibernate.mock.MockDAO;

import java.util.*;

/**
 * @author rrmall
 */
public class MockProductServiceConfiguredForNE5112v1 extends ProductServiceImpl {
  //todo this is an overly elaborate mock, probably need to break up and just setup whatever piece is needed in each test
  public MockProductServiceConfiguredForNE5112v1() {
    super(new MockDAO<Product, Long>());
  }

  public static final String TEST_PRODUCT_1 = "NE5112_v1";
  public static final String PRODUCT_THAT_DOES_NOT_EXIST = "XYZ";

  @Override
  public Collection<Product> getProductByBaseAndTrait(Product product, Trait trait) {
    List<Product> productList = new ArrayList<Product>();
    if (product.getProductName(ProductNameType.BASE_PRECOMMERCIAL) == "01DKD2") {
      return productList;
    }
    Product baseProduct = new ProductImpl(1L, "1", trait, null, null, product.getHandoffDate(), product.getPrimaryTestingDate(), true, null,
            null, false);
    ProductName name = new ProductNameImpl(11L, "BASE_MFG", baseProduct, DataSource.PREFOUNDATION, "1",
            ProductNameType.BASE_MANUFACTURING);
    Map<ProductNameType, ProductName> productNamesMap = new HashMap<ProductNameType, ProductName>();
    productNamesMap.put(name.getType(), name);
    name = new ProductNameImpl(12L, "BASE_PRECOMM", baseProduct, DataSource.PREFOUNDATION, "1",
            ProductNameType.BASE_PRECOMMERCIAL);
    productNamesMap.put(name.getType(), name);
    baseProduct.setProductNames(productNamesMap);
    productList.add(baseProduct);
    return productList;
  }

  public ProductSearchResults lookupProductMatchingInputCriteria(String productNamesEntered, boolean isHybrid) {
    String[] pNames = productNamesEntered.split("\\s+");
    ProductSearchResults results = new ProductSearchResults(productNamesEntered);
    for (String p : pNames) {
      if (p.equalsIgnoreCase(TEST_PRODUCT_1)) {
        ProductImpl product = new ProductImpl(2L, "1", new MockTrait(1L, "SSTX", null, null, null, true), null, null, null, null, false, null,
                null, false);
        ProductName baseMfgNameForProd2 = new ProductNameImpl(21L, TEST_PRODUCT_1, product, DataSource.PREFOUNDATION, "1",
                ProductNameType.BASE_MANUFACTURING);
        Map<ProductNameType, ProductName> productNamesMap = new HashMap<ProductNameType, ProductName>();
        productNamesMap.put(baseMfgNameForProd2.getType(), baseMfgNameForProd2);
        product.setProductNames(productNamesMap);
        results.add(product);
      } else if (p.equalsIgnoreCase("DKC*")) {
        ProductImpl product = new ProductImpl(3L, "1", new MockTrait(1L, "CTCX", null, null, null, true), null, null, null, null, false, null,
                null, false);
        ProductName baseMfgNameForProd = new ProductNameImpl(21L, "DKC1121", product, DataSource.PREFOUNDATION, "1",
                ProductNameType.BASE_MANUFACTURING);
        Map<ProductNameType, ProductName> productNamesMap = new HashMap<ProductNameType, ProductName>();
        productNamesMap.put(baseMfgNameForProd.getType(), baseMfgNameForProd);
        product.setProductNames(productNamesMap);
        results.add(product);
      } else if (p.equalsIgnoreCase("NE5112_v2")) {
        setupNE5112V2(results);
      } else if (p.equalsIgnoreCase(PRODUCT_THAT_DOES_NOT_EXIST) || p.equalsIgnoreCase(PRODUCT_THAT_DOES_NOT_EXIST + "*")) {
        results.fail(p);
      } else {
        ProductImpl product = new ProductImpl(3L, "1", new MockTrait(1L, "ABCD", null, null, null, true), null, null, null, null, false, null,
                null, false);
        ProductName baseMfgNameForProd = new ProductNameImpl(22L, "ABC_v1", product, DataSource.PREFOUNDATION, "1",
                ProductNameType.BASE_MANUFACTURING);
        Map<ProductNameType, ProductName> productNamesMap = new HashMap<ProductNameType, ProductName>();
        productNamesMap.put(baseMfgNameForProd.getType(), baseMfgNameForProd);
        product.setProductNames(productNamesMap);
        results.add(product);
      }
    }

    return results;
  }

  private void setupNE5112V2(ProductSearchResults results) {
    ProductImpl baseProduct1 = new ProductImpl(7L, "BASE 1", new MockTrait("BASE 1"), null, null, new Date(), new Date(), true, null,
            null, false);
    ProductImpl baseProduct2 = new ProductImpl(8L, "BASE 2", new MockTrait("BASE 2"), null, null, new Date(), new Date(), true, null,
            null, false);

    ProductName baseMfgNameForProd1 = new ProductNameImpl(71L, "HCL119_BASE", baseProduct1, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING);
    ProductName baseMfgNameForProd2 = new ProductNameImpl(81L, "HCL414_BASE", baseProduct2, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING);
    ProductName basePreCommNameForProd1 = new ProductNameImpl(711L, "HCL119NRR1", baseProduct1, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_PRECOMMERCIAL);
    ProductName basePreCommNameForProd2 = new ProductNameImpl(811L, "HCL414NRR1", baseProduct2, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_PRECOMMERCIAL);

    Map<ProductNameType, ProductName> productNamesForProd1 = new HashMap<ProductNameType, ProductName>();
    Map<ProductNameType, ProductName> productNamesForProd2 = new HashMap<ProductNameType, ProductName>();
    productNamesForProd1.put(ProductNameType.BASE_MANUFACTURING, baseMfgNameForProd2);
    productNamesForProd1.put(ProductNameType.BASE_PRECOMMERCIAL, basePreCommNameForProd1);
    baseProduct1.setProductNames(productNamesForProd1);

    productNamesForProd2.put(ProductNameType.BASE_MANUFACTURING, baseMfgNameForProd1);
    productNamesForProd2.put(ProductNameType.BASE_PRECOMMERCIAL, basePreCommNameForProd2);
    baseProduct2.setProductNames(productNamesForProd2);

    ProductImpl product3 = new ProductImpl(3L, "1", new MockTrait("PPTX"), null, null, null, null, false, baseProduct1,
            null, false);
    ProductImpl product4 = new ProductImpl(4L, "1", new MockTrait("QQTX"), null, null, null, null, false, baseProduct2,
            null, false);

    ProductImpl product5 = new ProductImpl(5L, "1", new MockTrait("SSTX"), product3, product4, new Date(), new Date(), true, null,
            null, false);
    ProductName baseMfgNameForProd5 = new ProductNameImpl(51L, "NE5112_v2", product5, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING);
    Map<ProductNameType, ProductName> productNamesForProd5 = new HashMap<ProductNameType, ProductName>();
    productNamesForProd5.put(ProductNameType.BASE_MANUFACTURING, baseMfgNameForProd5);
    product5.setProductNames(productNamesForProd5);
    results.add(product5);
  }

  public Collection<Product> getUniqueBaseProducts(Collection<Product> products) {
    if (products.isEmpty()) {
      return new ArrayList<Product>();
    }

    Set<Product> baseProductList = new HashSet<Product>();
    for (Product prod : products) {
      baseProductList.add(prod.getBase());
    }
//    List<Product> productList = new ArrayList<Product>();
//    Product product = new ProductImpl(1L, "1", new MockTrait(1L, "ABCD", null, null, null), null, null, null, null, true, null,
//        null, false);
//    productList.add(product);
    return baseProductList;
  }

  @Override
  public Product lookupProductById(Long id) {
    return new MockProduct(id, "MOCK", new MockTrait(2L), new MockProduct(1L), new MockProduct(3L), new Date(), new Date(), false, new MockProduct(4L), "Primary", false);
  }
}