package com.monsanto.eas.hiat.controller.mock;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.service.mock.mock.MockTraitDAO;
import com.monsanto.eas.hiat.trait.TraitTree;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class MockTraitCalculator implements Calculator<Trait, List<TraitTree>> {
    public List<TraitTree> calculate(Trait trait) {
        List<TraitTree> listOfPossibleParents = new ArrayList<TraitTree>();
        final Trait conventional = new MockTraitDAO().getConventional();
        listOfPossibleParents.add(new TraitTree(trait, conventional));
        if (trait != conventional) {
            listOfPossibleParents.add(new TraitTree(conventional, trait));
        }
        return listOfPossibleParents;
    }
}
