package com.monsanto.eas.hiat.controller.mock;

import com.monsanto.eas.hiat.controller.TraitConfigController;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import com.monsanto.eas.hiat.service.TraitService;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.ServletFramework.UCCHelper;

/**
 * Created by IntelliJ IDEA.
 * User: VVVELU
 * Date: Jun 2, 2009
 * Time: 4:29:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockTraitConfigController extends TraitConfigController {
    public MockTraitConfigController(GenericDAO<HIATConfiguration, Long> configDAO, TraitService traitService) {
        super(configDAO, traitService);
    }

    @Override
    protected boolean isUserAuthorized(UCCHelper helper) {
        return true;
    }

}
