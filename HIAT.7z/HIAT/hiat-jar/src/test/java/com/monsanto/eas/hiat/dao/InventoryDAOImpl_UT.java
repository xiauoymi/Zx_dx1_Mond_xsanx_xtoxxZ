package com.monsanto.eas.hiat.dao;

import com.monsanto.eas.hiat.model.InventoryEntry;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.mock.MockDAO;
import org.hibernate.criterion.Criterion;

import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InventoryDAOImpl_UT extends HIATUnitTest {
    public void testfindAllCallsFindAllOfBaseDAO() throws Exception {
        MockDAO<InventoryEntry, Long> mockDAO = new MockDAO<InventoryEntry, Long>();
        InventoryDAO dao = new InventoryDAOImpl(mockDAO);
        assertFalse(mockDAO.wasFindAllCalled());
        dao.findAll();
        assertTrue(mockDAO.wasFindAllCalled());
    }

    public void testFindByProduct_CriteriaWasUsed() throws Exception {
        MockDAO<InventoryEntry, Long> mockDAO = new MockDAO<InventoryEntry, Long>();
        InventoryDAO dao = new InventoryDAOImpl(mockDAO);
        Product testProduct = new ProductImpl();
        List<InventoryEntry> inventory = dao.findByProduct(testProduct);
        assertNotNull(inventory);
        assertFalse(mockDAO.wasFindAllCalled());
        MockCriteria criteria = mockDAO.getMockCriteria();
        assertTrue(criteria.wasListCalled());
        List<Criterion> critList = criteria.getCriteria();
        assertNotNull(critList);
        assertEquals(1, critList.size());
    }

    public void testFindByProductAndGeneration_CriteriaWasUsed() throws Exception {
        MockDAO<InventoryEntry, Long> mockDAO = new MockDAO<InventoryEntry, Long>();
        InventoryDAO dao = new InventoryDAOImpl(mockDAO);
        Product testProduct = new ProductImpl();
        long qty = dao.getInventory(testProduct, InventoryType.GENERATION_1);
        assertFalse(mockDAO.wasFindAllCalled());
        MockCriteria criteria = mockDAO.getMockCriteria();
        assertTrue(criteria.wasListCalled());
        List<Criterion> critList = criteria.getCriteria();
        assertNotNull(critList);
        assertEquals(2, critList.size());
    }

}