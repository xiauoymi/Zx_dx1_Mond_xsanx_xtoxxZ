package com.monsanto.eas.hiat.database;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */

import com.monsanto.wst.hibernate.HibernateFactoryImpl;
import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.Oracle10gDialect;

public class GenerateDDL {
  public static void main(String[] args) {
    Configuration cfg = HibernateFactoryImpl.getConfigurationForApp("hiat");
    cfg.addResource("hibernate.cfg.xml");
    String[] lines = cfg.generateSchemaCreationScript(new Oracle10gDialect());

    for (String line : lines) {
      System.out.println(line + ";");
    }
  }
}