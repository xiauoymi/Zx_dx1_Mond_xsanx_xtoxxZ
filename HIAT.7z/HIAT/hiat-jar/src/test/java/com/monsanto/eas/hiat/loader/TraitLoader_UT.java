package com.monsanto.eas.hiat.loader;

import org.junit.Test;
import com.monsanto.wst.hibernate.mock.MockHibernateFactory;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.eas.hiat.model.Trait;

import java.io.ByteArrayInputStream;
import java.util.Collection;
import java.util.ArrayList;

import static org.junit.Assert.*;


/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class TraitLoader_UT {

  @Test
  public void testUnknownParentThrowsException() throws Exception {
    String testParentCommName = "ABC";
    String testParentFullName = "ABC";
    String testParentCode = "ABC";
    String testCommName = "A01";
    String testFullName = testParentCode + TraitLoader.PARENT_SEPERATOR  + "XYZ";
    String testCode = "LMN";
    String fileString =
            testParentCommName + TraitLoader.FIELD_SEPERATOR +
            testParentFullName + TraitLoader.FIELD_SEPERATOR +
            testParentCode + "\n" +
            testCommName + TraitLoader.FIELD_SEPERATOR +
            testFullName + TraitLoader.FIELD_SEPERATOR +
            testCode;
    TraitLoader loader = new TraitLoader(new MockHibernateFactory() ,new MockDAO<Trait,Long>());
    try {
        loader.parseTraits(new ByteArrayInputStream(fileString.getBytes()));
        fail("Expected failure due to unknown parent");
    } catch (Exception IGNORE) {
      // ignore expected exception
    }
  }

  @Test
  public void testTraitWithNoParent() throws Exception {
    String testCommName = "A01";
    String testFullName = "A01";
    String testCode = "ABC";
    String fileString = testCommName + TraitLoader.FIELD_SEPERATOR +
            testFullName + TraitLoader.FIELD_SEPERATOR +
            testCode;
    TraitLoader loader = new TraitLoader(new MockHibernateFactory(), new MockDAO<Trait,Long>());
    Collection<Trait> results = loader.parseTraits(new ByteArrayInputStream(fileString.getBytes()));
    assertNotNull(results);
    assertEquals(1, results.size());
    Trait result = results.iterator().next();
    assertNotNull(result);
    assertEquals(testCommName, result.getCommercialName());
    assertEquals(testFullName, result.getFullName());
    assertEquals(testCode, result.getCode());
    assertTrue(result.getParentTraits().isEmpty());
  }

  @Test
  public void testTraitsWithParentRelationship() throws Exception {
    String testParentCommName = "A01";
    String testParentFullName = "A01";
    String testParentCode = "ABC";
    String testParent2CommName = "B01";
    String testParent2FullName = "B01";
    String testParent2Code = "BBB";
    String testCommName = "XYZ";
    String testFullName = testParentCommName + TraitLoader.PARENT_SEPERATOR + testParent2CommName;
    String testCode = "XYZ";
    String fileString =
            testParentCommName + TraitLoader.FIELD_SEPERATOR +
            testParentFullName + TraitLoader.FIELD_SEPERATOR +
            testParentCode + "\n" +
            testParent2CommName + TraitLoader.FIELD_SEPERATOR +
            testParent2FullName + TraitLoader.FIELD_SEPERATOR +
            testParent2Code + "\n" +
            testCommName + TraitLoader.FIELD_SEPERATOR +
            testFullName + TraitLoader.FIELD_SEPERATOR +
            testCode + "\n";
    TraitLoader loader = new TraitLoader(new MockHibernateFactory(), new MockDAO<Trait,Long>());
    Collection<Trait> results = loader.parseTraits(new ByteArrayInputStream(fileString.getBytes()));
    assertNotNull(results);
    assertEquals(3, results.size());
    Collection<Trait> parentTraits = new ArrayList<Trait>();
    Trait childTrait = null;
    for (Trait result : results) {
      if (result.getCode().equals(testCode)) {
        childTrait = result;
      } else {
        parentTraits.add(result);
      }
    }

    assertNotNull("Expected to find child trait but did not: " + results, childTrait);
    assertEquals(testCommName, childTrait.getCommercialName());
    assertEquals(testFullName, childTrait.getFullName());
    Collection<Trait> childParents = childTrait.getParentTraits();
    assertTrue("Expected to find all of the parent traits: " + parentTraits + " in " + childParents,
            childParents.containsAll(parentTraits));

  }
}
