package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.dao.TraitDAO;
import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import com.monsanto.wst.dao.GenericDAO;

import java.util.*;

public abstract class HIATDatabaseTestCase extends HIATUnitTest {
  ProductImpl testProduct;
  Trait testTrait;

  @Override
  protected void setUp() throws Exception {
    new TestInitService().getHibernate().beginTransaction();
    super.setUp();
  }

  @Override
  protected void tearDown() throws Exception {
    new TestInitService().getHibernate().rollbackTransaction();
    super.tearDown();
  }

  public void setUpProductTraitData(boolean isHybrid) {
    Trait fatherTrait;
    Trait motherTrait;
    InventoryEntry invEntry1;
    InventoryEntry invEntry2;
    InventoryEntry invEntry3;
    ProductionEntry productionEntry1;
    ProductionEntry productionEntry2;
    ProductionEntry productionEntry3;
    Product baseProduct;
    TestInitService initService = new TestInitService();
    GenericDAO<Product, Long> productDAO = initService.initProductDAO();
    TraitDAO traitDAO = initService.initTraitDAO();
    GenericDAO<InventoryEntry, Long> inventoryEntryDAO = initService.initInventoryEntryDAO();
    GenericDAO<ProductionEntry, Long> productEntryDAO = initService.initProductionEntryDAO();


    Set<Trait> parentTraits = new HashSet<Trait>();
    fatherTrait = new TraitImpl(null, "FATHER", "SUPER FATHER", "SUPER FATHER", new HashSet<Trait>(), true);
    traitDAO.save(fatherTrait);
    motherTrait = new TraitImpl(null, "MOTHER", "SUPER MOTHER", "SUPER MOTHER", new HashSet<Trait>(), true);
    traitDAO.save(motherTrait);
    parentTraits.add(fatherTrait);
    parentTraits.add(motherTrait);
    testTrait = new TraitImpl(null, "CHILD", "SUPER DUPER", "CHILD-IS-SUPER", parentTraits, true);
    traitDAO.save(testTrait);

    Trait testTraitMaleParent = new TraitImpl(null, "MALE", "SUPER MALE", "SUPER MALE COMM NAMe", new HashSet<Trait>(), true);
    traitDAO.save(testTraitMaleParent);

    Trait testTraitFemaleParent = new TraitImpl(null, "FEMALE", "SUPER FEMALE", "SUPER FEMALE COMM NAME", new HashSet<Trait>(), true);
    traitDAO.save(testTraitFemaleParent);

    Date handOffDate = new GregorianCalendar(2009, 1, 1).getTime();
    Date primaryTestingDate = new GregorianCalendar(2009, 2, 1).getTime();

    Product testProductBaseMale = new ProductImpl(null, "3", testTraitMaleParent, null, null, handOffDate, primaryTestingDate, true, null,
        null, false);
    productDAO.save(testProductBaseMale);

    Product testProductMaleParent = new ProductImpl(null, "1", testTraitMaleParent, null, null, handOffDate, primaryTestingDate, true, testProductBaseMale,
        null, false);
    productDAO.save(testProductMaleParent);


     Product testProductBaseFemale = new ProductImpl(null, "2", testTraitFemaleParent, null, null, handOffDate, primaryTestingDate, true, null,
        "Primary", false);
    productDAO.save(testProductBaseFemale);

    Product testProductFemaleParent = new ProductImpl(null, "1", testTraitFemaleParent, null, null, handOffDate, primaryTestingDate, true, testProductBaseFemale,
        "Active", false);
    productDAO.save(testProductFemaleParent);
    
    baseProduct = new ProductImpl(null, null, null, testProductFemaleParent, testProductMaleParent, handOffDate, primaryTestingDate, true, null, null, false);
    productDAO.save(baseProduct);
    handOffDate = new GregorianCalendar(2009, 2, 2).getTime();
    primaryTestingDate = new GregorianCalendar(2009, 3, 2).getTime();

    testProduct = new ProductImpl(null, "1", testTrait, testProductFemaleParent, testProductMaleParent, handOffDate, primaryTestingDate, true, baseProduct,
        "Primary", isHybrid);

    Map<ProductNameType, ProductName> productNames = new HashMap<ProductNameType, ProductName>();
    ProductName name = new ProductNameImpl(null, "BASE_MFG_NAME", testProduct, DataSource.PREFOUNDATION, "1",
        ProductNameType.BASE_MANUFACTURING);
    productNames.put(ProductNameType.BASE_MANUFACTURING, name);

    ProductName name1 = new ProductNameImpl(null, "BASE_PRE_COMM_NAME", testProduct, DataSource.PREFOUNDATION, "1",
        ProductNameType.BASE_PRECOMMERCIAL);
    productNames.put(ProductNameType.BASE_PRECOMMERCIAL, name1);

    ProductName name2 = new ProductNameImpl(null, "COMMERCIAL_NAME", testProduct, DataSource.PREFOUNDATION, "1",
        ProductNameType.COMMERCIAL);
    productNames.put(ProductNameType.COMMERCIAL, name2);

    ProductName name3 = new ProductNameImpl(null, "TRAITED_PRE_COMM_NAME", testProduct, DataSource.PREFOUNDATION, "1",
        ProductNameType.TRAITED_PRECOMMERCIAL);
    productNames.put(ProductNameType.TRAITED_PRECOMMERCIAL, name3);

    testProduct.setProductNames(productNames);
    productDAO.save(testProduct);

    invEntry1 = new InventoryEntryImpl(testProduct, 20, InventoryType.GENERATION_1);
    inventoryEntryDAO.save(invEntry1);
    invEntry2 = new InventoryEntryImpl(testProduct, 30, InventoryType.GENERATION_2);
    inventoryEntryDAO.save(invEntry2);
    invEntry3 = new InventoryEntryImpl(testProduct, 10, InventoryType.PREFOUNDATION);
    inventoryEntryDAO.save(invEntry3);

    productionEntry1 = new ProductionEntryImpl(handOffDate, testProduct, 2222, InventoryType.GENERATION_1, false);
    productEntryDAO.save(productionEntry1);
    productionEntry2 = new ProductionEntryImpl(handOffDate, testProduct, 333, InventoryType.GENERATION_2, false);
    productEntryDAO.save(productionEntry2);
    productionEntry3 = new ProductionEntryImpl(handOffDate, testProduct, 111, InventoryType.PREFOUNDATION, false);
    productEntryDAO.save(productionEntry3);
  }

  public ProductImpl getTestProduct() {
    return testProduct;
  }

  public Trait getTestTrait() {
    return testTrait;
  }
}
