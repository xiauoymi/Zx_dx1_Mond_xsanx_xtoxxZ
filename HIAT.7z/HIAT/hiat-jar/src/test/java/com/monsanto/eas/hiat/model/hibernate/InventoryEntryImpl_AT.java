package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.InventoryEntry;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.dao.GenericDAO;

import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InventoryEntryImpl_AT extends HIATDatabaseTestCase {
    public void testInitDAO() throws Exception {
        GenericDAO<InventoryEntry, Long> dao = new TestInitService().initInventoryEntryDAO();
        assertNotNull(dao);
    }

    public void testNegativeProductIdDoesntExist() throws Exception {
        GenericDAO<InventoryEntry, Long> dao = new TestInitService().initInventoryEntryDAO();
        long testId = TestUtils.getRandomLong();
        if (testId > 0) {
            testId = -testId;
        } else if (testId == 0) {
            testId = -1;
        }

        InventoryEntry entry = dao.findByPrimaryKey(testId);
        assertNull(entry);
    }

    public void testFindByExample() throws Exception {
        GenericDAO<InventoryEntry, Long> dao = new TestInitService().initInventoryEntryDAO();
        Product testProduct = new ProductImpl();
        InventoryEntry example = new InventoryEntryImpl(testProduct, 0, null);
        String[] excludedProperties = {"quantity", "inventoryType"};
        List<InventoryEntry> entries = dao.findByExample(example, excludedProperties);
        assertNotNull(entries);
    }
}