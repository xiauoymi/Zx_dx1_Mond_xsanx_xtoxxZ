package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.InventoryEntry;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.util.HIATUnitTest;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InventoryEntryImpl_UT extends HIATUnitTest {
  public void testNewInventoryEntryIsAllNulls() throws Exception {
    InventoryEntry invEntry = new InventoryEntryImpl();
    assertNull(invEntry.getProduct());
    assertNull(invEntry.getType());
    assertEquals(0, invEntry.getQuantity());
  }

  public void testNewInventoryEntryWithValuesHasValues() throws Exception {
    Product testProduct = new ProductImpl();
    long testQuantity = 123L;
    InventoryType testInventoryType = InventoryType.GENERATION_1;
    InventoryEntry invEntry = new InventoryEntryImpl(testProduct, testQuantity, testInventoryType);
    assertEquals(testProduct, invEntry.getProduct());
    assertEquals(testQuantity, invEntry.getQuantity());
    assertEquals(testInventoryType, invEntry.getType());
  }

  public void testThousandsSeperator() throws Exception {
    Product testProduct = new ProductImpl();
    long testQuantity = 123456L;
    InventoryType testInventoryType = InventoryType.GENERATION_1;
    InventoryEntry invEntry = new InventoryEntryImpl(testProduct, testQuantity, testInventoryType);
    assertEquals("123,456", invEntry.getFormattedQuantity());
  }
}