package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.dao.GenericDAO;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ProductImpl_AT extends HIATDatabaseTestCase {
    public void testInitDAO() throws Exception {
        GenericDAO<Product, Long> dao = new TestInitService().initProductDAO();
        assertNotNull(dao);
    }

    public void testNegativeProductIdDoesntExist() throws Exception {
        GenericDAO<Product, Long> dao = new TestInitService().initProductDAO();
        long testId = TestUtils.getRandomLong();
        if (testId > 0) {
            testId = -testId;
        } else if (testId == 0) {
            testId = -1;
        }

        Product prod = dao.findByPrimaryKey(testId);
        assertNull(prod);
    }
}