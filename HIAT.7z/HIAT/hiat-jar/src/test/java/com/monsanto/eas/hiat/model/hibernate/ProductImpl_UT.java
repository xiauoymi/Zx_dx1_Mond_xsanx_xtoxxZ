package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.util.DateTestUtil;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ProductImpl_UT extends HIATUnitTest {
    public void testNewProductIsAllNulls() throws Exception {
        Product prod = new ProductImpl();
        assertNull(prod.getFemaleParent());
        assertNull(prod.getMaleParent());
        assertNull(prod.getTrait());
        assertEquals("", prod.getTraitVersion());
        assertNull(prod.getHandoffDate());
        assertNull(prod.getPrimaryTestingDate());
        assertEquals(prod, prod.getBase());
    }

    public void testNewProductWithValuesHasValues() throws Exception {
        String testTraitVersion = "1";
        Trait testTrait = new MockTrait(1L, "RR2", "RR2TEST", "TEST", null, true);
        String testBaseInbred = "12DK34";
        Product testFemaleParent = new ProductImpl();
        Product testMaleParent = new ProductImpl();
        Product testBaseProduct = new ProductImpl();
        Date testHandoffDate = new GregorianCalendar(2009, Calendar.JANUARY, 11).getTime();
        Date testPrimaryTestingDate = new GregorianCalendar(2009, Calendar.MARCH, 1).getTime();
        Product prod = new ProductImpl(0L, testTraitVersion, testTrait,
                testFemaleParent, testMaleParent, testHandoffDate, testPrimaryTestingDate, false, testBaseProduct, null, false);
        assertEquals(testTraitVersion, prod.getTraitVersion());
        assertEquals(testTrait, prod.getTrait());
        assertEquals(testFemaleParent, prod.getFemaleParent());
        assertEquals(testMaleParent, prod.getMaleParent());
        DateTestUtil.assertDatesEqual(testHandoffDate, prod.getHandoffDate());
        DateTestUtil.assertDatesEqual(testPrimaryTestingDate, prod.getPrimaryTestingDate());
        assertEquals(testBaseProduct, prod.getBase());
    }

  public void testGetProductNamesForProduct_SetReturned() throws Exception {
    Product product = createNewProduct();
    assertEquals(4, product.getProductNames().size());
    Map<ProductNameType, ProductName> namesMap = product.getProductNames();
    ProductName name = namesMap.get(ProductNameType.TRAITED_PRECOMMERCIAL);
    assertEquals("XYZ_123", name.getName());
    assertEquals(product, name.getProduct());
    assertEquals(DataSource.PREFOUNDATION, name.getSource());
    assertEquals(ProductNameType.TRAITED_PRECOMMERCIAL, name.getType());

    name = namesMap.get(ProductNameType.MANUFACTURING);
    assertEquals("XXYYZZ", name.getName());
    assertEquals(product, name.getProduct());
    assertEquals(DataSource.SAP, name.getSource());
    assertEquals(ProductNameType.MANUFACTURING, name.getType());

    name = namesMap.get(ProductNameType.BASE_PRECOMMERCIAL);
    assertEquals("ABC123", name.getName());
    assertEquals(product, name.getProduct());
    assertEquals(DataSource.SAP, name.getSource());
    assertEquals(ProductNameType.BASE_PRECOMMERCIAL, name.getType());

    name = namesMap.get(ProductNameType.BASE_MANUFACTURING);
    assertEquals("XYZABC", name.getName());
    assertEquals(product, name.getProduct());
    assertEquals(DataSource.SAP, name.getSource());
    assertEquals(ProductNameType.BASE_MANUFACTURING, name.getType());
  }


  private Product createNewProduct() {
     String testTraitVersion = "1";
     Trait testTrait = new MockTrait(2L, "RR2", "RR2TEST", "TEST", null, true);
     String testBaseInbred = "12DK34";
     Product testFemaleParent = new ProductImpl();
     Product testMaleParent = new ProductImpl();
     Date testHandoffDate = new GregorianCalendar(2009, Calendar.JANUARY, 11).getTime();
     Date testPrimaryTestingDate = new GregorianCalendar(2009, Calendar.MARCH, 1).getTime();
     ProductImpl prod = new ProductImpl(0L, testTraitVersion, testTrait,
             testFemaleParent, testMaleParent, testHandoffDate, testPrimaryTestingDate, false, null, null, false);
     Map<ProductNameType, ProductName> names = new HashMap<ProductNameType, ProductName>();
     ProductName name = new ProductNameImpl(1L, "XYZ_123", prod, DataSource.PREFOUNDATION, "1", ProductNameType.TRAITED_PRECOMMERCIAL);
     names.put(name.getType(), name);
     name = new ProductNameImpl(2L, "XXYYZZ", prod, DataSource.SAP, "1", ProductNameType.MANUFACTURING);
     names.put(name.getType(), name);
     name = new ProductNameImpl(3L, "ABC123", prod, DataSource.SAP, "1", ProductNameType.BASE_PRECOMMERCIAL);
     names.put(name.getType(), name);
     name = new ProductNameImpl(4L, "XYZABC", prod, DataSource.SAP, "1", ProductNameType.BASE_MANUFACTURING);
     names.put(name.getType(), name);
     prod.setProductNames(names);
    return prod;
  }

  public void testEquals_IdsAreEqual_ReturnsTrue() throws Exception {
    Product product1 = new ProductImpl(1L, null, null, null, null, null, null, false, null, null, false);
    Product product2 = new ProductImpl(1L, null, null, null, null, null, null, false, null, null, false);
    assertTrue(product1.equals(product2));
  }

  public void testEquals_IdsAreNotEqual_ReturnsFalse() throws Exception {
    Product product1 = new ProductImpl(1L, null, null, null, null, null, null, false, null, null, false);
    Product product2 = new ProductImpl(2L, null, null, null, null, null, null, false, null, null, false);
    assertFalse(product1.equals(product2));
  }


  public void testCompareTo_SameProducts_ReturnsZero() throws Exception {
    Product product1 = new ProductImpl(1L, null, null, null, null, null, null, false, null, null, false);
    Product product2 = new ProductImpl(1L, null, null, null, null, null, null, false, null, null, false);
    assertTrue(product1.compareTo(product2) == 0);
  }

   public void testCompareTo_DifferentProducts_Returnsfalse() throws Exception {
    Product product1 = new ProductImpl(1L, null, null, null, null, null, null, false, null, null, false);
    Product product2 = new ProductImpl(2L, null, null, null, null, null, null, false, null, null, false);
    assertTrue(product1.compareTo(product2) < 0);
    assertTrue(product2.compareTo(product1) > 0);
  }

}