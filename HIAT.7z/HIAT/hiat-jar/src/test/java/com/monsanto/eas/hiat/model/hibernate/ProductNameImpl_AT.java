package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.ProductName;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.dao.GenericDAO;

import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ProductNameImpl_AT extends HIATDatabaseTestCase {
    public void testInitDAO() throws Exception {
        GenericDAO<ProductName, Long> dao = new TestInitService().initProductNameDAO();
        assertNotNull(dao);
    }

    public void testNegativeProductIdDoesntExist() throws Exception {
        GenericDAO<ProductName, Long> dao = new TestInitService().initProductNameDAO();
        long testId = TestUtils.getRandomLong();
        if (testId > 0) {
            testId = -testId;
        } else if (testId == 0) {
            testId = -1;
        }

        ProductName entry = dao.findByPrimaryKey(testId);
        assertNull(entry);
    }

    public void testFindByExample() throws Exception {
        GenericDAO<ProductName, Long> dao = new TestInitService().initProductNameDAO();
        String testName = "ABC123";
        ProductName example = new ProductNameImpl(0L, testName, null, null, null, null);
        String[] excludedProperties = {"product", "nameType", "source", "sourceId"};
        List<ProductName> entries = dao.findByExample(example, excludedProperties);
        assertNotNull(entries);
    }
}