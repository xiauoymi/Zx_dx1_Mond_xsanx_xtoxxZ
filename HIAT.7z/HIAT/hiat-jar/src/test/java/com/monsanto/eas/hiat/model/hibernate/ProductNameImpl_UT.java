package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.DataSource;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductName;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.util.HIATUnitTest;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ProductNameImpl_UT extends HIATUnitTest {
    public void testNewProductNameIsAllNulls() throws Exception {
        ProductName invEntry = new ProductNameImpl();
        assertNull(invEntry.getName());
        assertNull(invEntry.getProduct());
        assertNull(invEntry.getSource());
        assertNull(invEntry.getSourceId());
        assertNull(invEntry.getType());
    }

    public void testNewProductNameWithValuesHasValues() throws Exception {
        String testName = "TESTNAME";
        Product testProduct = new ProductImpl();
        DataSource testSource = DataSource.LEXICON;
        String testSourceId = "AAABBB111";
        ProductNameType testNameType = ProductNameType.BASE_PRECOMMERCIAL;
        ProductName invEntry = new ProductNameImpl(0L, testName, testProduct, testSource, testSourceId, testNameType);
        assertEquals(testName, invEntry.getName());
        assertEquals(testProduct, invEntry.getProduct());
        assertEquals(testSource, invEntry.getSource());
        assertEquals(testSourceId, invEntry.getSourceId());
        assertEquals(testNameType, invEntry.getType());
    }
}