package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.dao.GenericDAO;

import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ProductionEntryImpl_AT extends HIATDatabaseTestCase {
    public void testInitDAO() throws Exception {
        GenericDAO<ProductionEntry, Long> dao = new TestInitService().initProductionEntryDAO();
        assertNotNull(dao);
    }

    public void testNegativeProductIdDoesntExist() throws Exception {
        GenericDAO<ProductionEntry, Long> dao = new TestInitService().initProductionEntryDAO();
        long testId = TestUtils.getRandomLong();
        if (testId > 0) {
            testId = -testId;
        } else if (testId == 0) {
            testId = -1;
        }

        ProductionEntry entry = dao.findByPrimaryKey(testId);
        assertNull(entry);
    }

    public void testFindByExample() throws Exception {
        GenericDAO<ProductionEntry, Long> dao = new TestInitService().initProductionEntryDAO();
        Product testProduct = new ProductImpl();
        ProductionEntry example = new ProductionEntryImpl(null, testProduct, 0, null, false);
        String[] excludedProperties = {"availableDate", "quantity", "inventoryType"};
        List<ProductionEntry> entries = dao.findByExample(example, excludedProperties);
        assertNotNull(entries);
    }
}