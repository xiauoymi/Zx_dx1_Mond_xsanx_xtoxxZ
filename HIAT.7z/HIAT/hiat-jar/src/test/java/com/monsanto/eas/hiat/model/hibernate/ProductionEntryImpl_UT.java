package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;
import com.monsanto.eas.hiat.util.DateTestUtil;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ProductionEntryImpl_UT extends HIATUnitTest {
  public void testNewProductionEntryIsAllNulls() throws Exception {
    ProductionEntry invEntry = new ProductionEntryImpl();
    assertNull(invEntry.getAvailableDate());
    assertNull(invEntry.getProduct());
    assertNull(invEntry.getType());
    assertFalse(invEntry.isPlanned());
    assertEquals(0, invEntry.getQuantity());
  }

  public void testNewInventoryEntryWithValuesHasValues() throws Exception {
    Date testDate = new Date();
    Product testProduct = new ProductImpl();
    long testQuantity = 123L;
    InventoryType testInventoryType = InventoryType.GENERATION_1;
    ProductionEntry invEntry = new ProductionEntryImpl(testDate, testProduct, testQuantity, testInventoryType, true);
    DateTestUtil.assertDatesEqual(testDate, invEntry.getAvailableDate());
    assertEquals(testProduct, invEntry.getProduct());
    assertEquals(testQuantity, invEntry.getQuantity());
    assertEquals(testInventoryType, invEntry.getType());
    assertTrue(invEntry.isPlanned());
  }

  public void testFormattingInventoryQuantity_ThousandsSeperated() throws Exception {
    Date testDate = new Date();
    Product testProduct = new ProductImpl();
    long testQuantity = 123456789;
    InventoryType testInventoryType = InventoryType.GENERATION_1;
    ProductionEntry invEntry = new ProductionEntryImpl(testDate, testProduct, testQuantity, testInventoryType, false);
    DateTestUtil.assertDatesEqual(testDate, invEntry.getAvailableDate());
    assertEquals(testProduct, invEntry.getProduct());
    assertEquals(testQuantity, invEntry.getQuantity());
    assertEquals(testInventoryType, invEntry.getType());
    assertEquals("123,456,789", invEntry.getFormattedQuantity());
  }
}