package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.dao.GenericDAO;

import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class TraitImpl_AT extends HIATDatabaseTestCase {
    public void testInitDAO() throws Exception {
        GenericDAO<Trait, Long> dao = new TestInitService().initTraitDAO();
        assertNotNull(dao);
    }

    public void testNegativeProductIdDoesntExist() throws Exception {
        GenericDAO<Trait, Long> dao = new TestInitService().initTraitDAO();
        long testId = TestUtils.getRandomLong();
        if (testId > 0) {
            testId = -testId;
        } else if (testId == 0) {
            testId = -1;
        }

        Trait trait = dao.findByPrimaryKey(testId);
        assertNull(trait);
    }

    public void testReadTraits() throws Exception {
        GenericDAO<Trait, Long> dao = new TestInitService().initTraitDAO();
        List<Trait> traits = dao.findAll();
        assertNotNull(traits);
        assertFalse(traits.isEmpty());
    }
}