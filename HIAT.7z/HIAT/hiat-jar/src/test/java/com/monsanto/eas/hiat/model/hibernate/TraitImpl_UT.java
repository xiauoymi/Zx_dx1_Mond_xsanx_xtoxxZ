package com.monsanto.eas.hiat.model.hibernate;

import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.Set;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class TraitImpl_UT extends HIATUnitTest {
    public void testNewProductIsNullOrEmpty() throws Exception {
        Trait trait = new TraitImpl();
        assertNull(trait.getCode());
        assertNull(trait.getCommercialName());
        assertNull(trait.getFullName());
        Set<Trait> parents = trait.getParentTraits();
        assertNotNull(parents);
        assertTrue(parents.isEmpty());
    }

  public void testEquals_IdsAreEqual_ReturnsTrue() throws Exception {
    Trait trait1 = new TraitImpl(1L);
    Trait trait2 = new TraitImpl(1L);
    assertTrue(trait1.equals(trait2));
  }

  public void testEquals_IdsAreNotEqual_ReturnsFalse() throws Exception {
    Trait trait1 = new TraitImpl(1L);
    Trait trait2 = new TraitImpl(2L);
    assertFalse(trait1.equals(trait2));
  }

  public void testDifferentTraits_SameCodes() throws Exception {
    Trait trait1 = new TraitImpl(1L, "ABC", null, null, null, true);
    Trait trait2 = new TraitImpl(2L, "ABC", null, null, null, true);
    assertTrue(!trait1.equals(trait2)) ;
    assertEquals(0, trait1.compareTo(trait2)) ;
  }

  public void testSameTraits_SameCodes() throws Exception {
    Trait trait1 = new TraitImpl(1L, "ABC", null, null, null, true);
    Trait trait2 = new TraitImpl(1L, "ABC", null, null, null, true);
    assertTrue(trait1.equals(trait2)) ;
    assertEquals(0, trait1.compareTo(trait2)) ;
  }

  public void testCompareTraits_CodeIsDifferent() throws Exception {
    Trait trait1 = new TraitImpl(1L, "ABC", null, null, null, true);
    Trait trait2 = new TraitImpl(2L, "DEF", null, null, null, true);
    assertTrue(trait1.compareTo(trait2) < 0) ;
    assertTrue(trait2.compareTo(trait1) > 0) ;
  }
}