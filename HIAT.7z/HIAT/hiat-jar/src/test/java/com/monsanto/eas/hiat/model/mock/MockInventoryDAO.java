package com.monsanto.eas.hiat.model.mock;

import com.monsanto.eas.hiat.dao.InventoryDAO;
import com.monsanto.eas.hiat.model.InventoryEntry;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.wst.hibernate.mock.MockDAO;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockInventoryDAO extends MockDAO<InventoryEntry, Long> implements InventoryDAO {
  private List<InventoryEntry> inventoryList;

  public MockInventoryDAO() {
        super(new ArrayList<InventoryEntry>());
    }

    public MockInventoryDAO(List<InventoryEntry> inventory) {
        super(inventory);
      this.inventoryList = inventory;
    }

    public List<InventoryEntry> findByProduct(Product product) {
//        List<InventoryEntry> productEntries = new ArrayList<InventoryEntry>();
//        for (InventoryEntry entry : findAll()) {
//            if (entry.getProduct().equals(product)) {
//                productEntries.add(entry);
//            }
//        }
//
//        return productEntries;
      return inventoryList;
    }

    public long getInventory(Product product, InventoryType invType) {
        long quantityOnHand = 0L;
        for (InventoryEntry entry : findAll()) {
            if (entry.getProduct().equals(product) && entry.getType().equals(invType)) {
                quantityOnHand += entry.getQuantity();
            }
        }

        return quantityOnHand;
    }
}

