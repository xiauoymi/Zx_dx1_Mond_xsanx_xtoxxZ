package com.monsanto.eas.hiat.model.mock;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockPreFoundationDAO {
    private final Date harvestDate;
    private final Date plantingDate;

    public MockPreFoundationDAO(Date harvestDate, Date plantingDate) {
        this.harvestDate = harvestDate;
        this.plantingDate = plantingDate;
    }

}
