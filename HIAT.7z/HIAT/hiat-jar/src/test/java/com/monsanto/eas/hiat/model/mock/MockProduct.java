/*
 MockProduct was created on Mar 16, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.model.mock;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductName;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.Trait;

import java.util.Date;
import java.util.Map;

/**
 * MockProduct.java
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class MockProduct implements Product {
  private Long id;
  private String traitVersion;
  private Trait trait;
  private Product femaleParent;
  private Product maleParent;
  private Date handoffDate;
  private Date primaryTestingDate;
  private boolean isPrimary;
  private Product base;
  private String status;
  private boolean isHybrid;

  public MockProduct(Long id) {
    this(id, null, null, null, null, null, null, false, null, null, false);
  }

  public MockProduct(Long id, String traitVersion, Trait trait, Product femaleParent, Product maleParent, Date handoffDate, Date primaryTestingDate, boolean isPrimary, Product base, String status, boolean isHybrid) {
    this.id = id;
    this.traitVersion = traitVersion;
    this.trait = trait;
    this.femaleParent = femaleParent;
    this.maleParent = maleParent;
    this.handoffDate = handoffDate;
    this.primaryTestingDate = primaryTestingDate;
    this.isPrimary = isPrimary;
    this.base = base;
    this.status = status;
    this.isHybrid = isHybrid;
  }

  public Long getId() {
    return id;
  }

  public String getTraitVersion() {
    return traitVersion;
  }

  public Trait getTrait() {
    return trait;
  }

  public Product getFemaleParent() {
    return femaleParent;
  }

  public Product getMaleParent() {
    return maleParent;
  }

  public Date getHandoffDate() {
    return handoffDate;
  }

  public Date getPrimaryTestingDate() {
    return primaryTestingDate;
  }

  public boolean isPrimary() {
    return isPrimary;
  }

  public Map<ProductNameType, ProductName> getProductNames() {
    return null;
  }

  public String getProductName(ProductNameType nameType) {
    return "MOCK-" + id;
  }

  public void setProductNames(Map<ProductNameType, ProductName> productNames) {
  }

  public Product getBase() {
    if (base == null){
      return this;
    }
    return base;
  }

  public String getStatus() {
    return status;
  }

  public boolean isHybrid() {
    return isHybrid;
  }

  public int compareTo(Object o) {
    return 0;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof Product)) return false;

    Product product = (Product) o;

    return id.equals(product.getId());

  }

  @Override
  public int hashCode() {
    return (int) (id ^ (id >>> 32));
  }

  public String toString() {
    return "MOCKPRODUCT-" + id;
  }
}