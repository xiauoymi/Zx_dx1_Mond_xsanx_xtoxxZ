package com.monsanto.eas.hiat.model.mock;

import com.monsanto.eas.hiat.dao.ProductionDAO;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;
import com.monsanto.wst.hibernate.mock.MockDAO;

import java.util.ArrayList;
import java.util.List;

public class MockProductionDAO extends MockDAO<ProductionEntry, Long> implements ProductionDAO {
  private List<ProductionEntry> productionInventory;

  public MockProductionDAO() {
        super(new ArrayList<ProductionEntry>());
    }

    public MockProductionDAO(List<ProductionEntry> inventory) {
        super(inventory);
      this.productionInventory = inventory;
    }

    public List<ProductionEntry> findByProduct(Product product) {
      return productionInventory;
    }

    public long getProduction(Product product, InventoryType invType) {
        long quantityOnHand = 0L;
        for (ProductionEntry entry : findAll()) {
            if (entry.getProduct().equals(product) && entry.getType().equals(invType) && !entry.isPlanned()) {
                quantityOnHand += entry.getQuantity();
            }
        }

        return quantityOnHand;
    }

    public long getPlannedProduction(Product product, InventoryType invType) {
        long quantityOnHand = 0L;
        for (ProductionEntry entry : findAll()) {
            if (entry.getProduct().equals(product) && entry.getType().equals(invType) && entry.isPlanned()) {
                quantityOnHand += entry.getQuantity();
            }
        }

        return quantityOnHand;
    }
}
