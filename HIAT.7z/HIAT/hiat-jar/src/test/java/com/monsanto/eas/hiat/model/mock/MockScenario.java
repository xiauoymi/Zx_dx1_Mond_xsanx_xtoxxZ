/*
 MockScenario was created on Mar 26, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.model.mock;

import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.scenario.ScenarioDetail;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.util.Collection;
import java.util.Date;
import java.util.Set;

/**
 * Filename:    $RCSfile: MockScenario.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-04-14 19:14:58 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class MockScenario implements Scenario {
  private Long id;
  private String name;
  private String username;
  private String description;
  private Date saveDate;
  private String products;
  private Set<Trait> traits;
  private Set<ScenarioDetail> details;
  private boolean outOfDate;

  public MockScenario() {
  }

  public MockScenario(String name, String username) {
    this.name = name;
    this.username = username;
  }

  public MockScenario(Long id, String username, String name, String description, Date saveDate,
                      boolean outOfDate, String products, Set<Trait> traits, Set<ScenarioDetail> details) {
    this.id = id;
    this.name = name;
    this.username = username;
    this.description = description;
    this.saveDate = saveDate;
    this.products = products;
    this.traits = traits;
    this.details = details;
    this.outOfDate = outOfDate;
  }
  public Long getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public String getUsername() {
    return username;
  }

  public String getDescription() {
    return description;
  }

  public Date getSaveDate() {
    return saveDate;
  }

  public String getProducts() {
    return products;
  }

  public void setDetails(Set<ScenarioDetail> details) {
  }

  public Collection<HybridAnalysis> getHybridAnalysis() {
    return null;
  }

  public Set<Trait> getTraits() {
    return traits;
  }

  public Set<ScenarioDetail> getDetails() {
    return details;
  }

  public void setDeleted(boolean deleted) {
  }

  public boolean isDeleted() {
    return false;
  }

  public boolean isOutOfDate() {
    return outOfDate;
  }

  public boolean equals(Object o) {
    if (!(o instanceof Scenario)) return false;
    Scenario scenario = (Scenario) o;

    return new EqualsBuilder().append(name, scenario.getName())
        .append(username, scenario.getUsername())
        .isEquals();
  }

  public int hashCode() {
    return HashCodeBuilder.reflectionHashCode(this);
  }

}