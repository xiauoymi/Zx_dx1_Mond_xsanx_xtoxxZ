package com.monsanto.eas.hiat.model.mock;

import com.monsanto.eas.hiat.model.Trait;

import java.util.Collections;
import java.util.Set;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class MockTrait implements Trait {
    private final Long id;
    private final String code;
    private final String fullName;
    private final String commercialName;
    private final Set<Trait> parentTraits;
    private boolean isActive;

    public MockTrait(Long id) {
        this(id, "MOCK", "MOCK", "MOCK", null, true);
    }
    
    public MockTrait(String code) {
        this(0L, code, "MOCK:" + code, "MOCK_COMMERCIAL:" + code, null, true);
    }

    public MockTrait(Long id, String code, String fullName, String commercialName, Set<Trait> parentTraits, boolean isActive) {
        this.id = id;
        this.code = code;
        this.fullName = fullName;
        this.commercialName = commercialName;
        if (parentTraits == null) {
            this.parentTraits = Collections.emptySet();
        } else {
            this.parentTraits = parentTraits;
        }
        this.isActive = isActive;
    }

    public Long getId() {
      return id;
    }

    public String getCode() {
        return code;
    }

    public String getFullName() {
        return fullName;
    }

    public String getCommercialName() {
        return commercialName;
    }

    public boolean getActive() {
        return isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    public Set<Trait> getParentTraits() {
        return parentTraits;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Trait)) {
            return false;
        }

        Trait trait = (Trait) obj;
        return this.getId().equals(trait.getId());
    }

    @Override
    public int hashCode() {
        return id.intValue();
    }

  public int compareTo(Object o) {
    return this.getCode().compareTo(((Trait)o).getCode());
  }

  @Override
  public String toString() {
    return "MOCKTRAIT-" + id;
  }
}
