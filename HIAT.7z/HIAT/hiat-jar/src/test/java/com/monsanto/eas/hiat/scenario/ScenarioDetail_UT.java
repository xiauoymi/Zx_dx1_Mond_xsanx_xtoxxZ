/*
 ScenarioDetail_UT was created on Mar 31, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.scenario;

import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisImpl;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockScenario;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioDetailImpl;
import com.monsanto.eas.hiat.util.HIATUnitTest;

/**
 * Filename:    $RCSfile: ScenarioDetail_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2009-04-14 19:14:58 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class ScenarioDetail_UT extends HIATUnitTest {
  public void testEquals_ReturnsTrue() throws Exception {
    ScenarioDetail detail1 = new ScenarioDetailImpl(new MockScenario("name 1", "testId"), new HybridAnalysisImpl(new MockProduct(1L), new MockTrait(2L), null));
    ScenarioDetail detail2 = new ScenarioDetailImpl(new MockScenario("name 1", "testId"), new HybridAnalysisImpl(new MockProduct(1L), new MockTrait(2L), null));
    assertTrue(detail1.equals(detail2));
  }

  public void testEquals_ScenarioDontMatch_ReturnsFalse() throws Exception {
    ScenarioDetail detail1 = new ScenarioDetailImpl(new MockScenario("name 2", "testId"), new HybridAnalysisImpl(new MockProduct(1L), new MockTrait(2L), null));
    ScenarioDetail detail2 = new ScenarioDetailImpl(new MockScenario("name 1", "testId"), new HybridAnalysisImpl(new MockProduct(1L), new MockTrait(2L), null));
    assertFalse(detail1.equals(detail2));
  }
  
  public void testEquals_AnalysisDontMatch_ReturnsFalse() throws Exception {
    ScenarioDetail detail1 = new ScenarioDetailImpl(new MockScenario("name 1", "testId"), new HybridAnalysisImpl(new MockProduct(1L), new MockTrait(2L), null));
    ScenarioDetail detail2 = new ScenarioDetailImpl(new MockScenario("name 1", "testId"), new HybridAnalysisImpl(new MockProduct(2L), new MockTrait(2L), null));
    assertFalse(detail1.equals(detail2));
  }
}