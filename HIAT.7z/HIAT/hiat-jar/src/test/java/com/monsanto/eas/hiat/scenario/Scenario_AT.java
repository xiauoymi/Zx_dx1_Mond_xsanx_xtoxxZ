package com.monsanto.eas.hiat.scenario;

import com.monsanto.eas.hiat.model.hibernate.HIATDatabaseTestCase;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioImpl;
import com.monsanto.eas.hiat.service.TestInitService;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.dao.GenericDAO;

import java.util.Date;
import java.util.HashSet;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class Scenario_AT extends HIATDatabaseTestCase {
    public void testInitDAO() throws Exception {
        GenericDAO<Scenario, Long> dao = new TestInitService().initScenarioDAO();
        assertNotNull(dao);
    }

    public void testNegativeIdDoesntExist() throws Exception {
        GenericDAO<Scenario, Long> dao = new TestInitService().initScenarioDAO();
        long testId = TestUtils.getRandomLong();
        if (testId > 0) {
            testId = -testId;
        } else if (testId == 0) {
            testId = -1;
        }

        Scenario scenario = dao.findByPrimaryKey(testId);
        assertNull(scenario);
    }

    public void testAddATraitAndThenFindItAndRemoveIt() throws Exception {
        GenericDAO<Scenario, Long> dao = new TestInitService().initScenarioDAO();
        Scenario addedScenario = new ScenarioImpl(null, "TEST", "TEST", null, new Date(), false, null, null, new HashSet<ScenarioDetail>()
        );
        dao.save(addedScenario);
        long testId = addedScenario.getId();
        try {
            assertNotNull(dao.findByPrimaryKey(testId));
        } finally {
            dao.delete(addedScenario);
        }

        assertNull(dao.findByPrimaryKey(testId));
    }
}