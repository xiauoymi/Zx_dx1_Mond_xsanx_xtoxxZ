package com.monsanto.eas.hiat.scenario;

import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisImpl;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockScenario;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioDetailImpl;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioImpl;
import com.monsanto.eas.hiat.util.DateTestUtil;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class Scenario_UT extends HIATUnitTest {
  public void testNewScenarioIsNullOrEmpty() throws Exception {
    Scenario scenario = new ScenarioImpl();
    assertNull(scenario.getId());
    assertEquals("", scenario.getName());
    assertEquals("", scenario.getUsername());
    assertNotNull(scenario.getSaveDate());
    assertFalse(scenario.isOutOfDate());
    Collection<ScenarioDetail> details = scenario.getDetails();
    assertNotNull(details);
    assertTrue(details.isEmpty());
    assertEquals(scenario.hashCode(), scenario.hashCode());
  }

  public void testNewScenarioWithValuesHasValues() throws Exception {
    String testUsername = "some name";
    String testName = "SomeTest";
    Date testDate = new Date();
    ScenarioDetail testScenarioDetail1 = new ScenarioDetailImpl();
    ScenarioDetail testScenarioDetail2 = new ScenarioDetailImpl();
    Set<ScenarioDetail> testDetails = new HashSet<ScenarioDetail>();
    testDetails.add(testScenarioDetail1);
    testDetails.add(testScenarioDetail2);
    Scenario scenario = new ScenarioImpl(null, testUsername, testName, null, testDate, true, null, null, testDetails);
    assertEquals(testUsername, scenario.getUsername());
    assertEquals(testName, scenario.getName());
    DateTestUtil.assertDatesEqual(testDate, scenario.getSaveDate());
    assertTrue(scenario.isOutOfDate());
    Collection<ScenarioDetail> details = scenario.getDetails();
    assertEquals(testDetails.size(), details.size());
    assertTrue(details.contains(testScenarioDetail1));
    assertTrue(details.contains(testScenarioDetail2));
  }

  public void testEquals_NameAndUserNameAreEqual_ReturnsTrue() throws Exception {
    Scenario scenario1 = new ScenarioImpl(null, "testId", "name 1", null, null, true, null, null, null);
    Scenario scenario2 = new ScenarioImpl(null, "testId", "name 1", null, null, true, null, null, null);
    assertTrue(scenario1.equals(scenario2));
  }

  public void testEquals_NamesDontMatch_ReturnsFalse() throws Exception {
    Scenario scenario1 = new ScenarioImpl(null, "testId", "name 1", null, null, true, null, null, null);
    Scenario scenario2 = new ScenarioImpl(null, "testId", "name 2", null, null, true, null, null, null);
    assertFalse(scenario1.equals(scenario2));
  }

  public void testEquals_UsersDontMatch_ReturnsFalse() throws Exception {
    Scenario scenario1 = new ScenarioImpl(null, "testId", "name 1", null, null, true, null, null, null);
    Scenario scenario2 = new ScenarioImpl(null, "testId1", "name 1", null, null, true, null, null, null);
    assertFalse(scenario1.equals(scenario2));
  }

  public void testGetHybridAnalysis_NoDetails_ReturnsEmptyList() throws Exception {
    Scenario scenario = new ScenarioImpl(1L, null, null, null, null, true, null, null, new HashSet<ScenarioDetail>());
    assertTrue(scenario.getHybridAnalysis().isEmpty());
  }

  public void testGetHybridAnalysis_2Details_Returns2() throws Exception {
    Set<ScenarioDetail> details = new HashSet<ScenarioDetail>();
    details.add(new ScenarioDetailImpl(new MockScenario("name 1", "testId"), new HybridAnalysisImpl(new MockProduct(1L), new MockTrait(2L), null)));
    details.add(new ScenarioDetailImpl(new MockScenario("name 1", "testId"), new HybridAnalysisImpl(new MockProduct(3L), new MockTrait(2L), null)));
    Scenario scenario = new ScenarioImpl(1L, null, null, null, null, true, null, null, details);
    assertEquals(2, scenario.getHybridAnalysis().size());
  }
}