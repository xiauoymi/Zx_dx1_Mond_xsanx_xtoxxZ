package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.availability.AvailDateTestUtil;
import com.monsanto.eas.hiat.availability.MockInventoryService;
import com.monsanto.eas.hiat.availability.MockProductionService;
import com.monsanto.eas.hiat.model.InventoryType;
import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.ProductionEntry;
import com.monsanto.eas.hiat.model.hibernate.ProductionEntryImpl;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.util.DateTestUtil;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class AvailabilityServiceImpl_UT extends HIATUnitTest {
  public void testHasSufficientInventoryOnHandReturnToday() throws Exception {
    Product testProduct = new MockProduct(1L);
    InventoryType testInvType = InventoryType.GENERATION_1;
    long testQty = 123L;
    InventoryService invService = new MockInventoryService(testQty * 5);
    ProductionService prodService = new MockProductionService();
    AvailabilityService availService = new AvailabilityServiceImpl(invService, prodService);
    Date availDate = availService.getInventoryAvailabilityDate(testProduct, testInvType, testQty);
    assertNotNull(availDate);
    DateTestUtil.assertDatesEqual(new Date(), availDate);
  }

  public void testHasSomeInventoryRestWithAnOrder() throws Exception {
    Date testOrderDate = AvailDateTestUtil.randomFutureDate();
    Date laterTestOrderDate = org.apache.commons.lang.time.DateUtils.addDays(testOrderDate, 100);
    Date evenLaterTestOrderDate = org.apache.commons.lang.time.DateUtils.addDays(laterTestOrderDate, 100);
    Product testProduct = new MockProduct(1L);
    InventoryType testInvType = InventoryType.GENERATION_1;
    long testQty = 123L;
    InventoryService invService = new MockInventoryService(testQty - 5);
    Collection<ProductionEntry> production = new ArrayList<ProductionEntry>();
    production.add(new ProductionEntryImpl(testOrderDate, testProduct, 10, testInvType, false));
    production.add(new ProductionEntryImpl(laterTestOrderDate, testProduct, 10, testInvType, false));
    production.add(new ProductionEntryImpl(evenLaterTestOrderDate, testProduct, 10, testInvType, false));
    ProductionService prodService = new MockProductionService(production);
    AvailabilityService availService = new AvailabilityServiceImpl(invService, prodService);
    Date availDate = availService.getInventoryAvailabilityDate(testProduct, testInvType, testQty);
    assertNotNull(availDate);
    DateTestUtil.assertDatesEqual(testOrderDate, availDate);
  }

  public void testHasSomeInventoryRestWithMultipleOrders() throws Exception {
    Date testOrderDate = AvailDateTestUtil.randomFutureDate();
    Date laterTestOrderDate = org.apache.commons.lang.time.DateUtils.addDays(testOrderDate, 100);
    Date evenLaterTestOrderDate = org.apache.commons.lang.time.DateUtils.addDays(laterTestOrderDate, 100);
    Product testProduct = new MockProduct(1L);
    InventoryType testInvType = InventoryType.GENERATION_1;
    long testQty = 123L;
    InventoryService invService = new MockInventoryService(testQty - 5);
    Collection<ProductionEntry> production = new ArrayList<ProductionEntry>();
    production.add(new ProductionEntryImpl(testOrderDate, testProduct, 3, testInvType, false));
    production.add(new ProductionEntryImpl(laterTestOrderDate, testProduct, 3, testInvType, false));
    production.add(new ProductionEntryImpl(evenLaterTestOrderDate, testProduct, 3, testInvType, false));
    ProductionService prodService = new MockProductionService(production);
    AvailabilityService availService = new AvailabilityServiceImpl(invService, prodService);
    Date availDate = availService.getInventoryAvailabilityDate(testProduct, testInvType, testQty);
    assertNotNull(availDate);
    DateTestUtil.assertDatesEqual(laterTestOrderDate, availDate);
  }

  public void testNotEnoughInvOrOrdersNoAvailDate() throws Exception {
    Product testProduct = new MockProduct(1L);
    InventoryType testInvType = InventoryType.GENERATION_1;
    long testQty = 123L;
    InventoryService invService = new MockInventoryService(testQty - 10);
    ProductionService prodService = new MockProductionService();
    AvailabilityService availService = new AvailabilityServiceImpl(invService, prodService);
    Date availDate = availService.getInventoryAvailabilityDate(testProduct, testInvType, testQty);
    assertNull(availDate);
  }
}