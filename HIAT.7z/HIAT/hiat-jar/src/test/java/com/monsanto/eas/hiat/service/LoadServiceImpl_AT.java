package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.model.hibernate.HIATDatabaseTestCase;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class LoadServiceImpl_AT extends HIATDatabaseTestCase {
  public void testLoadServiceReturnsLastLoadDate() throws Exception {
    LoadService loadService = new TestInitService().initLoadService();
    Date lastLoadDate = loadService.getLastLoadDate();
    assertNotNull(lastLoadDate);
  }
}