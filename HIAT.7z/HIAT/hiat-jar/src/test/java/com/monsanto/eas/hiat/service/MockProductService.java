package com.monsanto.eas.hiat.service;

import com.monsanto.eas.hiat.model.Product;
import com.monsanto.eas.hiat.model.Trait;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class MockProductService implements ProductService {
  private Collection<Product> products = new ArrayList<Product>();
  private Map<Product, Map<Trait, Collection<Product>>> productsByBaseAndTrait = new HashMap<Product, Map<Trait, Collection<Product>>>();

  public void add(Product product) {
    products.add(product);
  }

  public void addMapping(Product base, Trait trait, Product traitedProduct) {
    Collection<Product> traitedProductCollection = getTraitedProductCollection(base, trait);
    traitedProductCollection.add(traitedProduct);
  }

  private Collection<Product> getTraitedProductCollection(Product base, Trait trait) {
    Map<Trait, Collection<Product>> traitMap = getTraitMap(base);
    return getTraitedProductCollectionFromMap(traitMap, trait);
  }

  private Collection<Product> getTraitedProductCollectionFromMap(Map<Trait, Collection<Product>> traitMap, Trait trait) {
    Collection<Product> traitedProductCollection = traitMap.get(trait);
    if (traitedProductCollection == null) {
      Collection<Product> newCollection = new ArrayList<Product>();
      traitMap.put(trait, newCollection);
      return newCollection;
    } else {
      return traitedProductCollection;
    }
  }

  private Map<Trait, Collection<Product>> getTraitMap(Product base) {
    Map<Trait, Collection<Product>> traitMap = productsByBaseAndTrait.get(base);
    if (traitMap == null) {
      Map<Trait, Collection<Product>> newTraitMap = new HashMap<Trait, Collection<Product>>();
      productsByBaseAndTrait.put(base, newTraitMap);
      return newTraitMap;
    } else {
      return traitMap;
    }
  }

  public ProductSearchResults lookupProductMatchingInputCriteria(String productNamesEntered, boolean isHybrid) {
    throw new RuntimeException("this method not yet implemented in the mock");
  }

  public Collection<Product> getUniqueBaseProducts(Collection<Product> products) {
    Collection<Product> bases = new HashSet<Product>();
    for (Product product : products) {
      bases.add(product.getBase());
    }
    return bases;
  }

  public Product lookupProductById(Long id) {
    for (Product product : products) {
      if (product.getId().equals(id)) {
        return product;
      }
    }

    return null;
  }

  public Collection<Product> getProductByBaseAndTrait(Product baseProduct, Trait trait) {
    return getTraitedProductCollection(baseProduct, trait);
  }
}
