/*
 ProductServiceImpl_UT was created on Mar 2, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.service.mock;

import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.hibernate.ProductNameImpl;
import com.monsanto.eas.hiat.model.hibernate.TraitImpl;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.service.ProductSearchResults;
import com.monsanto.eas.hiat.service.ProductService;
import com.monsanto.eas.hiat.service.ProductServiceImpl;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.mock.MockDAO;
import org.hibernate.criterion.Criterion;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;

import java.util.*;

/**
 * Filename:    $RCSfile: ProductServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-04-15 15:10:00 $
 *
 * @author rrmall
 * @version $Revision: 1.18 $
 */
public class ProductServiceImpl_UT extends HIATUnitTest {
  public void testProductThatDoesNotExistIsRecordedAsFailure() throws Exception {
    MockDAO<Product, Long> baseDao = new MockDAO<Product, Long>(getProductSetMatchingCriteria("DKC*"));
    ProductService service = new ProductServiceImpl(baseDao);
    String testProductThatDoesntExist = "QQQQWWWWEERRTTYY";
    ProductSearchResults results = service.lookupProductMatchingInputCriteria(testProductThatDoesntExist, false);
    Collection<String> failures = results.getFailures();
    assertNotNull(failures);
    assertEquals(1, failures.size());
    assertTrue(failures.contains(testProductThatDoesntExist));
  }

  public void testLookupProductMatchingInputCriteriaForInbredSearch_CriteriaMatchesName_ListReturned() {
    MockDAO<Product, Long> baseDao = new MockDAO<Product, Long>(getProductSetMatchingCriteria("DKC*"));
    ProductService service = new ProductServiceImpl(baseDao);
    Collection<Product> productSet = service.lookupProductMatchingInputCriteria("DKC*", false).getResults();
    for (Product product : productSet) {
      Map<ProductNameType, ProductName> productNames = product.getProductNames();
      Set<ProductNameType> keys = productNames.keySet();
      for (ProductNameType nameType : keys)
        assertTrue(productNames.get(nameType).getName().contains("DKC"));
    }
    MockCriteria criteria = baseDao.getMockCriteria();
    assertTrue(criteria.wasListCalled());
    assertEquals(2, criteria.getCriteria().size());
    Criterion criterion = criteria.getCriteria().get(1);
    assertEquals("isHybrid=false", criterion.toString());
  }

  public void testLookupProductMatchingInputCriteriaForInbredSearch_NameDoesNotMatchCriteria_EmptyListReturned() {
    MockDAO<Product, Long> baseDao = new MockDAO<Product, Long>(getProductSetMatchingCriteria("ABC123"));
    ProductService service = new ProductServiceImpl(baseDao);
    Collection<Product> productSet = service.lookupProductMatchingInputCriteria("ABC123", true).getResults();
    assertEquals(0, productSet.size());
  }

  public void testLookupProductMatchingInputCriteriaMoreThanOneNameEnteredForInbredSearch_CriteriaMatchesName_ListReturned() {
    MockDAO<Product, Long> baseDao = new MockDAO<Product, Long>(getProductSetMatchingCriteria("DKC*\nNE5112_v1"));
    ProductService service = new ProductServiceImpl(baseDao);
    Collection<Product> productSet = service.lookupProductMatchingInputCriteria("DKC*\nNE5112_v1", false).getResults();
    for (Product product : productSet) {
      Map<ProductNameType, ProductName> productNames = product.getProductNames();
      Set<ProductNameType> keys = productNames.keySet();
      for (ProductNameType nameType : keys) {
        assertTrue(productNames.get(nameType).getName().contains("DKC") || productNames.get(nameType).getName().contains("NE5112_v1"));
      }
    }

    MockCriteria criteria = baseDao.getMockCriteria();
    assertTrue(criteria.wasListCalled());
    assertEquals(4, criteria.getCriteria().size());
  }


  public void testLookupProductMatchingInputCriteriaForHybridSearch_CriteriaMatchesName_ListReturned() {
    MockDAO<Product, Long> baseDao = new MockDAO<Product, Long>(getProductSetMatchingCriteriaForHybrid("DKC*"));
    ProductService service = new ProductServiceImpl(baseDao);
    Collection<Product> productSet = service.lookupProductMatchingInputCriteria("DKC*", true).getResults();
    for (Product product : productSet) {
      Map<ProductNameType, ProductName> productNames = product.getProductNames();
      Set<ProductNameType> keys = productNames.keySet();
      for (ProductNameType nameType : keys) {
        assertTrue(productNames.get(nameType).getName().contains("DKC"));
      }
    }

    MockCriteria criteria = baseDao.getMockCriteria();
    assertTrue(criteria.wasListCalled());
    assertEquals(2, criteria.getCriteria().size());
    Criterion criterion = criteria.getCriteria().get(1);
    assertEquals("isHybrid=true", criterion.toString());
  }


  private List<Product> getProductSetMatchingCriteria(String criteria) {
    if (criteria.equalsIgnoreCase("DKC*")) {
      Set<Product> productSet = new HashSet<Product>();
      ProductImpl product = new ProductImpl(1L, "DKC 12", new MockTrait("XYZ"), null, null, null, null, false, null,
              null, false);
      productSet.add(product);
      Map<ProductNameType, ProductName> productNames = new HashMap<ProductNameType, ProductName>();
      productNames.put(ProductNameType.BASE_MANUFACTURING, new ProductNameImpl(31L, "DKC123", product, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING));
      productNames.put(ProductNameType.MANUFACTURING, new ProductNameImpl(32L, "DKC456", product, DataSource.PREFOUNDATION, "3", ProductNameType.MANUFACTURING));
      product.setProductNames(productNames);
      return new ArrayList<Product>(productSet);
    } else if (criteria.equalsIgnoreCase("DKC*\bNE5112_v1")) {
      Set<Product> productSet = new HashSet<Product>();
      ProductImpl product = new ProductImpl(1L, "DKC 12", new MockTrait("XYZ"), null, null, null, null, false, null,
              null, false);
      productSet.add(product);
      Map<ProductNameType, ProductName> productNames = new HashMap<ProductNameType, ProductName>();
      productNames.put(ProductNameType.BASE_MANUFACTURING, new ProductNameImpl(31L, "DKC123", product, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING));
      productNames.put(ProductNameType.MANUFACTURING, new ProductNameImpl(32L, "DKC456", product, DataSource.PREFOUNDATION, "3", ProductNameType.MANUFACTURING));
      product.setProductNames(productNames);
      product = new ProductImpl(1L, "NE5112_v1", new MockTrait("NE5112"), null, null, null, null, false, null, null, false);
      productSet.add(product);
      productNames.put(ProductNameType.BASE_MANUFACTURING, new ProductNameImpl(33L, "NE5112_v1", product, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING));
      product.setProductNames(productNames);
      return new ArrayList<Product>(productSet);
    } else {
      return new ArrayList<Product>();
    }
  }


  private List<Product> getProductSetMatchingCriteriaForHybrid(String criteria) {
    if (criteria.equalsIgnoreCase("DKC*")) {
      Set<Product> productSet = new HashSet<Product>();
      ProductImpl base = new ProductImpl(2L, "BASE", null, null, null, null, null, true, null, "active", false);
      ProductImpl female = new ProductImpl(3L, "ABC123", new MockTrait("ABC"), null, null, null, null, true, base, "active", true);
      ProductImpl male = new ProductImpl(4L, "DEF456", new MockTrait("DEF"), null, null, null, null, true, base, "active", true);
      ProductImpl product = new ProductImpl(1L, "DKC-12-34", new MockTrait("XYZ"), female, male, null, null, false, null,
              null, false);
      productSet.add(product);
      Map<ProductNameType, ProductName> productNames = new HashMap<ProductNameType, ProductName>();
      productNames.put(ProductNameType.BASE_MANUFACTURING, new ProductNameImpl(31L, "DKC123", product, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING));
      productNames.put(ProductNameType.MANUFACTURING, new ProductNameImpl(32L, "DKC456", product, DataSource.PREFOUNDATION, "3", ProductNameType.MANUFACTURING));
      product.setProductNames(productNames);
      return new ArrayList<Product>(productSet);
    } else if (criteria.equalsIgnoreCase("DKC*\bNE5112_v1")) {
      Set<Product> productSet = new HashSet<Product>();
      ProductImpl product = new ProductImpl(1L, "DKC 12", new MockTrait("XYZ"), null, null, null, null, false, null,
              null, false);
      productSet.add(product);
      Map<ProductNameType, ProductName> productNames = new HashMap<ProductNameType, ProductName>();
      productNames.put(ProductNameType.BASE_MANUFACTURING, new ProductNameImpl(31L, "DKC123", product, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING));
      productNames.put(ProductNameType.MANUFACTURING, new ProductNameImpl(32L, "DKC456", product, DataSource.PREFOUNDATION, "3", ProductNameType.MANUFACTURING));
      product.setProductNames(productNames);
      product = new ProductImpl(1L, "NE5112_v1", new MockTrait("NE5112"), null, null, null, null, false, null, null, false);
      productSet.add(product);
      productNames.put(ProductNameType.BASE_MANUFACTURING, new ProductNameImpl(33L, "NE5112_v1", product, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING));
      product.setProductNames(productNames);
      return new ArrayList<Product>(productSet);
    } else {
      return new ArrayList<Product>();
    }
  }

  public void testGetBaseProducts_ReturnsCorrectProducts() throws Exception {
    Product product1_BASE = new ProductImpl(1L, null, null, null, null, null, null, false, null, null, false);
    Product product2_BASE = new ProductImpl(2L, null, null, null, null, null, null, true, null, null, false);
    Product product3 = new ProductImpl(3L, "A1", new TraitImpl(), null, null, null, null, false, product1_BASE, null, false);
    Product product4 = new ProductImpl(4L, "A1", new TraitImpl(), null, null, null, null, false, product1_BASE, null, false);

    List<Product> allProducts = new ArrayList<Product>();
    allProducts.add(product1_BASE);
    allProducts.add(product2_BASE);
    allProducts.add(product3);
    allProducts.add(product4);

    List<Product> queryProducts = new ArrayList<Product>();
    queryProducts.add(product1_BASE);
    queryProducts.add(product3);
    queryProducts.add(product4);

    MockDAO<Product, Long> baseDao = new MockDAO<Product, Long>(allProducts);
    ProductService service = new ProductServiceImpl(baseDao);
    Collection<Product> uniqueBaseProducts = service.getUniqueBaseProducts(queryProducts);
    assertNotNull(uniqueBaseProducts);
    assertEquals(1, uniqueBaseProducts.size());
    assertTrue(uniqueBaseProducts.contains(product1_BASE));
    assertFalse(uniqueBaseProducts.contains(product2_BASE));
    assertFalse(uniqueBaseProducts.contains(product3));
    assertFalse(uniqueBaseProducts.contains(product4));
  }

  public void testLookupProductById_FindByPrimaryKeyWasCalled() throws Exception {
    Product p1 = new ProductImpl(2L, null, null, null, null, null, null, false, null, null, false);
    List<Product> products = new ArrayList<Product>();
    products.add(p1);
    MockDAO<Product, Long> baseDao = new MockDAO<Product, Long>(products);
    ProductService service = new ProductServiceImpl(baseDao);
    service.lookupProductById(2L);
    assertTrue(baseDao.wasFindByPrimaryKeyCalled());
  }

  public void testLookupProductsByBaseAndTrait() throws Exception {
    Product p1 = new ProductImpl(2L, null, null, null, null, null, null, false, null, null, false);
    List<Product> products = new ArrayList<Product>();
    products.add(p1);
    MockDAO<Product, Long> baseDao = new MockDAO<Product, Long>(products);
    ProductService service = new ProductServiceImpl(baseDao);
    TraitImpl trait = new TraitImpl(1L, "XYZ", "ABC-123", "11-AA-22", null, true);
    service.getProductByBaseAndTrait(p1, trait);
    assertTrue(baseDao.getMockCriteria().wasListCalled());
    MockCriteria mockCriteria = baseDao.getMockCriteria();
    assertEquals(3, mockCriteria.getCriteria().size());
    assertEquals("base=" + p1.toString(), mockCriteria.getCriteria().get(0).toString());
    assertEquals("trait=ABC-123", mockCriteria.getCriteria().get(1).toString());
    assertEquals("status like Primary or status like Primary1 or status like Active% or status like UNKNOWN", mockCriteria.getCriteria().get(2).toString());
  }

  public void testProductThatIsSversionNOTRACKIsShownUnlessInactive() throws Exception {
    Product product1_BASE = new MockProduct(1L, null, null, null, null, null, null, false, null, null, false);
    Trait testTrait = new MockTrait(123L);
    Product product3 = new MockProduct(3L, "NO-TRACK", testTrait, null, null, null, null, false, product1_BASE, "UNKNOWN", false);
    Product product4 = new MockProduct(4L, "NO-TRACK", testTrait, null, null, null, null, false, product1_BASE, "INACTIVE", false);

    List<Product> allProducts = new ArrayList<Product>();
    allProducts.add(product1_BASE);
    allProducts.add(product3);
    allProducts.add(product4);

    MockDAO<Product, Long> baseDao = new MockProductDAOForAllProductsInQuery(allProducts);
    ProductService service = new ProductServiceImpl(baseDao);
    Collection<Product> resultProducts = service.getProductByBaseAndTrait(product1_BASE, testTrait);
    assertTrue("Unknown NO-TRACK was not found, but expected", resultProducts.contains(product3));
    assertFalse("Inactive NO-TRACK was found, but not expected", resultProducts.contains(product4));
  }

  private static class MockProductDAOForAllProductsInQuery extends MockDAO<Product, Long> {
    private MockProductDAOForAllProductsInQuery(List<Product> products) {
      super(products);
    }

    @Override
    public List<Product> findByExample(Product product, String[] strings) {
      return findAll();
    }

    @Override
    public Criteria createCriteria() {
      return new MockCriteriaForAllResults();
    }

    private class MockCriteriaForAllResults extends MockCriteria {
      @Override
      public List list() throws HibernateException {
        return findAll();
      }
    }
  }
}