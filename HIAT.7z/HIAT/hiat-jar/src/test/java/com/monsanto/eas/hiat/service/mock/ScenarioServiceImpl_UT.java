/*
 SavedScenarioServiceImpl_UT was created on Feb 24, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.service.mock;

import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisImpl;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.scenario.ScenarioDetail;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioImpl;
import com.monsanto.eas.hiat.service.ScenarioService;
import com.monsanto.eas.hiat.service.ScenarioServiceImpl;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import com.monsanto.wst.hibernate.mock.MockCriteria;
import com.monsanto.wst.hibernate.mock.MockDAO;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

/**
 * Filename:    $RCSfile: ScenarioServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $
 * On:	$Date: 2009-04-14 19:13:15 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public class ScenarioServiceImpl_UT extends HIATUnitTest {
  //todo asserts are requiring criteria be in a specific order - we really don't care about the order, this should be refactored
  
  public void testLookupScenarioById_FindByPrimaryKeyWasCalled() throws Exception {
    ArrayList<Scenario> scenarios = new ArrayList<Scenario>();
    scenarios.add(new ScenarioImpl(1L, "testId1", "scenario name 1", null, new Date(), false, null,
        null, new HashSet<ScenarioDetail>()));
    scenarios.add(new ScenarioImpl(2L, "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>()));
    scenarios.add(new ScenarioImpl(3L, "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>()));
    MockDAO<Scenario, Long> scenarioDao = new MockDAO<Scenario, Long>(scenarios);
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    Scenario scenario = service.lookupSavedScenariosById(1L);
    assertTrue(scenarioDao.wasFindByPrimaryKeyCalled());
    assertEquals(new Long(1), scenario.getId());
    assertEquals("testId1", scenario.getUsername());
    assertEquals("scenario name 1", scenario.getName());
  }

  public void testLookupSavedScenariosByCriteria_SortBy2Desc_VerifyCriteria() throws Exception {
    MockDAO<Scenario, Long> scenarioDao = new MockDAO<Scenario, Long>(new ArrayList<Scenario>());
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    Date fromDate = DateUtils.addDays(new Date(), 1);
    Date toDate = DateUtils.addDays(new Date(), 2);
    List<Scenario> scenarios = service
        .lookupSavedScenariosByCriteria("userId", "scenario name", fromDate, toDate, new String[]{"name", "username"},
            "desc");
    assertEquals(0, scenarios.size());
    MockCriteria criteria = (MockCriteria) scenarioDao.createCriteria();
    assertTrue(criteria.wasListCalled());
    assertEquals(4, criteria.getCriteria().size());
    assertEquals("username=userId", criteria.getCriteria().get(0).toString());
    assertEquals("name ilike %scenario name%", criteria.getCriteria().get(1).toString());
    assertEquals("saveDate>="+ fromDate.toString(), criteria.getCriteria().get(2).toString());
    assertEquals("saveDate<"+ ScenarioServiceImpl.startOfNextDay(toDate).toString(), criteria.getCriteria().get(3).toString());
    assertEquals(2, criteria.getOrderings().size());
    assertEquals("name desc", criteria.getOrderings().get(0).toString());
    assertEquals("username desc", criteria.getOrderings().get(1).toString());
  }

  public void testLookupSavedScenariosByCriteria_SortBy1Asc_VerifyCriteria() throws Exception {
    MockDAO<Scenario, Long> scenarioDao = new MockDAO<Scenario, Long>(new ArrayList<Scenario>());
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    Date fromDate = DateUtils.addDays(new Date(), 1);
    Date toDate = DateUtils.addDays(new Date(), 2);
    List<Scenario> scenarios = service
        .lookupSavedScenariosByCriteria(null, "scenario NAME", fromDate, toDate, new String[]{"name", "username"},
            "asc");
    assertEquals(0, scenarios.size());
    MockCriteria criteria = (MockCriteria) scenarioDao.createCriteria();
    assertTrue(criteria.wasListCalled());
    assertEquals(3, criteria.getCriteria().size());
    assertEquals("name ilike %scenario NAME%", criteria.getCriteria().get(0).toString());
    assertEquals("saveDate>="+ fromDate.toString(), criteria.getCriteria().get(1).toString());
    assertEquals("saveDate<"+ ScenarioServiceImpl.startOfNextDay(toDate).toString(), criteria.getCriteria().get(2).toString());
    assertEquals(2, criteria.getOrderings().size());
    assertEquals("name asc", criteria.getOrderings().get(0).toString());
    assertEquals("username asc", criteria.getOrderings().get(1).toString());
  }

  public void testLookupSavedScenariosByCriteria_SortDirIsNull_VerifyCriteria() throws Exception {
    MockDAO<Scenario, Long> scenarioDao = new MockDAO<Scenario, Long>(new ArrayList<Scenario>());
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    Date fromDate = DateUtils.addDays(new Date(), 1);
    Date toDate = DateUtils.addDays(new Date(), 2);
    List<Scenario> scenarios = service
        .lookupSavedScenariosByCriteria("userId", " ", fromDate, toDate, new String[]{"name", "username"}, null);
    assertEquals(0, scenarios.size());
    MockCriteria criteria = (MockCriteria) scenarioDao.createCriteria();
    assertTrue(criteria.wasListCalled());
    assertEquals(3, criteria.getCriteria().size());
    assertEquals("username=userId", criteria.getCriteria().get(0).toString());
    assertEquals("saveDate>="+ fromDate.toString(), criteria.getCriteria().get(1).toString());
    assertEquals("saveDate<"+ ScenarioServiceImpl.startOfNextDay(toDate).toString(), criteria.getCriteria().get(2).toString());
    assertEquals(2, criteria.getOrderings().size());
    assertEquals("name asc", criteria.getOrderings().get(0).toString());
    assertEquals("username asc", criteria.getOrderings().get(1).toString());
  }

  public void testLookupSavedScenariosByCriteria_FromIsNullSortByNone_VerifyCriteria() throws Exception {
    MockDAO<Scenario, Long> scenarioDao = new MockDAO<Scenario, Long>(new ArrayList<Scenario>());
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    Date toDate = DateUtils.addDays(new Date(), 2);
    List<Scenario> scenarios = service
        .lookupSavedScenariosByCriteria("userId", "scenario name", null, toDate, new String[0], null);
    assertEquals(0, scenarios.size());
    MockCriteria criteria = (MockCriteria) scenarioDao.createCriteria();
    assertTrue(criteria.wasListCalled());
    assertEquals(4, criteria.getCriteria().size());
    assertEquals("username=userId", criteria.getCriteria().get(0).toString());
    assertEquals("name ilike %scenario name%", criteria.getCriteria().get(1).toString());
    assertEquals("saveDate>="+ toDate.toString(), criteria.getCriteria().get(2).toString());
    assertEquals("saveDate<"+ ScenarioServiceImpl.startOfNextDay(toDate).toString(), criteria.getCriteria().get(3).toString());
    assertEquals(0, criteria.getOrderings().size());
  }

  public void testLookupSavedScenariosByCriteria_ToIsNullSortByNone_VerifyCriteria() throws Exception {
    MockDAO<Scenario, Long> scenarioDao = new MockDAO<Scenario, Long>(new ArrayList<Scenario>());
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    Date fromDate = DateUtils.addDays(new Date(), 1);
    List<Scenario> scenarios = service
        .lookupSavedScenariosByCriteria("userId", "scenario name", fromDate, null, new String[0], null);
    assertEquals(0, scenarios.size());
    MockCriteria criteria = (MockCriteria) scenarioDao.createCriteria();
    assertTrue(criteria.wasListCalled());
    assertEquals(4, criteria.getCriteria().size());
    assertEquals("username=userId", criteria.getCriteria().get(0).toString());
    assertEquals("name ilike %scenario name%", criteria.getCriteria().get(1).toString());
    assertEquals("saveDate>="+ fromDate.toString(), criteria.getCriteria().get(2).toString());
    assertEquals("saveDate<"+ ScenarioServiceImpl.startOfNextDay(fromDate).toString(), criteria.getCriteria().get(3).toString());
    assertEquals(0, criteria.getOrderings().size());
  }

  public void testLookupUserIdWithSavedScenarios_ReturnsListOfUserIds() throws Exception {
    ArrayList<Scenario> scenarios = new ArrayList<Scenario>();
    scenarios.add(new ScenarioImpl(null, "testId1", "scenario name 1", null, new Date(), false, null,
        null, new HashSet<ScenarioDetail>()
    ));
    scenarios.add(new ScenarioImpl(null, "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>()
    ));
    scenarios.add(new ScenarioImpl(null, "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>()
    ));
    MockDAO<Scenario, Long> scenarioDao = new MockDAO<Scenario, Long>(scenarios);
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    List<String> userIds = service.lookupUserIdsWithSavedScenarios();
    assertEquals(2, userIds.size());
    assertEquals("testId1", userIds.get(0));
    assertEquals("testId2", userIds.get(1));
    assertEquals("username", scenarioDao.getSortKey());
    assertTrue(scenarioDao.getSortOrder());
  }

  public void testLookupUserIdWithSavedScenarios_NoSavedScenarios_ReturnsEmptyList() throws Exception {
    MockDAO<Scenario, Long> scenarioDao = new MockDAO<Scenario, Long>(new ArrayList<Scenario>());
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    List<String> userIds = service.lookupUserIdsWithSavedScenarios();
    assertEquals("username", scenarioDao.getSortKey());
    assertTrue(scenarioDao.getSortOrder());
    assertEquals(0, userIds.size());
  }

  public void testDeleteScenarios_NoIds_ScenariosNotDeleted() throws Exception {
    MockScenarioDAO<Scenario, Long> scenarioDao = new MockScenarioDAO<Scenario, Long>(new ArrayList<Scenario>(), null);
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    service.deleteScenariosById(new String[]{});
    assertEquals(0, scenarioDao.getSavedScenarios().size());
  }

  public void testDeleteScenarios_2Ids_VeridyIsDeletedFlagSetToYes() throws Exception {
    ArrayList<Scenario> list = new ArrayList<Scenario>();
    list.add(new ScenarioImpl(new Long(2), "testId1", "scenario name 1", null, new Date(), false, null,
        null, new HashSet<ScenarioDetail>()));
    list.add(new ScenarioImpl(new Long(3), "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>()));
    list.add(new ScenarioImpl(new Long(4), "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>()));
    MockScenarioDAO<Scenario, Long> scenarioDao = new MockScenarioDAO<Scenario, Long>(list, null);
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    service.deleteScenariosById(new String[]{"2", "3"});
    assertEquals(2, scenarioDao.getSavedScenarios().size());
    Scenario scenario = scenarioDao.getSavedScenarios().get(0);
    assertEquals(new Long(2), scenario.getId());
    assertTrue(scenario.isDeleted());
    scenario = scenarioDao.getSavedScenarios().get(1);
    assertEquals(new Long(3), scenario.getId());
    assertTrue(scenario.isDeleted());
  }

  public void testLookupScenarioByName_NullName_ReturnsNull() throws Exception {
    Scenario scenario = new ScenarioImpl(null, "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>());
    MockScenarioDAO<Scenario, Long> scenarioDao = new MockScenarioDAO<Scenario, Long>(null, scenario);
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    scenario = service.lookupScenarioByName(null);
    assertNull(scenario);
    assertNotNull(scenarioDao.getCriteria().uniqueResult());
  }

  public void testLookupScenarioByName_NameExists_VerifyCriteria() throws Exception {
    Scenario scenario = new ScenarioImpl(null, "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>());
    MockScenarioDAO<Scenario, Long> scenarioDao = new MockScenarioDAO<Scenario, Long>(null, scenario);
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    scenario = service.lookupScenarioByName("scenario");
    MockCriteria criteria = (MockCriteria) scenarioDao.getCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("name=scenario", criteria.getCriteria().get(0).toString());
    assertEquals(scenario, criteria.uniqueResult());
  }

  public void testLookupScenarioByName_NameDoesNotExist_VerifyCriteria() throws Exception {
    ArrayList<Scenario> list = new ArrayList<Scenario>();
    list.add(new ScenarioImpl(null, "testId1", "scenario name 1", null, new Date(), false, null,
        null, new HashSet<ScenarioDetail>()));
    list.add(new ScenarioImpl(null, "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>()));
    list.add(new ScenarioImpl(null, "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>()));
    MockScenarioDAO<Scenario, Long> scenarioDao = new MockScenarioDAO<Scenario, Long>(list, null);
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    Scenario scenario = service.lookupScenarioByName("scenario");
    assertNull(scenario);
    MockCriteria criteria = (MockCriteria) scenarioDao.getCriteria();
    assertEquals(1, criteria.getCriteria().size());
    assertEquals("name=scenario", criteria.getCriteria().get(0).toString());
    assertNull(criteria.uniqueResult());
  }

  public void testSaveOrUpdateScenario_SaveScenario_Saved() throws Exception {
    MockScenarioDAO<Scenario, Long> scenarioDao = new MockScenarioDAO<Scenario, Long>(null, null);
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    List<Trait> traits = new ArrayList<Trait>();
    traits.add(new MockTrait(new Long(123)));
    traits.add(new MockTrait(new Long(234)));
    List<HybridAnalysis> analysis = new ArrayList<HybridAnalysis>();
    analysis.add(new HybridAnalysisImpl(new MockProduct(1L), new MockTrait(2L), null));
    service.saveOrUpdatedScenario("testId", "scenario name new", "scenario desc", "NE5112", traits, analysis, false);

    assertEquals(1, scenarioDao.getSavedScenarios().size());
    Scenario newScenario = scenarioDao.getSavedScenarios().get(0);
    assertNull(newScenario.getId());
    assertEquals("testId", newScenario.getUsername());
    assertEquals("scenario name new", newScenario.getName());
    assertEquals("scenario desc", newScenario.getDescription());
    assertDateEqual(new Date(), newScenario.getSaveDate());
    assertFalse(newScenario.isOutOfDate());
    assertEquals(2, newScenario.getTraits().size());
    assertEquals("NE5112", newScenario.getProducts());
    assertEquals(1, newScenario.getDetails().size());
    ScenarioDetail scenarioDetail = (ScenarioDetail) newScenario.getDetails().iterator().next();
    assertNull(scenarioDetail.getId());
    assertNotNull(scenarioDetail.getScenario());
    assertNotNull(scenarioDetail.getHybridAnalysis());
  }

  private void assertDateEqual(Date date1, Date date2) {
      if (date1 == date2 || date1 == null || date2 == null || date1.equals(date2)) {
          assertEquals(date1, date2);
      }

      DateFormat df = SimpleDateFormat.getDateInstance();
      assertEquals(df.format(date1), df.format(date2));
  }

  public void testSaveOrUpdateScenario_UpdateScenario_OldScenarioIsDeletedNewIsSaved() throws Exception {
    ArrayList<Scenario> list = new ArrayList<Scenario>();
    list.add(new ScenarioImpl(new Long(2), "testId1", "scenario name 1", null, new Date(), false, null,
        null, new HashSet<ScenarioDetail>()));
    list.add(new ScenarioImpl(new Long(3), "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>()));
    list.add(new ScenarioImpl(new Long(4), "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>()));
    Scenario uniqueResult = new ScenarioImpl(new Long(3), "testId2", "scenario name 2", null, new Date(), true, null,
        null, new HashSet<ScenarioDetail>());
    MockScenarioDAO<Scenario, Long> scenarioDao = new MockScenarioDAO<Scenario, Long>(list, uniqueResult);
    ScenarioService service = new ScenarioServiceImpl(scenarioDao);
    List<Trait> traits = new ArrayList<Trait>();
    traits.add(new MockTrait(new Long(123)));
    traits.add(new MockTrait(new Long(234)));
    List<HybridAnalysis> analysis = new ArrayList<HybridAnalysis>();
    analysis.add(new HybridAnalysisImpl(new MockProduct(1L), new MockTrait(2L), null));
    service.saveOrUpdatedScenario("testId", "scenario name new", "scenario desc", "NE5112", traits, analysis, true);
    MockCriteria criteria = (MockCriteria) scenarioDao.getCriteria();
    assertEquals(uniqueResult, criteria.uniqueResult());

    assertEquals(2, scenarioDao.getSavedScenarios().size());
    Scenario deletedScenario = scenarioDao.getSavedScenarios().get(0);
    assertEquals(deletedScenario.getId(), uniqueResult.getId());
    assertEquals(new Long(3), deletedScenario.getId());
    assertTrue(deletedScenario.isDeleted());

    Scenario newScenario = scenarioDao.getSavedScenarios().get(1);
    assertNull(newScenario.getId());
    assertEquals("testId", newScenario.getUsername());
    assertEquals("scenario name new", newScenario.getName());
    assertEquals("scenario desc", newScenario.getDescription());
    assertDateEqual(new Date(), newScenario.getSaveDate());
    assertFalse(newScenario.isOutOfDate());
    assertEquals(2, newScenario.getTraits().size());
    assertEquals("NE5112", newScenario.getProducts());
    assertEquals(1, newScenario.getDetails().size());
    ScenarioDetail scenarioDetail = (ScenarioDetail) newScenario.getDetails().iterator().next();
    assertNull(scenarioDetail.getId());
    assertNotNull(scenarioDetail.getScenario());
    assertNotNull(scenarioDetail.getHybridAnalysis());
  }

  private class MockScenarioDAO<T, T1> extends MockDAO<Scenario, Long> {
    private List<Scenario> scenarios;
    private Scenario uniqueResult;
    private List<Scenario> savedScenarios = new ArrayList<Scenario>();
    private MockCriteriaOverridesUniqueResult criteria;

    public MockScenarioDAO(List<Scenario> scenarios, Scenario uniqueResult) {
      this.scenarios = scenarios;
      this.uniqueResult = uniqueResult;
    }

    public Scenario findByPrimaryKey(Long id) {
      for (Scenario scenario : scenarios) {
        if (scenario.getId().equals(id)) {
          return scenario;
        }
      }
      return null;
    }

    public Criteria createCriteria() {
      criteria = new MockCriteriaOverridesUniqueResult(uniqueResult);
      return criteria;
    }

    public Scenario save(Scenario scenario) {
      savedScenarios.add(scenario);
      return scenario;
    }

    public List<Scenario> getSavedScenarios() {
      return savedScenarios;
    }

    public MockCriteriaOverridesUniqueResult getCriteria() {
      return criteria;
    }
  }

  private class MockCriteriaOverridesUniqueResult extends MockCriteria {
    private Object uniqueResult;

    private MockCriteriaOverridesUniqueResult(Object uniqueResult) {
      this.uniqueResult = uniqueResult;
    }

    public Object uniqueResult() throws HibernateException {
      return uniqueResult;
    }
  }
}