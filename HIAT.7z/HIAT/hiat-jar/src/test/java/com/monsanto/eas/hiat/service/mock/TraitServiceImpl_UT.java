package com.monsanto.eas.hiat.service.mock;

import com.monsanto.eas.hiat.controller.mock.MockTraitCalculator;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.service.TraitService;
import com.monsanto.eas.hiat.service.TraitServiceImpl;
import com.monsanto.eas.hiat.service.mock.mock.MockTraitDAO;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;

import java.util.List;

/**
 * Created by vvvelu Date: Feb 13, 2009 Time: 1:49:06 PM
 */
public class TraitServiceImpl_UT extends HIATUnitTest {

  public void testLookupAllTraits() throws Exception {
    MockTraitDAO mockTraitDao = new MockTraitDAO();
    TraitService traitService = new TraitServiceImpl(mockTraitDao, null);
    List<Trait> traitsList = traitService.lookupAllTraits();
    assertEquals(6, traitsList.size());
    assertEquals("code", mockTraitDao.getSortKey());
    assertTrue(mockTraitDao.getSortOrder());
  }

  public void testLookupSelectedTraits() throws Exception {
    MockTraitDAO mockTraitDao = new MockTraitDAO();
    TraitService traitService = new TraitServiceImpl(mockTraitDao, null);
    List<Trait> list = traitService.lookupSelectedTraits(new String[]{"1"});
    assertEquals(1, list.size());
    assertTrue(mockTraitDao.wasFindByPrimaryKeyCalled());
  }

  public void testConfigTrait() throws Exception {
      MockTraitDAO mockTraitDao = new MockTraitDAO();
      TraitService traitService = new TraitServiceImpl(mockTraitDao, null);
      Trait trait = traitService.lookupTraitById(1L);
      traitService.configureTrait(trait);
      assertTrue(mockTraitDao.wasSaved(trait));
  }

  public void testLookupAllActive() throws Exception {
      MockTraitDAO mockTraitDao = new MockTraitDAO();
      TraitService traitService = new TraitServiceImpl(mockTraitDao, null);
      List<Trait> activeTraits = traitService.lookupAllActive();
      assertEquals(4, activeTraits.size());
  }

  public void testLookupAllInActive() throws Exception {
      MockTraitDAO mockTraitDao = new MockTraitDAO();
      TraitService traitService = new TraitServiceImpl(mockTraitDao, null);
      List<Trait> inActiveTraits = traitService.lookupAllInActive();
      assertEquals(2, inActiveTraits.size());
  }

/*
todo this was a jumbled mess of different things going on, parsing, lookup, etc.  need to seperate out into individual tests, if they don't already exist elsewhere
  public void testGetPossibleTraitCombinations() throws Exception {
      String traits = "1_2_3_";
      MockTraitDAO mockTraitDao = new MockTraitDAO();
      MockTraitCalculator traitCalc = new MockTraitCalculator();
      TraitServiceImpl traitService = new TraitServiceImpl(mockTraitDao, traitCalc);
      Document doc = traitService.getPossibleTraitCombinations(traits);
      assertXpathEvaluatesTo("1", "count(//TRAITS)", doc);
      assertXpathEvaluatesTo("4", "count(//TRAIT)", doc);
      String xpath1 = "//TRAIT[COMM_NAME='HXCB']";
      String xpath2 = "//TRAIT[COMM_NAME='HXRW']";
      String xpath3 = "//TRAIT[COMM_NAME='HXCB-HXRW']";
      String xpath4 = "//TRAIT[COMM_NAME='CONV']";
      assertXpathEvaluatesTo("1", xpath1+"//ID", doc);
      assertXpathEvaluatesTo("2", xpath2+"//ID", doc);
      assertXpathEvaluatesTo("3", xpath3+"//ID", doc);
      assertXpathEvaluatesTo("0", xpath4+"//ID", doc);
  }
*/

  public void testCalculateTraits() throws Exception {
      MockTraitDAO mockTraitDao = new MockTraitDAO();
      MockTraitCalculator traitCalc = new MockTraitCalculator();
      TraitServiceImpl traitService = new TraitServiceImpl(mockTraitDao, traitCalc);
      List<Trait> calculatedTraits = traitService.calculateTraits(new String[] {"1", "2", "3"});
      assertEquals(4, calculatedTraits.size());
      assertTrue(calculatedTraits.contains(mockTraitDao.getTestTrait(1L)));
      assertTrue(calculatedTraits.contains(mockTraitDao.getTestTrait(2L)));
      assertTrue(calculatedTraits.contains(mockTraitDao.getTestTrait(3L)));
      assertTrue(calculatedTraits.contains(mockTraitDao.getTestTrait(0L)));
  }

  public void testTraitsAreUniqueAndSorted() throws Exception {
    MockTraitDAO mockTraitDao = new MockTraitDAO();
    MockTraitCalculator traitCalc = new MockTraitCalculator();
    TraitServiceImpl traitService = new TraitServiceImpl(mockTraitDao, traitCalc);
    List<Trait> calculatedTraits = traitService.calculateTraits(new String[] {"1", "3", "1", "2", "3"});
    assertEquals(4, calculatedTraits.size());
    assertEquals(mockTraitDao.getTestTrait(0L), calculatedTraits.get(0));
    assertEquals(mockTraitDao.getTestTrait(1L), calculatedTraits.get(1));
    assertEquals(mockTraitDao.getTestTrait(3L), calculatedTraits.get(2));
    assertEquals(mockTraitDao.getTestTrait(2L), calculatedTraits.get(3));
  }

}
