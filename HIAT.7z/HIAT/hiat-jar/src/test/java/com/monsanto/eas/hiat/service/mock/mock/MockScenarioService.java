/*
 MockSavedScenarioService was created on Feb 24, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.service.mock.mock;

import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.mock.MockScenario;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.scenario.ScenarioDetail;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioDetailImpl;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioImpl;
import com.monsanto.eas.hiat.service.ScenarioService;

import java.util.*;

/**
 * Filename:    $RCSfile: MockScenarioService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2009-03-31 17:03:08 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class MockScenarioService implements ScenarioService {
  private List<Scenario> scenarios;
  private List<String> userIds;
  private String userId;
  private String name;
  private Date saveDataFrom;
  private Date saveDateTo;
  private String[] sortKeys;
  private String sortDir;
  private String[] deletedIds;
  private Scenario savedScenario;
  private Scenario replacedScenario;

  public MockScenarioService(List<Scenario> scenarios, List<String> userIds) {
    this.scenarios = scenarios;
    this.userIds = userIds;
  }

  public Scenario lookupSavedScenariosById(Long scenarioId) {
    for (Scenario scenario : scenarios) {
      if (scenario.getId().equals(scenarioId)) {
        return scenario;
      }
    }
    return null;
  }

  public List<Scenario> lookupSavedScenariosByCriteria(String userId, String name, Date saveDateFrom, Date saveDateTo,
                                                       String[] sortKeys, String sortDir) {
    this.userId = userId;
    this.name = name;
    this.saveDataFrom = saveDateFrom;
    this.saveDateTo = saveDateTo;
    this.sortKeys = sortKeys;
    this.sortDir = sortDir;
    return this.scenarios;
  }

  public List<String> lookupUserIdsWithSavedScenarios() {
    return this.userIds;
  }

  public void deleteScenariosById(String[] scenarioIds) {
    this.deletedIds = scenarioIds;
  }

  public Scenario lookupScenarioByName(String name) {
    for(Scenario scenario: scenarios){
      if(scenario.getName().equalsIgnoreCase(name)){
        return scenario;
      }
    }
    return null;
  }

  public Scenario saveOrUpdatedScenario(String userId, String scenarioName, String scenarioDesc, String productNames,
                                    Collection<? extends Trait> traits,
                                    Collection<? extends HybridAnalysis> hyrbridAnalysisList, boolean updateScenario) {
    if(updateScenario){
      return replaceScenario(userId, scenarioName, scenarioDesc, productNames, traits, hyrbridAnalysisList);
    }else{
      return saveScenario(userId, scenarioName, scenarioDesc, productNames, traits, hyrbridAnalysisList);
    }
  }

  private Scenario saveScenario(String userId, String scenarioName, String scenarioDesc, String productNames,
                               Collection<? extends Trait> traits, Collection<? extends HybridAnalysis> hyrbridAnalysisList) {
    Set<ScenarioDetail> details = new HashSet<ScenarioDetail>();
    for(HybridAnalysis analysis: hyrbridAnalysisList){
      details.add(new ScenarioDetailImpl(new MockScenario(scenarioName, userId), analysis));
    }
    savedScenario = new ScenarioImpl(123L, userId, scenarioName, scenarioDesc, new Date(), false, productNames,
        new HashSet<Trait>(traits), details);
    return savedScenario;
  }

  private Scenario replaceScenario(String userId, String scenarioName, String scenarioDesc, String productNames,
                                  Collection<? extends Trait> traits, Collection<? extends HybridAnalysis> hyrbridAnalysisList) {
    Set<ScenarioDetail> details = new HashSet<ScenarioDetail>();
    for(HybridAnalysis analysis: hyrbridAnalysisList){
      details.add(new ScenarioDetailImpl(new MockScenario(scenarioName, userId), analysis));
    }
    replacedScenario = new ScenarioImpl(234L, userId, scenarioName, scenarioDesc, new Date(), false, productNames,
        new HashSet<Trait>(traits), details);
    return replacedScenario;
  }

  public String getUserId() {
    return userId;
  }

  public String getName() {
    return name;
  }

  public Date getSaveDataFrom() {
    return saveDataFrom;
  }

  public Date getSaveDateTo() {
    return saveDateTo;
  }

  public String[] getSortKeys() {
    return sortKeys;
  }

  public String getSortDir() {
    return sortDir;
  }

  public String[] getDeletedIds() {
    return deletedIds;
  }

  public Scenario getSavedScenario() {
    return savedScenario;
  }

  public Scenario getReplacedScenario() {
    return replacedScenario;
  }
}