package com.monsanto.eas.hiat.service.mock.mock;

import com.monsanto.eas.hiat.dao.TraitDAO;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.wst.hibernate.mock.MockDAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by vvvelu Date: Feb 10, 2009 Time: 10:22:15 AM
 */
public class MockTraitDAO extends MockDAO<Trait,Long> implements TraitDAO {
    private static final Trait CONV = new MockTrait(0L, "CONV", "CONV", "CONV", null, true);
    private final static Trait traitOne = new MockTrait(1L,"WHM", "HXCB", "HXCB", null, true);
    private final static Trait traitTwo = new MockTrait(2L,"FWM", "HXRW", "HXRW", null, true);
    private final static Trait traitThree = new MockTrait(3L, "MSL", "HXCB-HXRW", "HXCB-HXRW", null, true);
    private final static Trait traitFour = new MockTrait(4L, "BDH", "BDH", "BDH", null, false);
    private final static Trait traitFive = new MockTrait(5L, "BGL", "BDH", "BDH", null, false);

    private final Map<Long, Trait> testTraits;
    private boolean wasFindByPrimaryKeyCalled;

  public MockTraitDAO() {
      this(getTestTraits());
  }

    public MockTraitDAO(Map<Long, Trait> testTraits) {
        super(new ArrayList<Trait>(testTraits.values()));
        this.testTraits = testTraits;
    }

    private static Map<Long, Trait> getTestTraits() {
        Map<Long, Trait> testTraits = new HashMap<Long, Trait>();
        testTraits.put(1L, traitOne);
        testTraits.put(2L, traitTwo);
        testTraits.put(3L, traitThree);
        testTraits.put(0L, CONV);
        testTraits.put(4L, traitFour);
        testTraits.put(5L, traitFive);
        return testTraits;
    }

    public Trait getTestTrait(long id) {
      return testTraits.get(id);
  }

    public Trait getConventional() {
        return CONV;
    }

    @Override
    public Trait findByPrimaryKey(Long aLong) {
        wasFindByPrimaryKeyCalled = true;
        return testTraits.get(aLong);
    }

    @Override
    public boolean wasFindByPrimaryKeyCalled() {
        return wasFindByPrimaryKeyCalled;
    }

    @Override
    public List<Trait> findAll(String s, boolean b) {
        super.findAll(s, b);
        return new ArrayList<Trait>(testTraits.values());    
    }

}
