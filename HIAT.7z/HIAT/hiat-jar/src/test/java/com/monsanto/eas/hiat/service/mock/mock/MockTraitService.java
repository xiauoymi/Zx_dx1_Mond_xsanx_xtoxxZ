package com.monsanto.eas.hiat.service.mock.mock;

import com.monsanto.eas.hiat.controller.mock.MockTraitCalculator;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.service.TraitServiceImpl;

import java.util.*;

/**
 * Created by User: vvvelu Date: Feb 10, 2009 Time: 10:22:15 AM
 */
public class MockTraitService extends TraitServiceImpl {

  private final Trait traitOne = new MockTrait(1L, "WHM", "HXCB", "HXCB", null, true);
  private final Trait traitTwo = new MockTrait(2L, "FWM", "HXRW", "HXRW", null, true);
  private final Trait traitThree = new MockTrait(3L, "MSL", "HXCB-HXRW", "HXCB-HXRW", null, true);
  private static final Trait CONV = new MockTrait(0L, "CONV", "CONV", "CONV", null, true);
  private Trait traitFour = new MockTrait(4L, "BDH", "BDH", "BDH", null, false);
  private Trait traitFive = new MockTrait(5L, "BGL", "BDH", "BDH", null, false);

  private final Map<Long, Trait> testTraits = new HashMap<Long, Trait>();
  private boolean wasConfigureTraitCalled;
  private boolean wasCalculateTraitsCalled;
  private boolean wasGetAllTraitsCalled = false;
  private boolean wasGetActiveTraitsCalled = false;

  public MockTraitService() {
    super(new MockTraitDAO(), new MockTraitCalculator());
    testTraits.put(1L, traitOne);
    testTraits.put(2L, traitTwo);
    testTraits.put(3L, traitThree);
  }

  public boolean wasGetAllTraitsCalled() {
    return wasGetAllTraitsCalled;
  }

  public boolean wasGetActiveTraitsCalled() {
    return wasGetActiveTraitsCalled;
  }

  public Trait getTestTrait(long id) {
    return testTraits.get(id);
  }

  public List<Trait> lookupAllTraits() {
    wasGetAllTraitsCalled = true;
    List<Trait> traits = new ArrayList<Trait>();
    traits.add(traitOne);
    traits.add(traitTwo);
    traits.add(traitThree);
    traits.add(CONV);
    //traits.add(traitFour);
    //traits.add(traitFive);
    return traits;
  }

  public List<Trait> lookupSelectedTraits(String[] traits) {
    List<Trait> traitsList = new ArrayList<Trait>();
    for (String traidId : traits) {
      traitsList.add(new MockTrait(new Long(traidId)));
    }
    return traitsList;
  }

  public Trait lookupTraitById(Long id) {
    return id == 4L ? new MockTrait(4L, "MOCK", "MOCK", "MOCK", Collections.<Trait>emptySet(), false) : new MockTrait(id, "MOCK", "MOCK", "MOCK", Collections.<Trait>emptySet(), true);

  }

  @Override
  public void configureTrait(Trait trait) {
    wasConfigureTraitCalled = true;
  }

  public boolean wasConfigureTraitCalled() {
    return wasConfigureTraitCalled;
  }

  @Override
  public List<Trait> lookupAllActive() {
    wasGetActiveTraitsCalled = true;
    return new ArrayList<Trait>(testTraits.values());
  }

  public List<Trait> lookupAllInActive() {
//        Trait traitOne = new MockTrait(4L, "BDH", "BDH", "BDH", null, false);
//        Trait traitTwo = new MockTrait(5L, "BGL", "BDH", "BDH", null, false);
    List<Trait> inactiveTraits = new ArrayList<Trait>();
    inactiveTraits.add(traitFour);
    inactiveTraits.add(traitFive);
    return inactiveTraits;
  }

  @Override
  public List<Trait> calculateTraits(String[] splitTraits) {
    wasCalculateTraitsCalled = true;
    return new ArrayList<Trait>();
  }

  public boolean wasCalculateTraitsCalled() {
    return wasCalculateTraitsCalled;
  }
}
