package com.monsanto.eas.hiat.trait;

import com.monsanto.eas.hiat.calculator.Calculator;
import com.monsanto.eas.hiat.dao.TraitDAO;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.service.mock.mock.MockTraitDAO;
import com.monsanto.eas.hiat.util.HIATUnitTest;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class TraitCalculator_UT extends HIATUnitTest {
    public void testSimpleTraitReturnsJustSelfandConventional() throws Exception {
        Trait testTrait = new MockTrait(-2L, "MOCK", "MOCK TRAIT-2", "MOCK", new HashSet<Trait>(), true);
        Map<Long, Trait> traitList = new HashMap<Long, Trait>();
        traitList.put(-2L, testTrait);
        TraitDAO traitDAO = new MockTraitDAO(traitList);

        Calculator<Trait, List<TraitTree>> calc = new TraitCalculatorImpl(traitDAO);
        List<TraitTree> pairings = calc.calculate(testTrait);
        assertNotNull(pairings);
        final Trait conventional = new MockTraitDAO().getConventional();
        assertContains(new TraitTree(testTrait, conventional), pairings);
        assertContains(new TraitTree(conventional, testTrait), pairings);
        assertEquals(2, pairings.size());
    }

    private void assertContains(Object obj, Collection<?> collection) {
        assertTrue("Expected collection " + collection + " to contain " + obj + " but did not.", collection.contains(obj));
    }

    public void testBinaryTraitReturnsSelfPlusTwoParents() throws Exception {
        Trait testParent1Trait = new MockTrait(-3L, "MOCK", "MOCK TRAIT-3", "MOCK", new HashSet<Trait>(), true);
        Trait testParent2Trait = new MockTrait(-4L, "MOCK", "MOCK TRAIT-4", "MOCK", new HashSet<Trait>(), true);
        Set<Trait> parents = new HashSet<Trait>();
        parents.add(testParent1Trait);
        parents.add(testParent2Trait);
        Trait testTrait = new MockTrait(-2L, "MOCK", "MOCK TRAIT-2", "MOCK", parents, true);

        Map<Long, Trait> traitList = new HashMap<Long, Trait>();
        traitList.put(-3L, testParent1Trait);
        traitList.put(-4L, testParent2Trait);
        traitList.put(-2L, testTrait);
        TraitDAO traitDAO = new MockTraitDAO(traitList);

        Calculator<Trait, List<TraitTree>> calc = new TraitCalculatorImpl(traitDAO);
        List<TraitTree> pairings = calc.calculate(testTrait);
        assertNotNull(pairings);
        final Trait conventional = new MockTraitDAO().getConventional();
        assertContains(new TraitTree(testParent1Trait, testParent2Trait), pairings);
        assertContains(new TraitTree(testParent2Trait, testParent1Trait), pairings);
        assertContains(new TraitTree(testTrait, conventional), pairings);
        assertContains(new TraitTree(conventional, testTrait), pairings);
        assertEquals(4, pairings.size());
    }

    public void testManyParentsReturnsCorrectNumberOfPairsAndAllPairsAreValid() throws Exception {
        Trait testParent1Trait = new MockTrait(-3L, "MOCK", "MOCK TRAIT-3", "MOCK", new HashSet<Trait>(), true);
        Trait testParent2Trait = new MockTrait(-4L, "MOCK", "MOCK TRAIT-4", "MOCK", new HashSet<Trait>(), true);
        Trait testParent3Trait = new MockTrait(-5L, "MOCK", "MOCK TRAIT-5", "MOCK", new HashSet<Trait>(), true);
        Trait testParent4Trait = new MockTrait(-6L, "MOCK", "MOCK TRAIT-6", "MOCK", new HashSet<Trait>(), true);
        Set<Trait> parentPairing1List = new HashSet<Trait>();
        parentPairing1List.add(testParent1Trait);
        parentPairing1List.add(testParent2Trait);
        parentPairing1List.add(testParent3Trait);
        Trait testParentPairing1 = new MockTrait(-7L, "MOCK", "MOCK TRAIT-7", "MOCK", parentPairing1List, true);
        Set<Trait> parentPairing2List = new HashSet<Trait>();
        parentPairing2List.add(testParent1Trait);
        parentPairing2List.add(testParent2Trait);
        Trait testParentPairing2 = new MockTrait(-8L, "MOCK", "MOCK TRAIT-8", "MOCK", parentPairing2List, true);
        Set<Trait> parentPairing3List = new HashSet<Trait>();
        parentPairing3List.add(testParent3Trait);
        parentPairing3List.add(testParent4Trait);
        Trait testParentPairing3 = new MockTrait(-9L, "MOCK", "MOCK TRAIT-9", "MOCK", parentPairing3List, true);
        Set<Trait> parents = new HashSet<Trait>();
        parents.add(testParent1Trait);
        parents.add(testParent2Trait);
        parents.add(testParent3Trait);
        parents.add(testParent4Trait);
        Trait testTrait = new MockTrait(-2L, "MOCK", "MOCK TRAIT-2", "MOCK", parents, true  );

        Map<Long, Trait> traitList = new HashMap<Long, Trait>();
        traitList.put(-3L, testParent1Trait);
        traitList.put(-4L, testParent2Trait);
        traitList.put(-5L, testParent3Trait);
        traitList.put(-6L, testParent4Trait);
        traitList.put(-7L, testParentPairing1);
        traitList.put(-8L, testParentPairing2);
        traitList.put(-9L, testParentPairing3);
        traitList.put(-2L, testTrait);
        TraitDAO traitDAO = new MockTraitDAO(traitList);

        Calculator<Trait, List<TraitTree>> calc = new TraitCalculatorImpl(traitDAO);
        List<TraitTree> pairings = calc.calculate(testTrait);
        assertNotNull(pairings);
        final Trait conventional = new MockTraitDAO().getConventional();
        assertContains(new TraitTree(testTrait, conventional), pairings);
        assertContains(new TraitTree(conventional, testTrait), pairings);
        assertContains(new TraitTree(testParentPairing1, testParent4Trait), pairings);
        assertContains(new TraitTree(testParent4Trait, testParentPairing1), pairings);
        assertContains(new TraitTree(testParentPairing2, testParentPairing3), pairings);
        assertContains(new TraitTree(testParentPairing3, testParentPairing2), pairings);
        assertEquals(6, pairings.size());
    }
}
