package com.monsanto.eas.hiat.util;

public class AnalysisTestConstants {

  public static final String GENERATE_ANALYSIS = "generateAnalysis";
  public static final String DOWNLOAD_SAVED_SCENARIO = "downloadSavedScenario";
  public static final String DOWNLOAD_CURRENT_VALUES_FOR_SAVED_SCENARIO = "downloadCurrentValuesForSavedScenario";
  public static final String CONFIG_TRAIT = "configTrait";
}
