package com.monsanto.eas.hiat.util;

import com.monsanto.eas.hiat.availability.AvailabilityDate;
import junit.framework.TestCase;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class DateTestUtil {
    public static void assertDatesEqual(Date date1, Date date2) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        if (date1 == date2 || date1 == null || date2 == null) {
            TestCase.assertEquals(date1, date2);
        } else {
            String fmtDate1 = df.format(date1);
            String fmtDate2 = df.format(date2);
            TestCase.assertEquals(fmtDate1, fmtDate2);
        }
    }

    public static void assertDatesEqual(AvailabilityDate date1, AvailabilityDate date2) {
        if (date1 == date2 || date1 == null || date2 == null) {
            TestCase.assertEquals(date1, date2);
        } else {
            assertDatesEqual(date1.getExactDate(), date2.getExactDate());
        }
    }
}
