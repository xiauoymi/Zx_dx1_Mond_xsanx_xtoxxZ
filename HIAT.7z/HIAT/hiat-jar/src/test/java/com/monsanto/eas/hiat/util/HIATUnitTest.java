package com.monsanto.eas.hiat.util;

import com.monsanto.eas.hiat.config.HIATConfigurationFactory;
import com.monsanto.eas.hiat.config.MockConfiguration;
import org.custommonkey.xmlunit.XMLTestCase;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public abstract class HIATUnitTest extends XMLTestCase {
  @Override
  protected void setUp() throws Exception {
    super.setUp();
    HIATConfigurationFactory.setConfiguration(new MockConfiguration());
  }
}