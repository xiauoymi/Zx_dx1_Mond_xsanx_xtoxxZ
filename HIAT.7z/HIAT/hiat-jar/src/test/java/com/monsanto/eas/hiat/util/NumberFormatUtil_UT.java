/*
 NumberFormatUtil_UT was created on Apr 27, 2009 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.hiat.util;

/**
 * @author rrmall
 */
public class NumberFormatUtil_UT extends HIATUnitTest {
  public void testFormatANumberThousandsSeperated_NumberHasManyDigits() throws Exception {
    long number = 123456789L;
    assertEquals("123,456,789", NumberFormatUtil.format(number));
  }

  public void testFormatANumberThousandsSeperated_SingleDigitNumber() throws Exception {
    long number = 2L;
    assertEquals("2", NumberFormatUtil.format(number));
  }

  public void testFormatANumberThousandsSeperated_NegativeNumber() throws Exception {
    long number = -1L;
    assertEquals("-1", NumberFormatUtil.format(number));
  }

}