package com.monsanto.eas.hiat.util;

import com.monsanto.ServletFramework.UCCHelper;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class TestUtil {
  @SuppressWarnings("unchecked")
  public static <T> T getRequestAttributeValue(UCCHelper helper, String attributeName) {
    return (T) helper.getRequestAttributeValue(attributeName);
  }
}
