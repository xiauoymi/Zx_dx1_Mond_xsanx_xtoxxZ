package com.monsanto.eas.hiat.view;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.analysis.HybridAnalysisDetail;
import com.monsanto.eas.hiat.analysis.HybridAnalysisParentDetail;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisDetailImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisImpl;
import com.monsanto.eas.hiat.analysis.hibernate.HybridAnalysisParentDetailImpl;
import com.monsanto.eas.hiat.availability.AvailDateTestUtil;
import com.monsanto.eas.hiat.availability.AvailabilityDate;
import com.monsanto.eas.hiat.availability.AvailabilityDateImpl;
import com.monsanto.eas.hiat.availability.SeasonCalculator;
import com.monsanto.eas.hiat.controller.mock.MockProductServiceConfiguredForNE5112v1;
import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.hibernate.ProductNameImpl;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.scenario.hibernate.ScenarioImpl;
import com.monsanto.eas.hiat.service.mock.mock.MockTraitService;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by vvvelu Date: Mar 10, 2009 Time: 1:53:03 PM
 */
public class HybridAnalysisXMLGenerator_UT extends HIATUnitTest {
  HybridAnalysisXMLGenerator hybridAnalysisXMLGenerator;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    hybridAnalysisXMLGenerator = new HybridAnalysisXMLGenerator(new MockProductServiceConfiguredForNE5112v1(), new MockTraitService());
  }

  public void testGetXmlContent_ReturnsDocument() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);

    List<HybridAnalysis> testListExpected = setupAnalysisDetails();
    Document document = hybridAnalysisXMLGenerator
        .getXmlContent(testListExpected, null, null, false, helper, new ArrayList<String>(0));

    assertXpathEvaluatesTo("", "//ANALYSIS/SCENARIO_CREATION_DATE", document);
    assertXpathEvaluatesTo("", "//ANALYSIS/SCENARIO_NAME", document);
    assertXpathEvaluatesTo("", "//ANALYSIS/SCENARIO_DESCRIPTION", document);

    assertAnalysisElements(document);

  }

  public void testNullAnalysisDoesNotCauseNPE() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);

    Collection<HybridAnalysis> analysisList = new LinkedList<HybridAnalysis>();
    analysisList.add(null);
    analysisList.add(null);
    analysisList.add(null);
    Document analysisDoc = hybridAnalysisXMLGenerator.getXmlContent(analysisList, null, null, false, helper, new ArrayList<String>(0));
    // we got here, so it didn't fail with an exception - which is what this test is really trying to prevent
    assertNotNull(analysisDoc);
  }


  public void testMissingProducts_AreInDocument() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    List<HybridAnalysis> testListExpected = setupAnalysisDetails();
    String testMissingProduct1 = "ABC123";
    String testMissingProduct2 = "XYZ989";
    Collection<String> missingProducts = new ArrayList<String>(0);
    missingProducts.add(testMissingProduct1);
    missingProducts.add(testMissingProduct2);
    Document document = hybridAnalysisXMLGenerator
        .getXmlContent(testListExpected, null, null, false, helper, missingProducts);

    assertXpathEvaluatesTo("1", "count(//MISSING_PRODUCTS)", document);
    assertXpathEvaluatesTo("2", "count(//MISSING_PRODUCTS/MISSING_PRODUCT)", document);
    assertXpathExists("//MISSING_PRODUCTS[MISSING_PRODUCT='" + testMissingProduct1 + "']", document);
    assertXpathExists("//MISSING_PRODUCTS[MISSING_PRODUCT='" + testMissingProduct2 + "']", document);
  }

  private void assertAnalysisElements(Document document) throws Exception {
    assertXpathEvaluatesTo("1", "count(//ANALYSIS)", document);
    assertXpathEvaluatesTo("1", "count(//PRODUCT)", document);
    assertXpathEvaluatesTo("2", "count(//PRODUCT_INFO)", document);

    assertXpathEvaluatesTo("1", "count(//SCENARIO_CREATION_DATE)", document);
    assertXpathEvaluatesTo("1", "count(//SCENARIO_NAME)", document);
    assertXpathEvaluatesTo("1", "count(//SCENARIO_DESCRIPTION)", document);

    final String product1Xpath = "//PRODUCT_INFO[TRAIT_CODE_MALE='WHM' and INBRED_MALE_TRAIT='HXCB' and TRAIT_CODE_FEMALE='CONV' and INBRED_FEMALE_TRAIT='CONV']";
    final String product2Xpath = "//PRODUCT_INFO[TRAIT_CODE_FEMALE='WHM' and INBRED_FEMALE_TRAIT='HXCB' and TRAIT_CODE_MALE='CONV' and INBRED_MALE_TRAIT='CONV']";
    assertXpathExists(product1Xpath, document);

    assertXpathEvaluatesTo("NE5112_v2", product1Xpath + "/HYBRID_MFG_NAME", document);
    assertXpathEvaluatesTo("WHM", product1Xpath + "/TRAIT_CODE", document);
    assertXpathEvaluatesTo("HX1", product1Xpath + "/TARGET_TRAIT_COMMERCIAL", document);
    assertXpathEvaluatesTo("HCL414_BASE", product1Xpath + "/MFG_INBRED_FEMALE", document);
    assertXpathEvaluatesTo("HCL119NRR1", product1Xpath + "/BASE_INBRED_FEMALE", document);
    assertXpathEvaluatesTo("+", product1Xpath + "/PLUS1", document);
    assertXpathEvaluatesTo("HCL119_BASE", product1Xpath + "/MFG_INBRED_MALE", document);
    assertXpathEvaluatesTo("HCL414NRR1", product1Xpath + "/BASE_INBRED_MALE", document);

    assertXpathEvaluatesTo("CONV", product1Xpath + "/COMMERCIAL_TRAIT_FEMALE", document);
    assertXpathEvaluatesTo("HX1", product1Xpath + "/COMMERCIAL_TRAIT_MALE", document);
    assertXpathEvaluatesTo("Spring 09", product1Xpath + "/PCM_HYBRID_150_DATE", document);
    assertXpathEvaluatesTo("Spring 09", product1Xpath + "/PCM_HYBRID_300_DATE", document);
    assertXpathEvaluatesTo("Spring 09", product1Xpath + "/COM_HYBRID_DATE", document);
    assertXpathEvaluatesTo("No", product1Xpath + "/SELECT_TO_SAVE", document);
    assertXpathEvaluatesTo("03-11-09", product1Xpath + "/FEMALE_GEN_0_DATE", document);
    assertXpathEvaluatesTo("03-11-09", product1Xpath + "/FEMALE_GEN_1_DATE", document);
    assertXpathEvaluatesTo("03-11-09", product1Xpath + "/FEMALE_GEN_2_DATE", document);
    assertXpathEvaluatesTo("+", product1Xpath + "/PLUS2", document);
    assertXpathEvaluatesTo("03-11-09", product1Xpath + "/MALE_GEN_0_DATE", document);
    assertXpathEvaluatesTo("03-11-09", product1Xpath + "/MALE_GEN_1_DATE", document);
    assertXpathEvaluatesTo("03-11-09", product1Xpath + "/MALE_GEN_2_DATE", document);


    assertXpathEvaluatesTo("NE5112_v2", product2Xpath + "/HYBRID_MFG_NAME", document);
    assertXpathEvaluatesTo("WHM", product2Xpath + "/TRAIT_CODE", document);
    assertXpathEvaluatesTo("HX1", product2Xpath + "/COMMERCIAL_TRAIT_FEMALE", document);
    assertXpathEvaluatesTo("CONV", product2Xpath + "/COMMERCIAL_TRAIT_MALE", document);
    assertXpathEvaluatesTo("HCL414_BASE", product2Xpath + "/MFG_INBRED_FEMALE", document);
    assertXpathEvaluatesTo("HCL119NRR1", product2Xpath + "/BASE_INBRED_FEMALE", document);
    assertXpathEvaluatesTo("+", product2Xpath + "/PLUS2", document);
    assertXpathEvaluatesTo("HCL119_BASE", product2Xpath + "/MFG_INBRED_MALE", document);
    assertXpathEvaluatesTo("HCL414NRR1", product2Xpath + "/BASE_INBRED_MALE", document);

    assertXpathEvaluatesTo("Spring 09", product2Xpath + "/PCM_HYBRID_150_DATE", document);
    assertXpathEvaluatesTo("Spring 09", product2Xpath + "/PCM_HYBRID_300_DATE", document);
    assertXpathEvaluatesTo("Spring 09", product2Xpath + "/COM_HYBRID_DATE", document);
    assertXpathEvaluatesTo("03-11-09", product2Xpath + "/FEMALE_GEN_0_DATE", document);
    assertXpathEvaluatesTo("03-11-09", product2Xpath + "/FEMALE_GEN_1_DATE", document);
    assertXpathEvaluatesTo("03-11-09", product2Xpath + "/FEMALE_GEN_2_DATE", document);
    assertXpathEvaluatesTo("+", product2Xpath + "/PLUS2", document);
    assertXpathEvaluatesTo("03-11-09", product2Xpath + "/MALE_GEN_0_DATE", document);
    assertXpathEvaluatesTo("03-11-09", product2Xpath + "/MALE_GEN_1_DATE", document);
    assertXpathEvaluatesTo("03-11-09", product2Xpath + "/MALE_GEN_2_DATE", document);
  }

  public void testGetXmlContent_ForSavedScenario() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);

    Scenario scenario = getTestScenario();
    List<HybridAnalysis> testListExpected = setupAnalysisDetails();
    Document document = hybridAnalysisXMLGenerator
        .getXmlContent(testListExpected, scenario, "http://w3devel.kerberos.monsanto.com:8080/hiat", true,
            helper, new ArrayList<String>(0));

    assertXpathEvaluatesTo("1", "count(//LINK)", document);
    NodeList listByTagName = DOMUtil.getNodeListByTagName(document, "LINK");
    Node childNode = listByTagName.item(0);
    String childNodeValue = childNode.getNodeValue();
    assertTrue(StringUtils.contains(childNodeValue,
        "http://w3devel.kerberos.monsanto.com:8080/hiat/servlet/scenario?method=lookupScenario"));
    assertTrue(StringUtils.contains(childNodeValue, "scenarioId=123"));
    assertXpathEvaluatesTo("03-11-09", "//ANALYSIS/SCENARIO_CREATION_DATE", document);
    assertXpathEvaluatesTo("03-11-09", "//ANALYSIS/SCENARIO_CREATION_DATE", document);
    assertXpathEvaluatesTo("scenario name 1", "//ANALYSIS/SCENARIO_NAME", document);
    assertXpathEvaluatesTo("scenario desc 1", "//ANALYSIS/SCENARIO_DESCRIPTION", document);
    assertAnalysisElements(document);
  }

  private Scenario getTestScenario() {
    return new ScenarioImpl(123L, "testId", "scenario name 1", "scenario desc 1", getTestDate().getExactDate(), false,
        null, null, null);
  }

  private List<HybridAnalysis> setupAnalysisDetails() {
    List<HybridAnalysis> testListExpected = new ArrayList<HybridAnalysis>();
    ProductImpl product5 = getTestProductToVerifyAnalysisDetails();

    Trait traitOne = getTestTrait();
    Trait conventionalTrait = getConventionalTrait();
    Set<HybridAnalysisDetail> detail = new HashSet<HybridAnalysisDetail>();

    HybridAnalysisDetail hybridAnalysisDetailForTraitCONV = getHybridAnalysisDetailForCONVTrait(traitOne,
        conventionalTrait);
    detail.add(hybridAnalysisDetailForTraitCONV);
    HybridAnalysisDetail hybridAnalysisDetailForTraitWHM = getHybridAnalysisDetailForTraitWHM(traitOne,
        conventionalTrait);
    detail.add(hybridAnalysisDetailForTraitWHM);
    HybridAnalysis hybridAnalysis = new HybridAnalysisImpl(product5, traitOne, detail);
    testListExpected.add(hybridAnalysis);
    return testListExpected;
  }

  private HybridAnalysisDetail getHybridAnalysisDetailForTraitWHM(Trait traitOne, Trait conventionalTrait) {
    AvailabilityDate testDate = getTestDate();
    HybridAnalysisParentDetail femaleDetailForTraitWHM = new HybridAnalysisParentDetailImpl(null, traitOne, testDate, testDate, testDate);
    HybridAnalysisParentDetail maleDetailForTraitWHM = new HybridAnalysisParentDetailImpl(null, conventionalTrait, testDate, testDate, testDate);

    return new HybridAnalysisDetailImpl(maleDetailForTraitWHM, femaleDetailForTraitWHM,
        new SeasonCalculator().calculateSeasonForPrimaryCommercial(testDate.getExactDate()),
            new SeasonCalculator().calculateSeasonForPrimaryCommercial(testDate.getExactDate()),
            new SeasonCalculator().calculateSeasonForPrimaryCommercial(testDate.getExactDate()));
  }

  private AvailabilityDate getTestDate() {
    DateFormat dateFormat = new SimpleDateFormat("MM-dd-yy");
    Date testDate = null;
    try {
      testDate = dateFormat.parse("03-11-09");
    } catch (ParseException e) {
      e.printStackTrace();
    }
    return new AvailabilityDateImpl(AvailDateTestUtil.TEST_DATE_SOURCE, testDate, false);
  }

  private HybridAnalysisDetail getHybridAnalysisDetailForCONVTrait(Trait traitOne, Trait conventionalTrait) {
    AvailabilityDate testDate = getTestDate();
    HybridAnalysisParentDetail femaleDetailForTraitCONV = new HybridAnalysisParentDetailImpl(null, conventionalTrait, testDate, testDate, testDate);
    HybridAnalysisParentDetail maleDetailForTraitCONV = new HybridAnalysisParentDetailImpl(null, traitOne, testDate, testDate, testDate);

    return new HybridAnalysisDetailImpl(maleDetailForTraitCONV, femaleDetailForTraitCONV,
        new SeasonCalculator().calculateSeasonForPrimaryCommercial(testDate.getExactDate()),
            new SeasonCalculator().calculateSeasonForPrimaryCommercial(testDate.getExactDate()),
            new SeasonCalculator().calculateSeasonForPrimaryCommercial(testDate.getExactDate()));
  }

  private Trait getConventionalTrait() {
    return new MockTrait(0L, "CONV", "CONV", "CONV", null, true);
  }

  private Trait getTestTrait() {
    return new MockTrait(1L, "WHM", "HXCB", "HX1", null, true);
  }

  private ProductImpl getTestProductToVerifyAnalysisDetails() {
    AvailabilityDate testDate = getTestDate();
    ProductImpl baseProduct1 = new ProductImpl(7L, "BASE 1", new MockTrait("BASE 1"), null, null,
        testDate.getExactDate(), testDate.getExactDate(), true, null, null,
        false);
    ProductImpl baseProduct2 = new ProductImpl(8L, "BASE 2", new MockTrait("BASE 2"), null, null,
        testDate.getExactDate(), testDate.getExactDate(), true, null, null,
        false);

    ProductName baseMfgNameForProd1 = new ProductNameImpl(71L, "HCL119_BASE", baseProduct1, DataSource.PREFOUNDATION,
        "1", ProductNameType.BASE_MANUFACTURING);
    ProductName baseMfgNameForProd2 = new ProductNameImpl(81L, "HCL414_BASE", baseProduct2, DataSource.PREFOUNDATION,
        "1", ProductNameType.BASE_MANUFACTURING);
    ProductName basePreCommNameForProd1 = new ProductNameImpl(711L, "HCL119NRR1", baseProduct1,
        DataSource.PREFOUNDATION, "1", ProductNameType.BASE_PRECOMMERCIAL);
    ProductName basePreCommNameForProd2 = new ProductNameImpl(811L, "HCL414NRR1", baseProduct2,
        DataSource.PREFOUNDATION, "1", ProductNameType.BASE_PRECOMMERCIAL);

    Map<ProductNameType, ProductName> productNamesForProd1 = new HashMap<ProductNameType, ProductName>();
    Map<ProductNameType, ProductName> productNamesForProd2 = new HashMap<ProductNameType, ProductName>();
    productNamesForProd1.put(ProductNameType.BASE_MANUFACTURING, baseMfgNameForProd2);
    productNamesForProd1.put(ProductNameType.BASE_PRECOMMERCIAL, basePreCommNameForProd1);
    baseProduct1.setProductNames(productNamesForProd1);

    productNamesForProd2.put(ProductNameType.BASE_MANUFACTURING, baseMfgNameForProd1);
    productNamesForProd2.put(ProductNameType.BASE_PRECOMMERCIAL, basePreCommNameForProd2);
    baseProduct2.setProductNames(productNamesForProd2);

    ProductImpl product3 = new ProductImpl(3L, "1", new MockTrait("PPTX"), null, null, null, null, false, baseProduct1,
        null, false);
    ProductImpl product4 = new ProductImpl(4L, "1", new MockTrait("QQTX"), null, null, null, null, false, baseProduct2,
        null, false);

    ProductImpl product5 = new ProductImpl(5L, "1", new MockTrait("SSTX"), product3, product4, testDate.getExactDate(),
        testDate.getExactDate(), true, null
        , null, false);
    ProductName baseMfgNameForProd5 = new ProductNameImpl(51L, "NE5112_v2", product5, DataSource.PREFOUNDATION, "1",
        ProductNameType.BASE_MANUFACTURING);
    Map<ProductNameType, ProductName> productNamesForProd5 = new HashMap<ProductNameType, ProductName>();
    productNamesForProd5.put(ProductNameType.BASE_MANUFACTURING, baseMfgNameForProd5);
    product5.setProductNames(productNamesForProd5);
    return product5;
  }


  public void testGetXmlContent_FewDetailsAreChecked_SelectedEntryInXMLForTheseDetailsIsSetToYes() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);

    Collection<HybridAnalysis> testListExpected = setupAnalysisDetails();
    //product id, trait id, female trait id, male trait id
    helper.setRequestParameterValue(HybridAnalysisXMLGenerator.SELECTED_ANALYSIS_DETAILS_CHKBX,
        new String[]{"5, 1, 1, 0"});
    hybridAnalysisXMLGenerator = new HybridAnalysisXMLGenerator(new MockProductServiceForHybridXMLGenerator(), new MockTraitServiceForHybridXMLGenerator());
    Document document = hybridAnalysisXMLGenerator
        .getXmlContent(testListExpected, null, null, false, helper, new ArrayList<String>(0));

    assertXpathEvaluatesTo("", "//ANALYSIS/SCENARIO_CREATION_DATE", document);
    assertXpathEvaluatesTo("", "//ANALYSIS/SCENARIO_NAME", document);
    assertXpathEvaluatesTo("", "//ANALYSIS/SCENARIO_DESCRIPTION", document);

    assertXpathEvaluatesTo("1", "count(//ANALYSIS)", document);
    assertXpathEvaluatesTo("1", "count(//PRODUCT)", document);
    assertXpathEvaluatesTo("2", "count(//PRODUCT_INFO)", document);

    assertXpathEvaluatesTo("1", "count(//SCENARIO_CREATION_DATE)", document);
    assertXpathEvaluatesTo("1", "count(//SCENARIO_NAME)", document);
    assertXpathEvaluatesTo("1", "count(//SCENARIO_DESCRIPTION)", document);

    final String product1Xpath = "//PRODUCT_INFO[TRAIT_CODE_MALE='WHM' and INBRED_MALE_TRAIT='HXCB' and TRAIT_CODE_FEMALE='CONV' and INBRED_FEMALE_TRAIT='CONV']";
    final String product2Xpath = "//PRODUCT_INFO[TRAIT_CODE_FEMALE='WHM' and INBRED_FEMALE_TRAIT='HXCB' and TRAIT_CODE_MALE='CONV' and INBRED_MALE_TRAIT='CONV']";
    assertXpathExists(product1Xpath, document);

    assertXpathEvaluatesTo("No", product1Xpath + "/SELECT_TO_SAVE", document);
    assertXpathEvaluatesTo("Yes", product2Xpath + "/SELECT_TO_SAVE", document);
  }

  private class MockProductServiceForHybridXMLGenerator extends MockProductServiceConfiguredForNE5112v1 {
    @Override
    public Product lookupProductById(Long id) {
      if (id.longValue() == 5L){
        return getTestProductToVerifyAnalysisDetails();
      }
      return super.lookupProductById(id);
    }
  }

  private class MockTraitServiceForHybridXMLGenerator extends MockTraitService {
    public Trait lookupTraitById(Long id) {
      if (id.longValue() == 0L) {
        return getConventionalTrait();
      }
      return getTestTrait(1);
    }
  }
}