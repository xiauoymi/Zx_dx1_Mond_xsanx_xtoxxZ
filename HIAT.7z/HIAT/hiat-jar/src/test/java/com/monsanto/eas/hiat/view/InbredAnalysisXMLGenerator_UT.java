package com.monsanto.eas.hiat.view;

import com.monsanto.eas.hiat.analysis.InbredAnalysis;
import com.monsanto.eas.hiat.analysis.InbredAnalysisImpl;
import com.monsanto.eas.hiat.availability.*;
import com.monsanto.eas.hiat.model.DataSource;
import com.monsanto.eas.hiat.model.ProductName;
import com.monsanto.eas.hiat.model.ProductNameType;
import com.monsanto.eas.hiat.model.Trait;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.hibernate.ProductNameImpl;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import org.w3c.dom.Document;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredAnalysisXMLGenerator_UT extends HIATUnitTest {
  private Date date = AvailDateTestUtil.randomFutureDate();

  public void testGetXmlContent() throws Exception {
    Collection<InbredAnalysis> testListExpected = new ArrayList<InbredAnalysis>();

    String testTraitCode = "ABC";
    String testEventGroup = "ABCDEFG";
    String testTraitCommName = "ALPHA";

    ProductImpl testProduct = new ProductImpl(1L, "TEST", new MockTrait(12L, "XYZ", "BDH", "BDH", null, true), null, null, null, null, false, null,
            "Primary", false);
    ProductName traitedPreCommForProd5 = new ProductNameImpl(53L, "DKC112", testProduct, DataSource.PREFOUNDATION, "1", ProductNameType.TRAITED_PRECOMMERCIAL);
    String expectedBaseMfgName = "NE5112_v2";
    ProductName baseMfgNameForProd5 = new ProductNameImpl(51L, expectedBaseMfgName, testProduct, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING);
    String expectedBasePreCommName = "NE5112NRR1";
    ProductName preCommNameForProd5 = new ProductNameImpl(52L, expectedBasePreCommName, testProduct, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_PRECOMMERCIAL);
    Map<ProductNameType, ProductName> productNamesForProd5 = new HashMap<ProductNameType, ProductName>();
    productNamesForProd5.put(ProductNameType.BASE_MANUFACTURING, baseMfgNameForProd5);
    productNamesForProd5.put(ProductNameType.TRAITED_PRECOMMERCIAL, traitedPreCommForProd5);
    productNamesForProd5.put(ProductNameType.BASE_PRECOMMERCIAL, preCommNameForProd5);
    testProduct.setProductNames(productNamesForProd5);

    Trait testTrait = new MockTrait(1L, testTraitCode, testEventGroup, testTraitCommName, new HashSet<Trait>(), true);
    AvailabilityDateImpl testAvailDate = new AvailabilityDateImpl("test", date);
    InbredAvailabilityInformation testInbredInfo = new InbredAvailabilityInformation(testAvailDate, testAvailDate, testAvailDate);
    HybridAvailabilityInformation testHybridInfo = new HybridAvailabilityInformation(testAvailDate, testAvailDate, testAvailDate);
    InbredAnalysis analysis = new InbredAnalysisImpl(testProduct, testTrait, Boolean.TRUE, testInbredInfo, new HybridAvailabilitySeasonInformation(testHybridInfo, date));
    testListExpected.add(analysis);

    InbredAnalysisXMLGenerator xmlGenerator = new InbredAnalysisXMLGenerator();
    Document document = xmlGenerator.getXmlContent(testListExpected, new ArrayList<String>(0));

    assertXpathEvaluatesTo("1", "count(//ANALYSIS)", document);

    DateFormat df = new SimpleDateFormat(AnalysisXMLGenerator.DATE_FORMAT);
    String expectedDateString = df.format(testAvailDate.getExactDate());
    SeasonCalculator seasonCalc = new SeasonCalculator();
    String pcmSeasonString = seasonCalc.calculateSeasonForPCM(testAvailDate.getExactDate()).toString();
    String commSeasonString = seasonCalc.calculateSeason(testAvailDate.getExactDate(), testAvailDate.getExactDate()).toString();
    assertXpathEvaluatesTo(expectedBaseMfgName, "//ANALYSIS/BASE_MFG_INBRED", document);
    assertXpathEvaluatesTo(expectedBasePreCommName, "//ANALYSIS/PRECOMMERCIAL_INBRED", document);
    assertXpathEvaluatesTo(testTraitCode, "//ANALYSIS/TRAIT_CODE", document);
    assertXpathEvaluatesTo(testTraitCommName, "//ANALYSIS/TRAIT_COMMERCIAL", document);
    assertXpathEvaluatesTo(testEventGroup, "//ANALYSIS/EVENT_GROUP", document);
    assertXpathEvaluatesTo("YES", "//ANALYSIS/HAS_PRIMARY", document);
    assertXpathEvaluatesTo(expectedDateString, "//ANALYSIS/GEN0_DATE", document);
    assertXpathEvaluatesTo(expectedDateString, "//ANALYSIS/GEN1_DATE", document);
    assertXpathEvaluatesTo(expectedDateString, "//ANALYSIS/GEN2_DATE", document);
    assertXpathEvaluatesTo(pcmSeasonString, "//ANALYSIS/PCM150_SEASON", document);
    assertXpathEvaluatesTo(pcmSeasonString, "//ANALYSIS/PCM300_SEASON", document);
    assertXpathEvaluatesTo(commSeasonString, "//ANALYSIS/COMMERCIAL_SEASON", document);
  }
}