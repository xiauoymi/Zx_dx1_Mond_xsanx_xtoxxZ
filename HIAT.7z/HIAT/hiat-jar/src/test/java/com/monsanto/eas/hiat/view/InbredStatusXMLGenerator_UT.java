package com.monsanto.eas.hiat.view;

import com.monsanto.eas.hiat.analysis.InbredStatusDetailImpl;
import com.monsanto.eas.hiat.analysis.InbredStatusDetail;
import com.monsanto.eas.hiat.analysis.*;
import com.monsanto.eas.hiat.availability.AvailDateTestUtil;
import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.hibernate.InventoryEntryImpl;
import com.monsanto.eas.hiat.model.hibernate.ProductImpl;
import com.monsanto.eas.hiat.model.hibernate.ProductNameImpl;
import com.monsanto.eas.hiat.model.hibernate.ProductionEntryImpl;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import org.apache.commons.lang.time.DateFormatUtils;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.*;

/**
 * Created by vvvelu Date: Mar 12, 2009 Time: 4:08:32 PM
 */
public class InbredStatusXMLGenerator_UT extends XMLTestCase {
  Date date = AvailDateTestUtil.randomFutureDate();

  public void testGetXmlContent() throws Exception {
    Collection<InbredStatus> testListExpected = setupAnalysisDetails();
    InbredStatusXMLGenerator xmlGenerator = new InbredStatusXMLGenerator();
    Document document = xmlGenerator.getXmlContent(testListExpected, new ArrayList<String>(0));

    assertXpathEvaluatesTo("1", "count(//ANALYSIS)", document);
    assertXpathEvaluatesTo("1", "count(//PRODUCT)", document);
    assertXpathEvaluatesTo("1", "count(//PRODUCT_INFO)", document);

    assertXpathEvaluatesTo("-", "//PRODUCT_INFO/MFG_INBRED_FEMALE[1]", document);
    assertXpathEvaluatesTo("NE5112NRR1", "//PRODUCT_INFO/BASE_INBRED_FEMALE[1]", document);
    assertXpathEvaluatesTo("DKC112", "//PRODUCT_INFO/PRECOMMERCIAL_INBRED[1]", document);
    assertXpathEvaluatesTo("TEST", "//PRODUCT_INFO/TRAIT_VERSION[1]", document);
    assertXpathEvaluatesTo("Primary", "//PRODUCT_INFO/STATUS[1]", document);
    assertXpathEvaluatesTo("CHC", "//PRODUCT_INFO/TRAIT_CODE[1]", document);
    assertXpathEvaluatesTo("AABBCC", "//PRODUCT_INFO/TRAIT_COMMERCIAL[1]", document);
    assertXpathEvaluatesTo("ABC-DEF", "//PRODUCT_INFO/EVENT_GROUP[1]", document);
    assertXpathEvaluatesTo("01/11/2009", "//PRODUCT_INFO/TI/HAND_OFF_DATE[1]", document);
    assertXpathEvaluatesTo("03/01/2009", "//PRODUCT_INFO/TI/PRIMARY_DATE[1]", document);
    assertXpathEvaluatesTo("30", "//PRODUCT_INFO/PFND/INV_QTY[1]", document);
    assertXpathEvaluatesTo("33", "//PRODUCT_INFO/PFND/PROD_QTY[1]", document);
    assertXpathEvaluatesTo(DateFormatUtils.format(date, "MM/dd/yyyy"), "//PRODUCT_INFO/PFND/PROD_AVAIL_DATE[1]", document);
    assertXpathEvaluatesTo("10", "//PRODUCT_INFO/GEN1/INV_QTY[1]", document);
    assertXpathEvaluatesTo("11", "//PRODUCT_INFO/GEN1/PROD_QTY[1]", document);
    assertXpathEvaluatesTo(DateFormatUtils.format(date, "MM/dd/yyyy"), "//PRODUCT_INFO/GEN1/PROD_AVAIL_DATE[1]", document);
    assertXpathEvaluatesTo("", "//PRODUCT_INFO/GEN1/PLANNED_PROD_QTY[1]", document);
    assertXpathEvaluatesTo("", "//PRODUCT_INFO/GEN1/PLANNED_PROD_AVAIL_DATE[1]", document);
    assertXpathEvaluatesTo("20", "//PRODUCT_INFO/GEN2/INV_QTY[1]", document);
    assertXpathEvaluatesTo("22", "//PRODUCT_INFO/GEN2/PROD_QTY[1]", document);
    assertXpathEvaluatesTo(DateFormatUtils.format(date, "MM/dd/yyyy"), "//PRODUCT_INFO/GEN2/PROD_AVAIL_DATE[1]", document);
    assertXpathEvaluatesTo("", "//PRODUCT_INFO/GEN2/PLANNED_PROD_QTY[1]", document);
    assertXpathEvaluatesTo("", "//PRODUCT_INFO/GEN2/PLANNED_PROD_AVAIL_DATE[1]", document);
  }

  private Collection<InbredStatus> setupAnalysisDetails() {
    Date testHandoffDate = new GregorianCalendar(2009, Calendar.JANUARY, 11).getTime();
      Date testPrimaryTestingDate = new GregorianCalendar(2009, Calendar.MARCH, 1).getTime();

    ProductImpl testProduct = new ProductImpl(1L, "TEST", new MockTrait(12L,"XYZ", "BDH", "BDH", null, true), null, null, testHandoffDate, testPrimaryTestingDate, false, null,
        "Primary", false);
    ProductName traitedPreCommForProd5 = new ProductNameImpl(53L, "DKC112", testProduct, DataSource.PREFOUNDATION, "1", ProductNameType.TRAITED_PRECOMMERCIAL);
    ProductName baseMfgNameForProd5 = new ProductNameImpl(51L, "NE5112_v2", testProduct, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_MANUFACTURING);
    ProductName preCommNameForProd5 = new ProductNameImpl(52L, "NE5112NRR1", testProduct, DataSource.PREFOUNDATION, "1", ProductNameType.BASE_PRECOMMERCIAL);
    Map<ProductNameType, ProductName> productNamesForProd5 = new HashMap<ProductNameType, ProductName>();
    productNamesForProd5.put(ProductNameType.BASE_MANUFACTURING, baseMfgNameForProd5);
    productNamesForProd5.put(ProductNameType.TRAITED_PRECOMMERCIAL, traitedPreCommForProd5);
    productNamesForProd5.put(ProductNameType.BASE_PRECOMMERCIAL, preCommNameForProd5);
    testProduct.setProductNames(productNamesForProd5);



    Trait trait = new MockTrait(2L, "CHC", "ABC-DEF", "AABBCC", null, true);
    Map<InventoryType, InventoryEntry> inventoryQuantities = new HashMap<InventoryType, InventoryEntry>();
    inventoryQuantities.put(InventoryType.GENERATION_1, new InventoryEntryImpl(testProduct, 10,  InventoryType.GENERATION_1));
    inventoryQuantities.put(InventoryType.GENERATION_2,  new InventoryEntryImpl(testProduct, 20,  InventoryType.GENERATION_2));
    inventoryQuantities.put(InventoryType.PREFOUNDATION,  new InventoryEntryImpl(testProduct, 30,  InventoryType.PREFOUNDATION));

    Map<InventoryType, Collection<ProductionEntry>> productionQuantities = new HashMap<InventoryType, Collection<ProductionEntry>>();
    productionQuantities.put(InventoryType.GENERATION_1, singleEntryCollection(new ProductionEntryImpl(date, null, 11, InventoryType.GENERATION_1, false)));
    productionQuantities.put(InventoryType.GENERATION_2, singleEntryCollection(new ProductionEntryImpl(date, null, 22, InventoryType.GENERATION_2, false)));
    productionQuantities.put(InventoryType.PREFOUNDATION, singleEntryCollection(new ProductionEntryImpl(date, null, 33, InventoryType.PREFOUNDATION, false)));

    Set<InbredStatusDetail> testDetailSet = new HashSet<InbredStatusDetail>();


    InbredStatusDetail testDetail = new InbredStatusDetailImpl(trait, testProduct, testHandoffDate, testPrimaryTestingDate,
        inventoryQuantities, productionQuantities, new HashMap<InventoryType, Collection<ProductionEntry>>());
    testDetailSet.add(testDetail);
    InbredStatus status = new InbredStatusImpl(testProduct, testDetailSet);
    Collection<InbredStatus> statusList = new ArrayList<InbredStatus>();
    statusList.add(status);
    return statusList;
  }

  private Collection<ProductionEntry> singleEntryCollection(ProductionEntryImpl productionEntry) {
    Collection<ProductionEntry> coll = new LinkedList<ProductionEntry>();
    coll.add(productionEntry);
    return coll;
  }
}
