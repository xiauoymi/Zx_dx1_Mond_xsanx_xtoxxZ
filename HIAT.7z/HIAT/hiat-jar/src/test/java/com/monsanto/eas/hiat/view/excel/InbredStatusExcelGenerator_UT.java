package com.monsanto.eas.hiat.view.excel;

import com.monsanto.eas.hiat.analysis.InbredStatus;
import com.monsanto.eas.hiat.analysis.InbredStatusDetail;
import com.monsanto.eas.hiat.analysis.InbredStatusDetailImpl;
import com.monsanto.eas.hiat.analysis.InbredStatusImpl;
import com.monsanto.eas.hiat.model.*;
import com.monsanto.eas.hiat.model.mock.MockProduct;
import com.monsanto.eas.hiat.model.mock.MockTrait;
import com.monsanto.eas.hiat.util.HIATUnitTest;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class InbredStatusExcelGenerator_UT extends HIATUnitTest {
  private OutputStream dummyStream = new ByteArrayOutputStream();

  public void testCreateWorkbookCalled() throws Exception {
    MockInbredStatusExcelGeneratorForCreateWorkbook generator = new MockInbredStatusExcelGeneratorForCreateWorkbook();
    generator.generateStatusWorkbook(dummyStream, new LinkedList<InbredStatus>(), new LinkedList<String>());
    assertTrue(generator.wasCreateWorkbookCalled());
  }

  public void testCorrectTemplateIsUsed() throws Exception {
    MockInbredStatusExcelGeneratorForCreateWorkbook generator = new MockInbredStatusExcelGeneratorForCreateWorkbook();
    generator.generateStatusWorkbook(dummyStream, new LinkedList<InbredStatus>(), new LinkedList<String>());
    assertEquals(InbredStatusExcelGenerator.TEMPLATE_LOCATION, generator.getTemplateLocationPassed());
  }

  public void testExportStatusListIsUsed() throws Exception {
    MockInbredStatusExcelGeneratorForCreateWorkbook generator = new MockInbredStatusExcelGeneratorForCreateWorkbook();
    generator.generateStatusWorkbook(dummyStream, new LinkedList<InbredStatus>(), new LinkedList<String>());
    Map<String, Object> paramMap = generator.getParamMappingPassed();
    assertNotNull(paramMap);
    assertNotNull(paramMap.get("status"));
  }

  public void testMissingProductsListIsUsed() throws Exception {
    MockInbredStatusExcelGeneratorForCreateWorkbook generator = new MockInbredStatusExcelGeneratorForCreateWorkbook();
    LinkedList<String> missingList = new LinkedList<String>();
    String testMissing = "ABCQWERTY";
    missingList.add(testMissing);
    generator.generateStatusWorkbook(dummyStream, new LinkedList<InbredStatus>(), missingList);
    Map<String, Object> paramMap = generator.getParamMappingPassed();
    assertNotNull(paramMap);

    @SuppressWarnings("unchecked")
    List<String> missingListFromParams = (List<String>) paramMap.get("missing");

    assertNotNull(missingListFromParams);
    assertTrue(missingListFromParams.contains(testMissing));
  }

  public void testWorkbookIsGenerated() throws Exception {
    InbredStatusExcelGenerator generator = new InbredStatusExcelGenerator();
    ByteArrayOutputStream testStream = new ByteArrayOutputStream();
    generator.generateStatusWorkbook(testStream, new LinkedList<InbredStatus>(), new LinkedList<String>());
    assertTrue("Expected non-empty stream", testStream.size() > 0);
  }

  public void testWorkbookIsWritten() throws Exception {
    MockInbredStatusExcelGeneratorForCreateWorkbook generator = new MockInbredStatusExcelGeneratorForCreateWorkbook();
    generator.generateStatusWorkbook(dummyStream, new LinkedList<InbredStatus>(), new LinkedList<String>());
    assertTrue("Expected workbook to be written", generator.wasWorkbookWritten());
  }

  public void testCorrectExportStatusListIsGenerated() throws Exception {
    MockInbredStatusExcelGeneratorForCreateWorkbook generator = new MockInbredStatusExcelGeneratorForCreateWorkbook();
    Collection<InbredStatus> results = getTestResults();
    generator.generateStatusWorkbook(dummyStream, results, new LinkedList<String>());
    Map<String, Object> paramMap = generator.getParamMappingPassed();
    assertNotNull(paramMap);

    @SuppressWarnings("unchecked")
    List<ExcelExportStatus> exportStatusList = (List<ExcelExportStatus>) paramMap.get("status");
    assertNotNull(exportStatusList);

    List<InbredStatusDetail> details = getDetailsFromResults(results);
    assertEquals(details.size(), exportStatusList.size());

    for (int i = 0; i < details.size(); i++) {
      InbredStatusDetail detail = details.get(i);
      ExcelExportStatus exportStatus = exportStatusList.get(i);
      assertExportRowIsCorrect("Mismatch at index " + i, detail, exportStatus);
    }
  }

  private void assertExportRowIsCorrect(String msg, InbredStatusDetail expected, ExcelExportStatus export) {
    if (expected == null || export == null) {
      assertNull(msg, expected);
      assertNull(msg, export);
      return;
    }

    Product expectedProduct = expected.getProduct();
    Trait expectedTrait = expectedProduct.getTrait();

    assertEquals(msg, expectedProduct.getProductName(ProductNameType.BASE_MANUFACTURING), export.getBaseMfgInbred());
    assertEquals(msg, expectedProduct.getProductName(ProductNameType.BASE_PRECOMMERCIAL), export.getBasePCMInbred());
    assertEquals(msg, expectedProduct.getProductName(ProductNameType.TRAITED_PRECOMMERCIAL), export.getPreCommTraitedInbred());
    assertEquals(msg, expectedProduct.getProductName(ProductNameType.MANUFACTURING), export.getMfgTraitedInbred());

    assertEquals(msg, expectedProduct.getTraitVersion(), export.getVersion());
    assertEquals(msg, expectedProduct.getStatus(), export.getStatus());

    assertEquals(msg, expectedTrait.getCode(), export.getTraitCode());
    assertEquals(msg, expectedTrait.getCommercialName(), export.getTraitCommercialName());
    assertEquals(msg, expectedTrait.getFullName(), export.getTraitFullName());

    assertEquals(msg, expected.getHandoffDate(), export.getHoDate());
    assertEquals(msg, expected.getPrimaryDate(), export.getPrimaryDate());

    assertEquals(msg, new Long(expected.getInventory(InventoryType.PREFOUNDATION)), export.getPfndInvQty());
    ProductionEntry pfndEntry = expected.getTotalProductionQuantities().get(InventoryType.PREFOUNDATION);
    assertProductEntryEqual(msg, pfndEntry, export.getPfndProdQty(), export.getPfndProdAvailDate());

    ProductionEntry gen1PlanEntry = expected.getTotalProductionQuantities().get(InventoryType.GENERATION_1);
    ProductionEntry gen1ProdEntry = expected.getTotalPlannedProductionQuantities().get(InventoryType.GENERATION_1);
    assertProductEntryEqual(msg, gen1PlanEntry, export.getGen1PlanQty(), export.getGen1PlanAvailDate());
    assertProductEntryEqual(msg, gen1ProdEntry, export.getGen1ProdQty(), export.getGen1ProdAvailDate());
    assertEquals(msg, new Long(expected.getInventory(InventoryType.GENERATION_1)), export.getGen1InvQty());

    ProductionEntry gen2PlanEntry = expected.getTotalProductionQuantities().get(InventoryType.GENERATION_2);
    ProductionEntry gen2ProdEntry = expected.getTotalPlannedProductionQuantities().get(InventoryType.GENERATION_2);
    assertProductEntryEqual(msg, gen2PlanEntry, export.getGen2PlanQty(), export.getGen2PlanAvailDate());
    assertProductEntryEqual(msg, gen2ProdEntry, export.getGen2ProdQty(), export.getGen2ProdAvailDate());
    assertEquals(msg, new Long(expected.getInventory(InventoryType.GENERATION_2)), export.getGen2InvQty());
  }

  private void assertProductEntryEqual(String msg, ProductionEntry expected, Long actualQty, Date actualDate) {
    if (expected == null) {
      assertNull(msg, actualQty);
      assertNull(msg, actualDate);
    } else {
      if (actualQty == null) {
        assertEquals(msg, expected.getQuantity(), 0L);
      } else {
        assertEquals(msg, expected.getQuantity(), actualQty.longValue());
      }
      if (actualDate == null) {
        assertNull(msg, expected.getAvailableDate());
      } else {
        assertEquals(msg, expected.getAvailableDate(), actualDate);
      }
    }
  }

  private static class MockInbredStatusExcelGeneratorForCreateWorkbook extends InbredStatusExcelGenerator {
    private String templateLocationPassed = null;
    private Map<String, Object> paramMappingPassed = null;
    private boolean wasCreateWorkbookCalled = false;
    private boolean wasWorkbookWritten = false;

    @Override
    protected HSSFWorkbook createWorkbook(String templateLocation, Map<String, Object> paramMapping) {
      this.templateLocationPassed = templateLocation;
      this.paramMappingPassed = paramMapping;
      this.wasCreateWorkbookCalled = true;
      return new MockWorkbook();
    }

    public String getTemplateLocationPassed() {
      return templateLocationPassed;
    }

    public Map<String, Object> getParamMappingPassed() {
      return paramMappingPassed;
    }

    public boolean wasCreateWorkbookCalled() {
      return wasCreateWorkbookCalled;
    }

    public boolean wasWorkbookWritten() {
      return wasWorkbookWritten;
    }

    private class MockWorkbook extends HSSFWorkbook {
      @Override
      public void write(OutputStream outputStream) throws IOException {
        wasWorkbookWritten = true;
      }
    }
  }


/*
  public void testMissingProductsArePresent() throws Exception {
    Collection<InbredStatus> results = getTestResults();
    LinkedList<String> missingProductList = new LinkedList<String>();
    String missingProduct1 = "ABC123";
    String missingProduct2 = "XYZLMNOP";
    missingProductList.add(missingProduct1);
    missingProductList.add(missingProduct2);
    Sheet sheet = getOutputSheet(results, missingProductList);
    List<InbredStatusDetail> details = getDetailsFromResults(results);
    assertEquals("Did not find expected number of rows",
            details.size() + missingProductList.size() + 2, sheet.getRows() - InbredStatusExcelGenerator.DATA_START);
    assertCellBlank(sheet, 0, InbredStatusExcelGenerator.DATA_START + details.size());
    assertCellStringValueEquals(sheet, 0, InbredStatusExcelGenerator.DATA_START + details.size() + 1, ExcelGeneratorConstants.MISSING_PRODUCTS_MESSAGE);
    for (int i = 0; i < missingProductList.size(); i++) {
      int currRow = InbredStatusExcelGenerator.DATA_START + details.size() + 2 + i;
      assertCellStringValueEquals(sheet, 0, currRow, missingProductList.get(i));
    }
  }
*/

  private List<InbredStatusDetail> getDetailsFromResults(Collection<InbredStatus> results) {
    List<InbredStatusDetail> details = new ArrayList<InbredStatusDetail>();
    for (InbredStatus result : results) {
      details.addAll(result.getDetail());
    }
    return details;
  }

  private Collection<InbredStatus> getTestResults() {
    Collection<InbredStatus> results = new LinkedList<InbredStatus>();
    Trait testTrait = new MockTrait(1L, "ABC", "ABCDEFG", "ABC", new HashSet<Trait>(), true);
    Date testDate = new Date();
    Product testProduct1 = new MockProduct(1L, "ABC", testTrait, null, null, testDate, testDate, false, null, "ACTIVE", false);
    Product testProduct2 = new MockProduct(1L, "ABC", testTrait, null, null, null, null, false, null, "ACTIVE", false);
    Collection<InbredStatusDetail> testDetail1 = new LinkedList<InbredStatusDetail>();
    testDetail1.add(new InbredStatusDetailImpl(testTrait, testProduct1, testDate, testDate,
            new HashMap<InventoryType, InventoryEntry>(),
            new HashMap<InventoryType, Collection<ProductionEntry>>(),
            new HashMap<InventoryType, Collection<ProductionEntry>>()));
    Collection<InbredStatusDetail> testDetail2 = new LinkedList<InbredStatusDetail>();
    testDetail1.add(new InbredStatusDetailImpl(testTrait, testProduct2, testDate, testDate,
            new HashMap<InventoryType, InventoryEntry>(),
            new HashMap<InventoryType, Collection<ProductionEntry>>(),
            new HashMap<InventoryType, Collection<ProductionEntry>>()));
    results.add(new InbredStatusImpl(testProduct1, testDetail1));
    results.add(new InbredStatusImpl(testProduct2, testDetail2));
    return results;
  }

/*
this was a test I used when I was trying to get the template formatted just right
  public void testTestingWithJXLS() throws Exception {
    Collection<ExcelExportStatus> statusResults = new LinkedList<ExcelExportStatus>();
    statusResults.add(new ExcelExportStatus("ABC", "DEF", "GHI", "JKL", "T0A0", "Active",
            new MockTrait(1L, "AAA", "AAB+BBA", "ABCDEFG", new HashSet<Trait>(), true),
            new Date(), new Date(),
            123L, 1234L, new Date(),
            444L, new Date(), 555L, new Date(), 888L,
            114L, new Date(), 225L, new Date(), 3333L));
    statusResults.add(new ExcelExportStatus("XXX", "DEF", "GHI", "JKL", "T0A0", "Active",
            new MockTrait(1L, "QQQ", "QQR+RRQ", "QWERTY", new HashSet<Trait>(), true),
            new Date(), new Date(),
            11111L, null, null,
            null, null, null, null, 888L,
            null, null, null, null, 3333L));
    statusResults.add(new ExcelExportStatus("YYYY", "DEF", "GHI", "JKL", "T0A0", "Active",
            new MockTrait(1L, "ZZZ", "ZZB+BBZ", "ZXCVBNM", new HashSet<Trait>(), true),
            null, null,
            null, null, null,
            null, null, null, null, null,
            null, null, null, null, null));
    Collection<String> missingProducts = new LinkedList<String>();
    missingProducts.add("ABC123");
    missingProducts.add("LMNOP-12345");
    missingProducts.add("JJAJAJAJSADJA");

    Map<String, Object> paramMap = new HashMap<String, Object>();
    paramMap.put("missing", missingProducts);
    paramMap.put("status", statusResults);
    Configuration config = new Configuration();
    XLSTransformer transformer = new XLSTransformer(config);
    HSSFWorkbook workbook = transformer.transformXLS(new FileInputStream("c:\\xlstest\\statusTemplate.xls"), paramMap);
    workbook.write(new FileOutputStream("c:\\xlstest\\statusOutput.xls"));

    fail("testTestingWithJXLS is not a real UT");
  }
*/

}