package com.monsanto.eas.hiat.view.mock;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.hiat.analysis.HybridAnalysis;
import com.monsanto.eas.hiat.controller.mock.MockProductServiceConfiguredForNE5112v1;
import com.monsanto.eas.hiat.scenario.Scenario;
import com.monsanto.eas.hiat.service.mock.mock.MockTraitService;
import com.monsanto.eas.hiat.view.HybridAnalysisXMLGenerator;
import org.w3c.dom.Document;

import java.util.Collection;

/**
 * Created by vvvelu Date: Mar 11, 2009 Time: 2:32:42 PM
 */
public class MockHybridAnalysisXMLGenerator extends HybridAnalysisXMLGenerator {
  private boolean wasGetXmlContentCalled = false;
  private Collection<HybridAnalysis> analysisList = null;
  private Collection<String> missingProducts = null;

  public MockHybridAnalysisXMLGenerator() {
    super(new MockProductServiceConfiguredForNE5112v1(), new MockTraitService()); //todo fix this, its using the real DAOs
  }

  public Document getXmlContent(Collection<HybridAnalysis> analysisList, Scenario scenario, String url,
                                boolean isSavedScenario, UCCHelper helper, Collection<String> missingProducts) {
    this.analysisList = analysisList;
    this.missingProducts = missingProducts;
    wasGetXmlContentCalled = true;
    return DOMUtil.newDocument();
  }

  public Collection<String> getMissingProducts() {
    return missingProducts;
  }

  public boolean wasGetXmlContentCalled() {
    return wasGetXmlContentCalled;
  }

  public Collection<HybridAnalysis> getAnalysisList() {
    return analysisList;
  }
}
