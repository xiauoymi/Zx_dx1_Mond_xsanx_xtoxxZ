package com.monsanto.eas.hiat.view.mock;

import com.monsanto.eas.hiat.analysis.InbredAnalysis;
import com.monsanto.eas.hiat.view.InbredAnalysisXMLGenerator;
import org.w3c.dom.Document;

import java.util.Collection;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockInbredAnalysisXMLGenerator extends InbredAnalysisXMLGenerator {
  private boolean wasGetXMLContentCalled = false;

  @Override
  public Document getXmlContent(Collection<InbredAnalysis> statusResults, Collection<String> missingProducts) {
    wasGetXMLContentCalled = true;
    return super.getXmlContent(statusResults, missingProducts);
  }

  public boolean wasGetXmlContentCalled() {
    return wasGetXMLContentCalled;
  }
}
