package com.monsanto.eas.hiat.view.mock;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.eas.hiat.analysis.InbredStatus;
import com.monsanto.eas.hiat.view.InbredStatusXMLGenerator;
import org.w3c.dom.Document;

import java.util.Collection;

/**
 * Created by User: vvvelu Date: Mar 13, 2009 Time: 2:56:50 PM
 */
public class MockInbredStatusXMLGenerator extends InbredStatusXMLGenerator {
  private boolean wasGetXmlContentCalled;
  private Collection<InbredStatus> statusList;

  public Document getXmlContent(Collection<InbredStatus> statusList, Collection<String> missingProductList) {
    this.statusList = statusList;
    wasGetXmlContentCalled = true;
    Document document = DOMUtil.newDocument();
    return  document;
  }

  public boolean wasGetXmlContentCalled() {
    return wasGetXmlContentCalled;
  }

  public Collection<InbredStatus> getAnalysisList() {
    return statusList;
  }
}
