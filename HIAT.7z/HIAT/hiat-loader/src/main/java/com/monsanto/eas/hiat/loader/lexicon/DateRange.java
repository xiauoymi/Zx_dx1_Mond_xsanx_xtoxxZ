package com.monsanto.eas.hiat.loader.lexicon;

import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class DateRange {
  private final Date startDate;
  private final Date endDate;

  public DateRange(Date startDate, Date endDate) {
    this.startDate = startDate;
    this.endDate = endDate;
  }

  public Date getStartDate() {
    return startDate;
  }

  public Date getEndDate() {
    return endDate;
  }

  @Override
  public String toString() {
    return "[" + startDate + " to " + endDate + "]";
  }
}
