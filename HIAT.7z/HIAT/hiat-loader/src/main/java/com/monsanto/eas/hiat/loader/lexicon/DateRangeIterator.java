package com.monsanto.eas.hiat.loader.lexicon;

import java.util.Iterator;
import java.util.Date;
import java.util.Calendar;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class DateRangeIterator implements Iterator<DateRange> {
  private final Date endDate;
  private final int intervalSeconds;

  private Date currDate;

  public DateRangeIterator(Date startDate, Date endDate, int intervalSeconds) {
    this.currDate = startDate;
    this.endDate = endDate;
    this.intervalSeconds = intervalSeconds;
  }

  public boolean hasNext() {
    return currDate.before(endDate);
  }

  public DateRange next() {
    Date nextDate = addInterval(currDate);
    if (nextDate.after(endDate)) {
      nextDate = endDate;
    }
    DateRange currRange = new DateRange(currDate, nextDate);
    currDate = nextDate;
    return currRange;
  }

  private Date addInterval(Date currDate) {
    Calendar cal = Calendar.getInstance();
    cal.setTime(currDate);
    cal.add(Calendar.SECOND, intervalSeconds);
    return cal.getTime();
  }

  public void remove() {
    //optional operation, not implemented
  }
}
