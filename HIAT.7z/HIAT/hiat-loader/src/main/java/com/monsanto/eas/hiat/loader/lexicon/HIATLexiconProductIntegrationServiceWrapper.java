package com.monsanto.eas.hiat.loader.lexicon;

import com.monsanto.tps.lexicon.integration.product.*;

import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HIATLexiconProductIntegrationServiceWrapper implements ProductIntegrationService {
  private static final int HALF_DAY = 12 * 60 * 60;
  private final ProductIntegrationService baseService;

  public HIATLexiconProductIntegrationServiceWrapper(ProductIntegrationService baseService) {
    this.baseService = baseService;
  }

  public ModifiedInbredProductsSearchResults findModifiedInbredsByDateRangeAndCrop(Date startDate, Date endDate, String cropPubKey) {
    List<ModifiedInbredProduct> products = findModifiedProducts(new ModifiedInbredFinder(), startDate, endDate, cropPubKey);
    ModifiedInbredProductsSearchResults results = new ModifiedInbredProductsSearchResults();
    results.setStart(startDate);
    results.setEnd(endDate);
    results.setModifiedInbredProducts(products);
    return results;
  }

  public ModifiedHybridProductsSearchResults findModifiedHybridsByDateRangeAndCrop(Date startDate, Date endDate, String cropPubKey) {
    List<ModifiedHybridProduct> products = findModifiedProducts(new ModifiedHybridFinder(), startDate, endDate, cropPubKey);
    ModifiedHybridProductsSearchResults results = new ModifiedHybridProductsSearchResults();
    results.setStart(startDate);
    results.setEnd(endDate);
    results.setModifiedHybridProducts(products);
    return results;
  }

  private <T> List<T> findModifiedProducts(ModifiedProductFinder<T> finder, Date startDate, Date endDate, String cropPubKey) {
    List<T> products = new ArrayList<T>();

    for (DateRange range : generateDateRanges(startDate, endDate, HALF_DAY)) {
      System.out.print(range);
//      System.out.println("Calling for range: " + range);
      Collection<T> currResult = finder.findModifiedProducts(
              range.getStartDate(),
              range.getEndDate(),
              cropPubKey
      );

      if (currResult != null) {
        products.addAll(currResult);
        System.out.println(":" + currResult.size());
      } else {
        System.out.println(":NONE");
      }
    }

    return products;
  }

  private static Iterable<DateRange> generateDateRanges(final Date startDate, final Date endDate, final int intervalSeconds) {
    return new Iterable<DateRange>() {
      public Iterator<DateRange> iterator() {
        return new DateRangeIterator(startDate, endDate, intervalSeconds);
      }
    };
  }

  private static interface ModifiedProductFinder<T> {
    Collection<T> findModifiedProducts(Date startDate, Date endDate, String cropPubKey);
  }

  private class ModifiedInbredFinder implements ModifiedProductFinder<ModifiedInbredProduct> {
    public Collection<ModifiedInbredProduct> findModifiedProducts(Date startDate, Date endDate, String cropPubKey) {
      return baseService.findModifiedInbredsByDateRangeAndCrop(startDate, endDate, cropPubKey).getModifiedInbredProducts();
    }
  }

  private class ModifiedHybridFinder implements ModifiedProductFinder<ModifiedHybridProduct> {
    public Collection<ModifiedHybridProduct> findModifiedProducts(Date startDate, Date endDate, String cropPubKey) {
      return baseService.findModifiedHybridsByDateRangeAndCrop(startDate, endDate, cropPubKey).getModifiedHybridProducts();
    }
  }
}
