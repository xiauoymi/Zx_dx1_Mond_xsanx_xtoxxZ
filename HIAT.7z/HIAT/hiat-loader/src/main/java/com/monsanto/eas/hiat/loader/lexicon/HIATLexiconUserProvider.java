package com.monsanto.eas.hiat.loader.lexicon;

import com.monsanto.tps.authentication.UserNameProvider;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HIATLexiconUserProvider implements UserNameProvider {
  private static final String HIAT_USER = "HIAT_APP";

  public String getUserName() {
    return HIAT_USER;
  }
}
