package com.monsanto.eas.hiat.loader.lexicon;

import com.monsanto.tps.lexicon.integration.product.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class LexiconHybridLoad extends LexiconLoad {
  private static final String hybridSQL = "INSERT INTO HIAT.LEXICON_HYBRID_STAGING " +
          "(" +
          "HYBRID_PRECOM_NAME, HYBRID_MFG_NAME, HYBRID_BASE_MFG_NAME," +
          "FEMALE_PRECOMMERCIAL_NAME, FEMALE_MFG_NAME, FEMALE_BASE_MFG_NAME," +
          "MALE_PRECOMMERCIAL_NAME, MALE_MFG_NAME, MALE_BASE_MFG," +
          "PRODUCTION_STATUS, TRAIT_VERSION, VARIETY_NAME, COUNTRY," +
          "COML_TRAIT, STAGE, OECD_NAME, COMM_MATURITY," +
          "HYBRID_COM_NAME" +
          ") VALUES (" +
          "?, ?, ?," +
          "?, ?, ?," +
          "?, ?, ?," +
          "?, ?, ?, ?," +
          "?, ?, ?, ?," +
          "?" +
          ")";

  protected void loadProducts(ProductIntegrationService productIntegrationService, Connection conn, Date startDate, Date endDate) throws SQLException {
    ModifiedHybridProductsSearchResults results = productIntegrationService.findModifiedHybridsByDateRangeAndCrop(startDate, endDate, cornPubkey);

    PreparedStatement stmt = conn.prepareStatement(hybridSQL);
    try {
      loadProductsUsingPreparedStatement(results, stmt);
    } finally {
      stmt.close();
    }
  }

  private void loadProductsUsingPreparedStatement(ModifiedHybridProductsSearchResults results, PreparedStatement stmt) throws SQLException {
    for (ModifiedHybridProduct product : getModifiedProducts(results)) {
      for (ModifiedHybridProductStage stage : getProductStages(product)) {
        for (ProductParents parents : product.getProductParents()) {
          ParentProduct femaleParent = parents.getFemaleParent();
          ParentProduct maleParent = parents.getMaleParent();
          writeHybrid(stmt, product, stage, femaleParent, maleParent);
        }
      }
    }
  }

  private Iterable<ModifiedHybridProduct> getModifiedProducts(ModifiedHybridProductsSearchResults results) {
    Collection<ModifiedHybridProduct> products = new ArrayList<ModifiedHybridProduct>();
    for (ModifiedHybridProduct product : results.getModifiedHybridProducts()) {
      if (!product.isLogicalDelete()) {
        products.add(product);
      }
    }

    return products;
  }

  private Iterable<ModifiedHybridProductStage> getProductStages(ModifiedHybridProduct product) {
    Collection<ModifiedHybridProductStage> stages = new ArrayList<ModifiedHybridProductStage>();
    for (ModifiedHybridProductStage stage : product.getProductStages()) {
      if (!stage.isLogicalDelete()) {
        stages.add(stage);
      }
    }

    return stages;
  }

  private void writeHybrid(PreparedStatement stmt,
                           ModifiedHybridProduct product,
                           ModifiedHybridProductStage stage,
                           ParentProduct femaleParent,
                           ParentProduct maleParent) throws SQLException {
    stmt.setString(1, product.getPreComlName());
    stmt.setString(2, product.getManufacturingName());
    stmt.setString(3, product.getBaseManufacturingName());
    setParent(stmt, 4, femaleParent);
    setParent(stmt, 7, maleParent);
    stmt.setString(10, product.getProductionStatus());
    stmt.setString(11, product.getTraitVersion());
    stmt.setString(12, product.getVarietyName());
    stmt.setString(13, stage.getIsoCountryCode());
    stmt.setString(14, stage.getComlTraitStackName());
    stmt.setString(15, stage.getProductStage());
    stmt.setString(16, stage.getOecdReqdName());
    stmt.setLong(17, stage.getCommercialMaturity());
    stmt.setString(18, stage.getCommercialName());

    stmt.executeUpdate();
  }

  private void setParent(PreparedStatement stmt, int offset, ParentProduct parent) throws SQLException {
    if (parent == null) {
      stmt.setString(offset, null);
      stmt.setString(offset + 1, null);
      stmt.setString(offset + 2, null);
    } else {
      stmt.setString(offset, parent.getPreComlName());
      stmt.setString(offset + 1, parent.getManufacturingName());
      stmt.setString(offset + 2, parent.getBaseManufacturingName());
    }
  }
}
