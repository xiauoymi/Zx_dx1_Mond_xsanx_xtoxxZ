package com.monsanto.eas.hiat.loader.lexicon;

import com.monsanto.tps.lexicon.integration.product.ModifiedInbredProduct;
import com.monsanto.tps.lexicon.integration.product.ModifiedInbredProductStage;
import com.monsanto.tps.lexicon.integration.product.ModifiedInbredProductsSearchResults;
import com.monsanto.tps.lexicon.integration.product.ProductIntegrationService;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class LexiconInbredLoad extends LexiconLoad {
  private static final String inbredSQL = "INSERT INTO HIAT.LEXICON_INBRED_STAGING " +
          "(" +
          "PROD_KEY, PRODUCT_STAGE_PUBKEY, CROP," +
          "PRE_COML_NAME, COUNTRY, STAGE," +
          "COML_TRAIT, MANF_NAME, BASE_MANF_NAME," +
          "PRODUCTION_STATUS, TRAIT_VERSION, LOGICICAL_DEL_FLAG, ACTIVE_FLAG" +
          ") VALUES (" +
          "?, ?, ?," +
          "?, ?, ?," +
          "?, ?, ?," +
          "?, ?, 'N', ?" +
          ")";

  protected void loadProducts(ProductIntegrationService productIntegrationService, Connection conn, Date startDate, Date endDate) throws SQLException {
    ModifiedInbredProductsSearchResults results = productIntegrationService.findModifiedInbredsByDateRangeAndCrop(startDate, endDate, cornPubkey);

    PreparedStatement stmt = conn.prepareStatement(inbredSQL);
    try {
      for (ModifiedInbredProduct product : getModifiedProducts(results)) {
        for (ModifiedInbredProductStage stage : getProductStages(product)) {
          writeInbred(stmt, product, stage);
        }
      }
    } finally {
      stmt.close();
    }
  }

  private Iterable<ModifiedInbredProduct> getModifiedProducts(ModifiedInbredProductsSearchResults results) {
    Collection<ModifiedInbredProduct> products = new ArrayList<ModifiedInbredProduct>();
    for (ModifiedInbredProduct product : results.getModifiedInbredProducts()) {
      if (!product.isLogicalDelete()) {
        products.add(product);
      }
    }

    return products;
  }

  private Iterable<ModifiedInbredProductStage> getProductStages(ModifiedInbredProduct product) {
    Collection<ModifiedInbredProductStage> stages = new ArrayList<ModifiedInbredProductStage>();
    for (ModifiedInbredProductStage stage : product.getProductStages()) {
      if (!stage.isLogicalDelete()) {
        stages.add(stage);
      }
    }

    return stages;
  }

  private void writeInbred(PreparedStatement stmt, ModifiedInbredProduct product, ModifiedInbredProductStage stage) throws SQLException {
    String status = product.getProductionStatus();

    stmt.setString(1, product.getProductPubkey());
    stmt.setString(2, stage.getProductStagePubkey());
    stmt.setString(3, cornPubkey);
    stmt.setString(4, product.getPreComlName());
    stmt.setString(5, stage.getIsoCountryCode());
    stmt.setString(6, stage.getProductStage());
    stmt.setString(7, stage.getComlTraitStackName());
    stmt.setString(8, product.getManufacturingName());
    stmt.setString(9, product.getBaseManufacturingName());
    stmt.setString(10, status);
    stmt.setString(11, product.getTraitVersion());
    if (status != null && (status.equalsIgnoreCase("ACTIVE") || status.toUpperCase().startsWith("PRIMARY"))) {
      stmt.setString(12, "Y");
    } else {
      stmt.setString(12, "N");
    }

    stmt.executeUpdate();
  }

}
