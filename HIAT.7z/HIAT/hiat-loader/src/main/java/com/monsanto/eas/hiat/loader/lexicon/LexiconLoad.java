package com.monsanto.eas.hiat.loader.lexicon;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.apache.commons.lang.time.DateUtils;

import java.util.Date;
import java.sql.*;

import com.monsanto.tps.lexicon.integration.product.ProductIntegrationService;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public abstract class LexiconLoad {
  protected static final String CONFIG_LOCATION = "/services-context.xml";
  protected static final String cornPubkey = "1015";

  protected Date getCurrentDatabaseDate(Connection conn) throws SQLException {
    Statement stmt = conn.createStatement();
// good inbred test range:    ResultSet result = stmt.executeQuery("SELECT to_date('09/06/2008', 'mm/dd/yyyy') FROM DUAL");
// good hybrid test range:    ResultSet result = stmt.executeQuery("SELECT to_date('02/06/2008', 'mm/dd/yyyy') FROM DUAL");
    ResultSet result = stmt.executeQuery("SELECT SYSDATE FROM DUAL");
    try {
      result.next();
      return new Date(result.getDate(1).getTime());
    } finally {
      result.close();
      stmt.close();
    }
  }

  protected Date getLastRanDate(Connection conn, String serviceName) throws SQLException {
// good inbred test range:    PreparedStatement stmt = conn.prepareStatement("SELECT to_date('09/01/2008', 'mm/dd/yyyy') FROM DUAL WHERE ? is not null");
// good hybrid test range:   PreparedStatement stmt = conn.prepareStatement("SELECT to_date('02/01/2008', 'mm/dd/yyyy') FROM DUAL WHERE ? is not null");
    PreparedStatement stmt = conn.prepareStatement("SELECT LAST_RAN_DATE FROM HIAT.LAST_RAN WHERE SERVICE_NAME=?");
    stmt.setString(1, serviceName);
    ResultSet result = stmt.executeQuery();
    try {
      if (result.next()) {
        return new Date(result.getDate(1).getTime() + 1);
      } else {
        throw new RuntimeException("This loader cannot be used for INITIAL data load of " + serviceName);
      }
    } finally {
      result.close();
      stmt.close();
    }
  }

  protected void setLastRanDate(Connection conn, String serviceName, Date endDate) throws SQLException {
    PreparedStatement stmt = conn.prepareStatement("UPDATE HIAT.LAST_RAN SET LAST_RAN_DATE = ? WHERE SERVICE_NAME=?");
    stmt.setDate(1, new java.sql.Date(endDate.getTime()));
    stmt.setString(2, serviceName);
    stmt.executeUpdate();
  }

  public void load(String[] args, String serviceName) throws SQLException, ClassNotFoundException, IllegalAccessException, InstantiationException {
    ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(CONFIG_LOCATION);
    ProductIntegrationService productIntegrationService = (ProductIntegrationService) context.getBean("productIntegrationService");

    if (args.length != 3) {
      System.err.println("SYNTAX: java LoaderClassName username password instance");
      throw new RuntimeException("Invalid syntax");
    }

    String username = args[0];
    String password = args[1];
    String instanceName = args[2];
    String db = "jdbc:oracle:thin:@" + instanceName + ":1521:" + instanceName;
    Class.forName("oracle.jdbc.driver.OracleDriver");
    Connection conn=DriverManager.getConnection(db, username, password);
    try {
      Date startDate = getLastRanDate(conn, serviceName);
      Date endDate = getCurrentDatabaseDate(conn);
      Date maxGap = DateUtils.addDays(startDate, 14);
      Date usedEndDate;
      if (maxGap.after(endDate)) {
        usedEndDate = endDate;
      } else {
        usedEndDate = maxGap;
      }

      loadProducts(productIntegrationService, conn, startDate, usedEndDate);

      setLastRanDate(conn, serviceName, usedEndDate);

      conn.commit();
    } finally {
      conn.close();
    }
  }

  protected abstract void loadProducts(ProductIntegrationService productIntegrationService, Connection conn, Date startDate, Date endDate) throws SQLException;
}
