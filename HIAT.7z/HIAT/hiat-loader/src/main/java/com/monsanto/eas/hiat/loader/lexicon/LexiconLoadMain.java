package com.monsanto.eas.hiat.loader.lexicon;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class LexiconLoadMain {
  private static final String INBRED_SERVICE_NAME = "LEXICON_INBRED";
  private static final String HYBRID_SERVICE_NAME = "LEXICON_HYBRID";

  public static void main(String[] args) throws Exception {
    new LexiconInbredLoad().load(args, INBRED_SERVICE_NAME);
    new LexiconHybridLoad().load(args, HYBRID_SERVICE_NAME);

  }
}
