package com.monsanto.eas.hiat.loader.lexicon.model;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HybridStagingRecord {
}
