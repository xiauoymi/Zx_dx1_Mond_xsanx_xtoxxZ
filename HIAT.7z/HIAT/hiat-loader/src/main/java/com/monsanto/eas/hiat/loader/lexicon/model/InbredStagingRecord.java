package com.monsanto.eas.hiat.loader.lexicon.model;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
/*
@SuppressWarnings({"CanBeFinal"})
@Entity
@Table(schema = "HIAT", name = "INVENTORY_ENTRY")
@AccessType("field")
@NoDeleteAllowed
*/
public class InbredStagingRecord {
/*
  @Id
  @Column(name="PROD_KEY")
  private String prodKey;

  @Column(name="PRODUCT_STAGE_PUBKEY")
  private String productStagePubKey;

  @Column(name="CROP")
  private String crop;

  @Column(name="PRE_COML_NAME")
  private String preComlName;

  @Column(name="COUNTRY")
  private String country;

  @Column(name="STAGE")
  private String stage;

  @Column(name="COML_TRAIT")
  private String comlTrait;

  @Column(name="MANF_NAME")
  private String manfName;

  @Column(name="BASE_MANF_NAME")
  private String baseManfName;

  @Column(name="PRODUCTION_STATUS")
  private String productionStatus;

  @Column(name="TRAIT_VERSION")
  private String traitVersion;

  @Column(name="LOGICAL_DEL_FLAG")
  private String logicalDelFlag;

  @Column(name="ACTIVE_FLAG")
  private String activeFlag;

  public InbredStagingRecord(String prodKey, String productStagePubKey, String crop, String preComlName, String country, String stage, String comlTrait, String manfName, String baseManfName, String productionStatus, String traitVersion, String logicalDelFlag, String activeFlag) {
    this.prodKey = prodKey;
    this.productStagePubKey = productStagePubKey;
    this.crop = crop;
    this.preComlName = preComlName;
    this.country = country;
    this.stage = stage;
    this.comlTrait = comlTrait;
    this.manfName = manfName;
    this.baseManfName = baseManfName;
    this.productionStatus = productionStatus;
    this.traitVersion = traitVersion;
    this.logicalDelFlag = logicalDelFlag;
    this.activeFlag = activeFlag;
  }
*/
}
