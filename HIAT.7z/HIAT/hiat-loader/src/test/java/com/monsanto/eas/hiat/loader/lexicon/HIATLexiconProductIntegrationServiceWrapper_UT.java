package com.monsanto.eas.hiat.loader.lexicon;

import com.monsanto.tps.lexicon.integration.product.ModifiedInbredProductsSearchResults;
import com.monsanto.tps.lexicon.integration.product.ProductIntegrationService;
import com.monsanto.tps.lexicon.integration.product.ModifiedHybridProductsSearchResults;
import junit.framework.TestCase;

import javax.jws.WebParam;
import java.util.*;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class HIATLexiconProductIntegrationServiceWrapper_UT extends TestCase {
  public void testStartDateAndEndDateAreAsExpected() throws Exception {
    MockProductIntegrationService mockBaseService = new MockProductIntegrationService();
    ProductIntegrationService service = new HIATLexiconProductIntegrationServiceWrapper(mockBaseService);
    Date testStartDate = getTestDate(2008, Calendar.JANUARY, 1, 0, 0, 0);
    Date testEndDate = getTestDate(2008, Calendar.FEBRUARY, 1, 14, 30, 0);
    ModifiedInbredProductsSearchResults result = service.findModifiedInbredsByDateRangeAndCrop(testStartDate, testEndDate, "1234");
    assertEquals(testStartDate, result.getStart());
    assertEquals(testEndDate, result.getEnd());
  }

  public void testDateRangesAreAllUnderTwentyFourHours() throws Exception {
    MockProductIntegrationService mockBaseService = new MockProductIntegrationService();
    ProductIntegrationService service = new HIATLexiconProductIntegrationServiceWrapper(mockBaseService);
    Date testStartDate = getTestDate(2008, Calendar.JANUARY, 1, 0, 0, 0);
    Date testEndDate = getTestDate(2008, Calendar.FEBRUARY, 1, 14, 30, 0);
    service.findModifiedInbredsByDateRangeAndCrop(testStartDate, testEndDate, "1234");
    for (ParametersToBaseService params : mockBaseService.getParamsUsed()) {
      Date dayLater = addDay(params.getStartDate());
      assertTrue("Date range should have been less than 24 hours", dayLater.after(params.getEndDate()));
    }
  }

  private Date addDay(Date date) {
    Calendar cal = Calendar.getInstance();
    cal.setTime(date);
    cal.add(Calendar.HOUR, 24);
    return cal.getTime();
  }

  public void testDateRangesAreContinuous() throws Exception {
    MockProductIntegrationService mockBaseService = new MockProductIntegrationService();
    ProductIntegrationService service = new HIATLexiconProductIntegrationServiceWrapper(mockBaseService);
    Date testStartDate = getTestDate(2008, Calendar.JANUARY, 1, 0, 0, 0);
    Date testEndDate = getTestDate(2008, Calendar.FEBRUARY, 1, 14, 30, 0);
    service.findModifiedInbredsByDateRangeAndCrop(testStartDate, testEndDate, "1234");
    Date prevDate = testStartDate;
    for (ParametersToBaseService params : mockBaseService.getParamsUsed()) {
      assertEquals("current range should have started with end of previous range", prevDate, params.getStartDate());
      prevDate = params.getEndDate();
    }
    assertEquals("last range should have ended with end date", testEndDate, prevDate);
  }

  private Date getTestDate(int year, int month, int day, int hour, int min, int sec) {
    GregorianCalendar cal = new GregorianCalendar();
    cal.set(year, month, day, hour, min, sec);
    return cal.getTime();
  }

  private static class MockProductIntegrationService implements ProductIntegrationService {
    private final List<ParametersToBaseService> paramsUsed = new ArrayList<ParametersToBaseService>();

    public ModifiedInbredProductsSearchResults findModifiedInbredsByDateRangeAndCrop(
            Date startDate,
            Date endDate,
            String cropPubKey) {
      paramsUsed.add(new ParametersToBaseService(startDate, endDate, cropPubKey));

      return new ModifiedInbredProductsSearchResults();
    }

    public ModifiedHybridProductsSearchResults findModifiedHybridsByDateRangeAndCrop(
            Date startDate,
            Date endDate,
            String cropPubKey) {
      paramsUsed.add(new ParametersToBaseService(startDate, endDate, cropPubKey));

      return new ModifiedHybridProductsSearchResults();
    }

    public List<ParametersToBaseService> getParamsUsed() {
      return paramsUsed;
    }
  }

  private static class ParametersToBaseService {
    private final Date startDate;
    private final Date endDate;
    private final String cropKey;

    public ParametersToBaseService(Date startDate, Date endDate, String cropKey) {
      this.startDate = startDate;
      this.endDate = endDate;
      this.cropKey = cropKey;
    }

    public Date getStartDate() {
      return startDate;
    }

    public Date getEndDate() {
      return endDate;
    }

    public String getCropKey() {
      return cropKey;
    }
  }
}