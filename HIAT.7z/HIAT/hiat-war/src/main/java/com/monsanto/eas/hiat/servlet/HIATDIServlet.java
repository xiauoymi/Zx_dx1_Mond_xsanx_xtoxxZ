package com.monsanto.eas.hiat.servlet;

import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.eas.hiat.config.HIATConfiguration;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class HIATDIServlet extends GatewayServlet {
  public void init(ServletConfig servletConfig) throws ServletException {
    super.init(servletConfig);

    Logger.traceEntry();

    enableLogging();

    Logger.traceExit();
  }

  private static void enableLogging() throws ServletException {
    try {
      HIATLoggerFactory loggerFactory = new HIATLoggerFactory();
      loggerFactory.setupLogging();
    }
    catch (LogRegistrationException lre) {
      throw new ServletException(lre);
    }
    catch (IOException ioe) {
      throw new ServletException(ioe);
    }
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    Logger.traceEntry();

    UCCHelper helper = createHelper(request, response);
    String controllerBeanId = getInitParameter("controllerBeanId");
    if (controllerBeanId == null) {
      Logger.log(
            new LoggableError("web.xml error: Controller parameter not found for URL " + helper.requestedURL()));
      helper.reportError("\"controllerBeanId\" parameter not found for use-case lookup.  Contact technical support.");
      return;
    }

    BeanFactory beanFactory = new XmlBeanFactory(new ClassPathResource(HIATConfiguration.HIAT_BEAN_XML));
    UseCaseController controller = (UseCaseController) beanFactory.getBean(controllerBeanId);
    controller.run(helper);

    Logger.traceExit();
  }

}
