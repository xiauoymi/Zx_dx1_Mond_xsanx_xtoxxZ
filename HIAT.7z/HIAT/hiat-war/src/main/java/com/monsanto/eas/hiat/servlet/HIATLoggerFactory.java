package com.monsanto.eas.hiat.servlet;

import com.monsanto.AbstractLogging.LogDevice;
import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Log4JLogging.*;
import com.monsanto.XMLUtil.DOMUtil;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class HIATLoggerFactory {
    private final String m_cstrAppName = "HIAT";
    private final String m_cstrTraceLogPath;
    private final String m_cstrRollingLogPath;
    private static final String LOGGER_PATTERN = "%d %-5r %-5p [%c{1}.%M]: %m%n";

    public HIATLoggerFactory() {
        String cstrLogFolderName = "";

        if (StringUtils.isNotEmpty(System.getProperty("server.logs"))) {
            cstrLogFolderName = System.getProperty("server.logs") + File.separatorChar;
        } else {
            cstrLogFolderName = System.getProperty("server.logs") + File.separatorChar;
        }
        System.out.println("log folder: '" + cstrLogFolderName + "'");

      m_cstrTraceLogPath = cstrLogFolderName + File.separatorChar + m_cstrAppName + "Trace.log";
      m_cstrRollingLogPath = cstrLogFolderName + File.separatorChar + m_cstrAppName + ".log";
    }

    public synchronized void setupLogging() throws IOException, LogRegistrationException {
        Logger.register(new Log4JTraceLog(m_cstrAppName, new Log4JFileLogDevice(m_cstrTraceLogPath)));

        LogDevice AppLogDevice = new Log4JMidnightRollingFileLogDevice(LOGGER_PATTERN, m_cstrRollingLogPath);
        Logger.register(new Log4JDebugLog(m_cstrAppName, AppLogDevice));
        Logger.register(new Log4JInfoLog(m_cstrAppName, AppLogDevice));
        Logger.register(new Log4JWarningLog(m_cstrAppName, AppLogDevice));
        Logger.register(new Log4JErrorLog(m_cstrAppName, AppLogDevice));
    }

    public Document toXML() {
        Logger.traceEntry();

        Document logDocument = DOMUtil.newDocument();
        Element rootElement = DOMUtil.addChildElement(logDocument, "LOGS");
        insertXML(rootElement);

        return (Document) Logger.traceExit(logDocument);
    }

    protected void insertXML(Node parentElement) {
        Logger.traceEntry();

        try {
            addLogDeviceToXmlDocument(parentElement, "Rolling Log (Text)", m_cstrRollingLogPath);
            addLogDeviceToXmlDocument(parentElement, "Trace Log", m_cstrTraceLogPath);
        }
        catch (UnsupportedEncodingException uee) {
            Logger.log(new LoggableError(uee));
        }

        Logger.traceExit();
    }

    private void addLogDeviceToXmlDocument(Node parentElement, String deviceName, String filePath)
            throws UnsupportedEncodingException {
        Logger.traceEntry();

        if (filePath != null && (!filePath.trim().equals(""))) {
            Element deviceElement = DOMUtil.addChildElement(parentElement, "LOG_DEVICE");
            DOMUtil.addChildElement(deviceElement, "DEVICE_NAME", deviceName);
            DOMUtil.addChildElement(deviceElement, "LOCATION", URLEncoder.encode(filePath, "UTF-8"));
        } else {
            throw new IllegalArgumentException("filePath argument cannot be null, blank, or empty.");
        }

        Logger.traceExit();
    }
}
