package com.monsanto.eas.hiat.servlet;

import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class KerberosTestServlet extends GatewayServlet {
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    UCCHelper helper = createHelper(request, response);
    helper.setContentType("text/plain");
    PrintWriter out = helper.getPrintWriter();
    try {
      out.println("*** Headers ***");
      for (String headerName : helper.getHeaderNames()) {
        String headerValue = helper.getHeader(headerName);
        out.println(headerName + " = " + headerValue);
      }
      out.println("***************");
      out.println("helper.getAuthenticatedUserID() = " + helper.getAuthenticatedUserID());
      out.println("helper.getAuthenticatedUserDomain() = " + helper.getAuthenticatedUserDomain());
      out.println("helper.getAuthenticatedUserFullName() = " + helper.getAuthenticatedUserFullName());
    } catch (Exception e) {
      out.println("EXCEPTION occurred : " + e.getMessage());
      e.printStackTrace(out);
    } finally {
      out.flush();
      out.close();
    }
  }


}
