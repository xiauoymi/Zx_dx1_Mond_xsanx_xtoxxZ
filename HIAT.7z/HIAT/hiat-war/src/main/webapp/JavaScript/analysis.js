window.onload = start;

function start() {
    document.getElementById('analysisResults').style.display = 'none';
    setSelectedTraits("traits", "trait");
    if (document.getElementById("displayAnalysisResults").value === "true") {
        document.getElementById('analysisResults').style.display = '';
        document.getElementById("productName").disabled = "disabled";
        document.getElementById("trait").disabled = "disabled";
        var possibleTraitComb = document.getElementById("possibleTraitComb");
        if (possibleTraitComb != null) {
            possibleTraitComb.disabled = "disabled";
        }
        document.getElementById("go").disabled = "disabled";
        disableAllOrNoneButtonsOnInbred(true);
        if (document.getElementById("download") != null && document.getElementById("download").disabled === true) {
            document.getElementById("download").disabled = '';
        }
        if (document.getElementById("noResults") != null) {
            document.getElementById("noResults").style.display = '';
        }
    }
}

function disableAllOrNoneButtonsOnInbred(disable) {
    var disabled = disable ? 'disabled' : '';
    if (document.getElementById("allTraits") && document.getElementById("noTraits") != null) {
        document.getElementById("allTraits").disabled = disabled;
        document.getElementById("noTraits").disabled = disabled;
    }
}


function setSelectedTraits(elementsToBeSelected, multipleSelectElement) {
    var arrayToBeSelected = document.getElementsByName(elementsToBeSelected);
    var selectElementOptions = document.getElementById(multipleSelectElement);
    for (var i = 0; i < selectElementOptions.options.length; i++) {
        for (var j = 0; j < arrayToBeSelected.length; j++) {
            if (selectElementOptions.options[ i ].value == arrayToBeSelected[j].value) {
                selectElementOptions.options[ i ].selected = true;
                break;
            }
        }
    }
}

function toggleAddMoreProducts() {
    document.getElementById('addMoreProducts').style.display = 'block';
}

function toggleToAnalysisParameters(object) {
    if (object == document.getElementById('cancel'))
        document.getElementById('addMoreProducts').style.display = 'none';

    if (object == document.getElementById('clear')) {
        document.getElementById('analysisResults').style.display = 'none';
        document.getElementById('go').disabled = "";
        document.getElementById('productName').disabled = "";
        document.getElementById("trait").disabled = '';
        var possibleTraitComb = document.getElementById("possibleTraitComb");
        if (possibleTraitComb != null) {
            possibleTraitComb.disabled = '';
        }
        disableAllOrNoneButtonsOnInbred(false);
    }
}

function hideMissingProducts() {
    document.getElementById('missingProducts').style.display = 'none';
}

function resetAnalysisParameters() {
    document.getElementById('go').disabled = '';
    document.getElementById('productName').value = "";
    document.getElementById('productName').disabled = '';
    document.getElementById("trait").disabled = '';
    var possibleTraitComb = document.getElementById("possibleTraitComb");
    if (possibleTraitComb != null) {
        possibleTraitComb.disabled = '';
    }
    resetSelectedTraits("trait");
    if (possibleTraitComb != null) {
        possibleTraitComb.length=0;
    }
    document.getElementById('unselectedTraits').length=0;
    disableAllOrNoneButtonsOnInbred(false);
}

function resetSelectedTraits(multipleSelectElement) {
    var selectElementOptions = document.getElementById(multipleSelectElement);
    for (var i = 0; i < selectElementOptions.options.length; i++) {
        if (selectElementOptions.options[ i ].selected) {
            selectElementOptions.options[ i ].selected = false;
        }
    }
}

function trim(str) {
    return str.replace(/^\s+|\s+$/g, "");
}

function toggleAddTraitsByCommercialName() {
    var traitElement = document.getElementById("trait");
    var traitsWithCode = document.getElementById("traitsWithCode");
    var traitsWithCommName = document.getElementById("traitsWithCommName");
    var traitsWithEvent = document.getElementById("traitsWithEvent");
    clearCurrentTraitSelection();
    sortSelect(traitsWithCommName);
    sortSelect(traitsWithEvent);
    if (document.getElementById("traitToggle").innerHTML === "By Commercial Name") {
        document.getElementById("traitToggle").innerHTML = "By Event";
        for (var i = 0; i < traitElement.options.length; i++) {
            if (traitElement.options[i].selected) {
                traitsWithCommName.options[i].selected = true;
            }
            traitElement.options[i].value = traitsWithCommName.options[i].value;
            traitElement.options[i].text = traitsWithCommName.options[i].text;
            traitElement.options[i].selected = traitsWithCommName.options[i].selected;
        }
    } else if (document.getElementById("traitToggle").innerHTML === "By Event") {
        document.getElementById("traitToggle").innerHTML = "By Code";
        for (var i = 0; i < traitElement.options.length; i++) {
            if (traitElement.options[i].selected) {
                traitsWithEvent.options[i].selected = true;
            }
            traitElement.options[i].value = traitsWithEvent.options[i].value;
            traitElement.options[i].text = traitsWithEvent.options[i].text;
            traitElement.options[i].selected = traitsWithEvent.options[i].selected;
        }

    } else if (document.getElementById("traitToggle").innerHTML === "By Code") {
        document.getElementById("traitToggle").innerHTML = "By Commercial Name";
        for (i = 0; i < traitElement.options.length; i++) {
            if (traitElement.options[i].selected) {
                traitsWithCode.options[i].selected = true;
            }
            traitElement.options[i].value = traitsWithCode.options[i].value;
            traitElement.options[i].text = traitsWithCode.options[i].text;
            traitElement.options[i].selected = traitsWithCode.options[i].selected;
        }
    }
}

function displayTraitSelection(showOrHide) {
    document.getElementById('pasteTraits').value = '';
    document.getElementById('traitSelection').style.display = showOrHide ? '' : 'none';
    document.getElementById("loadTraitElement").disabled = showOrHide ? '' : 'none';
}

function selectTraitByCodeOrCommName() {
    if (document.getElementById("selectTrait").innerHTML === 'Select Specific Traits By Code') {
        document.getElementById('traitSelectionByCode').style.display = '';
        document.getElementById('traitSelectionByCommName').style.display = 'none';
        document.getElementById("selectTrait").innerHTML = 'Select Specific Traits By Commercial Name';
    } else {
        document.getElementById("selectTrait").innerHTML = 'Select Specific Traits By Code';
        document.getElementById('traitSelectionByCode').style.display = 'none';
        document.getElementById('traitSelectionByCommName').style.display = '';
    }
    document.getElementById('selectionButtons').style.display = '';
}

function loadTraitElementWithSelection() {
    var pastedTraits = document.getElementById('pasteTraits').value;
    var traitElement = document.getElementById('trait');
    var traitsList = trim(pastedTraits);
    var traitWithSeperator = traitsList.replace(/\s+/g, "\n");

    var traitsArray = traitWithSeperator.split('\n');
    traitsArray.sort();
    clearCurrentTraitSelection();

    var traitsWithCode = document.getElementById("traitsWithCode");
    var traitsWithCommName = document.getElementById("traitsWithCommName");
    var traitsWithEvent = document.getElementById("traitsWithEvent");

    var traitToggle = document.getElementById("traitToggle").innerHTML;

    var noMatchString = '';
    for (var i = 0; i < traitsArray.length; i++) {
        var matchFound = false;
        var trait = trim(traitsArray[i]);

        for(var x = 0; x < traitsWithEvent.options.length; x++) {
           if (trait.toUpperCase() === traitsWithEvent.options[x].text.toUpperCase()) {
               var traitCode = traitsWithEvent.options[x].value;
               if(traitToggle === 'By Code') {
                   traitElement.options[x].selected = true;
                   matchFound = true;
                   break;
               }
               if(traitToggle === 'By Commercial Name') {
                   for(var e = 0; e < traitsWithCode.options.length; e++) {
                       if(traitsWithCode.options[e].value === traitCode) {
                           traitElement.options[e].selected = true;
                           matchFound = true;
                           break;
                       }
                   }
               }
               if(traitToggle === 'By Event') {
                 for(var f = 0; f < traitsWithCommName.options.length; f++) {
                    if(traitsWithCommName.options[f].value === traitCode) {
                        traitElement.options[f].selected = true;
                        matchFound = true;
                        break;
                     }
                 }
               }
           }
        }

        if(!matchFound) {
            for(var y= 0; y < traitsWithCode.options.length; y++) {
              if (trait.toUpperCase() === traitsWithCode.options[y].text.toUpperCase()) {
                  var traitCode = traitsWithCode.options[y].value;
                  if(traitToggle === 'By Commercial Name') {
                      traitElement.options[y].selected = true;
                      matchFound = true;
                      break;
                  }

                  if(traitToggle === 'By Event') {
                      for(var a = 0; a < traitsWithCommName.options.length; a++) {
                          if(traitsWithCommName.options[a].value === traitCode) {
                              traitElement.options[a].selected = true;
                              matchFound = true;
                              break;
                          }
                      }
                  }
                  if(traitToggle === 'By Code') {
                      for(var b = 0; b < traitsWithEvent.options.length; b++) {
                          if(traitsWithEvent.options[b].value === traitCode) {
                              traitElement.options[b].selected = true;
                              matchFound = true;
                              break;
                          }
                      }
                  }
              }
            }
        }

        if(!matchFound) {
            for(var z = 0; z < traitsWithCommName.options.length; z++) {
              if (trait.toUpperCase() === traitsWithCommName.options[z].text.toUpperCase()) {
                  var traitCode = traitsWithCommName.options[z].value;
                  if(traitToggle === 'By Event') {
                      traitElement.options[z].selected = true;
                      matchFound = true;
                      break;
                  }
                  if(traitToggle === 'By Commercial Name') {
                     for(var c = 0; c < traitsWithCode.options.length; c++) {
                         if(traitsWithCode.options[c].value === traitCode) {
                             traitElement.options[c].selected = true;
                             matchFound = true;
                             break;
                         }
                     }
                  }
                  if(traitToggle === 'By Code') {
                      for(var d = 0; d < traitsWithEvent.options.length; d++) {
                          if(traitsWithEvent.options[d].value === traitCode) {
                              traitElement.options[d].selected = true;
                              matchFound = true;
                              break;
                          }
                      }
                  }
              }
            }
        }

        if (!matchFound) {
            noMatchString += trait + '\n';
        }
    }


    if (noMatchString.length > 0) {
        alert("Traits entered below are not valid\n" + noMatchString);
    }
    else {
        var selectBox = document.getElementById('trait');
        updateTraitCombFilterSelectBox(selectBox);
    }

    document.getElementById("loadTraitElement").disabled = "disabled";
    document.getElementById('traitSelection').style.display = 'none';
}

function clearCurrentTraitSelection() {
    var traitElement = document.getElementById('trait');
    for (var i = 0; i < traitElement.length; i++) {
        traitElement.options[i].selected = false;
    }
}

function enableContinue() {
    clearCurrentTraitSelection();
    document.getElementById("loadTraitElement").disabled = "";
}

function sortSelect(selectToSort) {
    var arrOptions = [];

    for (var i = 0; i < selectToSort.options.length; i++) {
        arrOptions[i] = [];
        arrOptions[i][0] = selectToSort.options[i].value;
        arrOptions[i][1] = selectToSort.options[i].text;
        arrOptions[i][2] = selectToSort.options[i].selected;
    }

    arrOptions.sort(function (a, b) {
        return a[1] < b[1] ? -1 : a[1] > b[1] ? 1 : 0;
    });

    for (i = 0; i < selectToSort.options.length; i++) {
        selectToSort.options[i].value = arrOptions[i][0];
        selectToSort.options[i].text = arrOptions[i][1];
        selectToSort.options[i].selected = arrOptions[i][2];
    }
}


