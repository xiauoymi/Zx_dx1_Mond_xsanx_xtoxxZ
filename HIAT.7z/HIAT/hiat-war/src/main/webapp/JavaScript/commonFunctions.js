String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g,"");
};
String.prototype.ltrim = function() {
	return this.replace(/^\s+/,"");
};
String.prototype.rtrim = function() {
	return this.replace(/\s+$/,"");
};

function displayExceptionDetails() {
  document.getElementById('exceptionDetails').style.display = 'block';
}

function addEvent(obj, evType, fn) {
  if (obj.addEventListener) {
    obj.addEventListener(evType, fn, false);
    return true;
  } else if (obj.attachEvent) {
    return obj.attachEvent("on" + evType, fn);
  } else {
    return false;
  }
}

function createCalendar(textInputId, containerId) {
  var calendarMenuId = "calMenu-" + containerId;
  var calendarMenuBodyId = "calMenuBody-" + containerId;
  var calendarId = "cal-" + containerId;
  var buttonId = "btn-" + containerId;
  var oCalendarMenu = new YAHOO.widget.Overlay(calendarMenuId, { visible: false });
  var oCalButton = new YAHOO.widget.Button({
    type: "menu",
    className:"calender-button",
    id: buttonId,
    label: "Choose A Date",
    menu: oCalendarMenu,
    container: containerId });

  oCalButton.on("appendTo", function () {
    oCalendarMenu.setBody(" ");
    oCalendarMenu.body.id = calendarMenuBodyId;
    oCalendarMenu.render(this.get("container"));
  });

  var oCalButtonClick = function () {
    var oCalendar = new YAHOO.widget.Calendar(calendarId, oCalendarMenu.body.id);
    oCalendar.cfg.setProperty("DATE_FIELD_DELIMITER", "-");  
    oCalendar.cfg.setProperty("MDY_DAY_POSITION", 2);
    oCalendar.cfg.setProperty("MDY_MONTH_POSITION", 1);   
    oCalendar.cfg.setProperty("MDY_YEAR_POSITION", 3);
    oCalendar.render();
    oCalendar.changePageEvent.subscribe(function () {
      window.setTimeout(function () {
        oCalendarMenu.show();
      }, 0);
    });

    oCalendar.selectEvent.subscribe(function (p_sType, p_aArgs) {
      if (p_aArgs) {
        var period = document.getElementById(textInputId);
        var selDate = oCalendar.getSelectedDates()[0];
        var dStr = getDoubleDigitsForDate(selDate.getDate());
//        var monthShort = oCalendar.cfg.getProperty("MONTHS_SHORT")[selDate.getMonth()];
        var monthShort = getDoubleDigitsForDate(selDate.getMonth() + 1);
        var yStr = selDate.getFullYear();
        period.value = monthShort + "-" + dStr + "-" + yStr;
      }
      oCalendarMenu.hide();
    });
    this.unsubscribe("click", oCalButtonClick);
  }
  oCalButton.on("click", oCalButtonClick);
}

function getDoubleDigitsForDate(value) {
  if (value.toString().length == 1) {
    return '0' + value;
  }
  return value;
}


