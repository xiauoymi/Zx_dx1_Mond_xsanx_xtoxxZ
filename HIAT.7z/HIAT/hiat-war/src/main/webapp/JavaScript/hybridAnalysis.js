var areOneOrMoreDetailsChecked = false;

function onbodyLoad() {
    setSelectedTraits("traitsToBeIncluded", "possibleTraitComb");
    var contextPath = document.getElementById('contextPath').value;
    var saveScenarioSuccessfull = document.getElementById("saveScenarioSuccessfull").value;
    if (saveScenarioSuccessfull === "true") {
        var scenarioName = document.getElementById("scenarioName").value;
        window.showModalDialog(contextPath +
                               '/popup/scenario?method=displaySaveSuccessfulMessage', scenarioName, 'dialogWidth:200px; dialogHeight:150px');
    } else if (saveScenarioSuccessfull === "false") {
        document.getElementById("saveHybridAnalysisBtn").disabled = '';
        showReplaceOrSaveNewScenarioFrm();
    }
}

function toggleFilterParentTraits() {
    if (document.getElementById("traitFilterToggle").innerHTML === "Filter Left Hand Parent Traits") {
      document.getElementById("traitFilterToggle").innerHTML = "Close Filter Left Hand Parent Traits";
      document.getElementById("showFilterParentTraits").value = 'true';
      document.getElementById('displayTraitCombinations').style.display = '';
    } else {
        document.getElementById("traitFilterToggle").innerHTML = "Filter Left Hand Parent Traits";
        document.getElementById("showFilterParentTraits").value = '';
        document.getElementById('displayTraitCombinations').style.display = 'none';
    }
}

function showSaveScenarioFrm() {
    var contextPath = document.getElementById('contextPath').value;
    document.getElementById("saveHybridAnalysisBtn").disabled = "disabled";
    window.showModalDialog(contextPath +
                           '/popup/scenario?method=displaySaveScenarioForm', saveHybridAnalysis, 'dialogWidth:500px; dialogHeight:300px');
    document.getElementById("saveHybridAnalysisBtn").disabled = '';
}

function showReplaceOrSaveNewScenarioFrm() {
    var contextPath = document.getElementById('contextPath').value;
    var scenarioName = document.getElementById("newScenarioName").value;
    if (scenarioName === '') {
        scenarioName = document.getElementById("scenarioName").value;
    }
    var scenarioDesc = document.getElementById("scenarioDesc").value;
    var isRerun = document.getElementById("isRerun").value;
    window.showModalDialog(contextPath +
                           '/popup/scenario?method=displayReplaceOrSaveNewScenarioForm&scenarioName=' +
                           scenarioName + '&scenarioDesc=' + scenarioDesc + '&isRerun=' + isRerun
            , saveHybridAnalysis, 'dialogWidth:700px; dialogHeight:500px');
}

function saveHybridAnalysis(scenarioFrm, method) {
    document.getElementById('scenarioName').value = scenarioFrm.scenarioName.value;
    document.getElementById('scenarioDesc').value = scenarioFrm.scenarioDesc.value;
    document.getElementById('isRerun').value = scenarioFrm.isRerun == null ? 'false' : scenarioFrm.isRerun.value;
    document.getElementById('productName').disabled = false;
    document.getElementById('trait').disabled = false;
    var frm = document.getElementById('generateAnalysisFrm');
    frm.action = document.getElementById('contextPath').value + "/servlet/scenario?method=" + method;
    frm.submit();
}

function selectedTraitsAsString(selectObject) {
    //todo this is duplicated in traitCombFilter.js, need to refactor
    var selectedTraits = '';
    for(i = 0; i < selectObject.options.length; i++) {
        if (selectObject.options[i].selected) {
            selectedTraits = selectedTraits + selectObject.options[i].value + '_';
        }
    }
    return selectedTraits;
}

function downloadHybridAnalysis() {
    var contextPath = document.getElementById('contextPath').value;
    document.getElementById("trait").disabled = false;
    var productNames = document.getElementById('productName').value;
    var traitCombSelectControl = document.getElementById('possibleTraitComb');
    var selectedTraits = selectedTraitsAsString(traitCombSelectControl);
    document.generateAnalysisFrm.action = contextPath + "/downloadHybridAnalysis/hybrid?method=downloadHybridAnalysis" +
              "&productName=" + escape(productNames) + "&possibleTraitComb=" + escape(selectedTraits);
    document.generateAnalysisFrm.submit();
    document.getElementById("trait").disabled = "disabled";
}

function downloadSavedScenario() {
    var contextPath = document.getElementById('contextPath').value;
    document.getElementById("trait").disabled = false;
    var frm = document.getElementById('generateAnalysisFrm');
    frm.action = contextPath + "/downloadSavedScenario/scenario?method=downloadSavedScenario";
    frm.submit();
}

function downloadCurrentValuesForSavedScenario() {
    var contextPath = document.getElementById('contextPath').value;
    var frm = document.getElementById('generateAnalysisFrm');
    frm.action = contextPath +
                 "/downloadCurrentValuesForSavedScenario/scenario?method=downloadCurrentValuesForSavedScenario";
    frm.submit();

}

function rerunHybridAnalysis() {
    var frm = document.getElementById('generateAnalysisFrm');
    frm.action = document.getElementById('contextPath').value + "/servlet/scenario?method=rerunScenario";
    frm.submit();
}

function selectUnselectAllDetails(selectOrNot, productId, traitId) {
    var chkBxs = document.getElementsByName('selectedAnalysisDetailsChkBx' + productId + traitId);
    for (var i = 0; i < chkBxs.length; i++) {
        var chkBx = chkBxs[i];
        chkBx.checked = selectOrNot;
    }
}

function showAllDetails(showOrNot, productId, traitId) {
    var showSelectedBtn = document.getElementById('showSelectedBtn' + productId + traitId);
    var showAllBtn = document.getElementById('showAllBtn' + productId + traitId);
    if (showOrNot) {
        showSelectedBtn.disabled = false;
        showAllBtn.disabled = true;
    } else {
        showSelectedBtn.disabled = true;
        showAllBtn.disabled = false;
    }
    var style = showOrNot ? '' : 'none';
    var unSelectedDetails = document.getElementsByName('unSelectedDetail' + productId + traitId);
    for (var i = 0; i < unSelectedDetails.length; i++) {
        var unSelectedDetail = unSelectedDetails[i];
        unSelectedDetail.style.display = style;
    }
}

function generateAnalysis() {
    var contextPath = document.getElementById('contextPath').value;
    document.generateAnalysisFrm.action = contextPath + "/hybrid/hybrid?method=generateAnalysis";
    document.generateAnalysisFrm.submit();
}


addEvent(window, 'load', onbodyLoad);