window.onload = start;

function onLoadOfInbredAnalysis() {
    showHideAnalysisResults();
    if (document.getElementById("displayAnalysisResults").value === "true") {
        document.getElementById("productName").disabled = "disabled";
        document.getElementById("trait").disabled = "disabled";
    }

}

function selectAllTraits(valueForSelected) {
    var selectElement = document.getElementById('trait');
    for (var i = 0; i < selectElement.options.length; i++) {
        selectElement.options[i].selected = valueForSelected;
    }
}

function downloadInbredStatus() {
    var contextPath = document.getElementById('contextPath').value;
    var productNames = document.getElementById('productName').value;
    document.getElementById("trait").disabled = false;
    document.generateAnalysis.action = contextPath + "/downloadInbredStatus/inbredStatus?method=downloadInbredAnalysis" +
                                       "&productName=" + escape(productNames);
    document.generateAnalysis.submit();
    document.getElementById("trait").disabled = "disabled";
}

function generateInbredStatus() {
    document.getElementById("go").disabled = "disabled";
    var contextPath = document.getElementById('contextPath').value;
    document.generateAnalysis.action = contextPath + "/servlet/inbredStatus?method=generateAnalysis";
    document.generateAnalysis.submit();
}

function downloadInbredAnalysis() {
    var contextPath = document.getElementById('contextPath').value;
    var productNames = document.getElementById('productName').value;
    document.getElementById("trait").disabled = false;
    document.generateAnalysis.action = contextPath + "/downloadInbredAnalysis/inbredAnalysis?method=downloadInbredAnalysis" +
                                       "&productName=" + escape(productNames);
    document.generateAnalysis.submit();
    document.getElementById("trait").disabled = "disabled";
}

function generateInbredAnalysis() {
    document.getElementById("go").disabled = "disabled";
    var contextPath = document.getElementById('contextPath').value;
    document.generateAnalysis.action = contextPath + "/servlet/inbredAnalysis?method=generateAnalysis";
    document.generateAnalysis.submit();
}

function showHideAnalysisResults() {
    var displayAnalysisResults = document.getElementById('displayAnalysisResults').value;
    if (displayAnalysisResults === 'true') {
        document.getElementById('analysisResults').style.display = 'block';
        if (document.getElementById("analysisResultsSize").value > 0) {
            document.getElementById('download').disabled = false;
            document.getElementById('go').disabled = "disabled";
        }
    } else {
        document.getElementById('analysisResults').style.display = 'none';
        document.getElementById('go').disabled = "";
    }
}

function updateTraitCombFilterSelectBox(o) {
    // do nothing for inbred
}