function onbodyLoad(){
  var numOfScenariosDeleted = document.getElementById('numOfScenariosDeleted').value;
  if(numOfScenariosDeleted != "" && parseInt(numOfScenariosDeleted) > 0){
    alert(numOfScenariosDeleted + " scenario(s) successfully deleted.");
  }
  createCalendars();
}

function createCalendars() {
    var loader = new YAHOO.util.YUILoader();
    var contextPath = document.getElementById('contextPath').value;
    loader.sandbox({
        require: ["button","calendar","containercore", "container"],  
        base: contextPath + '/JavaScript/yui/build/',
        filter: "MIN",
        combine: true,
        allowRollup: true,  
        loadOptional: false,
        onSuccess: function() {
            createCalendar("saveDateFrom", "saveDateFromContainer");
            createCalendar("saveDateTo", "saveDateToContainer");
        }
    });
    loader.insert();
}

function clearResults() {
  document.getElementById('saveDateFrom').value = '';
  document.getElementById('saveDateTo').value = '';
  document.getElementById('scenarioName').value = '';
  document.getElementById('searchResultsDiv').innerHTML = '';
}

function sortSavedScenarios(anchor) {
  var th = anchor.parentElement;
  document.getElementById('sortKey').value = th.id;
  document.getElementById('sortDir').value = th.className.search(/forwardSort/) === -1 ? 'asc' : 'desc';

  clearResults();
  document.getElementById('searchSavedScenariosFrm').submit();
}

function deleteSavedScenarios() {
  var scenarioToDeleteChkBox = document.getElementsByName('scenarioToDeleteChkBox');
  var ids = "";
  for (var i = 0; i < scenarioToDeleteChkBox.length; i++) {
    if (scenarioToDeleteChkBox[i].checked) {
      ids += scenarioToDeleteChkBox[i].value + ",";
    }
  }
  if (ids === "") {
    alert('Please select scenarios to delete');
  } else {
    ids = ids.substring(0, ids.length - 1);
    if (confirm("Click OK to delete " + ids.split(",").length + " selected scenario(s).")) {
      var scenarioIdsToDelete = document.getElementById('scenarioIdsToDelete');
      scenarioIdsToDelete.value = ids;
      clearResults();
      document.getElementById('method').value = "deleteScenario";
      document.getElementById('searchSavedScenariosFrm').submit();
    }
  }
}


addEvent(window, 'load', onbodyLoad);
