function saveScenario() {
  var saveScenarioFrm = document.getElementById("saveScenarioFrm");
    if(saveScenarioFrm.scenarioName.value.trim() === ''){
        alert('Please enter a scenario name');
    }else{
        //window.dialogArguments will give you parent's form that was passed.
        window.close();
        var func = window.dialogArguments;
        func(document.getElementById("saveScenarioFrm"), "saveScenario");
    }
}

function replaceScenario() {
  //window.dialogArguments will give you parent's form that was passed.
  window.close();
  var func = window.dialogArguments;
  func(document.getElementById("replaceScenarioFrm"), "replaceScenario");
}

function cancelSaveScenario() {
  window.close();
}

function displayScenarioName(){
  document.getElementById('scenarioName').innerHTML = window.dialogArguments;
}