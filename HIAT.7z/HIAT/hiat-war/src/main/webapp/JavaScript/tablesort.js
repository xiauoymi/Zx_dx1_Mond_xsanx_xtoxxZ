var customTableSort = {
  initSort : function() {
    if (!document.getElementsByTagName) return;

    var tables = document.getElementsByTagName('table');
    for (var t = 0, tbl; tbl = tables[t]; t++) {
      var sortedByClassName = tbl.className.search(/sortedBy-/) != -1 ? tbl.className.match(/sortedBy-(\w+)-(\w+)/) : "";

      if (sortedByClassName != "") {
        var sortKey = sortedByClassName != "" ? sortedByClassName[1] : "";
        var sortDir = sortedByClassName != "" ? sortedByClassName[2] : "";
        var sortClass = sortDir === "asc" ? 'forwardSort' : 'reverseSort';

        var ths = tbl.getElementsByTagName('th');
        for (var k = 0, th; th = ths[k]; k++) {
          if (th.className.search(/sortable/) != -1) {
            if (th.id === sortKey) {
              th.className = th.className.replace(/forwardSort|reverseSort/, "");
              th.className = th.className + " " + sortClass;
              break;
            }
          }
        }
      }
    }
  }
};

addEvent(window, 'load', customTableSort.initSort);

