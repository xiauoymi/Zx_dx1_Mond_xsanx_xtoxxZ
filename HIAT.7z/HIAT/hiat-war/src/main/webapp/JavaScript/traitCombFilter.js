function updateTraitCombFilterSelectBox(selectObject) {
    if (YAHOO.util.Connect.isCallInProgress(this.getXML)) {
        YAHOO.util.Connect.abort(this.getXML, null, false);
    }

    var selectedTraits = '';
    for(i = 0; i < selectObject.options.length; i++) {
        if (selectObject.options[i].selected) {
            selectedTraits = selectedTraits + selectObject.options[i].value + '_';
        }
    }
    var possibleTraitComb = document.getElementById('possibleTraitComb');
    removeAllOptions(possibleTraitComb);
    if(selectedTraits != null && selectedTraits != '') {
        var createTraitList = {
          success: function(o) {
            fillSelectDropdown(o.responseXML, possibleTraitComb);
          },
          failure: function(o) {
          alert("Error occurred while retrieving Possible Trait Combinations");
          },
          cache:true,
          timeout: 20000 //10 seconds
        };
        this.getXML = YAHOO.util.Connect.asyncRequest("GET",
            "/hiat/data/possibleTraitComb/hybrid?method=getPossibleTraitCombinations&selectedTraits=" + selectedTraits,
            createTraitList);
    }
}

function fillSelectDropdown(xmlDoc, selectElement) {
  var elements = xmlDoc.getElementsByTagName('TRAIT');
  for (var i = 0; i < elements.length; i++) {
      /*todo this is assuming that elements ALWAYS appear in the same order, and there are no extra stuff in between - not good.
        They have NAMES for a REASON*/
    var traitId = elements[i].childNodes[0].firstChild.nodeValue;
    var traitCode = elements[i].childNodes[1].firstChild.nodeValue;
    var docoption = document.createElement("OPTION");
    docoption.text = traitCode;
    docoption.value = traitId;
    selectElement.options.add(docoption);
  }

  for (var i = 0; i < selectElement.options.length; i++) {
      selectElement.options[ i ].selected = true;
  }
  var unselectedTraits = document.getElementById('unselectedTraits');
    for (var i = 0; i < selectElement.options.length; i++) {
        for (var j = 0; j < unselectedTraits.length; j++) {
            if (selectElement.options[ i ].value == unselectedTraits.options[j].value) {
                selectElement.options[ i ].selected = false;
                break;
            }
        }
    }
}

function traceUnselectedPossibleTraits(selectbox) {
    var unselectedTraits = document.getElementById('unselectedTraits');
    removeAllOptions(unselectedTraits);
    var docoption = document.createElement("OPTION");
    for(var i = 0; i < selectbox.options.length; i++) {
       if (!selectbox.options[i].selected) {
         var docoption = document.createElement("OPTION");
         docoption.text = selectbox.options[i].text;
         docoption.value = selectbox.options[i].value;
         unselectedTraits.options.add(docoption);
       }
    }
}


function removeAllOptions(selectbox) {
  var i;
  for (i = selectbox.options.length - 1; i >= 0; i--) {
    selectbox.remove(i);
  }
}