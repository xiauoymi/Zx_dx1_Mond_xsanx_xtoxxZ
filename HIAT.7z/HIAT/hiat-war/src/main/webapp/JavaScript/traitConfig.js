function inActivateTrait() {
    //var traitsToBeInActivated = document.getElementById('traitsToBeInactivated').value;
    var contextPath = document.getElementById('contextPath').value;
    document.traitConfigFrm.action = contextPath + "/servlet/configTrait?method=configTrait&configType=inActivate";
    document.traitConfigFrm.submit();
}

function activateTrait() {
    //var traitsToBeActivated = document.getElementById('traitsToBeActivated').value;
    var contextPath = document.getElementById('contextPath').value;
    document.traitConfigFrm.action = contextPath + "/servlet/configTrait?method=configTrait&configType=activate";
    document.traitConfigFrm.submit();
}