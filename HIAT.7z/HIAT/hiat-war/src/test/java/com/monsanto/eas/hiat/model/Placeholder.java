package com.monsanto.eas.hiat.model;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class Placeholder {
}
