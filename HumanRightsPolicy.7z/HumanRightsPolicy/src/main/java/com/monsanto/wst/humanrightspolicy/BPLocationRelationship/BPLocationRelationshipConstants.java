/*
 BPLocationRelationshipConstants was created on Feb 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.BPLocationRelationship;

/**
 * @author sspati1
 */
public class BPLocationRelationshipConstants {
///CLOVER:OFF
  private BPLocationRelationshipConstants() {
  }
///CLOVER:ON

  public static final String METHOD_LOOKUP_BP_LOC_RELS_FOR_LOC_XML = "lookupBPLocRelsForLocationXML";
  public static final String METHOD_SET_PRIMARY_LOCATION = "setPrimaryLocation";
  public static final String METHOD_END_BP_LOCATION_RELATIONSHIP = "endBPLocationRelationship";
}