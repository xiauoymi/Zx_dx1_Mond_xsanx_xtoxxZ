/*
 BPLocationRelationshipController was created on Feb 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.BPLocationRelationship.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.LookupBPDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate.DBTemplateLookupBPDAOImpl;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.controller.HrpController;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.dao.LookupLocationDAO;
import com.monsanto.wst.humanrightspolicy.location.dao.dbtemplate.DBTemplateLocationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author sspati1
 */
public class BPLocationRelationshipController extends HrpController {

  protected void notSpecified(UCCHelper helper) throws IOException {
    helper.forward(HRPMainConstants.HRP_HOME_JSP);
  }

  public void setPrimaryLocation(UCCHelper helper) throws IOException {
    String bpId = helper.getRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID);
    String locId = helper.getRequestParameterValue(LocationsConstants.LOCATION_ID);
    BusinessPartner bp = getSearchBPDAO().lookupBPById(bpId);
    Location loc = getLocationDAO().lookupLocationById(locId);
    bp.setPrimaryLocation(loc);

    Document response = appendUpdatedInfoToResponse(bp);
    helper.setContentType("text/xml");
    helper.writeXMLDocument(response, HRPMainConstants.LATIN1_ENCODING);
  }

  /**
   * This method looks up bp location relationships for location
   *
   * @param helper - UCCHelper - helper
   *
   * @exception IOException - IOException
   */
  public void lookupBPLocRelsForLocationXML(UCCHelper helper) throws IOException {
    String locationId = helper.getRequestParameterValue(LocationsConstants.LOCATION_ID);
    BPLocationRelationship bpLocRel = getBPLocRelsForLocation(locationId);
    String menuLocation = helper.getRequestParameterValue(HRPMainConstants.MENU);
    Document response = appendBpLocRelsForLocation(bpLocRel, menuLocation);
    helper.setContentType("text/xml");
    helper.writeXMLDocument(response, HRPMainConstants.LATIN1_ENCODING);
  }

  protected BusinessPartner getBPImpl(String bpId) {
    return new BusinessPartnerImpl(bpId, null, null, null, null, null, null, null, null, null);
  }

  protected Location getLocationImpl(String locationId) {
    return new LocationImpl(locationId, null, null, null, "N", null, null, null, null, null, null, null,
        null, null, null, null);
  }

  protected LookupLocationDAO getLocationDAO() {
    return new DBTemplateLocationDAO(getTemplate(), InitService.initLocationTypeDAO());
  }

  protected LookupBPDAO getSearchBPDAO() {
    return new DBTemplateLookupBPDAOImpl(getTemplate());
  }

  private BPLocationRelationship getBPLocRelsForLocation(String locationId) {
    Location location = getLocationImpl(locationId);
    return location.getActiveBPLoctationRelationship();
  }

  private Document appendBpLocRelsForLocation(BPLocationRelationship bpLocRel, String menuLocation) {
    Document response = createNewDocument();
    Element bpLocRelsElement = response.createElement("bps");
    if (bpLocRel != null) {
        Element bpLocRelElement = response.createElement("bp");
        DOMUtil.addChildElement(bpLocRelElement, "relId", bpLocRel.getId());
        DOMUtil.addChildElement(bpLocRelElement, "bpId", bpLocRel.getBusinessPartner().getPartnerId());
        DOMUtil.addChildElement(bpLocRelElement, "sapId", bpLocRel.getBusinessPartner().getSapId());
        DOMUtil.addChildElement(bpLocRelElement, "bpName", bpLocRel.getBusinessPartner().getEntityName());
        DOMUtil.addChildElement(bpLocRelElement, "aliasName", bpLocRel.getBusinessPartner().getAliasName());
        Address address = bpLocRel.getBusinessPartner().getPrimaryRelationship().getLocation().getAddress();
        DOMUtil.addChildElement(bpLocRelElement, "state", address.getStateModel().getValue());
        DOMUtil.addChildElement(bpLocRelElement, "country", address.getCountryModel().getValue());
        DOMUtil.addChildElement(bpLocRelElement, "region", address.getRegionModel().getValue());
    //      DOMUtil.addChildElement(bpLocRelElement,"editable", bpLocRel.getLocation().getLocationType().getEditable());
        DOMUtil.addChildElement(bpLocRelElement, "viewUrl",
            new HrpUrlBuilder(menuLocation).getViewBpUrl(bpLocRel.getBusinessPartner().getPartnerId()));
        bpLocRelsElement.appendChild(bpLocRelElement);
    }
    response.appendChild(bpLocRelsElement);
    return response;
  }

  private Document appendUpdatedInfoToResponse(BusinessPartner bp) {
    Document response = createNewDocument();
    Element result = response.createElement("response");
    Element addressElement = response.createElement("address");
    BPLocationRelationship primaryRel = bp.getPrimaryRelationship();
    Location primaryRelsLocation = primaryRel.getLocation();
    Address address = primaryRelsLocation.getAddress();
    DOMUtil.addChildElement(addressElement, "streetAddress1", address.getStreetAddress1());
    DOMUtil.addChildElement(addressElement, "streetAddress2", address.getStreetAddress2());
    DOMUtil.addChildElement(addressElement, "city", address.getCity());
    DOMUtil.addChildElement(addressElement, "state", address.getStateModel().getValue());
    DOMUtil.addChildElement(addressElement, "country", address.getCountryModel().getValue());
    DOMUtil.addChildElement(addressElement, "region", address.getRegionModel().getValue());
    DOMUtil.addChildElement(addressElement, "zip", address.getZipcode());
    result.appendChild(addressElement);
    DOMUtil.addChildElement(result, "locName", primaryRelsLocation.getLocationName());
    DOMUtil.addChildElement(result, "relType", primaryRel.getBpLocRelType().getType());
    response.appendChild(result);
    return response;
  }

  public void endBPLocationRelationship(UCCHelper helper) throws IOException {
    String bpId = helper.getRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID);
    BusinessPartner bp = getSearchBPDAO().lookupBPById(bpId);
    List<String> locationIds = getSelectedLocationIds(bp);

    BPLocationRelationship bpLocRel = bp.getPrimaryRelationship();
    String primaryLocationId = bpLocRel.getLocation().getLocationId();
    for (String locId : locationIds) {
      Location location = getLocationDAO().lookupLocationById(locId);
      if (!location.getIsSap()) {
        if (primaryLocationId.equals(locId)) {
          List<Location> locations = bpLocRel.getBusinessPartner().getLocations();
          setSapLocationAsPrimaryLocationForBP(helper, bp, locations);
        }
        bp.endBpLocRelationship(location);
      }
    }
    String menu = helper.getRequestParameterValue(HRPMainConstants.MENU);
    helper.forward("businessPartner?method=lookupBP&businessPartnerId=" + bpId + "&menu=" + menu);
  }

  private List<String> getSelectedLocationIds(BusinessPartner bp)  {
    if (isAllSelected()) {
      List<BPLocationRelationship> bpLocRels = bp.getActiveBPLocationRelationships();
      List<String> selectedIds = new ArrayList<String>();
      for (BPLocationRelationship rel : bpLocRels) {
        selectedIds.add(rel.getLocation().getLocationId());
      }
      List<String> idsToExclude = getIdsToExclude();
      for (String id : idsToExclude) {
        selectedIds.remove(id);
      }
      return selectedIds;
    } else {
      return getSelectedIds();
    }
  }

  private void setSapLocationAsPrimaryLocationForBP(UCCHelper helper, BusinessPartner bp,
                                                    List<Location> locations) {
    for (Location location : locations) {
      boolean isSap = location.getIsSap();
      if (isSap) {
        bp.setPrimaryLocation(location);
        return;
      }
    }
  }
}