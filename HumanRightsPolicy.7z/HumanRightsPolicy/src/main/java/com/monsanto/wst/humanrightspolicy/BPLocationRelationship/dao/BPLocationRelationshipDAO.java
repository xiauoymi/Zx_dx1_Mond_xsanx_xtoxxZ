/*
 BPLocationRelationshipDAO was created on Feb 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao;

import com.monsanto.wst.humanrightspolicy.model.BPLocationRelationship;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.Location;

import java.util.List;

/**
 * @author sspati1
 */
public interface BPLocationRelationshipDAO {
  List<BPLocationRelationship> getActiveBPLocationRelationshipsForBP(BusinessPartner businessPartner
  );

  void endBPLocationRelationship(String bpLocRelId
  );

  void saveBPLocationRelationship(BPLocationRelationship bpLocRel);

  BPLocationRelationship getActiveBPLocationRelationshipForLocation(Location location
  );

    void endBPLocRelForLocation(BusinessPartner bp, Location location);
}