/*
 BPLocationRelationshipImpl was created on Feb 8, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao;

import com.monsanto.wst.humanrightspolicy.model.BPLocationRelationship;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.Location;
import com.monsanto.wst.humanrightspolicy.model.LocationType;
import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import com.monsanto.wst.textutil.TextUtil;

import java.util.Date;

/**
 * @author sspati1
 */
public class BPLocationRelationshipImpl implements BPLocationRelationship {
  private String id;
  private BusinessPartner businessPartner;
  private Location location;
  private boolean isPrimary;
  private LocationType bpLocRelType;
  private Date startDate;
  private Date endDate;

  public BPLocationRelationshipImpl() {
  }

  public BPLocationRelationshipImpl(String relId, BusinessPartner bp, Location loc, boolean primary,
                                    LocationType bpLocRelType, Date startDate,
                                    Date endDate) {
    this.id = relId;
    this.businessPartner = bp;
    this.location = loc;
    this.isPrimary = primary;
    this.bpLocRelType = bpLocRelType;
    this.startDate = startDate;
    this.endDate = endDate;
  }

  public void setId(String id) {
    this.id = id;
  }

  public boolean equals(Object obj) {
    if (obj instanceof BPLocationRelationship) {
      BPLocationRelationship objLocRel = (BPLocationRelationship) obj;
      return id.equals(objLocRel.getId());
    } else {
      return false;
    }
  }

  public int hashCode() {
    return id.hashCode();
  }

  public BusinessPartner getBusinessPartner() {
    return businessPartner;
  }

  public boolean getIsPrimary() {
    return isPrimary;
  }

  public Date getStartDate() {
    return startDate;
  }

  public Date getEndDate() {
    return endDate;
  }

  public Location getLocation() {
    return location;
  }

  public String getId() {
    return id;
  }

  public LocationType getBpLocRelType() {
    return bpLocRelType;
  }

  public String getIsPrimaryAsYOrN(){
    return isPrimary ? "Y": "N";
  }

  public String getIsSapAsYOrN(){
    return location.getIsSap() ? "Y": "N";
  }

  public String toXml() {
    String locationId = getLocation().getLocationId();
    String bpId = getBusinessPartner().getPartnerId();
    String viewUrl = new HrpUrlBuilder("bp").getViewLocationUrl(locationId);
    String removeUrl = new HrpUrlBuilder("bp").getEndBPLocationRelationship(bpId, locationId);
    String updatePrimaryFlagUrl = new HrpUrlBuilder("bp").getSetPrimaryLocationForBpUrl(locationId, bpId);
    StringBuffer xml = new StringBuffer("<location>");
    xml.append("<relId>").append(TextUtil.escapeXml(getId())).append("</relId>");
    xml.append("<isPrimary>").append(TextUtil.escapeXml(getIsPrimaryAsYOrN())).append("</isPrimary>");
    xml.append("<locId>").append(TextUtil.escapeXml(locationId)).append("</locId>");
    xml.append("<sapId>").append(TextUtil.escapeXml(getLocation().getSapId())).append("</sapId>");
    xml.append("<locName>").append(TextUtil.escapeXml(getLocation().getLocationName())).append("</locName>");
    xml.append("<bpLocRelType>").append(TextUtil.escapeXml(getBpLocRelType().getType())).append("</bpLocRelType>");
    xml.append("<state>").append(TextUtil.escapeXml(getLocation().getAddress().getStateModel().getValue())).append("</state>");
    xml.append("<country>").append(TextUtil.escapeXml(getLocation().getAddress().getCountryModel().getValue())).append("</country>");
    xml.append("<region>").append(TextUtil.escapeXml(getLocation().getAddress().getRegionModel().getValue())).append("</region>");
    xml.append("<isSap>").append(TextUtil.escapeXml(getIsSapAsYOrN())).append("</isSap>");
    xml.append("<removeUrl>").append(TextUtil.escapeXml(removeUrl)).append("</removeUrl>");
    xml.append("<viewUrl>").append(TextUtil.escapeXml(viewUrl)).append("</viewUrl>");
    xml.append("<updatePrimaryFlagUrl>").append(TextUtil.escapeXml(updatePrimaryFlagUrl)).append("</updatePrimaryFlagUrl>");
    xml.append("</location>");
    return xml.toString();
  }
}