/*
 DbTemplateBPLocationRelationshipDAO was created on Apr 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.dbtemplate;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipImpl;
import com.monsanto.wst.humanrightspolicy.model.BPLocationRelationship;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.Location;
import com.monsanto.wst.humanrightspolicy.model.TempBPLocationRelationship;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: DBTemplateBPLocationRelationshipDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-02 20:12:52 $
 *
 * @author sspati1
 * @version $Revision: 1.13 $
 */
public class DBTemplateBPLocationRelationshipDAO implements BPLocationRelationshipDAO {
  private final DBTemplate template;

  public DBTemplateBPLocationRelationshipDAO(DBTemplate template) {
    this.template = template;
  }

  public List<BPLocationRelationship> getActiveBPLocationRelationshipsForBP(BusinessPartner businessPartner) {
    List<BPLocationRelationship> bpLocRels = new ArrayList<BPLocationRelationship>();
    List<TempBPLocationRelationship> tempBpLocRels = this.template.executeListResultQuery("getActiveBPLocationRelsForBP", businessPartner.getPartnerId());
    for(TempBPLocationRelationship tempBpLocRel: tempBpLocRels){
      BPLocationRelationship bpLocRel = new BPLocationRelationshipImpl(tempBpLocRel.getRelationship().getId(),
          businessPartner, tempBpLocRel.getRelationship().getLocation(), tempBpLocRel.getRelationship().getIsPrimary(),
          tempBpLocRel.getRelationship().getBpLocRelType(), tempBpLocRel.getRelationship().getStartDate(),
          tempBpLocRel.getRelationship().getEndDate());
      bpLocRels.add(bpLocRel);
    }
    return bpLocRels;
  }

  public BPLocationRelationship getActiveBPLocationRelationshipForLocation(Location location) {
    TempBPLocationRelationship tempBpLocRel = (TempBPLocationRelationship) this.template.executeSingleResultQuery("getActiveBPLocationRelForLocation", location.getLocationId());
      return new BPLocationRelationshipImpl(tempBpLocRel.getRelationship().getId(),
          tempBpLocRel.getRelationship().getBusinessPartner(), location, tempBpLocRel.getRelationship().getIsPrimary(),
          tempBpLocRel.getRelationship().getBpLocRelType(), tempBpLocRel.getRelationship().getStartDate(),
          tempBpLocRel.getRelationship().getEndDate());
  }

    public void endBPLocRelForLocation(BusinessPartner bp, Location location) {
      BPLocationRelationship bpLocRel = new BPLocationRelationshipImpl(null, bp, location, false, null, null, null);
        this.template.executeUpdate("endBPLocRelForLocation", bpLocRel);
    }

    public void endBPLocationRelationship(String bpLocRelId) {
    this.template.executeUpdate("endBPLocRel", bpLocRelId);
  }

  public void saveBPLocationRelationship(BPLocationRelationship bpLocRel) {
    this.template.executeInsert("assignLocationToBp", bpLocRel);
  }

}

