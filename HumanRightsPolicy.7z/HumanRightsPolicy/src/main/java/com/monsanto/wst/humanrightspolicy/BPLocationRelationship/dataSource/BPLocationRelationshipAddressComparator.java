/*
 BPLocationRelationshipAddressComparator was created on May 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dataSource;

import com.monsanto.wst.humanrightspolicy.model.Address;
import com.monsanto.wst.humanrightspolicy.model.BPLocationRelationship;

/**
 * Filename:    $RCSfile: BPLocationRelationshipAddressComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-05-08 17:38:02 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */

public abstract class BPLocationRelationshipAddressComparator extends BPLocationRelationshipComparator{
  protected abstract String getValue(Address addr);

  protected String getValue(BPLocationRelationship bpLocRel) {
    Address address = bpLocRel.getLocation().getAddress();
    if (address == null) {
      return null;
    } else {
      return getValue(address);
    }
  }
}