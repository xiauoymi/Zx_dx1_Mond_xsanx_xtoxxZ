/*
 BPLocationRelationshipComparator was created on May 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dataSource;

import com.monsanto.wst.humanrightspolicy.model.BPLocationRelationship;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: BPLocationRelationshipComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-05-15 15:26:55 $
 *
 * @author rrmall
 * @version $Revision: 1.3 $
 */
public abstract class BPLocationRelationshipComparator  implements Comparator<XmlObject> {
  protected abstract String getValue(BPLocationRelationship bpLocRel);

  public int compare(XmlObject o1, XmlObject o2) {
    if (o1 instanceof BPLocationRelationship && o2 instanceof BPLocationRelationship) {
      return compareRels((BPLocationRelationship ) o1, (BPLocationRelationship ) o2);
    } else {
      return 0;
    }
  }

  public int compareRels(BPLocationRelationship bp1, BPLocationRelationship bp2) {
    String value1 = blankIfNull(getValue(bp1));
    String value2 = blankIfNull(getValue(bp2));
    return value1.compareTo(value2);
  }

  public String blankIfNull(String st) {
    if (st == null) {
      return "";
    } else {
      return st;
    }
  }
}
