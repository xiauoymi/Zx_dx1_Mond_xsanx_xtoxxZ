/*
 BPLocationRelationshipDataSource was created on May 6, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dataSource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.datasource.ComparatorMap;
import com.monsanto.wst.humanrightspolicy.datasource.DataSource;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.ParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.UCCHelperParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;

/**
 * Filename:    $RCSfile: BPLocationRelationshipDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-12-04 16:50:10 $
 *
 * @author rrmall
 * @version $Revision: 1.15 $
 */
public class BPLocationRelationshipDataSource implements XmlDataSource {
    public static final String NAME_SORT_KEY = "locName";
    public static final String TYPE_SORT_KEY = "bpLocType";
    public static final String REGION_SORT_KEY = "region";
    public static final String COUNTRY_SORT_KEY = "country";
    public static final String STATE_SORT_KEY = "state";

    private static final ComparatorMap<XmlObject> comparatorMap;

    private final ParameterCollection params;
    private final LookupBPService bpService;

    static {
        comparatorMap = new ComparatorMap<XmlObject>(new BPLocationRelationshipDefaultComparator());
        comparatorMap.addComparator(NAME_SORT_KEY.toLowerCase(), new BPLocationRelationshipNameComparator());
        comparatorMap.addComparator(TYPE_SORT_KEY.toLowerCase(), new BPLocationRelationshipTypeComparator());
        comparatorMap.addComparator(REGION_SORT_KEY.toLowerCase(), new BPLocationRelationshipRegionComparator());
        comparatorMap.addComparator(COUNTRY_SORT_KEY.toLowerCase(), new BPLocationRelationshipCountryComparator());
        comparatorMap.addComparator(STATE_SORT_KEY.toLowerCase(), new BPLocationRelationshipStateComparator());
    }

    public BPLocationRelationshipDataSource(ParameterCollection params, LookupBPService bpService) {
        this.params = params;
        this.bpService = bpService;
    }

    public BPLocationRelationshipDataSource(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initSearchBPService());
    }

    public BPLocationRelationshipDataSource(UCCHelper helper, LookupBPService bpService) {
        this(new UCCHelperParameterCollection(helper), bpService);
    }

    public BPLocationRelationshipDataSource(ParameterCollection params) {
        this(params, InitService.initSearchBPService());
    }

    public List<? extends XmlObject> getData() throws IOException {
        BusinessPartner bp1 = bpService.lookupBPById(params.get(BusinessPartnerConstants.BUSINESS_PARTNER_ID));
        return bp1.getActiveBPLocationRelationships();
    }

    public Comparator<XmlObject> getComparator(String sortKey) {
        return comparatorMap.getComparator(sortKey);
    }

    public boolean isSorted() {
        return false;
    }

    public boolean isFiltered() {
        return false;
    }

    public int getTotalRecords() {
        return DataSource.UNKNOWN_RECORD_COUNT;
    }
}