package com.monsanto.wst.humanrightspolicy.Security.constants;

public class AdminConstants {
///CLOVER:OFF
  private AdminConstants() {
  }
///CLOVER:ON

  public static final String DISPLAY_ALL_USERS_JSP = "/WEB-INF/jsp/admin/displayAllUsers.jsp";
  public static final String UPDATE_USER_ACCESS = "/WEB-INF/jsp/admin/updateUserAccess.jsp";

  public static final String USERS_LIST = "userList";
  public static final String USER_ID = "userId";
  public static final String USER_NAME = "userName";
  public static final String ROLE_ID = "roleId";
  public static final String REGIONS = "regions";
  public static final String COUNTRIES = "countries";
  public static final String STATES = "states";
  public static final String HRP_USER = "hrpUser";
  public static final String ROLE_LIST = "roleList";
  public static final String PRIVILEGE_LIST = "privilegeList";

  public static final String USERMAINTAIN = "USERMAINTAIN";
  public static final String USER_ID_MISSING = "Please select a user";
  public static final String ROLE_ID_MISSING = "Please select a role";
  public static final String USER_ALREADY_EXISTS = "This user already has a role. Please select a different user";
  public static final String NEW_USER = "newUser";
  public static final String ADMIN_FLAG = "adminFlag";
  public static final String REGION_LIST = "regionList";
  public static final String COUNTRY_LIST = "countryList";
  public static final String STATE_LIST = "stateList";
  public static final String RELOAD = "reload";
  public static final String USER_DESCRIPTION = "userDescription";
  public static final String USER_EMAIL = "email";
  public static String ID = "id";

}
