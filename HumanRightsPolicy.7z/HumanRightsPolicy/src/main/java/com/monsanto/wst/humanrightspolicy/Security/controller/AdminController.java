/*
 AdminController was created on Mar 13, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.Security.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.Security.constants.AdminConstants;
import com.monsanto.wst.humanrightspolicy.Security.datasource.AdminDataSource;
import com.monsanto.wst.humanrightspolicy.Security.service.SecurityService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.controller.FilteredXmlDataSource;
import com.monsanto.wst.humanrightspolicy.controller.HrpController;
import com.monsanto.wst.humanrightspolicy.geodata.GeoDataFactory;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.humanrightspolicy.utils.MsgAndErrorUtil;

import java.io.IOException;
import java.util.*;

/**
 * @author sspati1
 */
public class AdminController extends HrpController {
//  private static final Log logger = LogFactory.getLog(AdminController.class);

  private final SecurityService securityService;
  private final GeoDataFactory geoDataFactory;
  private static final String[] NO_STRINGS = new String[0];

  private final GenericDAO<LoginUser, Long> userDAO;
  private final GenericDAO<Role, String> roleDAO;

  public AdminController() {
    this(InitService.initSecurityService(), InitService.initGeoDataFactory(),
        InitService.initUserDAO(), InitService.initRoleDAO());
  }

  public AdminController(SecurityService securityService,
                         GeoDataFactory geoDataFactory,
                         GenericDAO<LoginUser, Long> userDAO,
                         GenericDAO<Role, String> roleDAO) {
    this.securityService = securityService;
    this.geoDataFactory = geoDataFactory;
    this.userDAO = userDAO;
    this.roleDAO = roleDAO;
  }

  /**
   * This method displays all the user, thier roles and regions
   *
   * @param helper - UCCHelper
   *
   * @exception IOException - IOException
   */
  protected void notSpecified(UCCHelper helper) throws IOException {
    setUserListInResponse(lookupAllUsersWithAccess(), helper);
    helper.forward(AdminConstants.DISPLAY_ALL_USERS_JSP);
  }

  /**
   * This method looks up user, its role and regions
   *
   * @param helper - UCCHelper
   *
   * @exception IOException - IOException
   */
  public void lookupUserRole(UCCHelper helper) throws IOException {
    String userId = helper.getRequestParameterValue(AdminConstants.USER_ID);
    LoginUser hrpUser = getUserById(helper, userId);
    setUserInResponse(hrpUser, helper);
    setRegionCountryStateInResponse(helper, hrpUser);
    setRolesInResponse(lookupRoles(), helper);
    updateAllPrivilegeListWithUserSelectionFromRequest(hrpUser, helper);
    helper
        .setRequestAttributeValue(AdminConstants.NEW_USER, helper.getRequestParameterValue(AdminConstants.NEW_USER));
    helper.forward(AdminConstants.UPDATE_USER_ACCESS);
  }

  private LoginUser getUserById(UCCHelper helper, String userId) throws IOException {
    LoginUser hrpUser = this.securityService.lookupUserByCriteria(userId);
    if (hrpUser == null) {
      String userName = helper.getRequestParameterValue(AdminConstants.USER_NAME);
      String roleId = helper.getRequestParameterValue(AdminConstants.ROLE_ID);
      boolean isAdmin = "Y".equalsIgnoreCase(helper.getRequestParameterValue(AdminConstants.ADMIN_FLAG));
      String description = helper.getRequestParameterValue(AdminConstants.USER_DESCRIPTION);
      String email = helper.getRequestParameterValue(AdminConstants.USER_EMAIL);
      Role role = roleDAO.findByPrimaryKey(roleId);
      hrpUser = new LoginUserImpl(null, userId, isAdmin, role, userName, description, email);
      hrpUser.setCountriesSpecificallyAuthorized(getCountriesForUser(helper));
      hrpUser.setPrivileges(getUserPrivileges(helper));
      hrpUser.setRegionsSpecificallyAuthorized(getRegionsForUser(helper));
      hrpUser.setStatesSpecificallyAuthorized(getStatesForUser(helper));
    }
    return hrpUser;
  }

  private void setPrivilegesInResponse(List<Privilege> privileges, UCCHelper helper) {
    List<PrivilegeSelection> defaultPrivileges = getPrivilegesAsPrivliegeSelections(privileges);
    helper.setRequestAttributeValue(AdminConstants.PRIVILEGE_LIST, defaultPrivileges);
  }

  private void updateAllPrivilegeListWithUserSelectionFromRequest(LoginUser hrpUser, UCCHelper helper) {
    List<Privilege> allPrivileges = lookupPrivileges();
    List<Privilege> userPrivileges = hrpUser.getPrivileges();
//    hrpUser.setPrivileges(userPrivileges);
    helper.setRequestAttributeValue(AdminConstants.PRIVILEGE_LIST,
        setSelectionInPrivileges(allPrivileges, userPrivileges));
  }

  private List<PrivilegeSelection> setSelectionInPrivileges(List<Privilege> allPrivileges,
                                                            List<Privilege> userPrivileges) {
    List<PrivilegeSelection> privilegeSetInResponse = getPrivilegesAsPrivliegeSelections(allPrivileges);

    for (Privilege userPrivilege : userPrivileges) {
      for (PrivilegeSelection privilegeSelection : privilegeSetInResponse) {
        if (userPrivilege.getId().equals(privilegeSelection.getPrivilege().getId())) {
          privilegeSelection.setSelected(true);
        }
      }
    }
    return privilegeSetInResponse;
  }

  private List<PrivilegeSelection> getPrivilegesAsPrivliegeSelections(List<Privilege> allPrivileges) {
    List<PrivilegeSelection> privilegeSetInResponse = new ArrayList<PrivilegeSelection>();
    for (Privilege privilege : allPrivileges) {
      PrivilegeSelection userPrivSet = new PrivilegeSelection(privilege, false);
      privilegeSetInResponse.add(userPrivSet);
    }
    return privilegeSetInResponse;
  }

  private List<Privilege> lookupPrivileges() {
    return this.securityService.lookupAllPrivileges();
  }

  /**
   * This method sets up data needed to add a new user
   *
   * @param helper - UCCHelper
   *
   * @exception IOException - IOException
   */
  public void setupDataForNewUserRole(UCCHelper helper) throws IOException {
    setNewUserFlagInResponse(helper);
    LoginUser hrpUser = new LoginUserImpl();
    setRegionCountryStateInResponse(helper, hrpUser);
    setUserInResponse(hrpUser, helper);
    setRolesInResponse(lookupRoles(), helper);
    setPrivilegesInResponse(lookupPrivileges(), helper);
    helper.forward(AdminConstants.UPDATE_USER_ACCESS);
  }

  /**
   * This method deletes a role for a user
   *
   * @param helper - UCCHelper
   *
   * @exception IOException - IOException
   */
  public void deleteUserRole(UCCHelper helper) throws IOException {
    String userId = helper.getRequestParameterValue(AdminConstants.USER_ID);
    deleteUserRole(userId);
    MsgAndErrorUtil.addDataDeletedMsgToResponse(helper);
    setUserListInResponse(lookupAllUsersWithAccess(), helper);
    helper.forward(AdminConstants.DISPLAY_ALL_USERS_JSP);
  }

  /**
   * This method deletes role for selected users.
   *
   * @param helper - UCCHelper
   *
   * @exception IOException - IOException
   */
  public void deleteUsersRole(UCCHelper helper) throws IOException {
    List<String> usersSelectedForDelete = getListOfUserIdsFromSelectOperation(helper);
    this.securityService.deleteSelectedUsers(usersSelectedForDelete);
    MsgAndErrorUtil.addDataDeletedMsgToResponse(helper);
    setUserListInResponse(lookupAllUsersWithAccess(), helper);
    helper.forward(AdminConstants.DISPLAY_ALL_USERS_JSP);
  }

  public void getSelectedUsersEmail(UCCHelper helper) throws IOException {
    List<String> selectedUsers = getListOfUserIdsFromSelectOperation(helper);
    String userEmailList = getListOfUserEmails(selectedUsers);
    helper.setRequestAttributeValue("emailList", userEmailList);
    helper.setContentType("text/plain");
    helper.getPrintWriter().write(userEmailList);
  }

  private String getListOfUserEmails(List<String> selectedUsers) throws IOException {
    StringBuffer emailList = new StringBuffer();
    List<LoginUser> userList = lookupAllUsersWithAccess();
    LoginNameComparator nameComparator = new LoginNameComparator();
    Collections.sort(userList, nameComparator);
    getEmailForSelectedUsers(selectedUsers, emailList, userList);
    return emailList.toString();
  }

  private void getEmailForSelectedUsers(List<String> selectedUsers, StringBuffer emailList, List<LoginUser> userList) {
    Collections.sort(selectedUsers);
    Collections.sort(userList);
    LoginNameComparator comparator = new LoginNameComparator();
    Collections.sort(userList, comparator);
    List<LoginUser> selectedUsersList = getUsersFromSelectedList(selectedUsers, userList);
    Collections.sort(selectedUsersList, comparator);
    for (LoginUser user : selectedUsersList) {
      emailList.append(user.getEmail()).append(';');
    }
  }

  private List<LoginUser> getUsersFromSelectedList(List<String> selectedUsers, List<LoginUser> userList) {
    List<LoginUser> selectedUsersList = new ArrayList<LoginUser>();
    for (String selectedUser : selectedUsers) {
      for (LoginUser user : userList) {
        if (user.getUserId().equalsIgnoreCase(selectedUser)) {
          selectedUsersList.add(user);
        }
      }
    }
    return selectedUsersList;
  }

  private List<String> getListOfUserIdsFromSelectOperation(UCCHelper helper) throws IOException {
    List<String> usersToBeDeleted = new ArrayList<String>();
    if (isAllSelected()) {
      List<LoginUserPagination> filteredUserList = getFilteredUsersList(helper);
      getListOfUsersToBeDeleted(usersToBeDeleted, filteredUserList);
      return usersToBeDeleted;
    } else {
      return this.getSelectedIds();
    }
  }

  private void getListOfUsersToBeDeleted(List<String> usersToBeDeleted, List<LoginUserPagination> filteredUserList) {
    for (LoginUserPagination users : filteredUserList) {
      usersToBeDeleted.add(users.getId().toUpperCase());
    }
    List<String> idsToExclude = getIdsToExclude();
    for (String id : idsToExclude) {
      usersToBeDeleted.remove(id);
    }
  }

  private List<LoginUserPagination> getFilteredUsersList(UCCHelper helper) throws IOException {
    AdminDataSource adminDataSource = getAdminDataSource(helper);
    FilteredXmlDataSource filteredDataSource = new FilteredXmlDataSource(adminDataSource, getFilterValue());
    return (List<LoginUserPagination>) filteredDataSource.getData();
  }

  protected AdminDataSource getAdminDataSource(UCCHelper helper) {
    return new AdminDataSource(helper);
  }

  /**
   * This method saves or updates a role for a user
   *
   * @param helper - UCCHelper
   *
   * @exception IOException - IOException
   */
  public void saveOrUpdateUserRole(UCCHelper helper) throws IOException {
    List<String> errorList = MsgAndErrorUtil.createAndSetErrorList(helper);
    setNewUserFlagInResponse(helper);
    LoginUser hrpUser = getUserFromRequest(helper, errorList);
    setRegionCountryStateInResponse(helper, hrpUser);
    updateAllPrivilegeListWithUserSelectionFromRequest(hrpUser, helper);
    if (hrpUser.getUserId().equalsIgnoreCase(helper.getAuthenticatedUserID())){
      helper.removeSessionParameter(HRPMainConstants.LOGINUSER);
      helper.setSessionParameter(HRPMainConstants.LOGINUSER, this.securityService.lookupUserByUserId(helper.getAuthenticatedUserID()));
    }

    if (errorList.isEmpty()) {
      MsgAndErrorUtil.addDataSavedMsgToResponse(helper);
      setUserListInResponse(lookupAllUsersWithAccess(), helper);
      helper.forward(AdminConstants.DISPLAY_ALL_USERS_JSP);
    } else {
      setUserInResponse(hrpUser, helper);
      setRolesInResponse(lookupRoles(), helper);
      setPrivilegesInResponse(lookupPrivileges(), helper);
      helper.forward(AdminConstants.UPDATE_USER_ACCESS);
    }
  }

  private LoginUser getUserFromRequest(UCCHelper helper, List<String> errorList) throws IOException {
    LoginUser hrpUser;

    if (isNewUserFlagSet(helper)) {
      hrpUser = createNewUserFromRequest(errorList,
          helper); //todo temporarily made error List unmodifiable to figure out where error is being added
    } else {
      hrpUser = updateExistingUserFromRequest(errorList, helper);
    }
    return hrpUser;
  }

  private void setRegionCountryStateInResponse(UCCHelper helper, LoginUser user) throws IOException {
    List<RegionSelection> regions = new ArrayList<RegionSelection>();
    List<CountrySelection> countries = new ArrayList<CountrySelection>();
    List<StateSelection> states = new ArrayList<StateSelection>();
    LoginUser hrpUser = getHrpUser(helper, user);

    addRegionsToList(regions, countries, states, hrpUser);

    helper.setRequestAttributeValue(AdminConstants.REGION_LIST, regions);
    helper.setRequestAttributeValue(AdminConstants.COUNTRY_LIST, countries);
    helper.setRequestAttributeValue(AdminConstants.STATE_LIST, states);
  }

  private LoginUser getHrpUser(UCCHelper helper, LoginUser user) throws IOException {
    LoginUser hrpUser;
    if (isReload(helper)) {
      hrpUser = new TemporaryUser(user, helper);
    } else {
      hrpUser = user;
    }
    return hrpUser;
  }

  private void addRegionsToList(List<RegionSelection> regions,
                                List<CountrySelection> countries, List<StateSelection> states, LoginUser hrpUser) throws
      IOException {
    for (Region region : geoDataFactory.getRegions()) {
      boolean hasRegion = hrpUser.isAuthorizedExplicity(region);
      regions.add(new RegionSelection(region, hasRegion));
      if (hasRegion) {
        addCountriesToList(countries, states, hrpUser, region);
      }
    }
  }

  private void addCountriesToList(List<CountrySelection> countries, List<StateSelection> states, LoginUser hrpUser,
                                  Region region) throws IOException {
    for (Country country : region.getCountries()) {
      boolean hasCountry = hrpUser.isAuthorizedExplicity(country);
      countries.add(new CountrySelection(country, hasCountry));
      if (hasCountry) {
        addStatesToList(states, hrpUser, country);
      }
    }
  }

  private void addStatesToList(List<StateSelection> states, LoginUser hrpUser, Country country) throws
      IOException {
    for (StateProvince state : country.getStates()) {
      boolean hasState = hrpUser.isAuthorizedExplicity(state);
      states.add(new StateSelection(state, hasState));
    }
  }

  private boolean isReload(UCCHelper helper) throws IOException {
    String reload = helper.getRequestParameterValue(AdminConstants.RELOAD);
    return ("Y".equals(reload));
  }

  private static class TemporaryUser implements LoginUser {
    //todo is this class still needed after we moved to hibernate?
    private final LoginUser baseUser;
    private final UCCHelper helper;

    private TemporaryUser(LoginUser baseUser, UCCHelper helper) {
      this.baseUser = baseUser;
      this.helper = helper;
    }

    public boolean isAuthorizedExplicity(Region region) throws IOException {
      return isIdInList(helper.getRequestParameterValues(AdminConstants.REGIONS), region.getId());
    }

    public boolean isAuthorizedExplicity(Country country) throws IOException {
      return isIdInList(helper.getRequestParameterValues(AdminConstants.COUNTRIES), country.getId());
    }

    public boolean isAuthorizedExplicity(StateProvince state) throws IOException {
      return isIdInList(helper.getRequestParameterValues(AdminConstants.STATES), state.getId());
    }

    private boolean isIdInList(String[] values, String id) {
      if (values == null) {
        return false;
      }

      for (String value : values) {
        if (value.equals(id)) {
          return true;
        }
      }

      return false;
    }

    public Long getId() {
      return baseUser.getId();
    }

    public String getUserId() {
      try {
        return baseUser.getUserId();
      } catch (RuntimeException e) {
        return "";
      }
    }

    public String getUserName() {
      try {
        return baseUser.getUserName();
      } catch (RuntimeException e) {
        return "Unable to determine username";
      }
    }

    public Role getRole() {
      try {
        String roleId = helper.getRequestParameterValue(AdminConstants.ROLE_ID);
        return new Role(roleId, null);
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    }

    public String getDescription() {
      try {
        return helper.getRequestParameterValue(AdminConstants.USER_DESCRIPTION);
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    }

    public String getEmail() {
      return baseUser.getEmail();
    }

    public boolean getHasEditRole() {
      return isInThisRole(HRPMainConstants.EDIT_ROLE);
    }

    public boolean getHasReadOnlyRole() {
      return isInThisRole(HRPMainConstants.READ_ROLE);
    }

    public boolean isAdmin() {
      return checkboxToBoolean(helper, AdminConstants.ADMIN_FLAG);
    }

    public boolean isInThisRole(String roleName) {
      return getRole().getRoleName().equals(roleName);
    }

    public boolean isAuthorized(Region region) {
      return baseUser.isAuthorized(region);
    }

    public boolean isAuthorized(Country country) {
      return baseUser.isAuthorized(country);
    }

    public boolean isAuthorized(StateProvince state) {
      return baseUser.isAuthorized(state);
    }

    public void addRegion(Region region) {
      baseUser.addRegion(region);
    }

    public void addCountry(Country country) {
      baseUser.addCountry(country);
    }

    public void addState(StateProvince state) {
      baseUser.addState(state);
    }

    public void clearRegions() {
      baseUser.clearRegions();
    }

    public void clearCountries() {
      baseUser.clearCountries();
    }

    public void clearStates() {
      baseUser.clearStates();
    }

    public void addPrivilege(Privilege privilege) {
      baseUser.addPrivilege(privilege);
    }

    public void clearPrivileges() {
      baseUser.clearPrivileges();
    }

    public Map<String, Boolean> getPrivilegeMap() {
      return baseUser.getPrivilegeMap();
    }

    public List<Privilege> getPrivileges() {
      String[] selectedPrivileges = getSelectedPrivileges();

      List<Privilege> userPriv = new ArrayList<Privilege>();
      if (selectedPrivileges != null) {
        for (String selectedPrivId : selectedPrivileges) {
          userPriv.add(new Privilege(selectedPrivId, null));
        }
      }
      return userPriv;
    }

    private String[] getSelectedPrivileges() {
      try {
        return helper.getRequestParameterValues(AdminConstants.PRIVILEGE_LIST);
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    }

    public void setPrivileges(List<Privilege> privileges) {
      baseUser.setPrivileges(privileges);
    }

    public int compareTo(Object o) {
      return baseUser.compareTo(o);
    }

    public List<Region> getRegionsSpecificallyAuthorized() {
      return null;
    }

    public List<Country> getCountriesSpecificallyAuthorized() {
      return null;
    }

    public List<StateProvince> getStatesSpecificallyAuthorized() {
      return null;
    }

    public void setRegionsSpecificallyAuthorized(List<Region> regionsSpecificallyAuthorized) {
      baseUser.setRegionsSpecificallyAuthorized(regionsSpecificallyAuthorized);
    }

    public void setCountriesSpecificallyAuthorized(List<Country> countriesSpecificallyAuthorized) {
      baseUser.setCountriesSpecificallyAuthorized(countriesSpecificallyAuthorized);
    }

    public void setStatesSpecificallyAuthorized(List<StateProvince> statesSpecificallyAuthorized) {
      baseUser.setStatesSpecificallyAuthorized(statesSpecificallyAuthorized);
    }
  }

  private void setNewUserFlagInResponse(UCCHelper helper) throws IOException {
    String value = getNewUserFlagFromRequest(helper);
    helper.setRequestAttributeValue(AdminConstants.NEW_USER, value);
  }

  private String getNewUserFlagFromRequest(UCCHelper helper) throws IOException {
    return helper.getRequestParameterValue(AdminConstants.NEW_USER);
  }

  private void addErrorIfUserAlreadyExists(String userID, List<String> errorList) {
    if (userExists(userID)) {
      errorList.clear();
      errorList.add(AdminConstants.USER_ALREADY_EXISTS);
    }
  }

  private boolean userExists(String userId) {
    return securityService.isUserFound(userId);
  }

  private boolean isNewUserFlagSet(UCCHelper helper) throws IOException {
    return !StringUtils.isNullOrEmpty(getNewUserFlagFromRequest(helper));
  }

  private LoginUser createNewUserFromRequest(List<String> errorList, UCCHelper helper) throws IOException {
    String userId = helper.getRequestParameterValue(AdminConstants.USER_ID);
    if (userId == null || userId.length() == 0) {
      errorList.add(AdminConstants.USER_ID_MISSING);
      return new LoginUserImpl();
    }
    String userName = helper.getRequestParameterValue(AdminConstants.USER_NAME);

    String roleId = helper.getRequestParameterValue(AdminConstants.ROLE_ID);
    addErrorIfUserAlreadyExists(userId, errorList);
    boolean isAdmin = "Y".equalsIgnoreCase(helper.getRequestParameterValue(AdminConstants.ADMIN_FLAG));
    validateUserId(userId, errorList);
    validateRoleId(roleId, errorList);
    String description = helper.getRequestParameterValue(AdminConstants.USER_DESCRIPTION);
    String email = helper.getRequestParameterValue(AdminConstants.USER_EMAIL);
    List<Region> userRegions = getRegionsForUser(helper);
    List<Country> userCountries = getCountriesForUser(helper);
    List<StateProvince> userStates = getStatesForUser(helper);
    List<Privilege> userPrivileges = getUserPrivileges(helper);

    return securityService.createUser(null, userId, new Role(roleId, null), isAdmin, userName,
        description, email, userRegions, userCountries, userStates, userPrivileges);
  }

  private LoginUser updateExistingUserFromRequest(List<String> errorList, UCCHelper helper) throws IOException {
    String userId = helper.getRequestParameterValue(AdminConstants.USER_ID);
    String userName = helper.getRequestParameterValue(AdminConstants.USER_NAME);
    String roleId = helper.getRequestParameterValue(AdminConstants.ROLE_ID);
    String description = helper.getRequestParameterValue(AdminConstants.USER_DESCRIPTION);
    String email = helper.getRequestParameterValue(AdminConstants.USER_EMAIL);
    boolean isAdmin = checkboxToBoolean(helper, AdminConstants.ADMIN_FLAG);
    validateUserId(userId, errorList);
    validateRoleId(roleId, errorList);
    List<Region> userRegions = getRegionsForUser(helper);
    List<Country> userCountries = getCountriesForUser(helper);
    List<StateProvince> userStates = getStatesForUser(helper);
    List<Privilege> userPrivileges = getUserPrivileges(helper);
    securityService.removeUserRole(userId);

    return securityService.createUser(null, userId, new Role(roleId, null), isAdmin, userName,
        description, email, userRegions, userCountries, userStates, userPrivileges);

  }

  private static boolean checkboxToBoolean(UCCHelper helper, String fieldName) {
    try {
      String checkboxString = helper.getRequestParameterValue(fieldName);
      return "ON".equalsIgnoreCase(checkboxString) ||
          "Y".equalsIgnoreCase(checkboxString) ||
          "T".equalsIgnoreCase(checkboxString);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  private String[] getParameterValues(UCCHelper helper, String paramName) throws IOException {
    //todo need to see if this is needed, or if getRequestParameterValues never returns null
    String[] values = helper.getRequestParameterValues(paramName);
    if (values == null) {
      return NO_STRINGS;
    } else {
      return values;
    }
  }

  private List<Region> getRegionsForUser(UCCHelper helper) throws IOException {
    String[] regions = getParameterValues(helper, AdminConstants.REGIONS);
    List<Region> userRegions = new ArrayList<Region>();
    for (String regionId : regions) {
      Region region = geoDataFactory.getRegionById(regionId);
      userRegions.add(region);
    }
    return userRegions;
  }

  private List<Country> getCountriesForUser(UCCHelper helper) throws IOException {
    String[] countries = getParameterValues(helper, AdminConstants.COUNTRIES);
    List<Country> userCountries = new ArrayList<Country>();
    for (String countryId : countries) {
      Country country = geoDataFactory.getCountryById(countryId);
      userCountries.add(country);
    }
    return userCountries;
  }

  private List<StateProvince> getStatesForUser(UCCHelper helper) throws IOException {
    String[] states = getParameterValues(helper, AdminConstants.STATES);
    List<StateProvince> userStates = new ArrayList<StateProvince>();
    for (String stateId : states) {
      StateProvince stateProvince = geoDataFactory.getStateById(stateId);
      userStates.add(stateProvince);
    }
    return userStates;
  }

  private List<Privilege> getUserPrivileges(UCCHelper helper) throws IOException {
    String[] privileges = getParameterValues(helper, AdminConstants.PRIVILEGE_LIST);
    List<Privilege> userPrivileges = new ArrayList<Privilege>();
    for (String privilege : privileges) {
      Privilege userPriv = new Privilege(privilege, null);
      userPrivileges.add(userPriv);
    }
    return userPrivileges;
  }

  private void validateRoleId(String roleId, List<String> errorList) {
    addErrorIfNull(roleId, AdminConstants.ROLE_ID_MISSING, errorList);
  }

  private void validateUserId(String userId, List<String> errorList) {
    addErrorIfNull(userId, AdminConstants.USER_ID_MISSING, errorList);
  }

  private void addErrorIfNull(String id, String messsge, List<String> errorList) {
    if (StringUtils.isNullOrEmpty(id)) {
      errorList.add(messsge);
    }
  }

  private List<Role> lookupRoles() {
    return roleDAO.findAll();
  }

  private void setRolesInResponse(List<Role> roles, UCCHelper helper) {
    helper.setRequestAttributeValue(AdminConstants.ROLE_LIST, roles);
  }

  private void deleteUserRole(String userId) {
    this.securityService.removeUserRole(userId);
  }

  private void setUserInResponse(LoginUser user, UCCHelper helper) {
    helper.setRequestAttributeValue(AdminConstants.HRP_USER, user);
  }

  private void setUserListInResponse(List<LoginUser> users, UCCHelper helper) {
    helper.setRequestAttributeValue(AdminConstants.USERS_LIST, users);
  }

  private List<LoginUser> lookupAllUsersWithAccess() {
    List<LoginUser> users = new ArrayList<LoginUser>(this.securityService.lookupAllUsers());
    Collections.sort(users);
    return users;
  }

  private class LoginNameComparator implements Comparator {
    public int compare(Object o1, Object o2) {
      if (o1 instanceof LoginUser && o2 instanceof LoginUser) {
        return compareValue((LoginUser) o1, (LoginUser) o2);
      } else {
        return 0;
      }
    }

    public int compareValue(LoginUser user1, LoginUser user2) {
      String value1 = blankIfNull(user1.getUserName().toLowerCase());
      String value2 = blankIfNull(user2.getUserName().toLowerCase());
      return value1.compareTo(value2);
    }

    public String blankIfNull(String st) {
      if (st == null) {
        return "";
      } else {
        return st;
      }
    }
  }

  private class NewUser {
    private Long id;
    private String userId;
    private boolean admin;
    private Role role;
    private String userName;
    private String description;
    private String email;

    private NewUser(Long id, String userId, boolean isAdmin, Role role, String userName, String description,
                    String email) {
      this.id = id;
      this.userId = userId;
      admin = isAdmin;
      this.role = role;
      this.userName = userName;
      this.description = description;
      this.email = email;
    }

    public Long getId() {
      return id;
    }

    public String getUserId() {
      return userId;
    }

    public boolean isAdmin() {
      return admin;
    }

    public Role getRole() {
      return role;
    }

    public String getUserName() {
      return userName;
    }

    public String getDescription() {
      return description;
    }

    public String getEmail() {
      return email;
    }
  }
}