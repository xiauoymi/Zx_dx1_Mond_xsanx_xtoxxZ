/*
 BaseTransactionalController was created on Mar 14, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.Security.controller;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.dbtemplate.factory.AbstractTransactionManagerFactory;
import com.monsanto.wst.dbtemplate.transaction.TransactionManager;

/**
 * @author sspati1
 */
public class BaseTransactionalController {
  private final DBTemplate template;


  public BaseTransactionalController() {
    AbstractTransactionManagerFactory txManagerFactory = AbstractTransactionManagerFactory.newInstance("database/dbtemplate-config.xml");
    TransactionManager transactionManager = txManagerFactory.getTransactionManager();
    this.template = new DBTemplateImpl(transactionManager, new String [] {"database/dbtemplate.xml"});
  }

  protected DBTemplate getDBTemplate() {
    return template;
  }
}