package com.monsanto.wst.humanrightspolicy.Security.controller;

import com.monsanto.wst.humanrightspolicy.model.Country;
/*
 CountrySelection was created on Feb 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class CountrySelection {
  private final Country country;
  private final boolean selected;

  public CountrySelection(Country country, boolean selected) {
    this.country = country;
    this.selected = selected;
  }

  public Country getCountry() {
    return country;
  }

  public boolean getSelected() {
    return selected;
  }
}
