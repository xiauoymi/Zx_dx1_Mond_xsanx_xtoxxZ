package com.monsanto.wst.humanrightspolicy.Security.controller;

import com.monsanto.wst.humanrightspolicy.model.Region;
/*
 RegionSelection was created on Feb 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class RegionSelection {
  private final Region region;
  private final boolean selected;

  public RegionSelection(Region region, boolean selected) {
    this.region = region;
    this.selected = selected;
  }

  public Region getRegion() {
    return region;
  }

  public boolean getSelected() {
    return selected;
  }
}
