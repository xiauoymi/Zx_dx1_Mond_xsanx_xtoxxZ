/*
 SessionTimeoutControlle was created on Mar 5, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.Security.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;

import java.io.IOException;

/**
 * @author sspati1
 */
public class SessionTimeoutController implements UseCaseController {
  public void run(UCCHelper helper) throws IOException {
    helper.closeSession();
    helper.forward(HRPMainConstants.HRP_SESSION_TIMEOUT_JSP);
  }
}