package com.monsanto.wst.humanrightspolicy.Security.controller;

import com.monsanto.wst.humanrightspolicy.model.StateProvince;
/*
 StateSelection was created on Feb 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class StateSelection {
  private final StateProvince state;
  private final boolean selected;

  public StateSelection(StateProvince state, boolean selected) {
    this.state = state;
    this.selected = selected;
  }

  public StateProvince getState() {
    return state;
  }

  public boolean getSelected() {
    return selected;
  }
}
