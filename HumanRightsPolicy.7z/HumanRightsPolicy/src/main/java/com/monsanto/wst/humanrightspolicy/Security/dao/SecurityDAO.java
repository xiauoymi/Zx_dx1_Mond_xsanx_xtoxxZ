/*
 SecurityDAO was created on Mar 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.Security.dao;

import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.List;

/**
 * @author sspati1
 */
public interface SecurityDAO {
  LoginUser addUser(Long id, String userId, Role role, boolean isAdmin, String name, String description,
                    String email, List<Region> userRegions, List<Country> userCountries, List<StateProvince> userStates,
                    List<Privilege> userPrivileges);

  List<Privilege> lookupAllPrivileges();

}