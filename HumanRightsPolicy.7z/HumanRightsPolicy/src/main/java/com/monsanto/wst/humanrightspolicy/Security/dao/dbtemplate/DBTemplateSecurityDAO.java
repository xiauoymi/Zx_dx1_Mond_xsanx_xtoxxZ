/*
 DBTemplateSecurityDAO2 was created on Mar 14, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.Security.dao.dbtemplate;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.Security.dao.SecurityDAO;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.util.List;

/**
 * @author sspati1
 */
//todo eliminate this and the class(es) that tests it (or at least rename it since there is no dbtemplate here anymore)
public class DBTemplateSecurityDAO implements SecurityDAO {
    private final GenericDAO<Privilege, String> privDAO;
    private final GenericDAO<LoginUser, Long> userDAO;

    public DBTemplateSecurityDAO(DBTemplate dbTemplate) {
        this(InitService.initPrivilegeDAO(), InitService.initUserDAO());
    }

    public DBTemplateSecurityDAO(GenericDAO<Privilege, String> privDAO, GenericDAO<LoginUser, Long> userDAO) {
        this.privDAO = privDAO;
        this.userDAO = userDAO;
    }

    public LoginUser addUser(Long id, String userId, Role role, boolean isAdmin, String name, String description,
                             String email, List<Region> userRegions, List<Country> userCountries,
                             List<StateProvince> userStates, List<Privilege> userPrivileges) {
        LoginUser user = new LoginUserImpl(id, userId, isAdmin, role, name, description, email);
        user.setRegionsSpecificallyAuthorized(userRegions);
        user.setCountriesSpecificallyAuthorized(userCountries);
        user.setStatesSpecificallyAuthorized(userStates);
        user.setPrivileges(userPrivileges);
        userDAO.save(user);
        return user;
    }

    public List<Privilege> lookupAllPrivileges() {
        return privDAO.findAll();
    }
}