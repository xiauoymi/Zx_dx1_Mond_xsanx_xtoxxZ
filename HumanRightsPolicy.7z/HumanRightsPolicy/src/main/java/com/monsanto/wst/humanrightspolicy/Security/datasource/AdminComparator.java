/*
 AdminComparator was created on May 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.Security.datasource;

import com.monsanto.wst.humanrightspolicy.model.LoginUserPagination;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: AdminComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-05-23 15:57:41 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public abstract class AdminComparator implements Comparator<XmlObject> {
  protected abstract String getValue(LoginUserPagination loginUser);

  public int compare(XmlObject o1, XmlObject o2) {
    if (o1 instanceof LoginUserPagination && o2 instanceof LoginUserPagination) {
      return compareRels((LoginUserPagination) o1, (LoginUserPagination) o2);
    } else {
      return 0;
    }
  }

  public int compareRels(LoginUserPagination user1, LoginUserPagination user2) {
    String value1 = blankIfNull(getValue(user1));
    String value2 = blankIfNull(getValue(user2));
    return value1.compareTo(value2);
  }

  public String blankIfNull(String st) {
    if (st == null) {
      return "";
    } else {
      return st;
    }
  }
}