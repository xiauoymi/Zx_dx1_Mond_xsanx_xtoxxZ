/*
 AdminDataSource was created on May 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.Security.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.Security.service.SecurityService;
import com.monsanto.wst.humanrightspolicy.controller.XmlDataPaginationController;
import com.monsanto.wst.humanrightspolicy.datasource.ComparatorMap;
import com.monsanto.wst.humanrightspolicy.datasource.DataSource;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.textutil.TextUtil;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Filename:    $RCSfile: AdminDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date:
 * 2008/07/09 19:46:21 $
 *
 * @author rrmall
 * @version $Revision: 1.20 $
 */
public class AdminDataSource implements XmlDataSource {
    private final ParameterCollection params;
    private final SecurityService securityService;

    public static final String NAME_SORT_KEY = "userName";
    public static final String REGION_SORT_KEY = "regions";
    public static final String ROLE_SORT_KEY = "role";
    public static final String DESCRIPTION_SORT_KEY = "description";
    private static final ComparatorMap<XmlObject> comparatorMap;

    static {
        comparatorMap = new ComparatorMap<XmlObject>(new AdminDefaultComparator());
        comparatorMap.addComparator(NAME_SORT_KEY, new AdminNameComparator());
        comparatorMap.addComparator(REGION_SORT_KEY, new AdminRegionComparator());
        comparatorMap.addComparator(ROLE_SORT_KEY, new AdminUserRoleComparator());
        comparatorMap.addComparator(DESCRIPTION_SORT_KEY, new AdminDescriptionComparator());
    }

    public AdminDataSource(ParameterCollection params, SecurityService securityService
    ) {
        this.params = params;
        this.securityService = securityService;
    }

    public AdminDataSource(UCCHelper helper, SecurityService securityService) {
        this(new UCCHelperParameterCollection(helper), securityService);
    }

    public AdminDataSource(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initSecurityService());
    }

    public AdminDataSource(ParameterCollection params) {
        this(params, InitService.initSecurityService());
    }

    public List<? extends XmlObject> getData() throws IOException {//TODO Change the exception heirarchy
        List<LoginUserPagination> userListForPagination = new ArrayList<LoginUserPagination>();
        List<? extends LoginUser> userList = this.securityService.lookupAllUsers();
        for (LoginUser user : userList) {
            List<Region> regionsForUser = user.getRegionsSpecificallyAuthorized();
            //Collections.sort(regionsForUser);
            String regionString = getRegionStringForUser(regionsForUser);
            userListForPagination.add(createPaginationObject(user, regionString));
        }
        return userListForPagination;
    }

    private String getRegionStringForUser(List<Region> regionsForUser) {

        if (regionsForUser.isEmpty()) {
            return "All";
        } else {
            return StringUtils.join(regionsForUser, ", ");
        }

    }

    private LoginUserPagination createPaginationObject(LoginUser user, String regionString) {
        String userID = user.getUserId();
        String userName = user.getUserName();
        String role = user.getRole().getRoleName();
        String description = user.getDescription();
        String viewUrl = new HrpUrlBuilder("displayUsers").getViewUserUrl(userID);
        String removeUrl = new HrpUrlBuilder("displayUsers").getRemoveUserUrl(userID);
        String addUrl = new HrpUrlBuilder("displayUsers").getAddUserUrl();
        return new LoginUserPaginationImpl(userName, userID, role, regionString, viewUrl, removeUrl, addUrl, description,
                null);
    }

    public Comparator<XmlObject> getComparator(String sortKey) {
        return comparatorMap.getComparator(sortKey);
    }

    public boolean isSorted() {
        return false;
    }

    public boolean isFiltered() {
        return false;
    }

    public int getTotalRecords() {
        return DataSource.UNKNOWN_RECORD_COUNT;
    }

    public String getFilterValue() throws IOException {
        return StringUtils.defaultString(
                TextUtil.decodeUsingUTF8(params.get(XmlDataPaginationController.FILTER_VALUE)));
    }

}