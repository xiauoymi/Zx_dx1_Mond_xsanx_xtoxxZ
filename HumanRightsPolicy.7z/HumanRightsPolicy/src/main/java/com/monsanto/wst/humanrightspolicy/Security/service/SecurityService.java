/*
 SecurityService was created on Mar 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.Security.service;

import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.List;

/**
 * @author sspati1
 */
public interface SecurityService {
  List<? extends LoginUser> lookupAllUsers();

  void removeUserRole(String userId);

  LoginUser lookupUserByUserId(String id);

  LoginUser createUser(Long id, String userName, Role role, boolean admin, String name, String description,
                       String email, List<Region> userRegions, List<Country> userCountries,
                       List<StateProvince> userStates, List<Privilege> userPrivileges);

  boolean isUserFound(String userId);

  void deleteSelectedUsers(List<String> usersList);

  List<Privilege> lookupAllPrivileges();

  void addPrivilegeToUser(LoginUser newUser, Privilege privilege);

  void clearPrivilegesForUser(Long id);

  LoginUser lookupUserByCriteria(String userId);
}