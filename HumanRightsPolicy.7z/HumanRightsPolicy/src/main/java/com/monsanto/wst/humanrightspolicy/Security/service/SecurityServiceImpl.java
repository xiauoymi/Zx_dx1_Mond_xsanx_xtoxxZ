/*
 SecurityServiceImpl was created on Mar 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.Security.service;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.Security.dao.SecurityDAO;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.hibernate.Criteria;
import org.hibernate.criterion.Expression;

import java.util.List;

/**
 * @author sspati1
 */
public class SecurityServiceImpl implements SecurityService {
    private final SecurityDAO securityDAO;
    private final GenericDAO<LoginUser, Long> userDAO;

    public SecurityServiceImpl(SecurityDAO securityDAO) {
        this(securityDAO, InitService.initUserDAO());
    }

    public SecurityServiceImpl(SecurityDAO securityDAO, GenericDAO<LoginUser, Long> userDAO) {
        this.securityDAO = securityDAO;
        this.userDAO = userDAO;
    }

    public List<Privilege> lookupAllPrivileges() {
        return securityDAO.lookupAllPrivileges();
    }

    public List<? extends LoginUser> lookupAllUsers() {
        return userDAO.findAll();
    }

    public LoginUser lookupUserByUserId(String id) {
        return lookupUserByCriteria(id);
    }

    public LoginUser createUser(Long id, String userName, Role role, boolean admin, String name,
                                String description, String email, List<Region> userRegions, List<Country> userCountries,
                                List<StateProvince> userStates, List<Privilege> userPrivileges) {
        return securityDAO.addUser(id, userName, role, admin, name, description, email, userRegions, userCountries,
                userStates, userPrivileges);
    }

    public boolean isUserFound(String id) {
        LoginUser user = lookupUserByCriteria(id);
        return user != null;
//    return userDAO.findByPrimaryKey(id) != null;
    }

    public void deleteSelectedUsers(List<String> usersList) {
        for (String id : usersList) {
//      LoginUser user = userDAO.findByPrimaryKey(new Long(id));
            LoginUser user = lookupUserByCriteria(id);
            userDAO.delete(user);
        }
    }

    public void addPrivilegeToUser(LoginUser newUser, Privilege privilege) {
        newUser.addPrivilege(privilege);
    }

    public void clearPrivilegesForUser(Long id) {
        LoginUser user = userDAO.findByPrimaryKey(id);
        user.clearPrivileges();
    }

    public LoginUser lookupUserByCriteria(String userId) {
        if (userId == null) {
            throw new NullPointerException("userId cannot be null");
        }
        Criteria criteria = userDAO.createCriteria();
        criteria.add(Expression.eq("userId", userId).ignoreCase());
        return (LoginUser) criteria.uniqueResult();
    }

    public void removeUserRole(String userId) {
        LoginUser user = lookupUserByCriteria(userId);
        userDAO.delete(user);
    }
}