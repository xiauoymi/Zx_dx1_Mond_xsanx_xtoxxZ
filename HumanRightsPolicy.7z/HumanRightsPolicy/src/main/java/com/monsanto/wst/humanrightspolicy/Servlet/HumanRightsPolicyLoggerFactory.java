/*
 ExampleServletLoggerFactory was created on Jul 3, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.Servlet;

import com.monsanto.AbstractLogging.LogDevice;
import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Log4JLogging.*;
import com.monsanto.XMLUtil.DOMUtil;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * <p>Title: HumanRightsPolicyLoggerFactory</p> <p>Description: <p>Copyright: Copyright (c) 2005</p> <p>Company:
 * Monsanto</p>
 *
 * @author Java Framework Code  Generator 2.3
 * @version $Id: HumanRightsPolicyLoggerFactory.java,v 1.16 2008-09-19 19:32:28 kjjohn2 Exp $
 */
public class HumanRightsPolicyLoggerFactory {
  private final String m_cstrAppName = "HumanRightsPolicy";
  private final String m_cstrTraceLogPath;
  private final String m_cstrRollingLogPath;

  public HumanRightsPolicyLoggerFactory() {
    String cstrLogFolderName;
    if (StringUtils.isNotEmpty(System.getProperty("catalina.home"))) {
        cstrLogFolderName = System.getProperty("catalina.home") + File.separatorChar + "logs";
    } else {
        cstrLogFolderName = System.getProperty("catalina.base") + File.separatorChar + "logs";
    }
    m_cstrTraceLogPath = cstrLogFolderName + File.separatorChar + m_cstrAppName + "Trace.log";
    m_cstrRollingLogPath = cstrLogFolderName + File.separatorChar + m_cstrAppName + ".log";
  }

  public synchronized void setupLogging() throws IOException,
      LogRegistrationException {
    Logger.register(new Log4JTraceLog(m_cstrAppName, new Log4JFileLogDevice(m_cstrTraceLogPath)));

    LogDevice AppLogDevice = new Log4JMidnightRollingFileLogDevice(m_cstrRollingLogPath);
    Logger.register(new Log4JDebugLog(m_cstrAppName, AppLogDevice));
    Logger.register(new Log4JInfoLog(m_cstrAppName, AppLogDevice));
    Logger.register(new Log4JWarningLog(m_cstrAppName, AppLogDevice));
    Logger.register(new Log4JErrorLog(m_cstrAppName, AppLogDevice));

//    LogDevice consoleLogDevice = new Log4JConsoleLogDevice();
//    Logger.register(new Log4JDebugLog(m_cstrAppName, consoleLogDevice));
//    Logger.register(new Log4JInfoLog(m_cstrAppName, consoleLogDevice));
//    Logger.register(new Log4JWarningLog(m_cstrAppName, consoleLogDevice));
//    Logger.register(new Log4JErrorLog(m_cstrAppName, consoleLogDevice));
  }

  public Document toXML() {
    Logger.traceEntry();

    Document logDocument = DOMUtil.newDocument();
    Element rootElement = DOMUtil.addChildElement(logDocument, "LOGS");
    insertXML(rootElement);

    return (Document) Logger.traceExit(logDocument);
  }

  public void insertXML(Element parentElement) {
    Logger.traceEntry();

    try {
      addLogDeviceToXmlDocument(parentElement, "Rolling Log (Text)", m_cstrRollingLogPath);
      addLogDeviceToXmlDocument(parentElement, "Trace Log", m_cstrTraceLogPath);
    }
    catch (UnsupportedEncodingException uee) {
      Logger.log(new LoggableError(uee));
    }

    Logger.traceExit();
  }

  private void addLogDeviceToXmlDocument(Element parentElement, String deviceName, String filePath)
      throws UnsupportedEncodingException {
    Logger.traceEntry();

    if (filePath != null && (!"".equals(filePath.trim()))) {
      Element deviceElement = DOMUtil.addChildElement(parentElement, "LOG_DEVICE");
      DOMUtil.addChildElement(deviceElement, "DEVICE_NAME", deviceName);
      DOMUtil.addChildElement(deviceElement, "LOCATION", URLEncoder.encode(filePath, "UTF-8"));
    } else {
      throw new IllegalArgumentException("filePath argument cannot be null, blank, or empty.");
    }

    Logger.traceExit();
  }
}
