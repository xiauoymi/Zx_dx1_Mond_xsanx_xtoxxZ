package com.monsanto.wst.humanrightspolicy.Servlet;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType2;

import java.util.ResourceBundle;

/**
 * <p>Title: HumanRightsPolicyPersistentStoreFactory</p> <p>Description: </p> <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 *
 * @author Java Framework Code  Generator 2.3
 * @version $Id: HumanRightsPolicyPersistentStoreFactory.java,v 1.4 2007-04-11 19:37:55 SSPATI1 Exp $
 */
public class HumanRightsPolicyPersistentStoreFactory {
  /**
   * Returns a Persistent Store.
   *
   * @param cstrResourceBundleName The name of the resource bundle that points to the correct database.
   *
   * @return A PersistentStore object.
   *
   * @exception WrappingException
   */
  public static PersistentStore getStore(String cstrResourceBundleName) throws WrappingException {
    Logger.traceEntry();


    ResourceBundle bundle = ResourceBundle.getBundle(cstrResourceBundleName);


    PersistentStore RetVal = new PersistentStoreOracleCachedType2(bundle);


    return (PersistentStore) Logger.traceExit(RetVal);
  }
}
