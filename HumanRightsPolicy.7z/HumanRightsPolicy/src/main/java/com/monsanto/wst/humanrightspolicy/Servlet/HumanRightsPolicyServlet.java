package com.monsanto.wst.humanrightspolicy.Servlet;


import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.Security.service.SecurityService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.LoginUser;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


/**
 * <p>Title: HumanRightsPolicyServlet</p> <p>Description: </p> <p>Copyright: Copyright (c) 2003</p> <p>Company:
 * Monsanto</p>
 *
 * @author Java Framework Code  Generator 2.3
 * @version $Id: HumanRightsPolicyServlet.java,v 1.17 2008-10-16 22:22:40 kjjohn2 Exp $
 */
public class HumanRightsPolicyServlet extends GatewayServlet {
  public static final String s_cstrResourceBundle = "com.monsanto.wst.humanrightspolicy.Servlet.HumanRightsPolicy";

  public HumanRightsPolicyServlet() {
    super(6000);  // Set the session timeout values in seconds. (6000)
  }

  public void init(ServletConfig servletConfig) throws ServletException {
    super.init(servletConfig);

    try {
      HumanRightsPolicyLoggerFactory loggerFactory = new HumanRightsPolicyLoggerFactory();
      loggerFactory.setupLogging();
    } catch (Exception e) {
      e.printStackTrace(); //setting up logging failed, so can't log much better than this
      throw new RuntimeException(e);
    }
  }

  /**
   * This static method will create an instance of the desired PersistentStore based on data within a property file.
   *
   * @param request  - The HttpServlet Request from the servlet container
   * @param response - The HttpServletResponse to be sent back to the servlet container.
   *
   * @exception IOException
   * @exception ServletException
   */
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    Logger.traceEntry();
    UCCHelper helper = createHelper(request, response);
    setLoginUserInSession(helper);
    super.doGet(request, response);
    Logger.traceExit();
  }

  public void setLoginUserInSession(UCCHelper helper) {
    helper.removeSessionParameter(HRPMainConstants.LOGINUSER);
    String userId = helper.getAuthenticatedUserID();
    LoginUser loginUser = getSecurityService().lookupUserByUserId(userId);
    helper.setSessionParameter(HRPMainConstants.LOGINUSER, loginUser);
  }

  protected SecurityService getSecurityService() {
    return InitService.initSecurityService();
  }
}
