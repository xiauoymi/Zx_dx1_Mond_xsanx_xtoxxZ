/*
 ActionConstants was created on Aug 25, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.action;

/**
 * Filename:    $RCSfile: ActionConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-07 21:17:06 $
 *
 * @author rrmall
 * @version $Revision: 1.6 $
 */
public interface ActionConstants {
  public static final String ACTION_NAME = "actionName";
  public static final String ACTION_DUE_DATE = "actionDueDate";
  public static final String ACTION_START_DATE = "actionStartDate";
  public static final String ACTION_DATE_COMPLETED = "actionDateCompleted";
  public static final String ACTION_STATUS = "actionStatus";
  public static final String ACTION_STATUS_VALUE = "actionStatusValue";
  public static final String ACTION_PRIORITY = "actionPriority";
  public static final String ACTION_PRIORITY_VALUE = "actionPriorityValue";
  public static final String ACTION_PERCENT_COMPLETE = "actionPercentComplete";
  public static final String ACTION_DESCRIPTION = "actionDescription";
  public static final String ACTION = "action";
  public static final String ACTION_LIST = "actionList";
  public static final String ACTION_ID = "actionId";
  public static final String LIST_ACTION_JSP = "/WEB-INF/jsp/action/listActions.jsp";
  public static final String ACTION_STATUS_LIST = "actionStatusList";
  public static final String ACTION_PRIORITY_LIST = "actionPriorityList";
  public static final String ACTION_ITEM_JSP = "/WEB-INF/jsp/action/actionItem.jsp";
  public static final String CHILD_ACTION = "childActionItem";
  public static final String ACTION_PARENT_ITEM = "parentAction";
  public static final String ACTION_SUBITEMS_CLOSED = "areAllSubActionItemsClosed";
  public static final String CLOSED_STATUS = "Closed";
  public static final String ASSIGNMENT = "assignment";
  public static final String USER_ID = "userId";
  public static final String IS_ASSIGNMENT_PRIMARY = "isAssignmentPrimary";

  public static final String COUNT_OF_SUB_ACTION_ITEMS = "countOfSubActionItems";
  public static final String COUNT_OF_ASSIGNMENTS = "countOfAssignments";
  public static final String ASSIGNEES = "assignees";
  public static final String TARGET_ID = "targetId";
}