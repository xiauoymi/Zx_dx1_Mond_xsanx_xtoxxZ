/*
 ActionController was created on Aug 25, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.action.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.humanrightspolicy.Security.datasource.AdminDataSource;
import com.monsanto.wst.humanrightspolicy.action.ActionConstants;
import com.monsanto.wst.humanrightspolicy.action.datasource.ActionDataSource;
import com.monsanto.wst.humanrightspolicy.action.datasource.AssignmentForActionDataSource;
import com.monsanto.wst.humanrightspolicy.action.service.ActionService;
import com.monsanto.wst.humanrightspolicy.assignment.AssignmentConstants;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.controller.FilteredXmlDataSource;
import com.monsanto.wst.humanrightspolicy.controller.HrpController;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: ActionController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-31 18:52:48 $
 *
 * @author rrmall
 * @version $Revision: 1.19 $
 */
public class ActionController extends HrpController {
  private static final Log logger = LogFactory.getLog(ActionController.class);
  private ActionService actionService;

  public ActionController() {
    this(InitService.initActionService());

  }

  public ActionController(ActionService actionService) {
    this.actionService = actionService;
  }
  
  protected void notSpecified(UCCHelper helper) throws IOException {
    setReferenceDataInHelper(helper);
    helper.forward(ActionConstants.LIST_ACTION_JSP);
  }

  private void setReferenceDataInHelper(UCCHelper helper) {
    helper.setRequestAttributeValue(ActionConstants.ACTION_STATUS_LIST,this.actionService.lookupAllStatusTypes());
    helper.setRequestAttributeValue(ActionConstants.ACTION_PRIORITY_LIST,this.actionService.lookupAllPriorityTypes());
  }

  public void addAction(UCCHelper helper) throws IOException {
    String parentId = helper.getRequestParameterValue(ActionConstants.ACTION_ID);
    String name = helper.getRequestParameterValue(ActionConstants.ACTION_NAME);
    Date dueDate =getDateFromString(helper.getRequestParameterValue(ActionConstants.ACTION_DUE_DATE));
    Date startDate =getDateFromString(helper.getRequestParameterValue(ActionConstants.ACTION_START_DATE));
    Date dateCompleted =getDateFromString(helper.getRequestParameterValue(ActionConstants.ACTION_DATE_COMPLETED));
    String status =getValueFromRequest(helper.getRequestParameterValue(ActionConstants.ACTION_STATUS));
    String priority = getValueFromRequest(helper.getRequestParameterValue(ActionConstants.ACTION_PRIORITY));
    String percentComplete =helper.getRequestParameterValue(ActionConstants.ACTION_PERCENT_COMPLETE);
    String description =helper.getRequestParameterValue(ActionConstants.ACTION_DESCRIPTION);
    Status actionStatus = getActionStatusBasedOnRequest(status);
    ActionPriority actionPriority = getActionPriorityBasedObRequest(priority);
    Action parentActionItem = getActionParentItem(parentId);

    Action newActionItem = this.actionService.addAction(null, name, startDate, dueDate, dateCompleted, actionStatus,
          actionPriority, percentComplete, description, parentActionItem);

    addAssignmentToActionAndMakeCreatorThePrimaryToTheAssignment(helper, newActionItem);

    setActionItemDataBackInResponseAndForward(helper, parentId, newActionItem);

  }

  private void addAssignmentToActionAndMakeCreatorThePrimaryToTheAssignment(UCCHelper helper, Action newActionItem) {
    LoginUser user = (LoginUser) helper.getSessionParameter(HRPMainConstants.LOGINUSER);
    List<String> userIds = new ArrayList<String>();
    userIds.add(user.getUserId());
    this.actionService.addAssignmentToAction(null, userIds, newActionItem.getId(), true);
  }

  private void setActionItemDataBackInResponseAndForward(UCCHelper helper, String parentId,
                                               Action newActionItem) throws IOException {
    setReferenceDataInHelper(helper);
    if (parentId != null && parentId.length() > 0) {
      helper.setRequestAttributeValue(ActionConstants.ACTION_ID, parentId);
      Action parentAction = getActionItem(parentId);
      helper.setRequestAttributeValue(ActionConstants.ACTION, parentAction);
      helper.setRequestAttributeValue(ActionConstants.CHILD_ACTION, newActionItem);
      helper.forward(ActionConstants.ACTION_ITEM_JSP);
    } else {
      helper.setRequestAttributeValue(ActionConstants.ACTION, this.actionService.lookupActionById(newActionItem.getId()));
      helper.forward(ActionConstants.LIST_ACTION_JSP);
    }
  }

  private Action getActionParentItem(String parentId) {
    Action parentActionItem = null;
    if (parentId != null && parentId.length() > 0){
      parentActionItem = getActionItem(parentId);
    }
    return parentActionItem;
  }

  private ActionPriority getActionPriorityBasedObRequest(String priority) {
    ActionPriority actionPriority = null;
    if (priority != null){
      actionPriority = new ActionPriority(new Long(priority), null);
    }
    return actionPriority;
  }

  private Status getActionStatusBasedOnRequest(String status) {
    Status actionStatus = null;
    if (status != null){
      actionStatus = new Status(new Long(status), null);
    }
    return actionStatus;
  }

  private String getValueFromRequest(String value) {
    if (value == null || StringUtils.isEmpty(value.trim())) {
           return null;
       } else {
           return value;
    }
  }

  public void lookupAction(UCCHelper helper) throws IOException {
    Long actionId = new Long(helper.getRequestParameterValue(ActionConstants.ACTION_ID));
    Action actionItem = this.actionService.lookupActionById(actionId);
    setActionAssociatedDataBackInHelper(helper, actionItem);
    setReferenceDataInHelper(helper);
    helper.forward(ActionConstants.ACTION_ITEM_JSP);
  }

  private void setActionAssociatedDataBackInHelper(UCCHelper helper, Action actionItem) throws IOException {
    helper.setRequestAttributeValue(ActionConstants.ACTION, actionItem);
    helper.setRequestAttributeValue(ActionConstants.ACTION_SUBITEMS_CLOSED,
        Boolean.valueOf(areAllSubActionItemsClosed(actionItem.getId())));
    List<Assignment> assignmentList = setCountOfAssignments(helper, actionItem);
//    helper.setRequestAttributeValue(ActionConstants.ASSIGNEES, getAssigneesAsString(assignmentList));
  }

  private List<Assignment> setCountOfAssignments(UCCHelper helper, Action actionItem) {
    //    List<Assignment> assignmentList = actionItem.getAssignments();
    List<Assignment> assignmentList = actionService.lookupAssignmentsByCriteria(actionItem.getId());
    helper.setRequestAttributeValue(ActionConstants.COUNT_OF_ASSIGNMENTS,
        Integer.valueOf(assignmentList.size()).toString());
    return assignmentList;
  }

  private void setCountOfSubActionItems(UCCHelper helper, Action actionItem) {
    List<Action> countOfSubActionItems = actionService.lookupSubActionItems(actionItem.getId().toString());
    helper.setRequestAttributeValue(ActionConstants.COUNT_OF_SUB_ACTION_ITEMS,
        Integer.valueOf(countOfSubActionItems.size()).toString());
  }

  private String getAssigneesAsString(List<Assignment> assignees) {
    StringBuffer assigneesAsString = new StringBuffer();
    if (assignees != null){
    for (Assignment assignee: assignees){
      assigneesAsString.append(assignee.getUser().getUserId()).append(",");
    }
    }
    return assigneesAsString.toString();
  }

  public void lookupAllActions(UCCHelper helper) throws IOException{
    helper.setRequestAttributeValue(ActionConstants.ACTION_LIST, this.actionService.lookupAllActions());
  }

  public void updateAction(UCCHelper helper) throws IOException{
    Action actionItemToBeUpdated = getActionItemToBeUpdatedFromHelper(helper);
    Action updatedAction = this.actionService.updateAction(actionItemToBeUpdated);
    helper.setRequestAttributeValue(ActionConstants.ACTION, updatedAction);
    helper.setRequestAttributeValue(ActionConstants.CHILD_ACTION, updatedAction);
    Document response = outputActionAsXML(helper);
    helper.setContentType("text/xml");
    helper.writeXMLDocument(response, HRPMainConstants.LATIN1_ENCODING);
  }

   public void deleteAction(UCCHelper helper) throws IOException{
    List<String> itemsToBeDeleted = getListOfItemsFromSelectOperation(helper);
    this.actionService.deleteActionItem(itemsToBeDeleted);
    setReferenceDataInHelper(helper);
    String parentId = helper.getRequestParameterValue(ActionConstants.ACTION_ID);
    if ( parentId != null && parentId.length() > 0){
      Action parentAction = getActionItem(parentId);
      helper.setRequestAttributeValue(ActionConstants.ACTION, parentAction);
      helper.setRequestAttributeValue(ActionConstants.ACTION_ID, parentId);
      helper.setRequestAttributeValue(HRPMainConstants.ACTIVE_TAB_INDEX, "0");
      helper.forward(ActionConstants.ACTION_ITEM_JSP);
    }else{
      helper.forward(ActionConstants.LIST_ACTION_JSP);
    }
   }


  private Action getActionItem(String parentId) {
    return this.actionService.lookupActionById(new Long(parentId));
  }

  private List<String> getListOfItemsFromSelectOperation(UCCHelper helper) throws IOException {
     List<String> itemsSelected = new ArrayList<String>();
     if (isAllSelected()) {
       List<Action> filteredUserList = getFilteredActionItemsList(helper);
       getListOfItemsSelected(itemsSelected, filteredUserList);
       return itemsSelected;
     } else {
       return this.getSelectedIds();
     }
   }

  private void getListOfItemsSelected(List<String> itemsList, List<Action> filteredUserList) {
     for (Action item : filteredUserList) {
      itemsList.add(item.getId().toString());
    }
    List<String> idsToExclude = getIdsToExclude();
    for (String id : idsToExclude) {
      itemsList.remove(id);
    }

  }

  private List<Action> getFilteredActionItemsList(UCCHelper helper) throws IOException {
       ActionDataSource actionDataSource = getActionDataSource(helper);
    FilteredXmlDataSource filteredDataSource = new FilteredXmlDataSource(actionDataSource, getFilterValue());
    return (List<Action>) filteredDataSource.getData();

  }

  private ActionDataSource getActionDataSource(UCCHelper helper) {
    return new ActionDataSource(helper);

  }

  private Action getActionItemToBeUpdatedFromHelper(UCCHelper helper) throws IOException {
    Long idLong = new Long(helper.getRequestParameterValue(ActionConstants.ACTION_ID));
    Action actionItemToBeUpdated = this.actionService.lookupActionById(idLong);
    actionItemToBeUpdated.setName(helper.getRequestParameterValue(ActionConstants.ACTION_NAME));
    actionItemToBeUpdated.setDueDate(getDateFromString(helper.getRequestParameterValue(ActionConstants.ACTION_DUE_DATE)));
    actionItemToBeUpdated.setStartDate(getDateFromString(helper.getRequestParameterValue(ActionConstants.ACTION_START_DATE)));
    actionItemToBeUpdated.setDateCompleted(getDateFromString(helper.getRequestParameterValue(ActionConstants.ACTION_DATE_COMPLETED)));
//    ActionStatus newStatus = this.actionService.lookupStatusById(helper.getRequestParameterValue(ActionConstants.ACTION_STATUS));
    ActionPriority newPriority = this.actionService.lookupPriorityById(helper.getRequestParameterValue(ActionConstants.ACTION_PRIORITY));
//    actionItemToBeUpdated.setStatus(newStatus);
    actionItemToBeUpdated.setPriority(newPriority);
    actionItemToBeUpdated.setPercentageComplete(helper.getRequestParameterValue(ActionConstants.ACTION_PERCENT_COMPLETE));
    actionItemToBeUpdated.setDescription(helper.getRequestParameterValue(ActionConstants.ACTION_DESCRIPTION));
    String parentItemId = helper.getRequestParameterValue(ActionConstants.ACTION_PARENT_ITEM);
    if (parentItemId != null && parentItemId.length() > 0){
      setStatusAndParentOfChildAction(helper, actionItemToBeUpdated, parentItemId);
    }else if (actionItemToBeUpdated.getSubActionItems().size() == 0){
    Status newStatus = this.actionService.lookupStatusById(helper.getRequestParameterValue(ActionConstants.ACTION_STATUS));
    actionItemToBeUpdated.setStatus(newStatus);
    }else{
      actionItemToBeUpdated.setStatus(actionItemToBeUpdated.getStatus());
    }
    return actionItemToBeUpdated;
  }

  private void setStatusAndParentOfChildAction(UCCHelper helper, Action actionItemToBeUpdated,
                                               String parentItemId) throws IOException {
    Action parentAction = getActionItem(parentItemId);
    Status newStatus = this.actionService.lookupStatusById(helper.getRequestParameterValue(ActionConstants.ACTION_STATUS));
    actionItemToBeUpdated.setStatus(newStatus);
    actionItemToBeUpdated.setParent(parentAction);
  }

  private Document outputActionAsXML(UCCHelper helper) {
    Document response = createNewDocument();
    Element result = response.createElement("response");
    Action action = (Action) helper.getRequestAttributeValue(ActionConstants.ACTION);
    Element actionInfo = response.createElement("action");
    DOMUtil.addChildElement(actionInfo, "actionId", action.getId().toString());
    DOMUtil.addChildElement(actionInfo, "actionName", action.getName());
    DOMUtil.addChildElement(actionInfo, "actionStartDate", action.getFormattedStartDate());
    DOMUtil.addChildElement(actionInfo, "actionDueDate", action.getFormattedDueDate());
    DOMUtil.addChildElement(actionInfo, "actionStatus", action.getStatus().getValue());
    DOMUtil.addChildElement(actionInfo, "actionPriority", action.getPriority().getValue());
    DOMUtil.addChildElement(actionInfo, "actionDateCompleted", action.getFormattedDateCompleted());
    DOMUtil.addChildElement(actionInfo, "actionPercentComplete", action.getPercentageComplete());
    DOMUtil.addChildElement(actionInfo, "actionDescription", action.getDescription());
    result.appendChild(actionInfo);
    response.appendChild(result);
    return response;
  }

  private boolean areAllSubActionItemsClosed(Long id) throws IOException {
    boolean areAllSubActionItemsClosed = false;
    Action parentActionItem = this.actionService.lookupActionById(id);
    List<Action> subActionItems = parentActionItem.getSubActionItems();
    if (subActionItems != null){
      for (Action subActionItem: subActionItems){
        if (!"Closed".equalsIgnoreCase(subActionItem.getStatus().getValue())){
            return areAllSubActionItemsClosed;
        }else{
          areAllSubActionItemsClosed = true;
        }
       }
    }
    return areAllSubActionItemsClosed;
  }

  public void setActionPlanStatusToClosed (UCCHelper helper) throws Exception{
    String actionId = helper.getRequestParameterValue(ActionConstants.ACTION_ID);
    Action parentActionItem = getActionItem(actionId);
    Status closedStatus = getStatusByValue(ActionConstants.CLOSED_STATUS);
    parentActionItem.setStatus(closedStatus);
    this.actionService.updateAction(parentActionItem);
    helper.setRequestAttributeValue(ActionConstants.ACTION, parentActionItem);
    setReferenceDataInHelper(helper);
    helper.forward(ActionConstants.ACTION_ITEM_JSP);
  }

  private Status getStatusByValue(String value) {
    List<Status> statuses = this.actionService.lookupAllStatusTypes();
    for (Status status : statuses) {
      if (status.getValue().equalsIgnoreCase(value)) {
        return status;
      }
    }
    return null;
  }

public void addAssignmentsToAction(UCCHelper helper) throws IOException {
  String actionId = helper.getRequestParameterValue(ActionConstants.ACTION_ID);
  addAssignmentsForAction(helper);
  setReferenceDataInHelper(helper);
  setActionReferenceDataBackInHelper(helper, actionId);
  helper.forward(ActionConstants.ACTION_ITEM_JSP);
}

  private void setActionReferenceDataBackInHelper(UCCHelper helper, String actionId) {
    Action action = getActionItem(actionId);
    helper.setRequestAttributeValue(ActionConstants.ACTION, action);
    helper.setRequestAttributeValue(ActionConstants.ACTION_ID, actionId);
    setCountOfAssignments(helper, action);
    helper.setRequestAttributeValue(HRPMainConstants.FILTER_VALUE, "");
    helper.setRequestAttributeValue(HRPMainConstants.ACTIVE_TAB_INDEX, "1");
  }

  private List<String> getListOfAssignmentsFromSelectOperation(UCCHelper helper) throws IOException {
     List<String> itemsSelected = new ArrayList<String>();
     if (isAllSelected()) {
       List<LoginUserPaginationImpl> filteredUserList = getFilteredAssignmentList(helper);
       getListOfAssignmentSelected(itemsSelected, filteredUserList);
       return itemsSelected;
     } else {
       return this.getSelectedIds();
     }
   }

  private List<String> getListOfAssignmentsToBeDeletedFromSelectOperation(UCCHelper helper) throws IOException {
     List<String> itemsSelected = new ArrayList<String>();
     if (isAllSelected()) {
       List<Assignment> filteredUserList = getFilteredAssignmentListFromAssignmentTable(helper);
       getListOfAssignmentSelectedForDeletion(itemsSelected, filteredUserList);
       return itemsSelected;
     } else {
       return this.getSelectedIds();
     }
   }

   private void getListOfAssignmentSelectedForDeletion(List<String> itemsList, List<Assignment> filteredUserList) {
     for (Assignment item : filteredUserList) {
      itemsList.add(item.getId().toString());
    }
    List<String> idsToExclude = getIdsToExclude();
    for (String id : idsToExclude) {
      itemsList.remove(id);
    }
  }

  private void getListOfAssignmentSelected(List<String> itemsList, List<LoginUserPaginationImpl> filteredUserList) {
     for (LoginUserPaginationImpl item : filteredUserList) {
      itemsList.add(item.getId().trim());
    }
    List<String> idsToExclude = getIdsToExclude();
    for (String id : idsToExclude) {
      itemsList.remove(id);
    }
  }

  private List<LoginUserPaginationImpl> getFilteredAssignmentList(UCCHelper helper) throws IOException {
    AdminDataSource adminDataSource = getAdminDataSource(helper);
    FilteredXmlDataSource filteredDataSourceForUsers = new FilteredXmlDataSource(adminDataSource, getFilterValue());
    return (List<LoginUserPaginationImpl>) filteredDataSourceForUsers.getData();
  }

  private List<Assignment> getFilteredAssignmentListFromAssignmentTable(UCCHelper helper) throws IOException {
     AssignmentForActionDataSource dataSource = new AssignmentForActionDataSource(helper);
     FilteredXmlDataSource filteredXmlDataSource = new FilteredXmlDataSource(dataSource, getFilterValue());
     return (List<Assignment>) filteredXmlDataSource.getData();
   }


  private AdminDataSource getAdminDataSource(UCCHelper helper) {
    return new AdminDataSource(helper);
  }

  private void addAssignmentsForAction(UCCHelper helper) throws IOException {
    List<String> assignmentIdsToBeAdded = getListOfAssignmentsFromSelectOperation(helper);
    String actionId = helper.getRequestParameterValue(ActionConstants.ACTION_ID);
    this.actionService.addAssignmentToAction(null, assignmentIdsToBeAdded, new Long(actionId), false);
  }

  public void deleteAssignmentForAction(UCCHelper helper) throws IOException{
    String parentId = helper.getRequestParameterValue(ActionConstants.ACTION_ID);
    Action action = getActionItem(parentId);
    List<String> itemsToBeDeleted = getListOfAssignmentsToBeDeletedFromSelectOperation(helper);
    this.actionService.deleteAssignmentFromAction(itemsToBeDeleted, action);
    setReferenceDataInHelper(helper);
    helper.setRequestAttributeValue(ActionConstants.ACTION, action);
    helper.setRequestAttributeValue(ActionConstants.ACTION_ID, parentId);
    helper.setRequestAttributeValue(HRPMainConstants.ACTIVE_TAB_INDEX, "1");
    helper.forward(ActionConstants.ACTION_ITEM_JSP);
  }

  public void setAssignmentAsPrimary(UCCHelper helper) throws IOException {
    String assingmentId = helper.getRequestParameterValue(AssignmentConstants.ASSIGNMENT_ID);
    String actionId = helper.getRequestParameterValue(ActionConstants.TARGET_ID);
    this.actionService.setAssignmentAsPrimaryForAction(assingmentId, actionId);
 }

  private Date getDateFromString(String dateStr) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    try {
      return sdf.parse(dateStr);
    } catch (ParseException e) {
      logger.error("Unable to parse action date");
    }
    return null;
  }

  protected ActionService getActionService() {
    return actionService;
  }
}