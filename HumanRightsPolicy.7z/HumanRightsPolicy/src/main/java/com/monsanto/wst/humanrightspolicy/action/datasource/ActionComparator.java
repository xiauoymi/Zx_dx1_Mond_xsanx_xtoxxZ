/*
 ActionComparator was created on Aug 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.action.datasource;

import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: ActionComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-07 19:05:23 $
 *
 * @author rrmall
 * @version $Revision: 1.3 $
 */
public abstract class ActionComparator implements Comparator<XmlObject> {
  protected abstract String getValue(Action action);

  public int compare(XmlObject o1, XmlObject o2) {
    if (o1 instanceof Action && o2 instanceof Action) {
      return compareAction((Action) o1, (Action) o2);
    } else {
      return 0;
    }
  }

  public int compareAction(Action action1, Action action2) {
    String value1 = blankIfNull(getValue(action1));
    String value2 = blankIfNull(getValue(action2));
    return value1.compareTo(value2);
  }

  public String blankIfNull(String st) {
    if (st == null) {
      return "";
    } else {
      return st;
    }
  }
}