/*
 ActionDataSource was created on Aug 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.action.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.action.ActionConstants;
import com.monsanto.wst.humanrightspolicy.action.service.ActionService;
import com.monsanto.wst.humanrightspolicy.controller.XmlDataPaginationController;
import com.monsanto.wst.humanrightspolicy.datasource.ComparatorMap;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.ParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.UCCHelperParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.textutil.TextUtil;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;

/**
 * Filename:    $RCSfile: ActionDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-12-04 16:49:57 $
 *
 * @author rrmall
 * @version $Revision: 1.10 $
 */
public class ActionDataSource implements XmlDataSource {
    public static final String NAME_SORT_KEY = "actionName";
    public static final String STATUS_SORT_KEY = "actionStatus";
    public static final String PRIORITY_SORT_KEY = "actionPriority";

    protected final ParameterCollection params;
    private final ActionService actionService;

    protected static final ComparatorMap<XmlObject> comparatorMap;

    static {
        comparatorMap = new ComparatorMap<XmlObject>(new ActionDefaultComparator());
        comparatorMap.addComparator(NAME_SORT_KEY, new ActionNameComparator());
        comparatorMap.addComparator(STATUS_SORT_KEY, new ActionStatusComparator());
        comparatorMap.addComparator(PRIORITY_SORT_KEY, new ActionPriorityComparator());
    }

    public ActionDataSource(ParameterCollection params, ActionService actionService) {
        this.params = params;
        this.actionService = actionService;
    }

    public ActionDataSource(UCCHelper helper, ActionService actionService) {
        this(new UCCHelperParameterCollection(helper), actionService);
    }

    public ActionDataSource(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initActionService());
    }

    public ActionDataSource(ParameterCollection params) {
        this(params, InitService.initActionService());
    }

    public List<? extends XmlObject> getData() throws IOException {
        String actionItemId = params.get(ActionConstants.ACTION_ID);
        return getMyActionItems(actionItemId);
    }

    public Comparator<XmlObject> getComparator(String sortKey) {
        return comparatorMap.getComparator(sortKey);
    }

    public boolean isSorted() {
        return false;
    }

    public boolean isFiltered() {
        return false;
    }

    public int getTotalRecords() throws IOException {
        return UNKNOWN_RECORD_COUNT;
    }

    private List<? extends XmlObject> getMyActionItems(String actionItemId) {
        if (actionItemId != null && actionItemId.trim().length() > 0) {
            return this.actionService.lookupSubActionItems(actionItemId);
//      Action actionItem = this.actionService.lookupActionById(new Long(actionItemId));
//      return actionItem.getSubActionItems();
        } else {
            return this.actionService.lookupAllActions();
        }
    }

    public ActionService getActionService() {
        return actionService;
    }

    public String getFilterValue() throws IOException {
        return StringUtils.defaultString(
                TextUtil.decodeUsingUTF8(params.get(XmlDataPaginationController.FILTER_VALUE)));
    }
}