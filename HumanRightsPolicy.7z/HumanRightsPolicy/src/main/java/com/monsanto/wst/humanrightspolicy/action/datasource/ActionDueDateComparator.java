/*
 ActionDueDateComparator was created on Aug 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.action.datasource;

import com.monsanto.wst.humanrightspolicy.model.Action;

/**
 * Filename:    $RCSfile: ActionDueDateComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-09-11 20:02:30 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class ActionDueDateComparator extends ActionComparator{
  protected String getValue(Action action) {
    return action.getFormattedDueDate();
  }
}