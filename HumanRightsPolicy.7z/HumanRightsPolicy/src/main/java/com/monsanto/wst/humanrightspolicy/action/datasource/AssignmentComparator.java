/*
 AssignmentComparator was created on Oct 1, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.action.datasource;

import com.monsanto.wst.humanrightspolicy.model.Assignment;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: AssignmentComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-07 19:04:44 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public abstract class AssignmentComparator implements Comparator<XmlObject> {
  protected abstract String getValue(Assignment assignment);

   public int compare(XmlObject o1, XmlObject o2) {
    if (o1 instanceof Assignment && o2 instanceof Assignment) {
      return compareAssignment((Assignment) o1, (Assignment) o2);
    } else {
      return 0;
    }
  }

  public int compareAssignment(Assignment assgn1, Assignment assgn2) {
    String value1 = blankIfNull(getValue(assgn1));
    String value2 = blankIfNull(getValue(assgn2));
    return value1.compareTo(value2);
  }

  public String blankIfNull(String st) {
    if (st == null) {
      return "";
    } else {
      return st;
    }
  }
}