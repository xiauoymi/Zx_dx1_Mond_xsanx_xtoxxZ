/*
 AssignmentNameComparator was created on Oct 1, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.action.datasource;

import com.monsanto.wst.humanrightspolicy.model.Assignment;

/**
 * Filename:    $RCSfile: AssignmentDefaultComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-16 22:22:29 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class AssignmentDefaultComparator extends AssignmentComparator {
  protected String getValue(Assignment assignment) {
    return assignment.getId().toString();
  }
}