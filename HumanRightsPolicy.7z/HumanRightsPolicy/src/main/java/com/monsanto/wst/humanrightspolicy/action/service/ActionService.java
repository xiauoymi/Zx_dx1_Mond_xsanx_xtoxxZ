/*
 ActionService was created on Aug 25, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.action.service;

import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.model.ActionPriority;
import com.monsanto.wst.humanrightspolicy.model.Assignment;
import com.monsanto.wst.humanrightspolicy.model.Status;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: ActionService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-16 22:22:29 $
 *
 * @author rrmall
 * @version $Revision: 1.5 $
 */
public interface ActionService {
  Action addAction(Long id, String name, Date startDate, Date dueDate, Date dateCompleted,
                   Status actionStatus,
                   ActionPriority actionPriority, String percentComplete, String description, Action parent);

  Action lookupActionById(Long actionId);

  List<Action> lookupAllActions();

  List<Status> lookupAllStatusTypes();

  List<ActionPriority> lookupAllPriorityTypes();

  Action updateAction(
      Action action);

  Status lookupStatusById(String statusId);

  ActionPriority lookupPriorityById(String priorityId);

//  void addItemToItemMapping(Long parentId, Long id);

  List<Action> lookupSubActionItemsByCriteria(Long actionId);

  List<Action> lookupSubActionItems(String actionItemId);

  void deleteActionItem(List<String> actionsToBeDeleted);

  void addAssignmentToAction(Long id, List<String> userIds, Long actionId, boolean isPrimary);

  List<Assignment> lookupAssignmentsByCriteria(Long actionId);

  void deleteAssignmentFromAction(List<String> assignments, Action action);

  void setAssignmentAsPrimaryForAction(String assingmentId, String actionId);
}