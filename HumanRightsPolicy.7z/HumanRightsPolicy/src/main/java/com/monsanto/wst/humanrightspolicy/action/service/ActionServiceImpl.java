/*
 ActionServiceImpl was created on Aug 25, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.action.service;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.model.*;
import org.hibernate.Criteria;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: ActionServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-12-11 22:17:44 $
 *
 * @author rrmall
 * @version $Revision: 1.8 $
 */
public class ActionServiceImpl implements ActionService {
    private final GenericDAO<Action, Long> actionDAO;
    private final GenericDAO<Status, Long> actionStatusDAO;
    private final GenericDAO<ActionPriority, Long> actionPriorityDAO;
    private final GenericDAO<LoginUser, Long> userDAO;
    private final GenericDAO<Assignment, Long> assignmentDAO;

    public ActionServiceImpl(GenericDAO<Action, Long> actionDAO, GenericDAO<Status, Long> actionStatusDAO,
                             GenericDAO<ActionPriority, Long> actionPriorityDAO,
                             GenericDAO<LoginUser, Long> userDAO, GenericDAO<Assignment, Long> assignmentDAO) {
        this.actionDAO = actionDAO;
        this.actionStatusDAO = actionStatusDAO;
        this.actionPriorityDAO = actionPriorityDAO;
        this.userDAO = userDAO;
        this.assignmentDAO = assignmentDAO;
    }

    public Action addAction(Long id, String name, Date startDate, Date dueDate, Date dateCompleted,
                            Status actionStatus,
                            ActionPriority actionPriority, String percentComplete, String description, Action parent) {
        Action tempAction = new Action(id, name, startDate, dueDate, dateCompleted, actionStatus, actionPriority, percentComplete, description,
                parent);
        Action newAction = this.actionDAO.save(tempAction);
        if (parent != null) {
            parent.getSubActionItems().add(newAction);
        }
        return newAction;
    }

    public Action lookupActionById(Long actionId) {
        return this.actionDAO.findByPrimaryKey(actionId);
    }

    public List<Action> lookupAllActions() {
        return this.actionDAO.findAll();
    }

    public List<Status> lookupAllStatusTypes() {
        return this.actionStatusDAO.findAll();
    }

    public List<ActionPriority> lookupAllPriorityTypes() {
        return this.actionPriorityDAO.findAll();
    }

    public Action updateAction(
            Action action) {
        return this.actionDAO.save(action);
    }

    public Status lookupStatusById(String statusId) {
        return this.actionStatusDAO.findByPrimaryKey(new Long(statusId));
    }

    public ActionPriority lookupPriorityById(String priorityId) {
        return this.actionPriorityDAO.findByPrimaryKey(new Long(priorityId));
    }

//  public void addItemToItemMapping(Long parentId, Long childId) {
//    Action parentAction = this.actionDAO.findByPrimaryKey(parentId);
//    Action childAction = this.actionDAO.findByPrimaryKey(childId);
//    ItemToItem itemToItemMapping = new ItemToItem(null, parentAction, childAction);
//    this.itemToItemDAO.save(itemToItemMapping);
//  }

    public List<Action> lookupSubActionItems(String actionItemId) {
        return (List<Action>) this.actionDAO.createCriteria().add(Restrictions.eq("parent.id", new Long(actionItemId))).list();
    }

    public void deleteActionItem(List<String> action) {
        for (String actionId : action) {
            Action actionItemToBeDeleted = this.actionDAO.findByPrimaryKey(new Long(actionId));
            if (actionItemToBeDeleted != null) {
                Action parentItem = actionItemToBeDeleted.getParent();
                if (parentItem != null) {
                    parentItem.getSubActionItems().remove(actionItemToBeDeleted);
                }
                this.actionDAO.delete(actionItemToBeDeleted);
            }
        }
    }

    public List<Action> lookupSubActionItemsByCriteria(Long actionId) {
        Action parentItem = this.actionDAO.findByPrimaryKey(actionId);
        return parentItem.getSubActionItems();
//    return this.actionDAO.createCriteria().add(Restrictions.in("id", subActionItemIds)).list();
    }

    public void addAssignmentToAction(Long id, List<String> userIds, Long actionId, boolean isPrimary) {
        Action action = this.actionDAO.findByPrimaryKey(actionId);
        for (String userId : userIds) {
            LoginUser user = getUser(userId);
            Assignment assignment = new Assignment(null, user, action, false, HRPEntityType.Action);
            deleteAssignmentIfRelationAlreadyExists(assignment, actionId);
            Assignment savedAssignment = saveAssignment(assignment);
            if (isPrimary) {
                setAssignmentAsPrimaryForAction(savedAssignment.getId().toString(), action.getId().toString());
            }
            action.getAssignments().add(savedAssignment);
        }
    }

    private void deleteAssignmentIfRelationAlreadyExists(Assignment assignment, Long actionId) {
        Assignment assignt = (Assignment) this.assignmentDAO.createCriteria().add(Restrictions.eq("user.id", assignment.getUser().getId())).add(Restrictions.eq("target.id", actionId)).uniqueResult();
        if (assignt != null) {
            this.assignmentDAO.delete(assignt);
        }
    }

    public void deleteAssignmentFromAction(List<String> assignments, Action action) {
        for (String id : assignments) {
            Assignment assignment = this.assignmentDAO.findByPrimaryKey(new Long(id));
            if (!"Y".equalsIgnoreCase(assignment.getIsPrimaryAsYorN())) {
                this.assignmentDAO.delete(assignment);
                action.getAssignments().remove(assignment);
            }
        }
    }

    private Assignment saveAssignment(Assignment assignment) {
        return this.assignmentDAO.save(assignment);
    }

    private LoginUser getUser(String userId) {
        Criteria criteria = userDAO.createCriteria().add(Expression.eq("userId", userId).ignoreCase());
        return (LoginUser) criteria.uniqueResult();
    }

    public List<Assignment> lookupAssignmentsByCriteria(Long actionId) {
        return this.assignmentDAO.createCriteria().add(Restrictions.eq("target.id", actionId)).list();
    }

    public void setAssignmentAsPrimaryForAction(String assignmentId, String actionId) {
        Assignment oldPrimary = getOldPrimaryAssignment(actionId);
        updateOldPrimaryAssignment(oldPrimary);
        this.assignmentDAO.save(newPrimaryAssignment(assignmentId));
    }

    private Assignment getOldPrimaryAssignment(String actionId) {
        Assignment oldPrimary = (Assignment) this.assignmentDAO.createCriteria().add(Restrictions.eq("target.id", Long.valueOf(actionId))).add(Restrictions.eq("isPrimary",
                Boolean.valueOf(true))).uniqueResult();
        return oldPrimary;
    }

    private Assignment newPrimaryAssignment(String assingmentId) {
        Assignment newPrimary = this.assignmentDAO.findByPrimaryKey(Long.valueOf(assingmentId));
        newPrimary.setIsPrimary(true);
        return newPrimary;
    }

    private void updateOldPrimaryAssignment(Assignment oldPrimary) {
        if (oldPrimary != null) {
            oldPrimary.setIsPrimary(false);
            this.assignmentDAO.save(oldPrimary);
        }
    }
}