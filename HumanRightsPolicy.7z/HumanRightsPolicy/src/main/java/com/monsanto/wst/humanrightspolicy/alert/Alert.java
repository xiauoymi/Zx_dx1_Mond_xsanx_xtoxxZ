package com.monsanto.wst.humanrightspolicy.alert;

import com.monsanto.wst.humanrightspolicy.model.HRPEntity;
import org.hibernate.annotations.AccessType;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import java.util.Date;

/*
 Alert was created on Aug 22, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
@Entity
@AccessType("field")
public class Alert {
    @Id
    private Long id;

    private String subject;

    private String description;

    private Date date;

    @ManyToOne(
            targetEntity = HRPEntity.class
    )
    private HRPEntity target;

    public Alert() {
        this(null, null, null, null);
    }

    public Alert(Long id, HRPEntity target, String subject, String description) {
        this.id = id;
        this.target = target;
        this.subject = subject;
        this.description = description;
        this.date = new Date();
    }

    public String getSubject() {
        return subject;
    }

    public String getDescription() {
        return description;
    }

    public Date getDate() {
        return date;
    }

    public HRPEntity getTarget() {
        return target;
    }

    public boolean equals(Object o) {
        if (o instanceof Alert) {
            Alert alert = (Alert) o;
            return id.equals(alert.id);
        } else {
            return false;
        }
    }

    public int hashCode() {
        return id.intValue();
    }
}
