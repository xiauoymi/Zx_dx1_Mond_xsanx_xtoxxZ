package com.monsanto.wst.humanrightspolicy.alert.dao;

import com.monsanto.wst.humanrightspolicy.model.HRPEntity;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface AlertDAO {
    void addAlert(HRPEntity target, String subject, String description);
}
