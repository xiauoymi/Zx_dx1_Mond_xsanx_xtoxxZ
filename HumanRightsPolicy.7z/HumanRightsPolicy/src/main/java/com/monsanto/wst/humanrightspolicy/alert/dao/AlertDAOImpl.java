package com.monsanto.wst.humanrightspolicy.alert.dao;

import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.humanrightspolicy.alert.Alert;
import com.monsanto.wst.humanrightspolicy.model.HRPEntity;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class AlertDAOImpl implements AlertDAO {
    private final HibernateFactory hibernate;

    public AlertDAOImpl(HibernateFactory hibernate) {
        this.hibernate = hibernate;
    }

    public void addAlert(HRPEntity target, String subject, String description) {
        Alert alert = new Alert(null, target, subject, description);
        hibernate.getSession().save(alert);
    }
}
