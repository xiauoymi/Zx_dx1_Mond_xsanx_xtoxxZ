/*
 Assessment was created on Oct 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment;

import com.monsanto.wst.humanrightspolicy.utils.DateUtil;
import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.textutil.TextUtil;
import com.monsanto.wst.hibernate.NoDeleteAllowed;

import javax.persistence.*;
import java.util.Date;

import org.hibernate.annotations.AccessType;

/**
 * Filename:    $RCSfile: Assessment.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-17 21:07:17 $
 *
 * @author RRMALL
 * @version $Revision: 1.1 $
 */
@Entity
@AccessType("field")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@Table(schema="HRPOLICY", name="ASSESSMENT")
public class Assessment extends HRPEntity implements XmlObject {
  @Column(name="NAME")
  private String name;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name="DUE_DATE")
  private Date dueDate;

  @JoinColumn(name="STATUS_ID")
  @ManyToOne(targetEntity= Status.class)
  private Status status;

  @JoinColumn(name = "REGION_ID")
  @ManyToOne(targetEntity = Region.class)
  private Region region;

  @JoinColumn(name = "COUNTRY_ID")
  @ManyToOne(targetEntity = Country.class)
  private Country country;

  @JoinColumn(name = "STATE_OR_PROVINCE_ID")
  @ManyToOne(targetEntity = StateProvince.class)
  private StateProvince state;

  @Column(name="DESCRIPTION", length = 2000)
  private String description;


  public Assessment(){
  }
  public Assessment(Long id, String name, Date dueDate, Status status, Region region, Country country,
                    StateProvince state, String description) {

    super(id);
    this.name = name;
    this.dueDate = dueDate;
    this.status = status;
    this.region = region;
    this.country = country;
    this.state = state;
    this.description = description;
  }

  public String getName() {
    return name;
  }

  public Date getDueDate() {
    return dueDate;
  }

  public Status getStatus() {
    return status;
  }

  public Region getRegion() {
    return region;
  }

  public Country getCountry() {
    return country;
  }

  public StateProvince getState() {
    return state;
  }

  public String getDescription() {
    return description;
  }

  public String getFormattedDueDate(){
    return DateUtil.formatDate(dueDate);
  }

  public String toXml() {
    String id = getId().toString();
    String viewUrl = new HrpUrlBuilder("assessment").getViewAssessmentUrl(id);
    StringBuffer xml = new StringBuffer("<assessment>");
    xml.append("<id>").append(TextUtil.escapeXml(id)).append("</id>");
    xml.append("<name>").append(TextUtil.escapeXml(getName())).append("</name>");
    xml.append("<dueDate>").append(TextUtil.escapeXml(getFormattedDueDate())).append("</dueDate>");
    xml.append("<status>").append(TextUtil.escapeXml(getStatus().getValue())).append("</status>");
    xml.append("<region>").append(TextUtil.escapeXml(getRegion().getValue())).append("</region>");
    xml.append("<country>").append(TextUtil.escapeXml(getCountry().getValue())).append("</country>");
    xml.append("<state>").append(TextUtil.escapeXml(getState().getValue())).append("</state>");
    xml.append("<viewUrl>").append(TextUtil.escapeXml(viewUrl)).append("</viewUrl>");
    xml.append("</assessment>");
    return xml.toString();
  }
}