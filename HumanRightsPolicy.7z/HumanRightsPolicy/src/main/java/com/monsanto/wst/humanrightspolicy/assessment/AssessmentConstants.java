/*
 AssessmentConstants was created on Sep 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment;

/**
 * Filename:    $RCSfile: AssessmentConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-17 21:05:13 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public interface AssessmentConstants {
  public static final String GLB_ASMT_LIST = "gblAsmtList";
  public static final String GLB_ASSESSMENT_JSP = "/WEB-INF/jsp/assessment/globalAssessment.jsp";
  public static final String GLB_ASSESSMENT_BY_REGION_JSP = "/WEB-INF/jsp/assessment/globalAssessmentForRegion.jsp";
  public static final String GLB_ASSESSMENT_BY_COUNTRY_JSP = "/WEB-INF/jsp/assessment/globalAssessmentForCountry.jsp";
  public static final String OVERALL_RISK = "overallRisk";
  public static final String REGION_POLICY_RISK_MAP = "regionPolicyRiskMap";
  public static final String POLICIES = "policies";
  public static final String REGIONS = "regions";
  public static final String COUNTRY_RISK_MAP = "countryRiskMap";
  public static final String HIGH_RISK_COUNTRY_POLICY_MAP = "hishRiskCountryPolicyMap";
  public static final String COUNTRIES = "countries";
  public static final String REGION = "region";
  public static final String COUNTRY = "country";
  public static final String STATE = "state";
  public static final String ASSESSMENT_LIST = "assessmentList";
  public static final String STATUS_LIST  = "statusList";
  public static final String ASSESSMENT_JSP = "/WEB-INF/jsp/assessment/assessment.jsp";
  public static final String LIST_ASSESSMENT_JSP = "/WEB-INF/jsp/assessment/listAssessments.jsp";
}