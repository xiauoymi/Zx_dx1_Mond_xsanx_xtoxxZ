/*
 PolicyNameComparator was created on Sep 9, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: GlbAsmtPolicyNameComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:23 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class GlbAsmtPolicyNameComparator implements Comparator<GlobalAssessment> {

  public int compare(GlobalAssessment ga1, GlobalAssessment ga2) {
    Policy p1 = ga1.getPolicy();
    Policy p2 = ga2.getPolicy();
    return p1.getValue().compareTo(p2.getValue());
  }
}