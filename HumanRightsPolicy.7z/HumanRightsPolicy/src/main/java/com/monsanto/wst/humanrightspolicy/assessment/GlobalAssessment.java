/*
 GlobalAssessment was created on Sep 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment;

import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import org.hibernate.annotations.AccessType;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: GlobalAssessment.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:23 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
@Entity
@AccessType("field")
@Table(schema = "HRPOLICY", name = "GLOBAL_ASSESSMENT")
@SequenceGenerator(name = "hrpSeq", sequenceName="HRPOLICY.HRP_SEQ")
public class GlobalAssessment implements XmlObject {
  @Id
  @Column(name = "ID", updatable = false)
  @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="hrpSeq")
  private Long id;

  @JoinColumn(name = "COUNTRY_ID")
  @ManyToOne(targetEntity = Country.class)
  private Country country;

  @JoinColumn(name = "POLICY_ID")
  @ManyToOne(targetEntity = Policy.class)
  private Policy policy;

  @Enumerated(EnumType.STRING)
  @Column(name = "RISK", updatable = false)  
  private Risk risk;

  public GlobalAssessment() {
  }

  public GlobalAssessment(Long id, Country country, Policy policy, Risk risk) {
    this.id = id;
    this.country = country;
    this.policy = policy;
    this.risk = risk;
  }

  public Long getId() {
    return id;
  }

  public Country getCountry() {
    return country;
  }

  public Policy getPolicy() {
    return policy;
  }

  public Risk getRisk() {
    return risk;
  }

  public void setRisk(Risk risk) {
    this.risk = risk;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public void setPolicy(Policy policy) {
    this.policy = policy;
  }

  public String toXml() {
    StringBuffer xml = new StringBuffer("<globalAssessment>");
    xml.append("<id>").append(getId().toString()).append("</id>");
    xml.append("<countryId>").append(getCountry().getId()).append("</countryId>");
    xml.append("<country>").append(getCountry().getValue()).append("</country>");
    xml.append("<policyId>").append(getPolicy().getId()).append("</policyId>");
    xml.append("<policy>").append(getPolicy().getValue()).append("</policy>");
    xml.append("<risk>").append(getRisk()).append("</risk>");
    xml.append("</globalAssessment>");
    return xml.toString();
  }
}