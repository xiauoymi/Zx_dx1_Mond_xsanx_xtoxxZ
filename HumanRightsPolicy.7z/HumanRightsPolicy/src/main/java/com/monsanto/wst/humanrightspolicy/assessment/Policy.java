/*
 Issue was created on Aug 20, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.utils.XMLUtil;
import org.hibernate.annotations.AccessType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Filename:    $RCSfile: Policy.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-12-16 20:26:55 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "HRPOLICY", name = "POLICY")
public class Policy implements Comparable, XmlObject {
    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "VALUE")
    private String value;

    Policy() {
    }

    public Policy(Long id, String value) {
        this.id = id;
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public int compareTo(Object o) {
        return value.compareTo(((Policy) o).getValue());
    }

    public String toXml() {
        return "\t<Policy>" +
                "\t\t<id>" + id + "</id>" +
                "\t\t<value>" + XMLUtil.xmlEncode(value) + "</value>" +
                "\t</Policy>";
    }
}