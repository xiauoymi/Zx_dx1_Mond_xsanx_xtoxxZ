package com.monsanto.wst.humanrightspolicy.assessment;

/**
 * Filename:    $RCSfile: Risk.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-06 20:50:07 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public enum Risk {
  NotAssessed, Low, Medium, High;

  public boolean higherThan(Risk otherRisk) {
    return this.compareTo(otherRisk) > 0;
  }  
}
