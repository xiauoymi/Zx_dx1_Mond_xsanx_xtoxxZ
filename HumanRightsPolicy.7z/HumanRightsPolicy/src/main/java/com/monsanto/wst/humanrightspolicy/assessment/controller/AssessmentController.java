/*
 AssessmentController was created on Oct 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.assessment.Assessment;
import com.monsanto.wst.humanrightspolicy.assessment.AssessmentConstants;
import com.monsanto.wst.humanrightspolicy.assessment.service.AssessmentService;
import com.monsanto.wst.humanrightspolicy.geodata.GeoDataFactory;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.humanrightspolicy.action.ActionConstants;
import com.monsanto.wst.humanrightspolicy.action.service.ActionService;
import com.monsanto.wst.servletframework.AbstractDispatchController;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: AssessmentController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-17 21:07:17 $
 *
 * @author RRMALL
 * @version $Revision: 1.1 $
 */
public class AssessmentController extends AbstractDispatchController {
  private AssessmentService assessmentService;
  private GeoDataFactory geoDataFactory;
  private ActionService actionService;

  public AssessmentController() {
    this(InitService.initAssessmentService(), InitService.initGeoDataFactory());
  }


  public AssessmentController(AssessmentService service, GeoDataFactory geoDataFactory) {
    this.assessmentService = service;
    this.geoDataFactory = geoDataFactory;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    List<Assessment> allAssessments = this.assessmentService.lookupAllAssessments();
    helper.setRequestAttributeValue(AssessmentConstants.ASSESSMENT_LIST, allAssessments);
    setReferenceDataInHelper(helper);
    helper.forward(AssessmentConstants.LIST_ASSESSMENT_JSP);
  }

  private void setReferenceDataInHelper(UCCHelper helper) {
    helper.setRequestAttributeValue(AssessmentConstants.STATUS_LIST,this.assessmentService.lookupAllStatusTypes());
  }
}