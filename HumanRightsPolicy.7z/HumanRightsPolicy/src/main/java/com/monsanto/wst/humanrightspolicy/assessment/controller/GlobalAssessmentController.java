/*
 AssessmentController was created on Aug 4, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.assessment.AssessmentConstants;
import com.monsanto.wst.humanrightspolicy.assessment.GlobalAssessment;
import com.monsanto.wst.humanrightspolicy.assessment.Policy;
import com.monsanto.wst.humanrightspolicy.assessment.Risk;
import com.monsanto.wst.humanrightspolicy.assessment.service.GlobalAssessmentService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.controller.HrpController;
import com.monsanto.wst.humanrightspolicy.geodata.GeoDataFactory;
import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.Region;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.io.IOException;
import java.util.*;

/**
 * Filename:    $RCSfile: GlobalAssessmentController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-17 21:05:12 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class GlobalAssessmentController extends HrpController {
  private GlobalAssessmentService glbAsmtService;
  private GeoDataFactory geoDataFactory;

  public GlobalAssessmentController() {
    this(InitService.initGlobalAssessmentService(), InitService.initGeoDataFactory());
  }

  public GlobalAssessmentController(GlobalAssessmentService glbAsmtService, GeoDataFactory geoDataFactory) {
    this.glbAsmtService = glbAsmtService;
    this.geoDataFactory = geoDataFactory;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    Risk overallRisk = Risk.Low;
    List<Region> regions = geoDataFactory.getRegions();
    Map<String, Map<Long, Risk>>
        regionPolicyRiskMap = new LinkedHashMap<String, Map<Long, Risk>>();
    for (Region r : regions) {
      Map<Long, Risk> policyRiskMap = new LinkedHashMap<Long, Risk>();
      Risk overallRegionRisk = getOverallRegionRiskAndUpdateMap(policyRiskMap, r.getCountries());
      if (overallRegionRisk.higherThan(overallRisk)) {
        overallRisk = overallRegionRisk;
      }
      regionPolicyRiskMap.put(r.getId(), policyRiskMap);
    }

    helper.setRequestAttributeValue(AssessmentConstants.OVERALL_RISK, overallRisk);
    helper.setRequestAttributeValue(AssessmentConstants.REGION_POLICY_RISK_MAP, regionPolicyRiskMap);
    helper.setRequestAttributeValue(AssessmentConstants.POLICIES, this.glbAsmtService.lookupAllPolies());
    helper.setRequestAttributeValue(AssessmentConstants.REGIONS, regions);
    helper.forward(AssessmentConstants.GLB_ASSESSMENT_JSP);
  }

  public void lookupGlobalAssessmentByRegion(UCCHelper helper) throws IOException {
    String regionId = helper.getRequestParameterValue(HRPMainConstants.REGION);
    Region regionById = geoDataFactory.getRegionById(regionId);
    List<Country> countries = regionById.getCountries();
    List<Country> countriesWithAssessments = new ArrayList<Country>();

    Risk regionRisk = Risk.Low;

    Map<String, Risk> countryRiskMap = new LinkedHashMap<String, Risk>();
    Map<String, List<Policy>> highRiskCountryPolicyMap = new LinkedHashMap<String, List<Policy>>();
    for (Country c : countries) {
      Risk overallCountryRisk = c.getOverallRisk();
      if (overallCountryRisk != Risk.NotAssessed) {
        countriesWithAssessments.add(c);
        if (overallCountryRisk.higherThan(regionRisk)) {
          regionRisk = overallCountryRisk;
        }
        countryRiskMap.put(c.getId(), overallCountryRisk);
        updateCountryPolicyMap(highRiskCountryPolicyMap, c.getGlobalAssessments());
      }
    }

    helper.setRequestAttributeValue(AssessmentConstants.OVERALL_RISK, regionRisk);
    helper.setRequestAttributeValue(AssessmentConstants.COUNTRY_RISK_MAP, countryRiskMap);
    helper.setRequestAttributeValue(AssessmentConstants.HIGH_RISK_COUNTRY_POLICY_MAP, highRiskCountryPolicyMap);
    helper.setRequestAttributeValue(AssessmentConstants.COUNTRIES, countriesWithAssessments);
    helper.setRequestAttributeValue(AssessmentConstants.REGION, regionById);
    helper.forward(AssessmentConstants.GLB_ASSESSMENT_BY_REGION_JSP);
  }

  public void lookupGlobalAssessmentByCountry(UCCHelper helper) throws IOException {
    String countryId = helper.getRequestParameterValue(HRPMainConstants.COUNTRY);
    Country countryById = geoDataFactory.getCountryById(countryId);
    SortedSet<GlobalAssessment> gblAsmts = countryById.getGlobalAssessments();

    helper.setRequestAttributeValue(AssessmentConstants.COUNTRY, countryById);
    helper.setRequestAttributeValue(AssessmentConstants.OVERALL_RISK, countryById.getOverallRisk());
    helper.setRequestAttributeValue(AssessmentConstants.GLB_ASMT_LIST, gblAsmts);
    helper.forward(AssessmentConstants.GLB_ASSESSMENT_BY_COUNTRY_JSP);
  }

  private Risk getOverallRegionRiskAndUpdateMap(Map<Long, Risk> policyRiskMap, List<Country> countries) {
    Risk overallRegionRisk = Risk.Low;
    for (Country c : countries) {
      Risk overallCountryRisk = c.getOverallRisk();
      if (overallCountryRisk.higherThan(overallRegionRisk)) {
        overallRegionRisk = overallCountryRisk;
      }
      populatePolicyRiskMap(policyRiskMap, c.getGlobalAssessments());
    }
    return overallRegionRisk;
  }

  private void populatePolicyRiskMap(Map<Long, Risk> policyRiskMap,
                                     SortedSet<GlobalAssessment> gbltAsmtsForCountry) {
    for (GlobalAssessment ga : gbltAsmtsForCountry) {
      if (policyRiskMap.containsKey(ga.getPolicy().getId())) {
        Risk risk = policyRiskMap.get(ga.getPolicy().getId());
        if (ga.getRisk().higherThan(risk)) {
          policyRiskMap.put(ga.getPolicy().getId(), ga.getRisk());
        }
      } else {
        policyRiskMap.put(ga.getPolicy().getId(), ga.getRisk());
      }
    }
  }

  private void updateCountryPolicyMap(Map<String, List<Policy>> highRiskCountryPolicyMap,
                                      SortedSet<GlobalAssessment> gblAsmtsForCountry) {
    for (GlobalAssessment ga : gblAsmtsForCountry) {
      if (ga.getRisk().equals(Risk.High)) {
        List<Policy> policyList;
        if (highRiskCountryPolicyMap.containsKey(ga.getCountry().getId())) {
          policyList = highRiskCountryPolicyMap.get(ga.getCountry().getId());
        } else {
          policyList = new ArrayList<Policy>();
        }
        policyList.add(ga.getPolicy());
        highRiskCountryPolicyMap.put(ga.getCountry().getId(), policyList);
      }
    }
  }
}