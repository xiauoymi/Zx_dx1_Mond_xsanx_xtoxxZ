/*
 GlobalAssessmentDAO was created on Sep 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment.dao;

/**
 * Filename:    $RCSfile: GlobalAssessmentDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-09-15 13:25:06 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public interface GlobalAssessmentDAO {
}