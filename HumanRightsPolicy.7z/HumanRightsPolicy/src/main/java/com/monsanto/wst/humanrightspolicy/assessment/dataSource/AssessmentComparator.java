/*
 AssessmentComparator was created on Oct 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment.dataSource;

import com.monsanto.wst.humanrightspolicy.assessment.Assessment;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: AssessmentComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-17 21:05:12 $
 *
 * @author RRMALL
 * @version $Revision: 1.1 $
 */
public abstract class AssessmentComparator implements Comparator<XmlObject> {
  protected abstract String getValue(Assessment assessment);

   public int compare(XmlObject o1, XmlObject o2) {
    if (o1 instanceof Assessment && o2 instanceof Assessment) {
      return compareAssessment((Assessment) o1, (Assessment) o2);
    } else {
      return 0;
    }
  }

  public int compareAssessment(Assessment assgn1, Assessment assgn2) {
    String value1 = blankIfNull(getValue(assgn1));
    String value2 = blankIfNull(getValue(assgn2));
    return value1.compareTo(value2);
  }

  public String blankIfNull(String st) {
    if (st == null) {
      return "";
    } else {
      return st;
    }
  }
}
