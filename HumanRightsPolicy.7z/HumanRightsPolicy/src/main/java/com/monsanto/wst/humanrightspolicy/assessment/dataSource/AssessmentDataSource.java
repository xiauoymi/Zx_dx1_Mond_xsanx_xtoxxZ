/*
 AssessmentDataSource was created on Oct 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment.dataSource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.action.datasource.ActionDefaultComparator;
import com.monsanto.wst.humanrightspolicy.assessment.service.AssessmentService;
import com.monsanto.wst.humanrightspolicy.controller.XmlDataPaginationController;
import com.monsanto.wst.humanrightspolicy.datasource.ComparatorMap;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.ParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.UCCHelperParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.textutil.TextUtil;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;

/**
 * Filename:    $RCSfile: AssessmentDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-12-04 16:50:10 $
 *
 * @author RRMALL
 * @version $Revision: 1.2 $
 */
public class AssessmentDataSource implements XmlDataSource {
    private final AssessmentService assessmentService;
    private final ParameterCollection params;

    protected static final ComparatorMap<XmlObject> comparatorMap;

    private static String NAME_SORT_KEY = "name";
    private static String DUE_DATE_SORT_KEY = "dueDate";
    private static String STATUS_SORT_KEY = "status";

    static {
        comparatorMap = new ComparatorMap<XmlObject>(new ActionDefaultComparator());
        comparatorMap.addComparator(NAME_SORT_KEY, new AssessmentNameComparator());
        comparatorMap.addComparator(DUE_DATE_SORT_KEY, new AssessmentDueDateComparator());
        comparatorMap.addComparator(STATUS_SORT_KEY, new AssessmentStatusComparator());
    }

    public AssessmentDataSource(ParameterCollection params, AssessmentService assessmentService) {
        this.params = params;
        this.assessmentService = assessmentService;
    }

    public AssessmentDataSource(ParameterCollection params) {
        this(params, InitService.initAssessmentService());
    }

    public AssessmentDataSource(UCCHelper helper, AssessmentService assessmentService) {
        this(new UCCHelperParameterCollection(helper), assessmentService);
    }

    public AssessmentDataSource(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initAssessmentService());
    }

    public List<? extends XmlObject> getData() throws IOException {
        return getMyAssessments();
    }

    public Comparator<XmlObject> getComparator(String sortKey) {
        return comparatorMap.getComparator(sortKey);
    }

    public boolean isSorted() {
        return false;
    }

    public boolean isFiltered() {
        return false;
    }

    public int getTotalRecords() throws IOException {
        return UNKNOWN_RECORD_COUNT;
    }

    public List<? extends XmlObject> getMyAssessments() {
        return this.assessmentService.lookupAllAssessments();
    }

    public String getFilterValue() throws IOException {
        return StringUtils.defaultString(
                TextUtil.decodeUsingUTF8(params.get(XmlDataPaginationController.FILTER_VALUE)));
    }
}