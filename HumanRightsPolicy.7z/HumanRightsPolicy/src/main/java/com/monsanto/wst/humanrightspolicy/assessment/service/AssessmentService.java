/*
 AssessmentService was created on Oct 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment.service;

import com.monsanto.wst.humanrightspolicy.assessment.Assessment;
import com.monsanto.wst.humanrightspolicy.model.Status;
import com.monsanto.wst.humanrightspolicy.model.Region;
import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.StateProvince;

import java.util.List;
import java.util.Date;

/**
 * Filename:    $RCSfile: AssessmentService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-17 21:07:17 $
 *
 * @author RRMALL
 * @version $Revision: 1.1 $
 */
public interface AssessmentService {
  List<Assessment> lookupAllAssessments();

  Assessment lookupAssessmentById(Long id);

  List<Status> lookupAllStatusTypes();

  Assessment addAssessment(Long id, String name, Date dueDate, Status status, String description, Region region, Country country,
                     StateProvince stateProvince);
}