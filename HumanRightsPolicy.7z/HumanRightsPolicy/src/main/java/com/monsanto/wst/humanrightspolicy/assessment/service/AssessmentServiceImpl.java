/*
 AssessmentServiceImpl was created on Oct 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment.service;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.assessment.Assessment;
import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.Region;
import com.monsanto.wst.humanrightspolicy.model.StateProvince;
import com.monsanto.wst.humanrightspolicy.model.Status;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: AssessmentServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-12-11 22:17:44 $
 *
 * @author RRMALL
 * @version $Revision: 1.2 $
 */
public class AssessmentServiceImpl implements AssessmentService {
    private GenericDAO<Assessment, Long> assessmentDAO;
    private GenericDAO<Status, Long> statusDAO;

    public AssessmentServiceImpl(GenericDAO<Assessment, Long> assessmentDAO, GenericDAO<Status, Long> statusDAO) {
        this.assessmentDAO = assessmentDAO;
        this.statusDAO = statusDAO;
    }

    public List<Assessment> lookupAllAssessments() {
        return this.assessmentDAO.findAll();
    }

    public Assessment lookupAssessmentById(Long id) {
        return this.assessmentDAO.findByPrimaryKey(id);
    }

    public List<Status> lookupAllStatusTypes() {
        return this.statusDAO.findAll();
    }

    public Assessment addAssessment(Long id, String name, Date dueDate, Status status, String description, Region region,
                                    Country country, StateProvince stateProvince) {
        Assessment assmt = new Assessment(id, name, dueDate, status, region, country, stateProvince, description);
        return this.assessmentDAO.save(assmt);
    }
}