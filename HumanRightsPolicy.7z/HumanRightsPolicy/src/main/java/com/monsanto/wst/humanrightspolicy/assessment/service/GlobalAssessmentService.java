/*
 AssessmentService was created on Sep 3, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment.service;

import com.monsanto.wst.humanrightspolicy.assessment.GlobalAssessment;
import com.monsanto.wst.humanrightspolicy.assessment.Policy;
import com.monsanto.wst.humanrightspolicy.assessment.Risk;
import com.monsanto.wst.humanrightspolicy.model.Country;

import java.util.List;

/**
 * Filename:    $RCSfile: GlobalAssessmentService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:24 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public interface GlobalAssessmentService {
  List<Policy> lookupAllPolies();

  GlobalAssessment saveGlobalAssessmentForCountry(Country country, Policy policy, Risk risk
  );

  GlobalAssessment updateGlobalAssessmentForCountry(Long id, Country country, Policy policy, Risk risk);

}