/*
 AssessmentServiceImpl was created on Sep 3, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assessment.service;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.assessment.GlobalAssessment;
import com.monsanto.wst.humanrightspolicy.assessment.Policy;
import com.monsanto.wst.humanrightspolicy.assessment.Risk;
import com.monsanto.wst.humanrightspolicy.model.Country;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * Filename:    $RCSfile: GlobalAssessmentServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-12-11 22:17:44 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class GlobalAssessmentServiceImpl implements GlobalAssessmentService {
    private GenericDAO<Policy, Long> policyDao;
    private GenericDAO<GlobalAssessment, Long> globalAsmtDao;

    public GlobalAssessmentServiceImpl(GenericDAO<Policy, Long> policyDao,
                                       GenericDAO<GlobalAssessment, Long> globalAsmtDao) {
        this.policyDao = policyDao;
        this.globalAsmtDao = globalAsmtDao;
    }

    public List<Policy> lookupAllPolies() {
        SortedSet<Policy> set = new TreeSet<Policy>();
        set.addAll(policyDao.findAll());
        List<Policy> policies = new ArrayList<Policy>();
        for (Policy p : set) {
            policies.add(p);
        }
        return policies;
    }

    public GlobalAssessment saveGlobalAssessmentForCountry(Country country, Policy policy, Risk risk) {
        GlobalAssessment asmt = new GlobalAssessment(null, country, policy, risk);
        return saveAssessment(asmt);
    }

    public GlobalAssessment updateGlobalAssessmentForCountry(Long id, Country country, Policy policy, Risk risk) {
        GlobalAssessment asmt = globalAsmtDao.findByPrimaryKey(id);
        asmt.setCountry(country);
        asmt.setPolicy(policy);
        asmt.setRisk(risk);
        return saveAssessment(asmt);
    }

    private GlobalAssessment saveAssessment(GlobalAssessment asmt) {
        globalAsmtDao.save(asmt);
        return asmt;
    }
}