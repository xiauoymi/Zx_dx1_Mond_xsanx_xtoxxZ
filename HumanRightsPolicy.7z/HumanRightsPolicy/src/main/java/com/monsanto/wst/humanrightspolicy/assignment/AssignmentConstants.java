/*
 AssignmentConstants was created on Sep 29, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.assignment;

/**
 * Filename:    $RCSfile: AssignmentConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-07 20:16:07 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class AssignmentConstants {
  public static final String USER_ID = "userId";
  public static final String USER_NAME = "userName";
  public static final String ASSIGNMENT = "assignment";
  public static final String ASSIGNMENT_ID = "assignmentId";

}