/*
 BPContactRelationshipConstants was created on Feb 19, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.bpContactRelationship;

/**
 * @author sspati1
 */
public class BPContactRelationshipConstants {
///CLOVER:OFF
  private BPContactRelationshipConstants() {
  }
///CLOVER:ON

  public static final String METHOD_END_BP_CONTACT_REL = "endBPContactRelationship";
}