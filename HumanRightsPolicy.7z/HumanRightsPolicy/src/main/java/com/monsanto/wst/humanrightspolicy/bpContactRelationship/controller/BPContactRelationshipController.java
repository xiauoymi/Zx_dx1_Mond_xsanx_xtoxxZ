/*
 BPContactRelationshipController was created on Feb 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.bpContactRelationship.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.LookupBPDAO;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.contact.dao.LookupContactDAO;
import com.monsanto.wst.humanrightspolicy.controller.HrpController;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.ContactInfo;
import com.monsanto.wst.humanrightspolicy.model.Location;
import com.monsanto.wst.humanrightspolicy.model.LocationContactRelationship;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author sspati1
 */
public class BPContactRelationshipController extends HrpController {
  private final LookupContactDAO contactDao;
  private final LookupBPDAO bpDao;

  public BPContactRelationshipController() {
    this(InitService.initLookupContactDao(), InitService.initLookupBPDao());
  }

  public BPContactRelationshipController(LookupContactDAO contactDao, LookupBPDAO bpDao) {
    this.contactDao = contactDao;
    this.bpDao = bpDao;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
//    helper.forward(HRPMainConstants.HRP_HOME_JSP);
  }

  public void endBPContactRelationship(UCCHelper helper) throws IOException {
    String menu = helper.getRequestParameterValue(HRPMainConstants.MENU);
    String bpId = helper.getRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID);
    BusinessPartner bp = this.bpDao.lookupBPById(bpId);
    List<String> contactIds = getSelectedContactIds(bp);
    for (String contactId : contactIds) {
      ContactInfo contact = this.contactDao.lookupContactById(contactId);
      if (!contact.getIsSap()) {
        endContactRelationship(contact, helper);
      }
    }
    helper.forward("businessPartner?method=lookupBP&businessPartnerId=" + bpId + "&menu=" + menu);
  }

  private void endContactRelationship(ContactInfo contact, UCCHelper helper) {
    List<LocationContactRelationship> locConRels = contact.getActiveLocationContactRelationships();
    for (LocationContactRelationship locConRel : locConRels) {
      if (locConRel.getIsContactPrimary()) {
        setSapContactAsPrimaryContact(locConRel.getLocation(), helper);
      }
      locConRel.getLocation().endLocationContactRelationship(contact.getContactId(), helper.getAuthenticatedUserID());
    }
  }

  private void setSapContactAsPrimaryContact(Location location, UCCHelper helper) {
    List<LocationContactRelationship> activeContactsForLocation = location.getActiveLocationContactRelationships();
    for (LocationContactRelationship locCon : activeContactsForLocation) {
      ContactInfo contact = locCon.getContact();
      if (contact.getIsSap()) {
        location.setPrimaryContact(contact, helper.getAuthenticatedUserID());
        return;
      }
    }
  }

  private List<String> getSelectedContactIds(BusinessPartner bp)  {
    if (isAllSelected()) {
      List<ContactInfo> contacts = bp.getActiveContacts();
      List<String> selectedIds = new ArrayList<String>();
      for (ContactInfo contact : contacts) {
        selectedIds.add(contact.getContactId());
      }
      List<String> idsToExclude = getIdsToExclude();
      for (String id : idsToExclude) {
        selectedIds.remove(id);
      }
      return selectedIds;
    } else {
      return getSelectedIds();
    }
  }

}