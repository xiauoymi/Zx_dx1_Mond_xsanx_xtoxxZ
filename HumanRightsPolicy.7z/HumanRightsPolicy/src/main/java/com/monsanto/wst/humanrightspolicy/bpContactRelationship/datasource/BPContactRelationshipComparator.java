/*
 BPContactComparator was created on May 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.bpContactRelationship.datasource;

import com.monsanto.wst.humanrightspolicy.model.ContactRelationship;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: BPContactRelationshipComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-05-15 15:26:56 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public abstract class BPContactRelationshipComparator implements Comparator<XmlObject> {
  protected abstract String getValue(ContactRelationship bpConRel);

  public int compare(XmlObject o1, XmlObject o2) {
    if (o1 instanceof ContactRelationship && o2 instanceof ContactRelationship) {
      return compareRels((ContactRelationship ) o1, (ContactRelationship ) o2);
    } else {
      return 0;
    }
  }

  public int compareRels(ContactRelationship bpConRel1, ContactRelationship bpConRel2) {
    String value1 = blankIfNull(getValue(bpConRel1));
    String value2 = blankIfNull(getValue(bpConRel2));
    return value1.compareTo(value2);
  }

  public String blankIfNull(String st) {
    if (st == null) {
      return "";
    } else {
      return st;
    }
  }
}