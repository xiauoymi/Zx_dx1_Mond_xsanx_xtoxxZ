/*
 bpContactRelationshipDataSource was created on May 9, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.bpContactRelationship.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.datasource.ComparatorMap;
import com.monsanto.wst.humanrightspolicy.datasource.DataSource;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Filename:    $RCSfile: BPContactRelationshipDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1
 * $    	 On:	$Date: 2008-12-04 16:50:10 $
 *
 * @author rrmall
 * @version $Revision: 1.11 $
 */
public class BPContactRelationshipDataSource implements XmlDataSource {
    private final ParameterCollection params;
    private final LookupBPService bpService;

    public static final String NAME_SORT_KEY = "name";
    public static final String REGION_SORT_KEY = "region";
    public static final String COUNTRY_SORT_KEY = "country";
    public static final String STATE_SORT_KEY = "state";
    private static final ComparatorMap<XmlObject> comparatorMap;

    static {
        comparatorMap = new ComparatorMap<XmlObject>(new BPContactRelationshipDefaultComparator());
        comparatorMap.addComparator(NAME_SORT_KEY, new BPContactRelationshipNameComparator());
        comparatorMap.addComparator(REGION_SORT_KEY, new BPContactRelationshipRegionComparator());
        comparatorMap.addComparator(COUNTRY_SORT_KEY, new BPContactRelationshipCountryComparator());
        comparatorMap.addComparator(STATE_SORT_KEY, new BPContactRelationshipStateComparator());
    }

    public BPContactRelationshipDataSource(ParameterCollection params, LookupBPService bpService) {
        this.params = params;
        this.bpService = bpService;
    }

    public BPContactRelationshipDataSource(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initSearchBPService());
    }

    public BPContactRelationshipDataSource(UCCHelper helper, LookupBPService bpService) {
        this(new UCCHelperParameterCollection(helper), bpService);
    }

    public BPContactRelationshipDataSource(ParameterCollection params) {
        this(params, InitService.initSearchBPService());
    }

    public List<? extends XmlObject> getData() throws IOException {
        String bpId = params.get(BusinessPartnerConstants.BUSINESS_PARTNER_ID);
        BusinessPartner bp = bpService.lookupBPById(bpId);
        ContactInfo primaryContact = bp.getPrimaryContact();
        List<ContactInfo> contactList = bp.getActiveContacts();
        List<ContactRelationship> contactRelationshipList = new ArrayList<ContactRelationship>();
        for (ContactInfo contact : contactList) {
            ContactRelationship contactRelationship = getContactRelationshipInformation(bpId, primaryContact, contact);
            contactRelationshipList.add(contactRelationship);
        }
        return contactRelationshipList;
    }

    private ContactRelationship getContactRelationshipInformation(String bpId, ContactInfo primaryContact,
                                                                  ContactInfo contact) {
        String contactId = contact.getContactId();
        boolean isPrimary = contact.equals(primaryContact);
        LocationContactRelationship primaryRel = contact.getPrimaryRelationship();
        Address address = primaryRel.getLocation().getAddress();
        String locationId = primaryRel.getLocation().getLocationId();
        HrpUrlBuilder urlBuilder = new HrpUrlBuilder("bp");
        String removeUrl = urlBuilder.getEndLocationToContactRelationship(contactId, locationId);
        String viewUrl = urlBuilder.getViewContactUrl(contactId);
        String updatePrimaryFlagUrl = urlBuilder.getSetPrimaryContactForBpUrl(contactId, bpId);
        return new ContactRelationshipImpl(contactId, contact.getContactName(), isPrimary, contact.getIsSap(), viewUrl,
                removeUrl, updatePrimaryFlagUrl,
                address.getRegionModel().getValue(), address.getStateModel().getValue(), address.getCountryModel().getValue());
    }

    public Comparator<XmlObject> getComparator(String sortKey) {
        return comparatorMap.getComparator(sortKey);
    }

    public boolean isSorted() {
        return false;
    }

    public boolean isFiltered() {
        return false;
    }

    public int getTotalRecords() {
        return DataSource.UNKNOWN_RECORD_COUNT;
    }
}