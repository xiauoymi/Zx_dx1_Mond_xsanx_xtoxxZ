/*
 BPContactRelationshipDefaultComparator was created on May 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.bpContactRelationship.datasource;

import com.monsanto.wst.humanrightspolicy.model.ContactRelationship;

/**
 * Filename:    $RCSfile: BPContactRelationshipDefaultComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-05-15 15:26:56 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class BPContactRelationshipDefaultComparator extends BPContactRelationshipComparator {
  protected String getValue(ContactRelationship bpConRel) {
    return bpConRel.getId();
  }
}