package com.monsanto.wst.humanrightspolicy.businessPartner;

import com.monsanto.wst.humanrightspolicy.model.Address;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.textutil.TextUtil;
/*
 BusinessPartnerXmlBuilder was created on Jun 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class BusinessPartnerXmlBuilder {
    public static String toDetailedXml(BusinessPartner businessPartner) {
        return null;
    }

  public static String toXml(BusinessPartner bp) {
    String addRemoveUrlBase =
        "/humanrightspolicy/servlet/searchBusinessPartner?method=setHrpFlagInBP&businessPartnerId=" + bp.getPartnerId() +
            "&hrpFlag=";
    String addUrl = addRemoveUrlBase + 'Y';
    String removeUrl = addRemoveUrlBase + 'N';
    String viewUrl = new HrpUrlBuilder("").getViewBpUrl(bp.getPartnerId());
    StringBuffer xml = new StringBuffer("<bp>");
    xml.append("<id>").append(TextUtil.escapeXml(bp.getPartnerId())).append("</id>");
    xml.append("<sapId>").append(TextUtil.escapeXml(bp.getFormattedSapId())).append("</sapId>");
    xml.append("<bpName>").append(TextUtil.escapeXml(bp.getFullName())).append("</bpName>");
    xml.append("<hrpTypesAsString>").append(TextUtil.escapeXml(bp.getHrpTypesAsCommaSeparatedString())).append("</hrpTypesAsString>");
    Address bpAddress = bp.getAddress();
    xml.append("<country>").append(TextUtil.escapeXml(getCountryName(bpAddress))).append("</country>");
    xml.append("<state>").append(TextUtil.escapeXml(getStateName(bpAddress))).append("</state>");
    xml.append("<region>").append(TextUtil.escapeXml(getRegionName(bpAddress))).append("</region>");
    xml.append("<hrpFlag>").append(TextUtil.escapeXml(bp.getHrpFlag())).append("</hrpFlag>");
    xml.append("<addUrl>").append(TextUtil.escapeXml(addUrl)).append("</addUrl>");
    xml.append("<removeUrl>").append(TextUtil.escapeXml(removeUrl)).append("</removeUrl>");
    xml.append("<viewUrl>").append(TextUtil.escapeXml(viewUrl)).append("</viewUrl>");
    xml.append("</bp>");
    return xml.toString();
  }

  private static String getRegionName(Address addr) {
    if (addr == null || addr.getRegionModel() == null) {
      return "";
    } else {
      return addr.getRegionModel().getValue();
    }
  }

  private static String getCountryName(Address addr) {
    if (addr == null || addr.getCountryModel() == null) {
      return "";
    } else {
      return addr.getCountryModel().getValue();
    }
  }

  private static String getStateName(Address addr) {
    if (addr == null || addr.getStateModel() == null) {
      return "";
    } else {
      return addr.getStateModel().getValue();
    }
  }

}
