package com.monsanto.wst.humanrightspolicy.businessPartner.constants;

public class BusinessPartnerConstants {

  ///CLOVER:OFF
  private BusinessPartnerConstants () {
  }
///CLOVER:ON

  public static final String BUSINESS_PARTNER_JSP = "/WEB-INF/jsp/businessPartner/businessPartner.jsp";
  public static final String SEARCH_BUSINESS_PARTNER_JSP = "/WEB-INF/jsp/businessPartner/searchBusinessPartner.jsp";

  public static final String METHOD_LOOKUP_BP = "lookupBP";
  public static final String METHOD_BP_SAVE = "saveBP";

  public static final String BUSINESS_PARTNER_ID = "businessPartnerId";
  public static final String REQUESTED_SAP_ID = "requestedSapId";
  public static final String SAP_ID = "sapId";
  public static final String BUSINESS_PARTNER_NAME = "businessPartnerName";
  public static final String BUSINESS_PARTNER = "businessPartner";

  public static final String BP_HRP_TYPE = "bpHrpType";
  public static final String BP_PRODUCT = "product";
  public static final String BP_REL_HRP_TYPE = "bpRelHrpType";
  public static final String HRP_FLAG = "hrpFlag";
  public static final String WEBSITE_URL = "websiteUrl";

  public static final String SEARCH_CRITERIA = "bpSearchCriteria";
  public static final String LOC_CON_REL_TYPE_LIST = "locConRelTypes";
  public static final String LOC_CON_REL_TYPE_ID = "locConRelTypeId";

  public static final String COMM_TYPE_LIST = "commTypeList";
  public static final String HRP_TYPES = "hrpTypes";
  public static final String HRP_TYPE = "hrpType";
  public static final String COUNT_OF_LOCATIONS = "countOfLocationsForBP";
  public static final String COUNT_OF_CONTACTS = "countOfContactsForBP";
  public static final String COUNT_OF_COMMUNICATIONS = "countOfCommunicationsForBP";
}
