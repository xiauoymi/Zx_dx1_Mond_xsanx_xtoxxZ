package com.monsanto.wst.humanrightspolicy.businessPartner.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.businessPartner.services.BusinessPartnerService;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.controller.HrpController;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.humanrightspolicy.utils.MsgAndErrorUtil;
import com.monsanto.wst.humanrightspolicy.utils.NumberUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class BusinessPartnerController extends HrpController {
    private static final Log logger = LogFactory.getLog(BusinessPartnerController.class);
    private final BusinessPartnerService bpService;
    private final LookupBPService lookupBPService;
    private final LocationService locationService;
    private final CommunicationService commService;
    private final GenericDAO<ContactType, Long> contactTypeDAO;

    public BusinessPartnerController() {
        this(InitService.initBusinessPartnerService(), InitService.initSearchBPService(),
                InitService.initLocationService(),
                InitService.initCommunicationService(),
                InitService.initContactTypeDAO());
    }

    public BusinessPartnerController(BusinessPartnerService businessPartnerService, LookupBPService lookupBPService,
                                     LocationService locationService,
                                     CommunicationService communicationService, GenericDAO<ContactType, Long> contactTypeLongMockDAO) {
        this.bpService = businessPartnerService;
        this.lookupBPService = lookupBPService;
        this.locationService = locationService;
        this.commService = communicationService;
        this.contactTypeDAO = contactTypeLongMockDAO;
    }

    /**
     * This method is called to set the initial lists (data) for a new Business Partner profile page
     *
     * @param helper - UCCHelper
     * @throws IOException IOException
     */
    protected void notSpecified(UCCHelper helper) throws IOException {
//    if (getLoginUserFromSession(helper).gethasAccessToAdministration()) {
        setBusinessPartnerInResponse(createNewBusinessPartnerInstance(), helper);
        try {
            //todo modify this method based on new requirements
//        setReferenceDataInResponse(helper);
            helper.forward(BusinessPartnerConstants.BUSINESS_PARTNER_JSP);
        } catch (Exception e) {
            MsgAndErrorUtil.addExceptionMsgToResponse(e, helper);
            helper.forward(HRPMainConstants.HRP_ERROR_JSP);
        }
//    } else {
//      helper.forward(HRPMainConstants.HRP_NOT_AUTHORIZED);
//    }
    }

    private CommStatus getOpenStatusId() {
        //todo move to DAO for ComStatus
        List<CommStatus> statuses = this.commService.lookupCommunicationStatuses();
        for (CommStatus status : statuses) {
            if (status.getStatus().equalsIgnoreCase(CommunicationConstants.OPEN_STATUS)) {
                return status;
            }
        }
        return null;
    }

    /**
     * This method lookz up a business partner
     *
     * @param helper - UCCHelper - helper
     * @throws IOException - IOException
     */
    public void lookupBP(UCCHelper helper) throws IOException {
        String businessPartnerId = helper.getRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID);
        BusinessPartner businessPartner = lookupBusinessPartner(businessPartnerId);
//    countOfRelatedEntitiesForBP(helper, businessPartner);
        setBusinessPartnerInResponse(businessPartner, helper);
        setCommReferenceDataInHelper(helper);
        helper.forward(BusinessPartnerConstants.BUSINESS_PARTNER_JSP);
    }

    private void setCommReferenceDataInHelper(UCCHelper helper) {
        helper.setRequestAttributeValue(CommunicationConstants.COMM_TYPE_LIST, commService.lookupCommunicationTypes());
        helper.setRequestAttributeValue(BusinessPartnerConstants.LOC_CON_REL_TYPE_LIST,
                contactTypeDAO.findAll());
        helper.setRequestAttributeValue(LocationsConstants.BP_LOC_REL_TYPE_LIST, locationService.lookupBPLocRelTypes());
    }

    private void setBusinessPartnerInResponse(BusinessPartner businessPartner, UCCHelper helper) {
        helper.setRequestAttributeValue(BusinessPartnerConstants.BUSINESS_PARTNER, businessPartner);
    }

    private BusinessPartner lookupBusinessPartner(String bpId) {
        return this.lookupBPService.lookupBPById(bpId);
    }

    private BusinessPartner createNewBusinessPartnerInstance() {
        return new BusinessPartnerImpl();
    }

    public void addCommunication(UCCHelper helper) throws IOException {
        String name = helper.getRequestParameterValue(CommunicationConstants.COMM_NAME);
        String notes = helper.getRequestParameterValue(CommunicationConstants.COMM_NOTES);
        Date fromDate = getDate(helper.getRequestParameterValue(CommunicationConstants.COMM_FROM_PERIOD));
        Date toDate = getDate(helper.getRequestParameterValue(CommunicationConstants.COMM_TO_PERIOD));
        Date dueDate = getDate(helper.getRequestParameterValue(CommunicationConstants.COMM_DUE_PERIOD));
        String urlTitle = helper.getRequestParameterValue(CommunicationConstants.COMM_URL_TITLE);
        String url = helper.getRequestParameterValue(CommunicationConstants.COMM_URL);
        String active = "Y";
        String bpId = helper.getRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID);
        CommType commType = new CommType(helper.getRequestParameterValue(CommunicationConstants.COMM_TYPE_ID), null
        );
        CommStatus status = getOpenStatusId();
        ContactType peopleType = new ContactType(
                helper.getRequestParameterValue(CommunicationConstants.COMM_PEOPLE_TYPE_ID), null);
        Long locTypeId = NumberUtil.stringToLong(helper.getRequestParameterValue(CommunicationConstants.COMM_LOC_TYPE_ID));
        LocationType locType = new LocationType(locTypeId, null);

        Communication newComm = this.commService
                .addCommunication(name, notes, fromDate, toDate, dueDate, active, urlTitle, url,
                        commType, status, peopleType, locType, null, null);

        BusinessPartner bp = this.lookupBPService.lookupBPById(bpId);
        ContactInfo primaryContact = bp.getPrimaryContact();
        newComm.addRecipient(primaryContact.getContactId());
        helper.setRequestAttributeValue(HRPMainConstants.ACTIVE_TAB_INDEX, "2");
        helper.forward("businessPartner?method=lookupBP&businessPartnerId=" + bpId + "&menu=bp");
    }

    private void countOfRelatedEntitiesForBP(UCCHelper helper, BusinessPartner businessPartner) throws IOException {
        helper.setRequestAttributeValue(BusinessPartnerConstants.COUNT_OF_LOCATIONS,
                Integer.valueOf(businessPartner.getActiveBPLocationRelationships().size()).toString());
        helper.setRequestAttributeValue(BusinessPartnerConstants.COUNT_OF_CONTACTS,
                Integer.valueOf(businessPartner.getActiveContacts().size()).toString());
        helper.setRequestAttributeValue(BusinessPartnerConstants.COUNT_OF_COMMUNICATIONS,
                Integer.valueOf(businessPartner.getCommunications().size()).toString());
    }

    private Date getDate(String dateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            logger.error("Unable to parse communication period");
        }
        return null;
    }

}

