/*
 SearchBusinessPartnerController was created on Jul 31, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.services.BusinessPartnerService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.controller.HrpController;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.io.IOException;

/**
 * @author sspati1
 */
public class SearchBusinessPartnerController extends HrpController {
  private final BusinessPartnerService bpService;

  public SearchBusinessPartnerController() {
    this(InitService.initBusinessPartnerService());
  }

  public SearchBusinessPartnerController(BusinessPartnerService bpService) {
    this.bpService = bpService;
  }

  /**
   * this method is called to set up the initial data for BP search based on states you have access to
   */
  protected void notSpecified(UCCHelper helper) throws IOException {
    setupSearch(helper, "My");
    helper.forward(BusinessPartnerConstants.SEARCH_BUSINESS_PARTNER_JSP);
  }

  /**
   * this method is called to set up the data to search all HRP BPs
   *
   * @param helper - UCCHelper
   *
   * @exception IOException - IOException
   */
  public void allBPs(UCCHelper helper) throws IOException {
    setupSearch(helper, "All");
    helper.setRequestAttributeValue(BusinessPartnerConstants.HRP_TYPES, bpService.lookupAllHrpTypes());
    helper.setRequestAttributeValue(HRPMainConstants.DONT_SEARCH, "true");
    helper.forward(BusinessPartnerConstants.SEARCH_BUSINESS_PARTNER_JSP);
  }

  private void setupSearchCriteria(UCCHelper helper)  {
    BusinessPartner bp = getBPForSearch();
    helper.setSessionParameter(BusinessPartnerConstants.SEARCH_CRITERIA, bp);
  }

  private void setupSearch(UCCHelper helper, String scope)  {
    setupSearchCriteria(helper);
    helper.setRequestAttributeValue(HRPMainConstants.SCOPE, scope);
  }

  private BusinessPartner getBPForSearch() {
    return new BusinessPartnerImpl(null, null, null, null, null, null, "Y", null, null, null);
  }

  protected String getHrpFlag(UCCHelper helper) throws IOException {
    return nullIfBlank(helper.getRequestParameterValue(BusinessPartnerConstants.HRP_FLAG));
  }

  private String nullIfBlank(String st) {
    if (st == null || st.length() == 0) {
      return null;
    } else {
      return st;
    }
  }
}