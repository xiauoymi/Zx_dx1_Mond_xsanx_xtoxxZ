package com.monsanto.wst.humanrightspolicy.businessPartner.dao;

import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.BusinessPartnerXmlBuilder;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.datasource.Filterable;
import com.monsanto.wst.humanrightspolicy.geodata.GeoDataFactory;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.textutil.TextUtil;

import java.util.Date;
import java.util.List;
/*
 BusinessPartnerDeferredImpl was created on May 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class BusinessPartnerDeferredImpl implements BusinessPartner, Filterable {
  private final LookupBPService bpService;
  private BusinessPartnerImpl instance = null;

  private final String bpId;
  private final String sapId;
  private final String name;
  private final String hrpFlag;
  private final String hrpTypes;

  private final String stateId;

  private Region region;
  private Country country;
  private StateProvince state;
  private final GeoDataFactory geoDataFactory;

  public BusinessPartnerDeferredImpl(GeoDataFactory geoDataFactory, String bpId, String sapId, String name,
                                     String stateId, String hrpFlag, String hrpTypes) {
    this(geoDataFactory, new DeferredLookupBPService(), bpId, sapId, name, stateId, hrpFlag, hrpTypes);
  }

  public BusinessPartnerDeferredImpl(GeoDataFactory geoDataFactory, LookupBPService bpService, String bpId,
                                     String sapId, String name, String stateId, String hrpFlag, String hrpTypes) {
    this.geoDataFactory = geoDataFactory;
    this.bpService = bpService;
    this.bpId = bpId;
    this.sapId = sapId;
    this.name = name;
    this.stateId = stateId;
    this.hrpFlag = hrpFlag;
    this.hrpTypes = hrpTypes;
    this.state = null;
    this.country = null;
    this.region = null;
  }

  protected synchronized BusinessPartnerImpl getInstance() {
    if (instance == null) {
      instance = queryInstance();
    }

    return instance;
  }

  private BusinessPartnerImpl queryInstance() {
    return (BusinessPartnerImpl) bpService.lookupBPById(bpId);
  }

  public String getPartnerId() {
    return bpId;
  }

  public String getSapId() {
    return sapId;
  }

    public String getFormattedSapId() {
        return getInstance().getFormattedSapId();
    }

    public String getFullName() {
    int pos = name.indexOf('/');
    if (pos != -1) {
      return name.substring(0, pos) + "<br />" + name.substring(pos + 1);
    }

    return name;
  }

  public String getHrpFlag() {
    return hrpFlag;
  }

  public String getHrpTypesAsCommaSeparatedString() {
    return this.hrpTypes;
  }

  public String getHrpTypes() {
    return this.hrpTypes;
  }

  public Address getAddress() {
    return new DeferredAddress();
  }

  public String toXml() {
    return BusinessPartnerXmlBuilder.toXml(this);
  }

  public String getEntityName() {
    return getInstance().getEntityName();
  }

  public void addLocationRelationship(Location loc, boolean isPrimary, LocationType bpLocType) {
    getInstance().addLocationRelationship(loc, isPrimary, bpLocType);
  }

  public void setPrimaryLocation(Location newPrimaryLocation) {
    getInstance().setPrimaryLocation(newPrimaryLocation);
  }

  public List<Location> getLocations() {
    return getInstance().getLocations();
  }

  public BPLocationRelationship getPrimaryRelationship() {
    return getInstance().getPrimaryRelationship();
  }

  public List<ContactInfo> getActiveContacts() {
    return getInstance().getActiveContacts();
  }

  public ContactInfo getPrimaryContact() {
    return getInstance().getPrimaryContact();
  }

  public BPLocationRelationshipDAO getBPLocationRelationshipDAO() {
    return getInstance().getBPLocationRelationshipDAO();
  }

  public Date getAddBPDate() {
    return getInstance().getAddBPDate();
  }

  public String getFormattedValue(String value) {
    return getInstance().getFormattedValue(value);
  }

  public String formatSAPId(String id) {
    return getInstance().formatSAPId(id);
  }

  public String getLegacyId() {
    return getInstance().getLegacyId();
  }

  public void setPartnerId(String partnerId) {
    getInstance().setPartnerId(partnerId);
  }

  public String getWebsiteUrl() {
    return getInstance().getWebsiteUrl();
  }

  public List<BPLocationRelationship> getActiveBPLocationRelationships() {
    return getInstance().getActiveBPLocationRelationships();
  }

  public String getAliasName() {
    return getInstance().getAliasName();
  }

  public String getActive() {
    return getInstance().getActive();
  }

  public String getIsComplete() {
    return getInstance().getIsComplete();
  }

  public String getNotes() {
    return getInstance().getNotes();
  }

  public String returnNullIfEmpty(String value) {
    return getInstance().returnNullIfEmpty(value);
  }

  public void setHrpFlag(String hrpFlag) {
    getInstance().setHrpFlag(hrpFlag);
  }

  public void setIsComplete(String isComplete) {
    getInstance().setIsComplete(isComplete);
  }

  public void setActive(String isActive) {
    getInstance().setActive(isActive);
  }

  public int hashCode() {
    return getInstance().hashCode();
  }

  public boolean equals(Object obj) {
    return getInstance().equals(obj);
  }

  public String toString() {
    return getInstance().toString();
  }

  public void endBpLocRelationship(Location location) {
    getInstance().endBpLocRelationship(location);
  }

  public List<Communication> getCommunications() {
    return getInstance().getCommunications();
  }

  public boolean filter(String filterValue) {
    boolean idMatchesFilter = TextUtil.contains(getFormattedSapId(), formatSAPId(filterValue));
    boolean nameMatchesFilter = TextUtil.contains(getFullName(), filterValue);

    return idMatchesFilter || nameMatchesFilter;
  }

    public String toDetailedXml() {
        return getInstance().toDetailedXml();
    }

//  public boolean filter(String filterValue) {
//    return getInstance().filter(filterValue);
//  }

  private class DeferredAddress extends Address {
    public synchronized Region getRegionModel() {
      if (region == null && stateId != null) {
        region = getCountryModel().getRegion();
      }

      return region;
    }

    public synchronized Country getCountryModel() {
      if (country == null && stateId != null) {
        country = getStateModel().getCountry();
      }

      return country;
    }

    public synchronized StateProvince getStateModel() {
      if (state == null && stateId != null) {
        state = geoDataFactory.getStateById(stateId);
      }

      return state;
    }

    public String toString() {
      return getInstance().getAddress().toString();
    }

    public void setZipcode(String zipcode) {
      getInstance().getAddress().setZipcode(zipcode);
    }

    public void setCity(String city) {
      getInstance().getAddress().setCity(city);
    }

    public void setStreetAddress2(String streetAddress2) {
      getInstance().getAddress().setStreetAddress2(streetAddress2);
    }

    public void setStreetAddress1(String streetAddress1) {
      getInstance().getAddress().setStreetAddress1(streetAddress1);
    }

    public void setCountryModel(Country countryModel) {
      getInstance().getAddress().setCountryModel(countryModel);
    }

    public void setStateModel(StateProvince stateModel) {
      getInstance().getAddress().setStateModel(stateModel);
    }

    public String getZipcode() {
      return getInstance().getAddress().getZipcode();
    }

    public void setRegionModel(Region regionModel) {
      getInstance().getAddress().setRegionModel(regionModel);
    }

    public String getCity() {
      return getInstance().getAddress().getCity();
    }

    public String getAddressId() {
      return getInstance().getAddress().getAddressId();
    }

    public void setAddressId(String addressId) {
      getInstance().getAddress().setAddressId(addressId);
    }

    public String getStreetAddress2() {
      return getInstance().getAddress().getStreetAddress2();
    }

    public String getStreetAddress1() {
      return getInstance().getAddress().getStreetAddress1();
    }
  }

  private static class DeferredLookupBPService implements LookupBPService {
    private LookupBPService instance = null;

    private synchronized LookupBPService getInstance() {
      if (instance == null) {
        instance = InitService.initSearchBPService();
      }
      return instance;
    }

    public BusinessPartnerResult lookupBPByCriteria(BusinessPartner bpSearchCriteria, boolean myBPScope, LoginUser user,
                                                    String sortKey, String filterValue, Integer startRecord,
                                                    Integer endRecord) {
      return getInstance().lookupBPByCriteria(bpSearchCriteria, myBPScope, user, sortKey, filterValue, startRecord, endRecord);
    }

    public BusinessPartner lookupBPById(String bpId) {
      return getInstance().lookupBPById(bpId);
    }
  }
}
