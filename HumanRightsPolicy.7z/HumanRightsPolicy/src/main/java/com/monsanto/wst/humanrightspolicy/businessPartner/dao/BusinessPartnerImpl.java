package com.monsanto.wst.humanrightspolicy.businessPartner.dao;

import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipImpl;
import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.dbtemplate.DBTemplateBPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.BusinessPartnerXmlBuilder;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate.DBTemplateBusinessPartnerDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.datasource.Filterable;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.textutil.TextUtil;
import org.apache.commons.lang.StringUtils;

import java.util.*;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Jun 16, 2006 Time: 3:16:15 PM To change this template use File |
 * Settings | File Templates.
 */
public class BusinessPartnerImpl implements BusinessPartner, Filterable {
    public static final String SAP_ID_FILTER = "sapId";
    public static final String BUSINESS_NAME_FILTER = "businessName";
    public static final String REGION_FILTER = "region";
    public static final String COUNTRY_FILTER = "country";
    public static final String STATE_FILTER = "state";

    private String sapId;
    private String legacyId;
    private String entityName;
    private String aliasName;
    private String isComplete;
    private String active;
    private String hrpFlag;
    private String websiteUrl;
    private String notes;
    private Address address;
    private String partnerId;
    private String hrpTypes;
  private Date addBPDate;

    public BusinessPartnerImpl() {
    }

    /**
     * This constructor is called from BusinessPartnerController's createBusinessPartner
     *
     * @param partnerId
     * @param sapId
     * @param legacyId
     * @param partnerName
     * @param aliasName
     * @param webSiteUrl
     * @param active
     * @param isComplete
     * @param hrpFlag
     * @param addBPDate
     */
    public BusinessPartnerImpl(String partnerId, String sapId, String legacyId, String partnerName, String aliasName,
                               String webSiteUrl, String active, String isComplete,
                               String hrpFlag, Date addBPDate) {
        this.partnerId = partnerId;
        this.sapId = formatSAPId(sapId);
        this.legacyId = legacyId;
        this.entityName = partnerName;
        this.aliasName = aliasName;
        this.isComplete = isComplete;
        this.websiteUrl = webSiteUrl;
        this.active = active;
        this.hrpFlag = hrpFlag;
      this.addBPDate = addBPDate;
    }

    public BusinessPartnerImpl(String id, String sapId, String legacyId, String partnerName, String aliasName,
                               String active,
                               String isComplete, String hrpFlag, String hrpTypesSeparatedByComma, String countryId,
                               String countryName,
                               String stateOrProvinceId, String stateOrProvinceName, String regionId, String regionName,
                               String addressId, String addressOne, String addressTwo, String city, String postalCode,
                               String websiteUrl, String notes, Date addBPDate) {
        this.partnerId = id;
        this.hrpTypes = hrpTypesSeparatedByComma;
        this.sapId = sapId;
        this.legacyId = returnNullIfEmpty(legacyId);
        this.entityName = returnNullIfEmpty(partnerName);
        this.aliasName = returnNullIfEmpty(aliasName);
        this.address = new Address(addressId, addressOne, addressTwo, city, postalCode,
                new StateProvince(getId(stateOrProvinceId), stateOrProvinceName),
                new Country(getId(countryId), countryName),
                new Region(getId(regionId), regionName));
        this.isComplete = isComplete;
        this.websiteUrl = websiteUrl;
        this.active = getId(active);
        this.hrpFlag = hrpFlag;
        this.notes = notes;
      this.addBPDate = addBPDate;
    }

    public void addLocationRelationship(Location loc, boolean isPrimary, LocationType bpLocType) {
        for (BPLocationRelationship rel : getActiveBPLocationRelationships()) {
            if (rel.getEndDate() == null && rel.getLocation().equals(loc)) {
                return; // ignore the request, location is already here and active
            }
        }

        BPLocationRelationship newLocRel = new BPLocationRelationshipImpl(null, this, loc, isPrimary, bpLocType, new Date(),
                null
        );
        try {
            getBPLocationRelationshipDAO().saveBPLocationRelationship(newLocRel);
        } catch (Exception e) {
            throw new RuntimeException("Unable to add new location relationship", e);
        }
    }

    public void setPrimaryLocation(Location newPrimaryLocation) {
        BPLocationRelationshipDAO dao = getBPLocationRelationshipDAO();
        try {
            endOldPrimaryLocationRelationship();
            BPLocationRelationship newPrimarysExistingRel = endNewPrimarysExisitingRelationship(newPrimaryLocation);
            BPLocationRelationship newPrimaryRel = new BPLocationRelationshipImpl(null, this, newPrimaryLocation, true,
                    newPrimarysExistingRel.getBpLocRelType(), new Date(), null
            );
            dao.saveBPLocationRelationship(newPrimaryRel);
        } catch (Exception e) {
            throw new RuntimeException("Unable to change primary location relationship", e);
        }
    }

    private BPLocationRelationship endNewPrimarysExisitingRelationship(Location newPrimaryLocation) {
        for (BPLocationRelationship rel : getActiveBPLocationRelationships()) {
            if (rel.getLocation().equals(newPrimaryLocation)) {
                getBPLocationRelationshipDAO().endBPLocationRelationship(rel.getId());
                return rel;
            }
        }
        return null;
    }

    private void endOldPrimaryLocationRelationship() {
        BPLocationRelationship oldPrimary = getPrimaryRelationship();
        if (oldPrimary != null) {
            getBPLocationRelationshipDAO().endBPLocationRelationship(oldPrimary.getId());

            BPLocationRelationship newNonPrimaryForOldPrimary = new BPLocationRelationshipImpl(null,
                    oldPrimary.getBusinessPartner(),
                    oldPrimary.getLocation(), false, oldPrimary.getBpLocRelType(), new Date(), null);
            getBPLocationRelationshipDAO().saveBPLocationRelationship(newNonPrimaryForOldPrimary);
        }
    }

  public Date getAddBPDate() {
    return addBPDate;
  }

    public List<Location> getLocations() {
        List<Location> locs = new ArrayList<Location>();
        for (BPLocationRelationship locRel : getActiveBPLocationRelationships()) {
            locs.add(locRel.getLocation());
        }

        return locs;
    }

    public BPLocationRelationship getPrimaryRelationship() {
        //todo can query a primary rel directly if performace becomes an issue
//    try {
//      return getBPLocationRelationshipDAO().getPrimaryRelationshipForBP(this, DBUtils.createPersistentStore());
//    }catch (Exception e) {
//      throw new RuntimeException(e);
//    }
        for (BPLocationRelationship locRel : getActiveBPLocationRelationships()) {
            if (locRel.getIsPrimary()) {
                return locRel;
            }
        }
        return null;
    }

    public List<ContactInfo> getActiveContacts() {
        Map<String, ContactInfo> contactMap = new HashMap<String, ContactInfo>();
        List<BPLocationRelationship> bpLocRels = getActiveBPLocationRelationships();
        for (BPLocationRelationship bpLocRel : bpLocRels) {
            List<LocationContactRelationship> locConRels = bpLocRel.getLocation().getActiveLocationContactRelationships();
            for (LocationContactRelationship locConRel : locConRels) {
                ContactInfo contact = locConRel.getContact();
                contactMap.put(contact.getContactId(), contact);
            }
        }
        return new ArrayList<ContactInfo>(contactMap.values());
    }

    public ContactInfo getPrimaryContact() {
        List<BPLocationRelationship> bpLocRels = getActiveBPLocationRelationships();
        for (BPLocationRelationship bpLocRel : bpLocRels) {
            List<LocationContactRelationship> locConRels = bpLocRel.getLocation().getActiveLocationContactRelationships();
            for (LocationContactRelationship locConRel : locConRels) {
                ContactInfo contact = locConRel.getContact();
                if (bpLocRel.getIsPrimary() && locConRel.getIsContactPrimary()) {
                    return contact;
                }
            }
        }
        return null;
    }

    public String getFormattedValue(String value) {
        if (StringUtils.isEmpty(value)) {
            return "N";
        } else {
            if ("on".equalsIgnoreCase(value)) {
                return "Y";
            }
            return value;
        }
    }

    public String formatSAPId(String id) {
        String formattedSapId = returnNullIfEmpty(id);
        if (formattedSapId != null) {
            formattedSapId = id.trim();
            while (formattedSapId.length() < 10) {
                formattedSapId = '0' + formattedSapId;
            }
        }
        return formattedSapId;
    }

    private String getId(String id) {
        if ("Select".equalsIgnoreCase(id)) {
            return null;
        } else {
            return id;
        }
    }

    public String getSapId() {
        return sapId;
    }

    public String getFormattedSapId() {
        return formatSAPId(sapId);
    }

    public Address getAddress() {
        return address;
    }

    public String getLegacyId() {
        return legacyId;
    }

    public String getPartnerId() {
        return this.partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getWebsiteUrl() {
        return websiteUrl;
    }

    public List<BPLocationRelationship> getActiveBPLocationRelationships() {
        try {
            return getBPLocationRelationshipDAO().getActiveBPLocationRelationshipsForBP(this);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String getEntityName() {
        return entityName;
    }

    public String getAliasName() {
        return aliasName;
    }

    public String getFullName() {
        String bpName = this.entityName;
        if (!StringUtils.isEmpty(this.aliasName)) {
            bpName += " <br /> " + this.aliasName;
        }
        return bpName;
    }

    public String getActive() {
        return active;
    }

    public String getIsComplete() {
        return isComplete;
    }

    public String getHrpFlag() {
        return hrpFlag;
    }

    public String getHrpTypesAsCommaSeparatedString() {
        return getBusinessPartnerDao().lookupHrpTypesForBP(this.partnerId);
    }

  public String getHrpTypes() {
    return hrpTypes;
  }
  public String getNotes() {
    return notes;
  }

    protected String returnNullIfEmpty(String value) {
        if (value == null || StringUtils.isEmpty(value.trim())) {
            return null;
        } else {
            return value;
        }
    }

    public void setHrpFlag(String hrpFlag) {
        this.hrpFlag = hrpFlag;
    }

    public void setIsComplete(String isComplete) {
        this.isComplete = isComplete;
    }

    public void setActive(String isActive) {
        this.active = isActive;
    }

    public int hashCode() {
        return this.getPartnerId().hashCode();
    }

    public boolean equals(Object obj) {
        if ((obj == null) || !(obj instanceof BusinessPartner)) {
            return false;
        } else if (obj == this) {
            return true;
        }
        BusinessPartner bp = (BusinessPartner) obj;
        return this.partnerId.equals(bp.getPartnerId());
    }

    public String toString() {
        return "(BP: " + getSapId() + ", " + getLegacyId() + ", " + getEntityName() + ", " + getAliasName() + ", " +
                getIsComplete() + ", " +
                getActive() + ", " + getHrpFlag() + ", " + getWebsiteUrl() + ", " +
                getNotes() + ", " + getAddress() + ", " + getPartnerId() + ')';
    }

    public String toXml() {
        return BusinessPartnerXmlBuilder.toXml(this);
    }

    public void endBpLocRelationship(Location location) {
        getBPLocationRelationshipDAO().endBPLocRelForLocation(this, location);
    }

    public boolean filter(String filterValue) {
      boolean idMatchesFilter = TextUtil.contains(getFormattedSapId(), formatSAPId(filterValue));
      boolean nameMatchesFilter = TextUtil.contains(getFullName(), filterValue);

        return idMatchesFilter || nameMatchesFilter;
    }

    public List<Communication> getCommunications() {
        return getCommunicationDAO().lookupCommunicationsByBPId(getPartnerId());
    }

    protected BusinessPartnerDAO getBusinessPartnerDao() {
        DBTemplateImpl template = new DBTemplateImpl("database/dbtemplate-config.xml",
                new String[]{"database/dbtemplate.xml"});
        return new DBTemplateBusinessPartnerDAO(template);
    }

    protected CommunicationDAO getCommunicationDAO() {
        return InitService.initCommunicationDAO();
    }

    protected BPLocationRelationshipDAO getBPLocationRelationshipDAO() {
        DBTemplateImpl template = new DBTemplateImpl("database/dbtemplate-config.xml",
                new String[]{"database/dbtemplate.xml"});
        return new DBTemplateBPLocationRelationshipDAO(template);
    }

    public String toDetailedXml() {
        return BusinessPartnerXmlBuilder.toDetailedXml(this);
    }
}
