package com.monsanto.wst.humanrightspolicy.businessPartner.dao;

import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;

import java.util.List;
/*
 BusinessPartnerResult was created on Jun 4, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class BusinessPartnerResult {
  private final List<BusinessPartner> data;
  private final int totalRecords;

  public BusinessPartnerResult(List<BusinessPartner> data, int totalRecords) {
    this.data = data;
    this.totalRecords = totalRecords;
  }

  public List<BusinessPartner> getData() {
    return data;
  }

  public int getTotalRecords() {
    return totalRecords;
  }
}
