/*
 SearchBusinessPartnerDAO was created on Dec 19, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.dao;

import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.LoginUser;

/**
 * @author sspati1
 */
public interface LookupBPDAO {
  BusinessPartnerResult lookupBPByCriteria(BusinessPartner bpSearchCriteria, boolean myBPScope, LoginUser user,
                                           String sortKey, String filterValue, Integer startRecord, Integer endRecord);

  BusinessPartner lookupBPById(String bpId);
}

