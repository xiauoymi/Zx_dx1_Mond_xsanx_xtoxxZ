/*
 DBTemplateBPDAO was created on Apr 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerDAO;
import com.monsanto.wst.humanrightspolicy.model.HrpType;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.util.List;

/**
 * Filename:    $RCSfile: DBTemplateBusinessPartnerDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:23 $
 *
 * @author sspati1
 * @version $Revision: 1.11 $
 */
public class DBTemplateBusinessPartnerDAO implements BusinessPartnerDAO {
  private final DBTemplate template;
  private GenericDAO<HrpType, Long> hrpTypeDao;

  public DBTemplateBusinessPartnerDAO(DBTemplate template, GenericDAO<HrpType, Long> hrpTypeDao) {
    this.template = template;
    this.hrpTypeDao = hrpTypeDao;
  }

  public DBTemplateBusinessPartnerDAO(DBTemplate template) {
    this(template, InitService.initHrpTypeDAO());
  }

  public String lookupHrpTypesForBP(String bpId) {
    return (String) this.template.executeSingleResultQuery("lookupHrpTypesForBP", bpId);
  }

  public List<HrpType> lookupAllHrpTypes() {
    return hrpTypeDao.findAll();
  }
}