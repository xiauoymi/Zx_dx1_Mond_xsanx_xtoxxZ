/*
 DBTemplateSearchBPDAOImpl was created on Oct 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerDeferredImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerResult;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.LookupBPDAO;
import com.monsanto.wst.humanrightspolicy.geodata.GeoDataFactory;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.LoginUser;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.util.ArrayList;
import java.util.List;

/**
 * @author sspati1
 */
public class DBTemplateLookupBPDAOImpl implements LookupBPDAO {
  private final DBTemplate template;
  public static final String LOOKUP_BP_BY_CRITERIA_QUERYNAME = "lookupBPByCriteria";
  public static final String LOOKUP_MY_BP_BY_CRITERIA_QUERYNAME = "lookupMyBPByCriteria";

  public DBTemplateLookupBPDAOImpl(DBTemplate template) {
    this.template = template;
  }

  public BusinessPartner lookupBPById(String bpId) {
    return (BusinessPartner) this.template.executeSingleResultQuery("lookupBPById", bpId);
  }

  private int getBPRecordCount(String queryName, BPSearchData searchData) {
    return template.executeCountQuery(queryName, searchData);
  }

  public BusinessPartnerResult lookupBPByCriteria(BusinessPartner bpSearchCriteria, boolean myBPScope, LoginUser user,
                                                  String sortKey, String filterValue, Integer startRecord,
                                                  Integer endRecord) {
    GeoDataFactory geoDataFactory = InitService.initGeoDataFactory(); //todo should probably not be in this method

//    BusinessPartner decoratedBp = new BusinessPartnerDecorator(bpSearchCriteria);
    BPSearchData searchData = new BPSearchData(bpSearchCriteria, user, filterValue);
    String queryName = getQueryNameForScope(myBPScope);
    int totalRecords = getBPRecordCount(queryName, searchData);
    List<String[]> results = getResults(sortKey, startRecord, endRecord, searchData, queryName);
    List<BusinessPartner> bpResults = convertStringArrayListToBPList(geoDataFactory, results);
    return new BusinessPartnerResult(bpResults, totalRecords);
  }

  private String getQueryNameForScope(boolean myBPScope) {
    String queryName;
    if (myBPScope) {
      queryName =  LOOKUP_MY_BP_BY_CRITERIA_QUERYNAME;
    } else {
      queryName =  LOOKUP_BP_BY_CRITERIA_QUERYNAME;
    }
    return queryName;
  }

  private List<BusinessPartner> convertStringArrayListToBPList(GeoDataFactory geoDataFactory, List<String[]> results) {
    List<BusinessPartner> bpResults = new ArrayList<BusinessPartner>(results.size());
    for (String[] row : results) {
      bpResults.add(new BusinessPartnerDeferredImpl(geoDataFactory, row[0], row[1], row[2], row[3], row[4], row[5]));
    }
    return bpResults;
  }

  private List<String[]> getResults(String sortKey, Integer startRecord, Integer endRecord,
                                    BPSearchData searchData, String queryName) {
    List<String[]> results;
    if (startRecord != null && endRecord != null) {
      results = template.executePaginatedQuery(queryName, searchData, sortKey, startRecord, endRecord);
    } else {
      results = template.executeQuery(queryName, searchData, sortKey);
    }
    return results;
  }

  public static class BPSearchData {
    private final BusinessPartner bp;
    private final LoginUser user;
    private final String filter;

    public BPSearchData(BusinessPartner bp, LoginUser user, String filter) {
      this.bp = bp;
      this.user = user;
      this.filter = nullIfEmpty(filter);
    }

    public BusinessPartner getBp() {
      return bp;
    }

    public LoginUser getUser() {
      return user;
    }

    public String getFilter() {
      return filter;
    }

    private static String nullIfEmpty(String s) {
      if (s == null || s.length() == 0) {
        return null;
      } else {
        return s;
      }
    }
  }

}