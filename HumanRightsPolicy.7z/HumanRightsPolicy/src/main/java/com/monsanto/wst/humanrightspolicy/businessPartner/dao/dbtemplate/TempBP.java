package com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate;
/*
 TempBP was created on May 22, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class TempBP {
  private final String bpId;
  private final String bpName;
  private final String aliasName;
  private final String sapId;
  private final String websiteUrl;
  private final String legacyId;
  private final String active;
  private final String isHrp;
  private final String isComplete;

  public TempBP(String bpId, String bpName, String aliasName, String sapId, String legacyId, String websiteUrl,
                String active, String isHrp, String isComplete) {
    this.bpId = bpId;
    this.bpName = bpName;
    this.aliasName = aliasName;
    this.sapId = sapId;
    this.websiteUrl = websiteUrl;
    this.legacyId = legacyId;
    this.active = active;
    this.isHrp = isHrp;
    this.isComplete = isComplete;
  }

  public String getBpId() {
    return bpId;
  }

  public String getBpName() {
    return bpName;
  }

  public String getAliasName() {
    return aliasName;
  }

  public String getSapId() {
    return sapId;
  }

  public String getWebsiteUrl() {
    return websiteUrl;
  }

  public String getLegacyId() {
    return legacyId;
  }

  public String getActive() {
    return active;
  }

  public String getIsHrp() {
    return isHrp;
  }

  public String getIsComplete() {
    return isComplete;
  }
}
