package com.monsanto.wst.humanrightspolicy.businessPartner.datasource;

import com.monsanto.wst.humanrightspolicy.model.Address;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
/*
 BPAddressComparator was created on Apr 24, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public abstract class BPAddressComparator extends BPComparator {
  protected abstract String getValue(Address addr);

  protected String getValue(BusinessPartner bp) {
    Address address = bp.getAddress();
    if (address == null) {
      return BLANK;
    } else {
      return getValue(address);
    }
  }
}
