package com.monsanto.wst.humanrightspolicy.businessPartner.datasource;

import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;

import java.util.Comparator;
/*
 BPComparator was created on Apr 24, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public abstract class BPComparator implements Comparator<XmlObject> {
  public static final String BLANK = "";
  protected abstract String getValue(BusinessPartner  bp);

  public int compare(XmlObject o1, XmlObject o2) {
    return compareBp((BusinessPartner ) o1, (BusinessPartner ) o2);
  }

  public int compareBp(BusinessPartner bp1, BusinessPartner bp2) {
    return getValue(bp1).compareTo(getValue(bp2));
  }

}
