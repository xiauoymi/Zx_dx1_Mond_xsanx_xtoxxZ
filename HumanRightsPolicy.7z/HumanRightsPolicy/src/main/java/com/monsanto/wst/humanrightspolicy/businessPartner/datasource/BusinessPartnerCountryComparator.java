package com.monsanto.wst.humanrightspolicy.businessPartner.datasource;

import com.monsanto.wst.humanrightspolicy.model.Address;
import com.monsanto.wst.humanrightspolicy.model.Country;
/*
 BusinessPartnerCountryComparator was created on Apr 24, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public final class BusinessPartnerCountryComparator extends BPAddressComparator {
  protected String getValue(Address addr) {
    Country country = addr.getCountryModel();
    if (country == null) {
      return BLANK;
    } else {
      return country.getValue();
    }
  }
}

