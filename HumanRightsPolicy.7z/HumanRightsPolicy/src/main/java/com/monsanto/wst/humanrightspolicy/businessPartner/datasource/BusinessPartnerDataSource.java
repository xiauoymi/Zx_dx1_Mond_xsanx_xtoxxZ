package com.monsanto.wst.humanrightspolicy.businessPartner.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.Security.service.SecurityService;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerResult;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.config.Configuration;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.controller.XmlDataPaginationController;
import com.monsanto.wst.humanrightspolicy.datasource.ComparatorMap;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.pos.DataRequestParser;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.textutil.TextUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.util.*;

/*
 BusinessPartnerDataSource was created on Apr 17, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class BusinessPartnerDataSource implements XmlDataSource {
    //todo this doesn't seem to be extending from the same base as the rest - why is that (because too many BP's to hold in memory perhaps)
    private static final Log logger = LogFactory.getLog(BusinessPartnerDataSource.class);

    public static final String SAPID_SORT_KEY = "sapId";
    public static final String NAME_SORT_KEY = "bpName";
    public static final String REGION_SORT_KEY = "region";
    public static final String COUNTRY_SORT_KEY = "country";
    public static final String STATE_SORT_KEY = "state";
    public static final String HRP_TYPES_SORT_KEY = "hrpTypesAsString";

    private final ParameterCollection params;
    private final LookupBPService lookupBPService;
    private final SecurityService securityService;
    private final Configuration config;

    private BusinessPartnerResult bpResult = null;

    private static final ComparatorMap<XmlObject> comparatorMap;

    static {
        comparatorMap = new ComparatorMap<XmlObject>(new BusinessPartnerDefaultComparator());
        comparatorMap.addComparator(SAPID_SORT_KEY, new BusinessPartnerSAPIDComparator());
        comparatorMap.addComparator(NAME_SORT_KEY, new BusinessPartnerNameComparator());
        comparatorMap.addComparator(REGION_SORT_KEY, new BusinessPartnerRegionComparator());
        comparatorMap.addComparator(COUNTRY_SORT_KEY, new BusinessPartnerCountryComparator());
        comparatorMap.addComparator(STATE_SORT_KEY, new BusinessPartnerStateComparator());
        comparatorMap.addComparator(HRP_TYPES_SORT_KEY, new BusinessPartnerHrpTypeComparator());
    }

    public BusinessPartnerDataSource(ParameterCollection params, LookupBPService lookupBPService, SecurityService securityService,
                                     Configuration config) {
        this.params = params;
        this.lookupBPService = lookupBPService;
        this.securityService = securityService;
        this.config = config;
    }

    public BusinessPartnerDataSource(UCCHelper helper, LookupBPService lookupBPService, SecurityService securityService,
                                     Configuration config) {
        this(new UCCHelperParameterCollection(helper), lookupBPService, securityService, config);
    }

    public BusinessPartnerDataSource(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initSearchBPService(), InitService.initSecurityService(), InitService.initConfig());
    }

    public BusinessPartnerDataSource(ParameterCollection params) {
        this(params, InitService.initSearchBPService(), InitService.initSecurityService(), InitService.initConfig());
    }

    private void loadDataIfNeeded() throws IOException {
        if (bpResult == null) {
            BusinessPartner bp = buildBpForSearch();
            String scope = params.get(HRPMainConstants.SCOPE);
            boolean myScope = "My".equalsIgnoreCase(scope);
            LoginUser loginUser = getLoginUser();
            String sortKey = getSortKey();
            String filterValue = getFilterValue();
            Integer startRecord = getStartRecord();
            Integer endRecord = getEndRecord(startRecord);

            bpResult = getBPList(bp, myScope, loginUser, sortKey, filterValue, startRecord, endRecord);
        }
    }

    private Integer getStartRecord() {
        try {
            String startString = params.get(XmlDataPaginationController.START_INDEX);
            return Integer.parseInt(startString) + 1;
        } catch (Exception e) {
            return null;
        }
    }

    private Integer getRowsPerPage() {
        try {
            String rowsPerPage = params.get(XmlDataPaginationController.ROWS_PER_PAGE);
            return Integer.parseInt(rowsPerPage);
        } catch (Exception e) {
            return null;
        }
    }

    private Integer getEndRecord(Integer startRecord) {
        Integer rowsPerPage = getRowsPerPage();
        if (startRecord == null || rowsPerPage == null) {
            return null;
        } else {
            return new Integer(startRecord.intValue() + rowsPerPage.intValue() - 1);
        }
    }

    public List<? extends XmlObject> getData() throws IOException {
        loadDataIfNeeded();
        return bpResult.getData();
    }

    public int getTotalRecords() throws IOException {
        try {
            loadDataIfNeeded();
            return bpResult.getTotalRecords();
        } catch (RuntimeException e) {
            logger.error("Unable to getData: ", e);
            throw e;
        }
    }

    public String getSortKey() throws IOException {
        // XmlDataPaginationController
        String baseKey = params.get(XmlDataPaginationController.SORT);
        String direction = params.get(XmlDataPaginationController.SORT_DIRECTION);
        boolean reversedDirection = XmlDataPaginationController.DESCENDING_SORT.equalsIgnoreCase(direction);
        if (reversedDirection) {
            return "DESC" + baseKey;
        } else {
            return baseKey;
        }
    }

    private String getFilterValue() throws IOException {
        return StringUtils.defaultString(
                TextUtil.decodeUsingUTF8(params.get(XmlDataPaginationController.FILTER_VALUE)));
    }

    public boolean isSorted() {
        return true;
    }

    public boolean isFiltered() {
        return true;
    }

    protected LoginUser getLoginUserFromSession(UCCHelper helper) {
        return (LoginUser) helper.getSessionParameter(HRPMainConstants.LOGINUSER);
    }

    public Comparator<XmlObject> getComparator(String sortKey) {
        return comparatorMap.getComparator(sortKey);
    }

    private LoginUser getLoginUser() {
        String userId = params.get(DataRequestParser.USER_ID);
        return securityService.lookupUserByUserId(userId);
//    return securityService.lookupUserByUserId(userId);
    }

    private BusinessPartner buildBpForSearch() throws IOException {
        String bpName = nullIfBlank(
                TextUtil.decodeUsingUTF8(params.get(HRPMainConstants.BUSINESS_NAME)));
        String sapOrLegacyId = TextUtil.decodeUsingUTF8(params.get(BusinessPartnerConstants.SAP_ID));
        String hrpType = nullIfBlank(params.get(BusinessPartnerConstants.HRP_TYPE));
        String hrpFlag = nullIfBlank(params.get(BusinessPartnerConstants.HRP_FLAG));
        String countryId = nullIfBlank(params.get(HRPMainConstants.COMPANY_COUNTRY));
        String stateId = nullIfBlank(params.get(HRPMainConstants.COMPANY_STATE));
        String regionId = nullIfBlank(params.get(HRPMainConstants.REGION));
        Date addBPDate = getAddBPDate(params.get(HRPMainConstants.RECENTLY_ADDED));
        return new BusinessPartnerImpl(null, sapOrLegacyId, null, bpName, null, null, null,
                hrpFlag, hrpType, countryId, null, stateId, null, regionId, null, null, null, null, null, null, null, null, addBPDate);
    }

    private Date getAddBPDate(String requestParameterValue) {
        if ("true".equalsIgnoreCase(requestParameterValue)) {
            Calendar cal = GregorianCalendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH, -config.getNumberOfRecentDays());
            return cal.getTime();
        } else {
            return null;
        }
    }

    private String nullIfBlank(String st) {
        if (st == null || st.length() == 0) {
            return null;
        } else {
            return st;
        }
    }

    private BusinessPartnerResult getBPList(BusinessPartner bp, boolean myScope, LoginUser user,
                                            String sortKey, String filterValue, Integer startRecord, Integer endRecord) {
        return this.lookupBPService
                .lookupBPByCriteria(bp, myScope, user, sortKey, filterValue, startRecord,
                        endRecord);
    }

}
