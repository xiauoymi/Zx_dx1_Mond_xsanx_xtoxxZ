package com.monsanto.wst.humanrightspolicy.businessPartner.datasource;

import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
/*
 BusinessPartnerNameComparator was created on Apr 24, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public final class BusinessPartnerNameComparator extends BPComparator {
  protected String getValue(BusinessPartner bp) {
    String name = bp.getFullName().toLowerCase(); //was getEntityName();
    if (name == null) {
      return BLANK;
    } else {
      return name;
    }
  }
}
