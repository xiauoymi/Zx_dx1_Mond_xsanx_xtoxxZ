/*
 SearchBPServiceImpl was created on Oct 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.search;

import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerResult;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.LookupBPDAO;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.LoginUser;

/**
 * @author sspati1
 */
public class LookupBPServiceImpl implements LookupBPService {
  private final LookupBPDAO lookupBPDAO;

  public LookupBPServiceImpl(LookupBPDAO lookupBPDAO) {
    this.lookupBPDAO = lookupBPDAO;
  }

  public BusinessPartner lookupBPById(String bpId) {
    return this.lookupBPDAO.lookupBPById(bpId);
  }

  public BusinessPartnerResult lookupBPByCriteria(BusinessPartner bp, boolean myBPScope, LoginUser user, String sortKey,
                                                  String filterValue, Integer startRecord, Integer endRecord) {
    return this.lookupBPDAO.lookupBPByCriteria(bp, myBPScope, user, sortKey, filterValue, startRecord, endRecord);
  }
}