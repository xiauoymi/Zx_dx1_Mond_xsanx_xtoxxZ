/*
 BusinessPartnerServiceImpl was created on Apr 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.services;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.model.HrpType;

import java.util.List;

/**
 * Filename:    $RCSfile: BusinessPartnerServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:23 $
 *
 * @author sspati1
 * @version $Revision: 1.70 $
 */
public class BusinessPartnerServiceImpl implements BusinessPartnerService{
  private GenericDAO<HrpType, Long> hrpTypeDao;

  public BusinessPartnerServiceImpl(GenericDAO<HrpType, Long> hrpTypeDao) {
    this.hrpTypeDao = hrpTypeDao;
  }

  public List<HrpType> lookupAllHrpTypes() {
    return hrpTypeDao.findAll();
  }
}