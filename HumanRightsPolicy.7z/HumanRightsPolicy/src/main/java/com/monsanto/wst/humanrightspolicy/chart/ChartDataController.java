package com.monsanto.wst.humanrightspolicy.chart;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.textutil.TextUtil;

import java.io.IOException;
import java.util.List;
/*
 ChartData was created on Jun 20, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class ChartDataController  implements UseCaseController {
  public static final String CHART_DATA_SOURCE = "chart-source";
  private final DBTemplate template;

  public ChartDataController() {
    this(InitService.initTemplate());
  }

  public ChartDataController(DBTemplate template) {
    this.template = template;
  }

  public void run(UCCHelper helper) throws IOException {
    ChartDataSource source = getChartDataSource(helper);
    Object criteria = source.getCriteria(helper);
    String stmtName = source.getStatement(criteria);
    List<String[]> results = template.executeQuery(stmtName, criteria);
    String title = (String) template.executeSingleResultQuery(stmtName + "_title", criteria);
    outputResults(helper, title, results);
  }

  private void outputResults(UCCHelper helper, String title, List<String[]> results) throws IOException {
    int numResults = results.size();
    StringBuffer xmlBuf = new StringBuffer("<ResultSet xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
        "xmlns=\"urn:yahoo:lcl\" " +
        "xsi:schemaLocation=\"urn:yahoo:lcl http://api.local.yahoo.com/LocalSearchService/V2/LocalSearchResponse.xsd\" " +
        "totalResultsAvailable=\"" + numResults + "\" totalResultsReturned=\"" + numResults + "\" firstResultPosition=\"1\">");

    xmlBuf.append("<title>");
    xmlBuf.append(TextUtil.escapeXml(title));
    xmlBuf.append("</title>");

    int itemNum = 0;
    for (String[] result : results) {
      String name = result[0];
      String value = result[1];
      String linkUrl = result[2];

      itemNum++;
      outputDataItem(xmlBuf, itemNum, name, value, linkUrl);
    }
    xmlBuf.append("</ResultSet>");

    try {
      helper.writeXMLDocument(DOMUtil.stringToXML(xmlBuf.toString()));
    } catch (ParserException e) {
      throw new RuntimeException(e);
    }
  }

  private void outputDataItem(StringBuffer xmlBuf, int itemNum, String name, String value, String linkUrl) {
    xmlBuf.append("<data>");
    xmlBuf.append("<num>");
    xmlBuf.append(itemNum);
    xmlBuf.append("</num>");
    xmlBuf.append("<drillUrl>");
    xmlBuf.append(TextUtil.escapeXml(linkUrl));
    xmlBuf.append("</drillUrl>");
    xmlBuf.append("<name>");
    xmlBuf.append(TextUtil.escapeXml(name));
    xmlBuf.append("</name>");
    xmlBuf.append("<value>");
    xmlBuf.append(TextUtil.escapeXml(value));
    xmlBuf.append("</value>");
    xmlBuf.append("</data>");
  }

  private ChartDataSource getChartDataSource(UCCHelper helper) {
    String sourceClassName = (String) helper.getInitParameters().get(CHART_DATA_SOURCE);
    if (sourceClassName == null) {
      throw new IllegalArgumentException(CHART_DATA_SOURCE + " attribute must be set");
    }

    try {
      Class clazz = Class.forName(sourceClassName);
      return (ChartDataSource) clazz.newInstance();
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }
}

