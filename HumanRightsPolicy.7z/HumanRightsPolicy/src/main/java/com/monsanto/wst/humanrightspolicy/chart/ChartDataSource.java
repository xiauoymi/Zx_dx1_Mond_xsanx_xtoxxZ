package com.monsanto.wst.humanrightspolicy.chart;

import com.monsanto.ServletFramework.UCCHelper;/*
 ChartDataSource was created on Jun 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public interface ChartDataSource {
  Object getCriteria(UCCHelper helper);
  String getStatement(Object criteria);
}
