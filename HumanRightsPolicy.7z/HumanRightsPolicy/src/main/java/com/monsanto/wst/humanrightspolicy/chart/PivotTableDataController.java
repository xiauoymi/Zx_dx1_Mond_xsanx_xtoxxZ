/*
 PivotTableDataController was created on Jul 25, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.chart;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.Security.service.SecurityService;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.controller.HrpController;
import com.monsanto.wst.humanrightspolicy.model.CommType;
import com.monsanto.wst.humanrightspolicy.model.LoginUser;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.textutil.TextUtil;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: PivotTableDataController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-10-16 21:36:27 $
 *
 * @author sspati1
 * @version $Revision: 1.15 $
 */
public class PivotTableDataController extends HrpController {
    private final DBTemplate template;
    private CommunicationService commService;
    private SecurityService securityService;
    private final String countOfBPsStmt = "getBPCountByRegionByCountry";
    private final String countOfAssociatedBPsStmt = "getCountOfBPAssociatedWithCommPlansByRegionByCountry";
    private final String countOfCompletedBPsStmt = "getCountOfCompletedBPAssociatedWithCommPlansByRegionByCountry";
    private final String xslPath = "xsl/bpCountOnHomePage.xsl";
    private final String title = "Business Partners";

    public PivotTableDataController() {
        this(InitService.initTemplate(), InitService.initCommunicationService(), InitService.initSecurityService());
    }

    public PivotTableDataController(DBTemplate template, CommunicationService commService,
                                    SecurityService securityService) {
        this.template = template;
        this.commService = commService;
        this.securityService = securityService;
    }

    protected void notSpecified(UCCHelper helper) throws IOException {
        LoginUser hrpUser = this.securityService.lookupUserByUserId(helper.getAuthenticatedUserID());
        List<String[]> countOfTotalBps = template.executeQuery(this.countOfBPsStmt, hrpUser.getId());
        List<String[]> countOfAssociatedBPs = template
                .executeQuery(this.countOfAssociatedBPsStmt, hrpUser.getId());
        List<String[]> countOfCompletedBPs = template
                .executeQuery(this.countOfCompletedBPsStmt, hrpUser.getId());
        Map<String, Map<String, String>> countOfTotalBpMap = createRegionCountryBPCountMap(countOfTotalBps);
        Map<String, Map<String, Map<String, String>>> countOfAssociatedBpMap = createRegionCountrtBPCountWithCommPlanMap(
                countOfAssociatedBPs);
        Map<String, Map<String, Map<String, String>>> countOfCompletedBpMap = createRegionCountrtBPCountWithCommPlanMap(
                countOfCompletedBPs);
        String xmlStr = getXMLString(countOfTotalBpMap, countOfAssociatedBpMap, countOfCompletedBpMap);
        try {
            Document document = DOMUtil.stringToXML(xmlStr);
            helper.applyStylesheet(document, xslPath);
        } catch (ParserException e) {
            throw new RuntimeException(e);
        }
    }

    private String getXMLString(Map<String, Map<String, String>> regionCountryTotalBPCountMap,
                                Map<String, Map<String, Map<String, String>>> regionCountryAssociatedBPCountMap,
                                Map<String, Map<String, Map<String, String>>> regionCountryCompletedBPCountMap) {
        StringBuffer xmlBuf = new StringBuffer();
        xmlBuf.append("<result>");
        xmlBuf.append("<title>");
      xmlBuf.append(TextUtil.escapeXml(title));
        xmlBuf.append("</title>");
        List<CommType> commTypes = this.commService.lookupCommunicationTypes();
        Collections.sort(commTypes);
        appendCommTypes(xmlBuf, commTypes);

        for (String region : regionCountryTotalBPCountMap.keySet()) {
            xmlBuf.append("<region>");
            xmlBuf.append("<name>");
          xmlBuf.append(TextUtil.escapeXml(region));
            xmlBuf.append("</name>");
            xmlBuf.append("<countries>");
            appendCountries(xmlBuf, regionCountryTotalBPCountMap.get(region), regionCountryAssociatedBPCountMap.get(region),
                    regionCountryCompletedBPCountMap.get(region), commTypes);
            xmlBuf.append("</countries>");
            xmlBuf.append("</region>");
        }
        xmlBuf.append("</result>");
        return xmlBuf.toString();
    }

    private void appendCommTypes(StringBuffer xmlBuf, List<CommType> commTypes) {
        xmlBuf.append("<commTypes>");
       for (CommType commType : commTypes) {
            xmlBuf.append("<commType>");
            xmlBuf.append("<id>");
            xmlBuf.append(commType.getId());
            xmlBuf.append("</id>");
            xmlBuf.append("<value>");
            xmlBuf.append(commType.getType());
            xmlBuf.append("</value>");
            xmlBuf.append("</commType>");
        }
        xmlBuf.append("</commTypes>");
    }

    private void appendCountries(StringBuffer xmlBuf, Map<String, String> countryTotalBPCountMap,
                                 Map<String, Map<String, String>> countryAssociatedBPCountMap,
                                 Map<String, Map<String, String>> countryCompletedBPCountMap, List<CommType> commTypes) {
        for (String countryName : countryTotalBPCountMap.keySet()) {
            String countOfBp = getBPCount(countryTotalBPCountMap, countryName);
            Map<String, String> countOfAssociatedBPs = getBPWithCommPlanCount(countryAssociatedBPCountMap, countryName);
            Map<String, String> countOfCompletedBPs = getBPWithCommPlanCount(countryCompletedBPCountMap, countryName);
            xmlBuf.append("<country>");
            xmlBuf.append("<name>");
          xmlBuf.append(TextUtil.escapeXml(countryName));
            xmlBuf.append("</name>");
            xmlBuf.append("<countOfBps>");
          xmlBuf.append(TextUtil.escapeXml(countOfBp));
            xmlBuf.append("</countOfBps>");
            appendCompletedBpsCountsByCommType(xmlBuf, countOfAssociatedBPs, countOfCompletedBPs, commTypes);
            xmlBuf.append("</country>");
        }
    }

    private void appendCompletedBpsCountsByCommType(StringBuffer xmlBuf, Map<String, String> countOfAssociatedBPs,
                                                    Map<String, String> countOfCompletedBPs, List<CommType> commTypes) {
        xmlBuf.append("<countOfCompletedBps>");
        for (CommType commType : commTypes) {
            //todo currently this has to be converted to String because thats how its being put in the hash, this should be fixed
            String commTypeIdString = Long.toString(commType.getId());
            String countOfAssociated = countOfAssociatedBPs.get(commTypeIdString);
            String countOfCompleted = countOfCompletedBPs.get(commTypeIdString);
            if (countOfAssociated != null) {
                xmlBuf.append("<count type='").append(commType.getId()).append("'>");
                if (countOfCompleted == null) {
                    countOfCompleted = "0";
                }
              xmlBuf.append(TextUtil.escapeXml(countOfCompleted));
                xmlBuf.append("</count>");
            }
        }
      xmlBuf.append("</countOfCompletedBps>");
    }

    private String getBPCount(Map<String, String> map, String countryName) {
        if (map != null && map.get(countryName) != null) {
            return map.get(countryName);
        }
        return "0";
    }

    private Map<String, String> getBPWithCommPlanCount(Map<String, Map<String, String>> map, String countryName) {
        if (map != null && map.get(countryName) != null) {
            return map.get(countryName);
        }
        return new LinkedHashMap<String, String>();
    }

    private Map<String, Map<String, String>> createRegionCountryBPCountMap(List<String[]> results) {
        Map<String, Map<String, String>> regions = new LinkedHashMap<String, Map<String, String>>();
        Map<String, String> countries;
        for (String[] result : results) {
            String region = result[0];
            String country = result[1];
            String countryCount = result[2];
            if (regions.containsKey(region)) {
                countries = regions.get(region);
            } else {
                countries = new LinkedHashMap<String, String>();
            }
            countries.put(country, countryCount);
            regions.put(region, countries);
        }
        return regions;
    }

    private Map<String, Map<String, Map<String, String>>> createRegionCountrtBPCountWithCommPlanMap(
            List<String[]> results) {
        Map<String, Map<String, Map<String, String>>> regions = new LinkedHashMap<String, Map<String, Map<String, String>>>();
        Map<String, Map<String, String>> countries;
        Map<String, String> commTypeCountMap;
        for (String[] result : results) {
            String region = result[0];
            String country = result[1];
            String countryCount = result[2];
            String commTypeId = result[3];
            if (regions.containsKey(region)) {
                countries = regions.get(region);
            } else {
                countries = new LinkedHashMap<String, Map<String, String>>();
            }
            if (countries.containsKey(country)) {
                commTypeCountMap = countries.get(country);
            } else {
                commTypeCountMap = new LinkedHashMap<String, String>();
            }
            commTypeCountMap.put(commTypeId, countryCount);
            countries.put(country, commTypeCountMap);
            regions.put(region, countries);
        }
        return regions;
    }

}