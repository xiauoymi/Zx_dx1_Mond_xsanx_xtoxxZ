package com.monsanto.wst.humanrightspolicy.chart.businesspartner;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.humanrightspolicy.chart.ChartDataSource;

import java.io.IOException;
/*
 BusinessPartnerByLocationChartDataSource was created on Jun 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class BusinessPartnerByLocationChartDataSource implements ChartDataSource {
  public static final String REGION_PARAMETER = "region";
  public static final String COUNTRY_PARAMETER = "country";

  public static final String BP_BY_REGION_STATEMENT = "listBpCountByRegion";
  public static final String BP_BY_COUNTRY_STATEMENT = "listBpCountByCountry";
  public static final String BP_BY_STATE_STATEMENT = "listBpCountByState";

  public Object getCriteria(UCCHelper helper) {
    try {
      String region = helper.getRequestParameterValue(REGION_PARAMETER);
      String country = helper.getRequestParameterValue(COUNTRY_PARAMETER);
      return new BusinessPartnerLocationCriteria(region, country);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  public String getStatement(Object criteria) {
    BusinessPartnerLocationCriteria bpCriteria = (BusinessPartnerLocationCriteria) criteria;
    if (!StringUtils.isNullOrEmpty(bpCriteria.getCountryId())) {
      return BP_BY_STATE_STATEMENT;
    } else if (!StringUtils.isNullOrEmpty(bpCriteria.getRegionId())) {
      return BP_BY_COUNTRY_STATEMENT;
    } else {
      return BP_BY_REGION_STATEMENT;
    }
  }
}
