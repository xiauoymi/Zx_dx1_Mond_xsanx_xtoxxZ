/*
 CommunicationConstants was created on Apr 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication;

/**
 * Filename:    $RCSfile: CommunicationConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: AFHYAT $
 * On:	$Date: 2008-10-02 18:31:46 $
 *
 * @author sspati1
 * @version $Revision: 1.20 $
 */
public class CommunicationConstants {
  ///CLOVER:OFF
  private CommunicationConstants() {
  }
  ///CLOVER:ON

  public static final String LIST_COMM_JSP = "/WEB-INF/jsp/communication/listCommunications.jsp";
  public static final String COMM_JSP = "/WEB-INF/jsp/communication/communication.jsp";
  public static final String COMMUNICATION = "communication";
  public static final String COMM_RECIPIENT_CRITERIA = "commRecipientCriteria";
  public static final String COMM_TYPE_LIST = "commTypeList";
  public static final String COMM_STATUS_LIST = "statusList";
  public static final String COMM_ID = "commId";
  public static final String RECIPIENT_ID = "recipientId";
  public static final String DONE_FLAG = "doneFlag";
  public static final String SET_ALL_AS_DONE = "setAllAsDone";
  public static final String IS_COMM_READY_FOR_COMPLETTION = "isCommunicationReadyForCompletion";
  public static final String ARE_ALL_RECIPIENTS_MARKED_AS_DONE = "areAllRecipientsMarkedAsDone";
  public static final String COMM_NAME = "commName";
  public static final String COMM_NOTES = "commNotes";
  public static final String COMM_FROM_PERIOD = "commFromPeriod";
  public static final String COMM_TO_PERIOD = "commToPeriod";
  public static final String COMM_DUE_PERIOD = "commDueDate";
  public static final String COMM_URL_TITLE = "commUrlTitle";
  public static final String COMM_URL = "commUrl";
  public static final String COMM_TYPE_ID = "commTypeId";
  public static final String COMM_STATUD_ID = "commStatusId";
  public static final String COMM_PEOPLE_TYPE_ID = "commPeopleTypeId";
  public static final String COMM_LOC_TYPE_ID = "commLocTypeId";
  public static final String ACTION_ITEMS_ON_COMM = "actionItemsOnCommPlan";
  public static final String REGION = "region";
  public static final String STATE = "state";
  public static final String COUNTRY = "country";
  public static final String SEARCH_LOC_TYPE_ID = "searchLocTypeId";
  public static final String SEARCH_PEOPLE_TYPE_ID = "searchPeopleTypeId";
  public static final String SEARCH_PERSON_NAME = "searchPersonName";
  public static final String SEARCH_COMPANY = "searchCompany";
  public static final String SET_TO_DISTRIBUTED = "setToDistributed";
  public static final String SEARCH_DUE_DATE_FROM = "dueDateFrom";
  public static final String SEARCH_DUE_DATE_TO = "dueDateTo";
  public static final String NEW_STATUS = "NEW";
  public static final String OPEN_STATUS = "OPEN";
  public static final String CLOSED_STATUS = "CLOSED";
  public static final String READY_STATUS = "READY";
  public static final String ADD_COMM_METHOD = "addCommunication";
  public static final String COMM_DATE_COMPLETED = "dateCompleted";
  public static final String COUNT_OF_RECIPIENTS = "countOfRecipientsForComm";

}