/*
 BaseCommunicationController was created on Aug 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.action.ActionConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.controller.HrpController;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.io.IOException;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: BaseCommunicationController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:21 $
 *
 * @author sspati1
 * @version $Revision: 1.9 $
 */
public class BaseCommunicationController extends HrpController {
    private CommunicationService commService;
    private LocationService locationService;
    private final GenericDAO<ContactType, Long> contactTypeDAO;

    public BaseCommunicationController(CommunicationService commService, LocationService locationService, GenericDAO<ContactType, Long> contactTypeDAO
    ) {
        this.commService = commService;
        this.locationService = locationService;
        this.contactTypeDAO = contactTypeDAO;
    }

    protected void notSpecified(UCCHelper helper) throws IOException {
    }

    protected CommunicationService getCommService() {
        return commService;
    }

    protected LocationService getLocationService() {
        return locationService;
    }

    protected CommStatus getStatusByValue(String value) {
        List<CommStatus> statuses = this.getCommService().lookupCommunicationStatuses();
        for (CommStatus status : statuses) {
            if (status.getStatus().equalsIgnoreCase(value)) {
                return status;
            }
        }
        return null;
    }

    protected boolean areAllRecipientsMarkedAsDoneForThisComm(Communication comm) {
        return comm.areAllRecipientsMarkedAsDone();
    }

    protected boolean isCommunicationReadyForCompletion(Communication comm) {
        return !(comm.getStatus().getId().equals(getStatusByValue(CommunicationConstants.NEW_STATUS).getId()) ||
                comm.getStatus().getId().equals(getStatusByValue(CommunicationConstants.CLOSED_STATUS).getId()))
                && areAllRecipientsMarkedAsDoneForThisComm(comm);
    }

    protected Communication updateCommStatus(Communication comm, CommStatus status) {
        return this.getCommService().updateCommunication(comm.getId(), comm.getName(), comm.getNotes(), comm.getFromDate(),
                comm.getToDate(), comm.getDueDate(), comm.getActive(), comm.getUrlTitle(), comm.getUrl(), comm.getCommType(),
                status, comm.getLocConRelType(), comm.getBpLocRelType(), new Date());
    }

    protected void setRequestAttributesInHelper(UCCHelper helper, Communication comm) {
        helper.setRequestAttributeValue(CommunicationConstants.COMMUNICATION, comm);
        boolean areAllRecipientsMarkedAsDone = areAllRecipientsMarkedAsDoneForThisComm(comm);
        helper.setRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE,
                areAllRecipientsMarkedAsDone);
        boolean isCommunicationReadyForCompletion = isCommunicationReadyForCompletion(comm);
        helper.setRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION,
                isCommunicationReadyForCompletion);
        CommRecipient commRecipient = getDefaultCommRecipientSearchCriteria(comm);
        helper.setRequestAttributeValue(CommunicationConstants.COMM_RECIPIENT_CRITERIA, commRecipient);
        setReferenceDataInHelper(helper);
    }

    protected void setReferenceDataInHelperForNewActionItem(UCCHelper helper) {
        helper.setRequestAttributeValue(ActionConstants.ACTION_STATUS_LIST, InitService.initActionService().lookupAllStatusTypes());
        helper.setRequestAttributeValue(ActionConstants.ACTION_PRIORITY_LIST, InitService.initActionService().lookupAllPriorityTypes());
    }

    protected void getCountOfRecipientsForCommunication(UCCHelper helper, Communication comm) {
        helper.setRequestAttributeValue(CommunicationConstants.COUNT_OF_RECIPIENTS,
                Integer.valueOf(comm.getRecipients().size()).toString());
    }

    protected CommRecipientImpl getDefaultCommRecipientSearchCriteria(Communication comm) {
        return new CommRecipientImpl(null, null, null, null, null, comm.getBpLocRelType().getId(),
                comm.getBpLocRelType().getType(),
                comm.getLocConRelType().getId(), comm.getLocConRelType().getType(), null, null, null, null, null, null, null,
                null, null, null, null, null, null, null);
    }

    protected void setReferenceDataInHelper(UCCHelper helper) {
        helper.setRequestAttributeValue(CommunicationConstants.COMM_TYPE_LIST, getCommService().lookupCommunicationTypes());
        helper.setRequestAttributeValue(BusinessPartnerConstants.LOC_CON_REL_TYPE_LIST,
                contactTypeDAO.findAll());
        helper.setRequestAttributeValue(LocationsConstants.BP_LOC_REL_TYPE_LIST, getLocationService().lookupBPLocRelTypes());
    }

}