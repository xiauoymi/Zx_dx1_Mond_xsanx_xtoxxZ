package com.monsanto.wst.humanrightspolicy.communication.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.humanrightspolicy.action.ActionConstants;
import com.monsanto.wst.humanrightspolicy.action.service.ActionService;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.model.ActionPriority;
import com.monsanto.wst.humanrightspolicy.model.Status;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 26, 2008
 * Time: 1:58:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommActionItemsController extends BaseCommunicationController {
  private static final Log logger = LogFactory.getLog(CommActionItemsController.class);
  private CommunicationService commService;
  private ActionService actionService;

  public CommActionItemsController() {
    this(InitService.initCommunicationService(), InitService.initActionService());
  }

  public CommActionItemsController(CommunicationService commService, ActionService actionService) {
    super(commService, InitService.initLocationService(), InitService.initContactTypeDAO());
    this.commService = commService;
    this.actionService = actionService;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
  }

  public void addActionItem(UCCHelper helper) throws IOException {
    String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
    Action action = addAction(helper);
    addUserAsPrimaryAssigneeToAction(helper, action);
    String actionID = action.getId().toString();
    CommunicationService communicationService = getCommService();
    communicationService.addActionItem(commId, actionID);
    lookupActionItemOnCommunicationPlanAsList(helper);
    helper.setRequestAttributeValue(ActionConstants.ACTION, action);
  }

  private void addUserAsPrimaryAssigneeToAction(UCCHelper helper, Action action) {
    List<String> userIds = new ArrayList<String>();
    userIds.add(helper.getAuthenticatedUserID());
    this.actionService.addAssignmentToAction(null, userIds, action.getId(), true);
  }

  private Date getDateFromString(String dateStr) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    try {
      return sdf.parse(dateStr);
    } catch (ParseException e) {
      logger.error("Unable to parse action date");
    }
    return null;
  }

  public Action addAction(UCCHelper helper) throws IOException {
    String name = helper.getRequestParameterValue(ActionConstants.ACTION_NAME);
    Date dueDate =getDateFromString(helper.getRequestParameterValue(ActionConstants.ACTION_DUE_DATE));
    Date startDate =getDateFromString(helper.getRequestParameterValue(ActionConstants.ACTION_START_DATE));
    Date dateCompleted =getDateFromString(helper.getRequestParameterValue(ActionConstants.ACTION_DATE_COMPLETED));
    String status =getValueFromRequest(helper.getRequestParameterValue(ActionConstants.ACTION_STATUS));
    String priority = getValueFromRequest(helper.getRequestParameterValue(ActionConstants.ACTION_PRIORITY));
    String percentComplete =helper.getRequestParameterValue(ActionConstants.ACTION_PERCENT_COMPLETE);
    String description =helper.getRequestParameterValue(ActionConstants.ACTION_DESCRIPTION);
    Status actionStatus = getActionStatusBasedOnRequest(status);
    ActionPriority actionPriority = getActionPriorityBasedObRequest(priority);
    return this.actionService.addAction(null, name, startDate, dueDate, dateCompleted, actionStatus,
        actionPriority, percentComplete, description, null);
  }

  private ActionPriority getActionPriorityBasedObRequest(String priority) {
    if (priority != null)
      return InitService.initPriorityDAO().findByPrimaryKey(new Long(priority));
    return null;
  }

  private Status getActionStatusBasedOnRequest(String status) {
    if (status != null)
      return InitService.initStatusDAO().findByPrimaryKey(new Long(status));
    return null;
  }

  private String getValueFromRequest(String value) {
    return value == null || StringUtils.isEmpty(value.trim()) ? null :   value;
  }

  public void lookupActionItemOnCommunicationPlanXML(UCCHelper helper) throws IOException {
    String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
    helper.setContentType("text/xml");
    Document doc = getCommService().getActionItemsAsXML(commId);
    helper.writeXMLDocument(doc, HRPMainConstants.LATIN1_ENCODING);
  }

  public void lookupActionItemOnCommunicationPlanAsList(UCCHelper helper) throws IOException {
    String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
    List<Action> actionsList = getCommService().getActionItemsAsList(commId);
    helper.setRequestAttributeValue(CommunicationConstants.ACTION_ITEMS_ON_COMM, actionsList);
  }

  protected CommunicationService getCommService() {
    return commService;
  }

}
