/*
 CommRecipientController was created on Aug 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.datasource.RecipientDataSource;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.controller.FilteredXmlDataSource;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.model.CommRecipient;
import com.monsanto.wst.humanrightspolicy.model.CommStatus;
import com.monsanto.wst.humanrightspolicy.model.Communication;
import com.monsanto.wst.humanrightspolicy.model.ContactType;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: CommRecipientController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:21 $
 *
 * @author sspati1
 * @version $Revision: 1.8 $
 */
public class CommRecipientController extends BaseCommunicationController {

  public CommRecipientController() {
    this(InitService.initCommunicationService(), InitService.initLocationService(), InitService.initContactTypeDAO()
    );
  }

  public CommRecipientController(CommunicationService commService, LocationService locationService, GenericDAO<ContactType, Long> contactTypeDAO
  ) {
    super(commService, locationService, contactTypeDAO);
  }

  public void updateDoneFlag(UCCHelper helper) throws IOException {
    String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
    String recipientId = helper.getRequestParameterValue(CommunicationConstants.RECIPIENT_ID);
    String doneFlag = helper.getRequestParameterValue(CommunicationConstants.DONE_FLAG);
    Communication comm = this.getCommService().lookupCommunicationById(commId);
    comm.updateDoneFlagForRecipient(recipientId, doneFlag);
    helper.setContentType("text/xml");
    Document response = createNewDocument();
    Element responseElement = response.createElement("response");
    Element resultElement = response.createElement("result");
    DOMUtil.addChildElement(resultElement, CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE,
        areAllRecipientsMarkedAsDoneForThisComm(comm));
    DOMUtil.addChildElement(resultElement, CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION,
        isCommunicationReadyForCompletion(comm));
    responseElement.appendChild(resultElement);
    response.appendChild(responseElement);
    helper.writeXMLDocument(response, HRPMainConstants.LATIN1_ENCODING);
  }

  public void updateDoneFlagForSelectedRecipients(UCCHelper helper) throws IOException {
    String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
    String doneFlag = helper.getRequestParameterValue(CommunicationConstants.DONE_FLAG);
    Communication comm = this.getCommService().lookupCommunicationById(commId);
    if (isAllSelectedNoneExcludedNotFiltered()) {
      comm.updateDoneFlagForAllRecipients(doneFlag);
    } else {
      List<String> selectdsIds = getSelectedRecipientIds(helper);
      comm.updateDoneFlagForSelectedRecipients(selectdsIds, doneFlag);
    }
    setRequestAttributesInHelper(helper, comm);
    helper.forward(CommunicationConstants.COMM_JSP);
  }

  public void updateDoneFlagForAllRecipients(UCCHelper helper) throws IOException {
    String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
    Communication comm = this.getCommService().lookupCommunicationById(commId);
    comm.updateDoneFlagForAllRecipients("Y");
    setRequestAttributesInHelper(helper, comm);
    helper.forward(CommunicationConstants.COMM_JSP);
  }

  public void addRecipient(UCCHelper helper) throws IOException {
    String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
    String recipientId = helper.getRequestParameterValue(CommunicationConstants.RECIPIENT_ID);
    Communication comm = this.getCommService().lookupCommunicationById(commId);
    comm.addRecipient(recipientId);
    setStatusToOpenIfNotAlready(helper, comm);
    super.getCountOfRecipientsForCommunication(helper, comm);
    helper.setContentType("text/plain");
    helper.getPrintWriter().write("ok");
  }

  public void addAllRecipients(UCCHelper helper) throws IOException {
    String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);

    CommRecipient commRecipientCriteria = getRecipientDataSource(helper).buildSearchCriteriaFromRequest();
    Communication comm = this.getCommService().lookupCommunicationById(commId);
    List<CommRecipient> recipientsNotAssociatedWithCommunication = comm
        .getRecipientsNotAssociatedWithThisCommunicationByCriteria(commRecipientCriteria);
    comm.addRecipients(recipientsNotAssociatedWithCommunication);
    setStatusToOpenIfNotAlready(helper, comm);
    super.getCountOfRecipientsForCommunication(helper, comm);
    helper.setContentType("text/plain");
    helper.getPrintWriter().write("ok");

//    List<CommRecipient> recipientList = getRecipientsList(commRecipientCriteria, comm);
//
//    Document response = appendRecipients(recipientList, menuLocation);
//    helper.setContentType("text/xml");
//    helper.writeXMLDocument(response, HRPMainConstants.XML_ENCODING);
  }

  public void deleteRecipient(UCCHelper helper) throws IOException {
    String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
    Communication comm = this.getCommService().lookupCommunicationById(commId);
    List<String> selectdsIds = new ArrayList<String>();
    selectdsIds.add(helper.getRequestParameterValue(CommunicationConstants.RECIPIENT_ID));
    comm.deleteSelectedRecipients(selectdsIds);
    super.getCountOfRecipientsForCommunication(helper, comm);
    helper.setContentType("text/plain");
    helper.getPrintWriter().write("ok");
  }

  public void deleteSelectedRecipients(UCCHelper helper) throws IOException {
    String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
    Communication comm = this.getCommService().lookupCommunicationById(commId);
    if (isAllSelectedNoneExcludedNotFiltered()) {
      comm.deleteAllRecipients();
    } else {
      List<String> selectdsIds = getSelectedRecipientIds(helper);
      comm.deleteSelectedRecipients(selectdsIds);
    }
    comm = updateCommAsNewIfNoRecipients(helper, comm);
    setRequestAttributesInHelper(helper, comm);
    helper.forward(CommunicationConstants.COMM_JSP);
  }

  public void lookupRecipientsForDistributionListXML(UCCHelper helper) throws IOException {
    String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
    Communication comm = getCommService().lookupCommunicationById(commId);
    setStatusToReady(comm, helper);
    List<CommRecipient> distributionList = comm.getRecipients();
//    lookupCommunication(helper);
    Document response = appendRecipientsForDistribution(comm, distributionList);
    String path = "xsl/styleSheetForDistribution.xsl";
    helper.writeToExcel(response, path);
  }

  private List<CommRecipient> getRecipientsForCommunication(UCCHelper helper) throws IOException {
    RecipientDataSource ds = getRecipientDataSource(helper);
    XmlDataSource filteredSource = new FilteredXmlDataSource(ds, getFilterValue());
    return (List<CommRecipient>) filteredSource.getData();
  }

  private List<String> getSelectedRecipientIds(UCCHelper helper) throws IOException {
    if (isAllSelected()) {
      List<CommRecipient> recipients = getRecipientsForCommunication(helper);
      List<String> selectedIds = new ArrayList<String>();
      for (CommRecipient recipient : recipients) {
        selectedIds.add(recipient.getContactId());
      }
      List<String> idsToExclude = getIdsToExclude();
      for (String id : idsToExclude) {
        selectedIds.remove(id);
      }
      return selectedIds;
    } else {
      return getSelectedIds();
    }
  }

  private Communication updateCommAsNewIfNoRecipients(UCCHelper helper, Communication comm) {
    if (comm.getRecipients().size() == 0) {
      CommStatus newStatus = getStatusByValue(CommunicationConstants.NEW_STATUS);
      comm = updateCommStatus(comm, newStatus);
    }
    return comm;
  }

  //This method has protected access only for testing
  protected RecipientDataSource getRecipientDataSource(UCCHelper helper) {
    return new RecipientDataSource(helper);
  }

  private void setStatusToReady(Communication comm, UCCHelper helper) throws IOException {
    String setToDistributed = helper.getRequestParameterValue(CommunicationConstants.SET_TO_DISTRIBUTED);
    if (StringUtils.isNotEmpty(setToDistributed) && "Y".equalsIgnoreCase(setToDistributed)) {
      CommStatus readyStatus = getStatusByValue(CommunicationConstants.READY_STATUS);
      updateCommStatus(comm, readyStatus);
    }
  }

  private void setStatusToOpenIfNotAlready(UCCHelper helper, Communication comm) {
    if (comm.getStatus().getStatus().equalsIgnoreCase(CommunicationConstants.NEW_STATUS)) {
      CommStatus openStatus = getStatusByValue(CommunicationConstants.OPEN_STATUS);
      updateCommStatus(comm, openStatus);
    }
  }

  private Document appendRecipientsForDistribution(Communication comm, List<CommRecipient> distributionList) {
    Document response = createNewDocument();
    Element distribution = response.createElement("distribution");
    Element comms = response.createElement("communicationProperties");
    DOMUtil.addChildElement(comms, "commName", comm.getName());
    DOMUtil.addChildElement(comms, "commFrom", comm.getFormattedFromDate());
    DOMUtil.addChildElement(comms, "commTo", comm.getFormattedToDate());
    DOMUtil.addChildElement(comms, "commType", comm.getCommType().getType());
    DOMUtil.addChildElement(comms, "commPeopleType", comm.getLocConRelType().getType());
    DOMUtil.addChildElement(comms, "commLocationType", comm.getBpLocRelType().getType());
    distribution.appendChild(comms);
    Element recipients = response.createElement("recipients");
    for (CommRecipient recipient : distributionList) {
      recipient.appendXML(recipients);
    }
    distribution.appendChild(recipients);
    response.appendChild(distribution);
    return response;
  }
}