/*
 CommunicationController was created on Apr 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.datasource.CommunicationDataSource;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.controller.FilteredXmlDataSource;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.humanrightspolicy.utils.NumberUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * <<<<<<< CommunicationController.java On:	$Date: 2008-10-17 19:19:28 $getRecipientsForCommList ======= On:	$Date:
 * 2008/05/05 15:25:27 $getRecipientsForCommList >>>>>>> 1.14
 *
 * @author sspati1 <<<<<<< CommunicationController.java
 * @version $Revision: 1.67 $ >>>>>>> 1.14
 */
public class CommunicationController extends BaseCommunicationController {
    private static final Log logger = LogFactory.getLog(CommunicationController.class);

    public CommunicationController() {
        this(
                InitService.initCommunicationService(),
                InitService.initLocationService(),
                InitService.initContactTypeDAO());
    }

    public CommunicationController(CommunicationService commService, LocationService locationService, GenericDAO<ContactType, Long> contactTypeDAO
    ) {
        super(commService, locationService, contactTypeDAO);
    }

    protected void notSpecified(UCCHelper helper) throws IOException {
        setupDataInHelper(helper, "My");
        helper.forward(CommunicationConstants.LIST_COMM_JSP);
    }

    public void allComms(UCCHelper helper) throws IOException {
        setReferenceDataInHelper(helper);
        helper.setRequestAttributeValue(CommunicationConstants.COMM_STATUS_LIST, getCommService().lookupCommunicationStatuses());
        helper.forward(CommunicationConstants.LIST_COMM_JSP);
    }

    public void lookupCommunication(UCCHelper helper) throws IOException {
        String recipientAdded = null;
        String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
        if (helper.getRequestParameterValue("recipientAdded") != null) {
            recipientAdded = helper.getRequestParameterValue("recipientAdded");
        }
        Communication comm = this.getCommService().lookupCommunicationById(commId);
//    getCountOfRecipientsForCommunication(helper, comm);
        helper.setRequestAttributeValue("recipientAdded", recipientAdded);
        setRequestAttributesInHelper(helper, comm);
        setReferenceDataInHelperForNewActionItem(helper);
        helper.forward(CommunicationConstants.COMM_JSP);
    }

    public void updateCommunication(UCCHelper helper) throws IOException {
        String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
        String name = helper.getRequestParameterValue(CommunicationConstants.COMM_NAME);
        String notes = helper.getRequestParameterValue(CommunicationConstants.COMM_NOTES);
        Date fromDate = getDate(helper.getRequestParameterValue(CommunicationConstants.COMM_FROM_PERIOD));
        Date toDate = getDate(helper.getRequestParameterValue(CommunicationConstants.COMM_TO_PERIOD));
        Date dueDate = getDate(helper.getRequestParameterValue(CommunicationConstants.COMM_DUE_PERIOD));
        String urlTitle = helper.getRequestParameterValue(CommunicationConstants.COMM_URL_TITLE);
        String url = helper.getRequestParameterValue(CommunicationConstants.COMM_URL);
        String active = "Y";
        CommType commType = new CommType(helper.getRequestParameterValue(CommunicationConstants.COMM_TYPE_ID), null);
        CommStatus status = new CommStatus(NumberUtil.stringToLong(helper.getRequestParameterValue(CommunicationConstants.COMM_STATUD_ID)), null); //todo change to lookup
        ContactType peopleType = new ContactType(
                helper.getRequestParameterValue(CommunicationConstants.COMM_PEOPLE_TYPE_ID), null);
        Long locTypeId = NumberUtil.stringToLong(helper.getRequestParameterValue(CommunicationConstants.COMM_LOC_TYPE_ID));
        LocationType locType = new LocationType(locTypeId, null);
        Date dateCompleted = null;
        Communication comm = getCommService()
                .updateCommunication(commId, name, notes, fromDate, toDate, dueDate, active, urlTitle, url, commType, status,
                        peopleType, locType, dateCompleted);
        setRequestAttributesInHelper(helper, comm);
        helper.forward(CommunicationConstants.COMM_JSP);
    }

    public void addCommunication(UCCHelper helper) throws IOException {
        String name = helper.getRequestParameterValue(CommunicationConstants.COMM_NAME);
        String notes = helper.getRequestParameterValue(CommunicationConstants.COMM_NOTES);
        Date fromDate = getDate(helper.getRequestParameterValue(CommunicationConstants.COMM_FROM_PERIOD));
        Date toDate = getDate(helper.getRequestParameterValue(CommunicationConstants.COMM_TO_PERIOD));
        Date dueDate = getDate(helper.getRequestParameterValue(CommunicationConstants.COMM_DUE_PERIOD));
        String urlTitle = helper.getRequestParameterValue(CommunicationConstants.COMM_URL_TITLE);
        String url = helper.getRequestParameterValue(CommunicationConstants.COMM_URL);
        String active = "Y";
        CommType commType = new CommType(helper.getRequestParameterValue(CommunicationConstants.COMM_TYPE_ID), null);
        CommStatus status = getStatusByValue(CommunicationConstants.NEW_STATUS);
        ContactType peopleType = new ContactType(
                helper.getRequestParameterValue(CommunicationConstants.COMM_PEOPLE_TYPE_ID), null);
        Long locTypeId = NumberUtil.stringToLong(helper.getRequestParameterValue(CommunicationConstants.COMM_LOC_TYPE_ID));
        LocationType locType = new LocationType(locTypeId, null);
        Communication newComm = getCommService()
                .addCommunication(name, notes, fromDate, toDate, dueDate, active, urlTitle, url,
                        commType, status,
                        peopleType, locType, null, null);

        CommRecipient commRecipient = getDefaultCommRecipientSearchCriteria(newComm);
        helper.setRequestAttributeValue(CommunicationConstants.COMM_RECIPIENT_CRITERIA, commRecipient);
        setReferenceDataInHelper(helper);
        helper.setRequestAttributeValue(CommunicationConstants.COMMUNICATION, newComm);
        helper.forward(CommunicationConstants.COMM_JSP);
    }

    public void copyCommunication(UCCHelper helper) throws IOException {
        String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
        Communication comm = this.getCommService().lookupCommunicationById(commId);
        Communication newComm = getCommService()
                .addCommunication(comm.getName(), comm.getNotes(), comm.getFromDate(), comm.getToDate(), comm.getDueDate(),
                        "Y", comm.getUrlTitle(), comm.getUrl(), comm.getCommType(), getStatusByValue(CommunicationConstants.NEW_STATUS), comm.getLocConRelType(),
                        comm.getBpLocRelType(), commId, null);

        CommRecipient commRecipient = getDefaultCommRecipientSearchCriteria(newComm);
        helper.setRequestAttributeValue(CommunicationConstants.COMM_RECIPIENT_CRITERIA, commRecipient);
        setReferenceDataInHelper(helper);
        helper.setRequestAttributeValue(CommunicationConstants.COMMUNICATION, newComm);
        helper.forward(CommunicationConstants.COMM_JSP);
    }

    public void deactivateSelectedCommunications(UCCHelper helper) throws IOException {
        List<String> selectedIds = getSelectedCommIds(helper);
        this.getCommService().deactivateSelectedCommunications(selectedIds);
        setupDataInHelper(helper, "My");
        helper.forward(CommunicationConstants.LIST_COMM_JSP);
    }

    public void setStatusToClosed(UCCHelper helper) throws IOException {
        String commId = helper.getRequestParameterValue(CommunicationConstants.COMM_ID);
        Communication comm = this.getCommService().lookupCommunicationById(commId);
        CommStatus closedStatus = getStatusByValue(CommunicationConstants.CLOSED_STATUS);
        comm = updateCommStatus(comm, closedStatus);
        setRequestAttributesInHelper(helper, comm);
        helper.forward(CommunicationConstants.COMM_JSP);
    }

    private void setupDataInHelper(UCCHelper helper, String scope) {
        setReferenceDataInHelper(helper);
        helper.setRequestAttributeValue(HRPMainConstants.SCOPE, scope);
    }

    private List<String> getSelectedCommIds(UCCHelper helper) throws IOException {
        if (isAllSelected()) {
            List<Communication> communications = getCommunications(helper);
            List<String> selectedIds = new ArrayList<String>();
            for (Communication comm : communications) {
                selectedIds.add(comm.getId());
            }
            List<String> idsToExclude = getIdsToExclude();
            for (String id : idsToExclude) {
                selectedIds.remove(id);
            }
            return selectedIds;
        } else {
            return getSelectedIds();
        }
    }

    private List<Communication> getCommunications(UCCHelper helper) throws IOException {
        CommunicationDataSource ds = getCommunicationDataSource(helper);
        XmlDataSource filteredSource = new FilteredXmlDataSource(ds, getFilterValue());
        return (List<Communication>) filteredSource.getData();
    }

    //This method has protected access only for testing
    protected CommunicationDataSource getCommunicationDataSource(UCCHelper helper) {
        return new CommunicationDataSource(helper);
    }

    private Date getDate(String dateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            logger.error("Unable to parse communication period");
        }
        return null;
    }

}