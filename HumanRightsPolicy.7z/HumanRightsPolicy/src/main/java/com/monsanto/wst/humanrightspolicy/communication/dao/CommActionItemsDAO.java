package com.monsanto.wst.humanrightspolicy.communication.dao;

import com.monsanto.wst.humanrightspolicy.model.Action;
import org.w3c.dom.Document;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 29, 2008
 * Time: 12:20:08 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CommActionItemsDAO {
  void addActionItem(String commID, String actionID);
  List<Action> lookupActionItemsByCommId(String id);
  Document lookupActionItemsByCommIdAsXML(String id);
  Document getActionItemsAsXML(List<Action> actions);
}
