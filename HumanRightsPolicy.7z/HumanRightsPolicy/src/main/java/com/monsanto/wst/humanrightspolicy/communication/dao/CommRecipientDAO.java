/*
 CommRecipientDAO was created on Jun 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.dao;

import com.monsanto.wst.humanrightspolicy.model.CommRecipient;

import java.util.List;

/**
 * Filename:    $RCSfile: CommRecipientDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-09-03 13:49:02 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public interface CommRecipientDAO {

  List<CommRecipient> lookupRecipientsByCommId(String commId);

  List<CommRecipient> lookupRecipientsNotAssociatedWithThisCommunicationByCriteria(CommRecipient commRecipient);
  
    void updateDoneFlagForRecipient(String commId, String recipientId, String doneFlag);

  void deleteAllRecipients(String commId);

  void updateDoneFlagForAllRecipients(String commId, String doneFlag);

  List<String> lookupRecipientsNotMarkedAsDone(String commId);

  void addRecipient(String commId, String recipientId);

  List<CommRecipient> lookupRecipientsForCommunicationByCriteria(CommRecipient criteria);

  void addRecipients(String commId, List<CommRecipient> recipients);

  void updateDoneFlagForSelectedRecipients(String commId, List<String> selectedIds, String doneFlag);

  void deleteSelectedRecipients(String commId, List<String> selectedRecipientIds);
}