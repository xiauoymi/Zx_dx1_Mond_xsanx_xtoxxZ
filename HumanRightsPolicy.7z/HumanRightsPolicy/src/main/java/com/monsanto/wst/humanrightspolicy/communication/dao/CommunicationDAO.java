/*
 CommunicationDAO was created on Apr 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.dao;

import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-10-17 15:36:23 $
 *
 * @author sspati1
 * @version $Revision: 1.20 $
 */
public interface CommunicationDAO {
  List<Communication> lookupCommunicationByCriteria(CommunicationSearchCriteria criteria);

  Communication lookupCommunicationById(String commId);

  void updateCommunication(String commId, String name, String notes, Date fromDate, Date toDate, Date dueDate,
                           String active,
                           String urlTitle, String url, CommType commType, CommStatus status,
                           ContactType peopleType,
                           LocationType locType,
                           Date dateCompleted);

  String addCommunication(String name, String notes, Date fromDate, Date toDate, Date dueDate, String active,
                          String urlTitle, String url, CommType commType, CommStatus status, ContactType peopleType,
                          LocationType locType, String copiedFromCommId, Date dateCompleted);

  List<CommType> lookupCommunicationTypes();

  List<CommStatus> lookupCommunicationStatuses();

  List<Communication> lookupCommunicationsByBPId(String bpId);

  List<Communication> lookupCommunicationsByLocationId(String locationId);

  List<Communication> lookupCommunicationsByContactId(String contactId);

  void deactivateSelectedCommunications(List<String> selectedIds);

  List<Communication> lookupMyCommunications();
}