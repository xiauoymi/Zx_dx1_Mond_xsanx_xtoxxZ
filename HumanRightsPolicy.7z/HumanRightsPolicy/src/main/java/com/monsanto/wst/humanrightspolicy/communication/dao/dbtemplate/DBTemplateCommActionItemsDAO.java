package com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommActionItemsDAO;
import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.model.CommActionItemsImpl;
import com.monsanto.wst.humanrightspolicy.utils.NumberUtil;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 29, 2008
 * Time: 12:30:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class DBTemplateCommActionItemsDAO implements CommActionItemsDAO {
  private DBTemplate template;
  private GenericDAO<Action, Long> actionDAO;

  public DBTemplateCommActionItemsDAO() {
  }

  public DBTemplateCommActionItemsDAO(DBTemplate template, GenericDAO<Action, Long> actionDAO) {
    this.template = template;
    this.actionDAO = actionDAO;
  }


//create table comm_actionItem (
//comm_actionItem_id number(10,0) not null,
//comm_id number(10,0) not null,
//action_id number(10, 0) not null,
//constraint pk_comm_actionItem primary key (comm_actionItem_id),
//constraint fk_comm_id foreign key(comm_id) references communication(comm_id),
//constraint fk_action_id foreign key(action_id) references action(id));
  public void addActionItem(String commID, String actionID) {
    String id = getNextId();
    TempCommActionItem commActionItem = new TempCommActionItem(id, commID, actionID);
    this.template.executeInsert("addActionItemToComm", commActionItem);
  }

  public List<Action> lookupActionItemsByCommId(String commId) {
    List<Action> actions = new ArrayList<Action>();
    List<CommActionItemsImpl> actionItems = this.template.executeListResultQuery("lookupActionsByCommId", commId);
    if(actionItems != null) {
      addActionItemsOnCommToList(actions, actionItems);
    }
    return actions;
  }

  private void addActionItemsOnCommToList(List<Action> actions, List<CommActionItemsImpl> actionItems) {
    for(CommActionItemsImpl actionIds : actionItems) {
      Long id =  NumberUtil.stringToLong(actionIds.getActionId());
      Action action =  actionDAO.findByPrimaryKey(id);
      if(action != null)
        actions.add(action);
    }
  }

  public Document lookupActionItemsByCommIdAsXML(String commId) {
    List<Action> actions = lookupActionItemsByCommId(commId);
    return getActionItemsAsXML(actions);
  }

  public Document getActionItemsAsXML(List<Action> actions) {
    StringBuffer actionStrBuffer = new StringBuffer("<actionsList>");

    for(Action action : actions) {
      actionStrBuffer.append(action.toXml());
    }
    try {
      if(!"<actionsList>".equals(actionStrBuffer.toString())) {
        actionStrBuffer.append("</actionsList>");
        return DOMUtil.stringToXML(actionStrBuffer.toString());
      }
    } catch (ParserException e) {
//      e.printStackTrace();
    } catch (IOException e) {
//      e.printStackTrace();
    }
    return DOMUtil.newDocument();
  }

  private String getNextId() {
    return this.template.executeSingleResultQuery("lookupNextSequenceId").toString();
  }
}
