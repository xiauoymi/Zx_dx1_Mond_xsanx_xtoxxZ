/*
 DBTemplateCommRecipientDAO was created on Jun 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.model.CommRecipient;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: DBTemplateCommRecipientDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-09-03 13:49:02 $
 *
 * @author sspati1
 * @version $Revision: 1.9 $
 */
public class DBTemplateCommRecipientDAO implements CommRecipientDAO {
  private final DBTemplate template;

  public DBTemplateCommRecipientDAO(DBTemplate template) {
    this.template = template;
  }

  public List<CommRecipient> lookupRecipientsByCommId(String commId) {
    return this.template.executeListResultQuery("lookupRecipientsByCommId", commId);
  }

  public List<CommRecipient> lookupRecipientsNotAssociatedWithThisCommunicationByCriteria(CommRecipient criteria) {
    return this.template.executeListResultQuery("lookupRecipientsNotAssociatedWithThisCommunicationByCriteria", criteria);
  }

  public List<CommRecipient> lookupRecipientsForCommunicationByCriteria(CommRecipient criteria) {
    return this.template.executeListResultQuery("lookupRecipientsForCommunicationByCriteria", criteria);
  }

  public void updateDoneFlagForRecipient(String commId, String recipientId, String doneFlag) {
    TempCommRecipient commRecipient = new TempCommRecipient(null, commId, recipientId, doneFlag);
    this.template.executeUpdate("updateDoneFlagForRecipient", commRecipient);
  }

  public void updateDoneFlagForSelectedRecipients(String commId, List<String> selectedIds, String doneFlag
  ) {
    List<TempCommRecipient> commRecipientsList = new ArrayList<TempCommRecipient>();
    for(String id: selectedIds){
      commRecipientsList.add(new TempCommRecipient(null, commId, id, doneFlag));
    }
    this.template.executeUpdate("updateDoneFlagForRecipient", commRecipientsList);

  }

  public void updateDoneFlagForSelectedRecipient(String commId, String recipientId, String doneFlag) {
    TempCommRecipient commRecipient = new TempCommRecipient( null, commId, recipientId, doneFlag);
    this.template.executeUpdate("updateDoneFlagForRecipient", commRecipient);
  }

  public void updateDoneFlagForAllRecipients(String commId, String doneFlag) {
    TempCommRecipient commRecipient = new TempCommRecipient(null, commId, null, doneFlag);
    this.template.executeUpdate("updateDoneFlagForAllRecipients", commRecipient);
  }

  public List<String> lookupRecipientsNotMarkedAsDone(String commId) {
    return this.template.executeListResultQuery("lookupRecipientsByCommIdNotMarkedAsDone", commId);
  }

  public void deleteAllRecipients(String commId) {
    this.template.executeDelete("deleteAllRecipientsForCommunication", commId);
  }

  public void deleteSelectedRecipients(String commId, List<String> selectedRecipientIds) {
    List<TempCommRecipient> commRecipientsList = new ArrayList<TempCommRecipient>();
    for(String id: selectedRecipientIds){
      commRecipientsList.add(new TempCommRecipient(null, commId, id, null));
    }
    this.template.executeDelete("deleteRecipient", commRecipientsList);
  }

  public void addRecipient(String commId, String recipientId) {
    String id = getNextId();
    TempCommRecipient commRecipient = new TempCommRecipient(id, commId, recipientId, "N");
    this.template.executeInsert("addRecipient", commRecipient);
  }

  public void addRecipients(String commId, List<CommRecipient> recipients) {
    for(CommRecipient recipient: recipients){
      addRecipient(commId, recipient.getContactId());
    }
  }

  private String getNextId() {
    return this.template.executeSingleResultQuery("lookupNextSequenceId").toString();
  }
}