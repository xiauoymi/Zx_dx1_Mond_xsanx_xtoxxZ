/*
 DBTemplateCommunicationDAO was created on Apr 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: DBTemplateCommunicationDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-10-17 15:36:23 $
 *
 * @author sspati1
 * @version $Revision: 1.26 $
 */
public class DBTemplateCommunicationDAO implements CommunicationDAO {
    private final DBTemplate template;
    private GenericDAO<CommStatus, Long> commStatusDAO;
    private GenericDAO<CommType, Long> commTypeDAO;

    public DBTemplateCommunicationDAO(DBTemplate template, GenericDAO<CommStatus, Long> commStatusDAO, GenericDAO<CommType, Long> commTypeDAO) {
        this.template = template;
        this.commStatusDAO = commStatusDAO;
        this.commTypeDAO = commTypeDAO;
    }

    public List<Communication> lookupMyCommunications() {
        return this.template.executeListResultQuery("lookupMyCommunications");
    }

    public List<Communication> lookupCommunicationByCriteria(CommunicationSearchCriteria criteria) {
        return this.template.executeListResultQuery("lookupCommunicationsByCriteria", criteria);
    }

    public Communication lookupCommunicationById(String commId) {
        return (Communication) this.template.executeSingleResultQuery("lookupCommunicationById", commId);
    }

    public void updateCommunication(String commId, String name, String notes, Date fromDate, Date toDate,
                                    Date dueDate, String active, String urlTitle, String url, CommType commType,
                                    CommStatus status,
                                    ContactType peopleType,
                                    LocationType locType, Date dateCompleted) {
        TempCommunication comm = new TempCommunication(commId, name, notes, fromDate, toDate, dueDate, active, urlTitle, url,
                commType, status, peopleType, locType, null, dateCompleted);
        this.template.executeUpdate("updateCommunication", comm);
    }

    public String addCommunication(String name, String notes, Date fromDate, Date toDate, Date dueDate, String active,
                                   String urlTitle, String url, CommType commType, CommStatus status,
                                   ContactType peopleType,
                                   LocationType locType,
                                   String copiedFromCommId, Date dateCompleted) {
        String id = getNextId();
        TempCommunication comm = new TempCommunication(id, name, notes, fromDate, toDate, dueDate, active, urlTitle, url,
                commType, status, peopleType, locType, copiedFromCommId, dateCompleted);
        this.template.executeInsert("addCommunication", comm);
        return id;
    }

    public void deactivateSelectedCommunications(List<String> selectedIds) {
        List<TempCommunication> tempComms = new ArrayList<TempCommunication>();
        for (String commId : selectedIds) {
            tempComms.add(new TempCommunication(commId));
        }
        this.template.executeUpdate("deactivateCommunication", tempComms);
    }

    public List<CommType> lookupCommunicationTypes() {
        return commTypeDAO.findAll();
    }

    public List<CommStatus> lookupCommunicationStatuses() {
        return commStatusDAO.findAll();
    }

    public List<Communication> lookupCommunicationsByBPId(String bpId) {
        return this.template.executeListResultQuery("lookupCommunicationsByBPId", bpId);
    }

    public List<Communication> lookupCommunicationsByLocationId(String locationId) {
        return this.template.executeListResultQuery("lookupCommunicationsByLocationId", locationId);
    }

    public List<Communication> lookupCommunicationsByContactId(String contactId) {
        return this.template.executeListResultQuery("lookupCommunicationsByContactId", contactId);
    }

    private String getNextId() {
        return this.template.executeSingleResultQuery("lookupNextSequenceId").toString();
    }
}