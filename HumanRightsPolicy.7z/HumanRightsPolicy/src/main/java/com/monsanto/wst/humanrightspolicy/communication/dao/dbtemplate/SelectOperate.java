/*
 SelectOperate was created on Jul 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate;

import java.util.List;

/**
 * Filename:    $RCSfile: SelectOperate.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-22 21:42:25 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class SelectOperate {
  private final List cms;
  private final String filterValue;
  private final boolean isAllSelected;
  private final String[] selectedIds;
  private final String[] idsToExclude;

  public SelectOperate(List cms, String filterValue, boolean isAllSelected, String[] selectedIds, String[] idsToExclude){
    this.cms = cms;
    this.filterValue = filterValue;
    this.isAllSelected = isAllSelected;
    this.selectedIds = selectedIds;
    this.idsToExclude = idsToExclude;
  }

  public String getFilterValue() {
    return filterValue;
  }

  public List getCms() {
    return cms;
  }

  public boolean isAllSelected() {
    return isAllSelected;
  }

  public String[] getSelectedIds() {
    return selectedIds;
  }

  public String[] getIdsToExclude() {
    return idsToExclude;
  }
}