package com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 29, 2008
 * Time: 3:37:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class TempCommActionItem {
  public String getCommID() {
    return commID;
  }

  public void setCommID(String commID) {
    this.commID = commID;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getActionID() {
    return actionID;
  }

  public void setActionID(String actionID) {
    this.actionID = actionID;
  }

  private String id;
  private String commID;
  private String actionID;

  public TempCommActionItem(String id, String commID, String actionID) {
    this.id = id;
    this.commID = commID;
    this.actionID = actionID;
  }
}
