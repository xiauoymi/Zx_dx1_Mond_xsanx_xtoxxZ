package com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate;

/*
 TempCommRecipient was created on May 22, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class TempCommRecipient {
  private final String commRecipientId;
  private final String commId;
  private final String recipientId;
  private final String isDone;

  public TempCommRecipient(
      String commRecipientId,
      String commId,
      String recipientId, String isDone
  ) {
    this.commRecipientId = commRecipientId;
    this.commId = commId;
    this.recipientId = recipientId;
    this.isDone = isDone;
  }

  public String getCommRecipientId() {
    return commRecipientId;
  }

  public String getCommId() {
    return commId;
  }

  public String getRecipientId() {
    return recipientId;
  }

  public String getIsDone() {
    return isDone;
  }
}
