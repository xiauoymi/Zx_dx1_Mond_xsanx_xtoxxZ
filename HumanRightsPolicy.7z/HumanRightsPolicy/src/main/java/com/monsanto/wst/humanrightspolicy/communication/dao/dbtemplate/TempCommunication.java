package com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate;

import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.Date;
/*
 TempCommunication was created on May 22, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class TempCommunication {
  private final String commId;
  private String name;
  private String notes;
  private Date fromDate;
  private Date toDate;
  private Date dueDate;
  private String active;
  private String urlTitle;
  private String url;
  private CommType commType;
  private CommStatus status;
  private ContactType locConRelType;
  private LocationType bpLocRelType;
  private String copiedFromCommId;
  private Date dateCompleted;

  public TempCommunication(String commId) {
    this.commId = commId;
  }

  public TempCommunication(String commId, String name, String notes, Date fromDate,
                           Date toDate, Date dueDate, String active, String urlTitle, String url, CommType commType,
                           CommStatus status,
                           ContactType peopleType, LocationType locType, String copiedFromCommId, Date dateCompleted) {

    this.commId = commId;
    this.name = name;
    this.notes = notes;
    this.fromDate = fromDate;
    this.toDate = toDate;
    this.dueDate = dueDate;
    this.active = active;
    this.urlTitle = urlTitle;
    this.url = url;
    this.commType = commType;
    this.status = status;
    this.locConRelType = peopleType;
    this.bpLocRelType = locType;
    this.copiedFromCommId = copiedFromCommId;
    this.dateCompleted = dateCompleted;
  }

  public String getCommId() {
    return commId;
  }

  public String getName() {
    return name;
  }

  public String getNotes() {
    return notes;
  }

  public Date getFromDate() {
    return fromDate;
  }

  public Date getToDate() {
    return toDate;
  }

  public Date getDueDate() {
    return dueDate;
  }

  public String getActive() {
    return active;
  }

  public String getUrlTitle() {
    return urlTitle;
  }

  public String getUrl() {
    return url;
  }

  public CommType getCommType() {
    return commType;
  }

  public CommStatus getStatus() {
    return status;
  }

  public ContactType getLocConRelType() {
    return locConRelType;
  }

  public LocationType getBpLocRelType() {
    return bpLocRelType;
  }

  public String getCopiedFromCommId() {
    return copiedFromCommId;
  }

  public Date getDateCompleted() {
    return dateCompleted;
  }
}
