package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.action.datasource.ActionDataSource;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.io.IOException;
import java.util.List;

/**
 * User: afhyat
 * Date: Oct 2, 2008
 * Time: 9:44:17 AM
 */
public class ActionItemsOnCommDataSource extends ActionDataSource {
  private final CommunicationService communciationService;

  public ActionItemsOnCommDataSource(UCCHelper helper, CommunicationService communciationService) {
    super(helper);
    this.communciationService = communciationService;
  }

  public ActionItemsOnCommDataSource(UCCHelper helper) {
    this(helper, InitService.initCommunicationService());
  }

  public List<Action> getData() throws IOException {
    String commId = params.get(CommunicationConstants.COMM_ID);
    return communciationService.getActionItemsAsList(commId);
  }

  public boolean isFiltered() {
    return false;
  }

  public CommunicationService getCommunicationService() {
    return communciationService;
  }
}
