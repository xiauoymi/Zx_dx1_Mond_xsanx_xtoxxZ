/*
 CommunicationComparator was created on Apr 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.wst.humanrightspolicy.model.Communication;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: CommunicationComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-05-15 15:26:55 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public abstract class CommunicationComparator implements Comparator<XmlObject> {
  protected abstract String getValue(Communication comm);

  public int compare(XmlObject o1, XmlObject o2) {
    if (o1 instanceof Communication && o2 instanceof Communication) {
      return compareComm((Communication ) o1, (Communication ) o2);
    } else {
      return 0;
    }
  }

  public int compareComm(Communication comm1, Communication comm2) {
    String value1 = blankIfNull(getValue(comm1));
    String value2 = blankIfNull(getValue(comm2));
    return value1.compareTo(value2);
  }

  public String blankIfNull(String st) {
    if (st == null) {
      return "";
    } else {
      return st;
    }
  }
}