/*
 CommunicationDataSource was created on Apr 28, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.datasource.ComparatorMap;
import com.monsanto.wst.humanrightspolicy.datasource.DataSource;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.humanrightspolicy.utils.NumberUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-12-04 16:49:57 $
 *
 * @author sspati1
 * @version $Revision: 1.21 $
 */
public class CommunicationDataSource implements XmlDataSource {
    private static final Log logger = LogFactory.getLog(CommunicationDataSource.class);
    public static final String FROM_PERIOD_SORT_KEY = "fromPeriod";
    public static final String COMM_TYPE_SORT_KEY = "commTypeValue";
    public static final String COMM_NAME_SORT_KEY = "name";
    public static final String RECIPIENT_TYPE_SORT_KEY = "recipientTypeValue";
    public static final String LOC_TYPE_SORT_KEY = "locTypeValue";
    public static final String DUE_DATE_SORT_KEY = "dueDate";

    public static final String STATUS_SORT_KEY = "status";
    private final CommunicationService commService;

    protected final ParameterCollection params;
    private static final ComparatorMap<XmlObject> comparatorMap;

    static {
        comparatorMap = new ComparatorMap<XmlObject>(new CommunicationDefaultComparator());
        comparatorMap.addComparator(FROM_PERIOD_SORT_KEY, new CommunicationFromPeriodComparator());
        comparatorMap.addComparator(COMM_TYPE_SORT_KEY, new CommunicationTypeComparator());
        comparatorMap.addComparator(COMM_NAME_SORT_KEY, new CommunicationNameComparator());
        comparatorMap.addComparator(RECIPIENT_TYPE_SORT_KEY, new CommunicationRecipientTypeComparator());
        comparatorMap.addComparator(LOC_TYPE_SORT_KEY, new CommunicationLocationTypeComparator());
        comparatorMap.addComparator(STATUS_SORT_KEY, new CommunicationStatusComparator());
        comparatorMap.addComparator(DUE_DATE_SORT_KEY, new CommunicationDueDateComparator());
    }

    public CommunicationDataSource(ParameterCollection params, CommunicationService commService) {
        this.params = params;
        this.commService = commService;
    }

    public CommunicationDataSource(UCCHelper helper, CommunicationService commService) {
        this(new UCCHelperParameterCollection(helper), commService);
    }

    public CommunicationDataSource(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initCommunicationService());
    }

    public CommunicationDataSource(ParameterCollection params) {
        this(params, InitService.initCommunicationService());
    }

    public List<? extends XmlObject> getData() throws IOException {
        String scope = params.get(HRPMainConstants.SCOPE);
        boolean myScope = "My".equalsIgnoreCase(scope);
        if (myScope) {
            return getMyCommunications();
        } else {
            return getCommunicationsByCriteria();
        }
    }

    public Comparator<XmlObject> getComparator(String sortKey) {
        return comparatorMap.getComparator(sortKey);
    }

    private List<Communication> getMyCommunications() {
        return this.commService.lookupMyCommunications();
    }

    private List<Communication> getCommunicationsByCriteria() throws IOException {
        String name = nullIfBlank(params.get(CommunicationConstants.COMM_NAME));
        Date dueDateFrom = getDate(params.get(CommunicationConstants.SEARCH_DUE_DATE_FROM));
        Date dueDateTo = getDate(params.get(CommunicationConstants.SEARCH_DUE_DATE_TO));
        Long commTypeId = NumberUtil.stringToLong(params.get(CommunicationConstants.COMM_TYPE_ID));
        Long commStatusId = NumberUtil.stringToLong(params.get(CommunicationConstants.COMM_STATUD_ID));
        Long locConRelTypeId = NumberUtil.stringToLong(params.get(CommunicationConstants.COMM_PEOPLE_TYPE_ID));
        Long bpLocRelTypeId = NumberUtil.stringToLong(params.get(CommunicationConstants.COMM_LOC_TYPE_ID));
        Communication comm = new CommunicationImpl(null, name, null, null, null, null, null, null, null,
                commTypeId,
                null, commStatusId, null, locConRelTypeId, null, bpLocRelTypeId, null, null, null);
        String stateId = nullIfBlank(params.get(HRPMainConstants.COMPANY_STATE));
        String countryId = nullIfBlank(params.get(HRPMainConstants.COMPANY_COUNTRY));
        String regionId = nullIfBlank(params.get(HRPMainConstants.REGION));
        CommunicationSearchCriteria criteria = new CommunicationSearchCriteria(comm, dueDateFrom, dueDateTo,
                stateId, countryId, regionId);
        return this.commService.lookupCommunicationByCriteria(criteria);
    }

    private Date getDate(String dateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            logger.error("Unable to parse communication period");
        } catch (NullPointerException e) {
            logger.error("Unable to parse communication period");
        }
        return null;
    }

    private String nullIfBlank(String st) {
        if (st == null || st.length() == 0) {
            return null;
        } else {
            return st;
        }
    }

    public boolean isSorted() {
        return false;
    }

    public boolean isFiltered() {
        return false;
    }

    public int getTotalRecords() {
        return DataSource.UNKNOWN_RECORD_COUNT;
    }
}