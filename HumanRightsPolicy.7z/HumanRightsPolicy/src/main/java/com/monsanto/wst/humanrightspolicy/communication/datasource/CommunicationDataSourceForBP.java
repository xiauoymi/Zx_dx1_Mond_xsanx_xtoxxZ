/*
 CommunicationDataSourceForBP was created on Jun 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.ParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.UCCHelperParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationDataSourceForBP.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-12-04 16:49:57 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class CommunicationDataSourceForBP extends CommunicationDataSource {
    private static final Log logger = LogFactory.getLog(CommunicationDataSourceForBP.class);
    private final LookupBPService lookupBPService;

    public CommunicationDataSourceForBP(ParameterCollection params) {
        this(params, InitService.initSearchBPService());
    }

    public CommunicationDataSourceForBP(ParameterCollection params, LookupBPService lookupBPService) {
        super(params);
        this.lookupBPService = lookupBPService;
    }

    public CommunicationDataSourceForBP(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initSearchBPService());
    }

    public CommunicationDataSourceForBP(UCCHelper helper, LookupBPService lookupBPService) {
        this(new UCCHelperParameterCollection(helper), lookupBPService);
    }

    public List<? extends XmlObject> getData() throws IOException {
        try {
            return getCommunicationsForBP();
        } catch (RuntimeException e) {
            logger.error("Unable to getData: ", e);
            throw e;
        }
    }

    private List<? extends XmlObject> getCommunicationsForBP() throws IOException {
        String bpId = params.get(BusinessPartnerConstants.BUSINESS_PARTNER_ID);
        BusinessPartner bp = this.lookupBPService.lookupBPById(bpId);
        return bp.getCommunications();
    }
}