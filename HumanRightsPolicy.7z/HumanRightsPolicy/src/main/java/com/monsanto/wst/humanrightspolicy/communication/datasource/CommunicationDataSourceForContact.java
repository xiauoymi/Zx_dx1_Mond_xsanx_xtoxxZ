/*
 CommunicationDataSourceForContact was created on Jun 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.contact.constants.ContactConstants;
import com.monsanto.wst.humanrightspolicy.contact.service.LookupContactService;
import com.monsanto.wst.humanrightspolicy.model.ContactInfo;
import com.monsanto.wst.humanrightspolicy.model.ParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.UCCHelperParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationDataSourceForContact.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * sspati1 $    	 On:	$Date: 2008-12-04 16:49:57 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class CommunicationDataSourceForContact extends CommunicationDataSource {
    private final LookupContactService contactService;

    public CommunicationDataSourceForContact(ParameterCollection params) {
        this(params, InitService.initLookupContactService());
    }

    public CommunicationDataSourceForContact(ParameterCollection params, LookupContactService contactService) {
        super(params);
        this.contactService = contactService;
    }

    public CommunicationDataSourceForContact(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initLookupContactService());
    }

    public CommunicationDataSourceForContact(UCCHelper helper, LookupContactService contactService) {
        this(new UCCHelperParameterCollection(helper), contactService);
    }

    public List<? extends XmlObject> getData() throws IOException {
        return getCommunicationsForContact();
    }

    private List<? extends XmlObject> getCommunicationsForContact() throws IOException {
        String contactId = params.get(ContactConstants.CONTACT_ID);
        ContactInfo contact = this.contactService.lookupContactById(contactId);
        return contact.getCommunications();
    }
}