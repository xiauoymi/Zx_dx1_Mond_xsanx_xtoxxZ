/*
 CommunicationDataSourceForLocation was created on Jun 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.model.Location;
import com.monsanto.wst.humanrightspolicy.model.ParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.UCCHelperParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationDataSourceForLocation.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-12-04 16:49:57 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class CommunicationDataSourceForLocation extends CommunicationDataSource {
    private static final Log logger = LogFactory.getLog(CommunicationDataSourceForLocation.class);
    private final LocationService locService;

    public CommunicationDataSourceForLocation(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initLocationService());
    }

    public CommunicationDataSourceForLocation(UCCHelper helper, LocationService locService) {
        this(new UCCHelperParameterCollection(helper), locService);
    }

    public CommunicationDataSourceForLocation(ParameterCollection params) {
        this(params, InitService.initLocationService());
    }

    public CommunicationDataSourceForLocation(ParameterCollection params, LocationService locService) {
        super(params);
        this.locService = locService;
    }

    public List<? extends XmlObject> getData() throws IOException {
        try {
            return getCommunicationsForLocation();
        } catch (RuntimeException e) {
            logger.error("Unable to getData: ", e);
            throw e;
        }
    }

    private List<? extends XmlObject> getCommunicationsForLocation() throws IOException {
        String locId = params.get(LocationsConstants.LOCATION_ID);
        Location location = this.locService.lookupLocationById(locId);
        return location.getCommunications();
    }

}