/*
 CommunicationDueDateComparator was created on Jul 16, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.wst.humanrightspolicy.model.Communication;

/**
 * Filename:    $RCSfile: CommunicationDueDateComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-07-16 15:20:15 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class CommunicationDueDateComparator extends CommunicationComparator{
  protected String getValue(Communication comm) {
    return comm.getFormattedDueDate();
  }
}