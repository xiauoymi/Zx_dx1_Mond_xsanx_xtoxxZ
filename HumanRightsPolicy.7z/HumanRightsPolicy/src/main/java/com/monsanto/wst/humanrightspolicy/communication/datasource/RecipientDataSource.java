/*
 RecipientDataSource was created on Apr 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.datasource.ComparatorMap;
import com.monsanto.wst.humanrightspolicy.datasource.DataSource;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.humanrightspolicy.utils.NumberUtil;
import com.monsanto.wst.textutil.TextUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Filename:    $RCSfile: RecipientDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date:
 * 2008/05/12 18:13:32 $
 *
 * @author sspati1
 * @version $Revision: 1.21 $
 */
public class RecipientDataSource implements XmlDataSource {
    private final ParameterCollection params;
    private final CommunicationService commService;
    public static final String NAME_SORT_KEY = "name";
    public static final String RECIPIENT_TYPE_VALUE_SORT_KEY = "recipientTypeValue";
    public static final String COMPANY_SORT_KEY = "company";
    public static final String STATE_SORT_KEY = "state";
    public static final String COUNTRY_SORT_KEY = "country";
    public static final String REGION_SORT_KEY = "region";
    private static final ComparatorMap<XmlObject> comparatorMap;

    static {
        comparatorMap = new ComparatorMap<XmlObject>(new RecipientDefaultComparator());
        comparatorMap.addComparator(NAME_SORT_KEY.toLowerCase(), new RecipientNameComparator());
        comparatorMap.addComparator(RECIPIENT_TYPE_VALUE_SORT_KEY.toLowerCase(), new RecipientTypeComparator());
        comparatorMap.addComparator(COMPANY_SORT_KEY.toLowerCase(), new RecipientCompanyComparator());
        comparatorMap.addComparator(STATE_SORT_KEY.toLowerCase(), new RecipientStateComparator());
        comparatorMap.addComparator(COUNTRY_SORT_KEY.toLowerCase(), new RecipientCountryComparator());
        comparatorMap.addComparator(REGION_SORT_KEY.toLowerCase(), new RecipientRegionComparator());
    }

    public RecipientDataSource(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initCommunicationService());
    }

    public RecipientDataSource(UCCHelper helper, CommunicationService commService) {
        this(new UCCHelperParameterCollection(helper), commService);
    }

    public RecipientDataSource(ParameterCollection params) {
        this(params, InitService.initCommunicationService());

    }

    public RecipientDataSource(ParameterCollection params, CommunicationService commService) {
        this.params = params;
        this.commService = commService;
    }


    public List<? extends XmlObject> getData() throws IOException {
        String scope = params.get(HRPMainConstants.SCOPE);
        String commId = params.get(CommunicationConstants.COMM_ID);
        Communication comm = this.commService.lookupCommunicationById(commId);
        if ("search".equalsIgnoreCase(scope)) {
            CommRecipient commRecipientCriteria = buildSearchCriteriaFromRequest();
            return getRecipientsList(commRecipientCriteria, comm);
        } else {
            return comm.getRecipients();
        }
    }

    public Comparator<XmlObject> getComparator(String sortKey) {
        return comparatorMap.getComparator(sortKey);
    }

    public CommRecipient buildSearchCriteriaFromRequest() throws IOException {
        String commId1 = params.get(CommunicationConstants.COMM_ID);
        String regionId = params.get(CommunicationConstants.REGION);
        String stateId = params.get(CommunicationConstants.STATE);
        String countryId = params.get(CommunicationConstants.COUNTRY);
        String company = TextUtil.decodeUsingUTF8(params.get(CommunicationConstants.SEARCH_COMPANY));
        String personName = TextUtil
                .decodeUsingUTF8(params.get(CommunicationConstants.SEARCH_PERSON_NAME));
        Long peopleTypeId = NumberUtil.stringToLong(params.get(CommunicationConstants.SEARCH_PEOPLE_TYPE_ID));
        Long locTypeId = NumberUtil.stringToLong(params.get(CommunicationConstants.SEARCH_LOC_TYPE_ID));
        return new CommRecipientImpl(null, null, commId1, null, personName, locTypeId, null, peopleTypeId, null, regionId,
                null,
                countryId, null, stateId, null, company, null, null, null, null, null, null, null);
    }

    private List<CommRecipient> getRecipientsList(CommRecipient commRecipientCriteria, Communication comm) {
        List<CommRecipient> recipientsNotAssociatedWithCommunication = comm
                .getRecipientsNotAssociatedWithThisCommunicationByCriteria(commRecipientCriteria);
        List<CommRecipient> recipientsAssociatedWithCommunication = comm
                .getRecipientsByCriteria(commRecipientCriteria);
        List<CommRecipient> recipientList = new ArrayList<CommRecipient>();
        recipientList.addAll(recipientsNotAssociatedWithCommunication);
        recipientList.addAll(recipientsAssociatedWithCommunication);
        Collections.sort(recipientList, new RecipientNameComparator());
        return recipientList;
    }

    public boolean isSorted() {
        return false;
    }

    public boolean isFiltered() {
        return false;
    }

    public int getTotalRecords() {
        return DataSource.UNKNOWN_RECORD_COUNT;
    }
}