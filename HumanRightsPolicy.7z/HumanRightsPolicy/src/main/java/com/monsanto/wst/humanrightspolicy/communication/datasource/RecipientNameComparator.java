/*
 RecipientNameComparator was created on Apr 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.wst.humanrightspolicy.model.CommRecipient;

/**
 * Filename:    $RCSfile: RecipientNameComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-06-19 13:48:55 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class RecipientNameComparator extends RecipientComparartor{
  protected String getValue(CommRecipient commRecipient) {
    return commRecipient.getName().toLowerCase();
  }

}