/*
 RecipientRegionComparator was created on May 8, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.wst.humanrightspolicy.model.Address;
import com.monsanto.wst.humanrightspolicy.model.Region;

/**
 * Filename:    $RCSfile: RecipientRegionComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-05-15 15:26:55 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class RecipientRegionComparator extends RecipientAddressComparator {
  protected String getValue(Address addr) {
    Region region = addr.getRegionModel();
    if (region == null) {
      return null;
    } else {
      return region.getValue();
    }
  }
}