/*
 CommunicationService was created on Apr 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.service;

import com.monsanto.wst.humanrightspolicy.model.*;
import org.w3c.dom.Document;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-10-17 15:36:23 $
 *
 * @author sspati1
 * @version $Revision: 1.19 $
 */
public interface CommunicationService {
  Communication updateCommunication(String commId, String name, String notes, Date fromDate, Date toDate, Date dueDate,
                                    String active,
                                    String urlTitle, String url, CommType commType, CommStatus status,
                                    ContactType peopleType,
                                    LocationType locType, Date dateCompleted);

  Communication lookupCommunicationById(String commId);

  List<Communication> lookupCommunicationByCriteria(CommunicationSearchCriteria criteria);

  Communication addCommunication(String name, String notes, Date fromDate, Date toDate, Date dueDate, String active,
                                 String urlTitle, String url, CommType commType, CommStatus status,
                                 ContactType peopleType,
                                 LocationType locType,
                                 String copiedFromCommId, Date dateCompleted);

  List<CommType> lookupCommunicationTypes();

  List<CommStatus> lookupCommunicationStatuses();

  void deactivateSelectedCommunications(List<String> selectedCommIds);

  List<Communication> lookupMyCommunications();

  void addActionItem(String commId, String actionID);

  List<Action> getActionItemsAsList(String commId);

  Document getActionItemsAsXML(String commId);

}