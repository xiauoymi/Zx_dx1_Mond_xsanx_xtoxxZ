/*
 CommunicationServiceImpl was created on Apr 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.service;

import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;
import org.w3c.dom.Document;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-10-17 15:36:23 $
 *
 * @author sspati1
 * @version $Revision: 1.20 $
 */
public class CommunicationServiceImpl implements CommunicationService {
  private final CommunicationDAO commDao;

  public CommunicationServiceImpl(CommunicationDAO commDao) {
    this.commDao = commDao;
  }

  public Communication updateCommunication(String commId, String name, String notes, Date fromDate, Date toDate,
                                           Date dueDate, String active, String urlTitle, String url,
                                           CommType commType, CommStatus status,
                                           ContactType peopleType, LocationType locType, Date dateCompleted) {
    this.commDao.updateCommunication(commId, name, notes, fromDate, toDate, dueDate, active, urlTitle, url, commType, status,
        peopleType, locType, dateCompleted);
    return lookupCommunicationById(commId);
  }

  public Communication addCommunication(String name, String notes, Date fromDate, Date toDate, Date dueDate,
                                        String active,
                                        String urlTitle, String url, CommType commType, CommStatus status,
                                        ContactType peopleType, LocationType locType, String copiedFromCommId,
                                        Date dateCompleted) {
    String id = this.commDao.addCommunication(name, notes, fromDate, toDate, dueDate, active, urlTitle, url, commType, status,
        peopleType, locType, copiedFromCommId, dateCompleted);
    return this.commDao.lookupCommunicationById(id);
  }

  public void deactivateSelectedCommunications(List<String> selectedCommIds) {
    this.commDao.deactivateSelectedCommunications(selectedCommIds);
  }

  public Communication lookupCommunicationById(String commId) {
    return this.commDao.lookupCommunicationById(commId);
  }

  public List<Communication> lookupMyCommunications() {
    return this.commDao.lookupMyCommunications();
  }

  public List<Communication> lookupCommunicationByCriteria(CommunicationSearchCriteria criteria) {
    return this.commDao.lookupCommunicationByCriteria(criteria);
  }

  public List<CommType> lookupCommunicationTypes() {
    return this.commDao.lookupCommunicationTypes();
  }

  public List<CommStatus> lookupCommunicationStatuses() {
    return this.commDao.lookupCommunicationStatuses();
  }

  public void addActionItem(String commId, String actionID) {
    Communication comm = lookupCommunicationById(commId);
    comm.addActionItem(actionID);
  }

  public List<Action> getActionItemsAsList(String commId) {
    Communication comm = lookupCommunicationById(commId);
    return comm.getActionItemsAsList();
  }

  public Document getActionItemsAsXML(String commId) {
    Communication comm = lookupCommunicationById(commId);
    return comm.getActionItemsAsXML();
  }
}