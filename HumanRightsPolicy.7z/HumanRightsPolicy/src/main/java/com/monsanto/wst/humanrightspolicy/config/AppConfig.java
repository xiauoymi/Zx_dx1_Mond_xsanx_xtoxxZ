package com.monsanto.wst.humanrightspolicy.config;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/*
 AppConfig was created on Aug 14, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

@Entity
@Table(schema="HRPOLICY", name="APP_CONFIG")
@NoDeleteAllowed
@AccessType("field")
public class AppConfig {
  @Id
  @Column(name="PARAM_NAME")
  private String name;

  @Column(name="PARAM_VALUE")
  private String value;

  public AppConfig() {
  }

  public AppConfig(String name, String value) {
    this.name = name;
    this.value = value;
  }

  public String getName() {
    return name;
  }

  public String getValue() {
    return value;
  }
}
