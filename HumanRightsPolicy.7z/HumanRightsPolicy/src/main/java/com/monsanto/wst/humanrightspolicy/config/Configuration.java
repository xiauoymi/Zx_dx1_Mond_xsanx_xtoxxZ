package com.monsanto.wst.humanrightspolicy.config;/*
 Configuration was created on Aug 14, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public interface Configuration {
  int getNumberOfRecentDays();
}
