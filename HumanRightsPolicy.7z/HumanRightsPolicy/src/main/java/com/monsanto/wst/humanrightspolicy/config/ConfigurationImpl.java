package com.monsanto.wst.humanrightspolicy.config;

import com.monsanto.wst.dao.GenericDAO;
/*
 ConfigurationImpl was created on Aug 14, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class ConfigurationImpl implements Configuration {
  public static final String RECENT_DAYS_PARAM = "RECENT_DAYS";

  private final GenericDAO<AppConfig, String> appConfigDAO;

  public ConfigurationImpl(GenericDAO<AppConfig, String> appConfigDAO) {
    this.appConfigDAO = appConfigDAO;
  }

  public int getNumberOfRecentDays() {
    String value = appConfigDAO.findByPrimaryKey(RECENT_DAYS_PARAM).getValue();
    return Integer.parseInt(value);
  }
}
