package com.monsanto.wst.humanrightspolicy.constants;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Jun 15, 2006 Time: 9:43:47 AM To change this template use File |
 * Settings | File Templates.
 */
public class HRPMainConstants {

    ///CLOVER:OFF
    private HRPMainConstants() {
    }
///CLOVER:ON

    public static final String HRIC_URL_PROPERTY = "hricurl";
    public static final String HRIC_URL_ATTRIBUTE = "hricUrl";
    public static final String LOGINUSER = "LOGINUSER";
    public static final String LSI_FUNCTION = "lsiFunction";
    public static final String ACTIVE_TAB_INDEX = "activeTabIndex";
    public static final String SUCCESS_LIST = "successList";
    public static final String ERROR_LIST = "errorList";

    public static final String BUSINESS_NAME = "businessName";
    public static final String ALIAS_NAME = "aliasName";
    public static final String ACTIVE_DATE = "activeDate";
    public static final String INACTIVE_DATE = "inactiveDate";

    public static final String SELECTED_COUNTRY_ID = "selectedCountryId";
    public static final String SELECTED_COUNTRY_NAME = "selectedCountryName";

    public static final String COMPANY_STATE = "state";
    public static final String COMPANY_COUNTRY = "country";
    public static final String REGION = "region";
    public static final String COUNTRY = "country";

    public static final String METHOD = "method";

    public static final String CONTACT_ID = "contactId";
    public static final String HRP_ERROR_JSP = "/WEB-INF/jsp/common/error.jsp";
    public static final String HRP_HOME_JSP = "/WEB-INF/jsp/common/home.jsp";

    public static final String HRP_SESSION_TIMEOUT_JSP = "/WEB-INF/jsp/common/sessionTimeout.jsp";
    public static final String HRP_NOACCESS_JSP = "/WEB-INF/jsp/common/accessDenied.jsp";
    public static final String HRP_NOT_AUTHORIZED = "/WEB-INF/jsp/common/notAuthorized.jsp";
    public static final String DATA_DELETED_SUCCESS_MSG = "Data Deleted Sucessfully";
    public static final String DATA_SAVED_SUCCESS_MSG = "Data Saved Sucessfully";
    public static final String APPLICATION_NAME = "HumanRightsPolicy";
    public static final String EDIT_ROLE = "EDIT";
    public static final String READ_ROLE = "READ-ONLY";
    public static final String ADMIN_ROLE = "ADMIN";
    public static final String EDIT_ROLE_ID = "2";
    public static final String SCOPE = "scope";
    public static final String DONT_SEARCH = "dontSearch";
    public static final String MENU = "menu";

    public static final String COUNTRY_HTML = "countryHTML";
    public static final String STATE_HTML = "stateHTML";
    public static final String ALL_COUNTRY_HTML = "allCountryHTML";
    public static final String ALL_STATE_HTML = "allStateHTML";

    public static final String LATIN1_ENCODING = "ISO-8859-1";
    public static final String REDIRECT_TO_AFTER_ADDING_CONTACT = "redirect";
    public static final String REDIRECT_TO_AFTER_REMOVING_CONTACT = "redirect";
    public static final String SELECT_ALL = "areAllAcrossPagesSelected";
    public static final String SELECTED_IDS = "selectedIds";
    public static final String IDS_TO_EXCLUDE = "idsToExclude";

    public static final String HOME = "Home";
    public static final String BUSINESS_PARTNERS = "Business Partners";
    public static final String COMMUNICATIONS = "Communications";
    public static final String ADMINISTRATION = "Administration";
    public static final String LOCATION = "Location";
    public static final String CONTACT = "Contact";
    public static final String ACTION_PLANS = "Action Plans";
    public static final String GLOBAL_ASSESSMENT = "Global Assessment";


    public static final String RECENTLY_ADDED = "recent";
    public static String FILTER_VALUE = "filterValue";
}
