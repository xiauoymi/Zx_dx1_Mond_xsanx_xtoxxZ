package com.monsanto.wst.humanrightspolicy.contact.constants;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Jul 13, 2006 Time: 8:34:53 AM To change this template use File |
 * Settings | File Templates.
 */
public class ContactConstants {

  ///CLOVER:OFF
  private ContactConstants() {
  }
///CLOVER:ON

  public static final String METHOD_BP_CONTACT_ADD_NEW = "addContact";
  public static final String METHOD_BP_CONTACT_UPDATE = "updateContact";
  public static final String METHOD_BP_CONTACT_LOOKUP = "lookupContact";
  public static final String METHOD_BP_CONTACT_DELETE = "deleteContact";
  public static final String METHOD_CONTACT_ADD_COMM = "addCommunication";
  public static final String CONTACT_JSP = "/WEB-INF/jsp/contact/contact.jsp";
  public static final String CONTACT_ID = "contactId";
  public static final String CONTACT_INFO = "contactInfo";
  public static final String PREFIX = "prefix";
  public static final String NAME = "name";
  public static final String WORK_PHONE = "workPhone";
  public static final String MOBILE_PHONE = "mobilePhone";
  public static final String FAX = "fax";
  public static final String EMAIL = "email";
  public static final String TITLE = "title";
  public static final String NAME_EDIT = "nameEdit";
  public static final String WORK_PHONE_EDIT = "workPhoneEdit";
  public static final String MOBILE_PHONE_EDIT = "mobilePhoneEdit";
  public static final String FAX_EDIT = "faxEdit";
  public static final String EMAIL_EDIT= "emailEdit";
  public static final String TITLE_EDIT = "titleEdit";
  public static final String COUNT_OF_LOCATIONS = "countOfLocationsForContact";
  public static final String COUNT_OF_COMMUNICATIONS = "countOfCommunicationsForContact";
}
