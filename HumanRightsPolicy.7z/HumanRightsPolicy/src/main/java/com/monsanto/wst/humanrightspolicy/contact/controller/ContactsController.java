package com.monsanto.wst.humanrightspolicy.contact.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.contact.constants.ContactConstants;
import com.monsanto.wst.humanrightspolicy.contact.service.ContactService;
import com.monsanto.wst.humanrightspolicy.contact.service.LookupContactService;
import com.monsanto.wst.humanrightspolicy.controller.HrpController;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.humanrightspolicy.utils.NumberUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * /** Created by IntelliJ IDEA. User: rgeorge Date: Jun 28, 2006 Time: 4:47:57 PM To change this template use File |
 * Settings | File Templates.
 */
public class ContactsController extends HrpController {
    private final LookupContactService lookupContactService;
    private final ContactService contactService;
    private final CommunicationService commService;
    private final LocationService locationService;
    private final GenericDAO<ContactType, Long> contactTypeDAO;

    public ContactsController() {
        this(InitService.initLookupContactService(), InitService.initContactService(),
                InitService.initCommunicationService(),
                InitService.initLocationService(),
                InitService.initContactTypeDAO());
    }

    public ContactsController(
            LookupContactService lookupContactService,
            ContactService contactService, CommunicationService commService,
            LocationService locationService, GenericDAO<ContactType, Long> contactTypeLongMockDAO) {
        this.lookupContactService = lookupContactService;
        this.contactService = contactService;
        this.commService = commService;
        this.locationService = locationService;
        this.contactTypeDAO = contactTypeLongMockDAO;
    }

    /**
     * This method displays all existing contacts for a business partner and sets up initial data for a new contact
     */
    protected void notSpecified(UCCHelper helper) throws IOException {
//    try {
////      helper.forward(ContactConstants.LIST_CONTACTS_JSP);
//    } catch (Exception e) {
//      MsgAndErrorUtil.addExceptionMsgToResponse(e, helper);
//      helper.forward(HRPMainConstants.HRP_ERROR_JSP);
//    }
    }

    /**
     * This method sets template for adding a new contact
     *
     * @param helper UCCHelper
     * @throws IOException IOException
     */
    public void addContact(UCCHelper helper) throws IOException {
        setContactInResponse(buildDefaultContact(), helper);
        helper.forward(ContactConstants.CONTACT_JSP);
    }

    /**
     * This method looks up a contact for a business partner
     *
     * @param helper UCCHelper
     * @throws IOException IOException
     */
    public void lookupContact(UCCHelper helper) throws IOException {
        ContactInfo contact = lookupContactById(helper);
        setContactInResponse(contact, helper);
        // getCountOfRelatedObjects(helper, contact);
        setCommReferenceDataInHelper(helper);
        helper.forward(ContactConstants.CONTACT_JSP);
    }

    private void getCountOfRelatedObjects(UCCHelper helper, ContactInfo contact) {
        helper.setRequestAttributeValue(ContactConstants.COUNT_OF_LOCATIONS,
                Integer.valueOf(contact.getActiveLocationContactRelationships().size()).toString());
        helper.setRequestAttributeValue(ContactConstants.COUNT_OF_COMMUNICATIONS,
                Integer.valueOf(contact.getCommunications().size()).toString());
    }

    private CommStatus getOpenStatusId() {
        //todo move to commstatus dao
        List<CommStatus> statuses = this.commService.lookupCommunicationStatuses();
        for (CommStatus status : statuses) {
            if (status.getStatus().equalsIgnoreCase(CommunicationConstants.OPEN_STATUS)) {
                return status;
            }
        }
        return null;
    }

    public void updateContact(UCCHelper helper) throws IOException {
        ContactInfo contact = updateContactInfoFromHelper(helper);
        helper.setRequestAttributeValue(ContactConstants.CONTACT_INFO, contact);
        Document response = outputContactAsXML(helper);
        helper.setContentType("text/xml");
        DOMUtil.outputXML(response);
        helper.writeXMLDocument(response, HRPMainConstants.LATIN1_ENCODING);
        // helper.forward("/servlet/contacts?method=lookupContact&contactId=" + contact.getContactId() + "&menu=" + menu);
    }

    public void addCommunication(UCCHelper helper) throws IOException {
        String recipientId = helper.getRequestParameterValue(HRPMainConstants.CONTACT_ID);
        String name = helper.getRequestParameterValue(CommunicationConstants.COMM_NAME);
        String notes = helper.getRequestParameterValue(CommunicationConstants.COMM_NOTES);
        Date fromDate = getDate(helper.getRequestParameterValue(CommunicationConstants.COMM_FROM_PERIOD));
        Date toDate = getDate(helper.getRequestParameterValue(CommunicationConstants.COMM_TO_PERIOD));
        Date dueDate = getDate(helper.getRequestParameterValue(CommunicationConstants.COMM_DUE_PERIOD));
        String urlTitle = helper.getRequestParameterValue(CommunicationConstants.COMM_URL_TITLE);
        String url = helper.getRequestParameterValue(CommunicationConstants.COMM_URL);
        String active = "Y";
        CommType commType = new CommType(helper.getRequestParameterValue(CommunicationConstants.COMM_TYPE_ID), null
        );
        CommStatus status = getOpenStatusId();
        ContactType peopleType = new ContactType(
                helper.getRequestParameterValue(CommunicationConstants.COMM_PEOPLE_TYPE_ID), null);
        Long locTypeId = NumberUtil.stringToLong(helper.getRequestParameterValue(CommunicationConstants.COMM_LOC_TYPE_ID));
        LocationType locType = new LocationType(locTypeId,
                null);
        Communication newComm = this.commService
                .addCommunication(name, notes, fromDate, toDate, dueDate, active, urlTitle, url,
                        commType, status,
                        peopleType, locType, null, null);
        newComm.addRecipient(recipientId);
        helper.setContentType("text/plain");
        helper.getPrintWriter().write("ok");
    }

    private Document outputContactAsXML(UCCHelper helper) {
        Document response = createNewDocument();
        Element result = response.createElement("response");
        ContactInfo contact = (ContactInfo) helper.getRequestAttributeValue(ContactConstants.CONTACT_INFO);
        Element contactInfo = response.createElement("contact");
        DOMUtil.addChildElement(contactInfo, "contactId", contact.getContactId());
        DOMUtil.addChildElement(contactInfo, "contactName", contact.getContactName());
        DOMUtil.addChildElement(contactInfo, "contactPrefix", contact.getContactNamePrefix());
        DOMUtil.addChildElement(contactInfo, "mobilePhone", contact.getContactMobilePhone());
        DOMUtil.addChildElement(contactInfo, "title", contact.getContactTitle());
        DOMUtil.addChildElement(contactInfo, "workPhone", contact.getContactWorkPhone());
        DOMUtil.addChildElement(contactInfo, "email", contact.getContactEmail());
        DOMUtil.addChildElement(contactInfo, "fax", contact.getContactFax());
        result.appendChild(contactInfo);
        response.appendChild(result);
        return response;
    }

    private ContactInfo updateContactInfoFromHelper(UCCHelper helper) throws IOException {
        String contactId = helper.getRequestParameterValue(ContactConstants.CONTACT_ID);
        String contactNamePrefix = helper.getRequestParameterValue(ContactConstants.PREFIX);
        String name = helper.getRequestParameterValue(ContactConstants.NAME);
        String contactTitle = helper.getRequestParameterValue(ContactConstants.TITLE);
        String contactWorkPhone = helper.getRequestParameterValue(ContactConstants.WORK_PHONE);
        String contactMobilePhone = helper.getRequestParameterValue(ContactConstants.MOBILE_PHONE);
        String contactFax = helper.getRequestParameterValue(ContactConstants.FAX);
        String contactEmail = helper.getRequestParameterValue(ContactConstants.EMAIL);
        return contactService.updateContact(contactId, contactNamePrefix, name,
                contactTitle, contactWorkPhone, contactMobilePhone, contactFax, contactEmail);
    }

    private void setContactInResponse(ContactInfo contactInfo, UCCHelper helper) {
        helper.setRequestAttributeValue(ContactConstants.CONTACT_INFO, contactInfo);
    }

    private ContactInfo lookupContactById(UCCHelper helper) throws IOException {
        String contactId = helper.getRequestParameterValue(HRPMainConstants.CONTACT_ID);
        return this.lookupContactService.lookupContactById(contactId);
    }

    private ContactInfo buildDefaultContact() {
        return new ContactInfoImpl(null, null, null, null, null, null, null, null, null);
    }

    private void setCommReferenceDataInHelper(UCCHelper helper) {
        helper.setRequestAttributeValue(CommunicationConstants.COMM_TYPE_LIST, commService.lookupCommunicationTypes());
        helper.setRequestAttributeValue(BusinessPartnerConstants.LOC_CON_REL_TYPE_LIST,
                contactTypeDAO.findAll());
        helper.setRequestAttributeValue(LocationsConstants.BP_LOC_REL_TYPE_LIST, locationService.lookupBPLocRelTypes());
    }

    private Date getDate(String dateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            return null;
        }
    }

}
