/*
 ContactDAO was created on Dec 12, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.contact.dao;

import com.monsanto.wst.humanrightspolicy.model.ContactInfo;

/**
 * @author sspati1
 */
public interface ContactDAO {


  String addContact(String contactNamePrefix, String contactName,
                    String contactTitle, String contactWorkPhone,
                    String contactMobilePhone, String contactFax, String contactEmail, String isSap);

  void updateContact(String contactId, String contactNamePrefix, String contactName,
                     String contactTitle, String contactWorkPhone, String contactMobilePhone, String contactFax,
                     String contactEmail);

  ContactInfo lookupContactById(String id);

}