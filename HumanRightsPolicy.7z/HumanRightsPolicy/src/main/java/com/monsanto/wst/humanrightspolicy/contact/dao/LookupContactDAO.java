/*
 LookupContactDAO was created on Jan 11, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.contact.dao;

import com.monsanto.wst.humanrightspolicy.model.ContactInfo;

import java.util.List;

/**
 * @author sspati1
 */
public interface LookupContactDAO {
  List<ContactInfo> lookupContactsByCriteria(ContactInfo contactCriteria);

  ContactInfo lookupContactById(String contactId);
}