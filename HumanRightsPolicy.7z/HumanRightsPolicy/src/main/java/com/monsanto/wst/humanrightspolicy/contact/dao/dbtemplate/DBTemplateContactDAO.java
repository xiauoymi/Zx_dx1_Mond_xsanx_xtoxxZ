/*
 DBTemplateContactDAO was created on Apr 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.contact.dao.dbtemplate;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.contact.dao.ContactDAO;
import com.monsanto.wst.humanrightspolicy.model.ContactInfo;

/**
 * Filename:    $RCSfile: DBTemplateContactDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-02 20:13:06 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class DBTemplateContactDAO implements ContactDAO {
  private final DBTemplate template;

  public DBTemplateContactDAO(DBTemplate template) {
    this.template = template;
  }

  public String addContact(String contactNamePrefix, String contactName,
                           String contactTitle, String contactWorkPhone,
                           String contactMobilePhone, String contactFax, String contactEmail, String isSap
  ) {
    String id = getNextId();

    TempContact contact = new TempContact(id, contactNamePrefix, contactName, contactTitle,
        contactWorkPhone, contactMobilePhone, contactFax, contactEmail, isSap);
    template.executeInsert("addContact", contact);

    return id;
  }

  public void updateContact(String contactId, String contactNamePrefix, String contactName,
                            String contactTitle, String contactWorkPhone, String contactMobilePhone, String contactFax,
                            String contactEmail) {
    TempContact contact = new TempContact(contactId, contactNamePrefix, contactName, contactTitle,
        contactWorkPhone, contactMobilePhone, contactFax, contactEmail, null);
    template.executeUpdate("updateContact", contact);
  }

  public ContactInfo lookupContactById(String id) {
    return (ContactInfo) template.executeSingleResultQuery("lookupContactById", id);
  }

  private String getNextId() {
    return this.template.executeSingleResultQuery("lookupNextSequenceId").toString();
  }

}