/*
 LookupContactDAOImpl was created on Jan 11, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.contact.dao.dbtemplate;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.contact.dao.LookupContactDAO;
import com.monsanto.wst.humanrightspolicy.model.ContactInfo;

import java.util.List;

/**
 * @author sspati1
 */
public class DBTemplateLookupContactDAOImpl implements LookupContactDAO {
  private final DBTemplate template;

  public DBTemplateLookupContactDAOImpl(DBTemplate template) {
    this.template = template;
  }

  public ContactInfo lookupContactById(String contactId) {
    return (ContactInfo) template.executeSingleResultQuery("lookupContactById", contactId);
  }

  public List<ContactInfo> lookupContactsByCriteria(ContactInfo contact) {
    return template.executeListResultQuery("lookupContactsByCriteria", contact);
  }
}