package com.monsanto.wst.humanrightspolicy.contact.dao.dbtemplate;
/*
 TempContact was created on May 2, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class TempContact {
  private final String id;
  private final String contactNamePrefix;
  private final String contactName;
  private final String contactTitle;
  private final String contactWorkPhone;
  private final String contactMobilePhone;
  private final String contactFax;
  private final String contactEmail;
  private final String isSap;

  public TempContact(String id, String contactNamePrefix, String contactName,
                     String contactTitle, String contactWorkPhone, String contactMobilePhone,
                     String contactFax, String contactEmail, String isSap) {
    this.id = id;
    this.contactNamePrefix = contactNamePrefix;
    this.contactName = contactName;
    this.contactTitle = contactTitle;
    this.contactWorkPhone = contactWorkPhone;
    this.contactMobilePhone = contactMobilePhone;
    this.contactFax = contactFax;
    this.contactEmail = contactEmail;
    this.isSap = isSap;
  }

  public String getId() {
    return id;
  }

  public String getContactNamePrefix() {
    return contactNamePrefix;
  }

  public String getContactName() {
    return contactName;
  }

  public String getContactTitle() {
    return contactTitle;
  }

  public String getContactWorkPhone() {
    return contactWorkPhone;
  }

  public String getContactMobilePhone() {
    return contactMobilePhone;
  }

  public String getContactFax() {
    return contactFax;
  }

  public String getContactEmail() {
    return contactEmail;
  }

  public String getIsSap() {
    return isSap;
  }
}
