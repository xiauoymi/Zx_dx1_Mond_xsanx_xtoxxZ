/*
 ContactService was created on Dec 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.contact.service;

import com.monsanto.wst.humanrightspolicy.model.ContactInfo;

/**
 * @author sspati1
 */
public interface ContactService {
  ContactInfo addContact(
      String contactNamePrefix, String contactName, String contactTitle,
      String contactWorkPhone, String contactMobilePhone, String contactFax,
      String contactEmail, String isSap);
  
  ContactInfo updateContact(String contactId,
                            String contactNamePrefix, String contactName, String contactTitle,
                            String contactWorkPhone, String contactMobilePhone, String contactFax,
                            String contactEmail);

}