/*
 ContactServiceImpl was created on Dec 13, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.contact.service;

import com.monsanto.wst.humanrightspolicy.contact.dao.ContactDAO;
import com.monsanto.wst.humanrightspolicy.model.ContactInfo;

/**
 * @author sspati1
 */
public class ContactServiceImpl implements ContactService {
  private final ContactDAO contactDAO;

  public ContactServiceImpl(ContactDAO contactDAO) {
    this.contactDAO = contactDAO;
  }

  public ContactInfo addContact(String contactNamePrefix,
                                String contactName, String contactTitle,
                                String contactWorkPhone, String contactMobilePhone, String contactFax,
                                String contactEmail, String isSap) {
    String id = contactDAO.addContact(contactNamePrefix, contactName, contactTitle,
        contactWorkPhone, contactMobilePhone, contactFax, contactEmail, isSap);
//      System.out.println("contact id = " + id);
    return contactDAO.lookupContactById(id);
  }


  public ContactInfo updateContact(String contacatId, String contactNamePrefix,
                                   String contactName, String contactTitle, String contactWorkPhone,
                                   String contactMobilePhone, String contactFax, String contactEmail) {
    contactDAO.updateContact(contacatId, contactNamePrefix, contactName, contactTitle,
        contactWorkPhone, contactMobilePhone, contactFax, contactEmail);
    return contactDAO.lookupContactById(contacatId);
  }

}