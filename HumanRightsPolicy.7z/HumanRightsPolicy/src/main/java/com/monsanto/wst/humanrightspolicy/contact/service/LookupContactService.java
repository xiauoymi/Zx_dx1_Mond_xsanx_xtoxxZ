/*
 LookupBPContactService was created on Jan 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.contact.service;

import com.monsanto.wst.humanrightspolicy.model.ContactInfo;
import com.monsanto.wst.humanrightspolicy.model.ContactInfoImpl;

import java.util.List;

/**
 * @author sspati1
 */
public interface LookupContactService {
  List<ContactInfo> lookupContactsByCriteria(ContactInfoImpl criteriaContact);
  ContactInfo lookupContactById(String contactId);
}