/*
 LookupBPContactServiceImpl was created on Jan 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.contact.service;

import com.monsanto.wst.humanrightspolicy.contact.dao.LookupContactDAO;
import com.monsanto.wst.humanrightspolicy.model.ContactInfo;
import com.monsanto.wst.humanrightspolicy.model.ContactInfoImpl;

import java.util.ArrayList;
import java.util.List;

/**
 * @author sspati1
 */
public class LookupContactServiceImpl implements LookupContactService {
  private final LookupContactDAO lookupContactDao;

  public LookupContactServiceImpl(LookupContactDAO lookupContactDao
  ) {
    this.lookupContactDao = lookupContactDao;
  }

  public List<ContactInfo> lookupContactsByCriteria(ContactInfoImpl criteriaContact) {
    List<ContactInfo> contactWithSameAddressAsBP = this.lookupContactDao.lookupContactsByCriteria(criteriaContact);
    List<ContactInfo> contacts = new ArrayList<ContactInfo>();
    contacts.addAll(contactWithSameAddressAsBP);
    return contacts;
  }

  public ContactInfo lookupContactById(String contactId) {
    return this.lookupContactDao.lookupContactById(contactId);
  }
}