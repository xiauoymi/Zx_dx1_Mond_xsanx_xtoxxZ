package com.monsanto.wst.humanrightspolicy.controller;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.humanrightspolicy.datasource.DataSource;
import com.monsanto.wst.humanrightspolicy.datasource.Filterable;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
/*
 FilteredDataSource was created on May 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class FilteredXmlDataSource<T> implements XmlDataSource {
  private final XmlDataSource baseSource;
  private final String filterValue;

  public FilteredXmlDataSource(XmlDataSource baseSource, String filterValue) {
    this.baseSource = baseSource;
    this.filterValue = filterValue;
  }

  public List<? extends XmlObject> getData() throws IOException {
    List<XmlObject> filteredList = new ArrayList<XmlObject>();
    for (XmlObject item : baseSource.getData()) {
      if (passesFilter(item)) {
        filteredList.add(item);
      }
    }

    return filteredList;
  }

  private boolean passesFilter(XmlObject item) {
    if (!StringUtils.isNullOrEmpty(filterValue) && (item instanceof Filterable)) {
      return ((Filterable) item).filter(filterValue);
    } else {
      return true; // if not filterable, pass-thru
    }
  }

  public Comparator<XmlObject> getComparator(String sortName) {
    return baseSource.getComparator(sortName);
  }

  public boolean isSorted() {
    return baseSource.isSorted();
  }

  public boolean isFiltered() {
    return true;
  }

  public int getTotalRecords() {
    return DataSource.UNKNOWN_RECORD_COUNT; // could calculate from the data source here
  }}
