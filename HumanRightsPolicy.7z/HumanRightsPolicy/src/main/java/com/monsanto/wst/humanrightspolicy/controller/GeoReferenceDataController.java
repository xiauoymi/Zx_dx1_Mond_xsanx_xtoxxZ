/*
 GeoReferenceDataController was created on Apr 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.geodata.GeoDataFactory;
import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.Region;
import com.monsanto.wst.humanrightspolicy.model.StateProvince;
import com.monsanto.wst.humanrightspolicy.services.GeographicalLocationReferenceDataService;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: GeoReferenceDataController.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:23 $
 *
 * @author sspati1
 * @version $Revision: 1.11 $
 */
public class GeoReferenceDataController extends AbstractDispatchController {
  private final GeographicalLocationReferenceDataService geoService;
  private final GeoDataFactory geoDataFactory;

  public GeoReferenceDataController() {
    this(InitService.initGeographicalLocationReferenceDataService(), InitService.initGeoDataFactory());
  }

  public GeoReferenceDataController(GeographicalLocationReferenceDataService geoService,
                                    GeoDataFactory geoDataFactory) {
    this.geoService = geoService;
    this.geoDataFactory = geoDataFactory;
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
  }

  public void regionHTML(UCCHelper helper)  {
    List<Region> regions = geoDataFactory.getRegions();
    outputListRegions(helper, regions);
  }

  public void countryHTML(UCCHelper helper) throws IOException {
    String regionId = helper.getRequestParameterValue("region");
    List<Country> countries = geoService.lookupActiveCountriesForRegion(regionId);
    outputListCountries(helper, countries);
  }

  public void stateHTML(UCCHelper helper) throws IOException {
    String countryId = helper.getRequestParameterValue("country");
    List<StateProvince> states = geoService.lookupActiveStatesForCountry(countryId);
    outputListStates(helper, states);
  }

  public void allCountryHTML(UCCHelper helper) throws IOException {
    String regionId = helper.getRequestParameterValue("region");
    Region region = geoDataFactory.getRegionById(regionId);
    List<Country> countries = region.getCountries();
    outputListCountries(helper, countries);
  }

  public void allStateHTML(UCCHelper helper) throws IOException {
    String countryId = helper.getRequestParameterValue("country");
    Country country = geoDataFactory.getCountryById(countryId);
    List<StateProvince> states = country.getStates();
    outputListStates(helper, states);
  }

  //todo in the process of refactoring StateProvince from CommonModel
  private void outputListStates(UCCHelper helper, List<? extends StateProvince> list)  {
    Document doc = DOMUtil.newDocument();
    Element selectElement = DOMUtil.addChildElement(doc, "select");
    for (StateProvince item : list) {
      Element currElement = DOMUtil.addChildElement(selectElement, "option", item.getValue());
      currElement.setAttribute("value", item.getId());
    }

    helper.setContentType("text/xml");
    helper.writeXMLDocument(doc, HRPMainConstants.LATIN1_ENCODING);
  }

  //todo in the process of refactoring Region from CommonModel
  private void outputListRegions(UCCHelper helper, List<? extends Region> list)  {
    Document doc = DOMUtil.newDocument();
    Element selectElement = DOMUtil.addChildElement(doc, "select");
    for (Region item : list) {
      Element currElement = DOMUtil.addChildElement(selectElement, "option", item.getValue());
      currElement.setAttribute("value", item.getId());
    }

    helper.setContentType("text/xml");
    helper.writeXMLDocument(doc, HRPMainConstants.LATIN1_ENCODING);
  }
  
  private void outputListCountries(UCCHelper helper, List<? extends Country> list)  {
    Document doc = DOMUtil.newDocument();
    Element selectElement = DOMUtil.addChildElement(doc, "select");
    for (Country item : list) {
      Element currElement = DOMUtil.addChildElement(selectElement, "option", item.getValue());
      currElement.setAttribute("value", item.getId());
    }

    helper.setContentType("text/xml");
    helper.writeXMLDocument(doc, HRPMainConstants.LATIN1_ENCODING);
  }

}