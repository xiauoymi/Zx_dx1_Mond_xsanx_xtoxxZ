/*
 HrpController was created on Aug 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.LoginUser;
import com.monsanto.wst.humanrightspolicy.utils.MsgAndErrorUtil;
import com.monsanto.wst.servletframework.AbstractDispatchController;
import com.monsanto.wst.textutil.TextUtil;
import com.monsanto.wst.commonutils.properties.PlatformProperties;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * This class sets some parameters in helper before passing it to the super class
 *
 * @author sspati1
 */
public abstract class HrpController extends AbstractDispatchController {
    private static final Log logger = LogFactory.getLog(HrpController.class);
    public static final String FILTER_VALUE = "filterValue";
    private boolean isAllSelected;
    private List<String> selectedIds;
    private List<String> idsToExclude;
    private String filterValue;

    public void run(UCCHelper helper) throws IOException {
        helper.setMaxImportFileSize(1024 * 1024 * 1024);
        helper.setHeader("Cache-Control", "no-cache");//To ensure that AJAX call does not use cache
        setLsiFunctionInSession(helper);
        setHRICUrlInRequest(helper);
        setFilterValue(helper);
        setSelectOperateProperties(helper);
        setActiveTabIndex(helper);
        try {
            super.run(helper);
        } catch (Exception e) {
            logger.error(e);
            MsgAndErrorUtil.addExceptionToResponse(e, helper);
            helper.setRequestAttributeValue("exception", e.getMessage());
            helper.setRequestAttributeValue("stackTrace", ExceptionUtils.getFullStackTrace(e));
            helper.forward(HRPMainConstants.HRP_ERROR_JSP);
        }
    }

    private void setHRICUrlInRequest(UCCHelper helper) {
        String url = getHRICUrl();
        helper.setRequestAttributeValue(HRPMainConstants.HRIC_URL_ATTRIBUTE, url);
    }

    private String getHRICUrl() {
        String ERROR_URL = "javascript:alert('Unable to locate HRIC')";
        try {
            Properties prop = new Properties();
            prop.load(this.getClass().getResourceAsStream("/hric.properties"));
            String property = prop.getProperty(HRPMainConstants.HRIC_URL_PROPERTY);
            if (property == null) {
                String platform = EnvironmentHelper.getPropertyPrefix();
                property = prop.getProperty(platform + HRPMainConstants.HRIC_URL_PROPERTY);
            }
            return property;
        } catch (Exception e) {
            return ERROR_URL;
        }
    }

    private void setActiveTabIndex(UCCHelper helper) throws IOException {
        helper.setRequestAttributeValue("activeTabIndex", helper.getRequestParameterValue("activeTabIndex"));
    }

    private void setFilterValue(UCCHelper helper) throws IOException {
        this.filterValue = TextUtil.decodeUsingUTF8(helper.getRequestParameterValue(FILTER_VALUE));
    }

    private void setLsiFunctionInSession(UCCHelper helper) {
        String lsiFunction = (String) helper.getSessionParameter(HRPMainConstants.LSI_FUNCTION);
        if (StringUtils.isNullOrEmpty(lsiFunction)) {
            lsiFunction = System.getProperty("lsi.function");
            helper.setSessionParameter(HRPMainConstants.LSI_FUNCTION, lsiFunction);
        }
    }

    public String getFilterValue() throws IOException {
        return this.filterValue;
    }

    protected LoginUser getLoginUserFromSession(UCCHelper helper) {
        return (LoginUser) helper.getSessionParameter(HRPMainConstants.LOGINUSER);
    }

    public boolean isAllSelected() {
        return this.isAllSelected;
    }

    public List<String> getSelectedIds() {
        return selectedIds;
    }

    public List<String> getIdsToExclude() {
        return idsToExclude;
    }

    protected boolean isAllSelectedNoneExcludedNotFiltered() throws IOException {
        return isAllSelected() && getIdsToExclude().isEmpty() && getFilterValue() == null;
    }

    private void setSelectOperateProperties(UCCHelper helper) throws IOException {
        String selectAll = helper.getRequestParameterValue(HRPMainConstants.SELECT_ALL);
        helper.setRequestAttributeValue(HRPMainConstants.SELECT_ALL, selectAll);
        this.isAllSelected = selectAll != null && selectAll.equalsIgnoreCase("true");

        String selectedIdsFromRequest = helper.getRequestParameterValue(HRPMainConstants.SELECTED_IDS);
        helper.setRequestAttributeValue(HRPMainConstants.SELECTED_IDS, selectedIdsFromRequest);
        this.selectedIds = createListFromCommaSeparatedString(selectedIdsFromRequest);

        String idsToExcludeFromRequest = helper.getRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE);
        helper.setRequestAttributeValue(HRPMainConstants.IDS_TO_EXCLUDE, idsToExcludeFromRequest);
        this.idsToExclude = createListFromCommaSeparatedString(idsToExcludeFromRequest);
    }

    private List<String> createListFromCommaSeparatedString(String string) {
        if (string == null) {
            return new ArrayList<String>();
        }
        List<String> list = new ArrayList<String>(Arrays.asList(string.split(",")));
        if (!list.isEmpty() && list.get(0).length() == 0) {
            list.remove(list.get(0));
        }
        return list;
    }

    /**
     * This method creates a new empty XML document.
     *
     * @return Document - Object to be rendered.
     */
    protected Document createNewDocument() {
        return DOMUtil.newDocument();
//    String DEFAULT_XML_READER = "org.apache.xerces.parsers.SAXParser";
//    XMLUtilities utils = new XMLUtilities(new ResourceUtils(), DEFAULT_XML_READER);
//    try {
//      return utils.createDocument();
//    } catch (XMLParserException e) {
//      throw new ViewRenderingException("Unable to create xml document.", e);
//    }
    }

    protected DBTemplateImpl getTemplate() {
        return new DBTemplateImpl("database/dbtemplate-config.xml", new String[]{"database/dbtemplate.xml"});
    }

}