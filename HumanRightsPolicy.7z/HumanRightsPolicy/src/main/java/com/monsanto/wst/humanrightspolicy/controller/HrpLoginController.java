package com.monsanto.wst.humanrightspolicy.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.LoginUser;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.hibernate.Criteria;
import org.hibernate.criterion.Expression;

import java.io.IOException;

public class HrpLoginController extends HrpController {
  private final GenericDAO<LoginUser, Long> userDAO;

  public HrpLoginController(GenericDAO<LoginUser, Long> userDAO) {
    this.userDAO = userDAO;
  }

  public HrpLoginController() {
    this(InitService.initUserDAO());
  }

  protected void notSpecified(UCCHelper helper) throws IOException {
    String userId = getAuthenticatedUserId(helper);
    LoginUser hrpUser = lookupUserById(userId);
    if(hrpUser == null){
      helper.forward(HRPMainConstants.HRP_NOACCESS_JSP);
    }else{
      setLoginUserInSession(helper, hrpUser);
      helper.forward(HRPMainConstants.HRP_HOME_JSP);
    }
  }

  public void home(UCCHelper helper) throws IOException {
    helper.forward(HRPMainConstants.HRP_HOME_JSP);
  }

  /***
   * This method forwards the user to a 'no access'. This is called from the HRPFilter if user is not an admin
   * but is trying to access user maintainenance page.
   * @param helper - UCCHelper
   * @throws IOException - IOException
   */

  public void doesNotHaveAccess(UCCHelper helper) throws IOException {
    helper.forward(HRPMainConstants.HRP_NOT_AUTHORIZED);
  }

  private void setLoginUserInSession(UCCHelper helper, LoginUser loginUser) {
    helper.removeSessionParameter(HRPMainConstants.LOGINUSER);
    helper.setSessionParameter(HRPMainConstants.LOGINUSER, loginUser);
  }

  private LoginUser lookupUserById(String id) {
   Criteria criteria = userDAO.createCriteria();
    criteria.add(Expression.eq("userId", id));
    return (LoginUser) criteria.uniqueResult();
  }

  private String getAuthenticatedUserId(UCCHelper helper) {
    return helper.getAuthenticatedUserID().toUpperCase();
  }
}
