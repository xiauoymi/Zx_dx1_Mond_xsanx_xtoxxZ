package com.monsanto.wst.humanrightspolicy.controller;

import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
/*
 SortedSource was created on Apr 24, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class SortedSource implements XmlDataSource {
  private final XmlDataSource source;
  private final Comparator<XmlObject> comparator;

  public SortedSource(XmlDataSource source, Comparator<XmlObject> comparator) {
    this.source = source;
    this.comparator = comparator;
  }

  public List<? extends XmlObject> getData() throws IOException {
    List<? extends XmlObject> sortedList = new ArrayList<XmlObject>(source.getData());
    Collections.sort(sortedList, comparator);
    return sortedList;
  }

  public Comparator<XmlObject> getComparator(String sortName) {
    return source.getComparator(sortName);
  }

  public boolean isSorted() {
    return true;
  }

  public boolean isFiltered() {
    return source.isFiltered();
  }

  public int getTotalRecords() throws IOException {
    return source.getTotalRecords();
  }
}
