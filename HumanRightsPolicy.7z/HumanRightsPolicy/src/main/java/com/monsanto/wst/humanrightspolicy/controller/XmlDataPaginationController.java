package com.monsanto.wst.humanrightspolicy.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.datasource.ComparatorInverter;
import com.monsanto.wst.humanrightspolicy.datasource.DataSource;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.pagination.Paginator;
import com.monsanto.wst.humanrightspolicy.pagination.Result;
import org.w3c.dom.Document;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.Comparator;
import java.util.List;
/*
 XmlDataPaginationController was created on Apr 16, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class XmlDataPaginationController extends HrpController {
  public static final String DATA_SOURCE_CLASSNAME = "data-source";
  public static final String START_INDEX = "startIndex";
  public static final String ROWS_PER_PAGE = "rowsPerPage";
  public static final String SORT = "sort";
  public static final String SORT_DIRECTION = "dir";
  public static final String DESCENDING_SORT = "desc";

  public void notSpecified(UCCHelper helper) throws IOException {
//    helper.setHeader("Cache-Control", "no-cache");
    int startIndex = getNumericParameter(helper, START_INDEX, 0);
    int rowsPerPage = getNumericParameter(helper, ROWS_PER_PAGE, 0);
    String sort = nullIfBlank(helper.getRequestParameterValue(SORT));
    String sortDir = helper.getRequestParameterValue(SORT_DIRECTION);
    boolean reverseSort = (sortDir != null && sortDir.equalsIgnoreCase(DESCENDING_SORT));

      String filterValue = getFilterValue();
    XmlDataSource rawSource = getDataSource(helper);
    XmlDataSource filteredSource = getFilteredSource(filterValue, rawSource);
    XmlDataSource sortedSource = getSortedSource(sort, reverseSort, filteredSource);
    Result<? extends XmlObject> results = getPaginatedResults(startIndex, rowsPerPage, sortedSource);

    List<? extends XmlObject> data = results.getData();
    int numRecords = results.getNumRecords();

    Document resultDoc = getResults(data, numRecords, startIndex);
    helper.setContentType("text/xml");
    helper.writeXMLDocument(resultDoc, HRPMainConstants.LATIN1_ENCODING);
  }

  private Result<? extends XmlObject> getPaginatedResults(int startIndex, int rowsPerPage,
                                                          XmlDataSource sortedSource) throws IOException {
    int totalRecords = sortedSource.getTotalRecords();
    if (totalRecords == DataSource.UNKNOWN_RECORD_COUNT) {
      Paginator<XmlObject> paginator = new Paginator<XmlObject>(sortedSource);
      return paginator.getRecords(startIndex, rowsPerPage);
    } else {
      return new Result<XmlObject>(sortedSource.getData(), totalRecords);
    }
  }

  private XmlDataSource getSortedSource(String sort, boolean reverseSort, XmlDataSource filteredSource) {
    XmlDataSource sortedSource;
    if (filteredSource.isSorted()) {
      sortedSource = filteredSource;
    } else {
      Comparator<XmlObject> comparator = filteredSource.getComparator(sort);
      if (reverseSort) {
        comparator = new ComparatorInverter<XmlObject>(comparator);
      }

      sortedSource = new SortedSource(filteredSource, comparator);
    }
    return sortedSource;
  }

  private XmlDataSource getFilteredSource(String filterValue, XmlDataSource rawSource) {
    XmlDataSource filteredSource;
    if (rawSource.isFiltered()) {
      filteredSource = rawSource;
    } else {
      filteredSource = new FilteredXmlDataSource(rawSource, filterValue);
    }
    return filteredSource;
  }

  //Thsi method is protected only for test purposes
//  protected String getFilterValue(UCCHelper helper) throws IOException {
//    return HrpUtil.decodeUsingUTF8(helper.getRequestParameterValue(FILTER_VALUE));
//  }

  private static String nullIfBlank(String st) {
    if (st == null || st.length() == 0) {
      return null;
    } else {
      return st;
    }
  }

  private int getNumericParameter(UCCHelper helper, String name, int defaultValue) throws IOException {
    try {
      return Integer.parseInt(helper.getRequestParameterValue(name));
    } catch (NullPointerException e) {
      return defaultValue;
    } catch (NumberFormatException e) {
      return defaultValue;
    }
  }

  private XmlDataSource getDataSource(UCCHelper helper) {
    String className = (String) helper.getInitParameters().get(DATA_SOURCE_CLASSNAME);
    Constructor<? extends XmlDataSource> constructor = getConstructor(className);
    return getNewInstance(helper, className, constructor);
  }

  private XmlDataSource getNewInstance(UCCHelper helper, String className,
                                       Constructor<? extends XmlDataSource> constructor) {
    try {
      return constructor.newInstance(helper);
    } catch (RuntimeException e) {
      throw e;
    } catch (Exception e) {
      throw new RuntimeException("Error on constructor call for data source class: " + className, e);
    }
  }

  private Constructor<? extends XmlDataSource> getConstructor(String className) {
    try {
      Class<? extends XmlDataSource> dataSourceClass = (Class<? extends XmlDataSource>) Class.forName(className);
      return dataSourceClass.getConstructor(UCCHelper.class);
    } catch (ClassNotFoundException e) {
      throw new RuntimeException("Unknown data source class: " + className, e);
    } catch (NoSuchMethodException e) {
      throw new RuntimeException("No valid constructor for data source class: " + className, e);
    }

  }

  private Document getResults(List<? extends XmlObject> data, int numRecords, int startIndex) throws IOException {
    StringBuffer xmlBuf = new StringBuffer("<ResultSet xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"urn:yahoo:lcl\" xsi:schemaLocation=\"urn:yahoo:lcl http://api.local.yahoo.com/LocalSearchService/V2/LocalSearchResponse.xsd\" ");
    xmlBuf.append("totalResultsAvailable=\"").append(numRecords).append("\" ");
    xmlBuf.append("totalRecords=\"").append(numRecords).append("\" ");
    xmlBuf.append("totalResultsReturned=\"").append(data.size()).append("\" ");
    xmlBuf.append("firstResultPosition=\"").append(startIndex).append("\" >");
    xmlBuf.append("<totalRecords>").append(numRecords).append("</totalRecords>");

    for (XmlObject obj : data) {
      xmlBuf.append(obj.toXml());
    }
    xmlBuf.append("</ResultSet>");

    try {
      return DOMUtil.stringToXML(xmlBuf.toString());
    } catch (ParserException e) {
      throw new RuntimeException("XML Exception", e);
    }
  }
}
