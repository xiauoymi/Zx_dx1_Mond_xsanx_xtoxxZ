/*
 DBTemplateGeographicReferenceDataDAO was created on Mar 27, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.dao.dbtemplate;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.dao.GeographicReferenceDataDAO;
import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.CriteriaObject;
import com.monsanto.wst.humanrightspolicy.model.StateProvince;

import java.util.List;

/**
 * @author sspati1
 */
public class DBTemplateGeographicReferenceDataDAO implements GeographicReferenceDataDAO {
  private final DBTemplate template;

  public DBTemplateGeographicReferenceDataDAO(DBTemplate template) {
    this.template = template;
  }

  public List<Country> lookupActiveCountriesByCriteira(CriteriaObject countryCriteria) {
    return template.executeListResultQuery("lookupActiveCountriesByCriteria", countryCriteria);
  }

  public List<StateProvince> lookupActiveStatesOrProvincesByCountry(String countryId) {
    return template.executeListResultQuery("lookupActiveStatesByCountry", countryId);
  }

}