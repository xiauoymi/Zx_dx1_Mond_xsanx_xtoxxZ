package com.monsanto.wst.humanrightspolicy.datasource;

import java.util.Comparator;
/*
 ComparatorInverter was created on Apr 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class ComparatorInverter<T> implements Comparator<T> {
  private final Comparator<T> baseComparator;

  public ComparatorInverter(Comparator<T> baseComparator) {
    this.baseComparator = baseComparator;
  }

  public int compare(T o1, T o2) {
    return -baseComparator.compare(o1, o2);
  }
}
