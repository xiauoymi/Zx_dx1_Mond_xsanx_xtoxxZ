package com.monsanto.wst.humanrightspolicy.datasource;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
/*
 ComparatorMap was created on May 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class ComparatorMap<T> {
  private final Map<String, Comparator<T>> map = new HashMap<String, Comparator<T>>();
  private final Comparator<T> defaultComparator;

  public ComparatorMap(Comparator<T> defaultComparator) {
    this.defaultComparator = defaultComparator;
  }

  public Comparator<T> getComparator(String key) {
    String searchkey;
    if (key == null) {
      searchkey = null;
    } else {
      searchkey = key.toLowerCase();
    }
    Comparator<T> comp = map.get(searchkey);
    if (comp == null) {
      return defaultComparator;
    } else {
      return comp;
    }
  }

  public void addComparator(String key, Comparator<T> comp) {
    map.put(key.toLowerCase(), comp);
  }
}
