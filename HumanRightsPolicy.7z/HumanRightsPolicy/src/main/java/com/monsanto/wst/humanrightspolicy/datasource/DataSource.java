package com.monsanto.wst.humanrightspolicy.datasource;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;/*
 DataSource was created on Apr 16, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public interface DataSource<T> {
  int UNKNOWN_RECORD_COUNT = -1; //todo need a better name for this

  List<? extends T> getData() throws IOException;
  Comparator<T> getComparator(String sortName);
  boolean isSorted();
  boolean isFiltered();
  int getTotalRecords() throws IOException;
}
