package com.monsanto.wst.humanrightspolicy.datasource;/*
 Filterable was created on May 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public interface Filterable {
  boolean filter(String filterValue);
}
