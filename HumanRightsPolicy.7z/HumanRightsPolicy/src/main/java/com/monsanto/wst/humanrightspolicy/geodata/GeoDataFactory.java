package com.monsanto.wst.humanrightspolicy.geodata;

import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.Region;
import com.monsanto.wst.humanrightspolicy.model.StateProvince;

import java.util.List;/*
 GeoDataFactory was created on May 30, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public interface GeoDataFactory {
  List<Region> getRegions();
  List<Country> getAllCountries();

  Region getRegionById(String regionId);
  Country getCountryById(String countryId);
  StateProvince getStateById(String stateId);
}
