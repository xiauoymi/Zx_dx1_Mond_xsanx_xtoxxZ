package com.monsanto.wst.humanrightspolicy.geodata;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.Region;
import com.monsanto.wst.humanrightspolicy.model.StateProvince;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;/*
 GeoDataFactoryImpl was created on May 30, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class GeoDataFactoryImpl implements GeoDataFactory {
  private final GenericDAO<Region, String> regionDAO;
  private final GenericDAO<Country, String> countryDAO;
  private final GenericDAO<StateProvince, String> stateDAO;

  public GeoDataFactoryImpl() {
    HibernateFactory hibernate = InitService.initHibernate();
    this.regionDAO = new HibernateDAO<Region, String>(hibernate, Region.class);
    this.countryDAO = new HibernateDAO<Country, String>(hibernate, Country.class);
    this.stateDAO = new HibernateDAO<StateProvince, String>(hibernate, StateProvince.class);
  }

  public GeoDataFactoryImpl(
      GenericDAO<Region, String> regionDAO,
      GenericDAO<Country, String> countryDAO,
      GenericDAO<StateProvince, String> stateDAO
  ) {
    this.regionDAO = regionDAO;
    this.countryDAO = countryDAO;
    this.stateDAO = stateDAO;
  }

  //  @Sort(type = SortType.NATURAL) For sort to work the return type needs to be a SortedSet
  public List<Region> getRegions() {
    SortedSet<Region> set = new TreeSet<Region>();
    set.addAll(regionDAO.findAll());
    List<Region> regions = new ArrayList<Region>();
    for (Region re : set) {
      regions.add(re);
    }
      return regions;
  }

  public List<Country> getAllCountries() {
    return countryDAO.findAll();
  }

  public Region getRegionById(String regionId) {
    return regionDAO.findByPrimaryKey(regionId);
  }

  public Country getCountryById(String countryId) {
    return countryDAO.findByPrimaryKey(countryId);
  }

  public StateProvince getStateById(String stateId) {
    return stateDAO.findByPrimaryKey(stateId);
  }

}
