/*
 LocationsConstants was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.contants;

/**
 * @author sspati1
 */
public class LocationsConstants {

  ///CLOVER:OFF
  private LocationsConstants() {
  }
///CLOVER:ON

  public static final String LOCATION_JSP = "/WEB-INF/jsp/location/location.jsp";
  public static final String LOCATION_ID = "locationId";
  public static final String LOCATION = "location";
  public static final String LOOKUP_LOCATION = "lookupLocation";
  public static final String SEARCH_LOCATIONS_XML = "searchLocationsXML";
  public static final String UPDATE_LOCATION ="updateLocation";
  public static final String SAVE_LOCATON = "saveLocationToBp";
  public static final String ADD_CONTACT = "addContactToLocation";
  public static final String SAVE_CONTACT = "saveContactToLocation";
  public static final String LOCATION_NAME = "locationName";
  public static final String SAP_ID = "sapId";
  public static final String ADDRESS="address";
  public static final String ADDR_ID = "addressId";
  public static final String ADDR1 = "addr1";
  public static final String ADDR2 = "addr2";
  public static final String CITY = "city";
  public static final String STATE = "state";
  public static final String COUNTRY = "country";
  public static final String REGION = "region";
  public static final String POSTAL = "postal";
  public static final String BP_LOC_TYPE_ID = "bpLocTypeId";

  public static final String BP_LOC_REL_TYPE_LIST = "bpLocRelTypes";
  public static final String COUNT_OF_CONTACTS = "countOfContactsForLocation";

}