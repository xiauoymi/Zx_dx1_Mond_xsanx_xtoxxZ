/*
 LocationController was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.contact.constants.ContactConstants;
import com.monsanto.wst.humanrightspolicy.contact.service.ContactService;
import com.monsanto.wst.humanrightspolicy.controller.HrpController;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.humanrightspolicy.utils.NumberUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.List;

/**
 * @author sspati1
 */
public class LocationController extends HrpController {
    private final LocationService locationService;
    private final LookupBPService bpLookupService;
    private final ContactService contactService;
    private final GenericDAO<ContactType, Long> contactTypeDAO;

    public LocationController() {
        this(InitService.initLocationService(),
                InitService.initSearchBPService(),
                InitService.initContactService(),
                InitService.initContactTypeDAO());
    }

    public LocationController(LocationService locationService, LookupBPService bpLookupService,
                              ContactService contactService, GenericDAO<ContactType, Long> contactTypeDAO) {
        this.locationService = locationService;
        this.bpLookupService = bpLookupService;
        this.contactService = contactService;
        this.contactTypeDAO = contactTypeDAO;
    }

    protected void notSpecified(UCCHelper helper) throws IOException {
    }

    public void lookupLocation(UCCHelper helper) throws IOException {
        String locationId = helper.getRequestParameterValue(LocationsConstants.LOCATION_ID);
        Location location = this.locationService.lookupLocationById(locationId);
        helper.setRequestAttributeValue(LocationsConstants.LOCATION, location);
        helper.setRequestAttributeValue(LocationsConstants.BP_LOC_REL_TYPE_LIST, locationService.lookupBPLocRelTypes());
        helper.setRequestAttributeValue(BusinessPartnerConstants.LOC_CON_REL_TYPE_LIST,
                contactTypeDAO.findAll());
        getCountOfContactsForLocation(helper, location);
        helper.forward(LocationsConstants.LOCATION_JSP);
    }

    private void getCountOfContactsForLocation(UCCHelper helper, Location location) {
        helper.setRequestAttributeValue(LocationsConstants.COUNT_OF_CONTACTS,
                Integer.valueOf(location.getActiveLocationContactRelationships().size()).toString());
    }

    public void saveContactToLocation(UCCHelper helper) throws IOException {
        String locationId = helper.getRequestParameterValue(LocationsConstants.LOCATION_ID);
        String locConRelTypeId = helper.getRequestParameterValue(BusinessPartnerConstants.LOC_CON_REL_TYPE_ID);
        Location loc = locationService.lookupLocationById(locationId);
        ContactInfo contact = addContactFromHelper(helper);
        boolean isContactPrimary = loc.getActiveLocationContactRelationships().isEmpty();
        locationService.addContactToLocation(loc, contact, isContactPrimary, new ContactType(locConRelTypeId, null)
        );
    }

    private ContactInfo addContactFromHelper(UCCHelper helper) throws IOException {
        String contactNamePrefix = helper.getRequestParameterValue(ContactConstants.PREFIX);
        String name = helper.getRequestParameterValue(ContactConstants.NAME);
        String contactTitle = helper.getRequestParameterValue(ContactConstants.TITLE);
        String contactWorkPhone = helper.getRequestParameterValue(ContactConstants.WORK_PHONE);
        String contactMobilePhone = helper.getRequestParameterValue(ContactConstants.MOBILE_PHONE);
        String contactFax = helper.getRequestParameterValue(ContactConstants.FAX);
        String contactEmail = helper.getRequestParameterValue(ContactConstants.EMAIL);
        return contactService.addContact(contactNamePrefix, name,
                contactTitle, contactWorkPhone, contactMobilePhone, contactFax, contactEmail, "N"
        );
    }

    public void updateLocation(UCCHelper helper) throws IOException {
        String locationId = helper.getRequestParameterValue(LocationsConstants.LOCATION_ID);
        String locationName = helper.getRequestParameterValue(LocationsConstants.LOCATION_NAME);
        String addressId = helper.getRequestParameterValue(LocationsConstants.ADDR_ID);
        String addr1 = helper.getRequestParameterValue(LocationsConstants.ADDR1);
        String addr2 = helper.getRequestParameterValue(LocationsConstants.ADDR2);
        String city = helper.getRequestParameterValue(LocationsConstants.CITY);
        String stateId = helper.getRequestParameterValue(LocationsConstants.STATE);
        String postal = helper.getRequestParameterValue(LocationsConstants.POSTAL);
        Address address = locationService
                .updateAddress(addressId, addr1, addr2, city, stateId, postal, null, null);
        Location location = locationService.updateLocation(locationId, locationName, address);
        helper.setRequestAttributeValue(LocationsConstants.ADDRESS, address);
        helper.setRequestAttributeValue(LocationsConstants.LOCATION, location);
        Document response = outputLocationAsXML(helper);
        helper.setContentType("text/xml");
        DOMUtil.outputXML(response);
        helper.writeXMLDocument(response, HRPMainConstants.LATIN1_ENCODING);
    }

    private Document outputLocationAsXML(UCCHelper helper) {
        Document response = createNewDocument();
        Element result = response.createElement("response");
        Location location = (Location) helper.getRequestAttributeValue(LocationsConstants.LOCATION);
        Element locationInfo = response.createElement("location");
        DOMUtil.addChildElement(locationInfo, "locationId", location.getLocationId());
        DOMUtil.addChildElement(locationInfo, "locName", location.getLocationName());
        DOMUtil.addChildElement(locationInfo, "relType", location.getActiveBPLoctationRelationship().getBpLocRelType().getType());
        DOMUtil.addChildElement(locationInfo, "isSap", location.getIsSap());
        Address address = (Address) helper.getRequestAttributeValue(LocationsConstants.ADDRESS);
        Element addressInfo = response.createElement("address");
        DOMUtil.addChildElement(addressInfo, "addressId", address.getAddressId());
        DOMUtil.addChildElement(addressInfo, "streetAddress1", address.getStreetAddress1());
        DOMUtil.addChildElement(addressInfo, "streetAddress2", address.getStreetAddress1());
        DOMUtil.addChildElement(addressInfo, "city", address.getCity());
        DOMUtil.addChildElement(addressInfo, "zip", address.getZipcode());
        DOMUtil.addChildElement(addressInfo, "region", address.getRegionModel().getValue());
        DOMUtil.addChildElement(addressInfo, "country", address.getCountryModel().getValue());
        DOMUtil.addChildElement(addressInfo, "state", address.getStateModel().getValue());
        locationInfo.appendChild(addressInfo);
        result.appendChild(locationInfo);
        response.appendChild(result);
        return response;
    }

    public void saveLocationToBp(UCCHelper helper) throws IOException {
        String bpId = helper.getRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID);
        BusinessPartner bp = bpLookupService.lookupBPById(bpId);

        String locationName = helper.getRequestParameterValue(LocationsConstants.LOCATION_NAME);
        String sapId = helper.getRequestParameterValue(LocationsConstants.SAP_ID);
        String addr1 = helper.getRequestParameterValue(LocationsConstants.ADDR1);
        String addr2 = helper.getRequestParameterValue(LocationsConstants.ADDR2);
        String city = helper.getRequestParameterValue(LocationsConstants.CITY);
        String stateId = helper.getRequestParameterValue(LocationsConstants.STATE);
        String postal = helper.getRequestParameterValue(LocationsConstants.POSTAL);
        Long bpLocTypeId = NumberUtil.stringToLong(helper.getRequestParameterValue(LocationsConstants.BP_LOC_TYPE_ID));

        Address address = locationService.addAddress(addr1, addr2, city, stateId, postal, null, null);
        Location location = locationService.addLocation(locationName, sapId, address);
        boolean isPrimary = getIsPrimaryFlag(bp);
        bp.addLocationRelationship(location, isPrimary, new LocationType(bpLocTypeId, null));
    }

    private boolean getIsPrimaryFlag(BusinessPartner bp) {
        List<BPLocationRelationship> bpLocRels = bp.getActiveBPLocationRelationships();
        return bpLocRels.isEmpty();
    }
}