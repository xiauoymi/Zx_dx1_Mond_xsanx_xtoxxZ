/*
 LookupLocationDAO was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.dao;

import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.List;

/**
 * @author sspati1
 */
public interface LookupLocationDAO {
  List<Location> lookupLocationByCriteria(Location locationCriteria);
  Location lookupLocationById(String locId);
  String addAddress(String addr1, String addr2, String city, String stateId, String postal
  );
  String addLocation(String locationName, String sapId, Address address);
  void addLocationToBp(BusinessPartner bp, Location location, boolean isPrimary, LocationType bpLocType);
  Address lookupAddressById(String id);
  void addContactToLocation(Location location, ContactInfo contact, boolean isContactPrimary, ContactType locConRelType
  );
  List<LocationType> lookupBPLocRelTypes();

  void updateLocation(String locationId, String locationName, Address address);

  void updateAddress(String addressId, String addr1, String addr2, String city, String stateId, String postal
  );

    //todo is this method still used?
   void updateLocationToBPRelationship(String locationId);
}