/*
 DBTemplateLookupLocationDAO was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.dao.dbtemplate;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipImpl;
import com.monsanto.wst.humanrightspolicy.location.dao.LookupLocationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.Date;
import java.util.List;

/**
 * @author sspati1
 */
public class DBTemplateLocationDAO implements LookupLocationDAO {
    private final DBTemplate template;
    private final GenericDAO<LocationType, Long> locationTypeDAO;

    public DBTemplateLocationDAO(DBTemplate template, GenericDAO<LocationType, Long> locationTypeDAO) {
        this.template = template;
        this.locationTypeDAO = locationTypeDAO;
    }

    public Location lookupLocationById(String locId) {
        Location locCriteria = new LocationImpl(locId, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null, null);
        return (Location) this.template.executeSingleResultQuery("lookupLocationByCriteria", locCriteria);
    }

    public List<Location> lookupLocationByCriteria(Location locationCriteria) {
        return this.template.executeListResultQuery("lookupLocationByCriteria", locationCriteria);
    }

    public List<LocationType> lookupBPLocRelTypes() {
        return locationTypeDAO.findAll();
    }

    public String addAddress(String addr1, String addr2, String city, String stateId, String postal) {
        String id = getNextId();
        StateProvince state = new StateProvince(stateId, null);
        Address addr = new Address(id, addr1, addr2, city, postal, state, null, null);
        template.executeInsert("addAddress", addr);

        return id;
    }

    public void updateAddress(String addressId, String addr1, String addr2, String city, String stateId, String postal) {
        StateProvince state = new StateProvince(stateId, null);
        Address addr = new Address(addressId, addr1, addr2, city, postal, state, null, null);
        template.executeUpdate("updateAddress", addr);
    }

    public void updateLocationToBPRelationship(String locationId) {
        Location locCriteria = new LocationImpl(locationId, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null, null);
        template.executeUpdate("updateLocationToBPRelationship", locCriteria);
    }

    public String addLocation(String locationName, String sapId, Address address) {
        String id = getNextId();

        Location loc = new LocationImpl(id, locationName, sapId, "N", "Y", address);
        template.executeInsert("addLocation", loc);

        return id;
    }

    public void updateLocation(String locationId, String locationName, Address address) {
        Location loc = new LocationImpl(locationId, locationName, "Y", null, null, address);
        template.executeUpdate("updateLocation", loc);
    }

    public void addLocationToBp(BusinessPartner bp, Location location, boolean isPrimary, LocationType bpLocType
    ) {
        BPLocationRelationship bpLocRel = new BPLocationRelationshipImpl(null, bp, location, isPrimary, bpLocType,
                new Date(),
                null);
        template.executeInsert("assignLocationToBp", bpLocRel);
    }

    public Address lookupAddressById(String id) {
        return (Address) template.executeSingleResultQuery("lookupAddressById", id);
    }

    public void addContactToLocation(Location location, ContactInfo contact, boolean isContactPrimary,
                                     ContactType locConRelType) {
        LocationContactRelationship relationship = new LocationContactRelationshipImpl(null, location, contact,
                isContactPrimary, true, locConRelType, new Date(), null);
        template.executeInsert("assignContactToLocation", relationship);
    }

    private String getNextId() {
        return this.template.executeSingleResultQuery("lookupNextSequenceId").toString();
    }

}