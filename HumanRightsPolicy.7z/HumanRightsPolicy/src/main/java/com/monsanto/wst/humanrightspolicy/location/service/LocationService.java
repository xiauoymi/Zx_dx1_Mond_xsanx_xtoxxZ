/*
 LookupLocationService was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.service;

import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.List;

/**
 * @author sspati1
 */
public interface LocationService {
  List<Location> lookupLocationByCriteria(Location locationCriteria);

  Location lookupLocationById(String id);

  void addContactToLocation(Location location, ContactInfo contact, boolean isContactPrimary, ContactType locConRelType
  );

  List<LocationType> lookupBPLocRelTypes();

  Location addLocation(String locationName, String sapId, Address address);

  Location updateLocation(String locationId, String locationName, Address address);

  Address addAddress(String addr1, String addr2, String city, String stateId, String postal, String countryId,
                     String regionId);

  Address updateAddress(String addressId, String addr1, String addr2, String city, String stateId, String postal,
                        String countryId,
                        String regionId);

}