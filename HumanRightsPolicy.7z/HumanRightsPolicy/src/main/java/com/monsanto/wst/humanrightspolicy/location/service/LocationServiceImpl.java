/*
 LookupLocationServiceImpl was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.service;

import com.monsanto.wst.humanrightspolicy.location.dao.LookupLocationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.List;

/**
 * @author sspati1
 */
public class LocationServiceImpl implements LocationService {
  private final LookupLocationDAO locationDao;

  public LocationServiceImpl(LookupLocationDAO locationDao) {
    this.locationDao = locationDao;
  }

  public List<Location> lookupLocationByCriteria(Location locationCriteria) {
    return locationDao.lookupLocationByCriteria(locationCriteria);
  }

  public Location lookupLocationById(String id) {
    return locationDao.lookupLocationById(id);
  }

  public Address addAddress(String addr1, String addr2, String city, String stateId, String postal, String countryId,
                            String regionId) {
    String id = locationDao.addAddress(addr1, addr2, city, stateId, postal);
    return lookupAddressById(id);
  }

  public Address updateAddress(String addressId, String addr1, String addr2, String city, String stateId, String postal,
                               String countryId, String regionId) {
    locationDao.updateAddress(addressId, addr1, addr2, city, stateId, postal);
    return lookupAddressById(addressId);
  }

    private Address lookupAddressById(String id) {
    return locationDao.lookupAddressById(id);
  }

  public Location addLocation(String locationName, String sapId, Address address) {
    String id = locationDao.addLocation(locationName, sapId, address);
    return lookupLocationById(id);
  }

  public Location updateLocation(String locationId, String locationName,
                                 Address address) {
    locationDao.updateLocation(locationId, locationName, address);
    return lookupLocationById(locationId);
  }

  public void addContactToLocation(Location location, ContactInfo contact, boolean isContactPrimary,
                                   ContactType locConRelType) {
    locationDao.addContactToLocation(location, contact, isContactPrimary, locConRelType);
  }

  public List<LocationType> lookupBPLocRelTypes() {
    return locationDao.lookupBPLocRelTypes();
  }
}