package com.monsanto.wst.humanrightspolicy.locationContactRelationship;

/**
 * @author sspati1
 */
public class LocationContactRelationshipConstants {
///CLOVER:OFF
  private LocationContactRelationshipConstants() {
  }
///CLOVER:ON

  public static final String LOOKUP_LOC_CONTACT_RELS_FOR_LOCATION_XML = "lookupLocContactRelsForLocationXML";
  public static final String LOOKUP_LOC_CONTACT_RELS_FOR_CONTACT_XML = "lookupLocContactRelsForContactXML";
  public static final String SET_PRIMARY_LOCATION = "setPrimaryLocation";
  public static final String SET_PRIMARY_CONTACT= "setPrimaryContact";
  public static final String END_LOC_CONTACT_REL="endLocationContactRelationship";
}
