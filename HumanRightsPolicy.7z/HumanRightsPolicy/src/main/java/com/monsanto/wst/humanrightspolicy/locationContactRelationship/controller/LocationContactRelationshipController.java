/*
 LocationContactRelationshipController was created on Feb 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.locationContactRelationship.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.contact.constants.ContactConstants;
import com.monsanto.wst.humanrightspolicy.contact.dao.LookupContactDAO;
import com.monsanto.wst.humanrightspolicy.contact.dao.dbtemplate.DBTemplateLookupContactDAOImpl;
import com.monsanto.wst.humanrightspolicy.controller.HrpController;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.dao.LookupLocationDAO;
import com.monsanto.wst.humanrightspolicy.location.dao.dbtemplate.DBTemplateLocationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author sspati1
 */
public class LocationContactRelationshipController extends HrpController {

  protected void notSpecified(UCCHelper helper) throws IOException {
    helper.forward(HRPMainConstants.HRP_HOME_JSP);
  }

  public void setPrimaryLocation(UCCHelper helper) throws IOException {
    String contactId = helper.getRequestParameterValue(ContactConstants.CONTACT_ID);
    String locationId = helper.getRequestParameterValue(LocationsConstants.LOCATION_ID);
    ContactInfo contact = getLookupContactDAO().lookupContactById(contactId);
    Location location = getLocationDAO().lookupLocationById(locationId);
    contact.setPrimaryLocation(location, helper.getAuthenticatedUserID());

    Document response = appendAddressToResponse(location.getAddress());
    helper.setContentType("text/xml");
    helper.writeXMLDocument(response, HRPMainConstants.LATIN1_ENCODING);
  }

  public void setPrimaryContact(UCCHelper helper) throws IOException {
    String contactId = helper.getRequestParameterValue(ContactConstants.CONTACT_ID);
    String locationId = helper.getRequestParameterValue(LocationsConstants.LOCATION_ID);
    ContactInfo contact = getLookupContactDAO().lookupContactById(contactId);
    Location location = getLocationDAO().lookupLocationById(locationId);
    location.setPrimaryContact(contact, helper.getAuthenticatedUserID());
  }

  public void endLocationContactRelationship(UCCHelper helper) throws IOException {
    String locationId = helper.getRequestParameterValue(LocationsConstants.LOCATION_ID);
    Location location = getLocationDAO().lookupLocationById(locationId);
    LocationContactRelationship primaryContact = location.getPrimaryRelationship();
    List<String> contactIds = getSelectedContactIds(location);
    for (String contactId : contactIds) {
      ContactInfo contact = getLookupContactDAO().lookupContactById(contactId);
      if (!contact.getIsSap()) {
        if (primaryContact != null && primaryContact.getContact().getContactId().equals(contactId)) {
          setSapContactAsPrimaryContact(helper, location);
        }
        location.endLocationContactRelationship(contactId, helper.getAuthenticatedUserID());
      }
    }
    String menu = helper.getRequestParameterValue(HRPMainConstants.MENU);
    helper.forward("location?method=lookupLocation&locationId=" + locationId + "&menu=" + menu);
  }

  private void setSapContactAsPrimaryContact(UCCHelper helper, Location location) {
    List<LocationContactRelationship> activeContactsForLocation = location.getActiveLocationContactRelationships();
    for (LocationContactRelationship locCon : activeContactsForLocation) {
      ContactInfo contact = locCon.getContact();
      if (contact.getIsSap()) {
        location.setPrimaryContact(contact, getLoginUserFromSession(helper).getUserId());
        return;
      }
    }
  }

  private List<String> getSelectedContactIds(Location location)  {
    if (isAllSelected()) {
      List<LocationContactRelationship> locConRels = location.getActiveLocationContactRelationships();
      List<String> selectedIds = new ArrayList<String>();
      for (LocationContactRelationship rel : locConRels) {
        selectedIds.add(rel.getContact().getContactId());
      }
      List<String> idsToExclude = getIdsToExclude();
      for (String id : idsToExclude) {
        selectedIds.remove(id);
      }
      return selectedIds;
    } else {
      return getSelectedIds();
    }
  }

  protected LookupContactDAO getLookupContactDAO() {
    return new DBTemplateLookupContactDAOImpl(getTemplate());
  }

  protected LookupLocationDAO getLocationDAO() {
    return new DBTemplateLocationDAO(getTemplate(), InitService.initLocationTypeDAO());
  }

  protected Location getLocationImpl(String locationId) {
    return new LocationImpl(locationId, null, null, null,
        "N", null, null, null, null, null, null, null, null, null, null, null);
  }

  protected ContactInfo getContactImpl(String contactId) {
    return new ContactInfoImpl(contactId, null, null, null, null, null, null, null, null);
  }

  private List<LocationContactRelationship> getRelationshipsForLocation(String locationId) {
    Location location = getLocationImpl(locationId);
    return location.getActiveLocationContactRelationships();
  }

  private List<LocationContactRelationship> getRelationshipsForContact(String contactId) {
    ContactInfo contact = getContactImpl(contactId);
    return contact.getActiveLocationContactRelationships();
  }

  private Document appendAddressToResponse(Address address) {
    Document response = createNewDocument();
    Element addressElement = response.createElement("address");
    DOMUtil.addChildElement(addressElement, "streetAddress1", address.getStreetAddress1());
    DOMUtil.addChildElement(addressElement, "streetAddress2", address.getStreetAddress2());
    DOMUtil.addChildElement(addressElement, "city", address.getCity());
    DOMUtil.addChildElement(addressElement, "state", address.getStateModel().getValue());
    DOMUtil.addChildElement(addressElement, "country", address.getCountryModel().getValue());
    DOMUtil.addChildElement(addressElement, "region", address.getRegionModel().getValue());
    DOMUtil.addChildElement(addressElement, "zip", address.getZipcode());
    response.appendChild(addressElement);
    return response;
  }
}