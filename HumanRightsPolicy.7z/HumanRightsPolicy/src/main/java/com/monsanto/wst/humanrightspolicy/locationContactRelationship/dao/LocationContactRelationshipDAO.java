/*
 LocationDAO was created on Feb 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.locationContactRelationship.dao;

import com.monsanto.wst.humanrightspolicy.model.LocationContactRelationship;

import java.util.Date;
import java.util.List;

/**
 * @author sspati1
 */
public interface LocationContactRelationshipDAO {
  void endLocationContactRelationship(String locationId, String contactId);

  List<LocationContactRelationship> getActiveContactRelationshipsForLocation(String locId);

  List<LocationContactRelationship> getActiveLocationRelationshipsForContact(String contactId);

  void saveLocationContactRelationship(String locId, String contactId, boolean isContactPrimary,
                                       boolean isLocationPrimary,
                                       Date startDate, Date endDate, Long locConRelTypeId);
}