/*
 DBtemplateLocationContactRelationshipDAO was created on Jun 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.locationContactRelationship.dao.dbtemplate;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.locationContactRelationship.dao.LocationContactRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.model.LocationContactRelationship;
import com.monsanto.wst.humanrightspolicy.model.TempLocationContactRelationship;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: DBtemplateLocationContactRelationshipDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:23 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class DBtemplateLocationContactRelationshipDAO implements LocationContactRelationshipDAO {
  private final DBTemplate template;

  public DBtemplateLocationContactRelationshipDAO(DBTemplate template) {
    this.template = template;
  }

  public List<LocationContactRelationship> getActiveContactRelationshipsForLocation(String locId) {
    return this.template.executeListResultQuery("lookupActiveContactRelationshipsByLocationId", locId);
  }

  public List<LocationContactRelationship> getActiveLocationRelationshipsForContact(String contactId){
    return this.template.executeListResultQuery("lookupActiveLocationRelationshipsByContactId", contactId);
  }

  public void saveLocationContactRelationship(String locId, String contactId, boolean isContactPrimary,
                                              boolean isLocationPrimary,
                                              Date startDate, Date endDate, Long locConRelTypeId){
    String relId = getNextId();
    TempLocationContactRelationship rel = new TempLocationContactRelationship(relId, locId, contactId, isContactPrimary, isLocationPrimary,
        startDate, endDate, locConRelTypeId);
    this.template.executeInsert("insertLocationContactRelationship", rel);
  }

  public void endLocationContactRelationship(String locId, String contactId){
    TempLocationContactRelationship rel = new TempLocationContactRelationship(null, locId, contactId, false, false,
        null, null, null);
    this.template.executeUpdate("endLocationContacatRelationship", rel);
  }

  private String getNextId() {
    return this.template.executeSingleResultQuery("lookupNextSequenceId").toString();
  }

}