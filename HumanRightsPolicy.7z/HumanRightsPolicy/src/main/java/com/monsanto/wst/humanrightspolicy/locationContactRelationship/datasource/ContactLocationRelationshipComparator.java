/*
 ContactLocationRelationshipComparator was created on May 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.locationContactRelationship.datasource;

import com.monsanto.wst.humanrightspolicy.model.LocationRelationship;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: ContactLocationRelationshipComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-05-15 15:26:55 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public abstract class ContactLocationRelationshipComparator implements Comparator<XmlObject> {
 protected abstract String getValue(LocationRelationship locConRel);

  public int compare(XmlObject o1, XmlObject o2) {
    if (o1 instanceof LocationRelationship && o2 instanceof LocationRelationship) {
      return compareRels((LocationRelationship ) o1, (LocationRelationship ) o2);
    } else {
      return 0;
    }
  }

  public int compareRels(LocationRelationship locConRel1, LocationRelationship locConRel2) {
    String value1 = blankIfNull(getValue(locConRel1));
    String value2 = blankIfNull(getValue(locConRel2));
    return value1.compareTo(value2);
  }

  public String blankIfNull(String st) {
    if (st == null) {
      return "";
    } else {
      return st;
    }
  }
}