/*
 ContactLocationRelationshipDataSource was created on May 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.locationContactRelationship.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.contact.constants.ContactConstants;
import com.monsanto.wst.humanrightspolicy.contact.service.LookupContactService;
import com.monsanto.wst.humanrightspolicy.datasource.ComparatorMap;
import com.monsanto.wst.humanrightspolicy.datasource.DataSource;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Filename:    $RCSfile: ContactLocationRelationshipDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * sspati1 $    	 On:	$Date: 2008-12-04 16:50:10 $
 *
 * @author rrmall
 * @version $Revision: 1.17 $
 */
public class ContactLocationRelationshipDataSource implements XmlDataSource {
  private final ParameterCollection params;
  private final LookupContactService contactService;
  public static final String NAME_SORT_KEY = "name";
  public static final String REGION_SORT_KEY = "region";
  public static final String COUNTRY_SORT_KEY = "country";
  public static final String STATE_SORT_KEY = "state";

  private static final ComparatorMap<XmlObject> comparatorMap;

  static {
    comparatorMap = new ComparatorMap<XmlObject>(new ContactLocationRelationsipDefaultComparator());
    comparatorMap.addComparator(NAME_SORT_KEY.toLowerCase(), new ContactLocationRelationshipNameComparator());
    comparatorMap.addComparator(REGION_SORT_KEY.toLowerCase(), new ContactLocationRelationshipRegionComparator());
    comparatorMap.addComparator(STATE_SORT_KEY.toLowerCase(), new ContactLocationRelationshipStateComparator());
    comparatorMap.addComparator(COUNTRY_SORT_KEY.toLowerCase(), new ContactLocationRelationshipCountryComparator());
  }

    public ContactLocationRelationshipDataSource(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initLookupContactService());
    }

    public ContactLocationRelationshipDataSource(UCCHelper helper, LookupContactService contactService) {
        this(new UCCHelperParameterCollection(helper), contactService);
    }

    public ContactLocationRelationshipDataSource(ParameterCollection params) {
        this(params, InitService.initLookupContactService());
    }

    public ContactLocationRelationshipDataSource(ParameterCollection params, LookupContactService contactService) {
        this.params = params;
        this.contactService = contactService;
    }

    public List<? extends XmlObject> getData() throws IOException {
    String contactId = params.get(ContactConstants.CONTACT_ID);
    ContactInfo contact = contactService.lookupContactById(contactId);
    List<LocationContactRelationship> locConRels = contact.getActiveLocationContactRelationships();
    List<LocationRelationship> contactRelationships = new ArrayList<LocationRelationship>();
    for (LocationContactRelationship relationship : locConRels) {
      contactRelationships.add(getContactRelationshipInformation(contactId, relationship));
    }
    return contactRelationships;
  }

  public Comparator<XmlObject> getComparator(String sortKey) {
    return comparatorMap.getComparator(sortKey);
  }

  private LocationRelationship getContactRelationshipInformation(String contactId,
                                                                 LocationContactRelationship locContactRel) {
    String locationId = locContactRel.getLocation().getLocationId();
    HrpUrlBuilder urlBuilder = new HrpUrlBuilder("bp");
    String removeUrl = urlBuilder.getEndLocationToContactRelationship(contactId, locationId);
    String viewUrl = urlBuilder.getViewLocationUrl(locationId);
    String updatePrimaryFlagUrl = urlBuilder.getSetPrimaryLocationUrl(locationId, contactId);
    boolean isPrimary = locContactRel.getIsLocationPrimary();
    boolean isSap = locContactRel.getLocation().getIsSap();
    String sapId = locContactRel.getLocation().getSapId();
    String locationName = locContactRel.getLocation().getLocationName();
    String bpLocRelType = locContactRel.getLocation().getActiveBPLoctationRelationship().getBpLocRelType().getType();
    Address address = getAdddressInformationForLocation(locContactRel.getLocation());
    return new LocationRelationshipImpl(locationId, isPrimary, sapId, isSap, locationName,
        bpLocRelType, viewUrl, removeUrl,
        updatePrimaryFlagUrl,
        address.getRegionModel().getValue(), address.getStateModel().getValue(), address.getCountryModel().getValue()
    );
  }

  private Address getAdddressInformationForLocation(Location location) {
    return location.getAddress();
  }

  public boolean isSorted() {
    return false;
  }

  public boolean isFiltered() {
    return false;
  }

  public int getTotalRecords() {
    return DataSource.UNKNOWN_RECORD_COUNT;
  }
}