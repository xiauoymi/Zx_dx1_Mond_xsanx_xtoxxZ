/*
 ContactLocationRelationsipDefaultComparator was created on May 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.locationContactRelationship.datasource;

import com.monsanto.wst.humanrightspolicy.model.LocationRelationship;

/**
 * Filename:    $RCSfile: ContactLocationRelationsipDefaultComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-05-12 20:15:51 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class ContactLocationRelationsipDefaultComparator extends ContactLocationRelationshipComparator{
  protected String getValue(LocationRelationship locConRel) {
    return locConRel.getLocationId();
  }
}