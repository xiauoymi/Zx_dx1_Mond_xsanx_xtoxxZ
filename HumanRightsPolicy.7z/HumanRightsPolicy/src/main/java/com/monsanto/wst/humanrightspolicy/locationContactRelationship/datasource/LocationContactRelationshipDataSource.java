/*
 LocationContactRelationshipDataSource was created on May 9, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.locationContactRelationship.datasource;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.datasource.ComparatorMap;
import com.monsanto.wst.humanrightspolicy.datasource.DataSource;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Filename:    $RCSfile: LocationContactRelationshipDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * sspati1 $    	 On:	$Date: 2008-12-04 16:50:10 $
 *
 * @author rrmall
 * @version $Revision: 1.16 $
 */
public class LocationContactRelationshipDataSource implements XmlDataSource {
    private final ParameterCollection params;
    private final LocationService locationService;

    public static final String NAME_SORT_KEY = "name";
    public static final String REGION_SORT_KEY = "region";
    public static final String COUNTRY_SORT_KEY = "country";
    public static final String STATE_SORT_KEY = "state";
    private static final ComparatorMap<XmlObject> comparatorMap;

    static {
        comparatorMap = new ComparatorMap<XmlObject>(new LocationContactRelationshipDefaultComparator());
        comparatorMap.addComparator(NAME_SORT_KEY, new LocationContactRelationshipNameComparator());
        comparatorMap.addComparator(REGION_SORT_KEY, new LocationContactRelationshipRegionComparator());
        comparatorMap.addComparator(COUNTRY_SORT_KEY, new LocationContactRelationshipCountryComparator());
        comparatorMap.addComparator(STATE_SORT_KEY, new LocationContactRelationshipStateComparator());
    }

    public LocationContactRelationshipDataSource(UCCHelper helper) {
        this(new UCCHelperParameterCollection(helper), InitService.initLocationService());
    }

    public LocationContactRelationshipDataSource(UCCHelper helper,
                                                 LocationService locationService) {
        this(new UCCHelperParameterCollection(helper), locationService);
    }

    public LocationContactRelationshipDataSource(ParameterCollection params) {
        this(params, InitService.initLocationService());
    }

    public LocationContactRelationshipDataSource(ParameterCollection params,
                                                 LocationService locationService) {
        this.params = params;
        this.locationService = locationService;
    }

    public List<? extends XmlObject> getData() throws IOException {
        String locationId = params.get(LocationsConstants.LOCATION_ID);
        Location location = locationService.lookupLocationById(locationId);
        List<LocationContactRelationship> locConRels = location.getActiveLocationContactRelationships();
        List<ContactRelationship> contactRelationships = new ArrayList<ContactRelationship>();
        for (LocationContactRelationship relationship : locConRels) {
            contactRelationships.add(getContactRelationshipInformation(locationId, relationship));
        }
        return contactRelationships;
    }

    public Comparator<XmlObject> getComparator(String sortKey) {
        return comparatorMap.getComparator(sortKey);
    }

    private ContactRelationship getContactRelationshipInformation(String locationId,
                                                                  LocationContactRelationship locContactRel) {
        ContactInfo contact = locContactRel.getContact();
        String contactId = contact.getContactId();
        boolean isPrimary = locContactRel.getIsContactPrimary();
        Address address = getAdddressInformationForContact(contact);
        HrpUrlBuilder urlBuilder = new HrpUrlBuilder("bp");
        String removeUrl = urlBuilder.getEndLocationToContactRelationship(contactId, locationId);
        String viewUrl = urlBuilder.getViewContactUrl(contactId);
        String updatePrimaryFlagUrl = urlBuilder.getSetPrimaryContactUrl(contactId, locationId);
        return new ContactRelationshipImpl(contactId, contact.getContactName(), isPrimary, contact.getIsSap(), viewUrl,
                removeUrl, updatePrimaryFlagUrl,
                address.getRegionModel().getValue(), address.getStateModel().getValue(), address.getCountryModel().getValue());
    }

    private Address getAdddressInformationForContact(ContactInfo contact) {
        return contact.getPrimaryRelationship().getLocation().getAddress();
    }

    public boolean isSorted() {
        return false;
    }

    public boolean isFiltered() {
        return false;
    }

    public int getTotalRecords() {
        return DataSource.UNKNOWN_RECORD_COUNT;
    }
}