/*
 LocationContactRelationshipStateComparator was created on May 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.locationContactRelationship.datasource;

import com.monsanto.wst.humanrightspolicy.model.ContactRelationship;

/**
 * Filename:    $RCSfile: LocationContactRelationshipStateComparator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-05-12 14:16:08 $
 *
 * @author rrmall
 * @version $Revision: 1.1 $
 */
public class LocationContactRelationshipStateComparator extends LocationContactRelationshipComparator{
  protected String getValue(ContactRelationship locConRel) {
    return locConRel.getState();
  }
}