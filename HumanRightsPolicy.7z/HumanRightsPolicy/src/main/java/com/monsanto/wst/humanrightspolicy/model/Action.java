/*
 ActionImpl was created on Aug 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.humanrightspolicy.datasource.Filterable;
import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import com.monsanto.wst.textutil.TextUtil;
import org.hibernate.annotations.AccessType;

import javax.persistence.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: Action.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-17 21:05:13 $
 *
 * @author rrmall
 * @version $Revision: 1.17 $
 */

@Entity
@AccessType("field")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@Table(schema="HRPOLICY", name="ACTION")
public class Action extends HRPEntity implements XmlObject, Filterable {
//  @Id
//  @Column(name="ID")
//  @SequenceGenerator(name="hrpSeq", sequenceName = "HRPOLICY.HRP_SEQ")
//  @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="hrpSeq")
//  private Long id;

  @Column(name="NAME")
  private String name;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name="DUE_DATE")
  private Date dueDate;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name="DATE_COMPLETED")
  private Date dateCompleted;

  @JoinColumn(name="STATUS_ID")
  @ManyToOne(fetch= FetchType.EAGER, targetEntity= Status.class)
  private Status status;

  @JoinColumn(name="PRIORITY_ID")
  @ManyToOne(targetEntity=ActionPriority.class)
  private ActionPriority priority;

  @Column(name="PERCENT_COMPLETE")
  private String percentageComplete;

  @Column(name="DESCRIPTION", length = 2000)
  private String description;

  @Column(name="START_DATE")
  private Date startDate;

  @ManyToOne
  @JoinColumn(name="PARENT_ITEM_ID", referencedColumnName = "ID")
  @org.hibernate.annotations.OrderBy(clause = "NAME asc")
  private Action parent;

  @OneToMany(
      cascade=CascadeType.REMOVE
  )
  @JoinColumn(name="PARENT_ITEM_ID", referencedColumnName = "ID")
  private List<Action> subActionItems = new ArrayList<Action>();

  @OneToMany(
      mappedBy = "target",
      targetEntity=Assignment.class,
      cascade=CascadeType.REMOVE
      //fetch = FetchType.EAGER
  )
    private List<Assignment> assignments = new ArrayList<Assignment>();
//
//  @Column(name="IS_DELETED")
//  private boolean isDeleted = false;


  public Action() {
    super();
  }

  public Action(Long id, String name, Date startDate, Date dueDate, Date dateCompleted, Status status,
                ActionPriority priority,
                String percentageComplete, String description, Action parentId) {
    super(id);
    this.name = name;
    this.startDate = startDate;
    this.dueDate = dueDate;
    this.dateCompleted = dateCompleted;
    this.status = status;
    this.priority = priority;
    this.percentageComplete = percentageComplete;
    this.description = description;
    this.parent = parentId;
  }

  public Action(Long id) {
    super(id);
  }

    public String getName() {
    return name;
  }

  public Date getDueDate() {
    return dueDate;
  }

  public Date getDateCompleted() {
    return dateCompleted;
  }

  public Status getStatus() {
    return status;
  }

  public ActionPriority getPriority() {
    return priority;
  }

  public String getPercentageComplete() {
    return percentageComplete;
  }

  public Date getStartDate() {
    return startDate;
  }

  public String getDescription() {
    return description;
  }

  public String getFormattedStartDate(){
    return formatDate(startDate);
  }

  public String getFormattedDueDate(){
    return formatDate(dueDate);
  }

  public String getFormattedDateCompleted(){
    return formatDate(dateCompleted);
  }


  private String  formatDate(Date date) {
    SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
    try {
      return dateFormatter.format(date);
    } catch (Exception e) {
      return "";
    }
  }

  public String toXml() {
     String actionId = getId().toString();
    String date = null;
    String viewUrl = new HrpUrlBuilder("action").getViewActionUrl(actionId);
    StringBuffer xml = new StringBuffer("<action>");
    xml.append("<actionId>").append(TextUtil.escapeXml(actionId)).append("</actionId>");
    xml.append("<actionName>").append(TextUtil.escapeXml(getName())).append("</actionName>");
    xml.append("<actionStartDate>").append(TextUtil.escapeXml(getFormattedStartDate())).append("</actionStartDate>");
    appendDateAndStatusToXml(xml);
    appendPriorityToXml(xml);
    xml.append("<actionPercentComplete>").append(TextUtil.escapeXml(getPercentageComplete())).append("</actionPercentComplete>");
    xml.append("<actionDescription>").append(TextUtil.escapeXml(getDescription())).append("</actionDescription>");
    xml.append("<actionViewUrl>").append(TextUtil.escapeXml(viewUrl)).append("</actionViewUrl>");
    xml.append("</action>");
    return xml.toString();
  }

  private void appendPriorityToXml(StringBuffer xml) {
    if (getPriority() != null){
      xml.append("<actionPriority>").append(TextUtil.escapeXml(getPriority().getValue())).append("</actionPriority>");
    }else{
      xml.append("<actionPriority>").append(TextUtil.escapeXml("")).append("</actionPriority>");
    }
  }

  private void appendDateAndStatusToXml(StringBuffer xml) {
    if (getStatus() != null){
      xml.append("<actionStatus>").append(TextUtil.escapeXml(getStatus().getValue())).append("</actionStatus>");
      if ("Closed".equalsIgnoreCase(getStatus().getValue())){
        xml.append("<actionDate>").append(TextUtil.escapeXml(getFormattedDueDate())).append("</actionDate>");
      }else{
        xml.append("<actionDate>").append(TextUtil.escapeXml(getFormattedDateCompleted())).append("</actionDate>");
      }
    }else{
      xml.append("<actionStatus>").append(TextUtil.escapeXml("")).append("</actionStatus>");
    }
  }

  public void setId(Long id) {
    super.setId(id);
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setDueDate(Date dueDate) {
    this.dueDate = dueDate;
  }

  public void setDateCompleted(Date dateCompleted) {
    this.dateCompleted = dateCompleted;
  }

  public void setStatus(Status status) {
    this.status = status;
  }

  public void setPriority(ActionPriority priority) {
    this.priority = priority;
  }

  public void setPercentageComplete(String percentageComplete) {
    this.percentageComplete = percentageComplete;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  public void setParent(Action parent) {
    this.parent = parent;
  }

  public List<Action> getSubActionItems() {
    return subActionItems;
  }

  public Action getParent() {
    return parent;
  }

  public boolean filter(String filterValue) {
    return TextUtil.contains(getName(), filterValue);
  }

  public List<Assignment> getAssignments() {
    return assignments;
  }

  public void setAssignments(List<Assignment> assignments) {
    this.assignments = assignments;
  }
}