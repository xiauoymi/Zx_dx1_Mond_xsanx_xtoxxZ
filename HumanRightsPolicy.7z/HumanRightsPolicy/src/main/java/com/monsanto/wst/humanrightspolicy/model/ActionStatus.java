/*
 ActionStatus was created on Aug 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Filename:    $RCSfile: ActionStatus.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:23 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */

@Entity
@AccessType("field")
@NoDeleteAllowed
@Table(schema="HRPOLICY", name="ACTION_STATUS")

public class ActionStatus {

  @Id
  @Column(name="STATUS_ID")
  Long id;

  @Column(name="STATUS_NAME")
  String value;

  

  public ActionStatus() {
  }

  public ActionStatus(Long id, String value) {
    this.id = id;
    this.value = value;
  }

  public Long getId() {
    return id;
  }

  public String getValue() {
    return value;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public void setValue(String value) {
    this.value = value;
  }
}