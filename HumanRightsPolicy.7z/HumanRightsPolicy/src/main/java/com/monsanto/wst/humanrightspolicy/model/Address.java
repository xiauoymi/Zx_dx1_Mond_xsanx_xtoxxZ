package com.monsanto.wst.humanrightspolicy.model;


public class Address{
  private String addressId;
  private String streetAddress1;
  private String streetAddress2;
  private String city;
  private String zipcode;
  private Region regionModel;
  private StateProvince stateModel;
  private Country countryModel;

  public Address() {
  }

  public Address(String addressId) {
    this.addressId = addressId;
  }

  public Address(Country countryModel) {
    this.countryModel = countryModel;
  }

  public Address(String addressId, String street1, String street2, String city, String zipcode,
                 String stateId, String state,
                 String countryId, String country,
                 String regionId, String region) {
    this(addressId, street1, street2, city, zipcode,
        new StateProvince(stateId, state),
        new Country(countryId, country),
        new Region(regionId, region));
  }

  public Address(String addressId, String street1, String street2, String city, String zipcode, StateProvince stateModel,
                 Country countryModel, Region regionModel) {
    this.addressId = addressId;
    this.streetAddress1 = street1;
    this.streetAddress2 = street2;
    this.city = city;
    this.stateModel = stateModel;
    this.countryModel = countryModel;
    this.zipcode = zipcode;
    this.regionModel = regionModel;
  }

  public String getStreetAddress1() {
    return streetAddress1;
  }

  public String getStreetAddress2() {
    return streetAddress2;
  }

  public void setAddressId(String addressId) {
    this.addressId = addressId;
  }

  public String getAddressId() {
    return addressId;
  }

  public String getCity() {
    return city;
  }

  public StateProvince getStateModel() {
    return stateModel;
  }

  public Country getCountryModel() {
    return countryModel;
  }

  public void setRegionModel(Region regionModel) {
    this.regionModel = regionModel;
  }

  public Region getRegionModel() {
    return regionModel;
  }

  public String getZipcode() {
    return zipcode;
  }

  public void setStateModel(StateProvince stateModel) {
    this.stateModel = stateModel;
  }

  public void setCountryModel(Country countryModel) {
    this.countryModel = countryModel;
  }

  public void setStreetAddress1(String streetAddress1) {
    this.streetAddress1 = streetAddress1;
  }

  public void setStreetAddress2(String streetAddress2) {
    this.streetAddress2 = streetAddress2;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public void setZipcode(String zipcode) {
    this.zipcode = zipcode;
  }

  public String toString() {
    return "(ADDR" + addressId + ": " + streetAddress1 + ", " + streetAddress2 + ", " + city + ", " + stateModel + ", " + countryModel + ", " + zipcode + ", " + regionModel + ')';
  }
}
