/*
 Assignment was created on Sep 29, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.humanrightspolicy.datasource.Filterable;
import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import com.monsanto.wst.textutil.TextUtil;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: Assignment.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-16 22:22:29 $
 *
 * @author rrmall
 * @version $Revision: 1.3 $
 */

@Entity
@AccessType("field")
@Table(schema = "HRPOLICY", name="ASSIGNMENT")
public class Assignment implements XmlObject, Filterable {
  @Id
   @SequenceGenerator(name="hrpSeq", sequenceName = "HRPOLICY.HRP_SEQ")
  @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="hrpSeq")
  private Long id;

  @JoinColumn(name="USER_ID")
  @ManyToOne(targetEntity = LoginUserImpl.class,fetch = FetchType.EAGER)
  private LoginUser user;

  @ManyToOne(
      targetEntity= HRPEntity.class
  )
  private HRPEntity target;

  @Column(name = "IS_PRIMARY")
  @Type(type="yes_no")
  private boolean isPrimary;

  @Enumerated(EnumType.STRING)
  @Column(name = "TYPE", updatable = false)
  private HRPEntityType entityType;


  public Assignment() {
  }

  public Assignment(Long id) {
    this.id = id;
  }

  public Assignment(Long id, LoginUser user, HRPEntity target, boolean primary, HRPEntityType entityType) {
    this.id = id;
    this.user = user;
    this.target = target;
    this.isPrimary = primary;
    this.entityType = entityType;
  }

  public HRPEntity getTarget() {
    return target;
  }

  public void setTarget(HRPEntity target) {
    this.target = target;
  }

  public Long getId() {
    return id;
  }

  public LoginUser getUser() {
    return user;
  }

  public boolean getIsPrimary() {
    return isPrimary;
  }

  public String getIsPrimaryAsString(){
    return isPrimary?"true":"false";
  }

  public String getIsPrimaryAsYorN(){
    return isPrimary ? "Y": "N";
  }

  public HRPEntityType getEntityType() {
    return entityType;
  }

  public String toXml() {
    String assignmentId = getId().toString();
    String date = null;
    String viewUrl = new HrpUrlBuilder("assignment").getViewActionUrl(assignmentId);
    String updatePrimaryFlagUrl = new HrpUrlBuilder("assignment").getSetPrimaryAssignmentForTargetUrl(assignmentId, getTarget().getId().toString());
    StringBuffer xml = new StringBuffer("<assignment>");
    xml.append("<assignmentId>").append(TextUtil.escapeXml(assignmentId)).append("</assignmentId>");
    xml.append("<assignmentUserId>").append(TextUtil.escapeXml(getUser().getUserId())).append("</assignmentUserId>");
    xml.append("<assignmentUserName>").append(TextUtil.escapeXml(getUser().getUserName())).append("</assignmentUserName>");
    xml.append("<isPrimary>").append(TextUtil.escapeXml(getIsPrimaryAsYorN())).append("</isPrimary>");
    xml.append("<updatePrimaryFlagUrl>").append(TextUtil.escapeXml(updatePrimaryFlagUrl)).append("</updatePrimaryFlagUrl>");
    xml.append("<assignmentViewUrl>").append(TextUtil.escapeXml(viewUrl)).append("</assignmentViewUrl>");
    xml.append("</assignment>");
    return xml.toString();
  }

  public boolean filter(String filterValue) {
    return TextUtil.contains(getUser().getUserName(), filterValue);
  }

  public void setIsPrimary(boolean isPrimary) {
    this.isPrimary = isPrimary;
  }
}