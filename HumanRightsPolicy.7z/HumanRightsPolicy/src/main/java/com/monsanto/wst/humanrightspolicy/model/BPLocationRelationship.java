/*
 BPLocationRelationship was created on Feb 8, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import java.util.Date;

/**
 * @author sspati1
 */
public interface BPLocationRelationship extends XmlObject {
  BusinessPartner getBusinessPartner();
  boolean getIsPrimary();
  Date getStartDate();
  Date getEndDate();
  Location getLocation();
  void setId(String relId);

  LocationType getBpLocRelType();

  String getId();
}