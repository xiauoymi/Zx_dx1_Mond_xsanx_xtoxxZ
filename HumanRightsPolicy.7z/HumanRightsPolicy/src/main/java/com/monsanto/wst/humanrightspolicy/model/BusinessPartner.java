/*
 BusinessPartner was created on Feb 8, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import java.util.Date;
import java.util.List;

/**
 * @author sspati1
 */
public interface BusinessPartner extends XmlObject, DetailedXmlObject{
  Date getAddBPDate();
  String getFormattedValue(String value);
  String formatSAPId(String id);

  String getSapId();
  String getLegacyId();
  String getPartnerId();

  String getWebsiteUrl();

  List<BPLocationRelationship> getActiveBPLocationRelationships();
  List<Location> getLocations();
  BPLocationRelationship getPrimaryRelationship();

  String getEntityName();
  String getAliasName();
  String getActive();
  String getIsComplete();
  String getHrpFlag();
  String getNotes();
  Address getAddress();

  void setPrimaryLocation(Location newPrimaryLocation);

  void addLocationRelationship(Location loc, boolean isPrimary, LocationType bpLocType);

  List<ContactInfo> getActiveContacts();

  ContactInfo getPrimaryContact();

  void setHrpFlag(String hrpFlag);

  void setIsComplete(String isComplete);

  void setActive(String isActive);

  void setPartnerId(String partnerId);

  String getFullName();

  void endBpLocRelationship(Location location);

  List<Communication> getCommunications();

  String getHrpTypesAsCommaSeparatedString();

    String getFormattedSapId();

  String getHrpTypes();
}