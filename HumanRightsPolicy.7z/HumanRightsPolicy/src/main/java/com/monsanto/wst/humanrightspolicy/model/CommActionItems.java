package com.monsanto.wst.humanrightspolicy.model;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 29, 2008
 * Time: 4:34:39 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CommActionItems extends XmlObject {
        String getActionId();

}
