package com.monsanto.wst.humanrightspolicy.model;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 30, 2008
 * Time: 8:28:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class CommActionItemsImpl implements CommActionItems {
  private String actionId;

  public CommActionItemsImpl(String actionId) {
    this.actionId = actionId;
  }

  public String getActionId() {
    return actionId;
  }

  public String toXml() {
    return null; // we are not interested in this at this point
  }
}
