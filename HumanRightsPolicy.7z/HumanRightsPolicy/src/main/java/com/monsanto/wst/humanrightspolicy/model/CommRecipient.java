/*
 Recipient was created on Apr 16, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import org.w3c.dom.Element;

/**
 * Filename:    $RCSfile: CommRecipient.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:20 $
 *
 * @author sspati1
 * @version $Revision: 1.17 $
 */
public interface CommRecipient extends XmlObject{
    String getIsDone();

    String getCommRecipientId();

    String getCommId();

    String getContactId();

    String getName();

    ContactType getLocConRelType();

    String getBpName();

    LocationType getBpLocRelType();

    Address getAddress();

    String getSapId();

  String hasContactsPrimaryRelationshipEnded();

  Element appendXML(Element parentElement);
}