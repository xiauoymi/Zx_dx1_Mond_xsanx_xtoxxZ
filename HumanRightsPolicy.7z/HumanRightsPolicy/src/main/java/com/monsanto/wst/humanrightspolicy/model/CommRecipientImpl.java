/*
 RecipientImpl was created on Apr 16, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.humanrightspolicy.datasource.Filterable;
import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import com.monsanto.wst.textutil.TextUtil;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Element;

import java.util.Date;

/**
 * Filename:    $RCSfile: CommRecipientImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date:
 * 2008/05/22 18:25:02 $
 *
 * @author sspati1
 * @version $Revision: 1.32 $
 */
public class CommRecipientImpl implements CommRecipient, Filterable {
  private final String isDone;
  private final String commRecipientId;
  private final String commId;
  private final String contactId;
  private final String name;
  private final LocationType bpLocRelType;
  private final ContactType locConRelType;
  private final String bpName;
  private final String sapId;
  private final Date locContactRelEndDate;
  private final Address address;

  public CommRecipientImpl(String contactId, String commRecipientId, String commId, String isDone,
                           String name,
                           Long bpRelTypeId, String bpLocRelTypeValue, Long locConRelTypeId,
                           String locConRelTypeValue,
                           String regionId, String regionValue, String countryId, String countryValue, String stateId,
                           String stateValue, String bpName,
                           String sapId, String addressId, String addressOne, String addressTwo, String city,
                           String postalCode, Date locContactRelEndDate) {

    this.commRecipientId = commRecipientId;
    this.commId = commId;
    this.contactId = contactId;
    this.isDone = isDone;
    this.name = name;
    this.sapId = sapId;
    this.locContactRelEndDate = locContactRelEndDate;
    this.address = new Address(addressId, addressOne, addressTwo, city, postalCode,
        new StateProvince(getNullIfEmpty(stateId), stateValue),
        new Country(getNullIfEmpty(countryId), countryValue),
        new Region(getNullIfEmpty(regionId), regionValue));
    this.bpLocRelType = new LocationType(bpRelTypeId, bpLocRelTypeValue);
    this.locConRelType = new ContactType(locConRelTypeId, locConRelTypeValue);
    this.bpName = bpName;
  }

  public String getIsDone() {
    return this.isDone;
  }

  public String getCommRecipientId() {
    return commRecipientId;
  }

  public String getCommId() {
    return commId;
  }

  public String getContactId() {
    return contactId;
  }

  public String getName() {
    return name;
  }

  public ContactType getLocConRelType() {
    return locConRelType;
  }

  public LocationType getBpLocRelType() {
    return bpLocRelType;
  }

  public String getBpName() {
    return bpName;
  }

  public Date getLocContactRelEndDate() {
    return locContactRelEndDate;
  }

  public String hasContactsPrimaryRelationshipEnded(){
    return locContactRelEndDate == null ? "N" : "Y";
  }

  public Element appendXML(Element parentElement) {
    Element recipientElement = DOMUtil.addChildElement(parentElement, "recipient");
    DOMUtil.addChildElement(recipientElement, "id", getCommRecipientId());
    DOMUtil.addChildElement(recipientElement, "isDone", getIsDone());
    DOMUtil.addChildElement(recipientElement, "sapId", getSapId());
    DOMUtil.addChildElement(recipientElement, "name", getName());
    DOMUtil.addChildElement(recipientElement, "recipientTypeValue", getLocConRelType().getType());
    DOMUtil.addChildElement(recipientElement, "company", getBpName());
    DOMUtil.addChildElement(recipientElement, "region", getAddress().getRegionModel().getValue());
    DOMUtil.addChildElement(recipientElement, "country", getAddress().getCountryModel().getValue());
    DOMUtil.addChildElement(recipientElement, "state", getAddress().getStateModel().getValue());
    DOMUtil.addChildElement(recipientElement, "address", getAddress().getStreetAddress1());
    DOMUtil.addChildElement(recipientElement, "address_two", getAddress().getStreetAddress2());
    DOMUtil.addChildElement(recipientElement, "city", getAddress().getCity());
    DOMUtil.addChildElement(recipientElement, "postal_code", getAddress().getZipcode());
    return recipientElement;
  }

  public String toXml() {
    StringBuffer xml = new StringBuffer("<recipient>");
    xml.append("<recipientId>").append(TextUtil.escapeXml(getContactId())).append("</recipientId>");
    xml.append("<commId>").append(TextUtil.escapeXml(getCommId())).append("</commId>");
    xml.append("<hasContactsPrimaryRelationshipEnded>").append(TextUtil.escapeXml(hasContactsPrimaryRelationshipEnded())).append("</hasContactsPrimaryRelationshipEnded>");
    xml.append("<isDone>").append(TextUtil.escapeXml(getIsDone())).append("</isDone>");
    xml.append("<name>").append(TextUtil.escapeXml(getName())).append("</name>");
    xml.append("<recipientTypeValue>").append(TextUtil.escapeXml(getLocConRelType().getType()))
        .append("</recipientTypeValue>");
    xml.append("<company>").append(TextUtil.escapeXml(getBpName())).append("</company>");
    xml.append("<region>").append(TextUtil.escapeXml(getAddress().getRegionModel().getValue())).append("</region>");
    xml.append("<country>").append(TextUtil.escapeXml(getAddress().getCountryModel().getValue()))
        .append("</country>");
    xml.append("<state>").append(TextUtil.escapeXml(getAddress().getStateModel().getValue())).append("</state>");
    xml.append("<address>").append(TextUtil.escapeXml(getAddress().getStreetAddress1())).append("</address>");
    xml.append("<address_two>").append(TextUtil.escapeXml(getAddress().getStreetAddress2())).append("</address_two>");
    xml.append("<city>").append(TextUtil.escapeXml(getAddress().getCity())).append("</city>");
    xml.append("<postal_code>").append(TextUtil.escapeXml(getAddress().getZipcode())).append("</postal_code>");
    xml.append("<viewUrl>").append(TextUtil.escapeXml(new HrpUrlBuilder("allcomm").getViewContactUrl(getContactId())))
        .append("</viewUrl>");
    xml.append("<updateDoneFlagUrl>")
        .append(TextUtil.escapeXml(new HrpUrlBuilder("allcomm").getUpdateDoneFlagUrl(getCommId(), getContactId())))
        .append("</updateDoneFlagUrl>");
    xml.append("<addRecipientUrl>")
        .append(TextUtil.escapeXml(new HrpUrlBuilder("allcomm").getAddRecipientUrl(getContactId())))
        .append("</addRecipientUrl>");
    xml.append("<removeUrl>")
        .append(TextUtil.escapeXml(new HrpUrlBuilder("allcomm").getDeleteRecipientUrl(getContactId())))
        .append("</removeUrl>");
    xml.append("<removeUrlForAsync>")
        .append(TextUtil.escapeXml(new HrpUrlBuilder("allcomm").getDeleteRecipientUrlForAysn(getContactId())))
        .append("</removeUrlForAsync>");

    xml.append("</recipient>");
    return xml.toString();

  }

  private String getNullIfEmpty(String id) {
    if (StringUtils.isEmpty(id)) {
      return null;
    } else {
      return id;
    }
  }

  public Address getAddress() {
    return address;
  }

  public String getSapId() {
    return sapId;
  }

  public boolean filter(String filterValue) {
    boolean nameMatchesFilter = TextUtil.contains(getName(), filterValue);
    boolean companyMatchesFilter = TextUtil.contains(getBpName(), filterValue);

    return nameMatchesFilter || companyMatchesFilter;
  }
}