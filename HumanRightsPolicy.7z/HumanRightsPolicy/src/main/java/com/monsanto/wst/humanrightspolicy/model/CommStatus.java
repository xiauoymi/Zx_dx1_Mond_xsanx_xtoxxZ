package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@Entity
@AccessType("field")
@Table(schema="HRPOLICY", name="COMM_STATUS")
@NoDeleteAllowed
public class CommStatus {
    @Id
    @Column(name="COMM_STATUS_ID")
    private Long id;

    @Column(name="STATUS")
    private String status;

    protected CommStatus() {
    }

    public CommStatus(Long id, String status) {
        this.id = id;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public String getStatus() {
        return status;
    }

    //todo see if getValue is needed
    //value is being used in jsp.
  public String getValue(){
      return status;
    }
}
