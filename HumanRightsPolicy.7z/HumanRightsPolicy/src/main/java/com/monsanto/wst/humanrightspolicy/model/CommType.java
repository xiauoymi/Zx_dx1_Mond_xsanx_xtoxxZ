package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.wst.humanrightspolicy.utils.NumberUtil;
import org.hibernate.annotations.AccessType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */

@Entity
@AccessType("field")
@Table(schema="HRPOLICY", name="COMM_TYPE")
@NoDeleteAllowed
public class CommType implements Comparable{

    @Id
    @Column(name="COMM_TYPE_ID")
    private Long id;

    @Column(name="TYPE")
    private String type;

    public CommType() {
    }

    public CommType(String id, String type) {
        this(NumberUtil.stringToLong(id), type); //todo refactor this constructor away
    }

    public CommType(Long id, String type) {
        this.id = id;
        this.type = type;
    }

    public Long getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public int compareTo(Object o) {
        return id.compareTo(((CommType) o).getId());
    }

    //todo see if getValue is needed
  //value is being used by jsp.
    public String getValue(){
      return type;
    }
}
