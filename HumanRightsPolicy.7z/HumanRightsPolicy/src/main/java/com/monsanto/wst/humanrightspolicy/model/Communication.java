package com.monsanto.wst.humanrightspolicy.model;

import org.w3c.dom.Document;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: Communication.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:20 $
 *
 * @author sspati1
 * @version $Revision: 1.21 $
 */
public interface Communication extends XmlObject{
  String getId();
  String getName();
  String getNotes();

  Date getFromDate();
  Date getToDate();
  Date getDueDate();
  long getDueInDays();
  boolean getIsUrgent();
  Date getDateCompleted();

  CommType getCommType();
  ContactType getLocConRelType();
  LocationType getBpLocRelType();
  CommStatus getStatus();

  String getFormattedFromDate();
  String getFormattedToDate();
  String getFormattedDueDate();
  String getActive();

  List<CommRecipient> getRecipients();
  List<CommRecipient> getRecipientsByCriteria(CommRecipient criteria);
  List<CommRecipient> getRecipientsNotAssociatedWithThisCommunicationByCriteria(CommRecipient criteria);

  boolean areAllRecipientsMarkedAsDone();

  void updateDoneFlagForRecipient(String recipientId, String doneFlag);
  void deleteAllRecipients();
  void updateDoneFlagForAllRecipients(String doneFlag);
  void addRecipient(String recipientId);
  void addRecipients(List<CommRecipient> recipients);
  void updateDoneFlagForSelectedRecipients(List<String> selectedIds, String doneFlag);
  void deleteSelectedRecipients(List<String> selectedRecipientIds);

  String getUrlTitle();
  String getUrl();
  String getFormattedUrl();

  String getCopiedFromCommId();
  String getFormattedDateCompleted();

  void addActionItem(String actionID);
  List<Action> getActionItemsAsList();
  Document getActionItemsAsXML(); //todo refactor, feature envy
}
