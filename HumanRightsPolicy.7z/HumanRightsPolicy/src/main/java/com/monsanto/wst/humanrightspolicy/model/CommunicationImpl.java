/*
 CommunicationImpl was created on Apr 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.Util.date.DateUtil;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommActionItemsDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommActionItemsDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.datasource.Filterable;
import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import com.monsanto.wst.textutil.TextUtil;
import org.w3c.dom.Document;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Filename:    $RCSfile: CommunicationImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date:
 * 2008/07/16 15:20:16 $
 *
 * @author sspati1
 * @version $Revision: 1.41 $
 */
public class CommunicationImpl implements Communication, Filterable {
  private final String id;
  private final String name;
  private final String notes;
  private final Date fromDate;
  private final Date toDate;
  private final Date dueDate;
  private final String active;
  private final CommType commType;
  private final ContactType locConRelType;
  private final LocationType bpLocRelType;
  private final CommStatus status;
  private final String url;
  private String copiedFromCommId;
  private final String urlTitle;
  private Date dateCompleted;

  public CommunicationImpl(String id, String name, String notes, Date fromDate, Date toDate,
                           Date dueDate, String active, String urlTitle, String url, Long commTypeId,
                           String commTypeValue,
                           Long commStatusId, String commStatusValue,
                           Long recipientTypeId, String recipientTypeValue,
                           Long locationTypeId, String locationTypeValue, String copiedFromCommId, Date dateCompleted) {
    this.id = id;
    this.name = name;
    this.notes = notes;
    this.fromDate = fromDate;
    this.toDate = toDate;
    this.dueDate = dueDate;
    this.active = active;
    this.urlTitle = urlTitle;
    this.url = url;
    this.copiedFromCommId = copiedFromCommId;
    this.commType = new CommType(commTypeId, commTypeValue);
    this.locConRelType = new ContactType(recipientTypeId, recipientTypeValue);
    this.bpLocRelType = new LocationType(locationTypeId, locationTypeValue);
    this.status = new CommStatus(commStatusId, commStatusValue); //to change to be passed in
    this.dateCompleted = dateCompleted;
  }

  public String getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public String getNotes() {
    return notes;
  }

  public Date getFromDate() {
    return fromDate;
  }

  public Date getToDate() {
    return toDate;
  }

  public Date getDueDate() {
    return dueDate;
  }

  public String getActive() {
    return active;
  }

  public String getUrlTitle() {
    return urlTitle;
  }

  public String getUrl() {
    return url;
  }

  public String getCopiedFromCommId() {
    return copiedFromCommId;
  }

  public String getFormattedUrl() {
    if (this.url == null) {
      return null;
    } else {
      String link = "<a href='";
      if (!this.url.startsWith("http://")) {
        link += "http://";
      }
      link += this.url + "'>" + this.urlTitle + "</a>";
      return link;
    }
  }

  public boolean getIsUrgent() {
    return this.dueDate != null && !isCommClosed() && ((getDueInDays() <= 15) ||
        (getDueInDays() <= 30 && !isCommReady()));
  }

  public long getDueInDays() {
    if (this.dueDate == null) {
      return 0;
    } else {
      Calendar todayWithTime = Calendar.getInstance();
      int year = todayWithTime.get(Calendar.YEAR);
      int month = todayWithTime.get(Calendar.MONTH);
      int day = todayWithTime.get(Calendar.DAY_OF_MONTH);
      Calendar today = new GregorianCalendar(year, month, day);
      return DateUtil.getHowManyDays(today.getTime(), this.dueDate);
    }
  }

  public CommType getCommType() {
    return commType;
  }

  public ContactType getLocConRelType() {
    return locConRelType;
  }

  public LocationType getBpLocRelType() {
    return bpLocRelType;
  }

  public CommStatus getStatus() {
    return status;
  }

  public String getFormattedFromDate() {
    return getFormattedDate(this.fromDate);
  }

  public String getFormattedToDate() {
    return getFormattedDate(this.toDate);
  }

  public String getFormattedDueDate() {
    return getFormattedDate(this.dueDate);
  }

   public String getFormattedDateCompleted() {
    return getFormattedDate(this.dateCompleted);
  }

  public List<CommRecipient> getRecipients() {
    return getCommRecipientDAO().lookupRecipientsByCommId(this.id);
  }

  public List<CommRecipient> getRecipientsByCriteria(CommRecipient criteria) {
    return getCommRecipientDAO().lookupRecipientsForCommunicationByCriteria(criteria);
  }

  public List<CommRecipient> getRecipientsNotAssociatedWithThisCommunicationByCriteria(CommRecipient criteria) {
    return getCommRecipientDAO().lookupRecipientsNotAssociatedWithThisCommunicationByCriteria(criteria);
  }

  public void updateDoneFlagForRecipient(String recipientId, String doneFlag) {
    getCommRecipientDAO().updateDoneFlagForRecipient(this.id, recipientId, doneFlag);
  }

  public void updateDoneFlagForSelectedRecipients(List<String> selectedIds, String doneFlag) {
    getCommRecipientDAO().updateDoneFlagForSelectedRecipients(this.id, selectedIds, doneFlag);
  }

  public void updateDoneFlagForAllRecipients(String doneFlag) {
    getCommRecipientDAO().updateDoneFlagForAllRecipients(this.id, doneFlag);
  }

  public boolean areAllRecipientsMarkedAsDone() {
    List<String> recipients = getCommRecipientDAO().lookupRecipientsNotMarkedAsDone(this.id);
    return recipients.isEmpty();
  }

  public void deleteAllRecipients() {
    getCommRecipientDAO().deleteAllRecipients(this.id);
  }

  public void deleteSelectedRecipients(List<String> selectedRecipientIds) {
    getCommRecipientDAO().deleteSelectedRecipients(this.id, selectedRecipientIds);
  }

  public void addRecipient(String recipientId) {
    getCommRecipientDAO().addRecipient(this.id, recipientId);
  }

  public void addRecipients(List<CommRecipient> recipients) {
    getCommRecipientDAO().addRecipients(this.id, recipients);
  }

  public String toXml() {
    StringBuffer xml = new StringBuffer("<communication>");
    xml.append("<id>").append(TextUtil.escapeXml(getId())).append("</id>");
    xml.append("<urgent>").append(TextUtil.escapeXml(getUrgent())).append("</urgent>");
    xml.append("<name>").append(TextUtil.escapeXml(getName())).append("</name>");
    xml.append("<fromPeriod>").append(TextUtil.escapeXml(getFormattedFromDate())).append("</fromPeriod>");
    xml.append("<toPeriod>").append(TextUtil.escapeXml(getFormattedToDate())).append("</toPeriod>");
    if ("Closed".equalsIgnoreCase(getStatus().getStatus())){
      xml.append("<dueDate>").append(TextUtil.escapeXml(getFormattedDateCompleted())).append("</dueDate>");
    }else{
      xml.append("<dueDate>").append(TextUtil.escapeXml(getFormattedDueDate())).append("</dueDate>");
    }
    xml.append("<active>").append(TextUtil.escapeXml(getActive())).append("</active>");
    xml.append("<link>").append(TextUtil.escapeXml(getFormattedUrl())).append("</link>");
    xml.append("<commTypeValue>").append(TextUtil.escapeXml(getCommType().getType())).append("</commTypeValue>");
    xml.append("<recipientTypeValue>").append(TextUtil.escapeXml(getLocConRelType().getType()))
        .append("</recipientTypeValue>");
    xml.append("<locTypeValue>").append(TextUtil.escapeXml(getBpLocRelType().getType())).append("</locTypeValue>");
    xml.append("<status>").append(TextUtil.escapeXml(getStatus().getStatus())).append("</status>");
    xml.append("<viewUrl>").append(TextUtil.escapeXml(new HrpUrlBuilder("myComms").getViewCommUrl(getId())))
        .append("</viewUrl>");

    xml.append("</communication>");
    return xml.toString();
  }

  public boolean filter(String filterValue) {
    return TextUtil.contains(getName(), filterValue);
  }

  protected CommRecipientDAO getCommRecipientDAO() {
    DBTemplateImpl template = new DBTemplateImpl("database/dbtemplate-config.xml",
        new String[]{"database/dbtemplate.xml"});
    return new DBTemplateCommRecipientDAO(template);
  }

  private String getUrgent() {
    return getIsUrgent() ? "Y" : "N";
  }

  private boolean isCommClosed() {
    return "CLOSED".equalsIgnoreCase(this.status.getStatus());
  }

  private boolean isCommReady() {
    return "READY".equalsIgnoreCase(this.status.getStatus());
  }

  private String getFormattedDate(Date date) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    try {
      return sdf.format(date);
    }
    catch (Exception e) {
      return "";
    }
  }

  public Date getDateCompleted() {
    return dateCompleted;
  }

  public void addActionItem(String actionID) {
    this.getCommActionItemsDAO().addActionItem(this.id, actionID);
  }

  public List<Action> getActionItemsAsList() {
    return getCommActionItemsDAO().lookupActionItemsByCommId(this.id);
  }

  public CommActionItemsDAO getCommActionItemsDAO() {
    DBTemplateImpl template = new DBTemplateImpl("database/dbtemplate-config.xml",
        new String[]{"database/dbtemplate.xml"});
    return new DBTemplateCommActionItemsDAO(template, InitService.initActionDAO());
  }

  public Document getActionItemsAsXML() {
    return getCommActionItemsDAO().lookupActionItemsByCommIdAsXML(this.id);
  }
}