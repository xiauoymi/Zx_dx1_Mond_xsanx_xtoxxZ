/*
 CommunicationSearchCriteria was created on Aug 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import java.util.Date;

/**
 * Filename:    $RCSfile: CommunicationSearchCriteria.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-22 21:42:24 $
 *
 * @author SSPATI1
 * @version $Revision: 1.3 $
 */
public class CommunicationSearchCriteria {
  private final Communication communication;
  private final Date dueDateFrom;
  private final Date dueDateTo;
  private final String stateId;
  private final String countryId;
  private final String regionId;

  public CommunicationSearchCriteria(Communication communication, Date dueDateFrom, Date dueDateTo, String stateId,
                                     String countryId, String regionId) {
    this.communication = communication;
    this.dueDateFrom = dueDateFrom;
    this.dueDateTo = dueDateTo;
    this.stateId = stateId;
    this.countryId = countryId;
    this.regionId = regionId;
  }

  public Communication getCommunication() {
    return communication;
  }

  public String getStateId() {
    return stateId;
  }

  public String getCountryId() {
    return countryId;
  }

  public String getRegionId() {
    return regionId;
  }

  public Date getDueDateFrom() {
    return dueDateFrom;
  }

  public Date getDueDateTo() {
    return dueDateTo;
  }

}