package com.monsanto.wst.humanrightspolicy.model;

import java.util.List;

/*
 ContactInfo was created on Feb 6, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public interface ContactInfo {

  String getContactEmail();

  String getContactNamePrefix();

  String getContactId();

  String getContactName();

  String getContactTitle();

  String getContactWorkPhone();

  String getContactMobilePhone();

  String getContactFax();

  List<LocationContactRelationship> getActiveLocationContactRelationships();

  LocationContactRelationship getPrimaryRelationship();

  BusinessPartner getActiveBusinessPartner();

  void setPrimaryLocation(Location location, String userId);

//  void addLocation(Location location, String userId);

  List<Communication> getCommunications();

  boolean getIsSap();

}