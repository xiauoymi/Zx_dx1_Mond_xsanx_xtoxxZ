package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.locationContactRelationship.dao.LocationContactRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.locationContactRelationship.dao.dbtemplate.DBtemplateLocationContactRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Jun 16, 2006 Time: 3:05:22 PM To change this template use File |
 * Settings | File Templates.
 */
public class ContactInfoImpl implements ContactInfo {
  private String contactId;
  private String contactNamePrefix;
  private String contactName;
  private String contactTitle;
  private String contactWorkPhone;
  private String contactMobilePhone;
  private String contactFax;
  private String contactEmail;
  private String isSap;

  public ContactInfoImpl() {
  }

  public ContactInfoImpl(String contactId) {
    this.contactId = contactId;
  }

  public ContactInfoImpl(String contactId,
                         String contactNamePrefix, String contactName, String contactTitle,
                         String contactWorkPhone, String contactMobilePhone, String contactFax,
                         String contactEmail, String isSap) {
    this.contactId = contactId;
    this.contactNamePrefix = contactNamePrefix;
    this.contactName = contactName;
    this.contactTitle = contactTitle;
    this.contactWorkPhone = contactWorkPhone;
    this.contactMobilePhone = contactMobilePhone;
    this.contactFax = contactFax;
    this.contactEmail = contactEmail;
    this.isSap = isSap;
  }

  protected String returnNullIfEmpty(String value) {
    if (value == null || StringUtils.isEmpty(value.trim())) {
      return null;
    } else {
      return value;
    }
  }

  @Override
  public boolean equals(Object obj) {
    return obj != null && obj instanceof ContactInfo && contactId.equals(((ContactInfo) obj).getContactId());
  }

  public int hashCode() {
    return contactId.hashCode();
  }

  public void setContactId(String contactId) {
    this.contactId = contactId;
  }

  public String getContactId() {
    return this.contactId;
  }

  public String getContactName() {
    return contactName;
  }

  public String getContactTitle() {
    return contactTitle;
  }

  public String getContactWorkPhone() {
    return contactWorkPhone;
  }

  public String getContactMobilePhone() {
    return contactMobilePhone;
  }

  public String getContactFax() {
    return contactFax;
  }

  public String getContactEmail() {
    return contactEmail;
  }

  public String getContactNamePrefix() {
    return contactNamePrefix;
  }

  public boolean getIsSap() {
    return isSap.equalsIgnoreCase("Y");
  }

  public LocationContactRelationship getActiveLocationContactRelationship() {
    return null;
  }

  public List<LocationContactRelationship> getActiveLocationContactRelationships() {
    try {
      return getLocationContactRelationshipDAO()
          .getActiveLocationRelationshipsForContact(getContactId());
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  public LocationContactRelationship getPrimaryRelationship() {
    for (LocationContactRelationship rel : getActiveLocationContactRelationships()) {
      if (rel.getIsLocationPrimary()) {
        return rel;
      }
    }
    return null;
  }

  public BusinessPartner getActiveBusinessPartner() {
    for (LocationContactRelationship locConRel : getActiveLocationContactRelationships()) {
      return locConRel.getLocation().getActiveBPLoctationRelationship().getBusinessPartner();
    }
    return null;
  }

  public void setPrimaryLocation(Location newPrimaryLocation, String userId) {
    LocationContactRelationshipDAO dao = getLocationContactRelationshipDAO();
    try {
      endOldPrimaryLocationRelationship(userId, dao);
      LocationContactRelationship newPrimarysExistingRel = getNewPrimarysExistingRelationship(newPrimaryLocation);
        dao.endLocationContactRelationship(newPrimarysExistingRel.getLocation().getLocationId(),
            newPrimarysExistingRel.getContact().getContactId());
      dao.saveLocationContactRelationship(newPrimaryLocation.getLocationId(), getContactId(),
          newPrimarysExistingRel.getIsContactPrimary(), true, new Date(), null, newPrimarysExistingRel.getLocConRelType().getId()
      );
    } catch (Exception e) {
      throw new RuntimeException("Unable to change primary location relationship", e);
    } 
  }

  public List<Communication> getCommunications() {
    return getCommunicationDAO().lookupCommunicationsByContactId(getContactId());
  }

  private LocationContactRelationship getNewPrimarysExistingRelationship(Location newPrimaryLocation) {
    for (LocationContactRelationship rel : getActiveLocationContactRelationships()) {
      if (rel.getLocation().equals(newPrimaryLocation)) {
        return rel;
      }
    }
    return null;
  }

  private void endOldPrimaryLocationRelationship(String userId, LocationContactRelationshipDAO dao
  ) {
    LocationContactRelationship oldPrimary = getPrimaryRelationship();
    if (oldPrimary != null) {
      dao.endLocationContactRelationship(oldPrimary.getLocation().getLocationId(), oldPrimary.getContact().getContactId()
      );

      dao.saveLocationContactRelationship(oldPrimary.getLocation().getLocationId(), oldPrimary.getContact().getContactId(),
         oldPrimary.getIsContactPrimary(), false, new Date(), null, oldPrimary.getLocConRelType().getId());
    }
  }

  protected LocationContactRelationshipDAO getLocationContactRelationshipDAO() {
    return new DBtemplateLocationContactRelationshipDAO(getTemplate());
  }

  protected CommunicationDAO getCommunicationDAO() {
      return InitService.initCommunicationDAO();
  }

  private DBTemplateImpl getTemplate() {
    return new DBTemplateImpl("database/dbtemplate-config.xml",
        new String[]{"database/dbtemplate.xml"});
  }
}
