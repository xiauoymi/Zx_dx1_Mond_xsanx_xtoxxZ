/*
 ContactRelationshipImpl was created on May 8, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.textutil.TextUtil;

/**
 * Filename:    $RCSfile: ContactRelationshipImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-07 16:07:31 $
 *
 * @author rrmall
 * @version $Revision: 1.13 $
 */
public class ContactRelationshipImpl implements ContactRelationship{
  private final String id;
  private final String viewUrl;
  private final String removeUrl;
  private final String updatePrimaryFlagUrl;
  private final String name;
  private final boolean isPrimary;
  private final boolean isSap;
  private final String state;
  private final String country;
  private final String region;

  public ContactRelationshipImpl(String id,
                                 String name, boolean isPrimary, boolean isSap,
                                 String viewUrl, String removeUrl,
                                 String updatePrimaryFlagUrl, String region, String state, String country) {
    this.id = id;
    this.name = name;
    this.isPrimary = isPrimary;
    this.isSap = isSap;
    this.viewUrl = viewUrl;
    this.removeUrl = removeUrl;
    this.updatePrimaryFlagUrl = updatePrimaryFlagUrl;
    this.region = region;
    this.state = state;
    this.country = country;
  }

  public boolean equals(Object obj) {
    if (obj instanceof ContactRelationship) {
      ContactRelationship relObj = (ContactRelationship) obj;
      return id.equals(relObj.getId());
    } else {
      return false;
    }
  }

  public int hashCode() {
    return id.hashCode();
  }

  public String getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public boolean getIsPrimary() {
    return isPrimary;
  }

  public boolean getIsSap() {
    return isSap;
  }

  public String getRegion() {
    return region;
  }

  public String getState() {
    return state;
  }

  public String getCountry() {
    return country;
  }

  public String getIsPrimaryAsYOrN() {
    return isPrimary ? "Y" : "N";
  }

  public String getIsSapAsYOrN() {
    return isSap ? "Y" : "N";
  }

  public String getViewUrl() {
    return viewUrl;
  }

  public String getRemoveUrl() {
    return removeUrl;
  }

  public String getUpdatePrimaryFlagUrl() {
    return updatePrimaryFlagUrl;
  }

  public String toXml() {
    StringBuffer xml = new StringBuffer("<contact>");
    xml.append("<contactId>").append(TextUtil.escapeXml(getId())).append("</contactId>");
    xml.append("<isPrimary>").append(TextUtil.escapeXml(getIsPrimaryAsYOrN())).append("</isPrimary>");
    xml.append("<name>").append(TextUtil.escapeXml(name)).append("</name>");
    xml.append("<state>").append(TextUtil.escapeXml(state)).append("</state>");
    xml.append("<country>").append(TextUtil.escapeXml(country)).append("</country>");
    xml.append("<region>").append(TextUtil.escapeXml(region)).append("</region>");
    xml.append("<isSap>").append(TextUtil.escapeXml(getIsSapAsYOrN())).append("</isSap>");
    xml.append("<removeUrl>").append(TextUtil.escapeXml(removeUrl)).append("</removeUrl>");
    xml.append("<viewUrl>").append(TextUtil.escapeXml(viewUrl)).append("</viewUrl>");
    xml.append("<updatePrimaryFlagUrl>").append(TextUtil.escapeXml(updatePrimaryFlagUrl)).append("</updatePrimaryFlagUrl>");
    xml.append("</contact>");
    return xml.toString();
  }
}