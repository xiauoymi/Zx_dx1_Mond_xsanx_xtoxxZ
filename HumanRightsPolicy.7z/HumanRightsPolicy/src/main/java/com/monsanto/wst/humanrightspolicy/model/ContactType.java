package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.wst.humanrightspolicy.utils.NumberUtil;
import com.monsanto.wst.humanrightspolicy.utils.XMLUtil;
import org.hibernate.annotations.AccessType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@Entity
@AccessType("field")
@Table(schema = "HRPOLICY", name = "LOC_CON_REL_TYPE")
@NoDeleteAllowed
public class ContactType implements XmlObject {
    //        implements Comparable
    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "TYPE")
    private String type;

    public ContactType() {
    }

    public ContactType(String id, String type) {
        this(NumberUtil.stringToLong(id), type); //todo refactory this constructor away
    }

    public ContactType(Long id, String type) {
        this.id = id;
        this.type = type;
    }

    public Long getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public String getValue() {
        return type;
    }

    public String toXml() {
        return "\t<ContactType>" +
                "\t\t<id>" + id + "</id>" +
                "\t\t<value>" + XMLUtil.xmlEncode(type) + "</value>" +
                "\t</ContactType>";
    }
}
