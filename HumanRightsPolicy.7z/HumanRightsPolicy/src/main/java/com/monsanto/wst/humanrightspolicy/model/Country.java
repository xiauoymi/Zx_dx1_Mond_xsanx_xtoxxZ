package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.wst.humanrightspolicy.assessment.GlbAsmtPolicyNameComparator;
import com.monsanto.wst.humanrightspolicy.assessment.GlobalAssessment;
import com.monsanto.wst.humanrightspolicy.assessment.Risk;
import com.monsanto.wst.humanrightspolicy.utils.XMLUtil;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Sort;
import org.hibernate.annotations.SortType;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.util.List;
import java.util.SortedSet;
/*
 Country was created on Feb 19, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
@Entity
@AccessType("field")
@NoDeleteAllowed
@Table(schema = "HRPOLICY", name = "COUNTRY")
public class Country implements Comparable, XmlObject {
    @Id
    @Column(name = "COUNTRY_ID")
    private String id;

    @Column(name = "COUNTRY")
    private String value;

    @OneToMany
    @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID")
    @org.hibernate.annotations.OrderBy(clause = "STATE_OR_PROVINCE asc")
    private List<StateProvince> states;

    @ManyToOne
    @JoinColumn(name = "REGION_ID")
    private Region region;

    @OneToMany
    @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID")
    @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
    @Sort(type = SortType.COMPARATOR, comparator = GlbAsmtPolicyNameComparator.class)
    private SortedSet<GlobalAssessment> glbAsmts;

    public Country() {
    }

    public Country(String id, String value) {
        this.id = id;
        this.value = value;
    }

    public List<StateProvince> getStates() {
        return states;
    }

    public SortedSet<GlobalAssessment> getGlobalAssessments() {
        return glbAsmts;
    }

    public String getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public Region getRegion() {
        return region;
    }

    public String toString() {
        return value;
    }

    public int compareTo(Object o) {
        return value.compareTo(((Country) o).getValue());
    }

    public boolean equals(Object obj) {
        if ((obj == null) || !(obj instanceof Country)) {
            return false;
        }
        Country country = (Country) obj;
        return this.id.equals(country.id);
    }

    public int hashCode() {
        return id.hashCode();
    }

    public Risk getOverallRisk() {
        Risk overallRisk = Risk.NotAssessed;
        for (GlobalAssessment ga : getGlobalAssessments()) {
            if (ga.getRisk().higherThan(overallRisk)) {
                overallRisk = ga.getRisk();
            }
        }
        return overallRisk;
    }


    public String toXml() {
        return "\t<Country>" +
                "\t\t<id>" + id + "</id>" +
                region.toXml() +
                "\t\t<value>" + XMLUtil.xmlEncode(value) + "</value>" +
                "\t</Country>";
    }
}

