/*
 Critetia was created on Mar 27, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import java.util.List;


/**
 * @author sspati1
 */
//todo this class can probably be eliminated now
public class CriteriaObject {
  private final List idList;

  public CriteriaObject(List list) {
    this.idList = list;
  }

  public List getIdList() {
    return idList;
  }
}