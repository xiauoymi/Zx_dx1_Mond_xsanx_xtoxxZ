package com.monsanto.wst.humanrightspolicy.model;

public interface DetailedXmlObject {
    //don't like the name of this class, or the method, but need to have alternate version of Xml, and don't want to mess with the old app code

    String toDetailedXml();
}
