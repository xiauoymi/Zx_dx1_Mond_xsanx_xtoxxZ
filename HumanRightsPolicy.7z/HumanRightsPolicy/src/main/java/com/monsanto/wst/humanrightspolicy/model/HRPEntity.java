package com.monsanto.wst.humanrightspolicy.model;

import org.hibernate.annotations.AccessType;

import javax.persistence.*;
/*
 AssignmentTarget was created on Sep 30, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@AccessType("field")
public abstract class HRPEntity {
  @Id
  @SequenceGenerator(name="hrpSeq", sequenceName = "HRPOLICY.HRP_SEQ")
  @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="hrpSeq")
  private Long id;

  public HRPEntity(Long id) {
    this.id = id;
  }

  public HRPEntity() {
  }

//  public abstract String getName();

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }
}