/*
 HrpType was created on Aug 26, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.wst.humanrightspolicy.utils.XMLUtil;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Where;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Filename:    $RCSfile: HrpType.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-12-04 16:49:57 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema = "HRPOLICY", name = "HRP_TYPE")
@Where(clause = "active = 'Y'")
public class HrpType implements XmlObject {
    @Id
    @Column(name = "HRP_TYPE_ID")
    private Long id;

    @Column(name = "HRP_TYPE")
    private String value;

    public HrpType() {
    }

    public HrpType(Long id, String value) {
        this.value = value;
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public String toXml() {
        return "\t<HrpType>\n" +
                "\t\t<id>" + id + "</id>\n" +
                "\t\t<value>" + XMLUtil.xmlEncode(value) + "</value>\n" +
                "\t</HrpType>";
    }
}