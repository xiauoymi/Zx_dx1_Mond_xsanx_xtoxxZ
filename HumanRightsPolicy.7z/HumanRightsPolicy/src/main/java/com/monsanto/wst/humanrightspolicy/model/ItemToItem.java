/*
 ItemToItem was created on Sep 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import org.hibernate.annotations.AccessType;

import javax.persistence.*;

/**
 * Filename:    $RCSfile: ItemToItem.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:23 $
 *
 * @author rrmall
 * @version $Revision: 1.3 $
 */
@Entity
@AccessType("field")
@Table(schema="HRPOLICY", name="ITEM_TO_ITEM")
public class ItemToItem {
  @Id
  @Column(name="ID")
  @SequenceGenerator(name="hrpSeq", sequenceName = "HRPOLICY.HRP_SEQ")
  @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="hrpSeq")
  Long  id;

  @JoinColumn(name = "PARENT_ITEM_ID")
  @ManyToOne(targetEntity = Action.class)
  Action parentItem;

  @JoinColumn(name = "CHILD_ITEM_ID")
  @ManyToOne(targetEntity = Action.class)
  Action childItem;

  public ItemToItem() {
  }

  public ItemToItem(Long id, Action parent, Action child) {
    this.id = id;
    this.parentItem = parent;
    this.childItem = child;
  }

  public Long getId() {
    return id;
  }

  public Action getParentItem() {
    return parentItem;
  }

  public Action getChildItem() {
    return childItem;
  }

  @ManyToOne(optional = false)
  private Action actions;

  public Action getActions() {
    return actions;
  }

  public void setActions(Action actions) {
    this.actions = actions;
  }
}