/*
 Location was created on Feb 8, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import java.util.List;

/**
 * @author sspati1
 */
public interface Location {
  String getLocationId();

  String getLocationName();

  String getSapId();

  String getActive();

  Address getAddress();

  List<LocationContactRelationship> getActiveLocationContactRelationships();

  BPLocationRelationship getActiveBPLoctationRelationship();

  LocationContactRelationship getPrimaryRelationship();

  void setPrimaryContact(ContactInfo newPrimaryContact, String userId);

  void setLocationId(String locId);

  void endLocationContactRelationship(String contactId, String userId);

  List<Communication> getCommunications();

  boolean getIsSap();

  String getIsSapAsYOrN();
}