/*
 LocationContactRelationship was created on Feb 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import java.util.Date;

/**
 * @author sspati1
 */
public interface LocationContactRelationship {
  String getRelId();

  Location getLocation();

  ContactInfo getContact();

  boolean getIsContactPrimary();

  Date getStartDate();

  Date getEndDate();

  boolean getIsLocationPrimary();

  void setRelId(String relId);

  ContactType getLocConRelType();
}