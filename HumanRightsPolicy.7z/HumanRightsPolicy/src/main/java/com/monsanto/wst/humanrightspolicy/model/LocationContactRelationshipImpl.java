/*
 LocationContactRelationshipImpl was created on Feb 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import java.util.Date;

/**
 * @author sspati1
 */
public class LocationContactRelationshipImpl implements LocationContactRelationship {
  private String relId;
  private final Location location;
  private final ContactInfo contact;
  private final boolean isContactPrimary;
  private final boolean isLocationPrimary;
  private final ContactType locConRelType;
  private final Date startDate;
  private final Date endDate;

  public LocationContactRelationshipImpl(String relId, Location location, ContactInfo contact, boolean isContactPrimary,
                                         boolean isLocationPrimary, ContactType locConRelType, Date startDate,
                                         Date endDate) {
    this.relId = relId;
    this.location = location;
    this.contact = contact;
    this.isContactPrimary = isContactPrimary;
    this.isLocationPrimary = isLocationPrimary;
    this.locConRelType = locConRelType;
    this.startDate = startDate;
    this.endDate = endDate;
  }

  public LocationContactRelationshipImpl(String relId, boolean isContactPrimary, boolean isLocationPrimary,
                                         Date startDate, Date endDate, String locConRelTypeId,
                                         String locConRelTypeValue,
                                         String contactId, String prefix,
                                         String contactName,
                                         String title, String isContacatSap, String locationId, String locName,
                                         String locSapId,
                                         String isLocationSap, String countryId, String countryName,
                                         String stateOrProvinceId, String stateOrProvinceName, String regionId,
                                         String regionName, String addressId, String addressOne, String addressTwo,
                                         String city,
                                         String postalCode) {
    this.relId = relId;
    this.isContactPrimary = isContactPrimary;
    this.isLocationPrimary = isLocationPrimary;
    this.locConRelType = new ContactType(locConRelTypeId, locConRelTypeValue);
    this.startDate = startDate;
    this.endDate = endDate;
    this.contact = new ContactInfoImpl(contactId, prefix, contactName, title, null, null, null, null, isContacatSap);
    this.location = new LocationImpl(locationId, locName, null, locSapId, isLocationSap, countryId, countryName,
        stateOrProvinceId, stateOrProvinceName, regionId, regionName, addressId, addressOne, addressTwo, city, postalCode);
  }

  public String getRelId() {
    return relId;
  }

  public void setRelId(String relId) {
    this.relId = relId;
  }

  public boolean equals(Object obj) {
    return obj != null && obj instanceof LocationContactRelationship &&
        relId.equals(((LocationContactRelationship) obj).getRelId());
  }

  public int hashCode() {
    return relId.hashCode();
  }

  public Location getLocation() {
    return location;
  }

  public ContactInfo getContact() {
    return contact;
  }

  public boolean getIsContactPrimary() {
    return isContactPrimary;
  }

  public boolean getIsLocationPrimary() {
    return isLocationPrimary;
  }

  public ContactType getLocConRelType() {
    return locConRelType;
  }

  public Date getStartDate() {
    return startDate;
  }

  public Date getEndDate() {
    return endDate;
  }

  public String getIsContactPrimaryAsYOrN() {
    return isContactPrimary ? "Y" : "N";
  }

  public String getIsLocationPrimaryAsYOrN() {
    return isLocationPrimary ? "Y" : "N";
  }
}