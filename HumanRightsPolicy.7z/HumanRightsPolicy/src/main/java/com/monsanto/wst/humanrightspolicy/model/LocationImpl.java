/*
 Facility was created on Jul 18, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.dbtemplate.DBTemplateBPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.locationContactRelationship.dao.LocationContactRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.locationContactRelationship.dao.dbtemplate.DBtemplateLocationContactRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.util.Date;
import java.util.List;

/**
 * @author sspati1
 */
public class LocationImpl implements Location {
  private String locationId;
  private String locationName;
  private String sapId;
  private String isSap;
  private String active;
  private Address address;

  public LocationImpl() {
  }

  public LocationImpl(String locationId) {
    this.locationId = locationId;
  }

  public LocationImpl(String locationId, String locationName, String sapId, String sap, String active, Address address) {
    this.locationId = locationId;
    this.locationName = locationName;
    this.sapId = sapId;
    this.isSap = sap;
    this.active = active;
    this.address = address;
  }

  public LocationImpl(String locationId, String locationName, String active, String sapId,
                      String isSap, String countryId,
                      String countryName,
                      String stateOrProvinceId, String stateOrProvinceName, String regionId, String regionName,
                      String addressId, String addressOne, String addressTwo, String city, String postalCode) {
    this.locationId = locationId;
    this.locationName = locationName;
    this.active = active;
    this.sapId = sapId;
    this.isSap = isSap;
    this.address = new Address(addressId, addressOne, addressTwo, city, postalCode,
        new StateProvince(stateOrProvinceId, stateOrProvinceName), new Country(countryId, countryName),
        new Region(regionId, regionName));
  }

  public String toString() {
    return "(Location: " + locationId + ", " + locationName + ", " + sapId + ", " + active +
        ", " + address + ')';
  }

  public boolean equals(Object obj) {
    if ((obj == null) || !(obj instanceof Location)) {
      return false;
    }
    Location location = (Location) obj;
    return this.locationId.equals(location.getLocationId());
  }

  public int hashCode() {
    return locationId.hashCode();
  }

  public String getLocationId() {
    return locationId;
  }

  public void setLocationId(String locationId) {
    this.locationId = locationId;
  }

  public String getLocationName() {
    return locationName;
  }

  public String getSapId() {
    return sapId;
  }

  public boolean getIsSap() {
    return isSap.equalsIgnoreCase("Y");
  }

  public String getIsSapAsYOrN() {
    return isSap;
  }

  public String getActive() {
    return active;
  }

  public void setActive(String active) {
    this.active = active;
  }

  public Address getAddress() {
    return address;
  }

  public void setAddress(Address address) {
    this.address = address;
  }

  public List<LocationContactRelationship> getActiveLocationContactRelationships() {
    try {
      return getLocationContactRelationshipDAO()
          .getActiveContactRelationshipsForLocation(getLocationId());
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  public BPLocationRelationship getActiveBPLoctationRelationship() {
    try {
      return getBPLocationRelationshipDAO().getActiveBPLocationRelationshipForLocation(this);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  public LocationContactRelationship getPrimaryRelationship() {
    for (LocationContactRelationship rel : getActiveLocationContactRelationships()) {
      if (rel.getIsContactPrimary()) {
        return rel;
      }
    }
    return null;
  }

//  public void addContact(ContactInfo contact, String userId) {
//    for (LocationContactRelationship rel : getActiveLocationContactRelationships()) {
//      if (rel.getContact().equals(contact)) {
//        //ignore if contact is already active with the location
//        return;
//      }
//    }
//    try {
//      LocationContactRelationship newRel = new LocationContactRelationshipImpl(null, this, contact, false, false,
//          df, new Date(), null,
//          null);
//      getLocationContactRelationshipDAO()
//          .saveLocationContactRelationship(newRel, userId, DBUtils.createPersistentStore());
//    } catch (Exception e) {
//      throw new RuntimeException(e);
//    }
//  }

  public void setPrimaryContact(ContactInfo newPrimaryContact, String userId) {
    LocationContactRelationshipDAO dao = getLocationContactRelationshipDAO();
    try {
      endOldPrimaryContactRelationship(userId, dao);
      LocationContactRelationship newPrimarysExistingRel = getNewPrimarysExistingRelationship(newPrimaryContact);
//      if (newPrimarysExistingRel != null) {
        dao.endLocationContactRelationship(getLocationId(), newPrimarysExistingRel.getContact().getContactId());
//      } else {
//        newRel = new LocationContactRelationshipImpl(null, this, newPrimaryContact,
//            true, false, df, new Date(), null, null);
//
//      }
      dao.saveLocationContactRelationship(getLocationId(), newPrimaryContact.getContactId(), true, newPrimarysExistingRel.getIsLocationPrimary(),
          new Date(), null, newPrimarysExistingRel.getLocConRelType().getId());
    } catch (Exception e) {
      throw new RuntimeException("Unable to change primary contact relationship", e);
    }
  }

  public void endLocationContactRelationship(String endContactId, String userId) {
    LocationContactRelationshipDAO dao = getLocationContactRelationshipDAO();
    try {
      dao.endLocationContactRelationship(this.locationId, endContactId);
    } catch (Exception e) {
      throw new RuntimeException("Unable to change primary contact relationship", e);
    }
  }

  public List<Communication> getCommunications() {
    return getCommunicationDAO().lookupCommunicationsByLocationId(getLocationId());
  }

  private void endOldPrimaryContactRelationship(String userId, LocationContactRelationshipDAO dao
  ) {
    LocationContactRelationship oldPrimary = getPrimaryRelationship();
    if (oldPrimary != null) {
      dao.endLocationContactRelationship(oldPrimary.getLocation().getLocationId(), oldPrimary.getContact().getContactId());
      dao.saveLocationContactRelationship(oldPrimary.getLocation().getLocationId(), oldPrimary.getContact().getContactId(),
          false, oldPrimary.getIsLocationPrimary(), new Date(), null, oldPrimary.getLocConRelType().getId());
    }
  }

  private LocationContactRelationship getNewPrimarysExistingRelationship(ContactInfo newPrimaryContact) {
    for (LocationContactRelationship rel : getActiveLocationContactRelationships()) {
      if (rel.getContact().equals(newPrimaryContact)) {
        return rel;
      }
    }
    return null;
  }

  protected BPLocationRelationshipDAO getBPLocationRelationshipDAO() {
    DBTemplateImpl template = getTemplate();
    return new DBTemplateBPLocationRelationshipDAO(template);
  }

  protected LocationContactRelationshipDAO getLocationContactRelationshipDAO() {
    return new DBtemplateLocationContactRelationshipDAO(getTemplate());
  }

  protected CommunicationDAO getCommunicationDAO() {
    return InitService.initCommunicationDAO();
  }

  private DBTemplateImpl getTemplate() {
    return new DBTemplateImpl("database/dbtemplate-config.xml",
        new String[]{"database/dbtemplate.xml"});
  }
}