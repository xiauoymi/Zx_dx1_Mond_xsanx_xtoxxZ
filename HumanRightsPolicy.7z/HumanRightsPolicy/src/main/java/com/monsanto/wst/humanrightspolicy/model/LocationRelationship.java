/*
 LocationRelationship was created on May 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

/**
 * Filename:    $RCSfile: LocationRelationship.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-07 16:07:31 $
 *
 * @author rrmall
 * @version $Revision: 1.4 $
 */
public interface LocationRelationship extends XmlObject{
  String getLocationId();
  String getLocationName();
  boolean getIsPrimary();
  String getSapId();
  String getState();
  String getCountry();
  String getRegion();

  String getViewUrl();
  String getRemoveUrl();
  String getUpdatePrimaryFlagUrl();

  boolean getIsSap();

  String getId();
}