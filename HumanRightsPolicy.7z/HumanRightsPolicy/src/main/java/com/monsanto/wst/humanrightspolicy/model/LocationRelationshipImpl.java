/*
 LocationRelationshipImpl was created on May 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.textutil.TextUtil;

/**
 * Filename:    $RCSfile: LocationRelationshipImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-06 16:07:45 $
 *
 * @author rrmall
 * @version $Revision: 1.8 $
 */
public class LocationRelationshipImpl implements LocationRelationship {
  private final String locationId;
  private final boolean isPrimary;
  private final String sapId;
  private final boolean isSap;
  private final String locationName;
  private final String bpLocRelType;
  private final String viewUrl;
  private final String removeUrl;
  private final String updatePrimaryFlagUrl;
  private final String region;
  private final String state;
  private final String country;

  public LocationRelationshipImpl(String locationId, boolean isPrimary, String sapId, boolean isSap,
                                  String locationName,
                                  String bpLocRelType,
                                  String viewUrl, String removeUrl, String updatePrimaryFlagUrl, String region,
                                  String state, String country) {
    this.locationId = locationId;
    this.isPrimary = isPrimary;
    this.sapId = sapId;
    this.isSap = isSap;
    this.locationName = locationName;
    this.bpLocRelType = bpLocRelType;
    this.viewUrl = viewUrl;
    this.removeUrl = removeUrl;
    this.updatePrimaryFlagUrl = updatePrimaryFlagUrl;
    this.region = region;
    this.state = state;
    this.country = country;
  }

  public String getId() {
    return null;
  }

  public String getLocationId() {
    return locationId;
  }

  public boolean getIsSap() {
    return isSap;
  }

  public boolean getIsPrimary() {
    return isPrimary;
  }

  public String getIsPrimaryAsYOrN(){
    return isPrimary?"Y":"N";
  }

  public String getIsSapAsYOrN(){
    return isSap?"Y":"N";
  }

  public String getSapId() {
    return sapId;
  }

  public String getLocationName() {
    return locationName;
  }

  public String getBpLocRelType() {
    return bpLocRelType;
  }

  public String getViewUrl() {
    return viewUrl;
  }

  public String getRemoveUrl() {
    return removeUrl;
  }

  public String getUpdatePrimaryFlagUrl() {
    return updatePrimaryFlagUrl;
  }

  public String getRegion() {
    return region;
  }

  public String getState() {
    return state;
  }

  public String getCountry() {
    return country;
  }

  public String toXml() {
     StringBuffer xml = new StringBuffer("<location>");
    xml.append("<locationId>").append(TextUtil.escapeXml(getLocationId())).append("</locationId>");
    xml.append("<sapId>").append(TextUtil.escapeXml(getSapId())).append("</sapId>");
    xml.append("<isPrimary>").append(TextUtil.escapeXml(getIsPrimaryAsYOrN())).append("</isPrimary>");
    xml.append("<locName>").append(TextUtil.escapeXml(locationName)).append("</locName>");
    xml.append("<bpLocRelType>").append(TextUtil.escapeXml(bpLocRelType)).append("</bpLocRelType>");
    xml.append("<state>").append(TextUtil.escapeXml(state)).append("</state>");
    xml.append("<country>").append(TextUtil.escapeXml(country)).append("</country>");
    xml.append("<region>").append(TextUtil.escapeXml(region)).append("</region>");
    xml.append("<isSap>").append(TextUtil.escapeXml(getIsSapAsYOrN())).append("</isSap>");
    xml.append("<removeUrl>").append(TextUtil.escapeXml(removeUrl)).append("</removeUrl>");
    xml.append("<viewUrl>").append(TextUtil.escapeXml(viewUrl)).append("</viewUrl>");
    xml.append("<updatePrimaryFlagUrl>").append(TextUtil.escapeXml(updatePrimaryFlagUrl)).append("</updatePrimaryFlagUrl>");
    xml.append("</location>");
    return xml.toString();
  }
}