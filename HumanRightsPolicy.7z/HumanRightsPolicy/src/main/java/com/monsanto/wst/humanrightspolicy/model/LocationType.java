package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.wst.humanrightspolicy.utils.XMLUtil;
import org.hibernate.annotations.AccessType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
@Entity
@Table(schema = "HRPOLICY", name = "BP_LOC_REL_TYPE")
@AccessType("field")
@NoDeleteAllowed
public class LocationType implements XmlObject {
    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "TYPE")
    private String type;

    public LocationType() {
    }

    public LocationType(Long id, String type) {
        this.id = id;
        this.type = type;
    }

    public Long getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    //todo see if getValue is needed
    //value is being used in jsp.
    public String getValue() {
        return type;
    }

    public String toXml() {
        return "\t<LocationType>" +
                "\t\t<id>" + id + "</id>" +
                "\t\t<value>" + XMLUtil.xmlEncode(type) + "</value>" +
                "\t</LocationType>";
    }
}
