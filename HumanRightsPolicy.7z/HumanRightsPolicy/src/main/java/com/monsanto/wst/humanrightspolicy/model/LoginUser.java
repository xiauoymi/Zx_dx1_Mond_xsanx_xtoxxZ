package com.monsanto.wst.humanrightspolicy.model;

import javax.persistence.MappedSuperclass;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/*
 LoginUser was created on Feb 11, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
@MappedSuperclass
public interface LoginUser extends Comparable {
  String getUserId();
  String getUserName();
  Role getRole();

  String getDescription();
  String getEmail();

  boolean getHasEditRole();
  boolean getHasReadOnlyRole();
  boolean isAdmin();
  boolean isInThisRole(String roleName);

  boolean isAuthorized(Region region);
  boolean isAuthorized(Country country);
  boolean isAuthorized(StateProvince state);

  boolean isAuthorizedExplicity(Region region) throws IOException;
  boolean isAuthorizedExplicity(Country country) throws IOException;
  boolean isAuthorizedExplicity(StateProvince state) throws IOException;

  List<Privilege> getPrivileges();

  void setPrivileges(List<Privilege> privileges);

  List<Region> getRegionsSpecificallyAuthorized();
  List<Country> getCountriesSpecificallyAuthorized();
  List<StateProvince> getStatesSpecificallyAuthorized();

  //todo addRegion/clearRegion, etc. these can probably be merged
  void addRegion(Region region);
  void addCountry(Country country);
  void addState(StateProvince state);

  void clearRegions();
  void clearCountries();
  void clearStates();

  void addPrivilege(Privilege privilege);
  void clearPrivileges();

  Long getId();

  void setRegionsSpecificallyAuthorized(List<Region> regionsSpecificallyAuthorized);

  void setCountriesSpecificallyAuthorized(List<Country> countriesSpecificallyAuthorized);

  void setStatesSpecificallyAuthorized(List<StateProvince> statesSpecificallyAuthorized);

    Map<String, Boolean> getPrivilegeMap();
}
