package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/*
 LoginUserBase was created on Feb 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
@Entity
@Table(schema="HRPOLICY", name="USER_ROLE")
@AccessType("field")
public class LoginUserImpl implements LoginUser {

  @Id
  @Column(name="ID")
  @SequenceGenerator(name="hrpSeq", sequenceName = "HRPOLICY.HRP_SEQ")
  @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="hrpSeq")
  private Long id;

  @Column(name="USER_ID")
  private String userId;

  @ManyToOne( cascade = {CascadeType.PERSIST, CascadeType.MERGE} )
  @JoinColumn(name="ROLE_ID")
  private Role role;

  @Column(name="IS_ADMIN")
  @Type(type="yes_no")
  private boolean isAdmin;

  @Column(name="NAME")
  private String userName;

  @Column(name="DESCRIPTION")
  private String description;

  @Column(name="EMAIL")
  private String email;

  @ManyToMany(
      targetEntity=Privilege.class,
      cascade={CascadeType.PERSIST, CascadeType.MERGE}
  )
  @JoinTable(
          schema="HRPOLICY",
          name="USER_PRIVILEGE",
          joinColumns=@JoinColumn(name="USER_ID"),
          inverseJoinColumns=@JoinColumn(name="PRIVILEGE_ID")
  )
  private List<Privilege> privileges;

  @ManyToMany(
      targetEntity=Region.class,
      cascade={CascadeType.PERSIST, CascadeType.MERGE}
  )
  @JoinTable(
          schema="HRPOLICY",
          name="USER_REGION",
          joinColumns=@JoinColumn(name="USER_ID"),
          inverseJoinColumns=@JoinColumn(name="REGION_ID")
  )
  private List<Region> regionsSpecificallyAuthorized;

  @ManyToMany(
      targetEntity=Country.class,
      cascade={CascadeType.PERSIST, CascadeType.MERGE}
  )
  @JoinTable(
          schema="HRPOLICY",
          name="USER_COUNTRY",
          joinColumns=@JoinColumn(name="USER_ID"),
          inverseJoinColumns=@JoinColumn(name="COUNTRY_ID")
  )
  private List<Country> countriesSpecificallyAuthorized;

  @ManyToMany(
      targetEntity=StateProvince.class,
      cascade={CascadeType.PERSIST, CascadeType.MERGE}
  )
  @JoinTable(
          schema="HRPOLICY",
          name="USER_STATE",
          joinColumns=@JoinColumn(name="USER_ID"),
          inverseJoinColumns=@JoinColumn(name="STATE_OR_PROVINCE_ID")
  )
  private List<StateProvince> statesSpecificallyAuthorized;

  public LoginUserImpl() {
    privileges = new ArrayList<Privilege>();
    regionsSpecificallyAuthorized = new ArrayList<Region>();
    countriesSpecificallyAuthorized = new ArrayList<Country>();
    statesSpecificallyAuthorized = new ArrayList<StateProvince>();
  }

  public LoginUserImpl(Long id, String userId, boolean isAdmin, Role role, String userName, String description,
                       String email) {
    this();
    this.id = id;
    this.userId = userId;
    this.isAdmin = isAdmin;
    this.role = role;
    this.userName = userName;
    this.description = description;
    this.email = email;
  }

  public boolean isAdmin() {
    return isAdmin;
  }

  public boolean isAuthorizedExplicity(Region region) {
    return regionsSpecificallyAuthorized.contains(region);
  }

  public List<Region> getRegionsSpecificallyAuthorized() {
    return new ArrayList<Region>(regionsSpecificallyAuthorized);
  }

  public List<Country> getCountriesSpecificallyAuthorized() {
    return new ArrayList<Country>(countriesSpecificallyAuthorized);
  }

  public List<StateProvince> getStatesSpecificallyAuthorized() {
    return new ArrayList<StateProvince>(statesSpecificallyAuthorized);
  }

  public boolean isAuthorizedExplicity(Country country) {
    Region region = country.getRegion();
    if (isAuthorizedExplicity(region)) {
      return countriesSpecificallyAuthorized.contains(country);
    } else {
      return false;
    }
  }

  public boolean isAuthorizedExplicity(StateProvince state) {
    Country country = state.getCountry();
    if (isAuthorizedExplicity(country)) {
      return statesSpecificallyAuthorized.contains(state);
    } else {
      return false;
    }
  }

  public boolean isAuthorized(Region region) {
    if (regionsSpecificallyAuthorized.size() == 0) {
      return true; // if no regions assigned, default is ALL regions
    } else {
      return regionsSpecificallyAuthorized.contains(region);
    }
  }

  public boolean isAuthorized(Country country) {
    if (country == null) {
      return true;
    }

    Region region = country.getRegion();
    if (isAuthorized(region)) {
      List<Country> countriesForRegion = region.getCountries();
      List<Country> countriesForUserInRegion = intersect(countriesSpecificallyAuthorized, countriesForRegion);
      if (countriesForUserInRegion.size() == 0) {
        return true;
      } else {
        return countriesForUserInRegion.contains(country);
      }
    } else {
      return false;
    }
  }

  public boolean isAuthorized(StateProvince state) {
    if (state == null) {
      return true;
    }

    Country country = state.getCountry();
    if (isAuthorized(country)) {
      List<StateProvince> statesForCountry = country.getStates();
      List<StateProvince> statesForUserInCountry = intersect(statesSpecificallyAuthorized, statesForCountry);
      if (statesForUserInCountry.size() == 0) {
        return true;
      } else {
        return statesForUserInCountry.contains(state);
      }
    } else {
      return false;
    }
  }

  private <T> List<T> intersect(List<T> list1, List<T> list2) {
    List<T> intersection = new ArrayList<T>();
    for (T item : list1) {
      if (list2.contains(item)) {
        intersection.add(item);
      }
    }
    return intersection;
  }


  public String getUserId() {
    return userId;
  }

  public String getUserName() {
    return userName;
  }

  public Role getRole() {
    return role;
  }

  public boolean getHasEditRole() {
    return isInThisRole(HRPMainConstants.EDIT_ROLE);
  }

  public boolean isInThisRole(String roleName) {
    if (role == null) {
      return false;
    } else {
      return roleName.equalsIgnoreCase(role.getRoleName());
    }
  }

  public boolean getHasReadOnlyRole() {
    return isInThisRole(HRPMainConstants.READ_ROLE);
  }

  public void addRegion(Region region) {
    regionsSpecificallyAuthorized.add(region);
  }

  public void addCountry(Country country) {
    countriesSpecificallyAuthorized.add(country);
  }

  public void addState(StateProvince state) {
    statesSpecificallyAuthorized.add(state);
  }

  public void clearRegions() {
    regionsSpecificallyAuthorized.clear();
  }

  public void clearCountries() {
    countriesSpecificallyAuthorized.clear();
  }

  public void clearStates() {
    statesSpecificallyAuthorized.clear();
  }

  public void addPrivilege(Privilege privilege) {
    privileges.add(privilege);
  }

  public void clearPrivileges() {
    privileges.clear();
  }

  public int compareTo(Object o) {
    if (o == null || !(o instanceof LoginUser)) {
      return -1;
    } else {
      return getUserId().compareTo(((LoginUser) o).getUserId());
    }
  }

  public String getDescription() {
    return description;
  }

  public String getEmail() {
    return email;
  }

  public List<Privilege> getPrivileges() {
    return new ArrayList<Privilege>(privileges);
  }

    public Map<String, Boolean> getPrivilegeMap(){
        Map<String, Boolean> map = new HashMap<String, Boolean>();
        for(Privilege priv: getPrivileges()){
            map.put(priv.getValue(), new Boolean(true));
        }
        return map;
    }

  public void setPrivileges(List<Privilege> privileges) {
    this.privileges = privileges;
  }

  public String toString() {
    return userId;
  }

  public Long getId() {
    return id;
  }

  public void setRegionsSpecificallyAuthorized(List<Region> regionsSpecificallyAuthorized) {
    this.regionsSpecificallyAuthorized = regionsSpecificallyAuthorized;
  }

  public void setCountriesSpecificallyAuthorized(List<Country> countriesSpecificallyAuthorized) {
    this.countriesSpecificallyAuthorized = countriesSpecificallyAuthorized;
  }

  public void setStatesSpecificallyAuthorized(List<StateProvince> statesSpecificallyAuthorized) {
    this.statesSpecificallyAuthorized = statesSpecificallyAuthorized;
  }
}
