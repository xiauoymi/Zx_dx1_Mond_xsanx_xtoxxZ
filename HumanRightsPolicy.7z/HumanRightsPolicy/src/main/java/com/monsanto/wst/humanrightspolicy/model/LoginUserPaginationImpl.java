/*
 LoginUserPaginationImpl was created on May 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.humanrightspolicy.datasource.Filterable;
import com.monsanto.wst.textutil.TextUtil;

/**
 * Filename:    $RCSfile: LoginUserPaginationImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-06 16:07:45 $
 *
 * @author rrmall
 * @version $Revision: 1.10 $
 */
public class LoginUserPaginationImpl implements LoginUserPagination, Filterable {
 private final String userName;
 private final String id;
 private final String role;
 private final String regions;
 private final String viewUrl;
 private final String removeUrl;
 private final String addUrl;
 private final String description;
  private final String email;

  public LoginUserPaginationImpl(String userName, String id, String role, String regions, String viewUrl,
                                 String removeUrl, String addUrl, String description, String email) {
    this.userName = userName;
    this.id = id;
    this.role = role;
    this.regions = regions;
    this.viewUrl = viewUrl;
    this.removeUrl = removeUrl;
    this.addUrl = addUrl;
    this.description = description;
    this.email = email;
  }

  public String getId() {
    return id;
  }

  public String getRole() {
    return role;
  }

  public String getRegions() {
    return regions;
  }

  public String getViewUrl() {
    return viewUrl;
  }

  public String getRemoveUrl() {
    return removeUrl;
  }

  public String getUserName() {
    return userName;
  }

  public String getAddUrl() {
    return addUrl;
  }

  public String getDescription() {
    return description;
  }

  public String getEmail() {
    return email;
  }

  public String getUserNameAndDescription() {
    StringBuffer nameDescription = new StringBuffer(getUserName());
    String descr = getDescription();
    if (descr == null || descr.length() == 0){
      descr = "";
    }else{
      descr = getDescription();
    }
    
    nameDescription.append("<br />").append(descr);
    return nameDescription.toString();
  }

  public String toXml() {
    StringBuffer xml = new StringBuffer("<user>");
    String nameDescription = getUserNameAndDescription();
    xml.append("<userName>").append(TextUtil.escapeXml(nameDescription)).append("</userName>");
    xml.append("<userID>").append(TextUtil.escapeXml(getId())).append("</userID>");
    xml.append("<role>").append(TextUtil.escapeXml(getRole())).append("</role>");
    xml.append("<regions>").append(TextUtil.escapeXml(getRegions())).append("</regions>");
    xml.append("<addUrl>").append(TextUtil.escapeXml(getAddUrl())).append("</addUrl>");
    xml.append("<viewUrl>").append(TextUtil.escapeXml(getViewUrl())).append("</viewUrl>");
    xml.append("<removeUrl>").append(TextUtil.escapeXml(getRemoveUrl())).append("</removeUrl>");
    xml.append("</user>");
    return xml.toString();
  }

  public boolean filter(String filterValue) {
    boolean idMatchesFilter = TextUtil.contains(getId(), filterValue);
    boolean nameMatchesFilter = TextUtil.contains(getUserName(), filterValue);

    return idMatchesFilter || nameMatchesFilter;
  }
}