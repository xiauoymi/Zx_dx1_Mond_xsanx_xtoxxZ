package com.monsanto.wst.humanrightspolicy.model;

import java.util.Map;

public class MapParameterCollection implements ParameterCollection {
    private final Map<String,String> map;

    public MapParameterCollection(Map<String, String> map) {
        this.map = map;
    }

    public String get(String name) {
        return map.get(name);
    }
}
