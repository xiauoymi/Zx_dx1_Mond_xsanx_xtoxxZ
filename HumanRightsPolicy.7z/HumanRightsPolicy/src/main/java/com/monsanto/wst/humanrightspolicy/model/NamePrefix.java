package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;

import javax.persistence.Entity;
import javax.persistence.Table;
/*
 NamePrefix was created on Aug 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
@Entity
@NoDeleteAllowed
@AccessType("field")
@Table(schema="HRPOLICY", name="CONTACT_NAME_PREFIX")
public class NamePrefix {
  private String prefix;

  public NamePrefix() {
    this("");
  }
  
  public NamePrefix(String prefix) {
    this.prefix = prefix;
  }

  public String getPrefix() {
    return prefix;
  }
}
