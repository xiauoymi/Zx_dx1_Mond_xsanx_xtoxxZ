package com.monsanto.wst.humanrightspolicy.model;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface ParameterCollection {
    String get(String name);
}

