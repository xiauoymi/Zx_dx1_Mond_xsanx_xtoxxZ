/*
 Privilege was created on Jul 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@AccessType("field")
@Table(schema="HRPOLICY", name="PRIVILEGE")
@NoDeleteAllowed
public class Privilege {
  @Id
  @Column(name="PRIVILEGE_ID")
  private final String id;

  @Column(name="PRIVILEGE_NAME")
  private final String value;

  public Privilege() {
    this("", "");
  }

  public Privilege(String id, String value) {
    this.id = id;
    this.value = value;
  }

//  public Privilege(String privilegeId, String privilegeName) {
//    this.id = privilegeId;
//    this.value = privilegeName;
//  }

  public String getId() {
    return id;
  }

  public boolean equals(Object obj) {
    if ((obj == null) || !(obj instanceof Privilege)) {
      return false;
    }
    Privilege otherPriv = (Privilege) obj;
    return this.id.equals(otherPriv.id);
  }

  public int hashCode() {
    return id.hashCode();
  }

  public String getValue() {
    return value;
  }

  public int compareTo(Object o) {
    return value.compareTo(((Privilege) o).getValue());
  }

  public String toString() {
    return value;
  }
}