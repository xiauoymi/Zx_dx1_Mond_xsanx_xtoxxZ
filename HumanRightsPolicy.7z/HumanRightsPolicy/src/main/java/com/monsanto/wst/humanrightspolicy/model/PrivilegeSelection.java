/*
 PrivilegeSelection was created on Aug 20, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

/**
 * Filename:    $RCSfile: PrivilegeSelection.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-22 21:42:24 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class PrivilegeSelection {
  private boolean selected;
  private final Privilege privilege;

  public PrivilegeSelection(Privilege privilege, boolean selected) {
    this.privilege = privilege;
    this.selected = selected;
  }

  public Privilege getPrivilege() {
    return privilege;
  }

  public boolean getSelected() {
    return selected;
  }

  public void setSelected(boolean selected) {
    this.selected = selected;
  }
}