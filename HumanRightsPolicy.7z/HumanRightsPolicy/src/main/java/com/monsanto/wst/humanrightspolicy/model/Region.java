package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.wst.humanrightspolicy.utils.XMLUtil;
import org.hibernate.annotations.AccessType;

import javax.persistence.*;
import java.util.List;/*
 Region was created on Feb 18, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
@Entity
@AccessType("field")
@NoDeleteAllowed
@Table(schema = "HRPOLICY", name = "REGION")
public class Region implements Comparable, XmlObject {
    @Id
    @Column(name = "REGION_ID")
    private String id;

    @Column(name = "REGION")
    private String value;

    @OneToMany
    @JoinColumn(name = "REGION_ID", referencedColumnName = "REGION_ID")
    @org.hibernate.annotations.OrderBy(clause = "COUNTRY asc")
    private List<Country> countries;

    public Region() {
    }

    public Region(String id, String value) {
        this.id = id;
        this.value = value;
    }

    public List<Country> getCountries() {
        return countries;
    }

    public String getId() {
        return id;
    }

    public boolean equals(Object obj) {
        if ((obj == null) || !(obj instanceof Region)) {
            return false;
        }
        Region region = (Region) obj;
        return this.id.equals(region.id);
    }

    public int hashCode() {
        return id.hashCode();
    }

    public String getValue() {
        return value;
    }

    public int compareTo(Object o) {
        return value.compareTo(((Region) o).getValue());
    }

    public String toString() {
        return value;
    }


    public String toXml() {
        return "\t<Region>" +
                "\t\t<id>" + id + "</id>" +
                "\t\t<value>" + XMLUtil.xmlEncode(value) + "</value>" +
                "\t</Region>";
    }
}
