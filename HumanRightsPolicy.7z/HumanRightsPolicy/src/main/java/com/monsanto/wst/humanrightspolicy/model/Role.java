/*
 Role was created on Mar 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import org.hibernate.annotations.AccessType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@AccessType("field")
@Table(schema="HRPOLICY", name="ROLE")
@NoDeleteAllowed
public class Role implements Serializable {
  @Id
  @Column(name="ROLE_ID")
  private String roleId;

  @Column(name="ROLE")
  private String roleName;

  Role() {
  }

  public Role(String roleId, String roleName) {
    this.roleId = roleId;
    this.roleName = roleName;
  }

  public String getRoleId() {
    return roleId;
  }

  public String getRoleName() {
    return roleName;
  }
}