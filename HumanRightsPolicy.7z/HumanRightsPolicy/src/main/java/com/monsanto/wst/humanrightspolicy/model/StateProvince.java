package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.hibernate.NoDeleteAllowed;
import com.monsanto.wst.humanrightspolicy.utils.XMLUtil;
import org.hibernate.annotations.AccessType;

import javax.persistence.*;
/*
 StateProvince was created on Feb 19, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
@Entity
@AccessType("field")
@NoDeleteAllowed
@Table(schema = "HRPOLICY", name = "STATE_OR_PROVINCE")
public class StateProvince implements Comparable<StateProvince>, XmlObject {
    @Id
    @Column(name = "STATE_OR_PROVINCE_ID")
    private String id;

    @Column(name = "STATE_OR_PROVINCE")
    private String value;

    @ManyToOne
    @JoinColumn(name = "COUNTRY_ID")
    private Country country;

    public StateProvince() {
    }

    public StateProvince(String id, String value) {
        this.id = id;
        this.value = value;
    }

    public String getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public int compareTo(StateProvince o) {
        return value.compareTo(o.getValue());
    }

    public String toString() {
        return value;
    }

    public boolean equals(Object obj) {
        if ((obj == null) || !(obj instanceof StateProvince)) {
            return false;
        }
        StateProvince stateProvince = (StateProvince) obj;
        return this.id.equals(stateProvince.id);
    }

    public int hashCode() {
        return id.hashCode();
    }

    public Country getCountry() {
        return country;
    }

    public String toXml() {
        return "\t<State>" +
                "\t\t<id>" + id + "</id>" +
                country.toXml() +
                "\t\t<value>" + XMLUtil.xmlEncode(value) + "</value>" +
                "\t</State>";
    }
}

