/*
 TempBPLocationRelationship was created on Apr 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;

import java.util.Date;

/**
 * Filename:    $RCSfile: TempBPLocationRelationship.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 19:19:27 $
*
* @author sspati1
* @version $Revision: 1.14 $
*/
public class TempBPLocationRelationship {
  private final BPLocationRelationship relationship;

  public TempBPLocationRelationship(BPLocationRelationship relationship) {
    this.relationship = relationship;
  }

  public TempBPLocationRelationship(String relId, String isPrimary, Date startDate, Date endDate, String locId,
                                    String locName, String locSapId, String isSap,
                                    String countryId, String country, String stateId,
                                    String state, String regionId,
                                    String region, String addressId, String streetAddress1, String streetAddress2,
                                    String city,
                                    String zipcode, Long bpLocRelTypeId, String bpLocRelType) {
    Location location = new LocationImpl(locId, locName, null, locSapId,
        isSap, countryId, country, stateId, state, regionId, region, addressId, streetAddress1, streetAddress2,
      city, zipcode);
    relationship = new BPLocationRelationshipImpl(relId, null,
        location, "Y".equalsIgnoreCase(isPrimary), new LocationType(bpLocRelTypeId, bpLocRelType), startDate, endDate);
  }

  public TempBPLocationRelationship(String relId, String isPrimary, Date startDate, Date endDate, String bpId,
                                    String name, String aliasName, String sapId, String isHrp, Long bpLocRelTypeId,
                                    String bpLocRelType) {
    BusinessPartner businessPartner = new BusinessPartnerImpl(bpId, sapId, null, name, aliasName, null, null, null, isHrp,
        null);
    relationship = new BPLocationRelationshipImpl(relId, businessPartner,
        null, "Y".equalsIgnoreCase(isPrimary), new LocationType(bpLocRelTypeId, bpLocRelType), startDate, endDate);
  }

  public BPLocationRelationship getRelationship() {
    return relationship;
  }
}