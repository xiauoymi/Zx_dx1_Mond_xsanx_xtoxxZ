/*
 TempLocationContactRelationship was created on May 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model;

import java.util.Date;

/**
 * Filename:    $RCSfile: TempLocationContactRelationship.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1
 * $    	 On:	$Date: 2008-10-17 15:36:20 $
 *
 * @author sspati1
 * @version $Revision: 1.8 $
 */
public class TempLocationContactRelationship {
  private final String contactId;
  private final String locationId;
  private final String relId;
  private final boolean isContactPrimary;
  private final boolean isLocationPrimary;
  private final Date startDate;
  private final Date endDate;
  private final Long locConRelTypeId;

  public TempLocationContactRelationship(String relId, String locationId, String contactId,
                                         boolean isContactPrimary,
                                         boolean isLocationPrimary, Date startDate, Date endDate,
                                         Long locConRelTypeId) {
    this.contactId = contactId;
    this.locationId = locationId;
    this.relId = relId;
    this.isContactPrimary = isContactPrimary;
    this.isLocationPrimary = isLocationPrimary;
    this.startDate = startDate;
    this.endDate = endDate;
    this.locConRelTypeId = locConRelTypeId;
  }

  public String getContactId() {
    return contactId;
  }

  public String getLocationId() {
    return locationId;
  }

  public String getRelId() {
    return relId;
  }

  public String getIsContactPrimaryAsYOrN() {
    return isContactPrimary ? "Y" : "N";
  }

  public String getIsLocationPrimaryAsYOrN() {
    return isLocationPrimary ? "Y" : "N";
  }

  public Date getStartDate() {
    return startDate;
  }

  public Date getEndDate() {
    return endDate;
  }

  public Long getLocConRelTypeId() {
    return locConRelTypeId;
  }
}