package com.monsanto.wst.humanrightspolicy.model;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.pos.DataRequestParser;

import java.io.IOException;

public class UCCHelperParameterCollection implements ParameterCollection {
    private final UCCHelper helper;

    public UCCHelperParameterCollection(UCCHelper helper) {
        this.helper = helper;
    }

    public String get(String name) {
        if (DataRequestParser.USER_ID.equalsIgnoreCase(name) || DataRequestParser.USER_ID_ONEWORD.equalsIgnoreCase(name)) {
            return helper.getAuthenticatedUserID();
        } else {
            return getParamFromHelper(name);
        }
    }

    private String getParamFromHelper(String name) {
        try {
            return helper.getRequestParameterValue(name);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
