package com.monsanto.wst.humanrightspolicy.note;

import com.monsanto.wst.humanrightspolicy.model.HRPEntity;
import org.hibernate.annotations.AccessType;

import javax.persistence.*;
/*
 Note was created on Oct 7, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
@Entity
@AccessType("field")
public class Note {
    @Id
    @Column(name = "ID")
    @SequenceGenerator(name = "hrpSeq", sequenceName = "HRPOLICY.HRP_SEQ")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hrpSeq")
    private Long id;

    @Column(name = "SUBJECT")
    private String subject;

    @Column(name = "TEXT")
    private String text;

    @ManyToOne(
        targetEntity= HRPEntity.class
    )
    private HRPEntity target;


    public Note() {
    }

    public Note(Long id, String subject, String text, HRPEntity target) {
        this.id = id;
        this.subject = subject;
        this.text = text;
        this.target = target;
    }

    public Long getId() {
        return id;
    }

    public String getSubject() {
        return subject;
    }

    public String getText() {
        return text;
    }

    public HRPEntity getTarget() {
        return target;
    }
}
