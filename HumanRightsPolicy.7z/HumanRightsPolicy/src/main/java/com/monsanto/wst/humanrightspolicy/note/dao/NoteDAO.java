package com.monsanto.wst.humanrightspolicy.note.dao;

import com.monsanto.wst.humanrightspolicy.model.HRPEntity;
import com.monsanto.wst.humanrightspolicy.note.Note;

import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface NoteDAO {
    void addNote(HRPEntity target, String subject, String text);

    Note findByPrimaryKey(Long id);

    List<Note> findByTarget(HRPEntity target);
}
