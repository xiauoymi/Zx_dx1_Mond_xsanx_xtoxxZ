package com.monsanto.wst.humanrightspolicy.note.dao;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.alert.dao.AlertDAO;
import com.monsanto.wst.humanrightspolicy.model.HRPEntity;
import com.monsanto.wst.humanrightspolicy.note.Note;

import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class NoteDAOImpl implements NoteDAO {
    private final GenericDAO<Note, Long> noteBaseDAO;
    private final AlertDAO alertDAO;

    public NoteDAOImpl(AlertDAO alertDAO, GenericDAO<Note, Long> noteBaseDAO) {
        this.alertDAO = alertDAO;
        this.noteBaseDAO = noteBaseDAO;
    }

    public void addNote(HRPEntity target, String subject, String text) {
        Note note = new Note(null, subject, text, target);
        noteBaseDAO.save(note);
        alertDAO.addAlert(target, subject, text);
    }

    public Note findByPrimaryKey(Long id) {
        return noteBaseDAO.findByPrimaryKey(id);
    }

    public List<Note> findByTarget(HRPEntity target) {
        Note exampleNote = new Note(null, null, null, target);
        String[] excludedFields = {"id", "subject", "text"};
        return noteBaseDAO.findByExample(exampleNote, excludedFields);
    }
}
