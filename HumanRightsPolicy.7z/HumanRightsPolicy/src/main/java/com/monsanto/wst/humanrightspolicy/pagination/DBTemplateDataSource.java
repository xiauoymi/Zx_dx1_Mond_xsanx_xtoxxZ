package com.monsanto.wst.humanrightspolicy.pagination;

import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.humanrightspolicy.datasource.DataSource;

import java.util.Comparator;
import java.util.List;
/*
 DBTemplatePaginator was created on Apr 16, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class DBTemplateDataSource<T> implements DataSource<T> {
  private final DBTemplate dbTemplate;
  private final String queryName;
  private final Object criteria;

  public DBTemplateDataSource(DBTemplate dbTemplate, String queryName, Object criteria) {
    this.dbTemplate = dbTemplate;
    this.queryName = queryName;
    this.criteria = criteria;
  }

  public DBTemplateDataSource(DBTemplate dbTemplate, String queryName) {
    this(dbTemplate, queryName, null);
  }

  public List<? extends T> getData() {
    if (criteria == null) {
      return (List<? extends T>) dbTemplate.executeListResultQuery(queryName);
    } else {
      return (List<? extends T>) dbTemplate.executeListResultQuery(queryName, criteria);
    }
  }

  public Comparator<T> getComparator(String sortName) {
    return new DefaultComparator<T>();
  }

  public boolean isSorted() {
    return false; //todo could add to check if a key was used and set to true if needed
  }

  public boolean isFiltered() {
    return false;
  }

  public int getTotalRecords() {
    return DataSource.UNKNOWN_RECORD_COUNT;
  }
}
