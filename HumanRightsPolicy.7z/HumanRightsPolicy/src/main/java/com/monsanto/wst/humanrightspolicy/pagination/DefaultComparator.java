package com.monsanto.wst.humanrightspolicy.pagination;

import java.util.Comparator;
/*
 DefaultComparator was created on May 2, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class DefaultComparator<T> implements Comparator<T> {
  public int compare(T o1, T o2) {
    if (o1 instanceof Comparable) {
      return ((Comparable) o1).compareTo(o2);
    } else {
      return 0;
    }
  }
}
