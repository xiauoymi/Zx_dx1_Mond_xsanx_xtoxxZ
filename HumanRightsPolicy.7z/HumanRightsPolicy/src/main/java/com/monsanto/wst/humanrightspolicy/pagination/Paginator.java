package com.monsanto.wst.humanrightspolicy.pagination;

import com.monsanto.wst.humanrightspolicy.datasource.DataSource;

import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
/*
 Paginator was created on Apr 16, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

//todo move this to a seperate shared component when it stablizes
/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class Paginator<T> implements DataSource<T> {
  private final DataSource<T> source;

  public Paginator(DataSource<T> source) {
    this.source = source;
  }

  public int getNumRecords() throws IOException {
    List<? extends T> baseList = source.getData();
    return baseList.size();
  }

  public Result<? extends T> getRecords(int startIndex) throws IOException {
    List<? extends T> baseList = source.getData();
    int len = baseList.size();
    if (len < startIndex) {
      return new Result<T>((List<? extends T>) Collections.emptyList(), 0);
    }

    List<? extends T> returnedItems = baseList.subList(startIndex, len);
    return new Result<T>(returnedItems, baseList.size());
  }

  public Result<? extends T> getRecords(int startIndex, int rowsPerPage) throws IOException {
    List<? extends T> baseList = source.getData();
    int len = baseList.size();
    if (len < startIndex) {
      return new Result<T>((List<? extends T>) Collections.emptyList(), 0);
    }
    int endIndex = getEndIndex(startIndex, rowsPerPage, len);

    List<? extends T> returnedItems = baseList.subList(startIndex, endIndex);
    int totalSize = getTotalSize(baseList);

    return new Result<T>(returnedItems, totalSize);
  }

  private int getTotalSize(List<? extends T> baseList) throws IOException {
    int totalSize = source.getTotalRecords();
    if (totalSize == DataSource.UNKNOWN_RECORD_COUNT) {
      totalSize = baseList.size();
    }
    return totalSize;
  }

  private int getEndIndex(int startIndex, int rowsPerPage, int len) {

    if (startIndex + rowsPerPage > len) {
      return  len;
    } else {
      return (startIndex + rowsPerPage);
    }
  }

  public List<? extends T> getData() throws IOException {
    return source.getData();
  }

  public Comparator<T> getComparator(String sortName) {
    return source.getComparator(sortName);
  }

  public boolean isSorted() {
    return source.isSorted();
  }

  public boolean isFiltered() {
    return source.isFiltered();
  }

  public int getTotalRecords() throws IOException {
    return source.getTotalRecords();
  }
}
