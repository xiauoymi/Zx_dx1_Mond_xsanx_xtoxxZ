package com.monsanto.wst.humanrightspolicy.pagination;

import java.util.Collections;
import java.util.List;
/*
 Result was created on Apr 18, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class Result<T> {
  private final List<? extends T> data;
  private final int numRecords;

  public Result(List<? extends T> data, int numPages) {
    this.data = Collections.unmodifiableList(data);
    this.numRecords = numPages;
  }

  public List<? extends T> getData() {
    return Collections.unmodifiableList(data);
  }

  public int getNumRecords() {
    return numRecords;
  }
}
