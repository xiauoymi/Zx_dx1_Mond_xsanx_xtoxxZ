package com.monsanto.wst.humanrightspolicy.persistence;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType2;
import com.monsanto.wst.humanrightspolicy.utils.PropertyFileUtil;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Jul 5, 2006 Time: 2:21:12 PM To change this template use File |
 * Settings | File Templates.
 */
public class HrpPersistenceStore {

  private static PersistentStore instance = null;

  public static PersistentStore getStore() throws WrappingException {
    Logger.traceEntry();
    String cstrResourceBundleName = "com.monsanto.wst.humanrightspolicy.Servlet.HumanRightsPolicy";
    String encryptedPassword = PasswordEncryptionUtil.getEncryptedPassword(cstrResourceBundleName);
    String userName = PropertyFileUtil.getSystemProperty(cstrResourceBundleName, "UserName");
    String sid = PropertyFileUtil.getSystemProperty(cstrResourceBundleName, "DataSource");
//    String server = PropertyFileUtil.getSystemProperty(cstrResourceBundleName, "Server");
    return getStoreInstance(userName, encryptedPassword, sid);
  }

  private static PersistentStore getStoreInstance(String userName, String encryptedPassword, String sid
  ) throws WrappingException {
    synchronized (HrpPersistenceStore.class) {
      if (instance == null) {
        instance = new PersistentStoreOracleCachedType2(userName, encryptedPassword, sid, 0, 10);
      }
      return (PersistentStore) Logger.traceExit(instance);
    }
  }
}
