package com.monsanto.wst.humanrightspolicy.persistence;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Jul 5, 2006 Time: 3:57:04 PM To change this template use File |
 * Settings | File Templates.
 */
public class PasswordEncryptionUtil {
  private static final Log logger = LogFactory.getLog(PasswordEncryptionUtil.class);

  public static String getEncryptedPassword(String cstrResourceBundleName) {
    String encryptedPassword = "";
    ResourceBundle bundle = ResourceBundle.getBundle(cstrResourceBundleName);
    String pwdEncEnvVar = bundle.getString("password.encryption.environment.variable");
    String applicationFolder = bundle.getString("password.encryption.application.folder");
    String cipherHexFile = bundle.getString("password.encryption.cipher.hexfile");
    String keyValueHexFile = bundle.getString("password.encryption.keyvalue.hexfile");

    try {
      encryptedPassword = EncryptionUtils
          .GetDecryptedStringFromExternalStorage(pwdEncEnvVar, applicationFolder, cipherHexFile, keyValueHexFile);

    } catch (EncryptorException e) {
      logger.error("Error in getEncryptedPassword", e);
    }
    return encryptedPassword;
  }
}
