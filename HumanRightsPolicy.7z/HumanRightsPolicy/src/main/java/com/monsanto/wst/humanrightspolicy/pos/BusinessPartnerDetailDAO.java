package com.monsanto.wst.humanrightspolicy.pos;

import com.monsanto.wst.humanrightspolicy.model.DetailedXmlObject;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class BusinessPartnerDetailDAO implements DetailDAO {
    public DetailedXmlObject getById(Long id) {
        return null;  //todo
    }
}
