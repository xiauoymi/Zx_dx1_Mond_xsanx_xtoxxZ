package com.monsanto.wst.humanrightspolicy.pos;

import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
*/
public class DataRequest {
    public static final String DESCENDING_SORT = "desc";

    private final String dataSource;
    private final int startIndex;
    private final int rowsPerPage;
    private final String sort;
    private final String sortDir;
    private final boolean reverseSort;
    private final String filterValue;
    private Map<String, String> parameters;

    public DataRequest(String dataSource, int startIndex, int rowsPerPage, String sort, String sortDir,
                       String filterValue, Map<String, String> parameters) {
        this.dataSource = dataSource;
        this.startIndex = startIndex;
        this.rowsPerPage = rowsPerPage;
        this.sort = sort;
        this.sortDir = sortDir;
        this.reverseSort = (sortDir != null && sortDir.equalsIgnoreCase(DESCENDING_SORT));
        this.filterValue = filterValue;
        this.parameters = parameters;
    }

    public String getDataSource() {
        return dataSource;
    }

    public int getStartIndex() {
        return startIndex;
    }

    public int getRowsPerPage() {
        return rowsPerPage;
    }

    public String getSort() {
        return sort;
    }

    public String getSortDir() {
        return sortDir;
    }

    public boolean isReverseSort() {
        return reverseSort;
    }

    public String getFilterValue() {
        return filterValue;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }
}
