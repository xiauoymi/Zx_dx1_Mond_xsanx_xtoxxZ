package com.monsanto.wst.humanrightspolicy.pos;

import org.w3c.dom.Document;

import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface DataRequestParser {
    String USER_ID = "USER_ID";
    String USER_ID_ONEWORD = "USERID";

    DataRequest parse(Document requestDocument) throws IOException;
}

