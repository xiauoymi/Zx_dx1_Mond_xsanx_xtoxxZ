package com.monsanto.wst.humanrightspolicy.pos;

import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class DataRequestParserImpl implements DataRequestParser {

    public String getSchemaPath() {
        return POSConstants.DATA_REQUEST_POS_SCHEMA;
    }

    public DataRequest parse(Document requestDoc) throws IOException {
        Map<String, String> parameters = getParmetersFromRequestDoc(requestDoc);
        String dataSource = parameters.get(POSConstants.DATA_SOURCE_CLASSNAME);
        int startIndex = getNumericParameter(parameters, POSConstants.START_INDEX, 0);
        int rowsPerPage = getNumericParameter(parameters, POSConstants.ROWS_PER_PAGE, 0);
        String sort = parameters.get(POSConstants.SORT);
        String sortDir = parameters.get(POSConstants.SORT_DIRECTION);
        String filterValue = parameters.get(POSConstants.FILTER_VALUE);
        return new DataRequest(dataSource, startIndex, rowsPerPage, sort, sortDir, filterValue, parameters);
    }

    private Map<String, String> getParmetersFromRequestDoc(Document requestDoc) {
        Map<String, String> map = new HashMap<String, String>();
        Element cmdElement = getCommandElement(requestDoc);
        NodeList elements = cmdElement.getChildNodes();
//        System.out.println("-- Params --");
        for (int i = 0; i < elements.getLength(); i++) {
            Node node = elements.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                String nodeName = node.getNodeName();
                String nodeValue = nullIfBlank(DOMUtil.getTextValue(node));
                map.put(nodeName, nodeValue);
//                System.out.println(nodeName + " -> " + nodeValue);
            }
        }
//        System.out.println("------------");

        return map;
    }

    private Element getCommandElement(Document requestDoc) {
        NodeList commandNodeList = DOMUtil.getNodeListByTagName(requestDoc, "command");
        if (commandNodeList.getLength() == 0) {
//            DOMUtil.outputXML(requestDoc);
            throw new RuntimeException("command node not found");
        }
        return (Element) commandNodeList.item(0);
    }


    private static String nullIfBlank(String st) {
        if (st == null || st.length() == 0) {
            return null;
        } else {
            return st;
        }
    }

    private int getNumericParameter(Map<String, String> parameters, String name, int defaultValue) throws IOException {
        String stringValue = parameters.get(name);

        if (stringValue == null) {
            return defaultValue;
        }

        try {
            return Integer.parseInt(stringValue);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }
}
