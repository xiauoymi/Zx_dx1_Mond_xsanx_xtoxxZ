package com.monsanto.wst.humanrightspolicy.pos;

import com.monsanto.POSServlet.POSControllerTemplate;
import com.monsanto.POSServlet.POSServerException;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.controller.FilteredXmlDataSource;
import com.monsanto.wst.humanrightspolicy.controller.SortedSource;
import com.monsanto.wst.humanrightspolicy.datasource.ComparatorInverter;
import com.monsanto.wst.humanrightspolicy.datasource.DataSource;
import com.monsanto.wst.humanrightspolicy.datasource.XmlDataSource;
import com.monsanto.wst.humanrightspolicy.model.MapParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.ParameterCollection;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.pagination.Paginator;
import com.monsanto.wst.humanrightspolicy.pagination.Result;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.Comparator;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class DataSourcePOS extends POSControllerTemplate {
    //note: this class was originally copied from XmlDataPaginationController.  I didn't refactor out of
    // XmlDataPaginationController as it will be eliminated eventually, but is being left as is until the
    // SharePoint cutover
    private final DataRequestParserImpl dataRequestParser;

    public DataSourcePOS() {
        this.dataRequestParser = new DataRequestParserImpl();
    }

    protected String getXMLSchemaRelativeToServletContext() {
        return dataRequestParser.getSchemaPath();
    }

    protected void processInput(UCCHelper helper, String inputFilePath) throws POSServerException {
        try {
            Document requestDoc = readRequestDocumentFromFile(inputFilePath);
            processRequest(helper, requestDoc);
        } catch (IOException e) {
            throw new POSServerException(e);
        } catch (SAXException e) {
            throw new POSServerException(e);
        }
    }

    protected Document readRequestDocumentFromFile(String inputFilePath) throws IOException, SAXException {
        return DOMUtil.newDocument(new FileInputStream(inputFilePath));
    }

    protected void processRequest(UCCHelper helper, Document requestDoc) throws IOException {
        DataRequest request = getDataRequest(requestDoc);
        Result<? extends XmlObject> results = getResultsForRequest(helper, request);
        outputResults(helper, request, results);
    }

    protected DataRequest getDataRequest(Document requestDoc) throws IOException {
        DOMUtil.outputXML(requestDoc);
        return dataRequestParser.parse(requestDoc);
    }

    protected Result<? extends XmlObject> getResultsForRequest(UCCHelper helper, DataRequest request) throws IOException {
        XmlDataSource rawSource = getDataSource(request);
        XmlDataSource filteredSource = getFilteredSource(request.getFilterValue(), rawSource);
        XmlDataSource sortedSource = getSortedSource(request.getSort(), request.isReverseSort(), filteredSource);
        return getPaginatedResults(request.getStartIndex(), request.getRowsPerPage(), sortedSource);
    }

    protected void outputResults(UCCHelper helper, DataRequest request, Result<? extends XmlObject> results) throws IOException {
        List<? extends XmlObject> data = results.getData();
        int numRecords = results.getNumRecords();
        Document resultDoc = getResults(data, numRecords, request.getStartIndex());
        helper.setContentType("text/xml");
        helper.writeXMLDocument(resultDoc, HRPMainConstants.LATIN1_ENCODING);
    }

    private Result<? extends XmlObject> getPaginatedResults(int startIndex, int rowsPerPage,
                                                            XmlDataSource sortedSource) throws IOException {
        int totalRecords = sortedSource.getTotalRecords();
        if (totalRecords == DataSource.UNKNOWN_RECORD_COUNT) {
            Paginator<XmlObject> paginator = new Paginator<XmlObject>(sortedSource);
            return paginator.getRecords(startIndex, rowsPerPage);
        } else {
            return new Result<XmlObject>(sortedSource.getData(), totalRecords);
        }
    }

    private XmlDataSource getSortedSource(String sort, boolean reverseSort, XmlDataSource filteredSource) {
        XmlDataSource sortedSource;
        if (filteredSource.isSorted()) {
            sortedSource = filteredSource;
        } else {
            Comparator<XmlObject> comparator = filteredSource.getComparator(sort);
            if (reverseSort) {
                comparator = new ComparatorInverter<XmlObject>(comparator);
            }

            sortedSource = new SortedSource(filteredSource, comparator);
        }
        return sortedSource;
    }

    private XmlDataSource getFilteredSource(String filterValue, XmlDataSource rawSource) {
        XmlDataSource filteredSource;
        if (rawSource.isFiltered()) {
            filteredSource = rawSource;
        } else {
            filteredSource = new FilteredXmlDataSource(rawSource, filterValue);
        }
        return filteredSource;
    }

    private XmlDataSource getDataSource(DataRequest request) {
        String className = request.getDataSource();
        Constructor<? extends XmlDataSource> constructor = getConstructor(className);
        return getNewInstance(request, className, constructor);
    }

    private XmlDataSource getNewInstance(DataRequest request, String className,
                                         Constructor<? extends XmlDataSource> constructor) {
        try {
            return constructor.newInstance(new MapParameterCollection(request.getParameters()));
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Error on constructor call for data source class: " + className, e);
        }
    }

    private Constructor<? extends XmlDataSource> getConstructor(String className) {
        try {
            if (className == null) {
                throw new NullPointerException("data source class not specified.  data source class cannot be null.");
            }
            Class<? extends XmlDataSource> dataSourceClass = (Class<? extends XmlDataSource>) Class.forName(className);
            return dataSourceClass.getConstructor(ParameterCollection.class);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Unknown data source class: " + className, e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException("No valid constructor for data source class: " + className, e);
        }
    }

    private Document getResults(List<? extends XmlObject> data, int numRecords, int startIndex) throws IOException {
        StringBuffer xmlBuf = new StringBuffer("<ResultSet ");
        xmlBuf.append("totalResultsAvailable=\"").append(numRecords).append("\" ");
        xmlBuf.append("totalRecords=\"").append(numRecords).append("\" ");
        xmlBuf.append("totalResultsReturned=\"").append(data.size()).append("\" ");
        xmlBuf.append("firstResultPosition=\"").append(startIndex).append("\" >");
        xmlBuf.append("<totalRecords>").append(numRecords).append("</totalRecords>");

        for (XmlObject obj : data) {
            xmlBuf.append(obj.toXml());
        }
        xmlBuf.append("</ResultSet>");

        try {
            return DOMUtil.stringToXML(xmlBuf.toString());
        } catch (ParserException e) {
            throw new RuntimeException("XML Exception", e);
        }
    }
}
