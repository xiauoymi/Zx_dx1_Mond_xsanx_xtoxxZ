package com.monsanto.wst.humanrightspolicy.pos;

import com.monsanto.wst.humanrightspolicy.model.DetailedXmlObject;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public interface DetailDAO {
    DetailedXmlObject getById(Long id);
}
