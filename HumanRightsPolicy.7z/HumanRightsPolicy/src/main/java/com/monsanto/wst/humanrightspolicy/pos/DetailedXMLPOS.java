package com.monsanto.wst.humanrightspolicy.pos;

import com.monsanto.POSServlet.POSControllerTemplate;
import com.monsanto.POSServlet.POSServerException;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.DetailedXmlObject;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.FileInputStream;
import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class DetailedXMLPOS extends POSControllerTemplate {
    public static final String DETAILED_XML_POS_SCHEMA = "DetailedXMLPOS.xsd";
    private static final String DAO_CLASSNAME_PARAM = "DAOClass" ;

    protected String getXMLSchemaRelativeToServletContext() {
        return DETAILED_XML_POS_SCHEMA;
    }

    protected void processInput(UCCHelper helper, String inputFilePath) throws POSServerException {
        try {
            Document requestDoc = readRequestDocumentFromFile(inputFilePath);
            processRequest(helper, requestDoc);
        } catch (IOException e) {
            throw new POSServerException(e);
        } catch (SAXException e) {
            throw new POSServerException(e);
        }
    }

    protected Document readRequestDocumentFromFile(String inputFilePath) throws IOException, SAXException {
        return DOMUtil.newDocument(new FileInputStream(inputFilePath));
    }

    protected void processRequest(UCCHelper helper, Document requestDoc) throws IOException {
        DetailDAO dao = getDAOFromHelper(helper);
        Long id = getKeyIdFromDocument(requestDoc);
        DetailedXmlObject result = dao.getById(id);
        outputResults(helper, result);
    }

    protected Long getKeyIdFromDocument(Document requestDoc) {
        Element idElement = getIdElement(requestDoc);
        String textValue = DOMUtil.getTextValue(idElement);
        if (textValue == null) {
            return 0L;
        } else {
            return Long.parseLong(textValue);
        }
    }

    private Element getIdElement(Document requestDoc) {
        NodeList idNodeList = DOMUtil.getNodeListByTagName(requestDoc, "id");
        if (idNodeList.getLength() == 0) {
            throw new RuntimeException("id node not found");
        }
        return (Element) idNodeList.item(0);
    }


    protected DetailDAO getDAOFromHelper(UCCHelper helper) {
        String daoClassName = (String) helper.getInitParameters().get(DAO_CLASSNAME_PARAM);
        try {
            Class<? extends DetailDAO> daoClass = (Class<? extends DetailDAO>) Class.forName(daoClassName);
            return daoClass.newInstance();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        }
    }

    protected void outputResults(UCCHelper helper, DetailedXmlObject data) throws IOException {
        Document resultDoc = getResults(data);
        helper.setContentType("text/xml");
        helper.writeXMLDocument(resultDoc, HRPMainConstants.LATIN1_ENCODING);
    }

    private Document getResults(DetailedXmlObject data) throws IOException {
        try {
            return DOMUtil.stringToXML(data.toDetailedXml());
        } catch (ParserException e) {
            throw new RuntimeException(e);
        }
    }
}
