package com.monsanto.wst.humanrightspolicy.pos;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class POSConstants {
    public static final String INPUT_POS_ELEMENT = "inputPos";
    public static final String COMMAND_ELEMENT = "command";
    public static final String DATA_SOURCE_CLASSNAME = "data-source";
    public static final String START_INDEX = "startIndex";
    public static final String ROWS_PER_PAGE = "rowsPerPage";
    public static final String SORT = "sort";
    public static final String SORT_DIRECTION = "dir";
    public static final String DESCENDING_SORT = "desc";
    public static final String FILTER_VALUE = "filterValue";
    public static final String DATA_REQUEST_POS_SCHEMA = "DataSourcePOS.xsd";
    public static final String QUERY_ELEMENT = "Query";
    public static final String REF_DATA_ELEMENT = "ReferenceData";

    private POSConstants() {}
    
}
