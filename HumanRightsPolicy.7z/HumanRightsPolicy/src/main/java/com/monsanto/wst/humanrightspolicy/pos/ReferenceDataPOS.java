package com.monsanto.wst.humanrightspolicy.pos;

import com.monsanto.POSServlet.POSControllerTemplate;
import com.monsanto.POSServlet.POSServerException;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.humanrightspolicy.assessment.Policy;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ReferenceDataPOS extends POSControllerTemplate {
    public static final String BP_TYPE_VALUE = "bpType";
    public static final String POLICY_VALUE = "policy";
    public static final String LOCATION_CONTACT_TYPE_VALUE = "contactType";
    public static final String BP_LOCATION_TYPE_VALUE = "locationType";
    public static final String REGION_VALUE = "region";
    public static final String COUNTRY_VALUE = "country";
    public static final String STATE_VALUE = "state";

    private static final String SCHEMA_PATH = "ReferenceDataPOS.xsd";

    private final GenericDAO<HrpType, Long> hrpTypeDAO;
    private final GenericDAO<Policy, Long> policyDAO;
    private final GenericDAO<ContactType, Long> contactTypeDAO;
    private final GenericDAO<LocationType, Long> locationTypeDAO;
    private final GenericDAO<Region, Long> regionDAO;
    private final GenericDAO<Country, Long> countryDAO;
    private final GenericDAO<StateProvince, Long> stateDAO;


    public ReferenceDataPOS() {
        this(InitService.initHrpTypeDAO(), InitService.initPolicyDao(), InitService.initContactTypeDAO(),
                InitService.initLocationTypeDAO(),
                InitService.initRegionDAO(), InitService.initCountryDAO(), InitService.initStateDAO());
    }

    public ReferenceDataPOS(GenericDAO<HrpType, Long> hrpTypeDAO, GenericDAO<Policy, Long> policyDAO,
                            GenericDAO<ContactType, Long> contactTypeDAO,
                            GenericDAO<LocationType, Long> locationTypeDAO,
                            GenericDAO<Region, Long> regionDAO, GenericDAO<Country, Long> countryDAO,
                            GenericDAO<StateProvince, Long> stateDAO) {
        this.hrpTypeDAO = hrpTypeDAO;
        this.policyDAO = policyDAO;
        this.contactTypeDAO = contactTypeDAO;
        this.locationTypeDAO = locationTypeDAO;
        this.regionDAO = regionDAO;
        this.countryDAO = countryDAO;
        this.stateDAO = stateDAO;
    }

    protected String getXMLSchemaRelativeToServletContext() {
        return SCHEMA_PATH;
    }

    protected void processInput(UCCHelper helper, String inputFilePath) throws POSServerException {
        try {
            Document requestDoc = readRequestDocumentFromFile(inputFilePath);
            processInputDocument(helper, requestDoc);
        } catch (IOException e) {
            throw new POSServerException(e);
        } catch (SAXException e) {
            throw new POSServerException(e);
        } catch (ParserException e) {
            throw new POSServerException(e);
        }
    }

    protected Document readRequestDocumentFromFile(String inputFilePath) throws IOException, SAXException {
        return DOMUtil.newDocument(new FileInputStream(inputFilePath));
    }

    protected void processInputDocument(UCCHelper helper, Document inputDoc) throws IOException, ParserException {
        String refData = getReferenceData(inputDoc);
        Document outputDoc = DOMUtil.stringToXML(refData);
        helper.writeXMLDocument(outputDoc);
    }

    private String getReferenceData(Document inputDoc) {
        String refDataType = getReferenceDataTypeFromDocument(inputDoc);
        Method method = getMethodForReturnType(refDataType);
        List<? extends XmlObject> results = getResults(refDataType, method);
        StringBuffer output = new StringBuffer("<Results>\n");
        for (XmlObject result : results) {
            output.append(result.toXml());
            output.append("\n");
        }
        output.append("</Results>");
        return output.toString();
    }

    private List<? extends XmlObject> getResults(String refDataType, Method method) {
        try {
            return (List<? extends XmlObject>) method.invoke(this);
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Invalid access configuration on reference data type: " + refDataType, e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    public List<? extends XmlObject> refData_bpType() {
        return hrpTypeDAO.findAll();
    }

    public List<? extends XmlObject> refData_policy() {
        return policyDAO.findAll();
    }

    public List<? extends XmlObject> refData_contactType() {
        return contactTypeDAO.findAll();
    }

    public List<? extends XmlObject> refData_locationType() {
        return locationTypeDAO.findAll();
    }

    public List<? extends XmlObject> refData_region() {
        return regionDAO.findAll();
    }

    public List<? extends XmlObject> refData_country() {
        return countryDAO.findAll();
    }

    public List<? extends XmlObject> refData_state() {
        return stateDAO.findAll();
    }

    private Method getMethodForReturnType(String refDataType) {
        String methodName = "refData_" + refDataType;
        try {
            return this.getClass().getMethod(methodName);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException("Unknown reference data type: " + refDataType);
        }
    }


    private String getReferenceDataTypeFromDocument(Document inputDoc) {
        NodeList refDataNodes = DOMUtil.getNodeListByTagName(inputDoc, POSConstants.REF_DATA_ELEMENT);
        if (refDataNodes.getLength() == 0) {
            DOMUtil.outputXML(inputDoc);
            throw new RuntimeException("Did not find ref data element");
        }

        return refDataNodes.item(0).getTextContent();
    }
}
