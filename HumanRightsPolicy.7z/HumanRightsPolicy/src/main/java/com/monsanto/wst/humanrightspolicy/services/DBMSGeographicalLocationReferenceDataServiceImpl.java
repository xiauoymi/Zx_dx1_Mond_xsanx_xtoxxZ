/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.humanrightspolicy.services;

import com.monsanto.wst.humanrightspolicy.dao.GeographicReferenceDataDAO;
import com.monsanto.wst.humanrightspolicy.geodata.GeoDataFactory;
import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.CriteriaObject;
import com.monsanto.wst.humanrightspolicy.model.Region;
import com.monsanto.wst.humanrightspolicy.model.StateProvince;

import java.util.ArrayList;
import java.util.List;

/**
 * @author jdpoul
 */
public class DBMSGeographicalLocationReferenceDataServiceImpl implements GeographicalLocationReferenceDataService{
  private final GeoDataFactory geoDataFactory;
  private final GeographicReferenceDataDAO geographicReferenceDataDAO;

  public DBMSGeographicalLocationReferenceDataServiceImpl(
      GeographicReferenceDataDAO geographicReferenceDataDAO, GeoDataFactory geoDataFactory) {
    this.geographicReferenceDataDAO = geographicReferenceDataDAO;
    this.geoDataFactory = geoDataFactory;
  }

  public List<StateProvince> lookupActiveStatesForCountry(String countryId){
    return geographicReferenceDataDAO.lookupActiveStatesOrProvincesByCountry(countryId);
  }

  public List<Country> lookupActiveCountriesForRegion(String regionId) {
    List<Region> regions = new ArrayList<Region>();
    Region region = geoDataFactory.getRegionById(regionId);
    regions.add(region);
    CriteriaObject criteria = new CriteriaObject(regions);
    return geographicReferenceDataDAO.lookupActiveCountriesByCriteira(criteria);
  }
}