/*
 LexiconCountryDataService was created on Dec 7, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.services;

import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.StateProvince;

import java.util.List;

/**
 * @author sspati1
 */
public interface GeographicalLocationReferenceDataService {
  //todo move to a filter on country and state
  List<Country> lookupActiveCountriesForRegion(String regionId);
  List<StateProvince> lookupActiveStatesForCountry(String countryId);
}