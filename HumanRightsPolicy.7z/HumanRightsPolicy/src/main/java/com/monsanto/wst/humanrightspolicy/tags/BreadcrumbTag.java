/*
 BreadcrumbTag was created on Jul 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.tags;

import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import org.apache.commons.lang.StringUtils;

import javax.servlet.jsp.tagext.SimpleTagSupport;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: BreadcrumbTag.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-17 21:05:12 $
 *
 * @author sspati1
 * @version $Revision: 1.10 $
 */
public class BreadcrumbTag extends SimpleTagSupport {
  private String text;
  private String href;
  private String defaultText;
  private String detaultHref;
  private static final Map<String, String> defaultTextMap;
  private static final Map<String, String> defaultHrefMap;

  static {
    defaultTextMap = new HashMap<String, String>();
    defaultTextMap.put("home", "Home");
    defaultTextMap.put("myBps", "My Business Partners");
    defaultTextMap.put("searchAllVendors", "Search All Vendors");
    defaultTextMap.put("myRecentlyAddedBps", "My Recently Added");
    defaultTextMap.put("myCommunications", "My Communication Plans");
    defaultTextMap.put("maintainUsers", "User Maintenance");
    defaultTextMap.put("myActionPlans", "My Action Plans");
    defaultTextMap.put("myAssessments", "My Assessments");

    defaultHrefMap = new HashMap<String, String>();
    defaultHrefMap.put("home", new HrpUrlBuilder(null).getBaseHomeUrl());
    defaultHrefMap.put("myBps", new HrpUrlBuilder(null).getBaseMyBpsUrl());
    defaultHrefMap.put("searchAllVendors", new HrpUrlBuilder(null).getBaseSearchAllVendorsUrl());
    defaultHrefMap.put("myRecentlyAddedBps", new HrpUrlBuilder(null).getBaseMyRecentedAddedBpsUrl());
    defaultHrefMap.put("myCommunications", new HrpUrlBuilder(null).getBaseMyCommunicationsUrl());
    defaultHrefMap.put("bpDetail", new HrpUrlBuilder(null).getBaseViewBpUrl());
    defaultHrefMap.put("locationDetail", new HrpUrlBuilder(null).getBaseViewLocationUrl());
    defaultHrefMap.put("maintainUsers", new HrpUrlBuilder(null).getBaseMaintainUsersUrl());
    defaultHrefMap.put("myActionPlans", new HrpUrlBuilder(null).getBaseActionPlansUrl());
    defaultHrefMap.put("myAssessments", new HrpUrlBuilder(null).getBaseAssessmentUrl());
  }

  public void doTag() throws IOException {
    String userText = getDefaultText() + getText();
    String userHref = getDefaultHref() + getHref();
    String resultStr;
    if(StringUtils.isBlank(userHref)){
      resultStr = userText;
    }else{
      resultStr = "<a href='" + userHref + "'>" + userText + "</a>" + " > ";
    }
    getJspContext().getOut().write(resultStr);
  }

  public void setText(String text) {
    this.text = text;
  }

  public void setHref(String href) {
    this.href = href;
  }

  public void setDefaultText(String defaultText) {
    this.defaultText = defaultText;
  }

  private String getText() {
    if (StringUtils.isNotBlank(this.text)) {
      return this.text;
    }
    return "";
  }

  private String getHref() {
    if (StringUtils.isNotBlank(this.href)) {
      return this.href;
    }
    return "";
  }

  private String getDefaultText() {
    String value = defaultTextMap.get(this.defaultText);
    if (value == null) {
      return "";
    } else {
      return value;
    }
  }

  private String getDefaultHref() {
    String value = defaultHrefMap.get(this.detaultHref);
    if (value == null) {
      return "";
    } else {
      return value;
    }
  }

  public void setDefaultHref(String detaultHref) {
    this.detaultHref = detaultHref;
  }
}