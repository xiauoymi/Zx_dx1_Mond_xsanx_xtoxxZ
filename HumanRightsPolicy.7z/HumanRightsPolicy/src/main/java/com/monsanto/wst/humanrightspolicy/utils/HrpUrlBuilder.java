package com.monsanto.wst.humanrightspolicy.utils;

/*
 BusinessPartnerUrlBuilder was created on Apr 3, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class HrpUrlBuilder {
  private static final String BASE_URL = "/humanrightspolicy/servlet";
  private static final String DATA_URL = "/humanrightspolicy/data";
  private final String menuLocation;

  public HrpUrlBuilder(String menuLocation) {
    this.menuLocation = menuLocation;
  }

  public String getBaseHomeUrl() {
    return BASE_URL + "/login?method=home&menu=Home";
  }

  public String getBaseMyBpsUrl() {
    return BASE_URL + "/searchBusinessPartner?method=&menu=bp";
  }

  public String getBaseSearchAllVendorsUrl() {
    return BASE_URL + "/searchBusinessPartner?method=allBPs";
  }
public String getBaseAssessmentUrl() {
    return BASE_URL + "/assessment?method=&menu=assessment";
  }
   public String getBaseMyRecentedAddedBpsUrl() {
    return BASE_URL + "/searchBusinessPartner?method=&menu=bp&recent=true";
  }

  public String getBaseActionPlansUrl() {
    return BASE_URL + "/action?method=&menu=action";
  }

  public String getBaseMyCommunicationsUrl() {
    return BASE_URL + "/communication?method=&menu=comm";
  }

  public String getBaseMaintainUsersUrl() {
    return BASE_URL + "/maintainUserAccess?menu=displayUsers";
  }

  public String getBaseViewBpUrl() {
    return BASE_URL + "/businessPartner?method=lookupBP&businessPartnerId=";
  }

  public String getViewBpUrl(String bpId) {
    return getBaseViewBpUrl() + bpId + getMenuParam();
  }

  public String getBaseViewLocationUrl() {
    return BASE_URL + "/location?method=lookupLocation&locationId=";
  }

  public String getViewLocationUrl(String locationId) {
    return getBaseViewLocationUrl() + locationId + getMenuParam();
  }

  public String getRemoveUserUrl(String userId) {
    return BASE_URL + "/maintainUserAccess?method=deleteUserRole&userId=" + userId + "&hrpFlag=N" + getMenuParam();
  }
  
  public String getAddUserUrl() {
    return BASE_URL + "/maintainUserAccess?method=setupDataForNewUserRole&newUser=Y" + getMenuParam();
  }

  public String getViewUserUrl(String userId) {
    return BASE_URL + "/maintainUserAccess?method=lookupUserRole&userId=" + userId + getMenuParam();
  }

  public String getViewContactUrl(String contactId) {
    return BASE_URL + "/contacts?method=lookupContact&contactId=" + contactId + getMenuParam();
  }

  public String getSetPrimaryLocationUrl(String locationId, String contactId) {
    return BASE_URL + "/locContactRel?method=setPrimaryLocation&locationId=" + locationId + "&contactId=" + contactId +
        getMenuParam();
  }

  public String getSetPrimaryContactUrl(String contactId, String locationId) {
    return BASE_URL + "/locContactRel?method=setPrimaryContact&contactId=" + contactId  + "&locationId=" + locationId +
        getMenuParam();
  }

  public String getSetPrimaryLocationForBpUrl(String locationId, String bpId) {
    return DATA_URL + "/bpLocRel?method=setPrimaryLocation&locationId=" + locationId + "&businessPartnerId=" + bpId +
        getMenuParam();
  }

  public String getSetPrimaryContactForBpUrl(String contactId, String bpId) {
    return BASE_URL + "/locContactRel?method=setPrimaryContact&contactId=" + contactId + "&businessPartnerId=" + bpId +
    getMenuParam();
  }

  public String getViewCommUrl(String commId) {
    return BASE_URL + "/communication?method=lookupCommunication&commId=" + commId + getMenuParam();
  }

  public String getDeleteRecipientUrl(String recipientId) {
    return DATA_URL + "/commRecipient?method=deleteRecipient&recipientId=" + recipientId + getMenuParam();
  }

  public String getDeleteRecipientUrlForAysn(String recipientId) {
    return DATA_URL + "/commRecipient?method=deleteRecipient&recipientId=" + recipientId + getMenuParam();
  }

  public String getUpdateDoneFlagUrl(String commId, String recipientId) {
    return DATA_URL + "/commRecipient?method=updateDoneFlag&commId=" + commId + "&recipientId=" + recipientId + getMenuParam();
  }

  public String getAddRecipientUrl(String recipientId) {
    return DATA_URL + "/commRecipient?method=addRecipient&recipientId=" + recipientId + getMenuParam();
  }

  private String getMenuParam() {
    return "&menu=" + menuLocation;
  }

  public String getEndBPLocationRelationship(String bpId, String locId){
      return BASE_URL + "/bpLocRel?method=endBPLocationRelationship&businessPartnerId=" + bpId + "&locationId=" + locId + getMenuParam();
  }

    public String getEndLocationToContactRelationship(String contactId, String locationId) {
        return BASE_URL + "/locContactRel?method=endLocationContactRelationship&contactId="+contactId+"&locationId="+locationId+getMenuParam();
    }


  public String getViewActionUrl(String actionId) {
    return BASE_URL + "/action?method=lookupAction&actionId=" + actionId + getMenuParam();
  }

  public String getSetPrimaryAssignmentForTargetUrl(String assignmentId, String targetId) {
    return BASE_URL + "/action?method=setAssignmentAsPrimary&assignmentId=" + assignmentId + "&targetId=" + targetId +
    getMenuParam();
  }

  public String getViewAssessmentUrl(String id) {
    return BASE_URL + "/assessment?method=lookupAssessment&assessmentId=" + id + getMenuParam();

  }


}
