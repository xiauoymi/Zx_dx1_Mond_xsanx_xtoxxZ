/*
 InitService was created on Feb 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.utils;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.dbtemplate.DBTemplate;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.hibernate.HibernateFactoryImpl;
import com.monsanto.wst.humanrightspolicy.Security.dao.dbtemplate.DBTemplateSecurityDAO;
import com.monsanto.wst.humanrightspolicy.Security.service.SecurityService;
import com.monsanto.wst.humanrightspolicy.Security.service.SecurityServiceImpl;
import com.monsanto.wst.humanrightspolicy.action.service.ActionService;
import com.monsanto.wst.humanrightspolicy.action.service.ActionServiceImpl;
import com.monsanto.wst.humanrightspolicy.alert.dao.AlertDAO;
import com.monsanto.wst.humanrightspolicy.alert.dao.AlertDAOImpl;
import com.monsanto.wst.humanrightspolicy.assessment.Assessment;
import com.monsanto.wst.humanrightspolicy.assessment.GlobalAssessment;
import com.monsanto.wst.humanrightspolicy.assessment.Policy;
import com.monsanto.wst.humanrightspolicy.assessment.service.AssessmentService;
import com.monsanto.wst.humanrightspolicy.assessment.service.AssessmentServiceImpl;
import com.monsanto.wst.humanrightspolicy.assessment.service.GlobalAssessmentService;
import com.monsanto.wst.humanrightspolicy.assessment.service.GlobalAssessmentServiceImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.LookupBPDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate.DBTemplateLookupBPDAOImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPServiceImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.services.BusinessPartnerService;
import com.monsanto.wst.humanrightspolicy.businessPartner.services.BusinessPartnerServiceImpl;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommunicationDAO;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationServiceImpl;
import com.monsanto.wst.humanrightspolicy.config.AppConfig;
import com.monsanto.wst.humanrightspolicy.config.Configuration;
import com.monsanto.wst.humanrightspolicy.config.ConfigurationImpl;
import com.monsanto.wst.humanrightspolicy.contact.dao.dbtemplate.DBTemplateContactDAO;
import com.monsanto.wst.humanrightspolicy.contact.dao.dbtemplate.DBTemplateLookupContactDAOImpl;
import com.monsanto.wst.humanrightspolicy.contact.service.ContactService;
import com.monsanto.wst.humanrightspolicy.contact.service.ContactServiceImpl;
import com.monsanto.wst.humanrightspolicy.contact.service.LookupContactService;
import com.monsanto.wst.humanrightspolicy.contact.service.LookupContactServiceImpl;
import com.monsanto.wst.humanrightspolicy.dao.dbtemplate.DBTemplateGeographicReferenceDataDAO;
import com.monsanto.wst.humanrightspolicy.geodata.GeoDataFactory;
import com.monsanto.wst.humanrightspolicy.geodata.GeoDataFactoryImpl;
import com.monsanto.wst.humanrightspolicy.location.dao.dbtemplate.DBTemplateLocationDAO;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.location.service.LocationServiceImpl;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.note.Note;
import com.monsanto.wst.humanrightspolicy.note.dao.NoteDAO;
import com.monsanto.wst.humanrightspolicy.note.dao.NoteDAOImpl;
import com.monsanto.wst.humanrightspolicy.services.DBMSGeographicalLocationReferenceDataServiceImpl;
import com.monsanto.wst.humanrightspolicy.services.GeographicalLocationReferenceDataService;

/**
 * @author sspati1
 */
public class InitService { //todo this needs to be refactored
    private static GeographicalLocationReferenceDataService geoService = null;
    private static DBTemplate template = null;
    private static ContactService contactService = null;
    private static LookupContactService lookupContactService = null;
    private static BusinessPartnerService bpService = null;
    private static LookupBPService lookupBpService = null;
    private static LocationService locationService = null;
    private static SecurityService securityService = null;
    private static CommunicationService communicationService = null;
    private static GeoDataFactory geoDataFactory = null;
    private static HibernateFactory hibernate = null;
    private static ActionService actionService = null;

    private InitService() {
    }

    public static DBTemplate initTemplate() {
        synchronized (InitService.class) {
            if (template == null) {
                template = new DBTemplateImpl("database/dbtemplate-config.xml", new String[]{"database/dbtemplate.xml"});
            }

            return template;
        }
    }

    public static HibernateFactory initHibernate() {
        synchronized (InitService.class) {
            if (hibernate == null) {
                hibernate = HibernateFactoryImpl.getInstance("humanrights");
            }

            return hibernate;
        }
    }

    public static ContactService initContactService() {
        synchronized (InitService.class) {
            if (contactService == null) {
                contactService = new ContactServiceImpl(new DBTemplateContactDAO(initTemplate()));
            }

            return contactService;
        }
    }

    public static LookupContactService initLookupContactService() {
        synchronized (InitService.class) {
            if (lookupContactService == null) {
                lookupContactService = createLookupBPContactService();
            }

            return lookupContactService;
        }
    }

    public static BusinessPartnerService initBusinessPartnerService() {
        synchronized (InitService.class) {
            if (bpService == null) {
                bpService = createBusinessPartnerService();
            }

            return bpService;
        }
    }

    public static LookupBPService initSearchBPService() {
        synchronized (InitService.class) {
            if (lookupBpService == null) {
                lookupBpService = createSearchBPService();
            }

            return lookupBpService;
        }
    }

    public static LocationService initLocationService() {
        synchronized (InitService.class) {
            if (locationService == null) {
                locationService = new LocationServiceImpl(initLookupLocationDao());
            }

            return locationService;
        }
    }

    public static DBTemplateLocationDAO initLookupLocationDao() {
        return new DBTemplateLocationDAO(initTemplate(), initLocationTypeDAO());
    }

    public static GenericDAO<LocationType, Long> initLocationTypeDAO() {
        return new HibernateDAO<LocationType, Long>(initHibernate(), LocationType.class);
    }

    public static GenericDAO<Region, Long> initRegionDAO() {
        return new HibernateDAO<Region, Long>(initHibernate(), Region.class);
    }

    public static GenericDAO<Country, Long> initCountryDAO() {
        return new HibernateDAO<Country, Long>(initHibernate(), Country.class);
    }

    public static GenericDAO<StateProvince, Long> initStateDAO() {
        return new HibernateDAO<StateProvince, Long>(initHibernate(), StateProvince.class);
    }

    public static GeographicalLocationReferenceDataService initGeographicalLocationReferenceDataService() {
        synchronized (InitService.class) {
            if (geoService == null) {
                geoService = new DBMSGeographicalLocationReferenceDataServiceImpl(new DBTemplateGeographicReferenceDataDAO(initTemplate()),
                        initGeoDataFactory());
            }
        }
        return geoService;
    }

    public static SecurityService initSecurityService() {
        synchronized (InitService.class) {
            if (securityService == null) {
                securityService = new SecurityServiceImpl(new DBTemplateSecurityDAO(initTemplate()));
            }

            return securityService;
        }
    }

    public static CommunicationService initCommunicationService() {
        synchronized (InitService.class) {
            if (communicationService == null) {
                communicationService = new CommunicationServiceImpl(createCommunicationDAO());
            }

            return communicationService;
        }
    }

    public static GeoDataFactory initGeoDataFactory() {
        synchronized (InitService.class) {
            if (geoDataFactory == null) {
                geoDataFactory = createGeoDataFactory();
            }

            return geoDataFactory;
        }
    }

    private static GeoDataFactory createGeoDataFactory() {
        HibernateFactory factory = initHibernate();

        return new GeoDataFactoryImpl(
                new HibernateDAO<Region, String>(factory, Region.class),
                new HibernateDAO<Country, String>(factory, Country.class),
                new HibernateDAO<StateProvince, String>(factory, StateProvince.class));
    }

    private static LookupContactService createLookupBPContactService() {
        return new LookupContactServiceImpl(initLookupContactDao());
    }

    public static DBTemplateLookupContactDAOImpl initLookupContactDao() {
        return new DBTemplateLookupContactDAOImpl(initTemplate());
    }

    private static BusinessPartnerService createBusinessPartnerService() {
        return new BusinessPartnerServiceImpl(initHrpTypeDAO());
    }

    public static LookupBPDAO initLookupBPDao() {
        return new DBTemplateLookupBPDAOImpl(initTemplate());
    }

    private static LookupBPService createSearchBPService() {
        return new LookupBPServiceImpl(initLookupBPDao());
    }

    private static CommunicationDAO createCommunicationDAO() {
        return new DBTemplateCommunicationDAO(initTemplate(), initCommStatusDAO(), initCommTypeDAO());
    }

    public static GenericDAO<CommType, Long> initCommTypeDAO() {
        return new HibernateDAO<CommType, Long>(initHibernate(), CommType.class);
    }

    public static GenericDAO<Role, String> initRoleDAO() {
        return new HibernateDAO<Role, String>(initHibernate(), Role.class);
    }

    public static GenericDAO<Privilege, String> initPrivilegeDAO() {
        return new HibernateDAO<Privilege, String>(initHibernate(), Privilege.class);
    }

    public static GenericDAO<LoginUser, Long> initUserDAO() {
        return new HibernateDAO<LoginUser, Long>(initHibernate(), LoginUserImpl.class);
    }

    public static GenericDAO<HrpType, Long> initHrpTypeDAO() {
        return new HibernateDAO<HrpType, Long>(initHibernate(), HrpType.class);
    }

    public static Configuration initConfig() {
        return new ConfigurationImpl(new HibernateDAO<AppConfig, String>(initHibernate(), AppConfig.class));
    }

    public static ActionService initActionService() {
        synchronized (InitService.class) {
            if (actionService == null) {
                actionService = createActionService();
            }
        }
        return actionService;
    }

    private static ActionService createActionService() {
        return new ActionServiceImpl(initActionDAO(), initStatusDAO(), initPriorityDAO(), initUserDAO(), initAssignmentDAO());
    }

    public static GenericDAO<Assignment, Long> initAssignmentDAO() {
        return new HibernateDAO<Assignment, Long>(initHibernate(), Assignment.class);
    }

    public static GenericDAO<Status, Long> initStatusDAO() {
        return new HibernateDAO<Status, Long>(initHibernate(), Status.class);
    }

    public static GenericDAO<ActionPriority, Long> initPriorityDAO() {
        return new HibernateDAO<ActionPriority, Long>(initHibernate(), ActionPriority.class);
    }

    public static GenericDAO<Action, Long> initActionDAO() {
        return new HibernateDAO<Action, Long>(initHibernate(), Action.class);
    }

    public static GlobalAssessmentService initGlobalAssessmentService() {
        return new GlobalAssessmentServiceImpl(initPolicyDao(), initGlobalAssessmentDao());
    }

    public static HibernateDAO<GlobalAssessment, Long> initGlobalAssessmentDao() {
        return new HibernateDAO<GlobalAssessment, Long>(initHibernate(), GlobalAssessment.class);
    }

    public static HibernateDAO<Policy, Long> initPolicyDao() {
        return new HibernateDAO<Policy, Long>(initHibernate(), Policy.class);
    }

    public static NoteDAO initNoteDAO() {
        return new NoteDAOImpl(initAlertDAO(), new HibernateDAO<Note, Long>(initHibernate(), Note.class));
    }

    private static AlertDAO initAlertDAO() {
        return new AlertDAOImpl(initHibernate());
    }

    public static CommunicationDAO initCommunicationDAO() {
        DBTemplateImpl template = new DBTemplateImpl("database/dbtemplate-config.xml",
                new String[]{"database/dbtemplate.xml"});
        return new DBTemplateCommunicationDAO(template, InitService.initCommStatusDAO(), initCommTypeDAO());
    }

    public static GenericDAO<CommStatus, Long> initCommStatusDAO() {
        return new HibernateDAO<CommStatus, Long>(initHibernate(), CommStatus.class);
    }

    public static GenericDAO<ContactType, Long> initContactTypeDAO() {
        return new HibernateDAO<ContactType, Long>(initHibernate(), ContactType.class);
    }

    public static AssessmentService initAssessmentService() {
        return new AssessmentServiceImpl(initAssessmentDao(), initStatusDAO());
    }

    public static GenericDAO<Assessment, Long> initAssessmentDao() {
        return new HibernateDAO<Assessment, Long>(initHibernate(), Assessment.class);
    }
}