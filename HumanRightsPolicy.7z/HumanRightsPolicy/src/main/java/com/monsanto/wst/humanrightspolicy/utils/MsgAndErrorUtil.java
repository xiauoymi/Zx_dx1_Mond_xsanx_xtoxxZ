/*
 MsgAndErrorUtil was created on Mar 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.utils;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * @author sspati1
 */
public class MsgAndErrorUtil {
  private static final Log log = LogFactory.getLog(MsgAndErrorUtil.class);

  public static void addDataSavedMsgToResponse(UCCHelper helper) {
    addMsgToList(HRPMainConstants.DATA_SAVED_SUCCESS_MSG, HRPMainConstants.SUCCESS_LIST, helper);
  }

  public static void addSucessMsgToResponse(String message, UCCHelper helper) {
    addMsgToList(message, HRPMainConstants.SUCCESS_LIST, helper);
  }

  public static void addDataDeletedMsgToResponse(UCCHelper helper) {
    addMsgToList(HRPMainConstants.DATA_DELETED_SUCCESS_MSG, HRPMainConstants.SUCCESS_LIST, helper);
  }

  public static void addExceptionToResponse(Exception e, UCCHelper helper) {
    logError(e);
    if (e.getCause() == null) {
      addMsgToList(e.getMessage(), HRPMainConstants.ERROR_LIST, helper);
    } else {
      addMsgToList(e.getCause().getMessage(), HRPMainConstants.ERROR_LIST, helper);
    }
  }

  public static void addExceptionMsgToResponse(Exception e, UCCHelper helper) {
    logError(e);
    addMsgToList(e.getMessage(), HRPMainConstants.ERROR_LIST, helper);
  }

  public static List<String> createAndSetErrorList(UCCHelper helper) {
    List<String> errorList = new ArrayList<String>();
    helper.setRequestAttributeValue(HRPMainConstants.ERROR_LIST, errorList);
    return errorList;
  }

  private static void addMsgToList(String msg, String listName, UCCHelper helper) {
    List<String> list = new ArrayList<String>();
    list.add(msg);
    helper.setRequestAttributeValue(listName, list);
  }

  private static void logError(Exception e) {
    Logger.log(new LoggableError(e));
    if (log.isErrorEnabled()) {
        log.error(e);
      }
  }
}