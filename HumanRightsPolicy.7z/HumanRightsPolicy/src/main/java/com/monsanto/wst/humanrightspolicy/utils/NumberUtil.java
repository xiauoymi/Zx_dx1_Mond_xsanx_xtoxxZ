package com.monsanto.wst.humanrightspolicy.utils;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class NumberUtil {
    public static Long stringToLong(String st) {
        if (st == null || st.length() == 0) {
            return null;
        } else {
            return Long.parseLong(st);
        }
    }
}
