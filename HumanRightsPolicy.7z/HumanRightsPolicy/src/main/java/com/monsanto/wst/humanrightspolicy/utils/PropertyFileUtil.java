package com.monsanto.wst.humanrightspolicy.utils;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.Util.Exceptions.WrappingException;

import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Jul 5, 2006 Time: 3:58:44 PM To change this template use File |
 * Settings | File Templates.
 */
public class PropertyFileUtil {

  public static String getSystemProperty(String cstrPropertiesFileName, String propertyRequested) throws
      WrappingException {
    Logger.traceEntry();

    /*  Get the data from the indicated properties file.  */
    ResourceBundle bundle = ResourceBundle.getBundle(cstrPropertiesFileName);
    String property = getToken(bundle, propertyRequested);
    Logger.traceExit();
    return property;
  }

  private static String getToken(ResourceBundle props, String cstrKey) throws WrappingException {
    Logger.traceEntry();

    String cstrValue;
    try {
      String cstrPrefix;
      cstrPrefix = EnvironmentHelper.getPropertyPrefix();
      Logger.log(new LoggableInfo("Envrionment :" + cstrPrefix));
      cstrValue = props.getString(cstrPrefix + cstrKey);
    }
    catch (EnvironmentHelperException ehe) {
      throw new WrappingException(ehe);
    }
    return Logger.traceExit(cstrValue);
  }
}
