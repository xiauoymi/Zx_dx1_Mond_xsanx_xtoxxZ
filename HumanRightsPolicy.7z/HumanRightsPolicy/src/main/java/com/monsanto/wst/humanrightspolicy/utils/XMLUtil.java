package com.monsanto.wst.humanrightspolicy.utils;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class XMLUtil {
    private XMLUtil() {}

    private static final String[][] TRANSLATIONS =
            {
                    {"&", "&amp;"}, // & must be first, since the other entities contain it
                    {"'", "&apos;"},
                    {"<", "&lt;"},
                    {">", "&gt;"},
                    {"\"", "&quot;"}
            };

    /**
     * Encodes any characters that have special meaning in xml
     * @param st string to encode as xml
     * @return encoded String
     */
    public static String xmlEncode(String st) {
        String currString = st;
        for (String[] translation : TRANSLATIONS) {
            currString = currString.replace(translation[0], translation[1]);
        }
        
        return currString;
    }

    /**
     * When xmlEncode just isn't enough, returns the data marked as a CDATA block.  If ]]> appears anywhere in the input
     * string, it will be stripped out.  (Since that would make for 
     * @param st string to enclose as CDATA
     * @return CDATA String
     */
    public static String cdata(String st) {
        return "<![CDATA[" + st.replace("]]>", "") + "]]>";
    }
}
