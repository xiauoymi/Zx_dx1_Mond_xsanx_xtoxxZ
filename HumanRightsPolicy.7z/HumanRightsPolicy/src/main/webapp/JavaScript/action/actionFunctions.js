YAHOO.util.Event.addListener(window, "load", function() {
  var scope = document.getElementById("scope").value;
   createActionTabs();
   createAddEditActionDialog();
   createAddEditAssignmentDialog();

//  if (scope == "My") {
    if (doesUserHaveEditRole()) {
      document.getElementById("actionBtn").disabled = "";
    if (document.getElementById("newActionBtn") != null){
      document.getElementById("newactionBtn").disabled = "";
    }
    if (document.getElementById("newAssignmentBtn") != null){
      document.getElementById("newAssignmentBtn").disabled = "";
    }
   createCalendar("calendarmenu1", "startDateCalendarPlaceHolder", "calendarcontainer1", "tablecalendar1", "calendarpicker1", "actionStartDate");
   createCalendar("calendarmenu2", "dueDateCalendarPlaceHolder", "calendarcontainer2", "tablecalendar2", "calendarpicker2", "actionDueDate");
   createCalendar("calendarmenu3", "dateCompletedCalendarPlaceHolder", "calendarcontainer3", "tablecalendar3", "calendarpicker3", "actionDateCompleted");
   alertIfActionPlanCanBeClosed();
  }
});

function alertIfActionPlanCanBeClosed() {
  var actionStatus = document.getElementById("status").value;
  var areAllSubActionItemsClosed = document.getElementById("areAllSubActionItemsClosed").value;
  if (areAllSubActionItemsClosed === 'true' && actionStatus != 'Closed'){
    showCloseActionPlanConfirmDialog();
  }
}

function showCloseActionPlanConfirmDialog() {
  var handleYes = function() {
    document.forms.actionItemForm.action = document.getElementById("contextPath").value +
                                     "/servlet/action?method=setActionPlanStatusToClosed";
    document.forms.actionItemForm.submit();
  }
  var handleNo = function() {
    this.hide();
  }
  var handleCancel = function() {
    this.hide();
  }
  // Instantiate the Dialog
  var closeActionPlanConfirmDialog =
      new YAHOO.widget.SimpleDialog("closeActionPlanConfirmDialog",
      { width: "400px",
        fixedcenter: true,
        visible: false,
        draggable: false,
        close: true,
        modal: true,
        text: '<b>Each action Item is marked as Completed. <br/>Are you finished with this Action Plan? <br/>Click "Yes" to change the status of this Action Plan to "Closed".</b>',
        icon: YAHOO.widget.SimpleDialog.ICON_HELP,
        constraintoviewport: true,
        buttons: [ { text:"Yes", handler:handleYes, isDefault:true },
          { text:"No",  handler:handleNo } , {text:"Cancel", handler:handleCancel} ]
      });
  closeActionPlanConfirmDialog.setHeader('Are you sure?');
  closeActionPlanConfirmDialog.render(document.body);
  closeActionPlanConfirmDialog.show();
}



function deleteSelectedActionItem(){
// var confirmMsg = 'This will revoke access for user ' + getQueryStringForDeleteMessage() + ' from the system. Are you sure?';
  var parentActionItem = document.getElementById('actionId').value;
  var contextPath = document.getElementById("contextPath").value;
  var filterValue =  encodeURIComponent(document.getElementById("filterValue").value);
//  if (confirm(confirmMsg)){
  document.location = contextPath + "/servlet/action?method=deleteAction&filterValue=" + filterValue +
                      "&actionId=" + parentActionItem + getQueryStringForSelectSave();
//  }
}

function deleteSelectedAssignmentsForAction(){
   var parentActionItem = document.getElementById('actionId').value;
  var contextPath = document.getElementById("contextPath").value;
  var filterValue =  encodeURIComponent(document.getElementById("filterValue").value);
//  if (confirm(confirmMsg)){
  document.location = contextPath + "/servlet/action?method=deleteAssignmentForAction&filterValue=" + filterValue +
                      "&actionId=" + parentActionItem + getQueryStringForSelectSave();
}

function createFilteredActionsTable(){
  clearSelectOperateSelections();
  populateActionsTable();
}

function clearFilterAndRefreshActionsTable(){
  document.getElementById("filterValueForAction").value = "";
  clearSelectOperateSelections();
  populateActionsTable();
}

function createFilteredAssignmentsTable(){
  clearSelectOperateSelections();
  populateAssignmentsTable();
}

function clearFilterAndRefreshAssignmentsTable(){
  document.getElementById("filterValueForAssignment").value = "";
  clearSelectOperateSelections();
  populateAssignmentsTable();
}

function createFilteredUsersTableForAssignment(){
  clearSelectOperateSelections();
  createUsersTable();
}

function clearFilterAndRefreshUsersTableForAssignment(){
  document.getElementById("filterValue").value = "";
  clearSelectOperateSelections();
  createUsersTable();
}


