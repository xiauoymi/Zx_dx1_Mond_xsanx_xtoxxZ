var createActionsTab = {
    success: function(o) {
        createActionsTable(o);
    },
    failure: function(o) {
    },
    timeout: 20000 //20 seconds
};

function createActionsTable(url) {
  //      var url = document.getElementById('contextPath').value + "/data/actionDataXml";
  //     url += "?filterValue=" + encodeURIComponent(document.getElementById("filterValue").value)
  //         +"&actionId=" + document.getElementById("actionId").value;

  this.actionsDataSource = getDataSourceForActionItems(url);
  this.actionsDataTable = getActionsTable(getActionColumnDefs(), this.actionsDataSource);
  this.actionsDataTable.subscribe("dataReturnEvent", function (oArgs) {
    setLabelForItemsTabOnAction(oArgs);
  });
}

function  getDataSourceForActionItems(url) {
  var actionsDataSource = createServerSidePaginationDataSource(url);
  actionsDataSource.responseSchema = {
    resultNode: "action",
    fields: ["actionId", "actionName",
      "actionStartDate", "actionDate", "actionStatus", "actionPriority", "actionPercentComplete", "actionViewUrl"],
    metaFields: {totalRecords : "totalRecords"}
  };
  return actionsDataSource;
}

function getActionsTable(actionColumnDefs, dataSource) {
  var actionsDataTable = createServerSidePaginationTable("actionsList", actionColumnDefs, dataSource, "actionName", null, {topPaginator:'topPaginatorForAction'});

  setParamsForSelectOperate(actionsDataTable, 'actionId', doesUserHaveEditRole());

  actionsDataTable.subscribe("checkboxClickEvent", function(oArgs) {
    checkboxClickEvent(oArgs);
  });

  actionsDataTable.subscribe("rowMouseoverEvent", actionsDataTable.onEventHighlightRow);
  actionsDataTable.subscribe("rowMouseoutEvent", actionsDataTable.onEventUnhighlightRow);

  return actionsDataTable;
}

function actionNameFormatter(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<a href="' + oRecord.getData('actionViewUrl') + '">' + oData + '</a>';
}

var urgentFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oData == "Y") {
      elCell.innerHTML = '<img border="0" alt="Urgent" src="' +
                         document.getElementById('contextPath').value +
                         '/images/imp-high.gif">';
    } else {
      elCell.innerHTML = '&nbsp;';//very important for sorting to work
    }
  };

  var attachmentFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oData != null || oData != undefined) {
      elCell.innerHTML = '<img border="0" alt="Attachment" src="' +
                         document.getElementById('contextPath').value +
                         '/images/paperclip.gif">';
    } else {
      elCell.innerHTML = '&nbsp;';//very important for sorting to work
    }
  };

 var actionTypeFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oData != "") {
      if (oRecord.getData('actionStatus') === 'Closed'){
        elCell.innerHTML = '<img border="0" alt="Action Item Closed" src="' +
                         document.getElementById('contextPath').value +
                         '/images/actionItem-done.gif">';
      }else{
        elCell.innerHTML = '<img border="0" alt="Action Item" src="' +
                         document.getElementById('contextPath').value +
                         '/images/actionItem.gif">';
      }
    } else {
      elCell.innerHTML = '&nbsp;';//very important for sorting to work
    }
  };

function getActionColumnDefs() {
  var urgentImgTh = '<img border="0" alt="Urgent" src="' +
                    document.getElementById('contextPath').value +
                    '/images/view-importance.gif">';

  var attachmentImgTh = '<img border="0" alt="Attachment" src="' +
                        document.getElementById('contextPath').value +
                        '/images/view-paperclip.gif">';

  var actionTypeImgTh = '<img border="0" alt="ActionItemType" src="' +
                        document.getElementById('contextPath').value +
                        '/images/actionItem.gif">';
   var checkbox = getCheckboxColumnDef();
  var urgent = {key:"urgent", label:urgentImgTh, formatter:urgentFormatter, width:14};
  var attachment = {key:"link", label:attachmentImgTh, formatter:attachmentFormatter, width:14};
  var actionType = {key:"actionTypeValue", label:actionTypeImgTh, formatter:actionTypeFormatter, sortable:true, resizeable:true, width:18};


    return [
         checkbox,
         actionType,
         urgent,
         attachment,
        {key:"actionName", label:"<b>Name</b>", formatter:actionNameFormatter, sortable:true, resizeable:true, minWidth:240},
        {key:"actionDate", label:"<b>Due Date</b>", sortable:true, resizeable:true, width:80},
        {key:"actionStatus", label:"<b>Status</b>", sortable:true, resizeable:true, width:80}
    ];
}
