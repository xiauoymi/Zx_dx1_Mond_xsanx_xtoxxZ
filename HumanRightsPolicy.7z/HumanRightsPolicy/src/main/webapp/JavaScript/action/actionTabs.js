var actionTabView;
var itemsTab;
var assignmentsTab;

function createActionTabs() {

  actionTabView = new YAHOO.widget.TabView();

  itemsTab = new YAHOO.widget.Tab({
    label: getLabelForActionItemsTabOnAction(),
    content: document.getElementById('itemsTab').innerHTML,
    active: false
 });
   if (hasAccessToAction()) {
     actionTabView.addTab(itemsTab);
   }

  assignmentsTab = new YAHOO.widget.Tab({
    label: getLabelForAssignmentsTabOnAction(),
    content: document.getElementById('assignmentsTab').innerHTML,
    active: false
  });
  if (hasAccessToAssignment()){
    actionTabView.addTab(assignmentsTab);
  }



  document.getElementById('tabs').innerHTML = '';
  if (actionTabView.get("tabs").length > 0) {
    actionTabView.appendTo('tabs');
    actionTabView.set("activeIndex", getActiveTabIndex());
  }

  if (hasAccessToAssignment()){
      populateAssignmentsTable();
  }

  if (hasAccessToAction()) {
      populateActionsTable();
  }

   actionTabView.on('activeTabChange', function(ev) {
        clearSelectionsIfActiveTabDifferentFromLastActiveTab(actionTabView, ev.newValue);
        if (ev.newValue == itemsTab) {
            populateActionsTable();
        } else if (ev.newValue == assignmentsTab) {
          populateAssignmentsTable();
        }
  });


  //createActionsTable();
}

function populateActionsTable() {
    var url = document.getElementById('contextPath').value + "/data/actionDataXml";
  url += "?filterValue=" + encodeURIComponent(document.getElementById("filterValueForAction").value)
         +"&actionId=" + document.getElementById("actionId").value;
    createActionsTable(url);
}

function populateAssignmentsTable() {
    var url = document.getElementById('contextPath').value + "/data/assignmentsForActionDataXml";
  url += "?filterValue=" + encodeURIComponent(document.getElementById("filterValueForAssignment").value)
          +"&actionId=" + document.getElementById("actionId").value;
  clearSelectOperateSelections();
    createAssignmentsTable(url);
}

function getLabelForActionItemsTabOnAction() {
  return "Action Items";
}

function setLabelForItemsTabOnAction(oArgs) {
  if(isTabAddedToTabView(actionTabView, itemsTab))
    setLabelOnTab(itemsTab, getLabelForActionItemsTabOnAction(), oArgs);
}

function setLabelForAssignmentsTabOnAction(oArgs) {
  if(isTabAddedToTabView(actionTabView, assignmentsTab))
    setLabelOnTab(assignmentsTab, getLabelForAssignmentsTabOnAction(), oArgs);
}

function getLabelForAssignmentsTabOnAction(){
  return "Assignments";
}
