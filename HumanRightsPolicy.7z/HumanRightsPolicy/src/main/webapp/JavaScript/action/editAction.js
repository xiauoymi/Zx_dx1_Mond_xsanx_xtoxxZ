function createAddEditActionDialog(newSubActionItem) {
    var handleSubmit = function() {
    if (this.validate()) {
      saveOrUpdateActionItem(this);
//      document.getElementById("statusHeader").style.visibility = "hidden";
//      document.getElementById("actionStatusId").disabled = "disabled";
      this.form.reset();
      this.hide();
    }
  };

  var handleCancel = function() {
      //document.getElementById("statusHeader").style.visibility = "hidden";
//    document.getElementById("actionStatusId").disabled = "disabled";
    this.form.reset();
    this.cancel();
  };



  var addEditActionDialog = new YAHOO.widget.Dialog("addEditActionDialog",
  { width : "50em",
    visible : false,
    x: getXForDialog(),
    y: getYForDialog()
  });

  addEditActionDialog.validate = function() {
    var data = this.getData();
    if (data.actionName.trim() === "") {
      alert("Please enter name.");
      return false;
    }else {
      return true;
    }
  };


  addKeyListeners(addEditActionDialog);
  addEditActionDialog.render();
  YAHOO.util.Event.addListener("actionBtn", "click", hideStatusElement, addEditActionDialog, true);
  YAHOO.util.Event.addListener("newActionBtn", "click", showNewActionItemDialog, addEditActionDialog, true);
  YAHOO.util.Event.addListener("saveActionBtn", "click", handleSubmit, addEditActionDialog, true);
  YAHOO.util.Event.addListener("saveActionBtnFromPlan", "click", handleSubmit, addEditActionDialog, true);
  YAHOO.util.Event.addListener("cancelActionBtn", "click", handleCancel, addEditActionDialog, true);
}

function hideStatusElement(){
  var hasSubActionItems = document.getElementById("hasSubActionItems").value;
  if (hasSubActionItems > 0){
//    document.getElementById("statusHeader").style.visibility = "hidden";
    document.getElementById("actionStatusId").disabled = "disabled";
    this.setHeader("Edit Action Plan");
  }else{
    this.setHeader("New Action Item");
  }

  this.show();
}

function showStatusElement(){
//  document.getElementById("statusHeader").style.visibility = "visible";
  document.getElementById("actionStatusId").disabled = "";
}

function showNewActionItemDialog(){
//  document.getElementById("statusHeader").style.visibility = "visible";
  document.getElementById("actionStatusId").disabled = "";
  resetFormForSubActionItem();
  this.setHeader("New Action Item");
  this.show();
}

function resetFormForSubActionItem(){
  document.getElementById("actionName").value = "";
  document.getElementById('thisActionId').value = "";
  document.getElementById('actionName').value = "";
  document.getElementById('actionStartDate').value = "";
  document.getElementById('actionDueDate').value = "";
  document.getElementById('actionDateCompleted').value = "";
  document.getElementById('actionDescription').value = "";
  var statusEl = document.getElementById('actionStatusId');
//  if (statusEl != null){
  statusEl.selectedIndex = 0;
//  }
  var priorityEl = document.getElementById('actionPriorityId');
  priorityEl.selectedIndex = 1;
  document.getElementById("actionPercentComplete").value = "0";
//  form.reset();
}

function getActionParameters() {
  var id = document.getElementById('actionId').value;
  var name = document.getElementById('actionName').value;
  var startDate = document.getElementById('actionStartDate').value;
  var dueDate = document.getElementById('actionDueDate').value;
  var dateCompleted = document.getElementById('actionDateCompleted').value;
  var description = document.getElementById('actionDescription').value;
  var statusEl = document.getElementById('actionStatusId');
  var status;
  if (statusEl == null){
        status = "";
  }else{
        status = statusEl.options[statusEl.selectedIndex].value;
  }
  var priorityEl = document.getElementById('actionPriorityId');
  var priority = priorityEl.options[priorityEl.selectedIndex].value;
  var percentageComplete = document.getElementById("actionPercentComplete").value;
  var parentActionItem = document.getElementById("parentAction").value;
  var parameters;
  parameters = "&actionId=" + id;
  parameters += "&actionName=" + name;
  parameters += "&actionStartDate=" + startDate;
  parameters += "&actionDueDate=" + dueDate;
  parameters += "&actionDateCompleted=" + dateCompleted;
  parameters += "&actionStatus=" + status;
  parameters += "&actionPriority=" + priority;
  parameters += "&actionPercentComplete=" + percentageComplete;
  parameters += "&actionDescription=" + description;
  parameters += "&parentAction=" + parentActionItem;
  return parameters;
}

function saveOrUpdateActionItem(dialog) {
  var actionId = document.getElementById('thisActionId').value;
  var parameters = getActionParameters();
  var method;
  var url;
  var operation;
  if (actionId == "") {
    method = "addAction";
    url = document.getElementById('contextPath').value + "/servlet/action?method=" + method + parameters;
    operation = "add";
    dialog.form.action = url;
    dialog.form.submit();
//    document.editAction.action = url;
//    document.editAction.submit();
  }else {
    method = "updateAction";
    url = document.getElementById('contextPath').value + "/data/action?method=" + method + parameters;
    operation = "edit";
    var callBackAfterAddingAction = {
      success: function(o) {
        this.cache = null;
        if (operation == "add"){
            //populateActionsTable();
        }else{
          populateActionPropertySheet(o);
        }
      },
    failure: function(o) {
      alert("Save/Update Action Call Failed.")
    },
    timeout: 20000 //20 seconds
  };

    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
    url,
    callBackAfterAddingAction);
  }
}

function populateActionPropertySheet(o)
{
   var xmlDoc = o.responseXML;
  document.getElementById('actionNameEdit').innerHTML = xmlDoc.getElementsByTagName('actionName')[0].text;
  document.getElementById('actionStartDateEdit').innerHTML = xmlDoc.getElementsByTagName('actionStartDate')[0].text;
  document.getElementById('actionDueDateEdit').innerHTML = xmlDoc.getElementsByTagName('actionDueDate')[0].text;
  document.getElementById('actionDateCompletedEdit').innerHTML = xmlDoc.getElementsByTagName('actionDateCompleted')[0].text;
  document.getElementById('actionDescriptionEdit').innerHTML = xmlDoc.getElementsByTagName('actionDescription')[0].text;
  if (document.getElementById('actionStatusEdit') != null){
    document.getElementById('actionStatusEdit').innerHTML = xmlDoc.getElementsByTagName('actionStatus')[0].text;
  }
   document.getElementById('actionPriorityEdit').innerHTML = xmlDoc.getElementsByTagName('actionPriority')[0].text;
}

