YAHOO.util.Event.addListener(window, "load", function() {
  var scope = document.getElementById("scope").value;
  populateActionsTableForList();
  createAddEditActionDialog();
    if (doesUserHaveEditRole()) {
      document.getElementById("actionBtn").disabled = "";
      createCalendar("calendarmenu1", "startDateCalendarPlaceHolder", "calendarcontainer1", "tablecalendar1", "calendarpicker1", "actionStartDate");
      createCalendar("calendarmenu2", "dueDateCalendarPlaceHolder", "calendarcontainer2", "tablecalendar2", "calendarpicker2", "actionDueDate");
      createCalendar("calendarmenu5", "dateCompletedCalendarPlaceHolder", "calendarcontainer5", "tablecalendar5", "calendarpicker5", "actionDateCompleted");
  }
});

function populateActionsTableForList() {
    var url = document.getElementById('contextPath').value + "/data/actionDataXml";
  url += "?filterValue=" + encodeURIComponent(document.getElementById("filterValue").value);
    createActionsTable(url);
}

function deleteSelectedActionItem(){
// var confirmMsg = 'This will revoke access for user ' + getQueryStringForDeleteMessage() + ' from the system. Are you sure?';
  var parentActionItem = document.getElementById('actionId').value;
  var contextPath = document.getElementById("contextPath").value;
  var filterValue =  encodeURIComponent(document.getElementById("filterValue").value);
//  if (confirm(confirmMsg)){
  document.location = contextPath + "/servlet/action?method=deleteAction&filterValue=" + filterValue +
                      "&actionId=" + parentActionItem + getQueryStringForSelectSave();
//  }
}

function createFilteredListOfAllActionsTable(){
  clearSelectOperateSelections();
  alert("filter = " + document.getElementById("filterValue").value);
  populateActionsTableForList();
}
function clearFilterAndRefreshAllActionsTable(){
  document.getElementById("filterValue").value = "";
  clearSelectOperateSelections();
  populateActionsTableForList();
}
