YAHOO.util.Event.addListener(window, "load", function() {
       createUsersTable();
      if (doesUserHaveEditRole()){
          document.getElementById("addNewUserButton").disabled = "";
      }
});

function createFilteredUsersTable(){
  clearSelectOperateSelections();
  createUsersTable();
}
function createUsersTable(){
  var filterValue = document.getElementById('filterValue').value;
  var url = document.getElementById('contextPath').value + "/data/userData?menu=" + document.getElementById('menu').value;
  url += "&filterValue=" + encodeURIComponent(filterValue);

        this.userDataSource = createServerSidePaginationDataSource(url);

           this.userDataSource.responseSchema = {
             resultNode: "user",
              fields: ["userName", "userID", "role", "regions", "viewUrl", "addUrl", "removeUrl"],
             metaFields: {totalRecords : "totalRecords"}
           };

        this.userDataTable = getUsersTable(getColumnDefs(), this.userDataSource);
}

function getUsersTable(columnDefs, dataSource){
 var usersDataTable = createServerSidePaginationTable("allUsersTable", columnDefs, dataSource, "userName", null, {topPaginator:'topPaginator'});

  setParamsForSelectOperate(usersDataTable, 'userID');
  usersDataTable.subscribe("checkboxClickEvent", function(oArgs) {
    checkboxClickEvent(oArgs);
  });

  usersDataTable.subscribe("rowMouseoverEvent", usersDataTable.onEventHighlightRow);
  usersDataTable.subscribe("rowMouseoverEvent", usersDataTable.onEventUnhighlightRow);
  usersDataTable.set("selectionMode", "single");
  return usersDataTable;
}

function usernameFormatter(elCell, oRecord) {
  var username = oRecord.getData("userName");
  var url = oRecord.getData("viewUrl");
  elCell.innerHTML = '<a href="' + url + '">' + username + '</a>';
}

function getColumnDefs() {
  var removeOrLockedFormatter = function(elCell, oRecord, oColumn, oData) {
    var username = oRecord.getData("userName");
    var confirmMsg = 'This will revoke access for user ' + username + ' from the system. Are you sure?';
    var deactivateUrl = oRecord.getData("removeUrl");
    setRemoveOrLocked(elCell, false, confirmMsg, deactivateUrl);
  };

  var myUsernameFormatter = function(elCell, oRecord, oColulmn, oData) {
    usernameFormatter(elCell, oRecord);
  };

  return [
   getCheckboxColumnDef(),
  {key:"userName", label:"<b>User Name</b>", sortable:true, resizeable:true, formatter: myUsernameFormatter},
  {key:"userID", label:"<b>User ID</b>", sortable:true, resizeable:true, width:100},
  {key:"role", label:"<b>Role</b>", sortable:true, resizeable:true, width:100},
  {key:"regions", label:"<b>Regions</b>", sortable:true, resizeable:true, width:100}
//  {key:"removeUrl", label:"", sortable:false, resizeable:true, formatter:removeOrLockedFormatter, width:40}
      ];
}

function addUser(){
  var contextPath = document.getElementById("contextPath").value;
  document.location = contextPath + "/servlet/maintainUserAccess?method=setupDataForNewUserRole&newUser=Y";
}

function clearUserSearchFilter(){
 document.getElementById("filterValue").value = "";
 clearSelectOperateSelections();
 createUsersTable();
}

function deleteSelected(){
// var confirmMsg = 'This will revoke access for user ' + getQueryStringForDeleteMessage() + ' from the system. Are you sure?';
  var contextPath = document.getElementById("contextPath").value;
  var filterValue =  encodeURIComponent(document.getElementById("filterValue").value);
//  if (confirm(confirmMsg)){
  document.location = contextPath + "/servlet/maintainUserAccess?method=deleteUsersRole&filterValue=" + filterValue +
                      getQueryStringForSelectSave();
//  }
}

function emailSelected(){
  var i = 0;
  var contextPath = document.getElementById("contextPath").value;
  var filterValue =  encodeURIComponent(document.getElementById("filterValue").value);

  var callBackAfterGettingEmailIds = {
  success: function(o) {
        this.cache = null;
        var emailString = o.responseText;
        document.location.href = "mailTo:" + emailString + ";";
      },
  failure: function(o) {
      alert("Email Call Failed.")
    },
  timeout: 20000 //20 seconds
};

  var url = contextPath + "/data/userAccess?method=getSelectedUsersEmail&filterValue=" + filterValue + getQueryStringForSelectSave();
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
  url,
  callBackAfterGettingEmailIds);
}


