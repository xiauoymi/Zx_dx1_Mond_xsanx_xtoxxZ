function createAddEditAssessmentDialog() {
    var handleSubmit = function() {
    if (this.validate()) {
      saveOrUpdateAssessment(this);
//      this.form.reset();
      this.hide();
    }
  };

  var handleCancel = function() {
    this.form.reset();
    this.cancel();
  };



  var addEditAssessmentnDialog = new YAHOO.widget.Dialog("addEditAssessmentDialog",
  { width : "50em",
    visible : false,
    x: getXForDialog(),
    y: getYForDialog()
  });

  addEditAssessmentnDialog.validate = function() {
    var data = this.getData();
    if (data.assmtName.trim() === "") {
      alert("Please enter name.");
      return false;
    }else {
      return true;
    }
  };


  addKeyListeners(addEditAssessmentnDialog);
  addEditAssessmentnDialog.render();
  YAHOO.util.Event.addListener("assessmentBtn", "click", addEditAssessmentnDialog.show, addEditAssessmentnDialog, true);
  YAHOO.util.Event.addListener("saveAssessmentBtn", "click", handleSubmit, addEditAssessmentnDialog, true);
  YAHOO.util.Event.addListener("saveAssessmentBtnFromList", "click", handleSubmit, addEditAssessmentnDialog, true);
  YAHOO.util.Event.addListener("cancelAssessmentBtn", "click", handleCancel, addEditAssessmentnDialog, true);
}

function hideStatusElement(){
  var hasSubActionItems = document.getElementById("hasSubActionItems").value;
  if (hasSubActionItems > 0){
    document.getElementById("statusHeader").style.visibility = "hidden";
    document.getElementById("actionStatusId").style.visibility = "hidden";
  }
  this.show();
}

function showStatusElement(){
  document.getElementById("statusHeader").style.visibility = "visible";
  document.getElementById("actionStatusId").style.visibility = "visible";
}

function showNewActionItemDialog(){
  document.getElementById("statusHeader").style.visibility = "visible";
  document.getElementById("actionStatusId").style.visibility = "visible";
  resetFormForSubActionItem();
  this.show();
}

function resetFormForSubActionItem(){
  document.getElementById("actionName").value = "";
  document.getElementById('thisActionId').value = "";
  document.getElementById('actionName').value = "";
  document.getElementById('actionStartDate').value = "";
  document.getElementById('actionDueDate').value = "";
  document.getElementById('actionDateCompleted').value = "";
  document.getElementById('actionDescription').value = "";
  var statusEl = document.getElementById('actionStatusId');
//  if (statusEl != null){
  statusEl.selectedIndex = 0;
//  }
  var priorityEl = document.getElementById('actionPriorityId');
  priorityEl.selectedIndex = 1;
  document.getElementById("actionPercentComplete").value = "0";
//  form.reset();
}

function getAssessmentParameters() {
  var id = document.getElementById('assessmentId').value;
  var name = document.getElementById('assmtName').value;
  var dueDate = document.getElementById('assmtDueDate').value;
  var description = document.getElementById('assmtDescription').value;

  var statusEl = document.getElementById('assmtStatusId');
  var status = statusEl.options[statusEl.selectedIndex].value;

   var regionEl = document.getElementById('region');
  var region = statusEl.options[regionEl.selectedIndex].value;

   var countryEl = document.getElementById('country');
  var country = statusEl.options[countryEl.selectedIndex].value;

   var stateEl = document.getElementById('state');
  var state = statusEl.options[stateEl.selectedIndex].value;

  var parameters;
  parameters = "&assessmentId=" + id;
  parameters += "&assmtName=" + name;
  parameters += "&assmtDueDate=" + dueDate;
  parameters += "&assmtStatus=" + status;
  parameters += "&assmtDescription=" + description;
  parameters += "&region=" + region;
  parameters += "&country=" + country;
  parameters += "&state=" + state;
  return parameters;
}

function saveOrUpdateAssessment(dialog) {
  var assmtId = document.getElementById('assessmentId').value;
  var parameters = getAssessmentParameters();
  var method;
  var url;
  var operation;
  if (assmtId == "") {
    method = "addAssessment";
    url = document.getElementById('contextPath').value + "/servlet/assessment?method=" + method + parameters;
    operation = "add";
    dialog.form.action = url;
    dialog.form.submit();
  }else {
    method = "updateAssessment";
    url = document.getElementById('contextPath').value + "/data/assessment?method=" + method + parameters;
    operation = "edit";
    var callBackAfterSavingAssessment = {
      success: function(o) {
        this.cache = null;
        if (operation == "add"){
            //populateActionsTable();
        }else{
          populateAssessmentPropertySheet(o);
        }
      },
    failure: function(o) {
      alert("Save/Update Action Call Failed.")
    },
    timeout: 20000 //20 seconds
  };

    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
    url,
    callBackAfterSavingAssessment);
  }
}

function populateAssessmentPropertySheet(o)
{
   var xmlDoc = o.responseXML;
  document.getElementById('actionNameEdit').innerHTML = xmlDoc.getElementsByTagName('actionName')[0].text;
  document.getElementById('actionStartDateEdit').innerHTML = xmlDoc.getElementsByTagName('actionStartDate')[0].text;
  document.getElementById('actionDueDateEdit').innerHTML = xmlDoc.getElementsByTagName('actionDueDate')[0].text;
  document.getElementById('actionDateCompletedEdit').innerHTML = xmlDoc.getElementsByTagName('actionDateCompleted')[0].text;
  document.getElementById('actionDescriptionEdit').innerHTML = xmlDoc.getElementsByTagName('actionDescription')[0].text;
  if (document.getElementById('actionStatusEdit') != null){
    document.getElementById('actionStatusEdit').innerHTML = xmlDoc.getElementsByTagName('actionStatus')[0].text;
  }
   document.getElementById('actionPriorityEdit').innerHTML = xmlDoc.getElementsByTagName('actionPriority')[0].text;
}

