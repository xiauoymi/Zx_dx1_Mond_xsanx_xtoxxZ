YAHOO.util.Event.addListener(window, "load", function() {
  var scope = document.getElementById("scope").value;
  populateAssessmentsTable();
  populateGeoDataLists(true);
  createAddEditAssessmentDialog();
//   createAddEditAssignmentDialog();

//  if (scope == "My") {
    if (doesUserHaveEditRole()) {
    if (document.getElementById("assessmentBtn") != null){
      document.getElementById("assessmentBtn").disabled = "";
    }
      document.getElementById("saveAssessmentBtnFromList").disabled = "";
      if (document.getElementById("saveAssessmentBtn") != null){
      document.getElementById("saveAssessmentBtn").disabled = "";
      }
    createCalendar("calendarmenu1", "dueDateCalendarPlaceHolder", "calendarcontainer1", "tablecalendar1", "calendarpicker1", "assmtDueDate");
  }
});


function populateAssessmentsTable(){
  var url = document.getElementById('contextPath').value + "/data/assessmentDataXml";
       url += "?filterValue=" + encodeURIComponent(document.getElementById("filterValue").value);
  createAssessmentTable(url);
}

function createFilteredListOfAllAssessmentsTable(){
  document.getElementById("filterValue").value = "";
  clearSelectOperateSelections();
  populateAssessmentsTable();
}

function clearFilterAndRefreshAllAssessmentsTable(){
  clearSelectOperateSelections();
  populateAssessmentsTable();
}



