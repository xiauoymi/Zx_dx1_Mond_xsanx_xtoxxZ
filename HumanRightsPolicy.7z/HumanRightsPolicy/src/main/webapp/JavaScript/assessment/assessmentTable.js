var createAssessmentTab = {
    success: function(o) {
        createAssessmentTable(o);
    },
    failure: function(o) {
    },
    timeout: 20000 //20 seconds
};

function createAssessmentTable(url) {
  this.assessmentDataSource = getDataSourceForAssessment(url);
  this.assessmentDataTable = getAssessmentTable(getAssessmentColumnDefs(), this.assessmentDataSource);
  this.assessmentDataTable.subscribe("dataReturnEvent", function (oArgs) {
  });
}

function  getDataSourceForAssessment(url) {
  var assessmentDataSource = createServerSidePaginationDataSource(url);
  assessmentDataSource.responseSchema = {
    resultNode: "assessment",
    fields: ["id", "name",
      "dueDate", "status", "region", "country", "state", "viewUrl"],
    metaFields: {totalRecords : "totalRecords"}
  };
  return assessmentDataSource;
}

function getAssessmentTable(columnDefs, dataSource) {
  var assessmentDataTable = createServerSidePaginationTable("assessmentsList", columnDefs, dataSource, "name", null, {topPaginator:'topPaginatorForAssessment'});

  setParamsForSelectOperate(assessmentDataTable, 'id', doesUserHaveEditRole());

  assessmentDataTable.subscribe("checkboxClickEvent", function(oArgs) {
    checkboxClickEvent(oArgs);
  });

  assessmentDataTable.subscribe("rowMouseoverEvent", assessmentDataTable.onEventHighlightRow);
  assessmentDataTable.subscribe("rowMouseoutEvent", assessmentDataTable.onEventUnhighlightRow);

  return assessmentDataTable;
}

function actionNameFormatter(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<a href="' + oRecord.getData('viewUrl') + '">' + oData + '</a>';
}

var urgentFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oData == "Y") {
      elCell.innerHTML = '<img border="0" alt="Urgent" src="' +
                         document.getElementById('contextPath').value +
                         '/images/imp-high.gif">';
    } else {
      elCell.innerHTML = '&nbsp;';//very important for sorting to work
    }
  };

  var attachmentFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oData != null || oData != undefined) {
      elCell.innerHTML = '<img border="0" alt="Attachment" src="' +
                         document.getElementById('contextPath').value +
                         '/images/paperclip.gif">';
    } else {
      elCell.innerHTML = '&nbsp;';//very important for sorting to work
    }
  };

 var actionTypeFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oData != "") {
      if (oRecord.getData('status') === 'Closed'){
        elCell.innerHTML = '<img border="0" alt="Assessment Closed" src="' +
                         document.getElementById('contextPath').value +
                         '/images/actionItem-done.gif">';
      }else{
        elCell.innerHTML = '<img border="0" alt="Action Item" src="' +
                         document.getElementById('contextPath').value +
                         '/images/actionItem.gif">';
      }
    } else {
      elCell.innerHTML = '&nbsp;';//very important for sorting to work
    }
  };

function getAssessmentColumnDefs() {
  var urgentImgTh = '<img border="0" alt="Urgent" src="' +
                    document.getElementById('contextPath').value +
                    '/images/view-importance.gif">';

  var attachmentImgTh = '<img border="0" alt="Attachment" src="' +
                        document.getElementById('contextPath').value +
                        '/images/view-paperclip.gif">';

  var actionTypeImgTh = '<img border="0" alt="ActionItemType" src="' +
                        document.getElementById('contextPath').value +
                        '/images/actionItem.gif">';
   var checkbox = getCheckboxColumnDef();
  var urgent = {key:"urgent", label:urgentImgTh, formatter:urgentFormatter, width:14};
  var attachment = {key:"link", label:attachmentImgTh, formatter:attachmentFormatter, width:14};
  var assessmentType = {key:"actionTypeValue", label:actionTypeImgTh, formatter:actionTypeFormatter, sortable:true, resizeable:true, width:18};


    return [
         checkbox,
         urgent,
         assessmentType,
         attachment,
        {key:"name", label:"<b>Name</b>", formatter:actionNameFormatter, sortable:true, resizeable:true, minWidth:240},
        {key:"dueDate", label:"<b>Due Date</b>", sortable:true, resizeable:true, width:80},
        {key:"status", label:"<b>Status</b>", sortable:true, resizeable:true, width:80}
    ];
}
