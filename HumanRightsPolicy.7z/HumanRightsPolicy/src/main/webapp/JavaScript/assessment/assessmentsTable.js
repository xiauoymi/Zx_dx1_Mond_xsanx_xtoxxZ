YAHOO.util.Event.addListener(window, "load", function() {
  getGlobalAssessmentsData();
});

var highImg = '<img border="0" alt="Attachment" src="' +
              '/humanrightspolicy/images/imp-high.gif">';

var mediumImg = '<img border="0" alt="Attachment" src="' +
                '/humanrightspolicy/images/completed.gif">';

var lowImg = '<img border="0" alt="Attachment" src="' +
             '/humanrightspolicy/images/padlock.gif">';


var riskFormatter = function(elCell, oRecord, oColumn, oData) {
  if (oData == "High") {
    elCell.innerHTML = highImg;
  } else if (oData == "Medium") {
    elCell.innerHTML = mediumImg;
  } else {
    elCell.innerHTML = lowImg;
  }
};

function getGlobalAssessmentsData() {
  var contextPath = document.getElementById("contextPath").value;
  var callBackAfterGettingGblAssessments = {
    success: function(o) {
      this.cache = null;
      var xmlDoc = o.responseXML;
      createGblAssessmentsTable(xmlDoc);
    },
    failure: function(o) {
      alert("Error getting data.")
    },
    timeout: 20000 //20 seconds
  };

  var url = contextPath + "/data/gblAssessment?region=34&startIndex=0&rowsPerPage=30";
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url,
      callBackAfterGettingGblAssessments);
}

function createGblAssessmentsTable(xmlDoc) {
  var myColumnDefs = [
    {key:"policy",label:"Policy"},
    {key:"country",label:"Country"},
    {key:"risk", label:"Risk", formatter: this.riskFormatter, editor:"radio", editorOptions:{radioOptions:["high", "medium", "low"],disableBtns:true}}
  ];

  this.gblAsmtDataSource = new YAHOO.util.DataSource(xmlDoc);
  this.gblAsmtDataSource.responseType = YAHOO.util.DataSource.TYPE_XML;
  this.gblAsmtDataSource.responseSchema = {
    resultNode: "globalAssessment",
    fields: ["id", "countryId", "country", "policyId", "policy", "riskId", "risk"],
    metaFields: {totalRecords : "totalRecords"}
  };

  this.gblAsmtTable = new YAHOO.widget.DataTable("globalAssessmentsForCountryList", myColumnDefs, this.gblAsmtDataSource);

  this.gblAsmtTable.subscribe("cellClickEvent", this.gblAsmtTable.onEventShowCellEditor);
  this.gblAsmtTable.subscribe("editorUpdateEvent", function(oArgs) {
    this.saveCellEditor();
  });
  this.gblAsmtTable.subscribe("editorBlurEvent", function(oArgs) {
    this.cancelCellEditor();
  });
}