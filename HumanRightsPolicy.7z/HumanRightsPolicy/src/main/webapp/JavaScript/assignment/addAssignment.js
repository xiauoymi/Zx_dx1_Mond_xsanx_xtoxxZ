function createAddEditAssignmentDialog() {
    var handleSubmit = function() {
    if (this.validate()) {
      saveAssignmentsForObject(this);
      this.hide();
    }
  };

  var handleCancel = function() {
    this.form.reset();
    this.cancel();
  };



  var addEditAssignmentDialog = new YAHOO.widget.Dialog("addEditAssignmentDialog",
  { width : "60em",
    visible : false,
    x: getXForDialog(),
    y: getYForDialog()
  });

  addEditAssignmentDialog.validate = function() {
    var data = this.getData();
//    if (data.assignmentName.trim() === "") {
//      alert("Please enter name.");
//      return false;
//    }else {
      return true;
//    }
  };


  addKeyListeners(addEditAssignmentDialog);
  addEditAssignmentDialog.render();
  YAHOO.util.Event.addListener("newAssignmentBtn", "click", showAllUsers, addEditAssignmentDialog, true);
  YAHOO.util.Event.addListener("saveAssignmentBtn", "click", handleSubmit, addEditAssignmentDialog, true);
  YAHOO.util.Event.addListener("saveAllAssignmentsBtn", "click", handleSubmitForAll, addEditAssignmentDialog, true);
  YAHOO.util.Event.addListener("cancelAssignmentBtn", "click", handleCancel, addEditAssignmentDialog, true);
}

function handleSubmitForAll(){
  if (this.validate()) {
    document.getElementById("areAllAcrossPagesSelected").value = "true";
      saveAssignmentsForObject(this);
      this.hide();
  }
}

function showAllUsers(){
  clearSelectOperateSelections();
  createUsersTable();
  this.show();
}


function getActionParameters() {
  var id = document.getElementById('actionId').value;
  var name = document.getElementById('actionName').value;
  var startDate = document.getElementById('actionStartDate').value;
  var dueDate = document.getElementById('actionDueDate').value;
  var dateCompleted = document.getElementById('actionDateCompleted').value;
  var description = document.getElementById('actionDescription').value;
  var statusEl = document.getElementById('actionStatusId');
  var status;
  if (statusEl == null){
        status = "";
  }else{
        status = statusEl.options[statusEl.selectedIndex].value;
  }
  var priorityEl = document.getElementById('actionPriorityId');
  var priority = priorityEl.options[priorityEl.selectedIndex].value;
  var percentageComplete = document.getElementById("actionPercentComplete").value;
  var parentActionItem = document.getElementById("parentAction").value;
  var parameters;
  parameters = "&actionId=" + id;
  parameters += "&actionName=" + name;
  parameters += "&actionStartDate=" + startDate;
  parameters += "&actionDueDate=" + dueDate;
  parameters += "&actionDateCompleted=" + dateCompleted;
  parameters += "&actionStatus=" + status;
  parameters += "&actionPriority=" + priority;
  parameters += "&actionPercentComplete=" + percentageComplete;
  parameters += "&actionDescription=" + description;
  parameters += "&parentAction=" + parentActionItem;
  return parameters;
}

function saveAssignmentsForObject(dialog) {
  var actionId = document.getElementById('actionId').value;
  var parameters = "&actionId=" + actionId + getQueryStringForSelectSave();
  var method;
  var url;
    method = "addAssignmentsToAction";
    url = document.getElementById('contextPath').value + "/servlet/action?method=" + method + parameters;
    dialog.form.action = url;
    dialog.form.submit();
//    var callBackAfterAddingAction = {
//      success: function(o) {
//        this.cache = null;
//        if (operation == "add"){
//            //populateActionsTable();
//        }else{
//          populateActionPropertySheet(o);
//        }
//      },
//    failure: function(o) {
//      alert("Save/Update Action Call Failed.")
//    },
//    timeout: 20000 //20 seconds
//  };
//
//    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
//    url,
//    callBackAfterAddingAction);
}

function populateActionPropertySheet(o)
{
   var xmlDoc = o.responseXML;
  document.getElementById('actionNameEdit').innerHTML = xmlDoc.getElementsByTagName('actionName')[0].text;
  document.getElementById('actionStartDateEdit').innerHTML = xmlDoc.getElementsByTagName('actionStartDate')[0].text;
  document.getElementById('actionDueDateEdit').innerHTML = xmlDoc.getElementsByTagName('actionDueDate')[0].text;
  document.getElementById('actionDateCompletedEdit').innerHTML = xmlDoc.getElementsByTagName('actionDateCompleted')[0].text;
  document.getElementById('actionDescriptionEdit').innerHTML = xmlDoc.getElementsByTagName('actionDescription')[0].text;
  if (document.getElementById('actionStatusEdit') != null){
    document.getElementById('actionStatusEdit').innerHTML = xmlDoc.getElementsByTagName('actionStatus')[0].text;
  }
   document.getElementById('actionPriorityEdit').innerHTML = xmlDoc.getElementsByTagName('actionPriority')[0].text;
}

function createUsersTable(){
var filterValue = document.getElementById('filterValue').value;
 var url = document.getElementById('contextPath').value + "/data/userData?menu=" + document.getElementById('menu').value;
 url += "&filterValue=" + encodeURIComponent(filterValue);

       this.userDataSource = createServerSidePaginationDataSource(url);

          this.userDataSource.responseSchema = {
            resultNode: "user",
             fields: ["userName", "userID", "updatePrimaryFlagUrl"],
            metaFields: {totalRecords : "totalRecords"}
          };

       this.userDataTable = getUsersTable(getColumnDefs(), this.userDataSource);
 }

 function getUsersTable(columnDefs, dataSource){
  var usersDataTable = createServerSidePaginationTable("allUsersForAssignmentTable", columnDefs, dataSource, "userName", {scrollable: true, height:"30em"}, {topPaginator:'topPaginator'});
 setParamsForSelectOperate(usersDataTable, 'userID', doesUserHaveEditRole());
 usersDataTable.subscribe("checkboxClickEvent", function(oArgs) {
   checkboxClickEvent(oArgs);
 });

 usersDataTable.subscribe("rowMouseoverEvent", usersDataTable.onEventHighlightRow);
 usersDataTable.subscribe("rowMouseoverEvent", usersDataTable.onEventUnhighlightRow);
 usersDataTable.set("selectionMode", "single");

 return usersDataTable;
 }

 function usernameFormatter(elCell, oRecord) {
 var username = oRecord.getData("userName");
 var url = oRecord.getData("viewUrl");
 elCell.innerHTML = '<a href="' + url + '">' + username + '</a>';
 }

function checkBoxFormatterForAssignment(elCell, oRecord, oColumn, oData)
{
  var i = 0;
 var assignees = document.getElementById("assignees").value;
  var assigneesAsArray = assignees.split(",");
  var bChecked = false;
  for (i=0; i < assigneesAsArray.length; i++){
    if (oRecord.getData("userID") === assigneesAsArray[i]){
      bChecked = true;
    }
  }
    var checkedFlag = (bChecked === true) ? " checked" : "";
    var innerHTMLForCheckbox = "<input type=\"checkbox\" " + checkedFlag;
    innerHTMLForCheckbox += " class=\"" + YAHOO.widget.DataTable.CLASS_CHECKBOX + "\">";
    elCell.innerHTML = innerHTMLForCheckbox;
 }

 function getColumnDefs() {
 return [
 //  {key:"userID",label:"<input id='theadCheckbox' name='theadCheckbox' type='checkbox' class='yui-dt-checkbox' onclick='theadCheckboxOnClick(this)'></input>", sortable:true, resizeable:true,formatter:checkBoxFormatterForAssignment, width:20},
     getCheckboxColumnDef(),
   {key:"userName", label:"<b>User Name</b>", sortable:true, resizeable:true}
     ];
 }

