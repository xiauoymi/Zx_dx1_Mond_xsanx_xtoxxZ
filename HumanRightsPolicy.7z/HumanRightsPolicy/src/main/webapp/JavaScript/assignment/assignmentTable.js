var createAssignmentsTab = {
    success: function(o) {
        createAssignmentsTable(o);
    },
    failure: function(o) {
    },
    timeout: 20000 //20 seconds
};

function createAssignmentsTable(url) {
  this.assignmentDataSource = createServerSidePaginationDataSource(url);
    this.assignmentDataSource.responseSchema = {
        resultNode: "assignment",
        fields: [{key: "isPrimary", parser:this.primaryFlagParser}, "assignmentId", "assignmentUserName", "updatePrimaryFlagUrl"],
        metaFields: {totalRecords : "totalRecords"}
    };
    this.assignmentDataTable = getAssignmentTable(getAssignmentColumnDefs(), this.assignmentDataSource);
  this.assignmentDataTable.subscribe("dataReturnEvent", function (oArgs) {
    setLabelForAssignmentsTabOnAction(oArgs);
  });
}

function checkIfRecordBeingDeletedIsPrimary(oArgs) {
   var elCheckbox = oArgs.target;
  var oRecord = dt.getRecord(elCheckbox);
  if (oRecord.getData("isPrimary") === true){
    alert("You cannot delete a primary assignment");
  }
}


function getAssignmentTable(assignmentColumnDefs, dataSource) {
  var assignmentsDataTable = createServerSidePaginationTable("assignmentsList", assignmentColumnDefs, dataSource, "assignmentUserName", null, {topPaginator:'topPaginatorForAssignment'});

  setParamsForSelectOperate(assignmentsDataTable, 'assignmentId', doesUserHaveEditRole());

  assignmentsDataTable.subscribe("checkboxClickEvent", function(oArgs) {
    checkboxClickEvent(oArgs);
  });

  assignmentsDataTable.subscribe("rowMouseoverEvent", assignmentsDataTable.onEventHighlightRow);
  assignmentsDataTable.subscribe("rowMouseoutEvent", assignmentsDataTable.onEventUnhighlightRow);
    assignmentsDataTable.subscribe("radioClickEvent", function(oArgs) {
    var elRadio = oArgs.target;
    elRadio.style.backgroundColor = "#854225";
    /*Red*/
    disableAllRadioBtns(assignmentsDataTable, true);
    var elRecord = this.getRecord(elRadio);
    var updatePrimaryFlagUrl = elRecord.getData("updatePrimaryFlagUrl");

    var callBackAfterUpdatingPrimaryFlagForAssignment = {
      success: function(o) {
        this.cache = null;
        elRadio.style.backgroundColor = "";
        disableAllRadioBtns(assignmentsDataTable, false);
//        populateAssignmentsTable();
      },
      failure: function(o) {
      },
      timeout: 20000 //20 seconds
    };

    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
        updatePrimaryFlagUrl,
        callBackAfterUpdatingPrimaryFlagForAssignment);
  });

  return assignmentsDataTable;
}

function assignmentNameFormatter(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<a href="' + oRecord.getData('assignmentUserName') + '">' + oData + '</a>';
}

 var assignmentTypeFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oData != "") {
      elCell.innerHTML = '<img border="0" alt="Action Item" src="' +
                         document.getElementById('contextPath').value +
                         '/images/actionItem.gif">';
    } else {
      elCell.innerHTML = '&nbsp;';//very important for sorting to work
    }
  };

function getAssignmentColumnDefs() {
  var checkbox = getCheckboxColumnDef();

  var assignmentTypeTh = '<img border="0" alt="ActionItemType" src="' +
                        document.getElementById('contextPath').value +
                        '/images/actionItem.gif">';
  var assignmentType = {key:"assignmentTypeValue", label:assignmentTypeTh, formatter:assignmentTypeFormatter, sortable:true, resizeable:true, width:18};

  var isPrimary = {key:"isPrimary", label:"", formatter:YAHOO.widget.DataTable.formatRadio, resizeable:true, width:20};

  return [
        checkbox,
        isPrimary,
        assignmentType,
        {key:"assignmentUserName", label:"<b>Name</b>", sortable:true, resizeable:true}
    ];
}
