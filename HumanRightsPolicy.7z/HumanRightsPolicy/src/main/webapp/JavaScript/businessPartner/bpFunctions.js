YAHOO.util.Event.addListener(window, "load", function() {
  createBPTabs();
  createAddEditLocationDialog();
  populateGeoDataLists(true);
  createAddEditContactDialog();
  createAddEditCommunicationDialog();
  createCalendar("calendarmenu1", "fromCalendarPlaceHolder", "calendarcontainer1", "tablecalendar1", "calendarpicker1", "commFromPeriod");
  createCalendar("calendarmenu2", "toCalendarPlaceHolder", "calendarcontainer2", "tablecalendar2", "calendarpicker2", "commToPeriod");
  createCalendar("calendarmenu5", "dueDateCalendarPlaceHolder", "calendarcontainer5", "tablecalendar5", "calendarpicker5", "commDueDate");

  if (doesUserHaveEditRole()) {
    document.getElementById("addEditLocationBtn").disabled = "";
    document.getElementById("addEditContactBtn").disabled = "";
    document.getElementById("commBtn").disabled = "";
  }
});

function selectStatesAndRegion(companyCountry) {
  var countryid = companyCountry.options[companyCountry.selectedIndex].value;
  document.forms[0].action = document.getElementById('contextPath').value +
                             "/servlet/businessPartner?method=lookupStatesAndRegionForCountry";
  document.forms[0].submit();
}

function showHidePolicySentDate(elemnetToHide, style) {
  var element = document.getElementById(elemnetToHide);
  element.style.display = style;
}

function cancelAction() {
  document.forms[0].action = document.getElementById('contextPath').value + "/servlet/searchBusinessPartner?method=";
  document.forms[0].submit();
}

function addNewContact() {
  document.forms[0].action = document.getElementById('contextPath').value + "/servlet/contacts?method=addContact";
  document.forms[0].submit();
}

function endBPLocationRels() {
  var bpId = document.getElementById("businessPartnerId").value;
  var menu = document.getElementById("menu").value;
  document.forms.locationForm.action = document.getElementById("contextPath").value +
                                       "/servlet/bpLocRel?method=endBPLocationRelationship&businessPartnerId=" + bpId
      + "&menu=" + menu + getQueryStringForSelectSave()
      + getQueryStringForActiveTabIndex();
  document.forms.locationForm.submit();
}

function endBPContactRels() {
  var bpId = document.getElementById("businessPartnerId").value;
  var menu = document.getElementById("menu").value;
  document.forms.contactForm.action = document.getElementById("contextPath").value +
                                      "/servlet/bpContactRel?method=endBPContactRelationship&businessPartnerId=" + bpId
      + "&menu=" + menu + getQueryStringForSelectSave()
      + getQueryStringForActiveTabIndex();
  document.forms.contactForm.submit();
}
