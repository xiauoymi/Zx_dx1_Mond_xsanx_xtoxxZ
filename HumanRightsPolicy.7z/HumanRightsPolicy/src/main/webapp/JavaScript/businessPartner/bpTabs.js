var bpTabView;
var locationsTab;
var contactsTab;
var commsTab;

function createBPTabs() {

    bpTabView = new YAHOO.widget.TabView();

    locationsTab = new YAHOO.widget.Tab({
        label: getLabelForLocationsTabOnBP(),
        content: document.getElementById('locationsTab').innerHTML,
        active: false
    });

  if (hasAccessToLocation()) {
    bpTabView.addTab(locationsTab);
  }

   contactsTab = new YAHOO.widget.Tab({
        label: getLabelForContactsTabOnBP(),
        content: document.getElementById('contactsTab').innerHTML,
        active: false
    });

  if (hasAccessToContact()) {
    bpTabView.addTab(contactsTab);
  }
    commsTab = new YAHOO.widget.Tab({
        label: getLabelForCommunicationsTabOnBP(),
        content: document.getElementById('commsTab').innerHTML,
        active: false
    });

   if (hasAccessToCommunication()) {
    bpTabView.addTab(commsTab);
   }

  document.getElementById('tabs').innerHTML = '';
  if (bpTabView.get("tabs").length > 0) {
    bpTabView.appendTo('tabs');
    bpTabView.set("activeIndex", getActiveTabIndex());
  }

  /* Only add the contacts tab, if user has permission to view it. */
  if (hasAccessToContact()) {
      populateContactsTable();
    }
  /* Only add the communication tab, if user has permission to view it. */
  if (hasAccessToCommunication()) {
      populateCommunicationsTable();
    }
  /* Only add the location tab, if user has permission to view it. */
  if (hasAccessToLocation()) {
      populateLocationsTable();
    }

  bpTabView.on('activeTabChange', function(ev) {
        clearSelectionsIfActiveTabDifferentFromLastActiveTab(bpTabView, ev.newValue);
        if (ev.newValue == contactsTab) {
            populateContactsTable();
        } else if (ev.newValue == locationsTab) {
            populateLocationsTable();
        } else if (ev.newValue == commsTab) {
            populateCommunicationsTable();
        }
    });
}

function getLabelForLocationsTabOnBP() {
  return "Locations";
}

function getLabelForContactsTabOnBP() {
  return "Contacts";
}

function getLabelForCommunicationsTabOnBP() {
  return "Communications";
}

function setLabelForLocationsTabOnBP(oArgs) {
  if(isTabAddedToTabView(bpTabView, locationsTab))
    setLabelOnTab(locationsTab, getLabelForLocationsTabOnBP(), oArgs);
}

function setLabelForContactsTabOnBP(oArgs) {
  if(isTabAddedToTabView(bpTabView, contactsTab))
    setLabelOnTab(contactsTab, getLabelForContactsTabOnBP(), oArgs);
}

function setLabelForCommunicationsTabOnBP(oArgs) {
  if(isTabAddedToTabView(bpTabView, commsTab))
    setLabelOnTab(commsTab, getLabelForCommunicationsTabOnBP(), oArgs);
}

function populateLocationsTable() {
    var url = document.getElementById('contextPath').value + "/data/bpLocationXml?businessPartnerId=" +
              document.getElementById("businessPartnerId").value +
              "&menu=" + document.getElementById('menu').value;
    createLocationsTable(url, true);
}

function populateContactsTable() {
    var url = document.getElementById('contextPath').value + "/data/bpContactXml?businessPartnerId=" +
              document.getElementById("businessPartnerId").value +
              "&menu=" + document.getElementById('menu').value;
    createContactsTable(url);
}

function populateContactsTableForBP() {
    var url = document.getElementById('contextPath').value + "/data/bpContactXml?businessPartnerId=" +
              document.getElementById("businessPartnerId").value +
              "&menu=" + document.getElementById('menu').value;
    createContactsTable(url);
}

function populateCommunicationsTable() {
    var url = document.getElementById('contextPath').value + "/data/communicationXmlForBP" +
              "?menu=" + document.getElementById('menu').value +
              "&businessPartnerId=" + document.getElementById('businessPartnerId').value;
    createCommunicationsTable(url);
}

function populateCommunicationsTableForBP() {
    var url = document.getElementById('contextPath').value + "/data/communicationXmlForBP" +
              "?menu=" + document.getElementById('menu').value +
              "&businessPartnerId=" + document.getElementById('businessPartnerId').value;
    createCommunicationsTable(url);
}