var createContentsForBPsTab = {
  success: function(o) {
    createBPsTable(o);
  },
  failure: function(o) {
  },
  timeout: 20000 //20 seconds
};


function createBPsTable(o) {
  this.cache = null;
  var xmlDoc = o.responseXML;
  this.bpNameFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<a href="' + oRecord.getData('viewUrl') + '">' + oData + '</a>';
  };

  var bpColumnDefs = [
    {key:"sapId", label:"<b>SAP ID</b>", sortable:true, resizeable:true, width:100},
    {key:"bpName", label:"<b>Company</b>", formatter:this.bpNameFormatter, sortable:true, resizeable:true, sortOptions:{defaultOrder:"asc"}},
    {key:"state", label:"<b>State/Province</b>", sortable:true, resizeable:true, width:120},
    {key:"country", label:"<b>Country</b>", sortable:true, resizeable:true, width:120},
    {key:"region", label:"<b>World Area</b>", sortable:true, resizeable:true, width:120}
  ];

  this.gblAsmtDataSource = new YAHOO.util.DataSource(xmlDoc);
  this.gblAsmtDataSource.responseType = YAHOO.util.DataSource.TYPE_XML;
  this.gblAsmtDataSource.responseSchema = {
    resultNode: "bp",
    fields: ["hrpFlag", "sapId", "bpName", "aliasName", "country", "state", "region", "viewUrl"]
  };

  var configuration = getConfiguration(xmlDoc, 'bp');

  this.myDataTable = new YAHOO.widget.DataTable("bpsList", bpColumnDefs, this.gblAsmtDataSource, configuration);
  this.myDataTable.subscribe("rowMouseoverEvent", this.myDataTable.onEventHighlightRow);
  this.myDataTable.subscribe("rowMouseoutEvent", this.myDataTable.onEventUnhighlightRow);
  this.myDataTable.subscribe("dataReturnEvent", function (oArgs) {
//    setLabelForBPTabOnContacts(oArgs);   //todo : uncomment and test when the BP tab is added to a contact
  });
}
