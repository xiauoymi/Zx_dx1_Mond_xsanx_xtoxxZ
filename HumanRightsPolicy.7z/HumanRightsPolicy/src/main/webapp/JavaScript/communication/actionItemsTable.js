var createActionItemsTab = {
  success: function(o) {
  },
  failure: function(o) {
    alert("Action Items table creation failed.");
  },
  timeout: 20000 //20 seconds
};

function createActionItemsTable() {
  var url = document.getElementById('contextPath').value + "/data/commActionItemsDataXML"
      + "?commId=" + document.getElementById('commId').value + getFilterParam();
  this.actionsDataTable = getActionsTable(getActionColumnDefs(), getDataSourceForActionItems(url));
  this.actionsDataTable.subscribe("dataReturnEvent", function (oArgs) {
    setLabelForActionItemsTabOnCommPlan(oArgs);
  });
}

function getFilterParam() {
  var filterValue = document.getElementById("filterValueForActionItems").value;
  return "&filterValue=" + encodeURIComponent(filterValue);
}

function createFilteredActionItemsOnCommTable() {
  clearSelectOperateSelections();
  createActionItemsTable();
}

function clearFilterAndRefreshActionItemsOnCommTable() {
  document.getElementById("filterValueForActionItems").value = "";
  createFilteredActionItemsOnCommTable();
}

