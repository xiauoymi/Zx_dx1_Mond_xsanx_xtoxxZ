function createAddActionFromCommDialog() {
  var handleSubmit = function() {
    if (this.validate()) {
      saveActionItemToCommunication(this);
      document.getElementById("statusHeader").style.visibility = "hidden";
      document.getElementById("actionStatusId").style.visibility = "hidden";
      this.form.reset();
      this.hide();
    }
  };
  var handleCancel = function() {
    document.getElementById("statusHeader").style.visibility = "hidden";
    document.getElementById("actionStatusId").style.visibility = "hidden";
    this.form.reset();
    this.cancel();
  };

  var addEditActionFromCommDialog = new YAHOO.widget.Dialog("addEditActionFromCommDialog",
  { width : "50em",
    visible : false,
    x: document.body.clientWidth * 0.10,
    y: document.body.clientHeight * 0.001
  });

  addEditActionFromCommDialog.validate = function() {
    var data = this.getData();
    if (data.actionName.trim() == "") {
      alert("Please enter name.");
      return false;
    }else {
      return true;
    }
  };

  addKeyListeners(addEditActionFromCommDialog);
  addEditActionFromCommDialog.render();
  YAHOO.util.Event.addListener("addActionItemFormBtn", "click", showNewActionItemFromCommDialog, addEditActionFromCommDialog, true);
  YAHOO.util.Event.addListener("saveActionToCommBtn", "click", handleSubmit, addEditActionFromCommDialog, true);
  YAHOO.util.Event.addListener("cancelActionToCommBtn", "click", handleCancel, addEditActionFromCommDialog, true);
}

function showNewActionItemFromCommDialog(){
  document.getElementById("statusHeader").style.visibility = "visible";
  document.getElementById("actionStatusId").style.visibility = "visible";
//  resetFormForSubActionItem();
  this.show();
}

function getParametersToAddActionToComm() {

  var name = document.getElementById('actionName').value;
  var startDate = document.getElementById('actionStartDate').value;
  var dueDate = document.getElementById('actionDueDate').value;
  var dateCompleted = document.getElementById('actionDateCompleted').value;
  var description = document.getElementById('actionDescription').value;
  var statusEl = document.getElementById('actionStatusId');
  var status = "";
  if(statusEl != null)
    status = statusEl.options[statusEl.selectedIndex].value;
  var priorityEl = document.getElementById('actionPriorityId');
  var priority = priorityEl.options[priorityEl.selectedIndex].value;
  var percentageComplete = document.getElementById("actionPercentComplete").value;

  var parameters = "&actionName=" + name;
  parameters += "&actionStartDate=" + startDate;
  parameters += "&actionDueDate=" + dueDate;
  parameters += "&actionDateCompleted=" + dateCompleted;
  parameters += "&actionStatus=" + status;
  parameters += "&actionPriority=" + priority;
  parameters += "&actionPercentComplete=" + percentageComplete;
  parameters += "&actionDescription=" + description;
  return parameters;
}

function saveActionItemToCommunication(dialog) {
  var parameters = getParametersToAddActionToComm();
  var url = document.getElementById('contextPath').value + "/servlet/commactionitems?method=addActionItem" +
            parameters + "&commId=" + document.getElementById('commId').value;
  addActionAsynchronously(url);
}

function addActionAsynchronously(url) {
  var callBackAfterAddingAction = {
    success: function(o) {
      this.cache = null;
      createActionItemsTable();
    },
    failure: function(o) {
      alert("Failed: callBackAfterAddingAction")
    },
    timeout: 20000 //20 seconds
  };

  this.getXML = YAHOO.util.Connect.asyncRequest("GET", url, callBackAfterAddingAction);
}