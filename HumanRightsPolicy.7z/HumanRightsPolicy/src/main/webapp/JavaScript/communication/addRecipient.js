var addRecipientDialog = null;
var addRecipientConfirmDialog = null;
var recipientsSearchDataTable = null;
var recordsToDisable = {};

function createAddRecipientDialog() {

  addRecipientDialog = new YAHOO.widget.Dialog("addRecipientDialog",
  { width : "55em",
    x: getXForAddRecipient(),
    y: getYForAddRecipient(),
    close:true,
    visible:false,
    draggable:true
  });

  addKeyListeners(addRecipientDialog);
//  var enterKeyListener1;
  //  addRecipientDialog.beforeShowEvent.subscribe(function () {
  //    enterKeyListener1 = new YAHOO.util.KeyListener(document, { keys:13 },
  //    { fn:searchRecipients,
  //      scope:addRecipientDialog,
  //      correctScope:true });
  //
  //    enterKeyListener1.enable();
  //  });
  //  addRecipientDialog.beforeHideEvent.subscribe(function () {
  //    enterKeyListener1.disable();
  //  });

  addRecipientDialog.render();

  addRecipientDialog.beforeHideEvent.subscribe(closeRecipientDialog);
  YAHOO.util.Event.addListener("addRecipientBtn", "click", addRecipientDialog.show, addRecipientDialog, true);
  YAHOO.util.Event.addListener("searchRecipientsBtn", "click", searchRecipients, addRecipientDialog, true);
  YAHOO.util.Event.addListener("clearRecipientsBtn", "click", handleClear, addRecipientDialog, true);
  YAHOO.util.Event.addListener("doneBtn", "click", addRecipientDialog.hide, addRecipientDialog, true);
//  YAHOO.util.Event.addListener("addAllBtn", "click", createAddRecipientConfirmDialog, addRecipientDialog, true);

  // add a key lister to open the dialog by pressing the Enter key
  //  var kl2 = new YAHOO.util.KeyListener(document, { keys:13 },
  //  { fn:searchRecipients,
  //    scope:addRecipientDialog,
  //    correctScope:true });
  //  kl2.enable();

  //  renderCaldendar('fromCalendarSearch', null, 'commFromPeriodSearch', 'fromImgSearch');
  //  renderCaldendar('toCalendarSearch', null, 'commToPeriodSearch', 'toImgSearch');

}

function getXForAddRecipient() {
  return (document.body.clientWidth * 0.30);
}

function getYForAddRecipient() {
  return (document.body.clientHeight * 0.15);
}

function handleClear() {
  document.getElementById('searchRecipientResults').innerHTML = " ";
  document.getElementById('addRecipientResultsDiv').style.display = "none";
  this.form.reset();
  disableAddAllBtn(true);
}

function disableAddAllBtn(boolValue) {
  document.getElementById('addAllBtn').disabled = boolValue;
}

function setRecipientAddedFlag() {
  //  document.getElementById('recipientAdded').value=true;
}

function closeRecipientDialog() {
  document.getElementById('searchRecipientResults').innerHTML = " ";
  this.form.reset();

  var commId = document.getElementById('commId').value;
  var menu = document.getElementById('menu').value;
  var recipientAdded = document.getElementById('recipientAdded').value;
  this.form.action = "/humanrightspolicy/servlet/communication?method=lookupCommunication&commId=" + commId +
                     "&recipientAdded=" + recipientAdded + "&menu=" + menu;
  this.form.submit();
}

function searchRecipients() {
  disableAddAllBtn(true);
  document.getElementById('addRecipientResultsDiv').style.display = "";
  var fromDate = document.getElementById('commFromPeriodSearch').value;
  var toDate = document.getElementById('commToPeriodSearch').value;
  if (fromDate !== "" && toDate !== "" && after(fromDate, toDate)) {
    alert('From date should be earlier than To date.');
  } else {
    var url = document.getElementById("contextPath").value + "/data/recipientXml";
    url += "?commId=" + document.getElementById('commId').value + "&menu=" + document.getElementById('menu').value +
           "&scope=search";
    url += getSearchParameters();

    this.recipientsResultsDataSource = createServerSidePaginationDataSource(url);

    this.recipientsResultsDataSource.responseSchema = {
      resultNode: "recipient",
      fields: ["recipientId", "commId", "isDone", "name", "recipientTypeValue", "company", "state", "country", "region", "addRecipientUrl", "removeUrlForAsync"],
      metaFields: {totalRecords : "totalRecords"}
    };
    recipientsSearchDataTable = getSearchRecipientsDataTable(getColumnDefsForSearchRecipientsTable(), this.recipientsResultsDataSource);
  }
}

function getSearchParameters() {
  var peopleType = document.getElementById('searchPeopleTypeId');
  var locationType = document.getElementById('searchLocTypeId');
  var region = document.getElementById('region');
  var country = document.getElementById('country');
  var state = document.getElementById('state');

  var searchParameters = "&commId=" + document.getElementById('commId').value;
  searchParameters += "&hrpFlag=" + document.getElementById('hrpFlag').value;
  searchParameters += "&searchCompany=" + encodeURIComponent(document.getElementById('searchCompany').value);
  searchParameters += "&searchPersonName=" + encodeURIComponent(document.getElementById('searchPersonName').value);
  searchParameters += "&searchPeopleTypeId=" + peopleType.options[peopleType.selectedIndex].value;
  searchParameters += "&searchLocTypeId=" + locationType.options[locationType.selectedIndex].value;
  ;
  searchParameters += "&region=" + region.options[region.selectedIndex].value;
  searchParameters += "&country=" + country.options[country.selectedIndex].value;
  searchParameters += "&state=" + state.options[state.selectedIndex].value;
  return searchParameters;
}

function getColumnDefsForSearchRecipientsTable() {
  return [
    {key:"commId", label:"", formatter:this.checkBoxFormatter, width:40},
    {key:"name", label:"<b>Name</b>", sortable:true, resizeable:true, width:140},
    {key:"recipientTypeValue", label:"<b>Type</b>", sortable:true, resizeable:true, width:80},
    {key:"company", label:"<b>Company</b>", sortable:true, resizeable:true, width:100},
    {key:"state", label:"<b>State/Province</b>", sortable:true, resizeable:true, width:80},
    {key:"country", label:"<b>Country</b>", sortable:true, resizeable:true, width:80},
    {key:"region", label:"<b>World Area</b>", sortable:true, resizeable:true, width:80}
  ];

}
function checkBoxFormatter(elCell, oRecord, oColumn, oData) {
  var bChecked = !isRecipientNotAssociatedWithThisComm(oData);
  if (bChecked) {
    var isDisabled = isRecipientAssociatedWithParentComms(oData);
  }
  bChecked = (bChecked) ? " checked" : "";
  var innerHTMLForCheckbox = "<input type=\"checkbox\" " + bChecked;
  if (isDisabled) {
    innerHTMLForCheckbox += " disabled ";
    recordsToDisable[oRecord.getData("recipientId")] = oRecord;
  }
  innerHTMLForCheckbox += " class=\"" + YAHOO.widget.DataTable.CLASS_CHECKBOX + "\">";
  elCell.innerHTML = innerHTMLForCheckbox;
 }

function getSearchRecipientsDataTable(columnDefs, dataSource) {
  recipientsSearchDataTable = createServerSidePaginationTable("searchRecipientResults", columnDefs, dataSource, "name", {scrollable: true, height:"30em"}, {topPaginator:'topPaginatorForAddRecipient'});

  recipientsSearchDataTable.subscribe("initEvent", function(oArgs) {
    var totalRecords = recipientsSearchDataTable.getAttributeConfig('paginator').value.getTotalRecords();
    disableAddAllBtn(totalRecords <= 0);
    for(var recipientId in recordsToDisable){
      YAHOO.util.Dom.addClass(recipientsSearchDataTable.getTrEl(recordsToDisable[recipientId]), 'disabledRow');
    }
  });
  recipientsSearchDataTable.subscribe("rowMouseoverEvent", recipientsSearchDataTable.onEventHighlightRow);
  recipientsSearchDataTable.subscribe("rowMouseoutEvent", recipientsSearchDataTable.onEventUnhighlightRow);
  recipientsSearchDataTable.set("selectionMode", "singlecell");

  recipientsSearchDataTable.subscribe("checkboxClickEvent", function(oArgs) {
    var elCheckbox = oArgs.target;
    elCheckbox.style.backgroundColor = '#854225';
    /*Red*/
    var oRecord = recipientsSearchDataTable.getRecord(elCheckbox);
    var thisCommId = document.getElementById('commId').value;

    if (elCheckbox.checked) {
      document.getElementById('recipientAdded').value = true;
      addRecipient(oRecord, elCheckbox, thisCommId, "true");
    } else {
      removeRecipient(oRecord, elCheckbox, thisCommId);
    }
  });

  return recipientsSearchDataTable;
}

function isRecipientNotAssociatedWithThisComm(commId) {
  return commId === null || commId === "";
}

function isRecipientAssociatedWithParentComms(commId) {
  var thisCommId = document.getElementById("commId").value;
  return commId != thisCommId;
}

//function addAllRecipients() {
//  var totalRecipients = this.recipientsSearchDataTable.getAttributeConfig('paginator').value.getTotalRecords();
//  if (totalRecipients == 1) {
//    var reci = ' recipient';
//  } else {
//    reci = ' recipients';
//  }
//  var msg = 'Are you sure?\n Click "OK" to add ' + totalRecipients + reci + ' to the Delivery List.';
//
//  createAddRecipientConfirmDialog();
//
//  if (confirm(msg)) {
//
//    var callBackPopulateRecipientsTable = {
//      success: function(o) {
//        this.cache = null;
//        addRecipientDialog.hide();
//        waitingPanel.hide();
//      },
//      failure: function(o)
//      {
//      }//,
//      //timeout: 60000 //60 seconds
//    };
//    waitingPanel.show();
//    document.getElementById('recipientAdded').value = true;
//    var addAllRecipientsUrl = document.getElementById("contextPath").value + "/data/communication";
//    addAllRecipientsUrl += "?method=addAllRecipients";
//    addAllRecipientsUrl += getSearchParameters();
//
//    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
//        addAllRecipientsUrl,
//        callBackPopulateRecipientsTable);
//  }
//}

function addRecipient(oRecord, elCheckbox, thisCommId, recipientAdded) {
  var addRecipientUrl = oRecord.getData("addRecipientUrl");
  addRecipientUrl += "&commId=" + thisCommId;
  addRecipientUrl += "&recipientAdded=" + recipientAdded;
  var callBackAfterAddingRecipient = {
    success: function(o) {
      this.cache = null;
      oRecord.setData("commId", thisCommId);
      elCheckbox.style.backgroundColor = '';
    },
    failure: function(o) {
    },
    timeout: 20000 //20 seconds
  };

  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      addRecipientUrl,
      callBackAfterAddingRecipient);
}

function removeRecipient(oRecord, elCheckbox, thisCommId) {
  var removeUrlForAsync = oRecord.getData("removeUrlForAsync");
  removeUrlForAsync += "&commId=" + thisCommId;

  var callBackAfterRemovingRecipient = {
    success: function(o) {
      this.cache = null;
      oRecord.setData("commId", "");
      elCheckbox.style.backgroundColor = '';
    },
    failure: function(o) {
    },
    timeout: 20000 //20 seconds
  };

  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      removeUrlForAsync,
      callBackAfterRemovingRecipient);
}

function createAddRecipientConfirmDialog() {

  var handleYes = function() {
    this.hide();
    var callBackPopulateRecipientsTable = {
      success: function(o) {
        this.cache = null;
        addRecipientDialog.hide();
        hideWaitingPanel();
      },
      failure: function(o)
      {
      }//,
      //timeout: 60000 //60 seconds
    };
    showWaitingPanel();
    document.getElementById('recipientAdded').value = true;
    var addAllRecipientsUrl = document.getElementById("contextPath").value + "/data/commRecipient";
    addAllRecipientsUrl += "?method=addAllRecipients";
    addAllRecipientsUrl += getSearchParameters();

    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
        addAllRecipientsUrl,
        callBackPopulateRecipientsTable);

  }
  var handleNo = function() {
    this.hide();
    addRecipientDialog.hide();
  }
  var handleCancel = function() {
    this.hide();
  }
  // Instantiate the Dialog
  addRecipientConfirmDialog =
  new YAHOO.widget.SimpleDialog("addRecipientConfirmDialog",
  { width: "400px",
    fixedcenter: true,
    visible: false,
    draggable: false,
    close: true,
    modal: true,
    icon: YAHOO.widget.SimpleDialog.ICON_HELP,
    constraintoviewport: true,
    buttons: [ { text:"Yes", handler:handleYes, isDefault:true },
      { text:"No",  handler:handleNo } , {text:"Cancel", handler:handleCancel} ]
  });
  addRecipientConfirmDialog.setHeader('Add All');
  addRecipientConfirmDialog.render(document.body);
  YAHOO.util.Event.addListener("addAllBtn", "click", showDialog, addRecipientConfirmDialog, true);
}

function showDialog() {
  var totalRecipients = recipientsSearchDataTable.getAttributeConfig('paginator').value.getTotalRecords();
  if (totalRecipients == 1) {
    var reci = ' recipient';
  } else {
    reci = ' recipients';
  }
  var msg = '<b>Are you sure? <br/>Click "Yes" to add ' + totalRecipients + reci + ' to the Delivery List.</b>';
  addRecipientConfirmDialog.configText("text", [msg]);
//  addRecipientConfirmDialog.setBody(msg);
  addRecipientConfirmDialog.show();
}