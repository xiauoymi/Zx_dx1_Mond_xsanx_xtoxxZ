//
//function renderCaldendar(idOfCalendar, dateToBeSelected, inputToBePopulated, btnName){
//  var fromDateElement = document.getElementById(dateToBeSelected);
//  if(fromDateElement == null){
//    var periodCalendar = new YAHOO.widget.Calendar(idOfCalendar, { title:"Choose a date:", iframe:true, close:true });
//  }else{
//    var fromDate = fromDateElement.value;
//    periodCalendar = new YAHOO.widget.Calendar(idOfCalendar, { selected:fromDate, title:"Choose a date:", iframe:true, close:true });
//  }
//  periodCalendar.render();
//
//  function handleSelect(type,args,obj) {
//    var dates = args[0];
//    var date = dates[0];
//    var year = date[0], month = date[1], day = date[2];
//
//    var period = document.getElementById(inputToBePopulated);
//    period.value = year + '-' + getDoubleDigitsForDate(month) + '-' + getDoubleDigitsForDate(day); //month + "/" + day + "/" + year;
//    periodCalendar.hide();
//  }
//
//  periodCalendar.selectEvent.subscribe(handleSelect, periodCalendar, true);
//  YAHOO.util.Event.addListener(btnName, "click", periodCalendar.show, periodCalendar, true);
//
//}

function getDoubleDigitsForDate(value){
  if(value.toString().length == 1){
    return '0' + value;
  }
  return value;
}

function createCalendar(calendarMenuId, containerId, calendarMenuBodyId, calendarId, buttonId, textInputId){
  var oCalendarMenu = new YAHOO.widget.Overlay(calendarMenuId, { visible: false });
  var oCalButton = new YAHOO.widget.Button({
                    type: "menu",
                    className:"calender-button",
                    id: buttonId,
                    label: "Choose A Date",
                    menu: oCalendarMenu,
                    container: containerId });

  oCalButton.on("appendTo", function () {
    oCalendarMenu.setBody(" ");
    oCalendarMenu.body.id = calendarMenuBodyId;
    oCalendarMenu.render(this.get("container"));

  });

function oCalButtonClick() {
	var oCalendar = new YAHOO.widget.Calendar(calendarId, oCalendarMenu.body.id);
	oCalendar.render();
	oCalendar.changePageEvent.subscribe(function () {
		window.setTimeout(function () {
			oCalendarMenu.show();
		}, 0);
	});

	oCalendar.selectEvent.subscribe(function (p_sType, p_aArgs) {
		var aDate;
		if (p_aArgs) {
			aDate = p_aArgs[0][0];
      var period = document.getElementById(textInputId);
      period.value = aDate[0] + '-' + getDoubleDigitsForDate(aDate[1]) + '-' + getDoubleDigitsForDate(aDate[2]); //month + "/" + day + "/" + year;
		}
		oCalendarMenu.hide();
	});
	this.unsubscribe("click", oCalButtonClick);
}
  oCalButton.on("click", oCalButtonClick);
}
