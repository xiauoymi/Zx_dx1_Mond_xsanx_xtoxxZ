var waitingPanel = null;

YAHOO.util.Event.addListener(window, "load", function() {
  createTabs();
  document.getElementById('addRecipientResultsDiv').style.display = "none";
  createAddRecipientDialog();
  createAddEditCommunicationDialog();
  createAddActionFromCommDialog();
  if (doesUserHaveEditRole()) {
    var commStatus = document.getElementById("status").value;
    if (commStatus.toUpperCase() === "NEW" || commStatus.toUpperCase() === "OPEN") {
      document.getElementById("addRecipientBtn").disabled = "";
    }
    if (commStatus.toUpperCase() != "NEW") {
      document.getElementById("distributionBtn").disabled = "";
    }
    if (document.getElementById("addActionItemFormBtn") != null){
      document.getElementById("addActionItemFormBtn").disabled = "";
    }
    document.getElementById("commBtn").disabled = "";
    document.getElementById("copyCommBtn").disabled = "";
    populateGeoDataLists(true);
    createAddRecipientConfirmDialog();
    createWaitingPanel();
    alertIfReadyForCompletion();
    createCalendar("calendarmenu1", "fromCalendarPlaceHolder", "calendarcontainer1", "tablecalendar1", "calendarpicker1", "commFromPeriod");
    createCalendar("calendarmenu2", "toCalendarPlaceHolder", "calendarcontainer2", "tablecalendar2", "calendarpicker2", "commToPeriod");
    createCalendar("calendarmenu3", "fromCalendarSearch", "calendarcontainer3", "tablecalendar3", "calendarpicker3", "commFromPeriodSearch");
    createCalendar("calendarmenu4", "toCalendarSearch", "calendarcontainer4", "tablecalendar4", "calendarpicker4", "commToPeriodSearch");
    createCalendar("calendarmenu5", "dueDateCalendarPlaceHolder", "calendarcontainer5", "tablecalendar5", "calendarpicker5", "commDueDate");
  }
});

function alertIfReadyForCompletion() {

  var isCommunicationReadyForCompletion = document.getElementById('isCommunicationReadyForCompletion').value;
  if (isCommunicationReadyForCompletion == "true") {
    showCloseCommunicationConfirmDialog();
  }
  var areAllRecipientsMarkedAsDone = document.getElementById('areAllRecipientsMarkedAsDone').value;
  if (areAllRecipientsMarkedAsDone == "true") {
    //    document.getElementById('markAllRecipientsBtn').disabled = true;
  }
}

function showCloseCommunicationConfirmDialog() {
  var handleYes = function() {
    document.forms.commForm.action = document.getElementById("contextPath").value +
                                     "/servlet/communication?method=setStatusToClosed";
    document.forms.commForm.submit();
  }
  var handleNo = function() {
    this.hide();
  }
  var handleCancel = function() {
    this.hide();
  }
  // Instantiate the Dialog
  var closeCommunicationConfirmDialog =
      new YAHOO.widget.SimpleDialog("closeCommunicationConfirmDialog",
      { width: "400px",
        fixedcenter: true,
        visible: false,
        draggable: false,
        close: true,
        modal: true,
        text: '<b>Each recipient is marked as Completed. <br/>Are you finished with this Communication? <br/>Click "Yes" to change the status of this Communication to "Closed".</b>',
        icon: YAHOO.widget.SimpleDialog.ICON_HELP,
        constraintoviewport: true,
        buttons: [ { text:"Yes", handler:handleYes, isDefault:true },
          { text:"No",  handler:handleNo } , {text:"Cancel", handler:handleCancel} ]
      });
  closeCommunicationConfirmDialog.setHeader('Are you sure?');
  closeCommunicationConfirmDialog.render(document.body);
  closeCommunicationConfirmDialog.show();
}

function createLockDeliveryListConfirmDialog() {
  var handleYes = function() {
    lockDeliveryListConfirmDialog.hide();
    var commStatusText = document.getElementById('commStatusText');
    commStatusText.innerHTML = 'Ready';
    var addRecipientsBtn = document.getElementById("addRecipientBtn");
    addRecipientsBtn.disabled = true;
    generateDistributionList(true);
  }
  var handleNo = function() {
    lockDeliveryListConfirmDialog.hide();
    generateDistributionList(false);
  }
  var handleCancel = function() {
    lockDeliveryListConfirmDialog.hide();
  }
  // Instantiate the Dialog
  var lockDeliveryListConfirmDialog =
      new YAHOO.widget.SimpleDialog("lockDeliveryListConfirmDialog",
      { width: "400px",
        fixedcenter: true,
        visible: false,
        draggable: false,
        close: true,
        modal: true,
        text: '<b>Are you ready to send the Communication? <br/>Click "Yes" to lock the Delivery List.</b>',
        icon: YAHOO.widget.SimpleDialog.ICON_HELP,
        constraintoviewport: true,
        buttons: [ { text:"Yes", handler:handleYes, isDefault:true },
          { text:"No",  handler:handleNo }, {text:"Cancel", handler:handleCancel} ]
      });
  lockDeliveryListConfirmDialog.setHeader('Export Delivery List');
  lockDeliveryListConfirmDialog.render(document.body);
  lockDeliveryListConfirmDialog.show();
}

function removeDeleteBtnFromSelectSaveBtns() {
  var deleteSelectedRecipientBtn = document.getElementById('deleteSelectedRecipientsBtn');
  deleteSelectedRecipientBtn.outerHTML = deleteSelectedRecipientBtn.outerHTML.replace('name=selectSaveBtn', '');
  deleteSelectedRecipientBtn.name = '';
}

function generateDistributionList(setToDistributed) {
  var action = document.getElementById("contextPath").value +
               "/data/lookupRecipientsForDistributionListXML/distribution_.xls";
  if (setToDistributed) {
    action += "?setToDistributed=Y";
  }
  document.forms.distForm.action = action;
  document.forms.distForm.submit();
}

function getDistributionList() {
  var commStatus = document.getElementById('commStatusText').innerHTML;
  if (commStatus.toUpperCase() == "OPEN") {
    createLockDeliveryListConfirmDialog();
  } else {
    generateDistributionList(false);
  }
}

function copyCommunication() {
  var contextPath = document.getElementById('contextPath').value;
  var commId = document.getElementById('commId').value;
  document.forms.commForm.action = contextPath + "/servlet/communication?method=copyCommunication&commId=" + commId;
  document.forms.commForm.submit();
}

function createWaitingPanel() {
  waitingPanel =
  new YAHOO.widget.Panel("wait",
  { width:"20em",
    height:"50px",
    fixedcenter:true,
    close:false,
    draggable:false,
    zindex:99,
    modal:true,
    visible:false
  }
      );

  waitingPanel.setHeader("Processing...Please wait...");
  var imageUrl = '<img src="' + document.getElementById('contextPath').value + '/images/wait.gif" />';
  waitingPanel.setBody(imageUrl);
  waitingPanel.render(document.body);
}

function showWaitingPanel() {
  waitingPanel.show();
}

function hideWaitingPanel() {
  waitingPanel.hide();
}
