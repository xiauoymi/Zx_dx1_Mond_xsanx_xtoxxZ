var commPlanTabView;
var recipientsTab;
var actionItemsTab;

function createTabs() {

  createElementForActionItemsInitialLoading();
  getElementForCountOfActionItems();

  commPlanTabView = new YAHOO.widget.TabView();

  recipientsTab = new YAHOO.widget.Tab({
    label: getLabelForDeliveryListTabOnCommPlan(),
    content: document.getElementById('recipientsTab').innerHTML,
    active: true
  });
  commPlanTabView.addTab(recipientsTab);  // tab index 0

  actionItemsTab = new YAHOO.widget.Tab({
    label: getLabelForActionItemsTabOnCommPlan(),
    content: document.getElementById('actionItemsTab').innerHTML,
    active: false
  });

  if (hasAccessToAction()){
    commPlanTabView.addTab(actionItemsTab);
  }

//  commPlanTabView.addTab(actionItemsTab); // tab index 1
//  var bpsTab = new YAHOO.widget.Tab({
  //  label: 'Business Partners',
  //  content: document.getElementById('bpsTab').innerHTML,
  //  active: false
  //});
  //  tabView.addTab(bpsTab);

  document.getElementById('tabs').innerHTML = '';
  commPlanTabView.appendTo('tabs');

//  if (hasAccessToAction()) {
//    createActionItemsTable();
//  }

  createRecipientsTable();

  commPlanTabView.on('activeTabChange', function(ev) {
    if((ev.newValue == actionItemsTab) && ifActionItemsAreLoadedInitially()) {
      document.getElementById("actionItemsOnCommPlanLoaded").value = false;
      createActionItemsTable();
    }
  });


}

function ifActionItemsAreLoadedInitially() {
  return document.getElementById("actionItemsOnCommPlanLoaded").value == 'true';
}

function getLabelForDeliveryListTabOnCommPlan() {
  return "Delivery List";
}

function getLabelForActionItemsTabOnCommPlan() {
  return "Action Items" ;
}

function getElementForCountOfActionItems() {
  var spanElement = document.createElement('span');
  spanElement.setAttribute("id", "countOfActionItemsOnCommPlan");
  spanElement.innerHTML = '';
  document.appendChild(spanElement);
}

function createElementForActionItemsInitialLoading() {
  var elementForActionItemsInitialLoading = document.createElement('input');
  elementForActionItemsInitialLoading.setAttribute("type", "hidden");
  elementForActionItemsInitialLoading.setAttribute("id", "actionItemsOnCommPlanLoaded");
  elementForActionItemsInitialLoading.setAttribute("value", true);
  document.appendChild(elementForActionItemsInitialLoading);
}

function setLabelForRecipientsTabOnCommPlan(oArgs) {
  if(isTabAddedToTabView(commPlanTabView, recipientsTab))
    setLabelOnTab(recipientsTab, getLabelForDeliveryListTabOnCommPlan(), oArgs);
}

function setLabelForActionItemsTabOnCommPlan(oArgs) {
  if(isTabAddedToTabView(commPlanTabView, actionItemsTab))
    setLabelOnTab(actionItemsTab, getLabelForActionItemsTabOnCommPlan(), oArgs);
}

//function createRecipientsTableForCommunication(){
//  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
//      document.getElementById('contextPath').value + "/data/communication?method=lookupRecipientsXML" +
//          "&commId=" + document.getElementById('commId').value + "&menu=" + document.getElementById('menu').value,
//      createContentsForRecipientTab);
//
//}
