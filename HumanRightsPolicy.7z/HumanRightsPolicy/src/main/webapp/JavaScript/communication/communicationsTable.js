function createCommunicationsTable(url, showSelectOperateCheckbox) {
  this.commDataSource = createServerSidePaginationDataSource(url);

  this.commDataSource.responseSchema = {
    resultNode: "communication",
    fields: ["id", "urgent", "name", "fromPeriod", "toPeriod", "dueDate", "active", "link", "commTypeValue","recipientTypeValue", "locTypeValue", "status", "viewUrl", "deactivateUrl"],
    metaFields: {totalRecords : "totalRecords"}
  };
  this.commDataTable = getCommunicationsDataTable(getColumnDefsForCommunicationsTable(showSelectOperateCheckbox), this.commDataSource);
  this.commDataTable.subscribe("dataReturnEvent", function (oArgs) {
    setLabelForCommunicationsTabOnBP(oArgs);
    setLabelForCommunicationsTabOnLocation(oArgs);
    setLabelForCommunicationsTabOnContacts(oArgs);
  });
}

function getColumnDefsForCommunicationsTable(showSelectOperateCheckbox) {
  var periodFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oRecord.getData('toPeriod') === '') {
      elCell.innerHTML = oRecord.getData('fromPeriod');
    } else {
      elCell.innerHTML = oRecord.getData('fromPeriod') + ' to ' + oRecord.getData('toPeriod');
    }
  };
  var nameFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<a href="' + oRecord.getData('viewUrl') + '">' + oRecord.getData('name') + '</a>';
  };

  var lockFormatter = function(elCell, oRecord, oColumn, oData) {
    var locked = !(oRecord.getData("status").toUpperCase() == 'NEW' ||
                   oRecord.getData("status").toUpperCase() == 'OPEN');
    setLockInTheCell(elCell, locked);
  };
  
  var urgentFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oData == "Y") {
      elCell.innerHTML = '<img border="0" alt="Urgent" src="' +
                         document.getElementById('contextPath').value +
                         '/images/imp-high.gif">';
    } else {
      elCell.innerHTML = '&nbsp;';//very important for sorting to work
    }
  };

  var attachmentFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oData != "") {
      elCell.innerHTML = '<img border="0" alt="Attachment" src="' +
                         document.getElementById('contextPath').value +
                         '/images/paperclip.gif">';
    } else {
      elCell.innerHTML = '&nbsp;';//very important for sorting to work
    }
  };

  var commTypeFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oData == "Letter") {
      elCell.innerHTML = '<img border="0" alt="Letter" src="' +
                         document.getElementById('contextPath').value +
                         '/images/icon-doc.gif">';
    } else if (oData == "Email") {
      elCell.innerHTML = '<img border="0" alt="Email" src="' +
                         document.getElementById('contextPath').value +
                         '/images/icon-mail.gif">';
    } else if (oData == "Guidebook") {
      elCell.innerHTML = '<img border="0" alt="Guidebook" src="' +
                         document.getElementById('contextPath').value +
                         '/images/icon-book.gif">';
    } else {
      elCell.innerHTML = '&nbsp;';//very important for sorting to work
    }
  };

//{key:"fromPeriod", label:"<b>Period</b>", formatter:periodFormatter, sortable:true, resizeable:true, width:100},

  var urgentImgTh = '<img border="0" alt="Urgent" src="' +
                    document.getElementById('contextPath').value +
                    '/images/view-importance.gif">';

  var commTypeImgTh = '<img border="0" alt="Communication Type" src="' +
                      document.getElementById('contextPath').value +
                      '/images/view-document.gif">';

  var attachmentImgTh = '<img border="0" alt="Attachment" src="' +
                        document.getElementById('contextPath').value +
                        '/images/view-paperclip.gif">';

  var checkbox = getCheckboxColumnDef();
  var urgent = {key:"urgent", label:urgentImgTh, formatter:urgentFormatter, width:14}
  var attachment = {key:"link", label:attachmentImgTh, formatter:attachmentFormatter, width:16}
  var name = {key:"name", label:"<b>Subject</b>", formatter:nameFormatter, sortable:true, resizeable:true};
  var date = {key:"dueDate", label:"<b>Date</b>", sortable:true, resizeable:true, width:100};
  var commType = {key:"commTypeValue", label:commTypeImgTh, formatter:commTypeFormatter, sortable:true, resizeable:true, width:20};
  var recipientType = {key:"recipientTypeValue", label:"<b>People</b>", sortable:true, resizeable:true, width:100};
  var locType = {key:"locTypeValue", label:"<b>Location</b>", sortable:true, resizeable:true, width:100};
  var status = {key:"status", label:"<b>Status</b>", sortable:true, resizeable:true, width:100};
  var locked = {label:"", formatter:lockFormatter, width:20}
  if (showSelectOperateCheckbox == undefined || !showSelectOperateCheckbox) {
    return [commType, urgent, attachment, name, date, recipientType, locType, status];
  } else {
    return [checkbox, commType, urgent, attachment, name, date, recipientType, locType, status, locked];
  }
}

function getCommunicationsDataTable(columnDefs, dataSource) {
  this.commDataTable = createServerSidePaginationTable("communicationsList", columnDefs, dataSource, "name", null, {topPaginator:'topPaginatorForCommunication'});

  setParamsForSelectOperate(this.commDataTable, 'id');

  this.commDataTable.subscribe("checkboxClickEvent", function(oArgs) {
    checkboxClickEvent(oArgs);
  });

  this.commDataTable.subscribe("rowMouseoverEvent", this.commDataTable.onEventHighlightRow);
  this.commDataTable.subscribe("rowMouseoutEvent", this.commDataTable.onEventUnhighlightRow);
//  this.commDataTable.set("selectionMode", "single");
  //  this.commDataTable.subscribe("rowClickEvent", this.commDataTable.onEventSelectRow);
  //{
  //    var oRecord = this.getRecord(args.target);
  //    document.location.href = oRecord.getData("viewUrl");
  //  });

  return this.commDataTable;
}

function deleteSelectedCommClick() {
  var url = document.getElementById("contextPath").value +
            "/servlet/communication?method=deactivateSelectedCommunications";
  var filterValue = "&filterValue=" + encodeURIComponent(document.getElementById("filterValue").value);

  url += filterValue + getQueryStringForSelectSave();
  document.forms.commListForm.action = url;
  document.forms.commListForm.submit();
}