var markAsCompleteConfirmDialog = null;

function createAddEditCommunicationDialog() {
  var handleSubmit = function() {
    if (this.validate()) {
      var url = document.getElementById("editOrAddCommUrl").value
      var editOrAddCommAsynchronously = document.getElementById("editOrAddCommAsynchronously");
      if (editOrAddCommAsynchronously != null && editOrAddCommAsynchronously.value == "true") {
        url += getCommParameters();
        addOrEditCommAsynchronously(url);
      } else {
        this.form.action = url;
        this.form.submit();
      }
      this.form.reset();
      this.hide();
    }
  };

  var handleCancel = function() {
    this.form.reset();
    this.cancel();
  };

//  var commId = document.getElementById('commId').value;
//  var buttons;
//  if (commId == null || commId == '') {
//    buttons = [ { text:"Continue", handler:handleSubmit, isDefault:true }, { text:"Cancel", handler:handleCancel } ]
//  } else {
//    buttons = [ { text:"Save", handler:handleSubmit, isDefault:true }, { text:"Cancel", handler:handleCancel } ]
//  }

  var editCommDialog = new YAHOO.widget.Dialog("editCommDialog",
  { width : "50em",
    close:true,
    visible:false,
    x: getXForDialog(),
    y: getYForDialog()
  });

  editCommDialog.validate = function() {
    var data = this.getData();
    var commTypeId = document.getElementById("commTypeId").selectedIndex;
    if (data.commName.trim() === "") {
      alert("Please enter name.");
      return false;
    } else if (commTypeId === 0) {
      alert("Please select communication type.");
      return false;
    } else if (data.commUrlTitle === "" && data.commUrl !== "") {
      alert("Please enter a title for the url.");
      return false;
    } else if (data.commUrlTitle !== "" && data.commUrl === "") {
      alert("Please enter a url.");
      return false;
    } else if (data.commFromPeriod !== "" && data.commToPeriod !== "" &&
               after(data.commFromPeriod, data.commToPeriod)) {
      alert("From date should be earlier than To date.");
      return false;
    } else {
      return true;
    }
  };


  addKeyListeners(editCommDialog);
//  var enterKeyListener;
//  editCommDialog.beforeShowEvent.subscribe(function (){
//        enterKeyListener = new YAHOO.util.KeyListener(document, { keys:13 },
//                                                   { fn:handleSubmit,
//                                                     scope:editCommDialog,
//                                                     correctScope:true } );
//
//    enterKeyListener.enable();
//  });
//  editCommDialog.beforeHideEvent.subscribe(function (){
//    enterKeyListener.disable();
//  });
  editCommDialog.render();

  YAHOO.util.Event.addListener("commBtn", "click", editCommDialog.show, editCommDialog, true);
  YAHOO.util.Event.addListener("saveCommBtn", "click", handleSubmit, editCommDialog, true);
  YAHOO.util.Event.addListener("cancelCommBtn", "click", handleCancel, editCommDialog, true);
}

function markSelectedAsCompleteClick(doneFlagValue) {
  showWaitingPanel();
  var commId = document.getElementById('commId').value;
  var filterValue = "&filterValue=" + encodeURIComponent(document.getElementById("filterValue").value);
  var doneFlag = "&doneFlag=" + doneFlagValue;
  document.forms.recipientForm.action = document.getElementById("contextPath").value +
                                        "/servlet/commRecipient?method=updateDoneFlagForSelectedRecipients&commId=" +
                                        commId + doneFlag + filterValue + getQueryStringForSelectSave();
  document.forms.recipientForm.submit();
}


function deleteSelectedRecipientsClick() {
  showWaitingPanel();
  var commId = document.getElementById('commId').value;
  var filterValue = "&filterValue=" + encodeURIComponent(document.getElementById("filterValue").value);
  document.forms.recipientForm.action = document.getElementById("contextPath").value +
                                        "/servlet/commRecipient?method=deleteSelectedRecipients&commId=" +
                                        commId + filterValue + getQueryStringForSelectSave();
  document.forms.recipientForm.submit();
}

function getCommParameters() {
  var commName = document.getElementById("commName").value;
  var notes = document.getElementById("commNotes").value;
  var fromDate = document.getElementById("fromDate").value;
  var toDate = document.getElementById("toDate").value;
  var dueDate = document.getElementById("commDueDate").value;
  var urlTitle = document.getElementById("commUrlTitle").value;
  var url = document.getElementById("commUrl").value;
  var commStatusId = document.getElementById("commStatusId").value;
  var commTypeId = document.getElementById("commTypeId").value;
  var commLocType = document.getElementById("commLocTypeId");
  var commLocTypeId = commLocType.options[commLocType.selectedIndex].value;
  var commPeopleType = document.getElementById("commPeopleTypeId");
  var commPeopleTypeId = commPeopleType.options[commPeopleType.selectedIndex].value;
  var active = "Y";

  return "&commName=" + commName +
         "&commNotes=" + notes +
         "&commFromPeriod=" + fromDate +
         "&commToPeriod=" + toDate +
         "&commDueDate=" + dueDate +
         "&commUrlTitle=" + urlTitle +
         "&commUrl=" + url +
         "&commStatusId=" + commStatusId +
         "&commTypeId=" + commTypeId +
         "&commPeopleTypeId=" + commPeopleTypeId +
         "&commLocTypeId=" + commLocTypeId +
         "&active=" + active;
}

function addOrEditCommAsynchronously(url) {
  var callBackAfterAddingCommunication = {
    success: function(o) {
      this.cache = null;
      populateCommunicationsTable();
    },
    failure: function(o) {
    },
    timeout: 20000 //20 seconds
  };

  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      url,
      callBackAfterAddingCommunication);
}
