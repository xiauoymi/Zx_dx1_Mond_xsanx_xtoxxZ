YAHOO.util.Event.addListener(window, "load", function() {
  var scope = document.getElementById("scope").value;

  if (scope == "My") {
    if (doesUserHaveEditRole()) {
      document.getElementById("commBtn").disabled = "";
    }
    createAddEditCommunicationDialog();
    populateCommunicationsTable();
    createCalendar("calendarmenu1", "fromCalendarPlaceHolder", "calendarcontainer1", "tablecalendar1", "calendarpicker1", "commFromPeriod");
    createCalendar("calendarmenu2", "toCalendarPlaceHolder", "calendarcontainer2", "tablecalendar2", "calendarpicker2", "commToPeriod");
    createCalendar("calendarmenu5", "dueDateCalendarPlaceHolder", "calendarcontainer5", "tablecalendar5", "calendarpicker5", "commDueDate");
  } else {
    populateGeoDataLists(true);
    document.getElementById('filterAndPageLinksTable').style.display = "none";
    createCalendar("calendarmenu6", "dueDateFromCalendarPlaceHolder", "calendarcontainer6", "tablecalendar6", "calendarpicker6", "dueDateFrom");
    createCalendar("calendarmenu7", "dueDateToCalendarPlaceHolder", "calendarcontainer7", "tablecalendar7", "calendarpicker7", "dueDateTo");
  }
});

function getCommunicationsXmlUrl() {
  var url = document.getElementById('contextPath').value + "/data/communicationXml" +
            "?menu=" + document.getElementById('menu').value;
  url += "&filterValue=" + encodeURIComponent(document.getElementById("filterValue").value);
  return url;
}

function createFilteredCommTable() {
  clearSelectOperateSelections();
  var filterValue = document.getElementById("filterValue").value;
  createCommunicationsTable(getCommunicationsXmlUrl() + "&filterValue=" + encodeURIComponent(filterValue), true);
}

function clearFilterAndCreateCommTable() {
  clearSelectOperateSelections();
  document.getElementById("filterValue").value = "";
  createCommunicationsTable(getCommunicationsXmlUrl(), true);
}

function populateCommunicationsTable() {
  createCommunicationsTable(getCommunicationsXmlUrl(), true);
}

function searchComms() {
  var dueDateFrom = document.getElementById('dueDateFrom').value;
  var dueDateTo = document.getElementById('dueDateTo').value;
  if (dueDateFrom !== "" && dueDateTo !== "" && after(dueDateFrom, dueDateTo)) {
    alert("From date should be earlier than To date.");
  } else {
    document.getElementById('filterAndPageLinksTable').style.display = "";
    var url = document.getElementById('contextPath').value + "/data/communicationXml" +
              "?menu=" + document.getElementById('menu').value;
    url += "&commName=" + document.getElementById("commName").value;
    url += "&commTypeId=" + document.getElementById("commTypeId").value;
    url += "&commStatusId=" + document.getElementById("commStatusId").value;
    url += "&commPeopleTypeId=" + document.getElementById("commPeopleTypeId").value;
    url += "&commLocTypeId=" + document.getElementById("commLocTypeId").value;
    url += "&dueDateFrom=" + document.getElementById("dueDateFrom").value;
    url += "&dueDateTo=" + document.getElementById("dueDateTo").value;
    url += "&state=" + document.getElementById("state").value;
    url += "&country=" + document.getElementById("country").value;
    url += "&region=" + document.getElementById("region").value;

    createCommunicationsTable(url, false);
  }
}

function clearCommSearch() {
  document.location = document.getElementById('contextPath').value + "/servlet/communication?method=allComms";
}

function searchCommsOnEnter(e) {
  var characterCode = e.keyCode
  var searchComms = document.getElementById('Search');
  if (characterCode == 13) {
    searchComms.click();
    return false;
  }
  else {
    return true;
  }
}