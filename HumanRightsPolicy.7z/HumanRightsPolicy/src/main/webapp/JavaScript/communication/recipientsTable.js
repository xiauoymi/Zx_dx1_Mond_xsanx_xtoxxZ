var recipientDataTable = null;
var key = 'recipientId';

var createContentsForRecipientTab = {
  success: function(o) {
    createRecipientsTable(o);
  },
  failure: function(o) {
  },
  timeout: 20000 //20 seconds
};

function clearFilterAndRefreshRecipientsTable() {
  document.getElementById("filterValue").value = "";
  clearSelectOperateSelections();
  createRecipientsTable();
}

function callBackAfterDeleteRecipient(o) {
  var xmlDoc = o.responseXML;
  document.getElementById('isCommunicationReadyForCompletion').value = xmlDoc.getElementsByTagName('isCommunicationReadyForCompletion')[0].text;
  document.getElementById('areAllRecipientsMarkedAsDone').value = xmlDoc.getElementsByTagName('areAllRecipientsMarkedAsDone')[0].text;
  document.getElementById('commStatusText').innerHTML = xmlDoc.getElementsByTagName('commStatus')[0].text;

  if (xmlDoc.getElementsByTagName('commStatus')[0].text.toUpperCase() == 'NEW') {
    document.getElementById('distributionBtn').disabled = true;
  }

  createRecipientsTable();
  alertIfReadyForCompletion();
}

function createFilteredRecipientsTable() {
  clearSelectOperateSelections();
  createRecipientsTable();
}

function createRecipientsTable() {

  var url = document.getElementById('contextPath').value + "/data/recipientXml" +
            "?commId=" + document.getElementById('commId').value + "&menu=" + document.getElementById('menu').value;
  url += "&filterValue=" + encodeURIComponent(document.getElementById("filterValue").value);


  this.recipientDataSource = createServerSidePaginationDataSource(url);

  this.recipientDataSource.responseSchema = {
    resultNode: "recipient",
    fields: ["recipientId", "commId", "isDone", "hasContactsPrimaryRelationshipEnded", "name", "recipientTypeValue", "company", "state", "country", "region", "viewUrl", "updateDoneFlagUrl", "removeUrl"],
    metaFields: {totalRecords : "totalRecords"}
  };
  this.recipientDataTable = getRecipientsDataTable(getColumnDefsForRecipientsTable(), this.recipientDataSource);
  this.recipientDataTable.subscribe("dataReturnEvent", function (oArgs) {
    setLabelForRecipientsTabOnCommPlan(oArgs) ;
  });
}

function getRecipientsDataTable(columnDefs, dataSource) {
  var recipientDataTable = createServerSidePaginationTable("recipientsList", columnDefs, dataSource, "name", null, {topPaginator:'topPaginatorForRecipients'});

  setParamsForSelectOperate(recipientDataTable, 'recipientId');
  
  recipientDataTable.subscribe("rowMouseoverEvent", recipientDataTable.onEventHighlightRow);
  recipientDataTable.subscribe("rowMouseoutEvent", recipientDataTable.onEventUnhighlightRow);
  recipientDataTable.set("selectionMode", "single");

  recipientDataTable.subscribe("checkboxClickEvent", function(oArgs) {
    checkboxClickEvent(oArgs);
  });

  recipientDataTable.subscribe("cellClickEvent", function(oArgs) {
    var oTarget = oArgs.target;
    var oRecord = recipientDataTable.getRecord(oTarget);
    var oColumn = recipientDataTable.getColumn(oTarget);
    if (oColumn.key == "isDone") {
      recipientDataTable.unsubscribe("rowClickEvent");
      var isDone = oRecord.getData("isDone");
      if (isDone == "Y" || isDone == "y") {
        updateCompleteFlag(recipientDataTable, oRecord, oTarget, 'N');
      } else {
        updateCompleteFlag(recipientDataTable, oRecord, oTarget, 'Y');
      }
    }
  });

  return recipientDataTable;
}

//function subscribeRowClickEvent(recipientDataTable) {
//  recipientDataTable.subscribe("rowClickEvent", function(oArgs) {
//    var oRecord = recipientDataTable.getRecord(oArgs.target);
//    document.location.href = oRecord.getData("viewUrl");
//  });
//}

function updateCompleteFlag(recipientDataTable, oRecord, oTarget, flag) {
  var updateDoneFlagUrl = oRecord.getData("updateDoneFlagUrl");
  updateDoneFlagUrl += "&doneFlag=" + flag;

  var callBackAfterUpdatingDoneFlag = {
    success: function(o) {
      this.cache = null;
      var xmlDoc = o.responseXML;

      document.getElementById('isCommunicationReadyForCompletion').value = xmlDoc.getElementsByTagName('isCommunicationReadyForCompletion')[0].text;
      document.getElementById('areAllRecipientsMarkedAsDone').value = xmlDoc.getElementsByTagName('areAllRecipientsMarkedAsDone')[0].text;
//      var isCommunicationReadyForCompletion = xmlDoc.getElementsByTagName('isCommunicationReadyForCompletion')[0].text;
      //      if (isCommunicationReadyForCompletion == "true") {
      //        showCloseCommunicationConfirmDialog();
      //      }
      //      var areAllRecipientsMarkedAsDone = xmlDoc.getElementsByTagName('areAllRecipientsMarkedAsDone')[0].text;
      //      var areAllRecipientsMarkedAsDoneElement = document.getElementById('areAllRecipientsMarkedAsDone');
      //      areAllRecipientsMarkedAsDoneElement.value = areAllRecipientsMarkedAsDone;
//      var checkAllBtn = document.getElementById('markAllRecipientsBtn');
//      checkAllBtn.disabled = xmlDoc.getElementsByTagName('areAllRecipientsMarkedAsDone')[0].text == 'true';

      var innerHTMLOftheCell = oTarget.innerHTML;
      if (flag == "Y") {
        innerHTMLOftheCell = innerHTMLOftheCell.replace('incomplete.gif', 'completed.gif');
        oRecord.setData("isDone", "Y");
      } else {
        innerHTMLOftheCell = innerHTMLOftheCell.replace('completed.gif', 'incomplete.gif');
        oRecord.setData("isDone", "N");
      }
      oTarget.innerHTML = innerHTMLOftheCell;

      alertIfReadyForCompletion();

    },
    failure: function(o) {
    },
    timeout: 20000 //20 seconds
  };

  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      updateDoneFlagUrl,
      callBackAfterUpdatingDoneFlag);
}

function getColumnDefsForRecipientsTable() {

  var nameFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oRecord.getData('hasContactsPrimaryRelationshipEnded') == "N") {
      elCell.innerHTML = '<a href="' + oRecord.getData('viewUrl') + '">' + oRecord.getData('name') + '</a>';
    } else {
      elCell.innerHTML = oRecord.getData('name');
    }
  };

  var lockFormatter = function(elCell, oRecord, oColumn, oData) {
    setLockInTheCell(elCell, true);
  };

  var checkBox = getCheckboxColumnDef();
  var doneIcon = {key:"isDone", label:"", formatter:setAddOrRemoveIcon, resizeable:true, width:20};
  var name = {key:"name", label:"<b>Name</b>", formatter:nameFormatter, sortable:true, resizeable:true};
  var recipientType = {key:"recipientTypeValue", label:"<b>Type</b>", sortable:true, resizeable:true, width:100};
  var company = {key:"company", label:"<b>Company</b>", sortable:true, resizeable:true};
  var state = {key:"state", label:"<b>State/Province</b>", sortable:true, resizeable:true, width:110};
  var country = {key:"country", label:"<b>Country</b>", sortable:true, resizeable:true, width:110};
  var region = {key:"region", label:"<b>World Area</b>", sortable:true, resizeable:true, width:110};
  var deleteIcon = {label:"", width:20};
//  var deleteIcon = {label:"", formatter:removeOrLockedFormatter, width:40};
  var padlockIcon = {label:"", formatter:lockFormatter, width:20};
  var commStatus = document.getElementById("status").value;
  if (commStatus.toUpperCase() == 'NEW' || commStatus.toUpperCase() == 'OPEN') {
    return [checkBox, doneIcon, name, recipientType, company, state, country, deleteIcon];
  } else {
    return [checkBox, doneIcon, name, recipientType, company, state, country, padlockIcon];
  }
}

function setAddOrRemoveIcon(elCell, oRecord, oColumn, oData) {
  if (oData == "Y" || oData == "y") {
    elCell.innerHTML = '<img border="0" class="clickableImg" src="' + document.getElementById('contextPath').value +
                       '/images/completed.gif">';
  } else {
    elCell.innerHTML = '<img border="0" class="clickableImg" src="' + document.getElementById('contextPath').value +
                       '/images/incomplete.gif">';
  }
}

