function createAddEditContactDialog() {
  var handleSubmit = function() {
    if (this.validate()) {
      saveChanges();
      this.hide();
      resetFormIfIdIsNull(this.form, 'thisContactId');
    }
  };
  var handleCancel = function() {
    resetFormIfIdIsNull(this.form, 'thisContactId');
    this.cancel();
  };

    // Instantiate the Dialog
  var editContactsDialog = new YAHOO.widget.Dialog("editContactsDialog",
  { width : "50em",
    visible : false,
    x: getXForDialog(),
    y:getYForDialog()
 //   buttons : [ { text:"Save", handler:handleSubmit, isDefault:true }, { text:"Cancel", handler:handleCancel } ]
  });

       // Validate the entries in the form to require that both first and last name are entered
  editContactsDialog.validate = function() {
    var data = this.getData();
    if (data.name.trim()  === "" || data.name === null) {
      alert("Contact name must be provided");
      return false;
    }else if (data.locConRelTypeId === "" || data.locConRelTypeId === null) {
      alert("Contact type must be provided");
      return false;
    }
    else {
      return true;
    }
  };
//
  addKeyListeners(editContactsDialog);
  editContactsDialog.render();

  YAHOO.util.Event.addListener("addEditContactBtn", "click", editContactsDialog.show, editContactsDialog, true);
  YAHOO.util.Event.addListener("saveContactBtn", "click", handleSubmit, editContactsDialog, true);
//  YAHOO.util.Event.addListener("saveContactBtn", "click", editContactsDialog.hide, editContactsDialog, true);
  YAHOO.util.Event.addListener("cancelContactBtn", "click", handleCancel, editContactsDialog, true);
}
function getContactParameters (){
  var name = document.getElementById('name').value;
  var title = document.getElementById('title').value;
  var workPhone = document.getElementById('workPhone').value;
  var mobilePhone = document.getElementById('mobilePhone').value;
  var fax = document.getElementById('fax').value;
  var email = document.getElementById('email').value;
  var parameters;
  parameters = "&name=" + name;
  parameters += "&title=" + title;
  parameters += "&workPhone=" + workPhone;
  parameters += "&mobilePhone=" + mobilePhone;
  parameters += "&fax=" + fax;
  parameters += "&email=" + email;
  return parameters;
}

function saveChanges()
{
  var contactId = document.getElementById('thisContactId').value;
  var locationId = document.getElementById("locationId").value;
  var parameters;
  parameters = getContactParameters();
  var method;
  var url;
  var operation;
  var parentPage = document.getElementById("parentPage").value;
  var businessPartnerId = document.getElementById("businessPartnerId").value;
  if (contactId == "") {
    method = "saveContactToLocation";
    url = document.getElementById('contextPath').value + "/servlet/location?method=" + method + "&locationId=" +
          locationId + parameters + "&locConRelTypeId=" + document.getElementById('locConRelTypeId').value;
    if (parentPage == "businessPartner"){
     url += "&businessPartnerId=" + businessPartnerId;
    }else{
      url += "&locationId=" + locationId;
    }
    operation = "add";
    document.editContacts.action = url;
    document.editContacts.submit();
  }else {
    method = "updateContact";
    url = document.getElementById('contextPath').value + "/data/contacts?method=" + method + "&contactId=" + contactId + parameters;
    operation = "edit";
    var callBackAfterAddingContact = {
      success: function(o) {
        this.cache = null;
        if (operation == "add"){
          if (parentPage == "businessPartner"){
            populateContactsTableForBP();
          }else{
            populateContactsTableForLocation();
          }
        }else {
          populateContactInformation(o);
        }
      },
    failure: function(o) {
    },
    timeout: 20000 //20 seconds
  };

    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
    url,
    callBackAfterAddingContact);
  }
}

function populateContactInformation(o){
  var xmlDoc = o.responseXML;
  document.getElementById('nameEdit').innerHTML = xmlDoc.getElementsByTagName('contactName')[0].text;
  document.getElementById('titleEdit').innerHTML = xmlDoc.getElementsByTagName('title')[0].text;
  document.getElementById('workPhoneEdit').innerHTML = xmlDoc.getElementsByTagName('workPhone')[0].text;
  document.getElementById('mobilePhoneEdit').innerHTML = xmlDoc.getElementsByTagName('mobilePhone')[0].text;
  document.getElementById('faxEdit').innerHTML = xmlDoc.getElementsByTagName('fax')[0].text;
  document.getElementById('emailEdit').innerHTML = xmlDoc.getElementsByTagName('email')[0].text;
}
