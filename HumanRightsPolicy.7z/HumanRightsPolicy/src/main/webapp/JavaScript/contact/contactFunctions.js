YAHOO.util.Event.addListener(window, "load", function() {
  createContactTabs();
  createAddEditContactDialog();
  createAddEditCommunicationDialog();
  createCalendar("calendarmenu1", "fromCalendarPlaceHolder", "calendarcontainer1", "tablecalendar1", "calendarpicker1", "commFromPeriod");
  createCalendar("calendarmenu2", "toCalendarPlaceHolder", "calendarcontainer2", "tablecalendar2", "calendarpicker2", "commToPeriod");
  createCalendar("calendarmenu5", "dueDateCalendarPlaceHolder", "calendarcontainer5", "tablecalendar5", "calendarpicker5", "commDueDate");

  if (doesUserHaveEditRole()) {
    document.getElementById("commBtn").disabled = "";
    if(!isContactSap()){
      document.getElementById("addEditContactBtn").disabled = "";
    }
  }
});

function isContactSap() {
  var isSap = document.getElementById("isSap").value;
  return isSap === "true";
}
