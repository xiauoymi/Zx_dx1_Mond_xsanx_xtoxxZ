var contactTabView;
var locationsTab;
var bpsTab;
var commsTab;

function createContactTabs() {

  contactTabView = new YAHOO.widget.TabView();

    locationsTab = new YAHOO.widget.Tab({
//        label: 'Locations',
        label: getLabelForLocationsTabOnContacts(),
        content: document.getElementById('locationsTab').innerHTML,
        active: false
    });

  if (hasAccessToLocation()){
    contactTabView.addTab(locationsTab);
  }


//    bpsTab = new YAHOO.widget.Tab({
//        label: getLabelForBPTabOnContacts(),
//        content: document.getElementById('bpsTab').innerHTML,
//        active: false
//    });
  //contactTabView.addTab(bpsTab);

    commsTab = new YAHOO.widget.Tab({
        label: getLabelForCommunicationsTabOnContacts(),
        content: document.getElementById('commsTab').innerHTML,
        active: false
    });

  if (hasAccessToCommunication()){
    contactTabView.addTab(commsTab);
  }

  document.getElementById('tabs').innerHTML = '';
  if (contactTabView.get("tabs").length > 0) {
    contactTabView.appendTo('tabs');
    contactTabView.set("activeIndex", getActiveTabIndex());
  }

  if (hasAccessToLocation()) {
    populateLocationsTable();
  }
  if (hasAccessToCommunication()) {
    populateCommunicationsTable();
  }

  contactTabView.on('activeTabChange', function(ev) {
  clearSelectionsIfActiveTabDifferentFromLastActiveTab(contactTabView);
  if (ev.newValue == bpsTab) {
            this.getXML = YAHOO.util.Connect.asyncRequest("GET",
                    document.getElementById('contextPath').value + "/data/bpContactRel?method=lookupBpConRelsForContactXML" +
                    "&contactId=" + document.getElementById('contactId').value + "&menu=" +
                    document.getElementById('menu').value,
                    createContentsForBPsTab);
        }
        else if (ev.newValue == locationsTab) {
            populateLocationsTable();
        }
        else if (ev.newValue == commsTab) {
            populateCommunicationsTable();
        }
    });


}

function getLabelForLocationsTabOnContacts(){
  return "Locations";
}

function getLabelForBPTabOnContacts(){
  return "Business Partners";
}

function getLabelForCommunicationsTabOnContacts(){
  return "Communication Plans";
}

function setLabelForLocationsTabOnContacts(oArgs) {
  if(isTabAddedToTabView(contactTabView, locationsTab))
    setLabelOnTab(locationsTab, getLabelForLocationsTabOnContacts(), oArgs);
}

function setLabelForBPTabOnContacts(oArgs) {
  if(isTabAddedToTabView(contactTabView, bpsTab))
    setLabelOnTab(bpsTab, getLabelForBPTabOnContacts(), oArgs);
}

function setLabelForCommunicationsTabOnContacts(oArgs) {
  if(isTabAddedToTabView(contactTabView, commsTab))
    setLabelOnTab(commsTab, getLabelForCommunicationsTabOnContacts(), oArgs);
}

function populateLocationsTable() {
    var url = document.getElementById('contextPath').value + "/data/contactLocationXml?contactId=" +
              document.getElementById("contactId").value +
              "&menu=" + document.getElementById('menu').value;
    createLocationsTable(url);
}

function populateCommunicationsTable() {
    var url = document.getElementById('contextPath').value + "/data/communicationXmlForContact" +
              "?menu=" + document.getElementById('menu').value +
              "&contactId=" + document.getElementById('contactId').value;
    createCommunicationsTable(url);
}