var createContentsForContactsTab = {
    success: function(o) {
        createContactsTable(o);
    },
    failure: function(o) {
    },
    timeout: 20000 //20 seconds
};

function createContactsTable(url) {

    this.contactsDataSource = createServerSidePaginationDataSource(url);

    this.contactsDataSource.responseSchema = {
        resultNode: "contact",
        fields: ["contactId", {key: "isPrimary", parser:this.primaryFlagParser}, "name",
            "state", "country", "region", "isSap", "removeUrl", "viewUrl", "updatePrimaryFlagUrl"],
        metaFields: {totalRecords : "totalRecords"}
    };

    this.contactsDataTable = getContactsTable(getContactColumnDefs(), this.contactsDataSource);
  this.contactsDataTable.subscribe("dataReturnEvent", function (oArgs) {
    setLabelForContactsTabOnBP(oArgs);
    setLabelForContactsTabOnLocation(oArgs);
  });
}

function getContactsTable(contactColumnDefs, dataSource) {
  var contactsDataTable = createServerSidePaginationTable("contactsList", contactColumnDefs, dataSource, "name", null, {topPaginator:'topPaginatorForContact'});

  setParamsForSelectOperate(contactsDataTable, 'contactId', doesUserHaveEditRole());

  contactsDataTable.subscribe("checkboxClickEvent", function(oArgs) {
    checkboxClickEvent(oArgs);
  });

  contactsDataTable.subscribe("rowMouseoverEvent", contactsDataTable.onEventHighlightRow);
  contactsDataTable.subscribe("rowMouseoutEvent", contactsDataTable.onEventUnhighlightRow);

  contactsDataTable.subscribe("radioClickEvent", function(oArgs) {
    var elRadio = oArgs.target;
    elRadio.style.backgroundColor = "#854225";
    /*Red*/
    disableAllRadioBtns(contactsDataTable, true);
    var elRecord = this.getRecord(elRadio);
    var updatePrimaryFlagUrl = elRecord.getData("updatePrimaryFlagUrl");

    var callBackAfterUpdatingPrimaryFlag = {
      success: function(o) {
        this.cache = null;
        disableAllRadioBtns(contactsDataTable, false);
        elRadio.style.backgroundColor = "";
      },
      failure: function(o) {
      },
      timeout: 20000 //20 seconds
    };

    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
        updatePrimaryFlagUrl,
        callBackAfterUpdatingPrimaryFlag);
  });

  return contactsDataTable;
}

function primaryRadioFormatter(el, oRecord, oColumn, oData) {
    var contactPrimaryFlagDisabled = document.getElementById("contactPrimaryFlagDisabled");
    if (contactPrimaryFlagDisabled !== null && contactPrimaryFlagDisabled == "true") {
        contactPrimaryFlagDisabled = true;
    }
    var bChecked = oData;
    bChecked = (bChecked) ? " checked" : "";
    var innerHTMLForRadio = "<input type=\"radio\"" + bChecked +
                            " name=\"" + oColumn.getKey() + "-radio\"";
    if (contactPrimaryFlagDisabled) {
        innerHTMLForRadio += " disabled ";
    }
    innerHTMLForRadio += " class=\"" + YAHOO.widget.DataTable.CLASS_RADIO + "\">";
    el.innerHTML = innerHTMLForRadio;
}

function contactNameFormatter(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<a href="' + oRecord.getData('viewUrl') + '">' + oData + '</a>';
}

function getContactColumnDefs() {
    var lockFormatter = function(elCell, oRecord, oColumn, oData) {
        var locked = oRecord.getData("isSap") == 'Y';
        setLockInTheCell(elCell, locked);
    };

    var checkbox = getCheckboxColumnDef();
    var contactColumnDefs = [
        checkbox,
        {key:"isPrimary", label:"", formatter:primaryRadioFormatter, width:20},
        {key:"name", label:"<b>Name</b>", formatter:contactNameFormatter, sortable:true, resizeable:true},
        {key:"state", label:"<b>State/Province</b>", sortable:true, resizeable:true, width:120},
        {key:"country", label:"<b>Country</b>", sortable:true, resizeable:true, width:120},
        {key:"region", label:"<b>World Area</b>", sortable:true, resizeable:true, width:120},
        {label:"", formatter:lockFormatter, width:20}
    ];

    return contactColumnDefs;
}
