YAHOO.util.Event.addListener(window, "load", function() {
  populatePivotTable();
});

function populatePivotTable() {
  var callBackAfterAddingContact = {
    success: function(o) {
      this.cache = null;
      var pivotDiv = document.getElementById("pivotDiv");
      pivotDiv.innerHTML = o.responseText;
    },
    failure: function(o) {
    },
    timeout: 60000 //60 seconds
  };

  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      document.getElementById('contextPath').value + "/data/pivotdata",
      callBackAfterAddingContact);
}

function printBpCount(){
  var pw = window.open("about:blank", "_new");
  pw.document.open("text/html");  
  var contextPath = document.getElementById('contextPath').value;
  var content = '<html><head>';
  content += '<link type="text/css" rel="stylesheet" href="' + contextPath + '/Stylesheet/hrp.css"/>';
  content += '<link type="text/css" rel="stylesheet" href="' + contextPath + '/Stylesheet/pivotdata.css"/>';
  content += '</head>';
  content += '<body style="margin:25px">';
  content += '<h4>Business Partners</h4>';
  content += document.getElementById("pivotDiv").outerHTML;
  content += '</body></html>';
  pw.document.write(content);
  pw.print();
  pw.document.close();
}
