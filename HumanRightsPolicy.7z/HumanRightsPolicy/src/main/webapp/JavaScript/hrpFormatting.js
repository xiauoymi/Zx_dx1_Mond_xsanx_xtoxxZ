function formatPage() {
  var x = YAHOO.util.Dom.getViewportWidth();
  var y = YAHOO.util.Dom.getViewportHeight();
  var leftNavSize = 225;
  var headerSize = 65;
  var footerSize = 20;
  var verticalPadding = 22;
  var horizontalPadding = 23;

  x = x -leftNavSize - horizontalPadding ;
  y = y - headerSize - footerSize - verticalPadding;

  YAHOO.util.Dom.setStyle("footer", "display", "inline");
  if (x > 0) {
    YAHOO.util.Dom.setStyle("pageDiv", "width", x);
  }

  if (y > 0) {
    YAHOO.util.Dom.setStyle("pageDiv", "height", y);
  }
}

function initFormat() {
  formatPage();
  YAHOO.util.Event.addListener(window, "resize", formatPage);
}

YAHOO.util.Event.onDOMReady(initFormat);  