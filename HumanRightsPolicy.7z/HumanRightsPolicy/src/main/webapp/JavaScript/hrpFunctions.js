function showDetails() {
    document.getElementById('showDetailsButton').style.display = 'none';
    document.getElementById('hideDetailsButton').style.display = '';
    document.getElementById('moreDetails').style.display = '';
}

function hideDetails() {
    document.getElementById('hideDetailsButton').style.display = 'none';
    document.getElementById('showDetailsButton').style.display = '';
    document.getElementById('moreDetails').style.display = 'none';
}

function getConfiguration(xmlDoc, tagName) {
    var dropdownOptionsValue = [20, 40, 60];
    var rowsPerPageValue = 20;
    var elements = xmlDoc.getElementsByTagName(tagName);
    if (elements.length > 200) {
        rowsPerPageValue = Math.floor(elements.length / 10);  //where 10 is the max number of pages
        rowsPerPageValue = rowsPerPageValue + (10 - (rowsPerPageValue % 10));  //multiple of 10
        dropdownOptionsValue = [rowsPerPageValue, rowsPerPageValue * 1.5, rowsPerPageValue * 2];
    }
  // Configure pagination features
    return {
        paginated:false, // Enables built-in client-side pagination
        paginator:{ // Configurable options
            containers: null, // Create container DIVs dynamically
            currentPage: 1, // Show page 1
            dropdownOptions: dropdownOptionsValue , // Show these in the rows-per-page dropdown
            pageLinks: 0, // Show links to all pages
            rowsPerPage: rowsPerPageValue // Show up to 20 rows per page
        }
    };
}
function after(startDate, endDate) {
    return Date.parse(formatDateAsMMDDYYYY(startDate)) >= Date.parse(formatDateAsMMDDYYYY(endDate));
}

function formatDateAsMMDDYYYY(yyyymmddDate) {
    var temp = yyyymmddDate.split('-');
    return temp[1] + '/' + temp[2] + '/' + temp[0];
}

function getXForDialog() {
    return (document.body.clientWidth * 0.30);
}

function getYForDialog() {
    return (document.body.clientHeight * 0.30);
}

function primaryFlagParser(oData) {
    return oData == "Y";
}

function populateAddres(o) {
    var xmlDoc = o.responseXML;
    document.getElementById('locNameEdit').innerHTML = xmlDoc.getElementsByTagName('locName')[0].text;
    document.getElementById('relTypeEdit').innerHTML = xmlDoc.getElementsByTagName('relType')[0].text;
    var address = xmlDoc.getElementsByTagName('address')[0];
    if (address != null) {
        document.getElementById('streetAddress1Edit').innerHTML = address.getElementsByTagName('streetAddress1')[0].text;
        document.getElementById('streetAddress2Edit').innerHTML = address.getElementsByTagName('streetAddress2')[0].text;
        document.getElementById('cityEdit').innerHTML = address.getElementsByTagName('city')[0].text;
        document.getElementById('stateValueEdit').innerHTML = address.getElementsByTagName('state')[0].text;
        document.getElementById('countryValueEdit').innerHTML = address.getElementsByTagName('country')[0].text;
        document.getElementById('regionValueEdit').innerHTML = address.getElementsByTagName('region')[0].text;
        document.getElementById('zipEdit').innerHTML = address.getElementsByTagName('zip')[0].text;
    }
}

function disableAllRadioBtns(dt, boolValue) {
    var allRadioBtns = dt.getElementsByClassName('yui-dt-radio');
    for (var k = 0; k < allRadioBtns.length; k++) {
        allRadioBtns[k].disabled = boolValue;
    }
}

function setLabelOnTab(tab, text, oArgs) {
  var totalRecords = oArgs.response.meta.totalRecords;
  var label =  text + '(' + totalRecords + ')';
  tab.set('label', label);
}

function isTabAddedToTabView(tabView, tab) {
  if(tabView == null)
    return false;
  return  tabView.getTabIndex(tab) != -1;
}

function displaySize(xmlDoc, tagName, elementId) {
    var records = xmlDoc.getElementsByTagName(tagName); //display length of list

    var element = document.getElementById(elementId);
    if (element !== null) {
        if (records.length == 1) {
            element.innerHTML = records.length + " record found";
        } else {
            element.innerHTML = records.length + " records found";
        }
    }
}

function booleanToString(flag) {
    if (flag) {
        return "Y";
    } else {
        return "N";
    }
}

String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g,"");
}

function checkboxYNFormatter(elCell, oRecord, oColumn, oData) {
    var boolValue = oData == "Y" || oData == "y";

    return YAHOO.widget.DataTable.formatCheckbox(elCell, oRecord, oColumn, boolValue);
}

function addKeyListeners(dialog) {
    // add a key listener to close the dialog by pressing Esc key
    var kl = new YAHOO.util.KeyListener(document, { keys:27 },
    { fn:dialog.hide,
        scope:dialog,
        correctScope:true });

    dialog.cfg.queueProperty("keylisteners", kl);

//  // add a key lister to open the dialog by pressing the Enter key
    //  var kl2 = new YAHOO.util.KeyListener(document, { keys:13 },
    //                                                 { fn:dialog.show,
    //                                                   scope:dialog,
    //                                                   correctScope:true } );
    //  kl2.enable();

}

var enterKeyListener1;
function addEnterKeyListenerToGoBtn() {
    var goBtn = document.getElementById("filterGo");
    enterKeyListener1 = new YAHOO.util.KeyListener(document, { keys:13 },
    { fn:goBtn.click,
        correctScope:true });

    enterKeyListener1.enable();
}

function scrollToTop() {
    window.scrollTo(0, 0);
    document.getElementById("pageDiv").focus();
//  return true;
}

function getTotalRecordCount(response, parsedResponse) {
  var totalCount = 0;
   parsedResponse.totalRecords = parseInt(response.totalRecords, 10);
    return parsedResponse;
//  return true;
}

function filterOnEnter(e) {
    var characterCode = e.keyCode
    var filterGo = document.getElementById('filterGo');
    if (characterCode == 13) {
        filterGo.click();
        return false;
    }
    else {
        return true;
    }
}

function searchBPOnEnter(e) {
    var characterCode = e.keyCode
    var searchBP = document.getElementById('Search');
    if (characterCode == 13) {
        searchBP.click();
        return false;
    }
    else {
        return true;
    }
}

function setFocus() {
    var firstElement = false;
    for (f = 0; f < document.forms.length; f++)
    {
        for (i = 0; i < document.forms[f].length; i++)
        {
            if (document.forms[f][i].type != "hidden")
            {
                var isDisabled = document.forms[f][i].disabled;
                var elementType = document.forms[f][i].type;
                if (!isDisabled && elementType == "text")
                {
                    document.forms[f][i].focus();
                    firstElement = true;
                }
            }
            if (firstElement)
                break;
        }
        if (firstElement)
            break;
    }
}

function setRemoveOrLocked(elCell, locked, confirmMsg, deactivateUrl, isAsync, callbackAfterSuccess) {
    elCell.innerHTML = '';
    if (isAsync) {
        var onclick = {fn:removeAfterConfirmAsync, obj:[confirmMsg, deactivateUrl, callbackAfterSuccess]};
    } else {
        onclick = {fn:removeAfterConfirm, obj:[confirmMsg, deactivateUrl]};
    }
    if (locked) {
        elCell.innerHTML = '<img border="0" alt="Locked" src="' +
                           document.getElementById('contextPath').value +
                           '/images/padlock.gif">';
    } else {
        var removeBtn = new YAHOO.widget.Button({
            id:'removeBtn',
            type: "push",
            title: "Remove from List",
            onclick: onclick,
            container: elCell });
    }
}

function setLockInTheCell(elCell, locked) {
    if (locked) {
        elCell.innerHTML = '<img border="0" alt="Locked" src="' +
                           document.getElementById('contextPath').value +
                           '/images/padlock.gif">';
    } else {
        elCell.innerHTML = '&nbsp;';//very important for sorting to work
    }
}

function removeAfterConfirm(type, args) {
    var confirmed = confirm(args[0]);
    if (confirmed) {
        document.location = args[1];
    }
}

//args[0] - confirm msg
//args[1] - url to go to
//args[2] - call back function name after success
function removeAfterConfirmAsync(type, args) {
    var confirmed = confirm(args[0]);
    if (confirmed) {

        var callBackAfterDelete = {
            success: function(o) {
                this.cache = null;
                args[2](o);
            },
            failure: function(o) {
            },
            timeout: 20000 //20 seconds
        };

        var getXML = YAHOO.util.Connect.asyncRequest("GET",
                args[1],
                callBackAfterDelete);
    }
}

function resetFormIfIdIsNull(form, idElementName) {
    var id = document.getElementById(idElementName).value;
    if (id === "") {
        form.reset();
    }
}

function getQueryStringForActiveTabIndex() {
    return "&activeTabIndex=" + document.getElementById("activeTabIndex").value;
}

function getActiveTabIndex() {
    var activeIndex = document.getElementById("activeTabIndex").value;
    if (activeIndex === "") {
        activeIndex = 0;
        setActiveTabIndexInHiddenField(activeIndex);
    }
    return activeIndex;
}

function setActiveTabIndexInHiddenField(activeIndex) {
    document.getElementById("activeTabIndex").value = activeIndex;
}

function getActiveTabIndexFromHiddenField() {
    return document.getElementById("activeTabIndex").value;
}

function clearSelectionsIfActiveTabDifferentFromLastActiveTab(myTabs, activeTab) {
    var lastActiveTabIndex = getActiveTabIndexFromHiddenField();
    if (lastActiveTabIndex != myTabs.getTabIndex(activeTab)) {
        clearSelectOperateSelections();
        setActiveTabIndexInHiddenField(myTabs.getTabIndex(activeTab));
    }
}

function doesUserHaveEditRole() {
    var hasEditRole = document.getElementById("hasEditRole").value;
    return hasEditRole === "true";
}

function hasAccessToLocation() {
    return document.getElementById('hasAccessToLocations').value === "true";
}

function hasAccessToContact() {
    return document.getElementById('hasAccessToContacts').value === "true";
}

function hasAccessToCommunication() {
    return document.getElementById('hasAccessToComms').value === "true";
}

function hasAccessToAction() {
    return document.getElementById('hasAccessToActions').value === "true";
}

function hasAccessToAssignment() {
    return document.getElementById('hasAccessToAssignment').value === "true";
}

