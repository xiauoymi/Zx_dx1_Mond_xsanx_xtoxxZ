YAHOO.util.Event.addListener(window, "load", initializeHistory);

function initializeHistory() {
  YAHOO.util.History.initialize("yui-history-field", "yui-history-iframe");
}

