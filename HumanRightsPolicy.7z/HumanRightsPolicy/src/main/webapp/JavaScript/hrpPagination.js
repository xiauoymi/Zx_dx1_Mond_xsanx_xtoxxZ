function buildQueryString(state, dt) {
  var startIndex = state.pagination.recordOffset;
  var rowsPerPage = state.pagination.rowsPerPage;
  var currentSortColumn = state.sorting.key;
  var currentSortOrder = ((state.sorting.dir === YAHOO.widget.DataTable.CLASS_DESC) ? "desc" : "asc");
  return "&startIndex=" + startIndex + "&rowsPerPage=" + rowsPerPage +
         "&sort=" + currentSortColumn + "&dir=" + currentSortOrder;
}

function handlePagination(state, dt) {
  var sortedBy = dt.get('sortedBy');
  if(dt.getColumnSet().keys[0].getThEl().getElementsByTagName('input').length > 0){
    dt.getColumnSet().keys[0].getThEl().getElementsByTagName('input')[0].checked = false;
  }

  //This is a fix to an exisiting bug in datatable. http://tech.groups.yahoo.com/group/ydn-javascript/message/29464 
  formatThead(dt, sortedBy.key);
  setAreAllOnThisPageSelected("");
  // Define the new state
  var newState = {
    startIndex: state.recordOffset,
    sorting: {
      key: sortedBy.key,
      dir: sortedBy.dir //((sortedBy.dir === YAHOO.widget.DataTable.CLASS_DESC) ? "desc" : "asc")
    },
    pagination : { // Pagination values
      recordOffset: state.recordOffset, // Default to first page when sorting
      rowsPerPage: 25 //todo let this be selected later
    }
  };

  // Create callback object for the request
  var oCallback = {
//    success: dt.onDataReturnInitializeTable,
        success: dt.onDataReturnSetRows,
    failure: dt.onDataReturnInitializeTable,
    scope: dt,
    argument: newState // Pass in new state as data payload for callback function to use
  };

  dt.getDataSource().doBeforeCallback = function(oRequest, oFullResponse, oParsedResponse) {
    scrollToTop();
    return oParsedResponse;
  }

  // Send the request
  dt.getDataSource().sendRequest(buildQueryString(newState), oCallback);
}

function getServerSidePaginationConfiguration(initialSort, scrollConfig, paginatorLinksConfig) {
  var imageDir = document.getElementById('contextPath').value + '/images/';

  return {
    initialRequest: '&startIndex=0&rowsPerPage=25&sort=' + initialSort + '&dir=asc',
    scrollable: (scrollConfig && scrollConfig.scrollable) ? scrollConfig.scrollable : false,
    height: (scrollConfig && scrollConfig.height) ? scrollConfig.height : "",
    width: (scrollConfig && scrollConfig.width) ? scrollConfig.width : "",
    generateRequest: buildQueryString,
    sortedBy: {key:initialSort, dir:YAHOO.widget.DataTable.CLASS_ASC},
    paginated:true,
    paginationEventHandler : handlePagination,
    paginator: new YAHOO.widget.Paginator({
      containers: getContainerConfig(paginatorLinksConfig),
      alwaysVisible: true, // todo enabled for now to get the record count
      rowsPerPage: 25, //todo let this be selected later
      rowsPerPageOptions: [25],
      pageLinks: 5,
      template : "<span class='currPageReport'>{CurrentPageReport}</span> <span class='pageLinks'>{FirstPageLink} {PreviousPageLink} {PageLinks} {NextPageLink} {LastPageLink}</span>",
      //  <span class='recordsPerPageControl>Results Per Page: {RowsPerPageDropdown}</span>
      pageReportTemplate : "Items <strong>{startRecord}</strong> - <strong>{endRecord}</strong> of <strong>{totalRecords}</strong>",
      firstPageLinkLabel : "<img style='vertical-align:middle;' alt='Go to first page' src='" + imageDir +
                           "page_first.gif'></img>",
      previousPageLinkLabel : "<img alt='Go to previous page' style='vertical-align:middle;' src='" + imageDir + "page_prev.gif'></img>",
      nextPageLinkLabel : "<img alt='Go to next page' style='vertical-align:middle;' src='" + imageDir + "page_next.gif'></img>",
      lastPageLinkLabel : "<img alt='Go to last page' style='vertical-align:middle;' src='" + imageDir + "page_last.gif'></img>"
    })
  };
}

function createServerSidePaginationDataSource(url) {
  var dataSource = new YAHOO.util.DataSource(url);
  dataSource.startIndex = 0;
  dataSource.rowsPerPage = 25;
  dataSource.responseType = YAHOO.util.DataSource.TYPE_XML;

  /*
    dataSource.doBeforeCallback = function(oRequest, oFullResponse, oParsedResponse) {
      oParsedResponse.totalRecords = parseInt(oFullResponse.totalRecords, 10);
      return oParsedResponse;
    };
  */

  return dataSource;
}

function createServerSidePaginationTable(id, columnDefs, dataSource, initialSort, scrollConfig, paginatorLinksConfig) {
  var dataTable = new YAHOO.widget.DataTable(id, columnDefs, dataSource, getServerSidePaginationConfiguration(initialSort, scrollConfig, paginatorLinksConfig));

//  dataTable.subscribe("initEvent", function(oArgs){
//    formatPage();//to set the footer position after datatable is initialized
//  });

  dataTable.sortedBy = {key:initialSort, dir:YAHOO.widget.DataTable.CLASS_ASC};

  formatThead(dataTable, initialSort);

  dataTable.sortColumn = function(oColumn, sDir) {
    // this function copied mainly from example on
    // http://satyam.com.ar/yui/2.5.0/dt_serverdriven.html
    // It was needed to resolve this problem: http://tech.groups.yahoo.com/group/ydn-javascript/message/28442
    //    if (oColumn && (oColumn instanceof YAHOO.widget.Column)) {
    //      if (!oColumn.sortable) {
    //        YAHOO.util.Dom.addClass(this.getThEl(oColumn), YAHOO.widget.DataTable.CLASS_SORTABLE);
    //      }

    //      var sortDirToUse;
    //      if (sDir && (sDir !== YAHOO.widget.DataTable.CLASS_ASC) && (sDir !== YAHOO.widget.DataTable.CLASS_DESC)) {
    //        sortDirToUse = null;
    //      } else {
    //        sortDirToUse = sDir;
    //      }

    var sortDir = this.getColumnSortDir(oColumn);
//      var sortDir = sortDirToUse || this.getColumnSortDir(oColumn);

    var oSortedBy = this.get("sortedBy") || {};

    var isSortNeeded = (!(oSortedBy.key === oColumn.key && oSortedBy.dir === sortDir));
    if (isSortNeeded) {
      // Clear the recordset which is acting as a cache of loaded pages.
      // Sort will scramble the records so they will no longer match the row positions.
      // Recordset cannot be sorted since many positions will be empty and cannot be compared against existing ones.
      //        this.initializeTable();

      // Update sortedBy tracker
      this.set("sortedBy", {key:oColumn.key, dir:sortDir, column:oColumn});

        // Cannot use setPage since it will refuse to trigger the changeRequest event
      // when the page requested is the same as the current one.
      // So, when you clicked the column header a second time to reverse the sort order
      // since the page requested was the same (though in a different order)
      // the paginationEventHandler is not called.
      var oPaginator = this.get('paginator');
      oPaginator.fireEvent('changeRequest', oPaginator.getState({'page':1}));

        // show what we have and fire the event as the original method does.
      this.render();

      this.fireEvent("columnSortEvent", {column:oColumn,dir:sortDir});
    } else {
      //do nothing, already sorted
    }
//    }
  };

  return dataTable;
}

function getContainerConfig(paginatorLinksConfig) {
  if(paginatorLinksConfig != null && paginatorLinksConfig != undefined){
  var containersConfig = new Array();
  var topPaginator = document.getElementById(paginatorLinksConfig.topPaginator);
  if (topPaginator != null) {
    containersConfig[containersConfig.length] = paginatorLinksConfig.topPaginator;
  }
  if (containersConfig.length == 0) {
    return null;
  }
  return containersConfig;
}
  return null;
}

function formatThead(dataTable, sortKey) {
  var col = dataTable.getColumn(sortKey);
  YAHOO.widget.DataTable.formatTheadCell(dataTable.getThLinerEl(col).firstChild, col, dataTable);
}

