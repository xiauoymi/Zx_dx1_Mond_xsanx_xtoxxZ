
function createAddEditLocationDialog() {
  var handleSubmit = function() {
    if (this.validate()) {
      saveEditChanges();
      this.hide();
      resetFormIfIdIsNull(this.form, 'thisLocationId');
//      this.form.reset();
    }
  };
  var handleCancel = function() {
    resetFormIfIdIsNull(this.form, 'thisLocationId');
    this.cancel();
  };
	// Instantiate the Dialog
  var editDialog = new YAHOO.widget.Dialog("editLocationDialog",
  { width : "55em",
    visible : false,
    x: getXForDialog(),
    y:getYForDialog()
//    buttons : [ {text:"Save", handler:handleSubmit, isDefault:true }, { text:"Cancel", handler:handleCancel } ]
  });


  // Validate the entries in the form to require that both first and last name are entered
  editDialog.validate = function() {
    var data = this.getData();
    if (data.locName.trim()  === "" || data.locName === null) {
      alert("Location name must be provided");
      return false;
    }

    var bpLocType = document.getElementById("bpLocTypeId")
    if (bpLocType.selectedIndex === 0){
      alert("Type must be provided");
      return false;
    }
    var stateElement = document.getElementById("state");
    if (stateElement.selectedIndex === 0) {
      alert("Region, country, and state must be provided");
      return false;
    }
    return true;

  };

  addKeyListeners(editDialog);
  editDialog.render();
  YAHOO.util.Event.addListener("addEditLocationBtn", "click", editDialog.show, editDialog, true);
  YAHOO.util.Event.addListener("saveLocationBtn", "click", handleSubmit, editDialog, true);
  YAHOO.util.Event.addListener("cancelLocationBtn", "click", handleCancel, editDialog, true);
}

function getLocationParameters(){
  var businessPartnerId = document.getElementById('businessPartnerId').value;
  var locationName = document.getElementById('locName').value;
  var bpLocTypeId = document.getElementById('bpLocTypeId').value;
  var addr1 = document.getElementById('addr1').value;
  var addr2 = document.getElementById('addr2').value;
  var regionEl = document.getElementById('region');
  var region = regionEl.options[regionEl.selectedIndex].value;
  var countryEl = document.getElementById('country');
  var country = countryEl.options[countryEl.selectedIndex].value;
  var stateEl = document.getElementById('state');
  var state = stateEl.options[stateEl.selectedIndex].value;
  var city = document.getElementById('city').value;
  var postal = document.getElementById('postal').value;
  var sapId = "";
  var parameters = "&businessPartnerId=" + businessPartnerId;
  parameters += "&locationName=" + locationName;
  parameters += "&bpLocTypeId=" + bpLocTypeId;
  parameters += "&addr1=" + addr1;
  parameters += "&addr2=" + addr2;
  parameters += "&region=" + region;
  parameters += "&country=" + country;
  parameters += "&state=" + state;
  parameters += "&city=" + city;
  parameters += "&postal=" + postal;
  parameters += "&sapId" + sapId;
  return parameters;
}

function saveEditChanges()
{
  var thisLocationId = document.getElementById('thisLocationId').value;
  var parameters = getLocationParameters();
  var method;
  var operation;
  if (thisLocationId === "") {
    method = "saveLocationToBp";
    operation = "add";
  } else {
    method = "updateLocation";
    operation = "edit";
//    document.editLocation.action = document.getElementById('contextPath').value + "/servlet/location?method=" + method +
//                                   "&locationId=" + thisLocationId;
//    document.editLocation.submit();
    var addressId = document.getElementById("addressId").value;
    parameters += "&addressId=" + addressId;
  }
  var callBackAfterAddingLocation = {
    success: function(o) {
    this.cache = null;
    if (operation == "add"){
        populateLocationsTable();
      }else{
        populateLocationInfo(o);
      }
  },
    failure: function(o) {
      alert("Unable to add location to BP\n");
  },
    timeout: 20000 //20 seconds
  };
  var url = document.getElementById('contextPath').value + "/data/location?method=" + method +
  "&locationId=" + thisLocationId + parameters;
  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
  url,
  callBackAfterAddingLocation);
}

function populateLocationInfo(o){
  var xmlDoc = o.responseXML;
  document.getElementById('locNameEdit').innerHTML = xmlDoc.getElementsByTagName('locName')[0].text;
  document.getElementById('relTypeEdit').innerHTML = xmlDoc.getElementsByTagName('relType')[0].text;
  var address = xmlDoc.getElementsByTagName('address')[0];
  if (address != null) {
    document.getElementById('streetAddress1Edit').innerHTML = address.getElementsByTagName('streetAddress1')[0].text;
    document.getElementById('streetAddress2Edit').innerHTML = address.getElementsByTagName('streetAddress2')[0].text;
    document.getElementById('cityEdit').innerHTML = address.getElementsByTagName('city')[0].text;
    document.getElementById('stateValueEdit').innerHTML = address.getElementsByTagName('state')[0].text;
    document.getElementById('countryValueEdit').innerHTML = address.getElementsByTagName('country')[0].text;
    document.getElementById('regionValueEdit').innerHTML = address.getElementsByTagName('region')[0].text;
    document.getElementById('zipEdit').innerHTML = address.getElementsByTagName('zip')[0].text;
  }
}

