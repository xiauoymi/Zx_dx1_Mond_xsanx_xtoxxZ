YAHOO.util.Event.addListener(window, "load", function() {
  createLocationTabs();
  createAddEditLocationDialog();
  populateGeoDataLists(true);
  createAddEditContactDialog();

  if (doesUserHaveEditRole()) {
    document.getElementById("addEditContactBtn").disabled = "";
    if (!isLocationSap()) {
      document.getElementById("addEditLocationBtn").disabled = "";
    }
  }
});

function isLocationSap() {
  var isSap = document.getElementById("isSap").value;
  return isSap === "true";
}

function endLocationContactRels() {
  var locationId = document.getElementById("locationId").value;
  var menu = document.getElementById("menu").value;
  document.forms.contactForm.action = document.getElementById("contextPath").value +
                                      "/servlet/locContactRel?method=endLocationContactRelationship&locationId=" +
                                      locationId
      + "&menu=" + menu + getQueryStringForSelectSave()
      + getQueryStringForActiveTabIndex();
  document.forms.contactForm.submit();
}
