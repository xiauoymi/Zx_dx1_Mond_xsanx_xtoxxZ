var locationTabView;
var contactsTab;
var bpsTab;
var commsTab;

function createLocationTabs() {

  locationTabView = new YAHOO.widget.TabView();

   contactsTab = new YAHOO.widget.Tab({
    label: getLabelForContactsTabOnLocation(),
    content: document.getElementById('contactsTab').innerHTML,
    active: false
  });

  if (hasAccessToContact()) {
    locationTabView.addTab(contactsTab);
  }

  bpsTab = new YAHOO.widget.Tab({
    label: getLabelForBPTabOnLocation(),
    content: document.getElementById('bpsTab').innerHTML,
    active: false
  });
  //locationTabView.addTab(bpsTab);

  commsTab = new YAHOO.widget.Tab({
    label: getLabelForCommTabOnLocation(),
    content: document.getElementById('commsTab').innerHTML,
    active: false
  });



//  if (hasAccessToCommunication()) {
//    locationTabView.addTab(commsTab);
//  }
   document.getElementById('tabs').innerHTML = '';
  if (locationTabView.get("tabs").length > 0) {
    locationTabView.appendTo('tabs');
    locationTabView.set("activeIndex", getActiveTabIndex());
  }

    if (hasAccessToContact()) {
      populateContactsTable();
    }

  locationTabView.on('activeTabChange', function(ev) {
    clearSelectionsIfActiveTabDifferentFromLastActiveTab(locationTabView);
    locationTabView.getTabIndex(ev.newValue);
    if (ev.newValue == bpsTab) {
      this.getXML = YAHOO.util.Connect.asyncRequest("GET",
          document.getElementById('contextPath').value + "/data/bpLocRel?method=lookupBPLocRelsForLocationXML" +
          "&locationId=" + document.getElementById('locationId').value + "&menu=" +
          document.getElementById('menu').value,
          createContentsForBPsTab);
    }
    else if (ev.newValue == contactsTab) {
      populateContactsTable();
    }
//    else if (ev.newValue == commsTab) {
//      populateCommunicationsTable();
//    }
  });


}

function getLabelForContactsTabOnLocation(){
  return "Contacts";
}

function getLabelForBPTabOnLocation(){
  return 'Business Partners';
}

function getLabelForCommTabOnLocation() {
  return 'Communication Plans';
}

function setLabelForContactsTabOnLocation(oArgs) {
  if(isTabAddedToTabView(locationTabView, contactsTab))
    setLabelOnTab(contactsTab, getLabelForContactsTabOnLocation(), oArgs);
}

function setLabelForBPTabOnLocation(oArgs) {
  if(isTabAddedToTabView(locationTabView, bpsTab))
    setLabelOnTab(bpsTab, getLabelForBPTabOnLocation(), oArgs);
}

function setLabelForCommunicationsTabOnLocation(oArgs) {
  if(isTabAddedToTabView(locationTabView, commsTab))
    setLabelOnTab(commsTab, getLabelForCommTabOnLocation(), oArgs);
}

function populateContactsTable() {
  var url = document.getElementById('contextPath').value + "/data/locationContactXml?locationId=" +
            document.getElementById("locationId").value +
            "&menu=" + document.getElementById('menu').value;
  createContactsTable(url);
}

function populateContactsTableForLocation() {
  var url = document.getElementById('contextPath').value + "/data/locationContactXml?locationId=" +
            document.getElementById("locationId").value +
            "&menu=" + document.getElementById('menu').value;
  createContactsTable(url);
}

function populateCommunicationsTable() {
  var url = document.getElementById('contextPath').value + "/data/communicationXmlForLocation" +
            "?menu=" + document.getElementById('menu').value +
            "&locationId=" + document.getElementById('locationId').value;
  createCommunicationsTable(url);
}