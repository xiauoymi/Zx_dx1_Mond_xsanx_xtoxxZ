var createContentsForLocationsTab = {
  success: function(o) {
    createLocationsTable(o);
  },
  failure: function(o) {
  },
  timeout: 20000 //20 seconds
};

function createLocationsTable(url, showSelectOperateCheckbox) {
  this.locationDataSource = createServerSidePaginationDataSource(url);
  this.locationDataSource.responseSchema = {
    resultNode: "location",
    fields: [{key: "isPrimary", parser:this.primaryFlagParser}, "relId", "locId", "sapId", "locName", "bpLocRelType",
      "state", "country", "region", "isSap", "removeUrl","viewUrl", "updatePrimaryFlagUrl"],
    metaFields: {totalRecords : "totalRecords"}
  };

  this.locationDataTable = getLocationTable(getLocationColumnDefs(showSelectOperateCheckbox), this.locationDataSource);
  this.locationDataTable.subscribe("dataReturnEvent", function (oArgs) {
    setLabelForLocationsTabOnBP(oArgs);
    setLabelForLocationsTabOnContacts(oArgs);
  });
}

function getLocationTable(columnDefs, dataSource) {
  var locationDataTable = createServerSidePaginationTable("locationsList", columnDefs, dataSource, "locName", null, {topPaginator:'topPaginatorForLocation'});

  setParamsForSelectOperate(locationDataTable, 'locId');

  locationDataTable.subscribe("checkboxClickEvent", function(oArgs) {
    checkboxClickEvent(oArgs);
  });

  locationDataTable.subscribe("rowMouseoverEvent", locationDataTable.onEventHighlightRow);
  locationDataTable.subscribe("rowMouseoutEvent", locationDataTable.onEventUnhighlightRow);
  locationDataTable.subscribe("radioClickEvent", function(oArgs) {
    var elRadio = oArgs.target;
    elRadio.style.backgroundColor = "#854225";
    /*Red*/
    disableAllRadioBtns(locationDataTable, true);
    var elRecord = this.getRecord(elRadio);
    var updatePrimaryFlagUrl = elRecord.getData("updatePrimaryFlagUrl");

    var callBackAfterUpdatingPrimaryFlag = {
      success: function(o) {
        this.cache = null;
        elRadio.style.backgroundColor = "";
        disableAllRadioBtns(locationDataTable, false);
        populateAddres(o);
      },
      failure: function(o) {
      },
      timeout: 20000 //20 seconds
    };

    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
        updatePrimaryFlagUrl,
        callBackAfterUpdatingPrimaryFlag);
  });
  return locationDataTable;
}

function locationNameFormatter(elCell, oRecord, oColumn, oData) {
  elCell.innerHTML = '<a href="' + oRecord.getData('viewUrl') + '">' + oData + '</a>';
}
;

function getLocationColumnDefs(showSelectOperateCheckbox) {
  var lockFormatter = function(elCell, oRecord, oColumn, oData) {
    var locked = oRecord.getData("isSap") == 'Y';
    setLockInTheCell(elCell, locked);
  };

  var checkbox = getCheckboxColumnDef();
  var isPrimary = {key:"isPrimary", label:"", formatter:YAHOO.widget.DataTable.formatRadio, resizeable:true, width:20};
  var locName = {key:"locName", label:"<b>Name</b>", formatter:this.locationNameFormatter, sortable:true, resizeable:true};
  var bpLocRelType = {key:"bpLocRelType", label:"<b>Type</b>", sortable:true, resizeable:true, width:100};
  var state = {key:"state", label:"<b>State/Province</b>", sortable:true, resizeable:true, width:120};
  var country = {key:"country", label:"<b>Country</b>", sortable:true, resizeable:true, width:120};
  var region = {key:"region", label:"<b>World Area</b>", sortable:true, resizeable:true, width:120};
  var lock = {label:"", formatter:lockFormatter, width:20};
  if (showSelectOperateCheckbox == undefined || !showSelectOperateCheckbox) {
    return [isPrimary, locName, bpLocRelType, state, country, region, lock];
  }else{
    return [checkbox, isPrimary, locName, bpLocRelType, state, country, region, lock];
  }
}
