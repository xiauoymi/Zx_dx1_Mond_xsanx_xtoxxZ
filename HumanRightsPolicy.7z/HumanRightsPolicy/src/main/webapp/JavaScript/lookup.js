function getLookupData(selectedLookup){
    var lookupId = selectedLookup.options[selectedLookup.selectedIndex].value;
    document.forms[0].action="/humanrightspolicy/servlet/display_lookup.htm?selectedLookup=" + lookupId + "";
    document.forms[0].submit();
}

function preUpdateLookup(type){
    document.forms[0].action="/humanrightspolicy/servlet/update_lookup.htm?process=" + type + "";
    document.forms[0].submit();
}

        function goToSearch(){
            var search = document.getElementById("search");
            var searchWhat = search.options[search.selectedIndex].value;
            if(searchWhat == "businessPartner"){
                  document.forms[0].action="searchBusinessPartner?method=";
                  document.forms[0].submit();
            } else if (searchWhat == "site") {
                  document.forms[0].action="setSiteSearchCriteria";
                  document.forms[0].submit();
            } else {
              alert("Please select a search");
            }
         }
