// Common Javascript functions.
	// --------------------------------------------------
	// Each page need to have this method customized to get data from People Picker Utility.
	// Do not change anything other than the html element ids.
	//	arrPeopleData
	//		index - 0 : party id
	//		index - 1 : last name
	//		index - 2 : first name
	//		index - 3 : middle name
	//		index - 4 : user id
	//		index - 5 : phone id
	//		index - 6 : email
	//
	// ---------------------------------------------------

  var usernameConrolId="";
  var fullnameConrolId="";
  var emailConrolId="";
function setValuesFromPeoplePicker(arrPeopleData)
{
  if (!usernameConrolId=="") {
    document.getElementById(usernameConrolId).value = arrPeopleData[4];
    }
    if (!fullnameConrolId=="") {
			document.getElementById(fullnameConrolId).value = arrPeopleData[1] + ", " + arrPeopleData[2] + " " + arrPeopleData[3];
    }
    if (!emailConrolId=="") {
			document.getElementById(emailConrolId).value = arrPeopleData[6] + "@monsanto.com";
    }
    document.getElementById(fullnameConrolId).focus();
	}
	
	function setPeoplePickerControlIds(usrname,fullname,email) {
    usernameConrolId=usrname;
		fullnameConrolId=fullname;
		emailConrolId=email;
	}
	
	function strtrim(s) {
	 //Match spaces at beginning and end of text and replace with null strings
		return s.replace(/^\s+/,'').replace(/\s+$/,'');
	}