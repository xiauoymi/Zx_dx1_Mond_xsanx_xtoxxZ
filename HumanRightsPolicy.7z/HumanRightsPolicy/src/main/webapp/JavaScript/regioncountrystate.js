//This code looks for regionId, countryId and stateId hidden elements on the jsp and uses their values to
//select appropriate value in the dropdowns.

//YAHOO.util.Event.addListener(window, "load", function() {
//  var regionId = document.getElementById('prevRegion').value;
//  var countryId = document.getElementById('prevCountry').value;
//  var stateId = document.getElementById('prevState').value;
//
//  populateRegionList(regionId, countryId, stateId, true); // to filter based on countries and states in bp table
//  populateRegionList(regionId, countryId, stateId, false);// or this to not filter
//}
//);

function populateGeoDataLists(filter) {
  var regionId = getValue('prevRegion');
  var countryId = getValue('prevCountry');
  var stateId = getValue('prevState');
  populateRegionList(regionId, countryId, stateId, filter);
}

function populateRegionList(regionId, countryId, stateId, filter) {
  var createList = {
    success: function(o) {
      fillList('region', o, regionId);
      updateCountryBasedOnRegion(countryId, stateId, filter);
    },
    failure: function(o) {
      alert("Unable to retrieve region list");
    }
    //,timeout: 10000 //10 seconds
  };

  this.getXML = YAHOO.util.Connect.asyncRequest("GET",
      document.getElementById('contextPath').value +
      "/data/geoData?method=regionHTML",
      createList);
}

function getValue(elementId) {
  if (document.getElementById(elementId) != null) {
    return document.getElementById(elementId).value;
  } else {
    return null;
  }
}

function updateList(parentListId, childListId, grandChildId, method, callUpdateStates, countryId, stateId, filter) {
  var createList = {
    success: function(o) {
      if (callUpdateStates) {
        fillList(childListId, o, countryId);
        updateStateBasedOnCountry(stateId, filter);
      } else {
        fillList(childListId, o, stateId);
      }
    },
    failure: function(o) {
      alert("Unable to retrieve " + childListId + " list");
    }
    //    , timeout: 10000 //10 seconds
  };

  var parentList = getList(parentListId);
  var currIndex = parentList.selectedIndex;
  if (currIndex === 0) {
    clearList(childListId, fixListName(parentListId));
    clearList(grandChildId, fixListName(parentListId) + " and " + fixListName(childListId));
  } else {
    if (parentList != undefined && parentList != null && parentList.options != undefined &&
        parentList.options != null) {
      var currValue = parentList.options[currIndex].value;

      clearList(grandChildId, fixListName(parentListId) + " and " + fixListName(childListId));

      this.getXML = YAHOO.util.Connect.asyncRequest("GET",
          document.getElementById('contextPath').value +
          "/data/geoData?method=" + method + "&" + parentListId + "=" + currValue,
          createList);
    }
  }
}

function fixListName(listName) {
  if (listName == 'region') {
    return 'world area';
  } else {
    return listName;
  }
}

function getList(listId) {
  return document.getElementById(listId);
}

function getIdToBeSelected(listId) {
  var idElement = document.getElementById(listId + 'Id');
  if (idElement === null) {
    return null;
  }
  return idElement.value;
}

function clearList(listId, parentName) {
  if (listId !== null) {
    var list = getList(listId);
    list.options.length = 1;
//    var selectOption = new Option('All');
    //    selectOption.selected = true;
    //    list.options[list.options.length] = selectOption;
  }
}

function updateActiveCountryBasedOnRegion(countryId, stateId) {
  document.getElementById("country").disabled = "";
  updateCountryBasedOnRegion(countryId, stateId, true);
}

function updateCountryBasedOnRegion(countryId, stateId, filter) {
  var method;
  if (filter) {
    method = "countryHTML";
  } else {
    method = "allCountryHTML";
  }

  document.getElementById("country").disabled = "";
  updateList("region", "country", "state", method, true, countryId, stateId, filter);
  if (document.getElementById("region").selectedIndex == 0) {
    document.getElementById("country").disabled = "disabled";
    document.getElementById("state").disabled = "disabled";
  }
}

function updateActiveStateBasedOnCountry(stateId) {
  updateStateBasedOnCountry(stateId, true);
}

function updateStateBasedOnCountry(stateId, filter) {
  var method;
  if (filter) {
    method = "stateHTML";
  } else {
    method = "allStateHTML";
  }
  document.getElementById("state").disabled = "";
  if (document.getElementById("country").selectedIndex == 0) {
    document.getElementById("state").disabled = "disabled";
  }
  updateList("country", "state", null, method, false, null, stateId, filter);
}

function fillList(listId, o, idToBeSelected) {
  var list = getList(listId);
  if (list != undefined && list != null && list.options != undefined && list.options != null) {
    list.options.length = 1;
//    var defaultOption = "Select";
    //    if (searchFlag){
    //      defaultOption = "All";
    //    }
    //    var selectOption = new Option(defaultOption, '');
    //    if (idToBeSelected === null || idToBeSelected === "") {
    //      selectOption.selected = true;
    //    }
    //    list.options[list.options.length] = selectOption;

    //  var idToBeSelected = getIdToBeSelected(listId);
    var optionElements = o.responseXML.documentElement.getElementsByTagName("option");
    for (var i = 0; i < optionElements.length; i++) {
      var optionElement = optionElements[i];
      var optionValue = optionElement.getAttribute("value");
      var optionText = optionElement.firstChild.nodeValue;
      var option = new Option(optionText, optionValue);
      if (idToBeSelected == optionValue) {
        option.selected = true;
      }
      list.options[list.options.length] = option;
    }
  }
}
