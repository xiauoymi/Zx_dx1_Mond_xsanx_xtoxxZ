function populateBPSearchTable() {
  if (document.getElementById('dontSearch').value == "true") {
    document.getElementById('filterAndPageLinksTable').style.display = "none";
  } else { // no search requested
    searchBPs();
  }
}

function clearFilterAndRefreshBPTable() {
  document.getElementById("filterValue").value = "";
//  clearSelectOperateSelections();
  populateBPSearchTable();
}

function createFilteredBPTable() {
  //  clearSelectOperateSelections();
  searchBPs();
}

function searchBPs() {
  document.getElementById('filterAndPageLinksTable').style.display = "";
  var regionId = document.getElementById('region').value;
  var countryId = document.getElementById('country').value;
  var stateId = document.getElementById('state').value;
  var filterValue = document.getElementById('filterValue').value;
  var hrpTypeElement = document.getElementById('hrpType');
  var hrpType;
  if (hrpTypeElement != null) {
    hrpType = hrpTypeElement.options[hrpTypeElement.selectedIndex].value;
  }

  // add a key lister to open the dialog by pressing the Enter key
  //    var kl2 = new YAHOO.util.KeyListener(document, { keys:13 },
  //                                                   { fn:searchBP,
  //                                                     scope:document,
  //                                                     correctScope:true } );

  //  kl2.enable();

  var url = document.getElementById('contextPath').value + "/data/searchBusinessPartnerXml?scope=" +
            document.getElementById('scope').value + "&menu=" + document.getElementById('menu').value;
  url = url + "&businessName=" + encodeURIComponent(document.getElementById('businessName').value);
  url = url + "&sapId=" + encodeURIComponent(document.getElementById('sapId').value);
  url = url + "&hrpType=" + hrpType;
  url = url + "&hrpFlag=" + document.getElementById('hrpFlag').value;
  url = url + "&recent=" + document.getElementById('recent').value;
  url = url + "&region=" + regionId;
  url = url + "&country=" + countryId;
  url = url + "&state=" + stateId;
  url = url + "&filterValue=" + encodeURIComponent(filterValue);

  this.bpDataSource = createServerSidePaginationDataSource(url);

  this.bpDataSource.responseSchema = {
    resultNode: "bp",
    fields: ["id", "hrpFlag", "sapId", "bpName","hrpTypesAsString","status","country", "state", "region", "viewUrl", "addUrl"],
    metaFields: {totalRecords : "totalRecords"}
  };


  if (document.getElementById('scope').value == "My") {
    this.bpDataTable = getDataTable(getColumnDefs(false), this.bpDataSource);
  } else {//all HRP Bps
    this.bpDataTable = getDataTable(getColumnDefs(true), this.bpDataSource);
  }
}

function getColumnDefs(includeHrpFlag) {
  this.bpNameFormatter = function(elCell, oRecord, oColumn, oData) {
    elCell.innerHTML = '<a href="' + oRecord.getData('viewUrl') + '">' + oData + '</a>';
    YAHOO.widget.DataTable.formatLink;
//    var tdElement = elCell.parentElement;
    //    var beginningDivTag = tdElement.innerHTML.split("</DIV>")[0];
    //    var endTag = tdElement.innerHTML.split("</DIV>")[1];
    //    tdElement.innerHTML = beginningDivTag +'<a href="' + oRecord.getData('viewUrl') + '">' + oData +  '</a></DIV>' ;
  };
  this.typeIconFormatter = function(elCell, oRecord, oColumn, oData) {
    if (oData == "Y" || oData == "y") {
      elCell.innerHTML = '<img border="0" class="padlock" alt="Business Partner " src="' +
                         document.getElementById('contextPath').value +
                         '/images/group.gif">';
    } else {
      elCell.innerHTML = "&nbsp;";//important for sorting
    }
  };
  var checkbox = getCheckboxColumnDef();
  var hrpFlag = {key:"hrpFlag", label:"", formatter:checkboxYNFormatter, width:20};
  var typeIcon = {key:"hrpFlag", label:"", formatter:typeIconFormatter, width:20};
  var sapId = {key:"sapId", label:"<b>SAP ID</b>", sortable:true, resizeable:true, width:100};
  var bpName = {key:"bpName", label:"<b>Company</b>", formatter:this.bpNameFormatter, sortable:true, resizeable:true, sortOptions:{defaultOrder:"asc"}};
  var hrpTypes = {key:"hrpTypesAsString", label:"<b>Category</b>", sortable:true, resizeable:true, width:120};
  var state = {key:"state", label:"<b>State/Province</b>", sortable:true, resizeable:true, width:120};
  var country = {key:"country", label:"<b>Country</b>", sortable:true, resizeable:true, width:120};
  var region = {key:"region", label:"<b>World Area</b>", sortable:true, resizeable:true, width:120};

  if (includeHrpFlag) {
    return [typeIcon, sapId, bpName, hrpTypes, state, country];
  } else {
    return [typeIcon, sapId, bpName, hrpTypes, state, country];
  }
}

function getDataTable(columnDefs, dataSource) {
  var menu = document.getElementById('menu').value;
  this.bpDataTable = createServerSidePaginationTable("searchBPResults", columnDefs, dataSource, "bpName", null, {topPaginator:'topPaginator'});
  this.bpDataTable.subscribe("rowMouseoverEvent", this.bpDataTable.onEventHighlightRow);
  this.bpDataTable.subscribe("rowMouseoutEvent", this.bpDataTable.onEventUnhighlightRow);
//  this.bpDataTable.set("selectionMode", "single");
  //  this.bpDataTable.subscribe("rowClickEvent", function(args) {
  //    var oRecord = this.getRecord(args.target);
  //    document.location.href = oRecord.getData("viewUrl") + menu;//Go to BP Details screen
  //  });
  //  setParamsForSelectOperate(this.bpDataTable, 'id');

  //  this.bpDataTable.subscribe("checkboxClickEvent", function(oArgs) {
  //    checkboxClickEvent(oArgs);
  //  });

  //  this.bpDataTable.subscribe("checkboxClickEvent", function(oArgs) {
  //    var elCheckbox = oArgs.target;
  //    elCheckbox.style.backgroundColor = '#854225';
  //    /*Red*/
  //    var elRecord = this.getRecord(elCheckbox);
  //    var updateHrpFlagUrl = document.getElementById('contextPath').value + "/servlet/businessPartner?method=saveChecks";
  //    updateHrpFlagUrl += "&businessPartnerId=" + elRecord.getData('id') + "&hrpFlag=" +
  //                        booleanToString(elCheckbox.checked);
  //
  //    var callBackAfterUpdatingHrpFlag = {
  //      success: function(o) {
  //        this.cache = null;
  //        elCheckbox.style.backgroundColor = '';
  //      },
  //      failure: function(o) {
  //      },
  //      timeout: 20000 //20 seconds
  //    };
  //
  //    this.getXML = YAHOO.util.Connect.asyncRequest("GET",
  //        updateHrpFlagUrl,
  //        callBackAfterUpdatingHrpFlag);
  //  });

  return this.bpDataTable;
}
