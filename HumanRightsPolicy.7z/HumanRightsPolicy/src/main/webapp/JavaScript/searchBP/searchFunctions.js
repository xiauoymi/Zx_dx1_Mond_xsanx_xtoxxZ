YAHOO.util.Event.addListener(window, "load", function() {
  populateBPSearchTable();
  populateGeoDataLists(true);
  setFocus();
});

function searchBP() {
  document.mainForm.action = document.getElementById('contextPath').value + "/servlet/searchBusinessPartner?method=searchBP";
  document.mainForm.submit();
}

function addBP() {
  document.mainForm.action = document.getElementById('contextPath').value + "/servlet/searchBusinessPartner?method=addBP";
  document.mainForm.submit();
}

function clearBPSearch() {
  var menu = document.getElementById('menu');
//  var isAllBp;
//  if (menu === null) {
//    isAllBp = true;
//  } else {
//    isAllBp = (menu.value == 'bp');
//  }
  document.location = document.getElementById('contextPath').value + "/servlet/searchBusinessPartner?method=allBPs";
//  if (isAllBp) {
//    document.location = document.getElementById('contextPath').value + "servlet/searchBusinessPartner?method=allBPs";
//  } else {
//    document.location = document.getElementById('contextPath').value + "/servlet/searchBusinessPartner?method=&menu=bp";
//  }
}