var dt = null;
var key = null;
var selectedIdsElementName = 'selectedIds';
var idsToExcludeElementName = 'idsToExclude';
var areAllOnThisPageSelectedElementName = 'areAllOnThisPageSelected';
var areAllAcrossPagesSelectedElementName = 'areAllAcrossPagesSelected';

function setParamsForSelectOperate(thisdt, thiskey) {
  dt = thisdt;
  key = thiskey;
}

function theadCheckboxOnClick(theadCheckbox) {
  for (var j = 0; j <= getTotalNumberOfRecordsOnThisPage(); j++) {
    var checkbox = getCheckbox(j);
    var id = getId(j);
    if (theadCheckbox.checked) {
      processCheckboxWhenTheadCheckboxIsChecked(id, checkbox);
    } else {
      processCheckboxWhenTheadCheckboxIsUnChecked(id, checkbox);
    }
  }
}

function checkboxFormatter(elCell, oRecord, oColumn, oData) {
  var id = oRecord.getData(key);
  var isCheckboxChecked = false;
  if (dt != null) {
    if (areAllAcrossPagesSelected()) {
      isCheckboxChecked = !isInIdsToExclude(id);
    }
    else {
      isCheckboxChecked = isIdInSelectedIds(id);
    }

    if (isCheckboxChecked) {
      if (areAllOnThisPageSelected()) {
        getTheadCheckboxElement().checked = true;
      }
    } else {
      setAreAllOnThisPageSelected("false");
      if (getTheadCheckboxElement() != null)
      getTheadCheckboxElement().checked = false;
    }
  }
  return YAHOO.widget.DataTable.formatCheckbox(elCell, oRecord, oColumn, isCheckboxChecked);
}

function checkboxClickEvent(oArgs) {
  //check for column key to be sure if there are more than 1 checkbox in the datatable
  var elCheckbox = oArgs.target;
  var oRecord = dt.getRecord(elCheckbox);
  var id = oRecord.getData(key);

  if (elCheckbox.checked) {
    if (areAllOnThisPageSelected()) {
      getTheadCheckboxElement().checked = true;
    }
    if (areAllAcrossPagesSelected()) {
      removeFromIdsToExclude(id);
    } else {
      addToSelectedIds(id);
    }
  } else {
    setAreAllOnThisPageSelected("false");
    getTheadCheckboxElement().checked = false;
    if (areAllAcrossPagesSelected()) {
      addToIdsToExclude(id);
    } else {
      removeFromSelectedIds(id);
    }
  }
}

function unselectAllAcrossAllPages() {
  getTheadCheckboxElement().checked = false;
  setAreAllAcrossPagesSelected("false");
  for (var j = 0; j <= getTotalNumberOfRecordsOnThisPage(); j++) {
    var checkbox = getCheckbox(j);
    checkbox.checked = false;
  }
  clearSelectedIds();
  clearIdsToExclude();
  disableSelectSaveBtnsIfNoneSelected();
}

function selectAllAcrossAllPages() {
  getTheadCheckboxElement().checked = true;
  setAreAllAcrossPagesSelected("true");
  clearSelectedIds();
  clearIdsToExclude();
  enableSelectSaveBtns();

  for (var j = 0; j <= getTotalNumberOfRecordsOnThisPage(); j++) {
    var checkbox = getCheckbox(j);
    if (!checkbox.checked) {//if the individual checkbox is already checked then dont add it again
      checkbox.checked = true;
    }
  }
}

function processCheckboxWhenTheadCheckboxIsChecked(id, checkbox) {
  if (!checkbox.checked) {
    checkbox.checked = true;
    if (areAllAcrossPagesSelected()) {
      removeFromIdsToExclude(id);
    } else {
      addToSelectedIds(id);
    }
  }
}

function getCheckboxColumnDef() {
  return {label:"<input id='theadCheckbox' name='theadCheckbox' type='checkbox' class='yui-dt-checkbox' onclick='theadCheckboxOnClick(this)'></input>", formatter:checkboxFormatter, resizeable:true, width:20};
}

function processCheckboxWhenTheadCheckboxIsUnChecked(id, checkbox) {
  if (checkbox.checked) {
    checkbox.checked = false;
    if (areAllAcrossPagesSelected()) {
      addToIdsToExclude(id);
    } else {
      removeFromSelectedIds(id);
    }
  }
}

function clearSelectOperateSelections() {
  clearSelectedIds();
  clearIdsToExclude();
  setAreAllAcrossPagesSelected("false");
  disableSelectSaveBtnsIfNoneSelected();
}

function getTheadCheckboxElement() {
  return dt.getThEl(dt.getColumn(0)).getElementsByTagName('input')[0];
}

function getSelectedIds() {
  return document.getElementById(selectedIdsElementName).value;
}

function isIdInSelectedIds(id) {
  return getSelectedIds().indexOf(',' + id) >= 0
}

function addToSelectedIds(id) {
  enableSelectSaveBtns();
  return setSelectedIds(getSelectedIds() + ',' + id);
}

function removeFromSelectedIds(id) {
  setSelectedIds(getSelectedIds().replace(',' + id, ''));
  disableSelectSaveBtnsIfNoneSelected();
}

function setSelectedIds(ids) {
  return document.getElementById(selectedIdsElementName).value = ids;
}

function clearSelectedIds() {
  return setSelectedIds("");
}

function getIdsToExclude() {
  return document.getElementById(idsToExcludeElementName).value;
}

function isInIdsToExclude(id) {
  return getIdsToExclude().indexOf(',' + id) >= 0
}

function addToIdsToExclude(id) {
  return setIdsToExclude(getIdsToExclude() + ',' + id);
}

function removeFromIdsToExclude(id) {
  return setIdsToExclude(getIdsToExclude().replace(',' + id, ''));
}

function setIdsToExclude(ids) {
  return document.getElementById(idsToExcludeElementName).value = ids;
}

function clearIdsToExclude() {
  return setIdsToExclude("");
}

function getAreAllAcrossPagesSelected() {
  return document.getElementById(areAllAcrossPagesSelectedElementName).value;
}

function areAllAcrossPagesSelected() {
  return getAreAllAcrossPagesSelected() === "true";
}

function setAreAllAcrossPagesSelected(value) {
  return document.getElementById(areAllAcrossPagesSelectedElementName).value = value;
}

function getAreAllOnThisPageSelected() {
  return document.getElementById(areAllOnThisPageSelectedElementName).value;
}

function areAllOnThisPageSelected() {
  return getAreAllOnThisPageSelected() === "" || getAreAllOnThisPageSelected() === "true";
}

function setAreAllOnThisPageSelected(value) {
  return document.getElementById(areAllOnThisPageSelectedElementName).value = value;
}

function getTotalNumberOfRecordsOnThisPage() {
  var firstIndexOnThisPage = getPaginator().getPageRecords()[0];
  var lastIndexOnThisPage = getPaginator().getPageRecords()[1];
  return lastIndexOnThisPage - firstIndexOnThisPage;
}

function getPaginator() {
  return dt.getAttributeConfig('paginator').value;
}

function getCheckbox(index) {
  var row = dt.getRow(index);
  var cell = row.cells[0];
  return cell.getElementsByTagName('input')[0];
}

function getId(index) {
  var row = dt.getRow(index);
  var oRecord = dt.getRecord(row);
  return oRecord.getData(key);
}
//  var firstRow = v.getFirstTrEl();
//  if(firstRow != null){
//    checkUncheckAllBoxes(firstRow, allCheckbox);
//    var nextRow = dt.getNextTrEl(firstRow);
//    while(nextRow != null){
//      checkUncheckAllBoxes(nextRow, allCheckbox);
//      nextRow = dt.getNextTrEl(nextRow);
//    }
//  }

function getQueryStringForSelectSave() {
  var areAllAcrossPagesSelected = "&areAllAcrossPagesSelected=" + encodeURIComponent(getAreAllAcrossPagesSelected());
  var selectedIds = "&selectedIds=" + encodeURIComponent(getSelectedIds());
  var idsToExclude = "&idsToExclude=" + encodeURIComponent(getIdsToExclude());
  return areAllAcrossPagesSelected + selectedIds + idsToExclude;
}

function enableSelectSaveBtns() {
  if (doesUserHaveEditRole()) {
    var btns = document.getElementsByName("selectSaveBtn");
    if (btns != null) {
      for (var j = 0; j < btns.length; j++) {
        btns[j].disabled = "";
      }
    }
  }
}

function disableSelectSaveBtnsIfNoneSelected() {
  var selectedIds = getSelectedIds();
  if (selectedIds.length == 0) {
    var btns = document.getElementsByName("selectSaveBtn");
    if (btns != null) {
      for (var j = 0; j < btns.length; j++) {
        btns[j].disabled = "disabled";
      }
    }
  }
}