package com.monsanto.wst.humanrightspolicy;

import com.monsanto.wst.hibernate.DbSchemaGenerator;

public class SchemaGenerationMain {
  public static void main(String[] args) {
    DbSchemaGenerator generator = new DbSchemaGenerator("humanrights");
    generator.generateCreateStatements();
  }
}
