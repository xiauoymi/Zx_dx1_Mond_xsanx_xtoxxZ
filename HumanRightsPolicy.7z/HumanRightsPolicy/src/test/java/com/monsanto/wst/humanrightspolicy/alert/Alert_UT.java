package com.monsanto.wst.humanrightspolicy.alert;

import junit.framework.TestCase;

import java.util.Calendar;
import java.util.Date;

/*
 Alert_UT was created on Oct 7, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class Alert_UT extends TestCase {
  public void testAlert_EmptyConstructor_DefaultsDateToToday() throws Exception {
    Alert alert = new Alert();
    Date alertDate = alert.getDate();
    assertNotNull(alertDate);
    long expectedTimeMillis = Calendar.getInstance().getTimeInMillis();
    long actualTimeMillis = alertDate.getTime();
    long milliDiff = expectedTimeMillis - actualTimeMillis;
    assertTrue("Expected date to be now:" + alertDate,
        milliDiff >= -5000 && milliDiff < 5000);
  }

  public void testAlert_DataConstructor_DefaultsDateToToday() throws Exception {
    Alert alert = new Alert(1L, null, "test", "test");
    Date alertDate = alert.getDate();
    assertNotNull(alertDate);
    long expectedTimeMillis = Calendar.getInstance().getTimeInMillis();
    long actualTimeMillis = alertDate.getTime();
    long milliDiff = expectedTimeMillis - actualTimeMillis;
    assertTrue("Expected date to be now:" + alertDate,
        milliDiff >= -5000 && milliDiff < 5000);
  }
}