package com.monsanto.wst.humanrightspolicy.alert.dao;

import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.hibernate.mock.MockHibernateFactory;
import com.monsanto.wst.hibernate.mock.MockHibernateSession;
import com.monsanto.wst.humanrightspolicy.action.controller.mock.MockAction;
import com.monsanto.wst.humanrightspolicy.alert.Alert;
import com.monsanto.wst.humanrightspolicy.model.HRPEntity;
import junit.framework.TestCase;

/*
 AlertDAO_UT was created on Oct 7, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class AlertDAO_UT extends TestCase {
    private HibernateFactory hibernate;

    protected void setUp() throws Exception {
        super.setUp();
        hibernate = new MockHibernateFactory();
    }

    public void testAddAlertSavesAlert() {
        HRPEntity testTarget = new MockAction(1L);
        String testSubject = "the subject";
        String testDescription = "the description";

        AlertDAO alertDao = new AlertDAOImpl(hibernate);
        alertDao.addAlert(testTarget, testSubject, testDescription);

        MockHibernateSession session = (MockHibernateSession) hibernate.getSession();
        Object savedObject = session.getSavedObject();
        assertNotNull(savedObject);
        assertTrue(savedObject instanceof Alert);
        Alert savedAlert = (Alert) savedObject;

        assertEquals(testTarget, savedAlert.getTarget());
        assertEquals(testSubject, savedAlert.getSubject());
        assertEquals(testDescription, savedAlert.getDescription());
        //todo test Date
    }
}