package com.monsanto.wst.humanrightspolicy.alert.dao;

import com.monsanto.wst.humanrightspolicy.alert.Alert;
import com.monsanto.wst.humanrightspolicy.model.HRPEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class MockAlertDAO implements AlertDAO {
    private List<Alert> savedAlerts = new ArrayList<Alert>();

    public void addAlert(HRPEntity target, String subject, String description) {
        savedAlerts.add(new Alert(null, target, subject, description));
    }

    public List<Alert> getSavedAlerts() {
        return savedAlerts;
    }
}
