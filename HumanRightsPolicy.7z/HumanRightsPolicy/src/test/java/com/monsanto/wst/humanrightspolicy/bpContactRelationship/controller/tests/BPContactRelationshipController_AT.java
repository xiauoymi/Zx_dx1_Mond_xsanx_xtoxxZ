/*
 BPContactRelationshipController_AT was created on Aug 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.bpContactRelationship.controller.tests;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.humanrightspolicy.bpContactRelationship.BPContactRelationshipConstants;
import com.monsanto.wst.humanrightspolicy.bpContactRelationship.controller.BPContactRelationshipController;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.LookupBPDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate.DBTemplateLookupBPDAOImpl;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.ContactInfo;
import com.monsanto.wst.humanrightspolicy.testUtils.HumanRightsPolicyDatabaseTestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: BPContactRelationshipController_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-02 20:12:52 $
 *
 * @author sspati1
 * @version $Revision: 1.3 $
 */
public class BPContactRelationshipController_AT extends HumanRightsPolicyDatabaseTestCase {
  private MockUCCHelper helper;

  public void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper(null, false, new KerberosStandaloneCredential());
  }

  public void testEndBPContactRelationship_ContactIsNotSapNotPrimary_RelIsEnded() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
    helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "2");
    helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
    helper.setRequestParameterValue(HRPMainConstants.MENU, "test");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, BPContactRelationshipConstants.METHOD_END_BP_CONTACT_REL); 
    helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, "1");

    LookupBPDAO bpDao = getBPDao();
    BusinessPartner bp = bpDao
        .lookupBPById(helper.getRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID));
    List<ContactInfo> contacts = bp.getActiveContacts();
    assertEquals(2, contacts.size());

    BPContactRelationshipController controller = new BPContactRelationshipController();
    controller.run(helper);

    contacts = bp.getActiveContacts();
    assertEquals(1, contacts.size());
    assertEquals("1", contacts.get(0).getContactId());
  }

  public LookupBPDAO getBPDao() {
    DBTemplateImpl template = new DBTemplateImpl("database/dbtemplate-config.xml",
        new String[]{"database/dbtemplate.xml"});
    return new DBTemplateLookupBPDAOImpl(template);
  }
}