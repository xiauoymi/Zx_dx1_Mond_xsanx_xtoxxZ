/*
 BPContactRelationshipController_UT was created on Feb 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.bpContactRelationship.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.humanrightspolicy.bpContactRelationship.BPContactRelationshipConstants;
import com.monsanto.wst.humanrightspolicy.bpContactRelationship.controller.BPContactRelationshipController;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.LookupBPDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.tests.mock.MockLookupBPDAO;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.contact.dao.LookupContactDAO;
import com.monsanto.wst.humanrightspolicy.contact.dao.tests.mock.MockLookupContactDAO;
import com.monsanto.wst.humanrightspolicy.location.service.tests.mock.MockLocation;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.*;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: BPContactRelationshipController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:21 $
 *
 * @author sspati1
 * @version $Revision: 1.36 $
 */
public class BPContactRelationshipController_UT extends TestCase {
  private MockUCCHelper helper = null;

  protected void setUp() throws Exception {
    helper = new MockUCCHelper(null);
  }

  public void testEndBPContactRelationship_ContactIsNotPrimaryNotSap_RelIsEnded() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
    helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "1, 2");
    helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
    helper.setRequestParameterValue(HRPMainConstants.MENU, "test");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, BPContactRelationshipConstants.METHOD_END_BP_CONTACT_REL);
    helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, "1");

    List<LocationContactRelationship> relationships = new ArrayList<LocationContactRelationship>();
    MockLocation loc = new MockLocation("2", "Loc 2", "0000000022", false, null, null, null, null);
    relationships.add(new LocationContactRelationshipImpl("2", loc, null, false, true, new ContactType("11", "Worker"), null, null));
    ContactInfo contact =  new MockContactInfo("1", "test", new MockLocationContactRelationshipDAO(relationships), "N");
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, new MockBPLocationRelationshipDAO(new ArrayList<BPLocationRelationship>()), null, null);
    LookupBPDAO bpDao = new MockLookupBPDAO(bp);
    LookupContactDAO contactDao = new MockLookupContactDAO(contact);
    BPContactRelationshipController controller = new BPContactRelationshipController(contactDao, bpDao);
    controller.run(helper);

    assertTrue(loc.isEndLocationContactRelationshipCalled());
    assertEquals(2, loc.getNumLocConRelEnded());
    assertTrue(helper.wasSentTo("businessPartner?method=lookupBP&businessPartnerId=1&menu=test"));
  }

  public void testEndBPContactRelationship_ContactIsPrimaryNotSap_RelIsEndedAndSAPContactBecomesPrimary() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
    helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "1");
    helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
    helper.setRequestParameterValue(HRPMainConstants.MENU, "test");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, BPContactRelationshipConstants.METHOD_END_BP_CONTACT_REL);
    helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, "1");

    List<LocationContactRelationship> locConRels = new ArrayList<LocationContactRelationship>();
    ContactInfo sapContact = new MockContactInfo("1", "pre", "first", "title", "work", "cell", "fax", "email", "Y");
    locConRels.add(new MockLocationContactRelationship("1", true, true, sapContact, null, new ContactType("11", "Worker")));
    MockLocation loc = new MockLocation("2", "Loc 2", "0000000022", false, null, locConRels, null, null);

    List<LocationContactRelationship> relationships = new ArrayList<LocationContactRelationship>();
    relationships.add(new LocationContactRelationshipImpl("2", loc, null, true, true, new ContactType("11", "Worker"), null, null));
    ContactInfo contact =  new MockContactInfo("1", "test", new MockLocationContactRelationshipDAO(relationships), "N");

    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, new MockBPLocationRelationshipDAO(new ArrayList<BPLocationRelationship>()), null, null);
    LookupBPDAO bpDao = new MockLookupBPDAO(bp);
    LookupContactDAO contactDao = new MockLookupContactDAO(contact);

    BPContactRelationshipController controller = new BPContactRelationshipController(contactDao, bpDao);
    controller.run(helper);

    assertTrue(loc.isEndLocationContactRelationshipCalled());
    assertEquals(1, loc.getNumLocConRelEnded());
    ContactInfo newPrimaryContact = loc.getNewPrimaryContact();
    assertTrue(sapContact.equals(newPrimaryContact));
    assertTrue(helper.wasSentTo("businessPartner?method=lookupBP&businessPartnerId=1&menu=test"));
  }

  public void testEndBPContactRelationship_ContactIsSap_RelIsNotEnded() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
    helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "1");
    helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
    helper.setRequestParameterValue(HRPMainConstants.MENU, "test");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, BPContactRelationshipConstants.METHOD_END_BP_CONTACT_REL);
    helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, "1");

    List<LocationContactRelationship> locConRels = new ArrayList<LocationContactRelationship>();
    ContactInfo sapContact = new MockContactInfo("1", "pre", "first", "title", "work", "cell", "fax", "email", "Y");
    locConRels.add(new MockLocationContactRelationship("1", true, true, sapContact, null, new ContactType("11", "Worker")));
    MockLocation loc = new MockLocation("2", "Loc 2", "0000000022", false, null, locConRels, null, null);

    List<LocationContactRelationship> relationships = new ArrayList<LocationContactRelationship>();
    relationships.add(new LocationContactRelationshipImpl("2", loc, null, true, true, new ContactType("11", "Worker"), null, null));
    ContactInfo contact =  new MockContactInfo("1", "test", new MockLocationContactRelationshipDAO(relationships), "Y");

    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, new MockBPLocationRelationshipDAO(new ArrayList<BPLocationRelationship>()), null, null);
    LookupBPDAO bpDao = new MockLookupBPDAO(bp);
    LookupContactDAO contactDao = new MockLookupContactDAO(contact);

    BPContactRelationshipController controller = new BPContactRelationshipController(contactDao, bpDao);
    controller.run(helper);

    assertFalse(loc.isEndLocationContactRelationshipCalled());
    assertEquals(0, loc.getNumLocConRelEnded());
    assertTrue(helper.wasSentTo("businessPartner?method=lookupBP&businessPartnerId=1&menu=test"));
  }

}