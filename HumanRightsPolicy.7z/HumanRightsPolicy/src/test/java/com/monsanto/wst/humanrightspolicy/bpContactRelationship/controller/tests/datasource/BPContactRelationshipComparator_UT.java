/*
 BPContactRelationshipComparator_UT was created on May 9, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.bpContactRelationship.controller.tests.datasource;

import com.monsanto.wst.humanrightspolicy.bpContactRelationship.datasource.*;
import com.monsanto.wst.humanrightspolicy.location.test.MockCountry;
import com.monsanto.wst.humanrightspolicy.model.Address;
import com.monsanto.wst.humanrightspolicy.model.ContactRelationshipImpl;
import com.monsanto.wst.humanrightspolicy.model.StateProvince;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.model.tests.MockRegion;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockAddress;
import junit.framework.TestCase;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: BPContactRelationshipComparator_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-29 18:55:55 $
 *
 * @author rrmall
 * @version $Revision: 1.7 $
 */
public class BPContactRelationshipComparator_UT extends TestCase {
  private ContactRelationshipImpl bpConRel1;
  private ContactRelationshipImpl bpConRel2;
  private ContactRelationshipImpl bpConRel3;
  private ContactRelationshipImpl bpConRel4;

  protected void setUp() throws Exception {
    super.setUp();
    bpConRel1 = new ContactRelationshipImpl("0001", "Test Contact 1", true, true, "testViewURL", "testRemoveUrl", "updatePrimaryFlagURL", "ABCD", "ABCD", "ABCD");
    bpConRel2 = new ContactRelationshipImpl("0002", "Test Contact 2", false, false, "testViewURL2", "testRemoveUrl2", "updatePrimaryFlagURL2", "BCDE", "BCDE", "BCDE");
    bpConRel3 = new ContactRelationshipImpl("0003", "Test Contact 3", false, false, "testViewURL3", "testRemoveUrl3", "updatePrimaryFlagURL3", "CDEF", "CDEF", "CDEF");
    bpConRel4 = new ContactRelationshipImpl("0004", "Test Contact 4", true, true, "testViewURL4", "testRemoveUrl4", "updatePrimaryFlagURL4", "DEFG", "DEFG", "DEFG");
  }

  private void assertOrderIsCorrect(Comparator<XmlObject> comparator
  ) {
    assertTrue(comparator.compare(bpConRel1, bpConRel2) < 0);
    assertTrue(comparator.compare(bpConRel2, bpConRel1) > 0);

    assertTrue(comparator.compare(bpConRel2, bpConRel3) < 0);
    assertTrue(comparator.compare(bpConRel3, bpConRel2) > 0);

    assertTrue(comparator.compare(bpConRel3, bpConRel4) < 0);
    assertTrue(comparator.compare(bpConRel4, bpConRel3) > 0);

    assertEquals(0, comparator.compare(bpConRel1, bpConRel1));
    assertEquals(0, comparator.compare(bpConRel2, bpConRel2));
    assertEquals(0, comparator.compare(bpConRel3, bpConRel3));
    assertEquals(0, comparator.compare(bpConRel4, bpConRel4));
  }

  public void testSortById() throws Exception {
    Comparator<XmlObject> comparator = new BPContactRelationshipDefaultComparator();
    assertOrderIsCorrect(comparator);
  }

  public void testSortByName() throws Exception {
    Comparator<XmlObject> comparator = new BPContactRelationshipNameComparator();
    assertOrderIsCorrect(comparator);
  }

  public void testSortByRegion() throws Exception {
    Comparator<XmlObject> comparator = new BPContactRelationshipRegionComparator();
    assertOrderIsCorrect(comparator);
  }

  public void testSortByState() throws Exception {
    Comparator<XmlObject> comparator = new BPContactRelationshipStateComparator();
    assertOrderIsCorrect(comparator);
  }

  public void testSortByType() throws Exception {
    Comparator<XmlObject> comparator = new BPContactRelationshipCountryComparator();
    assertOrderIsCorrect(comparator);
  }


  private static Address getAddress(String region, String country, String state) {
    return new MockAddress("1", "123 MAIN", "APT 2", "SAINT LOUIS", "63141", new StateProvince("1", state),
        new MockCountry("2", country), new MockRegion("3", region));
  }
}