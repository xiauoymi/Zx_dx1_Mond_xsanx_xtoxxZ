/*
 BPContactRelationshipDataSource_UT was created on May 9, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.bpContactRelationship.controller.tests.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.humanrightspolicy.bpContactRelationship.datasource.*;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.tests.mock.MockLookupBPService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.*;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Filename:    $RCSfile: BPContactRelationshipDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 19:19:27 $
 *
 * @author rrmall
 * @version $Revision: 1.17 $
 */
public class BPContactRelationshipDataSource_UT extends XMLTestCase {

  private MockUCCHelper helper = null;
  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper(null);
  }

  public void testGetBPContactRelationshipForBP() throws Exception {
    helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, "1");
    helper.setRequestParameterValue(HRPMainConstants.MENU, "bp");
    BPContactRelationshipDataSource dataSource = createDataSource();
    List<? extends XmlObject> data = dataSource.getData();
    Document bpLocRelDoc = DOMUtil.stringToXML(data.get(0).toXml());
    assertNotNull(data);
    assertEquals(2, data.size());
    assertNotNull(bpLocRelDoc);
    assertXpathEvaluatesTo("2", "/contact/contactId", bpLocRelDoc);
    assertXpathEvaluatesTo("Y", "/contact/isPrimary", bpLocRelDoc);
    assertXpathEvaluatesTo("John", "/contact/name", bpLocRelDoc);
    assertXpathEvaluatesTo("Illinois", "/contact/state", bpLocRelDoc);
    assertXpathEvaluatesTo("United States", "/contact/country", bpLocRelDoc);
    assertXpathEvaluatesTo("NA", "/contact/region", bpLocRelDoc);
    assertXpathEvaluatesTo("N", "/contact/isSap", bpLocRelDoc);
    assertXpathEvaluatesTo("/humanrightspolicy/servlet/locContactRel?method=endLocationContactRelationship&contactId=2&locationId=1&menu=bp", "/contact/removeUrl", bpLocRelDoc);
    assertXpathEvaluatesTo("/humanrightspolicy/servlet/contacts?method=lookupContact&contactId=2&menu=bp", "/contact/viewUrl", bpLocRelDoc);
    assertXpathEvaluatesTo("/humanrightspolicy/servlet/locContactRel?method=setPrimaryContact&contactId=2&businessPartnerId=1&menu=bp", "/contact/updatePrimaryFlagUrl", bpLocRelDoc);
  }

  public void testDefaultSortForBPContact() throws Exception {
    BPContactRelationshipDataSource dataSource = createDataSource();
    Comparator<? extends XmlObject> comparator = dataSource.getComparator(null);
    assertNotNull(comparator);
    assertTrue(comparator instanceof BPContactRelationshipDefaultComparator);
  }

  public void testNameSortForBPContact() throws Exception {
    BPContactRelationshipDataSource dataSource = createDataSource();
    Comparator<? extends XmlObject> comparator = dataSource.getComparator("name");
    assertNotNull(comparator);
    assertTrue(comparator instanceof BPContactRelationshipNameComparator);
  }

  public void testRegionSortForBPContact() throws Exception {
    BPContactRelationshipDataSource dataSource = createDataSource();
    Comparator<? extends XmlObject> comparator = dataSource.getComparator("region");
    assertNotNull(comparator);
    assertTrue(comparator instanceof BPContactRelationshipRegionComparator);
  }

  public void testCountrySortForBPContact() throws Exception {
    BPContactRelationshipDataSource dataSource = createDataSource();
    Comparator<? extends XmlObject> comparator = dataSource.getComparator("country");
    assertNotNull(comparator);
    assertTrue(comparator instanceof BPContactRelationshipCountryComparator);
  }

  public void testStateSortForBPContact () throws Exception {
    BPContactRelationshipDataSource dataSource = createDataSource();
    Comparator<? extends XmlObject> comparator = dataSource.getComparator("state");
    assertNotNull(comparator);
    assertTrue(comparator instanceof BPContactRelationshipStateComparator);
  }

  private BPContactRelationshipDataSource createDataSource() {
     List<BPLocationRelationship> bpLocRels = new ArrayList<BPLocationRelationship>();
      List<LocationContactRelationship> locConRels = new ArrayList<LocationContactRelationship>();

      Location primaryLocation = new LocationImpl("1", null, null, null, "N", null, "United States", null,
        "Missouri", null, "NA", null, null, null, null, null);
      List<LocationContactRelationship> locContactRels = new ArrayList<LocationContactRelationship>();
      locContactRels.add(new MockLocationContactRelationship(null, false, false, null, null, new ContactType("11", "Worker")
      ));
      locContactRels.add(new MockLocationContactRelationship(null, false, true, null, primaryLocation, new ContactType("11", "Worker")
      ));
      ContactInfo contact1 = new MockContactInfo("1", "janet", new MockLocationContactRelationshipDAO(
          locContactRels), "N");
      locConRels.add(new MockLocationContactRelationship(null, true, true, contact1, null, new ContactType("11", "Worker")
      ));
      Location loc1 = new MockLocationImpl(null, new MockLocationContactRelationshipDAO(locConRels), null, null);
      bpLocRels.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, loc1));

      locConRels = new ArrayList<LocationContactRelationship>();
      primaryLocation = new LocationImpl("2", null, null, null, "N", null, "United States", null,
        "Iowa", null, "NA", null, null, null, null, null);
      locContactRels = new ArrayList<LocationContactRelationship>();
      locContactRels.add(new MockLocationContactRelationship(null, false, false, null, null, new ContactType("11", "Worker")
      ));
      locContactRels.add(new MockLocationContactRelationship(null, false, true, null, primaryLocation, new ContactType("11", "Worker")
      ));
      contact1 = new MockContactInfo("1", "Jane", new MockLocationContactRelationshipDAO(
          locContactRels), "N");
      locConRels.add(new MockLocationContactRelationship(null, false, true, contact1, null, new ContactType("11", "Worker")
      ));

      primaryLocation = new LocationImpl("1", null, null, null, "N", null, "United States", null,
        "Illinois", null, "NA", null, null, null, null, null);
      locContactRels = new ArrayList<LocationContactRelationship>();
      locContactRels.add(new MockLocationContactRelationship(null, false, true, null, primaryLocation, new ContactType("11", "Worker")
      ));
      locContactRels.add(new MockLocationContactRelationship(null, false, false, null, null, new ContactType("11", "Worker")
      ));
      ContactInfo contact2 = new MockContactInfo("2", "John", new MockLocationContactRelationshipDAO(
          locContactRels), "N");
      locConRels.add(new MockLocationContactRelationship(null, true, false, contact2, null, new ContactType("11", "Worker")
      ));
      Location loc2 = new MockLocationImpl(null, new MockLocationContactRelationshipDAO(locConRels), null, null);
      MockBPLocationRelationship primaryRelForBP = new MockBPLocationRelationship(true, new LocationType(1L, null), null, loc2);
      bpLocRels.add(primaryRelForBP);
      BusinessPartner bp = new MockBusinessPartnerImpl("1", null, null, null, null, null, new MockBPLocationRelationshipDAO(bpLocRels
      ), null, null);
      return new BPContactRelationshipDataSource(helper, new MockLookupBPService(bp));
  }
}