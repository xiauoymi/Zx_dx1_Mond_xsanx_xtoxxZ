/*
SaveBusinessPartnerController_AT was created on Jul 10, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.controller.tests;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.controller.BusinessPartnerController;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommunicationDAO;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.persistence.HrpPersistenceStore;
import com.monsanto.wst.humanrightspolicy.testUtils.HumanRightsPolicyDatabaseTestCase;
import com.monsanto.wst.humanrightspolicy.testUtils.mock.MockUCCHelperForHrp;

import java.util.List;

/**
 * Filename:    $RCSfile: BusinessPartnerController_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-10-17 15:36:21 $
 *
 * @author vrbethi
 * @version $Revision: 1.76 $
 */
public class BusinessPartnerController_AT extends HumanRightsPolicyDatabaseTestCase {
  private MockUCCHelper helper;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper(null, false, new KerberosStandaloneCredential());
    LoginUser loginUser = new MockUser(new Long(1), "BP_UDP", "BP_UPD", false, new Role("1", "EDIT"), "test Description", "test Email");
    helper.setSessionParameter(HRPMainConstants.LOGINUSER, loginUser);
  }

  public void testLookupBP_VerifyValues() throws Exception {
    setupHelper(helper);
    helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, "1");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, BusinessPartnerConstants.METHOD_LOOKUP_BP);
    BusinessPartnerController controller = new BusinessPartnerController();
    controller.run(helper);
    BusinessPartnerImpl businessPartner = (BusinessPartnerImpl) helper.getRequestAttributeValue(BusinessPartnerConstants.BUSINESS_PARTNER);
    assertEquals("1", businessPartner.getPartnerId());
    assertEquals("TEST GM", businessPartner.getEntityName());
    assertEquals("GENERAL_MOTORS", businessPartner.getAliasName());
    assertEquals("0000012345", businessPartner.getSapId());
    assertEquals("5678", businessPartner.getLegacyId());
    assertEquals("N", businessPartner.getActive());
    assertEquals("N", businessPartner.getHrpFlag());
    assertEquals("Type 1, Type 2", businessPartner.getHrpTypesAsCommaSeparatedString());
    assertTrue(helper.wasSentTo(BusinessPartnerConstants.BUSINESS_PARTNER_JSP));
  }

  public void testAddCommunicationFromBusinessPartner_CommunicationHasBPsPrimaryLocationsPrimaryContactAsRecipient() throws Exception {
    helper = new MockUCCHelperForHrp("hrpAT");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, CommunicationConstants.ADD_COMM_METHOD);
    helper.setRequestParameterValue(CommunicationConstants.COMM_NAME, "111 comm name test");
    helper.setRequestParameterValue(CommunicationConstants.COMM_NOTES, "comm notes test");
    helper.setRequestParameterValue(CommunicationConstants.COMM_FROM_PERIOD, "2008-08-19");
    helper.setRequestParameterValue(CommunicationConstants.COMM_TO_PERIOD, "2008-09-19");
    helper.setRequestParameterValue(CommunicationConstants.COMM_DUE_PERIOD, "2008-09-25");
    helper.setRequestParameterValue(CommunicationConstants.COMM_TYPE_ID, "1");
    helper.setRequestParameterValue(CommunicationConstants.COMM_PEOPLE_TYPE_ID, "1");
    helper.setRequestParameterValue(CommunicationConstants.COMM_LOC_TYPE_ID, "1");
    String bpId = "1";
    helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, bpId);
    BusinessPartnerController controller = new BusinessPartnerController();
    controller.run(helper);
    List<Communication> commList = getCommunicationDAO().lookupCommunicationsByBPId(bpId);
    assertNotNull(commList);
    assertEquals(2, commList.size());
    Communication comm = commList.get(0);
    assertEquals("111 comm name test", comm.getName());
    assertEquals("comm notes test", comm.getNotes());
   assertEquals(new Long(1), comm.getCommType().getId());
   assertEquals(new Long(1), comm.getLocConRelType().getId());
   assertEquals(new Long(1), comm.getBpLocRelType().getId());
    assertEquals("Open", comm.getStatus().getStatus());
    assertEquals("2008-08-19", comm.getFormattedFromDate());
    assertEquals("2008-09-19", comm.getFormattedToDate());
    assertEquals("2008-09-25", comm.getFormattedDueDate());
    assertTrue(comm.getRecipients().size() == 1);
    List<CommRecipient> recipients = comm.getRecipients();
    assertNotNull(recipients);
    assertTrue(recipients.size() == 1);
    CommRecipient recipient = recipients.get(0);
    assertEquals("RAMBABU", recipient.getName());

    PersistentStore store = HrpPersistenceStore.getStore();
    PersistentStoreConnection connection = store.connect();
    connection.executeDelete("delete hrpolicy.comm_recipient where recipient_id = '1'");
    connection.executeDelete("delete hrpolicy.communication where comm_id = " + comm.getId());
  }

  private CommunicationDAO getCommunicationDAO() {
      DBTemplateImpl template = new DBTemplateImpl("database/dbtemplate-config.xml",
          new String[]{"database/dbtemplate.xml"});
      return new DBTemplateCommunicationDAO(template, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    }

  private void setupHelper(MockUCCHelper helper) {
    helper.setRequestParameterValue(HRPMainConstants.BUSINESS_NAME, "BUSINESS_NAME");
    helper.setRequestParameterValue(HRPMainConstants.ALIAS_NAME, "ALIAS_NAME_TEST");
    helper.setRequestParameterValue(BusinessPartnerConstants.SAP_ID, "2345");
    helper.setRequestParameterValue("region", "1");
    helper.setRequestParameterValue(BusinessPartnerConstants.WEBSITE_URL, "www.new.com");
    helper.setRequestParameterValue(BusinessPartnerConstants.HRP_FLAG, "Y");

  }

}