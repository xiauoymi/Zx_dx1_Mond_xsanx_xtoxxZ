package com.monsanto.wst.humanrightspolicy.businessPartner.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.controller.BusinessPartnerController;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.tests.mock.MockLookupBPService;
import com.monsanto.wst.humanrightspolicy.businessPartner.services.BusinessPartnerService;
import com.monsanto.wst.humanrightspolicy.businessPartner.services.tests.mock.MockBusinessPartnerService;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.service.tests.mock.MockCommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.service.tests.mock.MockLocation;
import com.monsanto.wst.humanrightspolicy.location.service.tests.mock.MockLocationService;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockBPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockBusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockCommunication;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockContactInfo;
import org.custommonkey.xmlunit.XMLTestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rgeorge Jun 19, 2006 Time: 10:32:23 AM
 */
public class BusinessPartnerController_UT extends XMLTestCase {

    private MockUCCHelper helper;

    protected void setUp() throws Exception {
        helper = new MockUCCHelper(null);
        LoginUser loginUser = new MockUser(1L, "BP_UDP", "BP_UPD", false, new Role("1", "EDIT"), "test Description", "test email");
        helper.setSessionParameter(HRPMainConstants.LOGINUSER, loginUser);
    }

    public void testCreate() throws Exception {
        BusinessPartnerController controller = new BusinessPartnerController();
        assertNotNull(controller);
    }

    public void testLookupBusinessPartner_ReturnsBP() throws Exception {
        helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, "1");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, BusinessPartnerConstants.METHOD_LOOKUP_BP);
        BusinessPartnerController controller = createBusinessPartnerController();
        controller.run(helper);
        validateBusinessPartner();
        List bpLocRelTypes = (List) helper.getRequestAttributeValue(LocationsConstants.BP_LOC_REL_TYPE_LIST);
        assertNotNull(bpLocRelTypes);
        List locConRelTypes = (List) helper.getRequestAttributeValue(BusinessPartnerConstants.LOC_CON_REL_TYPE_LIST);
        assertNotNull(locConRelTypes);
        assertTrue(helper.wasSentTo(BusinessPartnerConstants.BUSINESS_PARTNER_JSP));
    }

    public void testAddCommunicationFromBusinessPartner_CommunicationHasBPsPrimaryLocationsPrimaryContactAsRecipient() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.METHOD, CommunicationConstants.ADD_COMM_METHOD);
        helper.setRequestParameterValue(CommunicationConstants.COMM_NAME, "comm name test");
        helper.setRequestParameterValue(CommunicationConstants.COMM_NOTES, "comm notes test");
        helper.setRequestParameterValue(CommunicationConstants.COMM_FROM_PERIOD, "2008-08-19");
        helper.setRequestParameterValue(CommunicationConstants.COMM_TO_PERIOD, "2008-09-19");
        helper.setRequestParameterValue(CommunicationConstants.COMM_DUE_PERIOD, "2008-09-25");
        helper.setRequestParameterValue(CommunicationConstants.COMM_TYPE_ID, "12");
        helper.setRequestParameterValue(CommunicationConstants.COMM_STATUD_ID, "13");
        helper.setRequestParameterValue(CommunicationConstants.COMM_PEOPLE_TYPE_ID, "14");
        helper.setRequestParameterValue(CommunicationConstants.COMM_LOC_TYPE_ID, "15");
        helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, "1");

        MockBusinessPartnerService mockService = new MockBusinessPartnerService(null);
        List<BPLocationRelationship> bpLocationRelationship = new ArrayList<BPLocationRelationship>();
        List<LocationContactRelationship> locContactRels = new ArrayList<LocationContactRelationship>();
        locContactRels.add(new LocationContactRelationshipImpl("1", null, new MockContactInfo("contact1", null, "test Contact", "test Contact Name", null, null, null, null, null), true, true, new ContactType("1", null), null, null));
        LocationContactRelationship primaryRel = new LocationContactRelationshipImpl("11", null, new MockContactInfo("primary1", null, "primary Contact", "primary Contact Name", null, null, null, null, null), true, true, new ContactType("2", null), null, null);
        MockLocation loc = new MockLocation("1", "test", "0001", false, null, locContactRels, primaryRel, null);
        BPLocationRelationship bpLocRel = new BPLocationRelationshipImpl("1", null, loc, true, new LocationType(1L, null), null, null);
        bpLocationRelationship.add(bpLocRel);
        MockBPLocationRelationshipDAO relationshipDAO = new MockBPLocationRelationshipDAO(bpLocationRelationship);
        MockBusinessPartnerImpl testBp = new MockBusinessPartnerImpl("1", "TEST", "TEST", "1", null, null, relationshipDAO,
                null, null);
        MockLookupBPService mockBpLookupService = new MockLookupBPService(testBp);
        MockCommunicationService commService = new MockCommunicationService(null);
        BusinessPartnerController controller = new BusinessPartnerController(mockService, mockBpLookupService, new MockLocationService(null), commService, new MockDAO<ContactType, Long>());
        controller.run(helper);
        MockCommunication comm = (MockCommunication) commService.getNewComm();
        assertEquals("comm name test", comm.getName());
        assertEquals("comm notes test", comm.getNotes());
        assertEquals(new Long(12), comm.getCommType().getId());
        assertEquals("2008-08-19", comm.getFormattedFromDate());
        assertEquals("2008-09-19", comm.getFormattedToDate());
        assertEquals("2008-09-25", comm.getFormattedDueDate());
        assertTrue(comm.getRecipients().size() > 1);
        assertTrue(comm.getNumOfRecipientsAdded() == 1);
    }

    private void validateBusinessPartner() {
        BusinessPartnerImpl businessPartner = (BusinessPartnerImpl) helper.getRequestAttributeValue("businessPartner");
        assertEquals("1", businessPartner.getPartnerId());
        assertEquals("0000001234", businessPartner.getSapId());
    }

    private BusinessPartnerImpl getBusinessPartner() {

        return new BusinessPartnerImpl("1", "1234", "5678", "PARTNER_NAME", "ALIAS_NAME",
                "wwww.bp.com",
                null, null, null,
                null);
    }

    private BusinessPartnerController createBusinessPartnerController() {
        return createBusinessPartnerController(new MockBusinessPartnerService(null));
    }

    private BusinessPartnerController createBusinessPartnerController(BusinessPartnerService bpService) {
        return new BusinessPartnerController(bpService, new MockLookupBPService(getBusinessPartner()), new MockLocationService(null), new MockCommunicationService(null), new MockDAO<ContactType, Long>());
    }
}
