/*
 SearchBusinessPartnerController_AT was created on Sep 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.controller.SearchBusinessPartnerController;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.HrpType;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: SearchBusinessPartnerController_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:24 $
 *
 * @author sspati1
 * @version $Revision: 1.40 $
 */
public class SearchBusinessPartnerController_AT extends TestCase {

  public void testAllBPs_CategoryListIsSetInResponse() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "allBPs");
    SearchBusinessPartnerController controller = new SearchBusinessPartnerController();
    controller.run(helper);
    BusinessPartner bp = (BusinessPartner) helper
        .getSessionParameter(BusinessPartnerConstants.SEARCH_CRITERIA);
    assertNull(bp.getPartnerId());
    assertNull(bp.getSapId());
    assertNull(bp.getLegacyId());
    assertNull(bp.getEntityName());
    assertNull(bp.getAliasName());
    assertEquals("Y", bp.getActive());
    assertNull(bp.getHrpFlag());
    assertNull(bp.getAddress());
    List<HrpType> hrpTypes = (List<HrpType>) helper.getRequestAttributeValue(BusinessPartnerConstants.HRP_TYPES);
    assertNotNull(hrpTypes); //category
    assertEquals("All", helper.getRequestAttributeValue(HRPMainConstants.SCOPE));
    assertEquals("true", helper.getRequestAttributeValue(HRPMainConstants.DONT_SEARCH));
    assertTrue(helper.wasSentTo(BusinessPartnerConstants.SEARCH_BUSINESS_PARTNER_JSP));
  }
}