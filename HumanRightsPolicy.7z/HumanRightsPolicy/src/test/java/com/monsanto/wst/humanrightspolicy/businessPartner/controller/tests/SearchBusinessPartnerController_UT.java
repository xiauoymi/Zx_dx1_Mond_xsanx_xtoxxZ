/*
 SearchBusinessPartner_UT was created on Jul 31, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.controller.SearchBusinessPartnerController;
import com.monsanto.wst.humanrightspolicy.businessPartner.services.BusinessPartnerService;
import com.monsanto.wst.humanrightspolicy.businessPartner.services.tests.mock.MockBusinessPartnerService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.*;
import org.custommonkey.xmlunit.XMLTestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: SearchBusinessPartnerController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 *
 * @author sspati1
 */
public class SearchBusinessPartnerController_UT extends XMLTestCase {
  private MockUCCHelper helper;

  protected void setUp() throws Exception {
    helper = new MockUCCHelper(null);
    setLoginUserWithEditRoleAndStatesOrProvinces();
  }

  public void testCreate() throws Exception {
    SearchBusinessPartnerController controller = new SearchBusinessPartnerController();
    assertNotNull(controller);
  }

  public void testNonSpecified_CheckRequestAttributes() throws Exception {
    SearchBusinessPartnerController controller = new SearchBusinessPartnerController();
    controller.run(helper);
    BusinessPartner bp = (BusinessPartner) helper
        .getSessionParameter(BusinessPartnerConstants.SEARCH_CRITERIA);

    assertNull(bp.getPartnerId());
    assertNull(bp.getSapId());
    assertNull(bp.getLegacyId());
    assertNull(bp.getEntityName());
    assertNull(bp.getAliasName());
    assertEquals("Y", bp.getActive());
    assertNull(bp.getHrpFlag());
    assertNull(bp.getAddress());
    assertEquals("My", helper.getRequestAttributeValue(HRPMainConstants.SCOPE));
    assertNull(helper.getRequestAttributeValue(HRPMainConstants.DONT_SEARCH));
    assertTrue(helper.wasSentTo(BusinessPartnerConstants.SEARCH_BUSINESS_PARTNER_JSP));
  }

  public void testAllBps_CheckRequestAttributes() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "allBPs");
    List<HrpType> hrpTypeList = new ArrayList<HrpType>();
    hrpTypeList.add(new HrpType(new Long(1), "Internal"));
    hrpTypeList.add(new HrpType(new Long(2), "Grower"));
    BusinessPartnerService bpService = new MockBusinessPartnerService(hrpTypeList);
    SearchBusinessPartnerController controller = new SearchBusinessPartnerController(bpService);
    controller.run(helper);
    BusinessPartner bp = (BusinessPartner) helper
        .getSessionParameter(BusinessPartnerConstants.SEARCH_CRITERIA);
    assertNull(bp.getPartnerId());
    assertNull(bp.getSapId());
    assertNull(bp.getLegacyId());
    assertNull(bp.getEntityName());
    assertNull(bp.getAliasName());
    assertEquals("Y", bp.getActive());
    assertNull(bp.getHrpFlag());
    assertNull(bp.getAddress());
    List<HrpType> hrpTypes = (List<HrpType>) helper.getRequestAttributeValue(BusinessPartnerConstants.HRP_TYPES);
    assertEquals(2, hrpTypes.size());
    assertEquals(new Long(1), hrpTypes.get(0).getId());
    assertEquals("Internal", hrpTypes.get(0).getValue());
    assertEquals("All", helper.getRequestAttributeValue(HRPMainConstants.SCOPE));
    assertEquals("true", helper.getRequestAttributeValue(HRPMainConstants.DONT_SEARCH));
    assertTrue(helper.wasSentTo(BusinessPartnerConstants.SEARCH_BUSINESS_PARTNER_JSP));
  }

  private void setLoginUserWithEditRoleAndStatesOrProvinces() {
    MockUser loginUser = new MockUser(new Long(1), "BP_UDP", "BP_UPD", false, new Role("1", "EDIT"), "test Description", "test Email");
    loginUser.addRegion(new Region("2", "NALAN"));
    loginUser.addCountry(new Country("10", "UNITED STATES OF AMERICA"));
    loginUser.addState(new StateProvince("2", "ILLINOIS"));
    helper.setSessionParameter(HRPMainConstants.LOGINUSER, loginUser);
  }
}