package com.monsanto.wst.humanrightspolicy.businessPartner.dao;

import com.monsanto.wst.dbtemplate.dao.DBTemplateNoResultsException;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import junit.framework.TestCase;

/*
 BusinessPartnerDeferredImpl_AT was created on May 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class BusinessPartnerDeferredImpl_AT extends TestCase {
  public void testGetInstance() throws Exception {
    String testBpId = "-123";
    String testSAPId = "SAP123";
    String testName = "TEST VENDOR";
    String testHrpTypes = "GROWER, LABOR";
    String testStateId = "3";
    BusinessPartnerDeferredImpl bp = new BusinessPartnerDeferredImpl(InitService.initGeoDataFactory(), testBpId, testSAPId, testName, testStateId, "Y", testHrpTypes);
    try {
      bp.getInstance();
      fail("expected exception not received");
    } catch (DBTemplateNoResultsException e) {
      // ignore expected exception
    }
  }
}