package com.monsanto.wst.humanrightspolicy.businessPartner.dao;

import com.monsanto.wst.humanrightspolicy.geodata.GeoDataFactory;
import com.monsanto.wst.humanrightspolicy.geodata.mock.MockGeoDataFactory;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import junit.framework.TestCase;

/*
 BusinessPartnerDeferredImpl_UT was created on May 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class BusinessPartnerDeferredImpl_UT extends TestCase {
    public void testDeferredImplDoesntQueryForBasicFields() throws Exception {
        String testBpId = "123";
        String testSAPId = "SAP123";
        String testName = "TEST VENDOR";
        String testHrpTypes = "GROWER, LABOR";
        String testStateId = MockGeoDataFactory.MOCK_STATE_ID_1_1_2;

        GeoDataFactory geoDataFactory = new MockGeoDataFactory();
        BusinessPartner bp = new MockBusinessPartnerDeferredImplForErrorOnQuery(testBpId, testSAPId, testName,
                testStateId, geoDataFactory);
        assertEquals(testBpId, bp.getPartnerId());
        assertEquals(testSAPId, bp.getSapId());
        assertEquals(testName, bp.getFullName());
        assertEquals(testHrpTypes, bp.getHrpTypesAsCommaSeparatedString());
        assertEquals(testStateId, bp.getAddress().getStateModel().getId());
    }

    public void testDeferredImplDoesQueryForOtherThanBasicFields() throws Exception {
        String testBpId = "123";
        String testSAPId = "SAP123";
        String testName = "TEST VENDOR";
        String testHrpTypes = "GROWER, LABOR";
        String testStateId = MockGeoDataFactory.MOCK_STATE_ID_1_1_1;

        GeoDataFactory geoDataFactory = new MockGeoDataFactory();
        BusinessPartner bp = new MockBusinessPartnerDeferredImplForErrorOnQuery(testBpId, testSAPId, testName,
                testStateId, geoDataFactory);
        assertEquals(testBpId, bp.getPartnerId());
        assertEquals(testSAPId, bp.getSapId());
        assertEquals(testName, bp.getFullName());
        assertEquals(testHrpTypes, bp.getHrpTypesAsCommaSeparatedString());
        assertEquals(testStateId, bp.getAddress().getStateModel().getId());
        try {
            bp.getWebsiteUrl();
            fail("Expected exception not received");
        } catch (RuntimeException e) {
            // ignore expected exception
        }
    }

    private static class MockBusinessPartnerDeferredImplForErrorOnQuery extends BusinessPartnerDeferredImpl {
        public MockBusinessPartnerDeferredImplForErrorOnQuery(
                String bpId, String SAPId, String name,
                String stateId, GeoDataFactory geoDataFactory) {
            super(geoDataFactory, bpId, SAPId, name, stateId, "Y", "GROWER, LABOR"); //todo should be using mock geodatafactory
        }

        protected synchronized BusinessPartnerImpl getInstance() {
            throw new RuntimeException("MOCK");
        }
    }
}