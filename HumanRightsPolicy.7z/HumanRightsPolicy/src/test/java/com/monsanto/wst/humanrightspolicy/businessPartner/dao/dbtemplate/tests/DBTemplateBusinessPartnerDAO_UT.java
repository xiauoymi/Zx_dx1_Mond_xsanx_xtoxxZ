/*
 DBTemplateBusinessPartnerDAO_UT was created on Apr 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate.tests;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate.DBTemplateBusinessPartnerDAO;
import com.monsanto.wst.humanrightspolicy.model.HrpType;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: DBTemplateBusinessPartnerDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:24 $
 *
 * @author sspati1
 * @version $Revision: 1.10 $
 */
public class DBTemplateBusinessPartnerDAO_UT extends TestCase {

  public void testLookupHrpTypesForBP_CorrectStatementWasCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    BusinessPartnerDAO dao = new DBTemplateBusinessPartnerDAO(template);
    dao.lookupHrpTypesForBP("1");
    assertTrue(template.wasStatementNameCalled("lookupHrpTypesForBP"));
  }

  public void testLookupAllHrpTypes_CorrectStatementWasCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    MockDAO<HrpType, Long> hrpTypeDao = new MockDAO<HrpType, Long>();
    BusinessPartnerDAO dao = new DBTemplateBusinessPartnerDAO(template, hrpTypeDao);
    dao.lookupAllHrpTypes();
    assertTrue(hrpTypeDao.wasFindAllCalled());
  }
}