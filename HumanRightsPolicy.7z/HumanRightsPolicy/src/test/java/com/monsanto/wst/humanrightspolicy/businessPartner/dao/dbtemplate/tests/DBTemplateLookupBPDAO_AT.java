package com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate.tests;

import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerResult;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate.DBTemplateLookupBPDAOImpl;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.LoginUser;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import junit.framework.TestCase;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/*
 DBTemplateBusinessPartnerDAO_AT was created on Aug 13, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class DBTemplateLookupBPDAO_AT extends TestCase {
  public void testLookupRecentBPReturnsFewerThanFullSearch() throws Exception {
    Calendar cal = GregorianCalendar.getInstance();
    cal.add(Calendar.DAY_OF_MONTH, -5);
    Date recentDate = cal.getTime();
    String testName = "CAMPO";
    BusinessPartner allSearchCriteria = new BusinessPartnerImpl(null, null, null, testName, null, null, null, null, null, null);
    BusinessPartner recentSearchCriteria = new BusinessPartnerImpl(null, null, null, testName, null, null, null, null, null, recentDate);
    DBTemplateLookupBPDAOImpl dao = new DBTemplateLookupBPDAOImpl(InitService.initTemplate());
    LoginUser testUser = null;
    BusinessPartnerResult allResults = dao.lookupBPByCriteria(allSearchCriteria, false, testUser, null, null, null, null);
    BusinessPartnerResult recentResults = dao.lookupBPByCriteria(recentSearchCriteria, false, testUser, null, null, null, null);

    int allResultsCount = allResults.getTotalRecords();
    int recentResultsCount = recentResults.getTotalRecords();
    String message = "Expected allResults > recentResults, but was: allResults=" +  allResultsCount +
        ", recentResults=" + recentResultsCount;
    assertTrue(message, allResultsCount  > recentResultsCount);
  }
}