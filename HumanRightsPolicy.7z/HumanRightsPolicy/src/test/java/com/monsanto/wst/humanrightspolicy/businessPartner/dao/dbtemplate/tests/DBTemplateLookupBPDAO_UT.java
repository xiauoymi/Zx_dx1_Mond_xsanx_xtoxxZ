/*
 DBTemplateSearchBPDAO_UT was created on Oct 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate.tests;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplateNoResults;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.LookupBPDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate.DBTemplateLookupBPDAOImpl;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: DBTemplateLookupBPDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-06-05 17:56:26 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public class DBTemplateLookupBPDAO_UT extends TestCase {

  public void testSearchBP_StatementCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplateNoResults();
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(template);
    dao.lookupBPByCriteria(null, false, null, null, "", null, null);
    assertTrue(template.wasStatementNameCalled("lookupBPByCriteria"));
  }

  public void testLookupBPById_StatementCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(template);
    dao.lookupBPById("1");
    assertTrue(template.wasStatementNameCalled("lookupBPById"));
  }
}