/*
 BusinessPartnerDAO_AT was created on Jul 10, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.dao.tests;

import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.humanrightspolicy.Security.dao.dbtemplate.tests.DBTemplateBaseTransactionTestCase;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate.DBTemplateBusinessPartnerDAO;
import com.monsanto.wst.humanrightspolicy.model.HrpType;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.util.List;

/**
 * Filename:    $RCSfile: BusinessPartnerDAO_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-09-19 16:01:23 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public class BusinessPartnerDAO_AT extends DBTemplateBaseTransactionTestCase {
  protected String getConfigPath() {
    return "com/monsanto/wst/humanrightspolicy/testUtils/hrpData.xml";
  }

  public void testLookupHrpTypesForBP_ReturnsNull() throws Exception {
    BusinessPartnerDAO dao = new DBTemplateBusinessPartnerDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    String hrpTypes = dao.lookupHrpTypesForBP("2");
    assertNull(hrpTypes);
  }

  public void testLookupHrpTypesForBP_Returns2() throws Exception {
    BusinessPartnerDAO dao = new DBTemplateBusinessPartnerDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    String hrpTypes = dao.lookupHrpTypesForBP("1");
    assertEquals("Type 1, Type 2", hrpTypes);
  }

  public void testLookupAllHrpTypes() throws Exception {
    BusinessPartnerDAO dao = new DBTemplateBusinessPartnerDAO(null, InitService.initHrpTypeDAO());
    List<HrpType> list = dao.lookupAllHrpTypes();
    assertTrue(list.size() >= 2);
  }
}