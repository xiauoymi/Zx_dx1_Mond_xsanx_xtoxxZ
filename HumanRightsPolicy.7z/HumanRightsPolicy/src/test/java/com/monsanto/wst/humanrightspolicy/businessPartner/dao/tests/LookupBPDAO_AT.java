/*
 DBTemplateSearchBPDAO_UT was created on Oct 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.dao.tests;

import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.humanrightspolicy.Security.dao.dbtemplate.tests.DBTemplateBaseTransactionTestCase;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerResult;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.LookupBPDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.dbtemplate.DBTemplateLookupBPDAOImpl;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.MockUser;

import java.util.List;

/**
 * Filename:    $RCSfile: LookupBPDAO_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-29 18:50:37 $
 * @author sspati1
 * @version $Revision: 1.27 $
 */
public class LookupBPDAO_AT extends DBTemplateBaseTransactionTestCase {

  protected String getConfigPath() {
    return "com/monsanto/wst/humanrightspolicy/testUtils/hrpData.xml";
  }

  public void testLookupBPById_ReturnsOneBP() throws Exception {
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
    BusinessPartner bp = dao.lookupBPById("1");
    assertEquals("1", bp.getPartnerId());
    assertEquals("TEST GM <br /> GENERAL_MOTORS", bp.getFullName());
    assertEquals("0000012345", bp.getSapId());
    assertEquals("N", bp.getHrpFlag());
  }

 public void testSearchBP_withSAPID_ReturnsOneBP() throws Exception {
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
    BusinessPartner bp = new BusinessPartnerImpl(null, "0012345", null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
   BusinessPartnerResult result = dao.lookupBPByCriteria(bp, false, null, null, "", null, null);
   List searchResults = result.getData();
    assertNotNull(searchResults);
    assertTrue(searchResults.size() >= 1);
  }

  public void testSearchBP_withID_ReturnsOneBP() throws Exception {
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
    BusinessPartnerImpl bp = new BusinessPartnerImpl();
    bp.setPartnerId("1");
    BusinessPartnerResult result = dao.lookupBPByCriteria(bp, false, null, null, "", null, null);
    List searchResults = result.getData();
    assertNotNull(searchResults);
    assertEquals(1, searchResults.size());
    BusinessPartner businessPartner = (BusinessPartner) searchResults.get(0);
    assertNull(bp.getEntityName());
    validateBP(businessPartner);
  }

  public void testSearchBP_withSAPID_ReturnsOneIncompleteBP() throws Exception {
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
    BusinessPartner bp = new BusinessPartnerImpl(null, "4444", null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    BusinessPartnerResult result = dao.lookupBPByCriteria(bp, false, null, null, "", null, null);
    List searchResults = result.getData();
    assertNotNull(searchResults);
    assertTrue(searchResults.size() >= 1);
  }
//
//  public void testSearchBP_withIsCompleteFlagN_ReturnsOneIncompleteBP() throws Exception {
//    SearchBPDAO dao = new DBTemplateSearchBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
//    BusinessPartner bp = new BusinessPartnerImpl(null, null, null, null, null, null, "N",
//        null, null, null, null, null, null, null, null, null, null, null, null, null, null);
//    BPSearchCriteria bpSearchCriteria = new BPSearchCriteria(bp, null);
//    List searchResults = dao.searchBusinessPartners(bpSearchCriteria);
//    assertNotNull(searchResults);
//    //todo look at the query
////    assertTrue(searchResults.size() == 2);
//  }

  public void testSearchBP_withPartialName_ReturnsTwoBP() throws Exception {
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
    BusinessPartner bp = new BusinessPartnerImpl(null, null, null, "T�ST", null, null, null,
        null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    BusinessPartnerResult result = dao.lookupBPByCriteria(bp, false, null, null, "", null, null);
    List searchResults = result.getData();
    assertNotNull(searchResults);
    assertTrue(searchResults.size() >= 3);
  }

  public void testSearchMyBP_withPartialName_ReturnsTwoBP() throws Exception {
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
    BusinessPartner bp = new BusinessPartnerImpl(null, null, null, "T�ST", null, null, null,
        null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    BusinessPartnerResult result = dao.lookupBPByCriteria(bp, true, new MockUser(new Long(1), "SSPATI1", null), null, "", null, null);
    List searchResults = result.getData();
    assertNotNull(searchResults);
    assertTrue(searchResults.size() >= 3);
  }

  public void testSearchBP_withActive_ReturnsBP() throws Exception {
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
    BusinessPartner bp = new BusinessPartnerImpl(null, null, null, null, null, "N", null,
        null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    BusinessPartnerResult result = dao.lookupBPByCriteria(bp, false, null, null, "", null, null);
    List searchResults = result.getData();
    assertNotNull(searchResults);
    assertTrue(searchResults.size() > 0);
  }

  public void testSearchBP_withHrpFlag_ReturnsBP() throws Exception {
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
    BusinessPartner bp = new BusinessPartnerImpl(null, null, null, null, null,null, null,
        "Y", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    BusinessPartnerResult result = dao.lookupBPByCriteria(bp, false, null, null, "", null, null);
    List searchResults = result.getData();
    assertNotNull(searchResults);
    assertTrue(searchResults.size() > 0);
  }

  public void testSearchBP_withCountryId_ReturnsThreeBP() throws Exception {
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
    BusinessPartner bp = new BusinessPartnerImpl(null, null, null, null, null, null, null,
        null, null, "10", null, null, null, null, null, null, null, null, null, null, null, null, null);
    BusinessPartnerResult result = dao.lookupBPByCriteria(bp, false, null, null, "", null, null);
    List searchResults = result.getData();
    assertNotNull(searchResults);
    assertEquals(2, searchResults.size());
  }

  public void testSearchBP_withStateId_ReturnsThreeBP() throws Exception {
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
    BusinessPartner bp = new BusinessPartnerImpl(null, null, null, null, null, null, null,
        null, null, null, null, "2", null, null, null, null, null, null, null, null, null, null, null);
    BusinessPartnerResult result = dao.lookupBPByCriteria(bp, false, null, null, "", null, null);
    List searchResults = result.getData();
    assertNotNull(searchResults);
    assertEquals(1, searchResults.size());
  }

  public void testSearchBP_withRegionId_ReturnsBP() throws Exception {
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
    BusinessPartner bp = new BusinessPartnerImpl(null, null, null, null, null, null, null,
        null, null, null, null, null, null, "1", null, null, null, null, null, null, null, null, null);
    BusinessPartnerResult result = dao.lookupBPByCriteria(bp, false, null, null, "", null, null);
    List searchResults = result.getData();
    assertNotNull(searchResults);
    assertEquals(4, searchResults.size());
  }

  public void testSearchBP_withHrpType_ReturnsBP() throws Exception {
    LookupBPDAO dao = new DBTemplateLookupBPDAOImpl(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}));
    BusinessPartner bp = new BusinessPartnerImpl(null, null, null, null, null, null, null,
        null, "ype 1", null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    BusinessPartnerResult result = dao.lookupBPByCriteria(bp, false, null, null, "", null, null);
    List searchResults = result.getData();
    assertNotNull(searchResults);
    assertEquals(1, searchResults.size());
  }

  private void validateBP(BusinessPartner businessPartner) {
    assertEquals("1", businessPartner.getPartnerId());
    assertEquals("TEST GM <br /> GENERAL_MOTORS", businessPartner.getFullName());
    assertEquals("0000012345", businessPartner.getSapId());
    assertEquals("N", businessPartner.getHrpFlag());
    assertEquals("Type 1, Type 2", businessPartner.getHrpTypesAsCommaSeparatedString());
  }
}