/*
 MockBusinessPartnerDAO was created on Apr 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.dao.tests.mock;

import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerDAO;
import com.monsanto.wst.humanrightspolicy.model.HrpType;

import java.util.List;

/**
 * Filename:    $RCSfile: MockBusinessPartnerDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-29 18:25:21 $
 *
 * @author sspati1
 * @version $Revision: 1.14 $
 */
public class MockBusinessPartnerDAO implements BusinessPartnerDAO {
  private final String hrpTypes;
  private List<HrpType> hrpTypesList;
  private boolean lookupHrpTypesCalled;

  public MockBusinessPartnerDAO(String hrpTypes, List<HrpType> hrpTypesList) {
    this.hrpTypes = hrpTypes;
    this.hrpTypesList = hrpTypesList;
  }

  public String lookupHrpTypesForBP(String bpId) {
    this.lookupHrpTypesCalled = true;
    return hrpTypes;
  }

  public boolean isLookupHrpTypesCalled() {
    return lookupHrpTypesCalled;
  }

  public List<HrpType> lookupAllHrpTypes() {
    return hrpTypesList;
  }
}