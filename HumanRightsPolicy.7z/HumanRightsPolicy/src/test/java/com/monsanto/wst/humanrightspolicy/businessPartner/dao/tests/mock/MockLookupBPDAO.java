/*
 Mock was created on Dec 6, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.dao.tests.mock;

import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerResult;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.LookupBPDAO;
import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockLookupBPDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date:
 * 2008/01/03 22:00:33 $
 *
 * @author sspati1
 * @version $Revision: 1.15 $
 */
public class MockLookupBPDAO implements LookupBPDAO {
  private final BusinessPartner bp;

  public MockLookupBPDAO(BusinessPartner bp) {
    this.bp = bp;
  }

  public BusinessPartner lookupBPById(String bpId) {
    return bp;
  }

  public BusinessPartnerResult lookupBPByCriteria(BusinessPartner bpSearchCriteria, boolean myBPScope, LoginUser user, String sortKey,
                                 String filterValue, Integer startRecord, Integer endRecord) {
    if (bpSearchCriteria.getSapId().equalsIgnoreCase("0000012345")) {
      List<BusinessPartner> data = getSearchResults();
      return new BusinessPartnerResult(data, data.size());
    } else {
      return new BusinessPartnerResult(new ArrayList<BusinessPartner>(), 0);
    }
  }

  private List<BusinessPartner> getSearchResults() {
    List<BusinessPartner> bpList = new ArrayList<BusinessPartner>();
    new Address(null, "StreetAddress 1", "StreetAddress 2", "City", "ZIP",
        new StateProvince("10", "ILLINOIS"),
        new Country("10", "UNITED STATES OF AMERICA"), new Region("2", "NALAN"));
    BusinessPartnerImpl businessPartner = new BusinessPartnerImpl("23", "1234", "5678", "ABC", "REL",
        null,
        "N", null, "N", null);
    bpList.add(businessPartner);

    new Address(null, null, null, null, null, new StateProvince(null, "Virginia"),
        new Country(null, "United States"), new Region("1", "NALAN"));
    businessPartner = new BusinessPartnerImpl("12", "1234", "5678", "Reliance Petro", "REL",
        null, "Y", null, "Y", null);
    bpList.add(businessPartner);
    return bpList;
  }
}