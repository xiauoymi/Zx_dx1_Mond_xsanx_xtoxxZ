/*
 MockSearchBusinessPartnerDAOThrowsException was created on Jan 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.dao.tests.mock;

import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerResult;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.LookupBPDAO;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.LoginUser;

/**
 * Filename:    $RCSfile: MockLookupBPDAOThrowsException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-27 15:11:52 $
 *
 * @author sspati1
 * @version $Revision: 1.9 $
 */
public class MockLookupBPDAOThrowsException implements LookupBPDAO {

  public BusinessPartner lookupBPById(String bpId) {
    return null;
  }

  public BusinessPartnerResult lookupBPByCriteria(BusinessPartner bpSearchCriteria, boolean myBPScope, LoginUser user, String sortKey,
                                 String filterValue, Integer startRecord, Integer endRecord) {
    return null;
  }
}