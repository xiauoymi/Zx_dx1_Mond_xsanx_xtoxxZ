package com.monsanto.wst.humanrightspolicy.businessPartner.datasource;

import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.tests.mock.MockBusinessPartnerDAO;
import com.monsanto.wst.humanrightspolicy.location.test.MockCountry;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.MockRegion;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockAddress;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockBusinessPartnerImpl;
import junit.framework.AssertionFailedError;
import junit.framework.TestCase;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/*
 BusinessPartnerComparators_UT was created on Apr 24, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class BusinessPartnerComparators_UT extends TestCase {
  private BusinessPartner testbp1;
  private BusinessPartner testbp2;
  private BusinessPartner testbp3;
  private BusinessPartner testbp4;

  protected void setUp() throws Exception {
    super.setUp();

    MockBPLocationRelationship locationDao = new MockBPLocationRelationship();
    testbp1 = new MockBusinessPartnerImpl("001", "AAA", "AAA", "0002", null, null, getAddress("ZZZZ", "MMMM", "EEEE"), locationDao,
        null, new MockBusinessPartnerDAO("GROWER, LABOR", null));
    testbp2 = new MockBusinessPartnerImpl("002", "BBB", "BBB", "0001", null, null, getAddress("YYY", "HHHH", "GGGG"), locationDao,
        null, new MockBusinessPartnerDAO("LABOR", null));
    testbp3 = new MockBusinessPartnerImpl("003", "DDD", "DDD", "0003", null, null, getAddress("XXX", "TTTT", "HHHH"), locationDao,
        null, new MockBusinessPartnerDAO("", null));
    testbp4 = new MockBusinessPartnerImpl("004", "CCC", "CCC", "0004", null, null, getAddress("WWWW", "QQQQ", "FFFF"), locationDao,
        null, new MockBusinessPartnerDAO("GROWER", null));
  }

  @SuppressWarnings({"UseOfSystemOutOrSystemErr"})
  private void assertOrderIsCorrect(Comparator<XmlObject> comparator, BusinessPartner bp1, BusinessPartner bp2, BusinessPartner bp3, BusinessPartner bp4) {
    try {
      assertTrue(comparator.compare(bp1, bp2) < 0);
      assertTrue(comparator.compare(bp2, bp1) > 0);

      assertTrue(comparator.compare(bp2, bp3) < 0);
      assertTrue(comparator.compare(bp3, bp2) > 0);

      assertTrue(comparator.compare(bp3, bp4) < 0);
      assertTrue(comparator.compare(bp4, bp3) > 0);

      assertEquals(0, comparator.compare(bp1, bp1));
      assertEquals(0, comparator.compare(bp2, bp2));
      assertEquals(0, comparator.compare(bp3, bp3));
      assertEquals(0, comparator.compare(bp4, bp4));
    } catch (AssertionFailedError e) {
      System.out.println("bp1 = " + bp1);
      System.out.println("bp2 = " + bp2);
      System.out.println("bp3 = " + bp3);
      System.out.println("bp4 = " + bp4);
      throw e;
    }
  }

  public void testSortById() throws Exception {
    Comparator<XmlObject> comparator = new BusinessPartnerDefaultComparator();
    assertOrderIsCorrect(comparator, testbp1, testbp2, testbp3, testbp4);
  }

  public void testSortBySAPID() throws Exception {
    Comparator<XmlObject> comparator = new BusinessPartnerSAPIDComparator();
    assertOrderIsCorrect(comparator, testbp2, testbp1, testbp3, testbp4);
  }

  public void testSortByName() throws Exception {
    Comparator<XmlObject> comparator = new BusinessPartnerNameComparator();
    assertOrderIsCorrect(comparator, testbp1, testbp2, testbp4, testbp3);
  }

  public void testSortByRegion() throws Exception {
    Comparator<XmlObject> comparator = new BusinessPartnerRegionComparator();
    assertOrderIsCorrect(comparator, testbp4, testbp3, testbp2, testbp1);
  }

  public void testSortByCountry() throws Exception {
    Comparator<XmlObject> comparator = new BusinessPartnerCountryComparator();
    assertOrderIsCorrect(comparator, testbp2, testbp1, testbp4, testbp3);
  }

  public void testSortByState() throws Exception {
    Comparator<XmlObject> comparator = new BusinessPartnerStateComparator();
    assertOrderIsCorrect(comparator, testbp1, testbp4, testbp2, testbp3);
  }

  public void testSortByBpHrpTypes() throws Exception {
    Comparator<XmlObject> comparator = new BusinessPartnerHrpTypeComparator();
    assertOrderIsCorrect(comparator, testbp3, testbp4, testbp1, testbp2);
  }

  private static Address getAddress(String region, String country, String state) {
    return new MockAddress("1", "123 MAIN", "APT 2", "SAINT LOUIS", "63141", new StateProvince("1", state),
        new MockCountry("2", country), new MockRegion("3", region));
  }

  private static class MockBPLocationRelationship implements BPLocationRelationshipDAO {
    public List<BPLocationRelationship> getActiveBPLocationRelationshipsForBP(BusinessPartner businessPartner) {
      return Collections.emptyList();
    }

    public void endBPLocationRelationship(String bpLocRelId) {
    }

    public void saveBPLocationRelationship(BPLocationRelationship bpLocRel) {
    }

    public BPLocationRelationship getActiveBPLocationRelationshipForLocation(Location location) {
      return null;
    }

      public void endBPLocRelForLocation(BusinessPartner bp, Location location) {
          
      }
  }
}