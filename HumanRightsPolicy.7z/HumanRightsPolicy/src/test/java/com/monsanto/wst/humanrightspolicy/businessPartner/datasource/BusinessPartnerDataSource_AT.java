/*
 BusinessPartnerDataSource_AT was created on Jul 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.humanrightspolicy.Security.service.SecurityService;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.controller.XmlDataPaginationController;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.Role;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.testUtils.HumanRightsPolicyDatabaseTestCase;
import com.monsanto.wst.humanrightspolicy.testUtils.mock.MockUCCHelperForHrp;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.util.List;

/**
 * Filename:    $RCSfile: BusinessPartnerDataSource_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-09-29 14:34:32 $
 *
 * @author sspati1
 * @version $Revision: 1.13 $
 */
public class BusinessPartnerDataSource_AT extends HumanRightsPolicyDatabaseTestCase {
  //todo this testcase is probably taking to long and causing the problems with surefire
  private MockUCCHelper helper;
  private SecurityService securityService;

  protected void setUp() throws Exception {
    super.setUp();
    securityService = InitService.initSecurityService();
    securityService.createUser(null, "MECORU", new Role("22", null), true, "M CORUM", null, "m.c@monstanto.com", null, null, null, null);
    helper = new MockUCCHelperForHrp("MECORU");
  }

  protected void tearDown() throws Exception {
    securityService.removeUserRole("MECORU");
    super.tearDown();
  }

  public void testGetData_FilterBySAPId_ReturnsDataWithHrpTypes() throws Exception {
    helper.setRequestParameterValue("filterValue", "0000012345");
    BusinessPartnerDataSource ds = new BusinessPartnerDataSource(helper);
    List<? extends XmlObject> data = ds.getData();
    assertEquals(1, data.size());
    BusinessPartner bp = (BusinessPartner) data.get(0);
    assertEquals("1", bp.getPartnerId());
    assertEquals("0000012345", bp.getSapId());
    assertEquals("TEST GM <br /> GENERAL_MOTORS", bp.getFullName());
    assertEquals("Type 1, Type 2", bp.getHrpTypesAsCommaSeparatedString());
  }

  public void testGetData_ScopeIsMyHasAccessToAll_ReturnsAll() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.SCOPE, "My");
    helper.setRequestParameterValue(BusinessPartnerConstants.HRP_FLAG, "Y");
    helper.setRequestParameterValue(XmlDataPaginationController.START_INDEX, "0");
    helper.setRequestParameterValue(XmlDataPaginationController.ROWS_PER_PAGE, "10");
    BusinessPartnerDataSource ds = new BusinessPartnerDataSource(helper);
    List<? extends XmlObject> data = ds.getData();
    assertTrue(data.size() >= 2);
  }

  public void testGetData_RecentlyAddedHasLessOrEqualAsNormal() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.SCOPE, "My");
    helper.setRequestParameterValue(BusinessPartnerConstants.HRP_FLAG, "Y");
    helper.setRequestParameterValue(XmlDataPaginationController.START_INDEX, "0");
    helper.setRequestParameterValue(XmlDataPaginationController.ROWS_PER_PAGE, "10");
    int allCount = new BusinessPartnerDataSource(helper).getData().size();

    helper.setRequestParameterValue(HRPMainConstants.SCOPE, "My");
    helper.setRequestParameterValue(BusinessPartnerConstants.HRP_FLAG, "Y");
    helper.setRequestParameterValue(HRPMainConstants.RECENTLY_ADDED, "true");
    helper.setRequestParameterValue(XmlDataPaginationController.START_INDEX, "0");
    helper.setRequestParameterValue(XmlDataPaginationController.ROWS_PER_PAGE, "10");
    BusinessPartnerDataSource ds = new BusinessPartnerDataSource(helper);
    int recentCount = new BusinessPartnerDataSource(helper).getData().size();
    assertTrue(recentCount <= allCount);
  }

  //todo once createUser also saves userregions, usercountries, userstates and userprivs then this test will pass
//  public void testGetData_ScopeIsMyHasAccessToState10_ReturnsAll() throws Exception {
//    helper = new MockUCCHelperForHrp("MECORU");
//    helper.setRequestParameterValue(HRPMainConstants.SCOPE, "My");
//    helper.setRequestParameterValue(BusinessPartnerConstants.HRP_FLAG, "Y");
//    helper.setRequestParameterValue(XmlDataPaginationController.START_INDEX, "0");
//    helper.setRequestParameterValue(XmlDataPaginationController.ROWS_PER_PAGE, "10");
//    BusinessPartnerDataSource ds = new BusinessPartnerDataSource(helper);
//    List<? extends XmlObject> data = ds.getData();
//    assertTrue(data.size() == 1);
//  }

}