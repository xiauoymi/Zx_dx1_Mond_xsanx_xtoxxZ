package com.monsanto.wst.humanrightspolicy.businessPartner.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.humanrightspolicy.Security.service.SecurityService;
import com.monsanto.wst.humanrightspolicy.Security.service.tests.mock.MockSecurityService;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.tests.mock.MockLookupBPService;
import com.monsanto.wst.humanrightspolicy.config.mock.MockConfiguration;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.services.tests.mock.MockGeographicalLocationReferenceDataService;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.Comparator;
import java.util.Date;
import java.util.List;

/*
 BusinessPartnerDataSource_UT was created on Apr 23, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class BusinessPartnerDataSource_UT extends XMLTestCase {

  private BusinessPartnerDataSource getDataSource(UCCHelper helper) {
    LookupBPService mockLookupService = new MockLookupBPService(null);
    SecurityService mockSecurityService = new MockSecurityService(new MockGeographicalLocationReferenceDataService());
    return new BusinessPartnerDataSource(helper, mockLookupService, mockSecurityService, new MockConfiguration());
  }

  public void testGetDAta_AccentedCharacter_ConvertedToUtf8() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setRequestParameterValue("scope", "My");
    helper.setRequestParameterValue("businessName", "fárms");
    helper.setRequestParameterValue("sapId", "fárms");
    helper.setRequestParameterValue("hrpType", "Internal");
    helper.setRequestParameterValue("hrpFlag", "Y");
    helper.setRequestParameterValue("country", "11");
    helper.setRequestParameterValue("state", "22");
    helper.setRequestParameterValue("region", "33");
    helper.setRequestParameterValue("recent", "true");
    helper.setRequestParameterValue("filterValue", "fárms");
    helper.setRequestParameterValue(HRPMainConstants.MENU, "myBp");
    MockLookupBPService mockLookupService = new MockLookupBPService(null);
    SecurityService mockSecurityService = new MockSecurityService(new MockGeographicalLocationReferenceDataService());
    BusinessPartnerDataSource dataSource = new BusinessPartnerDataSource(helper, mockLookupService, mockSecurityService,
        new MockConfiguration());
    dataSource.getData();
    assertEquals("f�rms", mockLookupService.getBpCriteria().getEntityName());
    assertEquals("f�rms", mockLookupService.getBpCriteria().getSapId());
    assertEquals("f�rms", mockLookupService.getFilterValue());
    assertEquals("Internal", mockLookupService.getBpCriteria().getHrpTypes());
    assertEquals("Y", mockLookupService.getBpCriteria().getHrpFlag());
    assertEquals("11", mockLookupService.getBpCriteria().getAddress().getCountryModel().getId());
    assertEquals("22", mockLookupService.getBpCriteria().getAddress().getStateModel().getId());
    assertEquals("33", mockLookupService.getBpCriteria().getAddress().getRegionModel().getId());
    assertTrue(mockLookupService.getBpCriteria().getAddBPDate().before(new Date()));
  }

  public void testAddBPDateIsNullWhenNotNeeded() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setRequestParameterValue("scope", "My");
    helper.setRequestParameterValue("businessName", "fárms");
    helper.setRequestParameterValue("sapId", "fárms");
    helper.setRequestParameterValue("filterValue", "fárms");
    helper.setRequestParameterValue(HRPMainConstants.MENU, "myBp");
    MockLookupBPService mockLookupService = new MockLookupBPService(null);
    SecurityService mockSecurityService = new MockSecurityService(new MockGeographicalLocationReferenceDataService());
    BusinessPartnerDataSource dataSource = new BusinessPartnerDataSource(helper, mockLookupService, mockSecurityService,
        new MockConfiguration());
    dataSource.getData();
    assertNull(mockLookupService.getBpCriteria().getAddBPDate());
  }


  public void testGetData_ForRecentBP_PassesCorrectDateToLookupBPService() throws Exception {
    MockLookupBPService lookupBPService = new MockLookupBPService(null);
    SecurityService mockSecurityService = new MockSecurityService(new MockGeographicalLocationReferenceDataService());
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setRequestParameterValue("scope", "My");
    helper.setRequestParameterValue("recent", "true");
    helper.setRequestParameterValue(HRPMainConstants.MENU, "myBp");
    BusinessPartnerDataSource dataSource = new BusinessPartnerDataSource(helper, lookupBPService, mockSecurityService,
        new MockConfiguration());
    dataSource.getData();

    BusinessPartner criteriaPassed = lookupBPService.getBpCriteria();
    assertNotNull(criteriaPassed);
    assertNotNull(criteriaPassed.getAddBPDate());
    assertTrue(criteriaPassed.getAddBPDate().before(new Date()));
  }

/* this test is no longer applicable on this class as the fitlering is happening in SQL -- this might be a good idea for an AT
  public void testGetDAta_EditRole_ScopeIsMy_UserHasAccessToOnlyIllinois_ResultNodesReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setRequestParameterValue("scope", "My");
    helper.setRequestParameterValue("businessName", "fárms");
    helper.setRequestParameterValue("sapId", "fárms");
    helper.setRequestParameterValue(HRPMainConstants.MENU, "myBp");
    BusinessPartnerDataSource dataSource = getDataSource(helper);
    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(1, data.size());
    Document bpDoc = DOMUtil.stringToXML(data.get(0).toXml());

    assertXpathEvaluatesTo("0000001234", "/bp/sapId", bpDoc);
    assertXpathEvaluatesTo("ABC / REL", "/bp/bpName", bpDoc);
    assertXpathEvaluatesTo("UNITED STATES OF AMERICA", "/bp/country", bpDoc);
    assertXpathEvaluatesTo("ILLINOIS", "/bp/state", bpDoc);
    assertXpathEvaluatesTo("NALAN", "/bp/region", bpDoc);
    assertXpathEvaluatesTo("Y", "/bp/hrpFlag", bpDoc);
    assertXpathEvaluatesTo("/humanrightspolicy/servlet/businessPartner?method=lookupBP&businessPartnerId=11&menu=",
        "/bp/viewUrl", bpDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/servlet/searchBusinessPartner?method=setHrpFlagInBP&businessPartnerId=11&hrpFlag=Y",
        "/bp/addUrl", bpDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/servlet/searchBusinessPartner?method=setHrpFlagInBP&businessPartnerId=11&hrpFlag=N",
        "/bp/removeUrl", bpDoc);
//todo Is this still used?    assertXpathEvaluatesTo("true", "/bp/isEditable", bpDoc);
  }
*/

  public void testGetData_DontSearchIsFalse_ScopeIsAll_ResultNodesReturned() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setRequestParameterValue("scope", "All");
    helper.setRequestParameterValue(HRPMainConstants.MENU, "myBp");
    helper.setRequestParameterValue(HRPMainConstants.DONT_SEARCH, "false");

    BusinessPartnerDataSource dataSource = getDataSource(helper);
    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(2, data.size());
    Document bpDoc1 = DOMUtil.stringToXML(data.get(0).toXml());
    Document bpDoc2 = DOMUtil.stringToXML(data.get(1).toXml());

    assertXpathEvaluatesTo("0000001234", "/bp/sapId", bpDoc1);
    assertXpathEvaluatesTo("Reliance Petro <br /> REL", "/bp/bpName", bpDoc1);
    assertXpathEvaluatesTo("GROWER, LABOR", "/bp/hrpTypesAsString", bpDoc1);
    assertXpathEvaluatesTo("UNITED STATES OF AMERICA", "/bp/country", bpDoc1);
    assertXpathEvaluatesTo("VIRGINIA", "/bp/state", bpDoc1);
    assertXpathEvaluatesTo("NALAN", "/bp/region", bpDoc1);
    assertXpathEvaluatesTo("Y", "/bp/hrpFlag", bpDoc1);
    assertXpathEvaluatesTo("/humanrightspolicy/servlet/businessPartner?method=lookupBP&businessPartnerId=12&menu=",
        "/bp/viewUrl", bpDoc1);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/servlet/searchBusinessPartner?method=setHrpFlagInBP&businessPartnerId=12&hrpFlag=Y",
        "/bp/addUrl", bpDoc1);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/servlet/searchBusinessPartner?method=setHrpFlagInBP&businessPartnerId=12&hrpFlag=N",
        "/bp/removeUrl", bpDoc1);
//todo is this still used?    assertXpathEvaluatesTo("false", "/bp/isEditable", bpDoc1);

    assertXpathEvaluatesTo("0000001234", "/bp/sapId", bpDoc2);
    assertXpathEvaluatesTo("ABC <br /> REL", "/bp/bpName", bpDoc2);
    assertXpathEvaluatesTo("", "/bp/hrpTypesAsString", bpDoc2);
    assertXpathEvaluatesTo("UNITED STATES OF AMERICA", "/bp/country", bpDoc2);
    assertXpathEvaluatesTo("ILLINOIS", "/bp/state", bpDoc2);
    assertXpathEvaluatesTo("NALAN", "/bp/region", bpDoc2);
    assertXpathEvaluatesTo("Y", "/bp/hrpFlag", bpDoc2);
    assertXpathEvaluatesTo("/humanrightspolicy/servlet/businessPartner?method=lookupBP&businessPartnerId=11&menu=",
        "/bp/viewUrl", bpDoc2);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/servlet/searchBusinessPartner?method=setHrpFlagInBP&businessPartnerId=11&hrpFlag=Y",
        "/bp/addUrl", bpDoc2);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/servlet/searchBusinessPartner?method=setHrpFlagInBP&businessPartnerId=11&hrpFlag=N",
        "/bp/removeUrl", bpDoc2);
//todo is this still used?    assertXpathEvaluatesTo("false", "/bp/isEditable", bpDoc2);
  }

  public void testDefaultBusinessPartnerSort() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setRequestParameterValue("scope", "All");

    BusinessPartnerDataSource dataSource = getDataSource(helper);
    Comparator<? extends XmlObject> comparator = dataSource.getComparator(null);
    assertNotNull(comparator);
    assertTrue(comparator instanceof BusinessPartnerDefaultComparator);
  }

  public void testOtherBPSorts() throws Exception {
    MockUCCHelper helper = new MockUCCHelper("MOCK");
    helper.setRequestParameterValue("scope", "All");

    BusinessPartnerDataSource dataSource = getDataSource(helper);
    assertTrue(
        dataSource.getComparator(BusinessPartnerDataSource.SAPID_SORT_KEY) instanceof BusinessPartnerSAPIDComparator);
    assertTrue(
        dataSource.getComparator(BusinessPartnerDataSource.NAME_SORT_KEY) instanceof BusinessPartnerNameComparator);
    assertTrue(
        dataSource.getComparator(BusinessPartnerDataSource.REGION_SORT_KEY) instanceof BusinessPartnerRegionComparator);
    assertTrue(dataSource
        .getComparator(BusinessPartnerDataSource.COUNTRY_SORT_KEY) instanceof BusinessPartnerCountryComparator);
    assertTrue(
        dataSource.getComparator(BusinessPartnerDataSource.STATE_SORT_KEY) instanceof BusinessPartnerStateComparator);
    assertTrue(dataSource
        .getComparator(BusinessPartnerDataSource.HRP_TYPES_SORT_KEY) instanceof BusinessPartnerHrpTypeComparator);
  }
}