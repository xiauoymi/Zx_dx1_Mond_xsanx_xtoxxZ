/*
 SearchBPServiceImple_UT was created on Oct 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.search.tests;

import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerResult;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.tests.mock.MockLookupBPDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPServiceImpl;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: LookupBPServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-25 16:51:06 $
 *
 * @author sspati1
 * @version $Revision: 1.8 $
 */
public class LookupBPServiceImpl_UT extends TestCase {

  public void testCreate() throws Exception {
    LookupBPService service = new LookupBPServiceImpl(null);
    assertNotNull(service);
  }

  public void testSearchBP_Returns2Results() throws Exception {
    LookupBPService service = new LookupBPServiceImpl(new MockLookupBPDAO(null));
    BusinessPartnerImpl bp = new BusinessPartnerImpl(null, "12345", null, null, null, null, null, null, null, null);
    BusinessPartnerResult result = service.lookupBPByCriteria(bp, false, null, null, "", null, null);
    assertNotNull(result);
    assertEquals(2, result.getTotalRecords());
    List list = result.getData();
    assertNotNull(list);
    assertTrue(list.get(0) instanceof BusinessPartnerImpl);
    assertEquals(2, list.size());
  }

  public void testSearchBP_ReturnsEmptyList() throws Exception {
    LookupBPService service = new LookupBPServiceImpl(new MockLookupBPDAO(null));
    BusinessPartnerImpl bp = new BusinessPartnerImpl(null, "09876", null, null, null, null, null, null, null, null);
    BusinessPartnerResult result = service.lookupBPByCriteria(bp, false, null, null, "", null, null);
    assertNotNull(result);
    assertEquals(0, result.getTotalRecords());
    List list = result.getData();
    assertNotNull(list);
    assertEquals(0, list.size());
  }

  public void testLookupBPById_ReturnsABP() throws Exception {
    BusinessPartner bp = new BusinessPartnerImpl("1", "1234", "5678", "PARTNER_NAME", "ALIAS_NAME",
        "wwww.bp.com", null, null, null, null);
    LookupBPService service = new LookupBPServiceImpl(new MockLookupBPDAO(bp));
    bp = service.lookupBPById("1");
    assertNotNull(bp);
    assertEquals("1", bp.getPartnerId());
    assertEquals("0000001234", bp.getSapId());
    assertEquals("5678", bp.getLegacyId());
    assertEquals("PARTNER_NAME", bp.getEntityName());
    assertEquals("ALIAS_NAME", bp.getAliasName());
    assertEquals("wwww.bp.com", bp.getWebsiteUrl());
  }
  
}