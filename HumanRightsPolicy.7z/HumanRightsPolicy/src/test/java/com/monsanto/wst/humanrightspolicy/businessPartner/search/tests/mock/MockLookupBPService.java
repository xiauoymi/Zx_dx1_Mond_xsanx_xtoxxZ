/*
 MockSearchBPService was created on Oct 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.search.tests.mock;

import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerResult;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.tests.mock.MockBusinessPartnerDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockBusinessPartnerImpl;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockLookupBPService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $
 * On:	$Date: 2008-08-27 20:08:26 $
 *
 * @author sspati1
 * @version $Revision: 1.17 $
 */
public class MockLookupBPService implements LookupBPService {
  private final BusinessPartner bp;
  private BusinessPartner bpCriteria;
  private String filterValue;

  public MockLookupBPService(BusinessPartner bp) {
    this.bp = bp;
  }

  public BusinessPartner lookupBPById(String bpId) {
    return this.bp;
  }

  public BusinessPartnerResult lookupBPByCriteria(BusinessPartner bp, boolean myBPScope, LoginUser user, String sortKey,
                                                  String filterValue, Integer startRecord, Integer endRecord) {
    this.bpCriteria = bp;
    this.filterValue = filterValue;
    List<BusinessPartner> bpList = new ArrayList<BusinessPartner>();
    BusinessPartnerImpl businessPartner;
    if (bp != null && bp.getPartnerId() != null && bp.getPartnerId().equalsIgnoreCase("1")) {
      businessPartner = new BusinessPartnerImpl("1", "1234", "5678", "ABC", "REL", "Y", "Y",
          "Y", null, "1", "UNITED STATES OF AMERICA", "2", "ILLINOIS", "2", "NALAN", "1", "StreetAddress 1",
          "StreetAddress 2",
          "STL", "63303", null, null, null);
      bpList.add(businessPartner);
    } else {
//    businessPartner = new BusinessPartnerImpl("12", "1234", "5678", "Reliance Petro", "REL",
//        "Y", "Y", "Y", "GROWER, LABOR", "1", "UNITED STATES OF AMERICA", "10", "VIRGINIA", "2", "NALAN", "1", "StreetAddress 1", "StreetAddress 2",
//          "STL", "63303", null, null);
//      bpList.add(businessPartner);
      Address address = new Address(null, "StreetAddress 1", "StreetAddress 2", "STL", "63303",
          new StateProvince("10", "VIRGINIA"
          ), new Country("1", "UNITED STATES OF AMERICA"), new Region("2", "NALAN"));
      businessPartner = new MockBusinessPartnerImpl("12", "Reliance Petro", "REL", "1234", "Y", "Y", address, null, null,
          new MockBusinessPartnerDAO("GROWER, LABOR", null));
      bpList.add(businessPartner);
    }
//    businessPartner = new BusinessPartnerImpl("11", "1234", "5678", "ABC", "REL", "Y", "Y",
//        "Y", "", "1", "UNITED STATES OF AMERICA", "2", "ILLINOIS", "2", "NALAN", "1", "StreetAddress 1",
//        "StreetAddress 2",
//        "STL", "63303", null, null);
//    bpList.add(businessPartner);
    Address address = new Address(null, "StreetAddress 1", "StreetAddress 2", "STL", "63303",
        new StateProvince("2", "ILLINOIS"
        ), new Country("1", "UNITED STATES OF AMERICA"), new Region("2", "NALAN"));
    businessPartner = new MockBusinessPartnerImpl("11", "ABC", "REL", "1234", "Y", "Y", address, null, null,
        new MockBusinessPartnerDAO("", null));
    bpList.add(businessPartner);
    return new BusinessPartnerResult(bpList, bpList.size());
  }

  public BusinessPartner getBpCriteria() {
    return bpCriteria;
  }

  public String getFilterValue() {
    return filterValue;
  }


}