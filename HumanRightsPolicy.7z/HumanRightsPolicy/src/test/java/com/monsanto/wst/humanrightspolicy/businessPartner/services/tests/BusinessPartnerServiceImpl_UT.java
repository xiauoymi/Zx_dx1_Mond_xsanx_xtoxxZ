/*
 BusinessPartnerServiceImpl_UT was created on Apr 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.businessPartner.services.tests;

import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.services.BusinessPartnerService;
import com.monsanto.wst.humanrightspolicy.businessPartner.services.BusinessPartnerServiceImpl;
import com.monsanto.wst.humanrightspolicy.model.HrpType;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: BusinessPartnerServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-09-19 16:01:25 $
 *
 * @author sspati1
 * @version $Revision: 1.71 $
 */
public class BusinessPartnerServiceImpl_UT extends TestCase {

  public void testLookupAllHrpTypes() throws Exception {
    MockDAO<HrpType, Long> hrpTypeDao = new MockDAO<HrpType, Long>();
    BusinessPartnerService service = new BusinessPartnerServiceImpl(hrpTypeDao);
    service.lookupAllHrpTypes();
    assertTrue(hrpTypeDao.wasFindAllCalled());
  }
}