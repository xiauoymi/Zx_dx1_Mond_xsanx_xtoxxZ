package com.monsanto.wst.humanrightspolicy.communication.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.action.ActionConstants;
import com.monsanto.wst.humanrightspolicy.action.controller.mock.MockActionService;
import com.monsanto.wst.humanrightspolicy.action.mock.MockActionDAO;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.controller.CommActionItemsController;
import com.monsanto.wst.humanrightspolicy.communication.service.tests.mock.MockCommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockCommunication;
import org.custommonkey.xmlunit.XMLTestCase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 26, 2008
 * Time: 1:48:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommActionItemsController_UT extends XMLTestCase {
    private MockUCCHelper helper = null;
    private MockDAO<Action, Long> actiondao;
    private MockDAO<Status, Long> statusdao;
    private MockDAO<ActionPriority, Long> prioritydao;
    private MockDAO<LoginUser, Long> userDao;
    private MockDAO<Assignment, Long> assignmentDao;

    protected void setUp() throws Exception {
        super.setUp();
        helper = new MockUCCHelper(null);
        actiondao = new MockActionDAO();
        statusdao = new MockDAO<Status, Long>();
        prioritydao = new MockDAO<ActionPriority, Long>();
        userDao = new MockDAO<LoginUser, Long>();
        assignmentDao = new MockDAO<Assignment, Long>();
    }

/*
// disabled failing test for part of HRP not in use
  public void testAddActionItem_ToCommunicationPlan() throws Exception {
    setRequestParameters();
    List<Communication> comms = getCommunicationList();
    MockActionService actionService = new MockActionService(actiondao, statusdao, prioritydao, userDao, assignmentDao);
    MockCommunicationService commService = new MockCommunicationService(comms);
    CommActionItemsController controller = new CommActionItemsController(commService, actionService);
    controller.run(helper);
    MockCommunication mockCommunication = commService.getComm();
    assertNotNull(mockCommunication);
    assertTrue(commService.isAddActionItemCalled());
    assertTrue(commService.getNumOfActionItemsAdded() == 1);
  }
*/

    private void setRequestParameters() {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "22");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "addActionItem");
        helper.setRequestParameterValue(ActionConstants.ACTION_NAME, "action1");
        helper.setRequestParameterValue(ActionConstants.ACTION_DUE_DATE, "2008-07-02");
        helper.setRequestParameterValue(ActionConstants.ACTION_START_DATE, "2008-07-02");
        helper.setRequestParameterValue(ActionConstants.ACTION_DATE_COMPLETED, "2008-08-02");
        helper.setRequestParameterValue(ActionConstants.ACTION_STATUS, "1");
        helper.setRequestParameterValue(ActionConstants.ACTION_PRIORITY, "1");
        helper.setRequestParameterValue(ActionConstants.ACTION_PERCENT_COMPLETE, "50");
        helper.setRequestParameterValue(ActionConstants.ACTION_DESCRIPTION, "action1 desc");
    }

    private void addActionItemToCommPlan() throws IOException {
        List<Communication> comms = getCommunicationList();
        MockActionService actionService = new MockActionService(actiondao, statusdao, prioritydao, userDao, assignmentDao);
        MockCommunicationService commService = new MockCommunicationService(comms);
        CommActionItemsController controller = new CommActionItemsController(commService, actionService);
        controller.run(helper);
    }

/*
// disabled failing test for part of HRP not in use

  public void testAddActionItem_ToCommunicationPlan_CheckIfACTIONAttributeIsSet() throws Exception {
    setRequestParameters();
    addActionItemToCommPlan();
    assertNotNull(helper.getRequestAttributeValue(ActionConstants.ACTION));
  }
*/

    public void testlookupActionItemOnCommunicationPlanXML() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "22");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "lookupActionItemOnCommunicationPlanXML");
        List<Communication> comms = getCommunicationList();
        MockActionService actionService = new MockActionService(actiondao, statusdao, prioritydao, userDao, assignmentDao);
        MockCommunicationService commService = new MockCommunicationService(comms);
        CommActionItemsController controller = new CommActionItemsController(commService, actionService);
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertNotNull(mockCommunication);
        assertNotNull(mockCommunication.getActionItemsAsList());
        assertTrue(mockCommunication.getActionItemsAsList().size() == 1);
        assertNotNull(helper.getXML());
    }

    public void testlookupActionItemOnCommunicationPlanAsList_IfACTION_ITEMS_ON_COMMAttributeIsSet() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "22");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "lookupActionItemOnCommunicationPlanAsList");
        addActionItemToCommPlan();
        List<Action> actionsList = (List<Action>) helper.getRequestAttributeValue(CommunicationConstants.ACTION_ITEMS_ON_COMM);
        assertNotNull(actionsList);
        assertEquals(1, actionsList.size());
    }

/*
// disabled failing test for part of HRP not in use

  public void testAddActionItem_ToCommunicationPlan_CheckIfACTION_ITEMS_ON_COMMAttributeIsSet() throws Exception {
    setRequestParameters();
    addActionItemToCommPlan();
    List<Action> actionsList = (List<Action>) helper.getRequestAttributeValue(CommunicationConstants.ACTION_ITEMS_ON_COMM);
    assertNotNull(actionsList);
    assertEquals(1, actionsList.size());
  }
*/

    private List<Communication> getCommunicationList() {
        List<Communication> comms = new ArrayList<Communication>();
        comms.add(new CommunicationImpl("11", "commName1", "comm notes1", getDate(1), getDate(2), getDate(3), "Y",
                null, null, 1L, "Letter", 4L, "New", 2L, "Contact", 3L, "Main", "111", null));
        comms.add(new CommunicationImpl("22", "commName2", "comm notes2", getDate(1), getDate(2), getDate(3), "Y", null,
                null, 5L, "Training", 8L, "Open", 6L, "Worker", 7L, "Plant", "222", null));
        return comms;
    }

    private Date getDate(int numDaysToAdd) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, numDaysToAdd);
        return cal.getTime();
    }
}
