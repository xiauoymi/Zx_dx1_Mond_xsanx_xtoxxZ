/*
 CommRecipientController_AT was created on Aug 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.controller.CommRecipientController;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommunicationDAO;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.testUtils.HumanRightsPolicyDatabaseTestCase;
import com.monsanto.wst.humanrightspolicy.testUtils.mock.MockUCCHelperForHrp;
import org.w3c.dom.Document;

import java.util.List;

/**
 * Filename:    $RCSfile: CommRecipientController_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:21 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public class CommRecipientController_AT extends HumanRightsPolicyDatabaseTestCase {

  private MockUCCHelper helper;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelperForHrp("hrpAT");
  }

  public void testUpdateDoneFlag_UserChecksLastRecipientAsComplete_PromptsThatCommunicationIsReadyForCompletion() throws
      Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(CommunicationConstants.RECIPIENT_ID, "1");
    helper.setRequestParameterValue(CommunicationConstants.DONE_FLAG, "Y");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateDoneFlag");
    CommRecipientController controller = new CommRecipientController();
    controller.run(helper);
    Document resultsDoc = helper.getXML();
    String xmlStr = DOMUtil.XMLToString(resultsDoc);
    assertTrue(xmlStr.indexOf("<areAllRecipientsMarkedAsDone>true</areAllRecipientsMarkedAsDone>") > 0);
    assertTrue(xmlStr.indexOf("<isCommunicationReadyForCompletion>true</isCommunicationReadyForCompletion>") > 0);
  }

  public void testUpdateDoneFlagForSelectedRecipients_AllSelected() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
    helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
    helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(CommunicationConstants.DONE_FLAG, "Y");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateDoneFlagForSelectedRecipients");
    CommRecipientController controller = new CommRecipientController();
    controller.run(helper);
    List<CommRecipient> commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(3, commRecipients.size());
    assertEquals("Y", commRecipients.get(0).getIsDone());
    assertEquals("Y", commRecipients.get(1).getIsDone());
    validateAttributesInHelper();
    assertEquals("true",
        helper.getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE).toString());
    assertEquals("true",
        helper.getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION).toString());

    assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
  }

  public void testUpdateDoneFlagForSelectedRecipients_WithFilterAllSelected_Only1RecipientUpdated() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
    helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
    helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
    helper.setRequestParameterValue("filterValue", "bp with"); //filter on bp name
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(CommunicationConstants.DONE_FLAG, "Y");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateDoneFlagForSelectedRecipients");
    CommRecipientController controller = new CommRecipientController();
    controller.run(helper);
    List<CommRecipient> commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(3, commRecipients.size());
    assertEquals("Y", commRecipients.get(0).getIsDone());
    assertEquals("1", commRecipients.get(1).getContactId());
    assertEquals("N", commRecipients.get(1).getIsDone());
    validateAttributesInHelper();
    assertEquals("false",
        helper.getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE).toString());
    assertEquals("false",
        helper.getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION).toString());

    assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
  }

  public void testUpdateDoneFlagForSelectedRecipients_NotAllSelected() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
    helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "2");
    helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(CommunicationConstants.DONE_FLAG, "Y");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateDoneFlagForSelectedRecipients");
    CommRecipientController controller = new CommRecipientController();
    controller.run(helper);
    List<CommRecipient> commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(3, commRecipients.size());
    assertEquals("Y", commRecipients.get(0).getIsDone());
    assertEquals("N", commRecipients.get(1).getIsDone());
    validateAttributesInHelper();
    assertEquals("false",
        helper.getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE).toString());
    assertEquals("false",
        helper.getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION).toString());

    assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
  }

  public void testDeleteSelectedRecipients_NotAllSelected_RecipientIsNoLongerAssociatedWithTheCommunication() throws
      Exception {
    helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
    helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "1");
    helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
    helper.setRequestParameterValue("filterValue", "");
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteSelectedRecipients");

    List<CommRecipient> commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(3, commRecipients.size());

    CommRecipientController controller = new CommRecipientController();
    controller.run(helper);

    commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(2, commRecipients.size());
    assertEquals("2", commRecipients.get(0).getContactId());
  }

  public void testDeleteSelectedRecipients_NotAllSelectedWithFilter_RecipientIsNoLongerAssociatedWithTheCommunication() throws
      Exception {
    helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
    helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "1");
    helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
    helper.setRequestParameterValue("filterValue", "RAMBABU");
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteSelectedRecipients");

    List<CommRecipient> commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(3, commRecipients.size());

    CommRecipientController controller = new CommRecipientController();
    controller.run(helper);

    commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(2, commRecipients.size());
    assertEquals("2", commRecipients.get(0).getContactId());
  }

  public void testDeleteSelectedRecipients_AllSelectedWithExclude_RecipientIsNoLongerAssociatedWithTheCommunication() throws
      Exception {
    helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
    helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
    helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "4");
    helper.setRequestParameterValue("filterValue", "");
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteSelectedRecipients");

    List<CommRecipient> commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(3, commRecipients.size());

    CommRecipientController controller = new CommRecipientController();
    controller.run(helper);

    commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(1, commRecipients.size());
    assertEquals("4", commRecipients.get(0).getContactId());
  }

  public void testDeleteSelectedRecipients_WithFilterAllSelected_RecipientIsNoLongerAssociatedWithTheCommunication() throws
      Exception {
    helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
    helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
    helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
    helper.setRequestParameterValue("filterValue", "RAMBABU");
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteSelectedRecipients");

    List<CommRecipient> commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(3, commRecipients.size());

    CommRecipientController controller = new CommRecipientController();
    controller.run(helper);

    commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(1, commRecipients.size());
  }

  public void testDeleteSelectedRecipients_WithFilterAllSelectedWithExclude_RecipientIsNoLongerAssociatedWithTheCommunication() throws
      Exception {
    helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
    helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
    helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "4");
    helper.setRequestParameterValue("filterValue", "RAMBABU");
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteSelectedRecipients");

    List<CommRecipient> commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(3, commRecipients.size());

    CommRecipientController controller = new CommRecipientController();
    controller.run(helper);

    commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(2, commRecipients.size());
    assertEquals("2", commRecipients.get(0).getContactId());
  }

  public void testAddRecipient_FirstRecipientAndStatusIsOpen_StatusChangesToPending() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "4");
    helper.setRequestParameterValue(CommunicationConstants.RECIPIENT_ID, "4");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "addRecipient");

    CommunicationDAO commDao = getCommunicationDAO();
    CommRecipientDAO commRecpientDao = getCommRecipientDAO();

    List<CommRecipient> commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("4");
    assertEquals(0, commRecipients.size());
    Communication comm = commDao.lookupCommunicationById("4");
    assertEquals("OPEN1", comm.getStatus().getStatus());

    CommRecipientController controller = new CommRecipientController();
    controller.run(helper);

    commRecipients = commRecpientDao.lookupRecipientsByCommId("4");
    assertEquals(1, commRecipients.size());
    //cannot test that status changed to pending because the origina status is open1 and not open

    getCommRecipientDAO().deleteAllRecipients("4");
  }

  public void testUpdateDoneFlagForAllRecipients_UserClicksOnMarkAllAsComplete_PromptsThatCommunicationIsReadyForCompletionAndAllRecipientsAreMarkedAsComplete() throws
      Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateDoneFlagForAllRecipients");

    CommRecipientController controller = new CommRecipientController();
    controller.run(helper);

    List<CommRecipient> commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(3, commRecipients.size());
    assertEquals("Y", commRecipients.get(0).getIsDone());
    assertEquals("Y", commRecipients.get(1).getIsDone());
    validateAttributesInHelper();
    assertEquals("true",
        helper.getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE).toString());
    assertEquals("true",
        helper.getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION).toString());

    assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
  }

  public void testExportDistributionListForCommunication() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(CommunicationConstants.SET_TO_DISTRIBUTED, "Y");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, "lookupRecipientsForDistributionListXML");

    CommRecipientController controller = new CommRecipientController();
    controller.run(helper);
    List<CommRecipient> recipientDistributionList = getCommRecipientDAO().lookupRecipientsByCommId("1");
    assertEquals(3, recipientDistributionList.size());
  }

  private CommRecipientDAO getCommRecipientDAO() {
    DBTemplateImpl template = new DBTemplateImpl("database/dbtemplate-config.xml",
        new String[]{"database/dbtemplate.xml"});
    return new DBTemplateCommRecipientDAO(template);
  }

  private CommunicationDAO getCommunicationDAO() {
    DBTemplateImpl template = new DBTemplateImpl("database/dbtemplate-config.xml",
        new String[]{"database/dbtemplate.xml"});
    return new DBTemplateCommunicationDAO(template, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
  }

  private void validateAttributesInHelper() {
    assertNotNull(helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION));
    assertNotNull(helper.getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE));
    assertNotNull(helper.getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION));
    validateReferenceData();
  }

  private void validateReferenceData() {
    List<CommType> commTypeList = (List<CommType>) helper
        .getRequestAttributeValue(CommunicationConstants.COMM_TYPE_LIST);
    assertTrue(commTypeList.size() > 0);
    List<ContactType> recipientTypeList = (List<ContactType>) helper
        .getRequestAttributeValue(BusinessPartnerConstants.LOC_CON_REL_TYPE_LIST);
    assertTrue(recipientTypeList.size() >= 2);
    List<LocationType> locationTypeList = (List<LocationType>) helper
        .getRequestAttributeValue(LocationsConstants.BP_LOC_REL_TYPE_LIST);
    assertTrue(locationTypeList.size() >= 2);
  }

}