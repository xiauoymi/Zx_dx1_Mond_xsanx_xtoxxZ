/*
 CommRecipientController_UT was created on Aug 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.controller.BaseCommunicationController;
import com.monsanto.wst.humanrightspolicy.communication.controller.CommRecipientController;
import com.monsanto.wst.humanrightspolicy.communication.controller.tests.mock.MockCommunicationServiceAllDoneAndComplete;
import com.monsanto.wst.humanrightspolicy.communication.datasource.RecipientDataSource;
import com.monsanto.wst.humanrightspolicy.communication.datasource.mock.MockRecipientDataSource;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.communication.service.tests.mock.MockCommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.location.service.tests.mock.MockLocationService;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockCommunication;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommRecipientController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:21 $
 *
 * @author sspati1
 * @version $Revision: 1.8 $
 */
public class CommRecipientController_UT extends XMLTestCase {
    private MockUCCHelper helper = null;

    protected void setUp() throws Exception {
        super.setUp();
        helper = new MockUCCHelper(null);
    }

    public void testLookupRecipientsXMLForDistributionList_DontLockDeliveryList_StatusRemiansUnchangedValidateXML() throws
            Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.SET_TO_DISTRIBUTED, "N");
        helper.setRequestParameterValue(HRPMainConstants.MENU, "allComm");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "lookupRecipientsForDistributionListXML");
        List<Communication> comms = getCommunicationList();
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        CommRecipientController controller = new CommRecipientController(commService,
                lcoationService, new MockDAO<ContactType, Long>());
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertNotNull(mockCommunication);
        assertNotNull(mockCommunication.getRecipients());
        assertFalse(commService.isUpdateCommunicationCalled());
    }

    public void testLookupRecipientsXMLForDistributionList_LockDeliveryList_StatusChangesToReadyValidateXML() throws
            Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.SET_TO_DISTRIBUTED, "Y");
        helper.setRequestParameterValue(HRPMainConstants.MENU, "allComm");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "lookupRecipientsForDistributionListXML");
        List<Communication> comms = getCommunicationList();
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        CommRecipientController controller = new CommRecipientController(commService,
                lcoationService, new MockDAO<ContactType, Long>());
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertNotNull(mockCommunication);
        assertNotNull(mockCommunication.getRecipients());
        assertTrue(commService.isUpdateCommunicationCalled());
        MockCommunication comm = commService.getComm();
        assertEquals("11", comm.getId());
        assertEquals("commName1", comm.getName());
        assertEquals("comm notes1", comm.getNotes());
        assertEquals(getFormattedDate(getDate(1)), comm.getFormattedFromDate());
        assertEquals(getFormattedDate(getDate(2)), comm.getFormattedToDate());
        assertEquals(getFormattedDate(getDate(3)), comm.getFormattedDueDate());
        assertEquals("Y", comm.getActive());
        assertEquals(new Long(1), comm.getCommType().getId());
        assertEquals("Letter", comm.getCommType().getType());
        assertEquals(new Long(2), comm.getLocConRelType().getId());
        assertEquals("Contact", comm.getLocConRelType().getType());
        assertEquals(new Long(3), comm.getBpLocRelType().getId());
        assertEquals("Main", comm.getBpLocRelType().getType());
        assertEquals(new Long(33L), comm.getStatus().getId());//Ready status
    }

    public void testUpdateDoneFlag_ReturnsFalseForareAllRecipientsMarkedAsDone() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.RECIPIENT_ID, "12");
        helper.setRequestParameterValue(CommunicationConstants.DONE_FLAG, "N");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateDoneFlag");
        List<Communication> comms = getCommunicationList();
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        CommRecipientController controller = new CommRecipientController(commService,
                lcoationService, new MockDAO<ContactType, Long>());
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertTrue(mockCommunication.isUpdateDoneFlagForRecipientCalled());
        Document resultsDoc = helper.getXML();
        assertXpathEvaluatesTo("1", "count(//response)", resultsDoc);
        assertXpathEvaluatesTo("1", "count(//result)", resultsDoc);
        assertXpathEvaluatesTo("false", "//result/areAllRecipientsMarkedAsDone", resultsDoc);
        assertXpathEvaluatesTo("false", "//result/isCommunicationReadyForCompletion", resultsDoc);
    }

    public void testUpdateDoneFlagForSelected_NotAllSelected() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "1,2,3");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");

        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.DONE_FLAG, "N");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateDoneFlagForSelectedRecipients");
        List<Communication> comms = getCommunicationList();
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertTrue(mockCommunication.isUpdateDoneFlagForSelectedRecipientsCalled());
        assertEquals(3, mockCommunication.getSelectedRecipientIds().size());
        assertEquals("1", mockCommunication.getSelectedRecipientIds().get(0));
        assertEquals("2", mockCommunication.getSelectedRecipientIds().get(1));
        assertEquals("3", mockCommunication.getSelectedRecipientIds().get(2));

        validateDataInResponseForCommWithId11();
    }

    public void testUpdateDoneFlagForSelected_WithFilterNotAllSelected() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "3");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
        helper.setRequestParameterValue("filterValue", "person name 4");

        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.DONE_FLAG, "N");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateDoneFlagForSelectedRecipients");
        List<Communication> comms = getCommunicationList();
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertTrue(mockCommunication.isUpdateDoneFlagForSelectedRecipientsCalled());
        assertEquals(1, mockCommunication.getSelectedRecipientIds().size());
        assertEquals("3", mockCommunication.getSelectedRecipientIds().get(0));
        validateDataInResponseForCommWithId11();
    }

    public void testUpdateDoneFlagForSelected_AllSelected() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "2,3");

        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.DONE_FLAG, "N");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateDoneFlagForSelectedRecipients");
        List<Communication> comms = getCommunicationList();
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertTrue(mockCommunication.isUpdateDoneFlagForSelectedRecipientsCalled());
        assertEquals(1, mockCommunication.getSelectedRecipientIds().size());
        assertEquals("1", mockCommunication.getSelectedRecipientIds().get(0));
        validateDataInResponseForCommWithId11();
    }

    public void testUpdateDoneFlagForSelected_WithFilterAllSelected() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
        helper.setRequestParameterValue("filterValue", "person name 4");

        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.DONE_FLAG, "N");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateDoneFlagForSelectedRecipients");
        List<Communication> comms = getCommunicationList();
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertTrue(mockCommunication.isUpdateDoneFlagForSelectedRecipientsCalled());
        assertEquals(2, mockCommunication.getSelectedRecipientIds().size());
        assertEquals("2", mockCommunication.getSelectedRecipientIds().get(0));
        assertEquals("3", mockCommunication.getSelectedRecipientIds().get(1));
        validateDataInResponseForCommWithId11();
    }

    public void testUpdateDoneFlagForSelected_NoFilterAllSelectedNothingExcluded() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
        helper.setRequestParameterValue("filterValue", "");

        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.DONE_FLAG, "N");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateDoneFlagForSelectedRecipients");
        List<Communication> comms = getCommunicationList();
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertTrue(mockCommunication.isUpdateDoneFlagForAllRecipientsCalled());
        assertFalse(mockCommunication.isUpdateDoneFlagForSelectedRecipientsCalled());
        assertNull(mockCommunication.getSelectedRecipientIds());
        validateDataInResponseForCommWithId11();
    }

    public void testDeleteRecipient_CorrectMethodIsCalled() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.RECIPIENT_ID, "22");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteRecipient");
        List<Communication> comms = getCommunicationList();

        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        CommRecipientController controller = new CommRecipientController(commService,
                lcoationService, new MockDAO<ContactType, Long>());
        controller.run(helper);
        MockCommunication comm = commService.getComm();
        assertTrue(comm.isDeleteSelectedRecipientsCalled());
        assertEquals(1, comm.getSelectedRecipientIds().size());
        assertEquals("22", comm.getSelectedRecipientIds().get(0));
        String response = helper.getResponse();
        assertEquals("ok", response);
    }

    public void testDeleteSelectedRecipients_NotAllSelected() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "1,2");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
        helper.setRequestParameterValue("filterValue", "");
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteSelectedRecipients");
        List<Communication> comms = getCommunicationList();

        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        CommRecipientController controller = new CommRecipientController(commService,
                lcoationService, new MockDAO<ContactType, Long>());
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertFalse(commService.isUpdateCommunicationCalled());
        assertTrue(mockCommunication.isDeleteSelectedRecipientsCalled());
        assertEquals(2, mockCommunication.getSelectedRecipientIds().size());
        assertEquals("1", mockCommunication.getSelectedRecipientIds().get(0));
        assertEquals("2", mockCommunication.getSelectedRecipientIds().get(1));
        validateDataInResponseForCommWithId11();
    }

    public void testDeleteSelectedRecipients_WithFilterNotAllSelected() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "1,2");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
        helper.setRequestParameterValue("filterValue", "commName2");
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteSelectedRecipients");
        List<Communication> comms = getCommunicationList();

        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertFalse(commService.isUpdateCommunicationCalled());
        assertTrue(mockCommunication.isDeleteSelectedRecipientsCalled());
        assertEquals(2, mockCommunication.getSelectedRecipientIds().size());
        assertEquals("1", mockCommunication.getSelectedRecipientIds().get(0));
        assertEquals("2", mockCommunication.getSelectedRecipientIds().get(1));
        validateDataInResponseForCommWithId11();
    }

    public void testDeleteSelectedRecipients_AllSelectedNoFilterNoneExcluded_CommStatusUpdatedToNew() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
        helper.setRequestParameterValue("filterValue", "");
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteSelectedRecipients");
        List<Communication> comms = getCommunicationList();

        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationServiceAllDoneAndComplete(comms,
                new ArrayList<CommRecipient>());
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertTrue(commService.isUpdateCommunicationCalled());
        assertTrue(mockCommunication.isDeleteAllRecipientsCalled());
        assertFalse(mockCommunication.isDeleteSelectedRecipientsCalled());
        Boolean isCommReadyForCompletion = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION);
        assertFalse(isCommReadyForCompletion);
        Boolean areAllRecipientsMarkedAsComplete = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE);
        assertFalse(areAllRecipientsMarkedAsComplete);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertEquals("11", comm.getId());
        assertEquals("commName1", comm.getName());
        assertEquals("comm notes1", comm.getNotes());
        assertEquals(getFormattedDate(getDate(1)), comm.getFormattedFromDate());
        assertEquals(getFormattedDate(getDate(2)), comm.getFormattedToDate());
        assertEquals(getFormattedDate(getDate(3)), comm.getFormattedDueDate());
        assertEquals("Y", comm.getActive());
        assertEquals(new Long(1), comm.getCommType().getId());
        assertEquals("Letter", comm.getCommType().getType());
        assertEquals(new Long(2), comm.getLocConRelType().getId());
        assertEquals("Contact", comm.getLocConRelType().getType());
        assertEquals(new Long(3), comm.getBpLocRelType().getId());
        assertEquals("Main", comm.getBpLocRelType().getType());
        assertEquals(new Long(11L), comm.getStatus().getId());
        assertEquals("New", comm.getStatus().getStatus());

        CommRecipient commRecipient = (CommRecipient) helper
                .getRequestAttributeValue(CommunicationConstants.COMM_RECIPIENT_CRITERIA);
        assertEquals(new Long(2), commRecipient.getLocConRelType().getId());
        assertEquals("Contact", commRecipient.getLocConRelType().getType());
        assertEquals(new Long(3), commRecipient.getBpLocRelType().getId());
        assertEquals("Main", commRecipient.getBpLocRelType().getType());

        validateReferenceData();
        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
    }

    public void testDeleteSelectedRecipients_AllSelectedWithExclude() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "2");
        helper.setRequestParameterValue("filterValue", "");
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteSelectedRecipients");
        List<Communication> comms = getCommunicationList();

        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertFalse(commService.isUpdateCommunicationCalled());
        assertTrue(mockCommunication.isDeleteSelectedRecipientsCalled());
        assertEquals(2, mockCommunication.getSelectedRecipientIds().size());
        assertEquals("1", mockCommunication.getSelectedRecipientIds().get(0));
        assertEquals("3", mockCommunication.getSelectedRecipientIds().get(1));
        validateDataInResponseForCommWithId11();
    }

    public void testDeleteSelectedRecipients_WithFilterAllSelected() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "2");
        helper.setRequestParameterValue("filterValue", "person name 4");
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteSelectedRecipients");
        List<Communication> comms = getCommunicationList();

        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertFalse(commService.isUpdateCommunicationCalled());
        assertTrue(mockCommunication.isDeleteSelectedRecipientsCalled());
        assertEquals(1, mockCommunication.getSelectedRecipientIds().size());
        assertEquals("3", mockCommunication.getSelectedRecipientIds().get(0));
        validateDataInResponseForCommWithId11();
    }

    public void testDeleteSelectedRecipients_NoFilterAllSelectedNothingExcluded() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
        helper.setRequestParameterValue("filterValue", "");
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteSelectedRecipients");
        List<Communication> comms = getCommunicationList();

        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertFalse(commService.isUpdateCommunicationCalled());
        assertFalse(mockCommunication.isDeleteSelectedRecipientsCalled());
        assertTrue(mockCommunication.isDeleteAllRecipientsCalled());
        validateDataInResponseForCommWithId11();
    }

    public void testAddRecipient_StatusIsNew_StatusChangedToOpen() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.RECIPIENT_ID, "12");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "addRecipient");
        List<Communication> comms = getCommunicationList();

        List<CommRecipient> recipients = new ArrayList<CommRecipient>();
        recipients.add(new CommRecipientImpl("1", "1", "1", "Y", "person name 1", 11L, "Plant", 12L, "employee",
                "12", "India", "13", "India", "14", "Gujarat", "bp name 1", null, null, null, null, null, null, null));

        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationServiceAllDoneAndComplete(comms, recipients);
        CommRecipientController controller = new CommRecipientController(commService, lcoationService, new MockDAO<ContactType, Long>());

        controller.run(helper);
        MockCommunication comm = commService.getComm();
        assertTrue(commService.isUpdateCommunicationCalled());

        assertEquals(1, comm.getNumOfRecipientsAdded());
        String response = helper.getResponse();
        assertEquals("ok", response);
    }

    public void testAddRecipient_StatusIsNotOpen_StatusRemainsUnchanged() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.RECIPIENT_ID, "12");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "addRecipient");
        List<Communication> comms = new ArrayList<Communication>();
        comms.add(new CommunicationImpl("11", "commName1", "comm notes1", getDate(1), getDate(2), getDate(3), "Y",
                null, null, 1L, "Letter",
                4L, "Open", 2L, "Contact", 3L, "Main", "111", null));
        comms
                .add(
                        new CommunicationImpl("22", "commName2", "comm notes2", getDate(1), getDate(2), getDate(3), "Y", null,
                                null, 5L, "Training",
                                8L, "Open", 6L, "Worker", 7L, "Plant", "222", null));
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        CommRecipientController controller = new CommRecipientController(commService, lcoationService, new MockDAO<ContactType, Long>());
        controller.run(helper);
        MockCommunication comm = commService.getComm();
        assertFalse(commService.isUpdateCommunicationCalled());
        assertEquals(1, comm.getNumOfRecipientsAdded());
        String response = helper.getResponse();
        assertEquals("ok", response);
    }

    public void testAddAllRecipients_StatusIsOpen_StatusChangedToPending() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.RECIPIENT_ID, "12");
        helper.setRequestParameterValue(HRPMainConstants.MENU, "allComm");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "addAllRecipients");
        List<Communication> comms = getCommunicationList();
        LocationService lcoationService = new MockLocationService(null);
        List<CommRecipient> recipients = new ArrayList<CommRecipient>();
        recipients.add(new CommRecipientImpl("1", "1", "1", "Y", "person name 1", 11L, "Plant", 12L, "employee",
                "12", "India", "13", "India", "14", "Gujarat", "bp name 1", null, null, null, null, null, null, null));
        MockCommunicationService commService = new MockCommunicationServiceAllDoneAndComplete(comms, recipients);
        CommRecipientController controller = new CommRecipientController(commService, lcoationService, new MockDAO<ContactType, Long>());
        controller.run(helper);
        MockCommunication comm = commService.getComm();
        assertTrue(commService.isUpdateCommunicationCalled());
        assertEquals(2, comm.getNumOfRecipientsAdded());
        String response = helper.getResponse();
        assertEquals("ok", response);
    }

    public void testAddAllRecipients_StatusIsNotOpen_StatusRemainsUnchanged() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.RECIPIENT_ID, "12");
        helper.setRequestParameterValue(HRPMainConstants.MENU, "allComm");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "addAllRecipients");
        List<Communication> comms = new ArrayList<Communication>();
        comms.add(new CommunicationImpl("11", "commName1", "comm notes1", getDate(1), getDate(2), getDate(3), "Y",
                null, null, 1L, "Letter",
                4L, "Open", 2L, "Contact", 3L, "Main", "111", null));
        comms
                .add(
                        new CommunicationImpl("22", "commName2", "comm notes2", getDate(1), getDate(2), getDate(3), "Y", null,
                                null, 5L, "Training",
                                8L, "Open", 6L, "Worker", 7L, "Plant", "222", null));
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        CommRecipientController controller = new CommRecipientController(commService, lcoationService, new MockDAO<ContactType, Long>());
        controller.run(helper);
        MockCommunication comm = commService.getComm();
        assertFalse(commService.isUpdateCommunicationCalled());
        assertEquals(2, comm.getNumOfRecipientsAdded());
        String response = helper.getResponse();
        assertEquals("ok", response);
    }

    public void testUpdateFlagForAllRecipients() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateDoneFlagForAllRecipients");
        List<Communication> comms = getCommunicationList();
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(comms);
        CommRecipientController controller = new CommRecipientController(commService,
                lcoationService, new MockDAO<ContactType, Long>());
        controller.run(helper);
        MockCommunication mockCommunication = commService.getComm();
        assertTrue(mockCommunication.isUpdateDoneFlagForAllRecipientsCalled());
        Boolean isCommReadyForCompletion = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION);
        assertFalse(isCommReadyForCompletion);
        Boolean areAllRecipientsMarkedAsComplete = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE);
        assertFalse(areAllRecipientsMarkedAsComplete);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertEquals("11", comm.getId());

        validateReferenceData();

        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
    }

    private void validateDataInResponseForCommWithId11() {
        Boolean isCommReadyForCompletion = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION);
        assertFalse(isCommReadyForCompletion);
        Boolean areAllRecipientsMarkedAsComplete = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE);
        assertFalse(areAllRecipientsMarkedAsComplete);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertEquals("11", comm.getId());
        assertEquals("commName1", comm.getName());
        assertEquals("comm notes1", comm.getNotes());
        assertEquals(getFormattedDate(getDate(1)), comm.getFormattedFromDate());
        assertEquals(getFormattedDate(getDate(2)), comm.getFormattedToDate());
        assertEquals(getFormattedDate(getDate(3)), comm.getFormattedDueDate());
        assertEquals("Y", comm.getActive());
        assertEquals(new Long(1), comm.getCommType().getId());
        assertEquals("Letter", comm.getCommType().getType());
        assertEquals(new Long(2), comm.getLocConRelType().getId());
        assertEquals("Contact", comm.getLocConRelType().getType());
        assertEquals(new Long(3), comm.getBpLocRelType().getId());
        assertEquals("Main", comm.getBpLocRelType().getType());
        assertEquals(new Long(4L), comm.getStatus().getId());
        assertEquals("New", comm.getStatus().getStatus());

        CommRecipient commRecipient = (CommRecipient) helper
                .getRequestAttributeValue(CommunicationConstants.COMM_RECIPIENT_CRITERIA);
        assertEquals(new Long(2), commRecipient.getLocConRelType().getId());
        assertEquals("Contact", commRecipient.getLocConRelType().getType());
        assertEquals(new Long(3), commRecipient.getBpLocRelType().getId());
        assertEquals("Main", commRecipient.getBpLocRelType().getType());

        validateReferenceData();
        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
    }

    private void validateReferenceData() {
        List<CommType> commTypeList = (List<CommType>) helper
                .getRequestAttributeValue(CommunicationConstants.COMM_TYPE_LIST);
        List<ContactType> recipientTypeList = (List<ContactType>) helper
                .getRequestAttributeValue(BusinessPartnerConstants.LOC_CON_REL_TYPE_LIST);
        List<LocationType> locationTypeList = (List<LocationType>) helper
                .getRequestAttributeValue(LocationsConstants.BP_LOC_REL_TYPE_LIST);

        assertNotNull(commTypeList);
        assertNotNull(recipientTypeList);
        assertNotNull(locationTypeList);
    }

    private List<Communication> getCommunicationList() {
        List<Communication> comms = new ArrayList<Communication>();
        comms.add(new CommunicationImpl("11", "commName1", "comm notes1", getDate(1), getDate(2), getDate(3), "Y",
                null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "111", null));
        comms
                .add(
                        new CommunicationImpl("22", "commName2", "comm notes2", getDate(1), getDate(2), getDate(3), "Y", null,
                                null, 5L, "Training",
                                8L, "Open", 6L, "Worker", 7L, "Plant", "222", null));
        return comms;
    }

    private String getFormattedDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sdf.format(date);
        }
        catch (Exception e) {
            return "";
        }
    }

    private Date getDate(int numDaysToAdd) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, numDaysToAdd);
        return cal.getTime();
    }

    private class MockCommunicationController extends CommRecipientController {
        public MockCommunicationController(CommunicationService commService, LocationService locationService
        ) {
            super(commService, locationService, new MockDAO<ContactType, Long>());
        }

        //This method has protected access only for testing
        protected RecipientDataSource getRecipientDataSource(UCCHelper helper) {
            return new MockRecipientDataSource(helper);
        }
    }
}