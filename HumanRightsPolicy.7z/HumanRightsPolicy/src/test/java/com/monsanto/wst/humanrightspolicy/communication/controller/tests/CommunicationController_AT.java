/*
 CommunicationController_AT was created on May 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.action.ActionConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.controller.CommunicationController;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommunicationDAO;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.persistence.HrpPersistenceStore;
import com.monsanto.wst.humanrightspolicy.testUtils.HumanRightsPolicyDatabaseTestCase;
import com.monsanto.wst.humanrightspolicy.testUtils.mock.MockUCCHelperForHrp;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationController_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-10-17 15:36:21 $
 *
 * @author sspati1
 * @version $Revision: 1.31 $
 */
public class CommunicationController_AT extends HumanRightsPolicyDatabaseTestCase {

    private MockUCCHelper helper;

    protected void setUp() throws Exception {
        super.setUp();
        helper = new MockUCCHelperForHrp("hrpAT");
    }

    public void testNonSpecified_NewCommunication_StatusDefaultsToOpen() throws Exception {
        CommunicationController controller = new CommunicationController();
        controller.run(helper);
        validateReferenceData();
        assertTrue(helper.wasSentTo(CommunicationConstants.LIST_COMM_JSP));
    }

    public void testLookupCommunication_UserClicksOnACommunication_SeesDetailsAndDefaultSearchRecipientCriteriaIsSet() throws
            Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "lookupCommunication");
        CommunicationController controller = new CommunicationController();
        controller.run(helper);
        Boolean areAllRecipientsMarkedAsDone = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION);
        assertFalse(areAllRecipientsMarkedAsDone);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertEquals("1", comm.getId());
        assertEquals("C�MM TEST 1", comm.getName());
        assertEquals("COMM TEST NOTES 1", comm.getNotes());
        assertEquals("Y", comm.getActive());
        assertEquals("2008-01-02", comm.getFormattedFromDate());
        assertEquals("2009-01-02", comm.getFormattedToDate());
        assertEquals("2005-01-15", comm.getFormattedDueDate());
        assertEquals("COMM 1 POLICY", comm.getUrlTitle());
        assertEquals("http://www.monsanto.com", comm.getUrl());
        assertEquals(new Long(1), comm.getCommType().getId());
        assertEquals("Letter1", comm.getCommType().getType());
        assertEquals(new Long(3), comm.getLocConRelType().getId());
        assertEquals("MANAGERS1", comm.getLocConRelType().getType());
        assertEquals(new Long(1), comm.getBpLocRelType().getId());
        assertEquals("Type Main", comm.getBpLocRelType().getType());
        assertEquals(new Long(1), comm.getStatus().getId());
        assertEquals("OPEN1", comm.getStatus().getStatus());

        CommRecipient commRecipient = (CommRecipient) helper
                .getRequestAttributeValue(CommunicationConstants.COMM_RECIPIENT_CRITERIA);
        assertEquals(new Long(3), commRecipient.getLocConRelType().getId());
        assertEquals("MANAGERS1", commRecipient.getLocConRelType().getType());
        assertEquals(new Long(1), commRecipient.getBpLocRelType().getId());
        assertEquals("Type Main", commRecipient.getBpLocRelType().getType());
        validateReferenceData();
        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
    }

    public void testUpdateCommunication_CommIsUpdated() throws
            Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
        helper.setRequestParameterValue(CommunicationConstants.COMM_NAME, "new n�me");
        helper.setRequestParameterValue(CommunicationConstants.COMM_NOTES, "new notes");
        helper.setRequestParameterValue(CommunicationConstants.COMM_FROM_PERIOD, "2008-01-23");
        helper.setRequestParameterValue(CommunicationConstants.COMM_TO_PERIOD, "2008-01-24");
        helper.setRequestParameterValue(CommunicationConstants.COMM_DUE_PERIOD, "2008-01-25");
        helper.setRequestParameterValue(CommunicationConstants.COMM_URL_TITLE, "new COMM 1 POLICY");
        helper.setRequestParameterValue(CommunicationConstants.COMM_URL, "http://www.monsanto.com/new");
        helper.setRequestParameterValue(CommunicationConstants.COMM_DUE_PERIOD, "2008-01-25");
        helper.setRequestParameterValue(CommunicationConstants.COMM_TYPE_ID, "2");
        helper.setRequestParameterValue(CommunicationConstants.COMM_STATUD_ID, "3");
        helper.setRequestParameterValue(CommunicationConstants.COMM_PEOPLE_TYPE_ID, "2");
        helper.setRequestParameterValue(CommunicationConstants.COMM_LOC_TYPE_ID, "2");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateCommunication");
        CommunicationController controller = new CommunicationController();
        controller.run(helper);
        Boolean isCommReadyForCompletion = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION);
        assertFalse(isCommReadyForCompletion);
        Boolean areAllRecipientsMarkedAsComplete = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE);
        assertFalse(areAllRecipientsMarkedAsComplete);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertEquals("1", comm.getId());
        assertEquals("new n�me", comm.getName());
        assertEquals("new notes", comm.getNotes());
        assertEquals("Y", comm.getActive());
        assertEquals("2008-01-23", comm.getFormattedFromDate());
        assertEquals("2008-01-24", comm.getFormattedToDate());
        assertEquals("2008-01-25", comm.getFormattedDueDate());
        assertEquals("new COMM 1 POLICY", comm.getUrlTitle());
        assertEquals("http://www.monsanto.com/new", comm.getUrl());
        assertEquals(new Long(2), comm.getCommType().getId());
        assertEquals("Training1", comm.getCommType().getType());
        assertEquals(new Long(2), comm.getLocConRelType().getId());
        assertEquals("OTHER", comm.getLocConRelType().getType());
        assertEquals(new Long(2), comm.getBpLocRelType().getId());
        assertEquals("Plant", comm.getBpLocRelType().getType());
        assertEquals(new Long(3), comm.getStatus().getId());
        assertEquals("DISTRIBUTED1", comm.getStatus().getStatus());

        CommRecipient commRecipient = (CommRecipient) helper
                .getRequestAttributeValue(CommunicationConstants.COMM_RECIPIENT_CRITERIA);
        assertEquals(new Long(2), commRecipient.getLocConRelType().getId());
        assertEquals("OTHER", commRecipient.getLocConRelType().getType());
        assertEquals(new Long(2), commRecipient.getBpLocRelType().getId());
        assertEquals("Plant", commRecipient.getBpLocRelType().getType());

        validateReferenceData();
        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
    }

    public void testDeactivateSelectedCommunications_NotAllSelected() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "2");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deactivateSelectedCommunications");

        Communication comm = getCommunicationDAO().lookupCommunicationById("2");
        assertEquals("Y", comm.getActive());

        CommunicationController controller = new CommunicationController();
        controller.run(helper);

        comm = getCommunicationDAO().lookupCommunicationById("2");
        assertEquals("N", comm.getActive());
    }

    public void testDeactivateSelectedCommunications_WithFilterAllSelected_Only1CommunicationDeactivated() throws
            Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
        helper.setRequestParameterValue("filterValue", "COMM TEST 2");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deactivateSelectedCommunications");

        Communication comm = getCommunicationDAO().lookupCommunicationById("1");
        assertEquals("Y", comm.getActive());
        comm = getCommunicationDAO().lookupCommunicationById("2");
        assertEquals("Y", comm.getActive());

        CommunicationController controller = new CommunicationController();
        controller.run(helper);

        comm = getCommunicationDAO().lookupCommunicationById("1");
        assertEquals("Y", comm.getActive());
        comm = getCommunicationDAO().lookupCommunicationById("2");
        assertEquals("N", comm.getActive());
    }

//  public void testDeleteRecipient_UserDeletesARecipient_RecipientIsNoLongerAssociatedWithTheCommunication() throws
//      Exception {
//    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
//    helper.setRequestParameterValue(CommunicationConstants.RECIPIENT_ID, "1");
//    helper.setRequestParameterValue(HRPMainConstants.METHOD, "deleteRecipient");
//
//    List<CommRecipient> commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
//    assertEquals(2, commRecipients.size());
//
//    CommunicationController controller = new CommunicationController();
//    controller.run(helper);
//
//    commRecipients = getCommRecipientDAO().lookupRecipientsByCommId("1");
//    assertEquals(1, commRecipients.size());
//  }


    public void testSetStatusToComplete_UserSelectsToChangesStatusToCompleted_StatusIsChangedToCompleted() throws
            Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "setStatusToClosed");
        CommunicationController controller = new CommunicationController();
        controller.run(helper);

        validateAttributesInHelper();
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertEquals("Closed", comm.getStatus().getStatus());

        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
    }

    public void testCopyCommunication_CommIsCopied() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "copyCommunication");
        CommunicationController controller = new CommunicationController();
        controller.run(helper);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertFalse(comm.getId().equals("11"));
        assertEquals("C�MM TEST 1", comm.getName());
        assertEquals("COMM TEST NOTES 1", comm.getNotes());
        assertEquals("Y", comm.getActive());
        assertEquals("2008-01-02", comm.getFormattedFromDate());
        assertEquals("2009-01-02", comm.getFormattedToDate());
        assertEquals("2005-01-15", comm.getFormattedDueDate());
        assertEquals("COMM 1 POLICY", comm.getUrlTitle());
        assertEquals("http://www.monsanto.com", comm.getUrl());
        assertEquals(new Long(1), comm.getCommType().getId());
        assertEquals("Letter1", comm.getCommType().getType());
        assertEquals(new Long(3), comm.getLocConRelType().getId());
        assertEquals("MANAGERS1", comm.getLocConRelType().getType());
        assertEquals(new Long(1), comm.getBpLocRelType().getId());
        assertEquals("Type Main", comm.getBpLocRelType().getType());
        assertEquals(new Long(171629), comm.getStatus().getId());
        assertEquals("New", comm.getStatus().getStatus());
        assertEquals("1", comm.getCopiedFromCommId());
        validateReferenceData();
        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));

        deleteNewCommunication(comm.getId());
    }

    private CommunicationDAO getCommunicationDAO() {
        DBTemplateImpl template = new DBTemplateImpl("database/dbtemplate-config.xml",
                new String[]{"database/dbtemplate.xml"});
        return new DBTemplateCommunicationDAO(template, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    }

    private void validateAttributesInHelper() {
        assertNotNull(helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION));
        assertNotNull(helper.getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE));
        assertNotNull(helper.getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION));
        validateReferenceData();
    }

    private void validateReferenceData() {
        List<CommType> commTypeList = (List<CommType>) helper
                .getRequestAttributeValue(CommunicationConstants.COMM_TYPE_LIST);
        assertTrue(commTypeList.size() > 0);
        List<ContactType> recipientTypeList = (List<ContactType>) helper
                .getRequestAttributeValue(BusinessPartnerConstants.LOC_CON_REL_TYPE_LIST);
        assertTrue(recipientTypeList.size() >= 2);
        List<LocationType> locationTypeList = (List<LocationType>) helper
                .getRequestAttributeValue(LocationsConstants.BP_LOC_REL_TYPE_LIST);
        assertTrue(locationTypeList.size() >= 2);
    }

    private void deleteNewCommunication(String commId) {
        PersistentStore persistentStore = null;
        try {
            persistentStore = HrpPersistenceStore.getStore();
            PersistentStore.registerInstance(persistentStore);
            PersistentStoreConnection psConnection = persistentStore.connect();
            psConnection.executeDelete("delete hrpolicy.communication where comm_id = " + commId);
        } catch (WrappingException e) {
            //ignore
            System.out.println("sonal " + e.getMessage());
        }
    }

    public void testLookupCommunication_IsACTION_STATUS_LISTSet() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "lookupCommunication");
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
        CommunicationController controller = new CommunicationController();
        controller.run(helper);
        assertNotNull(helper.getRequestAttributeValue(ActionConstants.ACTION_STATUS_LIST));
    }

    public void testLookupCommunication_IsACTION_PRIORITY_LISTSet() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "lookupCommunication");
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
        CommunicationController controller = new CommunicationController();
        controller.run(helper);
        assertNotNull(helper.getRequestAttributeValue(ActionConstants.ACTION_PRIORITY_LIST));
    }
}