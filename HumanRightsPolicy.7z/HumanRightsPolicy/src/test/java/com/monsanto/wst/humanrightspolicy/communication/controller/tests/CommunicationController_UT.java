/*
 CommunicationController_UT was created on Apr 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.controller.BaseCommunicationController;
import com.monsanto.wst.humanrightspolicy.communication.controller.CommunicationController;
import com.monsanto.wst.humanrightspolicy.communication.datasource.CommunicationDataSource;
import com.monsanto.wst.humanrightspolicy.communication.datasource.mock.MockCommunicationDataSource;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.communication.service.tests.mock.MockCommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.location.service.tests.mock.MockLocationService;
import com.monsanto.wst.humanrightspolicy.model.*;
import org.custommonkey.xmlunit.XMLTestCase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-12-15 20:03:07 $
 *
 * @author sspati1
 * @version $Revision: 1.48 $
 */
public class CommunicationController_UT extends XMLTestCase {
    private MockUCCHelper helper = null;

    protected void setUp() throws Exception {
        super.setUp();
        helper = new MockUCCHelper(null);
    }

    public void testCreate() throws Exception {
        CommunicationController controller = new CommunicationController(null,
                null, new MockDAO<ContactType, Long>());
        assertNotNull(controller);
    }

    public void testNonSpecified_SentToJsp() throws Exception {
        helper.setRequestAttributeValue(HRPMainConstants.SCOPE, "My");
        CommunicationController controller = getCommunicationController();
        controller.run(helper);
        validateReferenceData();
        assertEquals("My", (String) helper.getRequestAttributeValue(HRPMainConstants.SCOPE));
        assertTrue(helper.wasSentTo(CommunicationConstants.LIST_COMM_JSP));
    }

    public void testAllComms_SentToJsp() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "allComms");
        CommunicationController controller = getCommunicationController();
        controller.run(helper);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertNull(comm);
        validateReferenceData();
        List<CommStatus> statusList = (List<CommStatus>) helper.getRequestAttributeValue(CommunicationConstants.COMM_STATUS_LIST);
        assertEquals(4, statusList.size());
        assertEquals("New", statusList.get(0).getStatus());
        assertNull(helper.getRequestAttributeValue(HRPMainConstants.SCOPE));
        assertTrue(helper.wasSentTo(CommunicationConstants.LIST_COMM_JSP));
    }

/*
//todo disabled failing test for part of HRP not in use
    public void testLookupCommunication_ReturnsCommunication() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "lookupCommunication");
        CommunicationController controller = getCommunicationController();
        controller.run(helper);
        validateDataInResponseForCommWithId11();
    }

*/

/*
//todo disabled failing test for part of HRP not in use
    public void testLookupCommunication_ReturnsCommunication_AllRecipientMarkedAsDoneDoneAndStatusIsNotComplete() throws
            Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "lookupCommunication");
        List<Communication> comms = new ArrayList<Communication>();
        comms.add(new CommunicationImpl("11", "commName1", "comm notes1", null, new Date(), null, "Y", null, null,
                1L, "Letter", 22L, "Open", 2L, "Contact", 3L, "Main", "111", null));

        List<CommRecipient> recipients = new ArrayList<CommRecipient>();
        recipients.add(new CommRecipientImpl("1", "1", "1", "Y", "person name 1", 11L, "Plant", 12L, "employee",
                "12", "India", "13", "India", "14", "Gujarat", "bp name 1", null, null, null, null, null, null, null));
        recipients.add(new CommRecipientImpl("2", "2", "2", "Y", "person name 2", 12L, "Type 1", 13L, "manager",
                "13", "NA", "14", "United States", "15", "Missouri", "bp name 2", null, null, null, null, null, null, null));

        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationServiceAllDoneAndComplete(comms, recipients);
        CommunicationController controller = new CommunicationController(commService,
                lcoationService, new MockDAO<ContactType, Long>());
        controller.run(helper);
        Boolean isCommunicationReadyForCompletion = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION);
        assertTrue(isCommunicationReadyForCompletion);
        Boolean areAllRecipientsMarkedAsComplete = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE);
        assertTrue(areAllRecipientsMarkedAsComplete);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertEquals("11", comm.getId());
        assertEquals("commName1", comm.getName());
        assertEquals("comm notes1", comm.getNotes());
        assertEquals("", comm.getFormattedFromDate());
        assertEquals("Y", comm.getActive());
        assertEquals(getFormattedDate(new Date()), comm.getFormattedToDate());
        assertEquals(new Long(1), comm.getCommType().getId());
        assertEquals("Letter", comm.getCommType().getType());
        assertEquals(new Long(2), comm.getLocConRelType().getId());
        assertEquals("Contact", comm.getLocConRelType().getType());
        assertEquals(new Long(3), comm.getBpLocRelType().getId());
        assertEquals("Main", comm.getBpLocRelType().getType());
        assertEquals(new Long(22L), comm.getStatus().getId());
        assertEquals("Open", comm.getStatus().getStatus());

        CommRecipient commRecipient = (CommRecipient) helper
                .getRequestAttributeValue(CommunicationConstants.COMM_RECIPIENT_CRITERIA);
        assertEquals(new Long(2), commRecipient.getLocConRelType().getId());
        assertEquals("Contact", commRecipient.getLocConRelType().getType());
        assertEquals(new Long(3), commRecipient.getBpLocRelType().getId());
        assertEquals("Main", commRecipient.getBpLocRelType().getType());

        validateReferenceData();
        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
    }
*/

    public void testUpdateCommunication_ReturnsCommunication() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.COMM_NAME, "new comm name");
        helper.setRequestParameterValue(CommunicationConstants.COMM_NOTES, "new comm notes");
        helper.setRequestParameterValue(CommunicationConstants.COMM_FROM_PERIOD, "2008-02-22");
        helper.setRequestParameterValue(CommunicationConstants.COMM_TO_PERIOD, "2008-03-21");
        helper.setRequestParameterValue(CommunicationConstants.COMM_DUE_PERIOD, "2008-03-21");
        helper.setRequestParameterValue(CommunicationConstants.COMM_TYPE_ID, "12");
        helper.setRequestParameterValue(CommunicationConstants.COMM_STATUD_ID, "13");
        helper.setRequestParameterValue(CommunicationConstants.COMM_PEOPLE_TYPE_ID, "14");
        helper.setRequestParameterValue(CommunicationConstants.COMM_LOC_TYPE_ID, "15");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "updateCommunication");
        CommunicationController controller = getCommunicationController();
        controller.run(helper);
        Boolean isCommReadyForCompletion = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION);
        assertFalse(isCommReadyForCompletion);
        Boolean areAllRecipientsMarkedAsComplete = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE);
        assertFalse(areAllRecipientsMarkedAsComplete);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertEquals("11", comm.getId());
        assertEquals("new comm name", comm.getName());
        assertEquals("new comm notes", comm.getNotes());
        assertEquals("2008-02-22", comm.getFormattedFromDate());
        assertEquals("2008-03-21", comm.getFormattedToDate());
        assertEquals("2008-03-21", comm.getFormattedDueDate());
        assertEquals(new Long(12), comm.getCommType().getId());
        assertEquals("Letter", comm.getCommType().getType());
        assertEquals(new Long(14), comm.getLocConRelType().getId());
        assertEquals("Contact", comm.getLocConRelType().getType());
        assertEquals(new Long(15), comm.getBpLocRelType().getId());
        assertEquals("Main", comm.getBpLocRelType().getType());
        assertEquals(new Long(13L), comm.getStatus().getId());
        assertEquals("New", comm.getStatus().getStatus());

        validateReferenceData();

        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
    }

    public void testSetStatusToClosed_OnlyStatusChanges() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(CommunicationConstants.COMM_NAME, "new comm name");
        helper.setRequestParameterValue(CommunicationConstants.COMM_NOTES, "new comm notes");
        helper.setRequestParameterValue(CommunicationConstants.COMM_FROM_PERIOD, "2008-02-22");
        helper.setRequestParameterValue(CommunicationConstants.COMM_TO_PERIOD, "2008-03-21");
        helper.setRequestParameterValue(CommunicationConstants.COMM_DUE_PERIOD, "2008-03-21");
        helper.setRequestParameterValue(CommunicationConstants.COMM_TYPE_ID, "12");
        helper.setRequestParameterValue(CommunicationConstants.COMM_STATUD_ID, "13");
        helper.setRequestParameterValue(CommunicationConstants.COMM_PEOPLE_TYPE_ID, "14");
        helper.setRequestParameterValue(CommunicationConstants.COMM_LOC_TYPE_ID, "15");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "setStatusToClosed");
        CommunicationController controller = getCommunicationController();
        controller.run(helper);
        Boolean isCommReadyForCompletion = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION);
        assertFalse(isCommReadyForCompletion);
        Boolean areAllRecipientsMarkedAsComplete = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE);
        assertFalse(areAllRecipientsMarkedAsComplete);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertEquals("11", comm.getId());
        assertEquals("commName1", comm.getName());
        assertEquals("comm notes1", comm.getNotes());
        assertEquals(getFormattedDate(getDate(1)), comm.getFormattedFromDate());
        assertEquals(getFormattedDate(getDate(2)), comm.getFormattedToDate());
        assertEquals(getFormattedDate(getDate(3)), comm.getFormattedDueDate());
        assertEquals("Y", comm.getActive());
        assertEquals(new Long(1), comm.getCommType().getId());
        assertEquals("Letter", comm.getCommType().getType());
        assertEquals(new Long(2), comm.getLocConRelType().getId());
        assertEquals("Contact", comm.getLocConRelType().getType());
        assertEquals(new Long(3), comm.getBpLocRelType().getId());
        assertEquals("Main", comm.getBpLocRelType().getType());
        assertEquals(new Long(44L), comm.getStatus().getId());//closed status
        assertEquals(getFormattedDate(new Date()), comm.getFormattedDateCompleted());

        validateReferenceData();

        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
    }

    public void testAddCommunication_ReturnsCommunication() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_NAME, "new comm name");
        helper.setRequestParameterValue(CommunicationConstants.COMM_NOTES, "new comm notes");
        helper.setRequestParameterValue(CommunicationConstants.COMM_FROM_PERIOD, "2008-02-22");
        helper.setRequestParameterValue(CommunicationConstants.COMM_TO_PERIOD, "2008-03-21");
        helper.setRequestParameterValue(CommunicationConstants.COMM_DUE_PERIOD, "2008-03-21");
        helper.setRequestParameterValue(CommunicationConstants.COMM_TYPE_ID, "12");
        helper.setRequestParameterValue(CommunicationConstants.COMM_PEOPLE_TYPE_ID, "14");
        helper.setRequestParameterValue(CommunicationConstants.COMM_LOC_TYPE_ID, "15");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "addCommunication");
        CommunicationController controller = getCommunicationController();
        controller.run(helper);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertEquals("123", comm.getId());
        assertEquals("new comm name", comm.getName());
        assertEquals("new comm notes", comm.getNotes());
        assertEquals("2008-02-22", comm.getFormattedFromDate());
        assertEquals("Y", comm.getActive());
        assertEquals("2008-03-21", comm.getFormattedToDate());
        assertEquals("2008-03-21", comm.getFormattedDueDate());
        assertEquals(new Long(12), comm.getCommType().getId());
        assertEquals(new Long(14), comm.getLocConRelType().getId());
        assertEquals(new Long(15), comm.getBpLocRelType().getId());
        assertEquals(new Long(11L), comm.getStatus().getId());
        assertNull(comm.getCopiedFromCommId());
        validateReferenceData();
        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
    }

    public void testCopyCommunication_CommIsCopied() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "copyCommunication");
        CommunicationController controller = getCommunicationController();
        controller.run(helper);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertEquals("123", comm.getId());
        assertEquals("commName1", comm.getName());
        assertEquals("comm notes1", comm.getNotes());
        assertEquals(getFormattedDate(getDate(1)), comm.getFormattedFromDate());
        assertEquals(getFormattedDate(getDate(2)), comm.getFormattedToDate());
        assertEquals(getFormattedDate(getDate(3)), comm.getFormattedDueDate());
        assertEquals("Y", comm.getActive());
        assertEquals(new Long(1), comm.getCommType().getId());
        assertEquals(new Long(2), comm.getLocConRelType().getId());
        assertEquals(new Long(3), comm.getBpLocRelType().getId());
        assertEquals(new Long(11L), comm.getStatus().getId());
        assertEquals("11", comm.getCopiedFromCommId());
        validateReferenceData();
        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
    }

    public void testDeactivateSelectedCommunications_NotAllSelected() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "11,33");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");

        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deactivateSelectedCommunications");
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(null);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        assertEquals(2, commService.getSelectedIds().size());
        validateReferenceData();
        assertTrue(helper.wasSentTo(CommunicationConstants.LIST_COMM_JSP));
    }

    public void testDeactivateSelectedCommunications_WithFilterNotAllSelected() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "33");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
        helper.setRequestParameterValue("filterValue", "commName2");

        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deactivateSelectedCommunications");
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(null);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        assertEquals(1, commService.getSelectedIds().size());
        assertEquals("33", commService.getSelectedIds().get(0));
        validateReferenceData();
        assertTrue(helper.wasSentTo(CommunicationConstants.LIST_COMM_JSP));
    }

    public void testDeactivateSelectedCommunications_WithFilterAllSelected() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");
        helper.setRequestParameterValue("filterValue", "commName2");

        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deactivateSelectedCommunications");
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(null);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        assertEquals(2, commService.getSelectedIds().size());
        validateReferenceData();
        assertTrue(helper.wasSentTo(CommunicationConstants.LIST_COMM_JSP));
    }

    public void testDeactivateSelectedCommunications_AllSelected() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "");

        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deactivateSelectedCommunications");
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(null);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        assertEquals(3, commService.getSelectedIds().size());
    }

    public void testDeactivateSelectedCommunications_AllSelectedWithExclude() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.SELECT_ALL, "true");
        helper.setRequestParameterValue(HRPMainConstants.SELECTED_IDS, "");
        helper.setRequestParameterValue(HRPMainConstants.IDS_TO_EXCLUDE, "22,33");

        helper.setRequestParameterValue(HRPMainConstants.METHOD, "deactivateSelectedCommunications");
        LocationService lcoationService = new MockLocationService(null);
        MockCommunicationService commService = new MockCommunicationService(null);
        BaseCommunicationController controller = new MockCommunicationController(commService,
                lcoationService);
        controller.run(helper);
        assertEquals(1, commService.getSelectedIds().size());
    }

    private List<Communication> getCommunicationList() {
        List<Communication> comms = new ArrayList<Communication>();
        comms.add(new CommunicationImpl("11", "commName1", "comm notes1", getDate(1), getDate(2), getDate(3), "Y",
                null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "111", null));
        comms
                .add(
                        new CommunicationImpl("22", "commName2", "comm notes2", getDate(1), getDate(2), getDate(3), "Y", null,
                                null, 5L, "Training",
                                8L, "Open", 6L, "Worker", 7L, "Plant", "222", null));
        return comms;
    }

    private CommunicationController getCommunicationController() {
        List<Communication> comms = getCommunicationList();
        LocationService lcoationService = new MockLocationService(null);
        return new CommunicationController(new MockCommunicationService(comms), lcoationService, new MockDAO<ContactType, Long>());
    }

    private void validateReferenceData() {
        List<CommType> commTypeList = (List<CommType>) helper
                .getRequestAttributeValue(CommunicationConstants.COMM_TYPE_LIST);
        List<ContactType> recipientTypeList = (List<ContactType>) helper
                .getRequestAttributeValue(BusinessPartnerConstants.LOC_CON_REL_TYPE_LIST);
        List<LocationType> locationTypeList = (List<LocationType>) helper
                .getRequestAttributeValue(LocationsConstants.BP_LOC_REL_TYPE_LIST);

        assertNotNull(commTypeList);
        assertNotNull(recipientTypeList);
        assertNotNull(locationTypeList);
    }

    private void validateDataInResponseForCommWithId11() {
        Boolean isCommReadyForCompletion = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.IS_COMM_READY_FOR_COMPLETTION);
        assertFalse(isCommReadyForCompletion);
        Boolean areAllRecipientsMarkedAsComplete = (Boolean) helper
                .getRequestAttributeValue(CommunicationConstants.ARE_ALL_RECIPIENTS_MARKED_AS_DONE);
        assertFalse(areAllRecipientsMarkedAsComplete);
        Communication comm = (Communication) helper.getRequestAttributeValue(CommunicationConstants.COMMUNICATION);
        assertEquals("11", comm.getId());
        assertEquals("commName1", comm.getName());
        assertEquals("comm notes1", comm.getNotes());
        assertEquals(getFormattedDate(getDate(1)), comm.getFormattedFromDate());
        assertEquals(getFormattedDate(getDate(2)), comm.getFormattedToDate());
        assertEquals(getFormattedDate(getDate(3)), comm.getFormattedDueDate());
        assertEquals("Y", comm.getActive());
        assertEquals(new Long(1), comm.getCommType().getId());
        assertEquals("Letter", comm.getCommType().getType());
        assertEquals(new Long(2), comm.getLocConRelType().getId());
        assertEquals("Contact", comm.getLocConRelType().getType());
        assertEquals(new Long(3), comm.getBpLocRelType().getId());
        assertEquals("Main", comm.getBpLocRelType().getType());
        assertEquals(new Long(4L), comm.getStatus().getId());
        assertEquals("New", comm.getStatus().getStatus());

        CommRecipient commRecipient = (CommRecipient) helper
                .getRequestAttributeValue(CommunicationConstants.COMM_RECIPIENT_CRITERIA);
        assertEquals(new Long(2), commRecipient.getLocConRelType().getId());
        assertEquals("Contact", commRecipient.getLocConRelType().getType());
        assertEquals(new Long(3), commRecipient.getBpLocRelType().getId());
        assertEquals("Main", commRecipient.getBpLocRelType().getType());

        validateReferenceData();
        assertFalse(helper.wasErrorGenerated());
        assertTrue(helper.wasSentTo(CommunicationConstants.COMM_JSP));
    }

    private String getFormattedDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sdf.format(date);
        }
        catch (Exception e) {
            return "";
        }
    }

    private Date getDate(int numDaysToAdd) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, numDaysToAdd);
        return cal.getTime();
    }

    private class MockCommunicationController extends CommunicationController {
        public MockCommunicationController(CommunicationService commService, LocationService locationService
        ) {
            super(commService, locationService, new MockDAO<ContactType, Long>());
        }

        //This method has protected access only for testing
        protected CommunicationDataSource getCommunicationDataSource(UCCHelper helper) {
            return new MockCommunicationDataSource(helper);
        }

    }
}