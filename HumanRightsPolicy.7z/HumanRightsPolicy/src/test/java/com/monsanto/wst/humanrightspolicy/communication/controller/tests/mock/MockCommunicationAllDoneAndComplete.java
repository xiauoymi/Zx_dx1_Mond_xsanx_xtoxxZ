/*
 MockCommunicationAllDoneAndComplete was created on Aug 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.controller.tests.mock;

import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock.MockCommunicationDAO;
import com.monsanto.wst.humanrightspolicy.model.CommRecipient;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockCommunication;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: MockCommunicationAllDoneAndComplete.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:20 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */

public class MockCommunicationAllDoneAndComplete extends MockCommunication {
  private final CommunicationDAO mockCommDao;
  private final List<CommRecipient> recipients;

  public MockCommunicationAllDoneAndComplete(String id, String name, String notes, Date fromDate, Date toDate,
                                             Date dueDate, String active,
                                             Long commTypeId, String commTypeValue, Long commStatusId,
                                             String commStatusValue,
                                             Long recipientTypeId, String recipientTypeValue, Long locationTypeId,
                                             String locationTypeValue, List<CommRecipient> recipients,
                                             String copiedFromCommId) {
    super(id, name, notes, fromDate, toDate, dueDate, active, commTypeId, commTypeValue, commStatusId, commStatusValue,
        recipientTypeId, recipientTypeValue, locationTypeId, locationTypeValue, copiedFromCommId, null);
    this.recipients = recipients;
    this.mockCommDao = new MockCommunicationDAO(null);
  }

  public boolean areAllRecipientsMarkedAsDone() {
    return true;
  }

  protected CommunicationDAO getCommunicationDAO() {
    return this.mockCommDao;
  }

  public List<CommRecipient> getRecipients() {
    return this.recipients;
  }
}
