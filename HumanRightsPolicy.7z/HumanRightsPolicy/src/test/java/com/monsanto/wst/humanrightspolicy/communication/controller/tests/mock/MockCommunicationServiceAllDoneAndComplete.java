/*
 MockCommunicationServiceAllDoneAndComplete was created on Aug 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.controller.tests.mock;

import com.monsanto.wst.humanrightspolicy.communication.service.tests.mock.MockCommunicationService;
import com.monsanto.wst.humanrightspolicy.model.CommRecipient;
import com.monsanto.wst.humanrightspolicy.model.Communication;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockCommunication;

import java.util.List;

/**
 * Filename:    $RCSfile: MockCommunicationServiceAllDoneAndComplete.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:20 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class MockCommunicationServiceAllDoneAndComplete extends MockCommunicationService {
    private final List<Communication> commList;
    private final List<CommRecipient> recipients;
    private MockCommunication comm;

    public MockCommunicationServiceAllDoneAndComplete(List<Communication> comms, List<CommRecipient> recipients) {
        super(comms);
        this.commList = comms;
        this.recipients = recipients;
    }

    public Communication lookupCommunicationById(String commId) {
        for (Communication comm : commList) {
            if (comm.getId().equalsIgnoreCase(commId)) {
                this.comm = new MockCommunicationAllDoneAndComplete(comm.getId(), comm.getName(), comm.getNotes(),
                        comm.getFromDate(),
                        comm.getToDate(), comm.getDueDate(), comm.getActive(), comm.getCommType().getId(),
                        comm.getCommType().getType(), comm.getStatus().getId(), comm.getStatus().getStatus(),
                        comm.getLocConRelType().getId(), comm.getLocConRelType().getType(),
                        comm.getBpLocRelType().getId(), comm.getBpLocRelType().getType(), this.recipients,
                        comm.getCopiedFromCommId());
                
                return this.comm;
            }
        }
        return null;
    }

    public MockCommunication getComm() {
        return this.comm;
    }
}
