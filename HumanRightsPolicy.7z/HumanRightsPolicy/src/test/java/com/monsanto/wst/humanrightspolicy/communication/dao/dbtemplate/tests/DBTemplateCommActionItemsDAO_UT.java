package com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.tests;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommActionItemsDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommActionItemsDAO;
import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.model.ActionPriority;
import com.monsanto.wst.humanrightspolicy.model.Status;
import org.apache.commons.lang.time.DateUtils;
import org.custommonkey.xmlunit.XMLTestCase;
import org.custommonkey.xmlunit.exceptions.XpathException;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * User: afhyat
 */
public class DBTemplateCommActionItemsDAO_UT extends XMLTestCase {

  public void testCreate() throws Exception {
    CommActionItemsDAO dao = new DBTemplateCommActionItemsDAO();
    assertNotNull(dao);
  }

  public void testLookupActionsByCommId_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommActionItemsDAO dao = new DBTemplateCommActionItemsDAO(template, new MockDAO<Action, Long>());
    dao.lookupActionItemsByCommId("123");
    assertTrue(template.wasStatementNameCalled("lookupActionsByCommId"));
  }

  public void testAddActionItem_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommActionItemsDAO dao = new DBTemplateCommActionItemsDAO(template, new MockDAO<Action, Long>());
    dao.addActionItem("12", "123");
    assertTrue(template.wasStatementNameCalled("addActionItemToComm"));
  }

  public void testGetActionItemsAsXML_DocumentContainsAction() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommActionItemsDAO dao = new DBTemplateCommActionItemsDAO(template, new MockDAO<Action, Long>());
    List<Action> actionList = getActionList();
    Document doc = dao.getActionItemsAsXML(actionList);
    assertNotNull(doc);
    assertActionDocument(doc);
  }

  public void testLookupActionItemsByCommIdAsXML_CorrectStatementIsCalled_And_ReturnsDocument() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommActionItemsDAO dao = new DBTemplateCommActionItemsDAO(template, new MockDAO<Action, Long>());
    Document doc = dao.lookupActionItemsByCommIdAsXML("123");
    assertTrue(template.wasStatementNameCalled("lookupActionsByCommId"));
    assertNotNull(doc);
  }


  private void assertActionDocument(Document doc) throws TransformerException, XpathException {
    assertXpathEvaluatesTo("1", "//actionId", doc);
    assertXpathEvaluatesTo("Action1", "//actionName", doc);
    assertXpathEvaluatesTo("2008-09-30", "//actionStartDate", doc);
//     assertXpathEvaluatesTo("2008-10-30", "//actionDueDate", doc);
//     assertXpathEvaluatesTo("2008-10-30", "//actionDateCompleted", doc);
    assertXpathEvaluatesTo("50", "//actionPercentComplete", doc);
    assertXpathEvaluatesTo("Desc Action1", "//actionDescription", doc);
//     assertXpathEvaluatesTo("Open", "//actionStatus", doc);
    assertXpathEvaluatesTo("High", "//actionPriority", doc);
  }

  private List<Action> getActionList() throws ParseException {
    Action actionItem = new Action();
    actionItem.setId(1L);
    actionItem.setName("Action1");
    actionItem.setPercentageComplete("50");
    actionItem.setDescription("Desc Action1");
    String[] formatPatterns = {"yyyy-MM-dd"};
    Date startDate = DateUtils.parseDate("2008-09-30", formatPatterns);
    actionItem.setStartDate(startDate);
    Date dueDate = DateUtils.parseDate("2008-10-30", formatPatterns);
    actionItem.setDueDate(dueDate);
    Date completionDate = DateUtils.parseDate("2008-10-30", formatPatterns);
    actionItem.setDateCompleted(completionDate);
    ActionPriority priority = new ActionPriority();
    priority.setId(15L);
    priority.setValue("High");
    actionItem.setPriority(priority);
    Status status = new Status();
    status.setId(25L);
    status.setValue("Open");
    List<Action> actionsList = new ArrayList<Action>();
    actionsList.add(actionItem);
    return actionsList;
  }
}
