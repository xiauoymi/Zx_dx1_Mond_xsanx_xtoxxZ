/*
 DBTemplateCommRecipientDAO_UT was created on Jun 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.tests;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.model.CommRecipient;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: DBTemplateCommRecipientDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-02 20:12:52 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public class DBTemplateCommRecipientDAO_UT extends TestCase {

  public void testCreate() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(null);
    assertNotNull(dao);
  }

  public void testLookupRecipientsByCommId_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(template);
    dao.lookupRecipientsByCommId("123");
    assertTrue(template.wasStatementNameCalled("lookupRecipientsByCommId"));
  }

  public void testlookupNewRecipientsForCommunicationByCriteria_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(template);
    CommRecipient criteria = null;
    dao.lookupRecipientsNotAssociatedWithThisCommunicationByCriteria(criteria);
    assertTrue(template.wasStatementNameCalled("lookupRecipientsNotAssociatedWithThisCommunicationByCriteria"));
  }

  public void testLookupRecipientsForCommunicationByCriteria_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(template);
    CommRecipient criteria = null;
    dao.lookupRecipientsForCommunicationByCriteria(criteria);
    assertTrue(template.wasStatementNameCalled("lookupRecipientsForCommunicationByCriteria"));
  }

  public void testUpdateDoneFlagForRecipient_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(template);
   dao.updateDoneFlagForRecipient("11", "12", "N");
    assertTrue(template.wasStatementNameCalled("updateDoneFlagForRecipient"));
  }

  public void testUpdateDoneFlagForSelectedRecipient_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(template);
   dao.updateDoneFlagForSelectedRecipients("11", new ArrayList<String>(), "N");
    assertTrue(template.wasStatementNameCalled("updateDoneFlagForRecipient"));
  }

  public void testUpdateDoneFlagForAllRecipients_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(template);
    dao.updateDoneFlagForAllRecipients("11", "N");
    assertTrue(template.wasStatementNameCalled("updateDoneFlagForAllRecipients"));
  }

  public void testLookupRecipientsNotMarkedAsDone_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(template);
    dao.lookupRecipientsNotMarkedAsDone("11");
    assertTrue(template.wasStatementNameCalled("lookupRecipientsByCommIdNotMarkedAsDone"));
  }

  public void testDeleteRecipient_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(template);
    dao.deleteAllRecipients("11");
    assertTrue(template.wasStatementNameCalled("deleteAllRecipientsForCommunication"));
  }

  public void testDeleteSelectedRecipients_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(template);
    List<String> ids = new ArrayList<String>();
    dao.deleteSelectedRecipients("11", ids);
    assertTrue(template.wasStatementNameCalled("deleteRecipient"));
  }

  public void testAddRecipient_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(template);
    dao.addRecipient("11", "12");
    assertTrue(template.wasStatementNameCalled("addRecipient"));
  }
}