/*
 DBTemplateCommunicationDAO_UT was created on Apr 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.tests;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommunicationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Date;


/**
 * Filename:    $RCSfile: DBTemplateCommunicationDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 19:19:28 $
 *
 * @author sspati1
 * @version $Revision: 1.25 $
 */
public class DBTemplateCommunicationDAO_UT extends TestCase {

  public void testCreate() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(null, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    assertNotNull(dao);
  }

  public void testLookupMyCommunications_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommunicationDAO dao = new DBTemplateCommunicationDAO(template, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    dao.lookupMyCommunications();
    assertTrue(template.wasStatementNameCalled("lookupMyCommunications"));
  }

  public void testLookupCommunicationsByCriteria_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommunicationDAO dao = new DBTemplateCommunicationDAO(template, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    CommunicationSearchCriteria commCriteria = null;
    dao.lookupCommunicationByCriteria(commCriteria);
    assertTrue(template.wasStatementNameCalled("lookupCommunicationsByCriteria"));
  }

  public void testLookupCommunicationsById_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommunicationDAO dao = new DBTemplateCommunicationDAO(template, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    dao.lookupCommunicationById("123");
    assertTrue(template.wasStatementNameCalled("lookupCommunicationById"));
  }

  public void testUpdateCommunication_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommunicationDAO dao = new DBTemplateCommunicationDAO(template, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    dao.updateCommunication("123", "new comm name", "new comm notes", new Date(), new Date(), null, "Y", null, null, new CommType("23", null
    ), new CommStatus(45L, null),
            new ContactType("12", null), new LocationType(34L, null), null);
    assertTrue(template.wasStatementNameCalled("updateCommunication"));
  }

  public void testAddCommunication_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommunicationDAO dao = new DBTemplateCommunicationDAO(template, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    dao.addCommunication("new comm name", "new comm notes", new Date(), new Date(), null, "Y", null, null, new CommType("23", null
    ), new CommStatus(45L, null),
            new ContactType("12", null), new LocationType(34L, null), null, null);
    assertTrue(template.wasStatementNameCalled("addCommunication"));
  }

  public void testDeactivateSelectedCommunication_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommunicationDAO dao = new DBTemplateCommunicationDAO(template, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    dao.deactivateSelectedCommunications(new ArrayList<String>());
    assertTrue(template.wasStatementNameCalled("deactivateCommunication"));
  }

    public void testLookupCommunicationsByBPId_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommunicationDAO dao = new DBTemplateCommunicationDAO(template, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    dao.lookupCommunicationsByBPId("12");
    assertTrue(template.wasStatementNameCalled("lookupCommunicationsByBPId"));
  }

  public void testLookupCommunicationsByLocationId_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommunicationDAO dao = new DBTemplateCommunicationDAO(template, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    dao.lookupCommunicationsByLocationId("12");
    assertTrue(template.wasStatementNameCalled("lookupCommunicationsByLocationId"));
  }

  public void testLookupCommunicationsByContactId_CorrectStatementIsCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    CommunicationDAO dao = new DBTemplateCommunicationDAO(template, new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    dao.lookupCommunicationsByContactId("12");
    assertTrue(template.wasStatementNameCalled("lookupCommunicationsByContactId"));
  }
}