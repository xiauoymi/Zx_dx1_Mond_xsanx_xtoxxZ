package com.monsanto.wst.humanrightspolicy.communication.dao.tests;

import com.monsanto.wst.dao.GenericDAO;
import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.hibernate.HibernateDAO;
import com.monsanto.wst.humanrightspolicy.Security.dao.dbtemplate.tests.DBTemplateBaseTransactionTestCase;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommActionItemsDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommActionItemsDAO;
import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.custommonkey.xmlunit.XMLAssert;
import org.custommonkey.xmlunit.exceptions.XpathException;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.util.List;

/**
 * User: afhyat
 */
public class CommActionItemsDAO_AT extends DBTemplateBaseTransactionTestCase {
  private GenericDAO<Action, Long> actionDAO;

  protected String getConfigPath() {
    return "com/monsanto/wst/humanrightspolicy/testUtils/hrpData.xml";
  }

  protected void setUp() throws Exception {
    super.setUp();
    actionDAO = new HibernateDAO<Action, Long>(InitService.initHibernate(), Action.class);
  }

  public void testAddActionItem() throws Exception {
    CommActionItemsDAO dao = getCommActionItemsDAO();
    dao.addActionItem("77777", "7777777");
    List<Action> actions = dao.lookupActionItemsByCommId("77777");
    assertTrue(actions.size() > 0);
    Action actionRetrieved = retrieveActionWithID7777777(actions) ;
    assertNotNull("Action with ID: 7777777 was not retrieved." , actionRetrieved);
  }

  private DBTemplateCommActionItemsDAO getCommActionItemsDAO() {
    return new DBTemplateCommActionItemsDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), actionDAO);
  }

  public void testLookupActionItemsByCommId() throws Exception {
    CommActionItemsDAO dao = getCommActionItemsDAO();
    dao.addActionItem("77777", "7777777");
    List<Action> actions = dao.lookupActionItemsByCommId("77777");
    assertTrue(actions.size() > 0);
    Action actionRetrieved = retrieveActionWithID7777777(actions) ;
    assertNotNull("Action with ID: 7777777 was not retrieved." , actionRetrieved);
  }

  private Action retrieveActionWithID7777777(List<Action> actions) {
    for(Action action : actions) {
      if(action != null && (action.getId().longValue() ==  7777777))
        return action;
    }
    return null;
  }

  public void testLookupActionItemsByCommIdAsXML() throws Exception {
    CommActionItemsDAO dao = getCommActionItemsDAO();
    dao.addActionItem("77777", "7777777");
    Document document = dao.lookupActionItemsByCommIdAsXML("77777");
    assertNotNull(document);
    assertActionFromDocument(document, "7777777");
  }

  private void assertActionFromDocument(Document doc, String actionId) throws TransformerException, XpathException {
    String actionXPath = "/actionsList/action[actionId/text()='" + actionId + "']";
    XMLAssert.assertXpathExists(actionXPath, doc);
    XMLAssert.assertXpathEvaluatesTo(actionId, actionXPath + "/actionId", doc);
    XMLAssert.assertXpathEvaluatesTo("NoDelete", actionXPath + "/actionName", doc);
    XMLAssert.assertXpathEvaluatesTo("2008-07-02", actionXPath + "/actionStartDate", doc);
//     XMLAssert.assertXpathEvaluatesTo("2008-08-02", "//actionDueDate", doc);
//     XMLAssert.assertXpathEvaluatesTo("2008-08-02", "//actionDateCompleted", doc);
    XMLAssert.assertXpathEvaluatesTo("50", actionXPath + "/actionPercentComplete", doc);
    XMLAssert.assertXpathEvaluatesTo("DO NOT DELETE", actionXPath + "/actionDescription", doc);
    XMLAssert.assertXpathEvaluatesTo("In Progress", actionXPath + "/actionStatus", doc);
    XMLAssert.assertXpathEvaluatesTo("High", actionXPath + "/actionPriority", doc);
  }


}
