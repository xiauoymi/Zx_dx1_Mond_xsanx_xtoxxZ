/*
 CommRecipientDAO_AT was created on Jun 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.dao.tests;

import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.humanrightspolicy.Security.dao.dbtemplate.tests.DBTemplateBaseTransactionTestCase;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.model.CommRecipient;
import com.monsanto.wst.humanrightspolicy.model.CommRecipientImpl;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: CommRecipientDAO_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2009-02-03 21:37:26 $
 *
 * @author sspati1
 * @version $Revision: 1.17 $
 */
public class CommRecipientDAO_AT extends DBTemplateBaseTransactionTestCase {

  protected String getConfigPath() {
    return "com/monsanto/wst/humanrightspolicy/testUtils/hrpData.xml";
  }

  public void testLookupRecipientsByCommId_ReturnsRecipients() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    List<CommRecipient> recipients = dao.lookupRecipientsByCommId("1");
    assertEquals(3, recipients.size());
    CommRecipient commRecipient = recipients.get(2);
    assertEquals("2", commRecipient.getCommRecipientId());
    assertEquals("1", commRecipient.getCommId());
    assertEquals("4", commRecipient.getContactId());
    assertEquals("Y", commRecipient.getIsDone());
    assertEquals("RAMB�BU", commRecipient.getName());
    assertEquals("BP with n� alias", commRecipient.getBpName());
    assertEquals("PRIMARY", commRecipient.getLocConRelType().getType());
    assertEquals("Illinois", commRecipient.getAddress().getStateModel().getValue());
    assertEquals("Mongolia", commRecipient.getAddress().getCountryModel().getValue());
    assertEquals("REGION", commRecipient.getAddress().getRegionModel().getValue());
    assertEquals("4", commRecipient.getAddress().getAddressId());
    assertEquals("OLIVE BLVD", commRecipient.getAddress().getStreetAddress1());
    assertEquals("APT 123", commRecipient.getAddress().getStreetAddress2());
    assertEquals("ST.LOUIS", commRecipient.getAddress().getCity());
    assertEquals("63127", commRecipient.getAddress().getZipcode());
    assertEquals("N", commRecipient.hasContactsPrimaryRelationshipEnded());
    assertEquals("0000004444", commRecipient.getSapId());

    commRecipient = recipients.get(1);
    assertEquals("3", commRecipient.getCommRecipientId());
    assertEquals("1", commRecipient.getCommId());
    assertEquals("1", commRecipient.getContactId());
    assertEquals("Kansas-1", commRecipient.getAddress().getStateModel().getValue());
    assertEquals("United States", commRecipient.getAddress().getCountryModel().getValue());
    assertEquals("N", commRecipient.hasContactsPrimaryRelationshipEnded());

    commRecipient = recipients.get(0);
    assertEquals("1", commRecipient.getCommRecipientId());
    assertEquals("1", commRecipient.getCommId());
    assertEquals("2", commRecipient.getContactId());
    assertEquals("Kansas-1", commRecipient.getAddress().getStateModel().getValue());
    assertEquals("United States", commRecipient.getAddress().getCountryModel().getValue());
    assertEquals("N", commRecipient.hasContactsPrimaryRelationshipEnded());
  }

  public void testLookupRecipientsNotAssociatedWithThisCommunicationByCriteria_CommHasGrandParent_ByBPName_Returns0Result() throws
      Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    CommRecipient criteria = new CommRecipientImpl(null, null, "6", null, null, null, null, null, null, null, null,
        null, null, null, null, "with n� alias",
        null, null, null, null, null, null, null);
    List<CommRecipient> recipients = dao.lookupRecipientsNotAssociatedWithThisCommunicationByCriteria(criteria);
    assertEquals(0, recipients.size());
  }

/* todo commented out test for unused functionality
  public void testLookupRecipientsNotAssociatedWithThisCommunicationByCriteria_ByBPName_Returns1Result() throws
      Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    CommRecipient criteria = new CommRecipientImpl(null, null, "2", null, null, null, null, null, null, null, null,
        null, null, null, null, "with n� alias",
        null, null, null, null, null, null, null);
    List<CommRecipient> recipients = dao.lookupRecipientsNotAssociatedWithThisCommunicationByCriteria(criteria);
    assertEquals(1, recipients.size());
    CommRecipient commRecipient = recipients.get(0);
    assertNull(commRecipient.getCommRecipientId());
    assertNull(commRecipient.getCommId());
    assertEquals("4", commRecipient.getContactId());
    assertNull(commRecipient.getIsDone());
    assertEquals("RAMB�BU", commRecipient.getName());
    assertEquals("BP with n� alias", commRecipient.getBpName());
    assertEquals("PRIMARY", commRecipient.getLocConRelType().getType());
    assertEquals("Illinois", commRecipient.getAddress().getStateModel().getValue());
    assertEquals("Mongolia", commRecipient.getAddress().getCountryModel().getValue());
    assertEquals("REGION", commRecipient.getAddress().getRegionModel().getValue());
    assertEquals("4", commRecipient.getAddress().getAddressId());
    assertEquals("OLIVE BLVD", commRecipient.getAddress().getStreetAddress1());
    assertEquals("APT 123", commRecipient.getAddress().getStreetAddress2());
    assertEquals("ST.LOUIS", commRecipient.getAddress().getCity());
    assertEquals("63127", commRecipient.getAddress().getZipcode());
    assertEquals("N", commRecipient.hasContactsPrimaryRelationshipEnded());
    assertEquals("0000004444", commRecipient.getSapId());
  }

*/
  public void testLookupRecipientsNotAssociatedWithThisCommunicationByCriteria_ByPersonName_Returns2Results() throws
      Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    CommRecipient criteria = new CommRecipientImpl(null, null, "2", null, "�BU", null, null, null, null, null, null,
        null, null, null, null, null,
        null, null, null, null, null, null, null);
    List<CommRecipient> recipients = dao.lookupRecipientsNotAssociatedWithThisCommunicationByCriteria(criteria);
    assertEquals(1, recipients.size());
    CommRecipient commRecipient = recipients.get(0);
    assertNull(commRecipient.getCommRecipientId());
    assertNull(commRecipient.getCommId());
    assertEquals("4", commRecipient.getContactId());
    assertNull(commRecipient.getIsDone());
    assertEquals("RAMB�BU", commRecipient.getName());
    assertEquals("BP with n� alias", commRecipient.getBpName());
    assertEquals("PRIMARY", commRecipient.getLocConRelType().getType());
    assertEquals("Illinois", commRecipient.getAddress().getStateModel().getValue());
    assertEquals("Mongolia", commRecipient.getAddress().getCountryModel().getValue());
    assertEquals("REGION", commRecipient.getAddress().getRegionModel().getValue());
    assertEquals("4", commRecipient.getAddress().getAddressId());
    assertEquals("OLIVE BLVD", commRecipient.getAddress().getStreetAddress1());
    assertEquals("APT 123", commRecipient.getAddress().getStreetAddress2());
    assertEquals("ST.LOUIS", commRecipient.getAddress().getCity());
    assertEquals("63127", commRecipient.getAddress().getZipcode());
    assertEquals("N", commRecipient.hasContactsPrimaryRelationshipEnded());
    assertEquals("0000004444", commRecipient.getSapId());
  }

  public void testLookupRecipientsNotAssociatedWithThisCommunicationByCriteria_ByContactTypeId_Returns1Result() throws
      Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    CommRecipient criteria = new CommRecipientImpl(null, null, "2", null, null, null, null, 1L, null, null, null, null,
        null, null, null, null,
        null, null, null, null, null, null, null);
    List<CommRecipient> recipients = dao.lookupRecipientsNotAssociatedWithThisCommunicationByCriteria(criteria);
    assertEquals(1, recipients.size());
  }

  public void testLookupRecipientsNotAssociatedWithThisCommunicationByCriteria_ByStateId_Returns1Result() throws
      Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    CommRecipient criteria = new CommRecipientImpl(null, null, "2", null, null, null, null, null, null, null, null,
        null, null, "10", null, null,
        null, null, null, null, null, null, null);
    List<CommRecipient> recipients = dao.lookupRecipientsNotAssociatedWithThisCommunicationByCriteria(criteria);
    assertEquals(1, recipients.size());
  }

  public void testLookupRecipientsNotAssociatedWithThisCommunicationByCriteria_ByContactTypeId_Returns2Results() throws
      Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    CommRecipient criteria = new CommRecipientImpl(null, null, "2", null, null, null, null, 1L, null, null, null, null,
        null, null, null, null,
        null, null, null, null, null, null, null);
    List<CommRecipient> recipients = dao.lookupRecipientsNotAssociatedWithThisCommunicationByCriteria(criteria);
    assertEquals(1, recipients.size());
  }

  public void testLookupRecipientsForCommunicationByCriteria_ByLocTypeId_Returns2Results() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    CommRecipient criteria = new CommRecipientImpl(null, null, "1", null, null, 1L, null, null, null, null, null, null,
        null, null, null, null,
        null, null, null, null, null, null, null);
    List<CommRecipient> recipients = dao.lookupRecipientsForCommunicationByCriteria(criteria);
    assertEquals(3, recipients.size());
    CommRecipient commRecipient = recipients.get(2);
    assertEquals("3", commRecipient.getCommRecipientId());
    assertEquals("1", commRecipient.getCommId());
    assertEquals("1", commRecipient.getContactId());
    assertEquals("N", commRecipient.getIsDone());
    assertEquals("RAMBABU", commRecipient.getName());
    assertEquals("TEST GM", commRecipient.getBpName());
    assertEquals("PRIMARY", commRecipient.getLocConRelType().getType());
    assertEquals("Kansas-1", commRecipient.getAddress().getStateModel().getValue());
    assertEquals("United States", commRecipient.getAddress().getCountryModel().getValue());
    assertEquals("REGION", commRecipient.getAddress().getRegionModel().getValue());
    assertEquals("6", commRecipient.getAddress().getAddressId());
    assertEquals("NEIMAN RD", commRecipient.getAddress().getStreetAddress1());
    assertEquals("BLVD", commRecipient.getAddress().getStreetAddress2());
    assertEquals("KANSAS CITY", commRecipient.getAddress().getCity());
    assertEquals("64110", commRecipient.getAddress().getZipcode());
    assertEquals("0000012345", commRecipient.getSapId());
    assertEquals("N", commRecipient.hasContactsPrimaryRelationshipEnded());
  }

  public void testLookupRecipientsForCommunicationByCriteria_ByName_Returns4Results() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    CommRecipient criteria = new CommRecipientImpl(null, null, "1", null, "B�BU", null, null, null, null, null, null,
        null, null, null, null, null,
        null, null, null, null, null, null, null);
    List<CommRecipient> recipients = dao.lookupRecipientsForCommunicationByCriteria(criteria);
    assertEquals(4, recipients.size());
  }

/* todo commented out test for unused functionality
  public void testLookupRecipientsForCommunicationByCriteria_ByCompanyName_Returns1Results() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    CommRecipient criteria = new CommRecipientImpl(null, null, "1", null, null, null, null, null, null, null, null,
        null, null, null, null, "TEST GM",
        null, null, null, null, null, null, null);
    List<CommRecipient> recipients = dao.lookupRecipientsForCommunicationByCriteria(criteria);
    assertEquals(2, recipients.size());
  }
*/

  public void testLookupRecipientsByCommIdNotMarkedAsDone_Returns2Recipients() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    List<String> recipients = dao.lookupRecipientsNotMarkedAsDone("1");
    assertEquals(1, recipients.size());
    assertEquals("1", recipients.get(0));
  }

  public void testUpdateDoneFlagForRecipient_setToNotDone() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    dao.updateDoneFlagForRecipient("1", "2", "N");
    List<CommRecipient> recipients = dao.lookupRecipientsByCommId("1");
    for (CommRecipient commRecipient : recipients) {
      if (commRecipient.getContactId().equals("2")) {
        assertEquals("N", commRecipient.getIsDone());
      }
    }
    assertEquals(3, recipients.size());
  }

  public void testUpdateDoneFlagForSelectedRecipients_setToNotDone() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    List<String> selectedIds = new ArrayList<String>();
    selectedIds.add("1");
    selectedIds.add("2");
    dao.updateDoneFlagForSelectedRecipients("1", selectedIds, "Y");
    List<CommRecipient> recipients = dao.lookupRecipientsByCommId("1");
    for (CommRecipient commRecipient : recipients) {
        assertEquals("Y", commRecipient.getIsDone());
    }
    assertEquals(3, recipients.size());
  }

  public void testUpdateDoneFlagForRecipient_setTODone() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    dao.updateDoneFlagForRecipient("1", "1", "Y");
    List<CommRecipient> recipients = dao.lookupRecipientsByCommId("1");
    assertEquals(3, recipients.size());
    for (CommRecipient commRecipient : recipients) {
      if (commRecipient.getContactId().equals("2")) {
        assertEquals("Y", commRecipient.getIsDone());
      }
    }
  }

  public void testUpdateDoneFlagForAllRecipients_done() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    dao.updateDoneFlagForAllRecipients("1", "Y");
    List<CommRecipient> recipients = dao.lookupRecipientsByCommId("1");
    assertEquals(3, recipients.size());
    for (CommRecipient commRecipient : recipients) {
      assertEquals("Y", commRecipient.getIsDone());
    }
  }

  public void testDeleteAllRecipients() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    List<CommRecipient> recipients = dao.lookupRecipientsByCommId("1");
    assertEquals(3, recipients.size());
    dao.deleteAllRecipients("1");
    recipients = dao.lookupRecipientsByCommId("1");
    assertEquals(0, recipients.size());
  }

  public void testDeleteSelectedRecipients() throws Exception {
    List<String> selectedIds = new ArrayList<String>();
    selectedIds.add("1");
    selectedIds.add("4");
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));

    List<CommRecipient> recipients = dao.lookupRecipientsByCommId("1");
    assertEquals(3, recipients.size());

    dao.deleteSelectedRecipients("1", selectedIds);

    recipients = dao.lookupRecipientsByCommId("1");
    assertEquals(1, recipients.size());
  }

  public void testAddRecipient() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    dao.addRecipient("1", "5");
    List<CommRecipient> recipients = dao.lookupRecipientsByCommId("1");
    assertEquals(5, recipients.size());
  }

  public void testAddRecipients() throws Exception {
    CommRecipientDAO dao = new DBTemplateCommRecipientDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}));
    List<CommRecipient> commRecipients = new ArrayList<CommRecipient>();
    commRecipients.add(new CommRecipientImpl("5", null, null, null, null, null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, null));
    dao.addRecipients("1", commRecipients);
    List<CommRecipient> recipients = dao.lookupRecipientsByCommId("1");
    assertEquals(5, recipients.size());
  }

}