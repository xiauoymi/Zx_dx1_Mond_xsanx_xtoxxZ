/*
 CommunicationDAO_AT was created on Apr 16, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.dao.tests;

import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.Security.dao.dbtemplate.tests.DBTemplateBaseTransactionTestCase;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommunicationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationDAO_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $ On:	$Date:
 * 2008/06/13 18:08:24 $
 *
 * @author sspati1
 * @version $Revision: 1.42 $
 */
public class CommunicationDAO_AT extends DBTemplateBaseTransactionTestCase {

  protected String getConfigPath() {
    return "com/monsanto/wst/humanrightspolicy/testUtils/hrpData.xml";
  }

  public void testLookupCommunicationById_ReturnComm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    Communication comm = dao.lookupCommunicationById("1");
    assertEquals("1", comm.getId());
    assertEquals("C�MM TEST 1", comm.getName());
    assertEquals("COMM TEST NOTES 1", comm.getNotes());
    assertEquals("Y", comm.getActive());
    assertEquals("2008-01-02", comm.getFormattedFromDate());
    assertEquals("2009-01-02", comm.getFormattedToDate());
    assertEquals("2005-01-15", comm.getFormattedDueDate());
    assertEquals("COMM 1 POLICY", comm.getUrlTitle());
    assertEquals("http://www.monsanto.com", comm.getUrl());
    assertEquals(new Long(1), comm.getCommType().getId());
    assertEquals("Letter1", comm.getCommType().getType());
    assertEquals(new Long(3), comm.getLocConRelType().getId());
    assertEquals("MANAGERS1", comm.getLocConRelType().getType());
    assertEquals(new Long(1), comm.getBpLocRelType().getId());
    assertEquals("Type Main", comm.getBpLocRelType().getType());
    assertEquals(new Long(1), comm.getStatus().getId());
    assertEquals("OPEN1", comm.getStatus().getStatus());
    assertEquals("10", comm.getCopiedFromCommId());
  }

  public void testLookupMyCommunications_Returns2Comm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    List<Communication> communicationList = dao.lookupMyCommunications();
    assertTrue(communicationList.size() >= 2);
  }

  public void testLookupCommunicationByCriteria_NoCriteria_Returns2Comm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    List<Communication> communicationList = dao.lookupCommunicationByCriteria(null);
    assertTrue(communicationList.size() >= 2);
  }

  public void testLookupCommunicationByCriteria_ByName_Returns2Comm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    Communication comm = new CommunicationImpl(null, "C�MM TEST 1", null, null, null, null, "Y", null, null,
        null, null, null, null, null, null, null, null, null, null);
    CommunicationSearchCriteria commCriteria = new CommunicationSearchCriteria(comm, null, null, null, null, null);
    List<Communication> communicationList = dao.lookupCommunicationByCriteria(commCriteria);
    assertTrue(communicationList.size() >= 1);
  }

  public void testLookupCommunicationByCriteria_ByStatusId_Returns1Comm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    Communication commC = new CommunicationImpl(null, null, null, null, null, null, "Y", null, null, null, null,
        2L, null, null, null,
        null, null, null, null);
    CommunicationSearchCriteria commCriteria = new CommunicationSearchCriteria(commC, null, null, null, null, null);
    List<Communication> communicationList = dao.lookupCommunicationByCriteria(commCriteria);
    assertEquals(1, communicationList.size());
    Communication comm = communicationList.get(0);
    assertEquals("2", comm.getId());
    assertEquals("COMM TEST 2", comm.getName());
    assertEquals("COMM TEST NOTES 2", comm.getNotes());
    assertEquals("Y", comm.getActive());
    assertEquals("2008-02-02", comm.getFormattedFromDate());
    assertEquals("2009-02-02", comm.getFormattedToDate());
    assertEquals("2005-01-16", comm.getFormattedDueDate());
    assertEquals("COMM 2 POLICY", comm.getUrlTitle());
    assertEquals("http://www.monsanto.com/comm2", comm.getUrl());
    assertEquals(new Long(2), comm.getCommType().getId());
    assertEquals("Training1", comm.getCommType().getType());
    assertEquals(new Long(4), comm.getLocConRelType().getId());
    assertEquals("EMPLOYEES1", comm.getLocConRelType().getType());
    assertEquals(new Long(1), comm.getBpLocRelType().getId());
    assertEquals("Type Main", comm.getBpLocRelType().getType());
    assertEquals(new Long(2), comm.getStatus().getId());
    assertEquals("PENDING1", comm.getStatus().getStatus());
    assertNull(comm.getCopiedFromCommId());
  }

  public void testLookupCommunicationByCriteria_ByCommTypeId_Returns1Comm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    Communication criteria = new CommunicationImpl(null, null, null, null, null, null, "Y", null, null, 1L, null,
        null, null, null, null,
        null, null, null, null);
    CommunicationSearchCriteria commCriteria = new CommunicationSearchCriteria(criteria, null, null, null, null, null);
    List<Communication> communicationList = dao.lookupCommunicationByCriteria(commCriteria);
    assertEquals(1, communicationList.size());
  }

  public void testLookupCommunicationByCriteria_ByLocTypeId_Returns1Comm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    Communication criteria = new CommunicationImpl(null, null, null, null, null, null, "Y", null, null, null,
        null, null, null, null,
        null, 1L, null, null, null);
    CommunicationSearchCriteria commCriteria = new CommunicationSearchCriteria(criteria, null, null, null, null, null);
    List<Communication> communicationList = dao.lookupCommunicationByCriteria(commCriteria);
    assertEquals(4, communicationList.size());
  }

  public void testLookupCommunicationByCriteria_ByRecipientTypeId_Returns1Comm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    Communication criteria = new CommunicationImpl(null, null, null, null, null, null, "Y", null, null, null,
        null, null, null, 3L, null,
        null, null, null, null);
    CommunicationSearchCriteria commCriteria = new CommunicationSearchCriteria(criteria, null, null, null, null, null);
    List<Communication> communicationList = dao.lookupCommunicationByCriteria(commCriteria);
    assertEquals(1, communicationList.size());
  }

  public void testLookupCommunicationByCriteria_ByStateId_Returns1Comm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    CommunicationSearchCriteria commCriteria = new CommunicationSearchCriteria(null, null, null, "4", null, null);
    List<Communication> communicationList = dao.lookupCommunicationByCriteria(commCriteria);
    assertEquals(1, communicationList.size());
  }

  public void testLookupCommunicationByCriteria_ByCountryId_Returns1Comm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    CommunicationSearchCriteria commCriteria = new CommunicationSearchCriteria(null, null, null, null, "1", null);
    List<Communication> communicationList = dao.lookupCommunicationByCriteria(commCriteria);
    assertEquals(3, communicationList.size());
  }

  public void testLookupCommunicationByCriteria_ByRegionId_Returns1Comm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    CommunicationSearchCriteria commCriteria = new CommunicationSearchCriteria(null, null, null, null, null, "1");
    List<Communication> communicationList = dao.lookupCommunicationByCriteria(commCriteria);
    assertEquals(3, communicationList.size());
  }

  public void testLookupCommunicationByCriteria_ByDueDateFrom_Returns1Comm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    CommunicationSearchCriteria commCriteria = new CommunicationSearchCriteria(null, getDate(2005, 0, 15), null, null,
        null, null);
    List<Communication> communicationList = dao.lookupCommunicationByCriteria(commCriteria);
    assertTrue(communicationList.size() >= 2);
  }

  public void testLookupCommunicationByCriteria_ByDueDateTo_Returns1Comm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    CommunicationSearchCriteria commCriteria = new CommunicationSearchCriteria(null, null, getDate(2005, 0, 16), null,
        null, null);
    List<Communication> communicationList = dao.lookupCommunicationByCriteria(commCriteria);
    assertTrue(communicationList.size() >= 2);
  }

  public void testLookupCommunicationByCriteria_ByDueDateFromAndDueDateTo_ReturnsComm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    CommunicationSearchCriteria commCriteria = new CommunicationSearchCriteria(null, getDate(2005, 0, 15),
        getDate(2005, 0, 18), null, null, null);
    List<Communication> communicationList = dao.lookupCommunicationByCriteria(commCriteria);
    assertTrue(communicationList.size() >= 2);
  }

  public void testUpdateCommunication() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    dao.updateCommunication("1", "new comm name", "new comm notes", new Date(), new Date(), new Date(), "N",
        "new COMM 1 POLICY", "http://www.monsanto.com/new", new CommType("2", null),
        new CommStatus(2L, null),
        new ContactType("4", null), new LocationType(2L, null), null);
    Communication comm = dao.lookupCommunicationById("1");
    assertEquals("1", comm.getId());
    assertEquals("new comm name", comm.getName());
    assertEquals("new comm notes", comm.getNotes());
    assertEquals("N", comm.getActive());
    assertEquals(getFormattedDate(new Date()), comm.getFormattedFromDate());
    assertEquals(getFormattedDate(new Date()), comm.getFormattedToDate());
    assertEquals(getFormattedDate(new Date()), comm.getFormattedDueDate());
    assertEquals("new COMM 1 POLICY", comm.getUrlTitle());
    assertEquals("http://www.monsanto.com/new", comm.getUrl());
    assertEquals(new Long(2), comm.getCommType().getId());
    assertEquals("Training1", comm.getCommType().getType());
    assertEquals(new Long(4), comm.getLocConRelType().getId());
    assertEquals("EMPLOYEES1", comm.getLocConRelType().getType());
    assertEquals(new Long(2), comm.getBpLocRelType().getId());
    assertEquals("Plant", comm.getBpLocRelType().getType());
    assertEquals(new Long(2), comm.getStatus().getId());
    assertEquals("PENDING1", comm.getStatus().getStatus());
  }

  public void testDeactivateSelectedCommunications() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    List<String> ids = new ArrayList<String>();
    ids.add("1");
    ids.add("2");
    dao.deactivateSelectedCommunications(ids);
    Communication comm = dao.lookupCommunicationById("1");
    assertEquals("1", comm.getId());
    assertEquals("C�MM TEST 1", comm.getName());
    assertEquals("COMM TEST NOTES 1", comm.getNotes());
    assertEquals("N", comm.getActive());
    assertEquals("2008-01-02", comm.getFormattedFromDate());
    assertEquals("2009-01-02", comm.getFormattedToDate());
    assertEquals("2005-01-15", comm.getFormattedDueDate());
    assertEquals("COMM 1 POLICY", comm.getUrlTitle());
    assertEquals("http://www.monsanto.com", comm.getUrl());
    assertEquals(new Long(1), comm.getCommType().getId());
    assertEquals("Letter1", comm.getCommType().getType());
    assertEquals(new Long(3), comm.getLocConRelType().getId());
    assertEquals("MANAGERS1", comm.getLocConRelType().getType());
    assertEquals(new Long(1), comm.getBpLocRelType().getId());
    assertEquals("Type Main", comm.getBpLocRelType().getType());
    assertEquals(new Long(1), comm.getStatus().getId());
    assertEquals("OPEN1", comm.getStatus().getStatus());

    comm = dao.lookupCommunicationById("2");
    assertEquals("N", comm.getActive());
  }

  public void testLookupCommunicationTypes_Returns2Types() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}),
            InitService.initCommStatusDAO(),
            InitService.initCommTypeDAO());
    List<CommType> commTypes = dao.lookupCommunicationTypes();
    assertTrue(commTypes.size() >= 2);
  }

  public void testLookupCommunicationStatuses_Returns2Types() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
            new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}),
                InitService.initCommStatusDAO(),
                InitService.initCommTypeDAO());
    List<CommStatus> statues = dao.lookupCommunicationStatuses();
    assertTrue(statues.size() >= 4);
  }

  public void testLookupCommunicationsByBPId_ReturnsComm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    List<Communication> comms = dao.lookupCommunicationsByBPId("1");
    assertEquals(1, comms.size());
    Communication comm = comms.get(0);
    assertEquals("1", comm.getId());
    assertEquals("C�MM TEST 1", comm.getName());
    assertEquals("COMM TEST NOTES 1", comm.getNotes());
    assertEquals("Y", comm.getActive());
    assertEquals("2008-01-02", comm.getFormattedFromDate());
    assertEquals("2009-01-02", comm.getFormattedToDate());
    assertEquals("2005-01-15", comm.getFormattedDueDate());
    assertEquals("COMM 1 POLICY", comm.getUrlTitle());
    assertEquals("http://www.monsanto.com", comm.getUrl());
    assertEquals(new Long(1), comm.getCommType().getId());
    assertEquals("Letter1", comm.getCommType().getType());
    assertEquals(new Long(3), comm.getLocConRelType().getId());
    assertEquals("MANAGERS1", comm.getLocConRelType().getType());
    assertEquals(new Long(1), comm.getBpLocRelType().getId());
    assertEquals("Type Main", comm.getBpLocRelType().getType());
    assertEquals(new Long(1), comm.getStatus().getId());
    assertEquals("OPEN1", comm.getStatus().getStatus());
  }

  public void testLookupCommunicationsByLocationId_ReturnsComm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    List<Communication> comms = dao.lookupCommunicationsByLocationId("1");
    assertEquals(1, comms.size());
    Communication comm = comms.get(0);
    assertEquals("1", comm.getId());
    assertEquals("C�MM TEST 1", comm.getName());
    assertEquals("COMM TEST NOTES 1", comm.getNotes());
    assertEquals("Y", comm.getActive());
    assertEquals("2008-01-02", comm.getFormattedFromDate());
    assertEquals("2009-01-02", comm.getFormattedToDate());
    assertEquals("2005-01-15", comm.getFormattedDueDate());
    assertEquals("COMM 1 POLICY", comm.getUrlTitle());
    assertEquals("http://www.monsanto.com", comm.getUrl());
    assertEquals(new Long(1), comm.getCommType().getId());
    assertEquals("Letter1", comm.getCommType().getType());
    assertEquals(new Long(3), comm.getLocConRelType().getId());
    assertEquals("MANAGERS1", comm.getLocConRelType().getType());
    assertEquals(new Long(1), comm.getBpLocRelType().getId());
    assertEquals("Type Main", comm.getBpLocRelType().getType());
    assertEquals(new Long(1), comm.getStatus().getId());
    assertEquals("OPEN1", comm.getStatus().getStatus());
  }

  public void testLookupCommunicationsByContactId_ReturnsComm() throws Exception {
    CommunicationDAO dao = new DBTemplateCommunicationDAO(
        new DBTemplateImpl(getTransactionManager(), new String[]{"database/dbtemplate.xml"}), new MockDAO<CommStatus, Long>(), new MockDAO<CommType, Long>());
    List<Communication> comms = dao.lookupCommunicationsByContactId("1");
    assertEquals(1, comms.size());
    Communication comm = comms.get(0);
    assertEquals("1", comm.getId());
    assertEquals("C�MM TEST 1", comm.getName());
    assertEquals("COMM TEST NOTES 1", comm.getNotes());
    assertEquals("Y", comm.getActive());
    assertEquals("2008-01-02", comm.getFormattedFromDate());
    assertEquals("2009-01-02", comm.getFormattedToDate());
    assertEquals("2005-01-15", comm.getFormattedDueDate());
    assertEquals("COMM 1 POLICY", comm.getUrlTitle());
    assertEquals("http://www.monsanto.com", comm.getUrl());
    assertEquals(new Long("1"), comm.getCommType().getId());
    assertEquals("Letter1", comm.getCommType().getType());
    assertEquals(new Long("3"), comm.getLocConRelType().getId());
    assertEquals("MANAGERS1", comm.getLocConRelType().getType());
    assertEquals(new Long("1"), comm.getBpLocRelType().getId());
    assertEquals("Type Main", comm.getBpLocRelType().getType());
    assertEquals(new Long("1"), comm.getStatus().getId());
    assertEquals("OPEN1", comm.getStatus().getStatus());
  }

  private String getFormattedDate(Date date) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    try {
      return sdf.format(date);
    }
    catch (Exception e) {
      return "";
    }
  }

  private Date getDate(int year, int month, int date) {
    Calendar cal = Calendar.getInstance();
    cal.set(Calendar.YEAR, year);
    cal.set(Calendar.MONTH, month);
    cal.set(Calendar.DATE, date);
    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

    String dateStr = sdf.format(cal.getTime());

    try {
      return sdf.parse(dateStr);
    } catch (ParseException e) {
      e.printStackTrace();
    }
    return null;
  }

}