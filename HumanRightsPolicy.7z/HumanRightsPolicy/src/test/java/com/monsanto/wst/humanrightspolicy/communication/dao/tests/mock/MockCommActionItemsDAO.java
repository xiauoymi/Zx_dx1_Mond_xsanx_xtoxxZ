package com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock;

import com.monsanto.wst.humanrightspolicy.communication.dao.dbtemplate.DBTemplateCommActionItemsDAO;
import com.monsanto.wst.humanrightspolicy.model.Action;
import org.w3c.dom.Document;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Sep 29, 2008
 * Time: 12:16:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockCommActionItemsDAO extends DBTemplateCommActionItemsDAO {
  private boolean addActionItemCalled;
  private List<Action> actionItems;

  public MockCommActionItemsDAO(List<Action> actionItems) {
    this.actionItems = actionItems;
  }

  public boolean isAddActionItemCalled() {
    return addActionItemCalled;
  }

  public void addActionItem(String commID, String actionID) {
    if(commID == null)
      return;
    addActionItemCalled = true;
  }

  public List<Action> lookupActionItemsByCommId(String id) {
//    if(id == null)
//    return new ArrayList();
    return  actionItems;
  }

  public Document lookupActionItemsByCommIdAsXML(String id) {
    return super.getActionItemsAsXML(actionItems);
  }

}
