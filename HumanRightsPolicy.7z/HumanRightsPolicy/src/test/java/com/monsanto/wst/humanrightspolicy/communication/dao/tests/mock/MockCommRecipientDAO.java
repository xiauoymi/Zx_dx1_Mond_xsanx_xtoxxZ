/*
 MockCommRecipientDAO was created on Jun 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock;

import com.monsanto.wst.humanrightspolicy.communication.dao.CommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.model.CommRecipient;
import com.monsanto.wst.humanrightspolicy.model.CommRecipientImpl;
import com.monsanto.wst.humanrightspolicy.model.Communication;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockCommRecipientDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-09-03 13:49:03 $
 *
 * @author sspati1
 * @version $Revision: 1.9 $
 */
public class MockCommRecipientDAO implements CommRecipientDAO {
  private List<Communication> comms = new ArrayList<Communication>();
  private final List<CommRecipient> recipients;
  private boolean updateDoneFlagForRecipientCalled;
  private boolean deleteAllRecipientsCalled;
  private boolean updateDoneFlagForAllRecipientsCalled;
  private boolean addRecipientCalled;
  private boolean addRecipientsCalled;
  private boolean updateDoneFlagForSelectedRecipientsCalled;
  private boolean deleteSelectedRecipientsCalled;
  private List<String> selectedRecipientIds;

  public MockCommRecipientDAO(List<Communication> comms, List<CommRecipient> recipients) {
    this.comms = comms;
    this.recipients = recipients;
  }

  public List<CommRecipient> lookupRecipientsByCommId(String commId) {
    return recipients;
  }

  public List<CommRecipient> lookupRecipientsNotAssociatedWithThisCommunicationByCriteria(CommRecipient commRecipient) {
    return recipients;
  }

  public List<CommRecipient> lookupRecipientsForCommunicationByCriteria(CommRecipient criteria) {
    return null;
  }

  public List<String> lookupRecipientsNotMarkedAsDone(String commId) {
    List<String> ids = new ArrayList<String>();
    ids.add("1");
    return ids;
  }

  public void updateDoneFlagForRecipient(String commId, String recipientId, String doneFlag) {
    this.updateDoneFlagForRecipientCalled = true;
  }

  public void updateDoneFlagForSelectedRecipients(String commId, List<String> selectedRecipientIds, String doneFlag
  ) {
    this.updateDoneFlagForSelectedRecipientsCalled = true;
    this.selectedRecipientIds = selectedRecipientIds;
  }

  public void updateDoneFlagForAllRecipients(String commId, String doneFlag) {
    this.updateDoneFlagForAllRecipientsCalled = true;
  }

  public void deleteAllRecipients(String commId) {
    this.deleteAllRecipientsCalled = true;
  }

  public void deleteSelectedRecipients(String commId, List<String> selectedRecipientIds) {
    this.deleteSelectedRecipientsCalled = true;
    this.selectedRecipientIds = selectedRecipientIds;
  }

  public void addRecipient(String commId, String recipientId) {
    this.addRecipientCalled = true;
    recipients.add(new CommRecipientImpl(recipientId, null, commId, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null));
  }

  public void addRecipients(String commId, List<CommRecipient> recipients) {
    this.addRecipientsCalled = true;
  }

  public boolean isUpdateDoneFlagForRecipientCalled() {
    return updateDoneFlagForRecipientCalled;
  }

  public boolean isDeleteAllRecipientsCalled() {
    return deleteAllRecipientsCalled;
  }

  public boolean isUpdateDoneFlagForAllRecipientsCalled() {
    return updateDoneFlagForAllRecipientsCalled;
  }

  public boolean isAddRecipientCalled() {
    return addRecipientCalled;
  }

  public boolean isAddRecipientsCalled() {
    return addRecipientsCalled;
  }

  public boolean isUpdateDoneFlagForSelectedRecipientsCalled() {
    return updateDoneFlagForSelectedRecipientsCalled;
  }

  public boolean isDeleteSelectedRecipientsCalled() {
    return deleteSelectedRecipientsCalled;
  }

  public List<String> getSelectedRecipientIds() {
    return selectedRecipientIds;
  }
}