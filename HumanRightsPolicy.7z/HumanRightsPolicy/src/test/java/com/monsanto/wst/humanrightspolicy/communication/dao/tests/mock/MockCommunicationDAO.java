/*
 MockCommunicationDAO was created on Apr 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock;

import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: MockCommunicationDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-10-17 15:36:23 $
 *
 * @author sspati1
 * @version $Revision: 1.21 $
 */
public class MockCommunicationDAO implements CommunicationDAO {
  private List<Communication> comms = new ArrayList<Communication>();
  private boolean updateCommCalled;
  private boolean addCommCalled;
  private boolean deactivateCommCalled;
  private boolean deactivateSelectedCommunicationsCalled;
  private List<String> selectedIds;

  public MockCommunicationDAO(List<Communication> comms) {
    this.comms = comms;
  }

  public List<Communication> lookupMyCommunications() {
    return comms;
  }

  public List<Communication> lookupCommunicationByCriteria(CommunicationSearchCriteria criteria) {
    return comms;
  }

  public Communication lookupCommunicationById(String commId) {
    for (Communication comm : comms) {
      if (comm.getId().equalsIgnoreCase(commId)) {
        return comm;
      }
    }
    return null;
  }

  public void updateCommunication(String commId, String name, String notes, Date fromDate, Date toDate,
                                  Date dueDate, String active, String urlTitle, String url, CommType commType,
                                  CommStatus status,
                                  ContactType peopleType,
                                  LocationType locType, Date dateCompleted) {
    this.updateCommCalled = true;
  }

  public String addCommunication(String name, String notes, Date fromDate, Date toDate, Date dueDate, String active,
                                 String urlTitle, String url, CommType commType, CommStatus status,
                                 ContactType peopleType,
                                 LocationType locType,
                                 String copiedFromCommId, Date dateCompleted) {
    this.addCommCalled = true;
    return "12";
  }

  public void deactivateSelectedCommunications(List<String> selectedIds) {
    this.deactivateSelectedCommunicationsCalled = true;
    this.selectedIds = selectedIds;
  }

  public List<CommType> lookupCommunicationTypes() {
    List<CommType> types = new ArrayList<CommType>();
    types.add(new CommType(1L, "Letter"));
    types.add(new CommType(2L, "Training"));
    return types;
  }

  public List<CommStatus> lookupCommunicationStatuses() {
    List<CommStatus> statuses = new ArrayList<CommStatus>();
    statuses.add(new CommStatus(1L, "New"));
    statuses.add(new CommStatus(2L, "Open"));
    statuses.add(new CommStatus(3L, "Raady To send"));
    statuses.add(new CommStatus(4L, "Closed"));
    return statuses;
  }

  public List<Communication> lookupCommunicationsByBPId(String bpId) {
    return this.comms;
  }

  public List<Communication> lookupCommunicationsByLocationId(String locationId) {
    return this.comms;
  }

  public List<Communication> lookupCommunicationsByContactId(String contactId) {
    return this.comms;
  }

  public boolean isUpdateCommCalled() {
    return updateCommCalled;
  }

  public boolean isAddCommCalled() {
    return addCommCalled;
  }

  public boolean isDeactivateCommCalled() {
    return deactivateCommCalled;
  }

  public boolean isDeactivateSelectedCommunicationsCalled() {
    return deactivateSelectedCommunicationsCalled;
  }

  public List<String> getSelectedIds() {
    return selectedIds;
  }
}