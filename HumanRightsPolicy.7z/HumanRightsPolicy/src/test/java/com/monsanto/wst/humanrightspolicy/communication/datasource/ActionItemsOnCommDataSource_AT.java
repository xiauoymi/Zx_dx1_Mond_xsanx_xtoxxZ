package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.humanrightspolicy.action.ActionConstants;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.controller.CommActionItemsController;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.model.CommunicationImpl;
import com.monsanto.wst.humanrightspolicy.testUtils.HumanRightsPolicyDatabaseTestCase;
import com.monsanto.wst.humanrightspolicy.testUtils.mock.MockUCCHelperForHrp;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.custommonkey.xmlunit.XMLTestCase;
import org.custommonkey.xmlunit.exceptions.XpathException;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.List;

/**
 * User: afhyat
 */
public class ActionItemsOnCommDataSource_AT extends HumanRightsPolicyDatabaseTestCase {

    private MockUCCHelper helper;

    protected void setUp() throws Exception {
        super.setUp();
        helper = new MockUCCHelperForHrp("KJJOHN2");
    }

    public void testGetData_AddActionItemAndLookupActionAddedToTheCommunicationPlan() throws Exception {
        helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "77777");
        CommActionItemsController controller = new CommActionItemsController();

        CommunicationService commService = InitService.initCommunicationService();
        ActionItemsOnCommDataSource dataSource = new ActionItemsOnCommDataSource(helper, commService);

        // The following lookup is done to ensure that the number of action items in the communication plan
        // increased by 1 after addition of 1 more action to the communication plan with ID 77777
        List<Action> actionsList = dataSource.getData();
        int numOfActions = actionsList.size();

        addActionItemToCommPlan(controller);

        actionsList = dataSource.getData();
        int numOfActionsAfterAddingActionToComm = actionsList.size();

        assertEquals("Number of action items in the communication plan did not increase by 1.", numOfActions + 1,
                numOfActionsAfterAddingActionToComm);

        CommunicationImpl commImpl = (CommunicationImpl) commService.lookupCommunicationById("77777");
        Document resultsDoc = commImpl.getCommActionItemsDAO().getActionItemsAsXML(actionsList);
        assertActionFromDocument(resultsDoc, "action1");
    }

    private void addActionItemToCommPlan(CommActionItemsController controller) throws IOException {
        helper.setRequestParameterValue(HRPMainConstants.METHOD, "addActionItem");
        helper.setRequestParameterValue(ActionConstants.ACTION_NAME, "action1");
        helper.setRequestParameterValue(ActionConstants.ACTION_DUE_DATE, "2008-08-02");
        helper.setRequestParameterValue(ActionConstants.ACTION_START_DATE, "2008-07-02");
        helper.setRequestParameterValue(ActionConstants.ACTION_DATE_COMPLETED, "2008-08-02");
        helper.setRequestParameterValue(ActionConstants.ACTION_STATUS, "12");
        helper.setRequestParameterValue(ActionConstants.ACTION_PRIORITY, "13");
        helper.setRequestParameterValue(ActionConstants.ACTION_PERCENT_COMPLETE, "50");
        helper.setRequestParameterValue(ActionConstants.ACTION_DESCRIPTION, "action1 desc");
        controller.run(helper);
    }

    private void assertActionFromDocument(Document doc, String actionName) throws TransformerException, XpathException {
        String actionXPath = "/actionsList/action[actionName/text()='" + actionName + "']";
        XMLTestCase xmlTest = new XMLTestCase() {
        };

        xmlTest.assertXpathExists(actionXPath, doc);
        xmlTest.assertXpathEvaluatesTo("action1", actionXPath + "/actionName", doc);
        xmlTest.assertXpathEvaluatesTo("2008-07-02", actionXPath + "/actionStartDate", doc);
//     xmlTest.assertXpathEvaluatesTo("2008-08-02", "//actionDueDate", doc);
//     xmlTest.assertXpathEvaluatesTo("2008-08-02", "//actionDateCompleted", doc);
        xmlTest.assertXpathEvaluatesTo("50", actionXPath + "/actionPercentComplete", doc);
        xmlTest.assertXpathEvaluatesTo("action1 desc", actionXPath + "/actionDescription", doc);
        xmlTest.assertXpathEvaluatesTo("In Progress", actionXPath + "/actionStatus", doc);
        xmlTest.assertXpathEvaluatesTo("High", actionXPath + "/actionPriority", doc);
    }
}
