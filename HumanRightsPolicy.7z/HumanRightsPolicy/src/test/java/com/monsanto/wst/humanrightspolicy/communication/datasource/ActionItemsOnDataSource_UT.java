package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.service.tests.mock.MockCommunicationService;
import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.model.Communication;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockCommunication;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: afhyat
 * Date: Oct 2, 2008
 * Time: 9:40:51 AM
 * To change this template use File | Settings | File Templates.
 */
public class ActionItemsOnDataSource_UT extends TestCase {

  private MockUCCHelper helper = null;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper(null);
  }

  public void testGetData_GetActionItemsAsList() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "12");
    Communication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
        1L, "Letter", 4L, "New", 2L, "Contact", 3L, "Main", "112", null);
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(comm);
    MockCommunicationService commService = new MockCommunicationService(comms);
    commService.addActionItem("12", "22");
    assertTrue(commService.isAddActionItemCalled());
    assertTrue(commService.getNumOfActionItemsAdded() == 1);
    List<Action> actionItemsList = commService.getActionItemsAsList("12");
    assertNotNull(actionItemsList);
    assertEquals(1, actionItemsList.size());
    ActionItemsOnCommDataSource dataSource = new ActionItemsOnCommDataSource(helper, commService);
    List<Action> actionList = dataSource.getData();
    assertNotNull(actionList);
    assertEquals(1, actionList.size());
  }

}
