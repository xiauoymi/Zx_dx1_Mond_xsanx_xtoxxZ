/*
 CommunicationComaparators_UT was created on Apr 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.wst.humanrightspolicy.model.Communication;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockCommunication;
import junit.framework.TestCase;

import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;

/**
 * Filename:    $RCSfile: CommunicationComaparators_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:20 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public class CommunicationComaparators_UT extends TestCase {
  private Communication testComm1;
  private Communication testComm2;
  private Communication testComm3;
  private Communication testComm4;

  protected void setUp() throws Exception {
    super.setUp();

    testComm1 = new MockCommunication("1", "DDD", "DDD NOTES", getDate(1), new Date(), getDate(4), "Y",
            1L, "ZZZ", 2L, "MMM", 3L, "EEE", 4L, "NNN", "11", null);
    testComm2 = new MockCommunication("2", "CCC", "CCC NOTES", getDate(-1), new Date(), getDate(-2), "Y",
            1L, "YYY", 2L, "HHH", 3L, "GGG", 4L, "QQQ", "22", null);
    testComm3 = new MockCommunication("3", "BBB", "BBB NOTES", getDate(-3), new Date(), getDate(0), "Y",
            1L, "XXX", 2L, "TTT", 3L, "HHH", 4L, "PPP", "33", null);
    testComm4 = new MockCommunication("4", "aAA", "AAA NOTES", getDate(3), new Date(), getDate(1), "Y",
            1L, "WWW", 2L, "QQQ", 3L, "FFF", 4L, "OOO", "44", null);
  }

  private void assertOrderIsCorrect(Comparator<XmlObject> comparator, Communication comm1, Communication comm2, Communication comm3, Communication comm4) {
    assertTrue(comparator.compare(comm1, comm2) < 0);
    assertTrue(comparator.compare(comm2, comm1) > 0);

    assertTrue(comparator.compare(comm2, comm3) < 0);
    assertTrue(comparator.compare(comm3, comm2) > 0);

    assertTrue(comparator.compare(comm3, comm4) < 0);
    assertTrue(comparator.compare(comm4, comm3) > 0);

    assertEquals(0, comparator.compare(comm1, comm1));
    assertEquals(0, comparator.compare(comm2, comm2));
    assertEquals(0, comparator.compare(comm3, comm3));
    assertEquals(0, comparator.compare(comm4, comm4));
  }

  public void testSortById() throws Exception {
    Comparator<XmlObject> comparator = new CommunicationDefaultComparator();
    assertOrderIsCorrect(comparator, testComm1, testComm2, testComm3, testComm4);
  }

  public void testSortByFromDate() throws Exception {
    Comparator<XmlObject> comparator = new CommunicationFromPeriodComparator();
    assertOrderIsCorrect(comparator, testComm3, testComm2, testComm1, testComm4);
  }

  public void testSortByName() throws Exception {
    Comparator<XmlObject> comparator = new CommunicationNameComparator();
    assertOrderIsCorrect(comparator, testComm4, testComm3, testComm2, testComm1);
  }

  public void testSortByCommType() throws Exception {
    Comparator<XmlObject> comparator = new CommunicationTypeComparator();
    assertOrderIsCorrect(comparator, testComm4, testComm3, testComm2, testComm1);
  }

  public void testSortByRecipientType() throws Exception {
    Comparator<XmlObject> comparator = new CommunicationRecipientTypeComparator();
    assertOrderIsCorrect(comparator, testComm1, testComm4, testComm2, testComm3);
  }

  public void testSortByLocationType() throws Exception {
    Comparator<XmlObject> comparator = new CommunicationLocationTypeComparator();
    assertOrderIsCorrect(comparator, testComm1, testComm4, testComm3, testComm2);
  }

  public void testSortByStatus() throws Exception {
    Comparator<XmlObject> comparator = new CommunicationStatusComparator();
    assertOrderIsCorrect(comparator, testComm2, testComm1, testComm4, testComm3);
  }

  public void testSortByDueDate() throws Exception {
    Comparator<XmlObject> comparator = new CommunicationDueDateComparator();
    assertOrderIsCorrect(comparator, testComm2, testComm3, testComm4, testComm1);
  }

  private Date getDate(int numDaysToAdd){
    Calendar cal = Calendar.getInstance();
    cal.setTime(new Date());
    cal.add(Calendar.DATE, numDaysToAdd);
    return cal.getTime();
  }
}