/*
 CommunicationDataSourceForBP_AT was created on Jun 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.testUtils.HumanRightsPolicyDatabaseTestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationDataSourceForBP_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-02 20:12:51 $
 *
 * @author sspati1
 * @version $Revision: 1.6 $
 */
public class CommunicationDataSourceForBP_AT extends HumanRightsPolicyDatabaseTestCase {
  private MockUCCHelper helper = null;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper(null, false, new KerberosStandaloneCredential());
  }

  public void testGetData_GoToCommunications_SeeAListOfCommunications() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.MENU, "allcomm");
    helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, "1");
    CommunicationDataSource dataSource = new CommunicationDataSourceForBP(helper);
    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(1, data.size());
  }
}