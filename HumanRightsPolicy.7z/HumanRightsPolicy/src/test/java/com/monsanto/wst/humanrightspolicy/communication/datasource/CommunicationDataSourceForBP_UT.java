/*
 CommunicationDataSourceForBP_UT was created on Jun 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.tests.mock.MockLookupBPService;
import com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock.MockCommunicationDAO;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.Communication;
import com.monsanto.wst.humanrightspolicy.model.CommunicationImpl;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockBusinessPartnerImpl;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationDataSourceForBP_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:20 $
 *
 * @author sspati1
 * @version $Revision: 1.13 $
 */
public class CommunicationDataSourceForBP_UT extends XMLTestCase {
  private MockUCCHelper helper = null;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper(null);
  }
  public void testCreate() throws Exception {
    CommunicationDataSource dataSource = new CommunicationDataSourceForBP(helper, null);
    assertNotNull(dataSource);
  }

  public void testGetData_ReturnComms() throws Exception {
    CommunicationDataSource dataSource = getCommunicationDataSourceForBP();
    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(2, data.size());
    Document commdoc = DOMUtil.stringToXML(data.get(0).toXml());

    assertXpathEvaluatesTo("11", "/communication/id", commdoc);
    assertXpathEvaluatesTo("commName1", "/communication/name", commdoc);
    assertXpathEvaluatesTo("", "/communication/fromPeriod", commdoc);
    assertXpathEvaluatesTo(getFormattedDate(new Date()), "/communication/toPeriod", commdoc);
    assertXpathEvaluatesTo("Letter", "/communication/commTypeValue", commdoc);
    assertXpathEvaluatesTo("Contact", "/communication/recipientTypeValue", commdoc);
    assertXpathEvaluatesTo("Main", "/communication/locTypeValue", commdoc);
    assertXpathEvaluatesTo("New", "/communication/status", commdoc);
    assertXpathEvaluatesTo("/humanrightspolicy/servlet/communication?method=lookupCommunication&commId=11&menu=myComms",
        "/communication/viewUrl", commdoc);

    commdoc = DOMUtil.stringToXML(data.get(1).toXml());
    assertXpathEvaluatesTo("22", "/communication/id", commdoc);
    assertXpathEvaluatesTo("commName2", "/communication/name", commdoc);
    assertXpathEvaluatesTo(getFormattedDate(new Date()), "/communication/fromPeriod", commdoc);
    assertXpathEvaluatesTo("", "/communication/toPeriod", commdoc);
    assertXpathEvaluatesTo("Worker", "/communication/recipientTypeValue", commdoc);
    assertXpathEvaluatesTo("Plant", "/communication/locTypeValue", commdoc);
    assertXpathEvaluatesTo("Open", "/communication/status", commdoc);
    assertXpathEvaluatesTo("/humanrightspolicy/servlet/communication?method=lookupCommunication&commId=22&menu=myComms",
        "/communication/viewUrl", commdoc);
  }

  private CommunicationDataSource getCommunicationDataSourceForBP() {
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(new CommunicationImpl("11", "commName1", "comm notes1", null, new Date(), null, "Y", null, null, 1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "111", null));
    comms.add(new CommunicationImpl("22", "commName2", "comm notes2", new Date(), null, null, "Y", null, null, 5L, "Training",
        8L, "Open", 6L, "Worker", 7L, "Plant", "222", null));
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, null, new MockCommunicationDAO(comms),
        null);
    CommunicationDataSource dataSource = new CommunicationDataSourceForBP(helper, new MockLookupBPService(bp));
    return dataSource;
  }

  private String getFormattedDate(Date date) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    try {
      return sdf.format(date);
    }
    catch (Exception e) {
      return "";
    }
  }
}