/*
 CommunicationDataSource_UT was created on Apr 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.service.tests.mock.MockCommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.Communication;
import com.monsanto.wst.humanrightspolicy.model.CommunicationImpl;
import com.monsanto.wst.humanrightspolicy.model.CommunicationSearchCriteria;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:20 $
 *
 * @author sspati1
 * @version $Revision: 1.16 $
 */
public class CommunicationDataSource_UT extends XMLTestCase {
  private MockUCCHelper helper = null;
  private MockCommunicationService commService;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper(null);
  }

  public void testSearchCommXML_MyComms_ValidateXML() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.SCOPE, "My");
    CommunicationDataSource dataSource = getCommunicationDataSource();

    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(2, data.size());
    Document commdoc = DOMUtil.stringToXML(data.get(0).toXml());

    assertXpathEvaluatesTo("11", "/communication/id", commdoc);
    assertXpathEvaluatesTo("commName1", "/communication/name", commdoc);
    assertXpathEvaluatesTo("", "/communication/fromPeriod", commdoc);
    assertXpathEvaluatesTo(getFormattedDate(new Date()), "/communication/toPeriod", commdoc);
    assertXpathEvaluatesTo("Letter", "/communication/commTypeValue", commdoc);
    assertXpathEvaluatesTo("Contact", "/communication/recipientTypeValue", commdoc);
    assertXpathEvaluatesTo("Main", "/communication/locTypeValue", commdoc);
    assertXpathEvaluatesTo("New", "/communication/status", commdoc);
    assertXpathEvaluatesTo("/humanrightspolicy/servlet/communication?method=lookupCommunication&commId=11&menu=myComms",
        "/communication/viewUrl", commdoc);

    commdoc = DOMUtil.stringToXML(data.get(1).toXml());
    assertXpathEvaluatesTo("22", "/communication/id", commdoc);
    assertXpathEvaluatesTo("commName2", "/communication/name", commdoc);
    assertXpathEvaluatesTo(getFormattedDate(new Date()), "/communication/fromPeriod", commdoc);
    assertXpathEvaluatesTo("", "/communication/toPeriod", commdoc);
    assertXpathEvaluatesTo("Worker", "/communication/recipientTypeValue", commdoc);
    assertXpathEvaluatesTo("Plant", "/communication/locTypeValue", commdoc);
    assertXpathEvaluatesTo(getFormattedDate(new Date()), "/communication/dueDate", commdoc);
    assertXpathEvaluatesTo("Closed", "/communication/status", commdoc);
    assertXpathEvaluatesTo("/humanrightspolicy/servlet/communication?method=lookupCommunication&commId=22&menu=myComms",
        "/communication/viewUrl", commdoc);

    assertTrue(commService.isLookupMyCommsCalled());
    assertFalse(commService.isLookupCommsByCriteriaCalled());
  }

  public void testSearchCommXML_AllComms_ValidateXML() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_NAME, "new comm name");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_DUE_DATE_FROM, "2008-02-22");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_DUE_DATE_TO, "2008-03-21");
    helper.setRequestParameterValue(CommunicationConstants.COMM_TYPE_ID, "12");
    helper.setRequestParameterValue(CommunicationConstants.COMM_STATUD_ID, "13");
    helper.setRequestParameterValue(CommunicationConstants.COMM_PEOPLE_TYPE_ID, "14");
    helper.setRequestParameterValue(CommunicationConstants.COMM_LOC_TYPE_ID, "15");
    helper.setRequestParameterValue(HRPMainConstants.COMPANY_STATE, "11");
    helper.setRequestParameterValue(HRPMainConstants.COMPANY_COUNTRY, "22");
    helper.setRequestParameterValue(HRPMainConstants.REGION, "33");
    CommunicationDataSource dataSource = getCommunicationDataSource();

    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(2, data.size());
    Document commdoc = DOMUtil.stringToXML(data.get(0).toXml());

    assertXpathEvaluatesTo("11", "/communication/id", commdoc);
    assertXpathEvaluatesTo("commName1", "/communication/name", commdoc);
    assertXpathEvaluatesTo("", "/communication/fromPeriod", commdoc);
    assertXpathEvaluatesTo(getFormattedDate(new Date()), "/communication/toPeriod", commdoc);
    assertXpathEvaluatesTo("Letter", "/communication/commTypeValue", commdoc);
    assertXpathEvaluatesTo("Contact", "/communication/recipientTypeValue", commdoc);
    assertXpathEvaluatesTo("Main", "/communication/locTypeValue", commdoc);
    assertXpathEvaluatesTo("New", "/communication/status", commdoc);
    assertXpathEvaluatesTo("/humanrightspolicy/servlet/communication?method=lookupCommunication&commId=11&menu=myComms",
        "/communication/viewUrl", commdoc);
    assertXpathEvaluatesTo("", "/communication/dueDate", commdoc);

    commdoc = DOMUtil.stringToXML(data.get(1).toXml());
    assertXpathEvaluatesTo("22", "/communication/id", commdoc);
    assertXpathEvaluatesTo("commName2", "/communication/name", commdoc);
    assertXpathEvaluatesTo(getFormattedDate(new Date()), "/communication/fromPeriod", commdoc);
    assertXpathEvaluatesTo(getFormattedDate(new Date()), "/communication/dueDate", commdoc);
    assertXpathEvaluatesTo("", "/communication/toPeriod", commdoc);
    assertXpathEvaluatesTo("Worker", "/communication/recipientTypeValue", commdoc);
    assertXpathEvaluatesTo("Plant", "/communication/locTypeValue", commdoc);
    assertXpathEvaluatesTo("Closed", "/communication/status", commdoc);
    assertXpathEvaluatesTo("/humanrightspolicy/servlet/communication?method=lookupCommunication&commId=22&menu=myComms",
        "/communication/viewUrl", commdoc);

    assertFalse(commService.isLookupMyCommsCalled());
    assertTrue(commService.isLookupCommsByCriteriaCalled());

    CommunicationSearchCriteria commSearchCriteria = commService.getCommSearchCriteria();
    Communication comm = commSearchCriteria.getCommunication();

    assertEquals("new comm name", comm.getName());
    assertNull(comm.getFromDate());
    assertNull(comm.getToDate());
    assertEquals(new Long(12), comm.getCommType().getId());
    assertEquals(new Long(14), comm.getLocConRelType().getId());
    assertEquals(new Long(15), comm.getBpLocRelType().getId());
    assertEquals(new Long(13L), comm.getStatus().getId());
    assertEquals("11", commSearchCriteria.getStateId());
    assertEquals("22", commSearchCriteria.getCountryId());
    assertEquals("33", commSearchCriteria.getRegionId());
    assertEquals("2008-02-22", getFormattedDate(commSearchCriteria.getDueDateFrom()));
    assertEquals("2008-03-21", getFormattedDate(commSearchCriteria.getDueDateTo()));
  }

  public void testSearchCommXML_AllCommsNoValuesSelected_VerifyCriteriaHasNullValues() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_NAME, "");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_DUE_DATE_FROM, "");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_DUE_DATE_FROM, "");
    helper.setRequestParameterValue(CommunicationConstants.COMM_TYPE_ID, "");
    helper.setRequestParameterValue(CommunicationConstants.COMM_STATUD_ID, "");
    helper.setRequestParameterValue(CommunicationConstants.COMM_PEOPLE_TYPE_ID, "");
    helper.setRequestParameterValue(CommunicationConstants.COMM_LOC_TYPE_ID, "");
    helper.setRequestParameterValue(HRPMainConstants.COMPANY_STATE, "");
    helper.setRequestParameterValue(HRPMainConstants.COMPANY_COUNTRY, "");
    helper.setRequestParameterValue(HRPMainConstants.REGION, "");
    CommunicationDataSource dataSource = getCommunicationDataSource();

    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(2, data.size());

    assertFalse(commService.isLookupMyCommsCalled());
    assertTrue(commService.isLookupCommsByCriteriaCalled());

    CommunicationSearchCriteria commSearchCriteria = commService.getCommSearchCriteria();
    Communication comm = commSearchCriteria.getCommunication();

    assertNull(comm.getName());
    assertNull(comm.getFromDate());
    assertNull(comm.getToDate());
    assertNull(comm.getCommType().getId());
    assertNull(comm.getLocConRelType().getId());
    assertNull(comm.getBpLocRelType().getId());
    assertNull(comm.getStatus().getId());
    assertNull(commSearchCriteria.getStateId());
    assertNull(commSearchCriteria.getCountryId());
    assertNull(commSearchCriteria.getRegionId());
    assertNull(commSearchCriteria.getDueDateFrom());
    assertNull(commSearchCriteria.getDueDateTo());
  }

  public void testDefaultCommunicationSort() throws Exception {
    CommunicationDataSource dataSource = getCommunicationDataSource();
    Comparator<? extends XmlObject> comparator = dataSource.getComparator(null);
    assertNotNull(comparator);
    assertTrue(comparator instanceof CommunicationDefaultComparator);
  }

  public void testOtherCommunicationSorts() throws Exception {
    CommunicationDataSource dataSource = getCommunicationDataSource();
    assertTrue(dataSource.getComparator(CommunicationDataSource.FROM_PERIOD_SORT_KEY) instanceof CommunicationFromPeriodComparator);
    assertTrue(dataSource.getComparator(CommunicationDataSource.COMM_TYPE_SORT_KEY) instanceof CommunicationTypeComparator);
    assertTrue(dataSource.getComparator(CommunicationDataSource.COMM_NAME_SORT_KEY) instanceof CommunicationNameComparator);
    assertTrue(dataSource.getComparator(CommunicationDataSource.RECIPIENT_TYPE_SORT_KEY) instanceof CommunicationRecipientTypeComparator);
    assertTrue(dataSource.getComparator(CommunicationDataSource.LOC_TYPE_SORT_KEY) instanceof CommunicationLocationTypeComparator);
    assertTrue(dataSource.getComparator(CommunicationDataSource.STATUS_SORT_KEY) instanceof CommunicationStatusComparator);
    assertTrue(dataSource.getComparator(CommunicationDataSource.DUE_DATE_SORT_KEY) instanceof CommunicationDueDateComparator);
  }

  private CommunicationDataSource getCommunicationDataSource() {
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(new CommunicationImpl("11", "commName1", "comm notes1", null, new Date(), null, "Y", null, null, 1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "111", null));
    comms.add(new CommunicationImpl("22", "commName2", "comm notes2", new Date(), null, null, "Y", null, null, 5L, "Training",
        8L, "Closed", 6L, "Worker", 7L, "Plant", "222", new Date()));
    commService = new MockCommunicationService(comms);
    return new CommunicationDataSource(helper, commService);
  }

  private String getFormattedDate(Date date) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    try {
      return sdf.format(date);
    }
    catch (Exception e) {
      return "";
    }
  }
}