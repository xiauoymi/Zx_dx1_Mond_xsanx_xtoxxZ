/*
 RecipientComparators_UT was created on May 1, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.wst.humanrightspolicy.model.CommRecipient;
import com.monsanto.wst.humanrightspolicy.model.CommRecipientImpl;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import junit.framework.TestCase;

import java.util.Comparator;

/**
 * Filename:    $RCSfile: RecipientComparators_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:20 $
 *
 * @author sspati1
 * @version $Revision: 1.8 $
 */
public class RecipientComparators_UT extends TestCase {
  private CommRecipient testRecipient1;
  private CommRecipient testRecipient2;
  private CommRecipient testRecipient3;
  private CommRecipient testRecipient4;

  protected void setUp() throws Exception {
    super.setUp();

    testRecipient1 = new CommRecipientImpl("1", "1", "1", "Y", "DDD", 1L, "ZZZ", 2L, "MMM", "3", "EEE", "4", "NNN",
    "5", "GGG", "UUU", null, "1", "STREET 1", "STRRET 12", "WWW", "1111", null);
    testRecipient2 = new CommRecipientImpl("2", "2", "2", "Y", "bBB", 1L, "YYY", 2L, "OOO", "3", "FFF", "4", "PPP",
    "5", "EEE", "VVV", null, "1", "STREET 1", "STRRET 12", "WWW", "1111", null);
    testRecipient3 = new CommRecipientImpl("4", "4", "4", "Y", "CCC", 1L, "XXX", 2L, "NNN", "3", "HHH", "4", "OOO",
    "5", "FFF", "TTT", null, "1", "STREET 1", "STRRET 12", "WWW", "1111", null);
    testRecipient4 = new CommRecipientImpl("3", "3", "3", "Y", "AAA", 1L, "WWW", 2L, "PPP", "3", "GGG", "4", "QQQ",
    "5", "JJJ", "SSS", null, "1", "STREET 1", "STRRET 12", "WWW", "1111", null);
  }

  private void assertOrderIsCorrect(Comparator<XmlObject> comparator, CommRecipient rep1, CommRecipient rep2, CommRecipient rep3, CommRecipient rep4) {
    assertTrue(comparator.compare(rep1, rep2) < 0);
    assertTrue(comparator.compare(rep2, rep1) > 0);

    assertTrue(comparator.compare(rep2, rep3) < 0);
    assertTrue(comparator.compare(rep3, rep2) > 0);

    assertTrue(comparator.compare(rep3, rep4) < 0);
    assertTrue(comparator.compare(rep4, rep3) > 0);

    assertEquals(0, comparator.compare(rep1, rep1));
    assertEquals(0, comparator.compare(rep2, rep2));
    assertEquals(0, comparator.compare(rep3, rep3));
    assertEquals(0, comparator.compare(rep4, rep4));
  }

  public void testSortByContactId() throws Exception {
    Comparator<XmlObject> comparator = new RecipientDefaultComparator();
    assertOrderIsCorrect(comparator, testRecipient1, testRecipient2, testRecipient4, testRecipient3);
  }

  public void testSortByContactName() throws Exception {
    Comparator<XmlObject> comparator = new RecipientNameComparator();
    assertOrderIsCorrect(comparator, testRecipient4, testRecipient2, testRecipient3, testRecipient1);
  }

  public void testSortByBpName() throws Exception {
    Comparator<XmlObject> comparator = new RecipientCompanyComparator();
    assertOrderIsCorrect(comparator, testRecipient4, testRecipient3, testRecipient1, testRecipient2);
  }

  public void testSortByLocType() throws Exception {
    Comparator<XmlObject> comparator = new RecipientLocationTypeComparator();
    assertOrderIsCorrect(comparator, testRecipient4, testRecipient3, testRecipient2, testRecipient1);
  }

  public void testSortByContactType() throws Exception {
    Comparator<XmlObject> comparator = new RecipientTypeComparator();
    assertOrderIsCorrect(comparator, testRecipient1, testRecipient3, testRecipient2, testRecipient4);
  }

  public void testSortByCountry() throws Exception {
    Comparator<XmlObject> comparator = new RecipientCountryComparator();
    assertOrderIsCorrect(comparator, testRecipient1, testRecipient3, testRecipient2, testRecipient4);
  }

  public void testSortByState() throws Exception {
    Comparator<XmlObject> comparator = new RecipientStateComparator();
    assertOrderIsCorrect(comparator, testRecipient2, testRecipient3, testRecipient1, testRecipient4);
  }
  
  public void testSortByRegion() throws Exception {
    Comparator<XmlObject> comparator = new RecipientRegionComparator();
    assertOrderIsCorrect(comparator, testRecipient1, testRecipient2, testRecipient4, testRecipient3);
  }
}