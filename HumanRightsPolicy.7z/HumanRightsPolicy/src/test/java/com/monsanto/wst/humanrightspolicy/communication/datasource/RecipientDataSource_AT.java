/*
 RecipientDataSource_AT was created on May 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.CommRecipientImpl;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.testUtils.HumanRightsPolicyDatabaseTestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: RecipientDataSource_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:23 $
 *
 * @author sspati1
 * @version $Revision: 1.7 $
 */
public class RecipientDataSource_AT extends HumanRightsPolicyDatabaseTestCase {
  private MockUCCHelper helper = null;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper(null, false, new KerberosStandaloneCredential());
  }

  public void testGetData_GetRecipients_SeesAListOfAssociatedRecipients() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");

    RecipientDataSource dataSource = new RecipientDataSource(helper);
    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(3, data.size());
    CommRecipientImpl commRecipient = (CommRecipientImpl) data.get(0);
    assertEquals("1", commRecipient.getCommId());
    assertEquals("2", commRecipient.getContactId());
    commRecipient = (CommRecipientImpl) data.get(1);
    assertEquals("1", commRecipient.getCommId());
    assertEquals("1", commRecipient.getContactId());
    commRecipient = (CommRecipientImpl) data.get(2);
    assertEquals("1", commRecipient.getCommId());
    assertEquals("4", commRecipient.getContactId());
  }

  public void testGetData_UserSearchesForRecipients_CommHasNoChild_SeesAListOfdRecipientsByCriteria() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "2");
    helper.setRequestParameterValue(HRPMainConstants.SCOPE, "search");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_PERSON_NAME, "RAMBABU");

    RecipientDataSource dataSource = new RecipientDataSource(helper);
    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(3, data.size());
    CommRecipientImpl commRecipient = (CommRecipientImpl) data.get(0);
    assertEquals("2", commRecipient.getCommId());
    assertEquals("5", commRecipient.getContactId());
    assertEquals("0000004444", commRecipient.getSapId());
    commRecipient = (CommRecipientImpl) data.get(1);
    assertEquals("2", commRecipient.getCommId());
    assertEquals("5", commRecipient.getContactId());
    assertEquals("0000000001", commRecipient.getSapId());
    commRecipient = (CommRecipientImpl) data.get(2);
    assertNull(commRecipient.getCommId());
    assertEquals("4", commRecipient.getContactId());
  }

  public void testGetData_UserSearchesForRecipients_CommHasAGrandChild_SeesAListOfdRecipientsByCriteria() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(HRPMainConstants.SCOPE, "search");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_PERSON_NAME, "RAMBABU");

    RecipientDataSource dataSource = new RecipientDataSource(helper);
    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(4, data.size());
    CommRecipientImpl commRecipient = (CommRecipientImpl) data.get(0);
    assertEquals("1", commRecipient.getCommId());
    assertEquals("1", commRecipient.getContactId());
    commRecipient = (CommRecipientImpl) data.get(1);
    assertEquals("5", commRecipient.getCommId());
    assertEquals("5", commRecipient.getContactId());
    assertEquals("0000000001", commRecipient.getSapId());
    commRecipient = (CommRecipientImpl) data.get(2);
    assertEquals("5", commRecipient.getCommId());
    assertEquals("5", commRecipient.getContactId());
    assertEquals("0000004444", commRecipient.getSapId());
    commRecipient = (CommRecipientImpl) data.get(3);
    assertEquals("1", commRecipient.getCommId());
    assertEquals("4", commRecipient.getContactId());
  }

  public void testGetData_UserSearchesForRecipients_CommHasAGrandChildSearchBYName_SeesAListOfdRecipientsByCriteria() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "1");
    helper.setRequestParameterValue(HRPMainConstants.SCOPE, "search");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_PERSON_NAME, "RAMBABU");
    helper.setRequestParameterValue(CommunicationConstants.STATE, "10");

    RecipientDataSource dataSource = new RecipientDataSource(helper);
    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(2, data.size());
    CommRecipientImpl commRecipient = (CommRecipientImpl) data.get(0);
    assertEquals("5", commRecipient.getCommId());
    assertEquals("5", commRecipient.getContactId());
    commRecipient = (CommRecipientImpl) data.get(1);
    assertEquals("1", commRecipient.getCommId());
    assertEquals("4", commRecipient.getContactId());
  }

  public void testGetData_UserSearchesForRecipients_CommHasAParent_SeesAListOfdRecipientsByCriteria() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "5");
    helper.setRequestParameterValue(HRPMainConstants.SCOPE, "search");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_PERSON_NAME, "RAMBABU");
    helper.setRequestParameterValue(CommunicationConstants.STATE, "10");

    RecipientDataSource dataSource = new RecipientDataSource(helper);
    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(2, data.size());
    CommRecipientImpl commRecipient = (CommRecipientImpl) data.get(0);
    assertEquals("5", commRecipient.getCommId());
    assertEquals("5", commRecipient.getContactId());
    commRecipient = (CommRecipientImpl) data.get(1);
    assertEquals("1", commRecipient.getCommId());
    assertEquals("4", commRecipient.getContactId());
  }

  public void testGetData_UserSearchesForRecipients_CommHasAGrandParent_SeesAListOfdRecipientsByCriteria() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "6");
    helper.setRequestParameterValue(HRPMainConstants.SCOPE, "search");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_PERSON_NAME, "RAMBABU");
    helper.setRequestParameterValue(CommunicationConstants.STATE, "10");

    RecipientDataSource dataSource = new RecipientDataSource(helper);
    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(2, data.size());
    CommRecipientImpl commRecipient = (CommRecipientImpl) data.get(0);
    assertEquals("5", commRecipient.getCommId());
    assertEquals("5", commRecipient.getContactId());
    commRecipient = (CommRecipientImpl) data.get(1);
    assertEquals("1", commRecipient.getCommId());
    assertEquals("4", commRecipient.getContactId());
  }
}