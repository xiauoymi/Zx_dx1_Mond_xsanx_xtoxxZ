/*
 RecipientDataSource_UT was created on Apr 30, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.humanrightspolicy.communication.CommunicationConstants;
import com.monsanto.wst.humanrightspolicy.communication.service.tests.mock.MockCommunicationService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.model.CommRecipient;
import com.monsanto.wst.humanrightspolicy.model.Communication;
import com.monsanto.wst.humanrightspolicy.model.CommunicationImpl;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockCommunication;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: RecipientDataSource_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:20 $
 *
 * @author sspati1
 * @version $Revision: 1.19 $
 */
public class RecipientDataSource_UT extends XMLTestCase {
  private MockUCCHelper helper = null;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper(null);
  }

  public void testGetData_ScopeIsSerch_AccentedCharacter_ConvertedToUtf8() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_COMPANY, "ábc");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_PERSON_NAME, "áli");
    helper.setRequestParameterValue(HRPMainConstants.SCOPE, "search");

    List<Communication> comms = new ArrayList<Communication>();
    comms.add(new CommunicationImpl("11", "commName1", "comm notes1", null, new Date(), null, "Y", null, null, 1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "111", null));
    comms.add(new CommunicationImpl("22", "commName2", "comm notes2", new Date(), null, null, "Y", null, null, 5L, "Training",
        8L, "Open", 6L, "Worker", 7L, "Plant", "222", null));
    MockCommunicationService mockCommService = new MockCommunicationService(comms);
    RecipientDataSource dataSource = new RecipientDataSource(helper, mockCommService);
    dataSource.getData();
    MockCommunication comm = mockCommService.getComm();
    assertEquals("�li", comm.getCommRecipientCriteria().getName());
    assertEquals("�bc", comm.getCommRecipientCriteria().getBpName());
  }

  public void testGetData_ScopeIsNotSearch_ReturnsRecipientsForCommunication() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");

    RecipientDataSource dataSource = getRecipientDataSource();
    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(2, data.size());
    Document resultsDoc = DOMUtil.stringToXML(data.get(0).toXml());

    assertXpathEvaluatesTo("3", "/recipient/recipientId", resultsDoc);
    assertXpathEvaluatesTo("11", "/recipient/commId", resultsDoc);
    assertXpathEvaluatesTo("person name 3", "/recipient/name", resultsDoc);
    assertXpathEvaluatesTo("Y", "/recipient/isDone", resultsDoc);
    assertXpathEvaluatesTo("employee", "/recipient/recipientTypeValue", resultsDoc);
    assertXpathEvaluatesTo("bp name 3", "/recipient/company", resultsDoc);
    assertXpathEvaluatesTo("India", "/recipient/region", resultsDoc);
    assertXpathEvaluatesTo("India", "/recipient/country", resultsDoc);
    assertXpathEvaluatesTo("Gujarat", "/recipient/state", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/servlet/contacts?method=lookupContact&contactId=3&menu=allcomm",
        "/recipient/viewUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=updateDoneFlag&commId=11&recipientId=3&menu=allcomm",
        "/recipient/updateDoneFlagUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=addRecipient&recipientId=3&menu=allcomm",
        "/recipient/addRecipientUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=deleteRecipient&recipientId=3&menu=allcomm",
        "/recipient/removeUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=deleteRecipient&recipientId=3&menu=allcomm",
        "/recipient/removeUrlForAsync", resultsDoc);

    resultsDoc = DOMUtil.stringToXML(data.get(1).toXml());
    assertXpathEvaluatesTo("4", "/recipient/recipientId", resultsDoc);
    assertXpathEvaluatesTo("11", "/recipient/commId", resultsDoc);
    assertXpathEvaluatesTo("person name 4", "/recipient/name", resultsDoc);
    assertXpathEvaluatesTo("N", "/recipient/isDone", resultsDoc);
    assertXpathEvaluatesTo("manager", "/recipient/recipientTypeValue", resultsDoc);
    assertXpathEvaluatesTo("bp name 4", "/recipient/company", resultsDoc);
    assertXpathEvaluatesTo("NA", "/recipient/region", resultsDoc);
    assertXpathEvaluatesTo("United States", "/recipient/country", resultsDoc);
    assertXpathEvaluatesTo("Missouri", "/recipient/state", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/servlet/contacts?method=lookupContact&contactId=4&menu=allcomm",
        "/recipient/viewUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=updateDoneFlag&commId=11&recipientId=4&menu=allcomm",
        "/recipient/updateDoneFlagUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=addRecipient&recipientId=4&menu=allcomm",
        "/recipient/addRecipientUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=deleteRecipient&recipientId=4&menu=allcomm",
        "/recipient/removeUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=deleteRecipient&recipientId=4&menu=allcomm",
        "/recipient/removeUrlForAsync", resultsDoc);
  }

  public void testGetData_ScopeIsSearch_ReturnsRecipientsForSearchResults() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.SCOPE, "search");
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
    helper.setRequestParameterValue(CommunicationConstants.REGION, "22");
    helper.setRequestParameterValue(CommunicationConstants.STATE, "33");
    helper.setRequestParameterValue(CommunicationConstants.COUNTRY, "44");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_PERSON_NAME, "person name");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_COMPANY, "Bp company name");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_PEOPLE_TYPE_ID, "55");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_LOC_TYPE_ID, "66");
    RecipientDataSource dataSource = getRecipientDataSource();
    List<? extends XmlObject> data = dataSource.getData();
    assertNotNull(data);
    assertEquals(4, data.size());

    Document resultsDoc = DOMUtil.stringToXML(data.get(0).toXml());
    assertXpathEvaluatesTo("3", "/recipient/recipientId", resultsDoc);
    assertXpathEvaluatesTo("11", "/recipient/commId", resultsDoc);
    assertXpathEvaluatesTo("person name 3", "/recipient/name", resultsDoc);
    assertXpathEvaluatesTo("Y", "/recipient/isDone", resultsDoc);
    assertXpathEvaluatesTo("employee", "/recipient/recipientTypeValue", resultsDoc);
    assertXpathEvaluatesTo("bp name 3", "/recipient/company", resultsDoc);
    assertXpathEvaluatesTo("India", "/recipient/region", resultsDoc);
    assertXpathEvaluatesTo("India", "/recipient/country", resultsDoc);
    assertXpathEvaluatesTo("Gujarat", "/recipient/state", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/servlet/contacts?method=lookupContact&contactId=3&menu=allcomm",
        "/recipient/viewUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=updateDoneFlag&commId=11&recipientId=3&menu=allcomm",
        "/recipient/updateDoneFlagUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=addRecipient&recipientId=3&menu=allcomm",
        "/recipient/addRecipientUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=deleteRecipient&recipientId=3&menu=allcomm",
        "/recipient/removeUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=deleteRecipient&recipientId=3&menu=allcomm",
        "/recipient/removeUrlForAsync", resultsDoc);

    resultsDoc = DOMUtil.stringToXML(data.get(3).toXml());
    assertXpathEvaluatesTo("1", "/recipient/recipientId", resultsDoc);
    assertXpathEvaluatesTo("", "/recipient/commId", resultsDoc);
    assertXpathEvaluatesTo("person name 6", "/recipient/name", resultsDoc);
    assertXpathEvaluatesTo("", "/recipient/isDone", resultsDoc);
    assertXpathEvaluatesTo("employee", "/recipient/recipientTypeValue", resultsDoc);
    assertXpathEvaluatesTo("bp name 1", "/recipient/company", resultsDoc);
    assertXpathEvaluatesTo("India", "/recipient/region", resultsDoc);
    assertXpathEvaluatesTo("India", "/recipient/country", resultsDoc);
    assertXpathEvaluatesTo("Gujarat", "/recipient/state", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/servlet/contacts?method=lookupContact&contactId=1&menu=allcomm",
        "/recipient/viewUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=updateDoneFlag&commId=null&recipientId=1&menu=allcomm",
        "/recipient/updateDoneFlagUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=addRecipient&recipientId=1&menu=allcomm",
        "/recipient/addRecipientUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=deleteRecipient&recipientId=1&menu=allcomm",
        "/recipient/removeUrl", resultsDoc);
    assertXpathEvaluatesTo(
        "/humanrightspolicy/data/commRecipient?method=deleteRecipient&recipientId=1&menu=allcomm",
        "/recipient/removeUrlForAsync", resultsDoc);
  }

  public void testBuildSearchCriteriaFromRequest() throws Exception {
    helper.setRequestParameterValue(CommunicationConstants.COMM_ID, "11");
    helper.setRequestParameterValue(CommunicationConstants.REGION, "22");
    helper.setRequestParameterValue(CommunicationConstants.STATE, "33");
    helper.setRequestParameterValue(CommunicationConstants.COUNTRY, "44");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_PERSON_NAME, "person name");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_COMPANY, "Bp company name");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_PEOPLE_TYPE_ID, "55");
    helper.setRequestParameterValue(CommunicationConstants.SEARCH_LOC_TYPE_ID, "66");
    RecipientDataSource dataSource = getRecipientDataSource();
    CommRecipient criteria = dataSource.buildSearchCriteriaFromRequest();
    assertEquals("11", criteria.getCommId());
    assertEquals("22", criteria.getAddress().getRegionModel().getId());
    assertEquals("33", criteria.getAddress().getStateModel().getId());
    assertEquals("44", criteria.getAddress().getCountryModel().getId());
    assertEquals("person name", criteria.getName());
    assertEquals("Bp company name", criteria.getBpName());
    assertEquals(new Long(55), criteria.getLocConRelType().getId());
    assertEquals(new Long(66), criteria.getBpLocRelType().getId());
  }

  public void testDefaultCommunicationSort() throws Exception {
    RecipientDataSource dataSource = getRecipientDataSource();
    Comparator<? extends XmlObject> comparator = dataSource.getComparator(null);
    assertNotNull(comparator);
    assertTrue(comparator instanceof RecipientComparartor);
  }

  public void testOtherCommunicationSorts() throws Exception {
    RecipientDataSource dataSource = getRecipientDataSource();
    assertTrue(dataSource.getComparator(RecipientDataSource.NAME_SORT_KEY) instanceof RecipientNameComparator);
    assertTrue(dataSource.getComparator(RecipientDataSource.RECIPIENT_TYPE_VALUE_SORT_KEY) instanceof RecipientTypeComparator);
    assertTrue(dataSource.getComparator(RecipientDataSource.COMPANY_SORT_KEY) instanceof RecipientCompanyComparator);
    assertTrue(dataSource.getComparator(RecipientDataSource.STATE_SORT_KEY) instanceof RecipientStateComparator);
    assertTrue(dataSource.getComparator(RecipientDataSource.COUNTRY_SORT_KEY) instanceof RecipientCountryComparator);
    assertTrue(dataSource.getComparator(RecipientDataSource.REGION_SORT_KEY) instanceof RecipientRegionComparator);
  }

  private RecipientDataSource getRecipientDataSource() {
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(new CommunicationImpl("11", "commName1", "comm notes1", null, new Date(), null, "Y", null, null, 1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "111", null));
    comms.add(new CommunicationImpl("22", "commName2", "comm notes2", new Date(), null, null, "Y", null, null, 5L, "Training",
        8L, "Open", 6L, "Worker", 7L, "Plant", "222", null));
    return new RecipientDataSource(helper, new MockCommunicationService(comms));
  }

}