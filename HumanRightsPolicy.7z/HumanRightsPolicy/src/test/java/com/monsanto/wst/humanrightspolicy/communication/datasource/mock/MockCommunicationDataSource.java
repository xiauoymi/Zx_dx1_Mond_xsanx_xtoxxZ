/*
 MockCommunicationDataSource was created on Jul 8, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource.mock;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.communication.datasource.CommunicationDataSource;
import com.monsanto.wst.humanrightspolicy.model.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: MockCommunicationDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-12-04 16:49:57 $
 *
 * @author sspati1
 * @version $Revision: 1.8 $
 */
public class MockCommunicationDataSource extends CommunicationDataSource {
  public MockCommunicationDataSource(UCCHelper helper) {
    this(new UCCHelperParameterCollection(helper));
  }

  public MockCommunicationDataSource(ParameterCollection params) {
    super(params);
  }

  public List<? extends XmlObject> getData() throws IOException {
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(new CommunicationImpl("11", "commName1", "comm notes1", null, new Date(), null, "Y", null, null, 1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "111", null));
    comms.add(new CommunicationImpl("22", "commName2", "comm notes2", new Date(), null, null, "Y", null, null, 5L, "Training",
        8L, "Open", 6L, "Worker", 7L, "Plant", "222", null));
    comms.add(new CommunicationImpl("33", "commName2", "comm notes2", new Date(), null, null, "Y", null, null, 5L, "Training",
        8L, "Open", 6L, "Worker", 7L, "Plant", "333", null));
    return comms;
  }
}