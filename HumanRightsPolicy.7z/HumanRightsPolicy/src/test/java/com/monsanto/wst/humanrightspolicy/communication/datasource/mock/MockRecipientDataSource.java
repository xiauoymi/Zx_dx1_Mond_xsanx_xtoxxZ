/*
 MockRecipientDataSource was created on Jul 8, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.datasource.mock;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.wst.humanrightspolicy.communication.datasource.RecipientDataSource;
import com.monsanto.wst.humanrightspolicy.model.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockRecipientDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-12-04 16:50:10 $
 *
 * @author sspati1
 * @version $Revision: 1.4 $
 */
public class MockRecipientDataSource extends RecipientDataSource {
  public MockRecipientDataSource(UCCHelper helper) {
    this(new UCCHelperParameterCollection(helper));
  }

  public MockRecipientDataSource(ParameterCollection params) {
    super(params);
  }

  public List<? extends XmlObject> getData() throws IOException {
    List<CommRecipient> recipients = new ArrayList<CommRecipient>();
    recipients.add(new CommRecipientImpl("1", "3", "11", "Y", "person name 3", 11L, "Plant", 12L, "employee",
        "12", "India", "13", "India", "14", "Gujarat", "bp name 3", null, null, "street", "street1", "testCity",
        "12345",
        null));
    recipients.add(new CommRecipientImpl("2", "4", "11", "N", "person name 4", 12L, "Type 1", 13L, "manager",
        "13", "NA", "14", "United States", "15", "Missouri", "bp name 4", null, null, "streetTest", "streetTest1",
        "testCity1", "85285",
        null));
    recipients.add(new CommRecipientImpl("3", "4", "11", "N", "person name 4", 12L, "Type 1", 13L, "manager",
        "13", "NA", "14", "United States", "15", "Missouri", "bp name 4", null, null, "streetTest", "streetTest1",
        "testCity1", "85285",
        null));
    return recipients;

  }
}