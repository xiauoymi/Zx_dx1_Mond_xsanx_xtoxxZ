/*
 CommunicationService_UT was created on Apr 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.service.tests;

import com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock.MockCommActionItemsDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock.MockCommunicationDAO;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationServiceImpl;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockCommunication;
import junit.framework.TestCase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationService_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 19:19:26 $
 *
 * @author sspati1
 * @version $Revision: 1.25 $
 */
public class CommunicationService_UT extends TestCase {

  public void testUpdateCommunication() throws Exception {
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(new CommunicationImpl("12", "commName", "comm notes", new Date(), new Date(), null, "Y", null, null,
        1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "112", null));

    MockCommunicationDAO commDao = new MockCommunicationDAO(comms);
    CommunicationService service = new CommunicationServiceImpl(commDao);
    Communication comm = service.updateCommunication("12", "new comm name", "new comm notes", new Date(), new Date(),
        null, "Y", null, null, new CommType("23", null), new CommStatus(45L, null),
            new ContactType("12", null), new LocationType(34L, null), null);
    assertEquals("12", comm.getId());
    assertTrue(commDao.isUpdateCommCalled());
  }

  public void testAddCommunication() throws Exception {
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(new CommunicationImpl("12", "commName", "comm notes", new Date(), new Date(), null, "Y", null, null,
        1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "112", null));

    MockCommunicationDAO commDao = new MockCommunicationDAO(comms);
    CommunicationService service = new CommunicationServiceImpl(commDao);
    Communication comm = service.addCommunication("new comm name", "new comm notes", new Date(), new Date(),
        null, "Y", null, null, new CommType("23", null), new CommStatus(45L, null),
            new ContactType("12", null), new LocationType(34L, null), null, null);
    assertEquals("12", comm.getId());
    assertTrue(commDao.isAddCommCalled());
  }

  public void testDeactivateSelectedCommunications() throws Exception {
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(new CommunicationImpl("12", "commName", "comm notes", new Date(), new Date(), null, "Y", null, null,
        1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "112", null));
    MockCommunicationDAO commDao = new MockCommunicationDAO(comms);
    CommunicationService service = new CommunicationServiceImpl(commDao);
    List<String> ids = new ArrayList<String>();
    ids.add("1");
    ids.add("2");
    service.deactivateSelectedCommunications(ids);
    assertTrue(commDao.isDeactivateSelectedCommunicationsCalled());
    assertEquals(2, commDao.getSelectedIds().size());
  }

  public void testLookupCommunicationById() throws Exception {
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(new CommunicationImpl("12", "commName", "comm notes", new Date(), new Date(), null, "Y", null, null,
        1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "112", null));

    MockCommunicationDAO commDao = new MockCommunicationDAO(comms);
    CommunicationService service = new CommunicationServiceImpl(commDao);
    Communication comm = service.lookupCommunicationById("12");
    assertEquals("12", comm.getId());
    assertEquals("commName", comm.getName());
    assertEquals("comm notes", comm.getNotes());
    assertEquals(getFormattedDate(new Date()), comm.getFormattedFromDate());
    assertEquals(getFormattedDate(new Date()), comm.getFormattedToDate());
    assertEquals(new Long(1), comm.getCommType().getId());
    assertEquals("Letter", comm.getCommType().getType());
    assertEquals(new Long(2), comm.getLocConRelType().getId());
    assertEquals("Contact", comm.getLocConRelType().getType());
    assertEquals(new Long(3), comm.getBpLocRelType().getId());
    assertEquals("Main", comm.getBpLocRelType().getType());
    assertEquals(new Long(4L), comm.getStatus().getId());
    assertEquals("New", comm.getStatus().getStatus());
  }

  public void testLookupMyCommunications() throws Exception {
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(new CommunicationImpl("12", "commName", "comm notes", new Date(), new Date(), null, "Y", null, null,
        1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", null, null));

    MockCommunicationDAO commDao = new MockCommunicationDAO(comms);
    CommunicationService service = new CommunicationServiceImpl(commDao);
    List<Communication> commList = service.lookupMyCommunications();
    Communication comm = commList.get(0);
    assertEquals("12", comm.getId());
    assertEquals("commName", comm.getName());
    assertEquals("comm notes", comm.getNotes());
    assertEquals(getFormattedDate(new Date()), comm.getFormattedFromDate());
    assertEquals(getFormattedDate(new Date()), comm.getFormattedToDate());
    assertEquals(new Long(1), comm.getCommType().getId());
    assertEquals("Letter", comm.getCommType().getType());
    assertEquals(new Long(2), comm.getLocConRelType().getId());
    assertEquals("Contact", comm.getLocConRelType().getType());
    assertEquals(new Long(3), comm.getBpLocRelType().getId());
    assertEquals("Main", comm.getBpLocRelType().getType());
    assertEquals(new Long(4L), comm.getStatus().getId());
    assertEquals("New", comm.getStatus().getStatus());
  }

  public void testLookupCommunicationByCriteria() throws Exception {
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(new CommunicationImpl("12", "commName", "comm notes", new Date(), new Date(), null, "Y", null, null,
        1L, "Letter", 4L, "New", 2L, "Contact", 3L, "Main", "112", null));

    MockCommunicationDAO commDao = new MockCommunicationDAO(comms);
    CommunicationService service = new CommunicationServiceImpl(commDao);
    Communication commC = new CommunicationImpl(null, "comm test", null, null, null, null, "Y", null, null,
        null, null, null, null, null,
        null, null, null, null, null);
    CommunicationSearchCriteria criteria = new CommunicationSearchCriteria(commC, null, null, null, null, null);
    List<Communication> commList = service.lookupCommunicationByCriteria(criteria);
    Communication comm = commList.get(0);
    assertEquals("12", comm.getId());
    assertEquals("commName", comm.getName());
    assertEquals("comm notes", comm.getNotes());
    assertEquals(getFormattedDate(new Date()), comm.getFormattedFromDate());
    assertEquals(getFormattedDate(new Date()), comm.getFormattedToDate());
    assertEquals(new Long(1), comm.getCommType().getId());
    assertEquals("Letter", comm.getCommType().getType());
    assertEquals(new Long(2), comm.getLocConRelType().getId());
    assertEquals("Contact", comm.getLocConRelType().getType());
    assertEquals(new Long(3), comm.getBpLocRelType().getId());
    assertEquals("Main", comm.getBpLocRelType().getType());
    assertEquals(new Long(4L), comm.getStatus().getId());
    assertEquals("New", comm.getStatus().getStatus());
  }

  public void testLookupCommunicationTypes() throws Exception {
    MockCommunicationDAO commDao = new MockCommunicationDAO(null);
    CommunicationService service = new CommunicationServiceImpl(commDao);
    List<CommType> commTypes = service.lookupCommunicationTypes();
    assertEquals(2, commTypes.size());
  }

  public void testLookupCommunicationStatuses() throws Exception {
    MockCommunicationDAO commDao = new MockCommunicationDAO(null);
    CommunicationService service = new CommunicationServiceImpl(commDao);
    List<CommStatus> statuses = service.lookupCommunicationStatuses();
    assertEquals(4, statuses.size());
  }

  private String getFormattedDate(Date date) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    try {
      return sdf.format(date);
    }
    catch (Exception e) {
      return "";
    }
  }

  public void testGetActionItemsAsXML() throws Exception {
    MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
        1L, "Letter", 4L, "New", 2L, "Contact", 3L, "Main", "112", null);
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(comm);
    MockCommunicationDAO commDao = new MockCommunicationDAO(comms);
    CommunicationService service = new CommunicationServiceImpl(commDao);
    comm = (MockCommunication) service.lookupCommunicationById("12");
    service.addActionItem("12", "22");
    assertTrue(comm.getNumOfActionItemsAdded() == 1);
    assertNotNull(service.getActionItemsAsXML("12"));
  }

  public void testGetActionItemsAsList() throws Exception {
    MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
        1L, "Letter", 4L, "New", 2L, "Contact", 3L, "Main", "112", null);
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(comm);
    MockCommunicationDAO commDao = new MockCommunicationDAO(comms);
    CommunicationService service = new CommunicationServiceImpl(commDao);
    comm = (MockCommunication) service.lookupCommunicationById("12");
    service.addActionItem("12", "22");
    assertTrue(comm.getNumOfActionItemsAdded() == 1);
    List<Action> actionItemsList = service.getActionItemsAsList("12");
    assertNotNull(actionItemsList);
    assertEquals(1, actionItemsList.size());
  }

  public void testAddActionItem_ForGivenCommID() throws Exception {
    MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
        1L, "Letter", 4L, "New", 2L, "Contact", 3L, "Main", "112", null);
    List<Communication> comms = new ArrayList<Communication>();
    comms.add(comm);
    MockCommunicationDAO commDao = new MockCommunicationDAO(comms);
    CommunicationService service = new CommunicationServiceImpl(commDao);
    comm = (MockCommunication) service.lookupCommunicationById("12");
    service.addActionItem("12", "22");
    assertNotNull(comm.isAddActionItemCalled());
  }

  public void testAddActionItem_ForNullCommID() throws Exception {
    List<Action>  actionItems = new ArrayList<Action>();
    Action actionItem = new Action();
    actionItem.setId(1L);
    actionItems.add(actionItem);
    MockCommActionItemsDAO mockCommActionItemDAO = new MockCommActionItemsDAO(actionItems);
    mockCommActionItemDAO.addActionItem(null, "22");
    assertFalse(mockCommActionItemDAO.isAddActionItemCalled());
  }

}