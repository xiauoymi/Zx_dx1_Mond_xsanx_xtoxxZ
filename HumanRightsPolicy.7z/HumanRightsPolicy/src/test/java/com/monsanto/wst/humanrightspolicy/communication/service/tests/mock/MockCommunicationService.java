/*
 MockCommunicationService was created on Apr 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.communication.service.tests.mock;

import com.monsanto.wst.humanrightspolicy.communication.service.CommunicationService;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockCommunication;
import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: MockCommunicationService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-10-17 15:36:20 $
 *
 * @author sspati1
 * @version $Revision: 1.27 $
 */
public class MockCommunicationService implements CommunicationService {
  private final List<Communication> comms;
  private MockCommunication comm;
  private boolean updateCommunicationCalled;
  private List<String> selectedIds;
  private boolean lookupMyCommsCalled;
  private boolean lookupCommsByCriteriaCalled;
  private CommunicationSearchCriteria commSearchCriteria;
  private Communication newComm;
  private int numOfActionItemsAdded;
  private boolean addActionItemCalled;

  public MockCommunicationService(List<Communication> comms) {
    this.comms = comms;
  }

  public Communication updateCommunication(String commId, String name, String notes, Date fromDate, Date toDate,
                                           Date dueDate, String active, String urlTitle, String url,
                                           CommType commType,
                                           CommStatus status, ContactType peopleType, LocationType locType,
                                           Date dateCompleted) {
    this.updateCommunicationCalled = true;
    for (Communication comm : comms) {
      if (comm.getId().equalsIgnoreCase(commId)) {
        this.comm = new MockCommunication(comm.getId(), name, notes, fromDate, toDate, dueDate, comm.getActive(), commType.getId(),
            comm.getCommType().getType(), status.getId(), comm.getStatus().getStatus(), peopleType.getId(), comm.getLocConRelType().getType(),
            locType.getId(), comm.getBpLocRelType().getType(), null, dateCompleted);
        return this.comm;
      }
    }
    return null;
  }

  public Communication addCommunication(String name, String notes, Date fromDate, Date toDate, Date dueDate,
                                        String active,
                                        String urlTitle, String url, CommType commType, CommStatus status,
                                        ContactType peopleType,
                                        LocationType locType, String copiedFromCommId, Date dateCompleted) {
    this.newComm = new MockCommunication("123", name, notes, fromDate, toDate, dueDate, "Y", commType.getId(), "TRAINING",
        status.getId(), "Open", peopleType.getId(), "EMPLOYEE", locType.getId(), "PLANT", copiedFromCommId, dateCompleted);
    return this.newComm;
  }

  public void deactivateSelectedCommunications(List<String> selectedCommIds) {
    this.selectedIds = selectedCommIds;
  }

  public Communication lookupCommunicationById(String commId) {
    for (Communication comm : comms) {
      if (comm.getId().equalsIgnoreCase(commId)) {
        this.comm = new MockCommunication(comm.getId(), comm.getName(), comm.getNotes(), comm.getFromDate(),
            comm.getToDate(), comm.getDueDate(), comm.getActive(), comm.getCommType().getId(),
            comm.getCommType().getType(), comm.getStatus().getId(), comm.getStatus().getStatus(),
            comm.getLocConRelType().getId(), comm.getLocConRelType().getType(),
            comm.getBpLocRelType().getId(), comm.getBpLocRelType().getType(), comm.getCopiedFromCommId(), null);
        return this.comm;
      }
    }
    return null;
  }

  public List<Communication> lookupMyCommunications() {
    this.lookupMyCommsCalled = true;
    return comms;
  }

  public List<Communication> lookupCommunicationByCriteria(CommunicationSearchCriteria criteria) {
    this.lookupCommsByCriteriaCalled = true;
    this.commSearchCriteria = criteria;
    return comms;
  }

  public List<CommType> lookupCommunicationTypes() {
    List<CommType> types = new ArrayList<CommType>();
    types.add(new CommType(1L, "Letter"));
    types.add(new CommType(2L, "Training"));
    return types;
  }

  public List<CommStatus> lookupCommunicationStatuses() {
    List<CommStatus> statuses = new ArrayList<CommStatus>();
    statuses.add(new CommStatus(11L, "New"));
    statuses.add(new CommStatus(22L, "Open"));
    statuses.add(new CommStatus(33L, "Ready"));
    statuses.add(new CommStatus(44L, "Closed"));
    return statuses;
  }

  public MockCommunication getComm() {
    return comm;
  }

  public boolean isUpdateCommunicationCalled() {
    return updateCommunicationCalled;
  }

  public List<String> getSelectedIds() {
    return selectedIds;
  }

  public boolean isLookupMyCommsCalled() {
    return lookupMyCommsCalled;
  }

  public boolean isLookupCommsByCriteriaCalled() {
    return lookupCommsByCriteriaCalled;
  }

  public CommunicationSearchCriteria getCommSearchCriteria() {
    return commSearchCriteria;
  }

  public Communication getNewComm() {
    return newComm;
  }

  public int getNumOfActionItemsAdded() {
    return numOfActionItemsAdded;
  }

  public void addActionItem(String commId, String actionID) {
    lookupCommunicationById(commId).addActionItem(actionID);
    numOfActionItemsAdded++;
    addActionItemCalled = true;
  }

  public List<Action> getActionItemsAsList(String commId) {
    return lookupCommunicationById(commId).getActionItemsAsList();
  }

  public Document getActionItemsAsXML(String commId) {
    return lookupCommunicationById(commId).getActionItemsAsXML();
  }

  public boolean isAddActionItemCalled() {
    return addActionItemCalled;
  }
}