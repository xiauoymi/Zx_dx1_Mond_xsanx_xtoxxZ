/*
 LocationController_AT was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.controller.tests;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.controller.LocationController;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.testUtils.HumanRightsPolicyDatabaseTestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: LocationController_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $
 * On:	$Date: 2008-09-26 20:17:37 $
 *
 * @author sspati1
 * @version $Revision: 1.25 $
 */
public class LocationController_AT extends HumanRightsPolicyDatabaseTestCase {
  private MockUCCHelper helper = null;

  protected void setUp() throws Exception {
    super.setUp();
    helper = new MockUCCHelper(null, false, new KerberosStandaloneCredential());
    helper = new MockUCCHelper(null, false, new KerberosStandaloneCredential());
    LoginUser loginUser = new MockUser(new Long(1), "BP_UDP", "BP_UPD", false, new Role("1", "EDIT"), "test Description", "test Email");
    helper.setSessionParameter(HRPMainConstants.LOGINUSER, loginUser);
  }

  public void testNonSpecified() throws Exception {
    LocationController controller = new LocationController();
    controller.run(helper);
    List locations = (List) helper.getRequestAttributeValue("locations");
    assertNull(locations);
  }

  public void testLookupLocationById() throws Exception {
    helper.setRequestParameterValue(LocationsConstants.LOCATION_ID, "2");
    helper.setRequestParameterValue("method", LocationsConstants.LOOKUP_LOCATION);
    LocationController controller = new LocationController();
    controller.run(helper);
    LocationImpl location = (LocationImpl) helper.getRequestAttributeValue(LocationsConstants.LOCATION);
    assertEquals("2", location.getLocationId());
    assertEquals("Plant 2", location.getLocationName());
    assertFalse(location.getIsSap());
    assertEquals("23", location.getSapId());
    assertEquals("Y", location.getActive());
    assertEquals("2", location.getAddress().getAddressId());
    assertEquals("10", location.getAddress().getCountryModel().getId());
    assertEquals("Mongolia", location.getAddress().getCountryModel().getValue());
    assertEquals("2", location.getAddress().getStateModel().getId());
    assertEquals("Missouri-1", location.getAddress().getStateModel().getValue());
    assertEquals("1", location.getAddress().getRegionModel().getId());
    assertEquals("REGION", location.getAddress().getRegionModel().getValue());
    assertEquals("ONE BELL CENTER", location.getAddress().getStreetAddress1());
    assertEquals("FIRST STREET", location.getAddress().getStreetAddress2());
    assertEquals("ST.LOUIS", location.getAddress().getCity());
    assertEquals("63043", location.getAddress().getZipcode());
    assertEquals("0", helper.getRequestAttributeValue(LocationsConstants.COUNT_OF_CONTACTS));
  }

  public void testUpdateLocation() throws Exception {
    helper.setRequestParameterValue(HRPMainConstants.MENU, "testMenu");
    helper.setRequestParameterValue(HRPMainConstants.METHOD, LocationsConstants.UPDATE_LOCATION);
    helper.setRequestParameterValue(LocationsConstants.LOCATION_ID, "1");
    helper.setRequestParameterValue(LocationsConstants.LOCATION_NAME, "test");
    String testAddressId = "1";
    String testAddress1 = "123 MAIN Street";
    String testAddress2 = "APT 2";
    String testCity = "Tinsel Town";
    String testStateId = "16129";
    String testPostal = "12345";
    helper.setRequestParameterValue(LocationsConstants.ADDR1, testAddress1);
    helper.setRequestParameterValue(LocationsConstants.ADDR2, testAddress2);
    helper.setRequestParameterValue(LocationsConstants.CITY, testCity);
    helper.setRequestParameterValue(LocationsConstants.STATE, testStateId);
    helper.setRequestParameterValue(LocationsConstants.POSTAL, testPostal);
    helper.setRequestParameterValue(LocationsConstants.ADDR_ID, testAddressId);
    LocationController controller = new LocationController();
    controller.run(helper);
    Address address = (Address) helper.getRequestAttributeValue(LocationsConstants.ADDRESS);
    assertNotNull(address);
    assertEquals("123 MAIN Street", address.getStreetAddress1());
    assertEquals("APT 2", address.getStreetAddress2());
    assertEquals("Tinsel Town", address.getCity());
    assertEquals("12345", address.getZipcode());
    Location location = (Location) helper.getRequestAttributeValue(LocationsConstants.LOCATION);
    assertNotNull(location);
    assertEquals("1", location.getLocationId());
    assertEquals("test", location.getLocationName());
//    assertTrue(helper.wasSentTo("location?method=lookupLocation&locationId=1&menu=testMenu"));
  }

}