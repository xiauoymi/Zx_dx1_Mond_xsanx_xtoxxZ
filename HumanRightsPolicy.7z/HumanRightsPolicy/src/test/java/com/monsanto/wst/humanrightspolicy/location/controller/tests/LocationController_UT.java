/*
 LocationController_UT was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.controller.tests;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.constants.BusinessPartnerConstants;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerResult;
import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.contact.constants.ContactConstants;
import com.monsanto.wst.humanrightspolicy.contact.service.tests.mock.MockContactService;
import com.monsanto.wst.humanrightspolicy.location.contants.LocationsConstants;
import com.monsanto.wst.humanrightspolicy.location.controller.LocationController;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.location.service.tests.mock.MockLocation;
import com.monsanto.wst.humanrightspolicy.location.service.tests.mock.MockLocationService;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockBPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockBusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockLocationContactRelationship;
import org.custommonkey.xmlunit.XMLTestCase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Filename:    $RCSfile: LocationController_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-10-17 15:36:21 $
 *
 * @author sspati1
 * @version $Revision: 1.56 $
 */
public class LocationController_UT extends XMLTestCase {
    private MockUCCHelper helper;

    protected void setUp() throws Exception {
        helper = new MockUCCHelper(null);
        setLoginUserWithEditRoleAndStatesOrProvinces();
    }

    public void testCreate() throws Exception {
        LocationController controller = new LocationController(null, null, new MockContactService(), new MockDAO<ContactType, Long>());
        assertNotNull(controller);
    }

    public void testLookupLocationById() throws Exception {
        helper.setRequestParameterValue(LocationsConstants.LOCATION_ID, "11");
        helper.setRequestParameterValue(HRPMainConstants.METHOD, LocationsConstants.LOOKUP_LOCATION);
        List<Location> locations = new ArrayList<Location>();
        locations.add(new LocationImpl("11", "Plant 1", "Y", "12345678", "N", "10", "United States",
                "20", "Missouri", "30", "NA", "345", "Olive Blvd", "Apt 123", "St. Louis", "63167"));
        LocationService service = new MockLocationService(locations);
        LocationController controller = new LocationController(service, new MockBPLookupService(), new MockContactService(), new MockDAO<ContactType, Long>()
        );
        controller.run(helper);
        Location location = (Location) helper.getRequestAttributeValue(LocationsConstants.LOCATION);

        assertEquals("11", location.getLocationId());
        List bpLocRelTypes = (List) helper.getRequestAttributeValue(LocationsConstants.BP_LOC_REL_TYPE_LIST);
        List locConRelTypes = (List) helper.getRequestAttributeValue(BusinessPartnerConstants.LOC_CON_REL_TYPE_LIST);
        assertEquals("0", helper.getRequestAttributeValue(LocationsConstants.COUNT_OF_CONTACTS));
        assertNotNull(bpLocRelTypes);
        assertNotNull(locConRelTypes);
        assertTrue(helper.wasSentTo(LocationsConstants.LOCATION_JSP));
    }

    public void testUpdateAddress() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.METHOD, LocationsConstants.UPDATE_LOCATION);
        String testBpId = "1";
        String testAddressId = "123";
        String testAddress1 = "123 MAIN Street";
        String testAddress2 = "APT 2";
        String testCity = "Tinsel Town";
        String testStateId = "MO";
        String testPostal = "12345";
        helper.setRequestParameterValue(LocationsConstants.ADDR1, testAddress1);
        helper.setRequestParameterValue(LocationsConstants.ADDR2, testAddress2);
        helper.setRequestParameterValue(LocationsConstants.CITY, testCity);
        helper.setRequestParameterValue(LocationsConstants.STATE, testStateId);
        helper.setRequestParameterValue(LocationsConstants.POSTAL, testPostal);
        helper.setRequestParameterValue(LocationsConstants.ADDR_ID, testAddressId);
        BusinessPartner testBp = new MockBusinessPartnerImpl(testBpId, "TEST", "TEST", "1", null, null, new MockBPLocationRelationshipDAO(new ArrayList<BPLocationRelationship>()),
                null, null);
        helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, testBpId);
        LocationService service = new MockLocationService(Collections.<Location>emptyList());
        MockBPLookupService mockBpLookupService = new MockBPLookupService(testBp);
        LocationController controller = new LocationController(service, mockBpLookupService, new MockContactService(), new MockDAO<ContactType, Long>()
        );
        controller.run(helper);
        assertFalse(helper.wasErrorGenerated());
        Address address = (Address) helper.getRequestAttributeValue(LocationsConstants.ADDRESS);
        assertEquals("123 MAIN Street", address.getStreetAddress1());
        assertEquals("APT 2", address.getStreetAddress2());
        assertEquals("Tinsel Town", address.getCity());
    }

    public void testSaveLocation_FirstLocationForBP() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.METHOD, LocationsConstants.SAVE_LOCATON);
        String testBpId = "1";
        String testLocationName = "BRANCH OFFICE";
        String testSapID = "BRANCH OFFICE";
        String testAddress1 = "123 MAIN";
        String testAddress2 = "APT 1";
        String testCity = "Anytown";
        String testStateId = "MO";
        String testPostal = "12345";
        String testBPLocTypeId = "11";

        helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, testBpId);
        helper.setRequestParameterValue(LocationsConstants.LOCATION_NAME, testLocationName);
        helper.setRequestParameterValue(LocationsConstants.SAP_ID, testSapID);
        helper.setRequestParameterValue(LocationsConstants.ADDR1, testAddress1);
        helper.setRequestParameterValue(LocationsConstants.ADDR2, testAddress2);
        helper.setRequestParameterValue(LocationsConstants.CITY, testCity);
        helper.setRequestParameterValue(LocationsConstants.STATE, testStateId);
        helper.setRequestParameterValue(LocationsConstants.POSTAL, testPostal);
        helper.setRequestParameterValue(LocationsConstants.BP_LOC_TYPE_ID, testBPLocTypeId);
        MockLocationService service = new MockLocationService(Collections.<Location>emptyList());
        BPLocationRelationshipDAO relationshipDAO = new MockBPLocationRelationshipDAO(
                new ArrayList<BPLocationRelationship>());
        MockBusinessPartnerImpl testBp = new MockBusinessPartnerImpl(testBpId, "TEST", "TEST", "1", null, null, relationshipDAO,
                null, null);
        MockBPLookupService mockBpLookupService = new MockBPLookupService(testBp);
        LocationController controller = new LocationController(service, mockBpLookupService, new MockContactService(), new MockDAO<ContactType, Long>()
        );
        controller.run(helper);

        assertFalse(helper.wasErrorGenerated());
        List<BPLocationRelationship> activeRels = relationshipDAO.getActiveBPLocationRelationshipsForBP(testBp);
        assertEquals(1, activeRels.size());
        BPLocationRelationship relationship = activeRels.get(0);
        assertTrue("BRANCH OFFICE".equals(relationship.getLocation().getLocationName()));
    }

    public void testSaveLocation_NotAFirstLocationForBP() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.METHOD, LocationsConstants.SAVE_LOCATON);
        String testBpId = "1";
        String testLocationName = "BRANCH OFFICE";
        String testSapID = "BRANCH OFFICE";
        String testAddress1 = "123 MAIN";
        String testAddress2 = "APT 1";
        String testCity = "Anytown";
        String testStateId = "MO";
        String testPostal = "12345";
        String testBPLocTypeId = "11";

        helper.setRequestParameterValue(BusinessPartnerConstants.BUSINESS_PARTNER_ID, testBpId);
        helper.setRequestParameterValue(LocationsConstants.LOCATION_NAME, testLocationName);
        helper.setRequestParameterValue(LocationsConstants.SAP_ID, testSapID);
        helper.setRequestParameterValue(LocationsConstants.ADDR1, testAddress1);
        helper.setRequestParameterValue(LocationsConstants.ADDR2, testAddress2);
        helper.setRequestParameterValue(LocationsConstants.CITY, testCity);
        helper.setRequestParameterValue(LocationsConstants.STATE, testStateId);
        helper.setRequestParameterValue(LocationsConstants.POSTAL, testPostal);
        helper.setRequestParameterValue(LocationsConstants.BP_LOC_TYPE_ID, testBPLocTypeId);
        MockLocationService service = new MockLocationService(Collections.<Location>emptyList());
        List<BPLocationRelationship> bpLocRels = new ArrayList<BPLocationRelationship>();
        BPLocationRelationshipDAO relationshipDAO = new MockBPLocationRelationshipDAO(bpLocRels);
        MockBusinessPartnerImpl testBp = new MockBusinessPartnerImpl(testBpId, "TEST", "TEST", "1", null, null, relationshipDAO,
                null, null);
        MockBPLookupService mockBpLookupService = new MockBPLookupService(testBp);
        LocationController controller = new LocationController(service, mockBpLookupService, new MockContactService(), new MockDAO<ContactType, Long>()
        );
        controller.run(helper);

        assertFalse(helper.wasErrorGenerated());
        List<BPLocationRelationship> activeRels = relationshipDAO.getActiveBPLocationRelationshipsForBP(testBp);
        assertEquals(1, activeRels.size());
        BPLocationRelationship relationship = activeRels.get(0);
        assertTrue("BRANCH OFFICE".equals(relationship.getLocation().getLocationName()));
    }


    public void testSaveContact_FirstContactForLocation() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.METHOD, LocationsConstants.SAVE_CONTACT);
        String testLocationId = "1";
        String testPrefix = "Mr.";
        String testName = "KEN";
        String workPhone = "314-694-1000";
        String mobilePhone = "314-694-2233";
        String fax = "314-694-9999";
        String email = "test@monsanto.com";
        String title = "Testing";

        helper.setRequestParameterValue(LocationsConstants.LOCATION_ID, testLocationId);
        helper.setRequestParameterValue(ContactConstants.PREFIX, testPrefix);
        helper.setRequestParameterValue(ContactConstants.NAME, testName);
        helper.setRequestParameterValue(ContactConstants.WORK_PHONE, workPhone);
        helper.setRequestParameterValue(ContactConstants.MOBILE_PHONE, mobilePhone);
        helper.setRequestParameterValue(ContactConstants.FAX, fax);
        helper.setRequestParameterValue(ContactConstants.EMAIL, email);
        helper.setRequestParameterValue(ContactConstants.TITLE, title);

        Location testLoc = new MockLocation(testLocationId, "TEST", null, false, null,
                new ArrayList<LocationContactRelationship>(), null, null);
        List<Location> locs = new ArrayList<Location>();
        locs.add(testLoc);
        MockLocationService service = new MockLocationService(locs);
        MockBPLookupService mockBpLookupService = new MockBPLookupService();
        LocationController controller = new LocationController(service, mockBpLookupService, new MockContactService(), new MockDAO<ContactType, Long>()
        );
        controller.run(helper);

        assertFalse(helper.wasErrorGenerated());

        assertTrue(service.wasAddContactToLocationCalled());
        assertTrue(service.isContactPrimary());

    }

    public void testSaveContact_NotAFirstContactForLocation() throws Exception {
        helper.setRequestParameterValue(HRPMainConstants.METHOD, LocationsConstants.SAVE_CONTACT);
        String testLocationId = "1";
        String testPrefix = "Mr.";
        String testName = "KEN";
        String workPhone = "314-694-1000";
        String mobilePhone = "314-694-2233";
        String fax = "314-694-9999";
        String email = "test@monsanto.com";
        String title = "Testing";

        helper.setRequestParameterValue(LocationsConstants.LOCATION_ID, testLocationId);
        helper.setRequestParameterValue(ContactConstants.PREFIX, testPrefix);
        helper.setRequestParameterValue(ContactConstants.NAME, testName);
        helper.setRequestParameterValue(ContactConstants.WORK_PHONE, workPhone);
        helper.setRequestParameterValue(ContactConstants.MOBILE_PHONE, mobilePhone);
        helper.setRequestParameterValue(ContactConstants.FAX, fax);
        helper.setRequestParameterValue(ContactConstants.EMAIL, email);
        helper.setRequestParameterValue(ContactConstants.TITLE, title);

        List<LocationContactRelationship> locContactRels = new ArrayList<LocationContactRelationship>();
        locContactRels.add(new MockLocationContactRelationship("1", true, true, null, null, new ContactType("11", "Worker")));
        Location testLoc = new MockLocation(testLocationId, "TEST", null, false, null, locContactRels, null, null);
        List<Location> locs = new ArrayList<Location>();
        locs.add(testLoc);
        MockLocationService service = new MockLocationService(locs);
        MockBPLookupService mockBpLookupService = new MockBPLookupService();
        LocationController controller = new LocationController(service, mockBpLookupService, new MockContactService(),
                new MockDAO<ContactType, Long>());
        controller.run(helper);

        assertFalse(helper.wasErrorGenerated());

        assertTrue(service.wasAddContactToLocationCalled());
        assertFalse(service.isContactPrimary());
    }

    private void setLoginUserWithEditRoleAndStatesOrProvinces() {
        LoginUser loginUser = new MockUser(1L, "BP_UDP", "BP_UPD", false, new Role("2", "EDIT"), "test Description", "test Email");
        helper.setSessionParameter(HRPMainConstants.LOGINUSER, loginUser);
    }


    private class MockBPLookupService implements LookupBPService {
        private final BusinessPartner bp;

        private MockBPLookupService() {
            bp = null;
        }

        private MockBPLookupService(BusinessPartner bp) {
            this.bp = bp;
        }

        public BusinessPartnerResult lookupBPByCriteria(BusinessPartner bp, boolean myBPScope, LoginUser user,
                                                        String sortKey, String filterValue, Integer startRecord,
                                                        Integer endRecord) {
            List<BusinessPartner> bps = new ArrayList<BusinessPartner>();
            bps.add(bp);
            return new BusinessPartnerResult(bps, bps.size());
        }

        public BusinessPartner lookupBPById(String bpId) {
            return bp;
        }
    }
}