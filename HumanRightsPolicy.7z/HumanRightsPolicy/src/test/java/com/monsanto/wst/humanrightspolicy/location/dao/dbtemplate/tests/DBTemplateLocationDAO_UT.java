/*
 DBTemplateLookupLocationDAO_UT was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.dao.dbtemplate.tests;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.location.dao.LookupLocationDAO;
import com.monsanto.wst.humanrightspolicy.location.dao.dbtemplate.DBTemplateLocationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockAddress;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockBusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockContactInfo;
import junit.framework.TestCase;

/**
 *
 * @author sspati1
 */
public class DBTemplateLocationDAO_UT extends TestCase {

  public void testCreate() throws Exception {
    LookupLocationDAO dao = new DBTemplateLocationDAO(null, new MockDAO<LocationType, Long>());
    assertNotNull(dao);
  }

  public void testLookupLocationById_CorrectStatementWasCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    LookupLocationDAO dao = new DBTemplateLocationDAO(template, new MockDAO<LocationType, Long>());
    dao.lookupLocationById("1");
    assertTrue(template.wasStatementNameCalled("lookupLocationByCriteria"));
  }

  public void testLookupLocationByCriteria_CorrectStatementWasCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    LookupLocationDAO dao = new DBTemplateLocationDAO(template, new MockDAO<LocationType, Long>());
    dao.lookupLocationByCriteria(new LocationImpl());
    assertTrue(template.wasStatementNameCalled("lookupLocationByCriteria"));
  }

  public void testAddAddress_CorrectStatementCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    LookupLocationDAO dao = new DBTemplateLocationDAO(template, new MockDAO<LocationType, Long>());
    dao.addAddress("test", "test", "test", "test", "test");
    assertTrue(template.wasStatementNameCalled("addAddress"));
  }

  public void testUpdateAddress_CorrectStatementCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    LookupLocationDAO dao = new DBTemplateLocationDAO(template, new MockDAO<LocationType, Long>());
    dao.updateAddress("1","test", "test", "test", "test", "test");
    assertTrue(template.wasStatementNameCalled("updateAddress"));
  }

  public void testAddLocation_CorrectStatementCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    LookupLocationDAO dao = new DBTemplateLocationDAO(template, new MockDAO<LocationType, Long>());
    dao.addLocation("test", "test", new MockAddress());
    assertTrue(template.wasStatementNameCalled("addLocation"));
  }

  public void testUpdateLocation_CorrectStatementCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    LookupLocationDAO dao = new DBTemplateLocationDAO(template, new MockDAO<LocationType, Long>());
    dao.updateLocation("12", "test", new MockAddress());
    assertTrue(template.wasStatementNameCalled("updateLocation"));
  }

  public void testAddLocationToBp_CorrectStatementCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    LookupLocationDAO dao = new DBTemplateLocationDAO(template, new MockDAO<LocationType, Long>());
    BusinessPartner bp = new MockBusinessPartnerImpl("1", "test", "test", "1", null, null, null, null, null);
    dao.addLocationToBp(bp, new LocationImpl(), false, new LocationType(1L, null));
    assertTrue(template.wasStatementNameCalled("assignLocationToBp"));
  }

  public void testLookupAddressById_CorrectStatementCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    LookupLocationDAO dao = new DBTemplateLocationDAO(template, new MockDAO<LocationType, Long>());
    dao.lookupAddressById("1");
    assertTrue(template.wasStatementNameCalled("lookupAddressById"));
  }

  public void testAddContactToLocation_CorrectStatementCalled() throws Exception {
    MockDBTemplate template = new MockDBTemplate();
    LookupLocationDAO dao = new DBTemplateLocationDAO(template, new MockDAO<LocationType, Long>());
    ContactInfo contact = new MockContactInfo("id", "1", "1", "pre", "first", "", "", "", "");
    Location loc = new LocationImpl();
    dao.addContactToLocation(loc, contact, false, new ContactType("11", "Worker"));
    assertTrue(template.wasStatementNameCalled("assignContactToLocation"));
  }

/*
 //todo this test was tempoarily disabled until Ramya's changes are committed.  It should be uncommented once they are
  public void testLookupLocationTypeById() throws Exception {
      MockDBTemplate template = new MockDBTemplate();
      LookupLocationDAO locationTypeDAO = new DBTemplateLocationDAO(template);
      locationTypeDAO.lookupLocationTypeById("1");
      assertTrue(template.wasStatementNameCalled("lookupLocationTypeById"));
  }
*/
}