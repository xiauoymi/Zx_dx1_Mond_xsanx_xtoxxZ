/*
 LookupLocationDAO_AT was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.dao.tests;

import com.monsanto.wst.dbtemplate.DBTemplateImpl;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.Security.dao.dbtemplate.tests.DBTemplateBaseTransactionTestCase;
import com.monsanto.wst.humanrightspolicy.location.dao.LookupLocationDAO;
import com.monsanto.wst.humanrightspolicy.location.dao.dbtemplate.DBTemplateLocationDAO;
import com.monsanto.wst.humanrightspolicy.model.Location;
import com.monsanto.wst.humanrightspolicy.model.LocationImpl;
import com.monsanto.wst.humanrightspolicy.model.LocationType;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.util.List;

/**
 * Filename:    $RCSfile: LookupLocationDAO_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:24 $
 *
 * @author sspati1
 * @version $Revision: 1.25 $
 */
public class LookupLocationDAO_AT extends DBTemplateBaseTransactionTestCase {

  protected String getConfigPath() {
    return "com/monsanto/wst/humanrightspolicy/testUtils/hrpData.xml";
  }

  public void testLookupLocationById_ValueReturned() throws Exception {
    LookupLocationDAO dao = new DBTemplateLocationDAO(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}), new MockDAO<LocationType, Long>());
    Location location = dao.lookupLocationById("2");
    assertEquals("2", location.getLocationId());
    assertEquals("Plant 2", location.getLocationName());
    assertEquals("23", location.getSapId());
    assertEquals("Y", location.getActive());
    assertFalse(location.getIsSap());
    assertEquals("2", location.getAddress().getAddressId());
    assertEquals("10", location.getAddress().getCountryModel().getId());
    assertEquals("Mongolia", location.getAddress().getCountryModel().getValue());
    assertEquals("2", location.getAddress().getStateModel().getId());
    assertEquals("Missouri-1", location.getAddress().getStateModel().getValue());
    assertEquals("1", location.getAddress().getRegionModel().getId());
    assertEquals("REGION", location.getAddress().getRegionModel().getValue());
    assertEquals("ONE BELL CENTER", location.getAddress().getStreetAddress1());
    assertEquals("FIRST STREET", location.getAddress().getStreetAddress2());
    assertEquals("ST.LOUIS", location.getAddress().getCity());
    assertEquals("63043", location.getAddress().getZipcode());
  }

  public void testLookupLocationByCriteria_OnlyIdPassed_ValueReturned() throws Exception {
    LookupLocationDAO dao = new DBTemplateLocationDAO(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}), new MockDAO<LocationType, Long>());
    LocationImpl location = new LocationImpl("2", null, null, null,
        "N", null, null, null, null, null, null, null, null, null, null, null);
    List fac = dao.lookupLocationByCriteria(location);
    assertTrue(fac.size() == 1);
    location = (LocationImpl) fac.get(0);
    assertTrue(location instanceof LocationImpl);
    assertEquals("2", location.getLocationId());
    assertEquals("Plant 2", location.getLocationName());
    assertEquals("23", location.getSapId());
    assertEquals("Y", location.getActive());
    assertFalse(location.getIsSap());
    assertEquals("2", location.getAddress().getAddressId());
    assertEquals("10", location.getAddress().getCountryModel().getId());
    assertEquals("Mongolia", location.getAddress().getCountryModel().getValue());
    assertEquals("2", location.getAddress().getStateModel().getId());
    assertEquals("Missouri-1", location.getAddress().getStateModel().getValue());
    assertEquals("1", location.getAddress().getRegionModel().getId());
    assertEquals("REGION", location.getAddress().getRegionModel().getValue());
    assertEquals("ONE BELL CENTER", location.getAddress().getStreetAddress1());
    assertEquals("FIRST STREET", location.getAddress().getStreetAddress2());
    assertEquals("ST.LOUIS", location.getAddress().getCity());
    assertEquals("63043", location.getAddress().getZipcode());
  }

  public void testLookupLocationByCriteria_OnlyNamePassed_ValueReturned() throws Exception {
    LookupLocationDAO dao = new DBTemplateLocationDAO(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}), new MockDAO<LocationType, Long>());
    LocationImpl location = new LocationImpl(null, "Plant 1", null, null,
        "N", null, null, null, null, null, null, null, null, null, null, null);
    List fac = dao.lookupLocationByCriteria(location);
    assertTrue(fac.size() == 1);
    location = (LocationImpl) fac.get(0);
    assertTrue(location instanceof LocationImpl);
    assertEquals("1", location.getLocationId());
    assertEquals("Plant 1", location.getLocationName());
    assertEquals("45", location.getSapId());
    assertEquals("Y", location.getActive());
    assertTrue(location.getIsSap());
    assertEquals("6", location.getAddress().getAddressId());
  }

  public void testLookupLocationByCriteria_OnlyIdAndNamePassed_ValueReturned() throws Exception {
    LookupLocationDAO dao = new DBTemplateLocationDAO(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}), new MockDAO<LocationType, Long>());
    LocationImpl location = new LocationImpl("2", "Plant 2", null, null,
        "N", null, null, null, null, null, null, null, null, null, null, null);
    List fac = dao.lookupLocationByCriteria(location);
    assertTrue(fac.size() == 1);
    location = (LocationImpl) fac.get(0);
    assertTrue(location instanceof LocationImpl);
    assertEquals("2", location.getLocationId());
    assertEquals("Plant 2", location.getLocationName());
    assertEquals("23", location.getSapId());
    assertEquals("Y", location.getActive());
    assertFalse(location.getIsSap());
    assertEquals("2", location.getAddress().getAddressId());
  }

  public void testLookupLocationByCriteria_OnlySAPIdPassed_ValueReturned() throws Exception {
    LookupLocationDAO dao = new DBTemplateLocationDAO(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}), new MockDAO<LocationType, Long>());
    LocationImpl location = new LocationImpl(null, null, null, "23",
        "N", null, null, null, null, null, null, null, null, null, null, null);
    List fac = dao.lookupLocationByCriteria(location);
    assertTrue(fac.size() == 1);
    location = (LocationImpl) fac.get(0);
    assertTrue(location instanceof LocationImpl);
    assertEquals("2", location.getLocationId());
    assertEquals("Plant 2", location.getLocationName());
    assertEquals("23", location.getSapId());
    assertEquals("Y", location.getActive());
    assertFalse(location.getIsSap());
    assertEquals("2", location.getAddress().getAddressId());
  }

  public void testLookupLocationByCriteria_StateIdPassed_ValueReturned() throws Exception {
    LookupLocationDAO dao = new DBTemplateLocationDAO(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}), new MockDAO<LocationType, Long>());
    Location location = new LocationImpl("2", "Plant 2", null, "23",
        "N", null, null, "2", null, null, null, null, null, null, null, null);
    List fac = dao.lookupLocationByCriteria(location);
    assertTrue(fac.size() == 1);
    location = (Location) fac.get(0);
    assertTrue(location instanceof LocationImpl);
    assertEquals("2", location.getLocationId());
    assertEquals("Plant 2", location.getLocationName());
    assertEquals("23", location.getSapId());
    assertEquals("Y", location.getActive());
    assertFalse(location.getIsSap());
    assertEquals("2", location.getAddress().getAddressId());
  }

  public void testLookupLocationByCriteria_EverythingPassed_ValueReturned() throws Exception {
    LookupLocationDAO dao = new DBTemplateLocationDAO(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}), new MockDAO<LocationType, Long>());
    Location location = new LocationImpl("2", "Plant 2", null, "23",
        "N", null, null, null, null, null, null, null, null, null, null, null);
    List fac = dao.lookupLocationByCriteria(location);
    assertTrue(fac.size() == 1);
    location = (Location) fac.get(0);
    assertTrue(location instanceof LocationImpl);
    assertEquals("2", location.getLocationId());
    assertEquals("Plant 2", location.getLocationName());
    assertEquals("23", location.getSapId());
    assertEquals("Y", location.getActive());
    assertFalse(location.getIsSap());
    assertEquals("2", location.getAddress().getAddressId());
  }

  public void testlookupBPLocRelTypes() throws Exception {
    LookupLocationDAO dao = new DBTemplateLocationDAO(new DBTemplateImpl(getTransactionManager(), new String [] {"database/dbtemplate.xml"}), InitService.initLocationTypeDAO());
    List<LocationType> types = dao.lookupBPLocRelTypes();
    assertTrue(types.size() >= 2);
  }
}