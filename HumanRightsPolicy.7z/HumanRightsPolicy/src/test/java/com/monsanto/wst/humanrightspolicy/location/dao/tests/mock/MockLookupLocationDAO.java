/*
 MockLookupLocationDAO was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.dao.tests.mock;

import com.monsanto.wst.humanrightspolicy.location.dao.LookupLocationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockAddress;

import java.util.ArrayList;
import java.util.List;

/**
 * @author sspati1
 */
public class MockLookupLocationDAO implements LookupLocationDAO {
  private Location loc;
  private boolean addAddressCalled = false;
  private boolean addLocationCalled = false;
  private boolean addLocationToBpCalled = false;
  private boolean addContactToLocationCalled = false;
  private ContactInfo contact;
  private boolean isContactPrimary;
  private boolean isPrimary;
  private boolean upadteLocationCalled;
  private boolean lookupLocationByIdCalled;
  private boolean updateAddressCalled;
  private boolean lookupAddressByIdCalled;

  public MockLookupLocationDAO(Location loc) {
    this.loc = loc;
  }

  public Location lookupLocationById(String locId) {
    lookupLocationByIdCalled = true;
    return loc;
  }

  public List<Location> lookupLocationByCriteria(Location locationCriteria) {
    List<Location> list = new ArrayList<Location>();
    Location location = new LocationImpl("11", "Plant 1", "Y", "12345678", "N", "10", "United States",
        "20", "Mossouri", "30", "NA", "345", "Olive Blvd", "Apt 123", "St. Louis", "63167");
    list.add(location);
    location = new LocationImpl("22", "Site 1", "Y", "456789123", "N", "10", "United States",
        "20", "Mossouri", "30", "NA", "456", "Olive Blvd", "Apt 123", "St. Louis", "63167");
    list.add(location);
    return list;
  }

  public String addAddress(String addr1, String addr2, String city, String stateId, String postal
  ) {
    addAddressCalled = true;
    return "MOCK-1";
  }

  public void updateAddress(String addressId, String addr1, String addr2, String city, String stateId, String postal
  ) {
    updateAddressCalled = true;
  }

    public void updateLocationToBPRelationship(String locationId) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

  public String addLocation(String locationName, String sapId, Address address) {
    addLocationCalled = true;
    return "MOCK-1";
  }

  public void updateLocation(String locationId, String locationName, Address address
  ) {
    upadteLocationCalled = true;
  }

  public void addLocationToBp(BusinessPartner bp, Location location, boolean isPrimary, LocationType bpLocType
  ) {
    this.isPrimary = isPrimary;
    addLocationToBpCalled = true;
  }

  public List<LocationType> lookupBPLocRelTypes() {
    return new ArrayList<LocationType>();
  }

  public void addContactToLocation(Location location, ContactInfo contact, boolean isContactPrimary,
                                   ContactType locConRelType) {
    loc = location;
    this.contact = contact;
    this.isContactPrimary = isContactPrimary;
    addContactToLocationCalled = true;
  }

  public Address lookupAddressById(String id) {
    lookupAddressByIdCalled = true;
    return new MockAddress();
  }

  public boolean wasAddAddressCalled() {
    return addAddressCalled;
  }

  public boolean wasAddLocationCalled() {
    return addLocationCalled;
  }

  public boolean wasAddLocationToBpCalled() {
    return addLocationToBpCalled;
  }

  public boolean wasAddContactToLocationCalled() {
    return addContactToLocationCalled;
  }

  public Location getLoc() {
    return loc;
  }

  public ContactInfo getContact() {
    return contact;
  }

  public boolean isContactPrimary() {
    return isContactPrimary;
  }

  public boolean isPrimary() {
    return isPrimary;
  }

  public boolean wasUpadteLocationCalled() {
    return upadteLocationCalled;
  }

  public boolean wasLookupLocationByIdCalled() {
    return lookupLocationByIdCalled;
  }

  public boolean wasUpdateAddressCalled() {
    return updateAddressCalled;
  }

  public boolean wasLookupAddressByIdCalled() {
    return lookupAddressByIdCalled;
  }

}