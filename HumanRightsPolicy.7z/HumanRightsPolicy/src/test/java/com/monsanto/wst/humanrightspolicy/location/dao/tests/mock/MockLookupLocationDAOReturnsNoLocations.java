/*
 MockLookupLocationDAOReturnsNoLocations was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.dao.tests.mock;

import com.monsanto.wst.humanrightspolicy.location.dao.LookupLocationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sspati1
 */
public class MockLookupLocationDAOReturnsNoLocations implements LookupLocationDAO {

  public Location lookupLocationById(String locId) {
    return null;
  }

  public List<Location> lookupLocationByCriteria(Location locationCriteria) {
    return null;
  }

  public String addAddress(String addr1, String addr2, String city, String stateId, String postal
  ) {
    return null;
  }

  public void updateAddress(String addressId, String addr1, String addr2, String city, String stateId, String postal
  ) {
  }

    public void updateLocationToBPRelationship(String locationId) {
    }

    public String addLocation(String locationName, String sapId, Address address) {
    return null;
  }

  public void updateLocation(String locationId, String locationName, Address address
  ) {
  }

  public void addLocationToBp(BusinessPartner bp, Location location, boolean isPrimary, LocationType bpLocType
  ) {
  }

  public Address lookupAddressById(String id) {
    return null;
  }

  public void addContactToLocation(Location location, ContactInfo contact, boolean isContactPrimary,
                                   ContactType locConRelType) {
  }

  public String addContact(
  ) {
    return null; 
  }

  public ContactInfo lookupContactById() {
    return null; 
  }

  public List<LocationType> lookupBPLocRelTypes() {
    return new ArrayList<LocationType>();
  }

    public List<String> getNamePrefixes() {
    return null; 
  }
}