/*
 LookupLocationServiceImpl_UT was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.service.tests;

import com.monsanto.wst.humanrightspolicy.location.dao.LookupLocationDAO;
import com.monsanto.wst.humanrightspolicy.location.dao.tests.mock.MockLookupLocationDAO;
import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.location.service.LocationServiceImpl;
import com.monsanto.wst.humanrightspolicy.location.service.tests.mock.MockLocation;
import com.monsanto.wst.humanrightspolicy.model.ContactInfo;
import com.monsanto.wst.humanrightspolicy.model.ContactType;
import com.monsanto.wst.humanrightspolicy.model.Location;
import com.monsanto.wst.humanrightspolicy.model.LocationImpl;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockContactInfo;
import junit.framework.TestCase;

import java.util.List;

/**
 * @author sspati1
 */
public class LocationServiceImpl_UT extends TestCase {

  public void testCreate() throws Exception {
    LocationService service = new LocationServiceImpl(null);
    assertNotNull(service);
  }

  public void testLookupLocationByCriteria() throws Exception {
    LookupLocationDAO dao = new MockLookupLocationDAO(null);
    LocationService service = new LocationServiceImpl(dao);
    List facilities = service.lookupLocationByCriteria(new LocationImpl());
    assertEquals(2, facilities.size());
  }

  public void testLookupLocationById_ReturnsALocation() throws Exception {
    Location location = new LocationImpl("11", "Plant 1", "Y", "12345678", "N", "10", "United States",
        "20", "Mossouri", "30", "NA", "345", "Olive Blvd", "Apt 123", "St. Louis", "63167");

    LookupLocationDAO dao = new MockLookupLocationDAO(location);
    LocationService service = new LocationServiceImpl(dao);
    location = service.lookupLocationById("11");
    assertEquals("11", location.getLocationId());
  }

  public void testAddAddress() throws Exception {
    MockLookupLocationDAO dao = new MockLookupLocationDAO(null);
    LocationService service = new LocationServiceImpl(dao);
    service.addAddress("test", "test", "test", "test", "test", "test", "test");
    assertTrue(dao.wasAddAddressCalled());
    assertTrue(dao.wasLookupAddressByIdCalled());
  }

  public void testUpdateAddress() throws Exception {
    MockLookupLocationDAO dao = new MockLookupLocationDAO(null);
    LocationService service = new LocationServiceImpl(dao);
    service.updateAddress("1", "test", "test", "test", "test", "test", "test", "test");
    assertTrue(dao.wasUpdateAddressCalled());
    assertTrue(dao.wasLookupAddressByIdCalled());
  }

  public void testAddLocation() throws Exception {
    MockLookupLocationDAO dao = new MockLookupLocationDAO(null);
    LocationService service = new LocationServiceImpl(dao);
    service.addLocation("test", "test", null);
    assertTrue(dao.wasAddLocationCalled());
    assertTrue(dao.wasLookupLocationByIdCalled());
  }

  public void testUpdateLocation() throws Exception {
    MockLookupLocationDAO dao = new MockLookupLocationDAO(null);
    LocationService service = new LocationServiceImpl(dao);
    service.updateLocation("1", "test", null);
    assertTrue(dao.wasUpadteLocationCalled());
    assertTrue(dao.wasLookupLocationByIdCalled());
  }

//  public void testAssignLocationToBp_IsPrimaryIsFalse() throws Exception {
//    BusinessPartner bp = new MockBusinessPartnerImpl("1", "test", "test", "test", null, null, null);
//    Location location = new MockLocation("1", "testloc", null, "1", null, null, null);
//
//    MockLookupLocationDAO dao = new MockLookupLocationDAO(location);
//    LocationService service = new LocationServiceImpl(dao);
//    service.addLocationToBp(bp, location, false, new CommonModel("1", null), "test");
//    assertTrue(dao.wasAddLocationToBpCalled());
//    assertFalse(dao.isPrimary());
//  }
//
//  public void testAssignLocationToBp_IsPrimaryIsTrue() throws Exception {
//    BusinessPartner bp = new MockBusinessPartnerImpl("1", "test", "test", "test", null, null, null);
//    Location location = new MockLocation("1", "testloc", null, "1", null, null, null);
//
//    MockLookupLocationDAO dao = new MockLookupLocationDAO(location);
//    LocationService service = new LocationServiceImpl(dao);
//    service.addLocationToBp(bp, location, true, new CommonModel("1", null), "test");
//    assertTrue(dao.wasAddLocationToBpCalled());
//    assertTrue(dao.isPrimary());
//  }

  public void testAssignContactToLocation_IsContactPrimaryIsTrue() throws Exception {
    Location location = new MockLocation("1", "testloc", "1", false, null, null, null, null);
    ContactInfo contact = new MockContactInfo("1", "pre", "first", "title", "work", "cell", "fax", "email", "N");

    MockLookupLocationDAO dao = new MockLookupLocationDAO(location);
    LocationService service = new LocationServiceImpl(dao);
    service.addContactToLocation(location, contact, true, new ContactType("11", "Worker"));
    assertTrue(dao.wasAddContactToLocationCalled());
    assertEquals("1", dao.getLoc().getLocationId());
    assertEquals("1", dao.getContact().getContactId());
    assertTrue(dao.isContactPrimary());
  }

  public void testAssignContactToLocation_IsContactPrimaryIsFalse() throws Exception {
    Location location = new MockLocation("1", "testloc", "1", false, null, null, null, null);
    ContactInfo contact = new MockContactInfo("1", "pre", "first", "title", "work", "cell", "fax", "email", "N");

    MockLookupLocationDAO dao = new MockLookupLocationDAO(location);
    LocationService service = new LocationServiceImpl(dao);
    service.addContactToLocation(location, contact, false, new ContactType("11", "Worker"));
    assertTrue(dao.wasAddContactToLocationCalled());
    assertEquals("1", dao.getLoc().getLocationId());
    assertEquals("1", dao.getContact().getContactId());
    assertFalse(dao.isContactPrimary());
  }
}