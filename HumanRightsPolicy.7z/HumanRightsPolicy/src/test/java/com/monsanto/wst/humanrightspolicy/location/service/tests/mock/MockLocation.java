package com.monsanto.wst.humanrightspolicy.location.service.tests.mock;

import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.ArrayList;
import java.util.List;
/*
 MockLocation was created on Mar 24, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class MockLocation implements Location {
  private String locationId;
  private final String locationName;
  private final String sapId;
  private final boolean isSap;
  private final LocationContactRelationship primaryRelationship;
  private final String active;
  private final Address address;
  private List<LocationContactRelationship> locContactRels = new ArrayList<LocationContactRelationship>();
  private ContactInfo newPrimaryContact;
  private boolean endLocationContactRelationshipCalled;
  private final BPLocationRelationship activeBpLocRel;
  private int numLocConRelEnded = 0;

  public MockLocation(String locationId, String locationName, String sapId,
                      boolean isSap, Address address,
                      List<LocationContactRelationship> locContactRels,
                      LocationContactRelationship primaryRelationship, BPLocationRelationship activeBpLocRel) {
    this.locationId = locationId;
    this.locationName = locationName;
    this.sapId = sapId;
    this.isSap = isSap;
    this.primaryRelationship = primaryRelationship;
    this.activeBpLocRel = activeBpLocRel;
    this.active = "Y";
    this.address = address;
    this.locContactRels = locContactRels;
  }

  public String getLocationId() {
    return locationId;
  }

  public String getLocationName() {
    return locationName;
  }

  public boolean getIsSap() {
    return isSap;
  }

  public String getIsSapAsYOrN() {
    return isSap ? "Y" : "N";
  }

  public String getSapId() {
    return sapId;
  }

  public String getActive() {
    return active;
  }

  public Address getAddress() {
    return address;
  }

  public List<LocationContactRelationship> getActiveLocationContactRelationships() {
    return locContactRels;
  }

  public BPLocationRelationship getActiveBPLoctationRelationship() {
    return activeBpLocRel;
  }

  public LocationContactRelationship getPrimaryRelationship() {
    return primaryRelationship;
  }

  public void setPrimaryContact(ContactInfo newPrimaryContact, String userId) {
    this.newPrimaryContact = newPrimaryContact;
  }

  public void setLocationId(String locId) {
    this.locationId = locId;
  }

  public void endLocationContactRelationship(String contactId, String userId) {
    this.numLocConRelEnded++;
    this.endLocationContactRelationshipCalled = true;
  }

  public ContactInfo getNewPrimaryContact() {
    return newPrimaryContact;
  }

  public boolean isEndLocationContactRelationshipCalled() {
    return endLocationContactRelationshipCalled;
  }

  public int getNumLocConRelEnded() {
    return numLocConRelEnded;
  }

  public List<Communication> getCommunications() {
    return null;
  }
}
