/*
 MockLookupLocationService was created on Feb 5, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.location.service.tests.mock;

import com.monsanto.wst.humanrightspolicy.location.service.LocationService;
import com.monsanto.wst.humanrightspolicy.location.test.MockCountry;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.MockRegion;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockAddress;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sspati1
 */
public class MockLocationService implements LocationService {
  private final List<Location> locations;
  private boolean addLocationToBpCalled = false;
  private boolean addContactToLocationCalled = false;
  private boolean isContactPrimary;
  private boolean isPrimary;

  public MockLocationService(List<Location> locations) {
    this.locations = locations;
  }

  public List<Location> lookupLocationByCriteria(Location locationCriteria) {
    return this.locations;
  }

  public Location lookupLocationById(String id) {
    return this.locations.get(0);
  }

  public Address addAddress(String addr1, String addr2, String city, String stateId, String postal, String countryId,
                            String regionId) {
    return new MockAddress("1", addr1, addr2, city, postal, new StateProvince(stateId, stateId),
        new MockCountry(countryId, countryId),
        new MockRegion(regionId, regionId));
  }

  public Address updateAddress(String addressId, String addr1, String addr2, String city, String stateId, String postal,
                               String countryId, String regionId) {
      return new MockAddress(addressId, addr1, addr2, city, postal, new StateProvince(stateId, stateId),new MockCountry(countryId, countryId), new MockRegion(regionId, regionId)) ;
  }

    public Location updateLocationToBPRelationship() {
        return null;
    }

    public Location addLocation(String locationName, String sapId, Address address) {
    return new MockLocation("MOCK1", locationName, sapId, false, address, null, null, null);
  }

  public Location updateLocation(String locationId, String locationName,
                                 Address address) {
    return null;
  }


  public List<LocationType> lookupBPLocRelTypes() {
    List<LocationType> types = new ArrayList<LocationType>();
    types.add(new LocationType(1L, "Plant"));
    types.add(new LocationType(2L, "Main"));
    types.add(new LocationType(3L, "Other"));
    return types;
  }

  public List<ContactType> getContactTypes() {
    List<ContactType> types = new ArrayList<ContactType>();
    types.add(new ContactType("1", "1"));
    return types;
  }

  public List<String> getNamePrefixes() {
    List<String> prefixes = new ArrayList<String>();
    prefixes.add("Dr.");
    return prefixes;
  }

  public void addLocationToBp(boolean isPrimary
  ) {
    this.isPrimary = isPrimary;
    addLocationToBpCalled = true;
  }

  public void addContactToLocation(Location location, ContactInfo contact, boolean isContactPrimary,
                                   ContactType locConRelType) {
    this.isContactPrimary = isContactPrimary;
    addContactToLocationCalled = true;
  }

  public boolean wasAddLocationToBpCalled() {
    return addLocationToBpCalled;
  }

  public boolean wasAddContactToLocationCalled() {
    return addContactToLocationCalled;
  }

  public boolean isContactPrimary() {
    return isContactPrimary;
  }

  public boolean isPrimary() {
    return isPrimary;
  }
}