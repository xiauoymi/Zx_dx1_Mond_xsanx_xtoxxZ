package com.monsanto.wst.humanrightspolicy.location.test;

import com.monsanto.wst.humanrightspolicy.assessment.GlobalAssessment;
import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.Region;
import com.monsanto.wst.humanrightspolicy.model.StateProvince;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
/*
 MockCountry was created on Feb 28, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class MockCountry extends Country {
  private final List<StateProvince> states;
  private final Region parentRegion;
  private SortedSet<GlobalAssessment> glbAsmts;

  public MockCountry(String id, String value) {
    this(id, value, (Region) null, null);
  }

  public MockCountry(String id, String value, Region parentRegion, SortedSet<GlobalAssessment> gblAsmts) {
    super(id, value);
    this.parentRegion = parentRegion;
    this.glbAsmts = gblAsmts;
    this.states = new ArrayList<StateProvince>();
  }

  public MockCountry(String id, String value, List<StateProvince> states) {
    this(id, value, (Region) null, null);
    this.states.addAll(states);
  }

  public Region getRegion() {
    return parentRegion;
  }

  public List<StateProvince> getStates() {
    return states;
  }

  public void addState(StateProvince state) {
    states.add(state);
  }

  public SortedSet<GlobalAssessment> getGlobalAssessments() {
    return glbAsmts;
  }
}
