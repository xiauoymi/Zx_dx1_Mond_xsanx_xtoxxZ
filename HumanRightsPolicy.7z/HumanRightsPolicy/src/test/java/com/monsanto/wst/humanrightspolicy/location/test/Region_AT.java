package com.monsanto.wst.humanrightspolicy.location.test;

import com.monsanto.wst.humanrightspolicy.geodata.GeoDataFactory;
import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.Region;
import com.monsanto.wst.humanrightspolicy.testUtils.HumanRightsPolicyDatabaseTestCase;
import com.monsanto.wst.humanrightspolicy.utils.InitService;

import java.util.List;
/*
 Region_AT was created on Feb 18, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class Region_AT extends HumanRightsPolicyDatabaseTestCase {
    public void testNorthAmericaHasUnitedStatesInIt() throws Exception {
        GeoDataFactory geoDataFactory = InitService.initGeoDataFactory();
        List<Region> regions = geoDataFactory.getRegions();
        boolean northAmericaFound = false;
        for (Region region : regions) {
            if ("North America".equals(region.getValue())) {
                northAmericaFound = true;

                List<Country> countries = region.getCountries();
                assertNotNull(countries);
                boolean usFound = false;
                for (Country country : countries) {
                    if ("United States".equals(country.getValue())) {
                        usFound = true;
                    }
                }

                assertTrue(usFound);
            }
        }
        assertTrue(northAmericaFound);
    }
}
