package com.monsanto.wst.humanrightspolicy.model;
/*
 MockState was created on Aug 27, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

public class MockState extends StateProvince {
  private final Country parentCountry;

  public MockState(String id, String value, Country parentCountry) {
    super(id, value);
    this.parentCountry = parentCountry;
  }

  public Country getCountry() {
    return parentCountry;
  }
}
