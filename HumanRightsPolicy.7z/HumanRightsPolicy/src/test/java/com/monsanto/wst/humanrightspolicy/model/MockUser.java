package com.monsanto.wst.humanrightspolicy.model;

/*
 MockUser was created on Feb 27, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class MockUser extends LoginUserImpl {
  public MockUser(Long id, String userId, Role role) {
    this(id, userId, userId, false, role, "test Description", "testEmail");
  }

  public MockUser(Long id, String userId, String username, boolean isAdmin, Role role, String description,
                  String email) {
    super(id, userId, isAdmin, role, username, description, email);
  }

  public MockUser(Long id, String userId, String username, boolean isAdmin, Role role) {
    super(id, userId, isAdmin, role, username, "test Description", "testEmail");
  }

  public boolean isAuthorized(StateProvince state) {
    return "ILLINOIS".equalsIgnoreCase(state.getValue());
  }
}
