/*
 ActionImpl_UT was created on Aug 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.model.ActionPriority;
import com.monsanto.wst.humanrightspolicy.model.Status;
import junit.framework.TestCase;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Filename:    $RCSfile: Action_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:22 $
 *
 * @author rrmall
 * @version $Revision: 1.7 $
 */
public class Action_UT extends TestCase {
  public void testCreateAction() throws Exception {
    Action action = new Action(new Long(1), "Test Action", new Date(), new Date(), new Date(), new Status(new Long(1), null), new ActionPriority(new Long(1), null),"20", "test Action Item.",
        null);
    assertNotNull(action);
    assertEquals(new Long(1), action.getId());
    assertEquals("Test Action", action.getName());
    assertEquals(new Long(1), action.getStatus().getId());
    assertEquals(new Long(1), action.getPriority().getId());
    assertEquals(formatDate(new Date()), action.getFormattedStartDate());
    assertEquals("20", action.getPercentageComplete());
    assertEquals("test Action Item.", action.getDescription());
  }

  public void testToXml() throws Exception {
    Action action = new Action(new Long(1), "Test Action", new Date("2008/10/15"), new Date("2008/10/15"), new Date("2008/10/15"), new Status(new Long(1), null), new ActionPriority(new Long(1), null),"20", "test Action Item.",
        null);
    assertEquals("<action><actionId>1</actionId><actionName>Test Action</actionName><actionStartDate>2008-10-15</actionStartDate>" +
        "<actionStatus></actionStatus><actionDate>2008-10-15</actionDate><actionPriority></actionPriority><actionPercentComplete>20</actionPercentComplete><actionDescription>test Action Item.</actionDescription>" +
        "<actionViewUrl>/humanrightspolicy/servlet/action?method=lookupAction&amp;actionId=1&amp;menu=action</actionViewUrl></action>", action.toXml());
  }

  private String formatDate(Date date) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    if (date != null){
      return sdf.format(date);
    }else{
      return null;
    }
  }
}