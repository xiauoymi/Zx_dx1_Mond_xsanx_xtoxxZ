package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.Address;
import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.Region;
import com.monsanto.wst.humanrightspolicy.model.StateProvince;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Jun 16, 2006 Time: 2:53:01 PM To change this template use File |
 * Settings | File Templates.
 */
public class Address_UT extends TestCase {

  public void testCreate() throws Exception {
    Address address = new Address(null, null, null, null, null, null, null, null);
    assertNotNull(address);
  }

  public void testBuildContructorAndCheckValues() throws Exception {
    Address address = new Address(null, "StreetAddress 1", "StreetAddress 2", "City", "ZIP", new StateProvince("10", "ILLINOIS"
    ),
        new Country("10", "UNITED STATES OF AMERICA"), new Region("2", "NALAN"));
    assertEquals("StreetAddress 1", address.getStreetAddress1());
    assertEquals("StreetAddress 2", address.getStreetAddress2());
    assertEquals("City", address.getCity());
    assertEquals("10", address.getStateModel().getId());
    assertEquals("10", address.getCountryModel().getId());
    assertEquals("ZIP", address.getZipcode());
    assertEquals("2", address.getRegionModel().getId());
  }
}
