/*
 Assignment_UT was created on Sep 29, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.*;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: Assignment_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:22 $
 *
 * @author rrmall
 * @version $Revision: 1.3 $
 */
public class Assignment_UT extends TestCase {
  public void testCreateAssignment() throws Exception {
    LoginUser user = new LoginUserImpl(new Long(123), "MECORU", false, new Role("1", null), "MECORU", "test", null);
    HRPEntity target = new Action(null, "test Action name", null, null, null, null, null,  null, "test action item", null);
    Assignment assignment = new Assignment(null, user, target, false, HRPEntityType.Action);
    assertNotNull(assignment);
    assertNotNull(assignment.getTarget());
    assertNotNull(assignment.getUser());
    assertNotNull(assignment.getEntityType());
  }

  public void testToXml() throws Exception{
     LoginUser user = new LoginUserImpl(new Long(123), "MECORU", false, new Role("1", null), "MECORU", "test", null);
    HRPEntity target = new Action(new Long(23), "test Action name", null, null, null, null, null,  null, "test action item", null);
    Assignment assignment = new Assignment(new Long(1), user, target, false, HRPEntityType.Action);
    assertEquals("<assignment><assignmentId>1</assignmentId><assignmentUserId>MECORU</assignmentUserId>" +
        "<assignmentUserName>MECORU</assignmentUserName><isPrimary>N</isPrimary>" +
        "<updatePrimaryFlagUrl>/humanrightspolicy/servlet/action?method=setAssignmentAsPrimary&amp;assignmentId=1&amp;targetId=23&amp;menu=assignment</updatePrimaryFlagUrl>" +
        "<assignmentViewUrl>/humanrightspolicy/servlet/action?method=lookupAction&amp;actionId=1&amp;menu=assignment</assignmentViewUrl>" +
        "</assignment>", assignment.toXml());
  }

}