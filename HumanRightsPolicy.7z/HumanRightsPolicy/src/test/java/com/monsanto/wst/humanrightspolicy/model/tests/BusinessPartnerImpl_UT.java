package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.tests.mock.MockBusinessPartnerDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock.MockCommunicationDAO;
import com.monsanto.wst.humanrightspolicy.datasource.Filterable;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.*;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/*
 BusinessPartner_UT was created on Mar 5, 2007 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto
 */

public class BusinessPartnerImpl_UT extends TestCase {
  public void testEquals() throws Exception {
    BusinessPartnerImpl partner1 = new BusinessPartnerImpl("1", null, null, null, null, null, null,
        null, null, null);
    BusinessPartnerImpl partner2 = new BusinessPartnerImpl("1", null, null, "foo", null, null,
        null, null, null, null);
    assertEquals(partner1, partner2);
    assertEquals(partner1.hashCode(), partner2.hashCode());
  }

  public void testNotEquals() throws Exception {
    BusinessPartnerImpl partner1 = new BusinessPartnerImpl("1", null, null, null, null, null, null,
        null, null, null);
    BusinessPartnerImpl partner2 = new BusinessPartnerImpl("2", null, null, "foo", null, null,
        null, null, null, null);
    assertFalse(partner1.equals(partner2));
  }

  public void testNotEqualsWrongType() throws Exception {
    BusinessPartnerImpl partner1 = new BusinessPartnerImpl("1", null, null, null, null, null, null,
        null, null, null);
    assertFalse(partner1.equals("1"));
  }

  public void testHRPFLag_N_ReturnsN() throws Exception {
    BusinessPartnerImpl bp = new BusinessPartnerImpl("1", null, null, null, null, null, null,
        null, "N", null);
    assertEquals("N", bp.getHrpFlag());
  }

  public void testHRPFLag_Empty_ReturnsEmpty() throws Exception {
    BusinessPartnerImpl bp = new BusinessPartnerImpl("1", null, null, null, null, null, null,
        null, "", null);
    assertEquals("", bp.getHrpFlag());
  }

  public void testHRPFLag_Y_ReturnsY() throws Exception {
    BusinessPartnerImpl bp = new BusinessPartnerImpl("1", null, null, null, null, null, null,
        null, "Y", null);
    assertEquals("Y", bp.getHrpFlag());
  }

  public void testSAPID_null_ReturnsNull() throws Exception {
    BusinessPartnerImpl bp = new BusinessPartnerImpl("1", null, null, null, null, null, null,
        null, null, null);
    assertNull(bp.getSapId());
  }

  public void testSAPID_empty_ReturnsNull() throws Exception {
    BusinessPartnerImpl bp = new BusinessPartnerImpl("1", "  ", null, null, null, null, null,
        null, null, null);
    assertNull(bp.getSapId());
  }

  public void testSAPID_Partial_ReturnsValueWithPaddedZeros() throws Exception {
    BusinessPartnerImpl bp = new BusinessPartnerImpl("1", " 123 ", null, null, null, null, null,
        null, null, null);
    assertEquals("0000000123", bp.getSapId());
  }

  public void testSAPID_SetterMethod_ReturnsValueWithPaddedZeros() throws Exception {
    BusinessPartnerImpl bp = new BusinessPartnerImpl("1", " 123 ", null, null, null, null, null,
        null, null, null);
    assertEquals("0000000123", bp.getSapId());
  }

  public void testGetFormattedSAPID() throws Exception {
    BusinessPartnerImpl bp = new BusinessPartnerImpl("1", " 123 ", null, null, null, null, null,
        null, null, null);
    assertEquals("0000000123", bp.getFormattedSapId());
  }

  public void testGetFullName() throws Exception {
       BusinessPartnerImpl bp = new BusinessPartnerImpl("1", " 123 ", null, "ABC", "DEF", null, null,
        null, null, null);
    assertEquals("ABC <br /> DEF", bp.getFullName());
  }
  
  public void testGetFullName_AliasNameIsNull() throws Exception {
       BusinessPartner bp = new BusinessPartnerImpl("1", " 123 ", null, "ABC", null, null, null,
        null, null, null);
    assertEquals("ABC", bp.getFullName());
  }

  public void testToXml() throws Exception {
    Address address = new Address(null, "StreetAddress 1", "StreetAddress 2", "City", "ZIP", new StateProvince("10", null
    ), new Country("10", null), new Region("2", null));
    BusinessPartner bp = new MockBusinessPartnerImpl("12", "BP NAME IS HERE", "ALIAS NAME IS HERE", "23455", null, null,
        address,
        null, null, new MockBusinessPartnerDAO("GROWER, LABOR", null));
    String xmlStr = bp.toXml();
    assertEquals("<bp><id>12</id><sapId>0000023455</sapId><bpName>BP NAME IS HERE &lt;br /&gt; ALIAS NAME IS HERE</bpName><hrpTypesAsString>GROWER, LABOR</hrpTypesAsString><country></country><state></state><region></region><hrpFlag></hrpFlag><addUrl>/humanrightspolicy/servlet/searchBusinessPartner?method=setHrpFlagInBP&amp;businessPartnerId=12&amp;hrpFlag=Y</addUrl><removeUrl>/humanrightspolicy/servlet/searchBusinessPartner?method=setHrpFlagInBP&amp;businessPartnerId=12&amp;hrpFlag=N</removeUrl><viewUrl>/humanrightspolicy/servlet/businessPartner?method=lookupBP&amp;businessPartnerId=12&amp;menu=</viewUrl></bp>", xmlStr);
  }

  public void testGetLocationRelationshipsNoRelationsips() throws Exception {
    BPLocationRelationshipDAO dao = new MockBPLocationRelationshipDAO(new ArrayList<BPLocationRelationship>());
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, dao, null, null);
    List<BPLocationRelationship> locRelations = bp.getActiveBPLocationRelationships();
    assertNotNull(locRelations);
    assertEquals(0, locRelations.size());
  }

  public void testGetLocationRelationshipsWithRelationsips() throws Exception {
    List<BPLocationRelationship> locs = new ArrayList<BPLocationRelationship>();
    locs.add(new MockBPLocationRelationship());
    BPLocationRelationshipDAO dao = new MockBPLocationRelationshipDAO(locs);
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, dao, null, null);
    List<BPLocationRelationship> locRelations = bp.getActiveBPLocationRelationships();
    assertNotNull(locRelations);
    assertFalse(locRelations.size() == 0);
  }

  public void testBPDAOIsCorrect() throws Exception {
    MockBusinessPartnerForVisibility bp = new MockBusinessPartnerForVisibility();
    BPLocationRelationshipDAO dao = bp.getBPLocationRelationshipDAO();
    assertNotNull(dao);
    assertTrue(dao instanceof BPLocationRelationshipDAO);
  }

  public void testGetPrimaryBPLocationRelationship_ReturnsARelationship() throws Exception {
    List<BPLocationRelationship> locs = new ArrayList<BPLocationRelationship>();
    locs.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, new MockLocationImpl(1)));
    locs.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, new MockLocationImpl(2)));
    MockBPLocationRelationship mockRel = new MockBPLocationRelationship(true, new LocationType(1L, null), null, new MockLocationImpl(123));
    locs.add(mockRel);
    locs.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, new MockLocationImpl(3)));
    BPLocationRelationshipDAO dao = new MockBPLocationRelationshipDAO(locs);
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, dao, null, null);
    BPLocationRelationship relationship = bp.getPrimaryRelationship();
    assertNotNull(relationship);
    assertEquals(mockRel, relationship);
  }

  public void testNoPrimaryLocationReturnsNull() throws Exception {
    List<BPLocationRelationship> locs = new ArrayList<BPLocationRelationship>();
    locs.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, new MockLocationImpl(1)));
    locs.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, new MockLocationImpl(2)));
    locs.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, new MockLocationImpl(3)));
    BPLocationRelationshipDAO dao = new MockBPLocationRelationshipDAO(locs);
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, dao, null, null);
    BPLocationRelationship relationship = bp.getPrimaryRelationship();
    assertNull(relationship);
  }

  public void testGetLocations() throws Exception {
    List<BPLocationRelationship> locationRelationships = new ArrayList<BPLocationRelationship>();
    Location loc1 = new MockLocationImpl(0);
    Location loc2 = new MockLocationImpl(1);
    Location loc3 = new MockLocationImpl(2);
    Location loc4 = new MockLocationImpl(3);
    locationRelationships.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, loc1));
    locationRelationships.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, loc2));
    locationRelationships.add(new MockBPLocationRelationship(true, new LocationType(1L, null), null, loc3));
    locationRelationships.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, loc4));
    BPLocationRelationshipDAO dao = new MockBPLocationRelationshipDAO(locationRelationships);
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, dao, null, null);
    List<Location> locs = bp.getLocations();
    assertNotNull(locs);
    assertEquals(4, locs.size());
    assertTrue(locs.contains(loc1));
    assertTrue(locs.contains(loc2));
    assertTrue(locs.contains(loc3));
    assertTrue(locs.contains(loc4));
  }

//  public void testAddLocation_LocationAlreadyExists() throws Exception {
//    List<BPLocationRelationship> allRelationships = new ArrayList<BPLocationRelationship>();
//
//    BPLocationRelationshipDAO mockDao = new MockBPLocationRelationshipDAO(allRelationships);
//    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, mockDao, null);
//    Location loc1 = new LocationImpl("1", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
//    bp.addLocation(loc1, "USERID");
//    Location loc2 = new LocationImpl("1", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
//    bp.addLocation(loc2, "USERID");
//    assertEquals(1, allRelationships.size());
//  }
//
//  public void testAddLocation_LocationAdded() throws Exception {
//    List<BPLocationRelationship> allRelationships = new ArrayList<BPLocationRelationship>();
//
//    BPLocationRelationshipDAO mockDao = new MockBPLocationRelationshipDAO(allRelationships);
//    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, mockDao, null);
//    Location loc1 = new LocationImpl("1", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
//    bp.addLocation(loc1, "USERID");
//    Location loc2 = new LocationImpl("2", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
//    bp.addLocation(loc2, "USERID");
//    assertEquals(2, allRelationships.size());
//  }

//  public void testSetPrimaryLocation_NoPrimaryExists_SetsLocationAsPrimary() throws Exception {
//    List<BPLocationRelationship> allRelationships = new ArrayList<BPLocationRelationship>();
//    allRelationships.add(new MockBPLocationRelationship(false, new CommonModel("1", null), "1", new MockLocationImpl(1)));
//
//    BPLocationRelationshipDAO mockDao = new MockBPLocationRelationshipDAO(allRelationships);
//    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, mockDao, null);
//    Location loc1 = new MockLocationImpl(1);
//    Location loc2 = new MockLocationImpl(2);
//    bp.setPrimaryLocation(loc1, "USERID");
//    bp.addLocationRelationship(loc2, true, new CommonModel("1", null), "USERID");
//    assertNotNull(bp.getPrimaryRelationship());
//    assertEquals(loc1, bp.getPrimaryRelationship().getLocation());
//    assertLocationRelationshipExists(allRelationships, loc1, true, true);
//    assertLocationRelationshipExists(allRelationships, loc2, false, true);
//  }

  public void testSetPrimaryLocation_PrimaryExists_ClosesOldRelationshipsCreatesNewOnes() throws Exception {
    Location loc1 = new MockLocationImpl(1);
    Location loc2 = new MockLocationImpl(2);
    Location loc3 = new MockLocationImpl(3);
    List<BPLocationRelationship> allRelationships = new ArrayList<BPLocationRelationship>();
    allRelationships.add(new MockBPLocationRelationship(false, new LocationType(1L, null), "1", loc1));
    allRelationships.add(new MockBPLocationRelationship(true, new LocationType(1L, null), "33", loc3));

    BPLocationRelationshipDAO mockDao = new MockBPLocationRelationshipDAO(allRelationships);
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, mockDao, null, null);
    bp.setPrimaryLocation(loc1);
    bp.addLocationRelationship(loc2, false, new LocationType(1L, null));
    assertNotNull(bp.getPrimaryRelationship());
    assertTrue(loc1.equals(bp.getPrimaryRelationship().getLocation()));
    assertLocationRelationshipExists(allRelationships, loc1, true, true);
    assertLocationRelationshipExists(allRelationships, loc2, false, true);
    assertLocationRelationshipExists(allRelationships, loc3, false, true);

    bp.setPrimaryLocation(loc2);
    assertNotNull(bp.getPrimaryRelationship());
    assertTrue(loc2.equals(bp.getPrimaryRelationship().getLocation()));

    assertLocationRelationshipExists(allRelationships, loc1, true, false);
    assertLocationRelationshipExists(allRelationships, loc2, false, false);
    assertLocationRelationshipExists(allRelationships, loc1, false, true);
    assertLocationRelationshipExists(allRelationships, loc2, true, true);
    assertLocationRelationshipExists(allRelationships, loc3, false, true);
  }

  public void testGetActiveContacts_ReturnsEmptyList() throws Exception {
    List<BPLocationRelationship> allRelationships = new ArrayList<BPLocationRelationship>();
    BPLocationRelationshipDAO mockDao = new MockBPLocationRelationshipDAO(allRelationships);
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, mockDao, null, null);
    List<ContactInfo> contacts = bp.getActiveContacts();
    assertTrue(contacts.isEmpty());
  }

  public void testGetActiveContacts_Returns2Contacts() throws Exception {
    List<BPLocationRelationship> bpLocationRels = new ArrayList<BPLocationRelationship>();
    List<LocationContactRelationship> locConRels = new ArrayList<LocationContactRelationship>();

    ContactInfo contact1 = new MockContactInfo("1", null, null, "N");
    locConRels.add(new MockLocationContactRelationship(null, true, true, contact1, null, new ContactType(11L, "Worker")
    ));
    Location loc1 = new MockLocationImpl(null, new MockLocationContactRelationshipDAO(locConRels), null, null);

    locConRels = new ArrayList<LocationContactRelationship>();
    contact1 = new MockContactInfo("1", null, null, "N");
    locConRels.add(new MockLocationContactRelationship(null, false, true, contact1, null, new ContactType(11L, "Worker")
    ));
    ContactInfo contact2 = new MockContactInfo("2", null, null, "N");
    locConRels.add(new MockLocationContactRelationship(null, true, false, contact2, null, new ContactType(11L, "Worker")
    ));
    Location loc2 = new MockLocationImpl(null, new MockLocationContactRelationshipDAO(locConRels), null, null);

    bpLocationRels.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, loc1));
    bpLocationRels.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, loc2));

    BPLocationRelationshipDAO mockDao = new MockBPLocationRelationshipDAO(bpLocationRels);
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, mockDao, null, null);
    List<ContactInfo> contacts = bp.getActiveContacts();
    assertEquals(2, contacts.size());
    assertTrue(contacts.contains(contact1));
    assertTrue(contacts.contains(contact2));
  }

  public void testGetPrimaryContact_NoPrimaryContactExists_ReturnsNull() throws Exception {
    List<BPLocationRelationship> bpLocationRels = new ArrayList<BPLocationRelationship>();
    List<LocationContactRelationship> locConRels = new ArrayList<LocationContactRelationship>();

    ContactInfo contact1 = new MockContactInfo("1", null, null, "N");
    locConRels.add(new MockLocationContactRelationship(null, true, true, contact1, null, new ContactType(11L, "Worker")
    ));
    Location loc1 = new MockLocationImpl(null, new MockLocationContactRelationshipDAO(locConRels), null, null);
    bpLocationRels.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, loc1));

    locConRels = new ArrayList<LocationContactRelationship>();
    contact1 = new MockContactInfo("1", null, null, "N");
    locConRels.add(new MockLocationContactRelationship(null, false, true, contact1, null, new ContactType(11L, "Worker")
    ));
    ContactInfo contact2 = new MockContactInfo("2", null, null, "N");
    locConRels.add(new MockLocationContactRelationship(null, true, false, contact2, null, new ContactType(11L, "Worker")
    ));
    Location loc2 = new MockLocationImpl(null, new MockLocationContactRelationshipDAO(locConRels), null, null);
    bpLocationRels.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, loc2));

    BPLocationRelationshipDAO mockDao = new MockBPLocationRelationshipDAO(bpLocationRels);
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, mockDao, null, null);
    ContactInfo contact = bp.getPrimaryContact();
    assertNull(contact);
  }

  public void testGetPrimaryContact_PrimaryContactExists_ReturnsAContact() throws Exception {
    List<BPLocationRelationship> bpLocationRels = new ArrayList<BPLocationRelationship>();
    List<LocationContactRelationship> locConRels = new ArrayList<LocationContactRelationship>();

    ContactInfo contact1 = new MockContactInfo("1", null, null, "N");
    locConRels.add(new MockLocationContactRelationship(null, true, true, contact1, null, new ContactType(11L, "Worker")
    ));
    Location loc1 = new MockLocationImpl(null, new MockLocationContactRelationshipDAO(locConRels), null, null);
    bpLocationRels.add(new MockBPLocationRelationship(false, new LocationType(1L, null), null, loc1));

    locConRels = new ArrayList<LocationContactRelationship>();
    contact1 = new MockContactInfo("1", null, null, "N");
    locConRels.add(new MockLocationContactRelationship(null, false, true, contact1, null, new ContactType(11L, "Worker")
    ));
    ContactInfo contact2 = new MockContactInfo("2", null, null, "N");
    locConRels.add(new MockLocationContactRelationship(null, true, false, contact2, null, new ContactType(11L, "Worker")
    ));
    Location loc2 = new MockLocationImpl(null, new MockLocationContactRelationshipDAO(locConRels), null, null);
    bpLocationRels.add(new MockBPLocationRelationship(true, new LocationType(1L, null), null, loc2));

    BPLocationRelationshipDAO mockDao = new MockBPLocationRelationshipDAO(bpLocationRels);
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, mockDao, null, null);
    ContactInfo contact = bp.getPrimaryContact();
    assertEquals(contact2, contact);
  }

  public void testBusinessPartnerImplFilterIsCorrect_WithoutAccents() throws Exception {
    String testSapId = "123";
    String testName = "ABC";
    String testRegion = "Antartica";
    String testCountry = "USA";
    String testState = "Iowa";

    Filterable bp = new BusinessPartnerImpl(null, testSapId, null, testName, null, "Y", "Y", "Y", null, "1",
        testCountry, "2", testState, "3", testRegion, "4", "123 Main", "Apt 1", "St charles", "MO", "http://", "note",
        null);

    assertTrue(bp.filter(testSapId));
    assertFalse(bp.filter("AAA"));

    assertTrue(bp.filter(testName));
    assertTrue(bp.filter("�bc"));
    assertFalse(bp.filter("AAA"));
  }

  public void testBusinessPartnerImplFilterIsCorrect_WithAccents() throws Exception {
    String testSapId = "123";
    String testName = "�BC";
    String testRegion = "Antartica";
    String testCountry = "USA";
    String testState = "Iowa";

    Filterable bp = new BusinessPartnerImpl(null, testSapId, null, testName, null, "Y", "Y", "Y", null, "1",
        testCountry, "2", testState, "3", testRegion, "4", "123 Main", "Apt 1", "St charles", "MO", "http://", "note",
        null);

    assertTrue(bp.filter(testSapId));
    assertFalse(bp.filter("AAA"));

    assertTrue(bp.filter(testName));
    assertTrue(bp.filter("ABC"));
  }

  public void testGetCommunications() throws Exception {
    List<Communication> communications = new ArrayList<Communication>();
    communications.add(new CommunicationImpl("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
        null, null, 1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "112", null));
    BusinessPartner bp = new MockBusinessPartnerImpl(null, null, null, null, null, null, null, new MockCommunicationDAO(communications),
        null);
    List<Communication> comms = bp.getCommunications();
    assertEquals(1, comms.size());
  }

  public void testLookupHrpTypesAsCommaSeparatedString() throws Exception {
    BusinessPartner bp = new MockBusinessPartnerImpl("1", null, null, null, null, null, null, null, new MockBusinessPartnerDAO("GROWER, LABOR",
        null));
    String typeStr = bp.getHrpTypesAsCommaSeparatedString();
    assertEquals("GROWER, LABOR", typeStr);
  }

  public void testLookupHrpTypesAsCommaSeparatedString_ReturnEmptyString() throws Exception {
    BusinessPartner bp = new MockBusinessPartnerImpl("2", null, null, null, null, null, null, null, new MockBusinessPartnerDAO("",
        null));
    String typeStr = bp.getHrpTypesAsCommaSeparatedString();
    assertTrue(typeStr.length() == 0);
  }

  private void assertLocationRelationshipExists(List<BPLocationRelationship> relationships, Location loc,
                                                boolean isPrimary, boolean isActive) {
    for (BPLocationRelationship rel : relationships) {
      if (rel.getLocation().equals(loc) && rel.getIsPrimary() == isPrimary &&
          isActive == (rel.getEndDate() == null)) {
        return;
      }
    }

    fail("Unable to find location: " + loc + " with primary=" + isPrimary + " and active=" + isActive);
  }

  private class MockBusinessPartnerForVisibility  extends BusinessPartnerImpl {
    protected BPLocationRelationshipDAO getBPLocationRelationshipDAO() {
      return super.getBPLocationRelationshipDAO();
    }
  }

}