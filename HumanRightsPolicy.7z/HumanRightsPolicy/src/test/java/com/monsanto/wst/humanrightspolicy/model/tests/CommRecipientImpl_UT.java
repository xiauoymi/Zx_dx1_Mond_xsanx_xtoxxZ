/*
 CommRecipientImpl_UT was created on Apr 28, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.datasource.Filterable;
import com.monsanto.wst.humanrightspolicy.model.CommRecipient;
import com.monsanto.wst.humanrightspolicy.model.CommRecipientImpl;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Filename:    $RCSfile: CommRecipientImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:22 $
 *
 * @author sspati1
 * @version $Revision: 1.16 $
 */
public class CommRecipientImpl_UT extends TestCase {

  public void testGetters_IDsAreEmpty() throws Exception {
    CommRecipient commRecipient = new CommRecipientImpl("1", "1", "1", "Y", "person name 1",
            null, "Plant", null, "employee",
        "", "India", "", "India", "", "Gujarat", "bp name 1", null, null, null, null, null, null, null);
    assertEquals("bp name 1", commRecipient.getBpName());
    assertEquals("bp name 1", commRecipient.getBpName());
    assertEquals("person name 1", commRecipient.getName());
    assertEquals("person name 1", commRecipient.getName());
    assertNull(commRecipient.getLocConRelType().getId());
    assertNull(commRecipient.getBpLocRelType().getId());
    assertNull(commRecipient.getAddress().getRegionModel().getId());
    assertNull(commRecipient.getAddress().getCountryModel().getId());
    assertNull(commRecipient.getAddress().getStateModel().getId());
  }

  public void testToXml_EndDateIsNotNull() throws Exception {
    CommRecipient commRecipient = new CommRecipientImpl("1", "1", "1", "Y", "person name 1", null, "Plant", null, "employee",
        "", "India", "", "India", "", "Gujarat", "bp name 1", null, "1", "FIRST STREET", "SECOND STREET", "ST.LOUIS", "63303",
        new Date());
    assertEquals("<recipient><recipientId>1</recipientId><commId>1</commId><hasContactsPrimaryRelationshipEnded>Y</hasContactsPrimaryRelationshipEnded><isDone>Y</isDone><name>person name 1</name><recipientTypeValue>employee</recipientTypeValue><company>bp name 1</company><region>India</region><country>India</country><state>Gujarat</state><address>FIRST STREET</address><address_two>SECOND STREET</address_two><city>ST.LOUIS</city><postal_code>63303</postal_code><viewUrl>/humanrightspolicy/servlet/contacts?method=lookupContact&amp;contactId=1&amp;menu=allcomm</viewUrl><updateDoneFlagUrl>/humanrightspolicy/data/commRecipient?method=updateDoneFlag&amp;commId=1&amp;recipientId=1&amp;menu=allcomm</updateDoneFlagUrl><addRecipientUrl>/humanrightspolicy/data/commRecipient?method=addRecipient&amp;recipientId=1&amp;menu=allcomm</addRecipientUrl><removeUrl>/humanrightspolicy/data/commRecipient?method=deleteRecipient&amp;recipientId=1&amp;menu=allcomm</removeUrl><removeUrlForAsync>/humanrightspolicy/data/commRecipient?method=deleteRecipient&amp;recipientId=1&amp;menu=allcomm</removeUrlForAsync></recipient>", commRecipient.toXml());
  }

  public void testToXml_EndDateIsNull() throws Exception {
    CommRecipient commRecipient = new CommRecipientImpl("1", "1", "1", "Y", "person name 1", null, "Plant", null, "employee",
        "", "India", "", "India", "", "Gujarat", "bp name 1", null, "1", "FIRST STREET", "SECOND STREET", "ST.LOUIS", "63303",
        null);
    assertEquals("<recipient><recipientId>1</recipientId><commId>1</commId><hasContactsPrimaryRelationshipEnded>N</hasContactsPrimaryRelationshipEnded><isDone>Y</isDone><name>person name 1</name><recipientTypeValue>employee</recipientTypeValue><company>bp name 1</company><region>India</region><country>India</country><state>Gujarat</state><address>FIRST STREET</address><address_two>SECOND STREET</address_two><city>ST.LOUIS</city><postal_code>63303</postal_code><viewUrl>/humanrightspolicy/servlet/contacts?method=lookupContact&amp;contactId=1&amp;menu=allcomm</viewUrl><updateDoneFlagUrl>/humanrightspolicy/data/commRecipient?method=updateDoneFlag&amp;commId=1&amp;recipientId=1&amp;menu=allcomm</updateDoneFlagUrl><addRecipientUrl>/humanrightspolicy/data/commRecipient?method=addRecipient&amp;recipientId=1&amp;menu=allcomm</addRecipientUrl><removeUrl>/humanrightspolicy/data/commRecipient?method=deleteRecipient&amp;recipientId=1&amp;menu=allcomm</removeUrl><removeUrlForAsync>/humanrightspolicy/data/commRecipient?method=deleteRecipient&amp;recipientId=1&amp;menu=allcomm</removeUrlForAsync></recipient>", commRecipient.toXml());
  }

  public void testCommRecipientImplFilter() throws Exception {
    String sapId = "123";
    String name = "ABC";
    String company = "Monsanto";
    String region = "Antartica";
    String country = "USA";
    String state = "Iowa";

    Filterable commRecipient = new CommRecipientImpl("1", "12", "1", "N", name, null, null, null, null, "1", region, "1", country, "1", state, company, sapId, "1", "123 Main", "Apt 1", "St charles", "12345",
        null);

    assertTrue(commRecipient.filter(company));
    assertFalse(commRecipient.filter("AAA"));

    assertTrue(commRecipient.filter(name));
    assertFalse(commRecipient.filter("AAA"));
  }
}