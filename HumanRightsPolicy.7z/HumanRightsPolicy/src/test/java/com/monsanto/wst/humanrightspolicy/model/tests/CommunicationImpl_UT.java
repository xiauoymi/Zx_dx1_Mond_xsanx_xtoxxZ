/*
 CommunicationImpl_UT was created on Apr 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock.MockCommActionItemsDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock.MockCommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.datasource.Filterable;
import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.model.CommRecipient;
import com.monsanto.wst.humanrightspolicy.model.Communication;
import com.monsanto.wst.humanrightspolicy.model.CommunicationImpl;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.MockCommunication;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: CommunicationImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-10-17 15:36:22 $
 *
 * @author sspati1
 * @version $Revision: 1.31 $
 */
public class CommunicationImpl_UT extends XMLTestCase {

    public void testCreate() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
                null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertNotNull(comm);
        assertEquals("12", comm.getId());
        assertEquals("commName", comm.getName());
        assertEquals("comm notes", comm.getNotes());
        assertEquals(getFormattedDate(new Date()), comm.getFormattedFromDate());
        assertEquals(getFormattedDate(new Date()), comm.getFormattedToDate());
        assertNull(comm.getUrlTitle());
        assertNull(comm.getUrl());
        assertNull(comm.getFormattedUrl());
        assertEquals(new Long(1), comm.getCommType().getId());
        assertEquals("Letter", comm.getCommType().getType());
        assertEquals(new Long(2), comm.getLocConRelType().getId());
        assertEquals("Contact", comm.getLocConRelType().getType());
        assertEquals(new Long(3), comm.getBpLocRelType().getId());
        assertEquals("Main", comm.getBpLocRelType().getType());
        assertEquals(new Long(4L), comm.getStatus().getId());
        assertEquals("New", comm.getStatus().getStatus());
        assertNull(comm.getDateCompleted());
    }


    public void testGetNameForLike() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date(), new Date(), null,
                "Y", "This Title", "www.monsanto.com", 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertNotNull(comm);
        assertEquals("12", comm.getId());
        assertEquals("commName", comm.getName());
        assertEquals("comm notes", comm.getNotes());
        assertEquals(getFormattedDate(new Date()), comm.getFormattedFromDate());
        assertEquals(getFormattedDate(new Date()), comm.getFormattedToDate());
        assertEquals("This Title", comm.getUrlTitle());
        assertEquals("www.monsanto.com", comm.getUrl());
        assertEquals("<a href='http://www.monsanto.com'>This Title</a>", comm.getFormattedUrl());
        assertEquals(new Long(1), comm.getCommType().getId());
        assertEquals("Letter", comm.getCommType().getType());
        assertEquals(new Long(2), comm.getLocConRelType().getId());
        assertEquals("Contact", comm.getLocConRelType().getType());
        assertEquals(new Long(3), comm.getBpLocRelType().getId());
        assertEquals("Main", comm.getBpLocRelType().getType());
        assertEquals(new Long(4L), comm.getStatus().getId());
        assertEquals("New", comm.getStatus().getStatus());
    }

    public void testGetFormattedUrl_UrlStartWithHttp() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date(), new Date(), null,
                "Y", "This Title", "http://www.monsanto.com", 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertEquals("This Title", comm.getUrlTitle());
        assertEquals("http://www.monsanto.com", comm.getUrl());
        assertEquals("<a href='http://www.monsanto.com'>This Title</a>", comm.getFormattedUrl());
    }

    public void testGetRecipients() throws Exception {
        Communication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y", 1L,
                "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        List<CommRecipient> commRecipients = comm.getRecipients();
        assertEquals(2, commRecipients.size());
    }

    public void testGetRecipientsByCriteria() throws Exception {
        Communication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y", 1L,
                "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        CommRecipient criteria = null;
        List<CommRecipient> commRecipients = comm.getRecipientsByCriteria(criteria);
        assertEquals(2, commRecipients.size());
    }

    public void testGetRecipientsNotAssociatedWithThisCommunicationByCriteria() throws Exception {
        Communication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y", 1L,
                "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        CommRecipient criteria = null;
        List<CommRecipient> commRecipients = comm.getRecipientsNotAssociatedWithThisCommunicationByCriteria(criteria);
        assertEquals(2, commRecipients.size());
    }

    public void testUpdateDoneFlagForRecipient() throws Exception {
        MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
                1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        comm.updateDoneFlagForRecipient("22", "N");
        assertTrue(((MockCommRecipientDAO) comm.getCommRecipientDAO()).isUpdateDoneFlagForRecipientCalled());
    }

    public void testUpdateDoneFlagForSelectedRecipients() throws Exception {
        MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
                1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        List<String> selectedIds = new ArrayList<String>();
        selectedIds.add("1");
        selectedIds.add("2");
        comm.updateDoneFlagForSelectedRecipients(selectedIds, "N");
        assertTrue(((MockCommRecipientDAO) comm.getCommRecipientDAO()).isUpdateDoneFlagForSelectedRecipientsCalled());
        assertEquals(2, ((MockCommRecipientDAO) comm.getCommRecipientDAO()).getSelectedRecipientIds().size());
    }

    public void testUpdateDoneFlagForAllRecipient() throws Exception {
        MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
                1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        comm.updateDoneFlagForAllRecipients("N");
        assertTrue(((MockCommRecipientDAO) comm.getCommRecipientDAO()).isUpdateDoneFlagForAllRecipientsCalled());
    }

    public void testAreAllRecipientsMarkedAsDone_False() throws Exception {
        Communication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
                1L,
                "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        boolean areAllRecipientsMarkedAsDone = comm.areAllRecipientsMarkedAsDone();
        assertFalse(areAllRecipientsMarkedAsDone);
    }

    public void testDeleteAllRecipients() throws Exception {
        MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
                1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        comm.deleteAllRecipients();
        assertTrue(((MockCommRecipientDAO) comm.getCommRecipientDAO()).isDeleteAllRecipientsCalled());
    }

    public void testDeleteSelectedRecipients() throws Exception {
        MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
                1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        List<String> ids = new ArrayList<String>();
        ids.add("1");
        ids.add("2");
        comm.deleteSelectedRecipients(ids);
        assertTrue(((MockCommRecipientDAO) comm.getCommRecipientDAO()).isDeleteSelectedRecipientsCalled());
        assertEquals(2, ((MockCommRecipientDAO) comm.getCommRecipientDAO()).getSelectedRecipientIds().size());
    }

    public void testAddRecipient() throws Exception {
        MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
                1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        comm.addRecipient("22");
        assertTrue(((MockCommRecipientDAO) comm.getCommRecipientDAO()).isAddRecipientCalled());
    }

    public void testAddRecipients() throws Exception {
        MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
                1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        List<CommRecipient> recipients = new ArrayList<CommRecipient>();
        comm.addRecipients(recipients);
        assertTrue(((MockCommRecipientDAO) comm.getCommRecipientDAO()).isAddRecipientsCalled());
    }

    public void testToXML() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"),
                new Date("05/30/2008"), "Y", null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertEquals(
                "<communication><id>12</id><urgent>Y</urgent><name>commName</name><fromPeriod>2008-04-30</fromPeriod><toPeriod>2008-04-30</toPeriod><dueDate>2008-05-30</dueDate><active>Y</active><link></link><commTypeValue>Letter</commTypeValue><recipientTypeValue>Contact</recipientTypeValue><locTypeValue>Main</locTypeValue><status>New</status><viewUrl>/humanrightspolicy/servlet/communication?method=lookupCommunication&amp;commId=12&amp;menu=myComms</viewUrl></communication>",
                comm.toXml());
    }

    public void testToXML_WithUrl() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"),
                new Date("05/30/2008"), "Y", "Link Title", "www.monsanto.com", 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertEquals(
                "<communication><id>12</id><urgent>Y</urgent><name>commName</name><fromPeriod>2008-04-30</fromPeriod><toPeriod>2008-04-30</toPeriod><dueDate>2008-05-30</dueDate><active>Y</active><link>&lt;a href='http://www.monsanto.com'&gt;Link Title&lt;/a&gt;</link><commTypeValue>Letter</commTypeValue><recipientTypeValue>Contact</recipientTypeValue><locTypeValue>Main</locTypeValue><status>New</status><viewUrl>/humanrightspolicy/servlet/communication?method=lookupCommunication&amp;commId=12&amp;menu=myComms</viewUrl></communication>",
                comm.toXml());
    }

    public void testFilter_WithAccents() throws Exception {
        Filterable comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"),
                null, "Y", null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertTrue(comm.filter("comm"));
        assertFalse(comm.filter("test"));
    }

    public void testFilter_WithoutAccents() throws Exception {
        Filterable comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"),
                null, "Y", null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertTrue(comm.filter("c�mm"));
        assertFalse(comm.filter("�o"));
    }

    public void testGetDueInDays_DueDateIsNull_0() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"),
                null, "Y", null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertEquals(0, comm.getDueInDays());
    }

    public void testGetDueInDays_DueDateIsNotNull_3() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"),
                getDate(3), "Y", null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertEquals(3, comm.getDueInDays());
    }

    public void testGetDueInDays_DueDateIsNotNull_Negative4() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"),
                getDate(-4), "Y", null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertEquals(-4, comm.getDueInDays());
    }

    public void testGetUrgent_DueDateIsNull_NotUrgent() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"),
                null, "Y", null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertFalse(comm.getIsUrgent());
    }

    public void testGetUrgent_Closed_FutureDueDate_IsNotUrgent() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"), getDate(2), "Y", null, null, 1L, "Letter",
                4L, "Closed", 2L, "Contact", 3L, "Main", "112", null);
        assertFalse(comm.getIsUrgent());
    }

    public void testGetUrgent_Closed_PastDueDate_IsNotUrgent() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"), getDate(-4), "Y", null, null, 1L, "Letter",
                4L, "Closed", 2L, "Contact", 3L, "Main", "112", null);
        assertFalse(comm.getIsUrgent());
    }

    public void testGetUrgent_NotClosed_DueIn15Days_IsUrgent() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"), getDate(2), "Y", null, null, 1L, "Letter",
               5L, "Ready", 2L, "Contact", 3L, "Main", "112", null);
        assertTrue(comm.getIsUrgent());
    }

    public void testGetUrgent_NotClosed_DueIn10Days_IsUrgent() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"), getDate(10), "Y", null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertTrue(comm.getIsUrgent());
    }

    public void testGetUrgent_NotClosed_PassedDueDate_IsUrgent() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"), getDate(-2), "Y", null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertTrue(comm.getIsUrgent());
    }

    public void testGetUrgent_NotReady_DueIn30Days_IsUrgent() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"), getDate(30), "Y", null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertTrue(comm.getIsUrgent());
    }

    public void testGetUrgent_NotReady_DueIn15Days_IsUrgent() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"), getDate(30), "Y", null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertTrue(comm.getIsUrgent());
    }

    public void testGetUrgent_NotReady_DueIn32Days_IsNotUrgent() throws Exception {
        Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
                new Date("04/30/2008"), getDate(32), "Y", null, null, 1L, "Letter",
                4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        assertFalse(comm.getIsUrgent());
    }

    private String getFormattedDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sdf.format(date);
        }
        catch (Exception e) {
            return "";
        }
    }

    private Date getDate(int numDaysToAdd) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, numDaysToAdd);
        return cal.getTime();
    }

    public void testGetActionItems() throws Exception {
        MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
                1L, "Letter", 4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        MockCommActionItemsDAO mockCommActionItemDAO = (MockCommActionItemsDAO) comm.getCommActionItemDAO();
        mockCommActionItemDAO.addActionItem("22", "22");
        assertTrue(mockCommActionItemDAO.isAddActionItemCalled());
        assertNotNull(comm.getActionItemsAsList());
        assertTrue(comm.getActionItemsAsList().size() == 1);
    }

    public void testGetActionItemsAsXML() throws Exception {
        MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
                1L, "Letter", 4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        MockCommActionItemsDAO mockCommActionItemDAO = (MockCommActionItemsDAO) comm.getCommActionItemDAO();
        mockCommActionItemDAO.addActionItem("22", "22");
        Document doc = comm.getActionItemsAsXML();
        assertNotNull(doc);
    }

    public void testAddActionItem_ForGivenCommID() throws Exception {
        MockCommunication comm = new MockCommunication("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
                1L, "Letter", 4L, "New", 2L, "Contact", 3L, "Main", "112", null);
        MockCommActionItemsDAO mockCommActionItemDAO = (MockCommActionItemsDAO) comm.getCommActionItemDAO();
        mockCommActionItemDAO.addActionItem("22", "22");
        assertTrue(mockCommActionItemDAO.isAddActionItemCalled());
    }

    public void testAddActionItem_ForNullCommID() throws Exception {
        List<Action> actionItems = new ArrayList();
        Action actionItem = new Action();
        actionItem.setId(1L);
        actionItems.add(actionItem);
        MockCommActionItemsDAO mockCommActionItemDAO = new MockCommActionItemsDAO(actionItems);
        mockCommActionItemDAO.addActionItem(null, "22");
        assertFalse(mockCommActionItemDAO.isAddActionItemCalled());
    }


}