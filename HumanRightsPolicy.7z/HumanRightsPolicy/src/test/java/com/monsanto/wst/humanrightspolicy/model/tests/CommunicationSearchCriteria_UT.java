/*
 CommunicationSearchCriteria_UT was created on Aug 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.Communication;
import com.monsanto.wst.humanrightspolicy.model.CommunicationImpl;
import com.monsanto.wst.humanrightspolicy.model.CommunicationSearchCriteria;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Filename:    $RCSfile: CommunicationSearchCriteria_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:22 $
 *
 * @author SSPATI1
 * @version $Revision: 1.7 $
 */
public class CommunicationSearchCriteria_UT extends TestCase {

  public void testCreate() throws Exception {
    CommunicationSearchCriteria criteria = new CommunicationSearchCriteria(null, null,
        null, null, null, null);
    assertNotNull(criteria);
  }

  public void testGetters() throws Exception {
    Communication comm = new CommunicationImpl("12", "commName", "comm notes", new Date("04/30/2008"),
        null, null, "Y", null, null, 1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "112", null);
    CommunicationSearchCriteria criteria = new CommunicationSearchCriteria(comm, new Date("05/30/2008"),
    new Date("05/30/2008"), "11", "22", "33");
    assertEquals(comm, criteria.getCommunication());
    assertEquals("11", criteria.getStateId());
    assertEquals("22", criteria.getCountryId());
    assertEquals("33", criteria.getRegionId());
  }
}