package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipImpl;
import com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock.MockCommunicationDAO;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.*;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Jun 16, 2006 Time: 3:04:42 PM To change this template use File |
 * Settings | File Templates.
 */
public class ContactInfo_UT extends TestCase {

  public void testCreate() throws Exception {
    ContactInfo contactInfo = new ContactInfoImpl(null, null, null, null, null, null, null, null, null);
    assertNotNull(contactInfo);
  }

  public void testEquals() throws Exception {
    ContactInfo contact1 = new ContactInfoImpl("123", null, null, null, null, null, null, null, null);
    ContactInfo contact2 = new ContactInfoImpl("123", null, null, null, null, null, null, null, null);
    assertTrue(contact1.equals(contact2));
  }

  public void testNotEquals() throws Exception {
    ContactInfo contact1 = new ContactInfoImpl("123", null, null, null, null, null, null, null, null);
    ContactInfo contact2 = new ContactInfoImpl("456", null, null, null, null, null, null, null, null);
    assertFalse(contact1.equals(contact2));
  }

  public void testNotEqualsDifferentTypes() throws Exception {
    ContactInfo contact = new ContactInfoImpl("123", null, null, null, null, null, null, null, null);
    assertFalse(contact.equals("test"));
  }

  public void testGetLocationContactRelationships_ReturnsNoRels() throws Exception {
    ContactInfo contact = new MockContactInfo("123", new MockLocationContactRelationshipDAO(new ArrayList<LocationContactRelationship>()),
        null);
    List<LocationContactRelationship> relationships = contact.getActiveLocationContactRelationships();
    assertNotNull(relationships);
    assertEquals(0, relationships.size());
  }

  public void testGetLocationContactRelationships_Returns2Rels() throws Exception {
    List<LocationContactRelationship> rels = new ArrayList<LocationContactRelationship>();
    rels.add(new MockLocationContactRelationship(null, false, false, null, null, new ContactType(11L, "Worker")
    ));
    rels.add(new MockLocationContactRelationship(null, false, true, null, null, new ContactType(11L, "Worker")
    ));
    ContactInfo contact = new MockContactInfo("123", new MockLocationContactRelationshipDAO(rels), null);
    List<LocationContactRelationship> relationships = contact.getActiveLocationContactRelationships();
    assertNotNull(relationships);
    assertEquals(2, relationships.size());
  }

  public void testGetPrimaryLocation_ReturnsNull() throws Exception {
    List<LocationContactRelationship> rels = new ArrayList<LocationContactRelationship>();
    rels.add(new MockLocationContactRelationship(null, false, false, null, null, new ContactType(11L, "Worker")
    ));
    rels.add(new MockLocationContactRelationship(null, false, false, null, null, new ContactType(11L, "Worker")
    ));
    ContactInfo contact = new MockContactInfo("123", new MockLocationContactRelationshipDAO(rels), null);
    LocationContactRelationship relationship = contact.getPrimaryRelationship();
    assertNull(relationship);
  }

  public void testGetPrimaryLocation_ReturnsALocation() throws Exception {
    List<LocationContactRelationship> rels = new ArrayList<LocationContactRelationship>();
    rels.add(new MockLocationContactRelationship(null, false, false, null, null, new ContactType(11L, "Worker")
    ));
    MockLocationContactRelationship rel = new MockLocationContactRelationship(null, false, true, null, null, new ContactType(11L, "Worker")
    );
    rels.add(rel);
    ContactInfo contact = new MockContactInfo("123", new MockLocationContactRelationshipDAO(rels), null);
    LocationContactRelationship relationship = contact.getPrimaryRelationship();
    contact.getPrimaryRelationship();
    assertNotNull(relationship);
    assertEquals(rel, relationship);
  }

  public void testGetActiveBusinessPartners_ReturnsNullIfNoBP() throws Exception {
    List<LocationContactRelationship> locConRels = new ArrayList<LocationContactRelationship>();
    ContactInfo contact = new MockContactInfo("123", new MockLocationContactRelationshipDAO(locConRels), null);
    BusinessPartner bp = contact.getActiveBusinessPartner();
    assertNull(bp);
  }

  public void testGetActiveBusinessPartners_Returns2BPs() throws Exception {
    List<LocationContactRelationship> locConRels = new ArrayList<LocationContactRelationship>();

    List<BPLocationRelationship> bpLocRels = new ArrayList<BPLocationRelationship>();
    BusinessPartner bp1 = new MockBusinessPartnerImpl("1", "General Motors", "GM", "0000000123", null, null, null, null,
        null);
    bpLocRels.add(new BPLocationRelationshipImpl(null, bp1, null, false, new LocationType(11L, null), null, null));
    Location loc1 = new MockLocationImpl(null, null, new MockBPLocationRelationshipDAO(bpLocRels), null);
    locConRels.add(new MockLocationContactRelationship(null, false, false, null, loc1, new ContactType(11L, "Worker")
    ));

    bpLocRels = new ArrayList<BPLocationRelationship>();
    bpLocRels.add(new BPLocationRelationshipImpl(null, bp1, null, false, new LocationType(11L, null), null, null));

    ContactInfo contact = new MockContactInfo("123", new MockLocationContactRelationshipDAO(locConRels), null);
    BusinessPartner bp = contact.getActiveBusinessPartner();
    assertNotNull(bp);
    assertEquals("1", bp.getPartnerId());
    assertEquals("General Motors", bp.getEntityName());
    assertEquals("GM", bp.getAliasName());
    assertEquals("0000000123", bp.getSapId());
  }

  public void testSetPrimaryLocation_PrimaryExists_ExisitingRelForNewPrimary_ClosesOldRelationshipsCreatesNewOnes() throws Exception {
    List<LocationContactRelationship> allRelationships = new ArrayList<LocationContactRelationship>();
    Location loc1 = new MockLocationImpl(1);
    Location loc2 = new MockLocationImpl(2);
    ContactInfo contact1 = new MockContactInfo("123", null, null);
    ContactInfo contact2 = new MockContactInfo("234", null, null);
    allRelationships.add(new MockLocationContactRelationship("8", true, true, contact1, loc1, new ContactType(11L, "Worker")
    ));
    allRelationships.add(new MockLocationContactRelationship("9", false, false, contact2, loc2, new ContactType(11L, "Worker")
    ));

    ContactInfo contact = new MockContactInfo("123", new MockLocationContactRelationshipDAO(allRelationships), null);
    LocationContactRelationship primaryRel = contact.getPrimaryRelationship();
    assertNotNull(primaryRel);
    assertTrue(loc1.equals(primaryRel.getLocation()));
    assertLocationRelationshipExists(allRelationships, loc1, true, true, true);
    assertLocationRelationshipExists(allRelationships, loc2, false, false, true);

    contact.setPrimaryLocation(loc2, "USERID");
    primaryRel = contact.getPrimaryRelationship();
    assertNotNull(primaryRel);
    assertTrue(loc2.equals(primaryRel.getLocation()));

    assertLocationRelationshipExists(allRelationships, loc1, true, true, false);
    assertLocationRelationshipExists(allRelationships, loc2, false, false, false);
    assertLocationRelationshipExists(allRelationships, loc1, true, false, true);
    assertLocationRelationshipExists(allRelationships, loc2, false, true, true);
 }

  public void testGetCommunications() throws Exception {
    List<Communication> communications = new ArrayList<Communication>();
    communications.add(new CommunicationImpl("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
        null, null, 1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "112", null));
    ContactInfo contact = new MockContactInfo("123", null, new MockCommunicationDAO(communications));
    List<Communication> comms = contact.getCommunications();
    assertEquals(1, comms.size());
  }

  private void assertLocationRelationshipExists(List<LocationContactRelationship> relationships, Location loc,
                                                boolean isContactPrimary, boolean isLocPrimary,
                                                boolean isActive) {
    for (LocationContactRelationship rel : relationships) {
      if (rel.getLocation().getLocationId().equals(loc.getLocationId()) && rel.getIsLocationPrimary() == isLocPrimary &&
          rel.getIsContactPrimary() == isContactPrimary && isActive == (rel.getEndDate() == null)) {
        return;
      }
    }

    fail("Unable to find location: " + loc + " with primary=" + isLocPrimary + " and active=" + isActive);
  }

}
