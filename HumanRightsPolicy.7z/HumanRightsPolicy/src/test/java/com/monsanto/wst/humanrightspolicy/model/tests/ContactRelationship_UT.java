/*
 ContactRelationship_UT was created on May 8, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.ContactRelationship;
import com.monsanto.wst.humanrightspolicy.model.ContactRelationshipImpl;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ContactRelationship_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-22 21:04:05 $
 *
 * @author rrmall
 * @version $Revision: 1.9 $
 */
public class ContactRelationship_UT extends TestCase {
   public void testEquals_True() throws Exception {
    ContactRelationship relationship1 = new ContactRelationshipImpl("111", null, false, false,
        null, null, null, null, null, null);
    ContactRelationship relationship2 = new ContactRelationshipImpl("111", null, false, false,
        null, null, null, null, null, null);
    assertTrue(relationship1.equals(relationship2));
  }

   public void testEquals_FalseWhenDifferentObject() throws Exception {
    ContactRelationship relationship1 = new ContactRelationshipImpl("111", null, false, false,
        null, null, null, null, null, null);
    assertFalse(relationship1.equals("hello"));
  }

  public void testEquals_FalseWhenDifferentObjectIsNull() throws Exception {
    ContactRelationship relationship1 = new ContactRelationshipImpl("111", null, false, false,
        null, null, null, null, null, null);
    //noinspection ObjectEqualsNull
    assertFalse(relationship1.equals(null));
  }

   public void testgetIsPrimaryAsYOrN_N() throws Exception {
    ContactRelationship relationship1 = new ContactRelationshipImpl("111", null, false, false,
        null, null, null, null, null, null);
    assertEquals("N", relationship1.getIsPrimaryAsYOrN());
  }
  
  public void testgetIsPrimaryAsYOrN_Y() throws Exception {
    ContactRelationship relationship1 = new ContactRelationshipImpl("111", null, true, false,
        null, null, null, null, null, null);
    assertEquals("Y", relationship1.getIsPrimaryAsYOrN());
  }

  public void testToXml() throws Exception {
     ContactRelationship relationship1 = new ContactRelationshipImpl("111", null, true, false,
        null, null, null, null, null, null);
    assertEquals("<contact><contactId>111</contactId><isPrimary>Y</isPrimary><name></name><state></state><country></country><region></region><isSap>N</isSap><removeUrl></removeUrl><viewUrl></viewUrl><updatePrimaryFlagUrl></updatePrimaryFlagUrl></contact>", relationship1.toXml());
  }
}