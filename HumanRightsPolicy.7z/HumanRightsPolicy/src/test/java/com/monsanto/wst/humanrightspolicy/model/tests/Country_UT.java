/*
 Country_UT was created on Sep 9, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.assessment.GlobalAssessment;
import com.monsanto.wst.humanrightspolicy.assessment.MockGlobalAssessmentComparator;
import com.monsanto.wst.humanrightspolicy.assessment.Risk;
import com.monsanto.wst.humanrightspolicy.model.Country;
import junit.framework.TestCase;

import java.util.SortedSet;
import java.util.TreeSet;

/**
 * Filename:    $RCSfile: Country_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:23 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class Country_UT extends TestCase {
  public void testOverallRisk_High() throws Exception {
    SortedSet<GlobalAssessment> set = new TreeSet<GlobalAssessment>(new MockGlobalAssessmentComparator());
    set.add(new GlobalAssessment(new Long(11), null, null, Risk.High));
    set.add(new GlobalAssessment(new Long(12), null, null, Risk.Medium));
    set.add(new GlobalAssessment(new Long(13), null, null, Risk.Low));
    set.add(new GlobalAssessment(new Long(14), null, null, Risk.High));
    Country country = new MockHibernateCountry(set);
    assertEquals(Risk.High, country.getOverallRisk());
  }

  public void testOverallRisk_Medium() throws Exception {
    SortedSet<GlobalAssessment> set = new TreeSet<GlobalAssessment>(new MockGlobalAssessmentComparator());
    set.add(new GlobalAssessment(new Long(11), null, null, Risk.Low));
    set.add(new GlobalAssessment(new Long(12), null, null, Risk.Medium));
    set.add(new GlobalAssessment(new Long(13), null, null, Risk.Low));
    set.add(new GlobalAssessment(new Long(14), null, null, Risk.Low));
    Country country = new MockHibernateCountry(set);
    assertEquals(Risk.Medium, country.getOverallRisk());
  }

  public void testOverallRisk_Low() throws Exception {
    SortedSet<GlobalAssessment> set = new TreeSet<GlobalAssessment>(new MockGlobalAssessmentComparator());
    set.add(new GlobalAssessment(new Long(11), null, null, Risk.Low));
    set.add(new GlobalAssessment(new Long(12), null, null, Risk.Low));
    set.add(new GlobalAssessment(new Long(13), null, null, Risk.Low));
    set.add(new GlobalAssessment(new Long(14), null, null, Risk.Low));
    Country country = new MockHibernateCountry(set);
    assertEquals(Risk.Low, country.getOverallRisk());
  }

  private class MockHibernateCountry extends Country {
    private SortedSet<GlobalAssessment> globalAssessmentSortedSet;

    private MockHibernateCountry(SortedSet<GlobalAssessment> globalAssessmentSortedSet) {
      this.globalAssessmentSortedSet = globalAssessmentSortedSet;
    }

    public SortedSet<GlobalAssessment> getGlobalAssessments() {
      return globalAssessmentSortedSet;
    }
  }

}