/*
 HrpType_UT was created on Aug 26, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.HrpType;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: HrpType_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:23 $
 *
 * @author sspati1
 * @version $Revision: 1.2 $
 */
public class HrpType_UT extends TestCase {

  public void testCreate() throws Exception {
    HrpType type = new HrpType(new Long(1), "Internal");
    assertNotNull(type);
    assertEquals(new Long(1), type.getId());
    assertEquals("Internal", type.getValue());
  }
}