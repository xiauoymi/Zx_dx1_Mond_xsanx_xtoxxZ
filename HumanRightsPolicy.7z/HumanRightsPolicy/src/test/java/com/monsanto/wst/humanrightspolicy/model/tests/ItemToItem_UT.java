/*
 ItemToItem was created on Sep 4, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.model.ItemToItem;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ItemToItem_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-19 16:01:23 $
 *
 * @author rrmall
 * @version $Revision: 1.2 $
 */
public class ItemToItem_UT extends TestCase {
  public void testCreateItemToItemObject() throws Exception {
    ItemToItem itemToitem = new ItemToItem(new Long(1), new Action(new Long(2)), new Action(new Long(3)));
    assertNotNull(itemToitem);
    assertEquals(new Long(1), itemToitem.getId());
    assertEquals(new Long(2), itemToitem.getParentItem().getId());
    assertEquals(new Long(3), itemToitem.getChildItem().getId());
  }
}