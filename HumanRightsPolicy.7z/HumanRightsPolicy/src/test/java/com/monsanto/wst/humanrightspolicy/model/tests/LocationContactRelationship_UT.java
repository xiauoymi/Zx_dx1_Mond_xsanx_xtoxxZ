/*
 LocationContactRelationship_UT was created on Feb 19, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.ContactType;
import com.monsanto.wst.humanrightspolicy.model.LocationContactRelationship;
import com.monsanto.wst.humanrightspolicy.model.LocationContactRelationshipImpl;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: LocationContactRelationship_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:22 $
 *
 * @author sspati1
 * @version $Revision: 1.11 $
 */
public class LocationContactRelationship_UT extends TestCase {

  public void testEquals_True() throws Exception {
    LocationContactRelationship relationship1 = new LocationContactRelationshipImpl("123", null, null, false, false, new ContactType(11L, "Worker"),
        null, null
    );
    LocationContactRelationship relationship2 = new LocationContactRelationshipImpl("123", null, null, false, false, new ContactType(11L, "Worker"),
        null, null
    );
    assertTrue(relationship1.equals(relationship2));
  }

  public void testEquals_False() throws Exception {
    LocationContactRelationship relationship1 = new LocationContactRelationshipImpl("123", null, null, false, false, new ContactType(11L, "Worker"),
        null, null
    );
    LocationContactRelationship relationship2 = new LocationContactRelationshipImpl("456", null, null, false, false, new ContactType(11L, "Worker"),
        null, null
    );
    assertFalse(relationship1.equals(relationship2));
  }

  public void testEquals_FalseWhenDifferentObject() throws Exception {
    LocationContactRelationship relationship1 = new LocationContactRelationshipImpl("123", null, null, false, false, new ContactType(11L, "Worker"),
        null, null
    );
    assertFalse(relationship1.equals("test"));
  }

  public void testEquals_FalseWhenOtherObjectIsNull() throws Exception {
    LocationContactRelationship relationship1 = new LocationContactRelationshipImpl("123", null, null, false, false, new ContactType(11L, "Worker"),
        null, null
    );
    //noinspection ObjectEqualsNull
    assertFalse(relationship1.equals(null));
  }

  public void testgetIsContactPrimaryAsYOrN_N() throws Exception {
    LocationContactRelationshipImpl relationship1 = new LocationContactRelationshipImpl("123", null, null, false, false,
        new ContactType(11L, "Worker"), null, null
    );
    assertEquals("N", relationship1.getIsContactPrimaryAsYOrN());
  }

  public void testgetIsContactPrimaryAsYOrN_Y() throws Exception {
    LocationContactRelationshipImpl relationship1 = new LocationContactRelationshipImpl("123", null, null, true, false,
        new ContactType(11L, "Worker"), null, null
    );
    assertEquals("Y", relationship1.getIsContactPrimaryAsYOrN());
  }

  public void testgetIsLocationPrimaryAsYOrN_N() throws Exception {
    LocationContactRelationshipImpl relationship1 = new LocationContactRelationshipImpl("123", null, null, false, false,
        new ContactType(11L, "Worker"), null, null
    );
    assertEquals("N", relationship1.getIsLocationPrimaryAsYOrN());
  }
  
  public void testgetIsLocationPrimaryAsYOrN_Y() throws Exception {
    LocationContactRelationshipImpl relationship1 = new LocationContactRelationshipImpl("123", null, null, true, true,
        new ContactType(11L, "Worker"), null, null
    );
    assertEquals("Y", relationship1.getIsLocationPrimaryAsYOrN());
  }

    

}