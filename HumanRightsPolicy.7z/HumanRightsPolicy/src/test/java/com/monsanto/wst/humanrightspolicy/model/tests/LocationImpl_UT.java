/*
 LocationImpl_UT was created on Feb 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock.MockCommunicationDAO;
import com.monsanto.wst.humanrightspolicy.locationContactRelationship.dao.LocationContactRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.model.*;
import com.monsanto.wst.humanrightspolicy.model.tests.mock.*;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: LocationImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:22 $
 *
 * @author sspati1
 * @version $Revision: 1.25 $
 */
public class LocationImpl_UT extends TestCase {

  public void testGetLocationContactRelationships_NoRelationships() throws Exception {
    LocationContactRelationshipDAO locContactDao = new MockLocationContactRelationshipDAO(new ArrayList<LocationContactRelationship>());
    Location loc = new MockLocationImpl(null, locContactDao, null, null);
    List<LocationContactRelationship> relationships = loc.getActiveLocationContactRelationships();
    assertNotNull(relationships);
    assertEquals(0, relationships.size());
  }

  public void testGetLocationContactRelationships_Returns3Relationships() throws Exception {
    List<LocationContactRelationship> relationships = new ArrayList<LocationContactRelationship>();
    relationships.add(new MockLocationContactRelationship(null, false, false, null, null, null));
    relationships.add(new MockLocationContactRelationship(null, true, false, null, null, null));
    relationships.add(new MockLocationContactRelationship(null, false, false, null, null, null));
    LocationContactRelationshipDAO locContactDao = new MockLocationContactRelationshipDAO(relationships);
    Location loc = new MockLocationImpl(null, locContactDao, null, null);
    relationships = loc.getActiveLocationContactRelationships();
    assertNotNull(relationships);
    assertEquals(3, relationships.size());
  }

  public void testGetBPLocationRelationship_ReturnsNullIfNoBP() throws Exception {
    BPLocationRelationshipDAO bpLocDao = new MockBPLocationRelationshipDAO(new ArrayList<BPLocationRelationship>());
    Location loc = new MockLocationImpl(null, null, bpLocDao, null);
    BPLocationRelationship bpLocRel = loc.getActiveBPLoctationRelationship();
    assertNull(bpLocRel);
 }

  public void testGetBPLocationRelationship_ReturnsARelationship() throws Exception {
    List<BPLocationRelationship> rels = new ArrayList<BPLocationRelationship>();
    BusinessPartner bp1 = new MockBusinessPartnerImpl("12", "ABC FARMS", null, null, null, null, null, null, null);
    rels.add(new MockBPLocationRelationship(true, bp1));
    BPLocationRelationshipDAO bpLocDao = new MockBPLocationRelationshipDAO(rels);
    Location loc = new MockLocationImpl(null, null, bpLocDao, null);
    BPLocationRelationship bpLocRel = loc.getActiveBPLoctationRelationship();
    assertNotNull(bpLocRel);
    BusinessPartner bp = bpLocRel.getBusinessPartner();
    assertEquals("12", bp.getPartnerId());
    assertEquals("ABC FARMS", bp.getEntityName());
 }

  public void testGetPrimaryRelationship_ReturnsNullIfNoPrimary() throws Exception {
    List<LocationContactRelationship> allRelationships = new ArrayList<LocationContactRelationship>();
    ContactInfo contact1 = new MockContactInfo("1", null, null, "N");
    ContactInfo contact2 = new MockContactInfo("2", null, null, "N");
    LocationContactRelationship rel1 = new MockLocationContactRelationship(null, false, true, contact1, null, null
    );
    LocationContactRelationship rel2 = new MockLocationContactRelationship(null, false, true, contact2, null, null
    );
    allRelationships.add(rel1);
    allRelationships.add(rel2);
    Location location = new MockLocationImpl(null, new MockLocationContactRelationshipDAO(allRelationships), null, null);
    LocationContactRelationship primaryRel = location.getPrimaryRelationship();
    assertNull(primaryRel);
  }

  public void testGetPrimaryRelationship_ReturnsARel() throws Exception {
    List<LocationContactRelationship> allRelationships = new ArrayList<LocationContactRelationship>();
    ContactInfo contact1 = new MockContactInfo("1", null, null, "N");
    ContactInfo contact2 = new MockContactInfo("2", null, null, "N");
    LocationContactRelationship rel1 = new MockLocationContactRelationship(null, false, true, contact1, null, null
    );
    LocationContactRelationship rel2 = new MockLocationContactRelationship(null, true, true, contact2, null, null
    );
    allRelationships.add(rel1);
    allRelationships.add(rel2);
    Location location = new MockLocationImpl(null, new MockLocationContactRelationshipDAO(allRelationships), null, null);
    LocationContactRelationship primaryRel = location.getPrimaryRelationship();
    assertNotNull(primaryRel);
    assertTrue(primaryRel.getContact().equals(contact2));
  }

  public void testSetPrimaryContact_PrimaryExists_ExisitingRelForNewPrimary_ClosesOldRels() throws Exception {
    List<LocationContactRelationship> allRelationships = new ArrayList<LocationContactRelationship>();
    ContactInfo contact1 = new MockContactInfo("1", null, null, "N");
    ContactInfo contact2 = new MockContactInfo("2", null, null, "N");
    allRelationships.add(new MockLocationContactRelationship("8", true, true, contact1, new MockLocationImpl(2), new ContactType("1", null)));
    allRelationships.add(new MockLocationContactRelationship("9", false, false, contact2, new MockLocationImpl(1), new ContactType("1", null)));

    Location location = new MockLocationImpl("1", new MockLocationContactRelationshipDAO(allRelationships), null, null);
    location.setPrimaryContact(contact2, "userId");
    assertTrue(location.getPrimaryRelationship().getContact().equals(contact2));

    assertLocationRelationshipExists(allRelationships, contact1, true, true, false);
    assertLocationRelationshipExists(allRelationships, contact2, false, false, false);
    assertLocationRelationshipExists(allRelationships, contact1, false, true, true);
    assertLocationRelationshipExists(allRelationships, contact2, true, false, true);
  }

  public void testGetCommunications() throws Exception {
    List<Communication> communications = new ArrayList<Communication>();
    communications.add(new CommunicationImpl("12", "commName", "comm notes", new Date(), new Date(), null, "Y",
        null, null, 1L, "Letter",
        4L, "New", 2L, "Contact", 3L, "Main", "112", null));
    Location loc = new MockLocationImpl(null, null, null, new MockCommunicationDAO(communications));
    List<Communication> comms = loc.getCommunications();
    assertEquals(1, comms.size());
  }

  private void assertLocationRelationshipExists(List<LocationContactRelationship> relationships, ContactInfo contact,
                                                boolean isContactPrimary, boolean isLocPrimary,
                                                boolean isActive) {
    for (LocationContactRelationship rel : relationships) {
      if (rel.getContact().equals(contact) && rel.getIsLocationPrimary() == isLocPrimary &&
          rel.getIsContactPrimary() == isContactPrimary && isActive == (rel.getEndDate() == null)) {
        return;
      }
    }

    fail("Unable to find contact: " + contact + " with primary=" + isContactPrimary + " and active=" + isActive);
  }
 }