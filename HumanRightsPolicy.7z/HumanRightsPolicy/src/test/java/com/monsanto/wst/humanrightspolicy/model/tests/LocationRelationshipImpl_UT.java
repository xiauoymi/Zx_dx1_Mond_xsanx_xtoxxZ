/*
 LocationRelationshipImpl_UT was created on May 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.LocationRelationship;
import com.monsanto.wst.humanrightspolicy.model.LocationRelationshipImpl;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: LocationRelationshipImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspati1 $    	 On:	$Date: 2008-06-25 18:46:02 $
 *
 * @author rrmall
 * @version $Revision: 1.5 $
 */
public class LocationRelationshipImpl_UT extends TestCase {
  public void testToXml() throws Exception {
    LocationRelationship locRel = new LocationRelationshipImpl("1", true, "000001", false, "Test Location", "MAIN", "testViewURL", "testRemoveURL", "testUpdatePrimaryFlagUrl",
        "NA", "Missouri", "USA");
    assertEquals("<location><locationId>1</locationId><sapId>000001</sapId><isPrimary>Y</isPrimary><locName>Test Location</locName><bpLocRelType>MAIN</bpLocRelType><state>Missouri</state><country>USA</country><region>NA</region><isSap>N</isSap><removeUrl>testRemoveURL</removeUrl><viewUrl>testViewURL</viewUrl><updatePrimaryFlagUrl>testUpdatePrimaryFlagUrl</updatePrimaryFlagUrl></location>", locRel.toXml());
  }
}