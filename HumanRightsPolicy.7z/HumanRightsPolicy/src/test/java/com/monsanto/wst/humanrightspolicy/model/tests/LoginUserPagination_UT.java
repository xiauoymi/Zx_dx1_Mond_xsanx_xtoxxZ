/*
 LoginUserPagination_UT was created on May 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.datasource.Filterable;
import com.monsanto.wst.humanrightspolicy.model.LoginUserPagination;
import com.monsanto.wst.humanrightspolicy.model.LoginUserPaginationImpl;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: LoginUserPagination_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-27 15:11:50 $
 *
 * @author rrmall
 * @version $Revision: 1.6 $
 */
public class LoginUserPagination_UT extends TestCase {
  public void testToXml() throws Exception {
    LoginUserPagination user = new LoginUserPaginationImpl("ABC-USER", "ABCD", "READER", "NALAN", "viewUrl",
        "removeUrl", "addUrl", "commander general", null);
    assertEquals(
        "<user><userName>ABC-USER&lt;br /&gt;commander general</userName><userID>ABCD</userID><role>READER</role><regions>NALAN</regions><addUrl>addUrl</addUrl><viewUrl>viewUrl</viewUrl><removeUrl>removeUrl</removeUrl></user>",
        user.toXml());
  }

  public void testFilter() throws Exception {
    Filterable loginUser = new LoginUserPaginationImpl("t�stId", "t�stId", "READER", "NALAN", "viewUrl", "removeUrl", "addUrl",
        "test Description", null);
    assertTrue(loginUser.filter("t�st"));
    assertFalse(loginUser.filter("no"));
  }
}