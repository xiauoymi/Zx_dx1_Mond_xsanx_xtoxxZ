package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.LoginUser;
import com.monsanto.wst.humanrightspolicy.model.MockUser;
import com.monsanto.wst.humanrightspolicy.model.Role;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA. User: rgeorge Date: Jul 17, 2006 Time: 10:29:06 AM To change this template use File |
 * Settings | File Templates.
 */
public class LoginUser_UT extends TestCase {
  public void testBuildLoggedInUserCheckUserIdAndName() throws Exception {
    LoginUser loginUser = new MockUser(new Long(1), "RGEORGE", "RIJO GEORGE", false, new Role("11", "EDIT"),
        "test Description", "test Email");
    assertEquals("RGEORGE", loginUser.getUserId());
    assertEquals("RIJO GEORGE", loginUser.getUserName());
    assertEquals("11", loginUser.getRole().getRoleId());
    assertEquals("EDIT", loginUser.getRole().getRoleName());
//    assertFalse(loginUser.isAdmin());
    assertTrue(loginUser.isInThisRole("EDIT"));
    assertTrue(loginUser.getHasEditRole());
    assertFalse(loginUser.getHasReadOnlyRole());
  }

  public void testBuildLoggedInUserCheckUserIdNameAndDescription() throws Exception {
    LoginUser loginUser = new MockUser(new Long(1), "RGEORGE", "RIJO GEORGE", false, new Role("11", "EDIT"),
        "test Description", "test Email");
    assertEquals("RGEORGE", loginUser.getUserId());
    assertEquals("RIJO GEORGE", loginUser.getUserName());
    assertEquals("11", loginUser.getRole().getRoleId());
    assertEquals("EDIT", loginUser.getRole().getRoleName());
//    assertFalse(loginUser.isAdmin());
    assertTrue(loginUser.isInThisRole("EDIT"));
    assertTrue(loginUser.getHasEditRole());
    assertEquals("test Description", loginUser.getDescription());
    assertFalse(loginUser.getHasReadOnlyRole());
  }

}
