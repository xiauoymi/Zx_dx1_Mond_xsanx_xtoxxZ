package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.Region;

import java.util.ArrayList;
import java.util.List;
/*
 MockRegion was created on Feb 18, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class MockRegion extends Region {
  private final List<Country> countries;

  public MockRegion(String id, String value) {
    super(id, value);
    countries =  new ArrayList<Country>();
  }

  public MockRegion(String id, String value, List<Country> countries) {
    this(id, value);
    this.countries.addAll(countries);
  }

  public List<Country> getCountries() {
    return countries;
  }

  public void addCountry(Country country) {
    countries.add(country);
  }
}
