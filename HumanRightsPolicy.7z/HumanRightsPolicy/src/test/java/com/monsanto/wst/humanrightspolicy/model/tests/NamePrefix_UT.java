package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.NamePrefix;
import junit.framework.TestCase;

/*
 NamePrefixUT was created on Sep 19, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class NamePrefix_UT extends TestCase {
  public void testNamePrefixHasPrefix() throws Exception {
    String testPrefix = "testing";
    NamePrefix prefix = new NamePrefix(testPrefix);
    assertEquals(testPrefix, prefix.getPrefix());
  }

  public void testDefaultNamePrefixHasBlankPrefix() throws Exception {
    NamePrefix prefix = new NamePrefix();
    assertEquals("", prefix.getPrefix());
  }
}