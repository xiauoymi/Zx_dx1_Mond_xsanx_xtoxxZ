/*
 Privilege_UT was created on Jul 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.Privilege;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: Privilege_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-08-21 16:17:57 $
 *
 * @author rrmall
 * @version $Revision: 1.3 $
 */
public class Privilege_UT extends TestCase {
  public void testCreate_CheckValues() throws Exception {
    Privilege privilege = new Privilege ("1", "TEST");
    assertEquals("1", privilege.getId());
    assertEquals("TEST", privilege.getValue());
  }
}