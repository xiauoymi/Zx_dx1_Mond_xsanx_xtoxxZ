/*
 Role_UT was created on Mar 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests;

import com.monsanto.wst.humanrightspolicy.model.Role;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: Role_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-02-27 19:23:02 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class Role_UT extends TestCase {

  public void testCreate_CheckValues() throws Exception {
    Role role = new Role("1", "ADMIN");
    assertEquals("1", role.getRoleId());
    assertEquals("ADMIN", role.getRoleName());
  }
}