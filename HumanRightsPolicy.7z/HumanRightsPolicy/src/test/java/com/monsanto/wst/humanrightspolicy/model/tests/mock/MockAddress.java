package com.monsanto.wst.humanrightspolicy.model.tests.mock;

import com.monsanto.wst.humanrightspolicy.location.test.MockCountry;
import com.monsanto.wst.humanrightspolicy.model.Address;
import com.monsanto.wst.humanrightspolicy.model.Country;
import com.monsanto.wst.humanrightspolicy.model.Region;
import com.monsanto.wst.humanrightspolicy.model.StateProvince;
import com.monsanto.wst.humanrightspolicy.model.tests.MockRegion;
/*
 MockAddress was created on Mar 17, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class MockAddress extends Address {
  public MockAddress() {
    super("123", "1234 Main", "Apt 101", "St Louis", "63129", new StateProvince("MO", "Missouri"), new MockCountry("US", "United States"), new MockRegion("NA", "North America"));
  }

  public MockAddress(String addressId, String street1, String street2, String city, String zipcode,
                     StateProvince stateModel, Country countryModel, Region regionModel) {
    super(addressId, street1, street2, city, zipcode, stateModel, countryModel, regionModel);
  }
}
