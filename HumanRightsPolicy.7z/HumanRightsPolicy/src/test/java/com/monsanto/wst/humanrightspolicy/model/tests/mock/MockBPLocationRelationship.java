/*
 MockBPLocationRelationship was created on Feb 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests.mock;

import com.monsanto.wst.humanrightspolicy.model.BPLocationRelationship;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.Location;
import com.monsanto.wst.humanrightspolicy.model.LocationType;

import java.util.Date;

/**
 * Filename:    $RCSfile: MockBPLocationRelationship.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $
 * On:	$Date: 2008-10-17 15:36:21 $
 *
 * @author sspati1
 * @version $Revision: 1.15 $
 */
public class MockBPLocationRelationship implements BPLocationRelationship {
  private boolean isPrimary;
  private String bpLocRelId;
  private Location location;
  private LocationType bpLocRelType;
  private final Date endDate = null;
  private BusinessPartner bp;

  public MockBPLocationRelationship() {
  }

  public MockBPLocationRelationship(boolean isPrimary, LocationType bpLocRelType, String bpLocRelId, Location location) {
    this.isPrimary = isPrimary;
    this.bpLocRelType = bpLocRelType;
    this.bpLocRelId = bpLocRelId;
    this.location = location;
  }

  public MockBPLocationRelationship(boolean isPrimary, BusinessPartner bp) {
    this.isPrimary = isPrimary;
    this.bp = bp;
  }

  public BusinessPartner getBusinessPartner() {
//    return new MockBusinessPartnerImpl("1", "test BP", "test alias", "0000001", null, null, null, null, null);
    return this.bp;
  }

  public boolean getIsPrimary() {
    return isPrimary;
  }

  public Date getStartDate() {
    return null;
  }

  public Date getEndDate() {
    return endDate;
  }

  public Location getLocation() {
    return location;
  }

  public void setId(String relId) {
    this.bpLocRelId = relId;
  }

  public LocationType getBpLocRelType() {
    return this.bpLocRelType;
  }

  public String getId() {
    return bpLocRelId;
  }

  public String getBpLocRelId() {
    return bpLocRelId;
  }

  public String toXml() {
    return null;
  }
}