/*
 MockBusinessPartnerDAO was created on Feb 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests.mock;

import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipImpl;
import com.monsanto.wst.humanrightspolicy.model.BPLocationRelationship;
import com.monsanto.wst.humanrightspolicy.model.BusinessPartner;
import com.monsanto.wst.humanrightspolicy.model.Location;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: MockBPLocationRelationshipDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-02 20:12:52 $
*
* @author sspati1
* @version $Revision: 1.14 $
*/
public class MockBPLocationRelationshipDAO implements BPLocationRelationshipDAO {
  private int id = 0;
  private final List<BPLocationRelationship> bpLocRels;

  public MockBPLocationRelationshipDAO(List<BPLocationRelationship> bpLocRels) {
    this.bpLocRels = bpLocRels;
  }

  public List<BPLocationRelationship> getActiveBPLocationRelationshipsForBP(BusinessPartner businessPartner
  ) {
     List<BPLocationRelationship> activeRels = new ArrayList<BPLocationRelationship>();
    for(BPLocationRelationship rel: this.bpLocRels){
      if(rel.getEndDate() == null){
        activeRels.add(rel);
      }
    }
    return activeRels;
  }


  public BPLocationRelationship getActiveBPLocationRelationshipForLocation(Location location) {
    if(this.bpLocRels.isEmpty()){
      return null;
    }else{
      return this.bpLocRels.get(0);
    }
  }

    public void endBPLocRelForLocation(BusinessPartner bp, Location location) {

    }

    public BPLocationRelationship lookupBPLocationRelationshipById(String bpLocRelId  ) {
    for(BPLocationRelationship rel : bpLocRels) {
      if (rel.getId().equals(bpLocRelId)) {
        return rel;
      }
    }
    return null;
  }

  public void endBPLocationRelationship(String bpLocRelId
  ) {
    BPLocationRelationship oldRel = lookupBPLocationRelationshipById(bpLocRelId);
    bpLocRels.remove(oldRel);
    bpLocRels.add(new BPLocationRelationshipImpl(oldRel.getId(), oldRel.getBusinessPartner(), oldRel.getLocation(),
        oldRel.getIsPrimary(), oldRel.getBpLocRelType(), oldRel.getStartDate(), new Date()));
  }

  public void saveBPLocationRelationship(BPLocationRelationship bpLocRel) {
    id++;
    bpLocRel.setId(Integer.toString(id));
    bpLocRels.add(bpLocRel);
  }
}