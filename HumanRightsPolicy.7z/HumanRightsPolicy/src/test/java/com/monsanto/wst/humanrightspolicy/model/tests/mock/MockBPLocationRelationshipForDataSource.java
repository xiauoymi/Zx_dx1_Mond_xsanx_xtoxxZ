/*
 MockBPLocatoinRelationshipForDataSource was created on May 7, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests.mock;

import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipImpl;
import com.monsanto.wst.humanrightspolicy.model.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: MockBPLocationRelationshipForDataSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 19:19:27 $
 *
 * @author rrmall
 * @version $Revision: 1.13 $
 */
public class MockBPLocationRelationshipForDataSource extends BPLocationRelationshipImpl {
  private boolean isPrimary;
  private String bpLocRelId;
  private Location location;
  private Date endDate = null;
  private MockBPLocationRelationshipDAO dao;

   public MockBPLocationRelationshipForDataSource(boolean isPrimary, String bpLocRelId, Location location) {
    this.isPrimary = isPrimary;
    this.bpLocRelId = bpLocRelId;
    this.location = location;
  }

 public MockBPLocationRelationshipForDataSource(
 ) {

   List<BPLocationRelationship> rels = new ArrayList<BPLocationRelationship>();

      List<BPLocationRelationship> bpLocRels = new ArrayList<BPLocationRelationship>();
      Location loc1 = new LocationImpl("1", "Loc 1", null, "0000000011", "N", "1", "United States", "10",
          "Missouri", "20", "NA", "111", "Lindberg", "Blvd", "Saint Louis", "63167");
      Location loc2 = new LocationImpl("2", "Loc 2", null, "0000000022", "N", "1", "United States", "10",
          "Illinois", "20", "NA", "222", "Oak Street", "Apt 11", "Kansas City", "64110");
      bpLocRels.add(new MockBPLocationRelationshipForDataSource(false, "1", loc1));

      bpLocRels.add(new MockBPLocationRelationshipForDataSource(true, "2", loc2));
      BusinessPartner bp1 = new MockBusinessPartnerImpl("1", "General Motors", "GM", "0000000123", null, null, null, new MockBPLocationRelationshipDAO(bpLocRels),
          null, null);
      rels.add(new BPLocationRelationshipImpl("12", bp1, null, false, new LocationType(11L, null), null, null));
    new MockBPLocationRelationshipDAO(bpLocRels); //todo is this needed?
  }

  public BusinessPartner getBusinessPartner() {
    return new MockBusinessPartnerImpl("1","test BP", "test alias", "0000001", null, null, null, null, null, null);
  }
}
