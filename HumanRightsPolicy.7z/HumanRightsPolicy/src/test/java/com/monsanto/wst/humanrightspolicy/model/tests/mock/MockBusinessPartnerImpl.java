/*
 MockBusinessPartnerImpl was created on Feb 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests.mock;

import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerDAO;
import com.monsanto.wst.humanrightspolicy.businessPartner.dao.BusinessPartnerImpl;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.model.Address;

/**
 * Filename:    $RCSfile: MockBusinessPartnerImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-27 15:11:51 $
*
* @author sspati1
* @version $Revision: 1.11 $
*/
public class MockBusinessPartnerImpl extends BusinessPartnerImpl {
  private String bpId;
  private String name;
  private String aliasName;
  private final BusinessPartnerDAO bpDAO;
  private String sapId;
  private final BPLocationRelationshipDAO bpRelDAO;
  private final CommunicationDAO commDAO;
  private String hrpTypesSeparatedByComma;
  private Address address;

  public MockBusinessPartnerImpl(String bpId, String name, String aliasName,
                                 String sapId, String hrpFlag, String active,
                                 BPLocationRelationshipDAO mockBPLocationRelationshipDAO,
                                 CommunicationDAO commDAO, BusinessPartnerDAO bpDAO) {
    super(bpId, sapId, null, name, aliasName, null, active, null, hrpFlag, null);
    this.bpRelDAO = mockBPLocationRelationshipDAO;
    this.commDAO = commDAO;
    this.bpDAO = bpDAO;
  }

  public MockBusinessPartnerImpl(String bpId, String name, String aliasName,
                                 String sapId, String hrpFlag, String active,
                                 Address address,
                                 BPLocationRelationshipDAO mockBPLocationRelationshipDAO,
                                 CommunicationDAO commDAO, BusinessPartnerDAO bpDAO) {
    super(bpId, sapId, null, name, aliasName, active, null, hrpFlag, null, address.getCountryModel().getId(),
        address.getCountryModel().getValue(), address.getStateModel().getId(), address.getStateModel().getValue(),
        address.getRegionModel().getId(), address.getRegionModel().getValue(), address.getAddressId(), address.getStreetAddress1(),
        address.getStreetAddress2(), address.getCity(), address.getZipcode(), null, null, null);
    this.bpRelDAO = mockBPLocationRelationshipDAO;
    this.commDAO = commDAO;
    this.bpDAO = bpDAO;
  }

  protected BPLocationRelationshipDAO getBPLocationRelationshipDAO() {
    return bpRelDAO;
  }

  protected CommunicationDAO getCommunicationDAO() {
    return this.commDAO;
  }

  protected BusinessPartnerDAO getBusinessPartnerDao() {
    return this.bpDAO;
  }

}