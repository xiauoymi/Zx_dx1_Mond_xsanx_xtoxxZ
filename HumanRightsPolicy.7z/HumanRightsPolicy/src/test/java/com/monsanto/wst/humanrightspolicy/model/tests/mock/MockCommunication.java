/*
 MockCommunication was created on Apr 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests.mock;

import com.monsanto.wst.humanrightspolicy.communication.dao.CommActionItemsDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock.MockCommActionItemsDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.tests.mock.MockCommRecipientDAO;
import com.monsanto.wst.humanrightspolicy.model.Action;
import com.monsanto.wst.humanrightspolicy.model.CommRecipient;
import com.monsanto.wst.humanrightspolicy.model.CommRecipientImpl;
import com.monsanto.wst.humanrightspolicy.model.CommunicationImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: MockCommunication.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:21 $
 *
 * @author sspati1
 * @version $Revision: 1.31 $
 */
public class MockCommunication extends CommunicationImpl {
  private final MockCommRecipientDAO commRecipientDao;
  private boolean deleteAllRecipientsCalled;
  private boolean updateDoneFlagForRecipientCalled;
  private boolean updateDoneFlagForAllRecipientsCalled;
  private int numOfRecipientsAdded = 0;
  private CommRecipient commRecipientCriteria;
  private boolean updateDoneFlagForSelectedRecipientsCalled;
  private List<String> selectedRecipientIds;
  private boolean deleteSelectedRecipientsCalled;
  private List<Action> actionItems;
  private int numOfActionItemsAdded;
  private MockCommActionItemsDAO commActionItemDAO;
  private boolean addActionItemCalled;

  public MockCommunication(String id, String name, String notes, Date fromDate, Date toDate, Date dueDate,
                           String active,
                           Long commTypeId, String commTypeValue, Long commStatusId, String commStatusValue,
                           Long recipientTypeId, String recipientTypeValue, Long locationTypeId,
                           String locationTypeValue, String copiedFromCommId, Date dateCompleted) {
    super(id, name, notes, fromDate, toDate, dueDate, active, null, null, commTypeId, commTypeValue, commStatusId, commStatusValue,
        recipientTypeId, recipientTypeValue, locationTypeId, locationTypeValue, copiedFromCommId, dateCompleted);
    List<CommRecipient> recipients = new ArrayList<CommRecipient>();
    recipients.add(new CommRecipientImpl("3", "3", "11", "Y", "person name 3", 11L, "Plant", 12L, "employee",
        "12", "India", "13", "India", "14", "Gujarat", "bp name 3", null, null, "street","street1","testCity","12345",
        null));
    recipients.add(new CommRecipientImpl("4", "4", "11", "N", "person name 4", 12L, "Type 1", 13L, "manager",
        "13", "NA", "14", "United States", "15", "Missouri", "bp name 4", null, null, "streetTest","streetTest1","testCity1","85285",
        null));
    this.commRecipientDao = new MockCommRecipientDAO(null, recipients);

    List<Action> actionItems = new ArrayList<Action>();
    Action actionItem1 = new Action();
    actionItem1.setId(1L);
    actionItems.add(actionItem1);
    this.commActionItemDAO = new MockCommActionItemsDAO(actionItems);
  }

  public CommRecipientDAO getCommRecipientDAO() {
    return this.commRecipientDao;
  }

  public List<CommRecipient> getRecipients() {
    return this.commRecipientDao.lookupRecipientsByCommId(null);
  }

  public List<CommRecipient> getRecipientsByCriteria(CommRecipient criteria) {
    return this.commRecipientDao.lookupRecipientsByCommId(null);
  }

  public List<CommRecipient> getRecipientsNotAssociatedWithThisCommunicationByCriteria(CommRecipient criteria) {
    this.commRecipientCriteria = criteria;
    List<CommRecipient> recipients = new ArrayList<CommRecipient>();
    recipients.add(new CommRecipientImpl("1", null, null, null, "person name 6", 11L, "Plant", 12L, "employee",
        "12", "India", "13", "India", "14", "Gujarat", "bp name 1", null, null, null, null, null, null, null));
    recipients.add(new CommRecipientImpl("2", null, null, null, "person name 5", 12L, "Type 1", 13L, "manager",
        "13", "NA", "14", "United States", "15", "Missouri", "bp name 2", null, null, null, null, null, null, null));
    return recipients;
  }

  public void updateDoneFlagForRecipient(String recipientId, String doneFlag) {
    super.updateDoneFlagForRecipient(recipientId, doneFlag);
    this.updateDoneFlagForRecipientCalled = true;
  }

  public void updateDoneFlagForAllRecipients(String doneFlag) {
    super.updateDoneFlagForAllRecipients(doneFlag);
    this.updateDoneFlagForAllRecipientsCalled = true;
  }

  public void updateDoneFlagForSelectedRecipients(List<String> selectedIds, String doneFlag) {
    super.updateDoneFlagForSelectedRecipients(selectedIds, doneFlag);
    this.updateDoneFlagForSelectedRecipientsCalled = true;
    this.selectedRecipientIds = selectedIds;
  }

  public void deleteAllRecipients() {
    super.deleteAllRecipients();
    this.deleteAllRecipientsCalled = true;
  }

  public void deleteSelectedRecipients(List<String> selectedRecipientIds) {
    super.deleteSelectedRecipients(selectedRecipientIds);
    this.deleteSelectedRecipientsCalled = true;
    this.selectedRecipientIds = selectedRecipientIds;
  }

  public void addRecipient(String recipientId) {
    super.addRecipient(recipientId);
    this.numOfRecipientsAdded++;
  }

  public void addRecipients(List<CommRecipient> recipients) {
    super.addRecipients(recipients);
    this.numOfRecipientsAdded = recipients.size();
  }

  public boolean areAllRecipientsMarkedAsDone() {
    return false;
  }

  public boolean isUpdateDoneFlagForRecipientCalled() {
    return updateDoneFlagForRecipientCalled;
  }

  public boolean isDeleteAllRecipientsCalled() {
    return deleteAllRecipientsCalled;
  }

  public boolean isUpdateDoneFlagForAllRecipientsCalled() {
    return updateDoneFlagForAllRecipientsCalled;
  }

  public int getNumOfRecipientsAdded() {
    return numOfRecipientsAdded;
  }

  public CommRecipient getCommRecipientCriteria() {
    return commRecipientCriteria;
  }

  public boolean isUpdateDoneFlagForSelectedRecipientsCalled() {
    return updateDoneFlagForSelectedRecipientsCalled;
  }

  public List<String> getSelectedRecipientIds() {
    return selectedRecipientIds;
  }

  public boolean isDeleteSelectedRecipientsCalled() {
    return deleteSelectedRecipientsCalled;
  }

  public List<Action> getActionItemsAsList() {
    return getCommActionItemDAO().lookupActionItemsByCommId(null);
  }

  public void addActionItem(String actionID) {
    getCommActionItemDAO().addActionItem(null, actionID);
    numOfActionItemsAdded++;
    addActionItemCalled = true;
  }

  public int getNumOfActionItemsAdded() {
    return numOfActionItemsAdded;
  }

  public CommActionItemsDAO getCommActionItemDAO() {
    return commActionItemDAO;
  }

  public boolean isAddActionItemCalled() {
    return addActionItemCalled;
  }
}