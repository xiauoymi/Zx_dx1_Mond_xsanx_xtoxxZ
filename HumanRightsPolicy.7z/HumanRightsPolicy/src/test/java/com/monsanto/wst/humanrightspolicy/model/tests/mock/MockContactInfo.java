/*
 MockContactInfo was created on Feb 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests.mock;

import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.locationContactRelationship.dao.LocationContactRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.model.ContactInfoImpl;
import com.monsanto.wst.humanrightspolicy.model.LocationContactRelationship;

import java.util.Collections;

/**
 * Filename:    $RCSfile: MockContactInfo.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-29 18:25:20 $
 *
 * @author sspati1
 * @version $Revision: 1.11 $
 */
public class MockContactInfo extends ContactInfoImpl {
  private final LocationContactRelationshipDAO dao;
  private CommunicationDAO commDao;

  public MockContactInfo(String contactId, String namePrefix, String name,
                         String title, String workPhoneNumber, String mobileNumber, String faxNumber,
                         String email, String isSap) {
    super(contactId, namePrefix, name, title, workPhoneNumber, mobileNumber,
        faxNumber, email, isSap);
    dao = new MockLocationContactRelationshipDAO(Collections.<LocationContactRelationship>emptyList());
  }

  public MockContactInfo(String contactId, String contactFirstName,
                         LocationContactRelationshipDAO locContactDao, String isSap) {
    super(contactId, null, contactFirstName, null, null,
        null, null, null, isSap);
    this.dao = locContactDao;
  }

  public MockContactInfo(String contactId, LocationContactRelationshipDAO dao, CommunicationDAO commDao) {
    super(contactId);
    this.dao = dao;
    this.commDao = commDao;
  }

  protected LocationContactRelationshipDAO getLocationContactRelationshipDAO() {
    return dao;
  }

  protected CommunicationDAO getCommunicationDAO() {
    return this.commDao;
  }
}