/*
 MockContactInfoOverridesPrimaryLocation was created on Feb 25, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests.mock;

import com.monsanto.wst.humanrightspolicy.locationContactRelationship.dao.LocationContactRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.model.ContactInfoImpl;
import com.monsanto.wst.humanrightspolicy.model.LocationContactRelationship;

/**
 * Filename:    $RCSfile: MockContactInfoOverridesPrimaryLocation.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-29 18:25:20 $
*
* @author sspati1
* @version $Revision: 1.7 $
*/
public class MockContactInfoOverridesPrimaryLocation extends ContactInfoImpl {
  private LocationContactRelationshipDAO dao;
  private LocationContactRelationship primaryRelationship;

 public MockContactInfoOverridesPrimaryLocation(String contactId, String contactFirstName,
                                                LocationContactRelationship primaryRelationship, String isSap) {
     super(contactId, null, contactFirstName, null, null,
             null, null, null, isSap);
    this.primaryRelationship = primaryRelationship;
  }

  public MockContactInfoOverridesPrimaryLocation(LocationContactRelationshipDAO dao) {
    this.dao = dao;
  }

  public LocationContactRelationship getPrimaryRelationship() {
    return this.primaryRelationship;
  }

  protected LocationContactRelationshipDAO getLocationContactRelationshipDAO() {
    return dao;
  }

}