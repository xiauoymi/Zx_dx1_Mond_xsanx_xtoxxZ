/*
 MockLocationContactRelationship was created on Feb 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests.mock;

import com.monsanto.wst.humanrightspolicy.model.ContactInfo;
import com.monsanto.wst.humanrightspolicy.model.ContactType;
import com.monsanto.wst.humanrightspolicy.model.Location;
import com.monsanto.wst.humanrightspolicy.model.LocationContactRelationship;

import java.util.Date;

/**
 * Filename:    $RCSfile: MockLocationContactRelationship.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-10-17 15:36:21 $
 *
 * @author sspati1
 * @version $Revision: 1.9 $
 */
public class MockLocationContactRelationship implements LocationContactRelationship {
  private String relId;
  private final boolean isContactPrimary;
  private final boolean isLocationPrimary;
  private final ContactInfo contact;
  private final Location location;
  private final ContactType locConRelType;

  public MockLocationContactRelationship(String relId, boolean isContactPrimary, boolean isLocationPrimary,
                                         ContactInfo contact,
                                         Location location, ContactType locConRelType) {
    this.relId = relId;
    this.isContactPrimary = isContactPrimary;
    this.isLocationPrimary = isLocationPrimary;
    this.contact = contact;
    this.location = location;
    this.locConRelType = locConRelType;
  }

  public String getRelId() {
    return relId;
  }

  public void setRelId(String relId) {
    this.relId = relId;
  }

  public Location getLocation() {
    return this.location;
  }

  public ContactInfo getContact() {
    return this.contact;
  }

  public boolean getIsContactPrimary() {
    return this.isContactPrimary;
  }

  public boolean getIsLocationPrimary() {
    return this.isLocationPrimary;
  }

  public ContactType getLocConRelType() {
    return locConRelType;
  }

  public Date getStartDate() {
    return null;
  }

  public Date getEndDate() {
    return null;
  }
}