/*
 MockLocationContactRelationshipDAO was created on Feb 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests.mock;

import com.monsanto.wst.humanrightspolicy.location.service.tests.mock.MockLocation;
import com.monsanto.wst.humanrightspolicy.locationContactRelationship.dao.LocationContactRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.model.ContactInfoImpl;
import com.monsanto.wst.humanrightspolicy.model.ContactType;
import com.monsanto.wst.humanrightspolicy.model.LocationContactRelationship;
import com.monsanto.wst.humanrightspolicy.model.LocationContactRelationshipImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: MockLocationContactRelationshipDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * sspati1 $    	 On:	$Date: 2008-10-17 15:36:21 $
 *
 * @author sspati1
 * @version $Revision: 1.12 $
 */
public class MockLocationContactRelationshipDAO implements LocationContactRelationshipDAO {
  private int id = 0;
  private final List<LocationContactRelationship> locationContactRelationships;

  public MockLocationContactRelationshipDAO(List<LocationContactRelationship> locationContactRelationships) {
    this.locationContactRelationships = locationContactRelationships;
  }

  public void endLocationContactRelationship(String locationId, String contactId){
    LocationContactRelationship oldRel = lookupLocationContactRelationshipById(locationId, contactId);
    locationContactRelationships.remove(oldRel);
    locationContactRelationships.add(new LocationContactRelationshipImpl(oldRel.getRelId(), oldRel.getLocation(),
        oldRel.getContact(), oldRel.getIsContactPrimary(), oldRel.getIsLocationPrimary(), oldRel.getLocConRelType(),
        oldRel.getStartDate(), new Date()));
  }

  public List<LocationContactRelationship> getActiveContactRelationshipsForLocation(String locId) {
    List<LocationContactRelationship> activeRels = new ArrayList<LocationContactRelationship>();
    for (LocationContactRelationship rel : this.locationContactRelationships) {
      if (rel.getEndDate() == null) {
        activeRels.add(rel);
      }
    }
    return activeRels;
  }

  public List<LocationContactRelationship> getActiveLocationRelationshipsForContact(String contactId) {
    List<LocationContactRelationship> activeRels = new ArrayList<LocationContactRelationship>();
    for (LocationContactRelationship rel : this.locationContactRelationships) {
      if (rel.getEndDate() == null) {
        activeRels.add(rel);
      }
    }
    return activeRels;
  }

  public void saveLocationContactRelationship(String locId, String contactId, boolean isContactPrimary,
                                              boolean isLocationPrimary, Date startDate, Date endDate,
                                              Long locConRelTypeId) {
    id++;
    LocationContactRelationship rel = new LocationContactRelationshipImpl(Integer.toString(id),
       new MockLocation(locId, null, null, false, null, null, null, null), new ContactInfoImpl(contactId), isContactPrimary,
        isLocationPrimary,  new ContactType(locConRelTypeId, null), new Date(), null);

    locationContactRelationships.add(rel);
  }

  private LocationContactRelationship lookupLocationContactRelationshipById(String locationId, String contactId) {
    for (LocationContactRelationship rel : locationContactRelationships) {
      if (rel.getLocation().getLocationId().equals(locationId) && rel.getContact().getContactId().equals(contactId)) {
        return rel;
      }
    }
    return null;

  }
}