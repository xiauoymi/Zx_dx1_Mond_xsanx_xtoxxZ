/*
 MockLocation was created on Feb 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.model.tests.mock;

import com.monsanto.wst.humanrightspolicy.BPLocationRelationship.dao.BPLocationRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.communication.dao.CommunicationDAO;
import com.monsanto.wst.humanrightspolicy.locationContactRelationship.dao.LocationContactRelationshipDAO;
import com.monsanto.wst.humanrightspolicy.model.LocationImpl;

/**
 * Filename:    $RCSfile: MockLocationImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-27 15:11:51 $
*
* @author sspati1
* @version $Revision: 1.6 $
*/
public class MockLocationImpl extends LocationImpl {
  private LocationContactRelationshipDAO locContactDao;
  private CommunicationDAO commDao;
  private BPLocationRelationshipDAO bpLocDao;

  public MockLocationImpl(int id) {
    super(Integer.toString(id));
  }

  public MockLocationImpl(String id, LocationContactRelationshipDAO locContactDao, BPLocationRelationshipDAO bpLocDao,
                          CommunicationDAO commDao) {
    super(id);
    this.bpLocDao = bpLocDao;
    this.locContactDao = locContactDao;
    this.commDao = commDao;
  }

  public String toString() {
    return "MockLoc:" + getLocationId();
  }

  protected LocationContactRelationshipDAO getLocationContactRelationshipDAO() {
    return locContactDao;
  }

  protected BPLocationRelationshipDAO getBPLocationRelationshipDAO() {
    return bpLocDao;
  }

  protected CommunicationDAO getCommunicationDAO() {
    return this.commDao;
  }
}