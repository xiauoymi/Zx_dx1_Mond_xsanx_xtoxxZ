package com.monsanto.wst.humanrightspolicy.note;

import junit.framework.TestCase;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class Note_UT extends TestCase {
    public void testNoteHasCorrectFields() {
        Long testId = 1L;
        String testSubject = "my test subject";
        String testText = "my test text";
        Note note = new Note(testId, testSubject, testText, null);
        assertEquals(testId, note.getId());
        assertEquals(testSubject, note.getSubject());
        assertEquals(testText, note.getText());
        //todo need to test for note target also
    }
}