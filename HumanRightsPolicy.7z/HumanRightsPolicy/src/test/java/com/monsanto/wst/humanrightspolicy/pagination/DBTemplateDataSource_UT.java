package com.monsanto.wst.humanrightspolicy.pagination;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;
import com.monsanto.wst.humanrightspolicy.datasource.DataSource;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/*
 DBTemplateDataSource_UT was created on Apr 16, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class DBTemplateDataSource_UT extends TestCase {
  public void testDataSourceIsCalledAtLeastOnce() throws Exception {
    MockDBTemplate dbTemplate = new MockDBTemplate();
    String testQuery1 = "query1";
    String testQuery2 = "query2";
    DataSource<?> source = new DBTemplateDataSource<Object>(dbTemplate, testQuery1);
    source.getData();
    assertTrue(dbTemplate.wasStatementNameCalled(testQuery1));

    DataSource<?> source2 = new DBTemplateDataSource<Object>(dbTemplate, testQuery2, new Integer(3));
    source2.getData();
    assertTrue(dbTemplate.wasStatementNameCalled(testQuery2));
  }

  public void testDataSourceReturnsListFromDBTemplate() throws Exception {
    List<String> list1 = new ArrayList<String>();
    List<String> list2 = new ArrayList<String>();
    list1.add("test1");
    list2.add("test2");

    MockDBTemplate dbTemplate = new MockDBTemplateForLists(list1, list2);

    DataSource<String> source1 = new DBTemplateDataSource<String>(dbTemplate, "test1");
    assertEquals(list1, source1.getData());

    DataSource<String> source2 = new DBTemplateDataSource<String>(dbTemplate, "test2", new Integer(3));
    assertEquals(list2, source2.getData());

    assertNotNull(source2.getComparator(null));
  }

}