package com.monsanto.wst.humanrightspolicy.pagination;

import junit.framework.TestCase;

/*
 DefaultComparator_UT was created on May 2, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class DefaultComparator_UT extends TestCase {
  private static final int TEST_VALUE = 1234;
  public void testComparableUsesItsOwnCompare() throws Exception {
    DefaultComparator<Object> comp = new DefaultComparator<Object>();
    new MockComparableClass();
    Object myObj2 = new MockComparableClass();

    assertEquals(TEST_VALUE, comp.compare(myObj2, myObj2));
  }

  public void testNonComparatorReturnsZero() throws Exception {
    DefaultComparator<Object> comp = new DefaultComparator<Object>();
    new MockClass();
    Object myObj2 = new MockClass();

    assertEquals(0, comp.compare(myObj2, myObj2));
  }

  private static class MockComparableClass implements Comparable<Object> {
    public int compareTo(Object o) {
      return TEST_VALUE;
    }
  }

  @SuppressWarnings({"EmptyClass"})
  private static class MockClass {
  }
}