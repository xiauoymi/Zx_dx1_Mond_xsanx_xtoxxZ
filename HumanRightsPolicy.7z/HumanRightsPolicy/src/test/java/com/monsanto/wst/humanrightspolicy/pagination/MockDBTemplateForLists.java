package com.monsanto.wst.humanrightspolicy.pagination;

import com.monsanto.wst.dbtemplate.test.mock.MockDBTemplate;

import java.util.List;
/*
 MockDBTemplateForLists was created on Apr 16, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
*/
public class MockDBTemplateForLists extends MockDBTemplate {
  private final List<String> list1;
  private final List<String> list2;

  public MockDBTemplateForLists(List<String> list1, List<String> list2) {
    this.list1 = list1;
    this.list2 = list2;
  }

  public List executeListResultQuery(String s) {
    return list1;
  }

  public List executeListResultQuery(String s, Object o) {
    return list2;
  }
}
