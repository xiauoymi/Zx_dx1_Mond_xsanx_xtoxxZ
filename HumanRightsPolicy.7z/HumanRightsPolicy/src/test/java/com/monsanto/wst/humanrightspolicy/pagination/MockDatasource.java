package com.monsanto.wst.humanrightspolicy.pagination;

import com.monsanto.wst.humanrightspolicy.datasource.DataSource;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
/*
 MockDatasource was created on Apr 16, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */
public class MockDatasource implements DataSource<Integer> {
  private final List<Integer> intList;
  private boolean wasGetComparatorCalled = false;

  public MockDatasource(int numRecords) {
    intList = new ArrayList<Integer>(numRecords);
    for (int i = 0; i < numRecords; i++) {
      intList.add(new Integer(i));
    }
  }

  public List<Integer> getData() {
    return intList;
  }

  public boolean wasGetComparatorCalled() {
    return wasGetComparatorCalled;
  }

  public Comparator<Integer> getComparator(String sortName) {
    wasGetComparatorCalled = true;
    return new Comparator<Integer>() {
      public int compare(Integer o1, Integer o2) {
        return 0;
      }
    };
  }

  public boolean isSorted() {
    return false;
  }

  public boolean isFiltered() {
    return false;
  }

  public int getTotalRecords() {
    return DataSource.UNKNOWN_RECORD_COUNT;
  }}
