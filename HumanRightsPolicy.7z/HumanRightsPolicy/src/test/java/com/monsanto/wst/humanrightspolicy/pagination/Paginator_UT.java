package com.monsanto.wst.humanrightspolicy.pagination;

import com.monsanto.wst.humanrightspolicy.datasource.DataSource;
import junit.framework.TestCase;

import java.util.List;

/*
 Paginator_UT was created on Apr 16, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class Paginator_UT extends TestCase {
  public void testNoResults() throws Exception {
    DataSource<Integer> mockSource = new MockDatasource(0);
    Paginator<Integer> paginator = new Paginator<Integer>(mockSource);
    assertEquals(0, paginator.getRecords(0, 10).getNumRecords());
    assertTrue(paginator.getRecords(0, 10).getData().isEmpty());
    assertTrue(paginator.getRecords(10, 10).getData().isEmpty());
    assertTrue(paginator.getRecords(20, 10).getData().isEmpty());
  }

  public void testPageResults() throws Exception {
    DataSource<Integer> mockSource = new MockDatasource(1000);
    Paginator<Integer> paginator = new Paginator<Integer>(mockSource);
    assertEquals(1000, paginator.getNumRecords());
    assertEquals(1000, paginator.getRecords(0, 10).getNumRecords());
    assertListMatchesRange(paginator.getRecords(0, 10).getData(), 0, 9);
    assertListMatchesRange(paginator.getRecords(10, 10).getData(), 10, 19);
    assertListMatchesRange(paginator.getRecords(10, 5).getData(), 10, 14);
    assertListMatchesRange(paginator.getRecords(998, 5).getData(), 998, 999);
    assertListMatchesRange(paginator.getRecords(0).getData(), 0, 999);
    assertTrue(paginator.getRecords(9999).getData().isEmpty());
    assertTrue(paginator.getRecords(9999, 10).getData().isEmpty());
  }

  public void testGetData() throws Exception {
    DataSource<Integer> mockSource = new MockDatasource(1000);
    DataSource<Integer> paginator = new Paginator<Integer>(mockSource);
    assertEquals(mockSource.getData(), paginator.getData());
  }

  public void testGetComparatorIsPassedThru() throws Exception {
    MockDatasource mockSource = new MockDatasource(1000);
    DataSource<Integer> paginator = new Paginator<Integer>(mockSource);
    paginator.getComparator("foo");
    assertTrue(mockSource.wasGetComparatorCalled());
  }

  private void assertListMatchesRange(List<? extends Integer> data, int startValue, int endValue) {
    int expectedValue = startValue;
    int offset;
    if (startValue <= endValue) {
      offset = 1;
    } else {
      offset = -1;
    }

    for (Integer value : data) {
      assertEquals(expectedValue, value.intValue());
      expectedValue += offset;
    }

    assertEquals("Array ended before expected", endValue, expectedValue - offset);
  }
}