package com.monsanto.wst.humanrightspolicy.pos;

import com.monsanto.XMLUtil.DOMUtil;
import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.Map;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class DataRequestParserImpl_UT extends TestCase {
    private final String TEST_SOURCE = "com.monsanto.something";
    private final int TEST_START_INDEX = 1234;
    private final int TEST_ROWS_PER_PAGE = 34;
    private final String TEST_SORT = "abc";
    private final String TEST_SORT_DIR = DataRequest.DESCENDING_SORT;
    private final String TEST_FILTER = "foo";
    private final String TEST_ADDITIONAL_FIELD_NAME_1 = "myfield1";
    private final String TEST_ADDITIONAL_FIELD_NAME_2 = "myfield2";
    private final String TEST_ADDITIONAL_FIELD_VALUE_1 = "myfield1Value";
    private final String TEST_ADDITIONAL_FIELD_VALUE_2 = "myfield2Value";

    public void testRequestDocumentIsParserCorrectlyForBasicParameters() throws IOException {
        Document requestDoc = getTestDocument();
        DataRequestParser parser = new DataRequestParserImpl();
        DataRequest request = parser.parse(requestDoc);
        assertNotNull(request);
        assertEquals(TEST_SOURCE, request.getDataSource());
        assertEquals(TEST_START_INDEX, request.getStartIndex());
        assertEquals(TEST_ROWS_PER_PAGE, request.getRowsPerPage());
        assertEquals(TEST_SORT, request.getSort());
        assertEquals(TEST_SORT_DIR, request.getSortDir());
        assertTrue(request.isReverseSort());
        assertEquals(TEST_FILTER, request.getFilterValue());
    }

    public void testRequestDocumentIsParseCorrectlyForAdditionalParameters() throws IOException {
        Document requestDoc = getTestDocument();
        DataRequestParser parser = new DataRequestParserImpl();
        DataRequest request = parser.parse(requestDoc);
        assertNotNull(request);
        Map<String, String> parameters = request.getParameters();
        assertNotNull(parameters);
        assertEquals(TEST_ADDITIONAL_FIELD_VALUE_1, parameters.get(TEST_ADDITIONAL_FIELD_NAME_1));
        assertEquals(TEST_ADDITIONAL_FIELD_VALUE_2, parameters.get(TEST_ADDITIONAL_FIELD_NAME_2));
    }

    private Document getTestDocument() {
        Document doc = DOMUtil.newDocumentNS();
        Element inputElem = DOMUtil.addChildElementWithNS("http://www.monsanto.com/pos", doc, POSConstants.INPUT_POS_ELEMENT);
        Element commandElem = DOMUtil.addChildElement(inputElem, POSConstants.COMMAND_ELEMENT);
        Element queryElem = DOMUtil.addChildElement(commandElem, POSConstants.QUERY_ELEMENT);
        DOMUtil.addChildElement(queryElem, POSConstants.DATA_SOURCE_CLASSNAME, TEST_SOURCE);
        DOMUtil.addChildElement(queryElem, POSConstants.START_INDEX, Integer.toString(TEST_START_INDEX));
        DOMUtil.addChildElement(queryElem, POSConstants.ROWS_PER_PAGE, Integer.toString(TEST_ROWS_PER_PAGE));
        DOMUtil.addChildElement(queryElem, POSConstants.SORT, TEST_SORT);
        DOMUtil.addChildElement(queryElem, POSConstants.SORT_DIRECTION, TEST_SORT_DIR);
        DOMUtil.addChildElement(queryElem, POSConstants.FILTER_VALUE, TEST_FILTER);
        DOMUtil.addChildElement(queryElem, TEST_ADDITIONAL_FIELD_NAME_1, TEST_ADDITIONAL_FIELD_VALUE_1);
        DOMUtil.addChildElement(queryElem, TEST_ADDITIONAL_FIELD_NAME_2, TEST_ADDITIONAL_FIELD_VALUE_2);

        return doc;
    }
}