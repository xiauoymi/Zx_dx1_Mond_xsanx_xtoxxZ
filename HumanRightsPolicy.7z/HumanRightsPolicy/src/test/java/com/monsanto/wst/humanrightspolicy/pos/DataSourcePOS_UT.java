package com.monsanto.wst.humanrightspolicy.pos;

import com.monsanto.POSServlet.POSServerException;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.humanrightspolicy.model.XmlObject;
import com.monsanto.wst.humanrightspolicy.pagination.Result;
import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class DataSourcePOS_UT extends TestCase {
    public void testProcessInputCallsProcessRequest() throws POSServerException {
        Document testDoc = DOMUtil.newDocument();
        MockDataSourcePOSForProcessInput pos = new MockDataSourcePOSForProcessInput(testDoc);
        pos.processInput(new MockUCCHelper("MOCK"), "somefile");
        assertEquals(testDoc, pos.getDocumentPassedToProcessRequest());
    }

    //todo this was originally moved from XmlDataPaginationController, need to write tests here for:
    //todo processRequest
    //todo getDataRequest
    //todo getResults
    //todo outputResults

    private static class MockDataSourcePOSForProcessInput extends MockDataSourcePOSForVisiblity {
        private final Document doc;
        private Document documentPassedToProcessRequest = null;

        public MockDataSourcePOSForProcessInput(Document doc) {
            this.doc = doc;
        }

        protected Document readRequestDocumentFromFile(String inputFilePath) throws IOException, SAXException {
            return doc;
        }

        protected void processRequest(UCCHelper helper, Document requestDoc) throws IOException {
            documentPassedToProcessRequest = requestDoc;
        }

        public Document getDocumentPassedToProcessRequest() {
            return documentPassedToProcessRequest;
        }
    }

    private static class MockDataSourcePOSForVisiblity extends DataSourcePOS {
        protected void processInput(UCCHelper helper, String inputFilePath) throws POSServerException {
            super.processInput(helper, inputFilePath);
        }

        protected Document readRequestDocumentFromFile(String inputFilePath) throws IOException, SAXException {
            return super.readRequestDocumentFromFile(inputFilePath);
        }

        protected void processRequest(UCCHelper helper, Document requestDoc) throws IOException {
            super.processRequest(helper, requestDoc);
        }

        protected DataRequest getDataRequest(Document requestDoc) throws IOException {
            return super.getDataRequest(requestDoc);
        }

        protected Result<? extends XmlObject> getResultsForRequest(UCCHelper helper, DataRequest request) throws IOException {
            return super.getResultsForRequest(helper, request);
        }

        protected void outputResults(UCCHelper helper, DataRequest request, Result<? extends XmlObject> results) throws IOException {
            super.outputResults(helper, request, results);
        }
    }
}