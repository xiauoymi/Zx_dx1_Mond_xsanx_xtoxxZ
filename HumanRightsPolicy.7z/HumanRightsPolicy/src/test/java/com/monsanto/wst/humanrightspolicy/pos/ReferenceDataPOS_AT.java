package com.monsanto.wst.humanrightspolicy.pos;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.hibernate.HibernateFactory;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ReferenceDataPOS_AT extends XMLTestCase {
    private ReferenceDataPOS pos;
    private MockUCCHelper helper;
    private HibernateFactory hibernate;

    protected void setUp() throws Exception {
        super.setUp();
        pos = new ReferenceDataPOS();
        helper = new MockUCCHelper("MOCK");
        hibernate = InitService.initHibernate();
        hibernate.beginTransaction();
    }

    protected void tearDown() throws Exception {
        hibernate.rollbackTransaction();
        super.tearDown();
    }

    public void testRegionQueryReturnsCorrectValues() throws Exception {
        File inputFile = getTestFile(ReferenceDataPOS.REGION_VALUE);
        pos.processInput(helper, inputFile.getCanonicalPath());
        Document outputXML = helper.getXML();
        assertXpathExists("/Results/Region/value[text()='North America']", outputXML);
    }

    public void testCountryQueryReturnsCorrectValues() throws Exception {
        File inputFile = getTestFile(ReferenceDataPOS.COUNTRY_VALUE);
        pos.processInput(helper, inputFile.getCanonicalPath());
        Document outputXML = helper.getXML();
        assertXpathExists("/Results/Country/value[text()='India']", outputXML);
    }

    public void testStateQueryReturnsCorrectValues() throws Exception {
        File inputFile = getTestFile(ReferenceDataPOS.STATE_VALUE);
        pos.processInput(helper, inputFile.getCanonicalPath());
        Document outputXML = helper.getXML();
        assertXpathExists("/Results/State/value[text()='Missouri']", outputXML);
    }

    public void testLocationTypeQueryReturnsCorrectValues() throws Exception {
        File inputFile = getTestFile(ReferenceDataPOS.BP_LOCATION_TYPE_VALUE);
        pos.processInput(helper, inputFile.getCanonicalPath());
        Document outputXML = helper.getXML();
        assertXpathExists("/Results/LocationType/value[text()='Main']", outputXML);
    }

    public void testContactTypeQueryReturnsCorrectValues() throws Exception {
        File inputFile = getTestFile(ReferenceDataPOS.LOCATION_CONTACT_TYPE_VALUE);
        pos.processInput(helper, inputFile.getCanonicalPath());
        Document outputXML = helper.getXML();
        assertXpathExists("/Results/ContactType/value[text()='Contact']", outputXML);
    }

    public void testBPTypeQueryReturnsCorrectValues() throws Exception {
        File inputFile = getTestFile(ReferenceDataPOS.BP_TYPE_VALUE);
        pos.processInput(helper, inputFile.getCanonicalPath());
        Document outputXML = helper.getXML();
        assertXpathExists("/Results/HrpType/value[text()='Labor']", outputXML);
        assertXpathExists("/Results/HrpType/value[text()='Grower']", outputXML);
        assertXpathExists("/Results/HrpType/value[text()='Other']", outputXML);
    }

    public void testPolicyQueryReturnsCorrectValues() throws Exception {
        File inputFile = getTestFile(ReferenceDataPOS.POLICY_VALUE);
        pos.processInput(helper, inputFile.getCanonicalPath());
        Document outputXML = helper.getXML();
        assertXpathExists("/Results/Policy/value[text()='Child Labor']", outputXML);
        assertXpathExists("/Results/Policy/value[text()='Safety']", outputXML);
    }

    private File getTestFile(String refDataType) throws IOException, TransformerException {
        Document doc = DOMUtil.newDocumentNS();
        Element inputElem = DOMUtil.addChildElementWithNS("http://www.monsanto.com/pos", doc, POSConstants.INPUT_POS_ELEMENT);
        Element commandElem = DOMUtil.addChildElement(inputElem, POSConstants.COMMAND_ELEMENT);
        DOMUtil.addChildElement(commandElem, POSConstants.REF_DATA_ELEMENT, refDataType);

        File tempFile = File.createTempFile("temp", ".xml");
        DOMUtil.writeDocumentToFile(doc, tempFile.getCanonicalPath());
        tempFile.deleteOnExit();

        return tempFile;
    }

}