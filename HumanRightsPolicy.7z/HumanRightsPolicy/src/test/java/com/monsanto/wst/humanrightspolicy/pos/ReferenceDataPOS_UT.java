package com.monsanto.wst.humanrightspolicy.pos;

import com.monsanto.POSServlet.POSServerException;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.hibernate.mock.MockDAO;
import com.monsanto.wst.humanrightspolicy.assessment.Policy;
import com.monsanto.wst.humanrightspolicy.model.*;
import junit.framework.TestCase;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.IOException;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class ReferenceDataPOS_UT extends TestCase {
    // skipping for now: Action Priority (currently: Low, Medium, or High)
    // skipping for now: Status (current values : Open, Closed, In Progress)

    private MockDAO<HrpType, Long> hrpTypeDAO;
    private MockDAO<Policy, Long> policyDAO;
    private MockDAO<ContactType, Long> contactTypeDAO;
    private MockDAO<LocationType, Long> locationTypeDAO;
    private MockDAO<Region, Long> regionDAO;
    private MockDAO<Country, Long> countryDAO;
    private MockDAO<StateProvince, Long> stateDAO;

    protected void setUp() throws Exception {
        super.setUp();
        hrpTypeDAO = new MockDAO<HrpType, Long>();
        policyDAO = new MockDAO<Policy, Long>();
        contactTypeDAO = new MockDAO<ContactType, Long>();
        locationTypeDAO = new MockDAO<LocationType, Long>();
        regionDAO = new MockDAO<Region, Long>();
        countryDAO = new MockDAO<Country, Long>();
        stateDAO = new MockDAO<StateProvince, Long>();
    }

    public void testRegionQueryLooksAtCorrectService() throws Exception {
        Document inputDoc = getTestDocument(ReferenceDataPOS.REGION_VALUE);
        ReferenceDataPOS pos = new MockReferenceDataPOSForProcessInput(inputDoc);
        MockUCCHelper helper = new MockUCCHelper("MOCK");
        pos.processInput(helper, "somefile");
        assertFalse(helper.wasErrorGenerated());
        assertFalse(hrpTypeDAO.wasFindAllCalled());
        assertFalse(policyDAO.wasFindAllCalled());
        assertFalse(contactTypeDAO.wasFindAllCalled());
        assertFalse(locationTypeDAO.wasFindAllCalled());
        assertTrue(regionDAO.wasFindAllCalled());
        assertFalse(countryDAO.wasFindAllCalled());
        assertFalse(stateDAO.wasFindAllCalled());
    }

    public void testCountryQueryLooksAtCorrectService() throws Exception {
        Document inputDoc = getTestDocument(ReferenceDataPOS.COUNTRY_VALUE);
        ReferenceDataPOS pos = new MockReferenceDataPOSForProcessInput(inputDoc);
        MockUCCHelper helper = new MockUCCHelper("MOCK");
        pos.processInput(helper, "somefile");
        assertFalse(helper.wasErrorGenerated());
        assertFalse(hrpTypeDAO.wasFindAllCalled());
        assertFalse(policyDAO.wasFindAllCalled());
        assertFalse(contactTypeDAO.wasFindAllCalled());
        assertFalse(locationTypeDAO.wasFindAllCalled());
        assertFalse(regionDAO.wasFindAllCalled());
        assertTrue(countryDAO.wasFindAllCalled());
        assertFalse(stateDAO.wasFindAllCalled());
    }

    public void testStateQueryLooksAtCorrectService() throws Exception {
        Document inputDoc = getTestDocument(ReferenceDataPOS.STATE_VALUE);
        ReferenceDataPOS pos = new MockReferenceDataPOSForProcessInput(inputDoc);
        MockUCCHelper helper = new MockUCCHelper("MOCK");
        pos.processInput(helper, "somefile");
        assertFalse(helper.wasErrorGenerated());
        assertFalse(hrpTypeDAO.wasFindAllCalled());
        assertFalse(policyDAO.wasFindAllCalled());
        assertFalse(contactTypeDAO.wasFindAllCalled());
        assertFalse(locationTypeDAO.wasFindAllCalled());
        assertFalse(regionDAO.wasFindAllCalled());
        assertFalse(countryDAO.wasFindAllCalled());
        assertTrue(stateDAO.wasFindAllCalled());
    }

    public void testBPLocationTypeQueryLooksAtCorrectService() throws Exception {
        Document inputDoc = getTestDocument(ReferenceDataPOS.BP_LOCATION_TYPE_VALUE);
        ReferenceDataPOS pos = new MockReferenceDataPOSForProcessInput(inputDoc);
        MockUCCHelper helper = new MockUCCHelper("MOCK");
        pos.processInput(helper, "somefile");
        assertFalse(helper.wasErrorGenerated());
        assertFalse(hrpTypeDAO.wasFindAllCalled());
        assertFalse(policyDAO.wasFindAllCalled());
        assertFalse(contactTypeDAO.wasFindAllCalled());
        assertTrue(locationTypeDAO.wasFindAllCalled());
        assertFalse(regionDAO.wasFindAllCalled());
        assertFalse(countryDAO.wasFindAllCalled());
        assertFalse(stateDAO.wasFindAllCalled());
    }

    public void testLocationContactTypeQueryLooksAtCorrectService() throws Exception {
        Document inputDoc = getTestDocument(ReferenceDataPOS.LOCATION_CONTACT_TYPE_VALUE);
        ReferenceDataPOS pos = new MockReferenceDataPOSForProcessInput(inputDoc);
        MockUCCHelper helper = new MockUCCHelper("MOCK");
        pos.processInput(helper, "somefile");
        assertFalse(helper.wasErrorGenerated());
        assertFalse(hrpTypeDAO.wasFindAllCalled());
        assertFalse(policyDAO.wasFindAllCalled());
        assertTrue(contactTypeDAO.wasFindAllCalled());
        assertFalse(locationTypeDAO.wasFindAllCalled());
        assertFalse(regionDAO.wasFindAllCalled());
        assertFalse(countryDAO.wasFindAllCalled());
        assertFalse(stateDAO.wasFindAllCalled());
    }

    public void testBPTypeQueryLooksAtCorrectService() throws POSServerException {
        Document inputDoc = getTestDocument(ReferenceDataPOS.BP_TYPE_VALUE);
        ReferenceDataPOS pos = new MockReferenceDataPOSForProcessInput(inputDoc);
        MockUCCHelper helper = new MockUCCHelper("MOCK");
        pos.processInput(helper, "somefile");
        assertFalse(helper.wasErrorGenerated());
        assertTrue(hrpTypeDAO.wasFindAllCalled());
        assertFalse(policyDAO.wasFindAllCalled());
        assertFalse(contactTypeDAO.wasFindAllCalled());
        assertFalse(locationTypeDAO.wasFindAllCalled());
        assertFalse(regionDAO.wasFindAllCalled());
        assertFalse(countryDAO.wasFindAllCalled());
        assertFalse(stateDAO.wasFindAllCalled());
    }

    public void testPolicyQueryLooksAtCorrectService() throws POSServerException {
        Document inputDoc = getTestDocument(ReferenceDataPOS.POLICY_VALUE);
        ReferenceDataPOS pos = new MockReferenceDataPOSForProcessInput(inputDoc);
        MockUCCHelper helper = new MockUCCHelper("MOCK");
        pos.processInput(helper, "somefile");
        assertFalse(helper.wasErrorGenerated());
        assertFalse(hrpTypeDAO.wasFindAllCalled());
        assertTrue(policyDAO.wasFindAllCalled());
        assertFalse(contactTypeDAO.wasFindAllCalled());
        assertFalse(locationTypeDAO.wasFindAllCalled());
        assertFalse(regionDAO.wasFindAllCalled());
        assertFalse(countryDAO.wasFindAllCalled());
        assertFalse(stateDAO.wasFindAllCalled());
    }

    public void testUnknownReferenceDataTypeReturnsError() throws POSServerException {
        Document inputDoc = getTestDocument("somethingUnexpected");
        ReferenceDataPOS pos = new MockReferenceDataPOSForProcessInput(inputDoc);
        MockUCCHelper helper = new MockUCCHelper("MOCK");
        try {
            pos.processInput(helper, "somefile");
            fail("Expected exception not received");
        } catch (RuntimeException IGNORE) {
            // ignore expected exception
        }
    }

    private Document getTestDocument(String refDataType) {
        Document doc = DOMUtil.newDocumentNS();
        Element inputElem = DOMUtil.addChildElementWithNS("http://www.monsanto.com/pos", doc, POSConstants.INPUT_POS_ELEMENT);
        Element commandElem = DOMUtil.addChildElement(inputElem, POSConstants.COMMAND_ELEMENT);
        DOMUtil.addChildElement(commandElem, POSConstants.REF_DATA_ELEMENT, refDataType);
        return doc;
    }

    private class MockReferenceDataPOSForProcessInput extends ReferenceDataPOS {
        private final Document inputDoc;

        public MockReferenceDataPOSForProcessInput(Document inputDoc) {
            super(hrpTypeDAO, policyDAO, contactTypeDAO, locationTypeDAO,
                    regionDAO, countryDAO, stateDAO);
            this.inputDoc = inputDoc;
        }

        protected void processInput(UCCHelper helper, String inputFilePath) throws POSServerException {
            try {
                processInputDocument(helper, inputDoc);
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (ParserException e) {
                throw new RuntimeException(e);
            }
        }
    }
}