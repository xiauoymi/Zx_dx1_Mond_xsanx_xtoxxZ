/*
 HrpUtil_UT was created on Oct 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.utils.tests;

import com.monsanto.wst.humanrightspolicy.utils.DateUtil;
import junit.framework.TestCase;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Filename:    $RCSfile: DateUtil_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrmall $    	 On:	$Date: 2008-10-17 21:05:12 $
 *
 * @author RRMALL
 * @version $Revision: 1.3 $
 */
public class DateUtil_UT extends TestCase {

  public DateUtil_UT(String name) {
      super(name);
  }

 public void testFormatDate() throws Exception {
     Date testDate = new Date();
     String formattedDate = DateUtil.formatDate(testDate);
     assertNotNull(formattedDate);
     assertEquals(formatDate(testDate), formattedDate);
  }

  public void testFormatDate_DateIsNull_ThrowsException() throws Exception {
     Date testDate = null;
     String formattedDate = DateUtil.formatDate(testDate);
     assertTrue(formattedDate.length() == 0);
  }

  private String formatDate(Date testDate) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    try{
      return sdf.format(testDate);
    } catch (Exception e){
      return "";
    }
  }
}