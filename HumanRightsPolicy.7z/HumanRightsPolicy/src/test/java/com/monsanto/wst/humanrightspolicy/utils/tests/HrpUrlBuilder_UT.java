/*
 HrpUrlBuilder_UT was created on Jul 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.utils.tests;

import com.monsanto.wst.humanrightspolicy.utils.HrpUrlBuilder;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: HrpUrlBuilder_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-09-30 14:51:59 $
 *
 * @author sspati1
 * @version $Revision: 1.1 $
 */
public class HrpUrlBuilder_UT extends TestCase {

  public void testBaseUrls() throws Exception {
    HrpUrlBuilder builder = new HrpUrlBuilder(null);
    assertEquals("/humanrightspolicy/servlet/login?method=home&menu=Home", builder.getBaseHomeUrl());
    assertEquals("/humanrightspolicy/servlet/searchBusinessPartner?method=&menu=bp", builder.getBaseMyBpsUrl());
    assertEquals("/humanrightspolicy/servlet/searchBusinessPartner?method=allBPs", builder.getBaseSearchAllVendorsUrl());
    assertEquals("/humanrightspolicy/servlet/communication?method=&menu=comm", builder.getBaseMyCommunicationsUrl());
    assertEquals("/humanrightspolicy/servlet/businessPartner?method=lookupBP&businessPartnerId=", builder.getBaseViewBpUrl());
    assertEquals("/humanrightspolicy/servlet/location?method=lookupLocation&locationId=", builder.getBaseViewLocationUrl());
    assertEquals("/humanrightspolicy/servlet/maintainUserAccess?menu=displayUsers", builder.getBaseMaintainUsersUrl());
  }
}