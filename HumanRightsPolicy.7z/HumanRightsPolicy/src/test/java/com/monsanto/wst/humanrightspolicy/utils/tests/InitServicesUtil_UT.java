/*
 InitServicesUtil_UT was created on Feb 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.utils.tests;

import com.monsanto.wst.humanrightspolicy.businessPartner.search.LookupBPService;
import com.monsanto.wst.humanrightspolicy.contact.service.ContactService;
import com.monsanto.wst.humanrightspolicy.utils.InitService;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: InitServicesUtil_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: kjjohn2 $    	 On:	$Date: 2008-08-27 15:11:52 $
 *
 * @author sspati1
 * @version $Revision: 1.22 $
 */
public class InitServicesUtil_UT extends TestCase {
  public InitServicesUtil_UT(String name) {
    super(name);
  }

  public void testInitContactService() throws Exception {
    ContactService service = InitService.initContactService();
    assertNotNull(service);
  }

  public void testInitBPSearchService() throws Exception {
    LookupBPService service = InitService.initSearchBPService();
    assertNotNull(service);
  }

}
