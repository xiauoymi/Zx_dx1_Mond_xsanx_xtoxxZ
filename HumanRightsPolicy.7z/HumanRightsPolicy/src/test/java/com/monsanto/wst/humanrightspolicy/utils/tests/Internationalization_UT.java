package com.monsanto.wst.humanrightspolicy.utils.tests;

import com.monsanto.XMLUtil.DOMUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.custommonkey.xmlunit.exceptions.XpathException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.transform.TransformerException;

/*
 Internationalization_UT was created on Apr 8, 2008 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, WST, Monsanto
 */

public class Internationalization_UT extends XMLTestCase {
  private static final String[] TEST_STATES = {"Paysand�", "Itap�a", "�eembuc�", "Caaguaz�", "Los R�os"};

  public void testSpecialCharactersWhenConveringToXMLFromString() throws Exception {
    StringBuffer buf = new StringBuffer("<?xml version='1.0' encoding='UTF-16' ?>\n<doc>\n");
    for (int i = 0; i < TEST_STATES.length; i++) {
      buf.append("<elem id='").append(i).append("'>");
      buf.append(TEST_STATES[i]);
      buf.append("</elem>\n");
    }
    buf.append("</doc>\n");

    Document doc = DOMUtil.stringToXML(buf.toString());
    verifyStatesInDocument(doc);
  }

  public void testSpecialCharactersWhenCreatingDocumentElementByElement() throws Exception {
    Document doc = DOMUtil.newDocument();
    Element docElem = DOMUtil.addChildElement(doc, "doc");
    for (int i = 0; i < TEST_STATES.length; i++) {
      Element elem = DOMUtil.addChildElement(docElem, "elem", TEST_STATES[i]);
      elem.setAttribute("id", Integer.toString(i));
    }

    verifyStatesInDocument(doc);
  }

  private void verifyStatesInDocument(Document doc) throws TransformerException, XpathException {
    assertNotNull(doc);
    assertXpathExists("/doc", doc);
    for (int i = 0; i < TEST_STATES.length; i++) {
      String xpath = "/doc/elem[@id='" + i + "']/text()";
      assertXpathExists(xpath, doc);
      assertXpathEvaluatesTo(TEST_STATES[i], xpath, doc);
    }
  }
}