/*
 MsgAndErrorUtil_UT was created on Mar 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.humanrightspolicy.utils.tests;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.wst.humanrightspolicy.constants.HRPMainConstants;
import com.monsanto.wst.humanrightspolicy.utils.MsgAndErrorUtil;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: MsgAndErrorUtil_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPATI1 $    	 On:	$Date: 2007-08-02 15:41:54 $
 *
 * @author sspati1
 * @version $Revision: 1.5 $
 */
public class MsgAndErrorUtil_UT extends TestCase {
  public MsgAndErrorUtil_UT(String name) {
    super(name);
  }
  protected void setUp() throws Exception {
    TestUtils testUtils = new TestUtils();
    testUtils.setupLogging(HRPMainConstants.APPLICATION_NAME);
    super.setUp();
  }

  public void testAddDataSavedMsg() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    MsgAndErrorUtil.addDataSavedMsgToResponse(helper);

    List list = (List) helper.getRequestAttributeValue(HRPMainConstants.SUCCESS_LIST);
    assertEquals(1, list.size());
    assertEquals("Data Saved Sucessfully", list.get(0));
  }

  public void testAddSuceessMsg() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    MsgAndErrorUtil.addSucessMsgToResponse("100 Business Partners Imported Sucessfully", helper);

    List list = (List) helper.getRequestAttributeValue(HRPMainConstants.SUCCESS_LIST);
    assertEquals(1, list.size());
    assertEquals("100 Business Partners Imported Sucessfully", list.get(0));
  }

  public void testAddDataDeletedMsg() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    MsgAndErrorUtil.addDataDeletedMsgToResponse(helper);

    List list = (List) helper.getRequestAttributeValue(HRPMainConstants.SUCCESS_LIST);
    assertEquals(1, list.size());
    assertEquals("Data Deleted Sucessfully", list.get(0));
  }

  public void testCreateAndSetErrorList() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    List list = MsgAndErrorUtil.createAndSetErrorList(helper);
    List errorList = (List) helper.getRequestAttributeValue(HRPMainConstants.ERROR_LIST);
    assertTrue(list.isEmpty());
    assertTrue(errorList.isEmpty());
  }

  public void testAddExceptionMsgMsg() throws Exception {
    MockUCCHelper helper = new MockUCCHelper(null);
    Logger.enableLogger(Logger.DEBUG_LOG);
    Exception exception = new Exception("test message");
    MsgAndErrorUtil.addExceptionMsgToResponse(exception, helper);
    List list = (List) helper.getRequestAttributeValue(HRPMainConstants.ERROR_LIST);
    assertEquals(1, list.size());
    assertEquals("test message", list.get(0));
    Logger.disableLogger(Logger.DEBUG_LOG);
  }
}