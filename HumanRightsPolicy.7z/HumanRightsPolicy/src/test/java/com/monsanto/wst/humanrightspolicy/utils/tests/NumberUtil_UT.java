package com.monsanto.wst.humanrightspolicy.utils.tests;

import com.monsanto.wst.humanrightspolicy.utils.NumberUtil;
import junit.framework.TestCase;

/**
 * @Author Ken Johnson, EAS, Monsanto -- kjjohn2@monsanto.com
 */
public class NumberUtil_UT extends TestCase {
    public void testStringToLong_NullInput_NullOutput() {
        Long result = NumberUtil.stringToLong(null);
        assertNull(result);
    }

    public void testStringToLong_BlankInput_NullOutput() {
        Long result = NumberUtil.stringToLong("");
        assertNull(result);
    }

    public void testStringToLong_NumericInput_LongOutput() {
        Long result = NumberUtil.stringToLong("1");
        assertNotNull(result);
        assertEquals(1L, (long) result);
    }

    public void testStringToLong_NonNumericInput_Throws() {
        try {
            NumberUtil.stringToLong("ABC");
            fail("expected exception not received");
        } catch (NumberFormatException IGNORE) {
            // ignore expected exception
        }
    }
}