/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.acceptancetest;

import com.monsanto.wst.lawmattermanagementsystem.invoice.controller.InvoiceBatchProcessController;
import com.monsanto.wst.lawmattermanagementsystem.invoice.controller.InvoiceBatchProcessFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.util.DocumentUtil;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import com.monsanto.wst.lawmattermanagementsystem.testutil.CustomFileComparator;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPService;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPServiceImpl;
import com.monsanto.wst.lawmattermanagementsystem.ftp.exception.FTPException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.check.TeamConnectCheckDAO;
import com.monsanto.wst.lawmattermanagementsystem.check.TeamConnectCheckDAOImpl;
import com.monsanto.wst.commonutils.resources.ResourceUtils;
import com.monsanto.Util.FileUtil;
import com.monsanto.Util.FTPConnection;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.XMLUtil.DOMUtil;

import java.io.*;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;

/**
 * Filename:    $RCSfile: InvoiceBatchProcess_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-07-12 14:32:03 $
 *
 * @author rdesai2
 * @version $Revision: 1.23 $
 */
public class InvoiceBatchProcess_AT extends LMMSBaseTestCase {

  private static final String EXPECTED_INVOICE_FILE = "com/monsanto/wst/lawmattermanagementsystem/acceptancetest/expectedfile/clpinv200611132231.txt";
  private static final String EXPECTED_SUMMARY_REPORT = "com/monsanto/wst/lawmattermanagementsystem/acceptancetest/expectedfile/inv_summ_200611132231.txt";
  private static final String EXPECTED_REJECTION_REPORT = "com/monsanto/wst/lawmattermanagementsystem/acceptancetest/expectedfile/rej_rpt_200611132231.txt";
  private static final String EXPECTED_ERROR_REPORT = "com/monsanto/wst/lawmattermanagementsystem/acceptancetest/expectedfile/sap_err_200611132231.txt";

  private static final String DATA_FILE_PROPERTY_LIST = "com/monsanto/wst/lawmattermanagementsystem/acceptancetest/datafile/PropertyList.xml";
  private static final String DATA_FILE_EMAIL_LIST = "com/monsanto/wst/lawmattermanagementsystem/acceptancetest/datafile/SAPNotificationRecipientList.xml";

  private static final String DATA_FILE_UPDATE_SEND_AP_DATE_REQUEST_VALID_INVOICE = "com/monsanto/wst/lawmattermanagementsystem/acceptancetest/datafile/UpdateSendAPDateForValidInvoice.xml";

  private String invoiceFileName = LMMSConstants.FILE_NAME_INVOICE_RFBIBLE_FILE;
  private String summaryReportFileName = LMMSConstants.FILE_NAME_SUMMARY_REPORT_FILE;
  private String rejectionReportFileName = LMMSConstants.FILE_NAME_REJECTION_REPORT_FILE;
  private String errorReportFileName = LMMSConstants.FILE_NAME_ERROR_REPORT_FILE;

  private String propertyList;
  private String emailList;

  private String tempSAPInvoiceFile;

  private String invoiceFile;
  private String summaryReport;
  private String rejectionReport;
  private String errorReport;

  protected void setUp() throws IOException {
    super.setUp();
    initializeFileNames();
    String futureDate = DateUtil.getFutureDate(LMMSConstants.DATE_FORMAT_FOR_UPDATE_INVOICE_TEAMCONNECT_REQUEST);
    updateInvoiceWithAFutureSendAPDate(futureDate);
    configurePropertyListWithFutureDate(futureDate + " 06:00:00");
    copyFile(DATA_FILE_EMAIL_LIST, emailList);
  }

  protected void tearDown() throws Exception {
    deleteFile(tempSAPInvoiceFile);
    deleteFile(propertyList);
    deleteFile(emailList);
    deleteFile(invoiceFile);
    deleteFile(summaryReport);
    deleteFile(rejectionReport);
    deleteFile(errorReport);
    deleteFile(System.getProperty(LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR) + File.separator + LMMSConstants.FILE_NAME_LAST_RUN_INFO_FILE);
    deleteFileFromFTPServer();
    super.tearDown();
  }

  public void testRunInvoiceBatchProcess() throws Exception {
    //todo uncomment after we receive conversion
//    InvoiceBatchProcessController controller = new InvoiceBatchProcessFactoryImpl().getController();
//    assertNotNull(controller);
//    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
//    compareInvoiceFile();
//    compareSummaryReport();
//    compareRejectionReport();
//    compareErrorReport();
  }

  private void copyFile(String originalFile, String newFile) throws IOException {
    FileWriter fileWriter = new FileWriter(newFile);
    fileWriter.write(FileUtil.readFileToString(new ResourceUtils().convertPathToFile(originalFile)));
    fileWriter.flush();
    fileWriter.close();
  }

  private void initializeFileNames() {
    propertyList = System.getProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR) + File.separator + LMMSConstants.FILE_NAME_PROPERTY_LIST_FILE;
    emailList = System.getProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR) + File.separator + LMMSConstants.FILE_NAME_EMAIL_LIST_FILE;
    tempSAPInvoiceFile = System.getProperty(LMMSConstants.SYSTEM_PARAM_TEMP_DIR) + File.separator + "uploadedInvoiceFile.txt";
    invoiceFile = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + invoiceFileName;
    summaryReport = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + summaryReportFileName;
    rejectionReport = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + rejectionReportFileName;
    errorReport = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + errorReportFileName;
  }

  private void compareErrorReport() throws IOException {
    assertTrue(new ErrorReportFileComparator().compareFiles(EXPECTED_ERROR_REPORT, errorReport));
  }

  private void compareRejectionReport() throws IOException {
    assertTrue(new RejectionReportFileComparator().compareFiles(EXPECTED_REJECTION_REPORT, rejectionReport));
  }

  private void compareSummaryReport() throws IOException {
    assertTrue(new SummaryReportFileComparator().compareFiles(EXPECTED_SUMMARY_REPORT, summaryReport));
  }

  private void compareInvoiceFile() throws FTPException, IOException {
    downloadInvoiceFile(tempSAPInvoiceFile);
    assertTrue(new InvoiceFileComparator().compareFiles(EXPECTED_INVOICE_FILE, tempSAPInvoiceFile));
  }

  private void downloadInvoiceFile(String absolutePathToDownloadLocation) throws FTPException {
    FTPService ftpService = new FTPServiceImpl(new ResourceManagerFactoryImpl());
    ftpService.download(invoiceFileName, absolutePathToDownloadLocation, LMMSConstants.FTP_REMOTE_SUB_DIR_INBOUND);
  }

  private void deleteFile(String fileName) {
    File file = new File(fileName);
    if (file.exists()) {
      file.delete();
    }
  }

  private void updateInvoiceWithAFutureSendAPDate(String futureDate) throws IOException {
    TeamConnectCheckDAO teamConnectCheckDAO = new TeamConnectCheckDAOImpl(new HttpClient(), new PostMethod(System.getProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL)));
    teamConnectCheckDAO.callService(getRequestXML(futureDate));
  }

  private Document getRequestXML(String futureDate) throws IOException {
    try {
      Document document = DocumentUtil.transformRequestXML(DATA_FILE_UPDATE_SEND_AP_DATE_REQUEST_VALID_INVOICE, futureDate, "TeamConnectRequest/Invoice/Detail/InSendAPDate", 0);
      DOMUtil.outputXML(document);
      return document;
    } catch (ParserException e) {
      e.printStackTrace();
      throw new IOException();
    } catch (TransformerException e) {
      e.printStackTrace();
      throw new IOException();
    }
  }

  private void configurePropertyListWithFutureDate(String futureDate) throws IOException {
    Document propertListDocument = getTransformedPropertyListXML(futureDate);
    writeToConfigDir(propertListDocument);
  }

  private void writeToConfigDir(Document propertListDocument) throws IOException {
    try {
      DOMUtil.writeDocumentToFile(propertListDocument, propertyList);
    } catch (TransformerException e) {
      e.printStackTrace();
      throw new IOException();
    }
  }

  private Document getTransformedPropertyListXML(String futureDate) throws IOException {
    Document propertListDocument;
    try {
      propertListDocument = DocumentUtil.transformRequestXML(DATA_FILE_PROPERTY_LIST, futureDate, "PropertyList/properties/Property[key='Repost Date']/value", 0);
    } catch (ParserException e) {
      e.printStackTrace();
      throw new IOException();
    } catch (TransformerException e) {
      e.printStackTrace();
      throw new IOException();
    }
    return propertListDocument;
  }

  private void deleteFileFromFTPServer() throws IOException {
    FTPConnection connection = new FTPConnection();
    connection.connect("dxdev", 21);
    connection.login("dxftp_q08_lawinv", "abc123$$");
    connection.changeDirectory("inbound");
    connection.deleteFile(invoiceFileName);
  }

  class InvoiceFileComparator extends CustomFileComparator {

    protected boolean isCharacterToIgnore(int lineNumber, int position) {
      return (lineNumber == 1 && inBetween(position, 6, 12))  //QueueGroupName Part: MMdd + 3 digit Random Number (always Ignore)
              || (lineNumber == 2 && inBetween(position, 94, 118)) //Practise Area (currently inconsistent) //todo...remove this if data is retrieved consistently
              || (lineNumber == 3 && inBetween(position, 323, 350));  //Employee Id (currently inconsistent) //todo...remove this if data is retrieved consistently
    }

  }

  class SummaryReportFileComparator extends CustomFileComparator {

    protected boolean isCharacterToIgnore(int lineNumber, int position) {
      return (lineNumber == 1 && inBetween(position, 64, 79));  //Report Header: Contains Date/Time MM/dd/yyyy HH:ss(always Ignore)
    }

  }

  class RejectionReportFileComparator extends CustomFileComparator {

    protected boolean isCharacterToIgnore(int lineNumber, int position) {
      return (lineNumber == 1 && inBetween(position, 64, 79));  //Report Header: Contains Date/Time MM/dd/yyyy HH:ss(always Ignore)
    }

  }

  class ErrorReportFileComparator extends CustomFileComparator {

    protected boolean isCharacterToIgnore(int lineNumber, int position) {
      return (lineNumber == 5) //Encrypted Dir...will be different on Cruise Control (always ignore)
              || (lineNumber == 9 && inBetween(position, 13, 22));  //Repost Specific Date Header: Contains Future Date (always Ignore)
    }
  }
}