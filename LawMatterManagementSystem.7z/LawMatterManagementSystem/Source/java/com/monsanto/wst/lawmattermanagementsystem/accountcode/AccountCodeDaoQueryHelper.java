/*
 AccountCodeDaoQueryHelper was created on Feb 11, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;

/**
 * Filename:    $RCSfile: AccountCodeDaoQueryHelper.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 17:51:35 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public interface AccountCodeDaoQueryHelper {
  String getQuery(AccountCode accountCode);
}