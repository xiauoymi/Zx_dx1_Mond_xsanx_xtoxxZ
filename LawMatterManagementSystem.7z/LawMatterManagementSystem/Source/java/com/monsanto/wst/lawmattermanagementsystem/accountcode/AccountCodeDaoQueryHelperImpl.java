/*
 AccountCodeDaoQueryHelperImpl was created on Feb 11, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: AccountCodeDaoQueryHelperImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-13 20:30:27 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class AccountCodeDaoQueryHelperImpl implements AccountCodeDaoQueryHelper {

  public String getQuery(AccountCode accountCode) {
    StringBuffer stringBuffer = new StringBuffer();

    appendConditionalClause(stringBuffer, accountCode.getCompanyCode(), "CcCompany");
    appendConditionalClause(stringBuffer, accountCode.getBusinessCode(), "CcSAPBusiness");
    appendConditionalClause(stringBuffer, accountCode.getCostCenter(), "CcCostCenter");
    appendConditionalClause(stringBuffer, accountCode.getCostElement(), "CcCostElement");
    appendConditionalClause(stringBuffer, accountCode.getProfitCenter(), "CcProfitCenter");
    appendConditionalClause(stringBuffer, accountCode.getInternalOrderNumber(), "CcInternalOrderNumber");
    appendConditionalClause(stringBuffer, accountCode.getWorkBreakDownStructure(), "CcWBS");

    if(!StringUtils.isEmpty(accountCode.getSapLinkNumber())){
      stringBuffer.append(" AND CcSAPLinkNo<>'");
      stringBuffer.append(accountCode.getSapLinkNumber());
      stringBuffer.append(".000000000000");
      stringBuffer.append("'");
    }
    return stringBuffer.toString();
  }

  private void appendConditionalClause(StringBuffer stringBuffer, String string, String databaseColumn) {
    if(!StringUtils.isEmpty(string)){
      stringBuffer.append(" AND ").append(databaseColumn).append("='");
      stringBuffer.append(string);
      stringBuffer.append("'");
    }else{
      stringBuffer.append(" AND ").append(databaseColumn).append(" is null");
    }
  }
}