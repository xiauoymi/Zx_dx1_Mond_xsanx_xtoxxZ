/*
 AccountCodeList was created on May 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: AccountCodeList.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-21 13:35:02 $
 *
 * @author VRBETHI
 * @version $Revision: 1.2 $
 */
public class AccountCodeList {
  private List accountCodeList = new ArrayList();

  public void add(AccountCode accountCode) {
    getAccountCodeList().add(accountCode);
  }

  public int size() {
    return getAccountCodeList().size();
  }

  public AccountCode get(int index) {
    return (AccountCode) getAccountCodeList().get(index);
  }

  public List getAccountCodeList() {
    return accountCodeList;
  }
}