/*
 AccountCodeSummaryService was created on May 21, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.check.ChecksProcessingMessage;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationService;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import org.apache.commons.lang.StringUtils;

import java.util.*;

/**
 * Filename:    $RCSfile: AccountCodeSummaryService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2008-11-21 20:39:35 $
 *
 * @author VRBETHI
 * @version $Revision: 1.15 $
 */
public class AccountCodeSummaryService implements ACSummaryService{

  private static Map accountCodeMap;

   static {
     accountCodeMap = new HashMap();
     accountCodeMap.put(LMMSConstants.SAP_ERROR_MSG_BAD_COMPANY_CODE," (bad company)");
     accountCodeMap.put(LMMSConstants.SAP_ERROR_MSG_BAD_BUSINESS_CODE," (bad bus.)");
     accountCodeMap.put(LMMSConstants.SAP_ERROR_MSG_BAD_COST_ELEMENT," (bad ce)");
     accountCodeMap.put(LMMSConstants.SAP_ERROR_MSG_BAD_COMPANY_COST_ELEMENT_COMBINATION," (bad c/ce)");
     accountCodeMap.put(LMMSConstants.SAP_ERROR_MSG_BAD_COMPANY_BUSINESS_COMBINATION," (bad c/b)");
     accountCodeMap.put(LMMSConstants.SAP_ERROR_MSG_BAD_COST_CENTER," (bad cc)");
     accountCodeMap.put(LMMSConstants.SAP_ERROR_MSG_BAD_COST_CENTER_FOR_COMPANY_BUSNESS_COMBINATION," (bad cc/c/b)");
     //todo this needs to be verified
     accountCodeMap.put(LMMSConstants.SAP_ERROR_MSG_INVALID_BALSHEET," (bad cc?)");

  }

  private SAPVerificationService sapVerificationService;
  private int totalValid = 0;
  private int totalStillInvalid = 0;
  private int totalNewInvalid = 0;
  private List changedAccountCodeList = new ArrayList();

  public AccountCodeSummaryService(SAPVerificationService sapVerificationService) {
    this.sapVerificationService = sapVerificationService;
  }

  public void summarizeValidityOfAccountCodes(AccountCode accountCode
  ) throws
      ServiceException {
    boolean resetValue=false;
    String tempCostCenter="";
    if(accountCode.getCostCenter()!=null && (accountCode.getCostCenter().equalsIgnoreCase("BALSHEET")
        || accountCode.getCostCenter().equalsIgnoreCase("NOCENTER") || accountCode.getCostCenter().equalsIgnoreCase("N/A"))){
      tempCostCenter = accountCode.getCostCenter();
      accountCode.setCostCenter("");
      resetValue=true;
    }
    String message = sapVerificationService.validateAccountCode(accountCode, null);
    if(isAccountCodeValid(message)){
      incrementTotalValid();
      String sapComments = accountCode.getSapComments();
      if(StringUtils.isEmpty(sapComments)){
        accountCode.setComment("SAP ACCOUNT CREATED as of: "+ DateUtil.getCurrentDate("MM/dd/yyyy hh:mm"));        
      }
      else if( StringUtils.contains(sapComments,"SAP Code VALID") ){
        accountCode.setComment("SAP Code VALID as of: "+ DateUtil.getCurrentDate("MM/dd/yyyy hh:mm"));
      }
      else if(StringUtils.contains(sapComments,"SAP ACCOUNT RE-OPENED as of")){
//        accountCode.setComment("SAP ACCOUNT RE-OPENED as of: "+ DateUtil.getCurrentDate("MM/dd/yyyy hh:mm"));
      }
      else if(StringUtils.contains(sapComments,"ACCOUNT RE-OPENED as of")){
        accountCode.setComment("SAP "+accountCode.getSapComments());
      }
      else{
        accountCode.setComment("SAP ACCOUNT RE-OPENED as of: "+ DateUtil.getCurrentDate("MM/dd/yyyy hh:mm"));
        changedAccountCodeList.add(accountCode);
      }
      accountCode.setCloseDate("");
      accountCode.setCloseUid("");
      accountCode.setSapFormatValid("YENO_ROOT_YESS");
      accountCode.closeAccount("YENO_ROOT_NOOO");
    }else{
      incrementInvalids(accountCode,message);
      accountCode.setCloseUid("AUTOCLOSE");
      accountCode.closeAccount("YENO_ROOT_YESS");
      //Set Account code closed date only if it is null
      if(accountCode.getCloseDate()==null){
        accountCode.setCloseDate(DateUtil.getCurrentDate("yyyy-MM-dd"));
      }
      accountCode.setSapFormatValid("YENO_ROOT_NOOO");
    }
    if(resetValue){
      accountCode.setCostCenter(tempCostCenter);
    }
  }

  private void incrementTotalValid() {
    totalValid++;
  }

  private void incrementInvalids(AccountCode accountCode, String message) {
    if(isAccountAutoClosed(accountCode)){
      totalStillInvalid++;
    }else{
      totalNewInvalid++;
      String strToAppend = (String) accountCodeMap.get(message);
      accountCode.setComment("ACCOUNT AUTOCLOSED as of: "+ DateUtil.getCurrentDate("MM/dd/yyyy ")+strToAppend);
      changedAccountCodeList.add(accountCode);
    }
  }

  private boolean isAccountAutoClosed(AccountCode accountCode) {
    return StringUtils.contains(accountCode.getSapComments(), "ACCOUNT AUTOCLOSED");
  }

  //todo take care of the null argument passed to validate
  private boolean isAccountCodeValid(String message
  ) throws ServiceException {
    if(message !=null && message.length()==0){
      return true;
    }
    return false;
  }

  ChecksProcessingMessage getSummaryOfAccountCodeProcessing(
  ) {
    ChecksProcessingMessage checksProcessingMessage = new ChecksProcessingMessage();
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("\n");
    stringBuffer.append("Total Accts inspected from MTCSAPMASTER =  ").append(totalValid);
    stringBuffer.append("(Includes all OPEN and previously autoclosed accts)");
    stringBuffer.append("\n");
    stringBuffer.append("Total Accts determined to have gone bad = ").append(totalNewInvalid);
    stringBuffer.append("\n");
    stringBuffer.append("Total Accts determined to    remain bad = ").append(totalStillInvalid);
    checksProcessingMessage.setMessage(stringBuffer.toString());
    return checksProcessingMessage;
  }

  public List getChangedAccountCodeList() {
    return changedAccountCodeList;
  }

  public String getSummaryOfChangedAccountCodes() {
    StringBuffer stringBuffer = new StringBuffer();
    Iterator iterator = changedAccountCodeList.iterator();
    while(iterator.hasNext()){
      AccountCode changedAccountCode = (AccountCode) iterator.next();
      stringBuffer.append(changedAccountCode.getCompanyCode()+"-"+changedAccountCode.getBusinessCode()+"-"+changedAccountCode.getCostElement());
      stringBuffer.append(" ");
      stringBuffer.append(changedAccountCode.getSapLinkNumber());
      stringBuffer.append(" ");
      stringBuffer.append(changedAccountCode.getCostCenter());
      stringBuffer.append(" ");
      stringBuffer.append(changedAccountCode.getSapComments());
      stringBuffer.append("\n");
    }
    return stringBuffer.toString();
  }
}