/*
 AccountCodeVerificationDAO was created on May 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;

/**
 * Filename:    $RCSfile: AccountCodeVerificationDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-18 22:00:15 $
 *
 * @author VRBETHI
 * @version $Revision: 1.11 $S
 */
public interface AccountCodeVerificationDAO {
  AccountCodeList getAccountCodeList();

  AccountCode lookUpAccountCodeForSAPLinkNumber(String sapLinkNumber);

  AccountCodeList lookUpAccountCodesWithValues(AccountCode accountCode,
                                               AccountCodeDaoQueryHelper accountCodeDaoQueryHelper);
}