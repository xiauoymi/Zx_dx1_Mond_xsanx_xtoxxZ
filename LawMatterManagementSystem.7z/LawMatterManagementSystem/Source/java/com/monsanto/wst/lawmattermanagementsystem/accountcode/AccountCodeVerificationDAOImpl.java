/*
 AccountCodeVerificationDAOImpl was created on May 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactory;

/**
 * Filename:    $RCSfile: AccountCodeVerificationDAOImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-09-09 15:46:25 $
 *
 * @author VRBETHI
 * @version $Revision: 1.23 $
 */
public class AccountCodeVerificationDAOImpl implements AccountCodeVerificationDAO {
  private ResourceManagerFactory resourceManagerFactory;
  private final String accountCodeListQuery = "--Autoclose select cost center (MTCSAPMASTER IN LAWPACK)\n" +
      "SELECT     CcSAPLinkNo AS SAP_LINKNO, CcLPCONV_SAP_FORMAT AS SAP_FORMAT, PROJECT_ID, CcAccountName AS ACCOUNT_NAME, \n" +
      "                      CcCAAMAccount AS CAAM_ACCOUNT, CcCAAMSubAccount AS CAAM_SUBACCOUNT, CcCloseDate AS CLOSE_DATE, \n" +
      "                      CcCloseUId AS CLOSE_UID, CcCompany AS SAP_COMPANY, CcCostCenter AS SAP_COST_CENTER, \n" +
      "                      CcCostCenterDesc AS SAP_COST_CENTER_DESC, CcCostCenterManager_VID, CcCostCenterManager_CID, \n" +
      "                      CcCostElement AS SAP_COST_ELEMENT, CcCostElementDesc AS SAP_COST_ELEMENT_DESC, CcEditDate AS EDIT_DATE, \n" +
      "                      CcEditUId AS EDIT_UID, CcInternalOrderNumber AS INTERNAL_ORDERNUMBER, CcWBS AS WORK_BREAKDOWN_ST, CcOpenDate AS OPEN_DATE, \n" +
      "                      CcOpenUId AS OPEN_UID, CcProfitCenter AS SAP_PROFITCENTER, CcSAPBusiness AS SAP_BUSINESS, " +
      "CcSAPComments AS SAP_Comments, " +
      "CcWBS AS SAP_WBS\n" +
      "FROM         PROJ_CAT_3930\n" +
      "WHERE     ((CcCloseDate IS NULL) AND (CcLPCONV_SAP_FORMAT = 'Y')) OR\n" +
      "                      ((SUBSTRING(CcSAPComments, 1, 18) = 'ACCOUNT AUTOCLOSED') OR (CcLPCONV_SAP_FORMAT is null))\n" +
//      "WHERE CcLPCONV_SAP_FORMAT is null " +
      "ORDER BY CcSAPLinkNo";
  private final String accountCodeQueryForSAPLinkNumber="SELECT     CcSAPLinkNo AS SAP_LINKNO, CcLPCONV_SAP_FORMAT AS SAP_FORMAT, PROJECT_ID, CcAccountName AS ACCOUNT_NAME, \n" +
      "                      CcCAAMAccount AS CAAM_ACCOUNT, CcCAAMSubAccount AS CAAM_SUBACCOUNT, CcCloseDate AS CLOSE_DATE, \n" +
      "                      CcCloseUId AS CLOSE_UID, CcCompany AS SAP_COMPANY, CcCostCenter AS SAP_COST_CENTER, \n" +
      "                      CcCostCenterDesc AS SAP_COST_CENTER_DESC, CcCostCenterManager_VID, CcCostCenterManager_CID, \n" +
      "                      CcCostElement AS SAP_COST_ELEMENT, CcCostElementDesc AS SAP_COST_ELEMENT_DESC, CcEditDate AS EDIT_DATE, \n" +
      "                      CcEditUId AS EDIT_UID, CcInternalOrderNumber AS INTERNAL_ORDERNUMBER, CcOpenDate AS OPEN_DATE, \n" +
      "                      CcOpenUId AS OPEN_UID, CcProfitCenter AS SAP_PROFITCENTER, CcSAPBusiness AS SAP_BUSINESS, CcSAPComments AS SAP_Comments, CcWBS AS SAP_WBS\n" +
      "FROM PROJ_CAT_3930\n" +
      "WHERE CcSAPLinkNo=?";

  public AccountCodeVerificationDAOImpl(ResourceManagerFactory resourceManagerFactory) {
    this.resourceManagerFactory = resourceManagerFactory;
  }

  public AccountCodeList getAccountCodeList() {

    AccountCodeList accountCodeList = new AccountCodeList();
    ResourceConnectionManager connectionManager;
    PersistentStoreConnection storeConnection=null;
    try {
      connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
      storeConnection = (PersistentStoreConnection) connectionManager
          .getConnection(LMMSConstants.DATABASE_LAW_TCE);
      String statement = accountCodeListQuery;
      PersistentStoreStatement storeStatement = storeConnection.prepareStatement(statement);
      PersistentStoreResultSet persistentStoreResultSet = storeStatement.executeQuery();
      PersistentStoreResultSetFwdIterator setFwdIterator = persistentStoreResultSet.getForwardIterator();
      while(setFwdIterator.next()){
        String costCenter = setFwdIterator.getString("SAP_COST_CENTER");
        String costElement = setFwdIterator.getString("SAP_COST_ELEMENT");
//        String costElement = setFwdIterator.getString("CAAM_ACCOUNT");
        String business = setFwdIterator.getString("SAP_BUSINESS");
        String company = setFwdIterator.getString("SAP_COMPANY");
        String sapComments = setFwdIterator.getString("SAP_Comments");
        String sapLinkNumber = setFwdIterator.getString("SAP_LINKNO");
        String closeDate = setFwdIterator.getString("CLOSE_DATE");
        String internalOrderNumber = setFwdIterator.getString("INTERNAL_ORDERNUMBER");
        String workBreakDownStructure = setFwdIterator.getString("WORK_BREAKDOWN_ST");
        AccountCode accountCode = new AccountCode(company,business,costElement,costCenter,sapComments, sapLinkNumber,
            null, internalOrderNumber, workBreakDownStructure);
        accountCode.setCloseDate(closeDate);
        if(sapLinkNumber!=null && business !=null && company!=null){
//          System.out.println("sapLinkNumber = " + sapLinkNumber);
//           if(sapLinkNumber.equalsIgnoreCase("1000344.000000000000")|| sapLinkNumber.equalsIgnoreCase("1000379.000000000000"))
            accountCodeList.add(accountCode);
        }
      }
    } catch (ResourceConnectionException e) {
      throw new AccountCodeProcessingException("Exception retrieving account codes",e);
    } catch (WrappingException e) {
      throw new AccountCodeProcessingException("Exception retrieving account codes",e);
    }
    finally{
      PersistencUtil.closeConnection(storeConnection);
    }
    return accountCodeList;
  }

  public AccountCode lookUpAccountCodeForSAPLinkNumber(String sapLinkNumber) {
    AccountCode accountCode = null;
    ResourceConnectionManager connectionManager;
    PersistentStoreConnection storeConnection=null;
    try {
      connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
      storeConnection = (PersistentStoreConnection) connectionManager
          .getConnection(LMMSConstants.DATABASE_LAW_TCE);
      PersistentStoreStatement storeStatement = storeConnection.prepareStatement(accountCodeQueryForSAPLinkNumber);
      storeStatement.setParam(1,new Integer(Double.valueOf(sapLinkNumber).intValue()));
      PersistentStoreResultSet persistentStoreResultSet = storeStatement.executeQuery();
      PersistentStoreResultSetFwdIterator setFwdIterator = persistentStoreResultSet.getForwardIterator();
      while(setFwdIterator.next()){
        String costCenter = setFwdIterator.getString("SAP_COST_CENTER");
        String costElement = setFwdIterator.getString("SAP_COST_ELEMENT");
        String business = setFwdIterator.getString("SAP_BUSINESS");
        String company = setFwdIterator.getString("SAP_COMPANY");
        String sapComments = setFwdIterator.getString("SAP_Comments");
        accountCode = new AccountCode(company,business,costElement,costCenter,sapComments, sapLinkNumber, null, null, null);
      }
    } catch (ResourceConnectionException e) {
      throw new AccountCodeProcessingException("Exception retrieving account codes",e);
    } catch (WrappingException e) {
      throw new AccountCodeProcessingException("Exception retrieving account codes",e);
    }
    finally{
      PersistencUtil.closeConnection(storeConnection);
    }
    return accountCode;

  }

  public AccountCodeList lookUpAccountCodesWithValues(AccountCode accountCode,
                                                      AccountCodeDaoQueryHelper accountCodeDaoQueryHelper) {
    AccountCodeList accountCodeList = new AccountCodeList();
    ResourceConnectionManager connectionManager;
    PersistentStoreConnection storeConnection=null;
    try {
      connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
      storeConnection = (PersistentStoreConnection) connectionManager
          .getConnection(LMMSConstants.DATABASE_LAW_TCE);
      String queryPartOne = "SELECT CcCompany,CcSAPBusiness,CcCostCenter,CcCostElement,CcProfitCenter,CcInternalOrderNumber,CcWBS FROM PROJ_CAT_3930 AC WHERE 1=1";
      String conditionalClause = accountCodeDaoQueryHelper.getQuery(accountCode);
      PersistentStoreStatement storeStatement = storeConnection.prepareStatement(queryPartOne+conditionalClause);
      PersistentStoreResultSet persistentStoreResultSet = storeStatement.executeQuery();
      PersistentStoreResultSetFwdIterator setFwdIterator = persistentStoreResultSet.getForwardIterator();
      while(setFwdIterator.next()){
        String company = setFwdIterator.getString("CcCompany");
        String business = setFwdIterator.getString("CcSAPBusiness");
        String costCenter = setFwdIterator.getString("CcCostCenter");
        String costElement = setFwdIterator.getString("CcCostElement");
        String profitCenter = setFwdIterator.getString("CcProfitCenter");
        String internalOrderNumber = setFwdIterator.getString("CcInternalOrderNumber");
        String workBreakDownStructure = setFwdIterator.getString("CcWBS");
        AccountCode accountCodeOne = new AccountCode(company,business,costElement,costCenter,null, null,
            profitCenter, internalOrderNumber, workBreakDownStructure);
        accountCodeList.add(accountCodeOne);
      }
    } catch (ResourceConnectionException e) {
      throw new AccountCodeProcessingException("Exception retrieving account codes",e);
    } catch (WrappingException e) {
      throw new AccountCodeProcessingException("Exception retrieving account codes",e);
    }
    finally{
      PersistencUtil.closeConnection(storeConnection);
    }
    return accountCodeList;
  }

}