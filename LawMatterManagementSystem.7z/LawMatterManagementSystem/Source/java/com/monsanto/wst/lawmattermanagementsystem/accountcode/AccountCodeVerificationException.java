/*
 AccountCodeVerificationException was created on May 4, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

/**
 * Filename:    $RCSfile: AccountCodeVerificationException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-08 20:14:20 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class AccountCodeVerificationException extends Exception{

  public AccountCodeVerificationException(String message, Throwable cause) {
    super(message, cause);
  }

}