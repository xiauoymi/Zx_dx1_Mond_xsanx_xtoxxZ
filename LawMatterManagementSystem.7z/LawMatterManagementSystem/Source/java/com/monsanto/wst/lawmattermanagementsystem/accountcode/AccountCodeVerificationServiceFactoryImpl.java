/*
 AccountCodeVerificationServiceFactoryImpl was created on Feb 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.invoice.controller.InvoiceBatchProcessFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationServiceImpl;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;

/**
 * Filename:    $RCSfile: AccountCodeVerificationServiceFactoryImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 17:51:35 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class AccountCodeVerificationServiceFactoryImpl implements AccountCodeVerificationServiceFactory {
  public AccountCodeVerificationService getAccountCodeVerificationService() {
    InvoiceBatchProcessFactoryImpl invoiceBatchProcessFactory = new InvoiceBatchProcessFactoryImpl();
    SAPVerificationServiceImpl sapVerificationService = invoiceBatchProcessFactory
        .getSAPVerificationService(new ResourceManagerFactoryImpl());
    AccountCodeVerificationDAO accountCodeVerificationDAO = new AccountCodeVerificationDAOImpl(new ResourceManagerFactoryImpl());
    return new AccountCodeVerificationServiceImpl(sapVerificationService,accountCodeVerificationDAO);
  }
}