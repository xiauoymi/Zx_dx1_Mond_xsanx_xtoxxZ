/*
 AccountCodeVerificationServiceImpl was created on Feb 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationService;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: AccountCodeVerificationServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-13 20:30:27 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class AccountCodeVerificationServiceImpl implements AccountCodeVerificationService {
  private SAPVerificationService sapVerificationService;
  private AccountCodeVerificationDAO accountCodeVerificationDAO;

  public AccountCodeVerificationServiceImpl(SAPVerificationService sapVerificationService,
                                            AccountCodeVerificationDAO accountCodeVerificationDAO) {
    this.sapVerificationService = sapVerificationService;
    this.accountCodeVerificationDAO = accountCodeVerificationDAO;
  }

  public String validateAccountCodes(AccountCode accountCode) throws ServiceException {
    String costCenter=accountCode.getCostCenter();
    setCostCenterToEmptyIfBalanceSheetAccount(accountCode, costCenter);
    String result = sapVerificationService.validateAccountCode(accountCode, null);
    if(isCostCenterValid(result)){
      return checkForDuplicateCostCenters(accountCode, costCenter);
    }else{
      return result;
    }
  }

  private String checkForDuplicateCostCenters(AccountCode accountCode, String tempCostCenter) {
    String resultString = "";
    accountCode.setCostCenter(tempCostCenter);
    AccountCodeList accountCodeList = accountCodeVerificationDAO
        .lookUpAccountCodesWithValues(accountCode, new AccountCodeDaoQueryHelperImpl());
    if (accountCodeList.size() >= 1) {
      resultString = "More than one cost center exists with entered values";
    }
    return resultString;
  }

  private boolean isCostCenterValid(String result) {
    return StringUtils.isEmpty(result);
  }

  private void setCostCenterToEmptyIfBalanceSheetAccount(AccountCode accountCode, String costCenter) {
    if(isCostCenterBalanceSheetAccount(costCenter)){
      accountCode.setCostCenter("");
    }
  }

  private boolean isCostCenterBalanceSheetAccount(String costCenter) {
    return ("BALSHEET".equalsIgnoreCase(costCenter)
          || "NOCENTER".equalsIgnoreCase(costCenter) || "N/A".equalsIgnoreCase(costCenter));
  }

  public String validateAccountCodeOnUpdate(AccountCode accountCode) throws ServiceException {
    return sapVerificationService.validateAccountCode(accountCode, null);
  }
}