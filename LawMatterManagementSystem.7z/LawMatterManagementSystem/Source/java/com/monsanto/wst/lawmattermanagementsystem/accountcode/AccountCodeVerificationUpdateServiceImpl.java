/*
 AccountCodeVerificationUpdateServiceImpl was created on May 21, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.lawmattermanagementsystem.check.*;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: AccountCodeVerificationUpdateServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 16:11:34 $
 *
 * @author VRBETHI
 * @version $Revision: 1.5 $
 */
public class AccountCodeVerificationUpdateServiceImpl implements AccountCodeVerificationUpdateService {
  private XMLBuilder xmlBuilder;
  private TeamConnectCheckDAO teamConnectCheckDAO;
  private ResultsProcessor resultsProcessor;
  private ErrorHandler errorHandler;

  public AccountCodeVerificationUpdateServiceImpl(XMLBuilder xmlBuilder, TeamConnectCheckDAO teamConnectCheckDAO,
                                                  ResultsProcessor resultsProcessor, ErrorHandler errorHandler) {
    this.xmlBuilder = xmlBuilder;
    this.teamConnectCheckDAO = teamConnectCheckDAO;
    this.resultsProcessor = resultsProcessor;
    this.errorHandler = errorHandler;
  }

  public boolean updateAccountCodeInTeamConnect(AccountCode code) {
    Document document = xmlBuilder.buildUpdateAccountCodeXML(code);
    DOMUtil.outputXML(document);
    Document outputDocument = teamConnectCheckDAO.callService(document);
    return resultsProcessor.processResult(outputDocument);
  }

  public boolean updateAccountEditCodeInTeamConnect(AccountCode code) {
    Document document = xmlBuilder.buildEditAccountCodeUpdateAccountCodeXML(code,null, DateUtil.getCurrentDate("MM/dd/yyyy"));
    DOMUtil.outputXML(document);
    Document outputDocument = teamConnectCheckDAO.callService(document);
    return resultsProcessor.processResult(outputDocument);
  }

  public boolean updateAccountNewCodeInTeamConnect(AccountCode code) {
    Document document = xmlBuilder.buildOpenAccountCodeUpdateAccountCodeXML(code,null,null);
    DOMUtil.outputXML(document);
    Document outputDocument = teamConnectCheckDAO.callService(document);
    return resultsProcessor.processResult(outputDocument);
  }

  public void updateAccountCodes(AccountCodeList accountCodeList) throws ServiceException {
    for (int i=0;i<accountCodeList.size();i++) {
      AccountCode code = accountCodeList.get(i);
//      if(StringUtils.contains(code.getSapLinkNumber(), "1000344")){
      boolean resultFromTeamConnect = updateAccountCodeInTeamConnect(code);
        if(!resultFromTeamConnect){
        ChecksProcessingMessage checksProcessingMessage = new ChecksProcessingMessage();
          checksProcessingMessage.setMessage("Error");
          errorHandler.handleError(checksProcessingMessage);
        }
//      }
    }
  }
}