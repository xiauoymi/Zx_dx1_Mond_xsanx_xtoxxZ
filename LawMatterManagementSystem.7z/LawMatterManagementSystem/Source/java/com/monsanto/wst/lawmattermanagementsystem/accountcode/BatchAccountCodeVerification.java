/*
 BatchAccountCodeVerification was created on May 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;

/**
 * Filename:    $RCSfile: BatchAccountCodeVerification.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 16:11:34 $
 *
 * @author VRBETHI
 * @version $Revision: 1.7 $
 */
public interface BatchAccountCodeVerification {
  public void verifyAccountCodes() throws ServiceException;

  void printClosedInvoices() throws ServiceException;

  boolean verifyAccountCode(AccountCode accountCode) throws ServiceException;
}