/*
 BatchAccountCodeVerificationFactoryImpl was created on May 25, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.check.*;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationServiceFactory;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationServiceFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.JavaMailEmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.MailDocumentFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.mail.util.dom.XMLEmailBuilderDOMImpl;

/**
 * Filename:    $RCSfile: BatchAccountCodeVerificationFactoryImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-09-09 15:46:28 $
 *
 * @author VRBETHI
 * @version $Revision: 1.8 $
 */
public class BatchAccountCodeVerificationFactoryImpl implements BatchAccountCodeVerificationFactory {
    public BatchAccountCodeVerification getBatchAccountCodeVerificationInstance(
            ErrorHandlerImpl handler) throws ServiceException {

        SAPVerificationServiceFactory sapVerificationServiceFactory = new SAPVerificationServiceFactoryImpl();
        TeamConnectDAOFactory teamConnectDAOFactory = new TeamConnectDAOFactoryImpl();
        TeamConnectCheckDAO teamConnectDAO = teamConnectDAOFactory.getTeamConnectDAOFactoryInstance();

        AccountCodeVerificationUpdateServiceImpl updateService =
                new AccountCodeVerificationUpdateServiceImpl
                        (new ChecksVoidsXMLBuilder(),teamConnectDAO, new ResultsProcessorImpl(), handler);
        EmailService service = new JavaMailEmailService(new MailDocumentFactoryImpl(), new XMLEmailBuilderDOMImpl());
        return new BatchAccountCodeVerificationImpl(
                new AccountCodeVerificationDAOImpl(new ResourceManagerFactoryImpl()),
                sapVerificationServiceFactory.getSAPVerificationServiceImpl(),
                handler,
                updateService,
                service);
    }
}