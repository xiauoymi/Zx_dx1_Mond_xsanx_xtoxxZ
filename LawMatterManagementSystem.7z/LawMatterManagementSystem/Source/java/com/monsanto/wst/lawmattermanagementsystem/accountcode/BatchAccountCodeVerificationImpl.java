/*
 BatchAccountCodeVerificationImpl was created on May 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.check.ChecksProcessingMessage;
import com.monsanto.wst.lawmattermanagementsystem.check.ErrorHandler;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationService;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

import java.util.Calendar;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: BatchAccountCodeVerificationImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-01-08 22:07:06 $
 *
 * @author VRBETHI
 * @version $Revision: 1.29 $
 */
public class BatchAccountCodeVerificationImpl implements BatchAccountCodeVerification {
  private AccountCodeVerificationDAO accountCodeVerificationDAO;
  private ErrorHandler errorHandler;
  private AccountCodeVerificationUpdateService accountCodeVerificationUpdateService;
  private EmailService emailService;
  protected AccountCodeSummaryService accountCodeSummaryService;
//  private IMAccountCodeSummaryService imAccountCodeSummaryService;


  public BatchAccountCodeVerificationImpl(
      AccountCodeVerificationDAO accountCodeVerificationDAO, SAPVerificationService sapVerificationService,
      ErrorHandler errorHandler, AccountCodeVerificationUpdateService accountCodeVerificationUpdateService,
      EmailService service) {
    this.accountCodeVerificationDAO = accountCodeVerificationDAO;
    this.errorHandler = errorHandler;
    this.accountCodeVerificationUpdateService = accountCodeVerificationUpdateService;
    emailService = service;
    setAccountCodeSummaryService(sapVerificationService);
//    imAccountCodeSummaryService = new IMAccountCodeSummaryService(this.accountCodeVerificationDAO,
//        imAccountCodeDAO);
  }

  protected void setAccountCodeSummaryService(SAPVerificationService sapVerificationService) {
    this.accountCodeSummaryService = new AccountCodeSummaryService(sapVerificationService);
  }

  public void verifyAccountCodes() throws ServiceException {
    //Read initial properties
    writeHeaderInformation();
    AccountCodeList accountCodeList = accountCodeVerificationDAO.getAccountCodeList();
    writeNumberOfCodesRetrieved(accountCodeList);
    StringBuffer stringBuffer = new StringBuffer();
    for(int i=0;i< accountCodeList.size();i++){
      AccountCode accountCode = accountCodeList.get(i);
      accountCodeSummaryService.summarizeValidityOfAccountCodes(accountCode);
    }
    String changeAccountCodesMessage = accountCodeSummaryService.getSummaryOfChangedAccountCodes();
    System.out.println("changeAccountCodesMessage = " + changeAccountCodesMessage);
    stringBuffer.append(changeAccountCodesMessage);
    ChecksProcessingMessage message = new ChecksProcessingMessage();
    message.setMessage(stringBuffer.toString());
    errorHandler.handleError(message);
    errorHandler.handleError(accountCodeSummaryService.getSummaryOfAccountCodeProcessing());
    accountCodeVerificationUpdateService.updateAccountCodes(accountCodeList);
    List messageList = new ArrayList();
    messageList.add(changeAccountCodesMessage);
//    try {
//      ArrayList toList = new ArrayList();
////      toList.add("judy.l.parker@MONSANTO.COM");
////      toList.add("kathleen.m.hudgens@MONSANTO.COM");
//      toList.add("bhargava.halemane@MONSANTO.COM");
//      emailService.sendEmail(LMMSConstants.EMAIL_CONST_FROM, toList,new ArrayList(),"Changed Account Codes",new ArrayList(),messageList);
//    } catch (EmailException e) {
//      e.printStackTrace();
//    }

  }

  public void printClosedInvoices() throws ServiceException {
  }

  public boolean verifyAccountCode(AccountCode accountCode) throws ServiceException {
    accountCodeSummaryService.summarizeValidityOfAccountCodes(accountCode);
    if(accountCode.getSapComments()== null || accountCode.getSapComments().length()==0){
      //Remove this since this is not possible.
//      accountCodeVerificationUpdateService.updateAccountNewCodeInTeamConnect(accountCode);
    }else{
      accountCodeVerificationUpdateService.updateAccountEditCodeInTeamConnect(accountCode);
    }
    return accountCodeVerificationUpdateService.updateAccountCodeInTeamConnect(accountCode);
  }



  private void writeNumberOfCodesRetrieved(AccountCodeList accountCodeList) throws ServiceException {
    ChecksProcessingMessage checksProcessingMessage = new ChecksProcessingMessage();
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("\n" +
        "Retrieve of SAPMASTER Recordset was Successful...");
    stringBuffer.append("\n");
    stringBuffer.append("   Number of Recs =  ");
    stringBuffer.append(accountCodeList.size());
    checksProcessingMessage.setMessage(stringBuffer.toString());
    errorHandler.handleError(checksProcessingMessage);
  }

  private void writeHeaderInformation() throws ServiceException {
    StringBuffer stringBuffer = new StringBuffer();
    ChecksProcessingMessage processingMessage = new ChecksProcessingMessage();
    stringBuffer.append("Date/Time : ");
    stringBuffer.append(DateUtil.getDate("MM/dd/yyyy  hh:mm", Calendar.getInstance().getTime()));
    stringBuffer.append("\n");
    processingMessage.setMessage(stringBuffer.toString());
    errorHandler.handleError(processingMessage);
  }
}