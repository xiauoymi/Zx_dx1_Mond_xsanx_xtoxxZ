/*
 BatchInvoiceAccountCodeVerificationFactoryImpl was created on Jun 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.check.ErrorHandlerImpl;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;

/**
 * Filename:    $RCSfile: BatchInvoiceAccountCodeVerificationFactoryImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-06-04 19:12:39 $
 *
 * @author vrbethi
 * @version $Revision: 1.4 $
 */
public class BatchInvoiceAccountCodeVerificationFactoryImpl implements BatchInvoiceAccountCodeVerificationFactory {
  public IMBatchAccountCodeVerificationService getBatchAccountCodeVerificationInstance(ErrorHandlerImpl handler) throws ServiceException {
    ResourceManagerFactoryImpl factory = new ResourceManagerFactoryImpl();
    IMAccountCodeSummaryService imAccountCodeSummaryService = new IMAccountCodeSummaryService(
        new AccountCodeVerificationDAOImpl(factory),new InvoiceAccountCodeDAOImpl(factory),new InvoiceACInformation());
    return new IMBatchInvoiceAccountCodeVerificationSercice(imAccountCodeSummaryService, handler);
  }
}