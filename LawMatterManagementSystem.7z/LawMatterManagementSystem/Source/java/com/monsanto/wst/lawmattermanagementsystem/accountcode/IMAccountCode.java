/*
 IMAccountCode was created on May 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

/**
 * Filename:    $RCSfile: IMAccountCode.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-01-15 16:56:50 $
 *
 * @author VRBETHI
 * @version $Revision: 1.6 $
 */
public class IMAccountCode {
  private String company;
  private String business;
  private String costelement;
  private String costcenter;

  public String getSapLinkNumber() {
    return sapLinkNumber;
  }

  private String sapLinkNumber;
  private String tranId;
  private String invoiceNumber;
  
  public String getTranId() {
    return tranId;
  }

  public String getInvoiceNumber() {
    return invoiceNumber;
  }


  
  public IMAccountCode(String company, String business, String costelement, String costcenter, String sapLinkNumber) {
    this.company = company;
    this.business = business;
    this.costelement = costelement;
    this.costcenter = costcenter;
    this.sapLinkNumber = sapLinkNumber;
  }

  public IMAccountCode(String company, String business, String costelement, String costcenter, String sapLinkNumber, String tranId, String invoiceNumber) {
    this.company = company;
    this.business = business;
    this.costelement = costelement;
    this.costcenter = costcenter;
    this.sapLinkNumber = sapLinkNumber;
    this.tranId = tranId;
    this.invoiceNumber = invoiceNumber;
  }

  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
//    stringBuffer.append("                   ");
    stringBuffer.append(company);
    stringBuffer.append("-");
    stringBuffer.append(business);
    stringBuffer.append("-");
    stringBuffer.append(costelement);
    stringBuffer.append("-");
    stringBuffer.append(costcenter);
    stringBuffer.append("(Link No:  ");
    stringBuffer.append(sapLinkNumber);
    stringBuffer.append(")");
//    stringBuffer.append("\n");
    return stringBuffer.toString();
  }

  public String getAccountCodeString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(company);
    stringBuffer.append("-");
    stringBuffer.append(business);
    stringBuffer.append("-");
    stringBuffer.append(costelement);
    stringBuffer.append("-");
    stringBuffer.append(costcenter);
    stringBuffer.append("(Link No:  ");
    stringBuffer.append(sapLinkNumber);
    stringBuffer.append(")");
    return stringBuffer.toString();
  }
}