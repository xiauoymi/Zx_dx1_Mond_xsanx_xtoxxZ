/*
 IMAccountCodeDAO was created on May 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;

/**
 * Filename:    $RCSfile: IMAccountCodeDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-31 19:43:19 $
*
* @author VRBETHI
* @version $Revision: 1.3 $
*/
public interface IMAccountCodeDAO {
  IMAccountCodeList getInvoiceAccountCodeList(String sapLinkNumber);
}