/*
 InvoiceAccountCodeList was created on May 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: IMAccountCodeList.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-31 19:06:22 $
 *
 * @author VRBETHI
 * @version $Revision: 1.3 $
 */
public class IMAccountCodeList {

  private List invoiceAccountCodeList = new ArrayList();

  public int size() {
    return invoiceAccountCodeList.size();
  }

  public void add(IMAccountCode invoiceAccountCode) {
    invoiceAccountCodeList.add(invoiceAccountCode);
  }

  public void add(IMAccountCodeList invoiceAccountCodeList) {
    if(invoiceAccountCodeList!=null){      
      for(int i=0;i<invoiceAccountCodeList.size();i++){
        this.invoiceAccountCodeList.add(invoiceAccountCodeList.get(i));
      }
    }
  }

  public IMAccountCode get(int index) {
    return (IMAccountCode) invoiceAccountCodeList.get(index);
  }
}