/*
 InvoiceAccountCodeSummaryService was created on May 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.check.ChecksProcessingMessage;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: IMAccountCodeSummaryService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-01-15 16:56:50 $
 *
 * @author VRBETHI
 * @version $Revision: 1.19 $
 */
public class IMAccountCodeSummaryService {
  private AccountCodeVerificationDAO accountCodeVerificationDAO;
  private ACInformation acInformation;
  private IMAccountCodeList invoiceAccountCodeCompleteList;
  private IMAccountCodeDAO imAccountCodeDAO;
  private StringBuffer stringBuffer;

  public IMAccountCodeSummaryService(AccountCodeVerificationDAO accountCodeVerificationDAO,
                                     IMAccountCodeDAO imAccountCodeDAO, ACInformation acInformation) {
    this.imAccountCodeDAO = imAccountCodeDAO;
    this.accountCodeVerificationDAO = accountCodeVerificationDAO;
    this.acInformation = acInformation;
    invoiceAccountCodeCompleteList = new IMAccountCodeList();
    stringBuffer = new StringBuffer();
  }

  public ChecksProcessingMessage summarizeIMAccountCodeService() {
    ChecksProcessingMessage checksProcessingMessage = new ChecksProcessingMessage();
    AccountCodeList accountCodeList = accountCodeVerificationDAO.getAccountCodeList();
    for (int i=0;i<accountCodeList.size();i++) {
      IMAccountCodeList invoiceAccountCodeList = getInvoicesForAccountCodeIfClosed(accountCodeList.get(i));
      invoiceAccountCodeCompleteList.add(invoiceAccountCodeList);
    }
    addIMAccountCodeInformation(stringBuffer);
    addSummaryInformation(stringBuffer);
    checksProcessingMessage.setMessage(stringBuffer.toString());
    return checksProcessingMessage;
  }
  private IMAccountCodeList getInvoicesForAccountCodeIfClosed(AccountCode code) {
    IMAccountCodeList invoiceAccountCodeList = null;
    if(isAccountCodeClosed(code)){
      invoiceAccountCodeList = getIMAccountCodeList(code);
    }
    return invoiceAccountCodeList;
  }

  private boolean isAccountCodeClosed(AccountCode code) {
    return StringUtils.contains(code.getSapComments(),"ACCOUNT AUTOCLOSED");
  }

  private IMAccountCodeList getIMAccountCodeList(AccountCode code) {
    return imAccountCodeDAO.getInvoiceAccountCodeList(code.getSapLinkNumber());
  }

  private void addIMAccountCodeInformation(StringBuffer stringBuffer) {
    String oldSapLinkNo = "";
    for (int i = 0; i < invoiceAccountCodeCompleteList.size(); i++) {
      IMAccountCode invoiceAccountCode = this.invoiceAccountCodeCompleteList.get(i);
      if (!isIdenticalSapLinkNumber(oldSapLinkNo, invoiceAccountCode)) {
        oldSapLinkNo = invoiceAccountCode.getSapLinkNumber();
        stringBuffer.append(invoiceAccountCode.getAccountCodeString()).append("[Closed]\n");
        addHeaderInformation(stringBuffer);
      }
      formatMatterInformation(stringBuffer, invoiceAccountCode);
    }
  }

  private void formatMatterInformation(StringBuffer stringBuffer, IMAccountCode invoiceAccountCode) {
    stringBuffer.append(StringUtils.rightPad(invoiceAccountCode.getTranId(), 21, ' '));
    stringBuffer.append(StringUtils.rightPad(invoiceAccountCode.getInvoiceNumber(), 50, ' '));
    stringBuffer.append("\n\n\r");
  }

  private boolean isIdenticalSapLinkNumber(String oldSapLinkNo, IMAccountCode invoiceAccountCode) {
    return invoiceAccountCode.getSapLinkNumber().equalsIgnoreCase(oldSapLinkNo);
  }

  private void addSummaryInformation(StringBuffer stringBuffer) {
    if(invoiceAccountCodeCompleteList.size()==0){
      stringBuffer.append("Number of ");
      stringBuffer.append(acInformation.getIMHeaderString());
      stringBuffer.append(" Effected Recs = 0");
      stringBuffer.append("\n\r");
    }else{
      stringBuffer.append("Number of ");
      stringBuffer.append(acInformation.getIMHeaderString());
      stringBuffer.append(" Effected Recs = ").append(invoiceAccountCodeCompleteList.size());
      stringBuffer.append("\n\r");
    }
  }

  private void addHeaderInformation(StringBuffer stringBuffer) {
    stringBuffer.append(acInformation.getIMColumnHeader());
    stringBuffer.append("\n");
    stringBuffer.append(StringUtils.rightPad("_________", 21, ' '));
    stringBuffer.append(StringUtils.rightPad("___________", 50, ' '));
    stringBuffer.append("\n\r");
  }
}