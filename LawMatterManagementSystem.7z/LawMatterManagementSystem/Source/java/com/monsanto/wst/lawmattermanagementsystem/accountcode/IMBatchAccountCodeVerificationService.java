/*
 IMBatchAccountCodeVerificationService was created on Jun 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

/**
 * Filename:    $RCSfile: IMBatchAccountCodeVerificationService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-06-04 18:48:35 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public interface IMBatchAccountCodeVerificationService {
  public void printClosedInvoices() throws ServiceException;
}