/*
 IMBatchInvoiceAccountCodeVerificationSercice was created on Jun 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.check.ChecksProcessingMessage;
import com.monsanto.wst.lawmattermanagementsystem.check.ErrorHandler;

/**
 * Filename:    $RCSfile: IMBatchInvoiceAccountCodeVerificationSercice.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-06-04 18:48:35 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public class IMBatchInvoiceAccountCodeVerificationSercice implements IMBatchAccountCodeVerificationService{
  private IMAccountCodeSummaryService imAccountCodeSummaryService;
  private ErrorHandler errorHandler;


  public IMBatchInvoiceAccountCodeVerificationSercice(IMAccountCodeSummaryService imAccountCodeSummaryService,
                                                      ErrorHandler errorHandler) {
    this.imAccountCodeSummaryService = imAccountCodeSummaryService;
    this.errorHandler = errorHandler;
  }

  public void printClosedInvoices() throws ServiceException {
    ChecksProcessingMessage checksProcessingMessage;
    checksProcessingMessage= imAccountCodeSummaryService.summarizeIMAccountCodeService();
    errorHandler.handleError(checksProcessingMessage);
  }
}