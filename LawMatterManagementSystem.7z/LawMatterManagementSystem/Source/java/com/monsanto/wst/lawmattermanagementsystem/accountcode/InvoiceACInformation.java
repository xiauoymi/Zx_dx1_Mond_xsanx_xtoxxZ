/*
 InvoiceACInformation was created on Jun 4, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

/**
 * Filename:    $RCSfile: InvoiceACInformation.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2008-12-09 20:44:48 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public class InvoiceACInformation implements ACInformation {
  public String getIMHeaderString() {
    return "IAC";
  }

  public String getIMColumnHeader() {
    return "TRAN ID                 INVOICE NUMBER";
  }
}