/*
 InvoiceAccountCode was created on May 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: InvoiceAccountCode.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-01-15 16:56:49 $
 *
 * @author VRBETHI
 * @version $Revision: 1.6 $
 */
public class InvoiceAccountCode extends IMAccountCode{
  private String costCenter;
  private String costElement;
  private String business;
  private String company;
  private String sapLinkNumber;
  

  public String getTranId() {
    return tranId;
  }

  public String getInvoiceNumber() {
    return invoiceNumber;
  }

  private String tranId;
  private String invoiceNumber;

  public InvoiceAccountCode(String costCenter, String costElement, String business, String company,
                            String sapLinkNumber,
                            String tranId, String invoiceNumber) {
    //super(company,business,costElement,costCenter,sapLinkNumber);
    super(company,business,costElement,costCenter,sapLinkNumber,tranId,invoiceNumber);
    this.costCenter = costCenter;
    this.costElement = costElement;
    this.business = business;
    this.company = company;
    this.sapLinkNumber = sapLinkNumber;
    this.tranId = tranId;
    this.invoiceNumber = invoiceNumber;
  }

  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    //stringBuffer.append("     ");
    stringBuffer.append(StringUtils.rightPad(tranId,27,' '));
    stringBuffer.append(StringUtils.rightPad(invoiceNumber,32,' '));
    stringBuffer.append(super.toString());
    return stringBuffer.toString();
  }
}