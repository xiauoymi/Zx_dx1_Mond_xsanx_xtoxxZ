/*
 AccountCodeVerificationDAOImpl was created on May 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactory;

/**
 * Filename:    $RCSfile: InvoiceAccountCodeDAOImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-01-15 16:56:47 $
 *
 * @author VRBETHI
 * @version $Revision: 1.7 $
 */
public class InvoiceAccountCodeDAOImpl implements IMAccountCodeDAO {
  private ResourceManagerFactory resourceManagerFactory;
  private final String cstrStatement = "--FINDS INVOICES/PAYMENTS FOR AUTOCLOSED ACCOUNTS\n" +
      "--------------------------------------------------------------------------\n" +
      "--RETURNS A SINLE ANSWER FOR A CANDIDATE SAPLINKNO, saplinkno variable  --\n" +
      "-- PMNT.InSAPLinkno  = 573 - PMNT.InSAPLinkno13  = 573 MUST BE CHANGED  --\n" +
      "--EACH TIME THIS QUERY IS INVOKED                                       --\n" +
      "--------------------------------------------------------------------------\n" +
      "--ALLOCATION 1 \n" +
      "SELECT\n" +
      "1 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno AS SAPLINKNO, \n" +
      "PMNT.InAllocPct AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno  = ?\n" +
      "UNION\n" +
      "--ALLOCATION 2 \n" +
      "SELECT\n" +
      "2 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt2 AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement2 AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno2 AS SAPLINKNO, \n" +
      "PMNT.InAllocPct2 AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter2 AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber2 AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter2 AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno2  = ?\n" +
      "UNION\n" +
      "--ALLOCATION 3 \n" +
      "SELECT\n" +
      "3 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt3 AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement3 AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno3 AS SAPLINKNO, \n" +
      "PMNT.InAllocPct3 AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter3 AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber3 AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter3 AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno3  = ?\n" +
      "UNION\n" +
      "--ALLOCATION 4 \n" +
      "SELECT\n" +
      "4 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt4 AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement4 AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno4 AS SAPLINKNO, \n" +
      "PMNT.InAllocPct4 AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter4 AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber4 AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter4 AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno4  = ?\n" +
      "UNION\n" +
      "--ALLOCATION 5 \n" +
      "SELECT\n" +
      "5 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt5 AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement5 AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno5 AS SAPLINKNO, \n" +
      "PMNT.InAllocPct5 AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter5 AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber5 AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter5 AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno5  = ?\n" +
      "UNION\n" +
      "--ALLOCATION 6\n" +
      "SELECT\n" +
      "6 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt6 AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement6 AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno6 AS SAPLINKNO, \n" +
      "PMNT.InAllocPct6 AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter6 AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber6 AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter6 AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno6  = ?\n" +
      "UNION\n" +
      "--ALLOCATION 7\n" +
      "SELECT\n" +
      "7 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt7 AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement7 AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno7 AS SAPLINKNO, \n" +
      "PMNT.InAllocPct7 AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter7 AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber7 AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter7 AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno7  = ?\n" +
      "UNION\n" +
      "--ALLOCATION 8\n" +
      "SELECT\n" +
      "8 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt8 AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement8 AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno8 AS SAPLINKNO, \n" +
      "PMNT.InAllocPct8 AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter8 AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber8 AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter8 AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno8  = ?\n" +
      "UNION\n" +
      "--ALLOCATION 9\n" +
      "SELECT\n" +
      "9 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt9 AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement9 AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno9 AS SAPLINKNO, \n" +
      "PMNT.InAllocPct9 AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter9 AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber9 AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter9 AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno9  = ?\n" +
      "UNION\n" +
      "--ALLOCATION 10\n" +
      "SELECT\n" +
      "10 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt10 AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement10 AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno10 AS SAPLINKNO, \n" +
      "PMNT.InAllocPct10 AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter10 AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber10 AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter10 AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno10  = ?\n" +
      "UNION\n" +
      "--ALLOCATION 11\n" +
      "SELECT\n" +
      "11 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt11 AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement11 AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno11 AS SAPLINKNO, \n" +
      "PMNT.InAllocPct11 AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter11 AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber11 AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter11 AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno11  = ?\n" +
      "UNION\n" +
      "--ALLOCATION 12\n" +
      "SELECT\n" +
      "12 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt12 AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement12 AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno12 AS SAPLINKNO, \n" +
      "PMNT.InAllocPct12 AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter12 AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber12 AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter12 AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno12  = ?\n" +
      "UNION\n" +
      "--ALLOCATION 13\n" +
      "SELECT\n" +
      "13 AS PMNTENTRY,\n" +
      "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
      "PMNT.InTransID AS TRAN_ID, \n" +
      "PMNT.InStatus AS INVOICE_STATUS,\n" +
      "PMNT.InAllocAmt13 AS ALLOCATION_PAY_LC, \n" +
      "PMNT.InCostElement13 AS COST_ELEMENT, \n" +
      "PMNT.InSAPLinkno13 AS SAPLINKNO, \n" +
      "PMNT.InAllocPct13 AS ALLOCATION_PCT, \n" +
      "PMNT.InCostCenter13 AS SUBACCOUNT, \n" +
      "PMNT.InInternalOrderNumber13 AS INTERNAL_ORDER_NUMBER, \n" +
      "PMNT.InProfitCenter13 AS PROFIT_CENTER,\n" +
      "PMNT.InSendAPDate, \n" +
      "PMNT.InPostDate\n" +
      "FROM         INVC_CAT_12 AS PMNT\n" +
      "WHERE PMNT.InSendAPDate IS NULL\n" +
      "--saplinkno variable\n" +
      "AND PMNT.InSAPLinkno13  = ?";

  public InvoiceAccountCodeDAOImpl(
      ResourceManagerFactory resourceManagerFactory) {
    this.resourceManagerFactory = resourceManagerFactory;
  }


  public IMAccountCodeList getInvoiceAccountCodeList(String sapLinkNumber) {
    IMAccountCodeList invoiceAccountCodeList = new IMAccountCodeList();
    PersistentStoreConnection storeConnection = null;
    try {
      ResourceConnectionManager connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
      storeConnection = (PersistentStoreConnection) connectionManager
          .getConnection(LMMSConstants.DATABASE_LAW_TCE);
      PersistentStoreStatement storeStatement = storeConnection.prepareStatement(cstrStatement);
      storeStatement.setParam(1,sapLinkNumber);
      storeStatement.setParam(2,sapLinkNumber);
      storeStatement.setParam(3,sapLinkNumber);
      storeStatement.setParam(4,sapLinkNumber);
      storeStatement.setParam(5,sapLinkNumber);
      storeStatement.setParam(6,sapLinkNumber);
      storeStatement.setParam(7,sapLinkNumber);
      storeStatement.setParam(8,sapLinkNumber);
      storeStatement.setParam(9,sapLinkNumber);
      storeStatement.setParam(10,sapLinkNumber);
      storeStatement.setParam(11,sapLinkNumber);
      storeStatement.setParam(12,sapLinkNumber);
      storeStatement.setParam(13,sapLinkNumber);
      PersistentStoreResultSet persistentStoreResultSet = storeStatement.executeQuery();
      PersistentStoreResultSetFwdIterator setFwdIterator = persistentStoreResultSet.getForwardIterator();
      while(setFwdIterator.next()){
      String costCenter = setFwdIterator.getString("SAP_COST_CENTER");
        String costElement = setFwdIterator.getString("SAP_COST_ELEMENT");
        String business = setFwdIterator.getString("SAP_BUSINESS");
        String company = setFwdIterator.getString("SAP_COMPANY");
        String tranId = setFwdIterator.getString("TRAN_ID");
        String invoiceNumber = setFwdIterator.getString("INVOICE_NUMBER");
        //TODO : The last parameter "" has to be replaced with Invoice Description once the Invoice Query is got from Mike.   
        InvoiceAccountCode invoiceAccountCode = new InvoiceAccountCode(costCenter,costElement,business,company,
            sapLinkNumber,tranId,invoiceNumber);
        invoiceAccountCodeList.add(invoiceAccountCode);
      }
    } catch (ResourceConnectionException e) {
      throw new AccountCodeProcessingException("Error during retrieval of invoice account code",e);
    } catch (WrappingException e) {
      throw new AccountCodeProcessingException("Error during retrieval of invoice account code",e);
    }
    finally{
      PersistencUtil.closeConnection(storeConnection);
    }
    return invoiceAccountCodeList;

  }
}