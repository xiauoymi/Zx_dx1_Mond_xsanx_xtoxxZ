/*
 MatterACInformation was created on Jun 4, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: MatterACInformation.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-01-15 16:56:50 $
 *
 * @author vrbethi
 * @version $Revision: 1.6 $
 */
public class MatterACInformation implements ACInformation {
  public String getIMHeaderString() {
    return "MC";
  }

  public String getIMColumnHeader() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(StringUtils.rightPad("MATTER ID", 21, ' '));
    stringBuffer.append(StringUtils.rightPad("MATTER NAME", 50, ' '));
    return stringBuffer.toString();
  }
}