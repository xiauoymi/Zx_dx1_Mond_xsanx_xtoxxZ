/*
 MatterAccountCode was created on May 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: MatterAccountCode.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-01-15 16:56:45 $
 *
 * @author VRBETHI
 * @version $Revision: 1.6 $
 */
public class MatterAccountCode extends IMAccountCode {
  private String matterId;
  private String matterName;
  private String company;
  private String business;
  private String costelement;
  private String costcenter;
  private String sapLinkNumber;
  private String matterDescription;


  public MatterAccountCode(String matterId, String matterName, String company, String business, String costelement,
                           String costcenter, String sapLinkNumber) {
    //super(company,business,costelement,costcenter,sapLinkNumber);
    super(company, business, costelement, costcenter, sapLinkNumber, matterId, matterName);
    this.matterId = matterId;
    this.matterName = matterName;
    this.company = company;
    this.business = business;
    this.costelement = costelement;
    this.costcenter = costcenter;
    this.sapLinkNumber = sapLinkNumber;
  }

  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(StringUtils.rightPad(matterId, 27, ' '));
    stringBuffer.append(StringUtils.rightPad(matterName, 32, ' '));
    stringBuffer.append(super.toString());
    return stringBuffer.toString();
  }

  public String getTranId() {
    return matterId;
  }

  public String getInvoiceNumber() {
    return matterName;
  }
}