/*
 MatterAccountCodeDAOImpl was created on Jun 4, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Filename:    $RCSfile: MatterAccountCodeDAOImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-01-15 16:56:49 $
 *
 * @author vrbethi
 * @version $Revision: 1.6 $
 */
public class MatterAccountCodeDAOImpl implements IMAccountCodeDAO {
  private ResourceManagerFactoryImpl factory;

//  private String cstrStatement="SELECT  T_PROJECT.NUMBER_STRING AS matter_id, T_PROJECT.NAME AS MATTER_NAME, PROJ_CAT_2786.MtAcSAPLinkno, " +
//      "                      PROJ_CAT_2786.MtAcEndDate, PROJ_CAT_2786.MtAcAccount, PROJ_CAT_2786.MtAcAcctDesc, PROJ_CAT_2786.MtAcCostCenter, " +
//      "                      PROJ_CAT_2786.MtAcCostCenterDesc, PROJ_CAT_2786.MtAcInternalOrderNumber, PROJ_CAT_2786.MtAcProfitCenter, " +
//      "                      PROJ_CAT_2786.MtAcWBS, PROJ_CAT_2786.MtAcStartDate, PROJ_CAT_3930.CcCompany AS SAP_COMPANY , PROJ_CAT_3930.CcSAPBusiness AS SAP_BUSINESS , " +
//      "                      PROJ_CAT_3930.CcCostCenter AS SAP_COST_CENTER, PROJ_CAT_3930.CcCostElement AS SAP_COST_ELEMENT , PROJ_CAT_3930.CcCloseDate, " +
//      "                      PROJ_CAT_3930.CcCloseUId, " +
//      "                      PROJ_CAT_3930.CcClosed, PROJ_CAT_3930.CcSAPComments, PROJ_CAT_3930.CcSAPFormat, " +
//      "                      L_PROJ_PHASE_TYPE.PRIMARY_KEY, L_PROJ_PHASE_TYPE.NAME " +
//
//      "                      FROM  PROJ_CAT_2786 LEFT OUTER JOIN " +
//
//      "                      T_PROJECT AS T_PROJECT_embed ON T_PROJECT_embed.PRIMARY_KEY = PROJ_CAT_2786.PROJECT_ID INNER JOIN " +
//      "                      T_PROJECT ON T_PROJECT_embed.PARENT_ID = T_PROJECT.PRIMARY_KEY INNER JOIN " +
//      "                      Y_APPLICATION ON Y_APPLICATION.PRIMARY_KEY = T_PROJECT.APPLICATION_ID INNER JOIN " +
//      "                      Y_OBJECT_DEFINITION ON Y_OBJECT_DEFINITION.PRIMARY_KEY = Y_APPLICATION.PROJ_OBJECT_DEFINITION_ID INNER JOIN\n" +
//      "                      PROJ_CAT_3930 ON PROJ_CAT_2786.MtAcSAPLinkno = PROJ_CAT_3930.CcSAPLinkNo INNER JOIN " +
//      "                      L_PROJ_PHASE_TYPE ON T_PROJECT.CURRENT_PHASE_TYPE_ID = L_PROJ_PHASE_TYPE.PRIMARY_KEY " +
//
//      "                      WHERE (Y_OBJECT_DEFINITION.ENTITY_CODE = 'PROJ') AND (Y_OBJECT_DEFINITION.PRIMARY_KEY >= 14) AND " +
//      "                      (Y_OBJECT_DEFINITION.OBJECT_TITLE = 'matter') AND (PROJ_CAT_2786.MtAcSAPLinkno  = ?) AND " +
//      "                      (NOT (L_PROJ_PHASE_TYPE.NAME IN ('CLOSED')))";

  private String cstrStatement="SELECT     T_PROJECT.NUMBER_STRING AS matter_id, T_PROJECT.NAME AS MATTER_NAME, PROJ_CAT_2786.MtAcSAPLinkno," +
      " PROJ_CAT_2786.MtAcEndDate, PROJ_CAT_2786.MtAcAccount, PROJ_CAT_2786.MtAcAcctDesc AS MATTER_DESC, PROJ_CAT_2786.MtAcCostCenter," +
      " PROJ_CAT_2786.MtAcCostCenterDesc, PROJ_CAT_2786.MtAcInternalOrderNumber, PROJ_CAT_2786.MtAcProfitCenter," +
      " PROJ_CAT_2786.MtAcWBS, PROJ_CAT_2786.MtAcStartDate, PROJ_CAT_3930.CcCompany AS SAP_COMPANY, " +
      " PROJ_CAT_3930.CcSAPBusiness AS SAP_BUSINESS, PROJ_CAT_3930.CcSAPComments, " +
      " PROJ_CAT_3930.CcCostCenter AS SAP_COST_CENTER, PROJ_CAT_3930.CcCostElement AS SAP_COST_ELEMENT, " +
      " PROJ_CAT_3930.CcCloseDate, PROJ_CAT_3930.CcCloseUId, PROJ_CAT_3930.CcClosed, PROJ_CAT_3930.CcSAPFormat, " +
      " L_PROJ_PHASE_TYPE.PRIMARY_KEY, L_PROJ_PHASE_TYPE.NAME " +
      " FROM PROJ_CAT_2786 LEFT OUTER JOIN " +
      " T_PROJECT AS T_PROJECT_embed ON T_PROJECT_embed.PRIMARY_KEY = PROJ_CAT_2786.PROJECT_ID INNER JOIN " +
      " T_PROJECT ON T_PROJECT_embed.PARENT_ID = T_PROJECT.PRIMARY_KEY INNER JOIN " +
      " Y_APPLICATION ON Y_APPLICATION.PRIMARY_KEY = T_PROJECT.APPLICATION_ID INNER JOIN " +
      " Y_OBJECT_DEFINITION ON Y_OBJECT_DEFINITION.PRIMARY_KEY = Y_APPLICATION.PROJ_OBJECT_DEFINITION_ID INNER JOIN " +
      " PROJ_CAT_3930 ON PROJ_CAT_2786.MtAcSAPLinkno = PROJ_CAT_3930.CcSAPLinkNo INNER JOIN " +
      " L_PROJ_PHASE_TYPE ON T_PROJECT.CURRENT_PHASE_TYPE_ID = L_PROJ_PHASE_TYPE.PRIMARY_KEY " +
      " WHERE(Y_OBJECT_DEFINITION.ENTITY_CODE = 'PROJ')  " +
      " AND (Y_OBJECT_DEFINITION.PRIMARY_KEY >= 14) AND " +
      " (Y_OBJECT_DEFINITION.OBJECT_TITLE = 'matter') " +
      " AND (PROJ_CAT_2786.MtAcEndDate IS NULL)  " +
      " AND (PROJ_CAT_2786.MtAcSAPLinkno  = ?) AND " +
      " (NOT (L_PROJ_PHASE_TYPE.NAME IN ('CLOSED'))) and " +
      " (NOT (L_PROJ_PHASE_TYPE.NAME IN ('CLOSE'))) and " +
      " (PROJ_CAT_3930.CcSAPFormat = 'yes')  " +
      " AND (SUBSTRING(PROJ_CAT_3930.CcSAPComments, 1, 18) = 'ACCOUNT AUTOCLOSED') ORDER BY PROJ_CAT_2786.MtAcSAPLinkno DESC," +
      " T_PROJECT.NUMBER_STRING DESC ";

  public MatterAccountCodeDAOImpl(ResourceManagerFactoryImpl factory) {
    this.factory = factory;
  }

  public IMAccountCodeList getInvoiceAccountCodeList(String sapLinkNumber) {
    IMAccountCodeList invoiceAccountCodeList = new IMAccountCodeList();
    PersistentStoreConnection storeConnection = null;
    try {
      ResourceConnectionManager connectionManager = factory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
      storeConnection = (PersistentStoreConnection) connectionManager
          .getConnection(LMMSConstants.DATABASE_LAW_TCE);
      PersistentStoreStatement storeStatement = storeConnection.prepareStatement(cstrStatement);
      storeStatement.setParam(1,sapLinkNumber);
      PersistentStoreResultSet persistentStoreResultSet = storeStatement.executeQuery();
      PersistentStoreResultSetFwdIterator setFwdIterator = persistentStoreResultSet.getForwardIterator();
      while(setFwdIterator.next()){
        String costCenter = setFwdIterator.getString("SAP_COST_CENTER");
        String costElement = setFwdIterator.getString("SAP_COST_ELEMENT");
        String business = setFwdIterator.getString("SAP_BUSINESS");
        String company = setFwdIterator.getString("SAP_COMPANY");
        String matterId = setFwdIterator.getString("Matter_ID");
        String matterName = setFwdIterator.getString("MATTER_NAME");
        MatterAccountCode matterAccountCode = new MatterAccountCode(matterId,matterName,company,business,costElement,costCenter,sapLinkNumber);
        invoiceAccountCodeList.add(matterAccountCode);
      }
    } catch (ResourceConnectionException e) {
      throw new AccountCodeProcessingException("Error during retrieval of invoice account code",e);
    } catch (WrappingException e) {
      throw new AccountCodeProcessingException("Error during retrieval of invoice account code",e);
    }
    finally{
      PersistencUtil.closeConnection(storeConnection);
    }
    return invoiceAccountCodeList;
  }
}