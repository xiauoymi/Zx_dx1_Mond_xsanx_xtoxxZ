/*
 PersistencUtil was created on Jun 5, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Filename:    $RCSfile: PersistencUtil.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-06-05 14:05:55 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class PersistencUtil {
  //todo Create a new Exception
  public static void closeConnection(PersistentStoreConnection storeConnection) {
    if(storeConnection!=null)
      try {
        storeConnection.close();
      } catch (WrappingException e) {
        e.printStackTrace();
      }
  }
}