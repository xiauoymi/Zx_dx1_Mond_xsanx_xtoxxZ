/*
 AccountCodeDaoQueryHelper_UT was created on Feb 11, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import junit.framework.TestCase;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeDaoQueryHelper;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeDaoQueryHelperImpl;

/**
 * Filename:    $RCSfile: AccountCodeDaoQueryHelper_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-13 20:30:27 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class AccountCodeDaoQueryHelper_UT extends TestCase {

  public void testGetAccountCodeVerificationQuery_AllDataIsNull() throws Exception {
    AccountCode accountCode = new AccountCode("", null, null, null, null, null, null, null, null);
    AccountCodeDaoQueryHelper accountCodeDaoQueryHelper = new AccountCodeDaoQueryHelperImpl();
    String  query = accountCodeDaoQueryHelper.getQuery(accountCode);
    assertEquals(" AND CcCompany is null AND CcSAPBusiness is null AND CcCostCenter is null AND CcCostElement is null AND CcProfitCenter is null AND CcInternalOrderNumber is null AND CcWBS is null",query);
  }

  public void testGetAccountCodeVerificationQuery_AddEnteredAccountCodeDataToQuery() throws Exception {
    AccountCode accountCode = new AccountCode("5180", "9130", "41701900", "SLR76327", null, "1465", "profitCenter", "n/a", "n/a");
    AccountCodeDaoQueryHelper accountCodeDaoQueryHelper = new AccountCodeDaoQueryHelperImpl();
    String  query = accountCodeDaoQueryHelper.getQuery(accountCode);
    assertEquals(" AND CcCompany='5180' AND CcSAPBusiness='9130' AND CcCostCenter='SLR76327' AND CcCostElement='41701900' AND CcProfitCenter='profitCenter' AND CcInternalOrderNumber='n/a' AND CcWBS='n/a' AND CcSAPLinkNo<>'1465.000000000000'",query);
  }
}