/*
 AccountCodeSummaryService_UT was created on May 25, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeSummaryService;
import com.monsanto.wst.lawmattermanagementsystem.check.test.TestData;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationService;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.mock.MockSAPVerificationService;
import junit.framework.TestCase;
import org.apache.commons.lang.StringUtils;

import java.util.Calendar;
import java.util.List;

/**
 * Filename:    $RCSfile: AccountCodeSummaryService_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-09-09 15:46:29 $
 *
 * @author VRBETHI
 * @version $Revision: 1.10 $
 */
public class AccountCodeSummaryService_UT extends TestCase {

  public void testSummarizeValidityOfAccountCodes_CheckCommentsOnValidAccountCode() throws Exception {
    SAPVerificationService sapVerification = new MockSAPVerificationService();
    AccountCodeSummaryService accountCodeSummaryService = new AccountCodeSummaryService(sapVerification);
    TestData testData = new TestData();
    AccountCode code = testData.createAccountCode();
    accountCodeSummaryService.summarizeValidityOfAccountCodes(code);
    String comments = code.getSapComments();
    String closeUid = code.getCloseUid();
    Calendar calendar = Calendar.getInstance();
    assertTrue(StringUtils.contains(comments,"ACCOUNT RE-OPENED as of: "));
    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(1))));
    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(2)+1)));
    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(5))));
    assertEquals("",closeUid);
  }

  public void testSummarizeValidityOfAccountCodes_CheckCommentsOnAccountThatWasValidAndContinuesToBeValid() throws Exception {
    SAPVerificationService sapVerification = new MockSAPVerificationService();
    AccountCodeSummaryService accountCodeSummaryService = new AccountCodeSummaryService(sapVerification);
    TestData testData = new TestData();
    AccountCode code = testData.createValidAccountCode();
    accountCodeSummaryService.summarizeValidityOfAccountCodes(code);
    String comments = code.getSapComments();
    String closeUid = code.getCloseUid();
    String sapFormat = code.getSapFormatValid();
    Calendar calendar = Calendar.getInstance();
    assertTrue(StringUtils.contains(comments,"SAP Code VALID as of:"));
    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(1))));
    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(2)+1)));
    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(5))));
    assertEquals("YENO_ROOT_YESS",sapFormat);
    assertEquals("",closeUid);
  }

  public void testSummarizeValidityOfAccountCodes_NewAccoutSetOpenDateAndSapComments() throws Exception {
    SAPVerificationService sapVerification = new MockSAPVerificationService();
    AccountCodeSummaryService accountCodeSummaryService = new AccountCodeSummaryService(sapVerification);
    TestData testData = new TestData();
    AccountCode code = testData.createNewAccountCode();
    accountCodeSummaryService.summarizeValidityOfAccountCodes(code);
    String comments = code.getSapComments();
    String closeUid = code.getCloseUid();
    String sapFormat = code.getSapFormatValid();
    Calendar calendar = Calendar.getInstance();
    assertTrue(StringUtils.contains(comments,"SAP Code VALID as of: "));
    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(1))));
    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(2)+1)));
    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(5))));
    assertEquals("YENO_ROOT_YESS",sapFormat);
    assertEquals("",closeUid);
  }

  public void testSummarizeValidityOfAccountCodes_ValidAccountThatWasReopnedCommentShouldNotChange() throws Exception {
    SAPVerificationService sapVerification = new MockSAPVerificationService();
    AccountCodeSummaryService accountCodeSummaryService = new AccountCodeSummaryService(sapVerification);
    TestData testData = new TestData();
    AccountCode code = testData.createNewAccountCode_ThatWasReopenedWayBack();
    accountCodeSummaryService.summarizeValidityOfAccountCodes(code);
    String comments = code.getSapComments();
    String closeUid = code.getCloseUid();
    String sapFormat = code.getSapFormatValid();
    assertTrue(StringUtils.contains(comments,"SAP ACCOUNT RE-OPENED as of: 12/02/2003"));
    assertEquals("YENO_ROOT_YESS",sapFormat);
    assertEquals("",closeUid);
  }

  public void testSummarizeValidityOfAccountCodes_ValidAccountIfCommentContains_Account_ReOpened() throws Exception {
    SAPVerificationService sapVerification = new MockSAPVerificationService();
    AccountCodeSummaryService accountCodeSummaryService = new AccountCodeSummaryService(sapVerification);
    TestData testData = new TestData();
    AccountCode code = testData.createNewAccountCode_CommentDoNotStartWithSAP_AccountReOpened();
    accountCodeSummaryService.summarizeValidityOfAccountCodes(code);
    String comments = code.getSapComments();
    String closeUid = code.getCloseUid();
    String sapFormat = code.getSapFormatValid();
// ACCOUNT RE-OPENED as of: 02/22/2005

    assertTrue(StringUtils.contains(comments,"SAP ACCOUNT RE-OPENED as of: 02/22/2005"));
//    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(1))));
//    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(2)+1)));
//    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(5))));
    assertEquals("YENO_ROOT_YESS",sapFormat);
    assertEquals("",closeUid);
  }

  public void testSummarizeValidityOfAccountCodes_CheckCommentsOnAutoClosedAccount_ClosedToday() throws Exception {
    SAPVerificationService sapVerification = new MockSAPVerificationService();
    AccountCodeSummaryService accountCodeSummaryService = new AccountCodeSummaryService(sapVerification);
    TestData testData = new TestData();
    AccountCode code = testData.createAccountCode_BadCostElement();
    accountCodeSummaryService.summarizeValidityOfAccountCodes(code);
    String comments = code.getSapComments();
    String closeUid = code.getCloseUid();
    String sapFormat = code.getSapFormatValid();
    Calendar calendar = Calendar.getInstance();
    assertTrue(StringUtils.contains(comments,"ACCOUNT AUTOCLOSED as of: "));
    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(1))));
    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(2)+1)));
    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(5))));
    assertEquals("AUTOCLOSE",closeUid);
    assertEquals("YENO_ROOT_NOOO",sapFormat);
  }

  public void testSummarizeValidityOfAccountCodes_CheckCommentsOnAutoClosedAccount_ClosedPreviously() throws Exception {
    SAPVerificationService sapVerification = new MockSAPVerificationService();
    AccountCodeSummaryService accountCodeSummaryService = new AccountCodeSummaryService(sapVerification);
    TestData testData = new TestData();
    AccountCode code = testData.createAccountCode_ClosedPreviously();
    accountCodeSummaryService.summarizeValidityOfAccountCodes(code);
    String closeUid = code.getCloseUid();
    String comments = code.getSapComments();
    String closeDate = code.getCloseDate();
    
    assertTrue(StringUtils.contains(comments, "ACCOUNT AUTOCLOSED as of:"));
//    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(1))));
//    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(2)+1)));
//    assertTrue(StringUtils.contains(comments, Integer.toString(calendar.get(5))));
    assertEquals("AUTOCLOSE",closeUid);
    assertEquals("12/18/2001",closeDate);
  }


  public void testSummarizeValidityOfAccountCodes_SetCostCenterToBlankIfBALSHEETAccount() throws Exception {
    SAPVerificationService sapVerification = new MockSAPVerificationService();
    AccountCodeSummaryService accountCodeSummaryService = new AccountCodeSummaryService(sapVerification);
    TestData testData = new TestData();
    AccountCode code = testData.createAccountCode_BALSHEETACCOUNT();
    accountCodeSummaryService.summarizeValidityOfAccountCodes(code);
    assertEquals("", ((MockSAPVerificationService) sapVerification).getCostCenter());
    assertEquals("BALSHEET",code.getCostCenter());
  }


  public void testSummarizeValidityOfAccountCodesAndGetEmailText__CheckListOfChangedAccountCode_OneAccountWhereCommentDidNotChange_OneAccountThatWasValidAndNowCostCenterIsInvalid_OneAccountThatWasInvalidAndIsValidNow() throws Exception {
    SAPVerificationService sapVerification = new MockSAPVerificationService();
    AccountCodeSummaryService accountCodeSummaryService = new AccountCodeSummaryService(sapVerification);
    TestData testData = new TestData();
    AccountCode code = testData.createNewAccountCode_ThatWasReopenedWayBack();
    AccountCode badCostElementCostCenter = testData.createAccountCode_BadCostElement();
    AccountCode closedPreviouslyButValidNow = testData.createAccountCode_ClosedPreviously_ButAccountIsValid();
    accountCodeSummaryService.summarizeValidityOfAccountCodes(code);
    accountCodeSummaryService.summarizeValidityOfAccountCodes(badCostElementCostCenter);
    accountCodeSummaryService.summarizeValidityOfAccountCodes(closedPreviouslyButValidNow);
    String changedAccountCodeSummary = accountCodeSummaryService.getSummaryOfChangedAccountCodes();
    System.out.println("changedAccountCodeSummary = " + changedAccountCodeSummary);
    List changedAccountCodeList = accountCodeSummaryService.getChangedAccountCodeList();
    assertTrue(StringUtils.contains(((AccountCode) changedAccountCodeList.get(0)).getSapComments(),"ACCOUNT AUTOCLOSED as of:"));
    assertTrue(StringUtils.contains(((AccountCode) changedAccountCodeList.get(1)).getSapComments(),"SAP ACCOUNT RE-OPENED as of:"));
    assertTrue(StringUtils.contains(changedAccountCodeSummary,"SAP ACCOUNT RE-OPENED as of:"));
    assertTrue(StringUtils.contains(changedAccountCodeSummary,"ACCOUNT AUTOCLOSED as of:"));
    assertEquals(2, changedAccountCodeList.size());
  }


}