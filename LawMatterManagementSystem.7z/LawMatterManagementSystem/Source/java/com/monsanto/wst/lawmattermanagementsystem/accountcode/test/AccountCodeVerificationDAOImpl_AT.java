/*
 AccountCodeVerificationDAOImpl_AT was created on May 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.*;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AccountCodeVerificationDAOImpl_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 16:11:20 $
 *
 * @author VRBETHI
 * @version $Revision: 1.8 $
 */
public class AccountCodeVerificationDAOImpl_AT extends TestCase {

  public void testGetAccountCodeList() throws Exception {
    //todo add test to get size
    AccountCodeVerificationDAO verificationDAO = new AccountCodeVerificationDAOImpl(new ResourceManagerFactoryImpl());
    AccountCodeList accountCodeList = verificationDAO.getAccountCodeList();
    assertNotNull(accountCodeList);
  }

  public void testGetAccountCodeForSAPLinkNumber() throws Exception {
    AccountCodeVerificationDAO verificationDAO = new AccountCodeVerificationDAOImpl(new ResourceManagerFactoryImpl());
    AccountCode accountCode = verificationDAO.lookUpAccountCodeForSAPLinkNumber("1276");
    assertEquals("MTL74238",accountCode.getCostCenter());
  }

  //todo this method needs to moved
  public void testGetInvoiceAccountCodeList() throws Exception {
//    ResourceConnectionManager connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
//    return (PersistentStoreConnection) connectionManager.getConnection(LMMSConstants.DATABASE_LAW_TCE);
    IMAccountCodeDAO verificationDAO = new InvoiceAccountCodeDAOImpl(new ResourceManagerFactoryImpl());
    IMAccountCodeList invoiceAccountCodeList = verificationDAO.getInvoiceAccountCodeList("6");
    assertNotNull(invoiceAccountCodeList);
  }

  public void testLookUpAccountCodesWithValues() throws Exception {
    AccountCodeVerificationDAO verificationDAO = new AccountCodeVerificationDAOImpl(new ResourceManagerFactoryImpl());
    AccountCode accountCode = new AccountCode("5180", "9130", "41701900", "SLR76327", null, null,
        null, "n/a", "n/a");   
    AccountCodeList list = verificationDAO.lookUpAccountCodesWithValues(accountCode, new AccountCodeDaoQueryHelperImpl());
    assertEquals(1,list.size());
  }


}