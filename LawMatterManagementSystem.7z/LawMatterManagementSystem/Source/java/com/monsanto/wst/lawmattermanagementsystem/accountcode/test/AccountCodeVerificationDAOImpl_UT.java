/*
 AccountCodeVerificationDAOImpl_UT was created on May 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.*;
import com.monsanto.wst.lawmattermanagementsystem.resource.mock.MockFactoryReturnsExceptionThrowingConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactory;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.dataservices.Test.MockPersistentStoreConnection;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AccountCodeVerificationDAOImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-23 15:21:14 $
 *
 * @author VRBETHI
 * @version $Revision: 1.7 $
 */
public class AccountCodeVerificationDAOImpl_UT extends TestCase {

  public void testCreateAccountCodeVerificationDAOImpl() throws Exception {
    AccountCodeVerificationDAO verificationDAO = new AccountCodeVerificationDAOImpl(null);
    assertNotNull(verificationDAO);
  }

  public void testCreateAccountCodeVerificationDAOImpl_ThrowsAccountCodeProcessingException_DueToResourceConnectionException() throws Exception {
    AccountCodeVerificationDAO verificationDAO = null;
    try {
      verificationDAO = new
          AccountCodeVerificationDAOImpl(new MockFactoryReturnsExceptionThrowingConnectionManager());
      verificationDAO.getAccountCodeList();
      fail("Account Code Exception shoule have been thrown");
    } catch (AccountCodeProcessingException e) {
      assertEquals("Exception retrieving account codes",e.getMessage());
      e.printStackTrace();
    }
  }

  public void testCreateAccountCodeVerificationDAOImpl_ThrowsAccountCodeProcessingException_DueToWrappingException() throws Exception {
    AccountCodeVerificationDAO verificationDAO = null;
    try {
      verificationDAO = new
          AccountCodeVerificationDAOImpl(new MockFactoryReturnsExceptionThrowingWrappingException());
      verificationDAO.getAccountCodeList();
      fail("Account Code Exception shoule have been thrown");
    } catch (AccountCodeProcessingException e) {
      assertEquals("Exception retrieving account codes",e.getMessage());
      e.printStackTrace();
    }
  }

  public void testCreateAccountCodeVerificationDAOImpl_LookUpAccountCodeForSAPLinkNumber_ThrowsAccountCodeProcessingException_DueToResourceConnectionException() throws Exception {
    AccountCodeVerificationDAO verificationDAO = null;
    try {
      verificationDAO = new
          AccountCodeVerificationDAOImpl(new MockFactoryReturnsExceptionThrowingConnectionManager());
      verificationDAO.lookUpAccountCodeForSAPLinkNumber(null);
      fail("Account Code Exception shoule have been thrown");
    } catch (AccountCodeProcessingException e) {
      assertEquals("Exception retrieving account codes",e.getMessage());
      e.printStackTrace();
    }
  }

  public void testCreateAccountCodeVerificationDAOImpl_LookUpAccountCodeForSAPLinkNumber_ThrowsAccountCodeProcessingException_DueToWrappingException() throws Exception {
    AccountCodeVerificationDAO verificationDAO = null;
    try {
      verificationDAO = new
          AccountCodeVerificationDAOImpl(new MockFactoryReturnsExceptionThrowingWrappingException());
      verificationDAO.lookUpAccountCodeForSAPLinkNumber(null);
      fail("Account Code Exception shoule have been thrown");
    } catch (AccountCodeProcessingException e) {
      assertEquals("Exception retrieving account codes",e.getMessage());
      e.printStackTrace();
    }
  }

  public void testLookUpAccountCodesForAccoutCodeWithValues() throws Exception {
    AccountCode accountCode = new AccountCode("5180", "9130", "41701900", "SLR76327", null, null, "profitCenter", "n/a", "n/a");
    AccountCodeVerificationDAO verificationDAO = null;
    verificationDAO = new
        AccountCodeVerificationDAOImpl(new MockResourceManagerFactory());
    AccountCodeList list = verificationDAO.lookUpAccountCodesWithValues(accountCode, new AccountCodeDaoQueryHelperImpl());
    assertNotNull(list);
  }

  class MockResourceManagerFactory implements ResourceManagerFactory{

    public ResourceConnectionManager getConnectionManager(String type) {
      return new MockResourceConnectionManger();
    }
  }

  class MockResourceConnectionManger implements ResourceConnectionManager{

    public Object getConnection(String databaseNameOrRemoteSubDir) throws ResourceConnectionException {
      return new MockPersistentStoreConnection(null);
    }
  }
}