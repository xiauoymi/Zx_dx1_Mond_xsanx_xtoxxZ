/*
 AccountCodeVerificationServiceImpl_AT was created on Feb 12, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationServiceFactory;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationServiceFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationService;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: AccountCodeVerificationServiceImpl_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-10 20:19:18 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class AccountCodeVerificationServiceImpl_AT extends TestCase {

  public void testValidateAccountCodes_AccountCodeIsValid() throws Exception {
    AccountCodeVerificationServiceFactory accountCodeVerificationServiceFactory = new AccountCodeVerificationServiceFactoryImpl();
    AccountCodeVerificationService service = accountCodeVerificationServiceFactory.getAccountCodeVerificationService();
    AccountCode accountCode = new AccountCode("5180", "9130", "41701900", "SLR75125", null, null,
        null, "n/a", "n/a");
    String outputString = service.validateAccountCodes(accountCode);
    assertEquals("Bad Cost Center",outputString);
  }

  public void testValidateAccountCodes_AccountCodeIsInvalidSinceAnAccountWithCodeAlreayExists() throws Exception {
    AccountCodeVerificationServiceFactory accountCodeVerificationServiceFactory = new AccountCodeVerificationServiceFactoryImpl();
    AccountCodeVerificationService service = accountCodeVerificationServiceFactory.getAccountCodeVerificationService();
    AccountCode accountCode = new AccountCode("5180", "9130", "41701900", null, null, null,
        null, null, null);
    String outputString = service.validateAccountCodes(accountCode);
    assertEquals("",outputString);
  }
}