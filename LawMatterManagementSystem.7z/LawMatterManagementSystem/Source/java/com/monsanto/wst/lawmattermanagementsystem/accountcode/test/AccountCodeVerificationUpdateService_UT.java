/*
 AccountCodeVerificationUpdateService_UT was created on May 21, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeList;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationUpdateService;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationUpdateServiceImpl;
import com.monsanto.wst.lawmattermanagementsystem.check.*;
import com.monsanto.wst.lawmattermanagementsystem.check.test.MockResultProcessorImpl;
import com.monsanto.wst.lawmattermanagementsystem.check.test.TestData;
import com.monsanto.wst.lawmattermanagementsystem.voids.test.MockErrorHandler;
import junit.framework.TestCase;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: AccountCodeVerificationUpdateService_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-25 15:31:16 $
 *
 * @author VRBETHI
 * @version $Revision: 1.3 $
 */
public class AccountCodeVerificationUpdateService_UT extends TestCase {

  public void testCreateAccountCodeVerificationUpdateService() throws Exception {
    XMLBuilder xmlBuilder = new MockAccountCodeXMLBuilder();
    TeamConnectCheckDAO teamConnectCheckDAO = new MockTeamConnectCheckDAOImpl(null);
    ResultsProcessor resultsProcessor = new MockResultProcessorImpl();
    ErrorHandler errorHandler = new MockErrorHandler();

    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new AccountCodeVerificationUpdateServiceImpl(xmlBuilder,teamConnectCheckDAO,resultsProcessor,errorHandler);
    assertNotNull(accountCodeVerificationUpdateService);
  }

  public void testUpdateAccountCodesCallCreateAccountCodeUpdateXML() throws Exception {
    XMLBuilder xmlBuilder = new MockAccountCodeXMLBuilder();
    TeamConnectCheckDAO teamConnectCheckDAO = new MockTeamConnectCheckDAOImpl(null);
    ResultsProcessor resultsProcessor = new MockResultProcessorImpl();
    ErrorHandler errorHandler = new MockErrorHandler();
    TestData testData = new TestData();
    AccountCodeList accountCodeList = testData.getAccountCodeList_WithOneAccountCode();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new AccountCodeVerificationUpdateServiceImpl(xmlBuilder,teamConnectCheckDAO,resultsProcessor,errorHandler);
    accountCodeVerificationUpdateService.updateAccountCodes(accountCodeList);
    boolean buildUpdateAccountCode = ((MockAccountCodeXMLBuilder)xmlBuilder).wasBuildUpdateAccountCodeCalled();
    assertTrue(buildUpdateAccountCode);
  }

  public void testUpdateAccountCodesCallCreateAccountCodeUpdateXML_Called3Times() throws Exception {
    XMLBuilder xmlBuilder = new MockAccountCodeXMLBuilder();
    TeamConnectCheckDAO teamConnectCheckDAO = new MockTeamConnectCheckDAOImpl(null);
    ResultsProcessor resultsProcessor = new MockResultProcessorImpl();
    ErrorHandler errorHandler = new MockErrorHandler();
    TestData testData = new TestData();
    AccountCodeList accountCodeList = testData.getAccountCodeList();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new AccountCodeVerificationUpdateServiceImpl(xmlBuilder,teamConnectCheckDAO,resultsProcessor,errorHandler);
    accountCodeVerificationUpdateService.updateAccountCodes(accountCodeList);
    int numberOfTimesBuilderCalled = ((MockAccountCodeXMLBuilder)xmlBuilder).numberOfTimesBuilderCalled();
    assertEquals(3,numberOfTimesBuilderCalled);
  }

  public void testUpdateAccountCodesCallCallServiceInTeamConnect() throws Exception {
    XMLBuilder xmlBuilder = new MockAccountCodeXMLBuilder();
    TeamConnectCheckDAO teamConnectCheckDAO = new MockTeamConnectCheckDAOImpl(null);
    ResultsProcessor resultsProcessor = new MockResultProcessorImpl();
    ErrorHandler errorHandler = new MockErrorHandler();
    TestData testData = new TestData();
    AccountCodeList accountCodeList = testData.getAccountCodeList_WithOneAccountCode();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new AccountCodeVerificationUpdateServiceImpl(xmlBuilder,teamConnectCheckDAO,resultsProcessor,errorHandler);
    accountCodeVerificationUpdateService.updateAccountCodes(accountCodeList);
    boolean buildUpdateAccountCode = ((MockTeamConnectCheckDAOImpl)teamConnectCheckDAO).wasCallSericeCalled();
    assertTrue(buildUpdateAccountCode);
  }

  public void testUpdateAccountCodesResultProcessorCalled() throws Exception {
    XMLBuilder xmlBuilder = new MockAccountCodeXMLBuilder();
    TeamConnectCheckDAO teamConnectCheckDAO = new MockTeamConnectCheckDAOImpl(null);
    ResultsProcessor resultsProcessor = new MockResultProcessorImpl();
    ErrorHandler errorHandler = new MockErrorHandler();
    TestData testData = new TestData();
    AccountCodeList accountCodeList = testData.getAccountCodeList_WithOneAccountCode();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new AccountCodeVerificationUpdateServiceImpl(xmlBuilder,teamConnectCheckDAO,resultsProcessor,errorHandler);
    accountCodeVerificationUpdateService.updateAccountCodes(accountCodeList);
    boolean buildUpdateAccountCode = ((MockResultProcessorImpl)resultsProcessor).wasResultsProcessorCalled();
    assertTrue(buildUpdateAccountCode);
  }
  public void testUpdateAccountCodesResultProcessorCalled_WriteErrorIfErrorOnUpdate() throws Exception {
    XMLBuilder xmlBuilder = new MockAccountCodeXMLBuilder();
    TeamConnectCheckDAO teamConnectCheckDAO = new MockTeamConnectCheckDAOImpl(null);
    ResultsProcessor resultsProcessor = new MockResultProcessorImpl();
    ErrorHandler errorHandler = new MockErrorHandler();
    TestData testData = new TestData();
    AccountCodeList accountCodeList = testData.getAccountCodeList_WithOneAccountCode();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new AccountCodeVerificationUpdateServiceImpl(xmlBuilder,teamConnectCheckDAO,resultsProcessor,errorHandler);
    accountCodeVerificationUpdateService.updateAccountCodes(accountCodeList);
    String message = ((MockErrorHandler) errorHandler).getMessage();
    assertEquals("Error",message);
  }

  class MockTeamConnectCheckDAOImpl extends TeamConnectCheckDAOImpl {
    private boolean wasCallServiceCalled=false;

    public MockTeamConnectCheckDAOImpl(HttpClient httpClient) {
      super(httpClient, new PostMethod());
    }

    public Document callService(Document document) {
      wasCallServiceCalled=true;
      return null;
    }

    public boolean wasCallSericeCalled() {
      return wasCallServiceCalled;
    }
  }
}