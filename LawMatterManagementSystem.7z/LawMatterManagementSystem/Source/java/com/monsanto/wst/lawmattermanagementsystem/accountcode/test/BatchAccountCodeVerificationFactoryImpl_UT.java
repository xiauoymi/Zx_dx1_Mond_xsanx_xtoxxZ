/*
 BatchAccountCodeVerificationFactoryImpl_UT was created on May 25, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.BatchAccountCodeVerification;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.BatchAccountCodeVerificationFactory;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.BatchAccountCodeVerificationFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.BatchAccountCodeVerificationImpl;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.check.ErrorHandlerImpl;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriterImpl;

/**
 * Filename:    $RCSfile: BatchAccountCodeVerificationFactoryImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-06-04 18:17:56 $
 *
 * @author VRBETHI
 * @version $Revision: 1.4 $
 */
public class BatchAccountCodeVerificationFactoryImpl_UT extends LMMSBaseTestCase {

  public void testCreateBatchAccountCodeVerification() throws Exception {
    BatchAccountCodeVerificationFactory batchAccountCodeVerificationFactory = new BatchAccountCodeVerificationFactoryImpl();
    BatchAccountCodeVerification batchAccountCodeVerification =
        batchAccountCodeVerificationFactory.getBatchAccountCodeVerificationInstance(
            new ErrorHandlerImpl(new ErrorReportWriterImpl(), LMMSConstants.BATCH_AC_SUMMARY_FILE_NAME));
    assertTrue(batchAccountCodeVerification instanceof BatchAccountCodeVerificationImpl);
  }
}