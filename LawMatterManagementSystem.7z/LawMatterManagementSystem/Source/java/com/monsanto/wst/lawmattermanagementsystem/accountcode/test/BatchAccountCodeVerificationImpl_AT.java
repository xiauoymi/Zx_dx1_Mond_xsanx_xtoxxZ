/*
 BatchAccountCodeVerificationImpl_AT was created on May 25, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.*;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.check.ErrorHandlerImpl;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriterImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;

/**
 * Filename:    $RCSfile: BatchAccountCodeVerificationImpl_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 16:11:20 $
 *
 * @author VRBETHI
 * @version $Revision: 1.7 $
 */
public class BatchAccountCodeVerificationImpl_AT extends LMMSBaseTestCase {

  public void testVerifyAccountCodes() throws Exception {
    BatchAccountCodeVerificationFactory batchAccountCodeVerificationFactory = new BatchAccountCodeVerificationFactoryImpl();
    BatchAccountCodeVerification verification = batchAccountCodeVerificationFactory
        .getBatchAccountCodeVerificationInstance(new ErrorHandlerImpl(new ErrorReportWriterImpl(),
            LMMSConstants.BATCH_AC_SUMMARY_FILE_NAME));
    verification.verifyAccountCodes();
    verification.printClosedInvoices();
  }

  public void testVerifyAccountCode() throws Exception {
    BatchAccountCodeVerificationFactory batchAccountCodeVerificationFactory = new BatchAccountCodeVerificationFactoryImpl();
    BatchAccountCodeVerification verification = batchAccountCodeVerificationFactory
        .getBatchAccountCodeVerificationInstance(new ErrorHandlerImpl(new ErrorReportWriterImpl(),
            LMMSConstants.BATCH_AC_SUMMARY_FILE_NAME));

    //String companyCode, String businessCode, String costElement, String costCenter, String sapComments,
//                     String sapLinkNumber, String profitCenter, String internalOrderNumber,
//                     String workBreakDownStructure
    AccountCode accountCode = new AccountCode("5180","9115","41701900","AGD80921",
        "SAP Code VALID as of: 09/06/2007 04:30","1000139","","n/a",
        "n/a");
    accountCode.setUserId("vrbethi");
    verification.verifyAccountCode(accountCode);
//    verification.verifyAccountCodes();
//    verification.printClosedInvoices();
  }

  public void testVerifyAccountCode_() throws Exception {
    AccountCodeVerificationServiceFactory accountCodeVerificationServiceFactory = new AccountCodeVerificationServiceFactoryImpl();
    AccountCodeVerificationService service = accountCodeVerificationServiceFactory.getAccountCodeVerificationService();
    AccountCode accountCode = new AccountCode("5180","9115","11607000","BALSHEET",
        "SAP Code VALID as of: 09/06/2007 04:30","1000162","500940000","",
        "n/a");
    String resultString = service.validateAccountCodes(accountCode);

    BatchAccountCodeVerificationFactory batchAccountCodeVerificationFactory = new BatchAccountCodeVerificationFactoryImpl();
    BatchAccountCodeVerification verification = batchAccountCodeVerificationFactory
        .getBatchAccountCodeVerificationInstance(new ErrorHandlerImpl(new ErrorReportWriterImpl(),
            LMMSConstants.BATCH_AC_SUMMARY_FILE_NAME));

    //String companyCode, String businessCode, String costElement, String costCenter, String sapComments,
//                     String sapLinkNumber, String profitCenter, String internalOrderNumber,
//                     String workBreakDownStructure

    accountCode.setUserId("vrbethi");
    verification.verifyAccountCode(accountCode);
//    verification.verifyAccountCodes();
//    verification.printClosedInvoices();
  }
}