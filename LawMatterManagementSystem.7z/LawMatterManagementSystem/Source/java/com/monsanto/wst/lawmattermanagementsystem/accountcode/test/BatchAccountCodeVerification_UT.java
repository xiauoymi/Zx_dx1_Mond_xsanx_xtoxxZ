/*
 BatchAccountCodeVerification_UT was created on May 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.*;
import com.monsanto.wst.lawmattermanagementsystem.check.ErrorHandler;
import com.monsanto.wst.lawmattermanagementsystem.check.test.TestData;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.mock.MockEmailService;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationService;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.mock.MockSAPVerificationService;
import com.monsanto.wst.lawmattermanagementsystem.voids.test.MockErrorHandler;
import junit.framework.TestCase;
import org.apache.commons.lang.StringUtils;

import java.util.Calendar;

/**
 * Filename:    $RCSfile: BatchAccountCodeVerification_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-01-12 15:13:53 $
 *
 * @author VRBETHI
 * @version $Revision: 1.26 $
 */
public class BatchAccountCodeVerification_UT extends TestCase {

  public void testVerifyAccountCodes_Create() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    EmailService service = new MockEmailService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();
    BatchAccountCodeVerification codeVerification = new BatchAccountCodeVerificationImpl
        (accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService, service);
    codeVerification.verifyAccountCodes();
    assertNotNull(codeVerification);
  }

  public void testVerifyAccountCodes_LogDetails() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    EmailService service = new MockEmailService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();
    BatchAccountCodeVerification codeVerification = new BatchAccountCodeVerificationImpl
        (accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService, service);
    codeVerification.verifyAccountCodes();
    String message = ((MockErrorHandler) errorHandler).getMessage();
    int year = Calendar.getInstance().get(1);
    int month = Calendar.getInstance().get(2);
    int day = Calendar.getInstance().get(5);
    assertTrue(StringUtils.contains(message,"Date/Time :"));
    assertTrue(StringUtils.contains(message,Integer.toString(year)));
    assertTrue(StringUtils.contains(message,Integer.toString(month+1)));
    //todo uncomment this
    assertTrue(StringUtils.contains(message,Integer.toString(day)));
    assertTrue(StringUtils.contains(message,"Retrieve of SAPMASTER Recordset was Successful..."));
    assertTrue(StringUtils.contains(message,"   Number of Recs =  2"));
  }

  public void testVerifyAccountCodes_RetrieveAccountCodesWasCalled() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    EmailService service = new MockEmailService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();
    BatchAccountCodeVerification codeVerification = new BatchAccountCodeVerificationImpl
        (accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService, service);
    codeVerification.verifyAccountCodes();
    boolean wasGetAccountCodeListCalled = ((MockAccountCodeVerificationDAO)accountCodeVerificationDAO).wasGetAccountCodeListCalled();
    assertTrue(wasGetAccountCodeListCalled);
  }

  public void testVerifyAccountCodes_SAPVeirficationServiceCalled() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    EmailService service = new MockEmailService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();
    BatchAccountCodeVerification codeVerification = new BatchAccountCodeVerificationImpl
        (accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService, service);
    codeVerification.verifyAccountCodes();
    boolean wasSAPValidationCalled = ((MockSAPVerificationService)sapVerificationService).wasSAPValidationCalled();
    int numberOfTimesAccountCodeValidationCalled = ((MockSAPVerificationService)sapVerificationService).numberOfTimesAccountCodeValidationCalled();
    assertTrue(wasSAPValidationCalled);
    assertEquals(2,numberOfTimesAccountCodeValidationCalled);
  }

  public void testVerifyAccountCode_SAPVeirficationServiceCalled() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    TestData testData = new TestData();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    EmailService service = new MockEmailService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();
    BatchAccountCodeVerification codeVerification = new BatchAccountCodeVerificationImpl
        (accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService, service);
    codeVerification.verifyAccountCode(testData.createAccountCode());
    boolean wasSAPValidationCalled = ((MockSAPVerificationService)sapVerificationService).wasSAPValidationCalled();
    assertTrue(wasSAPValidationCalled);
  }

  public void testVerifyAccountCode_UpdateAccountCode() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    TestData testData = new TestData();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();
    EmailService service = new MockEmailService();
    BatchAccountCodeVerification codeVerification = new BatchAccountCodeVerificationImpl
        (accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService, service);
    codeVerification.verifyAccountCode(testData.createAccountCode());
    boolean isWasUpdateAccountCodeInTeamConnectCalled = ((MockAccountCodeVerificationUpdateService)accountCodeVerificationUpdateService).isWasUpdateAccountCodeInTeamConnectCalled();
    assertTrue(isWasUpdateAccountCodeInTeamConnectCalled);
  }

  public void testVerifyAccountCodes_WriteTotalValidAccounts() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    EmailService service = new MockEmailService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();
    BatchAccountCodeVerification codeVerification = new
        BatchAccountCodeVerificationImpl(accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService,
        service);
    codeVerification.verifyAccountCodes();
    String message = ((MockErrorHandler) errorHandler).getMessage();
    assertTrue(StringUtils.contains(message, "Total Accts inspected from MTCSAPMASTER =  2(Includes all OPEN and previously autoclosed accts)"));
  }

  public void testVerifyAccountCodes_WriteStillInvalidAccounts() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO_AutoClosedAccounts();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();
    EmailService service = new MockEmailService();
    BatchAccountCodeVerification codeVerification = new
        BatchAccountCodeVerificationImpl(accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService,
        service);
    codeVerification.verifyAccountCodes();
    String message = ((MockErrorHandler) errorHandler).getMessage();
    assertTrue(StringUtils.contains(message, "Total Accts determined to have gone bad = 1"));
    assertTrue(StringUtils.contains(message, "Total Accts determined to    remain bad = 3"));
  }

  //TODO: Complete this Test
  public void testVerifyAccountCodes_EmailAccountCodesThatChanged() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO_AutoClosedAccounts();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();
    EmailService service = new MockEmailService();
    BatchAccountCodeVerification codeVerification = new
        MockBatchAccountCodeVerificationImpl(accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService,service
    );
    codeVerification.verifyAccountCodes();
    boolean wasSendEmailCalled =((MockEmailService) service).wasSendEmailCalled();
    //assertTrue(wasSendEmailCalled);
    assertFalse(wasSendEmailCalled);
//    assertEquals("1234 ACCOUNT AUTOCLOSED as of: 07/31/2008  (bad ce)", ((MockEmailService) service).getMessageLines().get(0));
//    assertEquals("Changed Account Codes", ((MockEmailService) service).getSubject());
  }

//todo uncomment this test after database back up is done
//  public void testVerifyAccountCodes_CallAccountCodeVerificationUpdateService() throws Exception {
//    ErrorHandler errorHandler = new MockErrorHandler();
//    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO_AutoClosedAccounts();
//    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
//    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
//        new MockAccountCodeVerificationUpdateService();
//    BatchAccountCodeVerification codeVerification = new
//        BatchAccountCodeVerificationImpl(accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService);
//    codeVerification.verifyAccountCodes();
//    boolean wasUpdateServiceCalled = ((MockAccountCodeVerificationUpdateService) accountCodeVerificationUpdateService).
//        wasUpdateServiceCalled();
//    assertTrue(wasUpdateServiceCalled);
//  }
//
 //TODO: Complete this Test
  public void testPrintClosedInvoices_NumberOfInvoicesIsZero() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO_ReturnsZeroInvoiceAccountCodes();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    EmailService service = new MockEmailService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();

    BatchAccountCodeVerification codeVerification = new
        BatchAccountCodeVerificationImpl(accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService,
        service);
    IMAccountCodeSummaryService imAccountCodeSummaryService =
        new IMAccountCodeSummaryService(accountCodeVerificationDAO,null,new InvoiceACInformation());
    IMBatchAccountCodeVerificationService imBatchAccountCodeVerificationService = new IMBatchInvoiceAccountCodeVerificationSercice(imAccountCodeSummaryService,errorHandler);
    imBatchAccountCodeVerificationService.printClosedInvoices();
    String message = ((MockErrorHandler) errorHandler).getMessage();
//    assertTrue(StringUtils.contains(message, "TRAN ID                 INVOICE NUMBER"));
//    assertTrue(StringUtils.contains(message, "= = = =                    = = = = = = = ="));
    assertTrue(StringUtils.contains(message, "Number of IAC Effected Recs = 0"));
  }

  public void testPrintClosedInvoices_RetrieveAccountCodesWasCalled() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    IMAccountCodeDAO imAccountCodeDAO = new MockInvoiceAccountCodeDAOImpl();
    EmailService service = new MockEmailService();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();
    IMAccountCodeSummaryService imAccountCodeSummaryService = new IMAccountCodeSummaryService(accountCodeVerificationDAO,imAccountCodeDAO,new InvoiceACInformation());

    BatchAccountCodeVerification codeVerification = new BatchAccountCodeVerificationImpl
        (accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService, service);
    IMBatchAccountCodeVerificationService imBatchAccountCodeVerificationService = new IMBatchInvoiceAccountCodeVerificationSercice(imAccountCodeSummaryService,errorHandler);

    imBatchAccountCodeVerificationService.printClosedInvoices();
    boolean wasGetAccountCodeListCalled = ((MockAccountCodeVerificationDAO)accountCodeVerificationDAO).wasGetAccountCodeListCalled();
    assertTrue(wasGetAccountCodeListCalled);
  }

  public void testPrintClosedInvoices_ForEachAccountCodeCall_GetInvoiceAccountCodeList() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    IMAccountCodeDAO imAccountCodeDAO = new MockInvoiceAccountCodeDAOImpl();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    EmailService service = new MockEmailService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();
    IMAccountCodeSummaryService imAccountCodeSummaryService = new
        IMAccountCodeSummaryService(accountCodeVerificationDAO,imAccountCodeDAO,new InvoiceACInformation());

    BatchAccountCodeVerification codeVerification = new BatchAccountCodeVerificationImpl
        (accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService, service);
    IMBatchAccountCodeVerificationService imBatchAccountCodeVerificationService =
        new IMBatchInvoiceAccountCodeVerificationSercice(imAccountCodeSummaryService,errorHandler);

    imBatchAccountCodeVerificationService.printClosedInvoices();
    int numberOfTimesGetInvoiceAccountCalled = ((MockInvoiceAccountCodeDAOImpl)imAccountCodeDAO).numberOfTimesGetInvoiceAccountCodeList();
    assertEquals(1,numberOfTimesGetInvoiceAccountCalled);
  }

  public void testPrintClosedInvoices_NumberOfInvoicesIsFive() throws Exception {
    ErrorHandler errorHandler = new MockErrorHandler();
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO_ReturnsFiveInvoiceAccountCodes();
    IMAccountCodeDAO imAccountCodeDAO = new MockInvoiceAccountCodeDAOImpl();
    EmailService service = new MockEmailService();
    SAPVerificationService sapVerificationService = new MockSAPVerificationService();
    AccountCodeVerificationUpdateService accountCodeVerificationUpdateService =
        new MockAccountCodeVerificationUpdateService();
    IMAccountCodeSummaryService imAccountCodeSummaryService =
        new IMAccountCodeSummaryService(accountCodeVerificationDAO,imAccountCodeDAO,new InvoiceACInformation());

    BatchAccountCodeVerification codeVerification = new
        BatchAccountCodeVerificationImpl(accountCodeVerificationDAO,sapVerificationService,errorHandler,accountCodeVerificationUpdateService,
        service);
    IMBatchAccountCodeVerificationService imBatchAccountCodeVerificationService = new IMBatchInvoiceAccountCodeVerificationSercice(imAccountCodeSummaryService,errorHandler);

    imBatchAccountCodeVerificationService.printClosedInvoices();
    String message = ((MockErrorHandler) errorHandler).getMessage();
//    assertTrue(StringUtils.contains(message, "TRAN ID                 INVOICE NUMBER"));
//    assertTrue(StringUtils.contains(message, "= = = =                    = = = = = = = ="));
    assertTrue(StringUtils.contains(message, "Number of IAC Effected Recs = 5"));
  }

  class MockAccountCodeVerificationDAO_AutoClosedAccounts extends MockAccountCodeVerificationDAO{

    public AccountCodeList getAccountCodeList() {
      AccountCodeList accountCodeList = new AccountCodeList();
      accountCodeList.add(new AccountCode("1","1","BAD_COST","1", "SAP Code VALID as of: 03/21/2007 04:30", null, null,
          null,
          null));
      accountCodeList.add(new AccountCode("1","1","BAD_COST","1", "ACCOUNT AUTOCLOSED as of: 03/21/2007 (bad cc)", null,
          null, null, null));
      accountCodeList.add(new AccountCode("1","1","BAD_COST","1", "ACCOUNT AUTOCLOSED as of: 03/22/2007 (bad cc)", null,
          null, null, null));
      accountCodeList.add(new AccountCode("1","1","BAD_COST","1", "ACCOUNT AUTOCLOSED as of: 03/23/2007 (bad cc)", null,
          null, null, null));
      return accountCodeList;
    }

    public IMAccountCodeList getInvoiceAccountCodeList(String sapLinkNumber) {
      return null;
    }
  }

  class MockAccountCodeVerificationDAO_ReturnsZeroInvoiceAccountCodes implements AccountCodeVerificationDAO{

    public AccountCodeList getAccountCodeList() {
      return new AccountCodeList();
    }

    public AccountCode lookUpAccountCodeForSAPLinkNumber(String sapLinkNumber) {
      return null;
    }

    public AccountCodeList lookUpAccountCodesWithValues(AccountCode accountCode,
                                                        AccountCodeDaoQueryHelper accountCodeDaoQueryHelper) {
      return null;
    }

    public IMAccountCodeList getInvoiceAccountCodeList(String sapLinkNumber){
      return new IMAccountCodeList();
    }
  }

  class MockAccountCodeVerificationDAO_ReturnsFiveInvoiceAccountCodes implements AccountCodeVerificationDAO{

    public AccountCodeList getAccountCodeList() {
      TestData testData = new TestData();
      return testData.getAccountCodeList_WithOneAccountCode();
    }

    public AccountCode lookUpAccountCodeForSAPLinkNumber(String sapLinkNumber) {
      return null;
    }

    public AccountCodeList lookUpAccountCodesWithValues(AccountCode accountCode,
                                                        AccountCodeDaoQueryHelper accountCodeDaoQueryHelper) {
      return null;
    }

    public IMAccountCodeList getInvoiceAccountCodeList(String sapLinkNumber){
      TestData testData = new TestData();
      return testData.getInvoiceAccountCodeList();
    }

    public MatterAccountCode[] getMatterAccountCodeList() {
      return null;
    }
  }

  class MockBatchAccountCodeVerificationImpl extends BatchAccountCodeVerificationImpl{
    public MockBatchAccountCodeVerificationImpl(AccountCodeVerificationDAO accountCodeVerificationDAO, SAPVerificationService sapVerificationService, ErrorHandler errorHandler, AccountCodeVerificationUpdateService accountCodeVerificationUpdateService, EmailService service) {
      super(accountCodeVerificationDAO, sapVerificationService, errorHandler, accountCodeVerificationUpdateService, service);
    }

    protected void setAccountCodeSummaryService(SAPVerificationService sapVerificationService) {
      this.accountCodeSummaryService=new MockAccountCodeSummaryService(new MockSAPVerificationService());
    }


  }
}