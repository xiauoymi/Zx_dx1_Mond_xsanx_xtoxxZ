/*
 BatchMatterAccountCodeVerificationFactoryImpl_UT was created on Jun 4, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.*;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.check.ErrorHandlerImpl;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriterImpl;

/**
 * Filename:    $RCSfile: BatchMatterAccountCodeVerificationFactoryImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-06-04 18:17:56 $
 *
 * @author VRBETHI
 * @version $Revision: 1.3 $
 */
public class BatchMatterAccountCodeVerificationFactoryImpl_UT extends LMMSBaseTestCase {

  public void testCreateBatchMatterAccountCodeVerification() throws Exception {
    BatchMatterAccountCodeVerificationFactory batchAccountCodeVerificationFactory = new BatchMatterAccountCodeVerificationFactoryImpl();
    IMBatchAccountCodeVerificationService batchAccountCodeVerification =
        batchAccountCodeVerificationFactory.getBatchMatterAccountCodeVerificationInstance(
            new ErrorHandlerImpl(new ErrorReportWriterImpl(), LMMSConstants.BATCH_AC_SUMMARY_FILE_NAME));
    assertTrue(batchAccountCodeVerification instanceof IMBatchInvoiceAccountCodeVerificationSercice);
  }
}