/*
 InvoiceAccountCodeDAOImpl_UT was created on May 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import junit.framework.TestCase;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.*;
import com.monsanto.wst.lawmattermanagementsystem.resource.mock.MockFactoryReturnsExceptionThrowingConnectionManager;

/**
 * Filename:    $RCSfile: InvoiceAccountCodeDAOImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-31 19:40:38 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class InvoiceAccountCodeDAOImpl_UT extends TestCase {

  public void testCreateAccountCodeVerificationDAOImpl_ThrowsAccountCodeProcessingException_DueToResourceConnectionException() throws Exception {
    IMAccountCodeDAO verificationDAO = null;
    try {
      verificationDAO = new
          InvoiceAccountCodeDAOImpl(new MockFactoryReturnsExceptionThrowingConnectionManager());
      verificationDAO.getInvoiceAccountCodeList(null);
      fail("Account Code Exception shoule have been thrown");
    } catch (AccountCodeProcessingException e) {
      assertEquals("Error during retrieval of invoice account code",e.getMessage());
      e.printStackTrace();
    }
  }

  public void testCreateAccountCodeVerificationDAOImpl_ThrowsAccountCodeProcessingException_DueToWrappingException() throws Exception {
    IMAccountCodeDAO verificationDAO = null;
    try {
      verificationDAO = new
          InvoiceAccountCodeDAOImpl(new MockFactoryReturnsExceptionThrowingConnectionManager());
      verificationDAO.getInvoiceAccountCodeList(null);
      fail("Account Code Exception shoule have been thrown");
    } catch (AccountCodeProcessingException e) {
      assertEquals("Error during retrieval of invoice account code",e.getMessage());
      e.printStackTrace();
    }
  }

}