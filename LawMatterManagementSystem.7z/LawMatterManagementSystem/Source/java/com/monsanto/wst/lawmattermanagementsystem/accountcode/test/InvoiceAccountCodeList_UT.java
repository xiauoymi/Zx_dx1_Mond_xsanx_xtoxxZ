/*
 InvoiceAccountCodeList_UT was created on May 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.IMAccountCodeList;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: InvoiceAccountCodeList_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-31 19:06:22 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public class InvoiceAccountCodeList_UT extends TestCase {
  
  public void testAddAccountCodeList_PassANullInvoiceAcccountCodeList() throws Exception {
    IMAccountCodeList invoiceAccountCodeList = new IMAccountCodeList();
    invoiceAccountCodeList.add((IMAccountCodeList)null);
    int size = invoiceAccountCodeList.size();
    assertEquals(0,size);
  }
}