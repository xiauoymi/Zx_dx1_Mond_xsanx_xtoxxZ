/*
 InvoiceAccountCodeSummaryService_UT was created on May 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationDAO;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.IMAccountCodeDAO;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.IMAccountCodeSummaryService;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.InvoiceACInformation;
import com.monsanto.wst.lawmattermanagementsystem.check.ChecksProcessingMessage;
import junit.framework.TestCase;
import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: InvoiceAccountCodeSummaryService_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-01-12 16:04:25 $
 *
 * @author VRBETHI
 * @version $Revision: 1.12 $
 */
public class InvoiceAccountCodeSummaryService_UT extends TestCase {

  public void testSummarizeInvoiceAccountCodeService_CallToStringForEachInvoiceAccountCode() throws Exception {
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    IMAccountCodeDAO imAccountCodeDAO = new MockInvoiceAccountCodeDAOImpl();
    IMAccountCodeSummaryService IMAccountCodeSummaryService = new IMAccountCodeSummaryService(accountCodeVerificationDAO,
        imAccountCodeDAO,new InvoiceACInformation());
    ChecksProcessingMessage processingMessage = IMAccountCodeSummaryService.summarizeIMAccountCodeService();
    String outputString = processingMessage.getMessage();
    assertTrue(StringUtils.contains(outputString.trim(), "Number of IAC Effected Recs = 5"));
  }

  public void testSummarizeInvoiceAccountCodeService_CallGetInvoiceAccountCodeList_OnlyIfAccountCodeAreNotClosed() throws Exception {
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    IMAccountCodeDAO imAccountCodeDAO = new MockInvoiceAccountCodeDAOImpl();
    IMAccountCodeSummaryService IMAccountCodeSummaryService = new IMAccountCodeSummaryService(accountCodeVerificationDAO,
        imAccountCodeDAO,new InvoiceACInformation());
    ChecksProcessingMessage processingMessage = IMAccountCodeSummaryService.summarizeIMAccountCodeService();
    processingMessage.getMessage();
    int numberOfTimesGetInvoiceAccountCodeListCalled = ((MockInvoiceAccountCodeDAOImpl) imAccountCodeDAO)
        .numberOfTimesGetInvoiceAccountCodeList();
    assertEquals(1,numberOfTimesGetInvoiceAccountCodeListCalled);
  }
}