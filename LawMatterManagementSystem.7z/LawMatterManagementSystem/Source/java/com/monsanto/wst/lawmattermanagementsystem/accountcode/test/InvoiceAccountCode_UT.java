/*
 InvoiceAccountCode_UT was created on May 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.InvoiceAccountCode;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: InvoiceAccountCode_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-01-15 16:56:51 $
 *
 * @author VRBETHI
 * @version $Revision: 1.6 $
 */
public class InvoiceAccountCode_UT extends TestCase {

  public void testToString() throws Exception {
    InvoiceAccountCode invoiceAccountCode = new InvoiceAccountCode("COST_CENTER","COST_ELEMENT","BUSINESS","COMPANY","SAP_LINK_NUM","TRANS_ID","INV_NUM");
    String outputString = invoiceAccountCode.toString();
    assertEquals("TRANS_ID                   INV_NUM                         COMPANY-BUSINESS-COST_ELEMENT-COST_CENTER(Link No:  SAP_LINK_NUM)".trim(),outputString.trim());
  }
}