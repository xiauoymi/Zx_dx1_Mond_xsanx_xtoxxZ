/*
 MatterAccountCodeDAOImpl_AT was created on Jun 4, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.IMAccountCodeDAO;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.MatterAccountCodeDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.IMAccountCodeList;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;

/**
 * Filename:    $RCSfile: MatterAccountCodeDAOImpl_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-06-04 17:13:54 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class MatterAccountCodeDAOImpl_AT extends LMMSBaseTestCase {

  public void testGetInvoiceAccountCodeList_ReturnNotNullList() throws Exception {
    IMAccountCodeDAO imAccountCodeDAO = new MatterAccountCodeDAOImpl(new ResourceManagerFactoryImpl());
    IMAccountCodeList list = imAccountCodeDAO.getInvoiceAccountCodeList(null);
    assertNotNull(list);
  }
}