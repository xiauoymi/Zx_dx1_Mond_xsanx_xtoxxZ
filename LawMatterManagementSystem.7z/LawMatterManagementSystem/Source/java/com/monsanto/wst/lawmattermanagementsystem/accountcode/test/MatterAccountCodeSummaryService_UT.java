/*
 MatterAccountCodeSummaryService_UT was created on May 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.*;
import com.monsanto.wst.lawmattermanagementsystem.check.ChecksProcessingMessage;
import junit.framework.TestCase;
import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: MatterAccountCodeSummaryService_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-02-24 15:51:44 $
 *
 * @author VRBETHI
 * @version $Revision: 1.11 $
 */
public class MatterAccountCodeSummaryService_UT extends TestCase {

  public void testSummarizeMatterAccountCodeInformation_PrintAllMatterRetrieved() throws Exception {
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    IMAccountCodeDAO imAccountCodeDAO = new MockMatterAccountCodeDAOImpl();
    ACInformation acInformation = new MatterACInformation();

    IMAccountCodeSummaryService matterAccountCodeSummaryService = new IMAccountCodeSummaryService(accountCodeVerificationDAO,imAccountCodeDAO,acInformation);
    ChecksProcessingMessage processingMessage = matterAccountCodeSummaryService.summarizeIMAccountCodeService();
    assertTrue(StringUtils.contains(processingMessage.getMessage(),
        "5180-9110-41701900-SLA72052(Link No:  111)[Closed]"));
  }

  public void testSummarizeMatterAccountCodeInformation_PrintAllMatterRetrieved_CheckForHeaderInformation() throws Exception {
    AccountCodeVerificationDAO accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();
    IMAccountCodeDAO imAccountCodeDAO = new MockMatterAccountCodeDAOImpl();
    ACInformation acInformation = new MatterACInformation();
    IMAccountCodeSummaryService matterAccountCodeSummaryService =
        new IMAccountCodeSummaryService(accountCodeVerificationDAO,imAccountCodeDAO,acInformation);
    ChecksProcessingMessage processingMessage = matterAccountCodeSummaryService.summarizeIMAccountCodeService();
    assertTrue(StringUtils.contains(processingMessage.getMessage(),"Number of MC Effected Recs = 1"));
    assertTrue(StringUtils.contains(processingMessage.getMessage(),
        "5180-9110-41701900-SLA72052(Link No:  111)[Closed]"));
  }
}