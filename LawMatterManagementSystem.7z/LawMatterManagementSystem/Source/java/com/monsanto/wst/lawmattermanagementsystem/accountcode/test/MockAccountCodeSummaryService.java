/*
 MockAccountCodeSummaryService was created on Jul 31, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeSummaryService;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationService;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockAccountCodeSummaryService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-09-09 15:46:29 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class MockAccountCodeSummaryService extends AccountCodeSummaryService {
  public MockAccountCodeSummaryService(SAPVerificationService sapVerificationService) {
    super(sapVerificationService);
  }

  public List getChangedAccountCodeList() {
    List changedAccountCodeList = new ArrayList();
    return super.getChangedAccountCodeList();
  }

  public String getSummaryOfChangedAccountCodes() {
    return "1234 ACCOUNT AUTOCLOSED as of: 07/31/2008  (bad ce)";
  }
}