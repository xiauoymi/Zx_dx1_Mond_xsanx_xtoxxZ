/*
 MockAccountCodeVerificationDAO was created on May 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeList;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationDAO;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeDaoQueryHelper;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;

/**
 * Filename:    $RCSfile: MockAccountCodeVerificationDAO_MultipleCostCenters.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-13 20:30:27 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class MockAccountCodeVerificationDAO_MultipleCostCenters implements AccountCodeVerificationDAO {
  private boolean wasGetAccountCodeListCalled = false;
  private boolean wasLookUpAccountCodeWithValuesCalled = false;

  public AccountCodeList getAccountCodeList() {
    wasGetAccountCodeListCalled=true;
    AccountCodeList accountCodeList = new AccountCodeList();
    accountCodeList.add(new AccountCode("1","1","1","1", "ACCOUNT AUTOCLOSED", null, null, null, null));
    accountCodeList.add(new AccountCode("1","1","1","1", "", null, null, null, null));
    return accountCodeList;
  }

  public AccountCode lookUpAccountCodeForSAPLinkNumber(String sapLinkNumber) {
    if(sapLinkNumber!=null && (sapLinkNumber.equalsIgnoreCase("1366") || sapLinkNumber.equalsIgnoreCase("1364") )){
      return new AccountCode("1","1","1","MTL74155", "ACCOUNT AUTOCLOSED", null, null, null, null);
    }
    if(sapLinkNumber==null){
      return null;
    }
    return new AccountCode("1","1","1","", "ACCOUNT AUTOCLOSED", null, null, null, null);
  }

  public AccountCodeList lookUpAccountCodesWithValues(AccountCode accountCode,
                                                      AccountCodeDaoQueryHelper accountCodeDaoQueryHelper) {
    wasLookUpAccountCodeWithValuesCalled=true;
    AccountCodeList accountCodeList = new AccountCodeList();
    accountCodeList.add(new AccountCode("1","1","1","1", "ACCOUNT AUTOCLOSED", null, null, null, null));
    accountCodeList.add(new AccountCode("1","1","1","1", "ACCOUNT AUTOCLOSED", null, null, null, null));
    return accountCodeList;
  }

  public boolean wasGetAccountCodeListCalled() {
    return wasGetAccountCodeListCalled;
  }

  public boolean wasLookUPAccountCodesWithValuesCalled() {
    return wasLookUpAccountCodeWithValuesCalled;
  }
}