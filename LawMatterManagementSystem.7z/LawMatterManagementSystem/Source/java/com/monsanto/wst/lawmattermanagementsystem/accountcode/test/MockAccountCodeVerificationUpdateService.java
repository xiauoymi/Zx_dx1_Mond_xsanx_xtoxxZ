/*
 MockAccountCodeVerificationUpdateService was created on May 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeList;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationUpdateService;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;

/**
 * Filename:    $RCSfile: MockAccountCodeVerificationUpdateService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-23 18:10:16 $
 *
 * @author VRBETHI
 * @version $Revision: 1.4 $
 */
public class MockAccountCodeVerificationUpdateService implements AccountCodeVerificationUpdateService {
  private boolean wasUpdateServiceCalled = false;
  private boolean wasUpdateAccountCodeInTeamConnectCalled = false;

  public void updateAccountCodes(AccountCodeList accountCodeList) throws ServiceException {
    wasUpdateServiceCalled=true;
  }

  public boolean updateAccountCodeInTeamConnect(AccountCode code) {
    wasUpdateAccountCodeInTeamConnectCalled=true;
    return wasUpdateAccountCodeInTeamConnectCalled;
  }

  public boolean updateAccountNewCodeInTeamConnect(AccountCode code) {
    return false;
  }

  public boolean updateAccountEditCodeInTeamConnect(AccountCode code) {
    return false;
  }

  public boolean wasUpdateServiceCalled() {
    return wasUpdateServiceCalled;
  }

  public boolean isWasUpdateAccountCodeInTeamConnectCalled() {
    return wasUpdateAccountCodeInTeamConnectCalled;
  }
}