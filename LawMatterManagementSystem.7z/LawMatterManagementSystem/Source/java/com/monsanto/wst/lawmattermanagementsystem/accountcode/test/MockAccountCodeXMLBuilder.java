/*
 MockAccountCodeXMLBuilder was created on May 21, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.check.Check;
import com.monsanto.wst.lawmattermanagementsystem.check.XMLBuilder;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.voids.VoidCheck;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentMetaData;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: MockAccountCodeXMLBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-02-10 19:48:04 $
 *
 * @author VRBETHI
 * @version $Revision: 1.8 $
 */
public class MockAccountCodeXMLBuilder implements XMLBuilder {
  private boolean wasBuildUpdateAccountCode = false;
  private int numberOfTimesBuilderCalled = 0;

  public Document buildUpdateCheckXML(Check check) {
    return null;
  }

  public Document buildRetrieveChecksXML(Check check) {
    return null;
  }

  public Document buildRetrieveVoidCheckXML(VoidCheck voidCheck) {
    return null;
  }

  public Document buildRetreiveTransactionXML(Check check) {
    return null;
  }

  public Document buildUpdateVoidCheckXML(VoidCheck voidCheck, Check check) {
    return null;
  }

  public Document buildUpdateAccountCodeXML(AccountCode accountCode) {
    numberOfTimesBuilderCalled++;
    wasBuildUpdateAccountCode=true;
    return null;
  }

  public Document buildUpdateDocumentXML(DocumentMetaData documentMetaData) {
    return null;
  }

  public Document buildCloseAccountCodeUpdateAccountCodeXML(AccountCode accountCode, String autoClosedString,
                                                            String closedString) {
    return null;
  }

  public Document buildEditAccountCodeUpdateAccountCodeXML(AccountCode accountCode, String autoClosedString,
                                                           String autoClosedDate) {
    return null;
  }

  public Document buildOpenAccountCodeUpdateAccountCodeXML(AccountCode accountCode, String autoClosedString,
                                                           String autoClosedDate) {
    return null;
  }

  public Document buildInvoiceAcknowledgementXML(InvoiceRecord invoiceRecord) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Document buildUpdateCheckXMLWithPrimaryKey(Check check, String s) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  //New Method added for Updating Voids associated to checks and those cheks having multiple invoice ids in them
  public Document buildUpdateVoidCheckXMLWithPrimaryKey(VoidCheck voidCheck, String invoiceIdPK) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public boolean wasBuildUpdateAccountCodeCalled() {
    return wasBuildUpdateAccountCode;
  }

  public int numberOfTimesBuilderCalled() {
    return numberOfTimesBuilderCalled;
  }
}