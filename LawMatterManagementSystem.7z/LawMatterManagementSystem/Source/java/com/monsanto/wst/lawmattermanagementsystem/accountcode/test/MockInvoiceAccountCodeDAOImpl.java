/*
 MockInvoiceAccountCodeDAOImpl was created on May 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.IMAccountCodeDAO;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.IMAccountCodeList;
import com.monsanto.wst.lawmattermanagementsystem.check.test.TestData;

/**
 * Filename:    $RCSfile: MockInvoiceAccountCodeDAOImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-31 19:43:19 $
 *
 * @author VRBETHI
 * @version $Revision: 1.3 $
 */
public class MockInvoiceAccountCodeDAOImpl implements IMAccountCodeDAO {
  private int numberOfTimesGetInvoiceAccountCodeListCalled=0;

  public IMAccountCodeList getInvoiceAccountCodeList(String sapLinkNumber) {
    numberOfTimesGetInvoiceAccountCodeListCalled++;
    TestData testData = new TestData();
    return testData.getInvoiceAccountCodeList();
  }

  public int numberOfTimesGetInvoiceAccountCodeList() {
    return numberOfTimesGetInvoiceAccountCodeListCalled;
  }
}