/*
 MockMatterAccountCodeDAOImpl was created on May 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.IMAccountCodeDAO;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.IMAccountCodeList;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.MatterAccountCode;

/**
 * Filename:    $RCSfile: MockMatterAccountCodeDAOImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-01-15 16:56:51 $
 *
 * @author VRBETHI
 * @version $Revision: 1.5 $
 */
public class MockMatterAccountCodeDAOImpl implements IMAccountCodeDAO {
  public IMAccountCodeList getInvoiceAccountCodeList(String sapLinkNumber) {
    IMAccountCodeList imAccountCodeList = new IMAccountCodeList();
    MatterAccountCode matterAccountCode = new MatterAccountCode("1997-000168","Project Crystal","5180","9110","41701900","SLA72052","111");
    imAccountCodeList.add(matterAccountCode);
    return imAccountCodeList;
  }
}