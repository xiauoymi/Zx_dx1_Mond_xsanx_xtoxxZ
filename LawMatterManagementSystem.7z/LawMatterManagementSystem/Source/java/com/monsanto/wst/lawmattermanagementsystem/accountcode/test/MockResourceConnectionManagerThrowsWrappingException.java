/*
 MockResourceConnectionManagerThrowsWrappingException was created on May 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.accountcode.test;

import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.dataservices.Test.MockPersistentStoreConnThrowsWrappingException;

/**
 * Filename:    $RCSfile: MockResourceConnectionManagerThrowsWrappingException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-31 19:31:35 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class MockResourceConnectionManagerThrowsWrappingException implements ResourceConnectionManager {
  public Object getConnection(String databaseNameOrRemoteSubDir) throws ResourceConnectionException {
    return new MockPersistentStoreConnThrowsWrappingException();
  }
}