/*
 BaseCheck was created on Feb 18, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

/**
 * Filename:    $RCSfile: BaseCheck.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-18 22:09:30 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class BaseCheck {
  protected String checkNumber;

  public String getCheckNumber() {
    return checkNumber;
  }
}