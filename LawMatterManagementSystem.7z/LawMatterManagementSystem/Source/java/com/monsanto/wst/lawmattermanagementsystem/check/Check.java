/*
 Check was created on Feb 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile: Check.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 16:11:20 $
 *
 * @author VRBETHI
 * @version $Revision: 1.19 $
 */
public class Check extends BaseCheck{

  private String invoiceNumber;
  private String invoiceDate;
  private String vendorId;
  private String wireIndicator;
  private String bankId;
  private String teamConnectCheckDate;
  private String checkDate;
  private String requestNumber;
  private String invoiceAmount;
  private String transactionId;
  private Set transactionMap;

  public Check(String invoiceNumber, String invoiceDate, String vendorId, String wireIndicator,
               String bankId, String checkDate, String checkNumber, String requestNumber, String invoiceAmount,
               String transactionId, String teamConnectCheckDate) {
    setInvoiceNumber(invoiceNumber);
    this.invoiceDate = invoiceDate;
    this.vendorId = vendorId;
    this.wireIndicator = wireIndicator;
    this.bankId = bankId;
    this.teamConnectCheckDate = teamConnectCheckDate;
    setCheckDate(checkDate);
    this.checkNumber = checkNumber;
    this.requestNumber = requestNumber;
    this.invoiceAmount = invoiceAmount;
    this.transactionId = transactionId;
    transactionMap = new HashSet();
  }

  private void setInvoiceNumber(String invoiceNumber) {
    if(invoiceNumber==null){
      this.invoiceNumber="";
    }else{
      this.invoiceNumber = invoiceNumber.trim();
    }
  }

  private void setCheckDate(String checkDate) {
    if(checkDate==null){
      throw new ChecksVoidsProcessingException("Check Date Cannot be null", new Exception());
    }
    if(checkDate.length()!=8){
      throw new ChecksVoidsProcessingException("Invalid Check Date :"+checkDate, new Exception());
    }
    this.checkDate = checkDate;
  }

  public String getInvoiceNumber() {
    return invoiceNumber;
  }

  public String getInvoiceDate() {
    return invoiceDate;
  }

  public Object getVendorId() {
    return vendorId;
  }

  public String getWireIndicator() {
    return wireIndicator;
  }

  public String getBankId() {
    return bankId;
  }

  public String getCheckDate() {
    return checkDate;
  }

  public String getRequestNumber() {
    return requestNumber;
  }

  public String getInvoiceAmount() {
    return invoiceAmount;
  }

  /**
   * Return true if check is Identical
   * @param checkIn
   * @return
   */
  public boolean isIdentical(Check checkIn) {
    if (isWireTransferNotIdentical(checkIn) || isCheckNotIdentical(checkIn)) return false;
    return true;
  }

  private boolean isWireTransferNotIdentical(Check checkIn) {
    if(isWireTransfer()){
      if(isBankNameNotSame(checkIn)){
        return true;
      }
    }
    return false;
  }

  private boolean isCheckNotIdentical(Check checkIn) {
    if(isCheck()){
      if(isCheckNumberNotSame(checkIn) || isCheckDateNotSame(checkIn) || isBankNameNotSame(checkIn)){
        return true;
      }
    }
    return false;
  }

  private boolean isWireTransfer() {
    return wireIndicator.equalsIgnoreCase("X") || wireIndicator.equalsIgnoreCase("N");
  }

  private boolean isCheck() {
    return wireIndicator.equalsIgnoreCase("C");
  }

  private boolean isCheckNumberNotSame(Check checkIn) {
    return !checkNumber.equalsIgnoreCase(checkIn.getCheckNumber());
  }

  private boolean isCheckDateNotSame(Check checkIn) {
    return !checkDate.equalsIgnoreCase(checkIn.getCheckDate());
  }

  private boolean isBankNameNotSame(Check checkIn) {
    return !bankId.equalsIgnoreCase(checkIn.getBankId());
  }

  public String getTransactionId() {
    return transactionId;
  }


  public String getTeamConnectCheckDate() {
    return teamConnectCheckDate;
  }

  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Check Number    :").append(checkNumber);
    stringBuffer.append("\n");
    stringBuffer.append("Check Date      :").append(checkDate);
    stringBuffer.append("\n");
    stringBuffer.append("Invoice Number  :").append(invoiceNumber);
    stringBuffer.append("\n");
    stringBuffer.append("Invoice Date      :").append(invoiceDate);
    stringBuffer.append("\n");
    return stringBuffer.toString();
  }

  public String getFormattedInvoiceDate() {
// String sendAPDateString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(sendAPDate);
    StringBuffer stringBuffer = new StringBuffer();
    String month = invoiceDate.substring(0,2);
    String day = invoiceDate.substring(3,5);
    String year = invoiceDate.substring(6,10);
//    stringBuffer.append(year);
//    stringBuffer.append("-");
//    stringBuffer.append(month);
//    stringBuffer.append("-");
//    stringBuffer.append(day);
//    stringBuffer.append(" ");
//    stringBuffer.append("06:00:00");
    stringBuffer.append(month).append('/').append(day).append('/').append(year);
    return stringBuffer.toString();
  }


  public void setTransactionId(String transactionIdIn) {
    this.transactionId = transactionIdIn;
  }


  public String getFormattedCheckDate() {
    StringBuffer stringBuffer = new StringBuffer();
    String year = checkDate.substring(0,4);
    String month = checkDate.substring(4,6);
    String day = checkDate.substring(6,8);
    stringBuffer.append(year);
    stringBuffer.append("-");
    stringBuffer.append(month);
    stringBuffer.append("-");
    stringBuffer.append(day);
    return stringBuffer.toString();
  }

  public int getNumberOfTransactions() {
    return transactionMap.size();
  }

  public void addTransaction(String transactionIdIn) {
    transactionMap.add(transactionIdIn);
  }
}