/*
 CheckList was created on Feb 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: CheckList.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-11 22:35:11 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class CheckList {
  List checkList = new ArrayList();
  public long size() {
    return checkList.size();
  }

  public void addCheck(Check check) {
    checkList.add(check);
  }

  public Check getCheck(int i) {
    return (Check) checkList.get(i);
  }
}