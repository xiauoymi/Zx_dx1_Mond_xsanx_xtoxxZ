/*
ChecksDAOImpl was created on Feb 8, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;

/**
 * Filename:    $RCSfile: ChecksDAOFileImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-08-22 14:41:23 $
 *
 * @author VRBETHI
 * @version $Revision: 1.8 $
 */
public class ChecksDAOFileImpl implements ChecksDAO {
  private String fileName;

  public ChecksDAOFileImpl(String fileName) {
    this.fileName = fileName;
  }

  public CheckList retrieveChecks(){
    CheckList checkList = new CheckList();
    String lineRead="";
    BufferedReader in = null;
    try {
      in = new BufferedReader(new FileReader(fileName));
      lineRead = in.readLine();
      while (lineRead != null) {
        Check check = createCheck(lineRead);
        checkList.addCheck(check);
        lineRead = in.readLine();
      }
    }catch (FileNotFoundException e){
      //do nothing : if file is not found just return an empty check list
    }
    catch (IOException e) {
      throw new ChecksVoidsProcessingException("Exception during processing of checks. File Not found "+fileName,e);
    }
    return checkList;
  }

  private Check createCheck(String lineRead) {
    StringBuffer stringBuffer = new StringBuffer();
    String requestNumber = lineRead.substring(49,59);
    String datestring = lineRead.substring(65,67);
    String monthString = lineRead.substring(67,69);
    String yearString = lineRead.substring(61,65);
    String vendorId = lineRead.substring(8,14);
    String invoiceDate = stringBuffer.append(datestring).append("/").append(monthString).append("/").append(yearString).toString();
    String invoiceNumber= lineRead.substring(77,93);
    String wireIndicator = lineRead.substring(164,165);
    String bankId = lineRead.substring(226,230);
    String checkDate = lineRead.substring(218,226);
    String checkNumber = lineRead.substring(205,218);
    String invoiceAmount = lineRead.substring(97,117);
    Check check = new Check(invoiceNumber, invoiceDate, vendorId, wireIndicator, bankId, checkDate,
      checkNumber, requestNumber, invoiceAmount, "transactionId", null);
    return check;
  }
}