/*
 ChecksProcessingMessage was created on Mar 6, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

/**
 * Filename:    $RCSfile: ChecksProcessingMessage.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-03-06 20:18:20 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class ChecksProcessingMessage {
  private String message;

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }
}