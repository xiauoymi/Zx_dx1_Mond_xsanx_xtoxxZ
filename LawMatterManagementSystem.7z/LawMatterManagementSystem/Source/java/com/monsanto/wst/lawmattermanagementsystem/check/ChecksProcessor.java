/*
ChecksProcessor was created on Feb 8, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPService;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;


/**
 * Filename:    $RCSfile: ChecksProcessor.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-02-10 19:04:50 $
 *
 * @author VRBETHI
 * @version $Revision: 1.32 $
 */
public class ChecksProcessor {
  private TransactionDAO transactionDAO;
  private ChecksService checksService;
  private ErrorHandler errorHandler;
  private CheckListRetriever checkListRetriever;

  public ChecksProcessor(ChecksDAO checksDAO, TransactionDAO transactionDAO, ChecksService checksService,
                         ErrorHandler errorHandler, FTPService ftpService) {
    this.transactionDAO = transactionDAO;
    this.checksService = checksService;
    this.errorHandler = errorHandler;
    this.checkListRetriever = new FTPCheckListRetrieverImpl(checksDAO,ftpService);
  }

  public boolean processChecks() throws ServiceException {
    CheckList checkList = null;
    checkList = checkListRetriever.retrieveCheckList();
    for(int i=0;i<checkList.size();i++){
      Check check = checkList.getCheck(i);
      processCheck(check);
    }
    errorHandler.closeResources();
    return true;
  }
  private void processCheck(Check check) throws ServiceException {
    int numberOfTransactionIds;
    ChecksProcessingMessage checksProcessingMessage = new ChecksProcessingMessage();
    numberOfTransactionIds = getNumberOfTransactionsForCheck(check);
    if(doesEachCheckHaveOnlyOneTransactionId(numberOfTransactionIds)){
      checksProcessingMessage = checksService.processCheck(check);
    }else{
      checksProcessingMessage.setMessage(getErrorMessage(numberOfTransactionIds, check));
    }
    errorHandler.handleError(checksProcessingMessage);
  }

  private String getErrorMessage(int numberOfTransactionIds,
                                 Check check) {
    StringBuffer message = new StringBuffer();
    if(numberOfTransactionIds==0){
      message.append("Error processing payment file - Invoice on Check or Wire Transfer could NOT be found in ISUM :");
    }else{
      message.append("Error processing payment file - Multiple Invoices found in ISUM for:");
    }
    message.append("\nInvoice Num : ");
    message.append(check.getInvoiceNumber());
    message.append(" ; SAP Vendor Id : ");
    message.append(check.getVendorId());
    return message.toString();
  }

  private boolean doesEachCheckHaveOnlyOneTransactionId(int numberOfTransactionIds) {
    return numberOfTransactionIds==1;
  }

  private int getNumberOfTransactionsForCheck(Check check){
    transactionDAO.retrieveTransaction(check);
    return check.getNumberOfTransactions();
  }
}