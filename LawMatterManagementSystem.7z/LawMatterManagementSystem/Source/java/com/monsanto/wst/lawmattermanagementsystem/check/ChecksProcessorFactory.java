/*
 ChecksProcessorFactory was created on May 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

/**
 * Filename:    $RCSfile: ChecksProcessorFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-16 16:01:52 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public interface ChecksProcessorFactory {
  ChecksProcessor getChecksProcessorInstance() throws ServiceException;
}