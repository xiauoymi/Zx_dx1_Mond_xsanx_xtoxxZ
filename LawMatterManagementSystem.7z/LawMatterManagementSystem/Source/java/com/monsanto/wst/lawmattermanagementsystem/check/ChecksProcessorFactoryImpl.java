/*
 ChecksProcessorFactoryImpl was created on May 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPService;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPServiceImpl;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactory;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriterImpl;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;

/**
 * Filename:    $RCSfile: ChecksProcessorFactoryImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-16 16:01:52 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class ChecksProcessorFactoryImpl implements ChecksProcessorFactory {
  public ChecksProcessor getChecksProcessorInstance() throws ServiceException {
    FTPService ftpService = new FTPServiceImpl(new ResourceManagerFactoryImpl());
    ChecksDAO checksDAO = new
      ChecksDAOFileImpl(LMMSConstants.FILE_NAME_INPUT_CHECKS);
    ResourceManagerFactory resourceManagerFactory = new ResourceManagerFactoryImpl();
    ResourceConnectionManager connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
    TransactionDAO transactionDAO = new TransactionDAOImpl(connectionManager);
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    ResultsProcessor resultsProcessor = new ResultsProcessorImpl();
    TeamConnectCheckDAO teamConnectCheckDAO = new
      TeamConnectCheckDAOImpl(new HttpClient(),new PostMethod(System.getProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL)));
    ChecksService checksService = new TeamConnectCheckServiceImpl(xmlBuilder, new XMLCheckParser(),
      teamConnectCheckDAO, new CheckValidator(), resultsProcessor);
    return new ChecksProcessor(checksDAO, transactionDAO, checksService, new ErrorHandlerImpl(new ErrorReportWriterImpl(),
        LMMSConstants.CHECK_ERROR_FILE_NAME), ftpService);
  }
}