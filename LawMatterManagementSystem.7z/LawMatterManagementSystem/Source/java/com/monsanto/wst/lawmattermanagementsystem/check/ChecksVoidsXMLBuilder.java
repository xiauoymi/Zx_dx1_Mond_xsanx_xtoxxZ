/*
ChecksXMLBuilder was created on Feb 9, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.lawmattermanagementsystem.voids.VoidCheck;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.config.ConfigReader;
import com.monsanto.wst.lawmattermanagementsystem.config.model.ConnectionParams;
import com.monsanto.wst.lawmattermanagementsystem.config.xstream.ConfigReaderXStreamImpl;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentMetaData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: ChecksVoidsXMLBuilder.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-02-10 19:05:56 $
 *
 * @author vrbethi
 * @version $Revision: 1.25 $
 */
//TODO Refactor and rename class
public class ChecksVoidsXMLBuilder implements XMLBuilder {

  public Document buildUpdateCheckXML(Check check) {
    Document document = DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element invoiceElement = addInvoiceHeaderInformation(teamConnectRequest, check);
    //todo replace this with a strategy and eliminate the next method
    addDetailCheckInformation(invoiceElement,check);
    return document;
  }

  /**
   * Method to build the XML structure to update invoices based on PK 
   * @param check
   * @param invoiceIdPK
   * @return
   */
  public Document buildUpdateCheckXMLWithPrimaryKey(Check check, String invoiceIdPK) {
    Document document = DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element invoiceElement = addInvoiceHeaderInformationWithPrimaryKey(teamConnectRequest, invoiceIdPK);
    addDetailCheckInformation(invoiceElement,check);
    return document;
  }
  
  //todo Get Rid of this method after doing the above refactoring
  public Document buildUpdateVoidCheckXML(VoidCheck voidCheck, Check check) {
    Document document = DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element invoiceElement = addInvoiceHeaderInformation(teamConnectRequest, check);
    addDetailVoidInformation(invoiceElement,voidCheck);
    return document;
  }

  public Document buildUpdateVoidCheckXMLWithPrimaryKey(VoidCheck voidCheck, String invoiceIdPK) {
    Document document = DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element invoiceElement = addInvoiceHeaderInformationWithPrimaryKey(teamConnectRequest, invoiceIdPK);
    addDetailVoidInformation(invoiceElement,voidCheck);
    return document;
  }

  public Document buildUpdateAccountCodeXML(AccountCode accountCode) {
    Document document= DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element invoiceElement = addAccountCodeHeaderInformation(teamConnectRequest, accountCode);
    //todo replace this with a strategy and eliminate the next method
    addDetailAccountCodeInformation(invoiceElement,accountCode);
    return document;
  }

  public Document buildUpdateDocumentXML(DocumentMetaData documentMetaData) {
    Document document= DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element invoiceElement = addDocumentHeaderInformation(teamConnectRequest, documentMetaData);
//    //todo replace this with a strategy and eliminate the next method
    addDetailDocumentInformation(invoiceElement,documentMetaData);
    return document;

  }

  public Document buildCloseAccountCodeUpdateAccountCodeXML(AccountCode accountCode, String autoClosedString,
                                                            String autoCloseDate) {
    Document document= DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element costCenterElement = addAccountCodeHeaderInformation(teamConnectRequest, accountCode);
    //todo replace this with a strategy and eliminate the next method
//    addDetailAccountCodeInformation(invoiceElement,accountCode);
    addDetailCloseAccountCodeInformation(costCenterElement,accountCode,autoClosedString, autoCloseDate);
    return document;
  }

  public Document buildEditAccountCodeUpdateAccountCodeXML(AccountCode accountCode, String autoClosedString,
                                                           String autoClosedDate) {
    Document document= DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element costCenterElement = addAccountCodeHeaderInformation(teamConnectRequest, accountCode);
    //todo replace this with a strategy and eliminate the next method
//    addDetailAccountCodeInformation(invoiceElement,accountCode);
    addDetailEditAccountCodeInformation(costCenterElement,accountCode, autoClosedDate);
    return document;
  }

  public Document buildOpenAccountCodeUpdateAccountCodeXML(AccountCode accountCode, String autoClosedString,
                                                           String autoClosedDate) {
    Document document= DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element invoiceElement = addAccountCodeHeaderInformation(teamConnectRequest, accountCode);
    //todo replace this with a strategy and eliminate the next method
//    addDetailAccountCodeInformation(invoiceElement,accountCode);
    addDetailOpenAccountCodeInformation(invoiceElement,accountCode,autoClosedString, autoClosedDate);
    return document;
  }

  public Document buildInvoiceAcknowledgementXML(InvoiceRecord invoiceRecord) {
    Document document = DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element invoiceElement = addInvoiceHeaderInformationForInvoiceAcknowledgement(teamConnectRequest, invoiceRecord);
    addDetailCheckInformationForInvoiceAcknowledgement(invoiceElement,invoiceRecord);
    return document;
  }

  private void addDetailCheckInformationForInvoiceAcknowledgement(Element invoiceElement, InvoiceRecord invoiceRecord) {
    Element invoiceDetail = DOMUtil.addChildElement(invoiceElement,"Detail");
    DOMUtil.setAttribute(invoiceDetail,"key","INVC");
    DOMUtil.addChildElement(invoiceDetail,"InSentSAP",invoiceRecord.getInvoiceSummary().getInvoiceAcknowledged());
  }

  private Element addInvoiceHeaderInformationForInvoiceAcknowledgement(Element teamConnectRequest, InvoiceRecord invoiceRecord) {
    Element invoiceElement = DOMUtil.addChildElement(teamConnectRequest,"Invoice");
    DOMUtil.setAttribute(invoiceElement,"op","update");
    DOMUtil.setAttribute(invoiceElement,"primaryKey",invoiceRecord.getInvoiceSummary().getInvoicePrimaryKey());
    return invoiceElement;
  }

  private void addDetailDocumentInformation(Element projectElement, DocumentMetaData documentMetaData) {
    DOMUtil.addChildElement(projectElement,"Application","DOCS");
    Element parentElement = DOMUtil.addChildElement(projectElement, "Parent", documentMetaData.getClp_no());
    DOMUtil.setAttribute(parentElement,"keymap","NumberString");
    DOMUtil.addChildElement(projectElement, "Name", documentMetaData.getObject_name());
    Element detailElement = DOMUtil.addChildElement(projectElement, "Detail");
    detailElement.setAttribute("key","DOCS");
    DOMUtil.addChildElement(detailElement,"DocCreatedBy",documentMetaData.getR_creator_name());
    DOMUtil.addChildElement(detailElement,"DocCreatedDate",documentMetaData.getR_creation_date());
    DOMUtil.addChildElement(detailElement,"DocDocType",documentMetaData.getDocumentType());
    DOMUtil.addChildElement(detailElement,"DocumentName",documentMetaData.getObject_name());
    DOMUtil.addChildElement(detailElement,"POSObjectId",documentMetaData.getI_chronicle_id());
//    Element invoiceElement = DOMUtil.addChildElement(searchResultsElement,"Invoice");
//
//    addElementWithSelectAttribute(invoiceElement, "InvoiceNumber", "NumberString");
//
//    Element detailElement = addElementWithSelectAttribute(invoiceElement, "Detail", "Detail[INVC]");
//
//    addElementWithSelectAttribute(detailElement, "TransactionId", "DetailValue[InTransID]");
//    addElementWithSelectAttribute(detailElement, "BankId", "DetailValue[InBankId]");
//    addElementWithSelectAttribute(detailElement, "CheckDate", "DetailValue[InCheckDate]");
//    addElementWithSelectAttribute(detailElement, "CheckNumber", "DetailValue[InCheckNum]");
//    addElementWithSelectAttribute(detailElement, "CheckAmount", "DetailValue[InCheckAmount]");
  }

  private Element addDocumentHeaderInformation(Element teamConnectRequest, DocumentMetaData documentMetaData) {
    Element invoiceElement = DOMUtil.addChildElement(teamConnectRequest,"Project");
    DOMUtil.setAttribute(invoiceElement,"op","insert");
    return invoiceElement;

  }

  private Element addAccountCodeHeaderInformation(Element teamConnectRequest, AccountCode accountCode) {
    Element costCenterElement = DOMUtil.addChildElement(teamConnectRequest,"Project");
    DOMUtil.setAttribute(costCenterElement,"Application", "COST");
    DOMUtil.setAttribute(costCenterElement,"NumberString", accountCode.getSapLinkNumber());
    DOMUtil.setAttribute(costCenterElement,"op","update");
    return costCenterElement;
  }

  public Document buildRetrieveChecksXML(Check check) {
    Document document = DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element searchElement = addSearchElement(teamConnectRequest);
    //todo replace this with a strategy and eliminate duplication
    addCheckQueryCriteira(searchElement,check);
    addCheckRequestedInforamtion(searchElement);
    return document;
  }

  //todo get rid of this after completing above refactoring
  public Document buildRetrieveVoidCheckXML(VoidCheck voidCheck) {
    Document document = DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element searchElement = addSearchElement(teamConnectRequest);
    addVoidQueryCriteira(searchElement,voidCheck);
    addCheckRequestedInforamtion(searchElement);
    return document;
  }

  //todo get rid of this after completing above refactoring
  public Document buildRetreiveTransactionXML(Check check) {
    Document document = DOMUtil.newDocument();
    Element teamConnectRequest = addTeamConnectHeaderInformation(document);
    Element searchElement = addSearchElement(teamConnectRequest);
    addTransactionQueryCriteira(searchElement,check);
    addCheckRequestedInforamtion(searchElement);
    return document;
  }

  private void addDetailVoidInformation(Element invoiceElement, VoidCheck voidCheck) {
    Element invoiceDetail = DOMUtil.addChildElement(invoiceElement,"Detail");
    DOMUtil.setAttribute(invoiceDetail,"key","INVC");
    DOMUtil.addChildElement(invoiceDetail,"InVoidCode",voidCheck.getVoidCode());
    DOMUtil.addChildElement(invoiceDetail,"InVoidCheckNumber",voidCheck.getCheckNumber());
    DOMUtil.addChildElement(invoiceDetail,"InVoidDate",voidCheck.getFormattedVoidDate());
  }

  private void addVoidQueryCriteira(Element searchElement, VoidCheck voidCheck) {
    Element queryElement = DOMUtil.addChildElement(searchElement,"Query");
    DOMUtil.addChildElement(queryElement,"Entity","Invoice");
    Element criteriaElement = DOMUtil.addChildElement(queryElement,"Criteria");
    Element andElement = DOMUtil.addChildElement(criteriaElement,"And");
    Element detailElement = DOMUtil.addChildElement(andElement,"Detail.INVC.InCheckNum",voidCheck.getCheckNumber());
    DOMUtil.setAttribute(detailElement,"is","equals");
  }

  private Element addSearchElement(Element teamConnectRequest) {
    return DOMUtil.addChildElement(teamConnectRequest,"Search");
  }

  private void addCheckRequestedInforamtion(Element searchElement) {
    Element searchResultsElement = DOMUtil.addChildElement(searchElement,"SearchResults");
    Element invoiceElement = DOMUtil.addChildElement(searchResultsElement,"Invoice");

    addElementWithSelectAttribute(invoiceElement, "InvoiceNumber", "NumberString");

    Element detailElement = addElementWithSelectAttribute(invoiceElement, "Detail", "Detail[INVC]");

    addElementWithSelectAttribute(detailElement, "TransactionId", "DetailValue[InTransID]");
    addElementWithSelectAttribute(detailElement, "BankId", "DetailValue[InBankId]");
    addElementWithSelectAttribute(detailElement, "CheckDate", "DetailValue[InCheckDate]");
    addElementWithSelectAttribute(detailElement, "CheckNumber", "DetailValue[InCheckNum]");
    addElementWithSelectAttribute(detailElement, "CheckAmount", "DetailValue[InCheckAmount]");
  }

  private Element addElementWithSelectAttribute(Element detailElement, String elementName, String selectAttribute) {
    Element transactionIdElement = DOMUtil.addChildElement(detailElement,elementName);
    DOMUtil.setAttribute(transactionIdElement,"select",selectAttribute);
    return transactionIdElement;
  }

  private void addCheckQueryCriteira(Element searchElement, Check check) {
    Element queryElement = DOMUtil.addChildElement(searchElement,"Query");
    DOMUtil.addChildElement(queryElement,"Entity","Invoice");
    Element criteriaElement = DOMUtil.addChildElement(queryElement,"Criteria");
    Element andElement = DOMUtil.addChildElement(criteriaElement,"And");
    Element detailElement = DOMUtil.addChildElement(andElement,"Detail.INVC.InTransID",check.getTransactionId());
    DOMUtil.setAttribute(detailElement,"is","equals");

  }

  private void addTransactionQueryCriteira(Element searchElement, Check check) {
    Element queryElement = DOMUtil.addChildElement(searchElement,"Query");
    DOMUtil.addChildElement(queryElement,"Entity","Invoice");
    Element criteriaElement = DOMUtil.addChildElement(queryElement,"Criteria");
    Element andElement = DOMUtil.addChildElement(criteriaElement,"And");
    Element detailElement = DOMUtil.addChildElement(andElement,"Detail.INVC.InTransID",check.getTransactionId());
    DOMUtil.setAttribute(detailElement,"is","equals");

  }

  private Element addTeamConnectHeaderInformation(Document document) {
    Element teamConnectRequest = addTeamConnectRequestElement(document);
    addAuthenticationInformation(teamConnectRequest);
    return teamConnectRequest;
  }

  private Element addTeamConnectRequestElement(Document document) {
    return DOMUtil.addChildElement(document,"TeamConnectRequest");
  }

  private Element addInvoiceHeaderInformation(Element teamConnectRequest, Check check) {
    Element invoiceElement = DOMUtil.addChildElement(teamConnectRequest,"Invoice");
    DOMUtil.setAttribute(invoiceElement,"op","update");
    DOMUtil.setAttribute(invoiceElement,"numberString",check.getInvoiceNumber());
    return invoiceElement;
  }

  private Element addInvoiceHeaderInformationWithPrimaryKey(Element teamConnectRequest, String invoiceIdPK) {
    Element invoiceElement = DOMUtil.addChildElement(teamConnectRequest,"Invoice");
    DOMUtil.setAttribute(invoiceElement,"op","update");
    DOMUtil.setAttribute(invoiceElement,"primaryKey",invoiceIdPK);
    return invoiceElement;
  }

  private void addDetailCheckInformation(Element invoiceElement, Check check) {
    Element invoiceDetail = DOMUtil.addChildElement(invoiceElement,"Detail");
    DOMUtil.setAttribute(invoiceDetail,"key","INVC");
    DOMUtil.addChildElement(invoiceDetail,"InTransID",check.getTransactionId());
    DOMUtil.addChildElement(invoiceDetail,"InBankId",check.getBankId());
    DOMUtil.addChildElement(invoiceDetail,"InCheckDate",check.getFormattedCheckDate());
    DOMUtil.addChildElement(invoiceDetail,"InCheckNum",check.getCheckNumber());
    DOMUtil.addChildElement(invoiceDetail,"InCheckAmount",check.getInvoiceAmount());
//    DOMUtil.addChildElement(invoiceDetail,"InWireTransfer","YENO_NO_ROOT_YESS");
  }

  private void addDetailAccountCodeInformation(Element invoiceElement, AccountCode accountCode) {
    Element accountCodeDetail = DOMUtil.addChildElement(invoiceElement,"Detail");
    DOMUtil.setAttribute(accountCodeDetail,"key","COST");
    DOMUtil.addChildElement(accountCodeDetail,"CcSAPComments", accountCode.getSapComments());
    //This field is to be used for setting if the SAP validation needs to be performed of not.
//    DOMUtil.addChildElement(accountCodeDetail,"CcSAPFormat", accountCode.getSapFormatValid());
    DOMUtil.addChildElement(accountCodeDetail,"CcCloseDate", accountCode.getCloseDate());
    DOMUtil.addChildElement(accountCodeDetail,"CcCloseUId",accountCode.getCloseUid());
    DOMUtil.addChildElement(accountCodeDetail,"CcClosed",accountCode.getCloseAccountString());
    DOMUtil.addChildElement(accountCodeDetail,"CcCAAMAccount",accountCode.getCaamAccount());
    DOMUtil.addChildElement(accountCodeDetail,"CcCAAMSubAccount",accountCode.getCaamSubAccount());
    if(accountCode.getInternalOrderNumber()==null){
      DOMUtil.addChildElement(accountCodeDetail,"CcInternalOrderNumber","n/a");
    }
    if(accountCode.getWorkBreakDownStructure()==null){
      DOMUtil.addChildElement(accountCodeDetail,"CcWBS","n/a");
    }
    //This field is to be used for setting if the SAP validation needs to be performed of not.
//    DOMUtil.addChildElement(accountCodeDetail,"CcLPCONV_SAP_FORMAT",accountCode.getConversionSAPFormat());
  }

  private void addDetailCloseAccountCodeInformation(Element invoiceElement, AccountCode check, String autoClosedString,
                                                    String autoCloseDate) {
    Element accountCodeDetail = DOMUtil.addChildElement(invoiceElement,"Detail");
    DOMUtil.setAttribute(accountCodeDetail,"key","COST");
    DOMUtil.addChildElement(accountCodeDetail,"CcSAPComments","ACCOUNT AUTOCLOSED as of: "+autoCloseDate);
    DOMUtil.addChildElement(accountCodeDetail,"CcCloseDate", autoCloseDate);
  }

  private void addDetailEditAccountCodeInformation(Element invoiceElement, AccountCode accountCode,
                                                   String editDate) {
    Element accountCodeDetail = DOMUtil.addChildElement(invoiceElement,"Detail");
    DOMUtil.setAttribute(accountCodeDetail,"key","COST");
//    DOMUtil.addChildElement(accountCodeDetail,"CcSAPComments","ACCOUNT AUTOCLOSED as of: "+autoCloseDate);
    DOMUtil.addChildElement(accountCodeDetail,"CcEditDate", editDate);
    DOMUtil.addChildElement(accountCodeDetail,"CcEditUId", accountCode.getUserId());
  }

  private void addDetailOpenAccountCodeInformation(Element invoiceElement, AccountCode accountCode, String autoClosedString,
                                                    String editDate) {
    Element accountCodeDetail = DOMUtil.addChildElement(invoiceElement,"Detail");
    DOMUtil.setAttribute(accountCodeDetail,"key","COST");
//    DOMUtil.addChildElement(accountCodeDetail,"CcSAPComments","ACCOUNT AUTOCLOSED as of: "+autoCloseDate);
    DOMUtil.addChildElement(accountCodeDetail,"CcOpenDate", editDate);
    DOMUtil.addChildElement(accountCodeDetail,"CcOpenUId", accountCode.getUserId());
  }

  private void addAuthenticationInformation(Element element) {
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_EXTERNAL_CONFIG);
    ConnectionParams connectionParams = configReader.getConnectionParams(LMMSConstants.TEAMCONNECT_ADMIN_USER, null);
    Element autheticationElement = DOMUtil.addChildElement(element,"Authentication");
    //todo change username and password make this a D param or put it in a property file
    DOMUtil.addChildElement(autheticationElement,"Username",connectionParams.getUserName());
    DOMUtil.addChildElement(autheticationElement,"Password",connectionParams.getPassword());
  }


  /**
   * Methods to build XML for Auto Indexing documents
   * @param customDate
   * @return
   */
  public Document buildCustomDateSearchRequestDocument(String customDate){
      Document customDateReqDocument = DOMUtil.newDocument();
      Node rootNode = DOMUtil.addChildElementWithNS("www.monsanto.com/pos", customDateReqDocument, "searchDocumentsRequest");
      DOMUtil.addChildElement(rootNode, "folder", "LitigationDocs");
      Node requestDetailsNode = DOMUtil.addChildElement(rootNode, "requestDetails");
      Node searchDocumentChildNode = DOMUtil.addChildElement(requestDetailsNode,"searchDocuments");
      DOMUtil.addChildElement(searchDocumentChildNode,"searchAllVersions","true");
      addCustomDateSearchDocumentAttributesNode(searchDocumentChildNode,customDate);
      return customDateReqDocument;
    }

  private void addCustomDateSearchDocumentAttributesNode(Node searchDocumentChildNode, String objectId) {
      Node docAttrName = DOMUtil.addChildElement(searchDocumentChildNode, "queryAttributes");
      Node attrName = DOMUtil.addChildElement(docAttrName, "attribute");
      DOMUtil.addChildElement(attrName, "name", "custom_date");
      DOMUtil.addChildElement(attrName, "operator", "equals");
      DOMUtil.addChildElement(attrName, "value", objectId);
      List requiredAttributeList = new ArrayList();
      requiredAttributeList.add("title");//Title
      requiredAttributeList.add("clp_no");//clp_no
      requiredAttributeList.add("cause_no");//cause_no
      requiredAttributeList.add("matter_name");//matter_name
      requiredAttributeList.add("folder_type");//folder_type
      requiredAttributeList.add("dateCreated");//r_creation_date
      requiredAttributeList.add("r_creator_name");//r_creator_name
      requiredAttributeList.add("date_filed");//r_creator_name
      requiredAttributeList.add("custom_date");//r_creator_name
      addRequiredAttributesNode(searchDocumentChildNode,requiredAttributeList);
    }

  private void addRequiredAttributesNode(Node retrieveDocNode, List requiredAttributes) {
    Node requiredAttrNode = DOMUtil.addChildElement(retrieveDocNode, "requiredAttributes");
    for (int i = 0; i < requiredAttributes.size(); i++) {
      String requiredAttr = (String) requiredAttributes.get(i);
      DOMUtil.addChildElement(requiredAttrNode, "attribute", requiredAttr);
    }
  }
  
  
}