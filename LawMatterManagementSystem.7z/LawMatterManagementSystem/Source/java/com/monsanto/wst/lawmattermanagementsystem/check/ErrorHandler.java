/*
 ErrorHandler was created on Feb 13, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

/**
 * Filename:    $RCSfile: ErrorHandler.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-03-07 16:00:33 $
 *
 * @author vrbethi
 * @version $Revision: 1.6 $
 */
public interface ErrorHandler {
  void handleError(ChecksProcessingMessage message) throws ServiceException;

  void closeResources() throws ServiceException;
}