/*
ErrorHandlerImpl was created on Feb 13, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

/**
 * Filename:    $RCSfile: ErrorHandlerImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rrmall $    	 On:	$Date: 2007-04-23 20:35:12 $
 *
 * @author vrbethi
 * @version $Revision: 1.13 $
 */
public class ErrorHandlerImpl implements ErrorHandler {
  private ErrorReportWriter errorReportWriter;

  public ErrorHandlerImpl(ErrorReportWriter errorReportWriter, String checkErrorFileName) throws ServiceException {
    this.errorReportWriter = errorReportWriter;
    errorReportWriter.initialize(checkErrorFileName);
  }

  public void handleError(ChecksProcessingMessage message) throws ServiceException {
    if(message!=null)
    errorReportWriter.writeErrorMessage(message.getMessage());
  }

  public void closeResources() throws ServiceException {
    errorReportWriter.saveAndClose();
  }
}