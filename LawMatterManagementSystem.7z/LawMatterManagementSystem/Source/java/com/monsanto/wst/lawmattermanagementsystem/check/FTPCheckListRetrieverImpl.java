/*
 FTPCheckListRetrieverImpl was created on Jun 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPService;
import com.monsanto.wst.lawmattermanagementsystem.ftp.exception.FTPException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.Util.FileUtil;

import java.io.IOException;

/**
 * Filename:    $RCSfile: FTPCheckListRetrieverImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-02-02 20:02:05 $
*
* @author vrbethi
* @version $Revision: 1.3 $
*/
class FTPCheckListRetrieverImpl implements CheckListRetriever{
  private ChecksDAO checksDAO;
  private FTPService ftpService;

  public FTPCheckListRetrieverImpl(
      ChecksDAO checksDAO, FTPService ftpService) {
    this.checksDAO = checksDAO;
    this.ftpService = ftpService;
  }

  public CheckList retrieveCheckList() {
    CheckList checkList;
    downloadChecksFile();
    checkList = checksDAO.retrieveChecks();
    return checkList;
  }

  private void downloadChecksFile() {
    try {
      //Get the file from FTP only in PROD
      if ("prod".equalsIgnoreCase(System.getProperty("lsi.function"))) {
        ftpService.download("clppayments", LMMSConstants.FILE_NAME_INPUT_CHECKS, LMMSConstants.FTP_REMOTE_SUB_DIR_OUTBOUND);
      }
      FileUtil.copyFile(LMMSConstants.FILE_NAME_INPUT_CHECKS, LMMSConstants.FILE_NAME_BACKUP_CHECKS);
    } catch (FTPException e) {
      throw new ChecksVoidsProcessingException(e.getMessage(), e);
    } catch (IOException e) {
      throw new ChecksVoidsProcessingException(e.getMessage(), e);
    }
  }

}