/*
 ResultsProcessor was created on Mar 6, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: ResultsProcessor.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-30 20:09:09 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public interface ResultsProcessor {
    boolean processResult(Document resultFromTeamConnect);
    String processResultForInvoiceAcknowledgement(Document resultFromTeamConnect);
}