/*
 ResultsProcessorImpl was created on Mar 6, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;

import javax.xml.transform.TransformerException;

import com.monsanto.XMLUtil.DOMUtil;

/**
 * Filename:    $RCSfile: ResultsProcessorImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-30 20:09:09 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public class ResultsProcessorImpl implements ResultsProcessor {


  public boolean processResult(Document resultFromTeamConnect) {
    DOMUtil.outputXML(resultFromTeamConnect);
    boolean validResult = true;
    Node node = evaluateExpression(resultFromTeamConnect);
    if (node != null) {
      validResult = false;
    }
    return validResult;
  }

  public String processResultForInvoiceAcknowledgement(Document resultFromTeamConnect) {
    String exceptionMessage = "Success";
    DOMUtil.outputXML(resultFromTeamConnect);
    Node node = evaluateExpression(resultFromTeamConnect);
    if (node != null) {
      NamedNodeMap nodeMap = node.getAttributes();
      Node messageNode = nodeMap.getNamedItem("message");
      if (messageNode != null) {
        exceptionMessage = messageNode.getNodeValue();
      }
    }
    return exceptionMessage;  
  }


  protected Node evaluateExpression(Document resultFromTeamConnect) {
    Node node = null;
    try {
      node = XPathAPI.selectSingleNode(resultFromTeamConnect, "TeamConnectResponse/Exception");
    } catch (TransformerException e) {
      throw new ChecksVoidsProcessingException("Exception during processing of Result document received from team connect during update operation", e);
    }
    return node;
  }
}