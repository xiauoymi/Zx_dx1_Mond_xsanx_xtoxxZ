/*
 TeamConnectCheckDAO was created on Feb 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: TeamConnectCheckDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-04-24 18:59:02 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public interface TeamConnectCheckDAO {
  Document callService(Document document) ;
}