/*
TeamConnectCheckDAOImpl was created on Feb 9, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.io.InputStream;

/**
 * Filename:    $RCSfile: TeamConnectCheckDAOImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-12 14:49:50 $
 *
 * @author vrbethi
 * @version $Revision: 1.10 $
 */
public class TeamConnectCheckDAOImpl implements TeamConnectCheckDAO{
  private HttpClient httpclient;
  private PostMethod postToWebApp;

  public TeamConnectCheckDAOImpl(HttpClient httpClient, PostMethod postMethod) {
    this.httpclient = httpClient;
    this.postToWebApp=postMethod;
  }

  public Document callService(Document document){
      DOMUtil.outputXML(document);
    Document responseDocument=null;
    InputStream responseBodyAsStream=null;
    try {
      String url = System.getProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL);
//      System.out.println("url = " + url);
//      String url = "http://w3-law.monsanto.com/TeamConnect/xml";
//      String url = "http://w3d.teamconnect.monsanto.com/TeamConnect/xml";
      postToWebApp = new PostMethod(url);
      InputStreamRequestEntity inputStreamRequestEntity = new InputStreamRequestEntity(DOMUtil.makeInputStreamFromDocument(document));
      postToWebApp.setRequestEntity(inputStreamRequestEntity);
      postToWebApp.setRequestHeader("Content-type", "text/xml; charset=ISO-8859-1");
      httpclient.executeMethod(postToWebApp);
      responseBodyAsStream = postToWebApp.getResponseBodyAsStream();
      responseDocument = DOMUtil.newDocument(responseBodyAsStream);
    } catch (IOException e) {
      throw new ChecksVoidsProcessingException("IO Exception conneting to team connect",e);
    } catch (TransformerException e) {
      throw new ChecksVoidsProcessingException("Exception during transforming input document to team connect",e);
    }catch (SAXException e) {
//      throw new ChecksVoidsProcessingException("Exception during creating an document with xml received from team connect",e);
    }
    finally{
      try {
        if(responseBodyAsStream!=null){
          responseBodyAsStream.close();
        }
      } catch (IOException e) {
        e.printStackTrace();
      }
      postToWebApp.releaseConnection();
    }
    return responseDocument;
  }
}