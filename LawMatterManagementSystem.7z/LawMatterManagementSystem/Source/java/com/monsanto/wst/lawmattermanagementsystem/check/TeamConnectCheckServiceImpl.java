/*
TeamConnectCheckService was created on Feb 9, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.dataservices.PersistentStoreConnection;
import org.w3c.dom.Document;

import java.util.List;
import java.util.Iterator;

/**
 * Filename:    $RCSfile: TeamConnectCheckServiceImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-01-16 17:49:49 $
 *
 * @author vrbethi
 * @version $Revision: 1.25 $
 */
public class TeamConnectCheckServiceImpl implements ChecksService {
  private XMLBuilder checksXMLBuilder;
  private XMLParser xmlParser;
  private TeamConnectCheckDAO teamConnectCheckDAO;
  private Validator checkValidator;
  private ResultsProcessor resultsProcessor;

  public TeamConnectCheckServiceImpl(XMLBuilder checksXMLBuilder, XMLParser xmlParser,
                                     TeamConnectCheckDAO teamConnectCheckDAO, Validator checkValidator,
                                     ResultsProcessor resultsProcessor) {
    this.checksXMLBuilder = checksXMLBuilder;
    this.xmlParser = xmlParser;
    this.teamConnectCheckDAO = teamConnectCheckDAO;
    this.checkValidator = checkValidator;
    this.resultsProcessor = resultsProcessor;
  }

  public ChecksProcessingMessage processCheck(Check check){
    StringBuffer message=new StringBuffer();
    ChecksProcessingMessage checksProcessingMessage = new ChecksProcessingMessage();
      if(isCheckValidToUpdateInTeamConnect(check)){
        message.append(updateCheckInTeamConnect(check));
      }else{
        appendErrorMessageIfPresentInTC(check, message);
        message.append(" for Inv/Vendor: ");
        message.append(check.getInvoiceNumber());
        message.append("/");
        message.append(check.getVendorId());
        message.append(" has been previously processed");
      }
    checksProcessingMessage.setMessage(message.toString());
    return checksProcessingMessage;
  }

  private void appendErrorMessageIfPresentInTC(Check check, StringBuffer message) {
    if(check.getWireIndicator().equalsIgnoreCase("X") || check.getWireIndicator().equalsIgnoreCase("N")){
      message.append("Wire Transfer");
    }else{
      message.append("The Check: ");
      message.append(check.getCheckNumber());
    }
  }

  /**
   * If checks for a transaction is zero then valid to insert (update) in Team Connect
   * if Greater than zero then check if check are identical
   * @param check
   * @return
   */
  private boolean isCheckValidToUpdateInTeamConnect(Check check) {
    boolean validToInsert=true;
    Document retrieveChecksXML = checksXMLBuilder.buildRetrieveChecksXML(check);
    DOMUtil.outputXML(retrieveChecksXML);
    Document responseCheckRequestedXml = teamConnectCheckDAO.callService(retrieveChecksXML);
    CheckList checkList =  xmlParser.getCheckList(responseCheckRequestedXml);
    if(checkList.size()>0){
        validToInsert = checkValidator.isCheckPresentNotInCheckList(check,checkList);
    }
    return validToInsert;
  }

  private String updateCheckInTeamConnect(Check check) {
    StringBuffer message = new StringBuffer();
    //Need to check for Multiple Invoices associated with the Check's invoice number.
    //If multiple invoices are associated, need to build a diff update XML with primaryKey attribute
    InvoiceDataDAO dao = new InvoiceDataDAOImpl(null, null);
    Document document = null;
    try {
      List invoiceIdList = dao.getInvoiceRecordsForInvoiceNumber(check.getInvoiceNumber(), getPersistentStoreConnection(new ResourceManagerFactoryImpl()));
      if (invoiceIdList != null && invoiceIdList.size() > 1) {
        Iterator invcItr = invoiceIdList.iterator();
        while (invcItr.hasNext()) {
          document = checksXMLBuilder.buildUpdateCheckXMLWithPrimaryKey(check, invcItr.next().toString());
          processUpdateCheckToTeamConnect(check, message, document);
        }
      } else {
        document = checksXMLBuilder.buildUpdateCheckXML(check);
        processUpdateCheckToTeamConnect(check, message, document);
      }
    } catch (DAOException e) {
      e.printStackTrace();
    }
    return message.toString();
  }

  private void processUpdateCheckToTeamConnect(Check check, StringBuffer message, Document document) {
    DOMUtil.outputXML(document);
    Document outputFromTeamConnect = teamConnectCheckDAO.callService(document);
    DOMUtil.outputXML(outputFromTeamConnect);
    boolean result = this.resultsProcessor.processResult(outputFromTeamConnect);
    if (!result) {
      message.append("Check: " + check.getCheckNumber() +" Invoice Number :"+check.getInvoiceNumber()+
          " Vendor :"+check.getVendorId()+" No of transactions "+check.getNumberOfTransactions()+
          " Trans ID "+check.getTransactionId()+
          " Error During Update Of Check In Team Connect");
    } else {
      message.append("Check: " + check.getCheckNumber() + " (from SAP) successfully processed. (Invoice = " + check.getInvoiceNumber() + ")");
    }
    message.append("\n");
  }

  private PersistentStoreConnection getPersistentStoreConnection(ResourceManagerFactoryImpl resourceManagerFactory) {
    try {
      ResourceConnectionManager connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
      return (PersistentStoreConnection) connectionManager.getConnection(LMMSConstants.DATABASE_LAW_TCE);
    } catch (ResourceConnectionException e) {
      return performFailureActionIfConnectionNotObtained(e);
    }    
  }

   private PersistentStoreConnection performFailureActionIfConnectionNotObtained(ResourceConnectionException e) {
    String errorMessage = "Fatal Error: Unable to connect to " + LMMSConstants.DATASOURCE_TYPE_SQL_SERVER + " database " + LMMSConstants.DATABASE_LAW_TCE + " for " + System.getProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION) + " environment. Error Message: " + e.getMessage();
    throw new RuntimeException(errorMessage, e);
  }
}