/*
 TeamConnectDAOFactory was created on May 25, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

/**
 * Filename:    $RCSfile: TeamConnectDAOFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-25 16:50:28 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public interface TeamConnectDAOFactory {
  TeamConnectCheckDAO getTeamConnectDAOFactoryInstance();
}