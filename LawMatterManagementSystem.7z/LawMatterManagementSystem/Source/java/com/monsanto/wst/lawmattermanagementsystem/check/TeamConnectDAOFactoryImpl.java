/*
 TeamConnectDAOFactoryImpl was created on May 25, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

/**
 * Filename:    $RCSfile: TeamConnectDAOFactoryImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-25 16:50:28 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class TeamConnectDAOFactoryImpl implements TeamConnectDAOFactory {
  public TeamConnectCheckDAO getTeamConnectDAOFactoryInstance() {
    return new TeamConnectCheckDAOImpl(new HttpClient(), new PostMethod(System.getProperty(
        LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL)));
  }
}