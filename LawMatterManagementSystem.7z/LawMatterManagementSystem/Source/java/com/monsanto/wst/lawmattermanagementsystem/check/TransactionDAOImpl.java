/*
 TransactionDAOImpl was created on Feb 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;

/**
 * Filename:    $RCSfile: TransactionDAOImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 16:11:20 $
 *
 * @author VRBETHI
 * @version $Revision: 1.19 $
 */
public class TransactionDAOImpl implements TransactionDAO {
  private ResourceConnectionManager resourceConnectionManager;
//  private String queryString = "SELECT DISTINCT cont_cat_57.cosapvendorid, cont_cat_57.covendorid,\n" +
//      "\n" +
//      "                t_invoice.invoice_date, t_invoice.number_string,invc_cat_12.InTransId,\n" +
//      "\n" +
//      "                invc_cat_12.inpayinvoice\n" +
//      "\n" +
//      "           FROM cont_cat_57 RIGHT OUTER JOIN t_involved INNER JOIN t_contact ON t_involved.contact_id =\n" +
//      "\n" +
//      "                                                                                  t_contact.primary_key\n" +
//      "\n" +
//      "                LEFT OUTER JOIN t_contact t_contact_invc_vendor RIGHT OUTER JOIN t_invoice INNER JOIN j_invc_line_item ON t_invoice.primary_key =\n" +
//      "\n" +
//      "                                                                                                                            j_invc_line_item.invoice_id\n" +
//      "\n" +
//      "                INNER JOIN t_project ON j_invc_line_item.project_id =\n" +
//      "\n" +
//      "                                                         t_project.primary_key\n" +
//      "\n" +
//      "                ON t_contact_invc_vendor.primary_key = t_invoice.vendor_id\n" +
//      "\n" +
//      "                LEFT OUTER JOIN invc_cat_12 ON t_invoice.primary_key =\n" +
//      "\n" +
//      "                                                        invc_cat_12.invoice_id\n" +
//      "\n" +
//      "                ON t_involved.project_id = t_project.primary_key\n" +
//      "\n" +
//      "                ON cont_cat_57.contact_id = t_contact.primary_key\n" +
//      "\n" +
//      "          WHERE (t_invoice.number_string = ?)\n" +
//      "\n" +
//      "            AND (cont_cat_57.cosapvendorid = ?)\n" +
//      "\n" +
//      "            AND (? =\n" +
//      "\n" +
//      "                                CONVERT(varchar, t_invoice.invoice_date, 101)\n" +
//      "\n" +
//      "                )\n" +
//      "\n" +
//      "            AND (invc_cat_12.inpayinvoice = 'Yes')";
  private String queryString = "SELECT distinct\n" +
    "  T_INVOICE.NUMBER_STRING,\n" +
    "  T_INVOICE.INVOICE_DATE ,\n" +
    "  INVC_CAT_12.InTransID,\n" +
    "  INVC_CAT_12.InPayInvoice,\n" +
    "  INVC_CAT_12.InBankId,\n" +
    "  INVC_CAT_12.InCheckAmount,\n" +
    "  InVC_CAT_12.InCheckDate,\n" +
    "  INVC_CAT_12.InCheckNum,\n" +
    "  T_PR_12_InMatter.NUMBER_STRING,\n" +
    "  L_ACCT_CATEGORY.NAME,\n" +
    "  CONT_CAT_57_Vendor.CoSAPVendorID,\n" +
    "  CONT_CAT_57_Vendor.CoVendorID\n" +
    "FROM\n" +
    "  T_PROJECT  T_PR_12_InMatter LEFT OUTER JOIN INVC_CAT_12 ON (INVC_CAT_12.InMatter=T_PR_12_InMatter.PRIMARY_KEY)\n" +
    "   LEFT OUTER JOIN T_INVOICE ON (T_INVOICE.PRIMARY_KEY=INVC_CAT_12.INVOICE_ID)\n" +
    "   RIGHT OUTER JOIN T_CONTACT  T_CONTACT_invc_vendor ON (T_CONTACT_invc_vendor.PRIMARY_KEY=T_INVOICE.VENDOR_ID)\n" +
    "   RIGHT OUTER JOIN CONT_CAT_57  CONT_CAT_57_Vendor ON (T_CONTACT_invc_vendor.PRIMARY_KEY=CONT_CAT_57_Vendor.CONTACT_ID)\n" +
    "   INNER JOIN J_INVC_LINE_ITEM ON (T_INVOICE.PRIMARY_KEY=J_INVC_LINE_ITEM.INVOICE_ID)\n" +
    "   INNER JOIN T_PROJECT ON (T_PROJECT.PRIMARY_KEY=J_INVC_LINE_ITEM.PROJECT_ID)\n" +
    "   INNER JOIN T_ACCOUNT ON (T_ACCOUNT.PROJECT_ID=T_PROJECT.PRIMARY_KEY)\n" +
    "   INNER JOIN E_ACCT_DETAIL ON (E_ACCT_DETAIL.ENTERPRISE_OBJECT_ID=T_ACCOUNT.PRIMARY_KEY)\n" +
    "   INNER JOIN Y_OBJ_CATEGORY  L_ACCT_CATEGORY ON (L_ACCT_CATEGORY.PRIMARY_KEY=E_ACCT_DETAIL.CATEGORY_ID)\n" +
    " WHERE\n" +
    "  ( \n" +
    "  T_INVOICE.NUMBER_STRING  = ? \n" +
    "  AND  CONT_CAT_57_Vendor.CoSAPVendorID  =  ?\n" +
    "  AND  INVC_CAT_12.InPayInvoice  =  'Yes'\n" +
//    "  AND  INVC_CAT_12.InInvoiceDate >= '2/25/2007'\n" +
    "  AND  ? = CONVERT(varchar, INVC_CAT_12.InInvoiceDate, 101)\n" +
    "  )";

  public TransactionDAOImpl(ResourceConnectionManager resourceConnectionManager) {
    this.resourceConnectionManager = resourceConnectionManager;
  }

  public int retrieveTransaction(Check check){
    int count=0;
    try {
      PersistentStoreConnection connection = (PersistentStoreConnection) this.resourceConnectionManager.getConnection(LMMSConstants.DATABASE_LAW_TCE);
      PersistentStoreStatement persistentStoreStatement = connection.prepareStatement(queryString);
      persistentStoreStatement.setParam(1,check.getInvoiceNumber());
      persistentStoreStatement.setParam(2,check.getVendorId());
      String formattedInvoiceDate = check.getFormattedInvoiceDate();
      persistentStoreStatement.setParam(3, formattedInvoiceDate);
      PersistentStoreResultSet persistentStoreResultSet = persistentStoreStatement.executeQuery();
      PersistentStoreResultSetFwdIterator forwardIterator = persistentStoreResultSet.getForwardIterator();
      while(forwardIterator.next()){
        String transactionIdIn = forwardIterator.getString("InTransID");
        check.setTransactionId(transactionIdIn);
        check.addTransaction(transactionIdIn);
        count++;
      }
    } catch (ResourceConnectionException e) {
      throw new ChecksVoidsProcessingException("Exception encountered connecting to Law database retreiving a tranasaction",e);
    } catch (WrappingException e) {
      throw new ChecksVoidsProcessingException("Exception encountered retrieving transaction from Law database",e);
    }
    return count;
  }
}