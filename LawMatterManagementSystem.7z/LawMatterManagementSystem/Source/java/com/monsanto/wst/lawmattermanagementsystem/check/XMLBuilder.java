/*
 XMLBuilder was created on Feb 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import com.monsanto.wst.lawmattermanagementsystem.voids.VoidCheck;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentMetaData;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: XMLBuilder.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-02-10 19:07:19 $
 *
 * @author vrbethi
 * @version $Revision: 1.15 $
 */
public interface XMLBuilder {
  Document buildUpdateCheckXML(Check check);

  Document buildRetrieveChecksXML(Check check);

  Document buildRetrieveVoidCheckXML(VoidCheck voidCheck);

  Document buildRetreiveTransactionXML(Check check);

  Document buildUpdateVoidCheckXML(VoidCheck voidCheck, Check check);

  Document buildUpdateAccountCodeXML(AccountCode accountCode);

  Document buildUpdateDocumentXML(DocumentMetaData documentMetaData);

  Document buildCloseAccountCodeUpdateAccountCodeXML(AccountCode accountCode, String autoClosedString,
                                                     String autoCloseDate);

  Document buildEditAccountCodeUpdateAccountCodeXML(AccountCode accountCode, String autoClosedString, String autoClosedDate);

  Document buildOpenAccountCodeUpdateAccountCodeXML(AccountCode accountCode, String autoClosedString, String autoClosedDate);

  Document buildInvoiceAcknowledgementXML(InvoiceRecord invoiceRecord);

  Document buildUpdateCheckXMLWithPrimaryKey(Check check, String s);

  //New Method added for Updating Voids associated to checks and those cheks having multiple invoice ids in them
  Document buildUpdateVoidCheckXMLWithPrimaryKey(VoidCheck voidCheck, String invoiceIdPK); 
}