/*
 XMLCheckParser was created on Feb 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import com.monsanto.XMLUtil.DOMUtil;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.transform.TransformerException;

/**
 * Filename:    $RCSfile: XMLCheckParser.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-22 20:24:07 $
 *
 * @author vrbethi
 * @version $Revision: 1.10 $
 */
public class XMLCheckParser implements XMLParser {
  public CheckList getCheckList(Document responseCheckRequestedXml) {
    DOMUtil.outputXML(responseCheckRequestedXml);
    CheckList checkList = new CheckList();
    try {
      NodeList nodeList = XPathAPI.selectNodeList(responseCheckRequestedXml,"TeamConnectResponse/SearchResults/Invoice");
      for(int i=0;i<nodeList.getLength();i++){
        Node invoiceNode = nodeList.item(i);
        Node invoiceNumber = XPathAPI.selectSingleNode(invoiceNode,"InvoiceNumber");
        Node transactionNode = XPathAPI.selectSingleNode(invoiceNode,"Detail/TransactionId");
        Node bankId = XPathAPI.selectSingleNode(invoiceNode,"Detail/BankId");
        //todo verify if this used at all else delete this.
        Node checkAmount = XPathAPI.selectSingleNode(invoiceNode,"Detail/CheckAmount");
        Check check = new Check(
            DOMUtil.getTextValue(invoiceNumber),
          "",
          "",
          "",
            getNodeValueReturnEmptyIfNodeIsNull(invoiceNode, "Detail/BankId"),
          "00000000",
            getNodeValueReturnEmptyIfNodeIsNull(invoiceNode, "Detail/CheckNumber"),
          "",
          "",
          DOMUtil.getTextValue(transactionNode),
            getTeamConnectCheckDate(invoiceNode));
        checkList.addCheck(check);
      }
    } catch (TransformerException e) {
      //todo add test for this.
      throw new ChecksVoidsProcessingException("Error during parsing xml document",e);
    }
    return checkList;
  }

  private String getNodeValueReturnEmptyIfNodeIsNull(Node invoiceNode, String nodePath) throws TransformerException {
    String selectedNodeValue = null;
    Node selectedNode = XPathAPI.selectSingleNode(invoiceNode, nodePath);
    if(selectedNode!=null){
          selectedNodeValue = DOMUtil.getTextValue(selectedNode);
    }else{
      selectedNodeValue = "";
    }
    return selectedNodeValue;
  }

  private String getTeamConnectCheckDate(Node invoiceNode) throws TransformerException {
    String connectCheckDate = null;
    Node teamonnectCheckDateNode = XPathAPI.selectSingleNode(invoiceNode,"Detail/CheckDate");
    if(teamonnectCheckDateNode!=null){
          connectCheckDate = DOMUtil.getTextValue(teamonnectCheckDateNode);
    }else{
      connectCheckDate = "";
    }
    return connectCheckDate;
  }
}