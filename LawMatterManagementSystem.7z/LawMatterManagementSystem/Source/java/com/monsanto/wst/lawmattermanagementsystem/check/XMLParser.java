/*
 XMLParser was created on Feb 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check;

import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: XMLParser.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-12 00:37:54 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public interface XMLParser {
  CheckList getCheckList(Document responseCheckRequestedXml);
}