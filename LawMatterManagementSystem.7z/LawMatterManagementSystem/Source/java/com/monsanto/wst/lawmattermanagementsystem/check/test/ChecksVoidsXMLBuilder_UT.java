/*
 ChecksXMLBuilder_UT was created on Feb 9, 2007 using Mons`anto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check.test;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.lawmattermanagementsystem.check.Check;
import com.monsanto.wst.lawmattermanagementsystem.check.ChecksVoidsXMLBuilder;
import com.monsanto.wst.lawmattermanagementsystem.check.XMLBuilder;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockInvoiceRecordDataUtility;
import com.monsanto.wst.lawmattermanagementsystem.voids.VoidCheck;
import junit.framework.TestCase;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NamedNodeMap;

/**
 * Filename:    $RCSfile: ChecksVoidsXMLBuilder_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-02-10 19:06:20 $
 *
 * @author batchuser
 * @version $Revision: 1.23 $
 */
public class ChecksVoidsXMLBuilder_UT extends TestCase{

  //todo check if this test is required if yes add for void check too.
  public void testBuildCheckInsertXML_ReturnNotNullDocument() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData testData = new TestData();
    Check check = testData.createTestCheckOne();
    Document document = xmlBuilder.buildUpdateCheckXML(check);
    assertNotNull(document);
  }

  public void testBuildCheckInsertXML_WithCheckInformation() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData testData = new TestData();
    Check check = testData.createTestCheckOne();
    Document document = xmlBuilder.buildUpdateCheckXML(check);
    DOMUtil.outputXML(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice");
    Node detail = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail");
    Node inTransId = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InTransID");
    Node inBankId = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InBankId");
    Node inCheckDate = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InCheckDate");
    Node inCheckAmount = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InCheckAmount");
    Node inCheckNumber = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InCheckNum");
//    Node inTransferAmount = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InWireTransfer");
    assertEquals("batchuser",DOMUtil.getTextValue(usernamenode));
    assertEquals("batch12!",DOMUtil.getTextValue(passwordNode));
    assertEquals("update",DOMUtil.getAttribute((Element) invoiceNode,"op"));
    assertEquals("5001",DOMUtil.getAttribute((Element) invoiceNode,"numberString"));
    assertEquals("INVC",DOMUtil.getAttribute((Element) detail,"key"));
    assertEquals("00014598",DOMUtil.getTextValue(inTransId));

    assertEquals("CITI BANK",DOMUtil.getTextValue(inBankId));
    assertEquals("2007-02-10",DOMUtil.getTextValue(inCheckDate));
    assertEquals("25000",DOMUtil.getTextValue(inCheckAmount));
    assertEquals("00145",DOMUtil.getTextValue(inCheckNumber));
//    assertEquals("YENO_NO_ROOT_YESS",DOMUtil.getTextValue(inTransfeabc_123ount));
  }

  public void testBuildRetrieveChecksReturnedNotNullDocument() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData data = new TestData();
    Document document = xmlBuilder.buildRetrieveChecksXML(data.createTestCheckOne());
    assertNotNull(document);
  }

  public void testBuildRetireveCheckXMLWithRequestedReturnElementsAndSearchCriteria() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData data = new TestData();
    Document document = xmlBuilder.buildRetrieveChecksXML(data.createTestCheckOne());
    assertNotNull(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceEntityNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Search/Query/Entity");
    Node transactionIdElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/Query/Criteria/And/Detail.INVC.InTransID");
    Node invoiceNumber = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/InvoiceNumber");
    Node searchRequetedDetail = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail");
    Node transactionIdElementSub = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/TransactionId");
    Node bankIdElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/BankId");
    Node checkDateElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/CheckDate");
    Node checkSumElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/CheckNumber");
    Node checkAmountElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/CheckAmount");

    DOMUtil.outputXML(document);
    assertEquals("batchuser",DOMUtil.getTextValue(usernamenode));
    assertEquals("batch12!",DOMUtil.getTextValue(passwordNode));
    assertEquals("Invoice",DOMUtil.getTextValue(invoiceEntityNode));
    assertEquals("00014598",DOMUtil.getTextValue(transactionIdElement));
    assertEquals("equals",DOMUtil.getAttribute((Element) transactionIdElement,"is"));
    assertEquals("NumberString",DOMUtil.getAttribute((Element) invoiceNumber,"select"));
    assertEquals("Detail[INVC]",DOMUtil.getAttribute((Element) searchRequetedDetail,"select"));
    assertEquals("DetailValue[InTransID]",DOMUtil.getAttribute((Element) transactionIdElementSub,"select"));
    assertEquals("DetailValue[InBankId]",DOMUtil.getAttribute((Element) bankIdElement,"select"));
    assertEquals("DetailValue[InCheckDate]",DOMUtil.getAttribute((Element) checkDateElement,"select"));
    assertEquals("DetailValue[InCheckNum]",DOMUtil.getAttribute((Element) checkSumElement,"select"));
    assertEquals("DetailValue[InCheckAmount]",DOMUtil.getAttribute((Element) checkAmountElement,"select"));
  }

  public void testBuildRetrieveVoidCheckXML() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData data = new TestData();
    Document document = xmlBuilder.buildRetrieveVoidCheckXML(data.createTestVoidCheckOne());
    assertNotNull(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceEntityNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Search/Query/Entity");
    Node checkNumberElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/Query/Criteria/And/Detail.INVC.InCheckNum");
    Node searchRequetedDetail = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail");
    Node invoiceNumber = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/InvoiceNumber");
    Node transactionIdElementSub = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/TransactionId");

    Node bankIdElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/BankId");
    Node checkDateElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/CheckDate");
    Node checkSumElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/CheckNumber");
    Node checkAmountElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/CheckAmount");

    DOMUtil.outputXML(document);
    assertEquals("batchuser",DOMUtil.getTextValue(usernamenode));
    assertEquals("batch12!",DOMUtil.getTextValue(passwordNode));
    assertEquals("Invoice",DOMUtil.getTextValue(invoiceEntityNode));
    assertEquals("00146",DOMUtil.getTextValue(checkNumberElement));
    assertEquals("equals",DOMUtil.getAttribute((Element) checkNumberElement,"is"));
    assertEquals("NumberString",DOMUtil.getAttribute((Element) invoiceNumber,"select"));
    assertEquals("Detail[INVC]",DOMUtil.getAttribute((Element) searchRequetedDetail,"select"));
    assertEquals("DetailValue[InTransID]",DOMUtil.getAttribute((Element) transactionIdElementSub,"select"));
    assertEquals("DetailValue[InBankId]",DOMUtil.getAttribute((Element) bankIdElement,"select"));
    assertEquals("DetailValue[InCheckDate]",DOMUtil.getAttribute((Element) checkDateElement,"select"));
    assertEquals("DetailValue[InCheckNum]",DOMUtil.getAttribute((Element) checkSumElement,"select"));
    assertEquals("DetailValue[InCheckAmount]",DOMUtil.getAttribute((Element) checkAmountElement,"select"));    
  }

  public void testBuildRetrieveTransactionReturnedNotNullDocument() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData data = new TestData();
    Document document = xmlBuilder.buildRetreiveTransactionXML(data.createTestCheckOne());
    assertNotNull(document);
  }

  public void testBuildRetireveTransactionXMLWithRequestedReturnElementsAndSearchCriteria() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData data = new TestData();
    Document document = xmlBuilder.buildRetreiveTransactionXML(data.createTestCheckOne());
    assertNotNull(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceEntityNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Search/Query/Entity");
    Node transactionIdElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/Query/Criteria/And/Detail.INVC.InTransID");
    Node searchRequetedDetail = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail");
    Node transactionIdElementSub = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/TransactionId");
    Node bankIdElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/BankId");
    Node checkDateElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/CheckDate");
    Node checkSumElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/CheckNumber");
    Node checkAmountElement = XPathAPI.selectSingleNode(document,
      "TeamConnectRequest/Search/SearchResults/Invoice/Detail/CheckAmount");

    DOMUtil.outputXML(document);
    assertEquals("batchuser",DOMUtil.getTextValue(usernamenode));
    assertEquals("batch12!",DOMUtil.getTextValue(passwordNode));
    assertEquals("Invoice",DOMUtil.getTextValue(invoiceEntityNode));
    assertEquals("00014598",DOMUtil.getTextValue(transactionIdElement));
    assertEquals("equals",DOMUtil.getAttribute((Element) transactionIdElement,"is"));
    assertEquals("Detail[INVC]",DOMUtil.getAttribute((Element) searchRequetedDetail,"select"));
    assertEquals("DetailValue[InTransID]",DOMUtil.getAttribute((Element) transactionIdElementSub,"select"));
    assertEquals("DetailValue[InBankId]",DOMUtil.getAttribute((Element) bankIdElement,"select"));
    assertEquals("DetailValue[InCheckDate]",DOMUtil.getAttribute((Element) checkDateElement,"select"));
    assertEquals("DetailValue[InCheckNum]",DOMUtil.getAttribute((Element) checkSumElement,"select"));
    assertEquals("DetailValue[InCheckAmount]",DOMUtil.getAttribute((Element) checkAmountElement,"select"));
  }

  //todo check if this test is required if yes add for void check too.
  public void testBuildVoidCheckUpdateXML_ReturnNotNullDocument() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData testData = new TestData();
    VoidCheck testVoidCheckOne = testData.createTestVoidCheckOne();
    Document document = xmlBuilder.buildUpdateVoidCheckXML(testVoidCheckOne, testData.createTestCheckOne());
    assertNotNull(document);
  }

  public void testBuildVoidCheckUpateXML_WithCheckInformation() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData testData = new TestData();
    VoidCheck testVoidCheckOne = testData.createTestVoidCheckOne();
    Document document = xmlBuilder.buildUpdateVoidCheckXML(testVoidCheckOne, testData.createTestCheckOne());
    DOMUtil.outputXML(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice");
    Node detail = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail");

    Node inVoidCode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InVoidCode");
    Node inVoidCheckNumber = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InVoidCheckNumber");
    Node inVoidDate = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InVoidDate");

    assertEquals("batchuser",DOMUtil.getTextValue(usernamenode));
    assertEquals("batch12!",DOMUtil.getTextValue(passwordNode));
    assertEquals("update",DOMUtil.getAttribute((Element) invoiceNode,"op"));
    assertEquals("5001",DOMUtil.getAttribute((Element) invoiceNode,"numberString"));
    assertEquals("INVC",DOMUtil.getAttribute((Element) detail,"key"));
    //todo correct for transaction id
    assertEquals("70",DOMUtil.getTextValue(inVoidCode));
    assertEquals("00146",DOMUtil.getTextValue(inVoidCheckNumber));
    assertEquals("2002-12-18",DOMUtil.getTextValue(inVoidDate));
  }

  public void testBuildAccountCodeUpateXML_UpdateSAPCommentField() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData testData = new TestData();
    AccountCode accountCode = testData.createAccountCodeWithNonEmptyInternalOrderNumberAndWbs();
    Document document = xmlBuilder.buildUpdateAccountCodeXML(accountCode);
    DOMUtil.outputXML(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project");
    Node detail = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail");

    Node sapComments = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcSAPComments");
    Node closeUid = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcCloseUid");

    assertEquals("batchuser",DOMUtil.getTextValue(usernamenode));
    assertEquals("batch12!",DOMUtil.getTextValue(passwordNode));
    assertEquals("update",DOMUtil.getAttribute((Element) invoiceNode,"op"));
    assertEquals("1234",DOMUtil.getAttribute((Element) invoiceNode,"NumberString"));
    assertEquals("COST",DOMUtil.getAttribute((Element) detail,"key"));
    //todo correct for transaction id
    assertEquals("ACCOUNT AUTOCLOSED",DOMUtil.getTextValue(sapComments));
    assertNull(XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcWBS"));
    assertNull(XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcInternalOrderNumber"));
//    assertEquals("AUTO CLOSE",DOMUtil.getTextValue(closeUid));
  }

  public void testBuildAccountCodeUpateXML_AccountCodeHasEmptyInternalOrderNumberAndWorkBreakdownStructure() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData testData = new TestData();
    AccountCode accountCode = testData.createAccountCode();
    Document document = xmlBuilder.buildUpdateAccountCodeXML(accountCode);
    DOMUtil.outputXML(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project");
    Node detail = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail");

    Node closeUid = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcCloseUid");

    assertEquals("batchuser",DOMUtil.getTextValue(usernamenode));
    assertEquals("batch12!",DOMUtil.getTextValue(passwordNode));
    assertEquals("update",DOMUtil.getAttribute((Element) invoiceNode,"op"));
    assertEquals("1234",DOMUtil.getAttribute((Element) invoiceNode,"NumberString"));
    assertEquals("COST",DOMUtil.getAttribute((Element) detail,"key"));
    //todo correct for transaction id
    assertEquals("ACCOUNT AUTOCLOSED",DOMUtil.getTextValue(XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcSAPComments")));
    assertEquals("n/a",DOMUtil.getTextValue(XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcWBS")));
    assertEquals("n/a",DOMUtil.getTextValue(XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcInternalOrderNumber")));
//    assertEquals("AUTO CLOSE",DOMUtil.getTextValue(closeUid));
  }

  public void testBuildAccountCodeUpateXML_UpdateCostCenterClosedField() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData testData = new TestData();
    AccountCode accountCode = testData.createAccountCode();
    String autoClosedString = "";
    String autoClosedDate = "12/28/2008";
    Document document = xmlBuilder.buildCloseAccountCodeUpdateAccountCodeXML(accountCode,autoClosedString, autoClosedDate);
    DOMUtil.outputXML(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project");
    Node detail = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail");

    Node sapComments = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcSAPComments");
    Node costCenterCloseDate = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcCloseDate");

    assertEquals("batchuser",DOMUtil.getTextValue(usernamenode));
    assertEquals("batch12!",DOMUtil.getTextValue(passwordNode));
    assertEquals("update",DOMUtil.getAttribute((Element) invoiceNode,"op"));
    assertEquals("1234",DOMUtil.getAttribute((Element) invoiceNode,"NumberString"));
    assertEquals("COST",DOMUtil.getAttribute((Element) detail,"key"));
    String sapCommentString = DOMUtil.getTextValue(sapComments);
    assertNotNull(sapCommentString);
    assertEquals("ACCOUNT AUTOCLOSED as of: 12/28/2008",sapCommentString);
    String closeDate = DOMUtil.getTextValue(costCenterCloseDate);
    assertNotNull(closeDate);
    assertEquals("12/28/2008",closeDate);
  }

  public void testBuildAccountCodeUpateXML_UpdateCostCenterOpenField() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData testData = new TestData();
    AccountCode accountCode = testData.createAccountCode();
    String autoClosedString = "";
    String autoClosedDate = "12/28/2008";
    Document document = xmlBuilder.buildOpenAccountCodeUpdateAccountCodeXML(accountCode,autoClosedString, autoClosedDate);
    DOMUtil.outputXML(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project");
    Node detail = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail");

//    Node sapComments = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcSAPComments");
    Node costCenterOpenDate = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcOpenDate");
    Node costCenterOpenUserId = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcOpenUId");

    assertEquals("batchuser",DOMUtil.getTextValue(usernamenode));
    assertEquals("batch12!",DOMUtil.getTextValue(passwordNode));
    assertEquals("update",DOMUtil.getAttribute((Element) invoiceNode,"op"));
    assertEquals("1234",DOMUtil.getAttribute((Element) invoiceNode,"NumberString"));
    assertEquals("COST",DOMUtil.getAttribute((Element) detail,"key"));
//    String sapCommentString = DOMUtil.getTextValue(sapComments);
//    assertNotNull(sapCommentString);
//    assertEquals("CcSAPComments,ACCOUNT AUTOCLOSED as of: 12/28/2008",sapCommentString);
    assertNotNull(DOMUtil.getTextValue(costCenterOpenDate));
    assertEquals("12/28/2008", DOMUtil.getTextValue(costCenterOpenDate));
    assertEquals("vrbethi", DOMUtil.getTextValue(costCenterOpenUserId));

  }

  public void testBuildAccountCodeUpateXML_UpdateCostCenterEditField() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData testData = new TestData();
    AccountCode accountCode = testData.createValidAccountCode();
    String autoClosedString = "";
    String autoClosedDate = "12/28/2008";
    Document document = xmlBuilder.buildEditAccountCodeUpdateAccountCodeXML(accountCode,autoClosedString, autoClosedDate);
    DOMUtil.outputXML(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project");
    Node detail = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail");

//    Node sapComments = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcSAPComments");
    Node costCenterEditDate = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcEditDate");
    Node costCenterEditUserId = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/CcEditUId");

    assertEquals("batchuser",DOMUtil.getTextValue(usernamenode));
    assertEquals("batch12!",DOMUtil.getTextValue(passwordNode));
    assertEquals("update",DOMUtil.getAttribute((Element) invoiceNode,"op"));
    assertEquals("1234",DOMUtil.getAttribute((Element) invoiceNode,"NumberString"));
    assertEquals("COST",DOMUtil.getAttribute((Element) detail,"key"));
//    String sapCommentString = DOMUtil.getTextValue(sapComments);
//    assertNotNull(sapCommentString);
//    assertEquals("CcSAPComments,ACCOUNT AUTOCLOSED as of: 12/28/2008",sapCommentString);
    assertNotNull(DOMUtil.getTextValue(costCenterEditDate));
    assertEquals("12/28/2008", DOMUtil.getTextValue(costCenterEditDate));
    assertEquals("vrbethi", DOMUtil.getTextValue(costCenterEditUserId));
  }

  public void testBuildInvoiceAcknowledgementXML() throws Exception {
    XMLBuilder builder = new ChecksVoidsXMLBuilder();
    InvoiceRecord invoiceRecord = MockInvoiceRecordDataUtility.getDefaultInvoiceRecord();
    String isInvoiceAcknowledged = invoiceRecord.getInvoiceSummary().getInvoiceAcknowledged();
    assertNotNull(isInvoiceAcknowledged);
    assertEquals("No",isInvoiceAcknowledged);
    Document document = builder.buildInvoiceAcknowledgementXML(invoiceRecord);
    assertNotNull(document);
    DOMUtil.outputXML(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice");
    assertEquals("batchuser",DOMUtil.getTextValue(usernamenode));
    assertEquals("batch12!",DOMUtil.getTextValue(passwordNode));
    assertEquals("update",DOMUtil.getAttribute((Element) invoiceNode,"op"));
    Node inSentSAP = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InSentSAP");
    assertEquals("No", DOMUtil.getTextValue(inSentSAP));
    NamedNodeMap attributeMap = invoiceNode.getAttributes();
    assertNotNull(attributeMap);
    assertEquals(2,attributeMap.getLength());
    assertNotNull(DOMUtil.getAttribute((Element) invoiceNode,"primaryKey"));//This is make sure that "numberString" attribute is replaced with "primaryKey"
    assertEquals("1234",DOMUtil.getAttribute((Element) invoiceNode,"primaryKey"));

  }

  public void testBuildUpdateVoidCheckXMLWithPrimaryKey_returnsSuccess() throws Exception{
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TestData testData = new TestData();
    VoidCheck testVoidCheckOne = testData.createTestVoidCheckOne();
    Document document = xmlBuilder.buildUpdateVoidCheckXMLWithPrimaryKey(testVoidCheckOne, "5001");
    DOMUtil.outputXML(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice");
    Node detail = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail");

    Node inVoidCode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InVoidCode");
    Node inVoidCheckNumber = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InVoidCheckNumber");
    Node inVoidDate = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InVoidDate");

    assertEquals("batchuser",DOMUtil.getTextValue(usernamenode));
    assertEquals("batch12!",DOMUtil.getTextValue(passwordNode));
    assertEquals("update",DOMUtil.getAttribute((Element) invoiceNode,"op"));
    assertEquals("5001",DOMUtil.getAttribute((Element) invoiceNode,"primaryKey"));
    assertEquals("INVC",DOMUtil.getAttribute((Element) detail,"key"));
    //todo correct for transaction id
    assertEquals("70",DOMUtil.getTextValue(inVoidCode));
    assertEquals("00146",DOMUtil.getTextValue(inVoidCheckNumber));
    assertEquals("2002-12-18",DOMUtil.getTextValue(inVoidDate));
  }
}