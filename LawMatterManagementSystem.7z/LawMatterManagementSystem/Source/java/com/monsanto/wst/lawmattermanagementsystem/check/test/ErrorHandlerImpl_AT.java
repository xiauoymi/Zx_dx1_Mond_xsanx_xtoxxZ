/*
 ErrorHandlerImpl_AT was created on Feb 13, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check.test;

import com.monsanto.Util.FileUtil;
import com.monsanto.wst.lawmattermanagementsystem.check.ErrorHandler;
import com.monsanto.wst.lawmattermanagementsystem.check.ErrorHandlerImpl;
import com.monsanto.wst.lawmattermanagementsystem.check.ChecksProcessingMessage;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriterImpl;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;

import java.io.File;

/**
 * Filename:    $RCSfile: ErrorHandlerImpl_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rrmall $    	 On:	$Date: 2007-04-23 20:35:12 $
 *
 * @author vrbethi
 * @version $Revision: 1.6 $
 */
public class ErrorHandlerImpl_AT extends LMMSBaseTestCase{

  public void testHasCheckBeenWrittenToFile() throws Exception {
    ErrorReportWriter errorReportWriter = new ErrorReportWriterImpl();
    ErrorHandler errorHandler = new ErrorHandlerImpl(errorReportWriter, LMMSConstants.CHECK_ERROR_FILE_NAME);
    ChecksProcessingMessage checksProcessingMessage = new ChecksProcessingMessage();
    checksProcessingMessage.setMessage("Check 00145 Invalid");
    errorHandler.handleError(checksProcessingMessage);
    errorHandler.closeResources();
    String outputString = FileUtil.readFileToString(new File(System.getProperty(LMMSConstants.SYSTEM_PARAM_TEMP_DIR)+LMMSConstants.CHECK_ERROR_FILE_NAME));
    assertTrue(outputString.indexOf("00145")>0);
  }
}