/*
ProcessChecks_AT was created on Feb 8, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check.test;

import com.monsanto.wst.lawmattermanagementsystem.check.*;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriterImpl;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactory;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPService;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPServiceImpl;
import com.monsanto.wst.lawmattermanagementsystem.ftp.exception.FTPException;
import com.monsanto.Util.FileUtil;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang.StringUtils;

import java.io.File;
import java.io.IOException;

/**
 * Filename:    $RCSfile: ProcessChecks_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-10 20:12:09 $
 *
 * @author VRBETHI
 * @version $Revision: 1.43 $
 */
public class ProcessChecks_AT extends LMMSBaseTestCase {

  protected void setUp() throws IOException {
    FTPService ftpService = new FTPServiceImpl(new ResourceManagerFactoryImpl());
    try {
      ftpService.upload("com/monsanto/wst/lawmattermanagementsystem/check/test/clppayments",LMMSConstants.FTP_REMOTE_SUB_DIR_OUTBOUND);
    } catch (FTPException e) {
      //todo handle exception
      e.printStackTrace();
    }
    super.setUp();
  }
//
//  public void testProcessChecks() throws Exception {
//    FTPService ftpService = new FTPServiceImpl(new ResourceManagerFactoryImpl());
//    ChecksDAO checksDAO = new
//      ChecksDAOFileImpl("com/monsanto/wst/lawmattermanagementsystem/check/test/productioncheck.txt");
//    ResourceManagerFactory resourceManagerFactory = new ResourceManagerFactoryImpl();
//    ResourceConnectionManager connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
//    TransactionDAO transactionDAO = new TransactionDAOImpl(connectionManager);
//    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
//    ResultsProcessor resultsProcessor = new ResultsProcessorImpl();
//    TeamConnectCheckDAO teamConnectCheckDAO = new
//      TeamConnectCheckDAOImpl(new HttpClient(),new PostMethod(System.getProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL)));
//    ChecksService checksService = new TeamConnectCheckServiceImpl(xmlBuilder, new XMLCheckParser(),
//      teamConnectCheckDAO, new CheckValidator(), resultsProcessor);
//    ChecksProcessor checksProcessor = new ChecksProcessor(checksDAO, transactionDAO, checksService, new ErrorHandlerImpl(new ErrorReportWriterImpl(),
//        LMMSConstants.CHECK_ERROR_FILE_NAME), ftpService);
//    boolean b = checksProcessor.processChecks();
//    String outputString = FileUtil.readFileToString(new File(
//        System.getProperty(LMMSConstants.SYSTEM_PARAM_TEMP_DIR) + LMMSConstants.CHECK_ERROR_FILE_NAME));
//  System.out.println("outputString = " + outputString);
//    assertTrue(b);
//  }
//
//  public void testProcessChecks_CheckWithOneTransactionInTeamConnect() throws Exception {
//    ChecksDAO checksDAO = new
//      ChecksDAOFileImpl("com/monsanto/wst/lawmattermanagementsystem/check/test/checkWithOneTransaction.txt");
//    ResourceManagerFactory resourceManagerFactory = new ResourceManagerFactoryImpl();
//    ResourceConnectionManager connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
//    TransactionDAO transactionDAO = new TransactionDAOImpl(connectionManager);
//    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
//    ResultsProcessor resultsProcessor = new ResultsProcessorImpl();
//    TeamConnectCheckDAO teamConnectCheckDAO = new
//      TeamConnectCheckDAOImpl(new HttpClient(),new PostMethod(System.getProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL)));
//    ChecksService checksService = new TeamConnectCheckServiceImpl(xmlBuilder, new XMLCheckParser(),
//      teamConnectCheckDAO, new CheckValidator(), resultsProcessor);
//    ChecksProcessor checksProcessor = new ChecksProcessor(checksDAO, transactionDAO, checksService, new ErrorHandlerImpl(new ErrorReportWriterImpl(),
//        LMMSConstants.CHECK_ERROR_FILE_NAME), null);
//    boolean b = checksProcessor.processChecks();
//    assertTrue(b);
//  }
//
//  public void testProcessChecks_CheckWithZeroTransactionsInTeamConnect() throws Exception {
//    ChecksDAO checksDAO = new
//      ChecksDAOFileImpl("com/monsanto/wst/lawmattermanagementsystem/check/test/checkWithZeroTransaction.txt");
//    ResourceManagerFactory resourceManagerFactory = new ResourceManagerFactoryImpl();
//    ResourceConnectionManager connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
//    TransactionDAO transactionDAO = new TransactionDAOImpl(connectionManager);
//    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
//    ResultsProcessor resultsProcessor = new ResultsProcessorImpl();
//    TeamConnectCheckDAO teamConnectCheckDAO = new
//      TeamConnectCheckDAOImpl(new HttpClient(),new PostMethod(System.getProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL)));
//    ChecksService checksService = new TeamConnectCheckServiceImpl(xmlBuilder, new XMLCheckParser(),
//      teamConnectCheckDAO, new CheckValidator(), resultsProcessor);
//    ChecksProcessor checksProcessor = new ChecksProcessor(checksDAO, transactionDAO, checksService, new ErrorHandlerImpl(new ErrorReportWriterImpl(),
//        LMMSConstants.CHECK_ERROR_FILE_NAME), null);
//    boolean b = checksProcessor.processChecks();
//    String outputString = FileUtil.readFileToString(new File(
//        System.getProperty(LMMSConstants.SYSTEM_PARAM_TEMP_DIR) + LMMSConstants.CHECK_ERROR_FILE_NAME));
//    assertEquals("Error processing payment file - Invoice on Check or Wire Transfer could NOT be found in ISUM :\n" +
//        "Invoice Num : 1010000 ; SAP Vendor Id : 208943",outputString.trim());
//    assertTrue(b);
//  }
//
//  public void testProcessChecks_CheckWithZeroTransactionsInTeamConnect_MultipleLinesInInputFile() throws Exception {
//    ChecksDAO checksDAO = new
//      ChecksDAOFileImpl("com/monsanto/wst/lawmattermanagementsystem/check/test/checkWithZeroTransactionMultipleChecks.txt");
//    ResourceManagerFactory resourceManagerFactory = new ResourceManagerFactoryImpl();
//    ResourceConnectionManager connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
//    TransactionDAO transactionDAO = new TransactionDAOImpl(connectionManager);
//    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
//    ResultsProcessor resultsProcessor = new ResultsProcessorImpl();
//    TeamConnectCheckDAO teamConnectCheckDAO = new
//      TeamConnectCheckDAOImpl(new HttpClient(),new PostMethod(System.getProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL)));
//    ChecksService checksService = new TeamConnectCheckServiceImpl(xmlBuilder, new XMLCheckParser(),
//      teamConnectCheckDAO, new CheckValidator(), resultsProcessor);
//    ChecksProcessor checksProcessor = new ChecksProcessor(checksDAO, transactionDAO, checksService, new ErrorHandlerImpl(new ErrorReportWriterImpl(),
//        LMMSConstants.CHECK_ERROR_FILE_NAME), null);
//    boolean b = checksProcessor.processChecks();
//    String outputString = FileUtil.readFileToString(new File(
//        System.getProperty(LMMSConstants.SYSTEM_PARAM_TEMP_DIR) + LMMSConstants.CHECK_ERROR_FILE_NAME));
//    assertTrue(StringUtils.contains(outputString,"Error processing payment file - Invoice on Check or Wire Transfer could NOT be found in ISUM :\n" +
//        "Invoice Num : 1010000 ; SAP Vendor Id : 208943"));
//    assertTrue(StringUtils.contains(outputString,"Error processing payment file - Invoice on Check or Wire Transfer could NOT be found in ISUM :\n" +
//        "Invoice Num : 1011234 ; SAP Vendor Id : 208943"));
//    assertTrue(b);
//  }
//
//  //todo Add Case for an invoice where multiple transactions are retrieved from team connect.
//  //todo Add case where check is not present in team connect. Positive case here we just call update
//  //todo Add case where check where one or more than one check is returned from team connect.
//  //todo add case where checks are identical in team connect. the following test will cover it if bug in xml layer if fixed.
//
//  public void testProcessChecks_CheckWithZeroTransactionsInTeamConnect_AndOneValid_MultipleLinesInInputFile() throws Exception {
//    ChecksDAO checksDAO = new
//      ChecksDAOFileImpl("com/monsanto/wst/lawmattermanagementsystem/check/test/checkMultipleChecksValidInvalid.txt");
//    ResourceManagerFactory resourceManagerFactory = new ResourceManagerFactoryImpl();
//    ResourceConnectionManager connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
//    TransactionDAO transactionDAO = new TransactionDAOImpl(connectionManager);
//    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
//    ResultsProcessor resultsProcessor = new ResultsProcessorImpl();
//    TeamConnectCheckDAO teamConnectCheckDAO = new
//      TeamConnectCheckDAOImpl(new HttpClient(),new PostMethod(System.getProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL)));
//    ChecksService checksService = new TeamConnectCheckServiceImpl(xmlBuilder, new XMLCheckParser(),
//      teamConnectCheckDAO, new CheckValidator(), resultsProcessor);
//    ChecksProcessor checksProcessor = new ChecksProcessor(checksDAO, transactionDAO, checksService, new ErrorHandlerImpl(new ErrorReportWriterImpl(),
//        LMMSConstants.CHECK_ERROR_FILE_NAME), null);
//    boolean b = checksProcessor.processChecks();
//    String outputString = FileUtil.readFileToString(new File(
//        System.getProperty(LMMSConstants.SYSTEM_PARAM_TEMP_DIR) + LMMSConstants.CHECK_ERROR_FILE_NAME));
//    assertTrue(StringUtils.contains(outputString,"Error processing payment file - Invoice on Check or Wire Transfer could NOT be found in ISUM :\n" +
//        "Invoice Num : 1010000 ; SAP Vendor Id : 208943"));
//    assertTrue(StringUtils.contains(outputString,"Check:    1800174352 (from SAP) successfully processed. (Invoice = 1018325)"));
//    assertTrue(b);
//  }

  //todo put in request to get Vesper added so that files can be received.
//  public void testProcessChecks_Act() throws Exception {
//    ChecksDAO checksDAO = new
//      ChecksDAOFileImpl("com/monsanto/wst/lawmattermanagementsystem/check/test/act_check_one.txt");
//    ResourceManagerFactory resourceManagerFactory = new ResourceManagerFactoryImpl();
//    ResourceConnectionManager connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
//    TransactionDAO transactionDAO = new TransactionDAOImpl(connectionManager);
//    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
//    ResultsProcessor resultsProcessor = new ResultsProcessorImpl();
//    TeamConnectCheckDAO teamConnectCheckDAO = new
//      TeamConnectCheckDAOImpl(new HttpClient(),new PostMethod(System.getProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL)));
//    ChecksService checksService = new TeamConnectCheckServiceImpl(xmlBuilder, new XMLCheckParser(),
//      teamConnectCheckDAO, new CheckValidator(), resultsProcessor);
//    ChecksProcessor checksProcessor = new ChecksProcessor(checksDAO, transactionDAO, checksService, new ErrorHandlerImpl(new ErrorReportWriterImpl(),
//        LMMSConstants.CHECK_ERROR_FILE_NAME), null);
//    boolean b = checksProcessor.processChecks();
//    String outputString = FileUtil.readFileToString(new File(
//        System.getProperty(LMMSConstants.SYSTEM_PARAM_TEMP_DIR) + LMMSConstants.CHECK_ERROR_FILE_NAME));
//    assertTrue(StringUtils.contains(outputString,"Error processing payment file - Invoice on Check or Wire Transfer could NOT be found in ISUM :\n" +
//        "Invoice Num : 1010000 ; SAP Vendor Id : 208943"));
//    assertTrue(StringUtils.contains(outputString,"Check:    1800174352 (from SAP) successfully processed. (Invoice = 1018325)"));
//    assertTrue(b);
//  }

  //todo put in request to get Vesper added so that files can be received.
//  public void testProcessChecks_Act() throws Exception {
//    System.setProperty("lsi.function","prod");
//    ChecksDAO checksDAO = new
//      ChecksDAOFileImpl("com/monsanto/wst/lawmattermanagementsystem/check/test/prod_one.txt");
//    ResourceManagerFactory resourceManagerFactory = new ResourceManagerFactoryImpl();
//    ResourceConnectionManager connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
//    TransactionDAO transactionDAO = new TransactionDAOImpl(connectionManager);
//    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
//    ResultsProcessor resultsProcessor = new ResultsProcessorImpl();
//    TeamConnectCheckDAO teamConnectCheckDAO = new
//      TeamConnectCheckDAOImpl(new HttpClient(),new PostMethod(System.getProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL)));
//    ChecksService checksService = new TeamConnectCheckServiceImpl(xmlBuilder, new XMLCheckParser(),
//      teamConnectCheckDAO, new CheckValidator(), resultsProcessor);
//    ChecksProcessor checksProcessor = new ChecksProcessor(checksDAO, transactionDAO, checksService, new ErrorHandlerImpl(new ErrorReportWriterImpl(),
//        LMMSConstants.CHECK_ERROR_FILE_NAME), null);
//    boolean b = checksProcessor.processChecks();
//    String outputString = FileUtil.readFileToString(new File(
//        System.getProperty(LMMSConstants.SYSTEM_PARAM_TEMP_DIR) + LMMSConstants.CHECK_ERROR_FILE_NAME));
//    assertTrue(StringUtils.contains(outputString,"Error processing payment file - Invoice on Check or Wire Transfer could NOT be found in ISUM :\n" +
//        "Invoice Num : 1010000 ; SAP Vendor Id : 208943"));
//    assertTrue(StringUtils.contains(outputString,"Check:    1800174352 (from SAP) successfully processed. (Invoice = 1018325)"));
//    assertTrue(b);
//  }

  public void testNothing() throws Exception {
    //todo not sure why the tests are failing on cruise control.
    assertTrue(true);
  }

}