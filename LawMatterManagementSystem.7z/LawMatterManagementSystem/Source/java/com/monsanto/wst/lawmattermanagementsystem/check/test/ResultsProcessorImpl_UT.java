/*
 ResultsProcessorImpl_UT was created on Mar 6, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.check.test;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.lawmattermanagementsystem.check.ResultsProcessor;
import com.monsanto.wst.lawmattermanagementsystem.check.ResultsProcessorImpl;
import junit.framework.TestCase;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: ResultsProcessorImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-30 20:09:09 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class ResultsProcessorImpl_UT extends TestCase {

  public void testProcessResults_InValidResult_ReturnFalse() throws Exception {
    Document resultFromTeamConnect = DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/check/test/exceptiononupdate.xml");
    ResultsProcessor resultsProcessor = new ResultsProcessorImpl();
    boolean result = resultsProcessor.processResult(resultFromTeamConnect);
    assertFalse(result);
  }

  public void testResults_InvalidResult_ReturnErrorMessage() throws Exception {
    Document resultFromTeamConnect = DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/check/test/InvalidVendorException.xml");
    //ResultsProcessor resultsProcessor = new MockResultProcessorImpl();
    ResultsProcessor resultsProcessor = new ResultsProcessorImpl();
    String exception = resultsProcessor.processResultForInvoiceAcknowledgement(resultFromTeamConnect);
    assertNotNull(exception);
    assertEquals("Only \"Approved Vendors\" may be entered as the vendor for an invoice.", exception);
  }
}