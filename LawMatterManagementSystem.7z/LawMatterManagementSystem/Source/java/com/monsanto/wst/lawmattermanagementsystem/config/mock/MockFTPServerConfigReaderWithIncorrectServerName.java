/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.config.mock;

import com.monsanto.wst.lawmattermanagementsystem.config.ConfigReader;
import com.monsanto.wst.lawmattermanagementsystem.config.exception.ConfigurationException;
import com.monsanto.wst.lawmattermanagementsystem.config.model.ConnectionParams;

/**
 * Filename:    $RCSfile: MockFTPServerConfigReaderWithIncorrectServerName.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-07 23:04:40 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class MockFTPServerConfigReaderWithIncorrectServerName implements ConfigReader {

  public ConnectionParams getConnectionParams(String datasourceType, String databaseName) throws ConfigurationException {
    return new ConnectionParams(null, "21", "incorrect-servername", "dxftp_q08_lawinv", null, "abc123$$", null, null);
  }
}