/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.config.mock;

import com.monsanto.wst.lawmattermanagementsystem.config.ConfigReader;
import com.monsanto.wst.lawmattermanagementsystem.config.exception.ConfigurationException;
import com.monsanto.wst.lawmattermanagementsystem.config.model.ConnectionParams;

/**
 * Filename:    $RCSfile: MockOracleConfigReader.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-26 20:26:45 $
 *
 * @author rdesai2
 * @version $Revision: 1.5 $
 */
public class MockOracleConfigReader implements ConfigReader {

  public ConnectionParams getConnectionParams(String datasourceType, String databaseName) throws ConfigurationException {
    if (databaseName.equalsIgnoreCase("funnel")) {
      return new ConnectionParams("findvl01.monsanto.com", "1521", null, "law_batch", null, "abc_123", null, null);
    }
    if (databaseName.equalsIgnoreCase("erd")) {
      return new ConnectionParams("erd_devl.monsanto.com", "1521", null, "law_batch", null, "July#07", null, null);
    }
    return null;
  }
}