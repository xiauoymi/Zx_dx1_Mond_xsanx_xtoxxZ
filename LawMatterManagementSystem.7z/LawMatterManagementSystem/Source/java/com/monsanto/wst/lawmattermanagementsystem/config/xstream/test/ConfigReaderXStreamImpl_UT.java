/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.config.xstream.test;

import com.monsanto.wst.lawmattermanagementsystem.config.ConfigReader;
import com.monsanto.wst.lawmattermanagementsystem.config.exception.ConfigurationException;
import com.monsanto.wst.lawmattermanagementsystem.config.model.ConnectionParams;
import com.monsanto.wst.lawmattermanagementsystem.config.xstream.ConfigReaderXStreamImpl;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ConfigReaderXStreamImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-12-19 21:26:18 $
 *
 * @author rdesai2
 * @version $Revision: 1.23 $
 */
public class ConfigReaderXStreamImpl_UT extends TestCase {

  private static String currentLSIEnvironment;

  protected void setUp() throws Exception {
    currentLSIEnvironment = System.getProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION);
  }

  protected void tearDown() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, currentLSIEnvironment);
  }

  public void testGetConnectionParams_ForSQLServer_WinEnvironment() throws Exception {
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
    ConnectionParams connectionParams = configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER, LMMSConstants.DATABASE_LAW_TCE);
    assertNotNull(connectionParams);
    assertEquals("localhost", connectionParams.getUrl());
    assertEquals("1433", connectionParams.getPortNumber());
    assertEquals("MAGPIE\\law1d", connectionParams.getServerName());
    assertEquals("testUser", connectionParams.getUserName());
    assertEquals("cursor", connectionParams.getSelectMethod());
    assertEquals("sqlserver_law_tce", connectionParams.getEncryptedPasswordDir());
    assertEquals("East1208!", connectionParams.getPassword());
    assertEquals("http://woodstork.monsanto.com", connectionParams.getUrlBase());
  }

  public void testGetConnectionParams_ForOracle_FunnelDB_WinEnvironment() throws Exception {
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
    ConnectionParams connectionParams = configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_ORACLE, LMMSConstants.DATABASE_FUNNEL);
    assertNotNull(connectionParams);
    assertEquals("findvl01.monsanto.com", connectionParams.getUrl());
    assertEquals("1521", connectionParams.getPortNumber());
    assertEquals(null, connectionParams.getServerName());
    assertEquals("law_batch", connectionParams.getUserName());
    assertEquals("oracle_funnel", connectionParams.getEncryptedPasswordDir());
//    assertEquals("abc_123", connectionParams.getPassword());
//    assertEquals("Sept_2007", connectionParams.getPassword());
  }

  public void testGetConnectionParams_ForOracle_FunnelDB_DevEnvironment() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, "dev");
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
    ConnectionParams connectionParams = configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_ORACLE, LMMSConstants.DATABASE_FUNNEL);
    assertNotNull(connectionParams);
    assertEquals("findvl01.monsanto.com", connectionParams.getUrl());
    assertEquals("1521", connectionParams.getPortNumber());
    assertEquals(null, connectionParams.getServerName());
    assertEquals("law_batch", connectionParams.getUserName());
    assertEquals("oracle_funnel", connectionParams.getEncryptedPasswordDir());
//    assertEquals("abc_123", connectionParams.getPassword());
  }

  public void testGetConnectionParams_ForOracle__FunnelDB_TestEnvironment() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, "test");
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
    ConnectionParams connectionParams = configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_ORACLE, LMMSConstants.DATABASE_FUNNEL);
    assertNotNull(connectionParams);
    assertEquals("fintst01.monsanto.com", connectionParams.getUrl());
    assertEquals("1521", connectionParams.getPortNumber());
    assertEquals("law_batch", connectionParams.getUserName());
    assertEquals("oracle_funnel", connectionParams.getEncryptedPasswordDir());
//    assertEquals("abc_123", connectionParams.getPassword());
  }

  public void testGetConnectionParams_ForOracle_ErdDB_WinEnvironment() throws Exception {
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
    ConnectionParams connectionParams = configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_ORACLE, LMMSConstants.DATABASE_ERD);
    assertNotNull(connectionParams);
    assertEquals("erd_devl.monsanto.com", connectionParams.getUrl());
    assertEquals("1521", connectionParams.getPortNumber());
    assertEquals("law_batch", connectionParams.getUserName());
    assertEquals("oracle_erd", connectionParams.getEncryptedPasswordDir());
//    assertEquals("July#07", connectionParams.getPassword());
  }

  public void testGetConnectionParams_ForOracle_ErdDB_DevEnvironment() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, "dev");
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
    ConnectionParams connectionParams = configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_ORACLE, LMMSConstants.DATABASE_ERD);
    assertNotNull(connectionParams);
    assertEquals("erd_devl.monsanto.com", connectionParams.getUrl());
    assertEquals("1521", connectionParams.getPortNumber());
    assertEquals("law_batch", connectionParams.getUserName());
    assertEquals("oracle_erd", connectionParams.getEncryptedPasswordDir());
//    assertEquals("July#07", connectionParams.getPassword());
  }

  public void testGetConnectionParams_ForOracle_ErdDB_TestEnvironment() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, "test");
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
    ConnectionParams connectionParams = configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_ORACLE, LMMSConstants.DATABASE_ERD);
    assertNotNull(connectionParams);
    assertEquals("erd_devl.monsanto.com", connectionParams.getUrl());
    assertEquals("1521", connectionParams.getPortNumber());
    assertEquals("law_batch", connectionParams.getUserName());
    assertEquals("oracle_erd", connectionParams.getEncryptedPasswordDir());
//    assertEquals("July#07", connectionParams.getPassword());
  }

  public void testGetConnectionParams_ForFTPServer_WinEnvironment() throws Exception {
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
    ConnectionParams connectionParams = configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_FTP_SERVER, null);
    assertNotNull(connectionParams);
    assertEquals(null, connectionParams.getUrl());
    assertEquals("21", connectionParams.getPortNumber());
    assertEquals("dxdev", connectionParams.getServerName());
    assertEquals("dxftp_q08_lawinv", connectionParams.getUserName());
    assertEquals("ftpserver", connectionParams.getEncryptedPasswordDir());
//    assertEquals("Temp123", connectionParams.getPassword());
  }

  public void testGetConnectionParams_ForTeamConnecAdminUser_WinEnvironment() throws Exception {
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
    ConnectionParams connectionParams = configReader.getConnectionParams(LMMSConstants.TEAMCONNECT_ADMIN_USER, null);
    assertNotNull(connectionParams);
    assertEquals("http://w3d.teamconnect.monsanto.com/TeamConnect/login", connectionParams.getUrl());
    assertEquals("vrbethi", connectionParams.getUserName());
    assertEquals("teamconnectadmin", connectionParams.getEncryptedPasswordDir());
//    assertEquals("ram", connectionParams.getPassword());
  }

  public void testGetConnectionParams_ForFTPServer_DevEnvironment() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, "dev");
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
    ConnectionParams connectionParams = configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_FTP_SERVER, null);
    assertNotNull(connectionParams);
    assertEquals(null, connectionParams.getUrl());
    assertEquals("21", connectionParams.getPortNumber());
    assertEquals("dxdev", connectionParams.getServerName());
    assertEquals("dxftp_q08_lawinv", connectionParams.getUserName());
    assertEquals("ftpserver", connectionParams.getEncryptedPasswordDir());
//    assertEquals("Temp123", connectionParams.getPassword());
  }

  public void testGetConnectionParams_ForFTPServer_TestEnvironment() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, "test");
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
    ConnectionParams connectionParams = configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_FTP_SERVER, null);
    assertNotNull(connectionParams);
    assertEquals(null, connectionParams.getUrl());
    assertEquals("21", connectionParams.getPortNumber());
    assertEquals("dxdev", connectionParams.getServerName());
    assertEquals("dxftp_q08_lawinv", connectionParams.getUserName());
    assertEquals("ftpserver", connectionParams.getEncryptedPasswordDir());
//    assertEquals("Temp123", connectionParams.getPassword());
  }

  public void testGetConnectionParams_ForNonExistingConfiguration() throws Exception {
    try {
      ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
      configReader.getConnectionParams("non-existing-datasource", "non-existing-database");
      fail("Required exception not thrown");
    } catch (ConfigurationException e) {
//      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetConnectionParams_ThrowsException_IfSystemPropertyIsNotSet() throws Exception {
    String currentLSIFunction = System.getProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION);
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, "");
    try {
      ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
      configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_ORACLE, LMMSConstants.DATABASE_FUNNEL);
      fail("Required exception not thrown");
    } catch(ConfigurationException e) {
//      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, currentLSIFunction);
  }

  public void testGetConnectionParams_ThrowsException_ForInvalidMethodArguments() throws Exception {
    try {
      ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
      configReader.getConnectionParams(null, LMMSConstants.DATABASE_FUNNEL);
      fail("Required exception not thrown");
    } catch(IllegalArgumentException e) {
//      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
      configReader.getConnectionParams("", LMMSConstants.DATABASE_FUNNEL);
      fail("Required exception not thrown");
    } catch(IllegalArgumentException e) {
//      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetConnectionParams_ThrowsException_ForInvalidConstructorArgument() throws Exception {
    try {
      new ConfigReaderXStreamImpl(null);
      fail("Required exception not thrown");
    } catch(IllegalArgumentException e) {
//      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetConnectionParams_ThrowsException_IfMONCRYPTJVParamNotSet() throws Exception {
    String currentMONCRYPTJVParam = System.getProperty(LMMSConstants.SYSTEM_PARAM_MONCRYPTJV);
    System.setProperty(LMMSConstants.SYSTEM_PARAM_MONCRYPTJV, "");
    ConfigReader configReader = new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_CONFIG);
    try {
      configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_FTP_SERVER, null);
      fail("Required exception not thrown.");
    } catch (ConfigurationException e) {
//      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    System.setProperty(LMMSConstants.SYSTEM_PARAM_MONCRYPTJV, currentMONCRYPTJVParam);
  }

  public void testGetConnectionParams_ThrowsException_IfEncryptedDirNotSetInConfigXML() throws Exception {
    ConfigReader configReader = new ConfigReaderXStreamImpl("com/monsanto/wst/lawmattermanagementsystem/config/xstream/test/TestConnectionConfigurations.xml");
    try {
      configReader.getConnectionParams(LMMSConstants.DATASOURCE_TYPE_FTP_SERVER, null);
      fail("Required exception not thrown.");
    } catch (ConfigurationException e) {
//      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }
}