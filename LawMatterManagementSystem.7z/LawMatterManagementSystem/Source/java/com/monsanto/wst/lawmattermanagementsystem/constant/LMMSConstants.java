/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.constant;

import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;

import java.util.ArrayList;
import java.util.List;
import java.io.File;

/**
 * Filename:    $RCSfile: LMMSConstants.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-02-10 19:07:38 $
 *
 * @author rdesai2
 * @version $Revision: 1.99 $
 */
public abstract class LMMSConstants {

  public static final String APP_NAME = "lmms";

  public static final String DATE_PATTERN_FOR_INVOICE_PROCESSING = "yyyyMMddHHmm";

  public static final String SYSTEM_SECURITY_PROXY = "SYSTEM_SECURITY_PROXY";

  public static final String EMPTY_STRING = "";

  //System/JVM Parameter names...
  public static final String SYSTEM_PARAM_LSI_FUNCTION = "lsi.function";
  public static final String SYSTEM_PARAM_HISTORY_DIR = "lmms.history.dir";
  public static final String SYSTEM_PARAM_LAST_RUN_INFO_DIR = "lmms.lastruninfo.dir";
  public static final String SYSTEM_PARAM_CONFIG_DIR = "lmms.config.dir";
  public static final String SYSTEM_PARAM_TEMP_DIR = "java.io.tmpdir";
  public static final String SYSTEM_PARAM_MONCRYPTJV = "MONCRYPTJV";
  public static final String SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL = "teamconnect.webservice.url";

  public static final String LSI_FUNCTION_PROD = "prod";
  public static final String LSI_FUNCTION_TEST = "test";
  public static final String LSI_FUNCTION_DEV = "dev";
  public static final String LSI_FUNCTION_WIN = "win";

  //Files...
  public static final String FILE_NAME_INVOICE_RFBIBLE_FILE = "clpinv" + DateUtil.getCurrentDate(DATE_PATTERN_FOR_INVOICE_PROCESSING) + ".txt";
  public static final String FILE_NAME_SUMMARY_REPORT_FILE = "Summ_Rep_" + DateUtil.getCurrentDate(DATE_PATTERN_FOR_INVOICE_PROCESSING) + ".dat";
  public static final String FILE_NAME_REJECTION_REPORT_FILE = "Rej_Rep_" + DateUtil.getCurrentDate(DATE_PATTERN_FOR_INVOICE_PROCESSING) + ".dat";
  public static final String FILE_NAME_ERROR_REPORT_FILE = "Err_Rep_" + DateUtil.getCurrentDate(DATE_PATTERN_FOR_INVOICE_PROCESSING) + ".dat";
  public static final String FILE_NAME_LAST_RUN_INFO_FILE = "LastInvoiceProcessingRunInfo.xml";
  public static final String FILE_NAME_PRODUCTION_DATE_INFO_FILE = "ProductionDate.xml";
  public static final String FILE_NAME_CUSTOM_DATE_INFO_FILE = "CustomDate.xml";
  public static final String FILE_NAME_EMAIL_LIST_FILE = "SAPNotificationRecipientList.xml";
  public static final String FILE_NAME_INPUT_VOIDS = System.getProperty("lmms.history.dir")+ File.separator+"voids.txt";
  public static final String FILE_NAME_BACKUP_VOIDS = System.getProperty("lmms.history.dir")+ File.separator+"voids_bckup"+DateUtil.getCurrentDate(DATE_PATTERN_FOR_INVOICE_PROCESSING) + ".txt";
  public static final String FILE_NAME_INPUT_CHECKS = System.getProperty("lmms.history.dir")+ File.separator+"checks.txt";
  public static final String FILE_NAME_BACKUP_CHECKS = System.getProperty("lmms.history.dir")+ File.separator+"checks_bckup"+DateUtil.getCurrentDate(DATE_PATTERN_FOR_INVOICE_PROCESSING) + ".txt";

  public static final String FILE_NAME_PROPERTY_LIST_FILE = "PropertyList.xml";
  //Todo...make this file external to project...available from 'lmms.config.dir' directory
  public static final String XML_CONNECTION_CONFIG = "com/monsanto/wst/lawmattermanagementsystem/config/ConnectionConfigurations.xml";

  public static final String XML_CONNECTION_EXTERNAL_CONFIG = System.getProperty("lmms.config.dir")+ File.separator+
  "ConnectionConfigurations.xml";
  //Database Names...
  public static final String DATABASE_FUNNEL = "funnel";
  public static final String DATABASE_ERD = "erd";

  public static final String DATABASE_LAW_TCE = "LAW_TCE";
  //FTP Remote Sub Directories...
  public static final String FTP_REMOTE_SUB_DIR_INBOUND = "inbound";

  public static final String FTP_REMOTE_SUB_DIR_OUTBOUND = "outbound";
  //Datasource Types...
  public static final String DATASOURCE_TYPE_ORACLE = "oracle";
  public static final String DATASOURCE_TYPE_SQL_SERVER = "sqlserver";

  public static final String DATASOURCE_TYPE_FTP_SERVER = "ftpserver";
  public static final String TEAMCONNECT_ADMIN_USER = "teamconnect_admin";
  //XStream alias/mapping names...
  public static final String ALIAS_CONNECTION_PARAMS = "connectionparams";
  public static final String ALIAS_EMAIL_LIST = "SAPNotificationRecipients";
  public static final String ALIAS_EMAIL_INFO = "EmailInfo";
  public static final String ALIAS_LAST_RUN_INFO = "LastRunInfo";
  public static final String ALIAS_PROPERTY_LIST = "PropertyList";

  public static final String ALIAS_PROPERTY = "Property";
  //Error Messages during SAP AccountCode Validation
  public static final String SAP_ERROR_MSG_BAD_COMPANY_CODE = "Bad Company Code";
  public static final String SAP_ERROR_MSG_BAD_BUSINESS_CODE = "Bad Business Code";
  public static final String SAP_ERROR_MSG_BAD_COST_ELEMENT = "Bad Cost Element";
  public static final String SAP_ERROR_MSG_BAD_COMPANY_COST_ELEMENT_COMBINATION = "Bad Company/CostElement Combination";
  public static final String SAP_ERROR_MSG_BAD_ACCOUNT_CODE= "Bad Account Code (Combination of Company-Business-Cost Element)";
  public static final String SAP_ERROR_MSG_BAD_COST_CENTER = "Bad Cost Center";
  public static final String SAP_ERROR_MSG_EMPTY_COST_CENTER = "Empty Cost Center";
  public static final String SAP_ERROR_MSG_BAD_COST_CENTER_FOR_COMPANY_BUSNESS_COMBINATION = "Bad Cost Center for this Company/Business";
  public static final String SAP_ERROR_MSG_INVALID_BALSHEET = "Cost Center SHOULD NOT BE PRESENT on BALSHEET ACCTS!";
  public static final String SAP_ERROR_MSG_BAD_COMPANY_BUSINESS_COMBINATION = "Bad Company/Business Combination";

  public static final String SAP_ERROR_MSG_BAD_VENDOR_FOR_COMPANY = "BAD VENDOR FOR COMPANY!";

  public static final String INFO_MSG_NO_PROFIT_CENTER_FOUND = "*INFO ONLY* NO PROFIT CENTER FOUND IN CLP";
  public static final String VALIDATION_ERROR_INVOICE_NUMBER_TOO_LONG = "Inv. Number too long !";
  public static final int MAX_LENGTH_INVOICE_NUMBER = 16;

  public static final String VALIDATION_ERROR_MSG_NO_NON_ZERO_ALLOCATION_AMOUNT_FOUND = "FC Allocation missing !";
  //XML File Template Names....
  public static final String XML_TEMPLATE_INVOICE_FILE_HEADER = "com/monsanto/wst/lawmattermanagementsystem/invoice/service/template/InvoiceFileHeaderTemplate.xml";
  public static final String XML_TEMPLATE_INVOICE_RECORD_HEADER = "com/monsanto/wst/lawmattermanagementsystem/invoice/service/template/InvoiceRecordHeaderTemplate.xml";
  public static final String XML_TEMPLATE_INVOICE_RECORD = "com/monsanto/wst/lawmattermanagementsystem/invoice/service/template/InvoiceRecordTemplate.xml";
  public static final String XML_TEMPLATE_REPORT_HEADER = "com/monsanto/wst/lawmattermanagementsystem/invoice/service/template/ReportHeaderTemplate.xml";
  public static final String XML_TEMPLATE_SUMMARY_REPORT_RECORD = "com/monsanto/wst/lawmattermanagementsystem/invoice/service/template/SummaryReportRecordTemplate.xml";
  public static final String XML_TEMPLATE_SUMMARY_FOOTER = "com/monsanto/wst/lawmattermanagementsystem/invoice/service/template/SummaryReportFooterTemplate.xml";

  public static final String XML_TEMPLATE_REJECTION_REPORT_RECORD = "com/monsanto/wst/lawmattermanagementsystem/invoice/service/template/RejectionReportRecordTemplate.xml";
  public static final String NEW_LINE_CONSTANT = "\r\n";
  public static final String N_A_CONSTANT = "n/a";

  public static final String SPACE_CONSTANT = " ";
  public static final String PRACTICE_AREA_ENVIRN = "ENVIRN";

  public static final String PRACTICE_AREA_LITIG = "LITIG";

  public static final String JURISDICTION_FOR_TAX_CALCULATION = "MO6314101";

  public static final String SAP_DEFAULT_COLUMN_VALUE = "~";
  public static final String ERROR_MSG_REJECTION_REPORT_ALLOCATION_LIST_SIZE_SMALLER_THAN_ERRONEOUS_ALLOCATION_NUMBER = "Cannot initialize RejectionReportRecord Variable: Allocation size is smaller than the erroneous allocation number.";
  public static final String ERROR_MSG_REJECTION_REPORT_NULL_INVOICE_RECORD = "Cannot initialize RejectionReportRecord Variable: Null Invoice Record.";
  public static final String ERROR_MSG_SUMMARY_REPORT_NULL_INVOICE_RECORD = "Cannot initialize SummaryReportRecord Variable: Null Invoice Record.";
  public static final String ERROR_MSG_RECORD_4050_NULL_INVOICE_RECORD = "Cannot initialize 40/50 Record Variable: Null Invoice Record.";
  public static final String ERROR_MSG_RECORD_4050_ALLOCATION_LIST_SIZE_SMALLER_THAN_ALLOCATION_NUMBER = "Cannot initialize 40/50 Record Variable: Allocation size is smaller than the requested allocation number: ";
  public static final String ERROR_MSG_RECORD_2131_NULL_INVOICE_RECORD = "Cannot initialize 21/31 Record Variable: Null Invoice Record.";

  public static final String ERROR_MSG_RECORD_2131_EMPTY_ALLOCATION_LIST = "Cannot initialize 40/50 Record Variable: Empty Allocation List.";
  public static final String PATTERN_DATE_REPORT_HEADER = "MM/dd/yyyy HH:mm";
  public static final String PATTERN_AMOUNT = "0.00";

  public static final String PATTERN_VENDOR_ID = "0000000000";
  public static final String SUMMARY_REPORT_NAME = "Invoice Summary Report ";
  public static final String SUMMARY_REPORT_TOTAL_INVOICES = "Total Number of invoices in  file";

  public static final String SUMMARY_REPORT_TOTAL_INVOICE_AMOUNT = "Total Amount for ALL invoices";

  public static final String REJECTION_REPORT_NAME = "Rejects in CLP invoice data ";
  //Email Comstants...
  public static final String EMAIL_CONST_FROM = "Law_SAP_Interface@monsanto.com";

  public static final String EMAIL_CONST_SUBJECT = "SAP Upload/Download Notification";

  public static final List EMAIL_CONST_DEFAULT_MESSAGE_LINES;

  static {
    EMAIL_CONST_DEFAULT_MESSAGE_LINES = new ArrayList();
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add("**************************************************************************");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add("Message originated from [LAW, SAP Interface].");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add("**************************************************************************");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add(" ");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add(" ");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add("You may wish to verify the success of the upload with SAP.");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add(" ");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add("Attached are the reports of this activity :");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add(" ");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add("1. Invoice Summary Report (lists all transactions sent to SAP - first attachment)");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add(" ");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add("2. Reject Report (Lists all invalid data in CLP within the data that was eligible to be sent to SAP - second attachment)");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add(" ");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add("3. Error Report (Lists processing errors - Notify system support if not empty - Third attachment)");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add(" ");
    EMAIL_CONST_DEFAULT_MESSAGE_LINES.add(" ");
  }

  public static final String EMAIL_SUCCESS_MESSAGE_LINE = "The name of the file copied to SAP is : ";

  public static final String EMAIL_NO_ELIGIBLE_INVOICES_FOUND = "No eligible invoices were found today";

  public static final List EMAIL_FAILURE_MESSAGE_LINES;

  static {
    EMAIL_FAILURE_MESSAGE_LINES = new ArrayList();
    EMAIL_FAILURE_MESSAGE_LINES.add("The CLP/SAP process FAILED !!");
    EMAIL_FAILURE_MESSAGE_LINES.add("(No files were copied to SAP.)");
    EMAIL_FAILURE_MESSAGE_LINES.add(" ");
    EMAIL_FAILURE_MESSAGE_LINES.add("Please check the Error report for more details.");
  }

  public static final String MSG_INVOICES_PROCESSED_NORMAL_PROGRAM_TERMINATION = "*** INVOICES PROCESSED, NORMAL PROGRAM TERMINATION ***";
  public static final String ATTENTION_TYPE_TO = "TO";  //People addressed as "TO" while sending actual status emails
  public static final String ATTENTION_TYPE_CC = "CC";  //People addressed as "CC" while sending actual status emails

  public static final String ATTENTION_TYPE_ADMIN = "ADMIN";  //Incase of unexpected error emails will be sent only to these administrators
  public static final String CHECK_ERROR_FILE_NAME = "checks_" + DateUtil.getCurrentDate(DATE_PATTERN_FOR_INVOICE_PROCESSING) + ".txt";
  public static final String BATCH_AC_SUMMARY_FILE_NAME = "Sapmaster_AutoClose_" + DateUtil.getCurrentDate(DATE_PATTERN_FOR_INVOICE_PROCESSING) + ".dat";

  public static final String VOIDS_ERROR_FILE_NAME = "voids_" + DateUtil.getCurrentDate(DATE_PATTERN_FOR_INVOICE_PROCESSING) + ".txt"; ;

  public static final String PROPERTY_CONTACT_NAME = "Contact Name";
  public static final String PROPERTY_SKIP_FILE_FTP = "Skip File FTP";
  public static final String PROPERTY_REPOST_FOR_SPECIFIC_DATE = "Repost For Specific Date";
  public static final String PROPERTY_REPOST_DATE = "Repost Date";

  public static final String PROPERTY_BOX_ID = "Box Id";
  public static final String PROPERTY_TEAMCONNECT_WEBSERVICE_URL = "TeamConnect WebService URL";
  public static final String DATE_FORMAT_FOR_INVOICE_QUERY_SAP_SENT_DATE = "MM/dd/yyyy";
  public static final String DATE_FORMAT_FOR_INVOICE_QUERY = "yyyy-MM-dd HH:mm:ss";

  public static final String DATE_FORMAT_FOR_LAST_SUCCESSFUL_RUN_DATE = "MM/dd/yyyy";
  public static final String DATE_FORMAT_FOR_UPDATE_INVOICE_TEAMCONNECT_REQUEST = "yyyy-MM-dd";
  public static final String DATE_FORMAT_FOR_DOCUMENT_INDEXING = "MM/dd/yyyy HH:mm:ss";
  public static final String COMPANY_CODE_5114 = "5114";
  public static final String COMPANY_CODE_5180 = "5180";
//  public static final String DOCUMENT_IMPORT_OUTPUTFILE = "documentImport.dat";
  public static final String DOCUMENT_IMPORT_OUTPUTFILE =  "DocumentIndexingResults_"+DateUtil.getCurrentDate(DATE_PATTERN_FOR_INVOICE_PROCESSING)+".txt";
  public static final String ACCOUNT_CODE_EMAIL_CONST_SUBJECT = "Account Code batch Summary Report";
  public static final String CHECKS_VOIDS_EMAIL_CONST_SUBJECT = "Checks/Voids batch Summary Report";
  public static final String VOIDS_LOG_FILE_NAME = System.getProperty("lmms.history.dir")+ File.separator+"voids_" + DateUtil.getCurrentDate(DATE_PATTERN_FOR_INVOICE_PROCESSING) + "_log.txt"; ;
}