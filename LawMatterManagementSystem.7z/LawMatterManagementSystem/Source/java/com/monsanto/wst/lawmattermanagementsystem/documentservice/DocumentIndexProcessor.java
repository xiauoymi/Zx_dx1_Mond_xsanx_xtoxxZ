package com.monsanto.wst.lawmattermanagementsystem.documentservice;

import com.monsanto.wst.lawmattermanagementsystem.mitratech.test.MockMitratechHttpSession;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos.DocumentPOSServiceFactory;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcessorFactory;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcessorFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcess;
import com.monsanto.wst.lawmattermanagementsystem.check.ChecksVoidsXMLBuilder;
import com.monsanto.wst.lawmattermanagementsystem.check.ChecksProcessingMessage;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.LastRunInfoDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.LastRunInfoDAO;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.Util.StringUtils;
import com.monsanto.Util.date.DateUtil;
import com.monsanto.xmlserialization.XmlSerializerBuilder;

import javax.servlet.http.HttpSession;

import org.w3c.dom.Document;
import org.apache.commons.lang.time.DateUtils;

import java.io.*;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Aug 4, 2008
 * Time: 12:15:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentIndexProcessor {
  
  private static String lastRunInfoDir = "";
  XmlSerializerBuilder xmlSerializerBuilder ;
  LastRunInfoDAO dao ;
  DocumentService documentService;
  HttpSession httpSession;
  DocumentImportProcessorFactory documentImportProcessorFactory;

  public DocumentIndexProcessor() {
    xmlSerializerBuilder = new XmlSerializerBuilder();
    dao = new LastRunInfoDAOImpl(xmlSerializerBuilder);
    documentService = new DocumentPOSServiceFactory().getDocumentService();
    httpSession = new MockMitratechHttpSession();
    documentImportProcessorFactory = new DocumentImportProcessorFactoryImpl();
  }

  public void runDocumentIndexingProcess() throws Exception {
    ChecksVoidsXMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    ChecksProcessingMessage message = new ChecksProcessingMessage();
    Date customDate = getCustomDate();
    Date currentDate = new Date();
    int numberOfDays = DateUtil.getHowManyDays(customDate, currentDate);
    String customDateString = "";
    if (numberOfDays == 0) {//This means the current day
      customDateString = new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_DOCUMENT_INDEXING).format(customDate);
      uploadIndexedDocuments(documentService, httpSession, documentImportProcessorFactory, xmlBuilder, customDateString,message);
    } else {
      for (int i = 0; i < numberOfDays; i++) {
        customDateString = new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_DOCUMENT_INDEXING).format(DateUtils.addDays(customDate, i));
        uploadIndexedDocuments(documentService, httpSession, documentImportProcessorFactory, xmlBuilder, customDateString,message);
      }
    }
    updateCustomDate();
  }

  private void uploadIndexedDocuments(DocumentService documentService, HttpSession httpSession, DocumentImportProcessorFactory documentImportProcessorFactory, ChecksVoidsXMLBuilder xmlBuilder, String customDateString, ChecksProcessingMessage message) throws Exception {
    DocumentImportProcess documentImportProcessor;
    documentImportProcessor = documentImportProcessorFactory.getDocumentImportProcessor();
    Document searchDocument = xmlBuilder.buildCustomDateSearchRequestDocument(customDateString);
    DOMUtil.outputXML(searchDocument);
    //Do a search
    InputStream returnInsertDocumentStream = documentService.search(searchDocument, httpSession);
    Document document = DOMUtil.newDocument(returnInsertDocumentStream);
    DOMUtil.outputXML(document);
    String fileName = writeXMLToFile(document);
    documentImportProcessor.importCustomDateDocumentMetaData(fileName,message);
    deleteFileIfPresent(fileName);
  }

  private void updateCustomDate() throws Exception {
    dao.updateLastSuccessfulRunDate(getCustomDateFileName());
  }

  private void deleteFileIfPresent(String fileName) {
    File file = new File(fileName);
    if (file.exists()) {
      file.delete();
    }
  }

  private String writeXMLToFile(Document document) throws Exception {
    String fileName = getLastRunInfoDirectory() + "\\Output.xml";
    deleteFileIfPresent(fileName);
    Writer fileWriter = new BufferedWriter(new FileWriter(fileName));
    fileWriter.write(DOMUtil.XMLToString(document));
    fileWriter.flush();
    fileWriter.close();
    return fileName;
  }

  private String getLastRunInfoDirSystemParam() throws Exception {
    lastRunInfoDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR);
    if (StringUtils.isNullOrEmpty(lastRunInfoDir)) {
      throw new Exception("Run Time parameter Last Run Info directory '-D" + LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR + "' Not Found.");
    }
    return lastRunInfoDir;
  }

  private String getCustomDateFileName() throws Exception {
    return getLastRunInfoDirectory() + File.separator + LMMSConstants.FILE_NAME_CUSTOM_DATE_INFO_FILE;
  }

  private String getLastRunInfoDirectory() throws Exception {
    return getLastRunInfoDirSystemParam();
  }

  public Date getCustomDate() throws Exception {
    return dao.readLastSuccessfulRunDate(getCustomDateFileName());
  }
}
