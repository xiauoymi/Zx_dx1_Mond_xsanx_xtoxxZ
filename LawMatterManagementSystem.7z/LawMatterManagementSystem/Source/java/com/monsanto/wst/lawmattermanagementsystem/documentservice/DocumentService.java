/*
 DocumentPOSService was created on Sep 21, 2006 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.documentservice;

import com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.DocumentException;
import org.w3c.dom.Document;

import javax.servlet.http.HttpSession;
import java.io.InputStream;

/**
 * Filename:    $RCSfile: DocumentService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 16:11:21 $
 *
 * @author vrbethi
 * @version $Revision: 1.4 $
 */
public interface DocumentService {

  /**
   * Method upoalds documents to Documentum
   * @param inputDocument Document containing the attributes of the files to be inserted (refer documentaion for exact details)
   * @param filePath Path of the file to be inserted
   * @param httpSession
   * @return
   * @throws com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.DocumentException
   */
  InputStream upload(Document inputDocument, String filePath, HttpSession httpSession) throws com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.DocumentException;

  /**
   * Method downloads documents from Documentum
   * @param inputDocument Document containing file requested (refer documentaion for exact details)
   * @param httpSession
   * @return
   * @throws com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.DocumentException
   */
  InputStream download(Document inputDocument, HttpSession httpSession) throws com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.DocumentException;

  /**
   * Method that deletes documents from Documentum
   * @param inputDocumentDelete Input document containing details of the document to be deleted (refer documentaion for exact details)
   * @param httpSession
   * @return
   * @throws com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.DocumentException
   */
  InputStream delete(Document inputDocumentDelete, HttpSession httpSession) throws DocumentException;

  /**
   * Method updates document with the same object id in documentum
   * @param inputUpdateDocument Document containing the attributes of the files to be update (refer documentaion for exact details)
   * @param filePath Path of the file to be updated
   * @param httpSession
   * @return
   * @throws DocumentException
   */
  InputStream update(Document inputUpdateDocument,String filePath,HttpSession httpSession)throws DocumentException;

  InputStream search(Document inputDocumentInsert, HttpSession httpSession) throws DocumentException;
}