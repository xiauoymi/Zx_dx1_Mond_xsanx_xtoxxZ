/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.documentservice;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.FactoryConfigurationException;


/**
 * Filename:    $RCSfile: DocumentServiceFactory.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public abstract class DocumentServiceFactory {

  public static final String SYSTEM_PROPERTY_DOCUMENT_SERVICE_FACTORY_IMPL = "lmms.documentservice.factoryimpl";

  /**
   * Looks up the classpath from a System property and determines the correct implementation of factory
   *
   * @return DocumentServiceFactory
   */
  public static DocumentServiceFactory getFactory() throws FactoryConfigurationException {
    String classpath = System.getProperty(SYSTEM_PROPERTY_DOCUMENT_SERVICE_FACTORY_IMPL);
    if(classpath == null || "".equalsIgnoreCase(classpath)){
      throw new FactoryConfigurationException("Please set the system property '"
              + SYSTEM_PROPERTY_DOCUMENT_SERVICE_FACTORY_IMPL + "' to the classpath for document service factory impl.");
    }
    try {
      return (DocumentServiceFactory) Class.forName(classpath).newInstance();
    } catch (ClassNotFoundException e) {
      Logger.log(new LoggableError(e));
      throw new FactoryConfigurationException("ClassNotFoundException while getting DocumentServiceFactory Impl: " + e.getMessage(), e);
    } catch (InstantiationException e) {
      Logger.log(new LoggableError(e));
      throw new FactoryConfigurationException("InstantiationException while getting DocumentServiceFactory Impl: " + e.getMessage(), e);
    } catch (IllegalAccessException e) {
      Logger.log(new LoggableError(e));
      throw new FactoryConfigurationException("IllegalAccessException while getting DocumentServiceFactory Impl: " + e.getMessage(), e);
    }
  }

  /**
   * Returns concrete implementation for document-service
   *
   * @return DocumentService
   */
  public abstract DocumentService getDocumentService();
}