/*
 SecureXMLPOSConnectionSession was created on Jan 26, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.documentservice;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.DocumentException;
import org.w3c.dom.Document;

import javax.servlet.http.HttpSession;

/**
 * Filename:    $RCSfile: SecureXMLPOSConnectionSession.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-01-29 19:34:08 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public class SecureXMLPOSConnectionSession extends SecureXMLPOSConnection{
    public SecureXMLPOSConnectionSession(HttpSession session) {
        super(new KerberosSPNEGOClient(new OSBasedGSSManagerFactory()), (SystemSecurityProxy) session.getAttribute(LMMSConstants.SYSTEM_SECURITY_PROXY));
    }

    public POSResult callDocumentService(Document inputDocument, String posName) throws DocumentException {
        POSResult result;
        try {
            result = callService(posName, inputDocument);
        } catch (POSCommunicationException e) {
            Logger.log(new LoggableError(e));
            throw new DocumentException("Communication Exception",e);
        } catch (POSException e) {
            Logger.log(new LoggableError(e));
            throw new DocumentException("Error during insertion of Document",e);
        }
        return result;
    }
}