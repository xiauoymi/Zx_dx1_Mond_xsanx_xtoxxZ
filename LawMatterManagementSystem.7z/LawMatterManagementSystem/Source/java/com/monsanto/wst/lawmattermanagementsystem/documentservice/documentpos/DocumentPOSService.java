/*
DocumentService was created on Sep 7, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.POSClient.InvalidMimeTypeException;
import com.monsanto.POSClient.MultiPartFormAttachment;
import com.monsanto.POSClient.MultipartAttachmentList;
import com.monsanto.POSClient.POSMIMEConstants;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.DocumentService;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.SecureXMLPOSConnectionSession;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.DocumentException;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;

import javax.servlet.http.HttpSession;
import java.io.InputStream;

/**
 * Filename:    $RCSfile: DocumentPOSService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-02-10 19:08:14 $
 *
 * @author vrbethi
 * @version $Revision: 1.11 $
 */
public class DocumentPOSService implements DocumentService {
    private POSConnectionFactory sucureXMLConnectionFactory;

    public DocumentPOSService(POSConnectionFactory sucureXMLConnectionFactory) {
        this.sucureXMLConnectionFactory = sucureXMLConnectionFactory;
    }

    public InputStream upload(Document inputDocument, String filePath, HttpSession httpSession) throws DocumentException {
        SecureXMLPOSConnectionSession connection =  sucureXMLConnectionFactory.getSecureXMLPOSConnectionSession(httpSession);
        MultiPartFormAttachment multiPartFormAttachment = createMultiPartFormAttachment(filePath);
        connection.addAttachment(multiPartFormAttachment);
        DOMUtil.outputXML(inputDocument);
        return connection.callDocumentService(inputDocument, "InsertDocumentService").getInputStream();
    }

    public InputStream download(Document inputDocument, HttpSession httpSession) throws DocumentException {
        return invokeService("RetrieveDocumentService", inputDocument, httpSession);
    }

    public InputStream delete(Document inputDocumentDelete, HttpSession httpSession) throws DocumentException {
        return invokeService("DeleteDocumentService", inputDocumentDelete, httpSession);
    }

    private InputStream invokeService(String posName, Document inputDocumentDelete, HttpSession httpSession) throws DocumentException {
        SecureXMLPOSConnectionSession connection = sucureXMLConnectionFactory.getSecureXMLPOSConnectionSession(httpSession);
        InputStream inputStream = connection.callDocumentService(inputDocumentDelete,posName).getInputStream();
        return inputStream;
    }

    public InputStream update(Document inputUpdateDocument, String filePath, HttpSession httpSession) throws DocumentException {
        SecureXMLPOSConnectionSession connection = sucureXMLConnectionFactory.getSecureXMLPOSConnectionSession(httpSession);
        MultiPartFormAttachment multiPartFormAttachment = createMultiPartFormAttachment(filePath);
        connection.addAttachment(multiPartFormAttachment);
        DOMUtil.outputXML(inputUpdateDocument);
        return connection.callDocumentService(inputUpdateDocument, "UpdateDocumentService").getInputStream();
    }

  public InputStream search(Document inputDocumentSearch, HttpSession httpSession) throws DocumentException {
    return invokeService("SearchDocumentsService", inputDocumentSearch, httpSession);      
  }


  private MultiPartFormAttachment createMultiPartFormAttachment(String filePath) throws DocumentException {
        MultipartAttachmentList multipartAttachmentList = new MultipartAttachmentList();
        multipartAttachmentList.addAttachment(createMultipartForm(filePath));
        return createMultipartForm(filePath);
    }

    private MultiPartFormAttachment createMultipartForm(String filePath) throws DocumentException {
        MultiPartFormAttachment multiPartFormAttachment;
        try {
            multiPartFormAttachment = new MultiPartFormAttachment(filePath,POSMIMEConstants.MIME_TYPE_TEXT);
        } catch (InvalidMimeTypeException e) {
            Logger.log(new LoggableError(e));
            throw new DocumentException("Invalid Mime Type",e);
        }
        return multiPartFormAttachment;
    }
}