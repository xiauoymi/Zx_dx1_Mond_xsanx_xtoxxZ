/*
 DocumentPOSServiceFactory was created on Sep 28, 2006 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos;

import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.DocumentService;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.DocumentServiceFactory;
import com.monsanto.wst.lawmattermanagementsystem.servlet.LawMatterManagementSystemLoggerFactory;

import java.io.IOException;

/**
 * Filename:    $RCSfile: DocumentPOSServiceFactory.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author vrbethi
 * @version $Revision: 1.4 $
 */
public class DocumentPOSServiceFactory extends DocumentServiceFactory {

  public DocumentService getDocumentService() {
    initializeLogging();
    return new com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos.DocumentPOSService(new SucureXMLConnectionFactory());
  }

  private void initializeLogging() {
    try {
      LawMatterManagementSystemLoggerFactory loggerFactory = new LawMatterManagementSystemLoggerFactory();
      loggerFactory.setupLogging();
    }
    catch (LogRegistrationException lre) {
      System.out.println(lre);
    }
    catch (IOException ioe) {
      System.out.println(ioe);
    }
  }
}