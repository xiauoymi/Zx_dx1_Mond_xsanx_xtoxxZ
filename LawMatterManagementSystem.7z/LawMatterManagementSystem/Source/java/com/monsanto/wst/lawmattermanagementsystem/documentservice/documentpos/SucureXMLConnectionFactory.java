/*
 SucureXMLConnectionFactory was created on Jan 26, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos;

import com.monsanto.wst.lawmattermanagementsystem.documentservice.SecureXMLPOSConnectionSession;

import javax.servlet.http.HttpSession;

/**
 * Filename:    $RCSfile: SucureXMLConnectionFactory.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-01-29 19:34:07 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class SucureXMLConnectionFactory implements POSConnectionFactory{
    public SecureXMLPOSConnectionSession getSecureXMLPOSConnectionSession(HttpSession httpSession) {
        SecureXMLPOSConnectionSession connection = new SecureXMLPOSConnectionSession(httpSession);
        return connection;
    }
}