/*
DocumentPOSService_AT was created on Sep 7, 2006 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos.acceptancetest;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.DocumentService;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.DocumentException;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos.DocumentPOSServiceFactory;
import com.monsanto.wst.lawmattermanagementsystem.util.DocumentUtil;
import com.monsanto.wst.lawmattermanagementsystem.mitratech.test.MockMitratechHttpSession;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.*;
import com.monsanto.wst.commonutils.testutils.TestUtils;
import com.monsanto.Util.StringUtils;
import junit.framework.TestCase;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;

import javax.servlet.http.HttpSession;
import javax.xml.transform.TransformerException;
import javax.xml.stream.XMLStreamWriter;
import java.io.*;
import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: DocumentPOSService_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-11-19 18:32:11 $
 *
 * @author vrbethi
 * @version $Revision: 1.19 $
 */
public class DocumentPOSService_AT extends TestCase {
  
  HttpSession httpSession;
  DocumentService documentService;
  String objectId= "";
  public DocumentPOSService_AT(String name) {
    super(name);
  }

  public void setUp() throws Exception{
    httpSession = new MockMitratechHttpSession();
    documentService = new DocumentPOSServiceFactory().getDocumentService();
    Document docToBeSearched = DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/searchDocument.xml");
    InputStream stream = documentService.search(docToBeSearched,httpSession);
    Document returnedDoc = DOMUtil.newDocument(stream);
    DOMUtil.outputXML(returnedDoc);
    objectId = XPathAPI.eval(returnedDoc, "/documentManagerResponse/searchDocuments/documentDetails/attribute/value").toString();
    if(!StringUtils.isNullOrEmpty(objectId)){//If the document is already present on the server, delete it first
      Document docToDelete = createTestDeleteRequestXML(objectId);
      DOMUtil.outputXML(docToDelete);
      documentService.delete(docToDelete,httpSession);
    } 
  }
  public void testUpload_Retrieve_Delete_And_Update_Services() throws Exception {
       //Insert
      testSearchDocumentAndDeleteIfPresent();
      Document inputDocumentInsert=DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/insertMitraTechDocument.xml");
      DOMUtil.outputXML(inputDocumentInsert);
      InputStream returnInsertDocumentStream=documentService.upload(
              inputDocumentInsert,
              "com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/testFile1.txt",
              httpSession);
      Document outputInsertDocumentResult = DOMUtil.newDocument(returnInsertDocumentStream);
      DOMUtil.outputXML(outputInsertDocumentResult);
      objectId = XPathAPI.eval(outputInsertDocumentResult, "/documentManagerResponse/insertDocument/documentDetails/attribute/value").toString();
      assertNotNull(objectId);


    //Retrieve
    Document inputDocumentRetrieve = buildRetrieveRequest(objectId,null);
    DOMUtil.outputXML(inputDocumentRetrieve);
    InputStream inputStreamDownload = documentService.download(inputDocumentRetrieve, httpSession);
    Document outputDownloadDocument = DOMUtil.newDocument(inputStreamDownload);
    DOMUtil.outputXML(outputDownloadDocument);
    String retrieveDocumentContent = XPathAPI.eval(outputDownloadDocument,"/documentManagerResponse/retrieveDocument/documentDetails/attribute/value").toString();
    assertEquals("VGVzdCBEYXRh",retrieveDocumentContent);

    //Update
    String updateTransformationXPathString = "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value";
    Document inputUpdateDocument = DocumentUtil.transformRequestXML
            ("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/updateRequest.xml", objectId, updateTransformationXPathString, 0);
    DOMUtil.outputXML(inputUpdateDocument);
    documentService.update(inputUpdateDocument,
            "com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/testFile2.txt",
            httpSession);

    //Retrieve Again
    Document inputDocumentRetrieveAgain = buildRetrieveRequest(objectId,null);
    DOMUtil.outputXML(inputDocumentRetrieveAgain);
    InputStream inputStreamDownloadAgain = documentService.download(inputDocumentRetrieve, httpSession);
    Document outputDownloadDocumentAgain = DOMUtil.newDocument(inputStreamDownloadAgain);

    DOMUtil.outputXML(outputDownloadDocumentAgain);
    String retrieveDocumentContentAgain = XPathAPI.eval(outputDownloadDocumentAgain,"/documentManagerResponse/retrieveDocument/documentDetails/attribute/value").toString();
    assertEquals("Rm9ybSBEYXRhIDI=",retrieveDocumentContentAgain);

    //Delete
    Document inputDocumentDelete = createTestDeleteRequestXML(objectId);
    InputStream inputStreamDelete = documentService.delete(inputDocumentDelete, httpSession);
    Document outputDeleteDocument = DOMUtil.newDocument(inputStreamDelete);
    DOMUtil.outputXML(outputDeleteDocument);
    String deletedDocumentObjectId = XPathAPI.eval(outputDeleteDocument,"/documentManagerResponse/documentDeletedSuccessfully/documentDetails/attribute/value").toString();
    assertEquals(objectId,deletedDocumentObjectId);
  }

 /* public String testSearchDocumentsInserted() throws Exception {
    
    Document inputDocumentInsert=DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/searchDocument_withObjectId.xml");
    DOMUtil.outputXML(inputDocumentInsert);
    InputStream returnInsertDocumentStream=documentService.search(
            inputDocumentInsert,
        httpSession);
    Document document = DOMUtil.newDocument(returnInsertDocumentStream);
    DOMUtil.outputXML(document);
    String documentObjectId = XPathAPI.eval(document,"/documentManagerResponse/searchDocuments/documentDetails/attribute[1]/value").toString();
    return  documentObjectId;

  }*/

  public void testSearchDocumentAndDeleteIfPresent() throws Exception{
    Document docToBeSearched = DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/searchDocument_withObjectId.xml");
    InputStream stream = documentService.search(docToBeSearched,httpSession);
    Document returnedDoc = DOMUtil.newDocument(stream);
    DOMUtil.outputXML(returnedDoc);
    objectId = XPathAPI.eval(returnedDoc, "/documentManagerResponse/searchDocuments/documentDetails/attribute[2]/value").toString();
    if(!StringUtils.isNullOrEmpty(objectId)){
      deleteDocumentFromLitigationsDoc(documentService);
    }
  }

  private void deleteDocumentFromLitigationsDoc(DocumentService documentService) throws Exception{
    Document deleteRequestDoc = DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/DeleteDocumentFromLitigationDocsFolder.xml");
    DOMUtil.outputXML(deleteRequestDoc);
    documentService.delete(deleteRequestDoc,httpSession);
  }


  public void testInsert_SearchDocumentsInserted_LitigatioNDocs_Indexing() throws Exception {
    //Before inserting a document, check if its already present
    //testSearchDocumentAndDeleteIfPresent();
//    Document inputDocumentInsert=DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/insertMitraTechDocument_TestForIndexing.xml");
//    DOMUtil.outputXML(inputDocumentInsert);
//    InputStream returnInsertDocumentStream=documentService.upload(
//            inputDocumentInsert,
//            "com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/MyTest_BGHALE.txt",
//            httpSession);

    Reader inputStream = new FileReader(new File("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/searchDocument_withObjectId.xml"));
    Document searchResult = DOMUtil.newDocument(inputStream);
    String objectId = XPathAPI.eval(searchResult, "/searchDocumentsRequest/requestDetails/searchDocuments/queryAttributes/attribute/value").toString();
    assertNotNull(objectId);
    //Build the Necessary XML using the Object ID above.
    Document searchDocument = buildCustomDateSearchRequestDocument("11/19/2008 00:00:00");
    System.out.println("\n...................Prepared Request Document.....................");
    DOMUtil.outputXML(searchDocument);
    //Do a search
    InputStream returnSearchDocumentStream=documentService.search(searchDocument,httpSession);
    Document document = DOMUtil.newDocument(returnSearchDocumentStream);
    System.out.println("\n...................Searched Document.....................");
    DOMUtil.outputXML(document);
    String fileName = "C:\\temp\\Output.xml";
    Writer fileWriter = new BufferedWriter(new FileWriter(fileName));
    fileWriter.write(DOMUtil.XMLToString(document));
    fileWriter.flush();
    fileWriter.close();
    CustomDateDocumentXMLReader reader = new CustomDateDocumentXMLReaderImpl();
    Root root = reader.parseCustomDateXML(fileName);
    assertNotNull(root);
    assertNotNull(root.getObjectList());
    assertTrue(root.getObjectList().size() > 0);
    DocumentMetaData docMetaData = (DocumentMetaData)root.getObjectList().get(0);
    assertNotNull(docMetaData);
    assertEquals("09001b5d800bc29e",docMetaData.getR_object_id());
    assertEquals("1980-000014",docMetaData.getClp_no());
    assertEquals("Correspondence",docMetaData.getFolder_type());
  }

 
  public void testThrowDocumentExceptionOnInsertOfInvalidXMLInputDocument()throws Exception {
    try{
      
      Document inputDocumentInsert=DOMUtil.newDocument
              ("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/insertMitraTechDocumentWithInvalidFileName.xml");
      documentService.upload(inputDocumentInsert,
              "com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/testFile1.txt", new MockMitratechHttpSession());
      fail("Exception should have been thrown");
    }catch(DocumentException e){
      assertTrue((e.getMessage().equals("Error during insertion of Document")));
    }
  }

  private Document createTestDeleteRequestXML(String objectId) throws ParserException, TransformerException {
    Document deleteRequestDoc = DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/deleteRequest.xml");
    Node objectIdValueNode = XPathAPI.eval(deleteRequestDoc, "/deleteDocumentRequest/requestDetails/deleteDocument/queryAttributes/attribute/value").nodelist().item(0);
    Node newObjectIdValueNode = deleteRequestDoc.createTextNode(objectId);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    return deleteRequestDoc;
  }

  
  private Document buildRetrieveRequest(String objectId, List requiredAttributes) {
    Document retrieveReqDoc = DOMUtil.newDocument();
    Node rootNode = DOMUtil.addChildElementWithNS("www.monsanto.com/pos", retrieveReqDoc, "retrieveDocumentRequest");
    DOMUtil.addChildElement(rootNode, "folder", "LawTeamConnect");
    Node requestDetailsNode = DOMUtil.addChildElement(rootNode, "requestDetails");
    Node retrieveDocNode = DOMUtil.addChildElement(requestDetailsNode, "retrieveDocument");
    addDocumentAttributesNode(retrieveDocNode, objectId);
    if (requiredAttributes != null && requiredAttributes.size() > 0) {
      addRequiredAttributesNode(retrieveDocNode, requiredAttributes);
    }
    return retrieveReqDoc;
  }

  private void addDocumentAttributesNode(Node retrieveDocNode, String objectId) {
    Node docAttrName = DOMUtil.addChildElement(retrieveDocNode, "queryAttributes");
    Node attrName = DOMUtil.addChildElement(docAttrName, "attribute");
    DOMUtil.addChildElement(attrName, "name", "objectId");
    DOMUtil.addChildElement(attrName, "value", objectId);
  }

  private void addRequiredAttributesNode(Node retrieveDocNode, List requiredAttributes) {
    Node requiredAttrNode = DOMUtil.addChildElement(retrieveDocNode, "requiredAttributes");
    for (int i = 0; i < requiredAttributes.size(); i++) {
      String requiredAttr = (String) requiredAttributes.get(i);
      DOMUtil.addChildElement(requiredAttrNode, "attribute", requiredAttr);
    }
  }

  private Document buildCustomDateSearchRequestDocument(String objectId){
    Document customDateReqDocument = DOMUtil.newDocument();
    Node rootNode = DOMUtil.addChildElementWithNS("www.monsanto.com/pos", customDateReqDocument, "searchDocumentsRequest");
    DOMUtil.addChildElement(rootNode, "folder", "LitigationDocs");
    Node requestDetailsNode = DOMUtil.addChildElement(rootNode, "requestDetails");
    Node searchDocumentChildNode = DOMUtil.addChildElement(requestDetailsNode,"searchDocuments");
    DOMUtil.addChildElement(searchDocumentChildNode,"searchAllVersions","true");
    addCustomDateSearchDocumentAttributesNode(searchDocumentChildNode,objectId);
    return customDateReqDocument;
  }

  private void addCustomDateSearchDocumentAttributesNode(Node searchDocumentChildNode, String objectId) {
    Node docAttrName = DOMUtil.addChildElement(searchDocumentChildNode, "queryAttributes");
    Node attrName = DOMUtil.addChildElement(docAttrName, "attribute");
    DOMUtil.addChildElement(attrName, "name", "custom_date");
    DOMUtil.addChildElement(attrName, "operator", "equals");
    DOMUtil.addChildElement(attrName, "value", objectId);
    List requiredAttributeList = new ArrayList();
    requiredAttributeList.add("title");//Title
    requiredAttributeList.add("clp_no");//clp_no
    requiredAttributeList.add("cause_no");//cause_no
    requiredAttributeList.add("matter_name");//matter_name
    requiredAttributeList.add("folder_type");//folder_type
    requiredAttributeList.add("dateCreated");//r_creation_date
    requiredAttributeList.add("r_creator_name");//r_creator_name
    requiredAttributeList.add("date_filed");//r_creator_name
    requiredAttributeList.add("custom_date");//r_creator_name
    addRequiredAttributesNode(searchDocumentChildNode,requiredAttributeList);
  }

}