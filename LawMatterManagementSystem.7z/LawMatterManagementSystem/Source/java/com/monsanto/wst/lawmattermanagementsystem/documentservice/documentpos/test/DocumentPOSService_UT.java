/*
DocumentPOSServiceUT was created on Jan 22, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos.test;

import com.monsanto.POSClient.InputStreamPOSResult;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.POSClient.POSResult;
import com.monsanto.Util.FileUtil;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.SecureXMLPOSConnectionSession;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos.DocumentPOSService;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos.POSConnectionFactory;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos.SucureXMLConnectionFactory;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.DocumentException;
import junit.framework.TestCase;
import org.w3c.dom.Document;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;

/**
 * Filename:    $RCSfile: DocumentPOSService_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-01-31 21:37:32 $
 *
 * @author VRBETHI
 * @version $Revision: 1.9 $
 */
public class DocumentPOSService_UT extends TestCase{

    public void testCreate() throws Exception {
        POSConnectionFactory sucureXMLConnectionFactory = new SucureXMLConnectionFactory();
        DocumentPOSService service = new DocumentPOSService(sucureXMLConnectionFactory);
        assertNotNull(service);
    }

    public void testUpload() throws Exception {
        POSConnectionFactory sucureXMLConnectionFactory = new MockSucureXMLConnectionFactory();
        DocumentPOSService service = new DocumentPOSService(sucureXMLConnectionFactory);
        Document inputDocumentInsert=DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/insertMitraTechDocument.xml");
        InputStream inputStream = service.upload(inputDocumentInsert,"com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/testFile1.txt",new MockHttpSession());
        String outputString = FileUtil.readFileToString(inputStream);
        assertEquals("<Hello/>",outputString);
    }

    public void testUpdate() throws Exception {
        POSConnectionFactory sucureXMLConnectionFactory = new MockSucureXMLConnectionFactory();
        DocumentPOSService service = new DocumentPOSService(sucureXMLConnectionFactory);
        Document inputDocumentInsert=DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/insertMitraTechDocument.xml");
        InputStream inputStream = service.update(inputDocumentInsert,"com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/testFile1.txt",new MockHttpSession());
        String outputString = FileUtil.readFileToString(inputStream);
        assertEquals("<Hello/>",outputString);
    }

    public void testDownload() throws Exception {
        POSConnectionFactory sucureXMLConnectionFactory = new MockSucureXMLConnectionFactory();
        DocumentPOSService service = new DocumentPOSService(sucureXMLConnectionFactory);
        Document inputDocumentInsert=DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/insertMitraTechDocument.xml");
        InputStream inputStream = service.download(inputDocumentInsert,new MockHttpSession());
        String outputString = FileUtil.readFileToString(inputStream);
        assertEquals("<Hello/>",outputString);
    }

    public void testDelete() throws Exception {
        POSConnectionFactory sucureXMLConnectionFactory = new MockSucureXMLConnectionFactory();
        DocumentPOSService service = new DocumentPOSService(sucureXMLConnectionFactory);
        Document inputDocumentInsert=DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/insertMitraTechDocument.xml");
        InputStream inputStream = service.delete(inputDocumentInsert,new MockHttpSession());
        String outputString = FileUtil.readFileToString(inputStream);
        assertEquals("<Hello/>",outputString);
    }

    class MockHttpSession implements HttpSession{

        public long getCreationTime() {
            return 0;
        }

        public String getId() {
            return null;
        }

        public long getLastAccessedTime() {
            return 0;
        }

        public ServletContext getServletContext() {
            return null;
        }

        public void setMaxInactiveInterval(int i) {
        }

        public int getMaxInactiveInterval() {
            return 0;
        }

        public HttpSessionContext getSessionContext() {
            return null;
        }

        public Object getAttribute(String s) {
            return null;
        }

        public Object getValue(String s) {
            return null;
        }

        public Enumeration getAttributeNames() {
            return null;
        }

        public String[] getValueNames() {
            return new String[0];
        }

        public void setAttribute(String s, Object o) {
        }

        public void putValue(String s, Object o) {
        }

        public void removeAttribute(String s) {
        }

        public void removeValue(String s) {
        }

        public void invalidate() {
        }

        public boolean isNew() {
            return false;
        }
    }

    class MockSucureXMLConnectionFactory implements POSConnectionFactory{

        public SecureXMLPOSConnectionSession getSecureXMLPOSConnectionSession(HttpSession httpSession) {
            return new MockSecureXMLPOSConnectionSession(httpSession);
        }
    }

    class MockSecureXMLPOSConnectionSession extends SecureXMLPOSConnectionSession{

        public MockSecureXMLPOSConnectionSession(HttpSession session) {
            super(session);
        }

        public POSResult callDocumentService(Document inputDocument, String posName) throws DocumentException {
            POSResult posResult = null;
            String outputString = "<Hello/>";
            try {
                posResult = new InputStreamPOSResult(new ByteArrayInputStream(outputString.getBytes()));
            } catch (POSCommunicationException e) {
                e.printStackTrace();
            } catch (POSException e) {
                e.printStackTrace();
            }
            return posResult;
        }
    }

    class MockInputStream extends InputStream{

        public int read() throws IOException {
            return 12;
        }
    }
}