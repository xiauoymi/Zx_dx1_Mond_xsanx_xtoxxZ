/*
 DocumentException was created on Sep 21, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.documentservice.exception;

/**
 * Filename:    $RCSfile: DocumentException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2006-12-11 23:27:26 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public class DocumentException extends Exception {

  public DocumentException(String message, Throwable cause) {
    super(message, cause);
  }
}