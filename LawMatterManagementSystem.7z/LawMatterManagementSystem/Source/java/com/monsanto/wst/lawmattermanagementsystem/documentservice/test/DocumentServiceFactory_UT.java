/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.documentservice.test;

import com.monsanto.wst.lawmattermanagementsystem.documentservice.DocumentServiceFactory;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos.DocumentPOSServiceFactory;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.FactoryConfigurationException;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: DocumentServiceFactory_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-12-19 21:26:18 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class DocumentServiceFactory_UT extends TestCase {

  public void testGetFactory_ThrowsException_IfSystemPropertyNotFound() throws Exception {
    try {
      DocumentServiceFactory.getFactory();
      //fail("Required exception not thrown.");
    } catch (FactoryConfigurationException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetFactory_ThrowsException_IfImplementingClassNotFound() throws Exception {
    System.setProperty(DocumentServiceFactory.SYSTEM_PROPERTY_DOCUMENT_SERVICE_FACTORY_IMPL,
            "com.non-existing-package.non-existing-class");
    try {
      DocumentServiceFactory.getFactory();
      fail("Required exception not thrown.");
    } catch (FactoryConfigurationException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    System.setProperty(DocumentServiceFactory.SYSTEM_PROPERTY_DOCUMENT_SERVICE_FACTORY_IMPL, "");
  }

  public void testGetFactory_ThrowsException_IfInstantiationExceptionOccurs_WhenClassIsAnInterface() throws Exception {
    System.setProperty(DocumentServiceFactory.SYSTEM_PROPERTY_DOCUMENT_SERVICE_FACTORY_IMPL,
            "com.monsanto.wst.lawmattermanagementsystem.documentservice.DocumentServiceFactory");
    try {
      DocumentServiceFactory.getFactory();
      fail("Required exception not thrown.");
    } catch (FactoryConfigurationException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    System.setProperty(DocumentServiceFactory.SYSTEM_PROPERTY_DOCUMENT_SERVICE_FACTORY_IMPL, "");
  }

  public void testGetFactory_ThrowsException_IfIllegalAccessExceptionOccurs_WhenNonAccessibleConstructorIsInvoked() throws Exception {
    System.setProperty(DocumentServiceFactory.SYSTEM_PROPERTY_DOCUMENT_SERVICE_FACTORY_IMPL,
            "com.monsanto.wst.lawmattermanagementsystem.documentservice.mock.MockClassWithNonPublicConstructor");
    try {
      DocumentServiceFactory.getFactory();
      fail("Required exception not thrown.");
    } catch (FactoryConfigurationException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    System.setProperty(DocumentServiceFactory.SYSTEM_PROPERTY_DOCUMENT_SERVICE_FACTORY_IMPL, "");
  }

  public void testGetFactory() throws Exception {
    System.setProperty(DocumentServiceFactory.SYSTEM_PROPERTY_DOCUMENT_SERVICE_FACTORY_IMPL,
            "com.monsanto.wst.lawmattermanagementsystem.documentservice.documentpos.DocumentPOSServiceFactory");
    assertEquals(DocumentPOSServiceFactory.class, DocumentServiceFactory.getFactory().getClass());
    System.setProperty(DocumentServiceFactory.SYSTEM_PROPERTY_DOCUMENT_SERVICE_FACTORY_IMPL, "");
  }
}