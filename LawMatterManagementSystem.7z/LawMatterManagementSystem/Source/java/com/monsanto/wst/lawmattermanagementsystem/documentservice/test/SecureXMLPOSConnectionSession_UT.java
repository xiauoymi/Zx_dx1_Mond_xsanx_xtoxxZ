/*
SecureXMLPOSConnectionSession_UT was created on Jan 26, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.documentservice.test;

import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.POSClient.POSResult;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.SecureXMLPOSConnectionSession;
import com.monsanto.wst.lawmattermanagementsystem.documentservice.exception.DocumentException;
import junit.framework.TestCase;
import org.w3c.dom.Document;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;
import java.util.Enumeration;

/**
 * Filename:    $RCSfile: SecureXMLPOSConnectionSession_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-01-26 18:32:04 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class SecureXMLPOSConnectionSession_UT extends TestCase{

    public void testCreateSecureXMLPOSConnectionSession() throws Exception {
        SecureXMLPOSConnectionSession connection = new SecureXMLPOSConnectionSession(new MockHttpSession());
        assertNotNull(connection);
    }

    public void testCallDocumentServiceTestPOSCommunicationException() throws ParserException {
        SecureXMLPOSConnectionSession connection = new MockSecureXMLPOSConnectionSessionThrowsCommunicationException(new MockHttpSession());
        Document inputDocumentInsert=DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/insertMitraTechDocument.xml");
        try {
            connection.callDocumentService(inputDocumentInsert, "InsertDocumentService");
            fail("Exception should have been thrown");
        } catch (DocumentException e) {
            assertEquals("Communication Exception",e.getMessage());
        }
    }

    public void testCallDocumentServiceTestPOSConnectionException() throws ParserException {
        SecureXMLPOSConnectionSession connection = new MockSecureXMLPOSConnectionSessionThrowsConnectionException(new MockHttpSession());
        Document inputDocumentInsert=DOMUtil.newDocument("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/insertMitraTechDocument.xml");
        try {
            connection.callDocumentService(inputDocumentInsert, "InsertDocumentService");
            fail("Exception should have been thrown");
        } catch (DocumentException e) {
        }
    }

    class MockHttpSession implements HttpSession{

        public long getCreationTime() {
            return 0;
        }

        public String getId() {
            return null;
        }

        public long getLastAccessedTime() {
            return 0;
        }

        public ServletContext getServletContext() {
            return null;
        }

        public void setMaxInactiveInterval(int i) {
        }

        public int getMaxInactiveInterval() {
            return 0;
        }

        public HttpSessionContext getSessionContext() {
            return null;
        }

        public Object getAttribute(String s) {
            return null;
        }

        public Object getValue(String s) {
            return null;
        }

        public Enumeration getAttributeNames() {
            return null;
        }

        public String[] getValueNames() {
            return new String[0];
        }

        public void setAttribute(String s, Object o) {
        }

        public void putValue(String s, Object o) {
        }

        public void removeAttribute(String s) {
        }

        public void removeValue(String s) {
        }

        public void invalidate() {
        }

        public boolean isNew() {
            return false;
        }
    }

    class MockSecureXMLPOSConnectionSessionThrowsCommunicationException extends SecureXMLPOSConnectionSession{

        public MockSecureXMLPOSConnectionSessionThrowsCommunicationException(HttpSession session) {
            super(session);
        }

        public POSResult callService(String posName, Document document) throws POSException, POSCommunicationException {
            throw new POSCommunicationException("Communication Exception");
        }
    }

    class MockSecureXMLPOSConnectionSessionThrowsConnectionException extends SecureXMLPOSConnectionSession{

        public MockSecureXMLPOSConnectionSessionThrowsConnectionException(HttpSession session) {
            super(session);
        }

        public POSResult callService(String posName, Document document) throws POSException, POSCommunicationException {
            throw new POSException("Communication Exception",0,"blah");
        }
    }
}