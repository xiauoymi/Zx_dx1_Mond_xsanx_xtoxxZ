/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.ftp.service.acceptancetest;

import com.monsanto.Util.FileUtil;
import com.monsanto.Util.StringUtils;
import com.monsanto.Util.FTPConnection;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPService;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPServiceImpl;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;

/**
 * Filename:    $RCSfile: FTPService_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-11-01 19:40:01 $
 *
 * @author rdesai2
 * @version $Revision: 1.13 $
 */

public class FTPService_AT extends TestCase {

  private final String testFTPDir = "C:/";
  public final String FILE_NAME = "TestFile_FTP_AT.txt";
  public final String DOWNLOADED_FILE_NAME = "downloadedFile_FTP_AT.txt";

  private String currentFTPDir;

  protected void setUp() throws IOException {
    currentFTPDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
    System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, testFTPDir);
    FileUtil.write(testFTPDir + FILE_NAME, "Test Contents for FTP acceptance test.");
  }

  //todo Get Access to ftp server and uncomment this test.
  public void testFileFTP() throws Exception {
//    FTPService ftpService = new FTPServiceImpl(new ResourceManagerFactoryImpl());
//    String ftpLocationOnServer = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
//    String absolutePathToLocalFile = ftpLocationOnServer + FILE_NAME;
//    String absolutePathToDownloadLocation = ftpLocationOnServer + DOWNLOADED_FILE_NAME;
//    assertTrue(ftpService.upload(absolutePathToLocalFile, LMMSConstants.FTP_REMOTE_SUB_DIR_INBOUND));
//    assertTrue(ftpService.download(FILE_NAME, absolutePathToDownloadLocation, LMMSConstants.FTP_REMOTE_SUB_DIR_INBOUND));
//    assertTrue(FileUtil.compareFiles(absolutePathToLocalFile, absolutePathToDownloadLocation));
    assertTrue(true);
  }

  protected void tearDown() throws Exception {
    if (!StringUtils.isNullOrEmpty(currentFTPDir)) {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, currentFTPDir);
    } else {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, "");
    }
    deleteLocalFile(testFTPDir + FILE_NAME);
    deleteLocalFile(testFTPDir + DOWNLOADED_FILE_NAME);
    deleteFileFromFTPServer();
  }

  private void deleteLocalFile(String fileToBeDeleted) {
    File downloadedFile = new File(fileToBeDeleted);
    if (downloadedFile.exists()) {
      downloadedFile.delete();
    }
  }

  private void deleteFileFromFTPServer() throws IOException {
    FTPConnection connection = new FTPConnection();
    connection.connect("dxdev", 21);
    connection.login("dxftp_q08_lawinv", "abc123$$");
    connection.changeDirectory("inbound");
    connection.deleteFile(FILE_NAME);
  }
}