/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.ftp.service.mock;

import com.monsanto.Util.FTPConnection;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;

/**
 * Filename:    $RCSfile: MockFTPConnection.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:24:54 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class MockFTPConnection extends FTPConnection {

  public static String CONNECTION_STATUS = "unknown";

  public boolean connect(String host) throws UnknownHostException, IOException {
    CONNECTION_STATUS = "connected";
    return true;
  }

  public boolean executeDataCommand(String command, InputStream in) throws IOException {
    return true;
  }

  public boolean executeDataCommand(String command, OutputStream out) throws IOException {
    return true;
  }

  public void disconnect() {
    CONNECTION_STATUS = "disconnected";
  }
}