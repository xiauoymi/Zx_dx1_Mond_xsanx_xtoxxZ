/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.ftp.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;

import java.io.IOException;

/**
 * Filename:    $RCSfile: MockFTPFailingConnectionManager.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:24:54 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockFTPFailingConnectionManager implements ResourceConnectionManager {

  public Object getConnection(String databaseName) throws ResourceConnectionException {
    MockFTPFailingConnection mockFTPFailingConnection = new MockFTPFailingConnection();
    connect(mockFTPFailingConnection);
    return mockFTPFailingConnection;
  }

  private void connect(MockFTPFailingConnection mockFTPFailingConnection) throws ResourceConnectionException {
    try {
      mockFTPFailingConnection.connect("test-host");
    } catch (IOException e) {
      throw new ResourceConnectionException("Error connecting to test-host", e);
    }
  }
}