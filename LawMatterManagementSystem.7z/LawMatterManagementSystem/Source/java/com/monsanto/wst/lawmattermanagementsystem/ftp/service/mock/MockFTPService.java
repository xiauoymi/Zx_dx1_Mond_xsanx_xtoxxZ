/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.ftp.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.ftp.exception.FTPException;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPService;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.Util.FileUtil;

import java.io.IOException;

/**
 * Filename:    $RCSfile: MockFTPService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-23 18:06:14 $
 *
 * @author rdesai2
 * @version $Revision: 1.5 $
 */
public class MockFTPService implements FTPService {

  private String absolutePathToLocalFile = null;
  private boolean wasDownloadCalled=false;

  public boolean upload(String absolutePathToLocalFile, String remoteSubDir) throws FTPException {
    this.absolutePathToLocalFile = absolutePathToLocalFile;
    return true;
  }

  public boolean download(String remoteFileName, String absolutePathToDownloadLocation, String remoteSubDir) throws FTPException {
    try {
      FileUtil.copyFile("com\\monsanto\\wst\\lawmattermanagementsystem\\check\\test\\checkfilewithentries.txt",absolutePathToDownloadLocation);
    } catch (IOException e) {
      e.printStackTrace();
    }

    wasDownloadCalled=true;
    return false;
  }

  public String getFileNameForUploadRequest(){
    return absolutePathToLocalFile;
  }

  public boolean wasDownloadCalled() {
    return wasDownloadCalled;
  }
}