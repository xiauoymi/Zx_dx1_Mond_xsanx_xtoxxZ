/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.ftp.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.ftp.exception.FTPException;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPService;

/**
 * Filename:    $RCSfile: MockFTPServiceReturnsFalse.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-07 22:03:37 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class MockFTPServiceReturnsFalse implements FTPService {

  public boolean upload(String absolutePathToLocalFile, String remoteSubDir) throws FTPException {
    return false;
  }

  public boolean download(String remoteFileName, String absolutePathToDownloadLocation, String remoteSubDir) throws FTPException {
    return false;
  }
}