/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.ftp.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactory;

/**
 * Filename:    $RCSfile: MockResourceManagerFactory.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:24:54 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockResourceManagerFactory implements ResourceManagerFactory {

  public ResourceConnectionManager getConnectionManager(String type) {
    return new MockFTPResourceConnectionManager();
  }
}