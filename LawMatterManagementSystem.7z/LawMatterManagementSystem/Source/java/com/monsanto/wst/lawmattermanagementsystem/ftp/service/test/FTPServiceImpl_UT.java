/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.ftp.service.test;

import com.monsanto.Util.FileUtil;
import com.monsanto.wst.lawmattermanagementsystem.ftp.exception.FTPException;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPService;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPServiceImpl;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.mock.MockFTPConnection;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.mock.MockResourceManagerFactory;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.mock.MockResourceManagerFactoryWithErroneousConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.mock.MockResourceManagerFactoryWithFailingConnectionManager;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;

/**
 * Filename:    $RCSfile: FTPServiceImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-07 22:03:37 $
 *
 * @author rdesai2
 * @version $Revision: 1.8 $
 */
public class FTPServiceImpl_UT extends TestCase {

  private FTPService ftpService;
  private static final String TEST_FILE = "testFile_FTP_UT.txt";
  private static final String TEST_FILE_LOCATION = "C:/testFile_FTP_UT.txt";
  private static final String DOWNLOADED_FILE = "C:/downloadedFile_FTP_UT.txt";

  protected void setUp() throws IOException {
    MockResourceManagerFactory ftpResourceManagerFactory = new MockResourceManagerFactory();
    ftpService = new FTPServiceImpl(ftpResourceManagerFactory);
    FileUtil.write(TEST_FILE_LOCATION, "Test Contents for FTP unit test.");
  }

  protected void tearDown() throws Exception {
    deleteLocalFile(TEST_FILE_LOCATION);
    deleteLocalFile(DOWNLOADED_FILE);
  }

  public void testUpload() throws Exception {
    assertTrue(ftpService.upload(TEST_FILE_LOCATION, null));
  }

  public void testUpload_ThowsException_ForInvalidLocalFileInput() throws Exception {
    try {
      ftpService.upload("non-existing-file", null);
      fail("Required exception not thrown");
    } catch (FTPException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      ftpService.upload(null, null);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      ftpService.upload("", null);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testDisconnectCalled_AfterUpload() throws Exception {
    ftpService.upload(TEST_FILE_LOCATION, null);
    assertEquals("disconnected", MockFTPConnection.CONNECTION_STATUS);
  }

  public void testDownload() throws Exception {
    assertTrue(ftpService.download(TEST_FILE, DOWNLOADED_FILE, null));
  }

  public void testDownload_ThrowsException_ForInvalidRemoteFileName() throws Exception {
    try {
      ftpService.download(null, DOWNLOADED_FILE, null);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      ftpService.download("", DOWNLOADED_FILE, null);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testDownload_ThrowsException_ForInvalidDownloadLocation() throws Exception {
    try {
      ftpService.download(TEST_FILE, null, null);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      ftpService.download(TEST_FILE, "", null);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testDisconnectCalled_AfterDownload() throws Exception {
    ftpService.download(TEST_FILE, DOWNLOADED_FILE, null);
    assertEquals("disconnected", MockFTPConnection.CONNECTION_STATUS);
  }

  public void testUpload_ThrowsException_IfConnectionFails() throws Exception {
    MockResourceManagerFactoryWithFailingConnectionManager ftpResourceManagerFactoryWithFailingConnectionManager = new MockResourceManagerFactoryWithFailingConnectionManager();
    ftpService = new FTPServiceImpl(ftpResourceManagerFactoryWithFailingConnectionManager);
    assertFalse(ftpService.upload(TEST_FILE_LOCATION, null));
  }

  public void testDownload_ThrowsException_IfConnectionFails() throws Exception {
    MockResourceManagerFactoryWithFailingConnectionManager ftpResourceManagerFactoryWithFailingConnectionManager = new MockResourceManagerFactoryWithFailingConnectionManager();
    ftpService = new FTPServiceImpl(ftpResourceManagerFactoryWithFailingConnectionManager);
    assertFalse(ftpService.download(TEST_FILE, DOWNLOADED_FILE, null));
  }

  public void testUpload_ThrowsException_IfConnectionThrowsException() throws Exception {
    MockResourceManagerFactoryWithErroneousConnectionManager ftpResourceManagerFactoryWithErroneousConnectionManager = new MockResourceManagerFactoryWithErroneousConnectionManager();
    ftpService = new FTPServiceImpl(ftpResourceManagerFactoryWithErroneousConnectionManager);
    try {
      ftpService.upload(TEST_FILE_LOCATION, null);
      fail("Required exception not thrown");
    } catch (FTPException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testDownload_ThrowsException_IfConnectionThrowsException() throws Exception {
    MockResourceManagerFactoryWithErroneousConnectionManager ftpResourceManagerFactoryWithErroneousConnectionManager = new MockResourceManagerFactoryWithErroneousConnectionManager();
    ftpService = new FTPServiceImpl(ftpResourceManagerFactoryWithErroneousConnectionManager);
    try{
      ftpService.download(TEST_FILE, DOWNLOADED_FILE, null);
      fail("Required exception not thrown");
    } catch (FTPException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getCause().getMessage());
    }
  }

  private void deleteLocalFile(String fileToBeDeleted) {
    File downloadedFile = new File(fileToBeDeleted);
    if(downloadedFile.exists()){
      downloadedFile.delete();
    }
  }
}