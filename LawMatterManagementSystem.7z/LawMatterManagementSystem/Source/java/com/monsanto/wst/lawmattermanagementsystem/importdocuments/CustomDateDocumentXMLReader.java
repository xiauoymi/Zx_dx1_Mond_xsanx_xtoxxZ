package com.monsanto.wst.lawmattermanagementsystem.importdocuments;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Aug 5, 2008
 * Time: 8:59:00 AM
 * To change this template use File | Settings | File Templates.
 */
public interface CustomDateDocumentXMLReader {
  Root parseCustomDateXML(String inputFilePath);
}
