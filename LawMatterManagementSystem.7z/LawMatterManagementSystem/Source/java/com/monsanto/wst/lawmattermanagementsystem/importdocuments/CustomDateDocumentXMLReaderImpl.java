package com.monsanto.wst.lawmattermanagementsystem.importdocuments;

import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import com.monsanto.XMLUtil.DOMUtil;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Aug 5, 2008
 * Time: 8:59:20 AM
 * To change this template use File | Settings | File Templates.
 */
public class CustomDateDocumentXMLReaderImpl implements CustomDateDocumentXMLReader {

  private static final String R_CREATOR_NAME = "r_creator_name";
  private static final String FOLDER_TYPE = "folder_type";
  private static final String MATTER_NAME = "matter_name";
  private static final String CLP_NO = "clp_no";
  private static final String R_OBJECT_ID = "objectId";
  private static final String R_CREATION_DATE = "dateCreated";
  private static final String DOC_NAME = "name";
  private static final String I_CHRONICLE_ID = "i_chronicle_id";
  private static final String CAUSE_NO = "cause_no";
  private static final String OBJECT_NAME = "object_name";
  private static final String PLEADING_TYPE = "pleading_type";
  private static final String DATE_FILED = "date_filed";
  private static Map attributeNameValueMap = new HashMap();

  public Root parseCustomDateXML(String inputFilePath) {
    FileInputStream fileInputStream;
    Root root = null;
    try {
      fileInputStream = new FileInputStream(inputFilePath);
      root = parseCustomDateDocuments(DOMUtil.newDocument(fileInputStream));
    } catch (FileNotFoundException e) {
      throw new DocumentImportProcessingException("Could not find import document located at :" + inputFilePath, e);
    } catch (XMLStreamException e) {
      throw new DocumentImportProcessingException("Error parsing import document located at :" + inputFilePath, e);
    } catch (IOException e) {
      throw new DocumentImportProcessingException("Error parsing import document located at :" + inputFilePath, e);
    } catch (SAXException e) {
      throw new DocumentImportProcessingException("Error parsing import document located at :" + inputFilePath, e);
    }
    return root;
  }

  private Root parseCustomDateDocuments(Document document) throws XMLStreamException {
    List objectList = new ArrayList();
    Node attributeNode = null;
    NodeList documentDetailsNode = document.getElementsByTagName("documentDetails");
    int documentDetailNodeListSize = documentDetailsNode.getLength();
    for (int i = 0; i < documentDetailNodeListSize; i++) {
      attributeNode = documentDetailsNode.item(i);
      populateAttributeNameValueMap(attributeNode);
      populateObjectList(objectList);
    }
    return new Root(objectList);
  }

  /**
   * Private method to fetch the attribute name / value pair and populate the map.
   * @param attributeNode
   */
  private void populateAttributeNameValueMap(Node attributeNode) {
    NodeList attributeNodes;
    int attributeNodeLength;
    if (attributeNode != null) {
      attributeNodes = attributeNode.getChildNodes();
      if (attributeNodes != null) {
        attributeNodeLength = attributeNodes.getLength();
        for (int j = 0; j < attributeNodeLength; j += 2) {
          Node attrNode = attributeNodes.item(j).getNextSibling();
          if (attrNode == null) break;
          String attributeName = getAttributeName(attrNode);
          String attributeValue = getAttributeValue(attrNode);
          attributeNameValueMap.put(attributeName, attributeValue);
        }
      }
    }
  }

  /**
   * Private method to fetch the attribute value
   *
   * @param attrNode
   * @return
   */
  private String getAttributeValue(Node attrNode) {
    Node lastChildNode = attrNode.getLastChild().getPreviousSibling().getFirstChild();
    String attributeValue = lastChildNode.getNodeValue();
    return attributeValue;
  }

  /**
   * Private method to fetch the attribute name
   *
   * @param attrNode
   * @return
   */
  private String getAttributeName(Node attrNode) {
    Node firstChildNode = attrNode.getFirstChild().getNextSibling().getFirstChild();
    String attributeName = firstChildNode.getNodeValue();
    return attributeName;
  }

  /**
   * private method to create DocumentMetaData Object and add it to a list
   *
   * @param objectList
   */
  private void populateObjectList(List objectList) {
    DocumentMetaData object;
    String objectIdString = "";
    String clpNumberString = "";
    String matterNameString = "";
    String docNameString = "";
    String folderTypeString = "";
    String createDateString = "";
    String createNameString = "";
    
    objectIdString = validateData(attributeNameValueMap.get(R_OBJECT_ID));
    clpNumberString = validateData(attributeNameValueMap.get(CLP_NO));
    matterNameString = validateData(attributeNameValueMap.get(MATTER_NAME));
    docNameString = validateData(attributeNameValueMap.get(DOC_NAME));
    folderTypeString = validateData(attributeNameValueMap.get(FOLDER_TYPE));
    createDateString = validateData(attributeNameValueMap.get(R_CREATION_DATE));
    createNameString = validateData(attributeNameValueMap.get(R_CREATOR_NAME));

    object = new DocumentMetaData(objectIdString,
        objectIdString, clpNumberString,
        matterNameString, "",
        docNameString, "",
        "", folderTypeString,
        createDateString, createNameString);
    objectList.add(object);
  }

  private String validateData(Object object) {
    if(object != null){
      return object.toString();
    }
    return "";
  }

}
