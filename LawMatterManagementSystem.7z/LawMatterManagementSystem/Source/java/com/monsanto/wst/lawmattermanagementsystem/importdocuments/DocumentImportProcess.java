/*
 DocumentImportProcess was created on Oct 15, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.check.ChecksProcessingMessage;

/**
 * Filename:    $RCSfile: DocumentImportProcess.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-02-02 20:04:42 $
 *
 * @author vrbethi
 * @version $Revision: 1.5 $
 */
public interface DocumentImportProcess {
  void importDocumentMetaData(String inputFilePath) throws ServiceException;
  void importCustomDateDocumentMetaData(String inputFilePath, ChecksProcessingMessage message) throws ServiceException;
}