/*
 DocumentImportProcessImpl was created on Oct 15, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments;

import com.monsanto.wst.lawmattermanagementsystem.check.*;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.XMLUtil.DOMUtil;

import java.util.List;
import java.util.Iterator;

import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: DocumentImportProcessImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-02-02 20:05:23 $
 *
 * @author vrbethi
 * @version $Revision: 1.9 $
 */
public class DocumentImportProcessImpl implements DocumentImportProcess {
  private DocumentXMLReader documentXMLReader;
  private ChecksVoidsXMLBuilder checksVoidsXMLBuilder;
  private TeamConnectCheckDAO teamConnectCheckDAO;
  private ResultsProcessor resultsProcessor;
  private ErrorHandler errorHandler;
  private CustomDateDocumentXMLReader customDateDocumentXMLReader;
  public DocumentImportProcessImpl(DocumentXMLReader documentXMLReader, ChecksVoidsXMLBuilder checksVoidsXMLBuilder,
                                   TeamConnectCheckDAO teamConnectCheckDAO, ResultsProcessor resultsProcessor,
                                   ErrorHandler errorHandler) {
    this.documentXMLReader = documentXMLReader;
    this.checksVoidsXMLBuilder = checksVoidsXMLBuilder;
    this.teamConnectCheckDAO = teamConnectCheckDAO;
    this.resultsProcessor = resultsProcessor;
    this.errorHandler = errorHandler;
   
  }

  public void importDocumentMetaData(String inputFilePath) throws ServiceException {
    Root root = documentXMLReader.parse(inputFilePath);
    List objectList = root.getObjectList();
    Iterator objectListIterator = objectList.iterator();
    while(objectListIterator.hasNext()){
      ChecksProcessingMessage processingMessage = new ChecksProcessingMessage();
      DocumentMetaData documentMetaData = (DocumentMetaData) objectListIterator.next();
      if(documentMetaData.getDocumentType()==null || documentMetaData.getDocumentType().length()==0){
        processingMessage.setMessage(
            new StringBuffer().append("Failure Processing :").append(documentMetaData.getClp_no()).append(" :Invalid document type :").append(documentMetaData.getPleading_type()).toString());
      }else{
          Document document = checksVoidsXMLBuilder.buildUpdateDocumentXML(documentMetaData);
          DOMUtil.outputXML(document);
          Document resultDocument = teamConnectCheckDAO.callService(document);
          processResult(resultDocument, documentMetaData, processingMessage);
      }
      errorHandler.handleError(processingMessage);
    }
    errorHandler.closeResources();
  }

  public void importCustomDateDocumentMetaData(String inputFilePath, ChecksProcessingMessage processingMessage) throws ServiceException {
    customDateDocumentXMLReader = new CustomDateDocumentXMLReaderImpl();
    Root root = customDateDocumentXMLReader.parseCustomDateXML(inputFilePath);
    List objectList = root.getObjectList();
    Iterator objectListIterator = objectList.iterator();
    while(objectListIterator.hasNext()){
      DocumentMetaData documentMetaData = (DocumentMetaData) objectListIterator.next();
      if(documentMetaData.getDocumentType()==null || documentMetaData.getDocumentType().length()==0){
        processingMessage.setMessage(
            new StringBuffer().append("Failure Processing : Matter Name :").append(documentMetaData.getMatter_name()+"CLP No. :"+documentMetaData.getClp_no()).append(" :Invalid document type :").append(documentMetaData.getPleading_type()).toString());
      }else{
          Document document = checksVoidsXMLBuilder.buildUpdateDocumentXML(documentMetaData);
          DOMUtil.outputXML(document);
          Document resultDocument = teamConnectCheckDAO.callService(document);
          processResult(resultDocument, documentMetaData, processingMessage);
      }
    }
    errorHandler.handleError(processingMessage);
    errorHandler.closeResources();

  }

  private void processResult(Document resultDocument, DocumentMetaData documentMetaData,
                             ChecksProcessingMessage processingMessage) {
    String message;
    boolean wasInsertSuccessful = resultsProcessor.processResult(resultDocument);
    if(wasInsertSuccessful){
      message = "Successfully Updated :Matter Name : ";
    }else{
      DOMUtil.outputXML(resultDocument);
      message = "Failure Processing Please read: "+documentMetaData.getDocumentType()+" for Matter : ";
    }
    processingMessage.setMessage(formatMessage(documentMetaData, processingMessage, message));

  }

  private String formatMessage(DocumentMetaData documentMetaData, ChecksProcessingMessage processingMessage, String message) {
    return processingMessage.getMessage() + "\r\n" +
        message + documentMetaData.getMatter_name() +
        "  CLP Nop. :" + documentMetaData.getClp_no()
        + "  Document Name :" + documentMetaData.getObject_name() + "\r\n";
  }
}