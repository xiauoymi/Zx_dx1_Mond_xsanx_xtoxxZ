/*
 DocumentImportProcessingException was created on Oct 15, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments;

/**
 * Filename:    $RCSfile: DocumentImportProcessingException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-15 16:11:18 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class DocumentImportProcessingException extends RuntimeException {

  public DocumentImportProcessingException(String message, Throwable cause) {
    super(message, cause);
  }
}