/*
 DocumentImportProcessorFactoryImpl was created on Oct 15, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments;

import com.monsanto.wst.lawmattermanagementsystem.check.*;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriterImpl;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

/**
 * Filename:    $RCSfile: DocumentImportProcessorFactoryImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-22 20:24:07 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public class DocumentImportProcessorFactoryImpl implements DocumentImportProcessorFactory {
  public DocumentImportProcess getDocumentImportProcessor() throws ServiceException {
    DocumentXMLReaderImpl reader = new DocumentXMLReaderImpl();
    ChecksVoidsXMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TeamConnectDAOFactoryImpl teamConnectDAOFactory = new TeamConnectDAOFactoryImpl();
    ErrorReportWriter errorReportWriter = new ErrorReportWriterImpl();
    String checkErrorFileName = LMMSConstants.DOCUMENT_IMPORT_OUTPUTFILE;
    ErrorHandler errorHandler = new ErrorHandlerImpl(errorReportWriter, checkErrorFileName);
    return new DocumentImportProcessImpl(reader, xmlBuilder, teamConnectDAOFactory.getTeamConnectDAOFactoryInstance(),
        new ResultsProcessorImpl(), errorHandler);
  }
}