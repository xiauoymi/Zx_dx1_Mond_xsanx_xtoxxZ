/*
 Object was created on Oct 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments;

import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;

import java.util.Map;
import java.util.HashMap;
import java.util.Date;

/**
 * Filename:    $RCSfile: DocumentMetaData.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-07-03 14:50:39 $
 *
 * @author vrbethi
 * @version $Revision: 1.5 $
 */
public class DocumentMetaData {

  private String r_object_id;
  private String i_chronicle_id;
  private String clp_no;
  private String matter_name;
  private String cause_no;
  private String object_name;
  private String pleading_type;
  private String date_filed;
  private String folder_type;
  private String r_creation_date;
  private String r_creator_name;

  private static Map documentTypeMap = new HashMap();

  static {
    documentTypeMap.put("Affidavit","DTYP_ROOT_AFFI");
    documentTypeMap.put("Affirmative","DTYP_ROOT_AFRM");
    documentTypeMap.put("Agreed","DTYP_ROOT_AGRE");
    documentTypeMap.put("Amended Pleading","DTYP_ROOT_AMPL");
    documentTypeMap.put("Amended","DTYP_ROOT_AMPL");
    documentTypeMap.put("Amendment","DTYP_ROOT_AMND");
    documentTypeMap.put("Answers","DTYP_ROOT_ANAP");
    documentTypeMap.put("Appeal","DTYP_ROOT_APPL");
    documentTypeMap.put("Appearance","DTYP_ROOT_APPE");
    documentTypeMap.put("Articles","DTYP_ROOT_ARTI");
    documentTypeMap.put("Asset Purchase Agreement","DTYP_ROOT_APAT");
    documentTypeMap.put("Assignment","DTYP_ROOT_ASSN");
    documentTypeMap.put("Bankruptcy","DTYP_ROOT_BKPT");
    documentTypeMap.put("Brief","DTYP_ROOT_BRIF");
    documentTypeMap.put("Certificate","DTYP_ROOT_CERT");
    documentTypeMap.put("Charitable Giving Plan","DTYP_ROOT_CHGP");
    documentTypeMap.put("Complaint","DTYP_ROOT_CMSU");
    documentTypeMap.put("complaint/summons","DTYP_ROOT_CMSU");
    documentTypeMap.put("Complaint/Summons","DTYP_ROOT_CMSU");
    documentTypeMap.put("COMPLAINT/SUMMONS","DTYP_ROOT_CMSU");
    documentTypeMap.put("Complaint-Summons","DTYP_ROOT_CMSU");
    documentTypeMap.put("Confidentiality","DTYP_ROOT_CFDI");
    documentTypeMap.put("Consignment","DTYP_ROOT_CNSM");
    documentTypeMap.put("Consulting","DTYP_ROOT_CNST");
    documentTypeMap.put("Correspondence","DTYP_ROOT_CORS");
    documentTypeMap.put("Declaration","DTYP_ROOT_DECL");
    documentTypeMap.put("Deferred Compensation Agreement","DTYP_ROOT_DECA");
    documentTypeMap.put("Demand","DTYP_ROOT_DMND");
    documentTypeMap.put("Depositions","DTYP_ROOT_DEPO");
    documentTypeMap.put("Deposition","DTYP_ROOT_DEPO");
    documentTypeMap.put("Designation","DTYP_ROOT_DESN");
    documentTypeMap.put("Disclosure","DTYP_ROOT_DISC");
    documentTypeMap.put("Discovery","DTYP_ROOT_DSCY");
    documentTypeMap.put("Dismissal","DTYP_ROOT_DISM");
    documentTypeMap.put("Drafts","DTYP_ROOT_DRFT");
    documentTypeMap.put("Employee Agreement","DTYP_ROOT_EMPA");
    documentTypeMap.put("Engagement Letter","DTYP_ROOT_ENGL");
    documentTypeMap.put("Entry","DTYP_ROOT_ENTY");
    documentTypeMap.put("Equipment Lease","DTYP_ROOT_EQLE");
    documentTypeMap.put("Equipment Purchase","DTYP_ROOT_EQPU");
    documentTypeMap.put("Expert Reports","DTYP_ROOT_EXPT");
    documentTypeMap.put("Governance Agreement","DTYP_ROOT_GVAG");
    documentTypeMap.put("Government Contracts","DTYP_ROOT_GVCT");
    documentTypeMap.put("Incentive Plan Agreement","DTYP_ROOT_INPA");
    documentTypeMap.put("Indemnification Agreement","DTYP_ROOT_INDM");
    documentTypeMap.put("Insurance Correspondence","DTYP_ROOT_INSC");
    documentTypeMap.put("Joinder","DTYP_ROOT_JNDR");
    documentTypeMap.put("Joint","DTYP_ROOT_JONT");
    documentTypeMap.put("Joint Venture and Alliances","DTYP_ROOT_JVAA");
    documentTypeMap.put("Judgment","DTYP_ROOT_JDGM");
    documentTypeMap.put("Judgment Order-Dismissal","DTYP_ROOT_JUOD");
    documentTypeMap.put("judgment order/dismissal","DTYP_ROOT_JUOD");
    documentTypeMap.put("Judgment order/Dismissal","DTYP_ROOT_JUOD");
    documentTypeMap.put("Lab Services Agreement","DTYP_ROOT_LSAG");
    documentTypeMap.put("Lease Agreement","DTYP_ROOT_LEAG");
    documentTypeMap.put("Loan Agreement","DTYP_ROOT_LNAG");
    documentTypeMap.put("Marketing Agreements","DTYP_ROOT_MKTG");
    documentTypeMap.put("Master Consulting","DTYP_ROOT_MTCN");
    documentTypeMap.put("Master Services","DTYP_ROOT_MTSV");
    documentTypeMap.put("Material Transfer Agreement","DTYP_ROOT_MTAG");
    documentTypeMap.put("Memorandum","DTYP_ROOT_MEMO");
    documentTypeMap.put("Merger Agreements","DTYP_ROOT_MRGE");
    documentTypeMap.put("Motion","DTYP_ROOT_MTON");
    documentTypeMap.put("Nondisclosure Agreement","DTYP_ROOT_NDCA");
    documentTypeMap.put("Notes","DTYP_ROOT_NOTE");
    documentTypeMap.put("Notice","DTYP_ROOT_NTCE");
    documentTypeMap.put("Objection","DTYP_ROOT_OBJN");
    documentTypeMap.put("Opinion","DTYP_ROOT_OPIN");
    documentTypeMap.put("Opposed","DTYP_ROOT_OPPO");
    documentTypeMap.put("Opposition","DTYP_ROOT_OPSN");
    documentTypeMap.put("Order","DTYP_ROOT_ORDR");
    documentTypeMap.put("Other/Miscellaneous","DTYP_ROOT_OTMI");
    documentTypeMap.put("Partnership Agreements","DTYP_ROOT_PTAG");
    documentTypeMap.put("Patent - Commercial","DTYP_ROOT_PTCM");
    documentTypeMap.put("Patent - Event","DTYP_ROOT_PTEV");
    documentTypeMap.put("Patent - Formulation","DTYP_ROOT_PTFO");
    documentTypeMap.put("Pleadings","DTYP_ROOT_PLEA");
    documentTypeMap.put("Preliminary Pleading","DTYP_ROOT_PREP");
    documentTypeMap.put("Preliminary","DTYP_ROOT_PREP");
    documentTypeMap.put("Programming/Consulting Services","DTYP_ROOT_PCSV");
    documentTypeMap.put("Proposed Pleading","DTYP_ROOT_PRPL");
    documentTypeMap.put("Proposed","DTYP_ROOT_PRPL");
    documentTypeMap.put("Purchase Agreement-Real Estate","DTYP_ROOT_PARE");
    documentTypeMap.put("Purchase of Goods","DTYP_ROOT_PUGO");
    documentTypeMap.put("Real Estate Sale Agreement","DTYP_ROOT_RESA");
    documentTypeMap.put("Regulatory Study Agreement","DTYP_ROOT_RSAG");
    documentTypeMap.put("Reply","DTYP_ROOT_RPLY");
    documentTypeMap.put("Report","DTYP_ROOT_REPT");
    documentTypeMap.put("Request","DTYP_ROOT_RQST");
    documentTypeMap.put("Respondent Pleading","DTYP_ROOT_REPL");
    documentTypeMap.put("Respondent","DTYP_ROOT_REPL");
    documentTypeMap.put("Response","DTYP_ROOT_RESP");
    documentTypeMap.put("Retirement Policy Agreement","DTYP_ROOT_RPAG");
    documentTypeMap.put("Sales Agreement","DTYP_ROOT_SALE");
    documentTypeMap.put("Scheduling","DTYP_ROOT_SCHE");
    documentTypeMap.put("Security Agreement","DTYP_ROOT_SCAG");
    documentTypeMap.put("Separation Agreement","DTYP_ROOT_SPAG");
    documentTypeMap.put("Services Agreement","DTYP_ROOT_SVAG");
    documentTypeMap.put("Share Exchange Agreement","DTYP_ROOT_SHEX");
    documentTypeMap.put("Shareholders Agreement","DTYP_ROOT_SHAG");
    documentTypeMap.put("Software License Agreement","DTYP_ROOT_SOLA");
    documentTypeMap.put("Standstill Agreement","DTYP_ROOT_STND");
    documentTypeMap.put("Stipulation","DTYP_ROOT_STIP");
    documentTypeMap.put("Stock Purchase Agreement","DTYP_ROOT_STPA");
    documentTypeMap.put("Strategic Marketing Alliance Agreement","DTYP_ROOT_SMAA");
    documentTypeMap.put("Submissions","DTYP_ROOT_SUBM");
    documentTypeMap.put("Subpoena","DTYP_ROOT_SUBP");
    documentTypeMap.put("Supplemental Pleading","DTYP_ROOT_SUPP");
    documentTypeMap.put("Supplemental","DTYP_ROOT_SUPP");
    documentTypeMap.put("Supply Agreement","DTYP_ROOT_SUAG");
    documentTypeMap.put("Support Pleading","DTYP_ROOT_SUPL");
    documentTypeMap.put("Support","DTYP_ROOT_SUPL");
    documentTypeMap.put("Training Eduction Services Agreement","DTYP_ROOT_TESA");
    documentTypeMap.put("Transcripts","DTYP_ROOT_TRAN");
    documentTypeMap.put("Unopposed Pleading","DTYP_ROOT_UNPL");
    documentTypeMap.put("Unopposed","DTYP_ROOT_UNPL");
    documentTypeMap.put("Verification","DTYP_ROOT_VERI");
    documentTypeMap.put("Verified","DTYP_ROOT_VERD");
    documentTypeMap.put("Witness","DTYP_ROOT_WITN");
  }


  public DocumentMetaData(String r_object_id, String i_chronicle_id, String clp_no, String matter_name, String cause_no,
                String object_name, String pleading_type, String date_filed, String folder_type,
                String r_creation_date, String r_creator_name) {
    this.r_object_id = r_object_id;
    this.i_chronicle_id = i_chronicle_id;
    this.clp_no = clp_no;
    this.matter_name = matter_name;
    this.cause_no = cause_no;
    this.object_name = object_name;
    this.pleading_type = pleading_type;
    this.date_filed = date_filed;
    this.folder_type = folder_type;
    this.r_creation_date = r_creation_date;
    this.r_creator_name = r_creator_name;
  }


  public String getR_object_id() {
    return r_object_id;
  }

  public String getI_chronicle_id() {
    return i_chronicle_id;
  }

  public String getClp_no() {
    return clp_no;
  }

  public String getMatter_name() {
    return matter_name;
  }

  public String getCause_no() {
    return cause_no;
  }

  public String getObject_name() {
    return object_name;
  }

  public String getPleading_type() {
    return pleading_type;
  }

  public String getDate_filed() {
    return date_filed;
  }

  public String getDocumentType() {
    if(folder_type==null){
       return "DTYP_ROOT_PLEA";
    }
    if(folder_type.equalsIgnoreCase("Pleadings")){
         if(pleading_type==null || pleading_type.length()==0){
           return "DTYP_ROOT_PLEA";
         } else{
             return (String) documentTypeMap.get(pleading_type);
         }
    }

    return (String) documentTypeMap.get(folder_type);
  }

  public String getFolder_type() {
    return folder_type;
  }

  public String getR_creation_date() {
    String date = DateUtil.getDate("yyyy-MM-dd", new Date(r_creation_date));
    return date;
  }

  public String getR_creator_name() {
    return r_creator_name;
  }
}