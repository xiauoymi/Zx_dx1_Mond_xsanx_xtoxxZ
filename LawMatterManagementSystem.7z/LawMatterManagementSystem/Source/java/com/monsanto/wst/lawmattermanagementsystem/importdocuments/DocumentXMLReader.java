/*
 DocumentXMLReader was created on Oct 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments;

/**
 * Filename:    $RCSfile: DocumentXMLReader.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-11 18:53:38 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public interface DocumentXMLReader {
  Root parse(String inputFilePath);
}