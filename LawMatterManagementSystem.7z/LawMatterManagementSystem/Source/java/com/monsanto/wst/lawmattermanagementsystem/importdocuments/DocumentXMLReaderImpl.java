/*
 DoucmentXMLReaderImpl was created on Oct 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments;

import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: DocumentXMLReaderImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-15 16:11:18 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class DocumentXMLReaderImpl implements DocumentXMLReader {

  private StAXParserUtil parserUtil = new StAXParserUtil();
  private static final String R_OBJECT_ID = "r_object_id";
  private static final String I_CHRONICLE_ID = "i_chronicle_id";
  private static final String CLP_NO = "clp_no";
  private static final String MATTER_NAME = "matter_name";
  private static final String CAUSE_NO = "cause_no";
  private static final String OBJECT_NAME = "object_name";
  private static final String PLEADING_TYPE = "pleading_type";
  private static final String DATE_FILED = "date_filed";
  private static final String FOLDER_TYPE = "folder_type";
  private static final String R_CREATION_DATE = "r_creation_date";
  private static final String R_CREATOR_NAME = "r_creator_name";

  //TODO Take care of exceptions
  public Root parse(String inputFilePath) {
    FileInputStream fileInputStream;
    Root root = null;
    try {
      fileInputStream = new FileInputStream(inputFilePath);
      XMLStreamReader xmlFileCursor = StAXParserUtil.instantiateStAXParser(fileInputStream);
      int event;
      while ((event = xmlFileCursor.next()) != XMLStreamConstants.END_DOCUMENT) {
        if (event == XMLStreamConstants.START_ELEMENT) {
          root = parseProductsDetail(xmlFileCursor);
        }
      }
      xmlFileCursor.close();
    } catch (FileNotFoundException e) {
      throw new DocumentImportProcessingException("Could not find import document located at :"+inputFilePath,e);
    } catch (XMLStreamException e) {
      throw new DocumentImportProcessingException("Error parsing import document located at :"+inputFilePath,e);      
    }
    return root;
  }

  private Root parseProductsDetail(XMLStreamReader xmlFileCursor) throws XMLStreamException {
    List objectList = new ArrayList();
    Root root = null;
    if(xmlFileCursor.getLocalName().equalsIgnoreCase("root")){
      DocumentMetaData object = null;
      while (parserUtil.getNextChildElement("object", xmlFileCursor) || parserUtil.getNextElement("object", xmlFileCursor)) {
        String objectId = getValue(xmlFileCursor, R_OBJECT_ID);
        String chronicleId = getValue(xmlFileCursor, I_CHRONICLE_ID);
        String clp_no = getValue(xmlFileCursor, CLP_NO);
        String matter_name = getValue(xmlFileCursor, MATTER_NAME);
        String cause_no = getValue(xmlFileCursor, CAUSE_NO);
        String object_name = getValue(xmlFileCursor, OBJECT_NAME);
        String pleading_type = getValue(xmlFileCursor, PLEADING_TYPE);
        String date_filed = getValue(xmlFileCursor, DATE_FILED);
        String folder_type = getValue(xmlFileCursor, FOLDER_TYPE);
        String r_creation_date = getValue(xmlFileCursor, R_CREATION_DATE);
        String r_creator_name = getValue(xmlFileCursor, R_CREATOR_NAME);
        object = new DocumentMetaData(objectId,chronicleId,clp_no,matter_name,cause_no,
            object_name,pleading_type,date_filed,folder_type,r_creation_date,r_creator_name);
        objectList.add(object);
      }
    }
    root = new Root(objectList);
    return root;
  }

  private String getValue(XMLStreamReader xmlFileCursor, String nodeName) throws XMLStreamException {
    String objectId = null;
    if(parserUtil.getNextChildElement(nodeName, xmlFileCursor)){
      objectId = parserUtil.getSimpleElementText(R_OBJECT_ID, xmlFileCursor);
    }
    return objectId;
  }
}