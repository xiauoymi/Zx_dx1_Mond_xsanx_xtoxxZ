/*
 Root was created on Oct 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments;

import java.util.List;

/**
 * Filename:    $RCSfile: Root.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-15 15:28:33 $
 *
 * @author vrbethi
 * @version $Revision: 1.4 $
 */
public class Root {
  private List objectList;

  public Root(List object) {
    this.objectList = object;
  }


  public List getObjectList() {
    return objectList;
  }
}