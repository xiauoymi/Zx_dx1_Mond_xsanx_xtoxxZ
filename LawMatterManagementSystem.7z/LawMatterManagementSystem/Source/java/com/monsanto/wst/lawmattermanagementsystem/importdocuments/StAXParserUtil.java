/*
 StAXParserUtil was created on Oct 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments;

import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLInputFactory;
import java.io.InputStream;

/**
 * Filename:    $RCSfile: StAXParserUtil.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-11 18:19:03 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class StAXParserUtil {
    String getSimpleElementText(String elementName, XMLStreamReader xmlFileCursor) throws XMLStreamException {
    String property = null;
    if(getCharacterElement(xmlFileCursor)){
      property = xmlFileCursor.getText();
      endCurrentElement(xmlFileCursor);
    }
    return property;
  }

  boolean getNextElement(String expectedElementName, XMLStreamReader xmlFileCursor) throws XMLStreamException {
    return moveCursorToNext(XMLStreamConstants.START_ELEMENT, false, xmlFileCursor, true) &&
        xmlFileCursor.getLocalName().equalsIgnoreCase(expectedElementName);
  }

  boolean getNextChildElement(String expectedElementName, XMLStreamReader xmlFileCursor) throws XMLStreamException {
    return moveCursorToNext(XMLStreamConstants.START_ELEMENT, true, xmlFileCursor, true) &&
        xmlFileCursor.getLocalName().equalsIgnoreCase(expectedElementName);
  }

  boolean getCharacterElement(XMLStreamReader xmlFileCursor) throws XMLStreamException {
    return moveCursorToNext(XMLStreamConstants.CHARACTERS, true, xmlFileCursor, true);
  }

  boolean endCurrentElement(XMLStreamReader xmlFileCursor) throws XMLStreamException {
    return moveCursorToNext(XMLStreamConstants.END_ELEMENT, true, xmlFileCursor, false);
  }

  /**
   * Case1: It is possible that while looking for a child element which was eventually not found, the cursor moved till the
   * end of parent element and returned false. Eg: When we look for productAliases recursively.
   * Thus we check for this condition even before starting to move towards the end.
   * @param elementName
   * @param xmlFileCursor
   * @return
   * @throws XMLStreamException
   */
  boolean endCurrentComplexElement(String elementName, XMLStreamReader xmlFileCursor) throws XMLStreamException {
    while (xmlFileCursor.getEventType() != XMLStreamConstants.END_ELEMENT || !xmlFileCursor.getLocalName().equalsIgnoreCase(elementName)) {
      if (!moveCursorToNext(XMLStreamConstants.END_ELEMENT, true, xmlFileCursor, false)) {
        return false;
      }
    }
    return true;
  }

  void skipElement(String elementName, XMLStreamReader xmlFileCursor) throws XMLStreamException {
    if(getNextElement(elementName, xmlFileCursor)) {
      endCurrentElement(xmlFileCursor);
    }
  }

  void skipChildElement(String elementName, XMLStreamReader xmlFileCursor) throws XMLStreamException {
    if(getNextChildElement(elementName, xmlFileCursor)) {
      endCurrentElement(xmlFileCursor);
    }
  }

  static XMLStreamReader instantiateStAXParser(InputStream inputStream) throws XMLStreamException {
    XMLInputFactory factory = XMLInputFactory.newInstance();
    factory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.FALSE);
    return factory.createXMLStreamReader(inputStream);
  }

  private boolean moveCursorToNext(int requiredPosition, boolean skipCurrentEvent, XMLStreamReader xmlFileCursor, boolean checkForEndElement) throws XMLStreamException {
    int event = getInitialEvent(skipCurrentEvent, xmlFileCursor);
    while(event != requiredPosition) {
      event = xmlFileCursor.next();
      if(checkForEndElement && event == XMLStreamConstants.END_ELEMENT) {
        return false;
      }
      if(event == XMLStreamConstants.END_DOCUMENT) {
        return false;
      }
    }
    return true;
  }

  /**
   * @param skipCurrentEvent  true - in case we are moving from ParentElement to First ChildElement
   *                          false - in case we are moving from one ChildElement to another ChildElement
   * @param xmlFileCursor
   * @return int - initialized value of event
   */
  private int getInitialEvent(boolean skipCurrentEvent, XMLStreamReader xmlFileCursor) {
    int event;
    if(skipCurrentEvent) {
      event = -1;
    } else {
      event = xmlFileCursor.getEventType();
    }
    return event;
  }
}