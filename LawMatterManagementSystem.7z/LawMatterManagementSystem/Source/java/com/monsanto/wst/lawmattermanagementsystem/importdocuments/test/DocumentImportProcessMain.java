/*
 DocumentImportProcessMain was created on Jun 10, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments.test;

import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcessorFactory;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcessorFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcess;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

/**
 * Filename:    $RCSfile: DocumentImportProcessMain.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-10 20:17:47 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class DocumentImportProcessMain {

  public static void main(String[] args) throws ServiceException {
    DocumentImportProcessorFactory documentImportProcessorFactory = new DocumentImportProcessorFactoryImpl();
    DocumentImportProcess documentImportProcessor = documentImportProcessorFactory.getDocumentImportProcessor();
    documentImportProcessor.importDocumentMetaData("C:\\WSTTemp\\lmms\\litigation_doc_dump.xml");
  }
}