/*
 DocumentImportProcessorImplFactory_UT was created on Oct 15, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments.test;

import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcess;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcessImpl;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcessorFactory;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcessorFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;

/**
 * Filename:    $RCSfile: DocumentImportProcessorImplFactory_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-15 15:46:29 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class DocumentImportProcessorImplFactory_UT extends LMMSBaseTestCase {
  
  public void testGetDocumentImportProcessor() throws Exception {
    DocumentImportProcessorFactory documentImportProcessorImplFactory = 
        new DocumentImportProcessorFactoryImpl();
    DocumentImportProcess documentImportProcess =documentImportProcessorImplFactory.getDocumentImportProcessor();
    assertTrue(documentImportProcess instanceof DocumentImportProcessImpl);
  }
}