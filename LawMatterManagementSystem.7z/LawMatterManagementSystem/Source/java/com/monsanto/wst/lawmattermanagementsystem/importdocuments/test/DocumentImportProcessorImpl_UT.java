/*
 DocumentImportProcessorImpl_UT was created on Oct 12, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments.test;

import com.monsanto.wst.lawmattermanagementsystem.check.ChecksVoidsXMLBuilder;
import com.monsanto.wst.lawmattermanagementsystem.check.ErrorHandler;
import com.monsanto.wst.lawmattermanagementsystem.check.ResultsProcessor;
import com.monsanto.wst.lawmattermanagementsystem.check.TeamConnectCheckDAO;
import com.monsanto.wst.lawmattermanagementsystem.check.test.MockChecksVoidsXMLBuilder;
import com.monsanto.wst.lawmattermanagementsystem.check.test.MockResultProcessorImpl;
import com.monsanto.wst.lawmattermanagementsystem.check.test.MockTeamConnectCheckDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.check.test.MockResutlProcessorImpl_SuccessfullyProcessed;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcess;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcessImpl;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentXMLReader;
import com.monsanto.wst.lawmattermanagementsystem.voids.test.MockErrorHandler;
import junit.framework.TestCase;
import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: DocumentImportProcessorImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: bghale $    	 On:	$Date: 2009-02-10 20:04:01 $
 *
 * @author vrbethi
 * @version $Revision: 1.5 $
 */
public class DocumentImportProcessorImpl_UT extends TestCase {
  private DocumentImportProcess documentImportProcess;
  private DocumentXMLReader documentXMLReader = new MockDocumentXMLReader();
  private ChecksVoidsXMLBuilder checksVoidsXMLBuilder = new MockChecksVoidsXMLBuilder();
  private TeamConnectCheckDAO teamConnectCheckDAO = new MockTeamConnectCheckDAOImpl(null);
  private ResultsProcessor resultsProcessor = new MockResultProcessorImpl();
  private ErrorHandler errorHandler = new MockErrorHandler();


  protected void setUp() throws Exception {
    super.setUp();
    documentImportProcess = new DocumentImportProcessImpl(documentXMLReader,
        checksVoidsXMLBuilder, teamConnectCheckDAO, resultsProcessor, errorHandler);
  }

  public void testImportDocumentMetaData_CallDocumentReader() throws Exception {
    documentImportProcess.importDocumentMetaData("inputfile");
    assertTrue(((MockDocumentXMLReader)documentXMLReader).wasCalled());
  }

  public void testImportDocumentMetaData_CallChecksVoidsXMLBuilder() throws Exception {
    documentImportProcess.importDocumentMetaData("inputfile");
    assertTrue(((MockChecksVoidsXMLBuilder)checksVoidsXMLBuilder).wasBuildUpdateDocumentXMLCalled());
    assertTrue(((MockChecksVoidsXMLBuilder)checksVoidsXMLBuilder).numberOfTimesBuildUpdateDocumentXMLCalled()==2);
  }

  public void testImportDocumentMetaData_CallTeamConnectCheckDAOImpl() throws Exception {
    documentImportProcess.importDocumentMetaData("inputfile");
    assertTrue(((MockTeamConnectCheckDAOImpl)teamConnectCheckDAO).wasCallServiceCalled());
    assertTrue(((MockTeamConnectCheckDAOImpl)teamConnectCheckDAO).numberOfTimesServiceCalled()==2);
  }

  public void testImportDocumentMetaData_CallResultProcessorAndWriteFailureResultsToOutputFile() throws Exception {
    documentImportProcess.importDocumentMetaData("inputfile");
    assertTrue(((MockResultProcessorImpl)resultsProcessor).wasResultsProcessorCalled());
    assertTrue(((MockResultProcessorImpl)resultsProcessor).numberOfTimesResultProcessorCalled()==2);
    String outputMessage = ((MockErrorHandler) errorHandler).getMessage();
    assertTrue(StringUtils.contains(outputMessage.trim(),
        "Failure Processing Please read: DTYP_ROOT_CORS for Matter : Nichols, John v. A. W. Chesterton (asbestos)  CLP Nop. :2003-000658  Document Name :Title_two"));
  }

  public void testImportDocumentMetaData_CallResultProcessorAndWriteSuccessResultsToOutputFile() throws Exception {
    resultsProcessor = new MockResutlProcessorImpl_SuccessfullyProcessed();
    documentImportProcess = new DocumentImportProcessImpl(documentXMLReader,
            checksVoidsXMLBuilder, teamConnectCheckDAO, resultsProcessor, errorHandler);
    documentImportProcess.importDocumentMetaData("inputfile");
    String outputMessage = ((MockErrorHandler) errorHandler).getMessage();
    assertTrue(StringUtils.contains(outputMessage.trim(),"Successfully Updated :Matter Name : Nichols, John v. A. W. Chesterton (asbestos)  CLP Nop. :2003-000658  Document Name :Title_two"));
  }

  public void testImportDocumentMetaData_CallResultProcessorInvalidDocumentTypeWriteError() throws Exception {
    resultsProcessor = new MockResutlProcessorImpl_SuccessfullyProcessed();
    documentImportProcess = new DocumentImportProcessImpl(new MockDocumentXMLReader_GetInvalidFolderTypeDocument(),
            checksVoidsXMLBuilder, teamConnectCheckDAO, resultsProcessor, errorHandler);
    documentImportProcess.importDocumentMetaData("inputfile");
    assertTrue(StringUtils.contains(((MockErrorHandler) errorHandler).getMessage().trim(),"Successfully Updated :Matter Name : Nichols, John v. A. W. Chesterton (asbestos)  CLP Nop. :2003-000658  Document Name :Title_two".trim()));
  }
}