/*
 DocumentMetaData_UT was created on Oct 24, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments.test;

import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentMetaData;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: DocumentMetaData_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-01-15 16:29:13 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class DocumentMetaData_UT extends TestCase {

  public void testGetDocumentType_IfFolderTypeIsNotPleading_AndFolderTypeIsNotNullAndNotPleading() throws Exception {
    DocumentMetaData documentMetaData = TestDocumentMetaData.getTestDocumentMetaDataWhereFolderTypeIsNotPleading_UseFolderTypeAsDocumentType();
    String folder_type = documentMetaData.getDocumentType();
    assertEquals("DTYP_ROOT_CORS",folder_type);
  }

  public void testGetDocumentType_IfFolderTypeIsNotPleading_AndFolderTypeIsNull() throws Exception {
    DocumentMetaData documentMetaData = TestDocumentMetaData.getTestDocumentMetaDataWithEmptyFolderType();
    String folder_type = documentMetaData.getDocumentType();
    assertEquals("DTYP_ROOT_PLEA",folder_type);
  }

  public void testGetDocumentType_IfFolderTypeIsPleading_AndPleadingTypeIsNull() throws Exception {
    DocumentMetaData documentMetaData = TestDocumentMetaData.getTestDocumentMetaDataTwoWithoutFolderType();
    String folder_type = documentMetaData.getDocumentType();
    assertEquals("DTYP_ROOT_PLEA",folder_type);
  }

  public void testGetDocumentType_IfFolderTypeIsPleading_GetTheCorrecspondingPleadingValue() throws Exception {
    DocumentMetaData documentMetaData = TestDocumentMetaData.getTestDocumentMetaDataWhereFolderTypeIsPleading();
    String folder_type = documentMetaData.getDocumentType();
    assertEquals("DTYP_ROOT_OTMI",folder_type);
  }
}