/*
 DocumentXMLBuilder_UT was created on Oct 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments.test;

import junit.framework.TestCase;
import com.monsanto.wst.lawmattermanagementsystem.check.XMLBuilder;
import com.monsanto.wst.lawmattermanagementsystem.check.ChecksVoidsXMLBuilder;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentMetaData;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.apache.xpath.XPathAPI;

/**
 * Filename:    $RCSfile: DocumentXMLBuilder_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-07-03 19:37:28 $
 *
 * @author vrbethi
 * @version $Revision: 1.5 $
 */
public class DocumentXMLBuilder_UT extends TestCase {
  
  public void testbuildUpdateDocumentXML() throws Exception {
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    DocumentMetaData documentMetaData = TestDocumentMetaData.getTestDocumentMetaDataWhereFolderTypeIsNotPleading_UseFolderTypeAsDocumentType();
    Document document= xmlBuilder.buildUpdateDocumentXML(documentMetaData);
    assertNotNull(document);
    DOMUtil.outputXML(document);
    Node usernamenode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Username");
    Node passwordNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Authentication/Password");
    Node invoiceNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project");
    Node applicationNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Application");
    Node parentNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Parent");
    Node nameNode = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Name");
    Node detail = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail");

    Node docCreateBy = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/DocCreatedBy");
    Node docType = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/DocDocType");
    Node docCreatedDate = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/DocCreatedDate");
    Node documentName = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/DocumentName");
    Node posId = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Project/Detail/POSObjectId");

//    assertEquals("vrbethi",DOMUtil.getTextValue(usernamenode));
//    assertEquals("janaki78",DOMUtil.getTextValue(passwordNode));
    assertEquals("insert",DOMUtil.getAttribute((Element) invoiceNode,"op"));
    assertEquals("DOCS",DOMUtil.getTextValue(applicationNode));
    assertEquals("2003-000658",DOMUtil.getTextValue(parentNode));
    assertEquals("NumberString",DOMUtil.getAttribute((Element) parentNode,"keymap"));
    assertEquals("Title_two",DOMUtil.getTextValue(nameNode));
    assertEquals("DOCS",DOMUtil.getAttribute((Element) detail,"key"));

    assertEquals("Watts Randall B",DOMUtil.getTextValue(docCreateBy));
    assertEquals("DTYP_ROOT_CORS",DOMUtil.getTextValue(docType));
    assertEquals("2004-10-20",DOMUtil.getTextValue(docCreatedDate));
    assertEquals("Title_two",DOMUtil.getTextValue(documentName));
    assertEquals("090055f6800a0948",DOMUtil.getTextValue(posId));

  }

}