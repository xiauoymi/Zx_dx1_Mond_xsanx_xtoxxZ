/*
 DocumentXMLReaderImpl_UT was created on Oct 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments.test;

import com.monsanto.wst.lawmattermanagementsystem.importdocuments.*;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: DocumentXMLReaderImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-15 16:11:18 $
 *
 * @author vrbethi
 * @version $Revision: 1.7 $
 */
public class DocumentXMLReaderImpl_UT extends TestCase {

  public void testParse_CheckXMLContents() throws Exception {
    DocumentXMLReader documentXMLReader = new DocumentXMLReaderImpl();
    Root documentDataList = documentXMLReader.parse(
        "com\\monsanto\\wst\\lawmattermanagementsystem\\importdocuments\\test\\input.xml");
    List objectList = documentDataList.getObjectList();
    assertEquals(1,objectList.size());
    assertEquals("2003-000658", ((DocumentMetaData) objectList.get(0)).getClp_no());
  }

  public void testParse_MultipleEntries() throws Exception {
    DocumentXMLReader documentXMLReader = new DocumentXMLReaderImpl();
    Root documentDataList = documentXMLReader.parse(
        "com\\monsanto\\wst\\lawmattermanagementsystem\\importdocuments\\test\\inputWithMultiple.xml");
    List objectList = documentDataList.getObjectList();
    assertEquals(2,objectList.size());
    assertEquals("2003-000460", ((DocumentMetaData) objectList.get(1)).getClp_no());
  }

  public void testParse_DocumentImportProcessingExcption_DueToFileNotFoundException() throws Exception {
    try {
      DocumentXMLReader documentXMLReader = new DocumentXMLReaderImpl();
      documentXMLReader.parse(
          "com\\monsanto\\wst\\lawmattermanagementsystem\\importdocuments\\test\\inputWithMurltiple.xml");
      fail("Exception should have been thrown");
    } catch (DocumentImportProcessingException e) {
      e.printStackTrace();
    }
  }

  public void testParse_DocumentImportProcessingExcption_PraseException() throws Exception {
    try {
      DocumentXMLReader documentXMLReader = new DocumentXMLReaderImpl();
      documentXMLReader.parse(
          "com\\monsanto\\wst\\lawmattermanagementsystem\\importdocuments\\test\\inputWithException.xml");
      fail("Exception should have been thrown");
    } catch (DocumentImportProcessingException e) {
      e.printStackTrace();
    }
  }
}