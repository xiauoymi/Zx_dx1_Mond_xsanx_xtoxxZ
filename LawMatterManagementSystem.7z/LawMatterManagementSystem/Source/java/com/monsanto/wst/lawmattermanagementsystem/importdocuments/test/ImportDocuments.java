/*
 ImportDocuments was created on Feb 15, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments.test;

import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcess;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcessorFactory;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentImportProcessorFactoryImpl;

/**
 * Filename:    $RCSfile: ImportDocuments.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 17:51:35 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class ImportDocuments {

  public static void main(String[] args) {
    String filelocation = args[0];
    System.out.println("filelocation = " + filelocation);
    try {
      DocumentImportProcessorFactory documentImportProcessorFactory = new DocumentImportProcessorFactoryImpl();
      DocumentImportProcess documentImportProcessor = documentImportProcessorFactory.getDocumentImportProcessor();
      documentImportProcessor.importDocumentMetaData(filelocation);
      System.out.println("Done importing documents");
    } catch (Exception e) {
      System.out.println("e = " + e);
    }

  }
}