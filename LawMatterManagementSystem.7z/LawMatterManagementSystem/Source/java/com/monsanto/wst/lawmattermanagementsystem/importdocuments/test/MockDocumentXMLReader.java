/*
 MockDocumentXMLReader was created on Oct 15, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments.test;

import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentXMLReader;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.Root;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentMetaData;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockDocumentXMLReader.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-01-15 16:29:13 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class MockDocumentXMLReader implements DocumentXMLReader {
  private boolean wasCalled = false;

  public Root parse(String inputFilePath) {
    DocumentMetaData documentMetaDataOne = TestDocumentMetaData.getTestDocumentMetaDataWhereFolderTypeIsNotPleading_UseFolderTypeAsDocumentType();
    DocumentMetaData documentMetaDataTwo = TestDocumentMetaData.getTestDocumentMetaDataWhereFolderTypeIsNotPleading_UseFolderTypeAsDocumentType();
    List documentMetaDataList = new ArrayList();
    documentMetaDataList.add(documentMetaDataOne);
    documentMetaDataList.add(documentMetaDataTwo);
    Root root = new Root(documentMetaDataList);
    if(inputFilePath!=null)
    wasCalled=true;
    return root;
  }

  public boolean wasCalled() {
    return wasCalled;
  }
}