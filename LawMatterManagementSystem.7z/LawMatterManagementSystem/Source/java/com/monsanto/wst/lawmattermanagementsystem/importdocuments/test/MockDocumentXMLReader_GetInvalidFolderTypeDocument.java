/*
 MockDocumentXMLReader_GetInvalidFolderTypeDocument was created on Oct 24, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments.test;

import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentXMLReader;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.Root;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentMetaData;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockDocumentXMLReader_GetInvalidFolderTypeDocument.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-26 20:27:04 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class MockDocumentXMLReader_GetInvalidFolderTypeDocument implements DocumentXMLReader {
  public Root parse(String inputFilePath) {
    DocumentMetaData documentMetaDataOne = TestDocumentMetaData.getTestDocumentMetaDataTwoWithoutFolderType();
    List documentMetaDataList = new ArrayList();
    documentMetaDataList.add(documentMetaDataOne);
    return new Root(documentMetaDataList);
  }
}