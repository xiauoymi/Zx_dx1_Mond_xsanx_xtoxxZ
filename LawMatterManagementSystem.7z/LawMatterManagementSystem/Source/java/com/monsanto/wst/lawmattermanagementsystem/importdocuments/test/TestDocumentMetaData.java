/*
 TestDocumentMetaData was created on Oct 15, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.importdocuments.test;

import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentMetaData;

/**
 * Filename:    $RCSfile: TestDocumentMetaData.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-01-15 16:29:13 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public class TestDocumentMetaData {
  static DocumentMetaData getTestDocumentMetaDataWhereFolderTypeIsNotPleading_UseFolderTypeAsDocumentType() {
    DocumentMetaData documentMetaData = new DocumentMetaData("090055f6800a0948","090055f6800a0948",
        "2003-000658","Nichols, John v. A. W. Chesterton (asbestos)","2003-37485","Title_two",
        "Correspondence","10/19/2004 12:00:00 AM","Correspondence","10/20/2004 02:18:15 PM","Watts Randall B");
    return documentMetaData;
  }

  static DocumentMetaData getTestDocumentMetaDataWithEmptyFolderType() {
    DocumentMetaData documentMetaData = new DocumentMetaData("090055f6800a0948","090055f6800a0948",
        "2003-000658","Nichols, John v. A. W. Chesterton (asbestos)","2003-37485","Title_two",
        "Correspondence","10/19/2004 12:00:00 AM",null,"10/20/2004 02:18:15 PM","Watts Randall B");
    return documentMetaData;
  }

  static DocumentMetaData getTestDocumentMetaDataTwoWithoutFolderType() {
    DocumentMetaData documentMetaData = new DocumentMetaData("090055f6800a0948","090055f6800a0948",
        "2003-000658","Nichols, John v. A. W. Chesterton (asbestos)","2003-37485","Title_two",
        null,"10/19/2004 12:00:00 AM","Pleadings","10/20/2004 02:18:15 PM","Watts Randall B");
    return documentMetaData;
  }

  static DocumentMetaData getTestDocumentMetaDataWhereFolderTypeIsPleading() {
    DocumentMetaData documentMetaData = new DocumentMetaData("090055f6800a0948","090055f6800a0948",
        "2003-000658","Nichols, John v. A. W. Chesterton (asbestos)","2003-37485","Title_two",
        "Other/Miscellaneous","10/19/2004 12:00:00 AM","Pleadings","10/20/2004 02:18:15 PM","Watts Randall B");
    return documentMetaData;
  }
}