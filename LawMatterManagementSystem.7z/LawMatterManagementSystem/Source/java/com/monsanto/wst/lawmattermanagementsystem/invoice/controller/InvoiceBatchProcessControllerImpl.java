/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.lawmattermanagementsystem.config.xstream.ConfigReaderXStreamImpl;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.LastRunInfoDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.EmailUtility;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceProcessingService;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.PropertyFileReader;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactory;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: InvoiceBatchProcessControllerImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-09 20:30:22 $
 *
 * @author rdesai2
 * @version $Revision: 1.40 $
 */
public class InvoiceBatchProcessControllerImpl implements InvoiceBatchProcessController {

  private String histroyDir;
  private String lastRunInfoDir;
  private String configDir;

  private InvoiceProcessingService invoiceProcessingService;
  private EmailUtility emailUtility;
  private ErrorReportWriter errorReportWriter;
  private LastRunInfoDAO lastRunInfoDAO;
  private PropertyFileReader propertyFileReader;
  private PropertyList propertyList;

  public InvoiceBatchProcessControllerImpl(InvoiceProcessingService invoiceProcessingService, EmailUtility emailUtility, ErrorReportWriter errorReportWriter, LastRunInfoDAO lastRunInfoDAO, PropertyFileReader propertyFileReader) {
    this.invoiceProcessingService = invoiceProcessingService;
    this.emailUtility = emailUtility;
    this.errorReportWriter = errorReportWriter;
    this.lastRunInfoDAO = lastRunInfoDAO;
    this.propertyFileReader = propertyFileReader;
  }

  public void runInvoiceBatchProcess(String invoiceFileName, String summaryReportFileName, String rejectionReportFileName, String errorReportFileName) {
    if (!systemParamsSet() || !readConfigProperties() || !errorReportInitialized(errorReportFileName) || !connectionParamsWrittenToErrorReport()
            || !configPropertiesWrittenToErrorReport()) {
      return;
    }
    boolean eligibleRecordFound;
    PersistentStoreConnection connectionForInvoiceProcessing=null;
    try {
      connectionForInvoiceProcessing = getConnectionForInvoiceProcessing(
          new ResourceManagerFactoryImpl());
      eligibleRecordFound = invoiceProcessingService.processInvoices(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportWriter, propertyList, getLastRunDataFileName(),
          connectionForInvoiceProcessing, getProductionDateFileName());
    } catch (ServiceException e) {
      performFailureActionForInvoiceProcessingError(e, summaryReportFileName, rejectionReportFileName, errorReportFileName);
      return;
    }
    finally{
      closeConnection(connectionForInvoiceProcessing);
    }
    if(!errorReportSavedAndClosed()) {
      return;
    }

    sendSuccessfulInvoiceProcessingNotificationEmail(eligibleRecordFound, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    updateLastRunDate();
    //TODO Verify This
  }

  private void closeConnection(PersistentStoreConnection connectionForInvoiceProcessing) {
    if(connectionForInvoiceProcessing!=null){
      try {
        connectionForInvoiceProcessing.close();
      } catch (WrappingException e) {
        e.printStackTrace();
      }
    }
  }

  private void sendSuccessfulInvoiceProcessingNotificationEmail(boolean eligibleRecordFound, String summaryReportFileName, String rejectionReportFileName, String errorReportFileName) {
    if(eligibleRecordFound) {
      sendSucessEmail(summaryReportFileName, rejectionReportFileName, errorReportFileName);
    } else {
      sendNoEligibleInvoicesFoundEmail(summaryReportFileName, rejectionReportFileName, errorReportFileName);
    }
  }

  private boolean errorReportSavedAndClosed() {
    try {
      errorReportWriter.writeErrorMessage(LMMSConstants.MSG_INVOICES_PROCESSED_NORMAL_PROGRAM_TERMINATION);
      errorReportWriter.saveAndClose();
      return true;
    } catch (ServiceException e) {
      return performProcessingErrorFailureAction("Fatal Error: Unable to save and close Error report writer. Error Message: " + e.getMessage(), e);
    }
  }

  private boolean readConfigProperties() {
    String propertyFileName = configDir + File.separator + LMMSConstants.FILE_NAME_PROPERTY_LIST_FILE;
    try {
      propertyList = propertyFileReader.readPropertyFile(propertyFileName);
      return true;
    } catch (ServiceException e) {
      return performProcessingErrorFailureAction("Fatal Error: Unable to read property file '" + propertyFileName + "'. Error Message: " + e.getMessage(), e);
    }
  }

  private boolean configPropertiesWrittenToErrorReport() {
    try {
      errorReportWriter.writeConfigProperties(propertyList);
      return true;
    } catch (ServiceException e) {
      return performProcessingErrorFailureAction("Fatal Error: Unable to write config properties to Error Report. Error Message: " + e.getMessage(), e);
    }
  }

  private boolean connectionParamsWrittenToErrorReport() {
    try {
      errorReportWriter.writeConnectionParams(new ConfigReaderXStreamImpl(LMMSConstants.XML_CONNECTION_EXTERNAL_CONFIG));
      return true;
    } catch (ServiceException e) {
      return performProcessingErrorFailureAction("Fatal Error: Unable to write connection parameters to Error Report. Error Message: " + e.getMessage(), e);
    }
  }

  private void updateLastRunDate() {
    try {
      lastRunInfoDAO.updateLastSuccessfulRunDate(getLastRunDataFileName());
    } catch (DAOException e) {
      performProcessingErrorFailureAction("Invoices processed, Email sent and RFBIBL FTP'd to SAP successfully, but exception occured while updating last run date: " + e.getMessage(), e);
    }
  }

  private String getLastRunDataFileName() {
    return lastRunInfoDir + File.separator + LMMSConstants.FILE_NAME_LAST_RUN_INFO_FILE;
  }

  private PersistentStoreConnection getConnectionForInvoiceProcessing(ResourceManagerFactory resourceManagerFactory) {
    try {
      ResourceConnectionManager connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
      return (PersistentStoreConnection) connectionManager.getConnection(LMMSConstants.DATABASE_LAW_TCE);
    } catch (ResourceConnectionException e) {
      return performFailureActionIfConnectionNotObtained(e);
    }
  }

  private PersistentStoreConnection performFailureActionIfConnectionNotObtained(ResourceConnectionException e) {
    String errorMessage = "Fatal Error: Unable to connect to " + LMMSConstants.DATASOURCE_TYPE_SQL_SERVER + " database " + LMMSConstants.DATABASE_LAW_TCE + " for " + System.getProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION) + " environment. Error Message: " + e.getMessage();
    logError(errorMessage, e);
    sendEmailToAdmin(errorMessage);
    throw new RuntimeException(errorMessage, e);
  }

  private boolean errorReportInitialized(String errorReportFileName) {
    try {
      errorReportWriter.initialize(errorReportFileName);
      return true;
    } catch (ServiceException e) {
      return performProcessingErrorFailureAction("Fatal Error: Error Report could not be initialized.", e);
    }
  }

  private boolean systemParamsSet() {
    try {
      getSystemParams();
      return true;
    } catch (Exception e) {
      return performProcessingErrorFailureAction("Fatal Error: Required System parameter, " + e.getMessage() + " not set on server.", e);
    }
  }

  private boolean performFailureActionForInvoiceProcessingError(ServiceException e, String summaryReportFileName, String rejectionReportFileName, String errorReportFileName) {
    String errorMessage = "Fatal Error occured while processing invoices: " + e.getMessage();
    logError(errorMessage, e);
    if (!writeToErrorReport(errorMessage)) {
      return false;
    }
    sendFailureEmail(summaryReportFileName, rejectionReportFileName, errorReportFileName);
    return false;
  }

  private boolean performProcessingErrorFailureAction(String errorMessage, Exception e) {
    logError(errorMessage, e);
    sendEmailToAdmin(errorMessage);
    return false;
  }

  private void logError(String errorMessage, Exception e) {
    Logger.log(new LoggableError(errorMessage));
    Logger.log(new LoggableError(e));
  }

  private void sendSucessEmail(String summaryReportFileName, String rejectionReportFileName, String errorReportFileName) {
    try {
      emailUtility.sendSuccessStatusEmail(LMMSConstants.FILE_NAME_INVOICE_RFBIBLE_FILE, getAttachmentList(summaryReportFileName, rejectionReportFileName, errorReportFileName));
    } catch (ServiceException e) {
      logError("Fatal Error: Exception occured while sending success notification Email.", e);
    }
  }

  private void sendNoEligibleInvoicesFoundEmail(String summaryReportFileName, String rejectionReportFileName, String errorReportFileName) {
    try {
      emailUtility.sendNoEligibleInvoicesFoundEmail(LMMSConstants.FILE_NAME_INVOICE_RFBIBLE_FILE, getAttachmentList(summaryReportFileName, rejectionReportFileName, errorReportFileName));
    } catch (ServiceException e) {
      logError("Fatal Error: Exception occured while sending no eligible invoices found notification Email.", e);
    }
  }

  private void sendFailureEmail(String summaryReportFileName, String rejectionReportFileName, String errorReportFileName) {
    try {
      emailUtility.sendFailureStatusEmail(getAttachmentList(summaryReportFileName, rejectionReportFileName, errorReportFileName));
    } catch (ServiceException e) {
      logError("Fatal Error: Exception occured while sending failure notification Email. Please look for some more fatal errors before this one too.", e);
    }
  }

  private void sendEmailToAdmin(String errorMessage) {
    try {
      emailUtility.sendEmailToAdmin(errorMessage);
    } catch (ServiceException e) {
      logError("Fatal Error: Exception occured while sending processing error email to Admin. Please look for some more errors before this one too.", e);
    }
  }

  private List getAttachmentList(String summaryReportFileName, String rejectionReportFileName, String errorReportFileName) {
    List attachmentList = new ArrayList();
    attachmentList.add(histroyDir + File.separator + summaryReportFileName);
    attachmentList.add(histroyDir + File.separator + rejectionReportFileName);
    attachmentList.add(histroyDir + File.separator + errorReportFileName);
    return attachmentList;
  }

  private boolean writeToErrorReport(String errorMessage) {
    try {
      errorReportWriter.writeErrorMessage(errorMessage);
      errorReportWriter.saveAndClose();
      return true;
    } catch (ServiceException e) {
      return performProcessingErrorFailureAction("Exception occured while writing following error message to ErrorReport Writer: '" + errorMessage + "'. The exception thrown by ErrorReport Writer is: " + e.getMessage(), e);
    }
  }

  private void getSystemParams() throws Exception {
    validateLSIFunctionSystemParam();
    getHistoryDirSystemParam();
    getConfigDirSystemParam();
    getLastRunInfoDirSystemParam();
  }

  private void getLastRunInfoDirSystemParam() throws Exception {
    lastRunInfoDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR);
    if (StringUtils.isNullOrEmpty(lastRunInfoDir)) {
      throw new Exception("Last Run Info directory '-D" + LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR + "'");
    }
  }

  private void getConfigDirSystemParam() throws Exception {
    configDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR);
    if (StringUtils.isNullOrEmpty(configDir)) {
      throw new Exception("Config directory '-D" + LMMSConstants.SYSTEM_PARAM_CONFIG_DIR + "'");
    }
  }

  private void getHistoryDirSystemParam() throws Exception {
    histroyDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
    if (StringUtils.isNullOrEmpty(histroyDir)) {
      throw new Exception("History directory '-D" + LMMSConstants.SYSTEM_PARAM_HISTORY_DIR + "'");
    }
  }

  private void validateLSIFunctionSystemParam() throws Exception {
    String lsiFunction = System.getProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION);
    if (StringUtils.isNullOrEmpty(lsiFunction)) {
      throw new Exception("Lsi Function '-D" + LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION + "'");
    }
  }

  public String getProductionDateFileName() {
    return lastRunInfoDir + File.separator + LMMSConstants.FILE_NAME_PRODUCTION_DATE_INFO_FILE;
  }
}