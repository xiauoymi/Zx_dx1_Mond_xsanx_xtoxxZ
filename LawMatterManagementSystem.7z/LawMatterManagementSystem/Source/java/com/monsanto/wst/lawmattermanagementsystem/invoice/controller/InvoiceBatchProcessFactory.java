/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.controller;

import com.monsanto.wst.lawmattermanagementsystem.exception.RuntimeFactoryException;


/**
 * Filename:    $RCSfile: InvoiceBatchProcessFactory.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-06 23:06:56 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public interface InvoiceBatchProcessFactory {

  InvoiceBatchProcessController getController() throws RuntimeFactoryException;
}