/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriterImpl;
import com.monsanto.wst.lawmattermanagementsystem.exception.RuntimeFactoryException;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPServiceImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.EmailDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.LastRunInfoDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.*;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.JavaMailEmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.MailDocumentFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.mail.util.dom.XMLEmailBuilderDOMImpl;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.PropertyFileReaderImpl;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactory;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.SAPValidationDAOFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationServiceImpl;
import com.monsanto.wst.lawmattermanagementsystem.servlet.LawMatterManagementSystemLoggerFactory;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateFactory;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationDAOImpl;
import com.monsanto.xmlserialization.XmlSerializerBuilder;

import java.io.File;

/**
 * Filename:    $RCSfile: InvoiceBatchProcessFactoryImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-09-09 15:46:28 $
 *
 * @author rdesai2
 * @version $Revision: 1.7 $
 */
public class InvoiceBatchProcessFactoryImpl implements InvoiceBatchProcessFactory {

  private ResourceManagerFactory resourceManagerFactory;
  private XMLTemplateFactory xmlTemplateFactory;
  private XmlSerializerBuilder xmlSerializerBuilder;
  private EmailUtility emailUtility;

  public InvoiceBatchProcessController getController() throws RuntimeFactoryException {
    setUpLogging();
    resourceManagerFactory = new ResourceManagerFactoryImpl();
    xmlTemplateFactory = new XMLTemplateFactoryImpl();
    xmlSerializerBuilder = new XmlSerializerBuilder();
    emailUtility = new EmailUtilityImpl(new JavaMailEmailService(new MailDocumentFactoryImpl(), new XMLEmailBuilderDOMImpl()), new EmailDAOImpl(getEmailXMLListFile(), xmlSerializerBuilder, LMMSConstants.ALIAS_EMAIL_LIST));
    return new InvoiceBatchProcessControllerImpl(
            getInvoiceProcessingService(),
            emailUtility,
            new ErrorReportWriterImpl(),
            new LastRunInfoDAOImpl(xmlSerializerBuilder),
            new PropertyFileReaderImpl(xmlSerializerBuilder));
  }

  private InvoiceProcessingService getInvoiceProcessingService() {
    return new InvoiceProcessingServiceImpl(
            new InvoiceDataDAOImpl(emailUtility, new AccountCodeVerificationDAOImpl(new ResourceManagerFactoryImpl())),
            new RecordValidationServiceImpl(getSAPVerificationService(resourceManagerFactory)),
            new InvoiceFileWriterImpl(xmlTemplateFactory),
            new SummaryReportWriterImpl(xmlTemplateFactory),
            new RejectionReportWriterImpl(xmlTemplateFactory),
            new SAPFTPUtilityImpl(new FTPServiceImpl(resourceManagerFactory)),
            new LastRunInfoDAOImpl(xmlSerializerBuilder),
            new InvoiceRecordProcessingServiceImpl(), new InvoiceAcknowledgementServiceImpl()); //TODO Pass appropriate Acknowledgement
  }

  private String getEmailXMLListFile() throws RuntimeFactoryException {
    String configDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR);
    if (StringUtils.isNullOrEmpty(configDir)) {
      String errorMessage = "Fatal Error: Required System parameter, Config directory '-D" + LMMSConstants.SYSTEM_PARAM_CONFIG_DIR + "' not set on server.";
      Logger.log(new LoggableError(errorMessage));
      throw new RuntimeFactoryException(errorMessage);
    }
    return configDir + File.separator + LMMSConstants.FILE_NAME_EMAIL_LIST_FILE;
  }

  public SAPVerificationServiceImpl getSAPVerificationService(ResourceManagerFactory resourceManagerFactory) throws RuntimeFactoryException {
    try {
      return new SAPVerificationServiceImpl(new SAPValidationDAOFactoryImpl(), resourceManagerFactory);
    } catch (ServiceException e) {
      Logger.log(new LoggableError(e));
      throw new RuntimeFactoryException("Error encountered while instantiating SAPVerificationServiceImpl: " + e.getMessage(), e);
    }
  }

  private void setUpLogging() {
    try {
      new LawMatterManagementSystemLoggerFactory().setupLogging();
    } catch (Exception e) {
      throw new RuntimeFactoryException("Logger could not be initialized. Please fix this error before proceeding: " + e.getMessage(), e);
    }
  }
}