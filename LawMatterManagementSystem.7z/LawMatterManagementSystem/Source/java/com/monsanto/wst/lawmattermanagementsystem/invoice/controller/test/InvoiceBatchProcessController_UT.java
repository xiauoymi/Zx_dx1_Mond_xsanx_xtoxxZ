/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.controller.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.mock.*;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.controller.InvoiceBatchProcessController;
import com.monsanto.wst.lawmattermanagementsystem.invoice.controller.InvoiceBatchProcessControllerImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockLastRunInfoDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockLastRunInfoDAOThrowsException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock.*;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.InvalidPropertyRequestException;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.mock.MockPropertyFileReaderReturnsRepostSpecificDateAsTrue;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.mock.MockPropertyFileReaderThrowsException;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.config.exception.ConfigurationException;

import java.io.File;
import java.io.IOException;

/**
 * Filename:    $RCSfile: InvoiceBatchProcessController_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-02-10 20:06:40 $
 *
 * @author rdesai2
 * @version $Revision: 1.26 $
 */
public class InvoiceBatchProcessController_UT extends LMMSBaseTestCase {

  private String invoiceFileName = LMMSConstants.FILE_NAME_INVOICE_RFBIBLE_FILE;
  private String summaryReportFileName = LMMSConstants.FILE_NAME_SUMMARY_REPORT_FILE;
  private String rejectionReportFileName = LMMSConstants.FILE_NAME_REJECTION_REPORT_FILE;
  private String errorReportFileName = LMMSConstants.FILE_NAME_ERROR_REPORT_FILE;

  private InvoiceBatchProcessController controller;
  private MockErrorReportWriter mockErrorReportWriter;
  private MockInvoiceProcessingService mockInvoiceProcessingService;
  private MockEmailUtility mockEmailUtility;
  private MockLastRunInfoDAO mockLastRunInfoUpdater;
  private MockPropertyFileReaderReturnsRepostSpecificDateAsTrue mockPropertyFileReaderReturnsRepostSpecificDateAsTrue;
  private String propertyFile;

  protected void setUp() throws IOException {
    super.setUp();
    propertyFile = System.getProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR) + File.separator + LMMSConstants.FILE_NAME_PROPERTY_LIST_FILE;
    mockErrorReportWriter = new MockErrorReportWriter();
    mockInvoiceProcessingService = new MockInvoiceProcessingService();
    mockEmailUtility = new MockEmailUtility();
    mockLastRunInfoUpdater = new MockLastRunInfoDAO();
    mockPropertyFileReaderReturnsRepostSpecificDateAsTrue = new MockPropertyFileReaderReturnsRepostSpecificDateAsTrue();
    controller = new InvoiceBatchProcessControllerImpl(
            mockInvoiceProcessingService,
            mockEmailUtility,
            mockErrorReportWriter,
            mockLastRunInfoUpdater,
            mockPropertyFileReaderReturnsRepostSpecificDateAsTrue);
  }

  public void testProcessInvoices_RequestCorrectPropertyFile_ToReadConfigProperties() throws Exception {
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertEquals(propertyFile, mockPropertyFileReaderReturnsRepostSpecificDateAsTrue.getFileNameForReadRequest());
  }

  public void testProcessInvoices_SendsProcessingErrorEmailToAdmin_IfPropertyFileReaderEncountersException() throws Exception {
    controller = new InvoiceBatchProcessControllerImpl(
            mockInvoiceProcessingService,
            mockEmailUtility,
            mockErrorReportWriter,
            mockLastRunInfoUpdater,
            new MockPropertyFileReaderThrowsException());
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Fatal Error: Unable to read property file '" + propertyFile + "'. Error Message: Mock exception by property file reader.", mockEmailUtility.getAdminMessage());
    validateNoAttachmentsSent();
    validateNothingWrittenToErrorReport();
  }

  public void testRunInvoiceBatchProcess_SendsProcessingErrorEmailToAdmin_IfLsiFunctionSystemParamNotSet() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, "");
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Fatal Error: Required System parameter, Lsi Function '-D" + LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION + "' not set on server.",
            mockEmailUtility.getAdminMessage());
    validateNoAttachmentsSent();
    validateNothingWrittenToErrorReport();
  }

  public void testRunInvoiceBatchProcess_SendsProcessingErrorEmailToAdmin_IfHistoryDirSystemParamNotSet() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, "");
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Fatal Error: Required System parameter, History directory '-D" + LMMSConstants.SYSTEM_PARAM_HISTORY_DIR + "' not set on server.",
            mockEmailUtility.getAdminMessage());
    validateNoAttachmentsSent();
    validateNothingWrittenToErrorReport();
  }

  public void testRunInvoiceBatchProcess_SendsProcessingErrorEmailToAdmin_IfConfigDirSystemParamNotSet() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR, "");
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Fatal Error: Required System parameter, Config directory '-D" + LMMSConstants.SYSTEM_PARAM_CONFIG_DIR + "' not set on server.",
            mockEmailUtility.getAdminMessage());
    validateNoAttachmentsSent();
    validateNothingWrittenToErrorReport();
  }

  public void testRunInvoiceBatchProcess_SendsProcessingErrorEmailToAdmin_IfLastRunDateDirSystemParamNotSet() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR, "");
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Fatal Error: Required System parameter, Last Run Info directory '-D" + LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR + "' not set on server.",
            mockEmailUtility.getAdminMessage());
    validateNoAttachmentsSent();
    validateNothingWrittenToErrorReport();
  }

  public void testRunInvoiceBatchProcess_InitializesErrorReport() throws Exception {
    assertFalse(mockErrorReportWriter.isInitialized());
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockErrorReportWriter.isInitialized());
  }

  public void testRunInvoiceBatchProcess_SendsProcessingErrorEmailToAdmin_IfErrorReportInitializationThrowsException() throws Exception {
    controller = new InvoiceBatchProcessControllerImpl(
            mockInvoiceProcessingService,
            mockEmailUtility,
            new MockErrorReportWriterThrowsException(),
            mockLastRunInfoUpdater, mockPropertyFileReaderReturnsRepostSpecificDateAsTrue);
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Fatal Error: Error Report could not be initialized.", mockEmailUtility.getAdminMessage());
    validateNoAttachmentsSent();
    validateNothingWrittenToErrorReport();
  }

  public void testRunInvoiceBatchProcess_WritesConnectionParamsToErrorReport() throws Exception {
    assertFalse(mockErrorReportWriter.isWriteConnectionParamsInvoked());
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockErrorReportWriter.isWriteConnectionParamsInvoked());
  }

  public void testRunInvoiceBatchProcess_SendsProcessingErrorEmailToAdmin_IfExceptionEncounteredWhileWritingConnectionParamsToErrorReport() throws Exception {
    controller = new InvoiceBatchProcessControllerImpl(
            mockInvoiceProcessingService,
            mockEmailUtility,
            new MockErrorReportWriterThrowsExceptionWhileWritingConnectionParams(),
            mockLastRunInfoUpdater, mockPropertyFileReaderReturnsRepostSpecificDateAsTrue);
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Fatal Error: Unable to write connection parameters to Error Report. Error Message: Mock exception while writing connection params.", mockEmailUtility.getAdminMessage());
    validateNoAttachmentsSent();
    validateNothingWrittenToErrorReport();
  }

  public void testRunInvoiceBatchProcess_WritesConfigPropertiesToErrorReport() throws Exception {
    assertFalse(mockErrorReportWriter.isWriteConfigProperties());
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockErrorReportWriter.isWriteConfigProperties());
    validatePropertyWrittenToErrorReport(LMMSConstants.PROPERTY_CONTACT_NAME);
    validatePropertyWrittenToErrorReport(LMMSConstants.PROPERTY_REPOST_DATE);
    validatePropertyWrittenToErrorReport(LMMSConstants.PROPERTY_REPOST_FOR_SPECIFIC_DATE);
    validatePropertyWrittenToErrorReport(LMMSConstants.PROPERTY_SKIP_FILE_FTP);
  }

  public void testRunInvoiceBatchProcess_SendsProcessingErrorEmailToAdmin_IfExceptionEncounteredWhileWritingConfigPropertiesToErrorReport() throws Exception {
    controller = new InvoiceBatchProcessControllerImpl(
            mockInvoiceProcessingService,
            mockEmailUtility,
            new MockErrorReportWriterThrowsExceptionWhileWritingConfigProperties(),
            mockLastRunInfoUpdater, mockPropertyFileReaderReturnsRepostSpecificDateAsTrue);
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Fatal Error: Unable to write config properties to Error Report. Error Message: Mock exception while writing config properties.", mockEmailUtility.getAdminMessage());
    validateNoAttachmentsSent();
    validateNothingWrittenToErrorReport();
  }

  public void testRunInvoiceBatchProcess_InvokesProcessInvoicesMethodOnInvoiceProcessingService() throws Exception {
    assertFalse(mockInvoiceProcessingService.isProcessInvoicesInvoked());
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockInvoiceProcessingService.isProcessInvoicesInvoked());
  }

  public void testProcessInvoices_SendsPropertyList_ToInvoiceProcessor() throws Exception {
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    validatePropertySentToInvoiceProcessor(LMMSConstants.PROPERTY_CONTACT_NAME);
    validatePropertySentToInvoiceProcessor(LMMSConstants.PROPERTY_REPOST_DATE);
    validatePropertySentToInvoiceProcessor(LMMSConstants.PROPERTY_REPOST_FOR_SPECIFIC_DATE);
    validatePropertySentToInvoiceProcessor(LMMSConstants.PROPERTY_SKIP_FILE_FTP);
  }

  public void testRunInvoiceBatchProcess_SendsEmailToAdmin_And_ThrowsRuntimeException_IfConnectionForInvoiceProcessingNotObtained() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, "Invalid-Lsi_function");
    try {
      controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
      fail("Required exception not thrown.");
    } catch (RuntimeException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Fatal Error: Unable to connect to sqlserver database LAW_TCE for Invalid-Lsi_function environment. Error Message: Error retrieving connection parameters for SQL Server database: 'LAW_TCE'.", mockEmailUtility.getAdminMessage());
    validateNoAttachmentsSent();
  }

  public void testRunInvoiceBatchProcess_EmailsFailureMessage_IfInvoiceProcessingServiceFails() throws Exception {
    controller = new InvoiceBatchProcessControllerImpl(
            new MockInvoiceProcessingServiceThrowsException(),
            mockEmailUtility,
            mockErrorReportWriter,
            mockLastRunInfoUpdater, mockPropertyFileReaderReturnsRepostSpecificDateAsTrue);
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendFailureStatusEmailInvoked());
    validateAttachmentsSent();
    assertTrue(mockErrorReportWriter.getLastRequestedErrorMessage().indexOf("Fatal Error occured while processing invoices: ") != -1);
    assertTrue(mockErrorReportWriter.saveAndCloseInvoked());
  }

  public void testRunInvoiceBatchProcess_SendsProcessingErrorEmailToAdmin_IfExceptionEncounteredWhileWritingInvoiceExceptionToErrorReport() throws Exception {
    controller = new InvoiceBatchProcessControllerImpl(
            new MockInvoiceProcessingServiceThrowsException(),
            mockEmailUtility,
            new MockErrorReportWriterThrowsExceptionOnWrite(),
            mockLastRunInfoUpdater, mockPropertyFileReaderReturnsRepostSpecificDateAsTrue);
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Exception occured while writing following error message to ErrorReport Writer: 'Fatal Error occured while processing invoices: Mock process invoices error...'. The exception thrown by ErrorReport Writer is: Mock Error Report Exception during writeErrorMessage...",
            mockEmailUtility.getAdminMessage());
    validateNoAttachmentsSent();
    validateNothingWrittenToErrorReport();
  }

  public void testRunInvoiceBatchProcess_SavesAndClosesErrorReport() throws Exception {
    assertFalse(mockErrorReportWriter.saveAndCloseInvoked());
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertEquals(LMMSConstants.MSG_INVOICES_PROCESSED_NORMAL_PROGRAM_TERMINATION, mockErrorReportWriter.getLastRequestedErrorMessage());
    assertTrue(mockErrorReportWriter.saveAndCloseInvoked());
  }

  public void testRunInvoiceBatchProcess_SendsProcessingErrorEmailToAdmin_IfErrorReportThrowsExceptionDuringSaveAndClose() throws Exception {
    controller = new InvoiceBatchProcessControllerImpl(
            mockInvoiceProcessingService,
            mockEmailUtility,
            new MockErrorReportWriterThrowsExceptionOnSaveAndClose(),
            mockLastRunInfoUpdater, mockPropertyFileReaderReturnsRepostSpecificDateAsTrue);
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Fatal Error: Unable to save and close Error report writer. Error Message: Mock error during save and close error report writer.", mockEmailUtility.getAdminMessage());
    validateNoAttachmentsSent();
    validateNothingWrittenToErrorReport();
  }

  public void testRunInvoiceBatchProcess_EmailsSuccessMessage_IfInvoiceProcessingServiceSucceeds() throws Exception {
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendSuccessStatusEmailInvoked());
    validateAttachmentsSent();
  }

  public void testRunInvoiceBatchProcess_EmailsNoEligibleInvoicesFoundMessage_IfInvoicesFoundOrAllGetRejected() throws Exception {
    controller = new InvoiceBatchProcessControllerImpl(
            new MockInvoiceProcessingServiceReturnsFalse(),
            mockEmailUtility,
            mockErrorReportWriter,
            mockLastRunInfoUpdater,
            mockPropertyFileReaderReturnsRepostSpecificDateAsTrue);
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendNoEligibleInvoicesEmailInvoked());
    validateAttachmentsSent();
  }

  public void testRunInvoiceBatchProcess_UpdatesLastRunDate_IfInvoiceProcessingServiceSucceeds() throws Exception {
    assertFalse(mockLastRunInfoUpdater.isInvoked());
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockLastRunInfoUpdater.isInvoked());
  }

  public void testRunInvoiceBatchProcess_EmailsProcessingErrorMessageToAdmin_IfUpdateLastRunDateFails() throws Exception {
    controller = new InvoiceBatchProcessControllerImpl(
            mockInvoiceProcessingService,
            mockEmailUtility,
            mockErrorReportWriter,
            new MockLastRunInfoDAOThrowsException(), mockPropertyFileReaderReturnsRepostSpecificDateAsTrue);
    controller.runInvoiceBatchProcess(invoiceFileName, summaryReportFileName, rejectionReportFileName, errorReportFileName);
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Invoices processed, Email sent and RFBIBL FTP'd to SAP successfully, " +
            "but exception occured while updating last run date: Mock Exception while updating last run date",
            mockEmailUtility.getAdminMessage());
    validateNoAttachmentsSent();
    validateNothingWrittenToErrorReportSpecificToThisErrorAfterNormalProgramTerminationMessage();
  }

  private void validateAttachmentsSent() {
    assertTrue(((String) mockEmailUtility.getAttachmentList().get(0)).indexOf("Summ_Rep") != -1);
    assertTrue(((String) mockEmailUtility.getAttachmentList().get(1)).indexOf("Rej_Rep") != -1);
    assertTrue(((String) mockEmailUtility.getAttachmentList().get(2)).indexOf("Err_Rep") != -1);
  }

  private void validateNothingWrittenToErrorReportSpecificToThisErrorAfterNormalProgramTerminationMessage() {
    assertEquals(LMMSConstants.MSG_INVOICES_PROCESSED_NORMAL_PROGRAM_TERMINATION, mockErrorReportWriter.getLastRequestedErrorMessage());
  }

  private void validateNothingWrittenToErrorReport() {
    assertEquals("", mockErrorReportWriter.getLastRequestedErrorMessage());
  }

  private void validateNoAttachmentsSent() {
    assertEquals(0, mockEmailUtility.getAttachmentList().size());
  }

  private void validatePropertyWrittenToErrorReport(String propertyName) throws InvalidPropertyRequestException, ServiceException, ConfigurationException {
    assertEquals(mockErrorReportWriter.getPropertyList().getPropertyValue(propertyName),
            mockPropertyFileReaderReturnsRepostSpecificDateAsTrue.readPropertyFile(null).getPropertyValue(propertyName));
  }

  private void validatePropertySentToInvoiceProcessor(String propertyName) throws InvalidPropertyRequestException, ServiceException, ConfigurationException {
    assertEquals(mockInvoiceProcessingService.getPropertyList().getPropertyValue(propertyName),
            mockPropertyFileReaderReturnsRepostSpecificDateAsTrue.readPropertyFile(null).getPropertyValue(propertyName));
  }
}