/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.EmailInfo;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.EmailList;
import com.monsanto.xmlserialization.DeserializationException;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerBuilder;

import java.util.List;

/**
 * Filename:    $RCSfile: EmailDAOImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-09-09 15:46:28 $
 *
 * @author rdesai2
 * @version $Revision: 1.7 $
 */
public class EmailDAOImpl implements EmailDAO {

  private EmailList emailList;
  private XmlSerializer serializer;
  private String emailListXML;

  public EmailDAOImpl(String emailListXML, XmlSerializerBuilder xmlSerializerBuilder, String aliasEmailList) {
    this.emailListXML = emailListXML;
    initializeSerializer(xmlSerializerBuilder, aliasEmailList);
  }

  public List getTOList() throws DAOException {
    readEmailList();
    return emailList.getToList();
  }

  public List getCCList() throws DAOException {
    readEmailList();
    return emailList.getCCList();
  }

  public List getAdminList() throws DAOException {
    readEmailList();
    return emailList.getAdminList();
  }

  private void readEmailList() throws DAOException {
    try {
      emailList = (EmailList) serializer.fromDocument(DOMUtil.newDocument(emailListXML));
    } catch (DeserializationException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while deserializing the XML containing email list '" + emailListXML + "' : " + e.getMessage(), e);
    } catch (ParserException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while parsing the XML containing email list '" + emailListXML + "' : " + e.getMessage(), e);
    } catch (Exception e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while reading the XML containing email list '" + emailListXML + "'. " + e.getClass() + " : " + e.getMessage(), e);
    }
  }

  private void initializeSerializer(XmlSerializerBuilder builder, String aliasEmailList) {
    builder.registerMapping("", aliasEmailList, EmailList.class);
    builder.registerMapping("", LMMSConstants.ALIAS_EMAIL_INFO, EmailInfo.class);
    serializer = builder.createSerializer();
  }
}