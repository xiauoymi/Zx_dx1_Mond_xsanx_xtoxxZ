/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao;

import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.dataservices.PersistentStoreConnection;

import java.util.List;
import java.util.Date;

/**
 * Filename:    $RCSfile: InvoiceDataDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-12-22 15:04:10 $
 *
 * @author rdesai2
 * @version $Revision: 1.10 $
 */
public interface InvoiceDataDAO {

  /**
   * Gets Invoice Data
   * @param isRepostForSpecificDateRequired: If true, only invoices for specific "sendAPDate" [Repost Date] will be returned
   *                                         If false, all invoices after "sendAPDate" [Last Run Date] will be returned
   * @param sendAPDate - could be "repost date" if isRepostForSpecificDateRequired = true
   *                 - could be "last run date" if isRepostForSpecificDateRequired = false
   * @param connection - PersistentStoreConnection
   * @param productionDate
   * @return List - Of InvoiceRecord [com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord]
   * @throws DAOException - If problem occurs while getting data
   */
  public List getInvoiceRecords(boolean isRepostForSpecificDateRequired, Date sendAPDate, PersistentStoreConnection connection, Date productionDate) throws DAOException;

  List getInvoiceRecordsForInvoiceNumber(String invoiceNumber, PersistentStoreConnection connection) throws DAOException;
}