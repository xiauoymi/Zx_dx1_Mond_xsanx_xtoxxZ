/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.*;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationDAO;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.*;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.EmailUtility;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Filename:    $RCSfile: InvoiceDataDAOImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-02-20 17:28:44 $
 *
 * @author rdesai2
 * @version $Revision: 1.37 $
 */
public class InvoiceDataDAOImpl implements InvoiceDataDAO {

  /**
   * -- 1.  THESE QUERIES EXTRACT INVOICES FOR THE TC-SAP INVOICE PROCESSING
   --     IT HAS TWO PARTS. THE FIRST EXTRACTS LITIGATION INVOICES FOLLOWED BY
   --     NON LITIGATTON INVOICES
   -- 2.  DATE SENT TO SAP MUST BE OVERLAYED/UPDATED IN TWO PLACES MARKED BY THE
   --         SET SEND SEND TO SAP DATE   STRING
   -- 3.  VENDOR_TYPE IS BEING HARDCODED AS  LAW
   -- mld - 2007-03-06
   */
  public static final String SQL_QUERY_INVOICE_DATA_FOR_SPECIFIC_SEND_AP_DATE =
      "SELECT DISTINCT \n" +
          "PMNT.INVOICE_ID AS INVOICE_ID,\n" +
          "T_INVOICE.INVOICE_DATE AS INVOICE_DATE,\n" +
          "PMNT.InSeqNo as SEQUENCE_NUMBER,\n" +
          "PMNT.InDueDate AS Due_Date, \n" +
          "PMNT.InCurrencyStr AS CURRENCY_CODE, \n" +
          "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
          "PMNT.InTransID AS TRAN_ID, \n" +
          "PMNT.InInvoiceAmount AS AMOUNT_VC, \n" +
          "tc.NUMBER_STRING AS VENDOR_ID,\n" +
          "PMNT.InLPCONV_EMPL_ID_APPROVE_NAME AS EMPL_ID_APPROVE, \n" +
          "'LAW' AS VENDOR_TYPE,\n" +
          "CONT_CAT_57.CoSAPVendorID AS SAP_VENDOR_ID, \n" +
          "tc.NAME_UPPER AS VENDOR_NAME,\n" +
          "--ALLOCATION 1 \n" +
          "PMNT.InAllocAmt AS ALLOCATION_PAY_LC, \n" +
          "PMNT.InCostElement AS COST_ELEMENT, \n" +
          "PMNT.InSAPLinkno AS SAPLINKNO, \n" +
          "PMNT.InAllocPct AS ALLOCATION_PCT, \n" +
          "PMNT.InCostCenter AS SUBACCOUNT, \n" +
          "PMNT.InInternalOrderNumber AS INTERNAL_ORDER_NUMBER, \n" +
          "PMNT.InProfitCenter AS PROFIT_CENTER,\n" +
          "--ALLOCATION 2 \n" +
          "PMNT.InAllocAmt2 AS ALLOCATION_PAY_LC2, \n" +
          "PMNT.InCostElement2 AS COST_ELEMENT2, \n" +
          "PMNT.InSAPLinkno2 AS SAPLINKNO2, \n" +
          "PMNT.InAllocPct2 AS ALLOCATION_PCT2, \n" +
          "PMNT.InCostCenter2 AS SUBACCOUNT2, \n" +
          "PMNT.InInternalOrderNumber2 AS INTERNAL_ORDER_NUMBER2, \n" +
          "PMNT.InProfitCenter2 AS PROFIT_CENTER2,\n" +
          "--ALLOCATION 3 \n" +
          "PMNT.InAllocAmt3 AS ALLOCATION_PAY_LC3, \n" +
          "PMNT.InCostElement3 AS COST_ELEMENT3, \n" +
          "PMNT.InSAPLinkno3 AS SAPLINKNO3, \n" +
          "PMNT.InAllocPct3 AS ALLOCATION_PCT3, \n" +
          "PMNT.InCostCenter3 AS SUBACCOUNT3, \n" +
          "PMNT.InInternalOrderNumber3 AS INTERNAL_ORDER_NUMBER3, \n" +
          "PMNT.InProfitCenter3 AS PROFIT_CENTER3,\n" +
          "--ALLOCATION 4 \n" +
          "PMNT.InAllocAmt4 AS ALLOCATION_PAY_LC4, \n" +
          "PMNT.InCostElement4 AS COST_ELEMENT4, \n" +
          "PMNT.InSAPLinkno4 AS SAPLINKNO4, \n" +
          "PMNT.InAllocPct4 AS ALLOCATION_PCT4, \n" +
          "PMNT.InCostCenter4 AS SUBACCOUNT4, \n" +
          "PMNT.InInternalOrderNumber4 AS INTERNAL_ORDER_NUMBER4, \n" +
          "PMNT.InProfitCenter4 AS PROFIT_CENTER4,\n" +
          "--ALLOCATION 5 \n" +
          "PMNT.InAllocAmt5 AS ALLOCATION_PAY_LC5, \n" +
          "PMNT.InCostElement5 AS COST_ELEMENT5, \n" +
          "PMNT.InSAPLinkno5 AS SAPLINKNO5, \n" +
          "PMNT.InAllocPct5 AS ALLOCATION_PCT5, \n" +
          "PMNT.InCostCenter5 AS SUBACCOUNT5, \n" +
          "PMNT.InInternalOrderNumber5 AS INTERNAL_ORDER_NUMBER5, \n" +
          "PMNT.InProfitCenter5 AS PROFIT_CENTER5, \n" +
          "--ALLOCATION 6\n" +
          "PMNT.InAllocAmt6 AS ALLOCATION_PAY_LC6, \n" +
          "PMNT.InCostElement6 AS COST_ELEMENT6, \n" +
          "PMNT.InSAPLinkno6 AS SAPLINKNO6, \n" +
          "PMNT.InAllocPct6 AS ALLOCATION_PCT6, \n" +
          "PMNT.InCostCenter6 AS SUBACCOUNT6, \n" +
          "PMNT.InInternalOrderNumber6 AS INTERNAL_ORDER_NUMBER6, \n" +
          "PMNT.InProfitCenter6 AS PROFIT_CENTER6, \n" +
          "--ALLOCATION 7\n" +
          "PMNT.InAllocAmt7 AS ALLOCATION_PAY_LC7, \n" +
          "PMNT.InCostElement7 AS COST_ELEMENT7, \n" +
          "PMNT.InAllocPct7 AS ALLOCATION_PCT7, \n" +
          "PMNT.InCostCenter7 AS SUBACCOUNT7, \n" +
          "PMNT.InInternalOrderNumber7 AS INTERNAL_ORDER_NUMBER7, \n" +
          "PMNT.InProfitCenter7 AS PROFIT_CENTER7,\n" +
          "--ALLOCATION 8 \n" +
          "PMNT.InAllocAmt8 AS ALLOCATION_PAY_LC8, \n" +
          "PMNT.InCostElement8 AS COST_ELEMENT8, \n" +
          "PMNT.InSAPLinkno8 AS SAPLINKNO8, \n" +
          "PMNT.InAllocPct8 AS ALLOCATION_PCT8, \n" +
          "PMNT.InCostCenter8 AS SUBACCOUNT8, \n" +
          "PMNT.InInternalOrderNumber8 AS INTERNAL_ORDER_NUMBER8, \n" +
          "PMNT.InProfitCenter8 AS PROFIT_CENTER8, \n" +
          "--ALLOCATION 9\n" +
          "PMNT.InAllocAmt9 AS ALLOCATION_PAY_LC9, \n" +
          "PMNT.InCostElement9 AS COST_ELEMENT9, \n" +
          "PMNT.InSAPLinkno9 AS SAPLINKNO9, \n" +
          "PMNT.InAllocPct9 AS ALLOCATION_PCT9, \n" +
          "PMNT.InCostCenter9 AS SUBACCOUNT9, \n" +
          "PMNT.InInternalOrderNumber9 AS INTERNAL_ORDER_NUMBER9, \n" +
          "PMNT.InProfitCenter9 AS PROFIT_CENTER9, \n" +
          "--ALLOCATION 10\n" +
          "PMNT.InAllocAmt10 AS ALLOCATION_PAY_LC10, \n" +
          "PMNT.InCostElement10 AS COST_ELEMENT10, \n" +
          "PMNT.InSAPLinkno10 AS SAPLINKNO10, \n" +
          "PMNT.InAllocPct10 AS ALLOCATION_PCT10, \n" +
          "PMNT.InCostCenter10 AS SUBACCOUNT10, \n" +
          "PMNT.InInternalOrderNumber10 AS INTERNAL_ORDER_NUMBER10, \n" +
          "PMNT.InProfitCenter10 AS PROFIT_CENTER10, \n" +
          "--ALLOCATION 11\n" +
          "PMNT.InAllocAmt11 AS ALLOCATION_PAY_LC11, \n" +
          "PMNT.InCostElement11 AS COST_ELEMENT11, \n" +
          "PMNT.InSAPLinkno11 AS SAPLINKNO11, \n" +
          "PMNT.InAllocPct11 AS ALLOCATION_PCT11, \n" +
          "PMNT.InCostCenter11 AS SUBACCOUNT11, \n" +
          "PMNT.InInternalOrderNumber11 AS INTERNAL_ORDER_NUMBER11, \n" +
          "PMNT.InProfitCenter11 AS PROFIT_CENTER11,\n" +
          "--ALLOCATION 12\n" +
          "PMNT.InAllocAmt12 AS ALLOCATION_PAY_LC12, \n" +
          "PMNT.InCostElement12 AS COST_ELEMENT12, \n" +
          "PMNT.InSAPLinkno12 AS SAPLINKNO12, \n" +
          "PMNT.InAllocPct12 AS ALLOCATION_PCT12, \n" +
          "PMNT.InCostCenter12 AS SUBACCOUNT12, \n" +
          "PMNT.InInternalOrderNumber12 AS INTERNAL_ORDER_NUMBER12, \n" +
          "PMNT.InProfitCenter12 AS PROFIT_CENTER12, \n" +
          "--ALLOCATION 13\n" +
          "PMNT.InAllocAmt13 AS ALLOCATION_PAY_LC13, \n" +
          "PMNT.InCostElement13 AS COST_ELEMENT13, \n" +
          "PMNT.InSAPLinkno13 AS SAPLINKNO13, \n" +
          "PMNT.InAllocPct13 AS ALLOCATION_PCT13, \n" +
          "PMNT.InCostCenter13 AS SUBACCOUNT13, \n" +
          "PMNT.InInternalOrderNumber13 AS INTERNAL_ORDER_NUMBER13, \n" +
          "PMNT.InProfitCenter13 AS PROFIT_CENTER13, \n" +
          "tp.NUMBER_STRING AS MATTER_ID, \n" +
          "tp.NAME AS MATTER_NAME, \n" +
          "tp.CLOSED_ON AS MATTER_CLOSE_DATE, \n" +
          "PMNT.InSendAPDate, \n" +
          "PMNT.InPostDate, \n" +
          "tp.PARENT_ID, \n" +
          "tp.PRIMARY_KEY, \n" +
          "Y_OBJ_CATEGORY.NAME AS Practice_Area, \n" +
          "tp.MtLiGrGroup AS Group_Reference\n" +
          "FROM         \n" +
          "INVC_CAT_12 PMNT,\n" +
          "J_INVC_LINE_ITEM J,\n" +
          "T_INVOICE ,\n" +
          "(   SELECT * \n" +
          "    FROM T_PROJECT left outer join PROJ_CAT_1330 on proj_cat_1330.project_id = t_project.primary_key\n" +
          ") tp,\n" +
          "T_CONTACT tc,\n" +
          "CONT_CAT_57,\n" +
          "Y_OBJ_CATEGORY\n" +
          "where PMNT.INVOICE_ID = T_INVOICE.PRIMARY_KEY\n" +
          "      and J.INVOICE_ID = T_INVOICE.PRIMARY_KEY\n" +
          "      and j.project_id = TP.primary_key\n" +
          "      and tc.primary_key = t_invoice.vendor_id\n" +
          "      AND CONT_CAT_57.CONTACT_ID = TC.PRIMARY_KEY\n" +
          "      AND Y_OBJ_CATEGORY.PRIMARY_KEY = TP.DEFAULT_CATEGORY_ID\n" +
          "     AND (?= CONVERT(varchar, PMNT.InSendAPDate, 101))\n"+
          "     AND PMNT.InPayInvoice='Yes'\n"+
          "      AND PMNT.InStatus='Posted'\n"+
          "     order by tc.NAME_UPPER,PMNT.InInvoiceNumber ";

  public static final String SQL_QUERY_INVOICE_DATA_SINCE_LAST_RUN_DATE =
      "SELECT DISTINCT \n" +
          "PMNT.INVOICE_ID AS INVOICE_ID,\n" +
          "T_INVOICE.INVOICE_DATE AS INVOICE_DATE,\n" +
          "PMNT.InSeqNo as SEQUENCE_NUMBER,\n" +
          "PMNT.InDueDate AS Due_Date, \n" +
          "PMNT.InCurrencyStr AS CURRENCY_CODE, \n" +
          "PMNT.InInvoiceNumber AS INVOICE_NUMBER, \n" +
          "PMNT.InTransID AS TRAN_ID, \n" +
          "PMNT.InInvoiceAmount AS AMOUNT_VC, \n" +
          "tc.NUMBER_STRING AS VENDOR_ID,\n" +
          "PMNT.InLPCONV_EMPL_ID_APPROVE_NAME AS EMPL_ID_APPROVE, \n" +
          "'LAW' AS VENDOR_TYPE,\n" +
          "CONT_CAT_57.CoSAPVendorID AS SAP_VENDOR_ID, \n" +
          "tc.NAME_UPPER AS VENDOR_NAME,\n" +
          "--ALLOCATION 1 \n" +
          "PMNT.InAllocAmt AS ALLOCATION_PAY_LC, \n" +
          "PMNT.InCostElement AS COST_ELEMENT, \n" +
          "PMNT.InSAPLinkno AS SAPLINKNO, \n" +
          "PMNT.InAllocPct AS ALLOCATION_PCT, \n" +
          "PMNT.InCostCenter AS SUBACCOUNT, \n" +
          "PMNT.InInternalOrderNumber AS INTERNAL_ORDER_NUMBER, \n" +
          "PMNT.InProfitCenter AS PROFIT_CENTER,\n" +
          "--ALLOCATION 2 \n" +
          "PMNT.InAllocAmt2 AS ALLOCATION_PAY_LC2, \n" +
          "PMNT.InCostElement2 AS COST_ELEMENT2, \n" +
          "PMNT.InSAPLinkno2 AS SAPLINKNO2, \n" +
          "PMNT.InAllocPct2 AS ALLOCATION_PCT2, \n" +
          "PMNT.InCostCenter2 AS SUBACCOUNT2, \n" +
          "PMNT.InInternalOrderNumber2 AS INTERNAL_ORDER_NUMBER2, \n" +
          "PMNT.InProfitCenter2 AS PROFIT_CENTER2,\n" +
          "--ALLOCATION 3 \n" +
          "PMNT.InAllocAmt3 AS ALLOCATION_PAY_LC3, \n" +
          "PMNT.InCostElement3 AS COST_ELEMENT3, \n" +
          "PMNT.InSAPLinkno3 AS SAPLINKNO3, \n" +
          "PMNT.InAllocPct3 AS ALLOCATION_PCT3, \n" +
          "PMNT.InCostCenter3 AS SUBACCOUNT3, \n" +
          "PMNT.InInternalOrderNumber3 AS INTERNAL_ORDER_NUMBER3, \n" +
          "PMNT.InProfitCenter3 AS PROFIT_CENTER3,\n" +
          "--ALLOCATION 4 \n" +
          "PMNT.InAllocAmt4 AS ALLOCATION_PAY_LC4, \n" +
          "PMNT.InCostElement4 AS COST_ELEMENT4, \n" +
          "PMNT.InSAPLinkno4 AS SAPLINKNO4, \n" +
          "PMNT.InAllocPct4 AS ALLOCATION_PCT4, \n" +
          "PMNT.InCostCenter4 AS SUBACCOUNT4, \n" +
          "PMNT.InInternalOrderNumber4 AS INTERNAL_ORDER_NUMBER4, \n" +
          "PMNT.InProfitCenter4 AS PROFIT_CENTER4,\n" +
          "--ALLOCATION 5 \n" +
          "PMNT.InAllocAmt5 AS ALLOCATION_PAY_LC5, \n" +
          "PMNT.InCostElement5 AS COST_ELEMENT5, \n" +
          "PMNT.InSAPLinkno5 AS SAPLINKNO5, \n" +
          "PMNT.InAllocPct5 AS ALLOCATION_PCT5, \n" +
          "PMNT.InCostCenter5 AS SUBACCOUNT5, \n" +
          "PMNT.InInternalOrderNumber5 AS INTERNAL_ORDER_NUMBER5, \n" +
          "PMNT.InProfitCenter5 AS PROFIT_CENTER5, \n" +
          "--ALLOCATION 6\n" +
          "PMNT.InAllocAmt6 AS ALLOCATION_PAY_LC6, \n" +
          "PMNT.InCostElement6 AS COST_ELEMENT6, \n" +
          "PMNT.InSAPLinkno6 AS SAPLINKNO6, \n" +
          "PMNT.InAllocPct6 AS ALLOCATION_PCT6, \n" +
          "PMNT.InCostCenter6 AS SUBACCOUNT6, \n" +
          "PMNT.InInternalOrderNumber6 AS INTERNAL_ORDER_NUMBER6, \n" +
          "PMNT.InProfitCenter6 AS PROFIT_CENTER6, \n" +
          "--ALLOCATION 7\n" +
          "PMNT.InAllocAmt7 AS ALLOCATION_PAY_LC7, \n" +
          "PMNT.InCostElement7 AS COST_ELEMENT7, \n" +
          "PMNT.InAllocPct7 AS ALLOCATION_PCT7, \n" +
          "PMNT.InCostCenter7 AS SUBACCOUNT7, \n" +
          "PMNT.InInternalOrderNumber7 AS INTERNAL_ORDER_NUMBER7, \n" +
          "PMNT.InProfitCenter7 AS PROFIT_CENTER7,\n" +
          "--ALLOCATION 8 \n" +
          "PMNT.InAllocAmt8 AS ALLOCATION_PAY_LC8, \n" +
          "PMNT.InCostElement8 AS COST_ELEMENT8, \n" +
          "PMNT.InSAPLinkno8 AS SAPLINKNO8, \n" +
          "PMNT.InAllocPct8 AS ALLOCATION_PCT8, \n" +
          "PMNT.InCostCenter8 AS SUBACCOUNT8, \n" +
          "PMNT.InInternalOrderNumber8 AS INTERNAL_ORDER_NUMBER8, \n" +
          "PMNT.InProfitCenter8 AS PROFIT_CENTER8, \n" +
          "--ALLOCATION 9\n" +
          "PMNT.InAllocAmt9 AS ALLOCATION_PAY_LC9, \n" +
          "PMNT.InCostElement9 AS COST_ELEMENT9, \n" +
          "PMNT.InSAPLinkno9 AS SAPLINKNO9, \n" +
          "PMNT.InAllocPct9 AS ALLOCATION_PCT9, \n" +
          "PMNT.InCostCenter9 AS SUBACCOUNT9, \n" +
          "PMNT.InInternalOrderNumber9 AS INTERNAL_ORDER_NUMBER9, \n" +
          "PMNT.InProfitCenter9 AS PROFIT_CENTER9, \n" +
          "--ALLOCATION 10\n" +
          "PMNT.InAllocAmt10 AS ALLOCATION_PAY_LC10, \n" +
          "PMNT.InCostElement10 AS COST_ELEMENT10, \n" +
          "PMNT.InSAPLinkno10 AS SAPLINKNO10, \n" +
          "PMNT.InAllocPct10 AS ALLOCATION_PCT10, \n" +
          "PMNT.InCostCenter10 AS SUBACCOUNT10, \n" +
          "PMNT.InInternalOrderNumber10 AS INTERNAL_ORDER_NUMBER10, \n" +
          "PMNT.InProfitCenter10 AS PROFIT_CENTER10, \n" +
          "--ALLOCATION 11\n" +
          "PMNT.InAllocAmt11 AS ALLOCATION_PAY_LC11, \n" +
          "PMNT.InCostElement11 AS COST_ELEMENT11, \n" +
          "PMNT.InSAPLinkno11 AS SAPLINKNO11, \n" +
          "PMNT.InAllocPct11 AS ALLOCATION_PCT11, \n" +
          "PMNT.InCostCenter11 AS SUBACCOUNT11, \n" +
          "PMNT.InInternalOrderNumber11 AS INTERNAL_ORDER_NUMBER11, \n" +
          "PMNT.InProfitCenter11 AS PROFIT_CENTER11,\n" +
          "--ALLOCATION 12\n" +
          "PMNT.InAllocAmt12 AS ALLOCATION_PAY_LC12, \n" +
          "PMNT.InCostElement12 AS COST_ELEMENT12, \n" +
          "PMNT.InSAPLinkno12 AS SAPLINKNO12, \n" +
          "PMNT.InAllocPct12 AS ALLOCATION_PCT12, \n" +
          "PMNT.InCostCenter12 AS SUBACCOUNT12, \n" +
          "PMNT.InInternalOrderNumber12 AS INTERNAL_ORDER_NUMBER12, \n" +
          "PMNT.InProfitCenter12 AS PROFIT_CENTER12, \n" +
          "--ALLOCATION 13\n" +
          "PMNT.InAllocAmt13 AS ALLOCATION_PAY_LC13, \n" +
          "PMNT.InCostElement13 AS COST_ELEMENT13, \n" +
          "PMNT.InSAPLinkno13 AS SAPLINKNO13, \n" +
          "PMNT.InAllocPct13 AS ALLOCATION_PCT13, \n" +
          "PMNT.InCostCenter13 AS SUBACCOUNT13, \n" +
          "PMNT.InInternalOrderNumber13 AS INTERNAL_ORDER_NUMBER13, \n" +
          "PMNT.InProfitCenter13 AS PROFIT_CENTER13, \n" +
          "tp.NUMBER_STRING AS MATTER_ID, \n" +
          "tp.NAME AS MATTER_NAME, \n" +
          "tp.CLOSED_ON AS MATTER_CLOSE_DATE, \n" +
          "PMNT.InSendAPDate, \n" +
          "PMNT.InPostDate, \n" +
          "tp.PARENT_ID, \n" +
          "tp.PRIMARY_KEY, \n" +
          "Y_OBJ_CATEGORY.NAME AS Practice_Area, \n" +
          "tp.MtLiGrGroup AS Group_Reference\n" +
          "FROM         \n" +
          "INVC_CAT_12 PMNT,\n" +
          "J_INVC_LINE_ITEM J,\n" +
          "T_INVOICE ,\n" +
          "(   SELECT * \n" +
          "    FROM T_PROJECT left outer join PROJ_CAT_1330 on proj_cat_1330.project_id = t_project.primary_key\n" +
          ") tp,\n" +
          "T_CONTACT tc,\n" +
          "CONT_CAT_57,\n" +
          "Y_OBJ_CATEGORY\n" +
          "where PMNT.INVOICE_ID = T_INVOICE.PRIMARY_KEY\n" +
          "      and J.INVOICE_ID = T_INVOICE.PRIMARY_KEY\n" +
          "      and j.project_id = TP.primary_key\n" +
          "      and tc.primary_key = t_invoice.vendor_id\n" +
          "      AND CONT_CAT_57.CONTACT_ID = TC.PRIMARY_KEY\n" +
          "      AND Y_OBJ_CATEGORY.PRIMARY_KEY = TP.DEFAULT_CATEGORY_ID\n" +
//          "      AND (PMNT.InSendAPDate > CONVERT(DATETIME,?, 101) OR (PMNT.InSentSAP <> 'CHECKED' AND PMNT.InSendAPDate > CONVERT(DATETIME,?, 101)))\n"+
          "      AND (PMNT.InSentSAP <> 'CHECKED' OR PMNT.InSentSAP IS NULL) " +
          "      AND PMNT.InSendAPDate > CONVERT(DATETIME,?, 101)\n"+
          "      AND PMNT.InPayInvoice='Yes'\n"+
          "      AND PMNT.InStatus='Posted'\n"+
          "      order by tc.NAME_UPPER,PMNT.InInvoiceNumber";

  public static final String SQL_QUERY_SAP_LINK_NO_JOIN =
      "SELECT     CcSAPLinkNo, PROJECT_ID, CcAccountName, CcCAAMAccount, CcCAAMSubAccount, CcCloseDate, CcCloseUId, CcSAPComments, \n" +
          "                      CcCompany, CcCostCenter, CcCostCenterDesc, CcCostCenterManager_VID, CcCostCenterManager_CID, CcCostElement, \n" +
          "                      CcCostElementDesc, CcEditDate, CcEditUId, CcInternalOrderNumber, CcLPCONV_SAP_FORMAT, CcOpenDate, CcOpenUId, \n" +
          "                      CcProfitCenter, CcSAPBusiness, CcSAPComments, CcSAPFormat, CcWBS AS WBS\n" +
          "FROM         PROJ_CAT_3930\n" +
          "WHERE     (CcSAPLinkNo = ?)";

  //Professional Contact Employee Id
  private static final String FIELD_EMPL_ID_APPROVE = "EMPL_ID_APPROVE";

  //Invoice Summary
  private static final String FIELD_INVOICE_DATE = "INVOICE_DATE";
  private static final String FIELD_CURRENCY_CODE = "CURRENCY_CODE";
  private static final String SEQUENCE_NUMBER = "SEQUENCE_NUMBER";
  private static final String FIELD_INVOICE_NUMBER = "INVOICE_NUMBER";
  private static final String FIELD_INVOICE_ID = "INVOICE_ID";
  private static final String FIELD_TRAN_ID = "TRAN_ID";
  private static final String FIELD_AMOUNT_VC = "AMOUNT_VC";
  private static final String FIELD_DUE_DATE = "DUE_DATE";

  private static final String FIELD_VENDOR_ID = "VENDOR_ID";
  //Vendor
  private static final String FIELD_VENDOR_TYPE = "VENDOR_TYPE";
  private static final String FIELD_SAP_VENDOR_ID = "SAP_VENDOR_ID";

  private static final String FIELD_VENDOR_NAME = "VENDOR_NAME";
  //Matter
  private static final String FIELD_MATTER_ID = "MATTER_ID";
  private static final String FIELD_PRACTICE_AREA = "PRACTICE_AREA";
  private static final String FIELD_MATTER_NAME = "MATTER_NAME";

  private static final String FIELD_GROUP_REF = "Group_Reference";
  //Allocation(s)
  private static final String FIELD_ALLOCATION_PAY_LC = "ALLOCATION_PAY_LC";
  private static final String FIELD_ACCOUNT_CODE = "COST_ELEMENT";
  private static final String FIELD_SUBACCOUNT = "SUBACCOUNT";
  private static final String FIELD_SAPLINKNO = "SAPLINKNO";
  private static final String FIELD_PROFIT_CENTER = "PROFIT_CENTER";
  private static final String FIELD_WBS = "WBS";
  private static final String FIELD_INTERNAL_ORDER_NUMBER = "INTERNAL_ORDER_NUMBER";
  private static final String FIELD_ALLOCATION_PERCENTAGE= "ALLOCATION_PCT";

  private EmailUtility emailUtility;
  private AccountCodeVerificationDAO accountCodeVerificationDAO;

  public InvoiceDataDAOImpl(EmailUtility emailUtility, AccountCodeVerificationDAO accountCodeVerificationDAO) {
    this.emailUtility = emailUtility;
    this.accountCodeVerificationDAO = accountCodeVerificationDAO;
  }

  public List getInvoiceRecords(boolean isRepostForSpecificDateRequired, Date sendAPDate, PersistentStoreConnection connection, Date productionDate) throws DAOException {
    System.out.println("sendAPDate = " + sendAPDate);
    int count=0;
//    Date date = DateUtils.addDays(sendAPDate, 1);
    sendAPDate.setHours(6);
    List invoiceRecords = new ArrayList();
    try {
      PersistentStoreStatement preparedStatement = connection.prepareStatement(getQueryString(isRepostForSpecificDateRequired));
//      String sendAPDateString = new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY_SAP_SENT_DATE).format(date);
      String sendAPDateString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(sendAPDate);
      String productionDateString = "";
      System.out.println("sendAPDateString = " + sendAPDateString);

      //below line of code is required if the Repost for a specific date is set to true.
      //In such a casse, we need to set the sendAPDate rather than Production date.
      preparedStatement.setParam(1, sendAPDateString);

      //If repost for a specific date is not required, then we need to set the Production Date : usual Run
      if (!isRepostForSpecificDateRequired) {
        productionDate.setHours(6);
        productionDateString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(productionDate);
        System.out.println("productionDateString = " + productionDateString);
        preparedStatement.setParam(1, productionDateString);
      }
      PersistentStoreResultSet resultSet = preparedStatement.executeQuery();
      PersistentStoreResultSetFwdIterator invoiceResultSetIterator = resultSet.getForwardIterator();
      int rowNumber = 1;
      while (invoiceResultSetIterator.next()) {
        count++;
        try {
          String dueDate = invoiceResultSetIterator.getString(FIELD_DUE_DATE);
          String invoiceno = invoiceResultSetIterator.getString(FIELD_INVOICE_NUMBER);
//          if(dueDate!=null && invoiceno.equalsIgnoreCase("35026")){            
          invoiceRecords.add(buildInvoiceRecord(invoiceResultSetIterator, connection));
//          }
        } catch (InvalidInvoiceDataException e) {
          performFaultHandlingForInconsistentData(isRepostForSpecificDateRequired, rowNumber, sendAPDate, e);
        }
        rowNumber++;
      }
      return invoiceRecords;
    } catch (WrappingException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while retrieving invoice data: " + e.getMessage(), e);
    }
  }

  public List getInvoiceRecordsForInvoiceNumber(String invoiceNumber, PersistentStoreConnection connection) throws DAOException {
    String queryString = "SELECT PMNT.INVOICE_ID FROM INVC_CAT_12 PMNT WHERE PMNT.InInvoiceNumber = ?";
    List invoiceIdList = new ArrayList();
    PersistentStoreStatement ps = null;
    PersistentStoreResultSet rs = null;
    try {
      ps = connection.prepareStatement(queryString);
      ps.setParam(1,invoiceNumber);
      rs = ps.executeQuery();
      PersistentStoreResultSetFwdIterator iterator = rs.getForwardIterator();
      while(iterator.next()){
        invoiceIdList.add(""+iterator.getInt("INVOICE_ID"));
      }
    } catch (WrappingException e) {
      e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
    } finally{
      try {
      if(rs != null) rs.close();
      if(ps != null) ps.close();
      } catch (WrappingException e) {
        System.out.println("Exception closing Resources in "+getClass()+".getInvoiceRecordsForInvoiceNumber() "+e.getMessage());
      }
    }
    return invoiceIdList;
  }

  public String getQueryString(boolean isRepostForSpecificDateRequired) {
    String queryString;
    if (isRepostForSpecificDateRequired) {
      queryString = SQL_QUERY_INVOICE_DATA_FOR_SPECIFIC_SEND_AP_DATE;
    } else {
      queryString = SQL_QUERY_INVOICE_DATA_SINCE_LAST_RUN_DATE;
    }
    System.out.println("queryString = " + queryString);
    return queryString;
  }

  private void performFaultHandlingForInconsistentData(boolean isRepostForSpecificDateRequired, int rowNumber, Date sendAPDate, InvalidInvoiceDataException e) {
    String errorMessage = getErrorMessageForInconsistentInvoiceData(isRepostForSpecificDateRequired, rowNumber, sendAPDate, e);
    logError(errorMessage, e);
    sendEmail(errorMessage, e);
  }

  private String getErrorMessageForInconsistentInvoiceData(boolean isRepostForSpecificDateRequired, int rowNumber, Date sendAPDate, RuntimeException e) {
    String errorMessage;
    if (isRepostForSpecificDateRequired) {
      errorMessage = "Invoice Record at Row # " + rowNumber + " skipped. Inconsistent data found while processing invoices for specific send AP date : " + DateUtil.getDate(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY, sendAPDate) + ". Error Message: " + e.getMessage() + ", Please see logs for more details.";
    } else {
      errorMessage = "Invoice Record at Row # " + rowNumber + " skipped. Inconsistent data found while processing invoices since last run date : " + DateUtil.getDate(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY, sendAPDate) + ". Error Message: " + e.getMessage() + ", Please see logs for more details.";
    }
    return errorMessage;
  }

  private void sendEmail(String errorMessage, RuntimeException e) {
    try {
      emailUtility.sendEmailToAdmin(errorMessage);
    } catch (ServiceException e1) {
      logError("Fatal Error: Exception occured while sending success notification Email.", e);
    }
  }

  private void logError(String errorMessage, RuntimeException e) {
    Logger.log(new LoggableError(errorMessage));
    Logger.log(new LoggableError(e));
  }

  private InvoiceRecord buildInvoiceRecord(PersistentStoreResultSetFwdIterator invoiceResultSetIterator, PersistentStoreConnection connection) throws WrappingException {
    return new InvoiceRecord(buildInvoiceSummary(invoiceResultSetIterator),
        buildEmployeeId(invoiceResultSetIterator),
        buildVendor(invoiceResultSetIterator),
        buildAllocationList(invoiceResultSetIterator, connection),
        buildMatter(invoiceResultSetIterator));
  }

  private List buildAllocationList(PersistentStoreResultSetFwdIterator invoiceResultSetIterator, PersistentStoreConnection connection) throws WrappingException {
    List invoiceAllocations = new ArrayList();
    int allocationNumber = 1;
    String allocationNumberAppenderString;
    while (true) {
      allocationNumberAppenderString = getAllocationNumberAppenderString(allocationNumber);
      String sapLinkNumberString = invoiceResultSetIterator.getString(FIELD_SAPLINKNO + allocationNumberAppenderString);
      if (StringUtils.isNullOrEmpty(sapLinkNumberString)) {
        break;
      }
      invoiceAllocations.add(buildAllocation(allocationNumberAppenderString, sapLinkNumberString, invoiceResultSetIterator, connection));
      allocationNumber++;
    }
    return invoiceAllocations;
  }

  private InvoiceAllocation buildAllocation(String allocationNumberAppenderString, String sapLinkNumberString, PersistentStoreResultSetFwdIterator invoiceResultSetIterator, PersistentStoreConnection connection) throws WrappingException {
    String subAccount = null;
    String accountCodeString = invoiceResultSetIterator.getString(FIELD_ACCOUNT_CODE + allocationNumberAppenderString);
    Double allocationAmount = Double.valueOf(invoiceResultSetIterator.getString(FIELD_ALLOCATION_PAY_LC + allocationNumberAppenderString));
//    String subAccount = invoiceResultSetIterator.getString(FIELD_SUBACCOUNT + allocationNumberAppenderString);
//    AccountCode accountCode = accountCodeVerificationDAO.lookUpAccountCodeForSAPLinkNumber(
//        FIELD_SAPLINKNO + allocationNumberAppenderString);
    AccountCode accountCode = accountCodeVerificationDAO.lookUpAccountCodeForSAPLinkNumber(sapLinkNumberString);
    if(accountCode!=null){
      subAccount = accountCode.getCostCenter();
      accountCodeString = accountCode.getAccountCode();
    }
    Integer sapLinkNumber = new Integer(Double.valueOf(sapLinkNumberString).intValue());
    String profitCenter = invoiceResultSetIterator.getString(FIELD_PROFIT_CENTER + allocationNumberAppenderString);
    String internalOrderNumber = invoiceResultSetIterator.getString(FIELD_INTERNAL_ORDER_NUMBER + allocationNumberAppenderString);
    String allocationPercentage = invoiceResultSetIterator.getString(FIELD_ALLOCATION_PERCENTAGE + allocationNumberAppenderString);
    return new InvoiceAllocation(accountCodeString, allocationAmount, subAccount, sapLinkNumber,
        profitCenter, getWBSUsingSAPLinkNumberJoin(sapLinkNumberString, connection), internalOrderNumber, allocationPercentage);
  }

  private String getWBSUsingSAPLinkNumberJoin(String sapLinkNumberString, PersistentStoreConnection connection) throws WrappingException {
    try {
      PersistentStoreStatement preparedStatement = connection.prepareStatement(SQL_QUERY_SAP_LINK_NO_JOIN);
      preparedStatement.setParam(1, sapLinkNumberString);
      PersistentStoreResultSet resultSet = preparedStatement.executeQuery();
      PersistentStoreResultSetSingleResult sapLinkNumberDataSingleResult = resultSet.getSingleResult();
      return sapLinkNumberDataSingleResult.getString(FIELD_WBS);
    } catch (EmptyResultSetException e) {
      return null;
    }
  }

  private String getAllocationNumberAppenderString(int allocationNumber) {
    if (allocationNumber == 1) {
      return "";
    } else {
      return String.valueOf(allocationNumber);
    }
  }

  private Matter buildMatter(PersistentStoreResultSetFwdIterator invoiceResultSetIterator) throws WrappingException {
    String matterId = invoiceResultSetIterator.getString(FIELD_MATTER_ID);
    String practiseArea = invoiceResultSetIterator.getString(FIELD_PRACTICE_AREA);
    String matterName = invoiceResultSetIterator.getString(FIELD_MATTER_NAME);
    String groupRef = invoiceResultSetIterator.getString(FIELD_GROUP_REF);
    return new Matter(matterId, practiseArea, matterName, groupRef);
  }

  //todo for now we will be using Kathy'id until the defect in team connect is fixed
  private String buildEmployeeId(PersistentStoreResultSetFwdIterator invoiceResultSetIterator) throws WrappingException {
//    return invoiceResultSetIterator.getString(FIELD_EMPL_ID_APPROVE);
    return "KMHUDG";
  }

  private Vendor buildVendor(PersistentStoreResultSetFwdIterator invoiceResultSetIterator) throws WrappingException {
    String vendorType = invoiceResultSetIterator.getString(FIELD_VENDOR_TYPE);
    String corpVendorId = invoiceResultSetIterator.getString(FIELD_SAP_VENDOR_ID);
    String vendorName = invoiceResultSetIterator.getString(FIELD_VENDOR_NAME);
    return new Vendor(vendorType, corpVendorId, vendorName);
  }

  private InvoiceSummary buildInvoiceSummary(PersistentStoreResultSetFwdIterator invoiceResultSetIterator) throws WrappingException {
    try {
      String invoicePrimaryKey = invoiceResultSetIterator.getString(FIELD_INVOICE_ID);
      String invoiceNumber = invoiceResultSetIterator.getString(FIELD_INVOICE_NUMBER);
      System.out.println("invoiceNumber = " + invoiceNumber);
      SimpleDateFormat dateFormat = new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY);
      String outputString = invoiceResultSetIterator.getString(FIELD_INVOICE_DATE);
      Date dateOnInvoice = dateFormat.parse(outputString);
      String source = invoiceResultSetIterator.getString(FIELD_DUE_DATE);
      Date dateDue = null;
      if(source!=null){
        dateDue = dateFormat.parse(source);
      }
      String sequenceNumber = invoiceResultSetIterator.getString(SEQUENCE_NUMBER);
      if(sequenceNumber!=null){
        sequenceNumber = sequenceNumber.substring(0,sequenceNumber.indexOf("."));
      }
      String currencyCode = invoiceResultSetIterator.getString(FIELD_CURRENCY_CODE);
      if(sequenceNumber!=null){
        invoiceNumber=invoiceNumber+"_"+sequenceNumber;
      }
      Integer transactionId = new Integer(Double.valueOf(invoiceResultSetIterator.getString(FIELD_TRAN_ID)).intValue());
      Double amountVC = Double.valueOf(invoiceResultSetIterator.getString(FIELD_AMOUNT_VC));
      String vendorId = invoiceResultSetIterator.getString(FIELD_VENDOR_ID);
      return new InvoiceSummary(dateOnInvoice, currencyCode, invoiceNumber, transactionId, amountVC, dateDue, vendorId, invoicePrimaryKey);
    } catch (ParseException e) {
      throw new InvalidInvoiceDataException(e);
    }
  }

  public String getDate() {
    
    TimeZone tz_gmt;
    tz_gmt = TimeZone.getTimeZone("CST");
//    SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    sdformat.setTimeZone(tz_gmt);
    Timestamp tsGmtnow;
    GregorianCalendar calendar = (new GregorianCalendar(tz_gmt));
//    calendar.setTimeZone(tz_gmt);
    tsGmtnow = Timestamp.valueOf(sdformat.format(calendar.getTime()));
    System.out.println("tsGmtnow.toGMTString() = " + tsGmtnow.toGMTString());
    return tsGmtnow.toGMTString();
  }
}