/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao;

import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;

import java.util.Date;

/**
 * Filename:    $RCSfile: LastRunInfoDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-02 22:28:47 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public interface LastRunInfoDAO {

  /**
   * Updates LastInvoiceProcessingRunInfo.xml with information about the last successful run
   * Note: For now just the current date will be written as last-successful-run-date.
   * @param lastRunInfoFileName - a new one will be created each time in dir specified by
   *                                        -Dlmms.lastruninfo.dir
   * @throws com.monsanto.wst.lawmattermanagementsystem.exception.DAOException -
   */
  void updateLastSuccessfulRunDate(String lastRunInfoFileName) throws DAOException;

  /**
   * Reads the last successful run date.
   * @return - Date
   * @throws DAOException - If file cannot be read or the such a file does not exist
   * @param lastRunInfoFileName - Absolute FileName of the file containg "last successful run date" information.
   */
  Date readLastSuccessfulRunDate(String lastRunInfoFileName) throws DAOException;
}