/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.LastRunInfo;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Filename:    $RCSfile: LastRunInfoDAOImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-12 20:46:13 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class LastRunInfoDAOImpl implements LastRunInfoDAO {

  private XmlSerializer serializer;

  public LastRunInfoDAOImpl(XmlSerializerBuilder xmlSerializerBuilder) {
    initializeSerializer(xmlSerializerBuilder);
  }

  public void updateLastSuccessfulRunDate(String lastRunInfoFileName) throws DAOException {
    validateFileNameForUpdate(lastRunInfoFileName);
    try {
      String xmlDataString = serializer.toXML(new LastRunInfo(DateUtil.getDate(LMMSConstants.DATE_FORMAT_FOR_LAST_SUCCESSFUL_RUN_DATE, new Date())));
      Document document = DOMUtil.newDocumentFromXML(xmlDataString);
      DOMUtil.writeDocumentToFile(document, lastRunInfoFileName);
    } catch (IOException e) {
      throw new DAOException("IOException occured while updating last run date to file '" + lastRunInfoFileName + "'. : " + e.getMessage(), e);
    } catch (ParserException e) {
      throw new DAOException("Exception occured while parsing string obtained from XMLSerializer to file '" + lastRunInfoFileName + "'. : " + e.getMessage(), e);
    } catch (TransformerException e) {
      throw new DAOException("Exception occured while transforming string obtained from XMLSerializer to file '" + lastRunInfoFileName + "'. : " + e.getMessage(), e);
    } catch (Exception e) {
      throw new DAOException("Exception occured while updating last run date to file '" + lastRunInfoFileName + "'. : " + e.getMessage(), e);
    }
  }

  public Date readLastSuccessfulRunDate(String lastRunInfoFileName) throws DAOException {
    validateFileNameForRead(lastRunInfoFileName);
    try {
      LastRunInfo lastRunInfo = (LastRunInfo) serializer.fromDocument(DOMUtil.newDocument(lastRunInfoFileName));
      return new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_LAST_SUCCESSFUL_RUN_DATE).parse(lastRunInfo.getLastSuccessfulRunDate());
    } catch (ParseException e) {
      throw new DAOException("Exception occured while parsing date string obtained from file '" + lastRunInfoFileName + "'. : " + e.getMessage(), e);
    } catch (ParserException e) {
      throw new DAOException("Exception occured while parsing XML file '" + lastRunInfoFileName + "'. : " + e.getMessage(), e);
    } catch (Exception e) {
      throw new DAOException("Exception occured while reading last run date from file '" + lastRunInfoFileName + "'. : " + e.getMessage(), e);
    }
  }

  private void validateFileNameForRead(String lastRunInfoFileName) throws DAOException {
    if (StringUtils.isNullOrEmpty(lastRunInfoFileName)) {
      throw new DAOException("LastRunInfoDAOImpl: Null or Empty File Name found while reading last successful run date.");
    }
  }

  private void validateFileNameForUpdate(String lastRunInfoFileName) throws DAOException {
    if (StringUtils.isNullOrEmpty(lastRunInfoFileName)) {
      throw new DAOException("LastRunInfoDAOImpl: Null or Empty File Name found while updating last successful run date.");
    }
  }

  private void initializeSerializer(XmlSerializerBuilder builder) {
    builder.registerMapping("", LMMSConstants.ALIAS_LAST_RUN_INFO, LastRunInfo.class);
    serializer = builder.createSerializer();
  }
}