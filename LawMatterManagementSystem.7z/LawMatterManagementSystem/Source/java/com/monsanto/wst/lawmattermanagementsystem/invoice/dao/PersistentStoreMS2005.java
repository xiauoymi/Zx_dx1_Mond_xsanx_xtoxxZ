package com.monsanto.wst.lawmattermanagementsystem.invoice.dao;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.PersistentStoreDB;
import com.monsanto.dbdataservices.PersistentStoreDBConnection;

import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * Date: Dec 21, 2005
 * Time: 10:04:50 AM
 * <p/>
 * This class is the Microsoft SQL Server 2000 jdbc driver implementation of the PersistentStoreDB abstract class.
 * Some things to note, when defining the data source, provide a url and if the server has a windows network style path,
 * ie. \\SERVER\NAME, provide a ServerName property at the end of the url.
 *
 * ie. //localhost:1433;ServerName=SERVER\NAME
 *
 * You can also specify what database on the server you are connecting to with the DatabaseName parameter.
 *
 * ie. //localhost:1433;ServerName=SERVER\NAME;DatabaseName=DBNAME
 *
 * There is an additional parameter you can add for optimization.  If you are going to be doing queries that return back
 * large result sets, then you should set the SelectMethod parameter to cursor.
 *
 * ie. //localhost:1433;ServerName=SERVER\NAME;DatabaseName=DBNAME;SelectMethod=cursor
 *
 * For additional information, consult the installation Help file which should be located here:
 * C:\Program Files\Microsoft SQL Server 2000 Driver for JDBC\Help\wwhelp\js\html\frames.htm
 *
 * @author njminsh (Nate Minshew)
 * @version 1.0
 * @since 1.0
 */
public class PersistentStoreMS2005 extends PersistentStoreDB {

    /**
     * This constructor takes the file path to a properties file that contains database configuration information.
     *
     * @param config String representing the file path to a config file.
     * @throws com.monsanto.Util.Exceptions.WrappingException - If unable to read the properties file.
     */
    public PersistentStoreMS2005(String config) throws WrappingException {
        super(config);
        init();
    }

    /**
     * This constructor takes the username, password, data source and sequence id of the resource you are connecting to.
     *
     * @param username String representing the username.
     * @param password String representing the password.
     * @param datasource String representing the location of the data source.
     * @param seqId String representing the name of the sequence to use.
     * @throws com.monsanto.Util.Exceptions.WrappingException - If invalid connection parameters were specified.
     */
    public PersistentStoreMS2005(String username, String password, String datasource, String seqId) throws WrappingException {
        super(username, password, datasource, seqId);
        init();
    }

    /**
     * This constructor takes the username, password and data source of the resource you are connecting to.
     *
     * @param username String representing the username.
     * @param password String representing the password.
     * @param datasource String representing the location of the data source
     * @throws com.monsanto.Util.Exceptions.WrappingException - If invalid connection parameters were specified.
     */
    public PersistentStoreMS2005(String username, String password, String datasource) throws WrappingException {
        super(username, password, datasource);
        init();
    }

    /**
     * This constructor takes a resource bundle that contains the database connection information.
     *
     * @param bundle ResourceBundle object containing the connection information.
     * @throws com.monsanto.Util.Exceptions.WrappingException - If unable to retrieve the connection information from the resource bundle.
     */
    public PersistentStoreMS2005(ResourceBundle bundle) throws WrappingException {
        super(bundle);
        init();
    }

    /**
     * This method registers the database driver to use.
     *
     * @throws com.monsanto.Util.Exceptions.WrappingException - If unable to find the appropriate database driver.
     */
    private void init() throws WrappingException {
        try {
            /*  Register the driver.  */
//            Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver").newInstance();
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
        } catch (ClassNotFoundException e) {
            throw new WrappingException(e);
        } catch (InstantiationException e) {
            throw new WrappingException(e);
        } catch (IllegalAccessException e) {
            throw new WrappingException(e);
        }
    }

    /**
     * This method creates a connection to the configured database.
     *
     * @return PersistentStoreConnection - Object representing the connection to the database.
     * @throws com.monsanto.Util.Exceptions.WrappingException - If unable to connect to the database.
     */
    public PersistentStoreConnection connect() throws WrappingException {
        return new PersistentStoreDBConnection(userName(), password(), new StringBuffer().append(dataSource()).toString());
//        return new PersistentStoreDBConnection(userName(), password(), new StringBuffer("jdbc:microsoft:sqlserver:").append(dataSource()).toString());
    }

}