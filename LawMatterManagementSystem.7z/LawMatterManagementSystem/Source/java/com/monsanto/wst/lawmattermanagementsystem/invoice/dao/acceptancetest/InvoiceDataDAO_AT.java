/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.acceptancetest;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.test.MockAccountCodeVerificationDAO;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceAllocation;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock.MockEmailUtility;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import junit.framework.TestCase;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Filename:    $RCSfile: InvoiceDataDAO_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-12-22 15:03:42 $
 *
 * @author rdesai2
 * @version $Revision: 1.24 $
 */
public class InvoiceDataDAO_AT extends TestCase {

  private ResourceConnectionManager resourceConnectionManager = null;
  private PersistentStoreConnection connection = null;

  protected void setUp() throws IOException {
    resourceConnectionManager = new ResourceManagerFactoryImpl().getConnectionManager(LMMSConstants.DATASOURCE_TYPE_SQL_SERVER);
  }

  protected void tearDown() throws Exception {
    closeConnection();
  }

  public void testGetInvoiceRecords_WithASpecificRepostDate() throws Exception {
    connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_LAW_TCE);
    InvoiceDataDAO invoiceDataDAO = new InvoiceDataDAOImpl(new MockEmailUtility(), new AccountCodeVerificationDAOImpl(new ResourceManagerFactoryImpl()));
    String outputString = ((InvoiceDataDAOImpl) invoiceDataDAO).getQueryString(true);
    System.out.println("outputString = " + outputString);
    List invoiceRecords = invoiceDataDAO.getInvoiceRecords(true, new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY_SAP_SENT_DATE).parse("06/08/2008"), connection, null);
    int totalRecords = invoiceRecords.size();
    System.out.println("totalRecords = " + totalRecords);
  }


  public void testTemp() throws Exception {
    InvoiceDataDAO invoiceDataDAO = new InvoiceDataDAOImpl(new MockEmailUtility(), new AccountCodeVerificationDAOImpl(new ResourceManagerFactoryImpl()));
    String outputString = ((InvoiceDataDAOImpl) invoiceDataDAO).getQueryString(false);
    System.out.println("outputString = " + outputString);

  }

  private void validateInvoiceNumber5(InvoiceRecord invoiceRecord, String invoiceNumber) {
    validateInvoiceSummary("2006-07-31 12:00:00", "2006-10-01 06:00:00", "USD", invoiceNumber, "114452", "1187.00",
            invoiceRecord);
    //todo this change needs to be undone after bug is fixed in Team connect
//    validateEmployeeId("Price, Countess W.", invoiceRecord);
    validateEmployeeId("KMHUDG", invoiceRecord);
    validateVendor("LAW", "519953", "ALVERSON, TAYLOR, MORTENSEN & SANDERS", invoiceRecord);
    validateAllocation("101.00", "5180-9130-21310878", "1364", "", "n/a", "500776000",
            "n/a", (InvoiceAllocation) invoiceRecord.getInvoiceAllocations().get(0));
    validateAllocation("1086.00", "5180-9130-21310878", "1364", "", "n/a", "500776000",
            "n/a", (InvoiceAllocation) invoiceRecord.getInvoiceAllocations().get(1));
    validateMatter("2006-000144", "Litigation", "Asbestos", "Bauer, Chalmer v. AW Chesterton (Asbestos)", invoiceRecord);
  }

  private void validateAllocation(String allocationAmt, String accountCode, String sapLinkNo, String subAccount, String ion, String profitCenter, String wbs, InvoiceAllocation invoiceAllocation) {
    assertEquals(new Double(allocationAmt), invoiceAllocation.getAllocationPayInLocalCurrency());
    assertEquals(accountCode, invoiceAllocation.getAccountCodeString());
    assertEquals(new Integer(sapLinkNo), invoiceAllocation.getMtcSAPLinkNumber());
    assertEquals(subAccount, invoiceAllocation.getSubAccountCode());
    assertEquals(ion, invoiceAllocation.getInternalOrderNumber());
    assertEquals(profitCenter, invoiceAllocation.getProfitCenter());
    assertEquals(wbs, invoiceAllocation.getWorkBreakdownStructure());
  }



  private void validateMatter(String matterId, String practiceArea, String grpRef, String matterName, InvoiceRecord invoiceRecord) {
    assertEquals(matterId, invoiceRecord.getMatter().getMatterId());
    assertEquals(practiceArea, invoiceRecord.getMatter().getPracticeArea());
    //todo the is commented out Not sure where we use gourp reference
//    assertEquals(grpRef, invoiceRecord.getMatter().getMatterGroupReference());
    assertEquals(matterName, invoiceRecord.getMatter().getMatterName());
  }

  private void validateVendor(String vendorType, String sapVendorId, String vendorName, InvoiceRecord invoiceRecord) {
    assertEquals(vendorType, invoiceRecord.getVendor().getVendorType());
    assertEquals(sapVendorId, invoiceRecord.getVendor().getCorpVendorId());
    assertEquals(vendorName, invoiceRecord.getVendor().getVendorShortName());
  }

  private void validateEmployeeId(String employeeId, InvoiceRecord invoiceRecord) {
    assertEquals(employeeId, invoiceRecord.getProfessionalContactEmployeeId());
  }

  private void validateInvoiceSummary(String dateOnInvoice, String dateDue, String currency, String invoiceNumber, String transactionId, String amountVC, InvoiceRecord invoiceRecord) {
    assertEquals(dateOnInvoice, DateUtil.getDate(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY, invoiceRecord.getInvoiceSummary().getDateOnInvoice()));
    assertEquals(dateDue, DateUtil.getDate(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY, invoiceRecord.getInvoiceSummary().getDateDue()));
    assertEquals(currency, invoiceRecord.getInvoiceSummary().getCurrencyCode());
    assertEquals(invoiceNumber, invoiceRecord.getInvoiceSummary().getInvoiceNumber());
    assertEquals(new Integer(transactionId), invoiceRecord.getInvoiceSummary().getTransactionId());
    assertEquals(new Double(amountVC), invoiceRecord.getInvoiceSummary().getAmountInVendorCurrency());
  }

  private void closeConnection() throws WrappingException {
    if (connection != null) {
      connection.close();
    }
  }

  public void testDates() throws Exception {
        InvoiceDataDAO invoiceDataDAO = new InvoiceDataDAOImpl(new MockEmailUtility(), new AccountCodeVerificationDAOImpl(new ResourceManagerFactoryImpl()));
    String outputString = ((InvoiceDataDAOImpl) invoiceDataDAO).getDate();
    System.out.println("outputString = " + outputString);

  }

  public void testGetAssociatedInvoiceIdsForInvoiceNumber() throws Exception {
    String invoiceNumber = "6489";
    connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_LAW_TCE);
    InvoiceDataDAO invoiceDao = new InvoiceDataDAOImpl(new MockEmailUtility(), new MockAccountCodeVerificationDAO());
    List invoiceIdList = invoiceDao.getInvoiceRecordsForInvoiceNumber(invoiceNumber, connection);
    assertNotNull(invoiceIdList);
    assertTrue(invoiceIdList.size() > 0);
  }
}