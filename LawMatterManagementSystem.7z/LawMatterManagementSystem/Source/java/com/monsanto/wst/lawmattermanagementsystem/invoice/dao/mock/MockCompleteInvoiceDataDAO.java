/*
MockCompleteInvoiceDataDAO was created on Feb 1, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: MockCompleteInvoiceDataDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-12-22 15:04:39 $
 *
 * @author vrbethi
 * @version $Revision: 1.10 $
 */
public class MockCompleteInvoiceDataDAO implements InvoiceDataDAO {

  public List getInvoiceRecords(boolean isRepostForSpecificDateRequired, Date repostDate, PersistentStoreConnection persistentStoreConnection, Date productionDate) throws DAOException {
    ArrayList arrayList = new ArrayList();
    arrayList.add(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord());
    return arrayList;
  }

  public List getInvoiceRecordsForInvoiceNumber(String invoiceNumber, PersistentStoreConnection connection) throws DAOException {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }
}