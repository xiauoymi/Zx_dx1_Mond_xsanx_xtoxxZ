/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dataservices.Test.MockConnection;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAOImpl;

/**
 * Filename:    $RCSfile: MockConnectionForInvoiceData.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-09 20:47:55 $
 *
 * @author rdesai2
 * @version $Revision: 1.5 $
 */
public class MockConnectionForInvoiceData extends MockConnection {

  private static final String XML_PAYMENT_DATA_FOR_SPECIFIC_SEND_AP_DATE = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/PaymentDataForSpecificSendAPDate.xml";
  private static final String XML_PAYMENT_DATA_SINCE_LAST_RUN_DATE = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/PaymentDataSinceLastRunDate.xml";

  public PersistentStoreStatement prepareStatement(String sqlQuery) throws WrappingException {
    if (sqlQuery != null) {
      if (sqlQuery.equalsIgnoreCase(InvoiceDataDAOImpl.SQL_QUERY_INVOICE_DATA_FOR_SPECIFIC_SEND_AP_DATE)) {
        return new MockPersistentStoreStatementForInvoiceData(XML_PAYMENT_DATA_FOR_SPECIFIC_SEND_AP_DATE);
      }
      if (sqlQuery.equalsIgnoreCase(InvoiceDataDAOImpl.SQL_QUERY_INVOICE_DATA_SINCE_LAST_RUN_DATE)) {
        return new MockPersistentStoreStatementForInvoiceData(XML_PAYMENT_DATA_SINCE_LAST_RUN_DATE);
      }
      if (sqlQuery.indexOf(InvoiceDataDAOImpl.SQL_QUERY_SAP_LINK_NO_JOIN) != -1) {
        return getPersistentStoreForSAPLinkData();
      }
    }
    return null;
  }

  protected PersistentStoreStatement getPersistentStoreForSAPLinkData() {
    return new MockPersistentStoreStatementForSAPLinkJoinData();
  }
}