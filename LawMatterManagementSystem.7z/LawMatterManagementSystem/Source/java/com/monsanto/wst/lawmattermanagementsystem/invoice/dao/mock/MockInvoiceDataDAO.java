/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock;

import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.*;
import com.monsanto.dataservices.PersistentStoreConnection;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;

/**
 * Filename:    $RCSfile: MockInvoiceDataDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-12-22 15:04:39 $
 *
 * @author rdesai2
 * @version $Revision: 1.11 $
 */
public class MockInvoiceDataDAO implements InvoiceDataDAO {

  private boolean repostForSpecificDateRequired;
  private Date sendAPDate;
  private Date productionDate;

  public List getInvoiceRecords(boolean isRepostForSpecificDateRequired, Date sendAPDate, PersistentStoreConnection persistentStoreConnection, Date productionDate) throws DAOException {
    repostForSpecificDateRequired = isRepostForSpecificDateRequired;
    this.sendAPDate = sendAPDate;
    this.productionDate = productionDate;
    ArrayList arrayList = new ArrayList();
    arrayList.add(new InvoiceRecord(new InvoiceSummary(new Date(), "USD","Invoice #1", new Integer(1), new Double(300.50), new Date(), "12", ""), "Emp1", new Vendor("LAW", "132" , "V-1"), getAllocations(), new Matter("33", "P1", "Matter1", null)));
    arrayList.add(new InvoiceRecord(new InvoiceSummary(new Date(), "USD","Invoice #2", new Integer(1), new Double(300.50), new Date(), "12", ""), "Emp1", new Vendor("LAW", "132" , "V-1"), getAllocationsWithNoProfitCenterAndSubAccountCode(), new Matter("33", "P1", "Matter1", null)));
    arrayList.add(new InvoiceRecord(new InvoiceSummary(new Date(), "USD","Invoice #3", new Integer(1), new Double(300.50), new Date(), "12", ""), "Emp1", new Vendor("LAW", "132" , "V-1"), getAllocations(), new Matter("33", "P1", "Matter1", null)));
    arrayList.add(new InvoiceRecord(new InvoiceSummary(new Date(), "USD","Invoice #4", new Integer(1), new Double(300.50), new Date(), "12", ""), "Emp1", new Vendor("LAW", "132" , "V-1"), getAllocations(), new Matter("33", "P1", "Matter1", null)));
    arrayList.add(new InvoiceRecord(new InvoiceSummary(new Date(), "USD","Invoice #4", new Integer(1), new Double(300.50), new Date(), "12", ""), "Emp1", new Vendor("LAW", "132" , "V-1"), getAllocations(), new Matter("33", "P1", "Matter1", null)));
    return arrayList;
  }

  public List getInvoiceRecordsForInvoiceNumber(String invoiceNumber, PersistentStoreConnection connection) throws DAOException {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public boolean isRepostForSpecificDateRequired() {
    return repostForSpecificDateRequired;
  }

  public Date getSendAPDate() {
    return sendAPDate;
  }

  private List getAllocations() {
    List allocations = new ArrayList();
    InvoiceAllocation allocation = new InvoiceAllocation("1234-5678-909009", new Double(912.50), "89898", new Integer(234), "PC1", null, null,
        null);
    allocations.add(allocation);
    return allocations;
  }

  private List getAllocationsWithNoProfitCenterAndSubAccountCode() {
    List allocations = new ArrayList();
    InvoiceAllocation allocation = new InvoiceAllocation("1234-5678-909009", new Double(912.50), "89898", new Integer(234), "PC1", null, null,
        null);
    allocations.add(allocation);
    allocation = new InvoiceAllocation("1234-5678-909009", new Double(912.50), "", new Integer(234), null, null, null,
        null);
    allocations.add(allocation);
    allocation = new InvoiceAllocation("1234-5678-909009", new Double(912.50), null, new Integer(234), "", null, null,
        null);
    allocations.add(allocation);
    return allocations;
  }


  public Date getProductionDate() {
    return productionDate;
  }
}