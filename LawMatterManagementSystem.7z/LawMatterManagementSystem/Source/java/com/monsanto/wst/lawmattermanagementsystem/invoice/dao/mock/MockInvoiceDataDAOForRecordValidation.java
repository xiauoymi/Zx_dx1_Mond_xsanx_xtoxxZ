/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock;

import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.*;
import com.monsanto.dataservices.PersistentStoreConnection;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: MockInvoiceDataDAOForRecordValidation.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-12-22 15:04:39 $
 *
 * @author rdesai2
 * @version $Revision: 1.12 $
 */
public class MockInvoiceDataDAOForRecordValidation implements InvoiceDataDAO {

  public List getInvoiceRecords_BadAccountCode(boolean isRepostForSpecificDateRequired, Date repostDate, PersistentStoreConnection persistentStoreConnection) throws DAOException {
    ArrayList arrayList = new ArrayList();
    arrayList.add(getTestInvoiceRecordEmptyAccountCodeString());
    arrayList.add(getTestInvoiceRecordWithBadAccountCode());
    arrayList.add(getTestInvoiceRecordWithEmptySubAccountCodeAndInvalidProfitCenter());
    arrayList.add(getTestInvoiceRecordWithInvoiceNumberGreaterThan16Digits());
    arrayList.add(getTestInvoiceRecordWithBadVendorId());
    arrayList.add(getTestInvoiceRecordWithOneBusinessCode());
    arrayList.add(getTestInvoiceRecordWithMoreThanOneBusinessCode());
    arrayList.add(getTestInvoiceRecordWithOneInvoiceAllocation());
    arrayList.add(getTestInvoiceRecordWithAllZeroAllocationAmount());
    return arrayList;
  }

  public List getInvoiceRecords(boolean isRepostForSpecificDateRequired, Date repostDate, PersistentStoreConnection persistentStoreConnection, Date productionDate) throws DAOException {
    ArrayList arrayList = new ArrayList();
    arrayList.add(getTestInvoiceRecordWithBadAccountCode());
    arrayList.add(getTestInvoiceRecordWithEmptySubAccountCodeAndInvalidProfitCenter());
    arrayList.add(getTestInvoiceRecordWithInvoiceNumberGreaterThan16Digits());
    arrayList.add(getTestInvoiceRecordWithBadVendorId());
    arrayList.add(getTestInvoiceRecordWithOneBusinessCode());
    arrayList.add(getTestInvoiceRecordWithMoreThanOneBusinessCode());
    arrayList.add(getTestInvoiceRecordWithOneInvoiceAllocation());
    arrayList.add(getTestInvoiceRecordWithAllZeroAllocationAmount());
    return arrayList;
  }

  public List getInvoiceRecordsForInvoiceNumber(String invoiceNumber, PersistentStoreConnection connection) throws DAOException {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public List getInvoiceRecordsWithMultipleAllcoations(boolean isRepostForSpecificDateRequired, Date repostDate, PersistentStoreConnection persistentStoreConnection) throws DAOException {
    ArrayList arrayList = new ArrayList();
    arrayList.add(getTestInvoiceRecordWithBadAccountCode());
    arrayList.add(getTestInvoiceRecordWithEmptySubAccountCodeAndInvalidProfitCenter());
    arrayList.add(getTestInvoiceRecordWithInvoiceNumberGreaterThan16Digits());
    arrayList.add(getTestInvoiceRecordWithBadVendorId());
    arrayList.add(getTestInvoiceRecordWithOneBusinessCode());
    arrayList.add(getTestInvoiceRecordWithMoreThanOneBusinessCode());
    arrayList.add(getTestInvoiceRecordWithMultipleInvoiceAllocations_ButOneAllocationWithHundredPct());
    return arrayList;
  }

  private InvoiceRecord getTestInvoiceRecordWithBadAccountCode() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "invoice#1", new Integer(1123), new Double(500.95), new Date(), "vendor1", "");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "250099", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-BAD_COST", new Double(-100), "89888", new Integer(44), "testProfitCenter2", "WBS2", "ION2",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-11006622", new Double(400.95), "787778", new Integer(56), "testProfitCenter3", "WBS3", "ION3",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private InvoiceRecord getTestInvoiceRecordWithOneBusinessCode() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "invoice#1", new Integer(1123), new Double(500.95), new Date(), "vendor1", "");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "250099", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-90099909", new Double(-100), "89888", new Integer(44), "testProfitCenter2", "WBS2", "ION2",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-11006622", new Double(400.95), "787778", new Integer(56), "testProfitCenter3", "WBS3", "ION3",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private InvoiceRecord getTestInvoiceRecordWithAllZeroAllocationAmount() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "invoice#1", new Integer(1123), new Double(500.95), new Date(), "vendor1", "");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "250099", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(0), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-90099909", new Double(0), "89888", new Integer(44), "testProfitCenter2", "WBS2", "ION2",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-11006622", new Double(0), "787778", new Integer(56), "testProfitCenter3", "WBS3", "ION3",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private InvoiceRecord getTestInvoiceRecordEmptyAccountCodeString() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "invoice#1", new Integer(1123), new Double(500.95), new Date(), "vendor1", "");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "250099", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation(null, new Double(0), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    invoiceAllocations.add(new InvoiceAllocation("", new Double(0), "89888", new Integer(44), "testProfitCenter2", "WBS2", "ION2",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-11006622", new Double(0), "787778", new Integer(56), "testProfitCenter3", "WBS3", "ION3",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private InvoiceRecord getTestInvoiceRecordWithMoreThanOneBusinessCode() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "invoice#1", new Integer(1123), new Double(500.95), new Date(), "vendor1", "");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "250099", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-90099909", new Double(-100), "89888", new Integer(44), "testProfitCenter2", "WBS2", "ION2",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9115-11006622", new Double(400.95), "787778", new Integer(56), "testProfitCenter3", "WBS3", "ION3",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-90099909", new Double(-100), "89888", new Integer(44), "testProfitCenter2", "WBS2", "ION2",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private InvoiceRecord getTestInvoiceRecordWithEmptySubAccountCodeAndInvalidProfitCenter() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "invoice#1", new Integer(1123), new Double(500.95), new Date(), "vendor1", "");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "250099", "V-LAW");
    List invoiceAllocations = new ArrayList();
    //This should be ignored since sub-account code is present
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-11006622", new Double(400.95), "787778", new Integer(56), "INVALID_PROFIT_CENTER", "WBS3", "ION3",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    //This should be reported as profit-center error, since sub-account code is empty.
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "", new Integer(2), "INVALID_PROFIT_CENTER", "WBS1", "ION1",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private InvoiceRecord getTestInvoiceRecordWithInvoiceNumberGreaterThan16Digits() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "12345678901234567", new Integer(1123), new Double(500.95), new Date(), "vendor1", "");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "250099", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private InvoiceRecord getTestInvoiceRecordWithBadVendorId() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "123456", new Integer(1123), new Double(500.95), new Date(), "vendor1", "");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "BAD_CORP_VENDOR", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private InvoiceRecord getTestInvoiceRecordWithOneInvoiceAllocation() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "123456", new Integer(1123), new Double(500.95), new Date(), "vendor1", "");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "250099", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private InvoiceRecord getTestInvoiceRecordWithMultipleInvoiceAllocations_ButOneAllocationWithHundredPct() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "123456", new Integer(1123), new Double(500.95), new Date(), "vendor1", "");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "250099", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        "100.00"));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }
}