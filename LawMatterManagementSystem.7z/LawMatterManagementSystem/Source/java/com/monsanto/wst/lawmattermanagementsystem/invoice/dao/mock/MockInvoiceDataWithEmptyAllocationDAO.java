package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock;

import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAO;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.dataservices.PersistentStoreConnection;

import java.util.List;
import java.util.Date;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Sep 15, 2008
 * Time: 3:51:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockInvoiceDataWithEmptyAllocationDAO implements InvoiceDataDAO{
  public List getInvoiceRecords(boolean isRepostForSpecificDateRequired, Date sendAPDate, PersistentStoreConnection connection, Date productionDate) throws DAOException {
    ArrayList arrayList = new ArrayList();
    arrayList.add(MockInvoiceRecordDataUtility.getInvoiceRecordWithEmptyAllocationList());
    return arrayList;
  }

  public List getInvoiceRecordsForInvoiceNumber(String invoiceNumber, PersistentStoreConnection connection) throws DAOException {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }
}
