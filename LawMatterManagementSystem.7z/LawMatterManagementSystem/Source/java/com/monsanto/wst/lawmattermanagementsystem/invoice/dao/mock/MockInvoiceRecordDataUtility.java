/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.*;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;

/**
 * Filename:    $RCSfile: MockInvoiceRecordDataUtility.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-15 21:15:41 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class MockInvoiceRecordDataUtility {

  public static InvoiceRecord getDefaultInvoiceRecord() {
    return new InvoiceRecord(getSummary(), getEmpId(), getVendor(), getAllocationList(), getMatter());
  }

  public static InvoiceRecord getInvoiceRecordWithAmountVC(double amountVC) {
    return new InvoiceRecord(getSummaryWithAmountVC(amountVC), getEmpId(), getVendor(), getAllocationList(), getMatter());
  }

  public static InvoiceRecord getInvoiceRecordWithWBS(String wbs) {
    return new InvoiceRecord(getSummary(), getEmpId(), getVendor(), getAllocationListWithWBS(wbs), getMatter());
  }

  public static InvoiceRecord getInvoiceRecordWithCostAndProfitCenter(String costCenter, String profitCenter) {
    return new InvoiceRecord(getSummary(), getEmpId(), getVendor(), getAllocationListWithCostAndProfitCenter(costCenter, profitCenter), getMatter());
  }

  public static InvoiceRecord getInvoiceRecordWithPractiseAreaAndMatterName(String practiceArea, String matterName) {
    return new InvoiceRecord(getSummary(), getEmpId(), getVendor(), getAllocationList(), getMatterWithPractiseAreaAndMatterName(practiceArea, matterName));
  }

  public static InvoiceRecord getInvoiceRecordWithPractiseAreaAndGrpRef(String practiceArea, String grpRef) {
    return new InvoiceRecord(getSummary(), getEmpId(), getVendor(), getAllocationList(), getMatterWithPractiseAreaAndGrpRef(practiceArea, grpRef));
  }

  public static InvoiceRecord getInvoiceRecordWithVendorType(String vendorType) {
    return new InvoiceRecord(getSummary(), getEmpId(), getVendorWithVendorType(vendorType), getAllocationList(), getMatter());
  }

  public static InvoiceRecord getInvoiceRecordWithION(String internalOrderNumber) {
    return new InvoiceRecord(getSummary(), getEmpId(), getVendor(), getAllocationListWithION(internalOrderNumber), getMatter());
  }

  public static InvoiceRecord getInvoiceRecordWithSubAccountCode(String subAccountCode) {
    return new InvoiceRecord(getSummary(), getEmpId(), getVendor(), getAllocationListWithSubAccountCode(subAccountCode), getMatter());
  }

  public static InvoiceRecord getInvoiceRecordWithAllocationAmount(double amount) {
    return new InvoiceRecord(getSummary(), getEmpId(), getVendor(), getAllocationWithAllocationAmount(amount), getMatter());
  }

  public static InvoiceRecord getInvoiceRecordWithNullAllocation() {
    return new InvoiceRecord(getSummary(), getEmpId(), getVendor(), getAllocationListWithNullAllocation(), getMatter());
  }

  public static InvoiceRecord getInvoiceRecordWithAccountCode(String accountCodeString) {
    return new InvoiceRecord(getSummary(), getEmpId(), getVendor(), getAllocationListWithAccountCode(accountCodeString), getMatter());
  }

  private static List getAllocationListWithNullAllocation() {
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(getAllocation1());
    invoiceAllocations.add(null);
    return invoiceAllocations;
  }

  private static List getAllocationListWithWBS(String wbs) {
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(getAllocation1WithWBS(wbs));
    return invoiceAllocations;
  }

  private static List getAllocationListWithCostAndProfitCenter(String costCenter, String profitCenter) {
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(getAllocationWithCostAndProfitCenter(costCenter, profitCenter));
    return invoiceAllocations;
  }

  private static List getAllocationListWithION(String internalOrderNumber) {
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(getAllocationWithION(internalOrderNumber));
    return invoiceAllocations;
  }

  private static List getAllocationList() {
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(getAllocation1());
    invoiceAllocations.add(getAllocation2());
    invoiceAllocations.add(getAllocation3());
    return invoiceAllocations;
  }

  private static List getAllocationWithAllocationAmount(double amount) {
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(getAllocation1(amount));
    return invoiceAllocations;
  }

  private static List getAllocationListWithAccountCode(String accountCodeString) {
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(getAllocation1(accountCodeString));
    return invoiceAllocations;
  }

  private static List getAllocationListWithSubAccountCode(String subAccountCodeString) {
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(getAllocation1WithSubAccount(subAccountCodeString));
    return invoiceAllocations;
  }

  private static InvoiceAllocation getAllocation1() {
    return new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null);
  }

  private static Object getAllocation1WithWBS(String wbs) {
    return new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", wbs, "ION1",
        null);
  }

  private static InvoiceAllocation getAllocationWithCostAndProfitCenter(String costCenter, String profitCenter) {
    return new InvoiceAllocation("5180-9130-41700900", new Double(200), costCenter, new Integer(2), profitCenter, "WBS1", "ION1",
        null);
  }

  private static Object getAllocationWithION(String internalOrderNumber) {
    return new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", internalOrderNumber,
        null);
  }

  private static InvoiceAllocation getAllocation1(String accountCodeString) {
    return new InvoiceAllocation(accountCodeString, new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null);
  }

  private static InvoiceAllocation getAllocation1WithSubAccount(String subAccountCodeString) {
    return new InvoiceAllocation("5180-9130-41700900", new Double(200), subAccountCodeString, new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null);
  }

  private static InvoiceAllocation getAllocation1(double amount) {
    return new InvoiceAllocation("5180-9130-41700900", new Double(amount), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null);
  }

  private static InvoiceAllocation getAllocation3() {
    return new InvoiceAllocation("5180-9130-11006622", new Double(400.95), "787778", new Integer(56), "testProfitCenter3", "WBS3", "ION3",
        null);
  }

  private static InvoiceAllocation getAllocation2() {
    return new InvoiceAllocation("5180-9130-90901090", new Double(-100), "89888", new Integer(44), "testProfitCenter2", "WBS2", "ION2",
        null);
  }

  private static String getEmpId() {
    return "empId334";
  }

  private static InvoiceSummary getSummary() {
    return new InvoiceSummary(new Date(), "USD", "invoice#1", new Integer(1123), new Double(500.95), new Date(), "vendor1", "1234");
  }

  private static InvoiceSummary getSummaryWithAmountVC(double amountVC) {
    return new InvoiceSummary(new Date(), "USD", "invoice#1", new Integer(1123), new Double(amountVC), new Date(), "vendor1", "1234");
  }

  private static Vendor getVendor() {
    return new Vendor("VendorType-LAW", "250099", "V-LAW");
  }

  private static Vendor getVendorWithVendorType(String vendorType) {
    return new Vendor(vendorType, "250099", "V-LAW");
  }

  private static Matter getMatter() {
    return new Matter("matter1", "practiseArea#1", "testMatter", "TST-ASBESTOS");
  }

  private static Matter getMatterWithPractiseAreaAndMatterName(String practiceArea, String matterName) {
    return new Matter("1", practiceArea, matterName, null);
  }

  private static Matter getMatterWithPractiseAreaAndGrpRef(String practiceArea, String grpRef) {
    return new Matter("1", practiceArea, "M1", grpRef);
  }

  public static InvoiceRecord getInvoiceRecordWithEmptyAllocationList() {
    return new InvoiceRecord(getSummary(), getEmpId(), getVendor(), new ArrayList(), getMatter());
  }
}