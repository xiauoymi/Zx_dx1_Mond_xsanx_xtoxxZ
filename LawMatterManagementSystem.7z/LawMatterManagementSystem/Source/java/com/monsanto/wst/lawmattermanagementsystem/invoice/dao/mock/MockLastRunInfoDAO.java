/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock;

import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.LastRunInfoDAO;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

/**
 * Filename:    $RCSfile: MockLastRunInfoDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-03 00:05:35 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockLastRunInfoDAO implements LastRunInfoDAO {

  private boolean invoked = false;

  public void updateLastSuccessfulRunDate(String lastRunInfoFileName) throws DAOException {
    invoked = true;
  }

  public Date readLastSuccessfulRunDate(String lastRunInfoFileName) throws DAOException {
    invoked = true;
    try {
      return new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_LAST_SUCCESSFUL_RUN_DATE).parse("03/03/2003");
    } catch (ParseException e) {
      return null;
    }
  }

  public boolean isInvoked() {
    return invoked;
  }
}