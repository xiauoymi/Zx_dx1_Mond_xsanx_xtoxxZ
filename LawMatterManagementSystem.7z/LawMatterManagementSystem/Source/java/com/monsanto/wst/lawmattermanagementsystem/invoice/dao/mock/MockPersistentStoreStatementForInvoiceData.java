/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.wst.lawmattermanagementsystem.mock.MockGenericResultSet;
import com.monsanto.wst.lawmattermanagementsystem.mock.MockPersistentStoreStatement;

/**
 * Filename:    $RCSfile: MockPersistentStoreStatementForInvoiceData.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-09 20:47:55 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class MockPersistentStoreStatementForInvoiceData extends MockPersistentStoreStatement {

  private String xmlDataFile;

  public MockPersistentStoreStatementForInvoiceData(String xmlDataFile) {
    this.xmlDataFile = xmlDataFile;
  }

  public PersistentStoreResultSet executeQuery() throws WrappingException {
    return new MockGenericResultSet(xmlDataFile);
  }
}