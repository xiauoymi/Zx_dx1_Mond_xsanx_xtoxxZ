/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.wst.lawmattermanagementsystem.mock.MockGenericResultSet;
import com.monsanto.wst.lawmattermanagementsystem.mock.MockPersistentStoreStatement;
import org.apache.xpath.XPathAPI;

import javax.xml.transform.TransformerException;

/**
 * Filename:    $RCSfile: MockPersistentStoreStatementForSAPLinkJoinData.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-01 19:23:36 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockPersistentStoreStatementForSAPLinkJoinData extends MockPersistentStoreStatement {

  private static final String XML_SAP_LINK_NO_JOIN_DATA = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/SAPLinkNumberJoinData.xml";
  private String sapLinkNumberString;

  public void setParam(int iPosn, String paramValue) throws WrappingException {
    sapLinkNumberString = paramValue;
  }

  public PersistentStoreResultSet executeQuery() throws WrappingException {
    try {
      return new MockGenericResultSet(XPathAPI.selectSingleNode(DOMUtil.newDocument(XML_SAP_LINK_NO_JOIN_DATA), "//Row[Column[@name='CcSAPLinkNo']=" + sapLinkNumberString + "]"));
    } catch (TransformerException e) {
      throw new WrappingException(e);
    } catch (ParserException e) {
      throw new WrappingException(e);
    }
  }
}