/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.test;

import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.EmailDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.EmailDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.mock.MockXmlSerializerBuilderReturnsSerializerThatThrowsException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: EmailDAOImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-09-09 15:46:29 $
 *
 * @author rdesai2
 * @version $Revision: 1.8 $
 */
public class EmailDAOImpl_UT extends TestCase {

  public void testGetToList() throws Exception {
    String emailListXML = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/TestEmailList.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new XmlSerializerBuilder(), LMMSConstants.ALIAS_EMAIL_LIST);
    List toList = emailDAO.getTOList();
    assertNotNull(toList);
    assertEquals(2, toList.size());
    assertEquals("user1@monsanto.com", toList.get(0));
    assertEquals("user5@monsanto.com", toList.get(1));
  }

  public void testExceptionThrown_IfEmailListFileNotFound() throws Exception {
    String emailListXML = "NonExistingEmailList.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new XmlSerializerBuilder(), LMMSConstants.ALIAS_EMAIL_LIST);
    try {
      emailDAO.getTOList();
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      emailDAO.getCCList();
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      emailDAO.getAdminList();
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetToList_ThrowsDAOException_IfDeserializationExceptionEncountered() throws Exception {
    String emailListXML = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/TestEmailList.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new MockXmlSerializerBuilderReturnsSerializerThatThrowsException(), LMMSConstants.ALIAS_EMAIL_LIST);
    try {
      emailDAO.getTOList();
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetToList_ThrowsDAOException_IfXMLParseExceptionEncountered() throws Exception {
    String emailListXML = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/TestNonWellFormedEmailList.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new XmlSerializerBuilder(), LMMSConstants.ALIAS_EMAIL_LIST);
    try {
      emailDAO.getTOList();
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetToList_ThrowsDAOException_IfEmailXMLList_ContainsIncorrectMapping() throws Exception {
    String emailListXML = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/TestEmailListWithIncorrectMapping.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new XmlSerializerBuilder(), LMMSConstants.ALIAS_EMAIL_LIST);
    try {
      emailDAO.getTOList();
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetCCList() throws Exception {
    String emailListXML = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/TestEmailList.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new XmlSerializerBuilder(), LMMSConstants.ALIAS_EMAIL_LIST);
    List ccList = emailDAO.getCCList();
    assertNotNull(ccList);
    assertEquals(3, ccList.size());
    assertEquals("user2@monsanto.com", ccList.get(0));
    assertEquals("user3@monsanto.com", ccList.get(1));
    assertEquals("user4@monsanto.com", ccList.get(2));
  }

  public void testGetCCList_ThrowsDAOException_IfDeserializationExceptionEncountered() throws Exception {
    String emailListXML = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/TestEmailList.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new MockXmlSerializerBuilderReturnsSerializerThatThrowsException(), LMMSConstants.ALIAS_EMAIL_LIST);
    try {
      emailDAO.getCCList();
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetCCList_ThrowsDAOException_IfXMLParseExceptionEncountered() throws Exception {
    String emailListXML = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/TestNonWellFormedEmailList.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new XmlSerializerBuilder(), LMMSConstants.ALIAS_EMAIL_LIST);
    try {
      emailDAO.getCCList();
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetCCList_ThrowsDAOException_IfEmailXMLList_ContainsIncorrectMapping() throws Exception {
    String emailListXML = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/TestEmailListWithIncorrectMapping.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new XmlSerializerBuilder(), LMMSConstants.ALIAS_EMAIL_LIST);
    try {
      emailDAO.getCCList();
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetAdminList() throws Exception {
    String emailListXML = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/TestEmailList.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new XmlSerializerBuilder(), LMMSConstants.ALIAS_EMAIL_LIST);
    List adminList = emailDAO.getAdminList();
    assertNotNull(adminList);
    assertEquals(2, adminList.size());
    assertEquals("admin1@monsanto.com", adminList.get(0));
    assertEquals("admin2@monsanto.com", adminList.get(1));
  }

  public void testGetAdminList_ThrowsDAOException_IfDeserializationExceptionEncountered() throws Exception {
    String emailListXML = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/TestEmailList.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new MockXmlSerializerBuilderReturnsSerializerThatThrowsException(), LMMSConstants.ALIAS_EMAIL_LIST);
    try {
      emailDAO.getAdminList();
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetAdminList_ThrowsDAOException_IfXMLParseExceptionEncountered() throws Exception {
    String emailListXML = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/TestNonWellFormedEmailList.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new XmlSerializerBuilder(), LMMSConstants.ALIAS_EMAIL_LIST);
    try {
      emailDAO.getAdminList();
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetAdminList_ThrowsDAOException_IfEmailXMLList_ContainsIncorrectMapping() throws Exception {
    String emailListXML = "com/monsanto/wst/lawmattermanagementsystem/invoice/dao/test/TestEmailListWithIncorrectMapping.xml";
    EmailDAO emailDAO = new EmailDAOImpl(emailListXML, new XmlSerializerBuilder(), LMMSConstants.ALIAS_EMAIL_LIST);
    try {
      emailDAO.getAdminList();
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }
}