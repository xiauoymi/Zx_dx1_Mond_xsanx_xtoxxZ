/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.test;

import com.monsanto.dataservices.Test.MockConnectionThrowsWrappingExceptionFromPrepareStatement;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockConnectionForInvoiceData;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockConnectionReturnsEmptyResultSetForSAPLinkData;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceAllocation;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock.MockEmailUtility;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationDAO;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.test.MockAccountCodeVerificationDAO;
import junit.framework.TestCase;

import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Filename:    $RCSfile: InvoiceDataDAOImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-12-19 21:27:04 $
 *
 * @author rdesai2
 * @version $Revision: 1.16 $
 */
public class InvoiceDataDAOImpl_UT extends TestCase {
  private AccountCodeVerificationDAO accountCodeVerificationDAO;


  protected void setUp() throws Exception {
    super.setUp();
    accountCodeVerificationDAO = new MockAccountCodeVerificationDAO();    
  }

  public void testGetInvoices_SinceLastRunDate() throws Exception {
    MockEmailUtility mockEmailUtility = new MockEmailUtility();
    InvoiceDataDAO invoiceDataDAO = new InvoiceDataDAOImpl(mockEmailUtility, accountCodeVerificationDAO);
    List invoiceRecords = invoiceDataDAO.getInvoiceRecords(false, new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2007-02-26 06:00:00"), new MockConnectionForInvoiceData(), new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2008-09-09 06:00:00"));
    assertEquals(3, invoiceRecords.size());  
    validateInvoiceNumber1((InvoiceRecord) invoiceRecords.get(0), "wbs1", "n/a");
    //validateInvoiceNumber2((InvoiceRecord) invoiceRecords.get(1), "wbs3");
  }

  public void testGetInvoices_SinceLastRunDate_SkipsCurrentInvoiceRecord_And_SendsEmailToAdmin_IfInconsistentInvoiceDataFoundInDatabase() throws Exception {
    
    MockEmailUtility mockEmailUtility = new MockEmailUtility();
    InvoiceDataDAO invoiceDataDAO = new InvoiceDataDAOImpl(mockEmailUtility, accountCodeVerificationDAO);
    invoiceDataDAO.getInvoiceRecords(false, new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2007-12-26 06:00:00"), new MockConnectionForInvoiceData(), new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2008-09-09 06:00:00"));
    assertFalse(mockEmailUtility.isSendEmailToAdminInvoked());
    //This test is modified as cost centre validation for empty allocation list is fixed
//    assertEquals("Invoice Record at Row # 2 skipped. " +
//            "Inconsistent data found while processing invoices since last run date : 2007-02-26 06:00:00. " +
//            "Error Message: Empty 'Allocation List' found while creating InvoiceRecord. " +
//            "InvoiceRecord should have atleast one allocation., " +
//            "Please see logs for more details.",
//            mockEmailUtility.getAdminMessage());
  }

  public void testGetInvoices_ForSpecificSendAPDate() throws Exception {
    InvoiceDataDAO invoiceDataDAO = new InvoiceDataDAOImpl(new MockEmailUtility(), accountCodeVerificationDAO);
    List invoiceRecords = invoiceDataDAO.getInvoiceRecords(true, new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2007-02-26 06:00:00"), new MockConnectionForInvoiceData(), new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2008-09-09 06:00:00"));
    assertEquals(2, invoiceRecords.size()); //Note: There are in all 2 records but 1 is invalid, see test below
    validateInvoiceNumber2((InvoiceRecord) invoiceRecords.get(0), "wbs3");
  }

  public void testGetInvoices_ForSpecificSendAPDate_LookUpAccountCodeForSAPLinkNumber_AccountCodeVerificationDAOImpl() throws Exception {
    InvoiceDataDAO invoiceDataDAO = new InvoiceDataDAOImpl(new MockEmailUtility(), accountCodeVerificationDAO);
    List invoiceRecords = invoiceDataDAO.getInvoiceRecords(true, new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2007-02-26 06:00:00"), new MockConnectionForInvoiceData(), new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2008-09-09 06:00:00"));
    InvoiceAllocation invoiceAllocation= (InvoiceAllocation) ((InvoiceRecord)(invoiceRecords.get(0))).getInvoiceAllocations().get(0);
    String code = invoiceAllocation.getSubAccountCode();
    assertEquals("MTL74155",code);
  }

  public void testGetInvoices_ForSpecificSendAPDate_NullSAPLinkNumber_AccountCodeVerificationDAOImpl() throws Exception {
    InvoiceDataDAO invoiceDataDAO = new InvoiceDataDAOImpl(new MockEmailUtility(), new MockAccountCodeVerificationDAONullAccountCode());
    List invoiceRecords = invoiceDataDAO.getInvoiceRecords(true, new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2007-02-26 06:00:00"), new MockConnectionForInvoiceData(), new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2008-09-09 06:00:00"));
    InvoiceAllocation invoiceAllocation= (InvoiceAllocation) ((InvoiceRecord)(invoiceRecords.get(0))).getInvoiceAllocations().get(0);
    String code = invoiceAllocation.getSubAccountCode();
    assertEquals("",code);
  }

  public void testGetInvoices_ForSpecificSendAPDate_SkipsCurrentInvoiceRecord_And_SendsEmailToAdmin_IfInconsistentInvoiceDataFoundInDatabase() throws Exception {
    MockEmailUtility mockEmailUtility = new MockEmailUtility();
    InvoiceDataDAO invoiceDataDAO = new InvoiceDataDAOImpl(mockEmailUtility, accountCodeVerificationDAO);
    invoiceDataDAO.getInvoiceRecords(true, new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2007-02-26 06:00:00"), new MockConnectionForInvoiceData(), new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2008-09-09 06:00:00"));
    assertTrue(mockEmailUtility.isSendEmailToAdminInvoked());
    assertEquals("Invoice Record at Row # 2 skipped. " +
            "Inconsistent data found while processing invoices for specific send AP date : 2007-02-26 06:00:00. " +
            "Error Message: Null 'CurrencyCode' found while creating InvoiceSummary., " +
            "Please see logs for more details.",
            mockEmailUtility.getAdminMessage());
  }

  public void testGetInvoices_PopulatesNullWBS_IfEmptyResultSetReturnedBySAPLinkData() throws Exception {
    InvoiceDataDAO invoiceDataDAO = new InvoiceDataDAOImpl(new MockEmailUtility(), accountCodeVerificationDAO);
    List invoiceRecords = invoiceDataDAO.getInvoiceRecords(true, new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2007-02-26 06:00:00"), new MockConnectionReturnsEmptyResultSetForSAPLinkData(), new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2008-09-09 06:00:00"));
    assertEquals(2, invoiceRecords.size());
    validateInvoiceNumber2((InvoiceRecord) invoiceRecords.get(0), null);
  }

  public void testGetInvoices_ThrowsDAOException_IfConnectionEncountersWrappingException() throws Exception {
    InvoiceDataDAO invoiceDataDAO = new InvoiceDataDAOImpl(new MockEmailUtility(), null);
    try {
      invoiceDataDAO.getInvoiceRecords(false, new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2007-02-26 06:00:00"), new MockConnectionThrowsWrappingExceptionFromPrepareStatement(), new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse("2008-09-09 06:00:00"));
      fail("Required exception not thrown.");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  private void validateInvoiceNumber2(InvoiceRecord invoiceRecord, String wbs1) {
    validateInvoiceSummary("2006-09-15 06:00:00", "2006-11-15 06:00:00", "USD", "248109", "114930", "38.00",
            invoiceRecord);
    //todo Undo this change after bug is fixed in Team Connect
//    validateEmployeeId("Boswell, Mark W", invoiceRecord);
    validateEmployeeId("KMHUDG", invoiceRecord);
    validateVendor("LAW", "513978", "BAKER STERCHI COWDEN AND RICE, L.L.C.", invoiceRecord);
    validateAllocation("1681.00", "3333-2222-11110878", "1366", "MTL74155", "n/a", null,
            wbs1, (InvoiceAllocation) invoiceRecord.getInvoiceAllocations().get(0), "100");
    validateMatter("2006-000667", "LITI", "ASBESTOS", "Aircraft Sale - Cessna Conquest II", invoiceRecord);
  }

  private void validateInvoiceNumber1(InvoiceRecord invoiceRecord, String wbs1, String wbs2) {
    validateInvoiceSummary("2006-08-15 06:00:00", "2006-10-15 06:00:00", "USD", "248116", "114911", "1614.08",
            invoiceRecord);
    //todo Undo this change after bug is fixed in Team Connect
//    validateEmployeeId("Price, Countess W.", invoiceRecord);
    validateEmployeeId("KMHUDG", invoiceRecord);
    validateVendor("LAW", "209402", "LEMLE AND KELLEHER, L.L.P.", invoiceRecord);
    validateAllocation("188.08", "5180-9130-21310878", "1364", "MTL74155", "n/a", "500776000",
            wbs1, (InvoiceAllocation) invoiceRecord.getInvoiceAllocations().get(0), "100");
    validateAllocation("1426.00", "5180-9130-12340878", "1365", "", "434", "657111222",
            wbs2, (InvoiceAllocation) invoiceRecord.getInvoiceAllocations().get(1), null);
    validateMatter("2001-000074", "LITI", "ASBESTOS", "Guy, Margie v. Monsanto (asbestos)", invoiceRecord);
  }

  private void validateAllocation(String allocationAmt, String accountCode, String sapLinkNo, String subAccount,
                                  String ion, String profitCenter, String wbs, InvoiceAllocation invoiceAllocation,
                                  String allocationPercentage) {
    assertEquals(new Double(allocationAmt), invoiceAllocation.getAllocationPayInLocalCurrency());
    assertEquals(accountCode, invoiceAllocation.getAccountCodeString());
    assertEquals(new Integer(sapLinkNo), invoiceAllocation.getMtcSAPLinkNumber());
    assertEquals(subAccount, invoiceAllocation.getSubAccountCode());
    assertEquals(ion, invoiceAllocation.getInternalOrderNumber());
    assertEquals(profitCenter, invoiceAllocation.getProfitCenter());
    assertEquals(wbs, invoiceAllocation.getWorkBreakdownStructure());
    assertEquals(allocationPercentage, invoiceAllocation.getAllocationPercentage());
  }

  private void validateMatter(String matterId, String practiceArea, String grpRef, String matterName, InvoiceRecord invoiceRecord) {
    assertEquals(matterId, invoiceRecord.getMatter().getMatterId());
    assertEquals(practiceArea, invoiceRecord.getMatter().getPracticeArea());
    assertEquals(grpRef, invoiceRecord.getMatter().getMatterGroupReference());
    assertEquals(matterName, invoiceRecord.getMatter().getMatterName());
  }

  private void validateVendor(String vendorType, String sapVendorId, String vendorName, InvoiceRecord invoiceRecord) {
    assertEquals(vendorType, invoiceRecord.getVendor().getVendorType());
    assertEquals(sapVendorId, invoiceRecord.getVendor().getCorpVendorId());
    assertEquals(vendorName, invoiceRecord.getVendor().getVendorShortName());
  }

  private void validateEmployeeId(String employeeId, InvoiceRecord invoiceRecord) {
    assertEquals(employeeId, invoiceRecord.getProfessionalContactEmployeeId());
  }

  private void validateInvoiceSummary(String dateOnInvoice, String dateDue, String currency, String invoiceNumber, String transactionId, String amountVC, InvoiceRecord invoiceRecord) {
    assertEquals(dateOnInvoice, DateUtil.getDate(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY, invoiceRecord.getInvoiceSummary().getDateOnInvoice()));
    assertEquals(dateDue, DateUtil.getDate(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY, invoiceRecord.getInvoiceSummary().getDateDue()));
    assertEquals(currency, invoiceRecord.getInvoiceSummary().getCurrencyCode());
    assertEquals(invoiceNumber, invoiceRecord.getInvoiceSummary().getInvoiceNumber());
    assertEquals(new Integer(transactionId), invoiceRecord.getInvoiceSummary().getTransactionId());
    assertEquals(new Double(amountVC), invoiceRecord.getInvoiceSummary().getAmountInVendorCurrency());
    assertEquals("1234",invoiceRecord.getInvoiceSummary().getInvoicePrimaryKey());
  }
}