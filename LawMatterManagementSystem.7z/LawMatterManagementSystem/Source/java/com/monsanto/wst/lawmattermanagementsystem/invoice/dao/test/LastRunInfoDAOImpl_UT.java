/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.test;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.LastRunInfoDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.LastRunInfoDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.mock.MockXmlSerializerBuilderReturnsSerializerThatThrowsException;
import com.monsanto.wst.lawmattermanagementsystem.mock.MockXmlSerializerBuilderReturnsSerializerWithInvalidXML;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import com.monsanto.Util.FileUtil;

import java.io.File;
import java.io.IOException;
import java.util.Date;

/**
 * Filename:    $RCSfile: LastRunInfoDAOImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-02 22:28:47 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class LastRunInfoDAOImpl_UT extends LMMSBaseTestCase {

  private String lastRunInfoFileName;

  protected void setUp() throws IOException {
    super.setUp();
    lastRunInfoFileName = System.getProperty(LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR) +
            File.separator +
            LMMSConstants.FILE_NAME_LAST_RUN_INFO_FILE;
  }

  protected void tearDown() throws Exception {
    deleteLastRunDateFile();
    super.tearDown();
  }

  public void testUpdateLastSuccessfulRunDate() throws Exception {
    LastRunInfoDAO lastRunInfoDAO = new LastRunInfoDAOImpl(new XmlSerializerBuilder());
    lastRunInfoDAO.updateLastSuccessfulRunDate(lastRunInfoFileName);
    assertXpathEvaluatesTo(DateUtil.getDateString(new Date()), "LastRunInfo/lastSuccessfulRunDate", DOMUtil.newDocument(lastRunInfoFileName));
  }

  public void testUpdateLastSuccessfulRunDate_ThrowsException_IfErrorEncounteredWhileConvertingLastRunInfoObjectToXML() throws Exception {
    LastRunInfoDAO lastRunInfoDAO = new LastRunInfoDAOImpl(new MockXmlSerializerBuilderReturnsSerializerThatThrowsException());
    try {
      lastRunInfoDAO.updateLastSuccessfulRunDate(lastRunInfoFileName);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testUpdateLastSuccessfulRunDate_ThrowsException_IfXMLSerializerReturnsInvalidXML() throws Exception {
    LastRunInfoDAO lastRunInfoDAO = new LastRunInfoDAOImpl(new MockXmlSerializerBuilderReturnsSerializerWithInvalidXML());
    try {
      lastRunInfoDAO.updateLastSuccessfulRunDate(lastRunInfoFileName);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testUpdateLastSuccessfulRunDate_ThrowsException_IfFileNameIsNull() throws Exception {
    LastRunInfoDAO lastRunInfoDAO = new LastRunInfoDAOImpl(new XmlSerializerBuilder());
    try {
      lastRunInfoDAO.updateLastSuccessfulRunDate(null);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testUpdateLastSuccessfulRunDate_ThrowsException_IfFileNameIsEmpty() throws Exception {
    LastRunInfoDAO lastRunInfoDAO = new LastRunInfoDAOImpl(new XmlSerializerBuilder());
    try {
      lastRunInfoDAO.updateLastSuccessfulRunDate("");
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testReadLastSuccessfulRunDate() throws Exception {
    String testDate = "07/12/1947";
    LastRunInfoDAO lastRunInfoDAO = new LastRunInfoDAOImpl(new XmlSerializerBuilder());
    FileUtil.write(lastRunInfoFileName, "<?xml version=\"1.0\" encoding=\"UTF-8\"?><LastRunInfo><lastSuccessfulRunDate>"+ testDate + "</lastSuccessfulRunDate></LastRunInfo>");
    Date lastSuccessfulRunDate = lastRunInfoDAO.readLastSuccessfulRunDate(lastRunInfoFileName);
    assertEquals(testDate, DateUtil.getDate(LMMSConstants.DATE_FORMAT_FOR_LAST_SUCCESSFUL_RUN_DATE, lastSuccessfulRunDate));
  }

  public void testReadLastSuccessfulRunDate_ThrowsException_IfFileNameArgumentIsNull() throws Exception {
    LastRunInfoDAO lastRunInfoDAO = new LastRunInfoDAOImpl(new XmlSerializerBuilder());
    try {
      lastRunInfoDAO.readLastSuccessfulRunDate(null);
      fail("Required exception not thrown.");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testReadLastSuccessfulRunDate_ThrowsException_IfFileNameArgumentIsEmpty() throws Exception {
    LastRunInfoDAO lastRunInfoDAO = new LastRunInfoDAOImpl(new XmlSerializerBuilder());
    try {
      lastRunInfoDAO.readLastSuccessfulRunDate("");
      fail("Required exception not thrown.");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testReadLastSuccessfulRunDate_ThrowsException_IfInvalidXMLFound() throws Exception {
    LastRunInfoDAO lastRunInfoDAO = new LastRunInfoDAOImpl(new XmlSerializerBuilder());
    FileUtil.write(lastRunInfoFileName, "<NonWellFormedXML</NonWellFormedXML>");
    try {
      lastRunInfoDAO.readLastSuccessfulRunDate(lastRunInfoFileName);
      fail("Required exception not thrown.");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testReadLastSuccessfulRunDate_ThrowsDAOException_IfFileNotFound() throws Exception {
    LastRunInfoDAO lastRunInfoDAO = new LastRunInfoDAOImpl(new XmlSerializerBuilder());
    try {
      lastRunInfoDAO.readLastSuccessfulRunDate(lastRunInfoFileName);
      fail("Required exception not thrown.");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testReadLastSuccessfulRunDate_ThrowsException_IfErrorEncounteredWhileConvertingXMLToLastRunInfoObject() throws Exception {
    LastRunInfoDAO lastRunInfoDAO = new LastRunInfoDAOImpl(new MockXmlSerializerBuilderReturnsSerializerThatThrowsException());
    FileUtil.write(lastRunInfoFileName, "<?xml version=\"1.0\" encoding=\"UTF-8\"?><LastRunInfo><lastSuccessfulRunDate>03/02/2007</lastSuccessfulRunDate></LastRunInfo>");
    try {
      lastRunInfoDAO.readLastSuccessfulRunDate(lastRunInfoFileName);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  private void deleteLastRunDateFile() {
    File file = new File(lastRunInfoFileName);
    if(file.exists()){
      file.delete();
    }
  }
}