/*
 MockAccountCodeVerificationDAONullAccountCode was created on Oct 26, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.dao.test;

import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeVerificationDAO;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeList;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeDaoQueryHelper;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;

/**
 * Filename:    $RCSfile: MockAccountCodeVerificationDAONullAccountCode.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 16:11:21 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class MockAccountCodeVerificationDAONullAccountCode implements AccountCodeVerificationDAO {
  public AccountCodeList getAccountCodeList() {
    return null;
  }

  public AccountCode lookUpAccountCodeForSAPLinkNumber(String sapLinkNumber) {
    return null;
  }

  public AccountCodeList lookUpAccountCodesWithValues(AccountCode accountCode,
                                                      AccountCodeDaoQueryHelper accountCodeDaoQueryHelper) {
    return new AccountCodeList();
  }
}