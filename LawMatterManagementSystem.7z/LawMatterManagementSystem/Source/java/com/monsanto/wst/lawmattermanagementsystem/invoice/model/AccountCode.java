/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model;

import com.monsanto.wst.lawmattermanagementsystem.util.CompanyCodeConverterUtil;
import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: AccountCode.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-23 22:21:25 $
 *
 * @author rdesai2
 * @version $Revision: 1.16 $
 */
public class AccountCode {

  private String companyCode;
  private String businessCode;
  private String costElement;
  private String costCenter;    //Subaccount
  private String sapComments;
  private String sapLinkNumber;
  private String profitCenter;
  private String internalOrderNumber;
  private String workBreakDownStructure;
  private String closeUid;
  private String closeDate;
  private String sapFormatValid;
  private String userId;
  private String closeAccountString;
  private String accountCode;

  public AccountCode(String companyCode, String businessCode, String costElement, String costCenter, String sapComments,
                     String sapLinkNumber, String profitCenter, String internalOrderNumber,
                     String workBreakDownStructure) {
    this.companyCode = companyCode;
    this.businessCode = businessCode;
    this.costElement = costElement;
    this.costCenter = costCenter;
    this.sapComments = sapComments;
    this.sapLinkNumber = sapLinkNumber;
    this.profitCenter = profitCenter;
    this.internalOrderNumber = internalOrderNumber;
    this.workBreakDownStructure = workBreakDownStructure;
  }

  public String getSapLinkNumber() {
    if(sapLinkNumber!=null && StringUtils.contains(sapLinkNumber,".")){
      sapLinkNumber = sapLinkNumber.substring(0,sapLinkNumber.indexOf("."));
    }
    return sapLinkNumber;
  }

  public String getCompanyCode() {
    return CompanyCodeConverterUtil.convert5114CompanyCodeTo5180(companyCode);
  }

  public String getBusinessCode() {
    return businessCode;
  }

  public String getCostElement() {
    return costElement;
  }

  public String getCostCenter() {
    return costCenter;
  }


  public String getSapComments() {
    return sapComments;
  }

  //todo check usage and remove
  public String getSAPLinkNumber() {
    return sapLinkNumber;
  }

  public void setComment(String comment) {
    this.sapComments = comment;
  }

  public String getCloseUid() {
    return closeUid;
  }

  public void setCloseUid(String closeUid) {
    this.closeUid = closeUid;
  }


  public String getProfitCenter() {
    return profitCenter;
  }

  public String getInternalOrderNumber() {
    return internalOrderNumber;
  }

  public String getWorkBreakDownStructure() {
    return workBreakDownStructure;
  }

  public void setCloseDate(String closeDate) {
    this.closeDate = closeDate;
  }

  public void setSapFormatValid(String sapFormatValid) {
    this.sapFormatValid = sapFormatValid;
  }  

  public String getSapFormatValid() {
    return sapFormatValid;
  }

  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(companyCode);
    stringBuffer.append("         ");
    stringBuffer.append(businessCode);
    stringBuffer.append("         ");
    stringBuffer.append(costCenter);
    stringBuffer.append("         ");
    stringBuffer.append(costElement);
    stringBuffer.append("         ");
    stringBuffer.append(sapLinkNumber);
    stringBuffer.append("         ");
    stringBuffer.append(sapComments);
    stringBuffer.append("         ");
    return stringBuffer.toString();
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getUserId() {
    return userId;
  }

  public String getCloseDate() {
    return closeDate;
  }

  public void closeAccount(String closeAccountString) {
    this.closeAccountString = closeAccountString;
  }

  public String getCloseAccountString() {
    return closeAccountString;
  }

  public String getCaamAccount() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(companyCode);
    stringBuffer.append("-");
    stringBuffer.append(businessCode);
    stringBuffer.append("-");
    stringBuffer.append(costElement);
    return stringBuffer.toString();
  }

  public String getCaamSubAccount() {
    return costCenter;
  }

  public String getConversionSAPFormat() {
    String conversionSAPFormat = null;

    if(sapFormatValid==null || sapFormatValid.equalsIgnoreCase("YENO_ROOT_NOOO")){
      conversionSAPFormat="N";
    }else{
      conversionSAPFormat="Y";      
    }
    return conversionSAPFormat;
  }

  public void setCostCenter(String costCenter) {
    this.costCenter = costCenter;
  }

  public String getAccountCode() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(companyCode);
    stringBuffer.append("-");
    stringBuffer.append(businessCode);
    stringBuffer.append("-");
    stringBuffer.append(costElement);
    return stringBuffer.toString();
  }
}