/*
 AllocationList was created on Feb 3, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: AllocationList.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author VRBETHI
 * @version $Revision: 1.4 $
 */
public class AllocationList {

  List allocationList = new ArrayList();

  public void addAllocation(InvoiceAllocation invoiceAllocation) throws InvalidInvoiceDataException {
    validateAllocation(invoiceAllocation);
    allocationList.add(invoiceAllocation);
  }

  public Iterator getAllocationListIterator() throws InvalidInvoiceDataRequestException {
    return allocationList.iterator();
  }

  private void validateAllocation(InvoiceAllocation invoiceAllocation) throws InvalidInvoiceDataException {
    if (invoiceAllocation == null) {
      throw new InvalidInvoiceDataException("Null allocation cannot be added.");
    }
  }
}