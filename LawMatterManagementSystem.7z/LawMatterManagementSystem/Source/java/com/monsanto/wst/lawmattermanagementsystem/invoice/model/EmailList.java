/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: EmailList.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-08 17:14:18 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class EmailList {

  private EmailInfo[] emailList;

  public EmailList(EmailInfo[] emailInfoArray) {
    this.emailList = emailInfoArray;
  }

  public List getToList() {
    List toList = new ArrayList();
    for (int i = 0; i < emailList.length; i++) {
      EmailInfo emailInfo = emailList[i];
      if (LMMSConstants.ATTENTION_TYPE_TO.equalsIgnoreCase(emailInfo.getAttentionType())) {
        toList.add(emailInfo.getEmailAddress());
      }
    }
    return toList;
  }

  public List getCCList() {
    List ccList = new ArrayList();
    for (int i = 0; i < emailList.length; i++) {
      EmailInfo emailInfo = emailList[i];
      if (LMMSConstants.ATTENTION_TYPE_CC.equalsIgnoreCase(emailInfo.getAttentionType())) {
        ccList.add(emailInfo.getEmailAddress());
      }
    }
    return ccList;
  }

  public List getAdminList() {
    List adminList = new ArrayList();
    for (int i = 0; i < emailList.length; i++) {
      EmailInfo emailInfo = emailList[i];
      if (LMMSConstants.ATTENTION_TYPE_ADMIN.equalsIgnoreCase(emailInfo.getAttentionType())) {
        adminList.add(emailInfo.getEmailAddress());
      }
    }
    return adminList;
  }
}