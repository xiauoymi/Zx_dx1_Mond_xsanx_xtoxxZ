/*
 InvalidInvoiceDataRequest was created on Feb 3, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model;

/**
 * Filename:    $RCSfile: InvalidInvoiceDataRequestException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-04 06:03:22 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class InvalidInvoiceDataRequestException extends Exception {

  public InvalidInvoiceDataRequestException(String message) {
    super(message);
  }
}