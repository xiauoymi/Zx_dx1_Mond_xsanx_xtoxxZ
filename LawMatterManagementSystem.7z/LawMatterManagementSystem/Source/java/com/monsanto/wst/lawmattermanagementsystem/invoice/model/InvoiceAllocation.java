/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

/**
 * Filename:    $RCSfile: InvoiceAllocation.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-23 22:21:25 $
 *
 * @author rdesai2
 * @version $Revision: 1.29 $
 */
public class InvoiceAllocation {

  private String accountCodeString;  //size = 20
  private Double allocationPayInLocalCurrency;  //size = 8
  private String subAccountCode;  //size = 20
  private Integer mtcSAPLinkNumber;  //size = 4
  private String profitCenter;  //size = unknown
  private String workBreakdownStructure;  //size = unknown
  private String internalOrderNumber;  //size = unknown
  private String companyCode;
  private String businessCode;
  private String costElement;
  private String allocationPercentage;

  public InvoiceAllocation(String accountCodeString, Double allocationPayInLocalCurrency, String subAccountCode,
                           Integer mtcSAPLinkNumber, String profitCenter, String workBreakdownStructure,
                           String internalOrderNumber, String allocationPercentage) {
    this.allocationPercentage = allocationPercentage;
    validateRequiredFields(accountCodeString, allocationPayInLocalCurrency);
    this.accountCodeString = accountCodeString;
    setCompanyCode();
    setBusinessCode();
    setCostElement();
    this.allocationPayInLocalCurrency = allocationPayInLocalCurrency;
    this.subAccountCode = subAccountCode;
    this.mtcSAPLinkNumber = mtcSAPLinkNumber;
    this.profitCenter = profitCenter;
    this.workBreakdownStructure = workBreakdownStructure;
    this.internalOrderNumber = internalOrderNumber;
    setAllocationPercentage(allocationPercentage);
  }

  private void setAllocationPercentage(String allocationPercentage) {
    if(allocationPercentage!=null){
      this.allocationPercentage=allocationPercentage.substring(0,allocationPercentage.indexOf('.'));
    }
  }

  public InvoiceAllocation(String companyCode, String businessCode, String costElement, Double allocationPayInLocalCurrency, String subAccountCode, Integer mtcSAPLinkNumber,
                           String profitCenter, String workBreakdownStructure, String internalOrderNumber) {
    this.accountCodeString="";
    this.companyCode=companyCode;
    this.businessCode=businessCode;
    this.costElement=costElement;
    this.allocationPayInLocalCurrency = allocationPayInLocalCurrency;
    this.subAccountCode = subAccountCode;
    this.mtcSAPLinkNumber = mtcSAPLinkNumber;
    this.profitCenter = profitCenter;
    this.workBreakdownStructure = workBreakdownStructure;
    this.internalOrderNumber = internalOrderNumber;
  }



  public String getAccountCodeString() {
    AccountCode accountCode = getAccountCode();
    return accountCode.getCompanyCode() + "-" + accountCode.getBusinessCode() + "-" + accountCode.getCostElement();
  }

  public Double getAllocationPayInLocalCurrency() {
    return allocationPayInLocalCurrency;
  }

  public String getSubAccountCode() {
    return getCostCenter();
  }

  public Integer getMtcSAPLinkNumber() {
    return mtcSAPLinkNumber;
  }

  public String getProfitCenter() {
    return profitCenter;
  }

  public String getWorkBreakdownStructure() {
    return workBreakdownStructure;
  }

  public String getInternalOrderNumber() {
    return internalOrderNumber;
  }

  public AccountCode getAccountCode() {
    return new AccountCode(getCompanyCode(),
        getBusinessCode(),
        getCostElement(),
        getCostCenter(), "", null, null, null, null);
  }

  private String getCostElement() {
    return costElement;
  }

  private String getBusinessCode() {
    return businessCode;
  }

  private String getCompanyCode() {
    return companyCode;
  }

  private String getAccountCodeSubString(int beginIndex, int endIndex, String defaultValue) {
    try {
      return accountCodeString.substring(beginIndex, endIndex);
    } catch (IndexOutOfBoundsException e) {
      return defaultValue;
    } catch (NullPointerException e) {
      return defaultValue;
    }
  }

  private String getCostCenter() {
    if (!StringUtils.isNullOrEmpty(subAccountCode)
        && !("BALSHEET".equalsIgnoreCase(subAccountCode) ||
        "N/A".equalsIgnoreCase(subAccountCode) ||
        "NOCENTER".equalsIgnoreCase(subAccountCode))) {
      return subAccountCode;
    }
//    if (!StringUtils.isNullOrEmpty(subAccountCode)
//        && !(org.apache.commons.lang.StringUtils.contains(subAccountCode, "BALSHEET") ||
//        "N/A".equalsIgnoreCase(subAccountCode) ||
//        "NOCENTER".equalsIgnoreCase(subAccountCode))) {
//      return subAccountCode;
//    }
    return "";
  }

  public String toString() {
    StringBuffer objectDetails = new StringBuffer();
    objectDetails.append(LMMSConstants.NEW_LINE_CONSTANT);
    objectDetails.append("Invoice Allocation: [")
        .append("AccountCodeString = '").append(accountCodeString).append("', ")
        .append("AllocationPayInLocalCurrency = '").append(allocationPayInLocalCurrency).append("', ")
        .append("SubAccountCode(CostElement) = '").append(subAccountCode).append("', ")
        .append("MtcSAPLinkNumber = '").append(mtcSAPLinkNumber).append("', ")
        .append("ProfitCenter = '").append(profitCenter).append("', ")
        .append("WorkBreakdownStructure = '").append(workBreakdownStructure).append("', ")
        .append("InternalOrderNumber = '").append(internalOrderNumber).append("']")
        ;
    return objectDetails.toString();
  }

  private void validateRequiredFields(String accountCodeString, Double allocationPayInLocalCurrency) {
//    validateAccountCode(accountCodeString);
    validateAllocationAmount(allocationPayInLocalCurrency);
  }

  private void validateAllocationAmount(Double allocationPayInLocalCurrency) {
    if(allocationPayInLocalCurrency == null) {
      throw new InvalidInvoiceDataException("Null 'AllocationAmount' found while creating Allocation.");
    }
  }

  private void validateAccountCode(String accountCodeString) {
    if(accountCodeString == null) {
      throw new InvalidInvoiceDataException("Null 'AccountCode' found while creating Allocation.");
    }
  }

  private void setCompanyCode() {
    this.companyCode=getAccountCodeSubString(0, 4, "");
  }

  private void setCostElement() {
    this.costElement = getAccountCodeSubString(10, 18, "");
  }

  private void setBusinessCode() {
    this.businessCode = getAccountCodeSubString(5, 9, "");
  }

  public String getAllocationPercentage() {
    return allocationPercentage;
  }
}