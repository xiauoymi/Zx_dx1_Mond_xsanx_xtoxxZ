/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

import java.util.List;

/**
 * Filename:    $RCSfile: InvoiceRecord.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-15 21:15:41 $
 *
 * @author rdesai2
 * @version $Revision: 1.10 $
 */
public class InvoiceRecord {

  //todo...if possible -> use AllocationList class

  private InvoiceSummary invoiceSummary;
  private String professionalContactEmployeeId;  //size = 8
  private Vendor vendor;
  private List invoiceAllocations;
  private Matter matter;

  public InvoiceRecord(InvoiceSummary invoiceSummary, String professionalContactEmployeeId, Vendor vendor, List invoiceAllocations, Matter matter) {
    validateRequiredFields(invoiceSummary, professionalContactEmployeeId, vendor, matter, invoiceAllocations);
    this.invoiceSummary = invoiceSummary;
    this.professionalContactEmployeeId = professionalContactEmployeeId;
    this.vendor = vendor;
    this.invoiceAllocations = invoiceAllocations;
    this.matter = matter;
  }

  private void validateRequiredFields(InvoiceSummary invoiceSummary, String professionalContactEmployeeId, Vendor vendor, Matter matter, List invoiceAllocations) throws InvalidInvoiceDataException {
    validateInvoiceSummary(invoiceSummary);
    validateEmployeeId(professionalContactEmployeeId);
    validateVendor(vendor);
    validateMatter(matter);
    validateInvoiceAllocations(invoiceAllocations);
  }

  private void validateInvoiceAllocations(List invoiceAllocations) throws InvalidInvoiceDataException {
    if(invoiceAllocations == null) {
      throw new InvalidInvoiceDataException("Null 'Allocation List' found while creating InvoiceRecord.");
    }
//    if(invoiceAllocations.size() == 0) {
//      throw new InvalidInvoiceDataException("Empty 'Allocation List' found while creating InvoiceRecord. InvoiceRecord should have atleast one allocation.");
//    }
  }

  private void validateMatter(Matter matter) throws InvalidInvoiceDataException {
    if (matter == null) {
      throw new InvalidInvoiceDataException("Null 'Matter' found while creating InvoiceRecord.");
    }
  }

  private void validateVendor(Vendor vendor) throws InvalidInvoiceDataException {
    if (vendor == null) {
      throw new InvalidInvoiceDataException("Null 'Vendor' found while creating InvoiceRecord.");
    }
  }

  private void validateEmployeeId(String professionalContactEmployeeId) throws InvalidInvoiceDataException {
    if (professionalContactEmployeeId == null) {
      throw new InvalidInvoiceDataException("Null 'EmployeeId' found while creating InvoiceRecord.");
    }
  }

  private void validateInvoiceSummary(InvoiceSummary invoiceSummary) throws InvalidInvoiceDataException {
    if (invoiceSummary == null) {
      throw new InvalidInvoiceDataException("Null 'InvoiceSummary' found while creating InvoiceRecord.");
    }
  }

  public InvoiceSummary getInvoiceSummary() {
    return invoiceSummary;
  }

  public String getProfessionalContactEmployeeId() {
    return professionalContactEmployeeId;
  }

  public Vendor getVendor() {
    return vendor;
  }

  public List getInvoiceAllocations() {
    return invoiceAllocations;
  }

  public Matter getMatter() {
    return matter;
  }


  public void setInvoiceAllocations(List invoiceAllocations) {
    this.invoiceAllocations = invoiceAllocations;
  }

  public String toString() {
    StringBuffer objectDetails = new StringBuffer();
    objectDetails.append("Invoice Details: ")
            .append(invoiceSummary.toString())
            .append(LMMSConstants.NEW_LINE_CONSTANT)
            .append("ProfessionalContactEmployeeId = '").append(professionalContactEmployeeId).append("'")
            .append(matter.toString())
            .append(vendor.toString());
    for (int i = 0; i < invoiceAllocations.size(); i++) {
      InvoiceAllocation allocation = (InvoiceAllocation) invoiceAllocations.get(i);
      objectDetails.append(allocation.toString());
    }
    return objectDetails.toString();
  }
}