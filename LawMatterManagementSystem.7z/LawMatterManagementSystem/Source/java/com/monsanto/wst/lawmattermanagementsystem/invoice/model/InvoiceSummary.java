/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;

import java.util.Date;

/**
 * Filename:    $RCSfile: InvoiceSummary.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-05 16:43:40 $
 *
 * @author rdesai2
 * @version $Revision: 1.11 $
 */
public class InvoiceSummary {

  private Date dateOnInvoice;
  private String currencyCode;  //size = 8
  private String invoiceNumber;  //size = 20
  private Integer transactionId;  //size = 4, reqd
  private Double amountInVendorCurrency; //size = 8
  private Date dateDue;
  private String vendorId;  //size = 8
  private String invoiceAcknowledged;
  private String invoicePrimaryKey;


  public InvoiceSummary(Date dateOnInvoice, String currencyCode, String invoiceNumber, Integer transactionId, Double amountInVendorCurrency, Date dateDue, String vendorId, String invoicePrimaryKey) {
    validateRequiredFields(dateOnInvoice, currencyCode, invoiceNumber, transactionId, amountInVendorCurrency, dateDue);
    this.dateOnInvoice = dateOnInvoice;
    this.currencyCode = currencyCode;
    this.invoiceNumber = invoiceNumber;
    this.transactionId = transactionId;
    this.amountInVendorCurrency = amountInVendorCurrency;
    this.dateDue = dateDue;
    this.vendorId = vendorId;
    this.invoiceAcknowledged="No";
    this.invoicePrimaryKey = invoicePrimaryKey;
  }

  public Date getDateOnInvoice() {
    return dateOnInvoice;
  }

  public String getCurrencyCode() {
    return currencyCode;
  }

  public String getInvoiceNumber() {
    return invoiceNumber;
  }

  public Integer getTransactionId() {
    return transactionId;
  }

  public Double getAmountInVendorCurrency() {
    return amountInVendorCurrency;
  }

  public Date getDateDue() {
    return dateDue;
  }

  public String getVendorId() {
    return vendorId;
  }

  public String toString() {
    StringBuffer objectDetails = new StringBuffer();
    objectDetails.append(LMMSConstants.NEW_LINE_CONSTANT);
    objectDetails.append("Invoice Summary: [")
            .append("InvoiceNumber = '").append(invoiceNumber).append("', ")
            .append("TransactionId = '").append(transactionId).append("', ")
            .append("DateOnInvoice = '").append(DateUtil.getDateString(dateOnInvoice)).append("', ")
            .append("VendorId = '").append(vendorId).append("', ")
            .append("AmountInVendorCurrency = '").append(amountInVendorCurrency).append("', ")
            .append("CurrencyCode = '").append(currencyCode).append("', ")
            .append("DateDue = '").append(DateUtil.getDateString(dateDue)).append("']")
            ;
    return objectDetails.toString();
  }

 private void validateRequiredFields(Date dateOnInvoice, String currencyCode, String invoiceNumber, Integer transactionId, Double amountInVendorCurrency, Date dateDue) {
    validateDateOnInvoice(dateOnInvoice);
    validateCurrencyCode(currencyCode);
    validateInvoiceNumber(invoiceNumber);
    validateTransactionId(transactionId);
    validateAmountVC(amountInVendorCurrency);
    validateDueDate(dateDue);
  }

  private void validateDueDate(Date dateDue) {
    if (dateDue == null) {
      throw new InvalidInvoiceDataException("Null 'DueDate' found while creating InvoiceSummary.");
    }
  }

  private void validateAmountVC(Double amountInVendorCurrency) {
    if (amountInVendorCurrency == null) {
      throw new InvalidInvoiceDataException("Null 'AmountVC' found while creating InvoiceSummary.");
    }
  }

  private void validateTransactionId(Integer transactionId) {
    if (transactionId == null) {
      throw new InvalidInvoiceDataException("Null 'TransactionId' found while creating InvoiceSummary.");
    }
  }

  private void validateInvoiceNumber(String invoiceNumber) {
    if (invoiceNumber == null) {
      throw new InvalidInvoiceDataException("Null 'InvoiceNumber' found while creating InvoiceSummary.");
    }
  }

  private void validateCurrencyCode(String currencyCode) {
    if (currencyCode == null) {
      throw new InvalidInvoiceDataException("Null 'CurrencyCode' found while creating InvoiceSummary.");
    }
  }

  private void validateDateOnInvoice(Date dateOnInvoice) {
    if (dateOnInvoice == null) {
      throw new InvalidInvoiceDataException("Null 'InvoiceDate' found while creating InvoiceSummary.");
    }
  }

  public String getInvoiceAcknowledged() {
    return invoiceAcknowledged;
  }

  public void setInvoiceAcknowledged(String invoiceAcknowledged) {
    this.invoiceAcknowledged = invoiceAcknowledged;
  }

  public String getInvoicePrimaryKey() {
    return invoicePrimaryKey;
  }
}