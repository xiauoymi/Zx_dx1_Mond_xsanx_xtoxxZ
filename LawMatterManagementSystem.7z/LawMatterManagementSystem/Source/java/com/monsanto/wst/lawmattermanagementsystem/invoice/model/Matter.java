/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

/**
 * Filename:    $RCSfile: Matter.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-27 23:07:31 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class Matter {

  private String matterId;  //size = 25
  private String practiceArea;  //size = 8
  private String matterName;  //size = 60
  private String matterGroupReference;

  public Matter(String matterId, String practiceArea, String matterName, String matterGroupReference) {
    validateRequiredFields(matterId, practiceArea, matterName);
    this.matterId = matterId;
    this.practiceArea = practiceArea;
    this.matterName = matterName;
    this.matterGroupReference = matterGroupReference;
  }

  public String getMatterId() {
    return matterId;
  }

  public String getPracticeArea() {
    return practiceArea;
  }

  public String getMatterName() {
    return matterName;
  }

  public String getMatterGroupReference() {
    return matterGroupReference;
  }

  public String toString() {
    StringBuffer objectDetails = new StringBuffer();
    objectDetails.append(LMMSConstants.NEW_LINE_CONSTANT);
    objectDetails.append("Matter: [")
            .append("MatterId = '").append(matterId).append("', ")
            .append("PracticeArea = '").append(practiceArea).append("', ")
            .append("MatterName = '").append(matterName).append("', ")
            .append("MatterGroupReference = '").append(matterGroupReference).append("']")
            ;
    return objectDetails.toString();
  }

  private void validateRequiredFields(String matterId, String practiceArea, String matterName) {
    validateMatterId(matterId);
    validatePractiseArea(practiceArea);
    validateMatterName(matterName);
  }

  private void validateMatterName(String matterName) {
    if(matterName == null){
      throw new InvalidInvoiceDataException("Null 'MatterName' found while creating Matter.");
    }
  }

  private void validatePractiseArea(String practiceArea) {
    if(practiceArea == null){
      throw new InvalidInvoiceDataException("Null 'PracticeArea' found while creating Matter.");
    }
  }

  private void validateMatterId(String matterId) {
    if(matterId == null){
      throw new InvalidInvoiceDataException("Null 'MatterId' found while creating Matter.");
    }
  }  
}