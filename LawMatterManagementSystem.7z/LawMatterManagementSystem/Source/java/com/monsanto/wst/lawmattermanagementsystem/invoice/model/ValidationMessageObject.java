/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model;

/**
 * Filename:    $RCSfile: ValidationMessageObject.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-05 22:52:00 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class ValidationMessageObject {

  public static final int MESSAGE_TYPE_EMPTY = 0;
  public static final int MESSAGE_TYPE_INFO = 1;
  public static final int MESSAGE_TYPE_ERROR = 2;

  private int messageType = 0;
  private String message = null;
  private int erroneousAllocationNumber = -1;

  private boolean oneBusinessArea;

  public ValidationMessageObject(int messageType, String errorMessage, int erroneousAllocationNumber, boolean oneBusinessArea) {
    validateArguments(errorMessage, erroneousAllocationNumber, messageType);
    this.messageType = messageType;
    this.message = errorMessage;
    this.erroneousAllocationNumber = erroneousAllocationNumber;
    this.oneBusinessArea = oneBusinessArea;
  }

  public String getMessage() {
    return message;
  }

  public int getErroneousAllocationNumber() {
    return erroneousAllocationNumber;
  }

  public boolean hasOneBusinessArea() {
    return oneBusinessArea;
  }

  public int getMessageType() {
    return messageType;
  }

  private void validateArguments(String errorMessage, int erroneousAllocationNumber, int messageType) {
    validateMessageType(messageType);
    validateErrorMessage(errorMessage);
    validateErroneousAllocationNumber(erroneousAllocationNumber);
  }

  private void validateMessageType(int messageType) {
    if(messageType < MESSAGE_TYPE_EMPTY || messageType > MESSAGE_TYPE_ERROR) {
      throw new IllegalArgumentException("ValidationMessageObject: Message type can only have values 0 (EMPTY), 1 (INFO) or 2 (ERROR).");
    }
  }

  private void validateErroneousAllocationNumber(int erroneousAllocationNumber) {
    if(erroneousAllocationNumber < 0){
      throw new IllegalArgumentException("ValidationMessageObject: ErroneousAllocationNumber cannot be negative.");
    }
  }

  private void validateErrorMessage(String errorMessage) {
    if(errorMessage == null){
      throw new IllegalArgumentException("ValidationMessageObject: Null message argument.");
    }
  }
}