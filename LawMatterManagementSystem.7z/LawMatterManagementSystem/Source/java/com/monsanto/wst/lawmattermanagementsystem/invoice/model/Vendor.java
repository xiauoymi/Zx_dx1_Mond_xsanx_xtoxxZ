/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

/**
 * Filename:    $RCSfile: Vendor.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-27 23:07:31 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class Vendor {

  private String vendorType;  //size = 8
  private String corpVendorId;  //SAP Vendor Id, size = 15
  private String vendorShortName;  //size = 30

  public Vendor(String vendorType, String corpVendorId, String vendorShortName) {
    validateRequiredFields(vendorType, corpVendorId, vendorShortName);
    this.vendorType = vendorType;
    this.corpVendorId = corpVendorId;
    this.vendorShortName = vendorShortName;
  }

  private void validateRequiredFields(String vendorType, String corpVendorId, String vendorShortName) {
    validateVendorType(vendorType);
    validateCorpVendorId(corpVendorId);
    validateVendorName(vendorShortName);
  }

  private void validateVendorName(String vendorShortName) {
    if(vendorShortName == null) {
      throw new InvalidInvoiceDataException("Null 'VendorName' found while creating Vendor.");
    }
  }

  private void validateCorpVendorId(String corpVendorId) {
    if(corpVendorId == null) {
      throw new InvalidInvoiceDataException("Null 'CorpVendorId' found while creating Vendor.");
    }
  }

  private void validateVendorType(String vendorType) {
    if(vendorType == null) {
      throw new InvalidInvoiceDataException("Null 'VendorType' found while creating Vendor.");
    }
  }

  public String getVendorType() {
    return vendorType;
  }

  public String getCorpVendorId() {
    return corpVendorId;
  }

  public String getVendorShortName() {
    return vendorShortName;
  }

  public String toString() {
    StringBuffer objectDetails = new StringBuffer();
    objectDetails.append(LMMSConstants.NEW_LINE_CONSTANT);
    objectDetails.append("Vendor: [")
            .append("CorpVendorId = '").append(corpVendorId).append("', ")
            .append("VendorType = '").append(vendorType).append("', ")
            .append("VendorName = '").append(vendorShortName).append("']")
            ;
    return objectDetails.toString();
  }
}