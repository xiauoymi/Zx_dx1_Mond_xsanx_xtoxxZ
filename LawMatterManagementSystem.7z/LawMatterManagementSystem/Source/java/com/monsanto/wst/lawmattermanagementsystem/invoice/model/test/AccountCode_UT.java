/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model.test;

import junit.framework.TestCase;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;

/**
 * Filename:    $RCSfile: AccountCode_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-23 22:21:25 $
 *
 * @author rdesai2
 * @version $Revision: 1.7 $
 */
public class AccountCode_UT extends TestCase {

  //todo this was put as a temporary fix and this needs to be removed
  /**
   * Note: As per the business requirement if the company code is "5114". It needs to be converted to "5180". This is
   * done only at one place - getAccountCode() method on InvoiceAllocation
   * @throws Exception -
   */
//  public void testGetCompanyCode_ConvertsTo5180_IfCompanyCodeIs5114() throws Exception {
//    AccountCode accountCode = new AccountCode("5114", "9130", "41700900", "SLR76387", "", null);
//    assertEquals("5180", accountCode.getCompanyCode());
//  }

  public void testGetCompanyCode_DoesNotConvertsTo5180_IfCompanyCodeIsNot5114() throws Exception {
    AccountCode accountCode = new AccountCode("Some-other-company-code", "9130", "41700900", "SLR76387", "", null, null,
        null,
        null);
    assertEquals("Some-other-company-code", accountCode.getCompanyCode());
  }

  public void testGetCompanyCode_ThrowsIllegalArgumentException_ForNullCompanyCode() throws Exception {
    try {
      AccountCode accountCode = new AccountCode(null, "9130", "41700900", "SLR76387", "", null, null, null, null);
      accountCode.getCompanyCode();
      fail("Required exception not thrown.");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testToString() throws Exception {
    AccountCode accountCode = new AccountCode("Some-other-company-code", "9130", "41700900", "SLR76387", "sap comments", "6",
        null, null, null);
    String outputString = accountCode.toString();
    assertEquals("Some-other-company-code         9130         SLR76387         41700900         6         sap comments",outputString.trim());
  }

  public void testGetSAPLinkNumber_IfSAPLinkNumberHasAPeriodStripAllDigitsAfterPeriod() throws Exception {
    AccountCode accountCode = new AccountCode("Some-other-company-code", "9130", "41700900", "SLR76387", "sap comments", "6.000000",
        null, null, null);
    String number = accountCode.getSapLinkNumber();
    assertEquals("6",number.trim());
  }

  public void testGetSAPLinkNumber_IfSAPLinkNumberHasNoPeriodDoNothing() throws Exception {
    AccountCode accountCode = new AccountCode("Some-other-company-code", "9130", "41700900", "SLR76387", "sap comments", "6",
        null, null, null);
    String number = accountCode.getSapLinkNumber();
    assertEquals("6",number.trim());
  }

  public void testAccountCodeString() throws Exception {
    AccountCode accountCode = new AccountCode("5180", "9130", "41700900", "SLR76387", "sap comments", "6",
        null, null, null);
    String accountCodeString = accountCode.getAccountCode();
    assertEquals("5180-9130-41700900",accountCodeString.trim());
  }


}