/*
AllocationList_UT was created on Feb 3, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model.test;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AllocationList;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvalidInvoiceDataException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvalidInvoiceDataRequestException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceAllocation;
import junit.framework.TestCase;

import java.util.Iterator;

/**
 * Filename:    $RCSfile: AllocationList_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-04 20:16:42 $
 *
 * @author VRBETHI
 * @version $Revision: 1.3 $
 */
public class AllocationList_UT extends TestCase {

  public void testAddAllocation_ThrowsException_ForNullAllocation() throws Exception {
    AllocationList allocationList = new AllocationList();
    try {
      allocationList.addAllocation(null);
      fail("Required exception not thrown");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testAddAllocation_ForValidInvoiceAllocation_ReturnsIteratorContainingThoseInvoices() throws Exception {
    AllocationList allocationList = new AllocationList();
    assertEquals(0, getNumberOfInvoices(allocationList));
    InvoiceAllocation invoiceAllocation = new InvoiceAllocation("account1", new Double(100.50), "sub1", new Integer(12), null, null, null,
        null);
    allocationList.addAllocation(invoiceAllocation);
    assertEquals(1, getNumberOfInvoices(allocationList));
  }

  private int getNumberOfInvoices(AllocationList allocationList) throws InvalidInvoiceDataRequestException {
    Iterator iterator = allocationList.getAllocationListIterator();
    int numberOfInvoice = 0;
    while(iterator.hasNext()){
      numberOfInvoice++;
      iterator.next();
    }
    return numberOfInvoice;
  }
}