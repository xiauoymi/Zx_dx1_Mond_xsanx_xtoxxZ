/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.EmailInfo;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.EmailList;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile: EmailList_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-08 17:14:18 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class EmailList_UT extends TestCase {

  public void testGetTOList() throws Exception {
    EmailList emailList = new EmailList(getEmailInfoArray());
    List toList = emailList.getToList();
    assertEquals(2, toList.size());
    assertEquals("testUser1@monsanto.com", toList.get(0));
    assertEquals("testUser4@monsanto.com", toList.get(1));
  }

  public void testGetCCList() throws Exception {
    EmailList emailList = new EmailList(getEmailInfoArray());
    List ccList = emailList.getCCList();
    assertEquals(2, ccList.size());
    assertEquals("testUser2@monsanto.com", ccList.get(0));
    assertEquals("testUser3@monsanto.com", ccList.get(1));
  }

  public void testGetAdminList() throws Exception {
    EmailList emailList = new EmailList(getEmailInfoArray());
    List adminList = emailList.getAdminList();
    assertEquals(2, adminList.size());
    assertEquals("admin1@monsanto.com", adminList.get(0));
    assertEquals("admin2@monsanto.com", adminList.get(1));
  }

  private EmailInfo[] getEmailInfoArray() {
    EmailInfo[] emailInfoArray = new EmailInfo[7];
    emailInfoArray[0] = (new EmailInfo("testUser1@monsanto.com", LMMSConstants.ATTENTION_TYPE_TO));
    emailInfoArray[1] = (new EmailInfo("testUser2@monsanto.com", LMMSConstants.ATTENTION_TYPE_CC));
    emailInfoArray[2] = (new EmailInfo("admin1@monsanto.com", LMMSConstants.ATTENTION_TYPE_ADMIN));
    emailInfoArray[3] = (new EmailInfo("testUser3@monsanto.com", LMMSConstants.ATTENTION_TYPE_CC));
    emailInfoArray[4] = (new EmailInfo("testUser5@monsanto.com", "invalid-attention"));  //Not added to any list
    emailInfoArray[5] = (new EmailInfo("admin2@monsanto.com", LMMSConstants.ATTENTION_TYPE_ADMIN));
    emailInfoArray[6] = (new EmailInfo("testUser4@monsanto.com", LMMSConstants.ATTENTION_TYPE_TO));
    return emailInfoArray;
  }
}