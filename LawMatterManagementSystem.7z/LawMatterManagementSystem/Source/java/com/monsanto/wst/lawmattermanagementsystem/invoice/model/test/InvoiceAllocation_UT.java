/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceAllocation;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvalidInvoiceDataException;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: InvoiceAllocation_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-23 22:21:25 $
 *
 * @author rdesai2
 * @version $Revision: 1.11 $
 */
public class InvoiceAllocation_UT extends TestCase {

  //todo...check with Mike to confirm the format for Account Code : [dddd-dddd-********] and throw InvalidInvoiceDataException on construction of InvoiceAllocation object

  public void testGetAccountCode() throws Exception {
    InvoiceAllocation allocation;
    allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), "SLR76387", null, null, null, null,
        null);
    validateAccountCode("5180", "9130", "41700900", "SLR76387", allocation.getAccountCode());
  }

  public void testGetAccountCodeWithOtherParameters() throws Exception {
    InvoiceAllocation allocation;
    allocation = new InvoiceAllocation("5180","9130","41700900", new Double(100.98), "SLR76387", null, null, null, null);
    validateAccountCode("5180", "9130", "41700900", "SLR76387", allocation.getAccountCode());
  }

  public void testGetAccountCode_ForEmptyAccountCodeAndSubAccountCode() throws Exception {
    InvoiceAllocation allocation;
    allocation = new InvoiceAllocation("", new Double(100.98), null, null, null, null, null, null);
    validateAccountCode("", "", "", "", allocation.getAccountCode());
  }

  public void testGetAccountCode_WithDifferentValuesOfAccountCode() throws Exception {
    InvoiceAllocation allocation;
    allocation = new InvoiceAllocation("0001-0001", new Double(100.98), "SLR76387", null, null, null, null, null);
    validateAccountCode("0001", "0001", "", "SLR76387", allocation.getAccountCode());
    allocation = new InvoiceAllocation("0001", new Double(100.98), "SLR76387", null, null, null, null, null);
    validateAccountCode("0001", "", "", "SLR76387", allocation.getAccountCode());
    allocation = new InvoiceAllocation("", new Double(100.98), "SLR76387", null, null, null, null, null);
    validateAccountCode("", "", "", "SLR76387", allocation.getAccountCode());
  }

  public void testGetAccountCode_WithDifferentValuesOfSubAccountCode() throws Exception {
    InvoiceAllocation allocation;
    allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), "", null, null, null, null, null);
    validateAccountCode("5180", "9130", "41700900", "", allocation.getAccountCode());
    allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), null, null, null, null, null, null);
    validateAccountCode("5180", "9130", "41700900", "", allocation.getAccountCode());
    allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), "BALSHEET", null, null, null, null,
        null);
    validateAccountCode("5180", "9130", "41700900", "", allocation.getAccountCode());
    allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), "N/A", null, null, null, null, null);
    validateAccountCode("5180", "9130", "41700900", "", allocation.getAccountCode());
    allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), "NOCENTER", null, null, null, null,
        null);
    validateAccountCode("5180", "9130", "41700900", "", allocation.getAccountCode());
  }

  private void validateAccountCode(String companyCode, String businessCode, String costElement, String subAccount, AccountCode accountCode) {
    assertNotNull(accountCode);
    assertEquals(companyCode, accountCode.getCompanyCode());
    assertEquals(businessCode, accountCode.getBusinessCode());
    assertEquals(costElement, accountCode.getCostElement());
    assertEquals(subAccount, accountCode.getCostCenter());
  }

  public void testToString() throws Exception {
    InvoiceAllocation allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), "SLR76387", new Integer(12), "profitCenter1", "WBS1", "ION1",
        null);
    assertEquals(LMMSConstants.NEW_LINE_CONSTANT + "Invoice Allocation: [AccountCodeString = '5180-9130-41700900', AllocationPayInLocalCurrency = '100.98', SubAccountCode(CostElement) = 'SLR76387', MtcSAPLinkNumber = '12', ProfitCenter = 'profitCenter1', WorkBreakdownStructure = 'WBS1', InternalOrderNumber = 'ION1']", allocation.toString());
  }

  public void testToString_WithNullValues() throws Exception {
    InvoiceAllocation allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), null, new Integer(12), null, "WBS1", "ION1",
        null);
    assertEquals(LMMSConstants.NEW_LINE_CONSTANT + "Invoice Allocation: [AccountCodeString = '5180-9130-41700900', AllocationPayInLocalCurrency = '100.98', SubAccountCode(CostElement) = 'null', MtcSAPLinkNumber = '12', ProfitCenter = 'null', WorkBreakdownStructure = 'WBS1', InternalOrderNumber = 'ION1']", allocation.toString());
  }

//  public void testConstruction_ThrowsException_IfRequiredFieldIsNull_AccountCode() throws Exception {
//    try {
//      new InvoiceAllocation(null, new Double(100.98), "SLR76387", new Integer(12), "profitCenter1", "WBS1", "ION1", null);
//      fail("Required exception not thrown.");
//    } catch (InvalidInvoiceDataException e) {
//      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
//    }
//  }

  public void testConstruction_ThrowsException_IfRequiredFieldIsNull_AllocationAmount() throws Exception {
    try {
      new InvoiceAllocation("5180-9130-41700900", null, "SLR76387", new Integer(12), "profitCenter1", "WBS1", "ION1",
          null);
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  //As per business requirement...
  public void testGetSubAccountCode_ForValidValue_ReturnsSameValue() throws Exception {
    String subAccountCode = "SLR76387";
    InvoiceAllocation allocation;
    allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), subAccountCode, null, null, null, null,
        null);
    assertEquals("SLR76387", allocation.getSubAccountCode());
  }

  //As per current business requirement...
  public void testGetSubAccountCode_ForNullValue_ReturnsEmptyString() throws Exception {
    String subAccountCode = null;
    InvoiceAllocation allocation;
    allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), subAccountCode, null, null, null, null,
        null);
    assertEquals("", allocation.getSubAccountCode());
  }

  //As per current business requirement...
  public void testGetSubAccountCode_IfValueIsBALSHEET_ReturnsEmptyString() throws Exception {
    String subAccountCode = "BALSHEET";
    InvoiceAllocation allocation;
    allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), subAccountCode, null, null, null, null,
        null);
    assertEquals("", allocation.getSubAccountCode());
  }

  //As per current business requirement...
  public void testGetSubAccountCode_IfValueIsNA_ReturnsEmptyString() throws Exception {
    String subAccountCode = "n/a";
    InvoiceAllocation allocation;
    allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), subAccountCode, null, null, null, null,
        null);
    assertEquals("", allocation.getSubAccountCode());
  }

  //As per current business requirement...
  public void testGetSubAccountCode_IfValueIsNoCenter_ReturnsEmptyString() throws Exception {
    String subAccountCode = "NoCenter";
    InvoiceAllocation allocation;
    allocation = new InvoiceAllocation("5180-9130-41700900", new Double(100.98), subAccountCode, null, null, null, null,
        null);
    assertEquals("", allocation.getSubAccountCode());
  }
}