/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockCompleteInvoiceDataDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.*;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import junit.framework.TestCase;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: InvoiceRecord_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-12-19 21:27:13 $
 *
 * @author rdesai2
 * @version $Revision: 1.13 $
 */
public class InvoiceRecord_UT extends TestCase {

  public InvoiceRecord_UT(String name) {
    super(name);
  }

  public void testConstruction_ThrowsException_IfNullRequiredFieldFound_InvoiceSummary() throws Exception {
    try {
      new InvoiceRecord(null, getEmployeeId(), getVendor(), getInvoiceAllocation(), getMatter());
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testConstruction_ThrowsException_IfNullRequiredFieldFound_EmployeeId() throws Exception {
    try {
      new InvoiceRecord(getSummary(), null, getVendor(), getInvoiceAllocation(), getMatter());
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testConstruction_ThrowsException_IfNullRequiredFieldFound_Vendor() throws Exception {
    try {
      new InvoiceRecord(getSummary(), getEmployeeId(), null, getInvoiceAllocation(), getMatter());
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testConstruction_ThrowsException_IfNullRequiredFieldFound_Matter() throws Exception {
    try {
      new InvoiceRecord(getSummary(), getEmployeeId(), getVendor(), getInvoiceAllocation(), null);
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testConstruction_ThrowsException_IfNullRequiredFieldFound_Allocations() throws Exception {
    try {
      new InvoiceRecord(getSummary(), getEmployeeId(), getVendor(), null, getMatter());
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testConstruction_ThrowsException_IfEmptyRequiredFieldFound_Allocations() throws Exception {
    try {
      InvoiceRecord invc = new InvoiceRecord(getSummary(), getEmployeeId(), getVendor(), new ArrayList(), getMatter());
      //fail("Required exception not thrown.");Modified the test<validating cost center : allocation list>
      assertNotNull(invc.getInvoiceAllocations());
      assertEquals(0,invc.getInvoiceAllocations().size());
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testToString() throws Exception {
    final MockCompleteInvoiceDataDAO mockCompleteInvoiceDataDAO = new MockCompleteInvoiceDataDAO();
    InvoiceRecord invoiceRecord = (InvoiceRecord) mockCompleteInvoiceDataDAO.getInvoiceRecords(false, null, null, null).get(0);
    assertEquals(
            "Invoice Details: " + LMMSConstants.NEW_LINE_CONSTANT +
            "Invoice Summary: [InvoiceNumber = 'invoice#1', TransactionId = '1123', DateOnInvoice = '" + DateUtil.getDateString(new Date()) + "', VendorId = 'vendor1', AmountInVendorCurrency = '500.95', CurrencyCode = 'USD', DateDue = '" + DateUtil.getDateString(new Date()) + "']" + LMMSConstants.NEW_LINE_CONSTANT +
            "ProfessionalContactEmployeeId = 'empId334'" + LMMSConstants.NEW_LINE_CONSTANT +
            "Matter: [MatterId = 'matter1', PracticeArea = 'practiseArea#1', MatterName = 'testMatter', MatterGroupReference = 'TST-ASBESTOS']" + LMMSConstants.NEW_LINE_CONSTANT +
            "Vendor: [CorpVendorId = '250099', VendorType = 'VendorType-LAW', VendorName = 'V-LAW']" + LMMSConstants.NEW_LINE_CONSTANT +
            "Invoice Allocation: [AccountCodeString = '5180-9130-41700900', AllocationPayInLocalCurrency = '200.0', SubAccountCode(CostElement) = '78787', MtcSAPLinkNumber = '2', ProfitCenter = 'testProfitCenter', WorkBreakdownStructure = 'WBS1', InternalOrderNumber = 'ION1']" + LMMSConstants.NEW_LINE_CONSTANT +
            "Invoice Allocation: [AccountCodeString = '5180-9130-90901090', AllocationPayInLocalCurrency = '-100.0', SubAccountCode(CostElement) = '89888', MtcSAPLinkNumber = '44', ProfitCenter = 'testProfitCenter2', WorkBreakdownStructure = 'WBS2', InternalOrderNumber = 'ION2']" + LMMSConstants.NEW_LINE_CONSTANT +
            "Invoice Allocation: [AccountCodeString = '5180-9130-11006622', AllocationPayInLocalCurrency = '400.95', SubAccountCode(CostElement) = '787778', MtcSAPLinkNumber = '56', ProfitCenter = 'testProfitCenter3', WorkBreakdownStructure = 'WBS3', InternalOrderNumber = 'ION3']",
            invoiceRecord.toString());
  }

  private InvoiceSummary getSummary() {
    return new InvoiceSummary(new Date(), "USD", "invoice#1", new Integer(1123), new Double(500.95), new Date(), "vendor1", "1234");
  }

  private Matter getMatter() {
    return new Matter("matter1", "practiseArea#1", "testMatter", null);
  }

  private Vendor getVendor() {
    return new Vendor("VendorType-LAW", "250099", "V-LAW");
  }

  private String getEmployeeId() {
    return "empId334";
  }

  private List getInvoiceAllocation() {
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    return invoiceAllocations;
  }
}