/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceSummary;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvalidInvoiceDataException;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Filename:    $RCSfile: InvoiceSummary_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-05 16:43:40 $
 *
 * @author rdesai2
 * @version $Revision: 1.6 $
 */
public class InvoiceSummary_UT extends TestCase {

  public InvoiceSummary_UT(String name) {
    super(name);
  }

  public void testConstruction_ThrowsException_ForNullRequiredField_DateOnInvoice() throws Exception {
    try {
      new InvoiceSummary(null, "USD", "67226666", new Integer(100), new Double(1223.067), new Date(), "LAW", "1234");
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testConstruction_ThrowsException_ForNullRequiredField_CurrencyCode() throws Exception {
    try {
      new InvoiceSummary(new Date(), null, "67226666", new Integer(100), new Double(1223.067), new Date(), "LAW", "1234");
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testConstruction_ThrowsException_ForNullRequiredField_InvoiceNumber() throws Exception {
    try {
      new InvoiceSummary(new Date(), "USD", null, new Integer(100), new Double(1223.067), new Date(), "LAW", "1234");
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testConstruction_ThrowsException_ForNullRequiredField_TransactionId() throws Exception {
    try {
      new InvoiceSummary(new Date(), "USD", "67226666", null, new Double(1223.067), new Date(), "LAW", "1234");
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testConstruction_ThrowsException_ForNullRequiredField_AmountVC() throws Exception {
    try {
      new InvoiceSummary(new Date(), "USD", "67226666", new Integer(100), null, new Date(), "LAW", "1234");
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testConstruction_ThrowsException_ForNullRequiredField_DueDate() throws Exception {
    try {
      new InvoiceSummary(new Date(), "USD", "67226666", new Integer(100), new Double(1223.067), null, "LAW", "1234");
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testToString() throws Exception {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "67226666", new Integer(100), new Double(1223.067), new Date(), "LAW", "1234");
    String expectedValue = LMMSConstants.NEW_LINE_CONSTANT +
            "Invoice Summary: [InvoiceNumber = '67226666', TransactionId = '100', DateOnInvoice = '"+ DateUtil.getDateString(new Date()) +"', VendorId = 'LAW', AmountInVendorCurrency = '1223.067', CurrencyCode = 'USD', DateDue = '" + DateUtil.getDateString(new Date()) + "']";
    assertEquals(expectedValue, invoiceSummary.toString());
  }
}