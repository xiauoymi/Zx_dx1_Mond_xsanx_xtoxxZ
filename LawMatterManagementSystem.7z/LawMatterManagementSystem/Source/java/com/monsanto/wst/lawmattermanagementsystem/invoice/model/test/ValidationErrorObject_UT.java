/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model.test;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.ValidationMessageObject;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ValidationErrorObject_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-05 22:52:00 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class ValidationErrorObject_UT extends TestCase {

  public void testCreate() throws Exception {
    ValidationMessageObject validationMessageObject = new ValidationMessageObject(0, "errorMsg1", 0, false);
    assertNotNull(validationMessageObject);
  }

  public void testCreate_ThrowsException_ForInvalidArguments() throws Exception {
    try {
      new ValidationMessageObject(0, null, 0, false);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      new ValidationMessageObject(0, "errorMessage1", -1, false);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      new ValidationMessageObject(3, "errorMessage1", 0, false);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      new ValidationMessageObject(-1, "errorMessage1", 0, false);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }
}