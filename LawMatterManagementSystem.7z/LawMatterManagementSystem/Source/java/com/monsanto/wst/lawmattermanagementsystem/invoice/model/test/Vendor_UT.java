/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.model.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.Vendor;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvalidInvoiceDataException;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: Vendor_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-27 23:07:31 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class Vendor_UT extends TestCase {

  public Vendor_UT(String name) {
    super(name);
  }

  public void testToString() throws Exception {
    Vendor vendor = new Vendor(getVendorType(), getCorpVendorId(), getVendorName());
    assertEquals(LMMSConstants.NEW_LINE_CONSTANT + "Vendor: [CorpVendorId = 'VendorId1', VendorType = 'LAW', VendorName = 'Vendor1']", vendor.toString());
  }

  public void testConstruction_ThrowsException_IfRequiredFieldIsNull_VendorType() throws Exception {
    try {
      new Vendor(null, getCorpVendorId(), getVendorName());
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testConstruction_ThrowsException_IfRequiredFieldIsNull_CorpVendorId() throws Exception {
    try {
      new Vendor(getVendorType(), null, getVendorName());
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testConstruction_ThrowsException_IfRequiredFieldIsNull_VendorName() throws Exception {
    try {
      new Vendor(getVendorType(), getCorpVendorId(), null);
      fail("Required exception not thrown.");
    } catch (InvalidInvoiceDataException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  private String getVendorName() {
    return "Vendor1";
  }

  private String getCorpVendorId() {
    return "VendorId1";
  }

  private String getVendorType() {
    return "LAW";
  }

}