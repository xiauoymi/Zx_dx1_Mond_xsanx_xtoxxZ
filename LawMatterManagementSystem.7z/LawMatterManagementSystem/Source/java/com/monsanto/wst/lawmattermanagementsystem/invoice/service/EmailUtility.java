/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

import java.util.List;

/**
 * Filename:    $RCSfile: EmailUtility.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-08 22:32:39 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public interface EmailUtility {

  void sendEmail(List customMessageLines, List attachmentList) throws ServiceException;

  void sendSuccessStatusEmail(String invoiceFileName, List attachmentList) throws ServiceException;

  void sendNoEligibleInvoicesFoundEmail(String invoiceFileName, List attachmentList) throws ServiceException;

  void sendFailureStatusEmail(List attachmentList) throws ServiceException;

  void sendEmailToAdmin(String message) throws ServiceException;
}