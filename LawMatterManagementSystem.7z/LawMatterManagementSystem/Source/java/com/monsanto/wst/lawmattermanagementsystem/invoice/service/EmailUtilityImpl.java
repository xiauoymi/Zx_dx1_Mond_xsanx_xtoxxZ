/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.EmailDAO;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailException;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailService;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: EmailUtilityImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-08 22:32:39 $
 *
 * @author rdesai2
 * @version $Revision: 1.6 $
 */
public class EmailUtilityImpl implements EmailUtility {

  private EmailService emailService;
  private EmailDAO emailDAO;

  public EmailUtilityImpl(EmailService emailService, EmailDAO emailDAO) {
    this.emailService = emailService;
    this.emailDAO = emailDAO;
  }

  public void sendEmail(List customMessageLines, List attachmentList) throws ServiceException {
    List messageLines = addCustomMessages(customMessageLines, LMMSConstants.EMAIL_CONST_DEFAULT_MESSAGE_LINES);
    sendFormattedEmail(getTOList(), getCCList(), attachmentList, messageLines);
  }

  public void sendSuccessStatusEmail(String invoiceFileName, List attachmentList) throws ServiceException {
    List customMessage = new ArrayList();
    customMessage.add(LMMSConstants.EMAIL_SUCCESS_MESSAGE_LINE + invoiceFileName);
    sendEmail(customMessage, attachmentList);
  }

  public void sendNoEligibleInvoicesFoundEmail(String invoiceFileName, List attachmentList) throws ServiceException {
    List customMessage = new ArrayList();
    customMessage.add(LMMSConstants.EMAIL_NO_ELIGIBLE_INVOICES_FOUND);
    sendEmail(customMessage, attachmentList);
  }

  public void sendFailureStatusEmail(List attachmentList) throws ServiceException {
    sendEmail(LMMSConstants.EMAIL_FAILURE_MESSAGE_LINES, attachmentList);
  }

  public void sendEmailToAdmin(String message) throws ServiceException {
    try {
      emailService.sendEmail(
              LMMSConstants.EMAIL_CONST_FROM,
              getAdminList(),
              null,
              LMMSConstants.EMAIL_CONST_SUBJECT,
              null,
              getMessageAsList(message));
    } catch (EmailException e) {
      throw new ServiceException("Error: Exception occured while sending email to Admin.", e);
    }
  }

  private List getMessageAsList(String message) {
    List messageLines = new ArrayList();
    messageLines.add(message);
    return messageLines;
  }

  private void sendFormattedEmail(List toList, List ccList, List attachmentList, List messageLines) throws ServiceException {
    try {
      emailService.sendEmail(
              LMMSConstants.EMAIL_CONST_FROM,
              toList,
              ccList,
              LMMSConstants.EMAIL_CONST_SUBJECT,
              attachmentList,
              messageLines);
    } catch (EmailException e) {
      throw new ServiceException("Error: Exception occured while sending email.", e);
    }
  }

  private List addCustomMessages(List customMessageLines, List defaultMessageLines) {
    List messageLines = new ArrayList();
    for (int i = 0; i < defaultMessageLines.size(); i++) {
      messageLines.add(defaultMessageLines.get(i));
    }
    for (int i = 0; i < customMessageLines.size(); i++) {
      messageLines.add(customMessageLines.get(i));
    }
    return messageLines;
  }

  private List getTOList() throws ServiceException {
    try {
      return emailDAO.getTOList();
    } catch (DAOException e) {
      throw new ServiceException("Error: Exception occured while reading recipient list (TO-List) for sending out email", e);
    }
  }

  private List getAdminList() throws ServiceException {
    try {
      return emailDAO.getAdminList();
    } catch (DAOException e) {
      throw new ServiceException("Error: Exception occured while reading recipient list (Admin-List) for sending out email", e);
    }
  }

  private List getCCList() throws ServiceException {
    try {
      return emailDAO.getCCList();
    } catch (DAOException e) {
      throw new ServiceException("Error: Exception occured while reading recipient list (CC-List) for sending out email", e);
    }
  }
}