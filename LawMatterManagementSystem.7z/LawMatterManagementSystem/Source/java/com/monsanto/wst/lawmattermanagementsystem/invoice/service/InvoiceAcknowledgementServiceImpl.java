package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.check.*;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Jul 29, 2008
 * Time: 1:01:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class InvoiceAcknowledgementServiceImpl implements InvoiceAcknowledgmentService{

  public String acknowledgeInvoice(InvoiceRecord invoiceRecord) {
    
    XMLBuilder xmlBuilder = new ChecksVoidsXMLBuilder();
    TeamConnectDAOFactory teamConnectDAOFactory = new TeamConnectDAOFactoryImpl();
    TeamConnectCheckDAO teamConnectDAO = teamConnectDAOFactory.getTeamConnectDAOFactoryInstance();
    ResultsProcessor resultsProcessor = new ResultsProcessorImpl();
    //Set the Acknowledgement String to Yes
    invoiceRecord.getInvoiceSummary().setInvoiceAcknowledged("Yes");
    Document document = xmlBuilder.buildInvoiceAcknowledgementXML(invoiceRecord);
    DOMUtil.outputXML(document);
    Document outputDocument = teamConnectDAO.callService(document);
    return resultsProcessor.processResultForInvoiceAcknowledgement(outputDocument);
  }
}
