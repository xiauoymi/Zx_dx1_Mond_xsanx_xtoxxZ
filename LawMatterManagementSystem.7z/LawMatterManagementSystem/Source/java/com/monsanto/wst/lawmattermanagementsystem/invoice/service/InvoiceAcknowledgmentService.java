package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Jul 29, 2008
 * Time: 10:00:35 AM
 * To change this template use File | Settings | File Templates.
 */
public interface InvoiceAcknowledgmentService {
  String acknowledgeInvoice(InvoiceRecord invoiceRecord);
}
