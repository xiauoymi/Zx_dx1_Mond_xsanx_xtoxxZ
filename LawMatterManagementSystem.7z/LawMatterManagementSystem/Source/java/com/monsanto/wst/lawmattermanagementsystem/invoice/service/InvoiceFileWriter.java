/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;

/**
 * Filename:    $RCSfile: InvoiceFileWriter.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-19 16:09:34 $
 *
 * @author rdesai2
 * @version $Revision: 1.11 $
 */
public interface InvoiceFileWriter {

  /**
   * Please Note: To use this utility, a call to initialize() has to be called first, this can be followed by one/many
   * calls to writeInvoiceRecord(). And finally a call to saveAndClose() is required.
   */

  /**
   * Initializes File(s)
   * @throws ServiceException
   * @param invoiceFileName - FileName (appended with DateTime)
   * @param queueGroupNameRandomNumber - between 0 - 999
   * @param errorReportWriter
   */
  void initialize(String invoiceFileName, int queueGroupNameRandomNumber, ErrorReportWriter errorReportWriter) throws ServiceException;

  /**
   * This is the RFBIBL00 file writer.
   * @param invoiceRecord
   * @param errorReportWriter
   * @param hasOneBusinessArea
   * @param contactName
   * @throws ServiceException
   */
  void writeInvoiceRecord(InvoiceRecord invoiceRecord, ErrorReportWriter errorReportWriter, boolean hasOneBusinessArea, String contactName) throws ServiceException;

  /**
   * This should perform save/flush/close file operations
   * @throws ServiceException
   */
  void saveAndClose() throws ServiceException;
}