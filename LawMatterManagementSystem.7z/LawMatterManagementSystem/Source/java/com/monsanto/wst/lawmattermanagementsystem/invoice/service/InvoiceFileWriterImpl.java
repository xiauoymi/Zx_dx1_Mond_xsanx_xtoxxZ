/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.*;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.DataExceedsColumnLengthException;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateFactory;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateService;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * Filename:    $RCSfile: InvoiceFileWriterImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-26 20:54:09 $
 *
 * @author rdesai2
 * @version $Revision: 1.34 $
 */
public class InvoiceFileWriterImpl implements InvoiceFileWriter {

  private FileWriter fileWriter;
  private String invoiceAbsoluteFileName;
  private boolean initialized = false;
  private XMLTemplateFactory xmlTemplateFactory;

  public InvoiceFileWriterImpl(XMLTemplateFactory xmlTemplateFactory) {
    this.xmlTemplateFactory = xmlTemplateFactory;
  }

  public void initialize(String invoiceFileName, int queueGroupNameRandomNumber, ErrorReportWriter errorReportWriter) throws ServiceException {
    String fileLocation = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
    validateFileLocation(fileLocation);
    invoiceAbsoluteFileName = fileLocation + File.separator + invoiceFileName;
    createNewInvoiceFile();
    writeFileHeader(queueGroupNameRandomNumber, errorReportWriter);
  }

  public void writeInvoiceRecord(InvoiceRecord invoiceRecord, ErrorReportWriter errorReportWriter, boolean hasOneBusinessArea, String contactName) throws ServiceException {
    validateFileInitialization();
    validateInvoiceRecord(invoiceRecord);
    StringBuffer invoiceRecordDetails = new StringBuffer();
    String recordHeaderString = getRecordHeaderFormattedString(invoiceRecord, errorReportWriter);
    if (StringUtils.isNullOrEmpty(recordHeaderString)) {
      return;
    } else {
      appendRecord(invoiceRecordDetails, recordHeaderString);
    }
    String record2131String = getRecord2131FormattedString(invoiceRecord, errorReportWriter, hasOneBusinessArea, contactName);
    if (StringUtils.isNullOrEmpty(record2131String)) {
      return;
    } else {
      appendRecord(invoiceRecordDetails, record2131String);
    }
    List invoiceAllocationList = invoiceRecord.getInvoiceAllocations();
    for (int allocationNumber = 0; allocationNumber < invoiceAllocationList.size(); allocationNumber++) {
      String record4050String = getRecord4050FormattedString(invoiceRecord, allocationNumber, errorReportWriter);
      if (StringUtils.isNullOrEmpty(record4050String)) {
        return;
      } else {
        appendRecord(invoiceRecordDetails, record4050String);
      }
    }
    writeRecord(invoiceRecordDetails.toString());
  }

  public void saveAndClose() throws ServiceException {
    validateFileInitialization();
    try {
      fileWriter.flush();
      fileWriter.close();
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException("Error saving and closing the invoice file: '" + invoiceAbsoluteFileName + "'", e);
    }
  }

  private String getRecord4050FormattedString(InvoiceRecord invoiceRecord, int allocationNumber, ErrorReportWriter errorReportWriter) throws ServiceException {
    String record4050String = null;
    try {
      record4050String = xmlTemplateFactory.getXMLTemplateFactoryInstance(LMMSConstants.XML_TEMPLATE_INVOICE_RECORD).getFormattedString(new InvoiceRecordVariable(new Record4050Strategy(invoiceRecord, allocationNumber)));
    } catch (DataExceedsColumnLengthException e) {
      String errorMessage = "Error: Invoice record skipped. Data exceeded assigned column length while writing 40/50 invoice record: " + e.getMessage();
      logErrorMessage(e, errorMessage);
      errorReportWriter.writeErrorMessageWithObject(errorMessage, invoiceRecord);
    }
    return record4050String;
  }

  private String getRecord2131FormattedString(InvoiceRecord invoiceRecord, ErrorReportWriter errorReportWriter, boolean hasOneBusinessArea, String contactName) throws ServiceException {
    String record2131String = null;
    try {
      record2131String = xmlTemplateFactory.getXMLTemplateFactoryInstance(LMMSConstants.XML_TEMPLATE_INVOICE_RECORD).getFormattedString(new InvoiceRecordVariable(new Record2131Strategy(invoiceRecord, hasOneBusinessArea, contactName)));
    } catch (DataExceedsColumnLengthException e) {
      System.out.println("e.getMessage() = " + e.getMessage());
      String errorMessage = "Error: Invoice record skipped. Data exceeded assigned column length while writing 21/31 invoice record: " + e.getMessage();
      logErrorMessage(e, errorMessage);
      errorReportWriter.writeErrorMessageWithObject(errorMessage, invoiceRecord);
    }
    return record2131String;
  }

  private void appendRecord(StringBuffer invoiceRecordDetails, String recordString) {
    invoiceRecordDetails.append(LMMSConstants.NEW_LINE_CONSTANT);
    invoiceRecordDetails.append(recordString);
  }

  private String getRecordHeaderFormattedString(InvoiceRecord invoiceRecord, ErrorReportWriter errorReportWriter) throws ServiceException {
    String recordHeaderString = null;
    try {
      recordHeaderString = xmlTemplateFactory.getXMLTemplateFactoryInstance(LMMSConstants.XML_TEMPLATE_INVOICE_RECORD_HEADER).getFormattedString(new InvoiceRecordHeaderVariable(invoiceRecord));
    } catch (DataExceedsColumnLengthException e) {
      String errorMessage = "Error: Invoice record skipped. Data exceeded assigned column length while writing invoice record header: " + e.getMessage();
      logErrorMessage(e, errorMessage);
      errorReportWriter.writeErrorMessageWithObject(errorMessage, invoiceRecord);
    }
    return recordHeaderString;
  }

  private void writeFileHeader(int queueGroupNameRandomNumber, ErrorReportWriter errorReportWriter) throws ServiceException {
    XMLTemplateService xmlTemplateService = this.xmlTemplateFactory.getXMLTemplateFactoryInstance(LMMSConstants.XML_TEMPLATE_INVOICE_FILE_HEADER);
    try {
      writeRecord(xmlTemplateService.getFormattedString(new InvoiceFileHeaderVariable(queueGroupNameRandomNumber)));
    } catch (DataExceedsColumnLengthException e) {
      String errorMessage = "Fatal Error: Data exceeded assigned column length while writing invoice file header: " + e.getMessage();
      logErrorMessage(e, errorMessage);
      errorReportWriter.writeErrorMessage(errorMessage);
      throw new ServiceException(errorMessage);
    }
  }

  private void logErrorMessage(DataExceedsColumnLengthException e, String errorMessage) {
    Logger.log(new LoggableError(e));
    Logger.log(new LoggableError(errorMessage));
  }

  private void validateFileLocation(String fileLocation) throws ServiceException {
    if (StringUtils.isNullOrEmpty(fileLocation)) {
      String errorMessage = "System param for History directory: '" + LMMSConstants.SYSTEM_PARAM_HISTORY_DIR + "' not set.";
      Logger.log(new LoggableError(errorMessage));
      throw new ServiceException(errorMessage);
    }
  }

  private void validateInvoiceRecord(InvoiceRecord invoiceRecord) throws ServiceException {
    if(invoiceRecord == null){
      saveAndClose();
      throw new ServiceException("Error while writing invoice record: Null Invoice Record found.");
    }
  }

  private void validateFileInitialization() throws ServiceException {
    if (!initialized) {
      throw new ServiceException("Error: Invoice File not initialized. [Please call initialize(), before calling this method.]");
    }
  }

  private void writeRecord(String formattedString) throws ServiceException {
    if (formattedString == null) {
      throw new ServiceException("Error: Null string returned by XMLTemplate");
    }
    try {
      fileWriter.write(formattedString);
    } catch (IOException e) {
      throw new ServiceException("Error writing to invoice file", e);
    }
  }

  private void createNewInvoiceFile() throws ServiceException {
    try {
      fileWriter = new FileWriter(new File(invoiceAbsoluteFileName));
      initialized = true;
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException("Error creating invoice file: '" + invoiceAbsoluteFileName + "'", e);
    }
  }
}