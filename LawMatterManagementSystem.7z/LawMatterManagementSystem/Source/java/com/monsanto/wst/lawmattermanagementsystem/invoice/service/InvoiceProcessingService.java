/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * Filename:    $RCSfile: InvoiceProcessingService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-09 20:30:22 $
 *
 * @author rdesai2
 * @version $Revision: 1.17 $
 */
public interface InvoiceProcessingService {

  /**
   * Reads the Invoice data from SQL Server DataMart, creates RFBIBL00 file and FTPs it over to DES (SAP) + generates
   * necessary reports
   * @return boolean - true if invoice processing done successfully, valid records found and FTP to SAP performed
   *                 - false otherwise
   *
   * Please use the following values for the file names as it is...
   *
   * @param invoiceFileName - LMMSConstants.FILE_NAME_INVOICE_RFBIBLE_FILE
   * @param summaryReportFileName - LMMSConstants.FILE_NAME_SUMMARY_REPORT_FILE
   * @param rejectionReportFileName - LMMSConstants.FILE_NAME_REJECTION_REPORT_FILE
   * @param errorReportWriter - to report unhandled error like: 1. Invoice DAO Invalid Data Error
   *                                                            2. DataExceedsColumnLength Error.
   * @param propertyList - config properties
   * @param lastRunDateFileName
   * @param connection
   * @param productionDateFileName
   * @throws com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException - for any invoice processing error
   */
  boolean processInvoices(String invoiceFileName, String summaryReportFileName, String rejectionReportFileName, ErrorReportWriter errorReportWriter, PropertyList propertyList, String lastRunDateFileName, PersistentStoreConnection connection, String productionDateFileName) throws ServiceException;
}