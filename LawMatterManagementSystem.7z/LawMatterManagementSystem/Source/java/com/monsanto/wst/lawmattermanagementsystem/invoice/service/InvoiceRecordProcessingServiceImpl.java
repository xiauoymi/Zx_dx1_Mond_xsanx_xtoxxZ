/*
 InvoiceRecordProcessingServiceImpl was created on Oct 4, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceAllocation;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: InvoiceRecordProcessingServiceImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-12 20:46:13 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class InvoiceRecordProcessingServiceImpl implements InvoiceRecordProcessingService {
  private InvoiceAllocation hundredPCTAllocation;

  public void processInvoiceRecords(InvoiceRecord invoiceRecord) {
    hundredPCTAllocation=null;
    hundredPCTAllocation = getInvoiceAllocationWithHundredPercentage(invoiceRecord);
    if(isThereAnAllocationWithHundredPercentage()){
      setInvoceAllocationsToHundredPercentAllocation(invoiceRecord);
    }
  }

  private void setInvoceAllocationsToHundredPercentAllocation(
      InvoiceRecord invoiceRecord) {
    List hundredPercentAllocationList = new ArrayList();
    hundredPercentAllocationList.add(hundredPCTAllocation);
    invoiceRecord.setInvoiceAllocations(hundredPercentAllocationList);
  }

  private boolean isThereAnAllocationWithHundredPercentage() {
    return hundredPCTAllocation!=null;
  }

  private InvoiceAllocation getInvoiceAllocationWithHundredPercentage(InvoiceRecord invoiceRecord
  ) {
    Iterator iterator = invoiceRecord.getInvoiceAllocations().iterator();
    while(iterator.hasNext()){
      InvoiceAllocation invoiceAllocation = (InvoiceAllocation) iterator.next();
      String allocationPercentage = invoiceAllocation.getAllocationPercentage();
      if(allocationPercentage!=null && allocationPercentage.equalsIgnoreCase("100")){
        hundredPCTAllocation = invoiceAllocation;
      }
    }
    return hundredPCTAllocation;
  }
}