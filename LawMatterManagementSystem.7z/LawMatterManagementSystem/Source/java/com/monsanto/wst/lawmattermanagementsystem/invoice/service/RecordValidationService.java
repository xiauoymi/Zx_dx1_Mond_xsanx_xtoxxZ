/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.ValidationMessageObject;

/**
 * Filename:    $RCSfile: RecordValidationService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-05 22:52:00 $
 *
 * @author rdesai2
 * @version $Revision: 1.6 $
 */
public interface RecordValidationService {

  /**
   * Assumptions: 1. InvoiceRecord can never be null
   *              2. Its allocationList cannot be null or empty and contains at least one allocation
   *              3. All required fields are present
   * @param invoiceRecord
   * @param environmentSpecificBoxId
   * @return
   * @throws ServiceException
   */
  ValidationMessageObject validateRecord(InvoiceRecord invoiceRecord, String environmentSpecificBoxId) throws ServiceException;
}