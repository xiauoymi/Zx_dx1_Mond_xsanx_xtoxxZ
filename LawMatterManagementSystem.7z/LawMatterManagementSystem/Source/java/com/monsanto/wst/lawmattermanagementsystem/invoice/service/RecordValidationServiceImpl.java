/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceAllocation;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.ValidationMessageObject;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationService;

import java.util.List;

/**
 * Filename:    $RCSfile: RecordValidationServiceImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-15 21:15:41 $
 *
 * @author rdesai2
 * @version $Revision: 1.8 $
 */
public class RecordValidationServiceImpl implements RecordValidationService {

  private SAPVerificationService sapVerificationService;
  private ValidationMessageObject messageObject;

  public RecordValidationServiceImpl(SAPVerificationService sapVerificationService) {
    this.sapVerificationService = sapVerificationService;
  }

  public ValidationMessageObject validateRecord(InvoiceRecord invoiceRecord, String environmentSpecificBoxId) throws ServiceException {
    //Validation needs to be done to check for Empty invoice Allocation List
    if(invoiceRecord.getInvoiceAllocations() != null && invoiceRecord.getInvoiceAllocations().size() == 0){
       return new ValidationMessageObject(ValidationMessageObject.MESSAGE_TYPE_ERROR, LMMSConstants.SAP_ERROR_MSG_EMPTY_COST_CENTER, 0, false);
    }
    if(!isAccountCodeAndProfitCenterValid(invoiceRecord.getInvoiceAllocations(), environmentSpecificBoxId)) {
     return messageObject;
    }
    if(!isInvoiceNumberLengthValid(invoiceRecord)) {
      return new ValidationMessageObject(ValidationMessageObject.MESSAGE_TYPE_ERROR, LMMSConstants.VALIDATION_ERROR_INVOICE_NUMBER_TOO_LONG, 0, false);
    }
    if(!isVendorValid(invoiceRecord)) {
      return new ValidationMessageObject(ValidationMessageObject.MESSAGE_TYPE_ERROR, LMMSConstants.SAP_ERROR_MSG_BAD_VENDOR_FOR_COMPANY, 0, false);
    }
    if(!atleastOneAllocationAmountIsNonZero(invoiceRecord.getInvoiceAllocations())) {
      return new ValidationMessageObject(ValidationMessageObject.MESSAGE_TYPE_ERROR, LMMSConstants.VALIDATION_ERROR_MSG_NO_NON_ZERO_ALLOCATION_AMOUNT_FOUND, 0, false);
    }
    return new ValidationMessageObject(ValidationMessageObject.MESSAGE_TYPE_EMPTY, LMMSConstants.EMPTY_STRING, 0, hasOneBusinessArea(invoiceRecord.getInvoiceAllocations()));
  }

  /**
   * Record Validation - Step# 1 and 2
   */
  private boolean isAccountCodeAndProfitCenterValid(List invoiceAllocationList, String environmentSpecificBoxId) throws ServiceException {
    boolean validAccountCodeAndProfitCenter = true;
    for (int allocationNumber = 0; allocationNumber < invoiceAllocationList.size(); allocationNumber++) {
      InvoiceAllocation invoiceAllocation = (InvoiceAllocation) invoiceAllocationList.get(allocationNumber);
      String aString = invoiceAllocation.getAccountCodeString();
      if(aString==null || (aString!=null && aString.length()<=2)){
        messageObject = new ValidationMessageObject(ValidationMessageObject.MESSAGE_TYPE_ERROR, LMMSConstants.SAP_ERROR_MSG_BAD_ACCOUNT_CODE, allocationNumber, false);
        validAccountCodeAndProfitCenter = false;
        break;        
      }
      String errorMessage = sapVerificationService.validateAccountCode(invoiceAllocation.getAccountCode(), environmentSpecificBoxId);
      if(!StringUtils.isNullOrEmpty(errorMessage)) {
        messageObject = new ValidationMessageObject(ValidationMessageObject.MESSAGE_TYPE_ERROR, errorMessage, allocationNumber, false);
        validAccountCodeAndProfitCenter = false;
        break;
      }
      if(StringUtils.isEmpty(invoiceAllocation.getAccountCode().getCostCenter())) {
        String profitCenter = invoiceAllocation.getProfitCenter();
        if(!sapVerificationService.validateProfitCenter(profitCenter, environmentSpecificBoxId)) {
          messageObject = new ValidationMessageObject(ValidationMessageObject.MESSAGE_TYPE_ERROR, "PROFIT CENTER: " + profitCenter + " IS NOT LEGAL IN SAP!", allocationNumber, false);
          validAccountCodeAndProfitCenter = false;
          break;
        }
      }
    }
    return validAccountCodeAndProfitCenter;
  }

  /**
   * Record Validation - Step#3
   */
  private boolean isInvoiceNumberLengthValid(InvoiceRecord invoiceRecord) {
    return invoiceRecord.getInvoiceSummary().getInvoiceNumber().length() <= LMMSConstants.MAX_LENGTH_INVOICE_NUMBER;
  }

  /**
   * Record Validation - Step#4
   */
  private boolean isVendorValid(InvoiceRecord invoiceRecord) throws ServiceException {
    InvoiceAllocation invoiceAllocation = (InvoiceAllocation) invoiceRecord.getInvoiceAllocations().get(0);
    return sapVerificationService.validateVendor(invoiceAllocation.getAccountCode().getCompanyCode(), invoiceRecord.getVendor().getCorpVendorId());
  }

  /**
   * Record Validation - Step#5
   */
  private boolean atleastOneAllocationAmountIsNonZero(List invoiceAllocationList) {
    for (int allocationNumber = 0; allocationNumber < invoiceAllocationList.size(); allocationNumber++) {
      InvoiceAllocation allocation = (InvoiceAllocation) invoiceAllocationList.get(allocationNumber);
      double allocationAmount = allocation.getAllocationPayInLocalCurrency().doubleValue();
      if(allocationAmount != 0) {
        return true;
      }
    }
    return false;
  }

  /**
   * Record Validation - Step#6
   */
  private boolean hasOneBusinessArea(List invoiceAllocationList) {
    String firstBusinessArea = null;
    for (int allocationNumber = 0; allocationNumber < invoiceAllocationList.size(); allocationNumber++) {
      String businessCode = ((InvoiceAllocation) invoiceAllocationList.get(allocationNumber)).getAccountCode().getBusinessCode();
      if (allocationNumber == 0) {
        firstBusinessArea = businessCode;
      } else {
        if(!firstBusinessArea.equalsIgnoreCase(businessCode)) {
          return false;
        }
      }
    }
    return true;
  }
}