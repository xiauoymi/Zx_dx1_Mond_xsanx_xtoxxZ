/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;

/**
 * Filename:    $RCSfile: RejectionReportWriter.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.8 $
 */
public interface RejectionReportWriter {

  /**
   * Please Note: To use this utility, a call to initialize() has to be called first, this can be followed by one/many
   * calls to writeRejectionRecord(). And finally a call to saveAndClose() is required.
   */

  /**
   * Initializes File(s)
   * @param rejectionReportFile
   * @param errorReportWriter - to log DECL error (DataExceedsColumnLength)
   */
  void initialize(String rejectionReportFile, ErrorReportWriter errorReportWriter) throws ServiceException;

  /**
   * This is the Rejection report file writer.
   * Note: The file should be initialized before a call to write();
   * @param invoiceRecord
   * @param errorMessage
   * @param erroneousAllocationNumber
   * @param errorReportWriter - to log DECL error
   * @throws ServiceException
   */
  void writeRejectionRecord(InvoiceRecord invoiceRecord, String errorMessage, int erroneousAllocationNumber, ErrorReportWriter errorReportWriter) throws ServiceException;

  /**
   * This should perform save/flush/close file operations [only after the file is initialized]
   * @throws ServiceException
   */
  void saveAndClose() throws ServiceException;
}