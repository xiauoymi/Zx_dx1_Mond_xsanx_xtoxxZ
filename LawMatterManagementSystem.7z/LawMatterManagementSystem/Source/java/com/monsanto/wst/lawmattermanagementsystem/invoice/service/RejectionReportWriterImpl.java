/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.RejectionReportRecordVariable;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.ReportHeaderVariable;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.DataExceedsColumnLengthException;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateFactory;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateService;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

/**
 * Filename:    $RCSfile: RejectionReportWriterImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:34:22 $
 *
 * @author rdesai2
 * @version $Revision: 1.7 $
 */
public class RejectionReportWriterImpl implements RejectionReportWriter {

  private FileWriter fileWriter;
  private String rejectionAbsoluteFileName;
  private boolean initialized = false;
  private XMLTemplateFactory xmlTemplateFactory;

  public RejectionReportWriterImpl(XMLTemplateFactory xmlTemplateFactory) {
    this.xmlTemplateFactory = xmlTemplateFactory;
  }

  public void initialize(String rejectionFileName, ErrorReportWriter errorReportWriter) throws ServiceException {
    String fileLocation = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
    validateFileLocation(fileLocation);
    createNewRejectionFile(fileLocation, rejectionFileName);
    writeFileHeader(errorReportWriter);
    XMLTemplateService xmlTemplateService = xmlTemplateFactory.getXMLTemplateFactoryInstance(LMMSConstants.XML_TEMPLATE_REJECTION_REPORT_RECORD);
    writeFieldNameTitleLine(xmlTemplateService, errorReportWriter);
    writeFieldNameSeperatorLine(xmlTemplateService, errorReportWriter);
  }

  public void writeRejectionRecord(InvoiceRecord invoiceRecord, String errorMessage, int erroneousAllocationNumber, ErrorReportWriter errorReportWriter) throws ServiceException {
    validateFileInitialization();
    XMLTemplateService xmlTemplateService = xmlTemplateFactory.getXMLTemplateFactoryInstance(LMMSConstants.XML_TEMPLATE_REJECTION_REPORT_RECORD);
    String rejectionRecordString = getRejectionRecordString(xmlTemplateService, invoiceRecord, errorMessage, erroneousAllocationNumber, errorReportWriter);
    if (!StringUtils.isNullOrEmpty(rejectionRecordString)) {
      writeRecord(LMMSConstants.NEW_LINE_CONSTANT);
      writeRecord(rejectionRecordString);
    }
  }

  private String getRejectionRecordString(XMLTemplateService xmlTemplateService, InvoiceRecord invoiceRecord, String errorMessage, int erroneousAllocationNumber, ErrorReportWriter errorReportWriter) throws ServiceException {
    String rejectionRecordString = null;
    try {
      rejectionRecordString = xmlTemplateService.getFormattedString(new RejectionReportRecordVariable(invoiceRecord, errorMessage, erroneousAllocationNumber));
    } catch (DataExceedsColumnLengthException e) {
      String errorMessageForDECL = "Error: Data exceeded allocated column length while writing Rejection Report record: " + e.getMessage();
      logError(errorMessageForDECL, e);
      errorReportWriter.writeErrorMessageWithObject(errorMessageForDECL, invoiceRecord);
    }
    return rejectionRecordString;
  }

  public void saveAndClose() throws ServiceException {
    validateFileInitialization();
    try {
      fileWriter.flush();
      fileWriter.close();
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException("Error saving and closing the rejection file: '" + rejectionAbsoluteFileName + "'", e);
    }
  }

  private void writeFieldNameSeperatorLine(XMLTemplateService xmlTemplateService, ErrorReportWriter errorReportWriter) throws ServiceException {
    String seperatorLine = getSeperatorLineString(xmlTemplateService, errorReportWriter);
    if (!StringUtils.isNullOrEmpty(seperatorLine)) {
      writeRecord(LMMSConstants.NEW_LINE_CONSTANT);
      writeRecord(seperatorLine);
    }
  }

  private String getSeperatorLineString(XMLTemplateService xmlTemplateService, ErrorReportWriter errorReportWriter) throws ServiceException {
    String seperatorLine = null;
    try {
      seperatorLine = xmlTemplateService.getFormattedString(new RejectionReportRecordVariable("-----------", "--------", "---------", "-----------", "-------", "-------------", "-------------"));
    } catch (DataExceedsColumnLengthException e) {
      String errorMessage = "Error: Data exceeded allocated column length while writing Rejection Report seperator line: " + e.getMessage();
      logError(errorMessage, e);
      errorReportWriter.writeErrorMessage(errorMessage);
    }
    return seperatorLine;
  }

  private void writeFieldNameTitleLine(XMLTemplateService xmlTemplateService, ErrorReportWriter errorReportWriter) throws ServiceException {
    String titleString = getTitleString(xmlTemplateService, errorReportWriter);
    if (!StringUtils.isNullOrEmpty(titleString) ) {
      writeRecord(LMMSConstants.NEW_LINE_CONSTANT);
      writeRecord(titleString);
    }
  }

  private String getTitleString(XMLTemplateService xmlTemplateService, ErrorReportWriter errorReportWriter) throws ServiceException {
    String titleString = null;
    try {
      titleString = xmlTemplateService.getFormattedString(new RejectionReportRecordVariable("Inv. Number", "Tran. Id", "Inv. Date", "Acc. Number", "Subacc.", "Corp. Ven. ID", "Error Message"));
    } catch (DataExceedsColumnLengthException e) {
      String errorMessage = "Error: Data exceeded allocated column length while writing Rejection Report record title: " + e.getMessage();
      logError(errorMessage, e);
      errorReportWriter.writeErrorMessage(errorMessage);
    }
    return titleString;
  }

  private void writeFileHeader(ErrorReportWriter errorReportWriter) throws ServiceException {
    writeFileHeader(LMMSConstants.REJECTION_REPORT_NAME, new Date(), errorReportWriter);
    writeRecord(LMMSConstants.NEW_LINE_CONSTANT);
  }

  private void createNewRejectionFile(String fileLocation, String rejectionFileName) throws ServiceException {
    rejectionAbsoluteFileName = fileLocation + File.separator + rejectionFileName;
    try {
      fileWriter = new FileWriter(new File(rejectionAbsoluteFileName));
      initialized = true;
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException("Error creating rejection file: '" + rejectionAbsoluteFileName + "'", e);
    }
  }

  private void validateFileInitialization() throws ServiceException {
    if (!initialized) {
      throw new ServiceException("Error: Rejection Report File not initialized. [Please call initialize(), before calling this method.]");
    }
  }

  private void validateFileLocation(String fileLocation) throws ServiceException {
    if (StringUtils.isNullOrEmpty(fileLocation)) {
      String errorMessage = "System param for History directory: '" + LMMSConstants.SYSTEM_PARAM_HISTORY_DIR + "' not set.";
      Logger.log(new LoggableError(errorMessage));
      throw new ServiceException(errorMessage);
    }
  }

  private void writeFileHeader(String reportName, Date reportDate, ErrorReportWriter errorReportWriter) throws ServiceException {
    XMLTemplateService xmlTemplateService = this.xmlTemplateFactory.getXMLTemplateFactoryInstance(LMMSConstants.XML_TEMPLATE_REPORT_HEADER);
    try {
      writeRecord(xmlTemplateService.getFormattedString(new ReportHeaderVariable(reportName, reportDate)));
    } catch (DataExceedsColumnLengthException e) {
      String errorMessage = "Error: Data exceeded allocated column length while writing Rejection Report header: " + e.getMessage();
      logError(errorMessage, e);
      errorReportWriter.writeErrorMessage(errorMessage);
    }
  }

  private void logError(String errorMessage, Exception e) {
    Logger.log(new LoggableError(errorMessage));
    Logger.log(new LoggableError(e));
  }

  private void writeRecord(String formattedString) throws ServiceException {
    if (formattedString == null) {
      throw new ServiceException("Error: Null string returned by XMLTemplate");
    }
    try {
      fileWriter.write(formattedString);
    } catch (IOException e) {
      throw new ServiceException("Error writing to rejection file", e);
    }
  }
}