/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.ftp.exception.FTPException;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.FTPService;

import java.io.File;

/**
 * Filename:    $RCSfile: SAPFTPUtilityImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-06-25 21:59:37 $
 *
 * @author rdesai2
 * @version $Revision: 1.9 $
 */
public class SAPFTPUtilityImpl implements SAPFTPUtility {

  private FTPService ftpService;

  public SAPFTPUtilityImpl(FTPService ftpService) {
    this.ftpService = ftpService;
  }

  public void ftpInvoiceFileToSAP(String invoiceFileName) throws ServiceException {
//    boolean doFTP = Boolean.getBoolean("FTP");
//    System.out.println("doFTP = " + doFTP);
//    System.out.println("invoiceFileName = " + invoiceFileName);
//    if(doFTP){
      String historyDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
      validateHistoryDirSystemParam(historyDir);
      boolean uploadSuccessful = uploadFile(historyDir, invoiceFileName);
      validateIfFTPWasSuccessful(uploadSuccessful);
//      System.out.println("FTP Done");
//    }else{
//      System.out.println("FTP not Done");
//    }
  }

  private void validateIfFTPWasSuccessful(boolean uploadSuccessful) throws ServiceException {
    if(!uploadSuccessful){
      String errorMessage = "Severe Error: Unable to upload invoice file to SAP using FTPService.";
      Logger.log(new LoggableError(errorMessage));
      throw new ServiceException(errorMessage);
    }
  }

  private boolean uploadFile(String historyDir, String invoiceFileName) throws ServiceException {
    try {
      return ftpService.upload(historyDir + File.separator + invoiceFileName, LMMSConstants.FTP_REMOTE_SUB_DIR_INBOUND);
    } catch (FTPException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException("Severe Error: Exception occured while uploading invoice file to SAP using FTPService. " +
          "Error Message: " + e.getMessage(), e);
    }
  }

  private void validateHistoryDirSystemParam(String historyDir) throws ServiceException {
    if(StringUtils.isNullOrEmpty(historyDir)){
      String errorMessage = "System param for History directory: '" + LMMSConstants.SYSTEM_PARAM_HISTORY_DIR + "' not set.";
      Logger.log(new LoggableError(errorMessage));
      throw new ServiceException(errorMessage);
    }
  }
}