/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;

/**
 * Filename:    $RCSfile: SummaryReportWriter.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:01 $
 *
 * @author rdesai2
 * @version $Revision: 1.5 $
 */
public interface SummaryReportWriter {

  /**
   * Please Note: To use this utility, a call to initialize() has to be called first, this can be followed by one/many
   * calls to writeInvoiceRecordSummary(). And finally a call to saveAndClose() is required.
   */

  /**
   * Initializes File(s)
   * @param summaryReportFile
   * @param errorReportWriter - to log DECL (DataExceedsColumnLength) Exceptions
   */
  void initialize(String summaryReportFile, ErrorReportWriter errorReportWriter) throws ServiceException;

  /**
   * This is the Invoice Summary Report File writer.
   * Note: The file should be initialized before a call to write();
   * @param invoiceRecord
   * @param errorReportWriter - to log DECL Exceptions
   */
  void writeInvoiceRecordSummary(InvoiceRecord invoiceRecord, ErrorReportWriter errorReportWriter) throws ServiceException;

  /**
   * This should perform save/flush/close file operations [only after file is initialized]
   * @throws com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException
   * @param errorReportWriter
   */
  void saveAndClose(ErrorReportWriter errorReportWriter) throws ServiceException;
}