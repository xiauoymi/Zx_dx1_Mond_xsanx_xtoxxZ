/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.ReportHeaderVariable;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.SummaryReportFooterVariable;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.SummaryReportRecordVariable;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.DataExceedsColumnLengthException;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateFactory;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateService;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Date;

/**
 * Filename:    $RCSfile: SummaryReportWriterImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:34:22 $
 *
 * @author rdesai2
 * @version $Revision: 1.11 $
 */
public class SummaryReportWriterImpl implements SummaryReportWriter {

  private FileWriter fileWriter;
  private String summaryAbsoluteFileName;
  private boolean initialized = false;
  private XMLTemplateFactory xmlTemplateFactory;
  private int totalInvoices = 0;
  private double totalInvoiceAmount = 0;

  public SummaryReportWriterImpl(XMLTemplateFactory xmlTemplateFactory) {
    this.xmlTemplateFactory = xmlTemplateFactory;
  }

  public void initialize(String summaryFileName, ErrorReportWriter errorReportWriter) throws ServiceException {
    String fileLocation = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
    validateFileLocation(fileLocation);
    summaryAbsoluteFileName = fileLocation + File.separator + summaryFileName;
    createNewFile();
    initialized = true;
    writeFileHeader(LMMSConstants.SUMMARY_REPORT_NAME, new Date(), errorReportWriter);
    writeRecord(LMMSConstants.NEW_LINE_CONSTANT);
    writeSummaryReportTitleLine(errorReportWriter);
    writeSummaryReportSeparatorLine(errorReportWriter);
  }

  public void writeInvoiceRecordSummary(InvoiceRecord invoiceRecord, ErrorReportWriter errorReportWriter) throws ServiceException {
    validateFileInitialization();
    String formattedRecordString = getSummaryRecord(invoiceRecord, errorReportWriter);
    if (!StringUtils.isNullOrEmpty(formattedRecordString)) {
      writeRecord(LMMSConstants.NEW_LINE_CONSTANT + formattedRecordString);
    }
    updateTotalInvoiceAndAmount(invoiceRecord.getInvoiceSummary().getAmountInVendorCurrency());
  }

  private String getSummaryRecord(InvoiceRecord invoiceRecord, ErrorReportWriter errorReportWriter) throws ServiceException {
    String formattedRecordString = null;
    try {
      formattedRecordString = getRecordTemplate().getFormattedString(new SummaryReportRecordVariable(invoiceRecord));
    } catch (DataExceedsColumnLengthException e) {
      String errorMessage = "Error: Invoice record skipped from being written to Summary report. Data exceeded allocated column length for Summary record: " + e.getMessage();
      logMessage(errorMessage, e);
      errorReportWriter.writeErrorMessageWithObject(errorMessage, invoiceRecord);
    }
    return formattedRecordString;
  }

  public void saveAndClose(ErrorReportWriter errorReportWriter) throws ServiceException {
    validateFileInitialization();
    writeTotalInvoiceSummary(errorReportWriter);
    writeTotalInvoiceAmountSummary(errorReportWriter);
    flushAndClose();
  }

  private void writeSummaryReportSeparatorLine(ErrorReportWriter errorReportWriter) throws ServiceException {
    writeRecord(LMMSConstants.NEW_LINE_CONSTANT);
    try {
      writeRecord(getRecordTemplate().getFormattedString(new SummaryReportRecordVariable("----------", "-------------------", "-------------", "------------", "-----------")));
    } catch (DataExceedsColumnLengthException e) {
      String errorMessage = "Error: Invoice record skipped from being written to Summary report. Data exceeded allocated column length for Summary record: " + e.getMessage();
      logMessage(errorMessage, e);
      errorReportWriter.writeErrorMessageWithObject(errorMessage, null);
    }
  }

  private void writeSummaryReportTitleLine(ErrorReportWriter errorReportWriter) throws ServiceException {
    writeRecord(LMMSConstants.NEW_LINE_CONSTANT);
    try {
      writeRecord(getRecordTemplate().getFormattedString(new SummaryReportRecordVariable("Vendor Num", "Vendor Name", "Invoice #", "Invoice Date", "Invoice AMT")));
    } catch (DataExceedsColumnLengthException e) {
      String errorMessage = "Error: Invoice record skipped from being written to Summary report. Data exceeded allocated column length for Summary record: " + e.getMessage();
      logMessage(errorMessage, e);
      errorReportWriter.writeErrorMessageWithObject(errorMessage, null);
    }
  }

  private void writeTotalInvoiceAmountSummary(ErrorReportWriter errorReportWriter) throws ServiceException {
    String totalInvoiceSummary = getTotalInvoiceAmount(errorReportWriter);
    if (!StringUtils.isNullOrEmpty(totalInvoiceSummary)) {
      writeRecord(LMMSConstants.NEW_LINE_CONSTANT);
      writeRecord(LMMSConstants.NEW_LINE_CONSTANT);
      writeRecord(totalInvoiceSummary);
    }
  }

  private String getTotalInvoiceAmount(ErrorReportWriter errorReportWriter) throws ServiceException {
    String totalInvoiceSummary = null;
    try {
      totalInvoiceSummary = getFooterTemplate().getFormattedString(new SummaryReportFooterVariable(LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICE_AMOUNT, new DecimalFormat(LMMSConstants.PATTERN_AMOUNT).format(totalInvoiceAmount)));
    } catch (DataExceedsColumnLengthException e) {
      String errorMessage = "Error: Invoice Summary for total invoice amount skipped. Data exceeded allocated column length: " + e.getMessage();
      logMessage(errorMessage, e);
      errorReportWriter.writeErrorMessage(errorMessage);
    }
    return totalInvoiceSummary;
  }

  private void writeTotalInvoiceSummary(ErrorReportWriter errorReportWriter) throws ServiceException {
    String totalAmount = getTotalInvoices(errorReportWriter);
    if (!StringUtils.isNullOrEmpty(totalAmount)) {
      writeRecord(LMMSConstants.NEW_LINE_CONSTANT);
      writeRecord(LMMSConstants.NEW_LINE_CONSTANT);
      writeRecord(totalAmount);
    }
  }

  private String getTotalInvoices(ErrorReportWriter errorReportWriter) throws ServiceException {
    String totalAmount = null;
    try {
      totalAmount = getFooterTemplate().getFormattedString(new SummaryReportFooterVariable(LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICES, String.valueOf(totalInvoices)));
    } catch (DataExceedsColumnLengthException e) {
      String errorMessage = "Error: Invoice Summary for total invoices skipped. Data exceeded allocated column length: " + e.getMessage();
      logMessage(errorMessage, e);
      errorReportWriter.writeErrorMessage(errorMessage);
    }
    return totalAmount;
  }

  private void flushAndClose() throws ServiceException {
    try {
      fileWriter.flush();
      fileWriter.close();
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException("Error saving and closing the summary file: '" + summaryAbsoluteFileName + "'", e);
    }
  }

  private XMLTemplateService getFooterTemplate() {
    return xmlTemplateFactory.getXMLTemplateFactoryInstance(LMMSConstants.XML_TEMPLATE_SUMMARY_FOOTER);
  }

  private void updateTotalInvoiceAndAmount(Double amountInVendorCurrency) {
    totalInvoiceAmount += amountInVendorCurrency.doubleValue();
    totalInvoices++;
  }

  private XMLTemplateService getRecordTemplate() {
    return xmlTemplateFactory.getXMLTemplateFactoryInstance(LMMSConstants.XML_TEMPLATE_SUMMARY_REPORT_RECORD);
  }

  private void validateFileInitialization() throws ServiceException {
    if (!initialized) {
      throw new ServiceException("Error: Summary Report File not initialized. [Please call initialize(), before calling this method.]");
    }
  }

  private void validateFileLocation(String fileLocation) throws ServiceException {
    if (StringUtils.isNullOrEmpty(fileLocation)) {
      String errorMessage = "System param for History directory: '" + LMMSConstants.SYSTEM_PARAM_HISTORY_DIR + "' not set.";
      Logger.log(new LoggableError(errorMessage));
      throw new ServiceException(errorMessage);
    }
  }

  private void writeFileHeader(String reportName, Date reportDate, ErrorReportWriter errorReportWriter) throws ServiceException {
    XMLTemplateService xmlTemplateService = this.xmlTemplateFactory.getXMLTemplateFactoryInstance(LMMSConstants.XML_TEMPLATE_REPORT_HEADER);
    try {
      String formattedString = xmlTemplateService.getFormattedString(new ReportHeaderVariable(reportName, reportDate));
      writeRecord(formattedString);
    } catch (DataExceedsColumnLengthException e) {
      String errorMessage = "Error: Data exceeded allocated column length while writing Invoice Summary Report Header: " + e.getMessage();
      logMessage(errorMessage, e);
      errorReportWriter.writeErrorMessage(errorMessage);
    }
  }

  private void logMessage(String errorMessage, Exception e) {
    Logger.log(new LoggableError(errorMessage));
    Logger.log(new LoggableError(e));
  }

  private void writeRecord(String formattedString) throws ServiceException {
    validateFormattedString(formattedString);
    try {
      fileWriter.write(formattedString);
    } catch (IOException e) {
      throw new ServiceException("Error writing to summary file", e);
    }
  }

  private void validateFormattedString(String formattedString) throws ServiceException {
    if (formattedString == null) {
      throw new ServiceException("Error: Null string returned by XMLTemplate");
    }
  }

  private void createNewFile() throws ServiceException {
    try {
      fileWriter = new FileWriter(new File(summaryAbsoluteFileName));
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException("Error creating summary file: '" + summaryAbsoluteFileName + "'", e);
    }
  }
}