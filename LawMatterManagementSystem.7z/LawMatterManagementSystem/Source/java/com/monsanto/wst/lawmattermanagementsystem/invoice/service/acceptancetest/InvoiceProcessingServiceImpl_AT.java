/*
InvoiceProcessingServiceImpl_AT was created on Feb 1, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.acceptancetest;

import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriterImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockCompleteInvoiceDataDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockLastRunInfoDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockInvoiceDataWithEmptyAllocationDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.*;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock.MockRecordValidationService;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock.MockSAPFTPUtility;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock.MockInvoiceRecordProcessingService;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.mock.MockPropertyFileReaderReturnsRepostSpecificDateAsTrue;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.wst.lawmattermanagementsystem.servlet.LawMatterManagementSystemLoggerFactory;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateFactory;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateFactoryImpl;
import org.apache.commons.lang.StringUtils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Calendar;

/**
 * Filename:    $RCSfile: InvoiceProcessingServiceImpl_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-15 21:15:41 $
 *
 * @author vrbethi
 * @version $Revision: 1.15 $
 */
public class InvoiceProcessingServiceImpl_AT extends LMMSBaseTestCase{

  protected void setUp() throws IOException {
    super.setUp();
    try {
      new LawMatterManagementSystemLoggerFactory().setupLogging();
    } catch (LogRegistrationException e) {
      //Ignore Error.
    }
  }

  protected void tearDown() throws Exception {
    super.tearDown();
  }

  public void testInvoiceProcessing_testRFBIBILOutputFile() throws Exception {

    String rfbiblfilename = LMMSConstants.FILE_NAME_INVOICE_RFBIBLE_FILE;
    String rejectionReport = LMMSConstants.FILE_NAME_REJECTION_REPORT_FILE;
    String summaryReport = LMMSConstants.FILE_NAME_SUMMARY_REPORT_FILE;
    String errorFile = LMMSConstants.FILE_NAME_ERROR_REPORT_FILE;

    String rfbibilFilePath = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR)+rfbiblfilename;
    XMLTemplateFactory xmlTemplateFactory = new XMLTemplateFactoryImpl();
    InvoiceProcessingService invoiceProcessing = new InvoiceProcessingServiceImpl(
            new MockCompleteInvoiceDataDAO(),new MockRecordValidationService(),new InvoiceFileWriterImpl(xmlTemplateFactory),
            new SummaryReportWriterImpl(xmlTemplateFactory),
            new RejectionReportWriterImpl(xmlTemplateFactory), new MockSAPFTPUtility(), new MockLastRunInfoDAO(),
            new MockInvoiceRecordProcessingService(),new InvoiceAcknowledgementServiceImpl());//TODO pass the appropriate invoice acknowledgement

    ErrorReportWriter errorReportWriter = new ErrorReportWriterImpl();

    PropertyList propertyList = new MockPropertyFileReaderReturnsRepostSpecificDateAsTrue().readPropertyFile(null);

    errorReportWriter.initialize(errorFile);
    boolean b = invoiceProcessing.processInvoices(rfbiblfilename,summaryReport,rejectionReport,errorReportWriter, propertyList, null, null, null);
    errorReportWriter.saveAndClose();

    String[] strings = readFileHeader(rfbibilFilePath);
    assertTrue("File Header invalid",validateFileHeader(strings[0]));
    assertTrue("Invoice Header invalid",validateInvoiceHeader(strings[1]));
    System.out.println("strings = " + strings[2]);
    System.out.println("strings = " + strings[3]);
    System.out.println("strings = " + strings[4]);
    //todo For rfbibil for each invoice record there should be the follwoing
    //todo n records will have n record headers
    //todo n record 21 or 31
    //todo n * m record 40 or 50 m is number of allocations
    assertTrue(b);
  }

  /**
   * Method to Test Processing of Invoice Records with empty allocation list
   * @throws Exception
   */
  public void testInvoiceProcessing_WithEmptyAllocationList() throws Exception {

    String rfbiblfilename = LMMSConstants.FILE_NAME_INVOICE_RFBIBLE_FILE;
    String rejectionReport = LMMSConstants.FILE_NAME_REJECTION_REPORT_FILE;
    String summaryReport = LMMSConstants.FILE_NAME_SUMMARY_REPORT_FILE;
    String errorFile = LMMSConstants.FILE_NAME_ERROR_REPORT_FILE;

    String rfbibilFilePath = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR)+rfbiblfilename;
    XMLTemplateFactory xmlTemplateFactory = new XMLTemplateFactoryImpl();
    InvoiceProcessingService invoiceProcessing = new InvoiceProcessingServiceImpl(
            new MockInvoiceDataWithEmptyAllocationDAO(),new RecordValidationServiceImpl(null),new InvoiceFileWriterImpl(xmlTemplateFactory),
            new SummaryReportWriterImpl(xmlTemplateFactory),
            new RejectionReportWriterImpl(xmlTemplateFactory), new MockSAPFTPUtility(), new MockLastRunInfoDAO(),
            new MockInvoiceRecordProcessingService(),new InvoiceAcknowledgementServiceImpl());//TODO pass the appropriate invoice acknowledgement

    ErrorReportWriter errorReportWriter = new ErrorReportWriterImpl();

    PropertyList propertyList = new MockPropertyFileReaderReturnsRepostSpecificDateAsTrue().readPropertyFile(null);

    errorReportWriter.initialize(errorFile);
    boolean b = invoiceProcessing.processInvoices(rfbiblfilename,summaryReport,rejectionReport,errorReportWriter, propertyList, null, null, null);
    errorReportWriter.saveAndClose();
    assertFalse(b);
  }

  private boolean validateInvoiceHeader(String string) {
    char[] invoiceHeader = string.toCharArray();
    if(invoiceHeader[0]!='1'){
      return false;
    }
    if(!StringUtils.containsOnly("FB01",new String(invoiceHeader,1,4))){
      return false;
    }
    //TODO THIS IS THE INVOICE DATE
//    if(!StringUtils.containsOnly("DOCUMENTDATE",new String(invoiceHeader,5,7))){
//      return false;
//    }
    if(!StringUtils.containsOnly("CP",new String(invoiceHeader,13,2))){
      return false;
    }
    if(!StringUtils.containsOnly("5180",new String(invoiceHeader,15,4))){
      return false;
    }
    if(!StringUtils.containsOnly("~      ",new String(invoiceHeader,19,7))){
      return false;
    }
    if(!StringUtils.containsOnly("USD",new String(invoiceHeader,29,4))){
      return false;
    }
    if(!StringUtils.containsOnly("~        ",new String(invoiceHeader,34,9))){
      return false;
    }
    if(!StringUtils.containsOnly("~        ",new String(invoiceHeader,44,9))){
      return false;
    }
    if(!StringUtils.containsOnly("~        ",new String(invoiceHeader,54,7))){
      return false;
    }
    //todo invoice number
//    if(!StringUtils.containsOnly("57018173",new String(invoiceHeader,63,15))){
//      return false;
//    }
    if(!StringUtils.containsOnly("~",new String(invoiceHeader,78,15))){
      return false;
    }
//    //todo practice area
//    if(!StringUtils.containsOnly("BENE",new String(invoiceHeader,94,24))){
//      return false;
//    }
    if(!StringUtils.containsOnly("~  ",new String(invoiceHeader,119,3))){
      return false;
    }
    if(!StringUtils.containsOnly("~      ",new String(invoiceHeader,123,7))){
      return false;
    }
    if(!StringUtils.containsOnly("~    ",new String(invoiceHeader,131,5))){
      return false;
    }
    if(!StringUtils.containsOnly("~",new String(invoiceHeader,137,1))){
      return false;
    }
    if(!StringUtils.containsOnly("~        ",new String(invoiceHeader,138,9))){
      return false;
    }
    if(!StringUtils.containsOnly("~                                       ",new String(invoiceHeader,148,40))){
      return false;
    }
    if(!StringUtils.containsOnly("~      ",new String(invoiceHeader,188,7))){
      return false;
    }
    if(!StringUtils.containsOnly("~",new String(invoiceHeader,196,1))){
      return false;
    }

    return true;
  }

  private boolean validateFileHeader(String string) {
    char[] hearder = string.toCharArray();
    if(hearder[0]!='0'){
      return false;
    }
    if(!StringUtils.containsOnly("CPINV",new String(hearder,1,5))){
      return false;
    }
    if(!StringUtils.containsOnly(DateUtil.getDate("MMdd",Calendar.getInstance().getTime()),new String(hearder,6,4))){
      return false;
    }
    if(!StringUtils.containsOnly("EDIUSER    ",new String(hearder,16,11))){
      return false;
    }
    if(!StringUtils.containsOnly("       ",new String(hearder,28,8))){
      return false;
    }
    if(hearder[36]!='X'){
      return false;
    }
    if(hearder[37]!='~'){
      return false;
    }
    return true;
  }

  private String[] readFileHeader(String rfbibilFilePath) throws IOException {
    String output[]=new String[50];
    BufferedReader in = new BufferedReader(new FileReader(rfbibilFilePath));
    String str;
    int count=0;
    while ((str = in.readLine()) != null) {
      output[count]=str;
      count++;
    }
    in.close();
    return output;
  }
}