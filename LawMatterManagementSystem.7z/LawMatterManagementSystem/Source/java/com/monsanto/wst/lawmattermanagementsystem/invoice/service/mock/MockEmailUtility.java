/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.EmailUtility;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: MockEmailUtility.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-08 22:32:39 $
 *
 * @author rdesai2
 * @version $Revision: 1.9 $
 */
public class MockEmailUtility implements EmailUtility {

  private List customMessageLines;
  private List attachmentList;
  private boolean sendSuccessStatusEmailInvoked = false;
  private boolean sendFailureStatusEmailInvoked = false;
  private boolean sendEmailToAdminInvoked = false;
  private boolean sendNoEligibleInvoicesEmailInvoked;
  private String adminMessage;

  public void sendEmail(List customMessageLines, List attachmentList) throws ServiceException {
    resetPreviousServiceCallData();
    this.customMessageLines = customMessageLines;
    this.attachmentList = attachmentList;
  }

  public void sendSuccessStatusEmail(String invoiceFileName, List attachmentList) throws ServiceException {
    resetPreviousServiceCallData();
    this.attachmentList = attachmentList;
    sendSuccessStatusEmailInvoked = true;
  }

  public void sendNoEligibleInvoicesFoundEmail(String invoiceFileName, List attachmentList) throws ServiceException {
    resetPreviousServiceCallData();
    this.attachmentList = attachmentList;
    sendNoEligibleInvoicesEmailInvoked = true;
  }

  public void sendFailureStatusEmail(List attachmentList) throws ServiceException {
    resetPreviousServiceCallData();
    this.attachmentList = attachmentList;
    sendFailureStatusEmailInvoked = true;
  }

  public void sendEmailToAdmin(String message) throws ServiceException {
    resetPreviousServiceCallData();
    this.adminMessage = message;
    sendEmailToAdminInvoked = true;
  }

  public List getCustomMessageLines() {
    return customMessageLines;
  }

  public List getAttachmentList() {
    return attachmentList;
  }

  public boolean isSendSuccessStatusEmailInvoked() {
    return sendSuccessStatusEmailInvoked;
  }

  public boolean isSendFailureStatusEmailInvoked() {
    return sendFailureStatusEmailInvoked;
  }

  public boolean isSendEmailToAdminInvoked() {
    return sendEmailToAdminInvoked;
  }

  public boolean isSendNoEligibleInvoicesEmailInvoked() {
    return sendNoEligibleInvoicesEmailInvoked;
  }

  public String getAdminMessage() {
    return adminMessage;
  }

  private void resetPreviousServiceCallData() {
    this.customMessageLines = new ArrayList();
    this.attachmentList = new ArrayList();
    this.sendSuccessStatusEmailInvoked = false;
    this.sendFailureStatusEmailInvoked = false;
    this.sendEmailToAdminInvoked = false;
    this.adminMessage = null;
  }
}