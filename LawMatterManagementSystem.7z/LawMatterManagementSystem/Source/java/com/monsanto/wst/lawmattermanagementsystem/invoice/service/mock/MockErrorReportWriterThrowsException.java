/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.config.ConfigReader;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;

/**
 * Filename:    $RCSfile: MockErrorReportWriterThrowsException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-20 22:51:16 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class MockErrorReportWriterThrowsException implements ErrorReportWriter {

  public void initialize(String errorFileName) throws ServiceException {
    throw new ServiceException("Mock Error Report Exception during initialize...");
  }

  public void writeErrorMessage(String errorMessage) throws ServiceException {
    throw new ServiceException("Mock Error Report Exception during writeErrorMessage...");
  }

  public void writeErrorMessageWithObject(String errorMessage, Object object) throws ServiceException {
    throw new ServiceException("Mock Error Report Exception during writeErrorMessageWithObject...");
  }

  public void writeConnectionParams(ConfigReader configReader) throws ServiceException {
  }

  public void writeConfigProperties(PropertyList propertyList) throws ServiceException {
  }

  public void saveAndClose() throws ServiceException {
    throw new ServiceException("Mock Error Report Exception during save and close...");
  }
}