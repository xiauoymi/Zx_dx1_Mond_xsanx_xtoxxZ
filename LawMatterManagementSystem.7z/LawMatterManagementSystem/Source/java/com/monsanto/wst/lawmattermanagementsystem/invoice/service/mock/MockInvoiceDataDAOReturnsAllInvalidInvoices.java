/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.InvoiceDataDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceSummary;
import com.monsanto.dataservices.PersistentStoreConnection;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;

/**
 * Filename:    $RCSfile: MockInvoiceDataDAOReturnsAllInvalidInvoices.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-12-22 15:04:39 $
 *
 * @author rdesai2
 * @version $Revision: 1.7 $
 */
public class MockInvoiceDataDAOReturnsAllInvalidInvoices implements InvoiceDataDAO {

  public List getInvoiceRecords(boolean isRepostForSpecificDateRequired, Date repostDate, PersistentStoreConnection persistentStoreConnection, Date productionDate) throws DAOException {
    ArrayList arrayList = new ArrayList();
    arrayList.add(new InvoiceRecord(new InvoiceSummary(null, null, "Invoice #1", null, null, null, null, "1234"), null, null, null, null));
    arrayList.add(new InvoiceRecord(new InvoiceSummary(null, null, "Invoice #3", null, null, null, null, "1234"), null, null, null, null));
    return arrayList;
  }

  public List getInvoiceRecordsForInvoiceNumber(String invoiceNumber, PersistentStoreConnection connection) throws DAOException {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }
}