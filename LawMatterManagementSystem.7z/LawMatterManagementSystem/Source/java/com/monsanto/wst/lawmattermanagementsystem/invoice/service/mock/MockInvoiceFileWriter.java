/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceFileWriter;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockInvoiceFileWriter.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-21 18:56:47 $
 *
 * @author rdesai2
 * @version $Revision: 1.11 $
 */
public class MockInvoiceFileWriter implements InvoiceFileWriter {

  private List listOfAllValidRecordsRequested = new ArrayList();
  private boolean saveAndCloseCalled = false;
  private int initializeCount = 0;
  private String contactName;

  public void initialize(String invoiceFileName, int queueGroupNameRandomNumber, ErrorReportWriter errorReportWriter) throws ServiceException {
    initializeCount++;
  }

  public void writeInvoiceRecord(InvoiceRecord invoiceRecord, ErrorReportWriter errorReportWriter, boolean hasOneBusinessArea, String contactName) throws ServiceException {
    this.contactName = contactName;
    if (initializeCount == 1) {
      listOfAllValidRecordsRequested.add(invoiceRecord.getInvoiceSummary().getInvoiceNumber());
    }
  }

  public void saveAndClose() throws ServiceException {
    if (initializeCount == 1) {
      saveAndCloseCalled = true;
    }
  }

  public String getInvoiceRequested(int index){
    return (String) listOfAllValidRecordsRequested.get(index);
  }

  public boolean saveAndCloseInvoked() {
    return saveAndCloseCalled;
  }

  public int numberOfTimesInitializeCalled() {
    return initializeCount;
  }

  public String getContactNameSent() {
    return contactName;
  }
}