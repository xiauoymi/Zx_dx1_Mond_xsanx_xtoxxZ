/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceProcessingService;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockInvoiceDataDAO;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.dataservices.PersistentStoreConnection;

import java.util.*;

/**
 * Filename:    $RCSfile: MockInvoiceProcessingService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-02-10 20:14:07 $
 *
 * @author rdesai2
 * @version $Revision: 1.12 $
 */
public class MockInvoiceProcessingService implements InvoiceProcessingService {

  private boolean processInvoicesInvoked = false;
  private PropertyList propertyList;
  private Map invoiceProcessMap = new HashMap();
  
  public boolean processInvoices(String invoiceFileName, String summaryReportFileName, String rejectionReportFileName, ErrorReportWriter errorReportWriter, PropertyList propertyList, String lastRunDateFileName, PersistentStoreConnection connection, String productionDateFileName) throws ServiceException {
    this.propertyList = propertyList;
    List invoiceRecordList = new ArrayList();
    try {
      invoiceRecordList = new MockInvoiceDataDAO().getInvoiceRecords(false,null,null,null);
      Iterator itr = invoiceRecordList.iterator();
      while(itr.hasNext()){
        processInvoice((InvoiceRecord)itr.next(),"","");
      }
    } catch (DAOException e) {
      e.printStackTrace();  
    }
    processInvoicesInvoked = true;
    return true;
  }

  public boolean isProcessInvoicesInvoked() {
    return processInvoicesInvoked;
  }

  public PropertyList getPropertyList() {
    return propertyList;
  }

  public boolean isInvoiceSentToSAP(String invoiceNumber){
    return "true".equalsIgnoreCase(invoiceProcessMap.get(invoiceNumber).toString());
  }

  public void processInvoice(InvoiceRecord invoiceRecord, String environmentSpecificBoxId, String contactName){
      if(invoiceRecord != null){
          if(invoiceRecord.getInvoiceSummary().getInvoiceNumber().equalsIgnoreCase("Invoice #3") ||
              invoiceRecord.getInvoiceSummary().getInvoiceNumber().equalsIgnoreCase("Invoice #4")){
              invoiceProcessMap.put(invoiceRecord.getInvoiceSummary().getInvoiceNumber(),"false");
          }else{
              invoiceProcessMap.put(invoiceRecord.getInvoiceSummary().getInvoiceNumber(),"true");            
          }
      }
  }
}