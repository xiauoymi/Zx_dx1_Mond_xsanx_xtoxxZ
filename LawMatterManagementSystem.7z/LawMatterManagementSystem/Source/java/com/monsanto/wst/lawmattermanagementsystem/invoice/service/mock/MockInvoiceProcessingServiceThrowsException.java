/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceProcessingService;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * Filename:    $RCSfile: MockInvoiceProcessingServiceThrowsException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-09 20:30:22 $
 *
 * @author rdesai2
 * @version $Revision: 1.8 $
 */
public class MockInvoiceProcessingServiceThrowsException implements InvoiceProcessingService {

  public boolean processInvoices(String invoiceFileName, String summaryReportFileName, String rejectionReportFileName, ErrorReportWriter errorReportWriter, PropertyList propertyList, String lastRunDateFileName, PersistentStoreConnection connection, String productionDateFileName) throws ServiceException {
    throw new ServiceException("Mock process invoices error...");
  }
}