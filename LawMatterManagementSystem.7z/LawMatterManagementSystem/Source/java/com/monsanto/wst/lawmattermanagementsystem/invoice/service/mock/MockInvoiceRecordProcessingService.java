/*
 MockInvoiceRecordProcessingService was created on Oct 4, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceRecordProcessingService;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;

/**
 * Filename:    $RCSfile: MockInvoiceRecordProcessingService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-04 21:57:27 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class MockInvoiceRecordProcessingService implements InvoiceRecordProcessingService {
  private boolean wasInvoked = false;

  public void processInvoiceRecords(InvoiceRecord invoiceRecord) {
    wasInvoked=true;
  }

  public boolean isInvoked() {
    return wasInvoked;
  }
}