/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.ValidationMessageObject;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.RecordValidationService;

/**
 * Filename:    $RCSfile: MockRecordValidationService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-06 00:04:00 $
 *
 * @author rdesai2
 * @version $Revision: 1.6 $
 */
public class MockRecordValidationService implements RecordValidationService {

  public ValidationMessageObject validateRecord(InvoiceRecord invoiceRecord, String environmentSpecificBoxId) {
    if(invoiceRecord.getInvoiceSummary().getInvoiceNumber().equalsIgnoreCase("Invoice #1")){
      return new ValidationMessageObject(ValidationMessageObject.MESSAGE_TYPE_ERROR, "error message 1", 0, false);
    }
    if(invoiceRecord.getInvoiceSummary().getInvoiceNumber().equalsIgnoreCase("Invoice #3")){
      return new ValidationMessageObject(ValidationMessageObject.MESSAGE_TYPE_ERROR, "error 2", 0, false);
    }
    return new ValidationMessageObject(ValidationMessageObject.MESSAGE_TYPE_EMPTY, "", 0, false);
  }
}