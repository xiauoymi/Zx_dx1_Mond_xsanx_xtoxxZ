/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.RejectionReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockRejectionReportWriter.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-06 00:49:24 $
 *
 * @author rdesai2
 * @version $Revision: 1.11 $
 */
public class MockRejectionReportWriter implements RejectionReportWriter {

  public List listOfAllInvalidRecordsRequested = new ArrayList();
  public List listOfAllInvoiceNumberWithNoProfitCenter = new ArrayList();
  public List listOfAllAllocationsWithNoProfitCenter = new ArrayList();
  private boolean saveAndCloseCalled = false;
  private int numberOfTimesInitializeCalled = 0;

  public void initialize(String rejectionReportFile, ErrorReportWriter errorReportWriter) throws ServiceException {
    numberOfTimesInitializeCalled++;
  }

  public void writeRejectionRecord(InvoiceRecord invoiceRecord, String errorMessage, int erroneousAllocationNumber, ErrorReportWriter errorReportWriter) {
    if (numberOfTimesInitializeCalled == 1) {
      if (LMMSConstants.INFO_MSG_NO_PROFIT_CENTER_FOUND.equalsIgnoreCase(errorMessage)) {
        listOfAllInvoiceNumberWithNoProfitCenter.add(invoiceRecord.getInvoiceSummary().getInvoiceNumber());
        listOfAllAllocationsWithNoProfitCenter.add(String.valueOf(erroneousAllocationNumber));
      } else {
        listOfAllInvalidRecordsRequested.add(invoiceRecord.getInvoiceSummary().getInvoiceNumber());
      }
    }
  }

  public void saveAndClose() throws ServiceException {
    if (numberOfTimesInitializeCalled == 1) {
      saveAndCloseCalled = true;
    }
  }

  public String getInvoiceRequested(int index) {
    return (String) listOfAllInvalidRecordsRequested.get(index);
  }

  public boolean saveAndCloseInvoked() {
    return saveAndCloseCalled;
  }

  public int numberOfTimesInitializeCalled() {
    return numberOfTimesInitializeCalled;
  }


  public List getListOfAllInvoiceNumberWithNoProfitCenter() {
    return listOfAllInvoiceNumberWithNoProfitCenter;
  }

  public List getListOfAllAllocationsWithNoProfitCenter() {
    return listOfAllAllocationsWithNoProfitCenter;
  }
}