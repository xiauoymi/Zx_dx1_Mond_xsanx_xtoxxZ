/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.errorreporter.ErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.SummaryReportWriter;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockSummaryReportWriter.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.6 $
 */
public class MockSummaryReportWriter implements SummaryReportWriter {

  private List listOfAllValidRecordsRequested = new ArrayList();
  private boolean saveAndCloseCalled = false;
  private int numberOfTimesInitialized = 0;

  public void initialize(String summaryReportFile, ErrorReportWriter errorReportWriter) throws ServiceException{
    numberOfTimesInitialized++;
  }

  public void writeInvoiceRecordSummary(InvoiceRecord invoiceRecord, ErrorReportWriter errorReportWriter) throws ServiceException {
    if (numberOfTimesInitialized == 1) {
      listOfAllValidRecordsRequested.add(invoiceRecord.getInvoiceSummary().getInvoiceNumber());
    }
  }

  public void saveAndClose(ErrorReportWriter errorReportWriter) throws ServiceException {
    if (numberOfTimesInitialized == 1) {
      saveAndCloseCalled = true;
    }
  }

  public String getInvoiceRequested(int index){
    return (String) listOfAllValidRecordsRequested.get(index);
  }

  public boolean saveAndCloseInvoked() {
    return saveAndCloseCalled;
  }

  public int numberOfTimesInitializeCalled() {
    return numberOfTimesInitialized;
  }
}