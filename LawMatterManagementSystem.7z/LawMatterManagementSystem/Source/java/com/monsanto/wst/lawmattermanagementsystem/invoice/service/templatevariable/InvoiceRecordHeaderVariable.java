/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceAllocation;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;

/**
 * Filename:    $RCSfile: InvoiceRecordHeaderVariable.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-26 20:54:09 $
 *
 * @author rdesai2
 * @version $Revision: 1.5 $
 */
public class InvoiceRecordHeaderVariable {

  private InvoiceRecord invoiceRecord;

  public InvoiceRecordHeaderVariable(InvoiceRecord invoiceRecord) {
    this.invoiceRecord = invoiceRecord;
  }

  public String getDocumentDate() {
    if(invoiceRecord != null) {
      return DateUtil.getDate("MMddyyyy", invoiceRecord.getInvoiceSummary().getDateOnInvoice());
    }
    return org.apache.commons.lang.StringUtils.EMPTY;
  }

  public String getCompanyCode() {
    if(invoiceRecord != null) {
      return ((InvoiceAllocation) invoiceRecord.getInvoiceAllocations().get(0)).getAccountCode().getCompanyCode();
    }
    return org.apache.commons.lang.StringUtils.EMPTY;
  }

  public String getInvoiceNumber() {
    if(invoiceRecord != null) {
      return invoiceRecord.getInvoiceSummary().getInvoiceNumber();
    }
    return org.apache.commons.lang.StringUtils.EMPTY;
  }

  public String getPracticeArea() {
    if (invoiceRecord != null) {
      return invoiceRecord.getMatter().getPracticeArea();
    }
    return org.apache.commons.lang.StringUtils.EMPTY;
  }
}