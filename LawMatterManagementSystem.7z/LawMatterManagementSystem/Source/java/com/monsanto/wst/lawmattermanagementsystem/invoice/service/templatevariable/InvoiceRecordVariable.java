/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable;

/**
 * Filename:    $RCSfile: InvoiceRecordVariable.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-01-30 23:42:20 $
 *
 * Note: This the "context" (as in Strategy Pattern UML diagram) that uses RecordTemplate "Strategy" (which could ideally
 * be of type 21/31 or 40/50)
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class InvoiceRecordVariable {

  private RecordTemplateStrategy recordTemplateStrategy;

  public InvoiceRecordVariable(RecordTemplateStrategy recordTemplateStrategy) {
    this.recordTemplateStrategy = recordTemplateStrategy;
  }

  public String getPostingKey() {
    return recordTemplateStrategy.getPostingKey();
  }

  public String getAmountInDocumentCurrency() {
    return recordTemplateStrategy.getAmountInDocumentCurrency();
  }

  public String getTaxCode() {
    return recordTemplateStrategy.getTaxCode();
  }

  public String getBusinessArea() {
    return recordTemplateStrategy.getBusinessArea();
  }

  public String getCostCenter() {
    return recordTemplateStrategy.getCostCenter();
  }

  public String getOrderNumber() {
    return recordTemplateStrategy.getOrderNumber();
  }

  public String getBaselineDate() {
    return recordTemplateStrategy.getBaselineDate();
  }

  public String getAllocationNumber() {
    return recordTemplateStrategy.getAllocationNumber();
  }

  public String getLineItemText() {
    return recordTemplateStrategy.getLineItemText();
  }

  public String getTermsOfPaymentKey() {
    return recordTemplateStrategy.getTermsOfPaymentKey();
  }

  public String getAccountOrMatchCode() {
    return recordTemplateStrategy.getAccountOrMatchCode();
  }

  public String getProfitCenter() {
    return recordTemplateStrategy.getProfitCenter();
  }

  public String getProjectAccountAssignment() {
    return recordTemplateStrategy.getProjectAccountAssignment();
  }

  public String getJurisdictionForTaxCalculation() {
    return recordTemplateStrategy.getJurisdictionForTaxCalculation();
  }
}