/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.*;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: Record2131Strategy.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-12 22:38:32 $
 *
 * @author rdesai2
 * @version $Revision: 1.23 $
 */
public class Record2131Strategy implements RecordTemplateStrategy {

  private String contactName = "";    //Read from the CLP_SAP_BATCH.ini file (Eg: KMHUDG) in the old system.
  private boolean hasOneBusinessArea;
  private String businessCode = null;
  private Double amountInVendorCurrency = null;
  private Date dateDue = null;
  private String professionalContactEmployeeId = null;
  private String matterId = null;
  private String corpVendorId = null;

  public Record2131Strategy(InvoiceRecord invoiceRecord, boolean hasOneBusinessArea, String contactName) {
    this.hasOneBusinessArea = hasOneBusinessArea;
    this.contactName = contactName;
    initializeRequiredFields(invoiceRecord);
  }

  public String getPostingKey() {
    if (amountInVendorCurrency != null) {
      if (amountInVendorCurrency.doubleValue() > 0) {
        return "31";
      }
      return "21";
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getAmountInDocumentCurrency() {
    if (amountInVendorCurrency != null) {
      return String.valueOf(amountInVendorCurrency.doubleValue());
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getTaxCode() {
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getBusinessArea() {
    if (hasOneBusinessArea && !StringUtils.isNullOrEmpty(businessCode)) {
      return businessCode;
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getCostCenter() {
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getOrderNumber() {
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getBaselineDate() {
    if (dateDue != null) {
      return DateUtil.getDate("MMddyyyy", dateDue);
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getAllocationNumber() {
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getLineItemText() {
    if (contactName != null && matterId != null && professionalContactEmployeeId != null) {
      return matterId + "-CT-" + contactName + ";" + professionalContactEmployeeId;
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getTermsOfPaymentKey() {
    return "0100";
  }

  public String getAccountOrMatchCode() {
    if (corpVendorId != null) {
      return corpVendorId;
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getProfitCenter() {
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getProjectAccountAssignment() {
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getJurisdictionForTaxCalculation() {
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  private void initializeRequiredFields(InvoiceRecord invoiceRecord) {
    if (invoiceRecord != null) {
      initializeEmployeeId(invoiceRecord);
      initializeAllocationVariables(invoiceRecord.getInvoiceAllocations());
      initializeInvoiceSummaryVariables(invoiceRecord.getInvoiceSummary());
      initializeMatterVariables(invoiceRecord.getMatter());
      initializeVendorVariables(invoiceRecord);
    }
  }

  private void initializeEmployeeId(InvoiceRecord invoiceRecord) {
    professionalContactEmployeeId = invoiceRecord.getProfessionalContactEmployeeId();
  }

  private void initializeVendorVariables(InvoiceRecord invoiceRecord) {
    corpVendorId = invoiceRecord.getVendor().getCorpVendorId();
  }

  private void initializeAllocationVariables(List allocationList) {
    businessCode = ((InvoiceAllocation) allocationList.get(0)).getAccountCode().getBusinessCode();
  }

  private void initializeMatterVariables(Matter matter) {
    matterId = matter.getMatterId();
  }

  private void initializeInvoiceSummaryVariables(InvoiceSummary invoiceSummary) {
    amountInVendorCurrency = invoiceSummary.getAmountInVendorCurrency();
    dateDue = invoiceSummary.getDateDue();
  }
}