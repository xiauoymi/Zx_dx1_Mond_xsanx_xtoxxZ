/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceAllocation;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.Matter;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.Vendor;

import java.util.List;

/**
 * Filename:    $RCSfile: Record4050Strategy.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-13 15:50:13 $
 *
 * @author rdesai2
 * @version $Revision: 1.26 $
 */
public class Record4050Strategy implements RecordTemplateStrategy {

  private int allocationNumber;
  private Double allocationPayInLocalCurrency = null;
  private String businessCode = null;
  private String subAccountCode = null;
  private String internalOrderNumber = null;
  private String vendorType = null;
  private String matterName = null;
  private String practiceArea = null;
  private String costElement = null;
  private String profitCenter = null;
  private String workBreakdownStructure = null;
  private String matterGroupReference = null;

  public Record4050Strategy(InvoiceRecord invoiceRecord, int allocationNumber) {
    this.allocationNumber = allocationNumber;
    initializeRequiredFields(invoiceRecord);
  }

  public String getPostingKey() {
    if (allocationPayInLocalCurrency != null) {
      if (allocationPayInLocalCurrency.doubleValue() > 0) {
        return "40";
      }
      if (allocationPayInLocalCurrency.doubleValue() < 0) {
        return "50";
      }
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getAmountInDocumentCurrency() {
    if (allocationPayInLocalCurrency != null) {
      return String.valueOf(allocationPayInLocalCurrency.doubleValue());
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getTaxCode() {
    return "E0";
  }

  public String getBusinessArea() {
    if (!StringUtils.isNullOrEmpty(businessCode)) {
      return businessCode;
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getCostCenter() {
    if (subAccountCode != null) {
      return subAccountCode;
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getOrderNumber() {
    if (internalOrderNumber != null && !LMMSConstants.N_A_CONSTANT.equalsIgnoreCase(internalOrderNumber)) {
      return internalOrderNumber;
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getBaselineDate() {
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getAllocationNumber() {
    if (vendorType != null) {
      return vendorType;
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getLineItemText() {
    if (practiceArea != null && LMMSConstants.PRACTICE_AREA_ENVIRN.equalsIgnoreCase(practiceArea) && matterName != null) {
      return matterName;
    }
    if (practiceArea != null && LMMSConstants.PRACTICE_AREA_LITIG.equalsIgnoreCase(practiceArea) && matterGroupReference != null) {
      return matterGroupReference;
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getTermsOfPaymentKey() {
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getAccountOrMatchCode() {
    if (!StringUtils.isNullOrEmpty(costElement)) {
      return costElement;
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getProfitCenter() {
    if (profitCenter != null && StringUtils.isNullOrEmpty(subAccountCode)) {
      return profitCenter;
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getProjectAccountAssignment() {
    if (workBreakdownStructure != null &&
            !LMMSConstants.N_A_CONSTANT.equalsIgnoreCase(workBreakdownStructure)) {
      return workBreakdownStructure;
    }
    return LMMSConstants.SAP_DEFAULT_COLUMN_VALUE;
  }

  public String getJurisdictionForTaxCalculation() {
    return LMMSConstants.JURISDICTION_FOR_TAX_CALCULATION;
  }

  private void initializeRequiredFields(InvoiceRecord invoiceRecord) {
    if (invoiceRecord != null) {
      initializeAllocationVariables(invoiceRecord.getInvoiceAllocations());
      initializeVendorVariables(invoiceRecord.getVendor());
      initializeMatterVariables(invoiceRecord.getMatter());
    }
  }

  private void initializeMatterVariables(Matter matter) {
    practiceArea = matter.getPracticeArea();
    matterName = matter.getMatterName();
    matterGroupReference = matter.getMatterGroupReference();
  }

  private void initializeAllocationVariables(List allocationList) {
    if (allocationList.size() > allocationNumber) {
      InvoiceAllocation allocation = (InvoiceAllocation) allocationList.get(allocationNumber);
      if (allocation != null) {
        allocationPayInLocalCurrency = allocation.getAllocationPayInLocalCurrency();
        businessCode = allocation.getAccountCode().getBusinessCode();
        subAccountCode = allocation.getSubAccountCode();
        internalOrderNumber = allocation.getInternalOrderNumber();
        costElement = allocation.getAccountCode().getCostElement();
        profitCenter = allocation.getProfitCenter();
        workBreakdownStructure = allocation.getWorkBreakdownStructure();
      }
    }
  }

  private void initializeVendorVariables(Vendor vendor) {
    vendorType = vendor.getVendorType();
  }
}