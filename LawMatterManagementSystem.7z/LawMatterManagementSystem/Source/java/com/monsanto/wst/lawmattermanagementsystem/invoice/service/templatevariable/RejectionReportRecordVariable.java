/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceAllocation;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceSummary;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.Vendor;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import org.apache.commons.lang.StringUtils;

import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: RejectionReportRecordVariable.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-26 20:54:09 $
 *
 * @author rdesai2
 * @version $Revision: 1.9 $
 */
public class RejectionReportRecordVariable {

  private String errorMessage;
  private int erroneousAllocationNumber;

  private String invoiceNumber = null;
  private Integer transactionId = null;
  private String transactionIdString = null;
  private Date dateOnInvoice = null;
  private String dateOnInvoiceString = null;
  private String accountNumber = null;
  private String subAccountCode = null;
  private String corpVendorId = null;

  public RejectionReportRecordVariable(InvoiceRecord invoiceRecord, String errorMessage, int erroneousAllocationNumber) {
    this.errorMessage = errorMessage;
    this.erroneousAllocationNumber = erroneousAllocationNumber;
    initializeRequiredVariables(invoiceRecord);
  }

  public RejectionReportRecordVariable(String invoiceNumber, String transactionIdString, String dateOnInvoiceString, String accountNumber, String subAccountCode, String corpVendorId, String errorMessage) {
    this.invoiceNumber = invoiceNumber;
    this.transactionIdString = transactionIdString;
    this.dateOnInvoiceString = dateOnInvoiceString;
    this.accountNumber = accountNumber;
    this.subAccountCode = subAccountCode;
    this.corpVendorId = corpVendorId;
    this.errorMessage = errorMessage;
  }

  public String getInvoiceNumber() {
    if (invoiceNumber == null) {
      return StringUtils.EMPTY;
    }
    return invoiceNumber;
  }

  public String getTransactionId() {
    if (transactionIdString != null) {
      return transactionIdString;
    }
    if (transactionId == null) {
      return StringUtils.EMPTY;
    }
    return transactionId.toString();
  }

  public String getInvoiceDate() {
    if (dateOnInvoiceString != null) {
      return dateOnInvoiceString;
    }
    if (dateOnInvoice == null) {
      return StringUtils.EMPTY;
    }
    return DateUtil.getDate("MM/dd/yyyy", dateOnInvoice);
  }

  public String getAccountNumber() {
    if (accountNumber == null) {
      return StringUtils.EMPTY;
    }
    return accountNumber;
  }

  public String getSubAccountNumber() {
    if (subAccountCode == null) {
      return StringUtils.EMPTY;
    }
    return subAccountCode;
  }

  public String getVendorId() {
    if (corpVendorId == null) {
      return StringUtils.EMPTY;
    }
    return corpVendorId;
  }

  public String getErrorMessage() {
    if (errorMessage == null) {
      return StringUtils.EMPTY;
    }
    return errorMessage;
  }

  private void initializeRequiredVariables(InvoiceRecord invoiceRecord) {
    if (invoiceRecord != null) {
      initializeInvoiceSummaryVariables(invoiceRecord.getInvoiceSummary());
      initializeAllocationVariables(invoiceRecord);
      initializeVendorVariables(invoiceRecord.getVendor());
    }
  }

  private void initializeVendorVariables(Vendor vendor) {
    corpVendorId = vendor.getCorpVendorId();
  }

  private void initializeAllocationVariables(InvoiceRecord invoiceRecord) {
    List allocationList = invoiceRecord.getInvoiceAllocations();
    if (allocationList.size() > erroneousAllocationNumber) {
      InvoiceAllocation allocation = ((InvoiceAllocation) allocationList.get(erroneousAllocationNumber));
      if (allocation != null) {
        accountNumber = allocation.getAccountCodeString();
        subAccountCode = ((InvoiceAllocation) allocationList.get(erroneousAllocationNumber)).getSubAccountCode();
      }
    }
  }

  private void initializeInvoiceSummaryVariables(InvoiceSummary invoiceSummary) {
    invoiceNumber = invoiceSummary.getInvoiceNumber();
    transactionId = invoiceSummary.getTransactionId();
    dateOnInvoice = invoiceSummary.getDateOnInvoice();
  }
}