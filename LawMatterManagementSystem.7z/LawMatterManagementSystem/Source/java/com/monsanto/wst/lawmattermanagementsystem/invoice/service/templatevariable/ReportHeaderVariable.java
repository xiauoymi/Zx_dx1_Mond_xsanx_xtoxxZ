/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;

import java.util.Date;

/**
 * Filename:    $RCSfile: ReportHeaderVariable.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:24:54 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class ReportHeaderVariable {

  private String reportName;
  private Date reportDate;

  public ReportHeaderVariable(String reportName, Date reportDate) {
    this.reportName = reportName;
    this.reportDate = reportDate;
  }

  public String getReportName() {
    if (reportName != null) {
      return reportName;
    }
    return "";
  }

  public String getReportDate() {
    if (reportDate != null) {
      return "[" + DateUtil.getDate(LMMSConstants.PATTERN_DATE_REPORT_HEADER, reportDate) + "]";
    }
    return "";
  }
}