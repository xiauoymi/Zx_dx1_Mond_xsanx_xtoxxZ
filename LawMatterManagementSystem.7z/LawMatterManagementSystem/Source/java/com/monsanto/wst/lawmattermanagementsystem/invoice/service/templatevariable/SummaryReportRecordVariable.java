/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceSummary;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.Vendor;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;

import java.text.DecimalFormat;
import java.util.Date;

/**
 * Filename:    $RCSfile: SummaryReportRecordVariable.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-26 20:54:09 $
 *
 * @author rdesai2
 * @version $Revision: 1.8 $
 */
public class SummaryReportRecordVariable {

  private String corpVendorId = null;
  private String vendorShortName = null;
  private String invoiceNumber = null;
  private Date dateOnInvoice = null;
  private String dateOnInvoiceString = null;
  private Double amountInVendorCurrency = null;
  private String amountInVendorCurrencyString = null;

  public SummaryReportRecordVariable(String corpVendorId, String vendorShortName, String invoiceNumber, String dateOnInvoice, String amountInVendorCurrency) {
    this.corpVendorId = corpVendorId;
    this.vendorShortName = vendorShortName;
    this.invoiceNumber = invoiceNumber;
    this.dateOnInvoiceString = dateOnInvoice;
    this.amountInVendorCurrencyString = amountInVendorCurrency;
  }

  public SummaryReportRecordVariable(InvoiceRecord invoiceRecord) {
    if (invoiceRecord != null) {
      initializeInvoiceSummaryVariables(invoiceRecord.getInvoiceSummary());
      initializeVendorVariables(invoiceRecord.getVendor());
    }
  }

  public String getVendorNumber() {
    if (corpVendorId != null) {
      return corpVendorId;
    }
    return "";
  }

  public String getVendorName() {
    if (vendorShortName != null) {
      return vendorShortName;
    }
    return "";
  }

  public String getInvoiceNumber() {
    if (invoiceNumber != null) {
      return invoiceNumber;
    }
    return "";
  }

  public String getInvoiceDate() {
    if (dateOnInvoiceString != null) {
      return dateOnInvoiceString;
    }
    if (dateOnInvoice != null) {
      return DateUtil.getDate("MM/dd/yyyy", dateOnInvoice);
    }
    return "";
  }

  public String getInvoiceAmount() {
    if (amountInVendorCurrencyString != null) {
      return amountInVendorCurrencyString;
    }
    if (amountInVendorCurrency != null) {
      return new DecimalFormat(LMMSConstants.PATTERN_AMOUNT).format(amountInVendorCurrency);
    }
    return "";
  }

  private void initializeVendorVariables(Vendor vendor) {
    corpVendorId = vendor.getCorpVendorId();
    vendorShortName = vendor.getVendorShortName();
  }

  private void initializeInvoiceSummaryVariables(InvoiceSummary invoiceSummary) {
    invoiceNumber = invoiceSummary.getInvoiceNumber();
    dateOnInvoice = invoiceSummary.getDateOnInvoice();
    amountInVendorCurrency = invoiceSummary.getAmountInVendorCurrency();
  }
}