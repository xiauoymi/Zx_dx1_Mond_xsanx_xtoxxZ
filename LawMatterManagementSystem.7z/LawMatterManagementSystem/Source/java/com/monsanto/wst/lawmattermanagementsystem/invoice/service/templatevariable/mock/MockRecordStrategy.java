/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.mock;

import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.RecordTemplateStrategy;

/**
 * Filename:    $RCSfile: MockRecordStrategy.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-01-30 21:42:35 $
 *
 * @author rdesai2
 * @version $Revision: 1.16 $
 */
public class MockRecordStrategy implements RecordTemplateStrategy {

  public String getPostingKey() {
    return "mockPostingKey";
  }

  public String getAmountInDocumentCurrency() {
    return "mockAmountInDocumentCurrency";
  }

  public String getTaxCode() {
    return "mockTaxCode";
  }

  public String getBusinessArea() {
    return "mockBusinessArea";
  }

  public String getCostCenter() {
    return "mockCostCenter";
  }

  public String getOrderNumber() {
    return "mockOrderNumber";
  }

  public String getBaselineDate() {
    return "mockBaselineDate";
  }

  public String getAllocationNumber() {
    return "mockAllocationNumber";
  }

  public String getLineItemText() {
    return "mockLineItemText";
  }

  public String getTermsOfPaymentKey() {
    return "mockTermsOfPaymentKey";
  }

  public String getAccountOrMatchCode() {
    return "mockAccountOrMatchCode";
  }

  public String getProfitCenter() {
    return "mockProfitCenter";
  }

  public String getProjectAccountAssignment() {
    return "mockProjectAccountAssignment";
  }

  public String getJurisdictionForTaxCalculation() {
    return "mockJurisdictionForTaxCalculation";
  }
}