/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.test;

import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.InvoiceFileHeaderVariable;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: InvoiceFileHeaderVariable_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class InvoiceFileHeaderVariable_UT extends TestCase {

  public void testGetters() throws Exception {
    int queueGroupNameRandomNumber = 123;
    InvoiceFileHeaderVariable invoiceFileHeaderVariable = new InvoiceFileHeaderVariable(queueGroupNameRandomNumber);
    assertEquals("CPINV"  + DateUtil.getCurrentDate("MMdd") + queueGroupNameRandomNumber, invoiceFileHeaderVariable.getQueueGroupName());
  }
}