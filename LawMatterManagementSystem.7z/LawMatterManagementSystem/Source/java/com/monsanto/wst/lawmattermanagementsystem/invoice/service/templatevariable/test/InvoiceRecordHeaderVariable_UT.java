/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.test;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.*;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.InvoiceRecordHeaderVariable;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: InvoiceRecordHeaderVariable_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-05 16:43:40 $
 *
 * @author rdesai2
 * @version $Revision: 1.8 $
 */
public class InvoiceRecordHeaderVariable_UT extends TestCase {

  public void testGetters() throws Exception {
    InvoiceRecord invoiceRecord = getInvoiceRecord();
    InvoiceRecordHeaderVariable invoiceRecordHeaderVariable = new InvoiceRecordHeaderVariable(invoiceRecord);
    assertEquals(DateUtil.getDate("MMddyyyy", new Date()), invoiceRecordHeaderVariable.getDocumentDate());
    assertEquals("5180", invoiceRecordHeaderVariable.getCompanyCode());
    assertEquals("invoice#1", invoiceRecordHeaderVariable.getInvoiceNumber());
    assertEquals("practiseArea#1", invoiceRecordHeaderVariable.getPracticeArea());
  }

  public void testGetters_ForNullInvoice() throws Exception {
    InvoiceRecordHeaderVariable invoiceRecordHeaderVariable = new InvoiceRecordHeaderVariable(null);
    assertEquals("", invoiceRecordHeaderVariable.getDocumentDate());
    assertEquals("", invoiceRecordHeaderVariable.getCompanyCode());
    assertEquals("", invoiceRecordHeaderVariable.getInvoiceNumber());
    assertEquals("", invoiceRecordHeaderVariable.getPracticeArea());
  }

  private InvoiceRecord getInvoiceRecord() {
    String companyCode = "5180";
    String invoiceNumber = "invoice#1";
    String practiceArea = "practiseArea#1";
    Date dateOnInvoice = new Date();
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation(companyCode + "-9130-41700900",new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    Matter matter = new Matter("11", practiceArea, "Matter11", null);
    Vendor vendor = new Vendor("VendorType-LAW", "250099", "V-LAW");
    return new InvoiceRecord(new InvoiceSummary(dateOnInvoice, "USD", invoiceNumber, new Integer(1123), new Double(500.95), new Date(), "vendor1", "1234"), "empId334", vendor, invoiceAllocations, matter);
  }
}