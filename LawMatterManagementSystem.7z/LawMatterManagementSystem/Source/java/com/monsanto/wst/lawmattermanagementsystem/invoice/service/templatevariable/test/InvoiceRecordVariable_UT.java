/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.test;

import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.InvoiceRecordVariable;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.RecordTemplateStrategy;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.mock.MockRecordStrategy;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: InvoiceRecordVariable_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-01-30 23:42:20 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class InvoiceRecordVariable_UT extends TestCase {

  public void testGetPostingKey() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockPostingKey", invoiceRecordVariable.getPostingKey());
  }

  public void testGetAmountInDocumentCurrency() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockAmountInDocumentCurrency", invoiceRecordVariable.getAmountInDocumentCurrency());
  }

  public void testGetTaxCode() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockTaxCode", invoiceRecordVariable.getTaxCode());
  }

  public void testGetBusinessArea() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockBusinessArea", invoiceRecordVariable.getBusinessArea());
  }

  public void testGetCostCenter() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockCostCenter", invoiceRecordVariable.getCostCenter());
  }

  public void testGetOrderNumber() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockOrderNumber", invoiceRecordVariable.getOrderNumber());
  }

  public void testGetBaselineDate() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockBaselineDate", invoiceRecordVariable.getBaselineDate());
  }

  public void testGetAllocationNumber() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockAllocationNumber", invoiceRecordVariable.getAllocationNumber());
  }

  public void testGetLineItemText() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockLineItemText", invoiceRecordVariable.getLineItemText());
  }

  public void testGetTermsOfPaymentKey() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockTermsOfPaymentKey", invoiceRecordVariable.getTermsOfPaymentKey());
  }

  public void testGetAccountOrMatchCode() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockAccountOrMatchCode", invoiceRecordVariable.getAccountOrMatchCode());
  }

  public void testGetProfitCenter() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockProfitCenter", invoiceRecordVariable.getProfitCenter());
  }

  public void testGetProjectAccountAssignment() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockProjectAccountAssignment", invoiceRecordVariable.getProjectAccountAssignment());
  }

  public void testGetJurisdictionForTaxCalculation() throws Exception {
    RecordTemplateStrategy recordTemplateStrategy = new MockRecordStrategy();
    InvoiceRecordVariable invoiceRecordVariable = new InvoiceRecordVariable(recordTemplateStrategy);
    assertEquals("mockJurisdictionForTaxCalculation", invoiceRecordVariable.getJurisdictionForTaxCalculation());
  }
}