/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockInvoiceRecordDataUtility;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.Record2131Strategy;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.RecordTemplateStrategy;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: Record2131Strategy_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-26 20:54:09 $
 *
 * @author rdesai2
 * @version $Revision: 1.24 $
 */
public class Record2131Strategy_UT extends TestCase {

  private String contactName = "KMHUDG";

  public void testGetPostingKey_ForPositiveAmmountInVendorCurrency() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAmountVC(100), true, contactName);
    assertEquals("31", templateStrategy.getPostingKey());
  }

  public void testGetPostingKey_ForNegativeAmmountInVendorCurrency() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAmountVC(-10), true, contactName);
    assertEquals("21", templateStrategy.getPostingKey());
  }

  public void testGetPostingKey_ForZeroAmmountInVendorCurrency() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAmountVC(0), true, contactName);
    assertEquals("21", templateStrategy.getPostingKey());
  }

  public void testGetPostingKey_ForNullInvoiceRecord() throws Exception {
    InvoiceRecord invoiceRecord = null;
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(invoiceRecord, true, contactName);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getPostingKey());
  }

  public void testGetAmountInDocumentCurrency() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAmountVC(100.50), true, contactName);
    assertEquals("100.5", templateStrategy.getAmountInDocumentCurrency());
  }

  public void testGetAmountInDocumentCurrency_ForNullInvoiceRecord() throws Exception {
    InvoiceRecord invoiceRecord = null;
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(invoiceRecord, true, contactName);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getAmountInDocumentCurrency());
  }

  public void testGetTaxCode() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(null, true, contactName);
    assertEquals("~", templateStrategy.getTaxCode());
  }

  public void testGetBusinessArea() throws Exception {
    String accountCodeString = "5180-5114-909090";
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAccountCode(accountCodeString), true, contactName);
    assertEquals("5114", templateStrategy.getBusinessArea());
  }

  public void testGetBusinessArea_ReturnsDefaultValue_IfAllAllocationsDoNotHaveOneBusinessArea() throws Exception {
    boolean hasOneBusinessArea = false;
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), hasOneBusinessArea, contactName);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getBusinessArea());
  }

  public void testGetBusinessArea_ForEmptyAccountCode() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAccountCode(""), true, contactName);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getBusinessArea());
  }

  public void testGetBusinessArea_ForNullInvoiceRecord() throws Exception {
    InvoiceRecord invoiceRecord = null;
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(invoiceRecord, true, contactName);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getBusinessArea());
  }

  public void testGetCostCenter() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(null, false, contactName);
    assertEquals("~", templateStrategy.getCostCenter());
  }

  public void testGetOrderNumber() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(null, false, contactName);
    assertEquals("~", templateStrategy.getOrderNumber());
  }

  public void testGetBaselineDate() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), false, contactName);
    assertEquals(DateUtil.getCurrentDate("MMddyyyy"), templateStrategy.getBaselineDate());
  }

  public void testGetBaselineDate_ForNullInvoiceRecord() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(null, false, contactName);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getBaselineDate());
  }

  public void testGetAllocationNumber() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(null, false, contactName);
    assertEquals("~", templateStrategy.getAllocationNumber());
  }

  public void testGetLineItemText() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), false, contactName);
    assertEquals("matter1-CT-"+ contactName +";empId334", templateStrategy.getLineItemText());
  }

  public void testGetLineItemText_ForNullContactName() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), false, null);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getLineItemText());
  }

  public void testGetLineItemText_ForNullInvoiceRecord() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(null, false, contactName);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getLineItemText());
  }

  public void testGetTermsOfPaymentKey() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(null, false, null);
    assertEquals("0100", templateStrategy.getTermsOfPaymentKey());
  }

  public void testGetAccountOrMatchCode() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), false, null);
    assertEquals("250099", templateStrategy.getAccountOrMatchCode());
  }

  public void testGetAccountOrMatchCode_ForNullInvoiceRecord() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(null, false, null);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getAccountOrMatchCode());
  }

  public void testGetProfitCenter() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(null, false, null);
    assertEquals("~", templateStrategy.getProfitCenter());
  }

  public void testGetProjectAccountAssignment() throws Exception {
    //Note: Verified - WBS is not supposed to be sent in for the 21/31 record
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(null, false, null);
    assertEquals("~", templateStrategy.getProjectAccountAssignment());
  }

  public void testGetJurisdictionForTaxCalculation() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record2131Strategy(null, false, null);
    assertEquals("~", templateStrategy.getJurisdictionForTaxCalculation());
  }
}