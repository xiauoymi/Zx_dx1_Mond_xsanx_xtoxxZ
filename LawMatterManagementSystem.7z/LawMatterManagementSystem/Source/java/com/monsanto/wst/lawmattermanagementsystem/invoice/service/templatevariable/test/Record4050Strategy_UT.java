/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockInvoiceRecordDataUtility;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.Record4050Strategy;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.RecordTemplateStrategy;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: Record4050Strategy_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-12 22:44:11 $
 *
 * @author rdesai2
 * @version $Revision: 1.25 $
 */
public class Record4050Strategy_UT extends TestCase {

  public void testGetPostingKey_ForPostiveAllocationPayInLocalCurrency() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAllocationAmount(100), 0);
    assertEquals("40", templateStrategy.getPostingKey());
  }

  public void testGetPostingKey_ForNegativeAllocationPayInLocalCurrency() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAllocationAmount(-1), 0);
    assertEquals("50", templateStrategy.getPostingKey());
  }

  public void testGetPostingKey_ForZeroAllocationPayInLocalCurrency() throws Exception {
    //No RFBIBL record should be created in such a case
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAllocationAmount(0), 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getPostingKey());
  }

  public void testGetPostingKey_ReturnsSAPDefault_ForInvalidAllocationNumber() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), 10);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getPostingKey());
  }

  public void testGetPostingKey_ForNullInvoiceAllocation() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithNullAllocation(), 1);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getPostingKey());
  }

  public void testGetPostingKey_ForNullInvoiceRecord() throws Exception {
    InvoiceRecord invoiceRecord = null;
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(invoiceRecord, 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getPostingKey());
  }

  public void testGetAmountInDocumentCurrency() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAllocationAmount(0.05), 0);
    assertEquals("0.05", templateStrategy.getAmountInDocumentCurrency());
  }

  public void testGetAmountInDocumentCurrency_ForInvalidAllocationNumberRequest() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), 10);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getAmountInDocumentCurrency());
  }

  public void testGetAmountInDocumentCurrency_ForNullInvoiceAllocation() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithNullAllocation(), 1);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getAmountInDocumentCurrency());
  }

  public void testGetAmountInDocumentCurrency_ForNullInvoiceRecord() throws Exception {
    InvoiceRecord invoiceRecord = null;
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(invoiceRecord, 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getAmountInDocumentCurrency());
  }

  public void testGetTaxCode() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(null, 0);
    assertEquals("E0", templateStrategy.getTaxCode());
  }

  public void testGetBusinessArea() throws Exception {
    String accountCodeString = "5180-5114-909090";
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAccountCode(accountCodeString), 0);
    assertEquals("5114", templateStrategy.getBusinessArea());
  }

  public void testGetBusinessArea_ForEmptyAccountCode() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAccountCode(""), 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getBusinessArea());
  }

  public void testGetBusinessArea_ForNullAllocation() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithNullAllocation(), 1);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getBusinessArea());
  }

  public void testGetBusinessArea_ForInvalidAllocationNumberRequest() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), 10);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getBusinessArea());
  }

  public void testGetBusinessArea_ForNullInvoiceRecord() throws Exception {
    InvoiceRecord invoiceRecord = null;
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(invoiceRecord, 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getBusinessArea());
  }

  public void testGetCostCenter() throws Exception {
    String subAccountCode = "12345678";
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithSubAccountCode(subAccountCode), 0);
    assertEquals("12345678", templateStrategy.getCostCenter());
  }

  public void testGetCostCenter_ForNullInvoiceAllocation() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithNullAllocation(), 1);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getCostCenter());
  }

  public void testGetCostCenter_ForInvalidInvoiceAllocationNumberRequest() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), 10);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getCostCenter());
  }

  public void testGetCostCenter_ForNullInvoiceRecord() throws Exception {
    InvoiceRecord invoiceRecord = null;
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(invoiceRecord, 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getCostCenter());
  }

  public void testGetOrderNumber() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithION("ION123"), 0);
    assertEquals("ION123", templateStrategy.getOrderNumber());
  }

  public void testGetOrderNumber_ForNullInternalOrderNumber() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithION(null), 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getOrderNumber());
  }

  public void testGetOrderNumber_ForNullInvoiceAllocation() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithNullAllocation(), 1);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getOrderNumber());
  }

  public void testGetOrderNumber_ForInvalidInvoiceAllocationNumberRequest() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), 10);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getOrderNumber());
  }

  public void testGetBaselineDate() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(null, 0);
    assertEquals("~", templateStrategy.getBaselineDate());
  }

  public void testGetAllocationNumber() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithVendorType("VendorType-LAW"), 0);
    assertEquals("VendorType-LAW", templateStrategy.getAllocationNumber());
  }

  public void testGetAllocationNumber_ForNullInvoiceRecord() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(null, 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getAllocationNumber());
  }

  public void testGetLineItemText_DefaultValue() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(null, 0);
    assertEquals("~", templateStrategy.getLineItemText());
  }

  public void testGetLineItemText_For_ENVIRN_PracticeArea() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithPractiseAreaAndMatterName(LMMSConstants.PRACTICE_AREA_ENVIRN, "testMatterName"), 0);
    assertEquals("testMatterName", templateStrategy.getLineItemText());
  }

  public void testGetLineItemText_For_LITIG_PracticeArea() throws Exception {
    //Note...In the old system we used to write matter-category + group_reference, now in the new system we write only grp_ref
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithPractiseAreaAndGrpRef(LMMSConstants.PRACTICE_AREA_LITIG, "TST-ASBESTOS"), 0);
    assertEquals("TST-ASBESTOS", templateStrategy.getLineItemText());
  }

  public void testGetLineItemText_ForNullInvoiceRecord() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(null, 0);
    assertEquals("~", templateStrategy.getLineItemText());
  }

  public void testGetTermsOfPaymentKey() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(null, 0);
    assertEquals("~", templateStrategy.getTermsOfPaymentKey());
  }

  public void testGetAccountOrMatchCode() throws Exception {
    String accountCodeString = "5180-5114-90901190";
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithAccountCode(accountCodeString), 0);
    assertEquals("90901190", templateStrategy.getAccountOrMatchCode());
  }

  public void testGetAccountOrMatchCode_ForNullAllocation() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithNullAllocation(), 1);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getAccountOrMatchCode());
  }

  public void testGetAccountOrMatchCode_InvalidAllocationNumberRequest() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), 10);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getAccountOrMatchCode());
  }

  public void testGetAccountOrMatchCode_ForNullInvoiceRecord() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(null, 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getAccountOrMatchCode());
  }

  public void testGetProfitCenter_WithNoCostCenter() throws Exception {
    String costCenter = "";   //NO Cost Center
    String profitCenter = "testProfitCenter";
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithCostAndProfitCenter(costCenter, profitCenter), 0);
    assertEquals("testProfitCenter", templateStrategy.getProfitCenter());
  }

  public void testGetProfitCenter_WithNullCostCenter() throws Exception {
    String costCenter = null;
    String profitCenter = "testProfitCenter";
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithCostAndProfitCenter(costCenter, profitCenter), 0);
    assertEquals("testProfitCenter", templateStrategy.getProfitCenter());
  }

  public void testGetProfitCenter_WithCostCenterPresent() throws Exception {
    String costCenter = "some-cost-center";
    String profitCenter = "testProfitCenter";
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithCostAndProfitCenter(costCenter, profitCenter), 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getProfitCenter());
  }

  public void testGetProfitCenter_ForNullProfitCenter() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithCostAndProfitCenter(null, null), 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getProfitCenter());
  }

  public void testGetProfitCenter_ForNullAllocation() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithNullAllocation(), 1);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getProfitCenter());
  }

  public void testGetProfitCenter_WithInvalidAllocationNumberRequest() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), 10);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getProfitCenter());
  }

  public void testGetProfitCenter_ForNullInvoiceRecord() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(null, 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getProfitCenter());
  }

  public void testGetProjectAccountAssignment() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), 1);
    assertEquals("WBS2", templateStrategy.getProjectAccountAssignment());
  }

  public void testGetProjectAccountAssignment_ForNullWBS() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithWBS(null), 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getProjectAccountAssignment());
  }

  public void testGetProjectAccountAssignment_ForNullAllocation() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getInvoiceRecordWithNullAllocation(), 1);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getProjectAccountAssignment());
  }

  public void testGetProjectAccountAssignment_ForInvalidAllocationNumberRequest() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), 10);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getProjectAccountAssignment());
  }

  public void testGetProjectAccountAssignment_ForNullInvoiceRecord() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(null, 0);
    assertEquals(LMMSConstants.SAP_DEFAULT_COLUMN_VALUE, templateStrategy.getProjectAccountAssignment());
  }

  public void testGetJurisdictionForTaxCalculation() throws Exception {
    RecordTemplateStrategy templateStrategy = new Record4050Strategy(null, 0);
    assertEquals(LMMSConstants.JURISDICTION_FOR_TAX_CALCULATION, templateStrategy.getJurisdictionForTaxCalculation());
  }
}