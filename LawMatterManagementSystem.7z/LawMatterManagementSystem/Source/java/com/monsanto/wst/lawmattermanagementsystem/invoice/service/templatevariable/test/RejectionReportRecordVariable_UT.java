/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.test;

import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockInvoiceRecordDataUtility;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.RejectionReportRecordVariable;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Filename:    $RCSfile: RejectionReportRecordVariable_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-26 20:54:09 $
 *
 * @author rdesai2
 * @version $Revision: 1.8 $
 */
public class RejectionReportRecordVariable_UT extends TestCase {

  public void testGetInvoiceNumber_ValidValue_AssertsCorrectValue() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), null, 0);
    assertEquals("invoice#1", rejectionReportRecordVariable.getInvoiceNumber());
  }

  public void testGetInvoiceNumber_ForNullInvoiceRecord_ReturnsEmptyString() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(null, null, 0);
    assertEquals("", rejectionReportRecordVariable.getInvoiceNumber());
  }

  public void testGetTransactionId_ValidValue_AssertsCorrectValue() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), null, 0);
    assertEquals("1123", rejectionReportRecordVariable.getTransactionId());
  }

  public void testGetTransactionId_ForNullInvoiceRecord_ReturnsEmptyString() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(null, null, 0);
    assertEquals("", rejectionReportRecordVariable.getTransactionId());
  }

  public void testGetInvoiceDate_ValidValue_AssertsCorrectValue() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), null, 0);
    assertEquals(DateUtil.getDate("MM/dd/yyyy", new Date()), rejectionReportRecordVariable.getInvoiceDate());
  }

  public void testGetInvoiceDate_ForNullInvoiceRecord_ReturnsEmptyString() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(null, null, 0);
    assertEquals("", rejectionReportRecordVariable.getInvoiceDate());
  }

  public void testGetAccountNumber_ValidValue_AssertsCorrectValue() throws Exception {
    String accountCodeString = "5112-9115-41701900";
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(MockInvoiceRecordDataUtility.getInvoiceRecordWithAccountCode(accountCodeString), null, 0);
    assertEquals("5112-9115-41701900", rejectionReportRecordVariable.getAccountNumber());
  }

  public void testGetAccountNumber_ReturnsEmptyString_ForNullAllocation() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(MockInvoiceRecordDataUtility.getInvoiceRecordWithNullAllocation(), null, 1);
    assertEquals("", rejectionReportRecordVariable.getAccountNumber());
  }

  public void testGetAccountNumber_ForInvalidAllocationNumber_ReturnsEmptyString() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), null, 10);
    assertEquals("", rejectionReportRecordVariable.getAccountNumber());
  }

  public void testGetAccountNumber_ForEmptyAccountNumber_ReturnsEmptyString() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(MockInvoiceRecordDataUtility.getInvoiceRecordWithAccountCode(""), null, 4);
    assertEquals("", rejectionReportRecordVariable.getAccountNumber());
  }

  public void testGetAccountNumber_ForNullInvoiceRecord_ReturnsEmptyString() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(null, null, 0);
    assertEquals("", rejectionReportRecordVariable.getAccountNumber());
  }

  public void testGetSubAccountNumber_ValidValue_AssertsCorrectValue() throws Exception {
    String subAccountCode = "TBF76526";
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(MockInvoiceRecordDataUtility.getInvoiceRecordWithSubAccountCode(subAccountCode), null, 0);
    assertEquals("TBF76526", rejectionReportRecordVariable.getSubAccountNumber());
  }

  public void testGetSubAccountNumber_ForInvalidAllocationNumber_ReturnsEmptyStringe() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), null, 10);
    assertEquals("", rejectionReportRecordVariable.getSubAccountNumber());
  }

  public void testGetSubAccountNumber_ForNullAllocation_ReturnsEmptyString() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(MockInvoiceRecordDataUtility.getInvoiceRecordWithNullAllocation(), null, 1);
    assertEquals("", rejectionReportRecordVariable.getSubAccountNumber());
  }

  public void testGetSubAccountNumber_ForNullInvoiceRecord_ReturnsEmptyString() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(null, null, 0);
    assertEquals("", rejectionReportRecordVariable.getSubAccountNumber());
  }

  public void testGetVendorId_ValidValue_AssertsCorrectValue() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord(), null, 0);
    assertEquals("250099", rejectionReportRecordVariable.getVendorId());
  }

  public void testGetVendorId_ForNullInvoiceRecord_ReturnsEmptyString() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(null, null, 0);
    assertEquals("", rejectionReportRecordVariable.getVendorId());
  }

  public void testGetErrorMessage_ValidValue_AssertsCorrectValue() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(null, "error1", 0);
    assertEquals("error1", rejectionReportRecordVariable.getErrorMessage());
  }

  public void testGetErrorMessage_ReturnsEmptyString_ForNullInput() throws Exception {
    RejectionReportRecordVariable rejectionReportRecordVariable = new RejectionReportRecordVariable(null, null, 0);
    assertEquals("", rejectionReportRecordVariable.getErrorMessage());
  }

  public void testGettersForRejectionReport_WithConstantValues() throws Exception {
    RejectionReportRecordVariable recordVariable;
    recordVariable = new RejectionReportRecordVariable("Inv. Number", "Tran. Id", "Inv. Date", "Acc. Number", "Subacc.", "Corp. Ven. ID", "Error Message");
    assertEquals("Inv. Number", recordVariable.getInvoiceNumber());
    assertEquals("Tran. Id", recordVariable.getTransactionId());
    assertEquals("Inv. Date", recordVariable.getInvoiceDate());
    assertEquals("Acc. Number", recordVariable.getAccountNumber());
    assertEquals("Subacc.", recordVariable.getSubAccountNumber());
    assertEquals("Corp. Ven. ID", recordVariable.getVendorId());
    assertEquals("Error Message", recordVariable.getErrorMessage());
    recordVariable = new RejectionReportRecordVariable("-----------", "--------", "---------", "-----------", "-------", "-------------", "-------------");
    assertEquals("-----------", recordVariable.getInvoiceNumber());
    assertEquals("--------", recordVariable.getTransactionId());
    assertEquals("---------", recordVariable.getInvoiceDate());
    assertEquals("-----------", recordVariable.getAccountNumber());
    assertEquals("-------", recordVariable.getSubAccountNumber());
    assertEquals("-------------", recordVariable.getVendorId());
    assertEquals("-------------", recordVariable.getErrorMessage());
  }

  public void testGettersForRejectionReport_WithConstantValues_ForNullCases() throws Exception {
    RejectionReportRecordVariable recordVariable;
    recordVariable = new RejectionReportRecordVariable(null, null, null, null, null, null, null);
    assertEquals("", recordVariable.getInvoiceNumber());
    assertEquals("", recordVariable.getTransactionId());
    assertEquals("", recordVariable.getInvoiceDate());
    assertEquals("", recordVariable.getAccountNumber());
    assertEquals("", recordVariable.getSubAccountNumber());
    assertEquals("", recordVariable.getVendorId());
    assertEquals("", recordVariable.getErrorMessage());
  }
}