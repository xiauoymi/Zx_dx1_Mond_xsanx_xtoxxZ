/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.test;

import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.ReportHeaderVariable;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Filename:    $RCSfile: ReportHeaderVariable_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class ReportHeaderVariable_UT extends TestCase {

  public ReportHeaderVariable_UT(String name) {
    super(name);
  }

  public void testGetReportName() throws Exception {
    String reportName = "Invoice Summary Report";
    ReportHeaderVariable reportHeaderVariable = new ReportHeaderVariable(reportName, new Date());
    assertEquals(reportName, reportHeaderVariable.getReportName());
  }

  public void testGetReportName_NullInput() throws Exception {
    ReportHeaderVariable reportHeaderVariable = new ReportHeaderVariable(null, new Date());
    assertEquals("", reportHeaderVariable.getReportName());
  }

  public void testGetReportDate() throws Exception {
    ReportHeaderVariable reportHeaderVariable = new ReportHeaderVariable("Invoice Summary Report", new Date());
    assertEquals("[" + DateUtil.getCurrentDate("MM/dd/yyyy HH:mm") + "]", reportHeaderVariable.getReportDate());
  }

  public void testGetReportDate_NullInput() throws Exception {
    ReportHeaderVariable reportHeaderVariable = new ReportHeaderVariable("Invoice Summary Report", null);
    assertEquals("", reportHeaderVariable.getReportDate());
  }
}