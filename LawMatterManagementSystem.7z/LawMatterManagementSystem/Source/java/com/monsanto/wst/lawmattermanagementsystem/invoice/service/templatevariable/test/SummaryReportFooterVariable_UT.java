/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.test;

import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.SummaryReportFooterVariable;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: SummaryReportFooterVariable_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class SummaryReportFooterVariable_UT extends TestCase {

  public SummaryReportFooterVariable_UT(String name) {
    super(name);
  }

  public void testGetSummaryFieldName() throws Exception {
    String summaryFieldName = "Total invoices";
    SummaryReportFooterVariable summaryReportFooterVariable = new SummaryReportFooterVariable(summaryFieldName, "57");
    assertEquals(summaryFieldName, summaryReportFooterVariable.getSummaryFieldName());
  }

  public void testGetSummaryFieldName_NullInput() throws Exception {
    String summaryFieldName = null;
    SummaryReportFooterVariable summaryReportFooterVariable = new SummaryReportFooterVariable(summaryFieldName, "57");
    assertEquals("", summaryReportFooterVariable.getSummaryFieldName());
  }

  public void testGetSummaryFieldValue() throws Exception {
    String summaryFieldValue = "57";
    SummaryReportFooterVariable summaryReportFooterVariable = new SummaryReportFooterVariable("Total invoices", summaryFieldValue);
    assertEquals(summaryFieldValue, summaryReportFooterVariable.getSummaryFieldValue());
  }

  public void testGetSummaryFieldValue_NullInput() throws Exception {
    String summaryFieldValue = null;
    SummaryReportFooterVariable summaryReportFooterVariable = new SummaryReportFooterVariable("Total invoices", summaryFieldValue);
    assertEquals("", summaryReportFooterVariable.getSummaryFieldValue());
  }

  public void testGetSummaryFieldSeperator() throws Exception {
    SummaryReportFooterVariable summaryReportFooterVariable = new SummaryReportFooterVariable(null, null);
    assertEquals(":", summaryReportFooterVariable.getSummaryFieldSeperator());
  }
}