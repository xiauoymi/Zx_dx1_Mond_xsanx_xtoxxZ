/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.test;

import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockInvoiceRecordDataUtility;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.SummaryReportRecordVariable;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: SummaryReportRecordVariable_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-26 20:54:09 $
 *
 * @author rdesai2
 * @version $Revision: 1.5 $
 */
public class SummaryReportRecordVariable_UT extends TestCase {

  public void testGetVendorNumber() throws Exception {
    SummaryReportRecordVariable summaryReportRecordVariable = new SummaryReportRecordVariable(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord());
    assertEquals("250099", summaryReportRecordVariable.getVendorNumber());
  }

  public void testGetVendorNumber_NullInvoiceRecord() throws Exception {
    SummaryReportRecordVariable summaryReportRecordVariable = new SummaryReportRecordVariable(null);
    assertEquals("", summaryReportRecordVariable.getVendorNumber());
  }

  public void testGetVendorName() throws Exception {
    SummaryReportRecordVariable summaryReportRecordVariable = new SummaryReportRecordVariable(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord());
    assertEquals("V-LAW", summaryReportRecordVariable.getVendorName());
  }

  public void testGetVendorName_NullInvoiceRecord() throws Exception {
    SummaryReportRecordVariable summaryReportRecordVariable = new SummaryReportRecordVariable(null);
    assertEquals("", summaryReportRecordVariable.getVendorName());
  }

  public void testGetInvoiceNumber() throws Exception {
    SummaryReportRecordVariable summaryReportRecordVariable = new SummaryReportRecordVariable(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord());
    assertEquals("invoice#1", summaryReportRecordVariable.getInvoiceNumber());
  }

  public void testGetInvoiceNumber_NullInvoiceRecord() throws Exception {
    SummaryReportRecordVariable summaryReportRecordVariable = new SummaryReportRecordVariable(null);
    assertEquals("", summaryReportRecordVariable.getInvoiceNumber());
  }

  public void testGetInvoiceDate() throws Exception {
    SummaryReportRecordVariable summaryReportRecordVariable = new SummaryReportRecordVariable(MockInvoiceRecordDataUtility.getDefaultInvoiceRecord());
    assertEquals(DateUtil.getCurrentDate("MM/dd/yyyy"), summaryReportRecordVariable.getInvoiceDate());
  }

  public void testGetInvoiceDate_NullInvoiceRecord() throws Exception {
    SummaryReportRecordVariable summaryReportRecordVariable = new SummaryReportRecordVariable(null);
    assertEquals("", summaryReportRecordVariable.getInvoiceDate());
  }

  public void testGetInvoiceAmount() throws Exception {
    SummaryReportRecordVariable summaryReportRecordVariable = new SummaryReportRecordVariable(MockInvoiceRecordDataUtility.getInvoiceRecordWithAmountVC(500.95));
    assertEquals("500.95", summaryReportRecordVariable.getInvoiceAmount());
  }

  public void testGetInvoiceAmount_NullInvoiceRecord() throws Exception {
    SummaryReportRecordVariable summaryReportRecordVariable = new SummaryReportRecordVariable(null);
    assertEquals("", summaryReportRecordVariable.getInvoiceAmount());
  }

  public void testGettersForSummaryReport_WithConstantValues() throws Exception {
    SummaryReportRecordVariable summaryReportRecordVariable;
    summaryReportRecordVariable = new SummaryReportRecordVariable("Vendor Num", "Vendor Name", "Invoice #", "Invoice Date", "Invoice AMT");
    assertEquals("Vendor Num", summaryReportRecordVariable.getVendorNumber());
    assertEquals("Vendor Name", summaryReportRecordVariable.getVendorName());
    assertEquals("Invoice #", summaryReportRecordVariable.getInvoiceNumber());
    assertEquals("Invoice Date", summaryReportRecordVariable.getInvoiceDate());
    assertEquals("Invoice AMT", summaryReportRecordVariable.getInvoiceAmount());
    summaryReportRecordVariable = new SummaryReportRecordVariable("----------", "-------------------", "-------------", "------------", "-----------");
    assertEquals("----------", summaryReportRecordVariable.getVendorNumber());
    assertEquals("-------------------", summaryReportRecordVariable.getVendorName());
    assertEquals("-------------", summaryReportRecordVariable.getInvoiceNumber());
    assertEquals("------------", summaryReportRecordVariable.getInvoiceDate());
    assertEquals("-----------", summaryReportRecordVariable.getInvoiceAmount());
  }

  public void testGettersForSummaryReport_WithConstantValues_ForNullCases() throws Exception {
    SummaryReportRecordVariable summaryReportRecordVariable;
    summaryReportRecordVariable = new SummaryReportRecordVariable(null, null, null, null, null);
    assertEquals("", summaryReportRecordVariable.getVendorNumber());
    assertEquals("", summaryReportRecordVariable.getVendorName());
    assertEquals("", summaryReportRecordVariable.getInvoiceNumber());
    assertEquals("", summaryReportRecordVariable.getInvoiceDate());
    assertEquals("", summaryReportRecordVariable.getInvoiceAmount());
  }
}