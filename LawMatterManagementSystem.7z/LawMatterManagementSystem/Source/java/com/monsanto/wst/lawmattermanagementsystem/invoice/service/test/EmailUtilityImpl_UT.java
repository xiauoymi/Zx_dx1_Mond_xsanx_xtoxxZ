/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.EmailDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockEmailDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockEmailDAOThrowsException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.EmailUtility;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.EmailUtilityImpl;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.mock.MockEmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.mock.MockEmailServiceThrowsException;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: EmailUtilityImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-08 22:32:39 $
 *
 * @author rdesai2
 * @version $Revision: 1.5 $
 */
public class EmailUtilityImpl_UT extends TestCase {

  public void testSendEmail() throws Exception {
    MockEmailDAO emailDAO = new MockEmailDAO();
    MockEmailService emailService = new MockEmailService();
    EmailUtility emailUtility = new EmailUtilityImpl(emailService, emailDAO);
    List customMessageLines = new ArrayList();
    customMessageLines.add("Invoice processing successful!!");
    List attachmentList = new ArrayList();
    attachmentList.add("C:/myFile.txt");
    emailUtility.sendEmail(customMessageLines, attachmentList);
    assertEquals("toEmail1@monsanto.com", emailService.getToList().get(0));
    assertEquals("ccEmail2@monsanto.com", emailService.getCcList().get(1));
    assertEquals(LMMSConstants.EMAIL_CONST_SUBJECT, emailService.getSubject());
    assertEquals("Invoice processing successful!!", emailService.getMessageLines().get(16));
    assertEquals("C:/myFile.txt", emailService.getAttachments().get(0));
  }

  public void testSendEmail_ThrowsException_IfDAOToGetTOListEncountersException() throws Exception {
    EmailDAO emailDAO = new MockEmailDAOThrowsException();
    MockEmailService emailService = new MockEmailService();
    EmailUtility emailUtility = new EmailUtilityImpl(emailService, emailDAO);
    List customMessageLines = new ArrayList();
    customMessageLines.add("Invoice processing successful!!");
    List attachmentList = new ArrayList();
    attachmentList.add("C:/myFile.txt");
    try {
      emailUtility.sendEmail(customMessageLines, attachmentList);
      fail("Required exception not thrown.");
    } catch (ServiceException e) {
      System.out.println("e.getMessage() = " + e.getMessage());
      System.out.println("e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testSendEmail_ThrowsException_IfDAOToGetCCListEncountersException() throws Exception {
    EmailDAO emailDAO = new MockEmailDAOThrowsException();
    MockEmailService emailService = new MockEmailService();
    EmailUtility emailUtility = new EmailUtilityImpl(emailService, emailDAO);
    List customMessageLines = new ArrayList();
    customMessageLines.add("Invoice processing successful!!");
    List attachmentList = new ArrayList();
    attachmentList.add("C:/myFile.txt");
    try {
      emailUtility.sendEmail(customMessageLines, attachmentList);
      fail("Required exception not thrown.");
    } catch (ServiceException e) {
      System.out.println("e.getMessage() = " + e.getMessage());
      System.out.println("e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testSendEmail_ThrowsException_IfEmailServiceEncountersException() throws Exception {
    EmailDAO emailDAO = new MockEmailDAO();
    EmailService emailService = new MockEmailServiceThrowsException();
    EmailUtility emailUtility = new EmailUtilityImpl(emailService, emailDAO);
    List customMessageLines = new ArrayList();
    customMessageLines.add("Invoice processing successful!!");
    List attachmentList = new ArrayList();
    attachmentList.add("C:/myFile.txt");
    try {
      emailUtility.sendEmail(customMessageLines, attachmentList);
      fail("Required exception not thrown.");
    } catch (ServiceException e) {
      System.out.println("e.getMessage() = " + e.getMessage());
      System.out.println("e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testSendSuccessStatusEmail() throws Exception {
    String invoiceFileName = "testRFBIBL.txt";
    MockEmailDAO emailDAO = new MockEmailDAO();
    MockEmailService emailService = new MockEmailService();
    EmailUtility emailUtility = new EmailUtilityImpl(emailService, emailDAO);
    List attachmentList = new ArrayList();
    attachmentList.add("C:/myFile.txt");
    emailUtility.sendSuccessStatusEmail(invoiceFileName, attachmentList);
    assertEquals("toEmail1@monsanto.com", emailService.getToList().get(0));
    assertEquals("ccEmail2@monsanto.com", emailService.getCcList().get(1));
    assertEquals(LMMSConstants.EMAIL_CONST_SUBJECT, emailService.getSubject());
    assertEquals("C:/myFile.txt", emailService.getAttachments().get(0));
    assertEquals(17, emailService.getMessageLines().size());
    assertEquals("The name of the file copied to SAP is : " + invoiceFileName, emailService.getMessageLines().get(16));
  }

  public void testSendFailureStatusEmail() throws Exception {
    MockEmailDAO emailDAO = new MockEmailDAO();
    MockEmailService emailService = new MockEmailService();
    EmailUtility emailUtility = new EmailUtilityImpl(emailService, emailDAO);
    List attachmentList = new ArrayList();
    attachmentList.add("C:/myFile.txt");
    emailUtility.sendFailureStatusEmail(attachmentList);
    assertEquals("toEmail1@monsanto.com", emailService.getToList().get(0));
    assertEquals("ccEmail2@monsanto.com", emailService.getCcList().get(1));
    assertEquals(LMMSConstants.EMAIL_CONST_SUBJECT, emailService.getSubject());
    assertEquals("C:/myFile.txt", emailService.getAttachments().get(0));
    assertEquals(20, emailService.getMessageLines().size());
    assertEquals("The CLP/SAP process FAILED !!", emailService.getMessageLines().get(16));
  }

  public void testSendNoEligibleInvoicesFoundEmail() throws Exception {
    String invoiceFileName = "testRFBIBL.txt";
    MockEmailDAO emailDAO = new MockEmailDAO();
    MockEmailService emailService = new MockEmailService();
    EmailUtility emailUtility = new EmailUtilityImpl(emailService, emailDAO);
    List attachmentList = new ArrayList();
    attachmentList.add("C:/myFile.txt");
    emailUtility.sendNoEligibleInvoicesFoundEmail(invoiceFileName, attachmentList);
    assertEquals("toEmail1@monsanto.com", emailService.getToList().get(0));
    assertEquals("ccEmail2@monsanto.com", emailService.getCcList().get(1));
    assertEquals(LMMSConstants.EMAIL_CONST_SUBJECT, emailService.getSubject());
    assertEquals("C:/myFile.txt", emailService.getAttachments().get(0));
    assertEquals(17, emailService.getMessageLines().size());
    assertEquals(LMMSConstants.EMAIL_NO_ELIGIBLE_INVOICES_FOUND, emailService.getMessageLines().get(16));
  }

  public void testSendEmailToAdmin() throws Exception {
    String message = "Some database error occured";
    MockEmailDAO emailDAO = new MockEmailDAO();
    MockEmailService emailService = new MockEmailService();
    EmailUtility emailUtility = new EmailUtilityImpl(emailService, emailDAO);
    emailUtility.sendEmailToAdmin(message);
    assertEquals("adminEmail1@monsanto.com", emailService.getToList().get(0));
    assertEquals(LMMSConstants.EMAIL_CONST_SUBJECT, emailService.getSubject());
    assertEquals(1, emailService.getMessageLines().size());
    assertEquals(message, emailService.getMessageLines().get(0));
  }

  public void testSendEmailToAdmin_ThrowsException_IfDAOToGetTOListEncountersException() throws Exception {
    String message = "Some database error occured";
    EmailDAO emailDAO = new MockEmailDAOThrowsException();
    MockEmailService emailService = new MockEmailService();
    EmailUtility emailUtility = new EmailUtilityImpl(emailService, emailDAO);
    try {
      emailUtility.sendEmailToAdmin(message);
      fail("Required exception not thrown.");
    } catch (ServiceException e) {
      System.out.println("e.getMessage() = " + e.getMessage());
      System.out.println("e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testSendEmailToAdmin_ThrowsException_IfEmailServiceEncountersException() throws Exception {
    String message = "Some database error occured";
    EmailDAO emailDAO = new MockEmailDAO();
    EmailService emailService = new MockEmailServiceThrowsException();
    EmailUtility emailUtility = new EmailUtilityImpl(emailService, emailDAO);
    try {
      emailUtility.sendEmailToAdmin(message);
      fail("Required exception not thrown.");
    } catch (ServiceException e) {
      System.out.println("e.getMessage() = " + e.getMessage());
      System.out.println("e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }
}