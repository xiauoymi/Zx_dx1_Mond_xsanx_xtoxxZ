package com.monsanto.wst.lawmattermanagementsystem.invoice.service.test;

import junit.framework.TestCase;
import com.monsanto.Util.date.DateUtil;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.lawmattermanagementsystem.check.XMLBuilder;
import com.monsanto.wst.lawmattermanagementsystem.check.ChecksVoidsXMLBuilder;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockInvoiceRecordDataUtility;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.test.MockAccountCodeXMLBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.apache.xpath.XPathAPI;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Jul 29, 2008
 * Time: 10:19:08 AM
 * To change this template use File | Settings | File Templates.
 */
public class InvoiceAcknowledgementServiceImpl_UT extends TestCase {
  //Test Class to test the creation of Request XML
  //and get the response back
  public void testInvoiceAcknowledgementXMLBuild() throws Exception {
    
    XMLBuilder xmlBuilder = new MockInvoiceAcknowledgementXMLBuilder();
    InvoiceRecord invoiceRecord = MockInvoiceRecordDataUtility.getDefaultInvoiceRecord();
    assertNotNull(invoiceRecord);
    Document document = xmlBuilder.buildInvoiceAcknowledgementXML(invoiceRecord);
    DOMUtil.outputXML(document);
    //Document outputDocument = teamConnectCheckDAO.callService(document);
    assertNotNull(document);
    Node inSentSAP = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InSentSAP");
    assertEquals("No", DOMUtil.getTextValue(inSentSAP));
    invoiceRecord.getInvoiceSummary().setInvoiceAcknowledged("Yes");
    document = xmlBuilder.buildInvoiceAcknowledgementXML(invoiceRecord);
    assertNotNull(document);
    DOMUtil.outputXML(document);
    inSentSAP = XPathAPI.selectSingleNode(document,"TeamConnectRequest/Invoice/Detail/InSentSAP");
    assertEquals("Yes", DOMUtil.getTextValue(inSentSAP));
  }



}
