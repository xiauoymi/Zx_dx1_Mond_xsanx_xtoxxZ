/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.test;

import com.monsanto.Util.FileUtil;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.mock.MockErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.*;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceFileWriter;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceFileWriterImpl;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: InvoiceFileWriterImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-05 16:43:40 $
 *
 * @author rdesai2
 * @version $Revision: 1.54 $
 */
public class InvoiceFileWriterImpl_UT extends LMMSBaseTestCase {

  private String invoiceFileName;
  private String testInvoiceFile;
  private int queueGroupNameRandomNumber = 57;
  private String testFileHeader = "***File-Header, QueueGroupName: CPINV" + DateUtil.getCurrentDate("MMdd")  + "057" + "***";
  private InvoiceFileWriter writer;
  private MockErrorReportWriter mockErrorReportWriter;

  protected void setUp() throws IOException {
    super.setUp();
    invoiceFileName = LMMSConstants.FILE_NAME_INVOICE_RFBIBLE_FILE;
    testInvoiceFile = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + "TestInvoiceFile.txt";
    writer = new InvoiceFileWriterImpl(new MockXMLTemplateFactory());
    mockErrorReportWriter = new MockErrorReportWriter();
  }

  protected void tearDown() throws Exception {
    deleteTemporaryFiles();
    super.tearDown();
  }

  public void testInitialize_CreatesInvoiceFile() throws Exception {
    writer.initialize(invoiceFileName, queueGroupNameRandomNumber, mockErrorReportWriter);
    File invoiceFileCreated = new File(System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + invoiceFileName);
    assertTrue(invoiceFileCreated.exists());
    writer.saveAndClose();
  }

  public void testInitialize_ThrowsException_IfHistoryDirSystemParamNotSet() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, "");
    try {
      writer.initialize(invoiceFileName, queueGroupNameRandomNumber, mockErrorReportWriter);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    resetFTPDirSystemParam();
  }

  public void testInitialize_ThrowsException_IfProblemEncounteredWhileCreatingInvoiceFile() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, "XO:");
    try {
      writer.initialize(invoiceFileName, queueGroupNameRandomNumber, mockErrorReportWriter);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    resetFTPDirSystemParam();
  }

  public void testInitialize_ThrowsServiceExceptionAndWritesToErrorLog_IfDataExceedsColumnLength_ForFileHeader() throws Exception {
    InvoiceFileWriter writer = new InvoiceFileWriterImpl(new MockFactoryReturnsXMLTemplateThatThrowsDECLException());
    try {
      writer.initialize(invoiceFileName, queueGroupNameRandomNumber, mockErrorReportWriter);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    writer.saveAndClose();
    assertTrue(mockErrorReportWriter.getLastRequestedErrorMessage().indexOf("Fatal Error: Data exceeded assigned column length while writing invoice file header") != -1);
    assertFalse(mockErrorReportWriter.isInvoiceDetailWritten());
  }

  public void testInitialize_WritesFileHeader() throws Exception {
    writer.initialize(invoiceFileName, queueGroupNameRandomNumber, mockErrorReportWriter);
    writer.saveAndClose();
    writeDataToTestInvoiceFile(testFileHeader);
    compareInvoiceFile();
  }

  public void testWriteInvoiceRecord_ThrowsException_IfCalledWithoutInitializing() throws Exception {
    try {
      writer.writeInvoiceRecord(null, mockErrorReportWriter, true, "RDESAI2");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testExceptionThrown_IfNullStringReturnedByXMLTemplate() throws Exception {
    InvoiceFileWriter writer = new InvoiceFileWriterImpl(new MockXMLTemplateFactoryReturningNullXMLTemplateService());
    try {
      writer.initialize(invoiceFileName, queueGroupNameRandomNumber, mockErrorReportWriter);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    writer.saveAndClose();
  }

  public void testSaveAndClose_ThrowsException_IfCalledBeforeInitializing() throws Exception {
    try {
      writer.saveAndClose();
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testSaveAndClose_ClosesTheFileStream_And_ThrowsException_IfCalledMoreThanOnce_SinceAnAttemptIsMadeToFlushDataAfterFileStreamIsClosed() throws Exception {
    writer.initialize(invoiceFileName, queueGroupNameRandomNumber, mockErrorReportWriter);
    writer.saveAndClose();
    try {
      writer.saveAndClose();
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testWriteInvoiceRecord() throws Exception {
    writer.initialize(invoiceFileName, queueGroupNameRandomNumber, mockErrorReportWriter);
    writer.writeInvoiceRecord(getTestInvoiceRecord1(), mockErrorReportWriter, true, "RDESAI2");
    writer.writeInvoiceRecord(getTestInvoiceRecord2(), mockErrorReportWriter, true, "RDESAI2");
    writer.saveAndClose();
    writeDataToTestInvoiceFile(
            testFileHeader
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestRecordHeader1()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTest31Record1()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestFirst40Record1()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTest50Record1()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestSecond40Record1()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestRecordHeader2()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTest21Record2()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTest50Record2()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTest40Record2()
    );
    compareInvoiceFile();
  }

  public void testWriteInvoiceRecord_WritesToErrorReportAndSkipsCurrentRecord_IfDataExccedsColumnLengthExceptionEncountered_OnRecordHeader() throws Exception {
    InvoiceFileWriter writer = new InvoiceFileWriterImpl(new MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForRecordHeader());
    writer.initialize(invoiceFileName, queueGroupNameRandomNumber, mockErrorReportWriter);
    writer.writeInvoiceRecord(getTestInvoiceRecord1(), mockErrorReportWriter, true, "RDESAI2");
    writer.saveAndClose();
    writeDataToTestInvoiceFile(
            testFileHeader
    );
    assertTrue(mockErrorReportWriter.getLastRequestedErrorMessage().indexOf("Data exceeded assigned column length while writing invoice record header") != -1);
    assertTrue(mockErrorReportWriter.isInvoiceDetailWritten());
    compareInvoiceFile();
  }

  public void testWriteInvoiceRecord_WritesToErrorReportAndSkipsCurrentRecord_IfDataExccedsColumnLengthExceptionEncountered_On2131Record() throws Exception {
    InvoiceFileWriter writer = new InvoiceFileWriterImpl(new MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForSpecificData());
    writer.initialize(invoiceFileName, queueGroupNameRandomNumber, mockErrorReportWriter);
    writer.writeInvoiceRecord(getTestInvoiceRecord1(), mockErrorReportWriter, true, "RDESAI2");
    writer.writeInvoiceRecord(getTestInvoiceRecord4(), mockErrorReportWriter, true, "RDESAI2");
    writer.saveAndClose();
    writeDataToTestInvoiceFile(
            testFileHeader
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestRecordHeader2()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTest21Record2()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTest50Record4()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTest40Record2()
    );
    assertTrue(mockErrorReportWriter.getLastRequestedErrorMessage().indexOf("Data exceeded assigned column length while writing 21/31 invoice record") != -1);
    assertTrue(mockErrorReportWriter.isInvoiceDetailWritten());
    compareInvoiceFile();
  }

  public void testWriteInvoiceRecord_WritesToErrorReportAndSkipsCurrentRecord_IfDataExccedsColumnLengthExceptionEncountered_On4050Record() throws Exception {
    InvoiceFileWriter writer = new InvoiceFileWriterImpl(new MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForSpecificData());
    writer.initialize(invoiceFileName, queueGroupNameRandomNumber, mockErrorReportWriter);
    writer.writeInvoiceRecord(getTestInvoiceRecord3(), mockErrorReportWriter, true, "RDESAI2");
    writer.writeInvoiceRecord(getTestInvoiceRecord2(), mockErrorReportWriter, true, "RDESAI2");
    writer.saveAndClose();
    writeDataToTestInvoiceFile(
            testFileHeader
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestRecordHeader1()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTest31Record3()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestFirst40Record1()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTest50Record1()
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestSecond40Record1()
    );
    assertTrue(mockErrorReportWriter.getLastRequestedErrorMessage().indexOf("Data exceeded assigned column length while writing 40/50 invoice record") != -1);
    assertTrue(mockErrorReportWriter.isInvoiceDetailWritten());
    compareInvoiceFile();
  }

  public void testWriteInvoiceRecord_ThrowsException_ForNullInvoiceRecord() throws Exception {
    writer.initialize(invoiceFileName, queueGroupNameRandomNumber, mockErrorReportWriter);
    try {
      writer.writeInvoiceRecord(null, mockErrorReportWriter, true, "RDESAI2");
      writer.saveAndClose();
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  private String getTestSecond40Record1() {
    return "***RecordType: 40, TaxCode: E0, AccountOrMatchCode: 11006622";
  }

  private void writeDataToTestInvoiceFile(String fileContents) throws IOException {
    FileUtil.write(testInvoiceFile, fileContents);
  }

  private String getTest40Record2() {
    return "***RecordType: 40, TaxCode: E0, AccountOrMatchCode: 11111111";
  }

  private String getTest50Record1() {
    return "***RecordType: 50, TaxCode: E0, AccountOrMatchCode: 90901090";
  }

  private String getTest50Record2() {
    return "***RecordType: 50, TaxCode: E0, AccountOrMatchCode: 22222222";
  }

  private String getTest50Record4() {
    return "***RecordType: 50, TaxCode: E0, AccountOrMatchCode: 44444444";
  }

  private String getTestFirst40Record1() {
    return "***RecordType: 40, TaxCode: E0, AccountOrMatchCode: 41700900";
  }

  private String getTest31Record1() {
    return "***RecordType: 31, TaxCode: ~, AccountOrMatchCode: corp-vendor-1";
  }

  private String getTest31Record3() {
    return "***RecordType: 31, TaxCode: ~, AccountOrMatchCode: corp-vendor-3";
  }

  private String getTest21Record2() {
    return "***RecordType: 21, TaxCode: ~, AccountOrMatchCode: corp-vendor-2";
  }

  private String getTestRecordHeader1() {
    return "***Record-Header, InvoiceSummaryDate: " + DateUtil.getDate("MMddyyyy", new Date()) + ", " +
            "CompanyCode: " + "5180" + ", Invoice#: " + "invoice#1" + ", PractiseArea: " + "practiseArea#1";
  }

  //Note: The company code gets converted to "5180" from "5114" as per the business requirement.
  private String getTestRecordHeader2() {
    return "***Record-Header, InvoiceSummaryDate: " + DateUtil.getDate("MMddyyyy", new Date()) + ", " +
            "CompanyCode: " + "5114" + ", Invoice#: " + "invoice#2" + ", PractiseArea: " + "practiseArea#2";
  }

  private InvoiceRecord getTestInvoiceRecord1() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "invoice#1", new Integer(1123), new Double(500.95), new Date(), "vendor1", "1234");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "corp-vendor-1", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-90901090", new Double(-100), "89888", new Integer(44), "testProfitCenter2", "WBS2", "ION2",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-11006622", new Double(400.95), "787778", new Integer(56), "testProfitCenter3", "WBS3", "ION3",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private InvoiceRecord getTestInvoiceRecord3() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "invoice#1", new Integer(1123), new Double(500.95), new Date(), "vendor1", "1234");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "corp-vendor-3", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-90901090", new Double(-100), "89888", new Integer(44), "testProfitCenter2", "WBS2", "ION2",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-11006622", new Double(400.95), "787778", new Integer(56), "testProfitCenter3", "WBS3", "ION3",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private InvoiceRecord getTestInvoiceRecord2() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "US$", "invoice#2", new Integer(333), new Double(-100.95), new Date(), "vendor5", "1234");
    Matter matter = new Matter("matter2", "practiseArea#2", "testMatter2", null);
    Vendor vendor = new Vendor("VendorType-NEW", "corp-vendor-2", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5114-9130-22222222", new Double(-100), "78787", new Integer(6565), "testProfitCenter22", "WBS23", "ION43",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5114-9130-11111111", new Double(200),  "232787", new Integer(335), "testProfitCenter22", "WBS43", "ION223",
        null));
    String professionalContactEmployeeId = "empId12234";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private InvoiceRecord getTestInvoiceRecord4() {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "US$", "invoice#2", new Integer(333), new Double(-100.95), new Date(), "vendor5", "1234");
    Matter matter = new Matter("matter2", "practiseArea#2", "testMatter2", null);
    Vendor vendor = new Vendor("VendorType-NEW", "corp-vendor-2", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5114-9130-44444444", new Double(-100), "78787", new Integer(6565), "testProfitCenter22", "WBS23", "ION43",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5114-9130-11111111", new Double(200),  "232787", new Integer(335), "testProfitCenter22", "WBS43", "ION223",
        null));
    String professionalContactEmployeeId = "empId12234";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private void compareInvoiceFile() throws IOException {
    String invoiceFile = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + invoiceFileName;
    assertTrue(FileUtil.compareFiles(testInvoiceFile, invoiceFile));
  }

  private void resetFTPDirSystemParam() {
    String currentHistoryDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
    if(currentHistoryDir != null) {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, currentHistoryDir);
    }
  }

  private void deleteTemporaryFiles() {
    deleteFile(invoiceFileName);
    deleteFile(testInvoiceFile);
  }

  //Not guaranteed!!
  private void deleteFile(String fileName) {
    File file = new File(fileName);
    if(file.exists()){
      file.delete();
    }
  }
}