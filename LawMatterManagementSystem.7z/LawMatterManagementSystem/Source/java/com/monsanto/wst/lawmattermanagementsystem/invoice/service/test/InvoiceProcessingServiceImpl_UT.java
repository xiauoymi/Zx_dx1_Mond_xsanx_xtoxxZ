/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.mock.MockErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockInvoiceDataDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockLastRunInfoDAO;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceProcessingService;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceProcessingServiceImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceAcknowledgmentService;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.mock.*;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.mock.*;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;

import java.io.IOException;
import java.text.SimpleDateFormat;

/**
 * Filename:    $RCSfile: InvoiceProcessingServiceImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-02-10 20:14:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.36 $
 */
public class InvoiceProcessingServiceImpl_UT extends LMMSBaseTestCase {

  private MockRecordValidationService mockRecordValidationService;
  private MockInvoiceRecordProcessingService mockInvoiceRecordProcessingService;
  private MockRejectionReportWriter mockRejectionReportWriter;
  private MockSAPFTPUtility mockSapftpUtility;
  private MockSummaryReportWriter mockSummaryReportWriter;
  private MockInvoiceFileWriter mockInvoiceFileWriter;
  private MockErrorReportWriter mockErrorReportWriter;
  private InvoiceProcessingService service;
  private MockInvoiceDataDAO mockInvoiceDataDAO;
  private PropertyList mockPropertyList;
  private MockLastRunInfoDAO mockLastRunInfoDAO;
  private InvoiceAcknowledgmentService invoiceAcknowledgmentService;

  public InvoiceProcessingServiceImpl_UT() throws Exception {
    mockPropertyList = new MockPropertyFileReaderReturnsRepostSpecificDateAsFalse() .readPropertyFile(null);
  }

  protected void setUp() throws IOException {
    super.setUp();
    mockRecordValidationService = new MockRecordValidationService();
    mockInvoiceRecordProcessingService = new MockInvoiceRecordProcessingService();
    mockRejectionReportWriter = new MockRejectionReportWriter();
    mockSapftpUtility = new MockSAPFTPUtility();
    mockSummaryReportWriter = new MockSummaryReportWriter();
    mockInvoiceFileWriter = new MockInvoiceFileWriter();
    mockErrorReportWriter = new MockErrorReportWriter();
    mockInvoiceDataDAO = new MockInvoiceDataDAO();
    mockLastRunInfoDAO = new MockLastRunInfoDAO();
    invoiceAcknowledgmentService = new MockInvoiceAcknowledgmentService();

    service = new InvoiceProcessingServiceImpl(mockInvoiceDataDAO, mockRecordValidationService, mockInvoiceFileWriter,
        mockSummaryReportWriter, mockRejectionReportWriter, mockSapftpUtility, mockLastRunInfoDAO, mockInvoiceRecordProcessingService, invoiceAcknowledgmentService);
  }

  public void testProcessInvoices_ThrowsException_ForNullPropertyList() throws Exception {
    try {
      service.processInvoices(null, null, null, null, null, null, null, null);
      fail("Required exception not thrown.");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testProcessInvoices_SendsCorrectContactName_ToInvoiceFileWriter() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, null, mockPropertyList, null, null, null));
    assertEquals(mockInvoiceFileWriter.getContactNameSent(), mockPropertyList.getPropertyValue(LMMSConstants.PROPERTY_CONTACT_NAME));
  }

  public void testProcessInvoices_SendsRepostDate_ToInvoiceDataDAO_IfRepostSpecificDateIsTrue() throws Exception {
    mockPropertyList = new MockPropertyFileReaderReturnsRepostSpecificDateAsTrue().readPropertyFile(null);
    assertTrue(service.processInvoices("clpinv.txt", null, null, null, mockPropertyList, null, null,null));
    assertEquals(mockInvoiceDataDAO.isRepostForSpecificDateRequired(), Boolean.valueOf(mockPropertyList.getPropertyValue(LMMSConstants.PROPERTY_REPOST_FOR_SPECIFIC_DATE)).booleanValue());
    assertEquals(mockInvoiceDataDAO.getSendAPDate(), new SimpleDateFormat(LMMSConstants.DATE_FORMAT_FOR_INVOICE_QUERY).parse(mockPropertyList.getPropertyValue(LMMSConstants.PROPERTY_REPOST_DATE)));
  }

  public void testProcessInvoices_SendsLastRunDate_ToInvoiceDataDAO_IfRepostSpecificDateIsFalse() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, null, mockPropertyList, null, null, null));
    assertEquals(mockInvoiceDataDAO.isRepostForSpecificDateRequired(), Boolean.valueOf(mockPropertyList.getPropertyValue(LMMSConstants.PROPERTY_REPOST_FOR_SPECIFIC_DATE)).booleanValue());
    assertTrue(mockLastRunInfoDAO.isInvoked());
    assertNotNull(mockInvoiceDataDAO.getProductionDate());
  }

  public void testProcessInvoices_IsInvoiceRecordProcessingCalled() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, null, mockPropertyList, null, null, null));
    assertTrue(mockInvoiceRecordProcessingService.isInvoked());
  }

  public void testProcessInvoices_ThrowsException_IfPropertyNotFound() throws Exception {
    InvoiceProcessingService service = new InvoiceProcessingServiceImpl(mockInvoiceDataDAO, mockRecordValidationService, mockInvoiceFileWriter, mockSummaryReportWriter, mockRejectionReportWriter, mockSapftpUtility, new MockLastRunInfoDAO(),
        null, invoiceAcknowledgmentService);
    try {
      service.processInvoices(null, null, null, null, new MockPropertyFileReaderReturnsEmptyList().readPropertyFile(null), null, null, null);
      fail("Required exception not thrown.");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testProcessInvoices_ThrowsException_IfDatePropertyInImproperFormat() throws Exception {
    InvoiceProcessingService service = new InvoiceProcessingServiceImpl(mockInvoiceDataDAO, mockRecordValidationService, mockInvoiceFileWriter, mockSummaryReportWriter, mockRejectionReportWriter, mockSapftpUtility, new MockLastRunInfoDAO(),
        null, invoiceAcknowledgmentService);
    try {
      service.processInvoices(null, null, null, null, new MockPropertyFileReaderReturnsDateInImproperFormat().readPropertyFile(null), null, null, null);
      fail("Required exception not thrown.");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testProcessInvoices_ThrowsException_IfBooleanPropertyInImproperFormat() throws Exception {
    InvoiceProcessingService service = new InvoiceProcessingServiceImpl(mockInvoiceDataDAO, mockRecordValidationService, mockInvoiceFileWriter, mockSummaryReportWriter, mockRejectionReportWriter, mockSapftpUtility, new MockLastRunInfoDAO(),
        null, invoiceAcknowledgmentService);
    try {
      service.processInvoices(null, null, null, null, new MockPropertyFileReaderReturnsBooleanInImproperFormat().readPropertyFile(null), null, null, null);
      fail("Required exception not thrown.");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testProcessInvoices_Initializes_InvoiceFileWriter() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    assertEquals(1, mockInvoiceFileWriter.numberOfTimesInitializeCalled());
  }

  public void testProcessInvoices_Initializes_SummaryReportWriter() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    assertEquals(1, mockSummaryReportWriter.numberOfTimesInitializeCalled());
  }

  public void testProcessInvoices_Initializes_RejectionReportWriter() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    assertEquals(1, mockRejectionReportWriter.numberOfTimesInitializeCalled());
  }

  public void testProcessInvoices_ReturnsTrue_NoInvoicesReturnedFromDAO() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
  }

  public void testProcessInvoices_ThrowsSeviceException_IfInvoiceDataDAOEncountersError() throws Exception {
    InvoiceProcessingService service = new InvoiceProcessingServiceImpl(new MockInvoiceDataDAOThrowsException(), mockRecordValidationService, mockInvoiceFileWriter, mockSummaryReportWriter, mockRejectionReportWriter, mockSapftpUtility, new MockLastRunInfoDAO(),
        null, invoiceAcknowledgmentService);
    try {
      service.processInvoices(null, null, null, mockErrorReportWriter, mockPropertyList, null, null, null);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testProcessInvoices_WritesInvalidRecords_ToRejectionReportWriter_AsErrorMessage() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    assertEquals("Invoice #1", mockRejectionReportWriter.getInvoiceRequested(0));
    assertEquals("Invoice #3", mockRejectionReportWriter.getInvoiceRequested(1));
  }

  public void testProcessInvoices_WritesValidRecords_ToInvoiceFileWriter() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    assertEquals("Invoice #2", mockInvoiceFileWriter.getInvoiceRequested(0));
    assertEquals("Invoice #4", mockInvoiceFileWriter.getInvoiceRequested(1));
  }

  public void testProcessInvoices_AcknowledgmentServiceCalled() throws Exception {
    service = new MockInvoiceProcessingService();
    service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null);
    assertFalse(((MockInvoiceProcessingService)service).isInvoiceSentToSAP("Invoice #3"));
    assertFalse(((MockInvoiceProcessingService)service).isInvoiceSentToSAP("Invoice #4"));
    assertTrue(((MockInvoiceProcessingService)service).isInvoiceSentToSAP("Invoice #1"));
    assertTrue(((MockInvoiceProcessingService)service).isInvoiceSentToSAP("Invoice #2"));

  }

  public void testProcessInvoices_WritesValidRecords_ToSummaryReportWriter() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    assertEquals("Invoice #2", mockSummaryReportWriter.getInvoiceRequested(0));
    assertEquals("Invoice #4", mockSummaryReportWriter.getInvoiceRequested(1));
  }

  public void testProcessInvoices_WritesRecordsWithNoProfitCenter_ToRejectionReportWriter_AsInfoMessage() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    assertEquals("Invoice #2", mockRejectionReportWriter.getListOfAllInvoiceNumberWithNoProfitCenter().get(0));
    assertEquals("1", mockRejectionReportWriter.getListOfAllAllocationsWithNoProfitCenter().get(0));
    assertEquals("Invoice #2", mockRejectionReportWriter.getListOfAllInvoiceNumberWithNoProfitCenter().get(1));
    assertEquals("2", mockRejectionReportWriter.getListOfAllAllocationsWithNoProfitCenter().get(1));
  }

  public void testProcessInvoices_SavesAndClosesAllWriters_ExceptErrorReportWriter_AfterProcessingAllRecords() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    assertTrue(mockRejectionReportWriter.saveAndCloseInvoked());
    assertTrue(mockSummaryReportWriter.saveAndCloseInvoked());
    assertTrue(mockInvoiceFileWriter.saveAndCloseInvoked());
    assertFalse(mockErrorReportWriter.saveAndCloseInvoked());
  }

  public void testProcessInvoices_DoesNotFTPToSAP_IfSkipFileFilePropertyIsSet() throws Exception {
    service = new InvoiceProcessingServiceImpl(mockInvoiceDataDAO, mockRecordValidationService,
        mockInvoiceFileWriter, mockSummaryReportWriter, mockRejectionReportWriter,
        mockSapftpUtility, new MockLastRunInfoDAO(), new MockInvoiceRecordProcessingService(), invoiceAcknowledgmentService);
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, new MockPropertyFileReaderReturnsSkipFileFTPPropertyAsTrue().readPropertyFile(null), null, null, null));
    assertFalse(mockSapftpUtility.invoked());
  }

  public void testProcessInvoices_DoesFTPToSAP_IfAtleastOneInvoiceRecordIsValid_AndSkipFileFTPPropertyIsReset() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    assertTrue(mockSapftpUtility.invoked());
  }

  public void testProcessInvoices_DoesFTPToSAP_CheckFileSNameentOverToSAP() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    String fileName = mockSapftpUtility.getFileName();
    boolean b = org.apache.commons.lang.StringUtils.contains(fileName, "txt");
    assertFalse(b);
  }

  public void testProcessInvoices_DoesNotFTPToSAP_IfAllInvoiceRecordsAreInvalid() throws Exception {
    InvoiceProcessingService service = new InvoiceProcessingServiceImpl
            (new MockInvoiceDataDAOReturnsEmptyList(), mockRecordValidationService, mockInvoiceFileWriter, mockSummaryReportWriter, mockRejectionReportWriter, mockSapftpUtility, new MockLastRunInfoDAO(),
                null, invoiceAcknowledgmentService);
    assertFalse(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    assertFalse(mockSapftpUtility.invoked());
  }

  public void testProcessInvoices_ReturnsTrue_IfEligibleOrValidInvoicesFound() throws Exception {
    assertTrue(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    assertTrue(mockSapftpUtility.invoked());
  }

  public void testProcessInvoices_ReturnsFalse_IfNoEligibleOrValidInvoicesFound() throws Exception {
    InvoiceProcessingService service = new InvoiceProcessingServiceImpl
            (new MockInvoiceDataDAOReturnsEmptyList(), mockRecordValidationService, mockInvoiceFileWriter, mockSummaryReportWriter, mockRejectionReportWriter, mockSapftpUtility, new MockLastRunInfoDAO(),
                null, invoiceAcknowledgmentService);
    assertFalse(service.processInvoices("clpinv.txt", null, null, mockErrorReportWriter, mockPropertyList, null, null, null));
    assertFalse(mockSapftpUtility.invoked());
  }
}