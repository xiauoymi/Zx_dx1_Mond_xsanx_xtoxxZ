/*
 InvoiceRecordProcessingServiceImpl_UT was created on Oct 4, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.test;

import junit.framework.TestCase;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceAllocation;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockInvoiceDataDAOForRecordValidation;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceRecordProcessingService;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceRecordProcessingServiceImpl;

import java.util.List;

/**
 * Filename:    $RCSfile: InvoiceRecordProcessingServiceImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-04 21:31:10 $
 *
 * @author vrbethi
 * @version $Revision: 1.1 $
 */
public class InvoiceRecordProcessingServiceImpl_UT extends TestCase {

  public void testProcessInvoiceRecords_RemoveAllOtherAllocationsIfThereIsOneWithHundredPCT() throws Exception {
    InvoiceRecord invoiceRecord = (InvoiceRecord) new MockInvoiceDataDAOForRecordValidation().
        getInvoiceRecordsWithMultipleAllcoations(false, null, null).get(6);
    InvoiceRecordProcessingService invoiceRecordProcessingService = new InvoiceRecordProcessingServiceImpl();
    invoiceRecordProcessingService.processInvoiceRecords(invoiceRecord);
    List list = invoiceRecord.getInvoiceAllocations();
    InvoiceAllocation invoiceAllocation = (InvoiceAllocation) list.get(0);
    assertEquals(1,list.size());
    assertEquals("100",invoiceAllocation.getAllocationPercentage());
  }
}