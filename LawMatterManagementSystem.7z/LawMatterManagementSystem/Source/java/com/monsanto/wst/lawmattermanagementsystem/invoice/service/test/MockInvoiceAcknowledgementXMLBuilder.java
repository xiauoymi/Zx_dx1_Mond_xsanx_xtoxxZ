package com.monsanto.wst.lawmattermanagementsystem.invoice.service.test;

import com.monsanto.wst.lawmattermanagementsystem.check.XMLBuilder;
import com.monsanto.wst.lawmattermanagementsystem.check.Check;
import com.monsanto.wst.lawmattermanagementsystem.check.ChecksVoidsXMLBuilder;
import com.monsanto.wst.lawmattermanagementsystem.voids.VoidCheck;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.importdocuments.DocumentMetaData;
import com.monsanto.Util.date.DateUtil;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Jul 29, 2008
 * Time: 11:37:09 AM
 * To change this template use File | Settings | File Templates.
 */
public class MockInvoiceAcknowledgementXMLBuilder implements XMLBuilder {
  public Document buildUpdateCheckXML(Check check) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Document buildRetrieveChecksXML(Check check) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Document buildRetrieveVoidCheckXML(VoidCheck voidCheck) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Document buildRetreiveTransactionXML(Check check) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Document buildUpdateVoidCheckXML(VoidCheck voidCheck, Check check) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Document buildUpdateAccountCodeXML(AccountCode accountCode) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Document buildUpdateDocumentXML(DocumentMetaData documentMetaData) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Document buildCloseAccountCodeUpdateAccountCodeXML(AccountCode accountCode, String autoClosedString, String autoCloseDate) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Document buildEditAccountCodeUpdateAccountCodeXML(AccountCode accountCode, String autoClosedString, String autoClosedDate) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Document buildOpenAccountCodeUpdateAccountCodeXML(AccountCode accountCode, String autoClosedString, String autoClosedDate) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Document buildInvoiceAcknowledgementXML(InvoiceRecord invoiceRecord) {
    
    XMLBuilder builder = new ChecksVoidsXMLBuilder();
    return builder.buildInvoiceAcknowledgementXML(invoiceRecord);
  }

  public Document buildUpdateCheckXMLWithPrimaryKey(Check check, String s) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  //New Method added for Updating Voids associated to checks and those cheks having multiple invoice ids in them
  public Document buildUpdateVoidCheckXMLWithPrimaryKey(VoidCheck voidCheck, String invoiceIdPK) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }
}
