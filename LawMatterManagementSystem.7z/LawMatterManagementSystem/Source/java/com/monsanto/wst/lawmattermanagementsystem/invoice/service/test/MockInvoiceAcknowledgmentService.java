package com.monsanto.wst.lawmattermanagementsystem.invoice.service.test;

import com.monsanto.wst.lawmattermanagementsystem.invoice.service.InvoiceAcknowledgmentService;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;

/**
 * Created by IntelliJ IDEA.
 * User: BGHALE
 * Date: Jul 29, 2008
 * Time: 10:01:02 AM
 * To change this template use File | Settings | File Templates.
 */
public class MockInvoiceAcknowledgmentService implements InvoiceAcknowledgmentService {
  private boolean wasAckInvCalled = false;

  public boolean invoiceAcknowledged() {
    return wasAckInvCalled;  //To change body of created methods use File | Settings | File Templates.
  }

  public String acknowledgeInvoice(InvoiceRecord invoiceRecord) {
    wasAckInvCalled= true;
    return "Success";
  }
}
