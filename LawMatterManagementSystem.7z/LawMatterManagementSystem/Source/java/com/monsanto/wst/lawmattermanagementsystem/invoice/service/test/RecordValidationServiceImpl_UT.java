/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockInvoiceDataDAOForRecordValidation;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.InvoiceRecord;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.ValidationMessageObject;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.RecordValidationService;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.RecordValidationServiceImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.mock.MockSAPVerificationService;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: RecordValidationServiceImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-09 20:30:22 $
 *
 * @author rdesai2
 * @version $Revision: 1.10 $
 */
public class RecordValidationServiceImpl_UT extends TestCase {

  public void testValidateRecord_PopulatesRespectiveErrorMessage_IfAccountCodeStringIsNull_Step1() throws Exception {
    RecordValidationService recordValidationService = new RecordValidationServiceImpl(new MockSAPVerificationService());
    InvoiceRecord invoiceRecord = (InvoiceRecord) new MockInvoiceDataDAOForRecordValidation().getInvoiceRecords_BadAccountCode(false, null, null).get(0);
    ValidationMessageObject messageObject = recordValidationService.validateRecord(invoiceRecord, "D08");
    assertNotNull(messageObject);
    assertEquals(LMMSConstants.SAP_ERROR_MSG_BAD_ACCOUNT_CODE, messageObject.getMessage());
    assertEquals(ValidationMessageObject.MESSAGE_TYPE_ERROR, messageObject.getMessageType());
    assertEquals(0, messageObject.getErroneousAllocationNumber());
  }

  public void testValidateRecord_PopulatesRespectiveErrorMessage_IfBadAccountCodeFound_Step1() throws Exception {
    RecordValidationService recordValidationService = new RecordValidationServiceImpl(new MockSAPVerificationService());
    final MockInvoiceDataDAOForRecordValidation mockInvoiceDataDAOForRecordValidation = new MockInvoiceDataDAOForRecordValidation();
    InvoiceRecord invoiceRecord = (InvoiceRecord) mockInvoiceDataDAOForRecordValidation.getInvoiceRecords(false, null, null, null).get(0);
    ValidationMessageObject messageObject = recordValidationService.validateRecord(invoiceRecord, "D08");
    assertNotNull(messageObject);
    assertEquals(LMMSConstants.SAP_ERROR_MSG_BAD_COST_ELEMENT, messageObject.getMessage());
    assertEquals(ValidationMessageObject.MESSAGE_TYPE_ERROR, messageObject.getMessageType());
    assertEquals(1, messageObject.getErroneousAllocationNumber());
  }

  public void testValidateRecord_PopulatesRespectiveErrorMessage_IfBadProfitCenterFound_Step2() throws Exception {
    String profitCenter = "INVALID_PROFIT_CENTER";
    RecordValidationService recordValidationService = new RecordValidationServiceImpl(new MockSAPVerificationService());
    final MockInvoiceDataDAOForRecordValidation mockInvoiceDataDAOForRecordValidation = new MockInvoiceDataDAOForRecordValidation();
    InvoiceRecord invoiceRecord = (InvoiceRecord) mockInvoiceDataDAOForRecordValidation.getInvoiceRecords(false, null, null, null).get(1);
    ValidationMessageObject messageObject = recordValidationService.validateRecord(invoiceRecord, "D08");
    assertNotNull(messageObject);
    assertEquals(ValidationMessageObject.MESSAGE_TYPE_ERROR, messageObject.getMessageType());    
    assertEquals("PROFIT CENTER: " + profitCenter + " IS NOT LEGAL IN SAP!", messageObject.getMessage());
    assertEquals(2, messageObject.getErroneousAllocationNumber());
  }

  public void testValidateRecord_PopulatesRespectiveErrorMessage_IfInvoiceNumberIsGreaterThan16Digits_Step3() throws Exception {
    RecordValidationService recordValidationService = new RecordValidationServiceImpl(new MockSAPVerificationService());
    final MockInvoiceDataDAOForRecordValidation mockInvoiceDataDAOForRecordValidation = new MockInvoiceDataDAOForRecordValidation();
    InvoiceRecord invoiceRecord = (InvoiceRecord) mockInvoiceDataDAOForRecordValidation.getInvoiceRecords(false, null, null, null).get(2);
    ValidationMessageObject messageObject = recordValidationService.validateRecord(invoiceRecord, "D08");
    assertNotNull(messageObject);
    assertEquals(ValidationMessageObject.MESSAGE_TYPE_ERROR, messageObject.getMessageType());        
    assertEquals(LMMSConstants.VALIDATION_ERROR_INVOICE_NUMBER_TOO_LONG, messageObject.getMessage());
    assertEquals(0, messageObject.getErroneousAllocationNumber());
  }

  public void testValidateRecord_PopulatesRespectiveErrorMessage_IfBadVendorIdFound_Step4() throws Exception {
    RecordValidationService recordValidationService = new RecordValidationServiceImpl(new MockSAPVerificationService());
    final MockInvoiceDataDAOForRecordValidation mockInvoiceDataDAOForRecordValidation = new MockInvoiceDataDAOForRecordValidation();
    InvoiceRecord invoiceRecord = (InvoiceRecord) mockInvoiceDataDAOForRecordValidation.getInvoiceRecords(false, null, null, null).get(3);
    ValidationMessageObject messageObject = recordValidationService.validateRecord(invoiceRecord, "D08");
    assertNotNull(messageObject);
    assertEquals(ValidationMessageObject.MESSAGE_TYPE_ERROR, messageObject.getMessageType());        
    assertEquals(LMMSConstants.SAP_ERROR_MSG_BAD_VENDOR_FOR_COMPANY, messageObject.getMessage());
    assertEquals(0, messageObject.getErroneousAllocationNumber());
  }

  public void testValidateRecord_PopulatesRespectiveErrorMessage_IfNoAllocationPayLCFoundNonZero_Step4() throws Exception {
    RecordValidationService recordValidationService = new RecordValidationServiceImpl(new MockSAPVerificationService());
    final MockInvoiceDataDAOForRecordValidation mockInvoiceDataDAOForRecordValidation = new MockInvoiceDataDAOForRecordValidation();
    InvoiceRecord invoiceRecord = (InvoiceRecord) mockInvoiceDataDAOForRecordValidation.getInvoiceRecords(false, null, null, null).get(7);
    ValidationMessageObject messageObject = recordValidationService.validateRecord(invoiceRecord, "D08");
    assertNotNull(messageObject);
    assertEquals(ValidationMessageObject.MESSAGE_TYPE_ERROR, messageObject.getMessageType());
    assertEquals(LMMSConstants.VALIDATION_ERROR_MSG_NO_NON_ZERO_ALLOCATION_AMOUNT_FOUND, messageObject.getMessage());
    assertEquals(0, messageObject.getErroneousAllocationNumber());
    assertEquals(false, messageObject.hasOneBusinessArea());
  }

  public void testValidateRecord_PopulatesCorrectStatus_ForNumberOfBusinessAreaFound_AfterAllFieldsAreValid_Step6() throws Exception {
    RecordValidationService recordValidationService = new RecordValidationServiceImpl(new MockSAPVerificationService());
    final MockInvoiceDataDAOForRecordValidation mockInvoiceDataDAOForRecordValidation = new MockInvoiceDataDAOForRecordValidation();
    InvoiceRecord invoiceRecord = (InvoiceRecord) mockInvoiceDataDAOForRecordValidation.getInvoiceRecords(false, null, null, null).get(4);
    ValidationMessageObject messageObject = recordValidationService.validateRecord(invoiceRecord, "D08");
    assertNotNull(messageObject);
    assertEquals(ValidationMessageObject.MESSAGE_TYPE_EMPTY, messageObject.getMessageType());        
    assertEquals(true, messageObject.hasOneBusinessArea());
    assertEquals("", messageObject.getMessage());
    assertEquals(0, messageObject.getErroneousAllocationNumber());

    recordValidationService = new RecordValidationServiceImpl(new MockSAPVerificationService());
    final MockInvoiceDataDAOForRecordValidation mockInvoiceDataDAOForRecordValidation1 = new MockInvoiceDataDAOForRecordValidation();
    invoiceRecord = (InvoiceRecord) mockInvoiceDataDAOForRecordValidation1.getInvoiceRecords(false, null, null, null).get(5);
    messageObject = recordValidationService.validateRecord(invoiceRecord, "D08");
    assertNotNull(messageObject);
    assertEquals(ValidationMessageObject.MESSAGE_TYPE_EMPTY, messageObject.getMessageType());
    assertEquals(false, messageObject.hasOneBusinessArea());
    assertEquals("", messageObject.getMessage());
    assertEquals(0, messageObject.getErroneousAllocationNumber());

    recordValidationService = new RecordValidationServiceImpl(new MockSAPVerificationService());
    final MockInvoiceDataDAOForRecordValidation mockInvoiceDataDAOForRecordValidation2 = new MockInvoiceDataDAOForRecordValidation();
    invoiceRecord = (InvoiceRecord) mockInvoiceDataDAOForRecordValidation2.getInvoiceRecords(false, null, null, null).get(6);
    messageObject = recordValidationService.validateRecord(invoiceRecord, "D08");
    assertNotNull(messageObject);
    assertEquals(ValidationMessageObject.MESSAGE_TYPE_EMPTY, messageObject.getMessageType());
    assertEquals(true, messageObject.hasOneBusinessArea());
    assertEquals("", messageObject.getMessage());
    assertEquals(0, messageObject.getErroneousAllocationNumber());
  }
}