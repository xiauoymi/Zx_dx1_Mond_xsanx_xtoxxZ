/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.test;

import com.monsanto.Util.FileUtil;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.mock.MockErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.*;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.RejectionReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.RejectionReportWriterImpl;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock.MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForReportHeader;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock.MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForSpecificData;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock.MockXMLTemplateFactory;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock.MockXMLTemplateFactoryReturningNullXMLTemplateService;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: RejectionReportWriterImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-05 16:43:40 $
 *
 * @author rdesai2
 * @version $Revision: 1.16 $
 */
public class RejectionReportWriterImpl_UT extends LMMSBaseTestCase {

  private String rejectionFileName;
  private String testRejectionFile;
  private RejectionReportWriter writer;
  private String testFileHeader = LMMSConstants.REJECTION_REPORT_NAME;
  private MockErrorReportWriter mockErrorReportWriter;

  protected void setUp() throws IOException {
    super.setUp();
    rejectionFileName = LMMSConstants.FILE_NAME_REJECTION_REPORT_FILE;
    testRejectionFile = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + "TestRejectionFile.txt";
    writer = new RejectionReportWriterImpl(new MockXMLTemplateFactory());
    mockErrorReportWriter = new MockErrorReportWriter();
  }

  protected void tearDown() throws Exception {
    deleteTemporaryFiles();
    super.tearDown();
  }

  public void testInitialize_CreatesRejectionFile() throws Exception {
    writer.initialize(rejectionFileName, mockErrorReportWriter);
    File invoiceFileCreated = new File(System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + rejectionFileName);
    assertTrue(invoiceFileCreated.exists());
    writer.saveAndClose();
  }

  public void testInitialize_ThrowsException_IfHistoryDirSystemParamNotSet() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, "");
    try {
      writer.initialize(rejectionFileName, mockErrorReportWriter);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    resetFTPDirSystemParam();
  }

  public void testInitialize_ThrowsException_IfProblemEncounteredWhileCreatingInvoiceFile() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, "XO:");
    try {
      writer.initialize(rejectionFileName, mockErrorReportWriter);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    resetFTPDirSystemParam();
  }

  public void testInitialize_WritesFileHeader_FieldNameTitleLine_And_SeperatorLine() throws Exception {
    writer.initialize(rejectionFileName, mockErrorReportWriter);
    writer.saveAndClose();
    writeDataToTestInvoiceFile(testFileHeader
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestRejectionRecord("Inv. Number", "Error Message")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestRejectionRecord("-----------", "-------------")
    );
    compareInvoiceFile();
  }

  public void testExceptionThrown_IfNullStringReturnedByXMLTemplate() throws Exception {
    RejectionReportWriter writer = new RejectionReportWriterImpl(new MockXMLTemplateFactoryReturningNullXMLTemplateService());
    try {
      writer.initialize(rejectionFileName, mockErrorReportWriter);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    writer.saveAndClose();
  }

  public void testSaveAndClose_ThrowsException_IfCalledBeforeInitializing() throws Exception {
    try {
      writer.saveAndClose();
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testSaveAndClose_ClosesTheFileStream_And_ThrowsException_IfCalledMoreThanOnce_SinceAnAttemptIsMadeToFlushDataAfterFileStreamIsClosed() throws Exception {
    writer.initialize(rejectionFileName, mockErrorReportWriter);
    writer.saveAndClose();
    try {
      writer.saveAndClose();
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testWriteRejectionRecord() throws Exception {
    String invoiceNumber1 = "Inv#1";
    String errorMsg1 = "Bad Company!";
    String invoiceNumber2 = "Inv#2";
    String errorMsg2 = "Bad Vendor!";
    writer.initialize(rejectionFileName, mockErrorReportWriter);
    writer.writeRejectionRecord(getTestInvoiceRecord(invoiceNumber1), errorMsg1, 0, mockErrorReportWriter);
    writer.writeRejectionRecord(getTestInvoiceRecord(invoiceNumber2), errorMsg2, 0, mockErrorReportWriter);
    writer.saveAndClose();
    writeDataToTestInvoiceFile(testFileHeader
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestRejectionRecord("Inv. Number", "Error Message")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestRejectionRecord("-----------", "-------------")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestRejectionRecord(invoiceNumber1, errorMsg1)
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestRejectionRecord(invoiceNumber2, errorMsg2)
    );
    compareInvoiceFile();
  }

  public void testInitialize_SkipsReportHeaderAndWritesToErrorLog_IFDataExceedsColumnLength() throws Exception {
    RejectionReportWriter writer = new RejectionReportWriterImpl(new MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForReportHeader());
    String invoiceNumber1 = "Inv#1";
    String errorMsg1 = "Bad Company!";
    String invoiceNumber2 = "Inv#2";
    String errorMsg2 = "Bad Vendor!";
    writer.initialize(rejectionFileName, mockErrorReportWriter);
    writer.writeRejectionRecord(getTestInvoiceRecord(invoiceNumber1), errorMsg1, 0, mockErrorReportWriter);
    writer.writeRejectionRecord(getTestInvoiceRecord(invoiceNumber2), errorMsg2, 0, mockErrorReportWriter);
    writer.saveAndClose();
    writeDataToTestInvoiceFile(
//            testFileHeader+
            LMMSConstants.NEW_LINE_CONSTANT
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestRejectionRecord("Inv. Number", "Error Message")
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestRejectionRecord("-----------", "-------------")
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestRejectionRecord(invoiceNumber1, errorMsg1)
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestRejectionRecord(invoiceNumber2, errorMsg2)
    );
    compareInvoiceFile();
    assertTrue(mockErrorReportWriter.getLastRequestedErrorMessage().indexOf("Data exceeded allocated column length while writing Rejection Report header") != -1);
    assertFalse(mockErrorReportWriter.isInvoiceDetailWritten());
  }

  public void testWriteRejectionRecord_SkipsSpecificRejectionReportRecordAndWritesToErrorLog_IFDataExceedsColumnLength() throws Exception {
    RejectionReportWriter writer = new RejectionReportWriterImpl(new MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForSpecificData());
    String invoiceNumber1 = "Inv#1";
    String errorMsg1 = "Bad Company!";
    String invoiceNumber3 = "Inv#3";
    String errorMsg3 = "Bad Vendor!";
    String invoiceNumber4 = "Inv#4";
    String errorMsg4 = "Bad SubAccount!";
    writer.initialize(rejectionFileName, mockErrorReportWriter);
    writer.writeRejectionRecord(getTestInvoiceRecord(invoiceNumber1), errorMsg1, 0, mockErrorReportWriter);
    writer.writeRejectionRecord(getTestInvoiceRecord(invoiceNumber3), errorMsg3, 0, mockErrorReportWriter);
    writer.writeRejectionRecord(getTestInvoiceRecord(invoiceNumber4), errorMsg4, 0, mockErrorReportWriter);
    writer.saveAndClose();
    writeDataToTestInvoiceFile(testFileHeader +
            LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestRejectionRecord("Inv. Number", "Error Message")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestRejectionRecord("-----------", "-------------")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestRejectionRecord(invoiceNumber1, errorMsg1)
//            + LMMSConstants.NEW_LINE_CONSTANT
//            + getTestRejectionRecord(invoiceNumber3, errorMsg3)
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestRejectionRecord(invoiceNumber4, errorMsg4)
    );
    compareInvoiceFile();
    assertTrue(mockErrorReportWriter.getLastRequestedErrorMessage().indexOf("Data exceeded allocated column length while writing Rejection Report record") != -1);
    assertTrue(mockErrorReportWriter.isInvoiceDetailWritten());
  }

  private InvoiceRecord getTestInvoiceRecord(String invoiceNumber) {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", invoiceNumber, new Integer(1123), new Double(500.95), new Date(), "vendor1", "1234");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "250099", "V-LAW");
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-90901090", new Double(-100), "89888", new Integer(44), "testProfitCenter2", "WBS2", "ION2",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-11006622", new Double(400.95), "787778", new Integer(56), "testProfitCenter3", "WBS3", "ION3",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private String getTestRejectionRecord(String invoiceNumber, String errorMsg) {
    return "***Rejection Record: " + invoiceNumber + " - " + errorMsg;
  }

  private void writeDataToTestInvoiceFile(String fileContents) throws IOException {
    FileUtil.write(testRejectionFile, fileContents);
  }

  private void compareInvoiceFile() throws IOException {
    String summaryFile = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + rejectionFileName;
    assertTrue(FileUtil.compareFiles(testRejectionFile, summaryFile));
  }

  private void resetFTPDirSystemParam() {
    String currentHistoryDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
    if(currentHistoryDir != null) {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, currentHistoryDir);
    }
  }

  private void deleteTemporaryFiles() {
    deleteFile(rejectionFileName);
    deleteFile(testRejectionFile);
  }

  /**
   * Not guaranteed!!
   */
  private void deleteFile(String fileName) {
    File file = new File(fileName);
    if(file.exists()){
      file.delete();
    }
  }
}