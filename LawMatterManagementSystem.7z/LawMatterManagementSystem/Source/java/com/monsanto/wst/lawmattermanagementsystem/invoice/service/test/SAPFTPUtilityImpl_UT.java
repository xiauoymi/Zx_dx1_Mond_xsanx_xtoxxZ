/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.test;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.mock.MockFTPService;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.mock.MockFTPServiceReturnsFalse;
import com.monsanto.wst.lawmattermanagementsystem.ftp.service.mock.MockFTPServiceThrowsException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.SAPFTPUtility;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.SAPFTPUtilityImpl;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;

/**
 * Filename:    $RCSfile: SAPFTPUtilityImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:24:54 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class SAPFTPUtilityImpl_UT extends TestCase {

  private String currentHistoryDir;

  protected void setUp() throws IOException {
    currentHistoryDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
    String tempDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_TEMP_DIR);
    if (StringUtils.isNullOrEmpty(tempDir)) {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, "C:");
    } else {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, tempDir);
    }
  }

  protected void tearDown() throws Exception {
    resetFTPDirSystemParam();
  }

  public void testFtpInvoiceFileToSAP() throws Exception {
    MockFTPService ftpService = new MockFTPService();
    SAPFTPUtility sapftpUtility = new SAPFTPUtilityImpl(ftpService);
    String invoiceFileName = "invoiceFileToTestSAPFTPUtility.txt";
    sapftpUtility.ftpInvoiceFileToSAP(invoiceFileName);
    assertEquals(System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + invoiceFileName, ftpService.getFileNameForUploadRequest());
  }

  public void testFtpInvoiceFileToSAP_ThrowsException_IfHistoryDirNotSet() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, "");
    SAPFTPUtility sapftpUtility = new SAPFTPUtilityImpl(new MockFTPService());
    try {
      sapftpUtility.ftpInvoiceFileToSAP("invoiceFileToTestSAPFTPUtility.txt");
      fail("Required exception not thrown.");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    resetFTPDirSystemParam();
  }

  public void testFtpInvoiceFileToSAP_ThrowsException_IfFTPServiceEncountersException() throws Exception {
    SAPFTPUtility sapftpUtility = new SAPFTPUtilityImpl(new MockFTPServiceThrowsException());
    try {
      sapftpUtility.ftpInvoiceFileToSAP("invoiceFileToTestSAPFTPUtility.txt");
      fail("Required exception not thrown.");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testFtpInvoiceFileToSAP_ThrowsException_IfUploadAttemptWasUnsuccessful() throws Exception {
    SAPFTPUtility sapftpUtility = new SAPFTPUtilityImpl(new MockFTPServiceReturnsFalse());
    try {
      sapftpUtility.ftpInvoiceFileToSAP("invoiceFileToTestSAPFTPUtility.txt");
      fail("Required exception not thrown.");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  private void resetFTPDirSystemParam() {
    if(currentHistoryDir != null) {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, currentHistoryDir);
    }
  }
}