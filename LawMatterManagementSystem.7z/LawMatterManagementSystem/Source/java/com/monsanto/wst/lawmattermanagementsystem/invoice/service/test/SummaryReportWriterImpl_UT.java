/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.invoice.service.test;

import com.monsanto.Util.FileUtil;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.errorreporter.mock.MockErrorReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.*;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.SummaryReportWriter;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.SummaryReportWriterImpl;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock.MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForReportHeader;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock.MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForSpecificData;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock.MockXMLTemplateFactory;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock.MockXMLTemplateFactoryReturningNullXMLTemplateService;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Filename:    $RCSfile: SummaryReportWriterImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-05 16:43:40 $
 *
 * @author rdesai2
 * @version $Revision: 1.19 $
 */
public class SummaryReportWriterImpl_UT extends LMMSBaseTestCase {

  private String summaryFileName;
  private String testSummaryFile;
  private SummaryReportWriter writer;
  private String testFileHeader = LMMSConstants.SUMMARY_REPORT_NAME;
  private MockErrorReportWriter mockErrorReportWriter;

  protected void setUp() throws IOException {
    super.setUp();
    summaryFileName = LMMSConstants.FILE_NAME_SUMMARY_REPORT_FILE;
    testSummaryFile = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + "TestSummaryFile.txt";
    writer = new SummaryReportWriterImpl(new MockXMLTemplateFactory());
    mockErrorReportWriter = new MockErrorReportWriter();
  }

  protected void tearDown() throws Exception {
    deleteTemporaryFiles();
    super.tearDown();
  }

  public void testInitialize_CreatesInvoiceFile() throws Exception {
    writer.initialize(summaryFileName, mockErrorReportWriter);
    File invoiceFileCreated = new File(System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + summaryFileName);
    assertTrue(invoiceFileCreated.exists());
    writer.saveAndClose(mockErrorReportWriter);
  }

  public void testInitialize_ThrowsException_IfHistoryDirSystemParamNotSet() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, "");
    try {
      writer.initialize(summaryFileName, mockErrorReportWriter);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    resetFTPDirSystemParam();
  }

  public void testInitialize_ThrowsException_IfProblemEncounteredWhileCreatingInvoiceFile() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, "XO:");
    try {
      writer.initialize(summaryFileName, mockErrorReportWriter);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    resetFTPDirSystemParam();
  }

  public void testExceptionThrown_IfNullStringReturnedByXMLTemplate() throws Exception {
    SummaryReportWriter writer = new SummaryReportWriterImpl(new MockXMLTemplateFactoryReturningNullXMLTemplateService());
    try {
      writer.initialize(summaryFileName, mockErrorReportWriter);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testSaveAndClose_ThrowsException_IfCalledBeforeInitializing() throws Exception {
    try {
      writer.saveAndClose(mockErrorReportWriter);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testSaveAndClose_ClosesTheFileStream_And_ThrowsException_IfCalledMoreThanOnce_SinceAnAttemptIsMadeToFlushDataAfterFileStreamIsClosed() throws Exception {
    writer.initialize(summaryFileName, mockErrorReportWriter);
    writer.saveAndClose(mockErrorReportWriter);
    try {
      writer.saveAndClose(mockErrorReportWriter);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testInitializeFollowedBySaveAndClose_WritesReportHeaderAndSummaryFooter() throws Exception {
    writer.initialize(summaryFileName, mockErrorReportWriter);
    writer.saveAndClose(mockErrorReportWriter);
    writeDataToTestInvoiceFile(testFileHeader
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord("Vendor Name", "Invoice AMT")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord("-------------------", "-----------")
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICES + " : 0"
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICE_AMOUNT + " : 0.00"
    );
    compareInvoiceFile();
  }

  public void testWriteInvoiceRecordSummary() throws Exception {
    String vendorName1 = "Bryan Cave";
    Double invoiceAmount1 = new Double(500.95);
    String vendorName2 = "Howrey LLP";
    Double invoiceAmount2 = new Double(200);
    writer.initialize(summaryFileName, mockErrorReportWriter);
    writer.writeInvoiceRecordSummary(getTestInvoiceRecord(vendorName1, invoiceAmount1), mockErrorReportWriter);
    writer.writeInvoiceRecordSummary(getTestInvoiceRecord(vendorName2, invoiceAmount2), mockErrorReportWriter);
    writer.saveAndClose(mockErrorReportWriter);
    writeDataToTestInvoiceFile(testFileHeader
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord("Vendor Name", "Invoice AMT")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord("-------------------", "-----------")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord(vendorName1, invoiceAmount1)
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord(vendorName2, invoiceAmount2)
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICES + " : 2"
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICE_AMOUNT + " : 700.95"
    );
    compareInvoiceFile();
  }

  public void testInitialize_SkipsReportHeaderAndWritesToErrorLog_IFDataExceedsColumnLength() throws Exception {
    SummaryReportWriter writer = new SummaryReportWriterImpl(new MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForReportHeader());
    String vendorName1 = "Rasesh Desai";
    Double invoiceAmount1 = new Double(600.50);
    String vendorName2 = "Howrey LLP";
    Double invoiceAmount2 = new Double(3500);
    writer.initialize(summaryFileName, mockErrorReportWriter);
    writer.writeInvoiceRecordSummary(getTestInvoiceRecord(vendorName1, invoiceAmount1), mockErrorReportWriter);
    writer.writeInvoiceRecordSummary(getTestInvoiceRecord(vendorName2, invoiceAmount2), mockErrorReportWriter);
    writer.saveAndClose(mockErrorReportWriter);
    writeDataToTestInvoiceFile(
//            testFileHeader +
            LMMSConstants.NEW_LINE_CONSTANT
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestSummaryRecord("Vendor Name", "Invoice AMT")
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestSummaryRecord("-------------------", "-----------")
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestSummaryRecord(vendorName1, invoiceAmount1)
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + getTestSummaryRecord(vendorName2, invoiceAmount2)
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICES + " : 2"
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + LMMSConstants.NEW_LINE_CONSTANT
                    + LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICE_AMOUNT + " : 4100.50"
    );
    compareInvoiceFile();
    System.out.println(mockErrorReportWriter.getLastRequestedErrorMessage());
    assertTrue(mockErrorReportWriter.getLastRequestedErrorMessage().indexOf("Data exceeded allocated column length while writing Invoice Summary Report Header") != -1);
    assertFalse(mockErrorReportWriter.isInvoiceDetailWritten());
  }

  public void testWriteInvoiceRecordSummary_SkipsInvoiceRecord_IFDataExceedsColumnLength_ForSummaryRecord() throws Exception {
    SummaryReportWriter writer = new SummaryReportWriterImpl(new MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForSpecificData());
    String vendorName1 = "Bryan Cave";
    Double invoiceAmount1 = new Double(500.95);
    String vendorName2 = "Howrey LLP";
    Double invoiceAmount2 = new Double(200);
    writer.initialize(summaryFileName, mockErrorReportWriter);
    writer.writeInvoiceRecordSummary(getTestInvoiceRecord(vendorName1, invoiceAmount1), mockErrorReportWriter);
    writer.writeInvoiceRecordSummary(getTestInvoiceRecord(vendorName2, invoiceAmount2), mockErrorReportWriter);
    writer.saveAndClose(mockErrorReportWriter);
    writeDataToTestInvoiceFile(testFileHeader
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord("Vendor Name", "Invoice AMT")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord("-------------------", "-----------")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord(vendorName2, invoiceAmount2)
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICES + " : 2"
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICE_AMOUNT + " : 700.95"
    );
    compareInvoiceFile();
    assertTrue(mockErrorReportWriter.getLastRequestedErrorMessage().indexOf("Data exceeded allocated column length for Summary record") != -1);
    assertTrue(mockErrorReportWriter.isInvoiceDetailWritten());
  }

  public void testWriteInvoiceRecordSummary_SkipsTotalInvoiceFooter_IFDataExceedsColumnLength() throws Exception {
    SummaryReportWriter writer = new SummaryReportWriterImpl(new MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForSpecificData());
    String vendorName1 = "Rasesh Desai";
    Double invoiceAmount1 = new Double(300);
    String vendorName2 = "Howrey LLP";
    Double invoiceAmount2 = new Double(200);
    String vendorName3 = "Ram Bethina";
    Double invoiceAmount3 = new Double(100);
    writer.initialize(summaryFileName, mockErrorReportWriter);
    writer.writeInvoiceRecordSummary(getTestInvoiceRecord(vendorName1, invoiceAmount1), mockErrorReportWriter);
    writer.writeInvoiceRecordSummary(getTestInvoiceRecord(vendorName2, invoiceAmount2), mockErrorReportWriter);
    writer.writeInvoiceRecordSummary(getTestInvoiceRecord(vendorName3, invoiceAmount3), mockErrorReportWriter);
    writer.saveAndClose(mockErrorReportWriter);
    writeDataToTestInvoiceFile(testFileHeader
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord("Vendor Name", "Invoice AMT")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord("-------------------", "-----------")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord(vendorName1, invoiceAmount1)
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord(vendorName2, invoiceAmount2)
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord(vendorName3, invoiceAmount3)
//            + LMMSConstants.NEW_LINE_CONSTANT
//            + LMMSConstants.NEW_LINE_CONSTANT
//            + LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICES + " : 3"
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICE_AMOUNT + " : 600.00"
    );
    compareInvoiceFile();
    System.out.println(mockErrorReportWriter.getLastRequestedErrorMessage());
    assertTrue(mockErrorReportWriter.getLastRequestedErrorMessage().indexOf("Error: Invoice Summary for total invoices skipped") != -1);
    assertFalse(mockErrorReportWriter.isInvoiceDetailWritten());
  }

  public void testWriteInvoiceRecordSummary_SkipsTotalInvoiceAmountFooter_IFDataExceedsColumnLength() throws Exception {
    SummaryReportWriter writer = new SummaryReportWriterImpl(new MockFactoryReturnsXMLTemplateThatThrowsDECLExceptionForSpecificData());
    String vendorName1 = "Rasesh Desai";
    Double invoiceAmount1 = new Double(600.50);
    String vendorName2 = "Howrey LLP";
    Double invoiceAmount2 = new Double(500);
    writer.initialize(summaryFileName, mockErrorReportWriter);
    writer.writeInvoiceRecordSummary(getTestInvoiceRecord(vendorName1, invoiceAmount1), mockErrorReportWriter);
    writer.writeInvoiceRecordSummary(getTestInvoiceRecord(vendorName2, invoiceAmount2), mockErrorReportWriter);
    writer.saveAndClose(mockErrorReportWriter);
    writeDataToTestInvoiceFile(testFileHeader
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord("Vendor Name", "Invoice AMT")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord("-------------------", "-----------")
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord(vendorName1, invoiceAmount1)
            + LMMSConstants.NEW_LINE_CONSTANT
            + getTestSummaryRecord(vendorName2, invoiceAmount2)
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.NEW_LINE_CONSTANT
            + LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICES + " : 2"
//            + LMMSConstants.NEW_LINE_CONSTANT
//            + LMMSConstants.NEW_LINE_CONSTANT
//            + LMMSConstants.SUMMARY_REPORT_TOTAL_INVOICE_AMOUNT + " : 1100.50"
    );
    compareInvoiceFile();
    System.out.println(mockErrorReportWriter.getLastRequestedErrorMessage());
    assertTrue(mockErrorReportWriter.getLastRequestedErrorMessage().indexOf("Error: Invoice Summary for total invoice amount skipped") != -1);
    assertFalse(mockErrorReportWriter.isInvoiceDetailWritten());
  }

  private String getTestSummaryRecord(String vendorName, Double invoiceAmount) {
    return "***Summary Record: " + vendorName + " - " + new DecimalFormat(LMMSConstants.PATTERN_AMOUNT).format(invoiceAmount);
  }

  private String getTestSummaryRecord(String vendorName, String invoiceAmount) {
    return "***Summary Record: " + vendorName + " - " + invoiceAmount;
  }

  private InvoiceRecord getTestInvoiceRecord(String vendorShortName, Double amountInVendorCurrency) {
    InvoiceSummary invoiceSummary = new InvoiceSummary(new Date(), "USD", "1", new Integer(1123), amountInVendorCurrency, new Date(), "vendor1", "1234");
    Matter matter = new Matter("matter1", "practiseArea#1", "testMatter", null);
    Vendor vendor = new Vendor("VendorType-LAW", "1", vendorShortName);
    List invoiceAllocations = new ArrayList();
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-41700900", new Double(200), "78787", new Integer(2), "testProfitCenter", "WBS1", "ION1",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-90901090", new Double(-100), "89888", new Integer(44), "testProfitCenter2", "WBS2", "ION2",
        null));
    invoiceAllocations.add(new InvoiceAllocation("5180-9130-11006622", new Double(400.95), "787778", new Integer(56), "testProfitCenter3", "WBS3", "ION3",
        null));
    String professionalContactEmployeeId = "empId334";
    return new InvoiceRecord(invoiceSummary, professionalContactEmployeeId, vendor, invoiceAllocations, matter);
  }

  private void writeDataToTestInvoiceFile(String fileContents) throws IOException {
    FileUtil.write(testSummaryFile, fileContents);
  }

  private void compareInvoiceFile() throws IOException {
    String summaryFile = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR) + File.separator + summaryFileName;
    assertTrue(FileUtil.compareFiles(testSummaryFile, summaryFile));
  }

  private void resetFTPDirSystemParam() {
    String currentHistoryDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
    if (currentHistoryDir != null) {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, currentHistoryDir);
    }
  }

  private void deleteTemporaryFiles() {
    deleteFile(summaryFileName);
    deleteFile(testSummaryFile);
  }

  /**
   * Not guaranteed!!
   */
  private void deleteFile(String fileName) {
    File file = new File(fileName);
    if (file.exists()) {
      file.delete();
    }
  }
}