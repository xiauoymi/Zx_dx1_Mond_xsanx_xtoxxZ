/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mail.service;

import java.util.List;

/**
 * Filename:    $RCSfile: EmailService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2006-12-19 16:34:04 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public interface EmailService {

  /**
   * This is the service to send emails for LMMS.
   *
   * @param from - sender's email address
   * @param toList - List of recipients to whom email should be sent
   * @param ccList - List of recipients to whom the email needs to be copied.
   * @param subject - Subject of the email.
   * @param attachments - List of absolute paths for all the attachments.
   * @param messageLines - Seperate lines in a message
   * @return boolean - true, if email sent successfully
   *                 - false, otherwise
   */
  boolean sendEmail(String from, List toList, List ccList, String subject, List attachments, List messageLines) throws EmailException;
}