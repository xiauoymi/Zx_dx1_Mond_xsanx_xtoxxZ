/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Mail.InvalidFormatException;
import com.monsanto.Mail.MailDocument;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailException;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.util.XMLEmailBuilder;
import com.monsanto.wst.lawmattermanagementsystem.mail.util.XMLEmailBuilderException;
import org.w3c.dom.Document;

import java.util.List;

/**
 * Filename:    $RCSfile: JavaMailEmailService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.8 $
 */
public class JavaMailEmailService implements EmailService {

  private XMLEmailBuilder xmlEmailBuilder;
  private MailDocumentFactory mailDocumentFactory;

  public JavaMailEmailService(MailDocumentFactory mailDocumentFactory, XMLEmailBuilder xmlEmailBuilder) {
    this.xmlEmailBuilder = xmlEmailBuilder;
    this.mailDocumentFactory = mailDocumentFactory;
  }

  public boolean sendEmail(String from, List toList, List ccList, String subject, List attachments, List messageLines) throws EmailException {
    Document xmlEmail = getXMLEmail(from, toList, ccList, subject, attachments, messageLines);
    MailDocument mailDocument = mailDocumentFactory.getMailDocument(MailDocumentFactoryImpl.TYPE_JAVA_MAIL_MAIL_DOCUMENT, xmlEmail);
    send(mailDocument);
    return true;
  }

  private void send(MailDocument mailDocument) throws EmailException {
    try {
      mailDocument.send();
    } catch (InvalidFormatException e) {
      Logger.log(new LoggableError(e));
      throw new EmailException("Error sending email", e);
    }
  }

  private Document getXMLEmail(String from, List toList, List ccList, String subject, List attachments, List messageLines) throws EmailException {
    Document xmlEmail;
    try {
      xmlEmail = xmlEmailBuilder.getEmailParametersAsXML(toList, ccList, from, subject, messageLines, attachments);
    } catch (XMLEmailBuilderException e) {
      Logger.log(new LoggableError(e));
      throw new EmailException("Error getting XMLEmail representation.", e);
    }
    return xmlEmail;
  }
}