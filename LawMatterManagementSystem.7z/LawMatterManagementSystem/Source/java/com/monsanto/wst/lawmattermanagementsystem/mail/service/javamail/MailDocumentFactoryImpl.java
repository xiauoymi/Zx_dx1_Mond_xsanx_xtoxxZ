/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.JavaMail.JavaMailMailDocument;
import com.monsanto.Mail.MailDocument;
import com.monsanto.Mail.MessageParseException;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailException;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: MailDocumentFactoryImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class MailDocumentFactoryImpl implements MailDocumentFactory {

  public static final String TYPE_JAVA_MAIL_MAIL_DOCUMENT = "javaMailMailDocument";

  public MailDocument getMailDocument(String type, Document xmlEmailDocument) throws EmailException {
    if (TYPE_JAVA_MAIL_MAIL_DOCUMENT.equalsIgnoreCase(type)) {
      return getJavaMailMailDocument(xmlEmailDocument);
    }
    throw new IllegalArgumentException("Invalid Mail Document Type requested: '" + type + "'");
  }

  private MailDocument getJavaMailMailDocument(Document xmlEmailDocument) throws EmailException {
    MailDocument mailDocument;
    try {
      mailDocument = new JavaMailMailDocument(xmlEmailDocument);
    } catch (MessageParseException e) {
      Logger.log(new LoggableError(e));
      throw new EmailException("Error instantiating MailDocument", e);
    }
    return mailDocument;
  }
}