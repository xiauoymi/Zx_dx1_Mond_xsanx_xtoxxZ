/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.acceptancetest;

import com.monsanto.Util.FileUtil;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.JavaMailEmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.MailDocumentFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.mail.util.dom.XMLEmailBuilderDOMImpl;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: JavaMailEmailService_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-19 23:23:04 $
 *
 * @author rdesai2
 * @version $Revision: 1.10 $
 */
public class JavaMailEmailService_AT extends TestCase {

  protected void setUp() throws IOException {
    FileUtil.write("C:/testFile1.txt", "Some Test Contents.");
  }

  public void testSendEmail() throws Exception {
    EmailService service = new JavaMailEmailService(new MailDocumentFactoryImpl(), new XMLEmailBuilderDOMImpl());

    List toList = getTOList();
    List ccList = getCCList();
    List attachments = getAttachments();
    List messageLines = addCustomMessage(LMMSConstants.EMAIL_CONST_DEFAULT_MESSAGE_LINES, "The name of the file copied to SAP is : clpinv200712112230");

    assertTrue(service.sendEmail(
            LMMSConstants.EMAIL_CONST_FROM,
            toList,
            ccList,
            LMMSConstants.EMAIL_CONST_SUBJECT,
            attachments,
            messageLines));
  }

  public void testSendEmailWithMinimalParameters() throws Exception {
    EmailService service = new JavaMailEmailService(new MailDocumentFactoryImpl(), new XMLEmailBuilderDOMImpl());

    List toList = getTOList();
    List ccList = null;
    List attachments = null;
    List messageLines = new ArrayList();
    messageLines.add("Brief Message.");

    assertTrue(service.sendEmail(
            LMMSConstants.EMAIL_CONST_FROM,
            toList,
            ccList,
            "Email with minimal parameters",
            attachments,
            messageLines));
  }

  private List addCustomMessage(List defaultMessageLines, String customMessage) {
    List messageLines = new ArrayList();
    for (int i = 0; i < defaultMessageLines.size(); i++) {
      messageLines.add(defaultMessageLines.get(i));
    }
    messageLines.add(customMessage);
    return messageLines;
  }

  private List getAttachments() {
    List attachments = new ArrayList();
    attachments.add("C:/testFile1.txt");
    return attachments;
  }

  private List getTOList() {
    List toList = new ArrayList();
    toList.add("TestUser@Woodstork.na.ds.monsanto.com");
    return toList;
  }

  private List getCCList() {
    List ccList = new ArrayList();
    ccList.add("CC_Recipient1@Woodstork.na.ds.monsanto.com");
    ccList.add("CC_Recipient2@Woodstork.na.ds.monsanto.com");
    return ccList;
  }

  protected void tearDown() throws Exception {
    File file = new File("C:/testFile1.txt");
    deleteFile(file);
  }

  private void deleteFile(File file) {
    if(file.exists()){
      file.delete();
    }
  }
}