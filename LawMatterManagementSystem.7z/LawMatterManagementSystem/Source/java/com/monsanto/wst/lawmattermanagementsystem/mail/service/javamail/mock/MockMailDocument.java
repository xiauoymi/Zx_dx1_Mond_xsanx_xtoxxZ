/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.mock;

import com.monsanto.Mail.InvalidFormatException;
import com.monsanto.Mail.MailAttachmentIterator;
import com.monsanto.Mail.MailDocument;
import com.monsanto.Mail.MessageParseException;
import org.w3c.dom.Document;

import java.util.Date;

/**
 * Filename:    $RCSfile: MockMailDocument.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockMailDocument implements MailDocument {

  public void send() throws InvalidFormatException {
    System.out.println("Mock email sent out...");
  }

  public MailAttachmentIterator getAttachmentIterator() {
    return null;
  }

  public Date getRecievedDate() {
    return null;
  }

  public Document toXML() throws MessageParseException {
    return null;
  }

  public void setAttachmentSavePath(String path) {
  }

  public Document getMessageBody() throws MessageParseException {
    return null;
  }
}