/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.mock;

import com.monsanto.Mail.MailDocument;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailException;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.MailDocumentFactory;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: MockMailDocumentFactoryThatThrowsException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockMailDocumentFactoryThatThrowsException implements MailDocumentFactory {

  public MailDocument getMailDocument(String type, Document xmlEmailDocument) throws EmailException {
    return new MockMailDocumentThatThrowsExceptionOnSend();
  }
}