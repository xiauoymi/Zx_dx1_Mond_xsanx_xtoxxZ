/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.test;

import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailException;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.JavaMailEmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.mock.MockMailDocumentFactory;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.mock.MockMailDocumentFactoryThatThrowsException;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.mock.MockXMLEmailBuilderThatThrowsException;
import com.monsanto.wst.lawmattermanagementsystem.mail.util.dom.XMLEmailBuilderDOMImpl;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: JavaMailEmailService_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class JavaMailEmailService_UT extends TestCase {

  public void testSendEmail() throws Exception {
    EmailService emailService = new JavaMailEmailService(new MockMailDocumentFactory(), new XMLEmailBuilderDOMImpl());
    List toList = new ArrayList();
    toList.add("user2@domain.com");
    assertTrue(emailService.sendEmail("user1@domain.com", toList, null, "test subject", null, null));
  }

  public void testSendEmail_ThrowsException_IfThereIsAProblemWhileCreatingXMLEmailDocument() throws Exception {
    EmailService emailService = new JavaMailEmailService(new MockMailDocumentFactory(), new MockXMLEmailBuilderThatThrowsException());
    List toList = new ArrayList();
    toList.add("user2@domain.com");
    try {
      emailService.sendEmail("user1@domain.com", toList, null, "test subject", null, null);
      fail("Required exception not thrown.");
    } catch (EmailException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testSendEmail_ThrowsException_IfThereIsAProblemInSendCall() throws Exception {
    EmailService emailService = new JavaMailEmailService(new MockMailDocumentFactoryThatThrowsException(), new XMLEmailBuilderDOMImpl());
    List toList = new ArrayList();
    toList.add("user2@domain.com");
    try {
      emailService.sendEmail("user1@domain.com", toList, null, "test subject", null, null);
      fail("Required exception not thrown.");
    } catch (EmailException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getCause().getMessage());
    }
  }
}