/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.test;

import com.monsanto.JavaMail.JavaMailMailDocument;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailException;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.MailDocumentFactoryImpl;
import junit.framework.TestCase;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: MailDocumentFactory_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class MailDocumentFactory_UT extends TestCase {

  private static final String TEST_XML_EMAIL = "com/monsanto/wst/lawmattermanagementsystem/mail/service/javamail/test/TestXMLEmail.xml";

  public void testGetMailDocument() throws Exception {
    Document xmlEmail = DOMUtil.newDocument(TEST_XML_EMAIL);
    MailDocumentFactoryImpl factory = new MailDocumentFactoryImpl();
    assertEquals(JavaMailMailDocument.class, factory.getMailDocument(MailDocumentFactoryImpl.TYPE_JAVA_MAIL_MAIL_DOCUMENT, xmlEmail).getClass());
  }

  public void testGetMailDocument_ThrowsException_IfNullDocumentSent() throws Exception {
    Document xmlEmail = null;
    MailDocumentFactoryImpl factory = new MailDocumentFactoryImpl();
    try {
      factory.getMailDocument(MailDocumentFactoryImpl.TYPE_JAVA_MAIL_MAIL_DOCUMENT, xmlEmail);
      fail("Required exception not thrown.");
    } catch (EmailException e) {
      System.out.println("e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetMailDocument_ThrowsException_IfInvalidTypeRequested() throws Exception {
    MailDocumentFactoryImpl factory = new MailDocumentFactoryImpl();
    Document xmlEmail = DOMUtil.newDocument(TEST_XML_EMAIL);
    try {
      factory.getMailDocument(null, xmlEmail);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      factory.getMailDocument("", xmlEmail);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      factory.getMailDocument("invalid-mail-document-type", xmlEmail);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }
}