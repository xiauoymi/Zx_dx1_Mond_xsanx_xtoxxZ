/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mail.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailException;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailService;

import java.util.List;

/**
 * Filename:    $RCSfile: MockEmailServiceThrowsException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockEmailServiceThrowsException implements EmailService {

  public boolean sendEmail(String from, List toList, List ccList, String subject, List attachments, List messageLines) throws EmailException {
    throw new EmailException("Mock exception by Email Service.");
  }
}