/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mail.util;

import org.w3c.dom.Document;

import java.util.List;

/**
 * Filename:    $RCSfile: XMLEmailBuilder.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2006-12-17 01:32:22 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public interface XMLEmailBuilder {

  /**
   * This is the utility that helps building an XML representation of email params (required by EmailService)
   *
   * @param toList - List of recipients to whom email should be sent (reqd, should contain at least one recipient)
   * @param ccList - List of recipients to whom the email needs to be copied. (opt, null allowed)
   * @param from - sender's email address (reqd, cannot be null)
   * @param subject - Subject of the email. (opt)
   * @param messageLines - A list of all lines in the message body (opt)
   * @param attachments - List of absolute paths for all the attachments. (opt)
   * @return Document - An XML document representation of all email-params, like one below:
   *
   *  <?xml version="1.0" encoding="UTF-8"?>
   *  <REQUEST>
   *   <HEADER>
   *    <TO>User1@MONSANTO.COM</TO>
   *    <CC>User2@MONSANTO.COM</CC>
   *    <CC>User3@MONSANTO.COM</CC>
   *     <FROM>RASESH.DESAI@MONSANTO.COM</FROM>
   *     <SUBJECT>TEST SUBJECT</SUBJECT>
   *   </HEADER>
   *   <BODY>
   *     <LINE>TEST MESSAGE Line 1</LINE>
   *     <LINE>TEST MESSAGE Line2</LINE>
   *   </BODY>
   *   <ATTACHMENT>
   *     <FILENAME>C:\DOCUMENTS\attachment.doc</FILENAME>
   *   </ATTACHMENT>
   * </REQUEST>
   *
   */
  Document getEmailParametersAsXML(List toList, List ccList, String from, String subject, List messageLines, List attachments) throws XMLEmailBuilderException;
}