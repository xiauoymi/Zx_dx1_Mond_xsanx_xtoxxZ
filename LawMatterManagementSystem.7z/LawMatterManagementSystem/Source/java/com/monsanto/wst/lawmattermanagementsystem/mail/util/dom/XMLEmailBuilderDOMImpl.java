/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mail.util.dom;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.lawmattermanagementsystem.mail.util.XMLEmailBuilder;
import com.monsanto.wst.lawmattermanagementsystem.mail.util.XMLEmailBuilderException;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.util.List;
import java.io.InputStream;
import java.io.IOException;

/**
 * Filename:    $RCSfile: XMLEmailBuilderDOMImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-15 22:31:47 $
 *
 * @author rdesai2
 * @version $Revision: 1.6 $
 */
public class XMLEmailBuilderDOMImpl implements XMLEmailBuilder {

  private String TEMPLATE_XML_EMAIL = "com/monsanto/wst/lawmattermanagementsystem/mail/util/dom/XMLEmailTemplate.xml";

  public Document getEmailParametersAsXML(List toList, List ccList, String from, String subject, List messageLines, List attachments) throws XMLEmailBuilderException {
    Document xmlEmailDoc = getXMLEmailTemplate();
    addTO(toList, xmlEmailDoc);
    addCC(ccList, xmlEmailDoc);
    addFROM(from, xmlEmailDoc);
    addSUBJECT(subject, xmlEmailDoc);
    addBODY(messageLines, xmlEmailDoc);
    addATTACHMENTS(attachments, xmlEmailDoc);
    return xmlEmailDoc;
  }

  private void addATTACHMENTS(List attachments, Document xmlEmailDoc) throws XMLEmailBuilderException {
    for (int i = 0; attachments != null && i < attachments.size(); i++) {
      addElement("FILENAME", "/REQUEST/ATTACHMENT", xmlEmailDoc);
      addTextNode((String) attachments.get(i), "/REQUEST/ATTACHMENT/FILENAME[" + (i + 1) + "]", xmlEmailDoc);
    }
  }

  private void addBODY(List messageLines, Document xmlEmailDoc) throws XMLEmailBuilderException {
    for (int i = 0; messageLines != null && i < messageLines.size(); i++) {
      addElement("LINE", "/REQUEST/BODY", xmlEmailDoc);
      addTextNode((String) messageLines.get(i), "/REQUEST/BODY/LINE[" + (i + 1) + "]", xmlEmailDoc);
    }
  }

  private void addSUBJECT(String subject, Document xmlEmailDoc) throws XMLEmailBuilderException {
    if (!StringUtils.isNullOrEmpty(subject)) {
      addTextNode(subject, "/REQUEST/HEADER/SUBJECT", xmlEmailDoc);
    }
  }

  private void addFROM(String from, Document xmlEmailDoc) throws XMLEmailBuilderException {
    validateFROM(from);
    addTextNode(from, "/REQUEST/HEADER/FROM", xmlEmailDoc);
  }

  private void validateFROM(String from) {
    if(StringUtils.isNullOrEmpty(from)) {
      throw new IllegalArgumentException("FROM parameter cannot be null or empty.");
    }
  }

  private void addCC(List ccList, Document xmlEmailDoc) throws XMLEmailBuilderException {
    for (int i = 0; ccList != null && i < ccList.size(); i++) {
      addElement("CC", "/REQUEST/HEADER", xmlEmailDoc);
      addTextNode((String) ccList.get(i), "/REQUEST/HEADER/CC[" + (i + 1) + "]", xmlEmailDoc);
    }
  }

  private void addTO(List toList, Document xmlEmailDoc) throws XMLEmailBuilderException {
    validateTOList(toList);
    for (int i = 0; i < toList.size(); i++) {
      addElement("TO", "/REQUEST/HEADER", xmlEmailDoc);
      addTextNode((String) toList.get(i), "/REQUEST/HEADER/TO[" + (i + 1) + "]", xmlEmailDoc);
    }
  }

  private void validateTOList(List toList) {
    if(toList == null || toList.size() < 1) {
      throw new IllegalArgumentException("TO-list parameter cannot be null or empty.");
    }
  }

  private void addElement(String elementName, String xpath, Document xmlEmailDoc) throws XMLEmailBuilderException {
    Node parentNode;
    try {
      parentNode = XPathAPI.selectSingleNode(xmlEmailDoc, xpath);
    } catch (TransformerException e) {
      Logger.log(new LoggableError(e));
      throw new XMLEmailBuilderException("Exception while customizing the XMLEmailTemplate.", e);
    }
    Node fromNode = xmlEmailDoc.createElement(elementName);
    parentNode.appendChild(fromNode);
  }

  private void addTextNode(String textValue, String xpath, Document xmlEmailDoc) throws XMLEmailBuilderException {
    Node parentNode;
    try {
      parentNode = XPathAPI.selectSingleNode(xmlEmailDoc, xpath);
    } catch (TransformerException e) {
      Logger.log(new LoggableError(e));
      throw new XMLEmailBuilderException("Exception while customizing the XMLEmailTemplate.", e);
    }
    Node fromNode = xmlEmailDoc.createTextNode(textValue);
    parentNode.appendChild(fromNode);
  }

  private Document getXMLEmailTemplate() throws XMLEmailBuilderException {
    Document xmlEmailDoc=null;
    try {
      InputStream asStream = getClass().getClassLoader().getResourceAsStream(TEMPLATE_XML_EMAIL);
      xmlEmailDoc = DOMUtil.newDocument(asStream);
    }catch (IOException e) {
      Logger.log(new LoggableError(e));
      throw new XMLEmailBuilderException("Exception while creating a dom out of xmlEmail template.", e);
    } catch (SAXException e) {
      Logger.log(new LoggableError(e));
      throw new XMLEmailBuilderException("Exception while creating a dom out of xmlEmail template.", e);
    }
    return xmlEmailDoc;
  }
}