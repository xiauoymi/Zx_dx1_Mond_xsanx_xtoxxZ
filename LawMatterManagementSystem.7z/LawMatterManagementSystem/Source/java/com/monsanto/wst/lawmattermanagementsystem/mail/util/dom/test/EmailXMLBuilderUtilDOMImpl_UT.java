/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mail.util.dom.test;

import com.monsanto.wst.lawmattermanagementsystem.mail.util.XMLEmailBuilder;
import com.monsanto.wst.lawmattermanagementsystem.mail.util.dom.XMLEmailBuilderDOMImpl;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: EmailXMLBuilderUtilDOMImpl_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2006-12-17 01:32:22 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class EmailXMLBuilderUtilDOMImpl_UT extends XMLTestCase {

  public void testGetEmailParamsAsXML_WithAllParameters() throws Exception {
    XMLEmailBuilder xmlEmailBuilder = new XMLEmailBuilderDOMImpl();
    List toList = getToList();
    List ccList = getCCList();
    String from = getFrom();
    String subject = getSubject();
    List message = getMessage();
    List attachments = getAttachments();
    Document xmlEmail = xmlEmailBuilder.getEmailParametersAsXML(toList, ccList, from, subject, message, attachments);
    assertNotNull(xmlEmail);
    assertXpathEvaluatesTo("SENDER@monsanto.com", "/REQUEST/HEADER/FROM", xmlEmail);
    assertXpathEvaluatesTo("Test Subject", "/REQUEST/HEADER/SUBJECT", xmlEmail);
    assertXpathEvaluatesTo("RECIPIENT1@monsanto.com", "/REQUEST/HEADER/TO[1]", xmlEmail);
    assertXpathEvaluatesTo("RECIPIENT2@monsanto.com", "/REQUEST/HEADER/TO[2]", xmlEmail);
    assertXpathEvaluatesTo("COPY-RECIPIENT1@gmail.com", "/REQUEST/HEADER/CC[1]", xmlEmail);
    assertXpathEvaluatesTo("COPY-RECIPIENT2@gmail.com", "/REQUEST/HEADER/CC[2]", xmlEmail);
    assertXpathEvaluatesTo("Test Msg Line1", "/REQUEST/BODY/LINE[1]", xmlEmail);
    assertXpathEvaluatesTo("Test Msg Line2", "/REQUEST/BODY/LINE[2]", xmlEmail);
    assertXpathEvaluatesTo("C:/file1.txt", "/REQUEST/ATTACHMENT/FILENAME[1]", xmlEmail);
    assertXpathEvaluatesTo("C:/file2.txt", "/REQUEST/ATTACHMENT/FILENAME[2]", xmlEmail);
  }

  public void testGetEmailParamsAsXML_WithMiminalParameters_WithoutException() throws Exception {
    XMLEmailBuilder xmlEmailBuilder = new XMLEmailBuilderDOMImpl();
    List toList = new ArrayList();
    toList.add("RECIPIENT1@monsanto.com");
    String from = getFrom();
    Document xmlEmail = xmlEmailBuilder.getEmailParametersAsXML(toList, null, from, null, new ArrayList(), null);
    assertNotNull(xmlEmail);
    assertXpathEvaluatesTo("SENDER@monsanto.com", "/REQUEST/HEADER/FROM", xmlEmail);
    assertXpathEvaluatesTo("", "/REQUEST/HEADER/SUBJECT", xmlEmail);
    assertXpathEvaluatesTo("RECIPIENT1@monsanto.com", "/REQUEST/HEADER/TO[1]", xmlEmail);
    assertXpathNotExists("/REQUEST/HEADER/TO[2]", xmlEmail);
    assertXpathNotExists("/REQUEST/HEADER/CC", xmlEmail);
    assertXpathNotExists("/REQUEST/BODY/LINE", xmlEmail);
    assertXpathNotExists("/REQUEST/ATTACHMENT/FILENAME", xmlEmail);
  }

  public void testExceptionThrown_TOIsNullOrEmpty() throws Exception {
    XMLEmailBuilder xmlEmailBuilder = new XMLEmailBuilderDOMImpl();
    String from = getFrom();
    try {
      xmlEmailBuilder.getEmailParametersAsXML(null, null, from, null, new ArrayList(), null);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      xmlEmailBuilder.getEmailParametersAsXML(new ArrayList(), null, from, null, new ArrayList(), null);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testExceptionThrown_FROMIsNullOrEmpty() throws Exception {
    XMLEmailBuilder xmlEmailBuilder = new XMLEmailBuilderDOMImpl();
    List toList = new ArrayList();
    toList.add("RECIPIENT1@monsanto.com");
    try {
      xmlEmailBuilder.getEmailParametersAsXML(toList, null, null, null, new ArrayList(), null);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      xmlEmailBuilder.getEmailParametersAsXML(toList, null, "", null, new ArrayList(), null);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  private List getMessage() {
    List messagLines = new ArrayList();
    messagLines.add("Test Msg Line1");
    messagLines.add("Test Msg Line2");
    return messagLines;
  }

  private String getSubject() {
    return "Test Subject";
  }

  private List getAttachments() {
    List attachments = new ArrayList();
    attachments.add("C:/file1.txt");
    attachments.add("C:/file2.txt");
    return attachments;
  }

  private String getFrom() {
    return "SENDER@monsanto.com";
  }

  private List getToList() {
    List toList = new ArrayList();
    toList.add("RECIPIENT1@monsanto.com");
    toList.add("RECIPIENT2@monsanto.com");
    return toList;
  }

  private List getCCList() {
    List CCList = new ArrayList();
    CCList.add("COPY-RECIPIENT1@gmail.com");
    CCList.add("COPY-RECIPIENT2@gmail.com");
    return CCList;
  }
}