/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mock;

import com.monsanto.AbstractLogging.NotificationSource;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.*;
import com.monsanto.dbdataservices.SqlWrappingException;

import java.text.ParseException;

/**
 * Filename:    $RCSfile: MockConnection.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-15 15:49:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class MockConnection implements PersistentStoreConnection {

  public PersistentStoreResultSet executeQuery(String cstrSQL) throws WrappingException {
    return null;
  }

  public PersistentStoreResultSet executeQuery(String cstrSQL, int iTimeoutSec) throws WrappingException, OperationTimeoutException {
    return null;
  }

  public PersistentStoreResultSet executeQuery(String cstrSQL, int iTimeoutSec, NotificationSource notificationSource, String cstrMessage) throws WrappingException {
    return null;
  }

  public int executeUpdate(String cstrSQL) throws WrappingException {
    return 0;
  }

  public int executeUpdate(String cstrSQL, int iTimeoutSec) throws WrappingException, OperationTimeoutException {
    return 0;
  }

  public int executeUpdate(String cstrSQL, int iTimeoutSec, NotificationSource notificationSource, String cstrMessage) throws WrappingException {
    return 0;
  }

  public int executeDelete(String cstrSQL) throws WrappingException {
    return 0;
  }

  public int executeDelete(String cstrSQL, int iTimeoutSec) throws WrappingException, OperationTimeoutException {
    return 0;
  }

  public int executeDelete(String cstrSQL, int iTimeoutSec, NotificationSource notificationSource, String cstrMessage) throws WrappingException {
    return 0;
  }

  public int executeInsert(String cstrSQL) throws WrappingException {
    return 0;
  }

  public int executeInsert(String cstrSQL, int iTimeoutSec) throws WrappingException, OperationTimeoutException {
    return 0;
  }

  public int executeInsert(String cstrSQL, int iTimeoutSec, NotificationSource notificationSource, String cstrMessage) throws WrappingException {
    return 0;
  }

  public void enableConstraint(String cstrTableName, String cstrConstraintName) throws WrappingException {
  }

  public void disableConstraint(String cstrTableName, String cstrConstraintName) throws WrappingException {
  }

  public void close() throws WrappingException {
  }

  public void beginTransaction() throws WrappingException {
  }

  public void rollbackTransaction() throws WrappingException {
  }

  public void endTransaction() throws WrappingException {
  }

  public PersistentStoreStatement prepareStatement(String cstrStatement) throws WrappingException {
    return null;
  }

  public PersistentStoreFunction prepareMethod(String cstrStatement) throws WrappingException, ParseException {
    return null;
  }

  public void lockTable(String cstrTableName) throws WrappingException {
  }

  public void lockTableWait(String cstrTableName) throws WrappingException {
  }

  public PersistentStoreBatch prepareBatch() {
    return null;
  }

  public void truncateTable(String cstrTableName) throws WrappingException {
  }

  public PersistentStoreScrollableStatement prepareScrollableStatement(String cstrStatement) throws WrappingException {
    return null;
  }

  public String getDriverInfo() throws SqlWrappingException {
    return null;
  }
}