/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mock;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Filename:    $RCSfile: MockConnectionThatReturnsPreparedStatementWithEmptyResultSet.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-01-10 22:38:24 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class MockConnectionThatReturnsPreparedStatementWithEmptyResultSet extends MockConnection{

  public PersistentStoreStatement prepareStatement(String cstrStatement) throws WrappingException {
    return new MockPreparedStatementWithEmptyResultSet();
  }
}