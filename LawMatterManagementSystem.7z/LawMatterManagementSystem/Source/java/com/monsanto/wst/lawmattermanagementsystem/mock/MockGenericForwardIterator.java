/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mock;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;

/**
 * Filename:    $RCSfile: MockGenericForwardIterator.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-09 20:47:56 $
 *
 * @author rdesai2
 * @version $Revision: 1.6 $
 */
public class MockGenericForwardIterator extends MockPersistentStoreResultSetFwdIterator {

  /**
   * MockGenericResultSet (com.monsanto.wst.lawmattermanagementsystem.mock.MockGenericResultSet) sends in this Generic
   * Mock Forward Iterator.
   * Please see the description in MockGenericResultSet for further details.
   *
   * MockGenericForwardIterator iterates in order based on row-id, so it is important that the "Row" has an "id" attribute
   * in proper order [starting with 1]
   */

  private int totalRecords;
  private Node tableDataNode;
  private int rowNumber = 0;

  public MockGenericForwardIterator(String tableDataFile) throws WrappingException {
    try {
      tableDataNode = DOMUtil.newDocument(tableDataFile);
      totalRecords = XPathAPI.eval(tableDataNode, "//Row").nodelist().getLength();
    } catch (ParserException e) {
      throw new WrappingException(e);
    } catch (TransformerException e) {
      throw new WrappingException(e);
    }
  }

  public MockGenericForwardIterator(Node tableDataNode) {
    this.tableDataNode = tableDataNode;
  }

  public boolean next() throws WrappingException {
    if (rowNumber >= totalRecords) {
      return false;
    }
    rowNumber++;
    return true;
  }

  public String getString(String columnName) throws WrappingException {
    try {
      String columnValue = XPathAPI.eval(tableDataNode, "//Row[@id='" + rowNumber + "']/Column[@name='" + columnName + "']").toString();
      if ("NULL".equalsIgnoreCase(columnValue)) {
        return null;
      }
      return columnValue;
    } catch (TransformerException e) {
      throw new WrappingException(e);
    }
  }
}