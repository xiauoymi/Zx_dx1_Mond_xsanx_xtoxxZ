/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mock;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.EmptyResultSetException;
import org.w3c.dom.Node;

/**
 * Filename:    $RCSfile: MockGenericResultSet.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-01 17:25:25 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class MockGenericResultSet extends MockPersistentStoreResultSet {


  /**
   * To Use this Generic Mock Result Set, you will need to create an XML file (that would mimic your database table) as
   * follows:
   *
   * <?xml version="1.0" encoding="UTF-8"?>
   * <YourTableName>
   *
   * <Row id="1">
   *    <Column name="INDEX">225</Column>
   *    <Column name="NAME">ghgfgdhfgsdgh</Column>
   *    ...
   * </Row>
   *
   * <Row id="2">
   *    <Column name="INDEX">1364</Column>
   *    <Column name="NAME">wbs1</Column>
   *    ...
   * </Row>
   *
   * ...
   *
   * </YourTableName>
   *
   * Your MockPreparedStatement or MockConnection specific to your application should instantiate this Generic Mock
   * Result Set with any of the constructors below:
   *    1. With FileName: If you need to retrieve all the data present in the XML file
   *    2. With Node: If you would like to filter the results based on some criteria (like dynamic query or
   *                  set params invoked on prepared statements). You can use XPath to achieve the above.
   *
   * Also it is important that the "Row" has an "id" attribute in proper order [starting with 1]
   *
   */

  private MockGenericForwardIterator mockGenericForwardIterator;
  private MockGenericSingleResultSet mockSingleResultSet;

  public MockGenericResultSet(String tableDataFile) throws WrappingException {
    mockGenericForwardIterator = new MockGenericForwardIterator(tableDataFile);
    mockSingleResultSet = new MockGenericSingleResultSet(tableDataFile);
  }

  public MockGenericResultSet(Node tableDataNode) throws WrappingException {
    mockGenericForwardIterator = new MockGenericForwardIterator(tableDataNode);
    mockSingleResultSet = new MockGenericSingleResultSet(tableDataNode);
  }

  public PersistentStoreResultSetFwdIterator getForwardIterator() throws WrappingException {
    return mockGenericForwardIterator;
  }

  public PersistentStoreResultSetSingleResult getSingleResult() throws EmptyResultSetException, WrappingException {
    return mockSingleResultSet;
  }
}