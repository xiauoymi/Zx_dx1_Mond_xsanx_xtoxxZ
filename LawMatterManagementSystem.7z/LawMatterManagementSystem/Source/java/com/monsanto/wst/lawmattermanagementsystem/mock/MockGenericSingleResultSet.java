/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mock;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import org.w3c.dom.Node;
import org.apache.xpath.XPathAPI;

import javax.xml.transform.TransformerException;

/**
 * Filename:    $RCSfile: MockGenericSingleResultSet.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-01 17:25:25 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockGenericSingleResultSet extends MockSingleResultSet {

  /**
   * MockGenericResultSet (com.monsanto.wst.lawmattermanagementsystem.mock.MockGenericResultSet) sends in this Generic
   * Mock Single Result Set.
   *
   * Please see the description in MockGenericResultSet for further details.
   *
   * The Generic Mock Single Result Set, expectes node (or an XML file) containing only one "Row" element [Since
   * it is supposed to be a single result] as follows:
   *
   * <Row id="can_be_any_number">
   *    <Column name="INDEX">225</Column>
   *    <Column name="NAME">ghgfgdhfgsdgh</Column>
   *    ...
   * </Row>
   *
   */

  private Node tableDataNode;

  public MockGenericSingleResultSet(String tableDataFile) throws WrappingException {
    try {
      tableDataNode = DOMUtil.newDocument(tableDataFile);
    } catch (ParserException e) {
      throw new WrappingException(e);
    }
  }

  public MockGenericSingleResultSet(Node tableDataNode) {
    this.tableDataNode = tableDataNode;
  }

  public String getString(String columnName) throws WrappingException {
    try {
      String columnValue = XPathAPI.eval(tableDataNode, "Column[@name='" + columnName + "']").toString();
      if ("NULL".equalsIgnoreCase(columnValue)) {
        return null;
      }
      return columnValue;
    } catch (TransformerException e) {
      throw new WrappingException(e);
    }
  }
}