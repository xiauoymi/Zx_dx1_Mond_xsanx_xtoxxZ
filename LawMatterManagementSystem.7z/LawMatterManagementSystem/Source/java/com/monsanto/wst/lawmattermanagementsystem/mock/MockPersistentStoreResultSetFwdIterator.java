/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mock;

import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.AbstractCLOB;
import com.monsanto.Util.Exceptions.WrappingException;

import java.util.Date;
import java.io.InputStream;
import java.io.Reader;

/**
 * Filename:    $RCSfile: MockPersistentStoreResultSetFwdIterator.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-27 01:01:37 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class MockPersistentStoreResultSetFwdIterator implements PersistentStoreResultSetFwdIterator {

  public boolean next() throws WrappingException {
    return false;
  }

  public int getInt(String cstrName) throws WrappingException {
    return 0;
  }

  public int getInt(int iCol) throws WrappingException {
    return 0;
  }

  public String getString(String cstrName) throws WrappingException {
    return null;
  }

  public String getString(int iCol) throws WrappingException {
    return null;
  }

  public Date getDate(String cstrName) throws WrappingException {
    return null;
  }

  public Date getDate(int iCol) throws WrappingException {
    return null;
  }

  public InputStream getBlob(String cstrName) throws WrappingException {
    return null;
  }

  public InputStream getBlob(int iCol) throws WrappingException {
    return null;
  }

  public Reader getClob(String cstrName) throws WrappingException {
    return null;
  }

  public Reader getClob(int iCol) throws WrappingException {
    return null;
  }

  public AbstractCLOB getClobObject(String cstrName) throws WrappingException {
    return null;
  }

  public AbstractCLOB getClobObject(int iCol) throws WrappingException {
    return null;
  }

  public double getDouble(String cstrName) throws WrappingException {
    return 0;
  }

  public double getDouble(int iCol) throws WrappingException {
    return 0;
  }

  public Date getTime(String cstrName) throws WrappingException {
    return null;
  }

  public Date getTime(int iCol) throws WrappingException {
    return null;
  }

  public Date getTimestamp(String cstrName) throws WrappingException {
    return null;
  }

  public Date getTimestamp(int iCol) throws WrappingException {
    return null;
  }

  public Integer getINTEGER(int iCol) throws WrappingException {
    return null;
  }

  public Integer getINTEGER(String cstrName) throws WrappingException {
    return null;
  }

  public byte[] getBytes(String cstrName) throws WrappingException {
    return new byte[0];
  }

  public byte[] getBytes(int iCol) throws WrappingException {
    return new byte[0];
  }

  public long getLong(String cstrName) throws WrappingException {
    return 0;
  }

  public long getLong(int iCol) throws WrappingException {
    return 0;
  }

  public Double getDOUBLE(String colName) throws WrappingException {
    return null;
  }

  public Double getDOUBLE(int iCol) throws WrappingException {
    return null;
  }

  public Long getLONG(String colName) throws WrappingException {
    return null;
  }

  public Long getLONG(int iCol) throws WrappingException {
    return null;
  }
}