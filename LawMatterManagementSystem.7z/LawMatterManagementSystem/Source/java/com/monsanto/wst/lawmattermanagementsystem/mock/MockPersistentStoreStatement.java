/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mock;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreStatement;

import java.io.InputStream;
import java.util.Date;

/**
 * Filename:    $RCSfile: MockPersistentStoreStatement.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockPersistentStoreStatement implements PersistentStoreStatement {

  public void setParam(int iPosn, Object oValue) throws WrappingException {
  }

  public void setParam(int iPosn, Double doubleValue) throws WrappingException {
  }

  public void setParam(int iPosn, Long longValue) throws WrappingException {
  }

  public void setParam(int iPosn, long longValue) throws WrappingException {
  }

  public void setParam(int iPosn, Integer integerValue) throws WrappingException {
  }

  public void setParam(int iPosn, int iValue) throws WrappingException {
  }

  public void setParam(int iPosn, String cstrValue) throws WrappingException {
  }

  public void setParam(int iPosn, byte[] bValue_a) throws WrappingException {
  }

  public void setParam(int iPosn, double dValue) throws WrappingException {
  }

  public void setParam(int iPosn, Date dateValue) throws WrappingException {
  }

  public void setParam(int iPosn, InputStream is, int length) throws WrappingException {
  }

  public void setAsciiParam(int iPosn, InputStream is, int length) throws WrappingException {
  }

  public int executeInsert() throws WrappingException {
    return 0;
  }

  public int executeUpdate() throws WrappingException {
    return 0;
  }

  public int executeDelete() throws WrappingException {
    return 0;
  }

  public PersistentStoreResultSet executeQuery() throws WrappingException {
    return null;
  }

  public PersistentStoreResultSet executeQuery(int timeOutInSeconds) throws WrappingException {
    return null;
  }

  public void close() throws WrappingException {
  }

  public void addBatch() throws WrappingException {
  }

  public void cancel() throws WrappingException {
  }

  public void executeBatch() throws WrappingException {
  }
}