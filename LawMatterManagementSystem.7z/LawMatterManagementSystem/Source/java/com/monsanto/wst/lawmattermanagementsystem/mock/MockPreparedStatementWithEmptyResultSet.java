/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.mock;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSet;

/**
 * Filename:    $RCSfile: MockPreparedStatementWithEmptyResultSet.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class MockPreparedStatementWithEmptyResultSet extends MockPersistentStoreStatement {

  public PersistentStoreResultSet executeQuery() throws WrappingException {
    return new MockEmptyPersistentStoreResultSet();
  }
}