/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.propertyreader;

import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

/**
 * Filename:    $RCSfile: PropertyFileReader.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-09 17:30:00 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public interface PropertyFileReader {

  /**
   * Reads
   * @param propertyFileName
   * @return PropertyList - this has 2 useful methods that can be directly used as needed:
   *                        1. getPropertyValue(String key) - Looks for environment specific property first and then gereral ones
   *                        2. getPropertyKeyIterator()
   * @throws com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException - On Error
   */
  PropertyList readPropertyFile(String propertyFileName) throws ServiceException;
}