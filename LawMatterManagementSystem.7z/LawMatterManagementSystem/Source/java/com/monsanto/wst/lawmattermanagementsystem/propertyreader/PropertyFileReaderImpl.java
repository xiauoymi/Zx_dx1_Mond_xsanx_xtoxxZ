/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.propertyreader;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.Property;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.xmlserialization.DeserializationException;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerBuilder;

/**
 * Filename:    $RCSfile: PropertyFileReaderImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-14 00:43:56 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class PropertyFileReaderImpl implements PropertyFileReader {

  private XmlSerializer serializer;

  public PropertyFileReaderImpl(XmlSerializerBuilder xmlSerializerBuilder) {
    initializeSerializer(xmlSerializerBuilder);
  }

  public PropertyList readPropertyFile(String propertyFileName) throws ServiceException {
    try {
      return (PropertyList) serializer.fromDocument(DOMUtil.newDocument(propertyFileName));
    } catch (DeserializationException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException("Exception occured while deserializing the XML containing property list '" + propertyFileName + "' : " + e.getMessage(), e);
    } catch (ParserException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException("Exception occured while parsing the XML containing property list '" + propertyFileName + "' : " + e.getMessage(), e);
    } catch (Exception e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException("Exception occured while reading the XML containing property list '" + propertyFileName + "'. " + e.getClass() + " : " + e.getMessage(), e);
    }
  }

  private void initializeSerializer(XmlSerializerBuilder builder) {
    builder.registerMapping("", LMMSConstants.ALIAS_PROPERTY_LIST, PropertyList.class);
    builder.registerMapping("", LMMSConstants.ALIAS_PROPERTY, Property.class);
    serializer = builder.createSerializer();
  }
}