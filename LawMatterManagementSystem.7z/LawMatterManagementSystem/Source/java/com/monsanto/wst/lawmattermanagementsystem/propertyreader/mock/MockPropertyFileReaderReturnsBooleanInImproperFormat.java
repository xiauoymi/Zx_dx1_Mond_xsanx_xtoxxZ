/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.propertyreader.mock;

import com.monsanto.wst.lawmattermanagementsystem.propertyreader.PropertyFileReader;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.Property;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

/**
 * Filename:    $RCSfile: MockPropertyFileReaderReturnsBooleanInImproperFormat.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-09 17:08:29 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockPropertyFileReaderReturnsBooleanInImproperFormat implements PropertyFileReader {

  public PropertyList readPropertyFile(String propertyFileName) throws ServiceException {
    return new PropertyList(new Property[]{
            new Property(LMMSConstants.PROPERTY_CONTACT_NAME, "KMHUDG", null),
            new Property(LMMSConstants.PROPERTY_SKIP_FILE_FTP, "incorrect-boolean-value", null),
            new Property(LMMSConstants.PROPERTY_REPOST_FOR_SPECIFIC_DATE, "incorrect-boolean-value", null),
            new Property(LMMSConstants.PROPERTY_REPOST_DATE, "2006-10-11 06:00:00", null)
    });
  }
}