/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.propertyreader.mock;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.PropertyFileReader;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.Property;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

/**
 * Filename:    $RCSfile: MockPropertyFileReaderReturnsRepostSpecificDateAsTrue.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-09 19:39:22 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class MockPropertyFileReaderReturnsRepostSpecificDateAsTrue implements PropertyFileReader {

  private String propertyFileName;

  public PropertyList readPropertyFile(String propertyFileName) throws ServiceException {
    this.propertyFileName = propertyFileName;
    return new PropertyList(new Property[]{
            new Property(LMMSConstants.PROPERTY_CONTACT_NAME, "KMHUDG", null),
            new Property(LMMSConstants.PROPERTY_SKIP_FILE_FTP, "false", null),
            new Property(LMMSConstants.PROPERTY_REPOST_FOR_SPECIFIC_DATE, "True", null),
            new Property(LMMSConstants.PROPERTY_REPOST_DATE, "2006-10-11 06:00:00", null),
            new Property(LMMSConstants.PROPERTY_BOX_ID, "D08", null)
    });
  }

  public String getFileNameForReadRequest() {
    return propertyFileName;
  }
}