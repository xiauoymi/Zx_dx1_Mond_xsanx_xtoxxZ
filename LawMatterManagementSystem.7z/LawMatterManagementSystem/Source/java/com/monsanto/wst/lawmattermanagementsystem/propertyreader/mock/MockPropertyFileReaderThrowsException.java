/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.propertyreader.mock;

import com.monsanto.wst.lawmattermanagementsystem.propertyreader.PropertyFileReader;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

/**
 * Filename:    $RCSfile: MockPropertyFileReaderThrowsException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-21 22:03:35 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class MockPropertyFileReaderThrowsException implements PropertyFileReader {

  public PropertyList readPropertyFile(String propertyFileName) throws ServiceException {
    throw new ServiceException("Mock exception by property file reader.");
  }
}