/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.propertyreader.model;

import com.monsanto.wst.lawmattermanagementsystem.propertyreader.InvalidPropertyRequestException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.config.exception.ConfigurationException;
import com.monsanto.Util.StringUtils;

import java.util.Arrays;
import java.util.Iterator;

/**
 * Filename:    $RCSfile: PropertyList.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-09 17:30:00 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class PropertyList {

  private Property[] properties;

  public PropertyList(Property[] properties) {
    validateArgument(properties);
    this.properties = properties;
  }

  /**
   * Looks for environment specific property first and then gereral ones
   * @param key
   * @return Value
   * @throws InvalidPropertyRequestException
   */
  public String getPropertyValue(String key) throws InvalidPropertyRequestException, ConfigurationException {
    String systemEnvironment = getSystemEnvironment();
    Iterator propertyIterator = getPropertyKeyIterator();
    while (propertyIterator.hasNext()) {
      Property property = (Property) propertyIterator.next();
      if (property.getKey().equalsIgnoreCase(key) && systemEnvironment.equalsIgnoreCase(property.getEnvironment())) {
        return property.getValue();
      }
    }
    propertyIterator = getPropertyKeyIterator();
    while (propertyIterator.hasNext()) {
      Property property = (Property) propertyIterator.next();
      if (property.getKey().equalsIgnoreCase(key) && StringUtils.isNullOrEmpty(property.getEnvironment())) {
        return property.getValue();
      }
    }
    throw new InvalidPropertyRequestException("Property '" + key + "' not found.");
  }

  private String getSystemEnvironment() throws ConfigurationException {
    String systemEnvironment = System.getProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION);
    if(StringUtils.isNullOrEmpty(systemEnvironment)) {
      throw new ConfigurationException("System parameter '-Dlsi.function' not set.");
    }
    return systemEnvironment;
  }

  public Iterator getPropertyKeyIterator() {
    return Arrays.asList(properties).iterator();
  }

  private void validateArgument(Property[] properties) {
    if (properties == null) {
      throw new IllegalArgumentException("Property Array cannot be null.");
    }
  }
}