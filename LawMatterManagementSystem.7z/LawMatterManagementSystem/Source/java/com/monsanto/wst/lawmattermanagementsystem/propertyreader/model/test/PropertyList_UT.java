/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.test;

import com.monsanto.wst.lawmattermanagementsystem.propertyreader.InvalidPropertyRequestException;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.Property;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.config.exception.ConfigurationException;

import java.util.Iterator;

/**
 * Filename:    $RCSfile: PropertyList_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-09 17:30:00 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class PropertyList_UT extends LMMSBaseTestCase {

  public void testCreate_ForNullPropertyArray_ThrowsException() throws Exception {
    try {
      new PropertyList(null);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetPropertyKeyIterator() throws Exception {
    Property[] properties = new Property[]{new Property("key1", "value1", null), new Property("key2", "value2", null)};
    PropertyList propertyList = new PropertyList(properties);
    Iterator keyIterator = propertyList.getPropertyKeyIterator();
    assertNotNull(keyIterator);
    while (keyIterator.hasNext()) {
      Property property = (Property) keyIterator.next();
      if ("key1".equalsIgnoreCase(property.getKey())) {
        assertEquals("value1", property.getValue());
      }
      if ("key2".equalsIgnoreCase(property.getKey())) {
        assertEquals("value2", property.getValue());
      }
    }
  }

  public void testGetPropertyKeyIterator_ForEmptyPropertyArray_ReturnsNotNullEmptyIterator() throws Exception {
    Property[] properties = new Property[]{};
    PropertyList propertyList = new PropertyList(properties);
    Iterator keyIterator = propertyList.getPropertyKeyIterator();
    assertNotNull(keyIterator);
    while (keyIterator.hasNext()) {
      fail("Empty iterator cannot have any data.");
    }
  }

  public void testGetPropertyValue() throws Exception {
    Property[] properties = new Property[]{new Property("key1", "value1", "prod"), new Property("key1", "value2", "win")};
    PropertyList propertyList = new PropertyList(properties);
    assertEquals("value2", propertyList.getPropertyValue("key1"));
  }

  public void testGetPropertyValue_ReturnsGeneralProperty_IfEnvironmentNotSpecified() throws Exception {
    Property[] properties = new Property[]{new Property("key1", "value1", null), new Property("key2", "value2", "")};
    PropertyList propertyList = new PropertyList(properties);
    assertEquals("value1", propertyList.getPropertyValue("key1"));
    assertEquals("value2", propertyList.getPropertyValue("key2"));
  }

  public void testGetPropertyValue_ReturnsSpecificProperty_IfErroneouslyBothSpecificAndGeneralPropertiesArePresent() throws Exception {
    Property[] properties = new Property[]{new Property("key1", "general-value", null), new Property("key1", "specific-value", "win")};
    PropertyList propertyList = new PropertyList(properties);
    assertEquals("specific-value", propertyList.getPropertyValue("key1"));
  }

  public void testGetPropertyValue_ThrowsConfigurationException_IfLSIEnvironmentNotSet() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, "");
    Property[] properties = new Property[]{new Property("key1", "value1", "win")};
    PropertyList propertyList = new PropertyList(properties);
    try {
      propertyList.getPropertyValue("key1");
      fail("Required exception not thrown.");
    } catch (ConfigurationException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testGetPropertyValue_ThrowsInvalidPropertyRequestException_IfInvalidKeyRequested() throws Exception {
    Property[] properties = new Property[]{new Property("key1", "value1", "win"), new Property("key2", "value2", null)};
    PropertyList propertyList = new PropertyList(properties);
    try {
      propertyList.getPropertyValue("non-existing-key");
      fail("Required exception not thrown");
    } catch (InvalidPropertyRequestException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      propertyList.getPropertyValue(null);
      fail("Required exception not thrown");
    } catch (InvalidPropertyRequestException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      propertyList.getPropertyValue("");
      fail("Required exception not thrown");
    } catch (InvalidPropertyRequestException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }
}