/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.propertyreader.test;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.mock.MockXmlSerializerBuilderReturnsSerializerThatThrowsException;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.PropertyFileReader;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.PropertyFileReaderImpl;
import com.monsanto.wst.lawmattermanagementsystem.propertyreader.model.PropertyList;
import com.monsanto.wst.lawmattermanagementsystem.util.LMMSBaseTestCase;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.xmlserialization.XmlSerializerBuilder;

/**
 * Filename:    $RCSfile: PropertyFileReader_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-03 14:37:45 $
 *
 * @author rdesai2
 * @version $Revision: 1.9 $
 */
public class PropertyFileReader_UT extends LMMSBaseTestCase {

  public void testReadPropertyFile() throws Exception {
    String propertyFileName = "com/monsanto/wst/lawmattermanagementsystem/propertyreader/test/TestPropertyFile.xml";
    PropertyFileReader propertyFileReader = new PropertyFileReaderImpl(new XmlSerializerBuilder());
    PropertyList propertyList = propertyFileReader.readPropertyFile(propertyFileName);
    assertNotNull(propertyList);
    assertEquals("KMHUDG", propertyList.getPropertyValue("Contact Name"));
    assertEquals("TRUE", propertyList.getPropertyValue("Skip File FTP"));
    assertEquals("TRUE", propertyList.getPropertyValue("Repost For Specific Date"));
    assertEquals("02/19/2007", propertyList.getPropertyValue("Repost Date"));
    assertEquals("D08", propertyList.getPropertyValue("Box Id"));
    assertEquals("TRUE", propertyList.getPropertyValue("Run_Invoice"));
    assertEquals("TRUE", propertyList.getPropertyValue("Run_Checks"));
    assertEquals("TRUE", propertyList.getPropertyValue("Run_Voids"));
    assertEquals("TRUE", propertyList.getPropertyValue("Run_AccountCode"));
  }

  public void testReadPropertyFile_ForDifferentEnvironments() throws Exception {
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, "prod");
    String propertyFileName = "com/monsanto/wst/lawmattermanagementsystem/propertyreader/test/TestPropertyFile.xml";
    PropertyFileReader propertyFileReader = new PropertyFileReaderImpl(new XmlSerializerBuilder());
    PropertyList propertyList = propertyFileReader.readPropertyFile(propertyFileName);
    assertNotNull(propertyList);
    assertEquals("KMHUDG", propertyList.getPropertyValue("Contact Name"));
    assertEquals("TRUE", propertyList.getPropertyValue("Skip File FTP"));
    assertEquals("TRUE", propertyList.getPropertyValue("Repost For Specific Date"));
    assertEquals("02/19/2007", propertyList.getPropertyValue("Repost Date"));
    assertEquals("P08", propertyList.getPropertyValue("Box Id"));
  }

  public void testReadPropertyFile_ThrowsException_IfPropertyFileNameIsInvalidOrNotFound() throws Exception {
    PropertyFileReader propertyFileReader = new PropertyFileReaderImpl(new XmlSerializerBuilder());
    try {
      propertyFileReader.readPropertyFile("NonExistingPropertyList.xml");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      propertyFileReader.readPropertyFile(null);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      propertyFileReader.readPropertyFile("");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testReadPropertyFile_ThrowsServiceException_IfDeserializationExceptionEncountered() throws Exception {
    String propertyFileName = "com/monsanto/wst/lawmattermanagementsystem/propertyreader/test/TestPropertyFile.xml";
    PropertyFileReader propertyFileReader = new PropertyFileReaderImpl(new MockXmlSerializerBuilderReturnsSerializerThatThrowsException());
    try {
      propertyFileReader.readPropertyFile(propertyFileName);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testReadPropertyFile_ThrowsServiceException_IfXMLParseExceptionEncountered() throws Exception {
    String propertyFileName = "com/monsanto/wst/lawmattermanagementsystem/propertyreader/test/TestNonWellFormedPropertyFile.xml";
    PropertyFileReader propertyFileReader = new PropertyFileReaderImpl(new XmlSerializerBuilder());
    try {
      propertyFileReader.readPropertyFile(propertyFileName);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testReadPropertyFile_ThrowsServiceException_IfPropertyListXMLFile_ContainsIncorrectMapping() throws Exception {
    String propertyFileName = "com/monsanto/wst/lawmattermanagementsystem/propertyreader/test/TestPropertyFileWithIncorrectMappings.xml";
    PropertyFileReader propertyFileReader = new PropertyFileReaderImpl(new XmlSerializerBuilder());
    try {
      propertyFileReader.readPropertyFile(propertyFileName);
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }
}