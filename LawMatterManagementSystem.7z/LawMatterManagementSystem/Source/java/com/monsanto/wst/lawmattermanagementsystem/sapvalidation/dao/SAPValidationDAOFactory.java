/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao;

/**
 * Filename:    $RCSfile: SAPValidationDAOFactory.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-01-17 01:36:47 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public interface SAPValidationDAOFactory {

  Object getValidationDAO(String databaseType);
}