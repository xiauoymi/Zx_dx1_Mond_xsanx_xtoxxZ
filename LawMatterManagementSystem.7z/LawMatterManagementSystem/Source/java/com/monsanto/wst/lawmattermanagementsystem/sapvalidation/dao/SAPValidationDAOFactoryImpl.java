/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.erd.ERDValidationDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.FunnelValidationDAOImpl;

/**
 * Filename:    $RCSfile: SAPValidationDAOFactoryImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class SAPValidationDAOFactoryImpl implements SAPValidationDAOFactory {

  public Object getValidationDAO(String databaseType) {
    if(LMMSConstants.DATABASE_FUNNEL.equalsIgnoreCase(databaseType)) {
      return new FunnelValidationDAOImpl();
    }
    if(LMMSConstants.DATABASE_ERD.equalsIgnoreCase(databaseType)) {
      return new ERDValidationDAOImpl();
    }
    String errorMessage = "Error getting ValidationDAO implementation. Invalid database type: '" + databaseType + "' specified.";
    Logger.log(new LoggableError(errorMessage));
    throw new IllegalArgumentException(errorMessage);
  }
}