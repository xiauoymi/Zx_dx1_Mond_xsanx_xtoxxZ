/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.erd;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;

/**
 * Filename:    $RCSfile: ERDValidationDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public interface ERDValidationDAO {

  /**
   * This method needs to be called for validate_SAP_BalSheet() check.
   * @param costElement - 10-digit code (please append 0s in the begining if required)
   *                      Eg: If costElement = '11642000', it should be sent as '0011642000'.
   * @param environmentSpecificBoxId [Eg: P08 or D08]
   * @param connection
   * @return boolean - true/false if such a record exists
   */
  boolean recordExistsWithCostElement(String costElement, String environmentSpecificBoxId, PersistentStoreConnection connection) throws DAOException;

  /**
   * This method needs to be called for validate_SAP_ProfitCenter() check.
   * @param profitCenter
   * @param environmentSpecificBoxId [Eg: P08 or D08]
   * @param connection
   * @return boolean - true/false
   * @throws DAOException
   */
  boolean recordExistsWithProfitCenter(String profitCenter, String environmentSpecificBoxId, PersistentStoreConnection connection) throws DAOException;
}