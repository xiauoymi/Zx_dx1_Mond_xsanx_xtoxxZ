/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.erd;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.util.DAOUtil;
import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: ERDValidationDAOImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-22 20:24:07 $
 *
 * @author rdesai2
 * @version $Revision: 1.6 $
 */
public class ERDValidationDAOImpl implements ERDValidationDAO {

  private static final String RECORD_EXISTS_WITH_COST_ELEMENT_SQL =
          "SELECT COUNT (*) NUMBER_OF_RECORDS \n" +
                  "  FROM erd.law_ska1 \n" +
                  " WHERE saknr = ? \n" +
                  "   AND environment = ? \n" +
                  "   AND ktopl = 'MONS' \n" +
                  "   AND xbilk = 'X' \n" +
                  "   AND ROWNUM = 1 ";

  private static final String RECORD_EXISTS_WITH_PROFIT_CENTER_SQL =
          "SELECT COUNT (*) NUMBER_OF_RECORDS \n" +
                  "  FROM erd.law_cepc \n" +
                  " WHERE prctr = ? AND environment = ? AND ROWNUM = 1 ";

  public boolean recordExistsWithCostElement(String costElement, String environmentSpecificBoxId, PersistentStoreConnection connection) throws DAOException {
    DAOUtil daoUtil = new DAOUtil(connection);
    try {
      return daoUtil.checkRecordExists(RECORD_EXISTS_WITH_COST_ELEMENT_SQL, new String[]{costElement, environmentSpecificBoxId}, "NUMBER_OF_RECORDS");
    } catch (WrappingException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with cost element: '" + costElement + "' and environmentSpecificBoxId: '" + environmentSpecificBoxId + "', from ERD database.", e);
    } catch (EmptyResultSetException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with cost element: '" + costElement + "' and environmentSpecificBoxId: '" + environmentSpecificBoxId + "', from ERD database." +
              " It should ideally return only 0 or 1.", e);
    } finally {
      daoUtil.closeResources();
    }
  }

  public boolean recordExistsWithProfitCenter(String profitCenter, String environmentSpecificBoxId, PersistentStoreConnection connection) throws DAOException {
    DAOUtil daoUtil = new DAOUtil(connection);
    try {
      //todo temporary fix remove late
      if(profitCenter==null){
        return true;
      }
      return daoUtil.checkRecordExists(RECORD_EXISTS_WITH_PROFIT_CENTER_SQL, new String[]{StringUtils.leftPad(profitCenter,10,'0'), environmentSpecificBoxId}, "NUMBER_OF_RECORDS");
    } catch (WrappingException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with profit center: '" + profitCenter + "' and environmentSpecificBoxId: '" + environmentSpecificBoxId + "', from ERD database.", e);
    } catch (EmptyResultSetException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with profit center: '" + profitCenter + "' and environmentSpecificBoxId: '" + environmentSpecificBoxId + "', from ERD database." +
              " It should ideally return only 0 or 1.", e);
    } finally {
      daoUtil.closeResources();
    }
  }
}