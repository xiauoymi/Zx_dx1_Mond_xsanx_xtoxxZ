/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.erd.mock;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.erd.ERDValidationDAO;

/**
 * Filename:    $RCSfile: MockERDValidationDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockERDValidationDAO implements ERDValidationDAO {

  public boolean recordExistsWithCostElement(String costElement, String environment, PersistentStoreConnection connection) throws DAOException {
    return false;
  }

  public boolean recordExistsWithProfitCenter(String profitCenter, String environment, PersistentStoreConnection connection) throws DAOException {
    return true;
  }
}