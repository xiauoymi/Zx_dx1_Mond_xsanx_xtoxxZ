/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.erd.test;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.mock.MockConnectionThatReturnsPreparedStatementWithEmptyResultSet;
import com.monsanto.wst.lawmattermanagementsystem.mock.MockConnectionThatThrowsExceptionWhileReturningPreparedStatement;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.erd.ERDValidationDAO;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.erd.ERDValidationDAOImpl;
import junit.framework.TestCase;

import java.io.IOException;

/**
 * Filename:    $RCSfile: ERDValidationDAO_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-27 15:55:55 $
 *
 * Note: Some unit tests make an actual connection to database because database just contains all valid account codes
 * and is read-only. Duplicating all account codes and validating against those is not desirable.
 *
 * @author rdesai2
 * @version $Revision: 1.7 $
 */
public class ERDValidationDAO_UT extends TestCase {

  private ResourceConnectionManager resourceConnectionManager;

  private PersistentStoreConnection connectionThatThrowsExceptionWhileReturningPreparedStatement
          = new MockConnectionThatThrowsExceptionWhileReturningPreparedStatement();

  private PersistentStoreConnection connectionThatReturnsPreparedStatementWithEmptyResultSet
          = new MockConnectionThatReturnsPreparedStatementWithEmptyResultSet();

  protected void setUp() throws IOException {
    resourceConnectionManager = new ResourceManagerFactoryImpl().getConnectionManager(LMMSConstants.DATASOURCE_TYPE_ORACLE);
  }

  public void testRecordExistsWithCostElement() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_ERD);
    ERDValidationDAO dao = new ERDValidationDAOImpl();
//    assertTrue(dao.recordExistsWithCostElement("0011642000", "D08", connection));
//    assertTrue(dao.recordExistsWithCostElement("0021310878", "D08", connection));
//    assertTrue(dao.recordExistsWithCostElement("0021307632", "D08", connection));
    assertFalse(dao.recordExistsWithCostElement("non-existing-cost-element", "non-existing-environment", connection));
    connection.close();
  }

  public void testRecordExistsWithCompanyCode_ThowsException_IfConnectionEncountersExceptionWhileReturningPreparedStatement() throws Exception {
    ERDValidationDAO dao = new ERDValidationDAOImpl();
    try {
      dao.recordExistsWithCostElement("0011642000", "D08", connectionThatThrowsExceptionWhileReturningPreparedStatement);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithCompanyCode_ThowsException_ForEmptyResultSet() throws Exception {
    ERDValidationDAO dao = new ERDValidationDAOImpl();
    try {
      dao.recordExistsWithCostElement("0011642000", "D08", connectionThatReturnsPreparedStatementWithEmptyResultSet);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithProfitCenter() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_ERD);
    ERDValidationDAO dao = new ERDValidationDAOImpl();
    assertFalse(dao.recordExistsWithProfitCenter("59165E926", "D08", connection));
    assertFalse(dao.recordExistsWithProfitCenter("NB3099", "D08", connection));
    assertFalse(dao.recordExistsWithProfitCenter("NB3099", "D08", connection));
    assertFalse(dao.recordExistsWithProfitCenter("non-existing-profit-center", "non-existing-environment", connection));
    connection.close();
  }

  public void testRecordExistsWithProfitCenter_ThowsException_IfConnectionEncountersExceptionWhileReturningPreparedStatement() throws Exception {
    ERDValidationDAO dao = new ERDValidationDAOImpl();
    try {
      dao.recordExistsWithProfitCenter("59165E926", "D08", connectionThatThrowsExceptionWhileReturningPreparedStatement);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithProfitCenter_ThowsException_ForEmptyResultSet() throws Exception {
    ERDValidationDAO dao = new ERDValidationDAOImpl();
    try {
      dao.recordExistsWithProfitCenter("59165E926", "D08", connectionThatReturnsPreparedStatementWithEmptyResultSet);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }
}