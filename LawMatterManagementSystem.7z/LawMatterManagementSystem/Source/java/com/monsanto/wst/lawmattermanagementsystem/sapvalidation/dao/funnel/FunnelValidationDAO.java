/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;

/**
 * Filename:    $RCSfile: FunnelValidationDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-12 14:57:36 $
 *
 * @author rdesai2
 * @version $Revision: 1.15 $
 */
public interface FunnelValidationDAO {

  boolean recordExistsWithCompanyCode(String companyCode, PersistentStoreConnection connection) throws DAOException;

  boolean recordExistsWithBusinessCode(String businessCode, PersistentStoreConnection connection) throws DAOException;

  boolean recordExistsWithCostElement(String costElementCode, PersistentStoreConnection connection) throws DAOException;

  boolean recordExistsWithCompanyAndCostElement(String companyCode, String costElement, PersistentStoreConnection connection) throws DAOException;

  boolean recordExistsWithCostCenter(String costCenter, PersistentStoreConnection connection) throws DAOException;

  /**
   * This method also does "recordExistsWithCostCenter" but incase seperate error messages needs to be populated,
   * these two methods can be called seperately.
   * @param costCenter
   * @param companyCode
   * @param businessCode
   * @param connection
   * @return
   * @throws DAOException
   */
  boolean uniqueCostCenterExistsForCompanyAndBusinessCombination(String costCenter, String companyCode, String businessCode, PersistentStoreConnection connection) throws DAOException;

  /**
   * This method gets Company and Business code for given CostCenter. Please remove this method if it has no application.
   * This method internally does both "recordExistsWithCostCenter" and "uniqueCostCenterExistsForCompanyAndBusinessCombination"
   * and returns companyCode and businessCode if validated.
   * @param costCenter
   * @param connection
   * @return AccountCode - containing "companycode" and "businesscode"
   * @throws DAOException
   */
  AccountCode getAccountCodeForCostCenter(String costCenter, PersistentStoreConnection connection) throws DAOException;

  boolean recordExistsWithCompanyAndBusinessCode(String companyCode, String businessCode, PersistentStoreConnection connection) throws DAOException;

  /**
   * Checks if a record exists with given Company code and VendorId
   * @param companyCode
   * @param vendorId Note: This method does the required 10-digit code formatting
   *                 Eg: If VendorId is '427786', a string that looks like '0000427786' will be sent for validation
   * @param connection
   * @return
   * @throws DAOException
   */
  boolean recordExistsWithCompanyAndVendorId(String companyCode, String vendorId, PersistentStoreConnection connection) throws DAOException;
}