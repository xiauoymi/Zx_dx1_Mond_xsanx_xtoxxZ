/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.*;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.util.DAOUtil;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

import java.text.DecimalFormat;

/**
 * Filename:    $RCSfile: FunnelValidationDAOImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 16:11:35 $
 *
 * @author rdesai2
 * @version $Revision: 1.25 $
 */
public class FunnelValidationDAOImpl implements FunnelValidationDAO {

  private PersistentStoreStatement preparedStatement;
  private PersistentStoreResultSet resultSet;

  private static final String RECORD_EXISTS_WITH_COMPANY_CODE_SQL =
          "SELECT COUNT (*) NUMBER_OF_RECORDS \n" +
                  "  FROM funnel.vf_cost_center \n" +
                  " WHERE company_code = ? AND ROWNUM = 1 ";

  private static final String RECORD_EXISTS_WITH_BUSINESS_CODE_SQL =
          "SELECT COUNT (*) NUMBER_OF_RECORDS \n" +
                  "  FROM funnel.vf_business_area \n" +
                  " WHERE business_area_code = ? AND ROWNUM = 1 ";

  private static final String RECORD_EXISTS_WITH_COST_ELEMENT_CODE_SQL =
          "SELECT COUNT (*) NUMBER_OF_RECORDS \n" +
                  "  FROM funnel.vf_account \n" +
                  " WHERE account_code = ? AND ROWNUM = 1 ";

  private static final String RECORD_EXISTS_WITH_COMPANY_AND_COST_ELEMENT_CODE_SQL =
          "SELECT COUNT (*) NUMBER_OF_RECORDS \n" +
                  "  FROM funnel.vf_account \n" +
                  " WHERE company_code = ? AND account_code = ? AND ROWNUM = 1 ";

  private static final String RECORD_EXISTS_WITH_COST_CENTER_SQL =
          "SELECT COUNT (*) NUMBER_OF_RECORDS \n" +
                  "  FROM funnel.vf_cost_center \n" +
                  " WHERE cost_center = ? AND ROWNUM = 1 ";

  private static final String LOOKUP_COMPANY_AND_BUSINESS_CODE_WITH_COST_CENTER_SQL =
          "SELECT COMPANY_CODE, BUSINESS_AREA_CODE  \n" +
                  "  FROM funnel.vf_cost_center \n" +
                  " WHERE cost_center = ? ";

  private static final String RECORD_EXISTS_WITH_COMPANY_AND_BUSINESS_CODE_SQL =
          "SELECT COUNT (*) NUMBER_OF_RECORDS \n" +
                  "  FROM funnel.vf_cost_center \n" +
                  " WHERE company_code = ? \n" +
                  "   AND business_area_code = ? \n" +
                  "   AND ROWNUM = 1 ";

  private static final String RECORD_EXISTS_WITH_COMPANY_AND_VENDOR_ID_SQL =
          "SELECT COUNT (*) NUMBER_OF_RECORDS \n" +
                  "  FROM funnel.vf_sap_vendor \n" +
                  " WHERE company_code = ? AND vendor_id = ? AND ROWNUM = 1 ";

  public boolean recordExistsWithCompanyCode(String companyCode, PersistentStoreConnection connection) throws DAOException {
    DAOUtil daoUtil = new DAOUtil(connection);
    try {
      return daoUtil.checkRecordExists(RECORD_EXISTS_WITH_COMPANY_CODE_SQL, new String[]{companyCode}, "NUMBER_OF_RECORDS");
    } catch (WrappingException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with company code: '" + companyCode + "', from Funnel database.", e);
    } catch (EmptyResultSetException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Null count returned while checking for existing records with company code: '" + companyCode + "', from Funnel database." +
              " It should ideally return only 0 or 1.", e);
    } finally {
      daoUtil.closeResources();
    }
  }

  public boolean recordExistsWithBusinessCode(String businessCode, PersistentStoreConnection connection) throws DAOException {
    DAOUtil daoUtil = new DAOUtil(connection);
    try {
      return daoUtil.checkRecordExists(RECORD_EXISTS_WITH_BUSINESS_CODE_SQL, new String[]{businessCode}, "NUMBER_OF_RECORDS");
    } catch (WrappingException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with bussiness code: '" + businessCode + "', from Funnel database.", e);
    } catch (EmptyResultSetException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Null count returned while checking for existing records with bussiness code: '" + businessCode + "', from Funnel database." +
              " It should ideally return only 0 or 1.", e);
    } finally {
      daoUtil.closeResources();
    }
  }

  public boolean recordExistsWithCostElement(String costElementCode, PersistentStoreConnection connection) throws DAOException {
    DAOUtil daoUtil = new DAOUtil(connection);
    try {
      return daoUtil.checkRecordExists(RECORD_EXISTS_WITH_COST_ELEMENT_CODE_SQL, new String[]{costElementCode}, "NUMBER_OF_RECORDS");
    } catch (WrappingException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with cost element: '" + costElementCode + "', from Funnel database.", e);
    } catch (EmptyResultSetException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Null count returned while checking for existing records with cost element: '" + costElementCode + "', from Funnel database." +
              " It should ideally return only 0 or 1.", e);
    } finally {
      daoUtil.closeResources();
    }
  }

  public boolean recordExistsWithCompanyAndCostElement(String companyCode, String costElement, PersistentStoreConnection connection) throws DAOException {
    DAOUtil daoUtil = new DAOUtil(connection);
    try {
      return daoUtil.checkRecordExists(RECORD_EXISTS_WITH_COMPANY_AND_COST_ELEMENT_CODE_SQL, new String[]{companyCode, costElement}, "NUMBER_OF_RECORDS");
    } catch (WrappingException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with company code: '" + companyCode + "' and cost element: '" + costElement + "', from Funnel database.", e);
    } catch (EmptyResultSetException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with company code: '" + companyCode + "' and cost element: '" + costElement + "', from Funnel database." +
              " It should ideally return only 0 or 1.", e);
    } finally {
      daoUtil.closeResources();
    }
  }

  public boolean recordExistsWithCostCenter(String costCenter, PersistentStoreConnection connection) throws DAOException {
    DAOUtil daoUtil = new DAOUtil(connection);
    try {
      return daoUtil.checkRecordExists(RECORD_EXISTS_WITH_COST_CENTER_SQL, new String[]{costCenter}, "NUMBER_OF_RECORDS");
    } catch (WrappingException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with cost center: '" + costCenter + "', from Funnel database.", e);
    } catch (EmptyResultSetException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Null count returned while checking for existing records with cost center: '" + costCenter + "', from Funnel database." +
              " It should ideally return only 0 or 1.", e);
    } finally {
      daoUtil.closeResources();
    }
  }

  public boolean uniqueCostCenterExistsForCompanyAndBusinessCombination(String costCenter, String companyCode, String businessCode, PersistentStoreConnection connection) throws DAOException {
    try {
      preparedStatement = connection.prepareStatement(LOOKUP_COMPANY_AND_BUSINESS_CODE_WITH_COST_CENTER_SQL);
      preparedStatement.setParam(1, costCenter);
      resultSet = preparedStatement.executeQuery();
      PersistentStoreResultSetFwdIterator resultSetIterator = resultSet.getForwardIterator();
      int count = 0;
      String retrievedCompanyCode = null;
      String retrievedBusinessCode = null;
      while(resultSetIterator.next()) {
        count++;
        if(count > 1){
          return false;
        }
        retrievedCompanyCode = resultSetIterator.getString("COMPANY_CODE");
        retrievedBusinessCode = resultSetIterator.getString("BUSINESS_AREA_CODE");
      }
      return companyCode.equalsIgnoreCase(retrievedCompanyCode) && businessCode.equalsIgnoreCase(retrievedBusinessCode);
    } catch (WrappingException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with cost center: '" + costCenter + "', from Funnel database.", e);
    } finally {
      DAOUtil.closeResources(preparedStatement, resultSet);
    }
  }

  public AccountCode getAccountCodeForCostCenter(String costCenter, PersistentStoreConnection connection) throws DAOException {
    try {
      preparedStatement = connection.prepareStatement(LOOKUP_COMPANY_AND_BUSINESS_CODE_WITH_COST_CENTER_SQL);
      preparedStatement.setParam(1, costCenter);
      resultSet = preparedStatement.executeQuery();
      PersistentStoreResultSetFwdIterator resultSetIterator = resultSet.getForwardIterator();
      int count = 0;
      String retrievedCompanyCode = null;
      String retrievedBusinessCode = null;
      while(resultSetIterator.next()) {
        count++;
        if(count > 1){
          return null;
        }
        retrievedCompanyCode = resultSetIterator.getString("COMPANY_CODE");
        retrievedBusinessCode = resultSetIterator.getString("BUSINESS_AREA_CODE");
      }
      if (!StringUtils.isNullOrEmpty(retrievedCompanyCode) && !StringUtils.isNullOrEmpty(retrievedBusinessCode)) {
        return new AccountCode(retrievedCompanyCode, retrievedBusinessCode, null, null, "", null, null, null, null);
      }
      return null;
    } catch (WrappingException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while getting company and business code for cost center: '" + costCenter + "', from Funnel database.", e);
    } finally {
      DAOUtil.closeResources(preparedStatement, resultSet);
    }
  }

  public boolean recordExistsWithCompanyAndBusinessCode(String companyCode, String businessCode, PersistentStoreConnection connection) throws DAOException {
    DAOUtil daoUtil = new DAOUtil(connection);
    try {
      return daoUtil.checkRecordExists(RECORD_EXISTS_WITH_COMPANY_AND_BUSINESS_CODE_SQL, new String[]{companyCode, businessCode}, "NUMBER_OF_RECORDS");
    } catch (WrappingException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with company code: '" + companyCode + "' and business code: '" + businessCode + "', from Funnel database.", e);
    } catch (EmptyResultSetException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with company code: '" + companyCode + "' and business code: '" + businessCode + "', from Funnel database." +
              " It should ideally return only 0 or 1.", e);
    } finally {
      daoUtil.closeResources();
    }
  }

  public boolean recordExistsWithCompanyAndVendorId(String companyCode, String vendorId, PersistentStoreConnection connection) throws DAOException {
    DAOUtil daoUtil = new DAOUtil(connection);
    try {
      //TODO GET RID OF THIS IF LOOP TEMPORARY FIX this takes care of company vendor combination
    if(companyCode!=null && companyCode.equalsIgnoreCase("5114")){
      return daoUtil.checkRecordExists(RECORD_EXISTS_WITH_COMPANY_AND_VENDOR_ID_SQL, new String[]{"5180",
          getFormattedVendorId(vendorId)}, "NUMBER_OF_RECORDS");
    }
      return daoUtil.checkRecordExists(RECORD_EXISTS_WITH_COMPANY_AND_VENDOR_ID_SQL, new String[]{companyCode, getFormattedVendorId(vendorId)}, "NUMBER_OF_RECORDS");
    } catch (WrappingException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with company code: '" + companyCode + "' and vendor id: '" + vendorId + "', from Funnel database.", e);
    } catch (EmptyResultSetException e) {
      Logger.log(new LoggableError(e));
      throw new DAOException("Exception occured while checking for existing records with company code: '" + companyCode + "' and vendor id: '" + vendorId + "', from Funnel database." +
              " It should ideally return only 0 or 1.", e);
    } finally {
      daoUtil.closeResources();
    }
  }

  private String getFormattedVendorId(String vendorId) {
    try {
      return new DecimalFormat(LMMSConstants.PATTERN_VENDOR_ID).format(new Long(vendorId));
    } catch (NumberFormatException e) {
      return vendorId;  //If this is not a valid number, maybe a string is expected as is.
    }
  }
}