/*
 SAPCostCenterInformationDAOImpl was created on Jun 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.*;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.AccountCodeProcessingException;
import com.monsanto.wst.lawmattermanagementsystem.accountcode.PersistencUtil;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactory;

/**
 * Filename:    $RCSfile: SAPCostCenterInformationDAOImpl.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-18 22:00:15 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class SAPCostCenterInformationDAOImpl implements SAPCostCenterInformationDAO {

  private ResourceManagerFactory resourceManagerFactory;

  private static final String GET_COST_CENTER_DESCRIPTION ="SELECT DESCR FROM funnel.vf_cost_center WHERE cost_center = " +
      "? AND ROWNUM = 1";

  private static final String GET_ACCOUNT_CODE_DESCRIPTION ="SELECT DESCR from funnel.vf_account WHERE account_code = ? AND ROWNUM = 1";

  public SAPCostCenterInformationDAOImpl(ResourceManagerFactory resourceManagerFactory) {
    this.resourceManagerFactory = resourceManagerFactory;
  }

  public String getCostCenterDescription(String costCenter) {
    ResourceConnectionManager connectionManager;
    PersistentStoreConnection storeConnection=null;
    String costCenterDescription;
    try {
      connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_ORACLE);
      storeConnection = (PersistentStoreConnection) connectionManager
          .getConnection(LMMSConstants.DATABASE_FUNNEL);
      PersistentStoreStatement storeStatement = storeConnection.prepareStatement(GET_COST_CENTER_DESCRIPTION);
      storeStatement.setParam(1,costCenter);
      PersistentStoreResultSet persistentStoreResultSet = storeStatement.executeQuery();
      PersistentStoreResultSetSingleResult storeResultSetSingleResult = persistentStoreResultSet.getSingleResult();
      costCenterDescription = storeResultSetSingleResult.getString("DESCR");
    } catch (ResourceConnectionException e) {
      throw new AccountCodeProcessingException("Exception retrieving account codes",e);
    } catch (WrappingException e) {
      throw new AccountCodeProcessingException("Exception retrieving account codes",e);
    } catch (EmptyResultSetException e) {
      throw new AccountCodeProcessingException("Exception retrieving account codes",e);
    } finally{
      PersistencUtil.closeConnection(storeConnection);
    }
    return costCenterDescription;
  }

  public String getAccountCodeDescripion(String accountDescritpion) {
    ResourceConnectionManager connectionManager;
    PersistentStoreConnection storeConnection=null;
    String accountCodeDescription;
    try {
      connectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_ORACLE);
      storeConnection = (PersistentStoreConnection) connectionManager
          .getConnection(LMMSConstants.DATABASE_FUNNEL);
      PersistentStoreStatement storeStatement = storeConnection.prepareStatement(GET_ACCOUNT_CODE_DESCRIPTION);
      storeStatement.setParam(1,accountDescritpion);
      PersistentStoreResultSet persistentStoreResultSet = storeStatement.executeQuery();
      PersistentStoreResultSetSingleResult storeResultSetSingleResult = persistentStoreResultSet.getSingleResult();
      accountCodeDescription = storeResultSetSingleResult.getString("DESCR");
    } catch (ResourceConnectionException e) {
      throw new AccountCodeProcessingException("Exception retrieving account codes",e);
    } catch (WrappingException e) {
      throw new AccountCodeProcessingException("Exception retrieving account codes",e);
    } catch (EmptyResultSetException e) {
      throw new AccountCodeProcessingException("Exception retrieving account codes",e);
    } finally{
      PersistencUtil.closeConnection(storeConnection);
    }
    return accountCodeDescription;

  }
}