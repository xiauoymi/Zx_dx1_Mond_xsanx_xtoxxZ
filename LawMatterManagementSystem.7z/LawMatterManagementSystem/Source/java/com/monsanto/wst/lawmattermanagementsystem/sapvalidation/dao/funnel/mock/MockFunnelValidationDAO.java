/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.mock;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.FunnelValidationDAO;

/**
 * Filename:    $RCSfile: MockFunnelValidationDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 16:11:20 $
 *
 * @author rdesai2
 * @version $Revision: 1.5 $
 */
public class MockFunnelValidationDAO implements FunnelValidationDAO {

  public boolean recordExistsWithCompanyCode(String companyCode, PersistentStoreConnection connection) throws DAOException {
    return true;
  }

  public boolean recordExistsWithBusinessCode(String businessCode, PersistentStoreConnection connection) throws DAOException {
    return true;
  }

  public boolean recordExistsWithCostElement(String costElementCode, PersistentStoreConnection connection) throws DAOException {
    return true;
  }

  public boolean recordExistsWithCompanyAndCostElement(String companyCode, String costElement, PersistentStoreConnection connection) throws DAOException {
    return true;
  }

  public boolean recordExistsWithCostCenter(String costCenter, PersistentStoreConnection connection) throws DAOException {
    return true;
  }

  public boolean uniqueCostCenterExistsForCompanyAndBusinessCombination(String costCenter, String companyCode, String businessCode, PersistentStoreConnection connection) throws DAOException {
    return true;
  }

  public AccountCode getAccountCodeForCostCenter(String costCenter, PersistentStoreConnection connection) throws DAOException {
    return new AccountCode("mock-company", "mock-business", null, null, "", null, null, null, null);
  }

  public boolean recordExistsWithCompanyAndBusinessCode(String companyCode, String businessCode, PersistentStoreConnection connection) throws DAOException {
    return true;
  }

  public boolean recordExistsWithCompanyAndVendorId(String companyCode, String vendorId, PersistentStoreConnection connection) throws DAOException {
    return true;
  }
}