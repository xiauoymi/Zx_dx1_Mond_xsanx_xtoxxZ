/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.mock;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.FunnelValidationDAO;

/**
 * Filename:    $RCSfile: MockFunnelValidationDAOThatThrowsException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockFunnelValidationDAOThatThrowsException implements FunnelValidationDAO {

  public boolean recordExistsWithCompanyCode(String companyCode, PersistentStoreConnection connection) throws DAOException {
    throw new DAOException("Mock Funnel DAO exception while implementing recordExistsWithCompanyCode()...");
  }

  public boolean recordExistsWithBusinessCode(String businessCode, PersistentStoreConnection connection) throws DAOException {
    throw new DAOException("Mock Funnel DAO exception while implementing recordExistsWithBusinessCode()...");
  }

  public boolean recordExistsWithCostElement(String costElementCode, PersistentStoreConnection connection) throws DAOException {
    throw new DAOException("Mock Funnel DAO exception while implementing recordExistsWithCostElement()...");
  }

  public boolean recordExistsWithCompanyAndCostElement(String companyCode, String costElement, PersistentStoreConnection connection) throws DAOException {
    throw new DAOException("Mock Funnel DAO exception while implementing recordExistsWithCompanyAndCostElement()...");
  }

  public boolean recordExistsWithCostCenter(String costCenter, PersistentStoreConnection connection) throws DAOException {
    throw new DAOException("Mock Funnel DAO exception while implementing recordExistsWithCostCenter()...");
  }

  public boolean uniqueCostCenterExistsForCompanyAndBusinessCombination(String costCenter, String companyCode, String businessCode, PersistentStoreConnection connection) throws DAOException {
    throw new DAOException("Mock Funnel DAO exception while implementing uniqueCostCenterExistsForCompanyAndBusinessCombination()...");
  }

  public AccountCode getAccountCodeForCostCenter(String costCenter, PersistentStoreConnection connection) throws DAOException {
    throw new DAOException("Mock Funnel DAO exception while implementing getAccountCodeForCostCenter()...");
  }

  public boolean recordExistsWithCompanyAndBusinessCode(String companyCode, String businessCode, PersistentStoreConnection connection) throws DAOException {
    throw new DAOException("Mock Funnel DAO exception while implementing recordExistsWithCompanyAndBusinessCode()...");
  }

  public boolean recordExistsWithCompanyAndVendorId(String companyCode, String vendorId, PersistentStoreConnection connection) throws DAOException {
    throw new DAOException("Mock Funnel DAO exception while implementing recordExistsWithCompanyAndVendorId()...");
  }
}