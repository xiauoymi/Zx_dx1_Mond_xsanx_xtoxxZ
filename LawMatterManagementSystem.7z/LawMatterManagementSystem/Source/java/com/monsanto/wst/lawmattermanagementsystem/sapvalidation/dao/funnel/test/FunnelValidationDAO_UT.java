/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.test;

import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.mock.MockConnectionThatReturnsPreparedStatementWithEmptyResultSet;
import com.monsanto.wst.lawmattermanagementsystem.mock.MockConnectionThatThrowsExceptionWhileReturningPreparedStatement;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.FunnelValidationDAO;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.FunnelValidationDAOImpl;
import junit.framework.TestCase;

import java.io.IOException;

/**
 * Filename:    $RCSfile: FunnelValidationDAO_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-26 20:26:46 $
 * <p/>
 * <p/>
 * Note: Some unit tests make an actual connection to database because database just contains all valid account codes
 * and is read-only. Duplicating all account codes and validating against those is not desirable.
 *
 * @author rdesai2
 * @version $Revision: 1.17 $
 */
public class FunnelValidationDAO_UT extends TestCase {

  private ResourceConnectionManager resourceConnectionManager;

  private PersistentStoreConnection connectionThatThrowsExceptionWhileReturningPreparedStatement
          = new MockConnectionThatThrowsExceptionWhileReturningPreparedStatement();

  private PersistentStoreConnection connectionThatReturnsPreparedStatementWithEmptyResultSet
          = new MockConnectionThatReturnsPreparedStatementWithEmptyResultSet();

  protected void setUp() throws IOException, ResourceConnectionException, LogRegistrationException {
    resourceConnectionManager = new ResourceManagerFactoryImpl().getConnectionManager(LMMSConstants.DATASOURCE_TYPE_ORACLE);
  }

  public void testRecordExistsWithCompanyCode() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    assertTrue(dao.recordExistsWithCompanyCode("5180", connection));
    assertTrue(dao.recordExistsWithCompanyCode("5114", connection));
    assertTrue(dao.recordExistsWithCompanyCode("0001", connection));
    assertFalse(dao.recordExistsWithCompanyCode("non-existing-company-code", connection));
    closeConnection(connection);
  }

  public void testRecordExistsWithCompanyCode_ThowsException_IfConnectionEncountersExceptionWhileReturningPreparedStatement() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithCompanyCode("5180", connectionThatThrowsExceptionWhileReturningPreparedStatement);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithCompanyCode_ThowsException_ForEmptyResultSet() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithCompanyCode("5180", connectionThatReturnsPreparedStatementWithEmptyResultSet);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithBusinessCode() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    assertTrue(dao.recordExistsWithBusinessCode("9130", connection));
    assertTrue(dao.recordExistsWithBusinessCode("9115", connection));
    assertTrue(dao.recordExistsWithBusinessCode("0001", connection));
    assertFalse(dao.recordExistsWithBusinessCode("non-existing-bussiness-code", connection));
    closeConnection(connection);
  }

  public void testRecordExistsWithBusinessCode_ThowsException_IfConnectionEncountersExceptionWhileReturningPreparedStatement() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithBusinessCode("9130", connectionThatThrowsExceptionWhileReturningPreparedStatement);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithBusinessCode_ThowsException_ForEmptyResultSet() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithBusinessCode("9130", connectionThatReturnsPreparedStatementWithEmptyResultSet);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithCostElement() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    assertTrue(dao.recordExistsWithCostElement("41702000", connection));
    assertTrue(dao.recordExistsWithCostElement("41701900", connection));
    assertTrue(dao.recordExistsWithCostElement("21310878", connection));
    assertFalse(dao.recordExistsWithCostElement("non-existing-cost-element", connection));
    closeConnection(connection);
  }

  public void testRecordExistsWithCostElement_ThowsException_IfConnectionEncountersExceptionWhileReturningPreparedStatement() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithCostElement("41702000", connectionThatThrowsExceptionWhileReturningPreparedStatement);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithCostElement_ThowsException_ForEmptyResultSet() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithCostElement("41702000", connectionThatReturnsPreparedStatementWithEmptyResultSet);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithCompanyAndCostElement() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    assertTrue(dao.recordExistsWithCompanyAndCostElement("5180", "41701900", connection));
    assertTrue(dao.recordExistsWithCompanyAndCostElement("5114", "41702000", connection));
    assertFalse(dao.recordExistsWithCompanyAndCostElement("non-existing-company-code", "non-existing-cost-element", connection));
    closeConnection(connection);
  }

  public void testRecordExistsWithCompanyAndCostElement_ThowsException_IfConnectionEncountersExceptionWhileReturningPreparedStatement() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithCompanyAndCostElement("5180", "41701900", connectionThatThrowsExceptionWhileReturningPreparedStatement);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithCompanyAndCostElement_ThowsException_ForEmptyResultSet() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithCompanyAndCostElement("5180", "41701900", connectionThatReturnsPreparedStatementWithEmptyResultSet);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithCostCenter() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    assertTrue(dao.recordExistsWithCostCenter("SLR76387", connection));
    assertTrue(dao.recordExistsWithCostCenter("MTL74238", connection));
    assertFalse(dao.recordExistsWithCostCenter("non-existing-cost-element", connection));
    closeConnection(connection);
  }

  public void testRecordExistsWithCostCenter_ThowsException_IfConnectionEncountersExceptionWhileReturningPreparedStatement() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithCostCenter("SLR76387", connectionThatThrowsExceptionWhileReturningPreparedStatement);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithCostCenter_ThowsException_ForEmptyResultSet() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithCostCenter("SLR76387", connectionThatReturnsPreparedStatementWithEmptyResultSet);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testUniqueCostCenterExistsForCompanyAndBusinessCombination() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    assertTrue(dao.uniqueCostCenterExistsForCompanyAndBusinessCombination("SLR76387", "5180", "9130", connection));
    assertTrue(dao.uniqueCostCenterExistsForCompanyAndBusinessCombination("MTL74238", "5114", "9115", connection));
    closeConnection(connection);
  }

  public void testUniqueCostCenterExistsForCompanyAndBusinessCombination_ReturnsFalse_IfDuplicateCombinationsFound() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    assertFalse(dao.uniqueCostCenterExistsForCompanyAndBusinessCombination("00000101", "CA01", "0001", connection));
    assertFalse(dao.uniqueCostCenterExistsForCompanyAndBusinessCombination("00000301", "US01", "0001", connection));
    closeConnection(connection);
  }

  public void testUniqueCostCenterExistsForCompanyAndBusinessCombination_ReturnsFalse_ForNonExistingCostCenter() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    assertFalse(dao.uniqueCostCenterExistsForCompanyAndBusinessCombination("non-existing-cost-center", "company-code-does-not-matter", "business-code-does-not-matter", connection));
    closeConnection(connection);
  }

  public void testUniqueCostCenterExistsForCompanyAndBusinessCombination_ThowsException_IfConnectionEncountersExceptionWhileReturningPreparedStatement() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.uniqueCostCenterExistsForCompanyAndBusinessCombination("SLR76387", "5180", "9130", connectionThatThrowsExceptionWhileReturningPreparedStatement);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  //Note: The company code gets converted to "5180" from "5114" as per the business requirement. So even though the
  //      company code returned for cost center "MTL74238" is "5114" it gets converted to "5180".
  public void testGetAccountCodeForCostCenter() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    validateAccountCode("5180", "9130", null, dao.getAccountCodeForCostCenter("SLR76387", connection));
    validateAccountCode("5114", "9115", null, dao.getAccountCodeForCostCenter("MTL74238", connection));
    closeConnection(connection);
  }

  private void validateAccountCode(String companyCode, String businessCode, String costElement, AccountCode accountCode) throws DAOException {
    assertEquals(companyCode, accountCode.getCompanyCode());
    assertEquals(businessCode, accountCode.getBusinessCode());
    assertEquals(costElement, accountCode.getCostElement());
  }

  public void testGetAccountCodeForCostCenter_ReturnsNull_IfDuplicateCombinationsFound() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    assertEquals(null, dao.getAccountCodeForCostCenter("00000101", connection));
    assertEquals(null, dao.getAccountCodeForCostCenter("00000301", connection));
    closeConnection(connection);
  }

  public void testGetAccountCodeForCostCenter_ReturnsNull_ForNonExistingCostCenter() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    assertEquals(null, dao.getAccountCodeForCostCenter("non-existing-cost-center", connection));
    closeConnection(connection);
  }

  public void testGetAccountCodeForCostCenter_ThowsException_IfConnectionEncountersExceptionWhileReturningPreparedStatement() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.getAccountCodeForCostCenter("SLR76387", connectionThatThrowsExceptionWhileReturningPreparedStatement);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithCompanyAndBusinessCode() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    assertTrue(dao.recordExistsWithCompanyAndBusinessCode("5114", "9115", connection));
    assertTrue(dao.recordExistsWithCompanyAndBusinessCode("5180", "9130", connection));
    assertTrue(dao.recordExistsWithCompanyAndBusinessCode("0001", "0001", connection));
    assertFalse(dao.recordExistsWithCompanyAndBusinessCode("non-existing-company-code", "non-existing-business-code", connection));
    closeConnection(connection);
  }

  public void testRecordExistsWithCompanyAndBusinessCode_ThowsException_IfConnectionEncountersExceptionWhileReturningPreparedStatement() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithCompanyAndBusinessCode("5114", "9115", connectionThatThrowsExceptionWhileReturningPreparedStatement);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithCompanyAndBusinessCode_ThowsException_ForEmptyResultSet() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithCompanyAndBusinessCode("5114", "9115", connectionThatReturnsPreparedStatementWithEmptyResultSet);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithCompanyAndVendorId() throws Exception {
    PersistentStoreConnection connection = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    assertTrue(dao.recordExistsWithCompanyAndVendorId("5180", "427786", connection));
    assertTrue(dao.recordExistsWithCompanyAndVendorId("5114", "0000228529", connection));
    assertTrue(dao.recordExistsWithCompanyAndVendorId("5181", "00250099", connection));
    assertFalse(dao.recordExistsWithCompanyAndVendorId("non-existing-company-code", "non-existing-business-code", connection));
    closeConnection(connection);
  }

  public void testRecordExistsWithCompanyAndVendorId_ThowsException_IfConnectionEncountersExceptionWhileReturningPreparedStatement() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithCompanyAndVendorId("5114", "0000427786", connectionThatThrowsExceptionWhileReturningPreparedStatement);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testRecordExistsWithCompanyAndVendorId_ThowsException_ForEmptyResultSet() throws Exception {
    FunnelValidationDAO dao = new FunnelValidationDAOImpl();
    try {
      dao.recordExistsWithCompanyAndVendorId("5114", "0000427786", connectionThatReturnsPreparedStatementWithEmptyResultSet);
      fail("Required exception not thrown");
    } catch (DAOException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  private void closeConnection(PersistentStoreConnection connection) throws Exception {
    if (connection != null) {
      connection.close();
    }
  }
}