/*
 SAPCostCenterInformationDAOImpl_UT was created on Jun 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.test;

import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.SAPCostCenterInformationDAO;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.SAPCostCenterInformationDAOImpl;
import junit.framework.TestCase;

import java.io.IOException;

/**
 * Filename:    $RCSfile: SAPCostCenterInformationDAOImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-18 22:00:16 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class SAPCostCenterInformationDAOImpl_UT extends TestCase {

  private ResourceManagerFactoryImpl factory;

  protected void setUp() throws IOException, ResourceConnectionException, LogRegistrationException {
    factory = new ResourceManagerFactoryImpl();
  }

  public void testGetCostCenterDescription() throws Exception {
    SAPCostCenterInformationDAO dao = new SAPCostCenterInformationDAOImpl(factory);
    String costCenterDescription = dao.getCostCenterDescription("SLR72111");
    assertEquals("Strategic Development",costCenterDescription);
  }

  public void testGetAccountCodeDescription() throws Exception {
    SAPCostCenterInformationDAO dao = new SAPCostCenterInformationDAOImpl(factory);
    String accountCodeDescription = dao.getAccountCodeDescripion("41701900");
    assertEquals("OUTSIDE COUNSEL FEES",accountCodeDescription);
  }
}