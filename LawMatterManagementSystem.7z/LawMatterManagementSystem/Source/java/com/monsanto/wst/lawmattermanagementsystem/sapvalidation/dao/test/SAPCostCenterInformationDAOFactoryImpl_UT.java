/*
 SAPCostCenterInformationDAOFactoryImpl_UT was created on Jun 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.test;

import junit.framework.TestCase;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.SAPCostCenterInformationDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.SAPCostCenterInformationDAOFactory;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.SAPCostCenterInformationDAOFactoryImpl;

/**
 * Filename:    $RCSfile: SAPCostCenterInformationDAOFactoryImpl_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-06-18 22:00:15 $
 *
 * @author VRBETHI
 * @version $Revision: 1.1 $
 */
public class SAPCostCenterInformationDAOFactoryImpl_UT extends TestCase {

  public void testSAPGetCostCenterInformationDAOFactory() throws Exception {
    SAPCostCenterInformationDAOFactory sapCostCenterInformationDAOFactory = new SAPCostCenterInformationDAOFactoryImpl();
    assertEquals(SAPCostCenterInformationDAOImpl.class,sapCostCenterInformationDAOFactory.getSAPCostCenterInformationDAO().getClass());
  }
}