/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.SAPValidationDAOFactory;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.SAPValidationDAOFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.erd.ERDValidationDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.FunnelValidationDAOImpl;
import junit.framework.TestCase;

import java.io.IOException;

/**
 * Filename:    $RCSfile: SAPValidationDAOFactory_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class SAPValidationDAOFactory_UT extends TestCase {

  private SAPValidationDAOFactory factory;

  protected void setUp() throws IOException {

    factory = new SAPValidationDAOFactoryImpl();
  }

  public void testGetValidationDAO_FunnelDAO() throws Exception {
    assertEquals(FunnelValidationDAOImpl.class, factory.getValidationDAO(LMMSConstants.DATABASE_FUNNEL).getClass());
  }

  public void testGetValidationDAO_ERDDAO() throws Exception {
    assertEquals(ERDValidationDAOImpl.class, factory.getValidationDAO(LMMSConstants.DATABASE_ERD).getClass());
  }

  public void testGetValidationDAO_ThrowsException_ForInvalidDatabaseType() throws Exception {
    try {
      factory.getValidationDAO("invalid-database-type");
      fail("Required exception not thrown.");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      factory.getValidationDAO("");
      fail("Required exception not thrown.");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      factory.getValidationDAO(null);
      fail("Required exception not thrown.");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }
}