/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;

/**
 * Filename:    $RCSfile: SAPVerificationService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-01-23 15:30:14 $
 *
 * It is the responsibility of the client app/user to closeResources() after completing all validation checks because
 * just one connection is used to perform all validation checks (for better performance).
 * Incase connection resources are closed and same instance needs to be reused then they must be re-initialized by
 * calling initializeConnections().
 *
 * @author rdesai2
 * @version $Revision: 1.11 $
 */
public interface SAPVerificationService {

  /**
   * This is the method that will be used while validating each Invoice record during invoice processing.
   * @param accountCode
   *        [Note: accountCode.costCenter and accountCode.profitCenter can be null/empty]
   * @param environmentSpecificBoxId
   *        It is generally the box-id referred as 'environmentSpecificBoxId'. Eg: P08 (prod) or D08 (dev)
   * @return String - Error Message describing validation failure
   *                - Empty string - if validation successful
   * @throws ServiceException
   */
  String validateAccountCode(AccountCode accountCode, String environmentSpecificBoxId) throws ServiceException;

  boolean validateCompany(String companyCode) throws ServiceException;

  boolean validateBusinessCode(String businessCode) throws ServiceException;

  boolean validateCostElement(String costElementCode) throws ServiceException;

  boolean validateCompanyAndCostElement(String companyCode, String costElement) throws ServiceException;

  boolean validateCostCenter(String costCenter) throws ServiceException;

  boolean validateUniqueCostCenterExistsForCompanyAndBusinessCombination(String costCenter, String companyCode, String businessCode) throws ServiceException;

  AccountCode validateCostCenterAndReturnCompanyAndBusinessCode(String costCenter) throws ServiceException;

  boolean validateCompanyAndBusinessCode(String companyCode, String businessCode) throws ServiceException;

  boolean validateVendor(String companyCode, String vendorId) throws ServiceException;

  boolean validateBalsheet(String costElement, String environmentSpecificBoxId) throws ServiceException;

  boolean validateProfitCenter(String profitCenter, String environmentSpecificBoxId) throws ServiceException;

  /**
   * Incase connection resources are closed and they need to be re-initialized making use of the same instance...
   * This is by default called in the constructor and in most cases will not be required to invoke.
   */
  void initializeConnections() throws ServiceException;

  /**
   * This method should be called after completing all the validation checks for a particular set.
   * If this is called in between and more validations are yet to be done with the existing set, please first call
   * initializeConnections()
   */
  void closeResourceConnections();
}