/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionException;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactory;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.SAPValidationDAOFactory;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.erd.ERDValidationDAO;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.funnel.FunnelValidationDAO;

/**
 * Filename:    $RCSfile: SAPVerificationServiceImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-03 14:37:45 $
 *
 * @author rdesai2
 * @version $Revision: 1.19 $
 */
public class SAPVerificationServiceImpl implements SAPVerificationService {
  private ResourceConnectionManager resourceConnectionManager;
  private boolean connected;
  private FunnelValidationDAO funnelDAO;
  private ERDValidationDAO erdDAO;
  private PersistentStoreConnection connectionToFunnelDatabase;
  private PersistentStoreConnection connectionToERDDatabase;

  public SAPVerificationServiceImpl(SAPValidationDAOFactory validationDAOFactory, ResourceManagerFactory resourceManagerFactory) throws ServiceException {
    this.resourceConnectionManager = resourceManagerFactory.getConnectionManager(LMMSConstants.DATASOURCE_TYPE_ORACLE);
    funnelDAO = (FunnelValidationDAO) validationDAOFactory.getValidationDAO(LMMSConstants.DATABASE_FUNNEL);
    erdDAO = (ERDValidationDAO) validationDAOFactory.getValidationDAO(LMMSConstants.DATABASE_ERD);
    initializeConnections();
  }

  public String validateAccountCode(AccountCode accountCode, String environmentSpecificBoxId) throws ServiceException {
    checkConnection();
    String companyCode = accountCode.getCompanyCode();
    if (!validateCompany(companyCode)) {
      return LMMSConstants.SAP_ERROR_MSG_BAD_COMPANY_CODE;
    }
    String businessCode = accountCode.getBusinessCode();
    if (!validateBusinessCode(businessCode)) {
      return LMMSConstants.SAP_ERROR_MSG_BAD_BUSINESS_CODE;
    }
    if (!validateCompanyAndBusinessCode(companyCode, businessCode)) {
      return LMMSConstants.SAP_ERROR_MSG_BAD_COMPANY_BUSINESS_COMBINATION;
    }
    String costElement = accountCode.getCostElement();
    if (!validateCostElement(costElement)) {
      return LMMSConstants.SAP_ERROR_MSG_BAD_COST_ELEMENT;
    }
    if (!validateCompanyAndCostElement(companyCode, costElement)) {
      return LMMSConstants.SAP_ERROR_MSG_BAD_COMPANY_COST_ELEMENT_COMBINATION;
    }
    String costCenter = accountCode.getCostCenter();
    if (isCostCenterPresent(costCenter)) {
      if (!validateCostCenter(costCenter)) {
        return LMMSConstants.SAP_ERROR_MSG_BAD_COST_CENTER;
      }
      if (!validateUniqueCostCenterExistsForCompanyAndBusinessCombination(costCenter, companyCode, businessCode)) {
        return LMMSConstants.SAP_ERROR_MSG_BAD_COST_CENTER_FOR_COMPANY_BUSNESS_COMBINATION;
      }
      if (!validateBalsheet(costElement, environmentSpecificBoxId)) {
        return LMMSConstants.SAP_ERROR_MSG_INVALID_BALSHEET;
      }
    }
    return returnNoErrorIndication();
  }

  public boolean validateCompany(String companyCode) throws ServiceException {
    checkConnection();
    try {
      return funnelDAO.recordExistsWithCompanyCode(companyCode, connectionToFunnelDatabase);
    } catch (DAOException e) {
      throw new ServiceException(e);
    }
  }

  public boolean validateBusinessCode(String businessCode) throws ServiceException {
    checkConnection();
    try {
      return funnelDAO.recordExistsWithBusinessCode(businessCode, connectionToFunnelDatabase);
    } catch (DAOException e) {
      throw new ServiceException(e);
    }
  }

  public boolean validateCostElement(String costElementCode) throws ServiceException {
    checkConnection();
    try {
      return funnelDAO.recordExistsWithCostElement(costElementCode, connectionToFunnelDatabase);
    } catch (DAOException e) {
      throw new ServiceException(e);
    }
  }

  public boolean validateCompanyAndCostElement(String companyCode, String costElement) throws ServiceException {
    checkConnection();
    try {
      return funnelDAO.recordExistsWithCompanyAndCostElement(companyCode, costElement, connectionToFunnelDatabase);
    } catch (DAOException e) {
      throw new ServiceException(e);
    }
  }

  public boolean validateCostCenter(String costCenter) throws ServiceException {
    checkConnection();
    try {
      return funnelDAO.recordExistsWithCostCenter(costCenter, connectionToFunnelDatabase);
    } catch (DAOException e) {
      throw new ServiceException(e);
    }
  }

  public boolean validateUniqueCostCenterExistsForCompanyAndBusinessCombination(String costCenter, String companyCode, String businessCode) throws ServiceException {
    checkConnection();
    try {
      return funnelDAO.uniqueCostCenterExistsForCompanyAndBusinessCombination(costCenter, companyCode, businessCode, connectionToFunnelDatabase);
    } catch (DAOException e) {
      throw new ServiceException(e);
    }
  }

  public AccountCode validateCostCenterAndReturnCompanyAndBusinessCode(String costCenter) throws ServiceException {
    checkConnection();
    try {
      return funnelDAO.getAccountCodeForCostCenter(costCenter, connectionToFunnelDatabase);
    } catch (DAOException e) {
      throw new ServiceException(e);
    }
  }

  public boolean validateCompanyAndBusinessCode(String companyCode, String businessCode) throws ServiceException {
    checkConnection();
    try {
      return funnelDAO.recordExistsWithCompanyAndBusinessCode(companyCode, businessCode, connectionToFunnelDatabase);
    } catch (DAOException e) {
      throw new ServiceException(e);
    }
  }

  public boolean validateVendor(String companyCode, String vendorId) throws ServiceException {
    checkConnection();
    try {
      return funnelDAO.recordExistsWithCompanyAndVendorId(companyCode, vendorId, connectionToFunnelDatabase);
    } catch (DAOException e) {
      throw new ServiceException(e);
    }
  }

  public boolean validateBalsheet(String costElement, String environmentSpecificBoxId) throws ServiceException {
    checkConnection();
    try {
      return !erdDAO.recordExistsWithCostElement(costElement, environmentSpecificBoxId, connectionToERDDatabase);
    } catch (DAOException e) {
      throw new ServiceException(e);
    }
  }

  public boolean validateProfitCenter(String profitCenter, String environmentSpecificBoxId) throws ServiceException {
    checkConnection();
    try {
      return erdDAO.recordExistsWithProfitCenter(profitCenter, environmentSpecificBoxId, connectionToERDDatabase);
    } catch (DAOException e) {
      throw new ServiceException(e);
    }
  }

  public void initializeConnections() throws ServiceException {
    getConnectionToFunnelDB(resourceConnectionManager);
    getConnectionToERDDB(resourceConnectionManager);
    connected = true;
  }

  public void closeResourceConnections() {
    connected = false;
    try {
      if (connectionToFunnelDatabase != null) {
        connectionToFunnelDatabase.close();
      }
      if (connectionToERDDatabase != null) {
        connectionToERDDatabase.close();
      }
    } catch (WrappingException e) {
      Logger.log(new LoggableError("SAPVerificationServiceImpl: Error while closing connection resources to Funnel and ERD Databases."));
      Logger.log(new LoggableError(e));
    }
  }

  private void checkConnection() throws ServiceException {
    if (!connected) {
      throw new ServiceException("Connection to respective database closed, please call initializeConnections() before this validation.");
    }
  }

  private void getConnectionToFunnelDB(ResourceConnectionManager resourceConnectionManager) throws ServiceException {
    try {
      connectionToFunnelDatabase = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_FUNNEL);
    } catch (ResourceConnectionException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException("SAPVerification service exception while getting connection to Funnel DB.", e);
    }
  }

  private void getConnectionToERDDB(ResourceConnectionManager resourceConnectionManager) throws ServiceException {
    try {
      connectionToERDDatabase = (PersistentStoreConnection) resourceConnectionManager.getConnection(LMMSConstants.DATABASE_ERD);
    } catch (ResourceConnectionException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException("SAPVerification service exception while getting connection to ERD DB.", e);
    }
  }

  private String returnNoErrorIndication() {
    return "";
  }

  private boolean isCostCenterPresent(String costCenter) {
    return !StringUtils.isNullOrEmpty(costCenter);
  }
}