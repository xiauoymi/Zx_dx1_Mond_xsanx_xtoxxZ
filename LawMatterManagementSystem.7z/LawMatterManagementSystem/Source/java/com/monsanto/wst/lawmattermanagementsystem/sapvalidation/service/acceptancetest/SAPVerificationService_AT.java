/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.acceptancetest;

import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.SAPValidationDAOFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationService;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationServiceImpl;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: SAPVerificationService_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-07-03 17:55:30 $
 *
 * @author rdesai2
 * @version $Revision: 1.19 $
 */
public class SAPVerificationService_AT extends TestCase {

  /**
   * Acceptance test against Funnel and ERD DB
   * @throws Exception
   */
  public void testSomeValidateInvoiceFields() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new SAPValidationDAOFactoryImpl(), new ResourceManagerFactoryImpl());
    assertEquals("", service.validateAccountCode(new AccountCode("5180", "9130", "41701900", "SLR76387", "", null, null,
        null,
        null), "D08"));
    assertTrue(service.validateCompany("5180"));
    assertFalse(service.validateCompany("invalid-company"));
    assertFalse(service.validateBalsheet("0011642000", "P08"));
    assertTrue(service.validateProfitCenter("0500821000", "P08"));
    assertFalse(service.validateVendor("5180", "invalid-vendor"));
    assertTrue(service.validateBusinessCode("9115"));
    service.closeResourceConnections();
  }

  public void testValidateForCompanyCostElementCombination() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new SAPValidationDAOFactoryImpl(), new ResourceManagerFactoryImpl());
    assertEquals("Bad Cost Center for this Company/Business", service.validateAccountCode(new AccountCode("0001", "0001", "00001010", "SLR76387", null, null,
        null, null, null), "D08"));
    assertTrue(service.validateCompany("5180"));
    assertFalse(service.validateCompany("invalid-company"));
    assertFalse(service.validateBalsheet("0011642000", "P08"));
    assertTrue(service.validateProfitCenter("0500821000", "P08"));
    assertFalse(service.validateVendor("5180", "invalid-vendor"));
    assertTrue(service.validateBusinessCode("9115"));
    service.closeResourceConnections();
  }

  public void testValidateForCompanyBusinessCombination() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new SAPValidationDAOFactoryImpl(), new ResourceManagerFactoryImpl());
    assertEquals("Bad Company/Business Combination", service.validateAccountCode(new AccountCode("5110", "0001", "00001010", "SLR76387", null, null,
        null, null, null), "D08"));
    assertTrue(service.validateCompany("5180"));
    assertFalse(service.validateCompany("invalid-company"));
    assertFalse(service.validateBalsheet("0011642000", "P08"));
    assertTrue(service.validateProfitCenter("0500821000", "P08"));
    assertFalse(service.validateVendor("5180", "invalid-vendor"));
    assertTrue(service.validateBusinessCode("9115"));
    service.closeResourceConnections();
  }

  public void testValidateForCompanyBusinessCombination_Bug() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new SAPValidationDAOFactoryImpl(), new ResourceManagerFactoryImpl());
    assertEquals("Bad Cost Element", service.validateAccountCode(new AccountCode("5180", "9115", "11649010", "BALSHEET", null, null,
        "509115000", null, null), "D08"));
    assertTrue(service.validateCompany("5180"));
    assertFalse(service.validateCompany("invalid-company"));
    assertFalse(service.validateBalsheet("0011642000", "P08"));
    assertTrue(service.validateProfitCenter("0500821000", "P08"));
    assertFalse(service.validateVendor("5180", "invalid-vendor"));
    assertTrue(service.validateBusinessCode("9115"));
    service.closeResourceConnections();
  }
}