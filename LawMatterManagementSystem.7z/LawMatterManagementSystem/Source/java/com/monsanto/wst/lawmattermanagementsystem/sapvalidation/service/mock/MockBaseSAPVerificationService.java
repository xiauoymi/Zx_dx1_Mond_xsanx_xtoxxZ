/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationService;

/**
 * Filename:    $RCSfile: MockBaseSAPVerificationService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public class MockBaseSAPVerificationService implements SAPVerificationService {

  public String validateAccountCode(AccountCode accountCode, String environmentSpecificBoxId) throws ServiceException {
    return null;
  }

  public boolean validateCompany(String companyCode) throws ServiceException {
    return false;
  }

  public boolean validateBusinessCode(String businessCode) throws ServiceException {
    return false;
  }

  public boolean validateCostElement(String costElementCode) throws ServiceException {
    return false;
  }

  public boolean validateCompanyAndCostElement(String companyCode, String costElement) throws ServiceException {
    return false;
  }

  public boolean validateCostCenter(String costCenter) throws ServiceException {
    return false;
  }

  public boolean validateUniqueCostCenterExistsForCompanyAndBusinessCombination(String costCenter, String companyCode, String businessCode) throws ServiceException {
    return false;
  }

  public AccountCode validateCostCenterAndReturnCompanyAndBusinessCode(String costCenter) throws ServiceException {
    return null;
  }

  public boolean validateCompanyAndBusinessCode(String companyCode, String businessCode) throws ServiceException {
    return false;
  }

  public boolean validateVendor(String companyCode, String vendorId) throws ServiceException {
    return false;
  }

  public boolean validateBalsheet(String costElement, String environmentSpecificBoxId) throws ServiceException {
    return false;
  }

  public boolean validateProfitCenter(String profitCenter, String environmentSpecificBoxId) throws ServiceException {
    return false;
  }

  public void initializeConnections() throws ServiceException {
  }

  public void closeResourceConnections() {
  }
}