/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.mock;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;

/**
 * Filename:    $RCSfile: MockSAPVerificationService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-29 21:00:55 $
 *
 * @author rdesai2
 * @version $Revision: 1.4 $
 */
public class MockSAPVerificationService extends MockBaseSAPVerificationService{
  private boolean wasSAPValidtaionCalled = false;
  private int numberOfTimesAccountCodeValidationCalled = 0;
  private String costCenter;

  public String validateAccountCode(AccountCode accountCode, String environmentSpecificBoxId) throws ServiceException {
    if ("BAD_COST".equalsIgnoreCase(accountCode.getCostElement())) {
      return LMMSConstants.SAP_ERROR_MSG_BAD_COST_ELEMENT;
    }
    numberOfTimesAccountCodeValidationCalled++;
    wasSAPValidtaionCalled=true;
    costCenter = accountCode.getCostCenter();
    return "";
  }

  public boolean validateProfitCenter(String profitCenter, String environmentSpecificBoxId) throws ServiceException {
    return !"INVALID_PROFIT_CENTER".equalsIgnoreCase(profitCenter);
  }

  public boolean validateVendor(String companyCode, String vendorId) throws ServiceException {
    return !"BAD_CORP_VENDOR".equalsIgnoreCase(vendorId);
  }

  public boolean wasSAPValidationCalled() {
    return wasSAPValidtaionCalled;
  }

  public int numberOfTimesAccountCodeValidationCalled() {
    return numberOfTimesAccountCodeValidationCalled;
  }

  public String getCostCenter() {
    return costCenter;
  }
}