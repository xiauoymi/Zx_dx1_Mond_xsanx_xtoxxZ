/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.test;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.model.AccountCode;
import com.monsanto.wst.lawmattermanagementsystem.resource.ResourceManagerFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.resource.mock.MockFactoryReturnsExceptionThrowingConnectionManager;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.SAPValidationDAOFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.dao.mock.*;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationService;
import com.monsanto.wst.lawmattermanagementsystem.sapvalidation.service.SAPVerificationServiceImpl;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: SAPVerificationService_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2009-02-24 16:16:49 $
 *
 * @author rdesai2
 * @version $Revision: 1.24 $
 */
public class SAPVerificationService_UT extends TestCase {


  /**
   * Please Note:
   * For the first few validation (in this test), it is possible to work with real data, so in order to avoid all confusing
   * mocks, direct database lookup (which is read-only and contains only valid account codes) is done.
   * For some (ones after this test) it is tough to get an invalid combinations, so in such cases mocks have been used.
   * @throws Exception -
   */
  public void testValidateAccountCode() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new SAPValidationDAOFactoryImpl(), new ResourceManagerFactoryImpl());
    validateMessage(LMMSConstants.SAP_ERROR_MSG_BAD_COMPANY_CODE, "invalid-company-code", null, null, null, service);
    validateMessage(LMMSConstants.SAP_ERROR_MSG_BAD_BUSINESS_CODE, "5180", "invalid-business-code", null, null, service);
    validateMessage(LMMSConstants.SAP_ERROR_MSG_BAD_COST_ELEMENT, "5180", "9130", "invalid-cost-element", null, service);
    validateMessage(LMMSConstants.SAP_ERROR_MSG_BAD_COMPANY_BUSINESS_COMBINATION, "0001", "9130", "21310878", null, service);
    validateMessage(LMMSConstants.SAP_ERROR_MSG_BAD_COST_CENTER, "5180", "9130", "41701900", "invalid-cost-element", service);
    validateMessage(LMMSConstants.SAP_ERROR_MSG_BAD_COMPANY_CODE, "CA01", "0001", "00001000", "00000101", service);
  }

  public void testValidateAccountCode_ForInvalidBalsheet() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactoryForTestingInvalidBalsheet(), new ResourceManagerFactoryImpl());
    validateMessage(LMMSConstants.SAP_ERROR_MSG_INVALID_BALSHEET, "5180", "9130", "41701900", "SLR76387", service);
  }

  public void testValidateAccountCode_ForInvalidCompanyAndBusinessCombination() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationFactoryForTestingInvalidCompanyBusinessCombination(), new ResourceManagerFactoryImpl());
    validateMessage(LMMSConstants.SAP_ERROR_MSG_BAD_COMPANY_BUSINESS_COMBINATION, "company-code", "business-code", "cost-element", "cost-center", service);
  }

  public void testValidateAccountCode_ForSuccessCondition() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new SAPValidationDAOFactoryImpl(), new ResourceManagerFactoryImpl());
    validateMessage("", "5180", "9130", "41701900", null, service);   //Valid - Since all previous checks are valid and CostCenter = null
    validateMessage("", "5180", "9130", "41701900", "", service);   //Valid - Since all previous checks are valid and CostCenter = ""
    validateMessage("", "5180", "9130", "41701900", "SLR76387", service); //All Valid Account Codes
  }

  public void testConstructor_ThrowsException_IfDatabaseConnectionToFunnelNotEstablished() throws Exception {
    try {
      new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new MockFactoryReturnsExceptionThrowingConnectionManager());
      fail("Required excpetion not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testConstructor_ThrowsException_IfDatabaseConnectionToERDNotEstablished() throws Exception {
    try {
      new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new MockFactoryReturnsExceptionThrowingConnectionManager());
      fail("Required excpetion not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testValidateCompany() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new ResourceManagerFactoryImpl());
    assertTrue(service.validateCompany("test-company-code"));
  }

  public void testValidateCompany_ThrowsException_IfDAOEncountersAnyException() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactoryThatReturnsExceptionThrowingDAOs(), new ResourceManagerFactoryImpl());
    try {
      service.validateCompany("test-company-code");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testValidateBusinessCode() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new ResourceManagerFactoryImpl());
    assertTrue(service.validateBusinessCode("test-business-code"));
  }

  public void testValidateBusinessCode_ThrowsException_IfDAOEncountersAnyException() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactoryThatReturnsExceptionThrowingDAOs(), new ResourceManagerFactoryImpl());
    try {
      service.validateBusinessCode("test-business-code");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testValidateCostElement() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new ResourceManagerFactoryImpl());
    assertTrue(service.validateCostElement("test-cost-element"));
  }

  public void testValidateCostElement_ThrowsException_IfDAOEncountersAnyException() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactoryThatReturnsExceptionThrowingDAOs(), new ResourceManagerFactoryImpl());
    try {
      service.validateCostElement("test-cost-element");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testValidateCompanyAndCostElement() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new ResourceManagerFactoryImpl());
    assertTrue(service.validateCompanyAndCostElement("test-company-code", "test-cost-element"));
  }

  public void testValidateCompanyAndCostElement_ThrowsException_IfDAOEncountersAnyException() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactoryThatReturnsExceptionThrowingDAOs(), new ResourceManagerFactoryImpl());
    try {
      service.validateCompanyAndCostElement("test-company-code", "test-cost-element");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testValidateCostCenter() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new ResourceManagerFactoryImpl());
    assertTrue(service.validateCostCenter("test-cost-center"));
  }

  public void testValidateCostCenter_ThrowsException_IfDAOEncountersAnyException() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactoryThatReturnsExceptionThrowingDAOs(), new ResourceManagerFactoryImpl());
    try {
      service.validateCostCenter("test-cost-center");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testValidateUniqueCostCenterExistsForCompanyAndBusinessCombination() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new ResourceManagerFactoryImpl());
    assertTrue(service.validateUniqueCostCenterExistsForCompanyAndBusinessCombination("test-cost-center", "test-company", "test-business"));
  }

  public void testValidateUniqueCostCenterExistsForCompanyAndBusinessCombination_ThrowsException_IfDAOEncountersAnyException() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactoryThatReturnsExceptionThrowingDAOs(), new ResourceManagerFactoryImpl());
    try {
      service.validateUniqueCostCenterExistsForCompanyAndBusinessCombination("test-cost-center", "test-company", "test-business");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testValidateCostCenterAndReturnCompanyAndBusinessCode() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new ResourceManagerFactoryImpl());
    AccountCode accountCode = service.validateCostCenterAndReturnCompanyAndBusinessCode("test-cost-center");
    assertEquals("mock-company", accountCode.getCompanyCode());
    assertEquals("mock-business", accountCode.getBusinessCode());
    assertEquals(null, accountCode.getCostElement());
  }

  public void testValidateCostCenterAndReturnCompanyAndBusinessCode_ThrowsException_IfDAOEncountersAnyException() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactoryThatReturnsExceptionThrowingDAOs(), new ResourceManagerFactoryImpl());
    try {
      service.validateCostCenterAndReturnCompanyAndBusinessCode("test-cost-center");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testValidateCompanyAndBusinessCode() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new ResourceManagerFactoryImpl());
    assertTrue(service.validateCompanyAndBusinessCode("test-company", "test-business"));
  }

  public void testValidateCompanyAndBusinessCode_ThrowsException_IfDAOEncountersAnyException() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactoryThatReturnsExceptionThrowingDAOs(), new ResourceManagerFactoryImpl());
    try {
      service.validateCompanyAndBusinessCode("test-company", "test-business");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testValidateVendor() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new ResourceManagerFactoryImpl());
    assertTrue(service.validateVendor("test-company", "test-vendor"));
  }

  public void testValidateVendor_ThrowsException_IfDAOEncountersAnyException() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactoryThatReturnsExceptionThrowingDAOs(), new ResourceManagerFactoryImpl());
    try {
      service.validateVendor("test-company", "test-vendor");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testValidateBalsheet() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new ResourceManagerFactoryImpl());
    assertTrue(service.validateBalsheet("test-cost-element", "D08"));
  }

  public void testValidateBalsheet_ThrowsException_IfDAOEncountersAnyException() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactoryThatReturnsExceptionThrowingDAOs(), new ResourceManagerFactoryImpl());
    try {
      service.validateBalsheet("test-cost-element", "D08");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testValidateProfitCenter() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactory(), new ResourceManagerFactoryImpl());
    assertTrue(service.validateProfitCenter("test-profit-center", "D08"));
  }

  public void testValidateProfitCenter_ThrowsException_IfDAOEncountersAnyException() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new MockSAPValidationDAOFactoryThatReturnsExceptionThrowingDAOs(), new ResourceManagerFactoryImpl());
    try {
      service.validateProfitCenter("test-profit-center", "D08");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
      System.out.println("Expected path, e.getCause().getMessage() = " + e.getCause().getMessage());
    }
  }

  public void testServiceExceptionThrown_IfValidateMethodCalled_AfterClosingResourceConnections() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new SAPValidationDAOFactoryImpl(), new ResourceManagerFactoryImpl());
    service.closeResourceConnections();
    try {
      service.validateCompany("5180");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      service.validateBusinessCode("test-business-code");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      service.validateCostElement("test-cost-element");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      service.validateCompanyAndCostElement("test-company-code", "test-cost-element");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      service.validateCostCenter("test-cost-center");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      service.validateUniqueCostCenterExistsForCompanyAndBusinessCombination("test-cost-center", "test-company", "test-business");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      service.validateCostCenterAndReturnCompanyAndBusinessCode("test-cost-center");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      service.validateCompanyAndBusinessCode("test-company", "test-business");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      service.validateVendor("test-company", "test-vendor");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      service.validateBalsheet("test-cost-element", "D08");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      service.validateProfitCenter("test-profit-center", "D08");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      service.validateAccountCode(null, "D08");
      fail("Required exception not thrown");
    } catch (ServiceException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

  public void testInitializeConnection() throws Exception {
    SAPVerificationService service = new SAPVerificationServiceImpl(new SAPValidationDAOFactoryImpl(), new ResourceManagerFactoryImpl());
    service.closeResourceConnections();
    try {
      service.validateCompany("5180");
    } catch (ServiceException e) {
      //Expected Path
    }
    service.initializeConnections();
    service.validateCompany("5180");
  }

  private void validateMessage(String expectedMessage, String companyCode, String businessCode, String costElement, String costCenter, SAPVerificationService service) throws ServiceException {
    AccountCode accountCode = new AccountCode(companyCode, businessCode, costElement, costCenter, "", null, null, null, null);
    String message = service.validateAccountCode(accountCode, "D08");
    assertEquals(expectedMessage, message);
  }
}