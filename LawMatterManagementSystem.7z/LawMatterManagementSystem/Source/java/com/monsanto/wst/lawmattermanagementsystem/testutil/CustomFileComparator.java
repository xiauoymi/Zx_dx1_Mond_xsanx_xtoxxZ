/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.testutil;

import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

/**
 * Filename:    $RCSfile: CustomFileComparator.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-13 22:05:45 $
 *
 * @author rdesai2
 * @version $Revision: 1.2 $
 */
public abstract class CustomFileComparator {

  /**
   * Allows file comparison with capability of optionally specifying condition for ignoring certain characters.
   *
   * Note: This will also truncate all the trailing spaces by default.
   *
   * The motivation is just for use in tests (UTs and ATs). Please feel free to refactor if needed.
   */

  public boolean compareFiles(String file1URL, String file2URL) throws IOException {
    BufferedReader br1 = new BufferedReader(new FileReader(resolveAbsolutePath(file1URL)));
    BufferedReader br2 = new BufferedReader(new FileReader(resolveAbsolutePath(file2URL)));
    int lineNumber = 1;
    while (true) {
      String line1 = br1.readLine();
      String line2 = br2.readLine();
      if (line1 == null) {
        if (line2 != null) {
          System.err.println(file1URL + " is shorter than " + file2URL);
        }
        return line2 == null;
      } else {
        if (line2 == null) {
          System.err.println(file2URL + " is shorter than " + file1URL);
          return false;
        } else if (!isEqual(StringUtils.stripEnd(line1, LMMSConstants.SPACE_CONSTANT) , StringUtils.stripEnd(line2, LMMSConstants.SPACE_CONSTANT), lineNumber)) {
          System.err.println(file1URL + " contains");
          System.err.println("> " + line1);
          System.err.println("where " + file2URL + " contains");
          System.err.println("> " + line2);
          return false;
        }
      }
      lineNumber++;
    }
  }

  /**
   * Can be overridden for ignoring certain characters depending on specific requirements for specific file.
   * <p/>
   * Eg: return (lineNumber == 1 && position == 2) || ((lineNumber == 3 && inBetween(position, 2, 5)));
   * <p/>
   * In the above example the following characters will be ignored from comparison:
   * 2nd Character of line#1 and
   * 2nd to 5th character in line#3
   * <p/>
   * Default: return false; [to compare the entire file and ignore nothing]
   *
   * @param lineNumber - begining with 1
   * @param position   - begining with 0.
   * @return
   */
  protected abstract boolean isCharacterToIgnore(int lineNumber, int position);

  /**
   * Inclusive of both start and end.
   *
   * @param position
   * @param start
   * @param end
   * @return
   */
  protected boolean inBetween(int position, int start, int end) {
    return position >= start && position <= end;
  }

  private boolean isEqual(String line1, String line2, int lineNumber) {
    if (line1 == null && line2 == null) {
      return true;
    }
    if (line1 == null || line2 == null) {
      return false;
    }
    int length;
    if (line1.length() >= line2.length()) {
      length = line1.length();
    } else {
      length = line2.length();
    }
    char line1Chars[] = line1.toCharArray();
    char line2Chars[] = line2.toCharArray();
    return !compareAllCharacters(length, line1Chars, line2Chars, lineNumber);
  }

  private boolean compareAllCharacters(int length, char[] line1Chars, char[] line2Chars, int lineNumber) {
    int position = 0;
    while (length-- != 0) {
      if (!isCharacterToIgnore(lineNumber, position)) {
        if (unequalCharacter(line1Chars[position], line2Chars[position])) {
          return true;
        }
      }
      position++;
    }
    return false;
  }

  private boolean unequalCharacter(char line1Char, char line2Char) {
    return line1Char != line2Char;
  }

  private static String resolveAbsolutePath(String fileURL) {
    return new File(fileURL).getAbsolutePath();
  }

}