package com.monsanto.wst.lawmattermanagementsystem.util;

import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.EmailDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.EmailUtilityImpl;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.JavaMailEmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.MailDocumentFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.mail.util.dom.XMLEmailBuilderDOMImpl;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.xmlserialization.XmlSerializerBuilder;

import java.util.List;
import java.util.ArrayList;
import java.io.File;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Jan 13, 2009
 * Time: 9:09:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class AccountCodeEmailUtil {

  private boolean emailSent = false;
  private EmailUtilityImpl emailUtility;
  private String accountCodeFileName;
  EmailDAOImpl emailDao;
  XmlSerializerBuilder serializer;
  public AccountCodeEmailUtil(String accountCodeFileName) {
    this.accountCodeFileName = accountCodeFileName;
    serializer = new XmlSerializerBuilder();
    emailDao = new EmailDAOImpl(System.getProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR)+File.separator+"AccountCodeNotificationList.xml",
                                                   serializer,
                                                   "AccountCodeNotificationRecepients");
    emailUtility = new AccountCodeEmailUtilityImpl(new JavaMailEmailService(new MailDocumentFactoryImpl(), new XMLEmailBuilderDOMImpl()), emailDao);
  }

  public AccountCodeEmailUtil() {
  }

  public void sendEmail() throws ServiceException {
    emailUtility.sendSuccessStatusEmail(LMMSConstants.BATCH_AC_SUMMARY_FILE_NAME,getAttachmentList(accountCodeFileName));
    emailSent = true;
  }

  public boolean wasEmailSent() {
    return emailSent;
  }
   private static List getAttachmentList(String summaryReportFileName) {
    List attachmentList = new ArrayList();
    String histroyDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
    attachmentList.add(histroyDir + File.separator + summaryReportFileName);
    return attachmentList;
  }

}
