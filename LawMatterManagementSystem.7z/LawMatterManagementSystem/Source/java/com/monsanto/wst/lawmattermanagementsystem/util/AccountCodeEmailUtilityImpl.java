package com.monsanto.wst.lawmattermanagementsystem.util;

import com.monsanto.wst.lawmattermanagementsystem.invoice.service.EmailUtilityImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.EmailDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.JavaMailEmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailException;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailService;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Jan 13, 2009
 * Time: 9:36:57 AM
 * To change this template use File | Settings | File Templates.
 */
public class AccountCodeEmailUtilityImpl extends EmailUtilityImpl {
  EmailService emailService;
  EmailDAOImpl emailDAO; 
  public AccountCodeEmailUtilityImpl(JavaMailEmailService emailService, EmailDAOImpl emailDao) {
    super(emailService,emailDao);
    this.emailDAO = emailDao;
    this.emailService = emailService;
  }

  public void sendSuccessStatusEmail(String accountCodeFileName, List attachmentList) throws ServiceException {
    sendEmail(attachmentList);
  }

  public void sendEmail(List attachmentList) throws ServiceException {
    List messageLineList = new ArrayList();
    messageLineList.add("Please find attached,the account code process summary report.");
    sendFormattedEmail(getTOList(),new ArrayList(),attachmentList,messageLineList);
  }
  private void sendFormattedEmail(List toList, List ccList, List attachmentList, List messageLines) throws ServiceException {
    try {
      emailService.sendEmail(
              LMMSConstants.EMAIL_CONST_FROM,
              toList,
              ccList,
              LMMSConstants.ACCOUNT_CODE_EMAIL_CONST_SUBJECT,
              attachmentList,
              messageLines);
    } catch (EmailException e) {
      throw new ServiceException("Error: Exception occured while sending email.", e);
    }
  }
  private List getTOList() throws ServiceException {
      try {
        return emailDAO.getTOList();
      } catch (DAOException e) {
        throw new ServiceException("Error: Exception occured while reading recipient list (TO-List) for sending out email [Account Code Batch Process] ", e);
      }
    }
 

}
