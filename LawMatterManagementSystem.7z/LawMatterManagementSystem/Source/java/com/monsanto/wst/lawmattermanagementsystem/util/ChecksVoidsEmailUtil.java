package com.monsanto.wst.lawmattermanagementsystem.util;

import com.monsanto.xmlserialization.XmlSerializerBuilder;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.EmailDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.JavaMailEmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.javamail.MailDocumentFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.mail.util.dom.XMLEmailBuilderDOMImpl;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

import java.io.File;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Feb 2, 2009
 * Time: 12:34:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class ChecksVoidsEmailUtil {
  private String checksFileName;
  private String voidsFileName;
  private XmlSerializerBuilder serializer;
  private EmailDAOImpl emailDao;
  private ChecksVoidsEmailUtilityImpl emailUtility;


  public ChecksVoidsEmailUtil(String checksFileName, String voidsFileName) {
    this.checksFileName = checksFileName;
    this.voidsFileName = voidsFileName;
    serializer = new XmlSerializerBuilder();
    emailDao = new EmailDAOImpl(System.getProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR)+ File.separator+"ChecksVoidsNotificationList.xml",
                                                   serializer,
                                                   "ChecksVoidsNotificationRecepients");
    emailUtility = new ChecksVoidsEmailUtilityImpl(new JavaMailEmailService(new MailDocumentFactoryImpl(), new XMLEmailBuilderDOMImpl()), emailDao);
  }

  public void sendEmail() throws ServiceException {
    emailUtility.sendSuccessStatusEmail("",getAttachmentList(checksFileName,voidsFileName));
  }

  public boolean wasEmailSent() {
    return true;
  }
   //TODO: Attach Voids when it is tested
   private static List getAttachmentList(String checksFileName, String voidsFileName) {
    List attachmentList = new ArrayList();
    String histroyDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
    attachmentList.add(histroyDir + File.separator + checksFileName);
    //attachmentList.add(histroyDir + File.separator + voidsFileName);
    return attachmentList;
  }
}
