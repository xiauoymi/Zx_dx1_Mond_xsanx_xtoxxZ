package com.monsanto.wst.lawmattermanagementsystem.util;

import com.monsanto.wst.lawmattermanagementsystem.invoice.service.EmailUtilityImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.EmailDAO;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailService;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.EmailException;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Feb 2, 2009
 * Time: 12:46:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class ChecksVoidsEmailUtilityImpl extends EmailUtilityImpl {

  private EmailService emailService;
  private EmailDAO emailDAO;
  
  public ChecksVoidsEmailUtilityImpl(EmailService emailService, EmailDAO emailDAO) {
    super(emailService, emailDAO);
    this.emailService = emailService;
    this.emailDAO = emailDAO;
  }

  public void sendSuccessStatusEmail(String invoiceFileName, List attachmentList) throws ServiceException {
    sendEmail(attachmentList);
  }

  public void sendEmail(List attachmentList) throws ServiceException {
    List messageLineList = new ArrayList();
    messageLineList.add("Please find attached,Checks/Voids process summary report.");
    sendFormattedEmail(getTOList(),new ArrayList(),attachmentList,messageLineList);
  }
  private void sendFormattedEmail(List toList, List ccList, List attachmentList, List messageLines) throws ServiceException {
    try {
      emailService.sendEmail(
              LMMSConstants.EMAIL_CONST_FROM,
              toList,
              ccList,
              LMMSConstants.CHECKS_VOIDS_EMAIL_CONST_SUBJECT,
              attachmentList,
              messageLines);
    } catch (EmailException e) {
      throw new ServiceException("Error: Exception occured while sending email.", e);
    }
  }
  private List getTOList() throws ServiceException {
      try {
        return emailDAO.getTOList();
      } catch (DAOException e) {
        throw new ServiceException("Error: Exception occured while reading recipient list (TO-List) for sending out email [Checks Voids Processing]", e);
      }
    }
  public boolean wasEmailSent(){
    return true;
  }
}
