/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.util;

import org.apache.commons.lang.time.DateUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.Calendar;

/**
 * Filename:    $RCSfile: DateUtil.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-14 16:11:34 $
 *
 * @author rdesai2
 * @version $Revision: 1.7 $
 */
public class DateUtil {

  public static String getCurrentDate(String datePattern) {
    return getDate(datePattern, new GregorianCalendar().getTime());
  }

  public static String getDate(String datePattern, Date date) {
    return new SimpleDateFormat(datePattern).format(date);
  }

  public static String getDateString(Date date) {
    if (date != null) {
      return DateUtil.getDate("MM/dd/yyyy", date);
    }
    return null;
  }

  /**
   * Returns date of 2 days from current date. Required for Invoice Batch Process ATs
   * @param datePattern
   * @return
   */
  public static String getFutureDate(String datePattern) {
    int numberOfDays = 2;
    long dateLongValue = System.currentTimeMillis() + new Long(numberOfDays*24*60*60*1000).longValue();
    Date futureDate = new Date(dateLongValue);
    return getDate(datePattern, futureDate);
  }

  public static double getTimeDifferenceBetweenCSTAndGMT() {
    GregorianCalendar gmtTime = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    int i = gmtTime.get(Calendar.HOUR_OF_DAY);
    System.out.println("i = " + i);
    long inMillis = gmtTime.getTimeInMillis();
    System.out.println("inMillis = " + inMillis);

    GregorianCalendar cstTime = new GregorianCalendar(TimeZone.getTimeZone("CST"));
    int i1 = cstTime.get(Calendar.HOUR_OF_DAY);
    System.out.println("i1 = " + i1);
    long inMillis1 = cstTime.getTimeInMillis();
    System.out.println("inMillis1 = " + inMillis1);

    long l = inMillis1 - inMillis;
    System.out.println("l = " + l);
    return l /(60 * 60 * 1000);

//
//    System.out.println("i = " + i);
//    System.out.println("gmtTime = " + gmtTime);
//    String outputString = gmtTime.getTimeZone().getDisplayName();
//    System.out.println("outputString = " + outputString);
//    System.out.println("cstTime = " + cstTime.getTime());
//    System.out.println("gmtTime = " + gmtTime.getTime());
//    Date date = cstTime.getTime();
//    Date date1 = gmtTime.getTime();
//    double duration = com.monsanto.Util.date.DateUtil.getHourDuration(date, date1);
//
//        // Get the current time in Hong Kong
//    Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("Hongkong"));
//
//    int hour12 = cal.get(Calendar.HOUR);         // 0..11
//    int minutes = cal.get(Calendar.MINUTE);      // 0..59
//    int seconds = cal.get(Calendar.SECOND);      // 0..59
//    boolean am = cal.get(Calendar.AM_PM) == Calendar.AM;
//
//    // Get the current hour-of-day at GMT
//    cal.setTimeZone(TimeZone.getTimeZone("GMT"));
//    int hour24 = cal.get(Calendar.HOUR_OF_DAY);  // 0..23
//    return duration;


  }
}