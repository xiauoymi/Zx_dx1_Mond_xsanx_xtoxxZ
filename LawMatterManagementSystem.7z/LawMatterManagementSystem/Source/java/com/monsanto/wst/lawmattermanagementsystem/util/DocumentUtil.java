/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.util;

import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;

/**
 * Filename:    $RCSfile: DocumentUtil.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.5 $
 */
public class DocumentUtil {

  public static Document transformRequestXML(String templateFileName, String newValue, String xpathString, int indexOfXPath) throws ParserException, TransformerException {
    Document document = DOMUtil.newDocument(templateFileName);
    Node objectIdValueNode = XPathAPI.eval(document, xpathString).nodelist().item(indexOfXPath);
    Node newObjectIdValueNode = document.createTextNode(newValue);
    objectIdValueNode.replaceChild(newObjectIdValueNode, objectIdValueNode.getFirstChild());
    return document;
  }

  public static String extractNameFromFilePath(String absoluteFilePath) {
    if(StringUtils.isNullOrEmpty(absoluteFilePath)){
      throw new IllegalArgumentException("Invalid file path: '" + absoluteFilePath + "'");
    }
    int lastIndex = absoluteFilePath.lastIndexOf("\\");
    if (lastIndex == -1) {
      lastIndex = absoluteFilePath.lastIndexOf("/");
    }
    if (lastIndex != -1) {
      return absoluteFilePath.substring(lastIndex + 1);
    }
    throw new IllegalArgumentException("Invalid file path: '" + absoluteFilePath + "'");
  }
}