/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.util;

import com.monsanto.Util.StringUtils;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import org.custommonkey.xmlunit.XMLTestCase;

import java.io.IOException;

/**
 * Filename:    $RCSfile: LMMSBaseTestCase.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-05-16 14:42:38 $
 *
 * @author rdesai2
 * @version $Revision: 1.14 $
 */
public class LMMSBaseTestCase extends XMLTestCase {

  /**
   * Use this if the test needs pre-setting of some System params (Eg: lsi.function, lmms.config.dir, etc...)
   */

  private String currentHistoryDir;
  private String currentConfigDir;
  private String currentLsiFunction;
  private String currentLastRunInfoDir;
  private String currentTeamconnectWebserviceUrl;

  protected void setUp() throws IOException {
    currentHistoryDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR);
    currentLastRunInfoDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR);
    currentConfigDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR);
    currentLsiFunction = System.getProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION);
    currentTeamconnectWebserviceUrl = System.getProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL);
    setTestValuesForSystemParam();
  }

  protected void tearDown() throws Exception {
    resetSystemParamValues();
  }

  public void testSystemParams() throws Exception {
    assertNotNull(System.getProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION));
    assertNotNull(System.getProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR));
    assertNotNull(System.getProperty(LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR));
    assertNotNull(System.getProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR));
    assertNotNull(System.getProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL));
  }

  private void setTestValuesForSystemParam() {
    String tempDir = System.getProperty(LMMSConstants.SYSTEM_PARAM_TEMP_DIR);
    if (StringUtils.isNullOrEmpty(tempDir)) {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, "C:");
      System.setProperty(LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR, "C:");
      System.setProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR, "C:");
    } else {
      //todo Take care of this
      System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, tempDir);
      System.setProperty(LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR, tempDir);
      //todo Take care of this
//      System.setProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR, tempDir);
    }
    System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, LMMSConstants.LSI_FUNCTION_WIN);
    //System.setProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL, "http://woodstork.monsanto.com/TeamConnect/xml");
    System.setProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL, "http://w3d.teamconnect.monsanto.com/TeamConnect/xml");
  }

  private void resetSystemParamValues() {
    if(currentHistoryDir != null) {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_HISTORY_DIR, currentHistoryDir);
    }
    if(currentConfigDir != null) {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_CONFIG_DIR, currentConfigDir);
    }
    if(currentLsiFunction != null) {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_LSI_FUNCTION, currentLsiFunction);
    }
    if(currentLastRunInfoDir != null) {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_LAST_RUN_INFO_DIR, currentLastRunInfoDir);
    }
    if(currentTeamconnectWebserviceUrl != null) {
      System.setProperty(LMMSConstants.SYSTEM_PARAM_TEAMCONNECT_WEBSERVICE_URL, currentTeamconnectWebserviceUrl);
    }
  }
}