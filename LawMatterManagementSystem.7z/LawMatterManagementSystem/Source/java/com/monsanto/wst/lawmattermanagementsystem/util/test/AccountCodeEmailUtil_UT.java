package com.monsanto.wst.lawmattermanagementsystem.util.test;

import junit.framework.TestCase;
import com.monsanto.wst.lawmattermanagementsystem.util.AccountCodeEmailUtil;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.EmailDAOImpl;
import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.xmlserialization.XmlSerializerBuilder;

import java.io.File;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Jan 13, 2009
 * Time: 9:06:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class AccountCodeEmailUtil_UT extends TestCase{
  public void testEmailSentOnSuccessfulAccountCodebatchProcess() throws Exception{
    AccountCodeEmailUtil accountCodeEmailUtil = new AccountCodeEmailUtil("Sapmaster_AutoClose_200901130954.dat");
    accountCodeEmailUtil.sendEmail();
    assertTrue(accountCodeEmailUtil.wasEmailSent());
  }
}
