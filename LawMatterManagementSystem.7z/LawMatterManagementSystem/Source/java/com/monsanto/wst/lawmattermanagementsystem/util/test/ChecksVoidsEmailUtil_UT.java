package com.monsanto.wst.lawmattermanagementsystem.util.test;

import junit.framework.TestCase;
import com.monsanto.wst.lawmattermanagementsystem.util.ChecksVoidsEmailUtil;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Feb 2, 2009
 * Time: 12:33:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class ChecksVoidsEmailUtil_UT extends TestCase{

  public void testChecksVoidsEmailSentSuccessfully() throws Exception{
    ChecksVoidsEmailUtil chkVoidEmailUtil = new ChecksVoidsEmailUtil("checks_200901301523.txt", "voids_200902021158.txt");
    chkVoidEmailUtil.sendEmail();
    assertTrue(chkVoidEmailUtil.wasEmailSent());
  }
}
