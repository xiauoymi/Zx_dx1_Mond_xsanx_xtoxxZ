package com.monsanto.wst.lawmattermanagementsystem.util.test;

import junit.framework.TestCase;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.EmailUtilityImpl;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockEmailDAO;
import com.monsanto.wst.lawmattermanagementsystem.util.ChecksVoidsEmailUtilityImpl;
import com.monsanto.wst.lawmattermanagementsystem.mail.service.mock.MockEmailService;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: bghale
 * Date: Feb 2, 2009
 * Time: 12:45:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class ChecksVoidsEmailUtilityImpl_UT extends TestCase{

  public void testChecksVoidsEmailSentSuccessfully() throws Exception{
    ChecksVoidsEmailUtilityImpl impl = new ChecksVoidsEmailUtilityImpl(new MockEmailService(),new MockEmailDAO());
    impl.sendSuccessStatusEmail("checks_200901301523.txt",new ArrayList());
    assertTrue(impl.wasEmailSent());
  }
}
