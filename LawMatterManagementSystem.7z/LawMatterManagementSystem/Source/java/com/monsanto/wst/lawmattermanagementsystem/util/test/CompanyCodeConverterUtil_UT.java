/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.util.test;

import com.monsanto.wst.lawmattermanagementsystem.util.CompanyCodeConverterUtil;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: CompanyCodeConverterUtil_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-10-22 20:19:19 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class CompanyCodeConverterUtil_UT extends TestCase {
//todo this is no more necessary. This was a temporary fix
//  public void testConvert5114CompanyCodeTo5180() throws Exception {
//    assertEquals("5180", CompanyCodeConverterUtil.convert5114CompanyCodeTo5180("5114"));
//    assertEquals("some-other-code", CompanyCodeConverterUtil.convert5114CompanyCodeTo5180("some-other-code"));
//    assertEquals("", CompanyCodeConverterUtil.convert5114CompanyCodeTo5180(""));
//  }

  public void testConvert5114CompanyCodeTo5180_ThrowsException_IfCompanyCodeIsNull() throws Exception {
    try {
      CompanyCodeConverterUtil.convert5114CompanyCodeTo5180(null);
      fail("Required exception not thrown.");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }
}