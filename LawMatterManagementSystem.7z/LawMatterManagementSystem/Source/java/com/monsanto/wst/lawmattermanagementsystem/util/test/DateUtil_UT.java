/*
 DateUtil_UT was created on Dec 13, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.util.test;

import junit.framework.TestCase;
import com.monsanto.wst.lawmattermanagementsystem.util.DateUtil;

/**
 * Filename:    $RCSfile: DateUtil_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: vrbethi $    	 On:	$Date: 2008-05-27 15:32:50 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class DateUtil_UT extends TestCase {

  public void testGetTimeDifferenceBetweenCSTAndGMT() throws Exception {
    double hours = DateUtil.getTimeDifferenceBetweenCSTAndGMT();
    assertEquals(0, (int) hours);
  }
}