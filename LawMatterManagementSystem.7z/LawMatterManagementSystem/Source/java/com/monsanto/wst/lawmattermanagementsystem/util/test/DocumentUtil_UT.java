/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.util.test;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.wst.lawmattermanagementsystem.util.DocumentUtil;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;

/**
 * Filename:    $RCSfile: DocumentUtil_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class DocumentUtil_UT extends XMLTestCase {

  public void testExtractFileNameFromLocation() throws Exception {
    assertEquals("test.txt", DocumentUtil.extractNameFromFilePath("C:/folder/folder2/test.txt"));
    assertEquals("test.txt", DocumentUtil.extractNameFromFilePath("C:\\folder\\folder2\\test.txt"));
  }

  public void testExtractFileNameFromLocation_ThrowsException_ForInvalidFileLocationInput() throws Exception {
    try {
      DocumentUtil.extractNameFromFilePath("some-text-without-file-seperators");
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      DocumentUtil.extractNameFromFilePath(null);
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
    try {
      DocumentUtil.extractNameFromFilePath("");
      fail("Required exception not thrown");
    } catch (IllegalArgumentException e) {
      System.out.println("Expected path, e.getMessage() = " + e.getMessage());
    }
  }

    public void testTransformRequestXML() throws Exception {
        Document document = DocumentUtil.transformRequestXML
                  ("com/monsanto/wst/lawmattermanagementsystem/documentservice/documentpos/acceptancetest/updateRequest.xml",
                      "001", "/updateDocumentRequest/requestDetails/updateDocument/documentAttributes/attribute/value", 0);
        Document resultDocument = DOMUtil.newDocumentFromXML("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                   "<updateDocumentRequest xmlns=\"www.monsanto.com/pos\">\n" +
                   "  <folder>LawTeamConnect</folder>\n" +
                   "  <requestDetails>\n" +
                   "    <updateDocument>\n" +
                   "      <documentAttributes>\n" +
                   "        <attribute>\n" +
                   "          <name>objectId</name>\n" +
                   "          <value>001</value>\n" +
                   "        </attribute>\n" +
                   "      </documentAttributes>\n" +
                   "    </updateDocument>\n" +
                   "  </requestDetails>\n" +
                   "</updateDocumentRequest>");
       assertXMLEqual(resultDocument,document);
    }


}