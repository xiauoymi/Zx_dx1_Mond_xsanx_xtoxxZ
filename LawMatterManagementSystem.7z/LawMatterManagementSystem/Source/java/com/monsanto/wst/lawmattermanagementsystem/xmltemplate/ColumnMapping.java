/*
 ColumnMapping was created on Jan 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate;

import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: ColumnMapping.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-08 19:41:49 $
 *
 * @author VRBETHI
 * @version $Revision: 1.9 $
 */
public class ColumnMapping implements Comparable{
    private int index;
    private int startIndex;
    private int endIndex;
    private String justification;
    private String text;
    private String filler;

    public ColumnMapping(int index, int startIndex, int endIndex, String justification, String text, String filler) {
        this.index = index;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.justification = justification;
        this.text = text;
        this.filler = filler;
    }

    public int getIndex() {
        return index;
    }

    public int getStartIndex() {
        return startIndex;
    }

    public int getEndIndex() {
        return endIndex;
    }

    public String getJustification() {
        return justification;
    }

    public String getText() {
        return text;
    }

    public String getFiller() {
        return filler;
    }

    //todo what if the text is null
    public String getFormattedString() throws DataExceedsColumnLengthException {
        String formattedString=null;
        int length = endIndex-startIndex+1;
        if(text==null){
            text= "";
        }
        if(text.length()>length){
            throw new DataExceedsColumnLengthException("Invalid Data "+text+" at column index "+index);
        }
        if(justification.equalsIgnoreCase("left")){
            formattedString = StringUtils.rightPad(text,length,filler);
        }
        if(justification.equalsIgnoreCase("right")){
            formattedString = StringUtils.leftPad(text,length,filler);
        }
        return formattedString;
    }


    public int compareTo(Object o) {
      int indexOfObject = ((ColumnMapping)o).getIndex();
      if(index==indexOfObject){
        return 0;
      }
      if(index > indexOfObject){
        return 1;
      }
      if(index < indexOfObject){
        return -1;
      }
      return 0;
    }
}