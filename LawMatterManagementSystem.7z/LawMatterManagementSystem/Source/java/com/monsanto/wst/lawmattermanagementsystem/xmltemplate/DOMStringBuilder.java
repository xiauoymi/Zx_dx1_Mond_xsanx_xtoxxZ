/*
 DOMStringBuilder was created on Jan 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

/**
 * Filename:    $RCSfile: DOMStringBuilder.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-12 15:58:30 $
 *
 * @author vrbethi
 * @version $Revision: 1.8 $
 */
public class DOMStringBuilder implements StringBuilder {

  public StringBuffer buildString(String evaluatedString, Parser parser) throws ServiceException, DataExceedsColumnLengthException {
    Mapping mapping;
    StringBuffer stringBuffer = new StringBuffer();
    try {
      mapping = parser.getMapping(evaluatedString);
      mapping.sortDescending();
      for (int i = 0; i < mapping.getSize(); i++) {
        ColumnMapping columnMapping = mapping.getColumnMapping(i);
        String formattedString = columnMapping.getFormattedString();
        stringBuffer.append(formattedString);
      }
    } catch (XMLTemplateParseException e) {
      throw new ServiceException("Exception occured while parsing the XML string: "
              + LMMSConstants.NEW_LINE_CONSTANT
              + evaluatedString
              + LMMSConstants.NEW_LINE_CONSTANT
              + "Error Message: " + e.getMessage()
              , e);
    }
    return stringBuffer;
  }
}