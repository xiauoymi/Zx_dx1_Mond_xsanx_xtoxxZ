/*
 DomXMLMappingParser was created on Jan 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.commonutils.xml.XalanXPathUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.IOException;

/**
 * Filename:    $RCSfile: DomXMLMappingParser.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-01-31 21:37:32 $
 *
 * @author VRBETHI
 * @version $Revision: 1.7 $
 */
public class DomXMLMappingParser implements Parser {

    public DomXMLMappingParser() {
    }

    //TODO What can I refactor over here.
    public Mapping getMapping(String evaluatedString) throws XMLTemplateParseException {
        Document document;
        Mapping mapping = new Mapping();
        try {
            document = DOMUtil.newDocumentFromXML(evaluatedString);
            //todo should I pass this in
            XalanXPathUtils xalanXPathUtils = new XalanXPathUtils();
            //todo clarify about exception
            NodeList nodeList = xalanXPathUtils.selectNodeList(document,"columns/column");
            for(int i=0;i<nodeList.getLength();i++){
                Node node = nodeList.item(i);
                ColumnMapping columnMapping = createColumnMapping(node);
                mapping.addColumnMapping(columnMapping);
            }
        } catch (ParserException e) {
            throw new XMLTemplateParseException("Parse Exception",e);
        } catch (IOException e) {
            throw new XMLTemplateParseException("Parse Exception",e);
        }
        return mapping;
    }

    private ColumnMapping createColumnMapping(Node node) {
        int id = Integer.parseInt(DOMUtil.getAttribute((Element) node,"id"));
        int startPosition = Integer.parseInt(DOMUtil.getAttribute((Element) node,"startPosition"));
        int endPosition = Integer.parseInt(DOMUtil.getAttribute((Element) node,"endPosition"));
        String justification = DOMUtil.getAttribute((Element) node,"justification");
        String text = DOMUtil.getTextValue(DOMUtil.getChild(node,"text"));
        String filler = DOMUtil.getTextValue(DOMUtil.getChild(node,"filler"));
        ColumnMapping columnMapping = new ColumnMapping(id,startPosition,endPosition,justification,text,filler);
        return columnMapping;
    }
}