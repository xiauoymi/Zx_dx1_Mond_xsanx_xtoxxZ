/*
 Mapping was created on Jan 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Filename:    $RCSfile: Mapping.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:24:54 $
 *
 * @author VRBETHI
 * @version $Revision: 1.3 $
 */
public class Mapping {
    List columnMappingList = new ArrayList();

    public void addColumnMapping(ColumnMapping columnMapping) {
        columnMappingList.add(columnMapping);
    }

    public ColumnMapping getColumnMapping(int index) {
        return (ColumnMapping) columnMappingList.get(index);
    }

    public int getSize() {
        return columnMappingList.size();
    }

    public void sortDescending() {
        Collections.sort(columnMappingList);
    }
}