/*
 Parser was created on Jan 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate;

/**
 * Filename:    $RCSfile: Parser.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-01-31 01:04:47 $
 *
 * @author VRBETHI
 * @version $Revision: 1.3 $
 */
public interface Parser {
    Mapping getMapping(String evaluatedString) throws XMLTemplateParseException;
}