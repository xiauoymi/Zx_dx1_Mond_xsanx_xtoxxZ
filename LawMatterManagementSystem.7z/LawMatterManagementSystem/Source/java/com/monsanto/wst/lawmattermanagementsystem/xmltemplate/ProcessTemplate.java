/*
 ProcessTemplate was created on Feb 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate;

import com.monsanto.wst.lawmattermanagementsystem.exception.DAOException;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.dao.mock.MockInvoiceDataDAO;

import java.util.List;

/**
 * Filename:    $RCSfile: ProcessTemplate.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: bghale $    	 On:	$Date: 2008-09-09 20:30:22 $
 *
 * @author vrbethi
 * @version $Revision: 1.6 $
 */
public class ProcessTemplate {

  //todo Remove this later
    public static void main(String[] args) throws DAOException, DataExceedsColumnLengthException, ServiceException {
        XMLTemplateFactory xmlTemplateFactory = new XMLTemplateFactoryImpl();
        XMLTemplateService service = xmlTemplateFactory.getXMLTemplateFactoryInstance("");
        MockInvoiceDataDAO mockInvoiceDataDAO = new MockInvoiceDataDAO();
        List invoiceRecords = mockInvoiceDataDAO.getInvoiceRecords(false, null, null, null);
        String formattedString = service.getFormattedString(invoiceRecords.get(0));
        System.out.println("formattedString = " + formattedString);
    }
}