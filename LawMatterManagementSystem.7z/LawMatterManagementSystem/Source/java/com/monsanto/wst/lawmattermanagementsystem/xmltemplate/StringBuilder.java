/*
 StringBuilder was created on Jan 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

/**
 * Filename:    $RCSfile: StringBuilder.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-01-31 22:13:09 $
 *
 * @author vrbethi
 * @version $Revision: 1.4 $
 */
public interface StringBuilder {
    StringBuffer buildString(String evaluatedString, Parser parser) throws ServiceException, DataExceedsColumnLengthException;
}