/*
 TemplateFactory was created on Jan 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate;

import com.monsanto.wst.commonutils.template.MessageTemplate;

/**
 * Filename:    $RCSfile: TemplateFactory.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-01-30 23:47:02 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public interface TemplateFactory {
    public MessageTemplate getMessageTemplate();
}