/*
 XMLFileConverter was created on Jan 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate;

import com.monsanto.XMLUtil.ParserException;

/**
 * Filename:    $RCSfile: XMLFileConverter.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-01-31 21:37:32 $
 *
 * @author VRBETHI
 * @version $Revision: 1.5 $
 */
public class XMLFileConverter {
    private String filePath;
    private Parser xmlParser;

    public XMLFileConverter(String filePath, Parser xmlParser) {
        this.filePath = filePath;
        this.xmlParser = xmlParser;
    }

    public String convertXML(String s) throws ParserException, DataExceedsColumnLengthException, XMLTemplateParseException {
        Mapping mapping = xmlParser.getMapping(s);
        StringBuffer stringBuffer = new StringBuffer();
        for(int i=0;i<mapping.getSize();i++){
            ColumnMapping columnMapping = mapping.getColumnMapping(i);
            stringBuffer.append(columnMapping.getFormattedString());
        }
        return stringBuffer.toString();
    }

}