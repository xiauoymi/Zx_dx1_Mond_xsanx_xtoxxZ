/*
 XMLTemplateParseException was created on Jan 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate;



/**
 * Filename:    $RCSfile: XMLTemplateParseException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:24:54 $
 *
 * @author vrbethi
 * @version $Revision: 1.3 $
 */
public class XMLTemplateParseException extends Exception{

    public XMLTemplateParseException(String message, Exception e) {
        super(message,e);
    }
}