/*
XMLTemplateServiceImpl was created on Jan 29, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate;

import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;

/**
 * Filename:    $RCSfile: XMLTemplateServiceImpl.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-03-08 17:14:18 $
 *
 * @author VRBETHI
 * @version $Revision: 1.16 $
 */
public class XMLTemplateServiceImpl implements XMLTemplateService {
  private TemplateFactory templateFactory;
  private StringBuilder stringBuilder;
  private Parser parser;

  public XMLTemplateServiceImpl(TemplateFactory templateFactory, StringBuilder stringBuilder, Parser parser) {
    this.templateFactory = templateFactory;
    this.stringBuilder = stringBuilder;
    this.parser = parser;
  }

  public String getFormattedString(Object object) throws ServiceException, DataExceedsColumnLengthException {
    String evaluatedString = templateFactory.getMessageTemplate().getFormattedMessage(object);
    StringBuffer stringBuffer = stringBuilder.buildString(evaluatedString, parser);
    return stringBuffer.toString();
  }

}