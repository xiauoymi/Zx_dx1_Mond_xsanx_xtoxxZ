/*
 Employee was created on Jan 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock;

/**
 * Filename:    $RCSfile: MockEmployee.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-01-31 21:49:49 $
 *
 * @author VRBETHI
 * @version $Revision: 1.3 $
 */
public class MockEmployee{
    private String employeeName;

    public MockEmployee(String name) {
        this.employeeName = name;
    }

    public void setName(String name) {
        this.employeeName = name;
    }

    public String getName() {
        return employeeName;
    }
}