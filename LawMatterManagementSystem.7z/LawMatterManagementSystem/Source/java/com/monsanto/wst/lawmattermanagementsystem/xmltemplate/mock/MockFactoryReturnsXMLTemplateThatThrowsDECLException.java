/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock;

import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateFactory;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateService;

/**
 * Filename:    $RCSfile: MockFactoryReturnsXMLTemplateThatThrowsDECLException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-07 01:48:29 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class MockFactoryReturnsXMLTemplateThatThrowsDECLException implements XMLTemplateFactory {

  public XMLTemplateService getXMLTemplateFactoryInstance(String filePath) {
    return new MockXMLTemplateServiceThrowsDECLException();
  }
}