/*
 MockParserFactory was created on Jan 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock;

import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.Parser;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.ParserFactory;

/**
 * Filename:    $RCSfile: MockParserFactory.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class MockParserFactory implements ParserFactory {
    public Parser getParser() {
        return null;
    }
}