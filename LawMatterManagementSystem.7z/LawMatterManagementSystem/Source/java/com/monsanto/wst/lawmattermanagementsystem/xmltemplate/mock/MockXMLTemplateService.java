/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.*;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateService;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockXMLTemplateService.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-05 07:10:36 $
 *
 * @author rdesai2
 * @version $Revision: 1.15 $
 */
public class MockXMLTemplateService implements XMLTemplateService {

  List requestList = new ArrayList();
  String xmlTemplateName;

  public MockXMLTemplateService(String xmlTemplateName) {
    this.xmlTemplateName = xmlTemplateName;
  }

  public String getFormattedString(Object object) {
    requestList.add(xmlTemplateName);
    if(LMMSConstants.XML_TEMPLATE_INVOICE_FILE_HEADER.equalsIgnoreCase(xmlTemplateName)
      && object != null && object instanceof InvoiceFileHeaderVariable) {
      return "***File-Header, QueueGroupName: " + ((InvoiceFileHeaderVariable)object).getQueueGroupName() + "***";
    }
    if(LMMSConstants.XML_TEMPLATE_INVOICE_RECORD_HEADER.equalsIgnoreCase(xmlTemplateName)
      && object != null && object instanceof InvoiceRecordHeaderVariable) {
      return "***Record-Header, " +
        "InvoiceSummaryDate: " + ((InvoiceRecordHeaderVariable)object).getDocumentDate() + ", " +
        "CompanyCode: "+ ((InvoiceRecordHeaderVariable)object).getCompanyCode() + ", " +
        "Invoice#: " + ((InvoiceRecordHeaderVariable)object).getInvoiceNumber() + ", " +
        "PractiseArea: " + ((InvoiceRecordHeaderVariable)object).getPracticeArea();
    }
    if(LMMSConstants.XML_TEMPLATE_INVOICE_RECORD.equalsIgnoreCase(xmlTemplateName)
      && object != null && object instanceof InvoiceRecordVariable) {
      return "***RecordType: " + ((InvoiceRecordVariable)object).getPostingKey() + ", " +
        "TaxCode: "+ ((InvoiceRecordVariable)object).getTaxCode() + ", " +
        "AccountOrMatchCode: " + ((InvoiceRecordVariable)object).getAccountOrMatchCode();
    }
    if(LMMSConstants.XML_TEMPLATE_REPORT_HEADER.equalsIgnoreCase(xmlTemplateName)
      && object != null && object instanceof ReportHeaderVariable) {
      return ((ReportHeaderVariable)object).getReportName();
    }
    if(LMMSConstants.XML_TEMPLATE_SUMMARY_REPORT_RECORD.equalsIgnoreCase(xmlTemplateName)
      && object != null && object instanceof SummaryReportRecordVariable) {
      return "***Summary Record: " + ((SummaryReportRecordVariable)object).getVendorName() + " - " + ((SummaryReportRecordVariable)object).getInvoiceAmount();
    }
    if(LMMSConstants.XML_TEMPLATE_SUMMARY_FOOTER.equalsIgnoreCase(xmlTemplateName)
      && object != null && object instanceof SummaryReportFooterVariable) {
      return ((SummaryReportFooterVariable)object).getSummaryFieldName()
        + " "
        + ((SummaryReportFooterVariable)object).getSummaryFieldSeperator()
        + " "
        + ((SummaryReportFooterVariable)object).getSummaryFieldValue();
    }
    if(LMMSConstants.XML_TEMPLATE_REJECTION_REPORT_RECORD.equalsIgnoreCase(xmlTemplateName)
      && object != null && object instanceof RejectionReportRecordVariable) {
      return "***Rejection Record: " + ((RejectionReportRecordVariable)object).getInvoiceNumber() + " - " + ((RejectionReportRecordVariable)object).getErrorMessage();
    }
    return "";
  }

  public String getRecentRequestedNameOfXMLTemplate() {
    if (requestList.size() > 0) {
      return (String) requestList.get(requestList.size() - 1);
    }
    return null;
  }
}