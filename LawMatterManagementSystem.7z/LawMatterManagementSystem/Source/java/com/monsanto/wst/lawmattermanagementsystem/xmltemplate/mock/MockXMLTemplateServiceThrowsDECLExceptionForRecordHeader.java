/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.InvoiceFileHeaderVariable;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.DataExceedsColumnLengthException;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateService;

/**
 * Filename:    $RCSfile: MockXMLTemplateServiceThrowsDECLExceptionForRecordHeader.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rdesai2 $    	 On:	$Date: 2007-02-07 01:48:29 $
 *
 * @author rdesai2
 * @version $Revision: 1.1 $
 */
public class MockXMLTemplateServiceThrowsDECLExceptionForRecordHeader implements XMLTemplateService {
  private String filePath;

  public MockXMLTemplateServiceThrowsDECLExceptionForRecordHeader(String filePath) {
    this.filePath = filePath;
  }

  public String getFormattedString(Object object) throws ServiceException, DataExceedsColumnLengthException {
    if(LMMSConstants.XML_TEMPLATE_INVOICE_FILE_HEADER.equalsIgnoreCase(filePath)
      && object != null && object instanceof InvoiceFileHeaderVariable) {
      return "***File-Header, QueueGroupName: " + ((InvoiceFileHeaderVariable)object).getQueueGroupName() + "***";
    }
    if(LMMSConstants.XML_TEMPLATE_INVOICE_RECORD_HEADER.equalsIgnoreCase(filePath)) {
      throw new DataExceedsColumnLengthException("Mock DECL Exception for invoice record header.");
    }
    return "";
  }
}