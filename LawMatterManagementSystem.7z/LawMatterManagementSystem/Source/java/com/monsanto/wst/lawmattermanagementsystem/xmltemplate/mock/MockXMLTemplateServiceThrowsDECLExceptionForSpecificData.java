/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock;

import com.monsanto.wst.lawmattermanagementsystem.constant.LMMSConstants;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.invoice.service.templatevariable.*;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.DataExceedsColumnLengthException;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateService;

/**
 * Filename:    $RCSfile: MockXMLTemplateServiceThrowsDECLExceptionForSpecificData.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author rdesai2
 * @version $Revision: 1.3 $
 */
public class MockXMLTemplateServiceThrowsDECLExceptionForSpecificData implements XMLTemplateService {

  //Note: Order is important in this test...

  private String filePath;

  public MockXMLTemplateServiceThrowsDECLExceptionForSpecificData(String filePath) {
    this.filePath = filePath;
  }

  public String getFormattedString(Object object) throws ServiceException, DataExceedsColumnLengthException {
    if(LMMSConstants.XML_TEMPLATE_INVOICE_FILE_HEADER.equalsIgnoreCase(filePath)
            && object != null && object instanceof InvoiceFileHeaderVariable) {
      return "***File-Header, QueueGroupName: " + ((InvoiceFileHeaderVariable)object).getQueueGroupName() + "***";
    }
    if(LMMSConstants.XML_TEMPLATE_INVOICE_RECORD_HEADER.equalsIgnoreCase(filePath)
            && object != null && object instanceof InvoiceRecordHeaderVariable) {
      return "***Record-Header, " +
              "InvoiceSummaryDate: " + ((InvoiceRecordHeaderVariable)object).getDocumentDate() + ", " +
              "CompanyCode: "+ ((InvoiceRecordHeaderVariable)object).getCompanyCode() + ", " +
              "Invoice#: " + ((InvoiceRecordHeaderVariable)object).getInvoiceNumber() + ", " +
              "PractiseArea: " + ((InvoiceRecordHeaderVariable)object).getPracticeArea();
    }
    if(LMMSConstants.XML_TEMPLATE_INVOICE_RECORD.equalsIgnoreCase(filePath)
            && object != null
            && object instanceof InvoiceRecordVariable
            && ((InvoiceRecordVariable)object).getAccountOrMatchCode().equalsIgnoreCase("22222222")) {
      throw new DataExceedsColumnLengthException("Mock DECL Exception for 40/50 invoice record.");
    }
    if(LMMSConstants.XML_TEMPLATE_INVOICE_RECORD.equalsIgnoreCase(filePath)
            && object != null
            && object instanceof InvoiceRecordVariable
            && ((InvoiceRecordVariable)object).getAccountOrMatchCode().equalsIgnoreCase("corp-vendor-1")) {
      throw new DataExceedsColumnLengthException("Mock DECL Exception for 21/31 invoice record.");
    }
    if(LMMSConstants.XML_TEMPLATE_INVOICE_RECORD.equalsIgnoreCase(filePath)
            && object != null && object instanceof InvoiceRecordVariable) {
      return "***RecordType: " + ((InvoiceRecordVariable)object).getPostingKey() + ", " +
              "TaxCode: "+ ((InvoiceRecordVariable)object).getTaxCode() + ", " +
              "AccountOrMatchCode: " + ((InvoiceRecordVariable)object).getAccountOrMatchCode();
    }

    if(LMMSConstants.XML_TEMPLATE_SUMMARY_REPORT_RECORD.equalsIgnoreCase(filePath)
            && object != null
            && object instanceof SummaryReportRecordVariable
            && ((SummaryReportRecordVariable)object).getVendorName().equalsIgnoreCase("Bryan Cave")) {
      throw new DataExceedsColumnLengthException("Mock DECL Exception for summary report record.");
    }

    if(LMMSConstants.XML_TEMPLATE_SUMMARY_FOOTER.equalsIgnoreCase(filePath)
            && object != null
            && object instanceof SummaryReportFooterVariable
            && ((SummaryReportFooterVariable)object).getSummaryFieldValue().equalsIgnoreCase("3")) {
      throw new DataExceedsColumnLengthException("Mock DECL Exception for summary footer for total invoices.");
    }

    if(LMMSConstants.XML_TEMPLATE_SUMMARY_FOOTER.equalsIgnoreCase(filePath)
            && object != null
            && object instanceof SummaryReportFooterVariable
            && ((SummaryReportFooterVariable)object).getSummaryFieldValue().equalsIgnoreCase("1100.50")) {
      throw new DataExceedsColumnLengthException("Mock DECL Exception for summary footer for total invoice amount.");
    }

    if(LMMSConstants.XML_TEMPLATE_REPORT_HEADER.equalsIgnoreCase(filePath)
            && object != null && object instanceof ReportHeaderVariable) {
      return ((ReportHeaderVariable)object).getReportName();
    }
    if(LMMSConstants.XML_TEMPLATE_SUMMARY_REPORT_RECORD.equalsIgnoreCase(filePath)
            && object != null && object instanceof SummaryReportRecordVariable) {
      return "***Summary Record: " + ((SummaryReportRecordVariable)object).getVendorName() + " - " + ((SummaryReportRecordVariable)object).getInvoiceAmount();
    }
    if(LMMSConstants.XML_TEMPLATE_SUMMARY_FOOTER.equalsIgnoreCase(filePath)
            && object != null && object instanceof SummaryReportFooterVariable) {
      return ((SummaryReportFooterVariable)object).getSummaryFieldName()
              + " "
              + ((SummaryReportFooterVariable)object).getSummaryFieldSeperator()
              + " "
              + ((SummaryReportFooterVariable)object).getSummaryFieldValue();
    }

    if(LMMSConstants.XML_TEMPLATE_REJECTION_REPORT_RECORD.equalsIgnoreCase(filePath)
            && object != null
            && object instanceof RejectionReportRecordVariable
            && ((RejectionReportRecordVariable)object).getInvoiceNumber().equalsIgnoreCase("Inv#3")) {
      throw new DataExceedsColumnLengthException("Mock DECL Exception for rejection record.");
    }

    if(LMMSConstants.XML_TEMPLATE_REJECTION_REPORT_RECORD.equalsIgnoreCase(filePath)
            && object != null && object instanceof RejectionReportRecordVariable) {
      return "***Rejection Record: " + ((RejectionReportRecordVariable)object).getInvoiceNumber() + " - " + ((RejectionReportRecordVariable)object).getErrorMessage();
    }


    return "";
  }
}