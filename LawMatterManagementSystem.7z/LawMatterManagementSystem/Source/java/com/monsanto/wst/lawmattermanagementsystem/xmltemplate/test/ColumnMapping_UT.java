/*
ColumnMapping_UT was created on Jan 29, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.test;

import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.ColumnMapping;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.DataExceedsColumnLengthException;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ColumnMapping_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-08 17:07:51 $
 *
 * @author VRBETHI
 * @version $Revision: 1.8 $
 */
public class ColumnMapping_UT extends TestCase{

    public void testGetFormattedColumnMapping_TextSizeAndLeghtTheSame_NoNeedToUseFiller_LeftJustified() throws Exception {
        ColumnMapping columnMapping = new ColumnMapping(1,1,4,"left","text","~");
        String formattedColumnMapping = columnMapping.getFormattedString();
        assertEquals("text",formattedColumnMapping);
    }

    public void testGetFormattedColumnMapping_JustOne() throws Exception {
        ColumnMapping columnMapping = new ColumnMapping(1,1,1,"left","t","~");
        String formattedColumnMapping = columnMapping.getFormattedString();
        assertEquals("t",formattedColumnMapping);
    }

    public void testGetFormattedColumnMapping_TextSizeIsSmallerThanLengtAllowedForColumn_FillerUsed_LeftJustified() throws Exception {
        ColumnMapping columnMapping = new ColumnMapping(1,1,10,"left","text","~");
        String formattedColumnMapping = columnMapping.getFormattedString();
        assertEquals("text~~~~~~",formattedColumnMapping);
    }

    public void testGetFormattedColumnMapping_TextSizeIsSmallerThanLengtAllowedForColumn_FillerUsed_RightJustified() throws Exception {
        ColumnMapping columnMapping = new ColumnMapping(1,1,10,"right","text","~");
        String formattedColumnMapping = columnMapping.getFormattedString();
        assertEquals("~~~~~~text",formattedColumnMapping);
    }

    public void testGetFormattedColumnMapping_TextIsBlank() throws Exception {
        ColumnMapping columnMapping = new ColumnMapping(1,1,10,"right",null,"~");
        String formattedColumnMapping = columnMapping.getFormattedString();
        assertEquals("~~~~~~~~~~",formattedColumnMapping);
    }

    public void testGetFormattedColumnMapping_ColumnValueLargerThanColumnSize_ThrowInvalidDataException() throws Exception {
        try{
            ColumnMapping columnMapping = new ColumnMapping(1,1,4,"right","BigTextString","~");
            columnMapping.getFormattedString();
            fail("Invalid Data Exception Should have been thrown");
        }catch(DataExceedsColumnLengthException ide){
            assertTrue(ide.getMessage().indexOf("Data")>0);
            assertTrue(ide.getMessage().indexOf("index 1")>0);
        }

    }

}