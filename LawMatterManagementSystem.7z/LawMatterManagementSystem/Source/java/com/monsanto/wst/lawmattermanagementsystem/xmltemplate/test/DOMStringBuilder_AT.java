/*
 DOMStringBuilder_AT was created on Jan 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.test;

import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.DOMStringBuilder;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.DomXMLMappingParser;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.StringBuilder;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: DOMStringBuilder_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author vrbethi
 * @version $Revision: 1.4 $
 */
public class DOMStringBuilder_AT extends TestCase{

    String inputString="<columns>\n" +
        "    <column id=\"1\" startPosition=\"1\" endPosition=\"10\" justification=\"left\">\n" +
        "        <text>Ram</text>\n" +
        "        <filler>~</filler>\n" +
        "    </column>\n" +
        "    <column id=\"2\" startPosition=\"11\" endPosition=\"25\" justification=\"right\">\n" +
        "        <text>to</text>\n" +
        "        <filler>@</filler>\n" +
        "    </column>\n" +
        "    <column id=\"3\" startPosition=\"26\" endPosition=\"40\" justification=\"left\">\n" +
        "        <text>build</text>\n" +
        "        <filler> </filler>\n" +
        "    </column>\n" +
        "    <column id=\"4\" startPosition=\"41\" endPosition=\"60\" justification=\"left\">\n" +
        "        <text>a new row</text>\n" +
        "        <filler>~</filler>\n" +
        "    </column>\n" +
        "    <column id=\"5\" startPosition=\"61\" endPosition=\"80\" justification=\"left\">\n" +
        "        <text></text>\n" +
        "        <filler> </filler>\n" +
        "    </column>\n" +
        "</columns>";

    public void testBuildString() throws Exception {
        StringBuilder stringBuilder = new DOMStringBuilder();
        StringBuffer stringBuffer = stringBuilder.buildString(inputString, new DomXMLMappingParser());
        assertEquals("Ram~~~~~~~@@@@@@@@@@@@@tobuild          a new row~~~~~~~~~~~                    ",stringBuffer.toString());
    }
}