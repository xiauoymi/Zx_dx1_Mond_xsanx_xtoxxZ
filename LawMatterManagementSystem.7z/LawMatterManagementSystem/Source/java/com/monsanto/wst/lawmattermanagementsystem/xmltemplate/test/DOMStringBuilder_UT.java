/*
DOMStringBuilder_UT was created on Jan 30, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.test;

import com.monsanto.XMLUtil.ParserException;
import com.monsanto.wst.lawmattermanagementsystem.exception.ServiceException;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.*;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.StringBuilder;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: DOMStringBuilder_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rrmall $    	 On:	$Date: 2007-04-23 20:35:12 $
 *
 * @author vrbethi
 * @version $Revision: 1.8 $
 */
public class DOMStringBuilder_UT extends TestCase {

  public void testBuildStringWithNoEntry() throws Exception {
    StringBuilder stringBuilder = new DOMStringBuilder();
    Parser parser = new MockDomXMLMappingParserWithNoEntry();
    StringBuffer stringBuffer = stringBuilder.buildString("<test>value</test>", parser);
    assertEquals("", stringBuffer.toString());
  }

  public void testBuildStringWithOneEntry() throws Exception {
    StringBuilder stringBuilder = new DOMStringBuilder();
    Parser parser = new MockDomXMLMappingParserWithOneEntry();
    StringBuffer stringBuffer = stringBuilder.buildString("<test>value</test>", parser);
    assertEquals("text~~~~~~", stringBuffer.toString());
  }

  public void testBuildStringWithTwoEntry() throws Exception {
    StringBuilder stringBuilder = new DOMStringBuilder();
    Parser parser = new MockDomXMLMappingParserWithTwoEntry();
    StringBuffer stringBuffer = stringBuilder.buildString("<test>value</test>", parser);
    assertEquals("text~~~~~~text~~~~~~", stringBuffer.toString());
  }

  public void testBuildStringWithTwoEntriesButWhatifAddedinWrongOrder() throws Exception {
    StringBuilder stringBuilder = new DOMStringBuilder();
    Parser parser = new MockDomXMLMappingParserWithTwoEntryDifferentOrder();
    StringBuffer stringBuffer = stringBuilder.buildString("<test>value</test>", parser);
    assertEquals("first~~~~~second~~~~", stringBuffer.toString());
  }

  public void testBuildStringThrowsExceptionServiceExceptionDuetoParseError() throws Exception {
    try {
      StringBuilder stringBuilder = new DOMStringBuilder();
      Parser parser = new MockDomXMLMappingParserThrowsXMLTemplateParseException();
      stringBuilder.buildString("<test>value</test>", parser);
      fail("Exception should have been thrown");
    } catch (ServiceException xte) {
      System.out.println("Expected path, xte.getMessage() = " + xte.getMessage());
    }
  }

  class MockDomXMLMappingParserWithNoEntry implements Parser {

    public Mapping getMapping(String evaluatedString) throws XMLTemplateParseException {
      return new Mapping();
    }
  }

  class MockDomXMLMappingParserWithOneEntry implements Parser {

    public Mapping getMapping(String evaluatedString) throws XMLTemplateParseException {
      Mapping mapping = new Mapping();
      mapping.addColumnMapping(new ColumnMapping(1, 1, 10, "left", "text", "~"));
      return mapping;
    }
  }

  class MockDomXMLMappingParserWithTwoEntry implements Parser {

    public Mapping getMapping(String evaluatedString) throws XMLTemplateParseException {
      Mapping mapping = new Mapping();
      mapping.addColumnMapping(new ColumnMapping(1, 1, 10, "left", "text", "~"));
      mapping.addColumnMapping(new ColumnMapping(2, 11, 20, "left", "text", "~"));
      return mapping;
    }
  }

  class MockDomXMLMappingParserWithTwoEntryDifferentOrder implements Parser {

    public Mapping getMapping(String evaluatedString) throws XMLTemplateParseException {
      Mapping mapping = new Mapping();
      mapping.addColumnMapping(new ColumnMapping(2, 11, 20, "left", "second", "~"));
      mapping.addColumnMapping(new ColumnMapping(1, 1, 10, "left", "first", "~"));
      return mapping;
    }
  }

  class MockDomXMLMappingParserThrowsXMLTemplateParseException implements Parser {

    public Mapping getMapping(String evaluatedString) throws XMLTemplateParseException {
      throw new XMLTemplateParseException("", new ParserException(""));
    }
  }

}