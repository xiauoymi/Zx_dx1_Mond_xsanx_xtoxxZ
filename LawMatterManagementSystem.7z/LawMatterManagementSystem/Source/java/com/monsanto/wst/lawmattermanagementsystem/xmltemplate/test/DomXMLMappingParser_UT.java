/*
DomXMLMappingParser was created on Jan 29, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.test;

import com.monsanto.Util.FileUtil;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.*;
import junit.framework.TestCase;

import java.io.File;

/**
 * Filename:    $RCSfile: DomXMLMappingParser_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-01-31 21:37:32 $
 *
 * @author VRBETHI
 * @version $Revision: 1.6 $
 */
public class DomXMLMappingParser_UT extends TestCase {
    public DomXMLMappingParser_UT(String name) {
        super(name);
    }

    public void testParseXMLToCreateMapping() throws Exception {
        String fileString = FileUtil.readFileToString(new File("com/monsanto/wst/lawmattermanagementsystem/xmltemplate/test/templatetoconvert.xml"));
        Parser parser = new DomXMLMappingParser();
        Mapping mapping = parser.getMapping(fileString);
        ColumnMapping columnMapping = mapping.getColumnMapping(0);
        assertEquals(4,mapping.getSize());
        columnMapping.getIndex();
        assertEquals(1,columnMapping.getIndex());
        assertEquals(1,columnMapping.getStartIndex());
        assertEquals(10,columnMapping.getEndIndex());
        assertEquals("left",columnMapping.getJustification());
        assertEquals("${name}",columnMapping.getText());
        assertEquals("~",columnMapping.getFiller());
    }

    //todo look into this test
    public void testParseXMLToCreateMapping_throwsXMLTemplateParseException() throws Exception {
        Parser parser = new DomXMLMappingParser();
        try{
            parser.getMapping("com/monsanto/wst/lawmattermanagementsystem/xmltemplate/test/parseexception.xml");
            fail("Exception should have been thrown");
        }catch(XMLTemplateParseException te){
            assertEquals("Parse Exception",te.getMessage());
        }
    }

//    public void testParseXMLToCreateMapping_throwsIOExceptionXMLTemplateParseException() throws Exception {
//        Parser parser = new DomXMLMappingParser();
//        try{
//            parser.getMapping(null);
//            fail("Exception should have been thrown");
//        }catch(XMLTemplateParseException te){
//            assertEquals("Parse Exception",te.getMessage());
//        }
//    }

}