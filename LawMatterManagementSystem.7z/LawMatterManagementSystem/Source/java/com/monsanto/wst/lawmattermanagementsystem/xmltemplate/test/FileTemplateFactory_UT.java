/*
FileTemplateFactory was created on Jan 30, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.test;

import com.monsanto.wst.commonutils.template.FileMessageTemplate;
import com.monsanto.wst.commonutils.template.MessageTemplate;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.FileTemplateFactory;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.TemplateFactory;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: FileTemplateFactory_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author vrbethi
 * @version $Revision: 1.2 $
 */
public class FileTemplateFactory_UT extends TestCase{

    public void testCreateFileTemplateFactory() throws Exception {
        TemplateFactory templateFactory = new FileTemplateFactory("com/monsanto/wst/lawmattermanagementsystem/xmltemplate/test/templatetoconvert.xml");
        MessageTemplate messageTemplate = templateFactory.getMessageTemplate();
        assertTrue(messageTemplate instanceof FileMessageTemplate);
    }
}