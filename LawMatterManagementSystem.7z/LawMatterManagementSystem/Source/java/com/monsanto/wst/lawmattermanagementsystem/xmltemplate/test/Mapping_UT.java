/*
Mapping_UT was created on Jan 29, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.test;

import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.ColumnMapping;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.Mapping;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: Mapping_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author VRBETHI
 * @version $Revision: 1.3 $
 */
public class Mapping_UT extends TestCase {
    public Mapping_UT(String name) {
        super(name);
    }

    public void testCreateMappingObject() throws Exception {
        Mapping mapping = new Mapping();
        mapping.addColumnMapping(new ColumnMapping(1,1,10,"left","text","~"));
        ColumnMapping columnMapping = mapping.getColumnMapping(0);
        int index = columnMapping.getIndex();
        int startIndex = columnMapping.getStartIndex();
        int endIndex = columnMapping.getEndIndex();
        String justification = columnMapping.getJustification();
        String text = columnMapping.getText();
        String filler = columnMapping.getFiller();

        assertEquals(1,index);
        assertEquals(1,startIndex);
        assertEquals(10,endIndex);
        assertEquals("left",justification);
        assertEquals("text",text);
        assertEquals("~",filler);

        assertEquals(1,mapping.getSize());
    }

    public void testCreateMappingObjectInCoorectOrder() throws Exception {
        Mapping mapping = new Mapping();
        mapping.addColumnMapping(new ColumnMapping(2,1,10,"left","second","~"));
        mapping.addColumnMapping(new ColumnMapping(1,1,10,"left","first","~"));
        mapping.sortDescending();
        ColumnMapping columnMapping = mapping.getColumnMapping(0);
        int index = columnMapping.getIndex();
        int startIndex = columnMapping.getStartIndex();
        int endIndex = columnMapping.getEndIndex();
        String justification = columnMapping.getJustification();
        String text = columnMapping.getText();
        String filler = columnMapping.getFiller();
        assertEquals(1,index);
        assertEquals(1,startIndex);
        assertEquals(10,endIndex);
        assertEquals("left",justification);
        assertEquals("first",text);
        assertEquals("~",filler);
    }


}