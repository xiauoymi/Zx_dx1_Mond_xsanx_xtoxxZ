/*
XMLFileConverter was created on Jan 29, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.test;

import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.ColumnMapping;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.Mapping;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.Parser;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLFileConverter;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: XMLFileConverter_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author VRBETHI
 * @version $Revision: 1.4 $
 */
public class XMLFileConverter_UT extends TestCase {
    public XMLFileConverter_UT(String name) {
        super(name);
    }

    public void testConvertXML() throws Exception {
        Parser parser = new MockXMLParser();
        XMLFileConverter converter =
            new XMLFileConverter("com/monsanto/wst/lawmattermanagementsystem/xmltemplate/test/templatetoconvert.xml", parser);
        String convertedXML = converter.convertXML("");
        assertTrue(((MockXMLParser)parser).isCalled());
        assertEquals("first~~~~~second~~~~third~~~~~~~~~fourth",convertedXML);

    }

    public void testConvertXML_NoEntriesInXML() throws Exception {
        Parser parser = new MockXMLParserNoEntries();
        XMLFileConverter converter =
            new XMLFileConverter("com/monsanto/wst/lawmattermanagementsystem/xmltemplate/test/templatetoconvert.xml", parser);
        String convertedXML = converter.convertXML("");
        assertEquals("",convertedXML);

    }

    class MockXMLParser implements Parser{
        boolean called = false;

        public boolean isCalled() {
            return called;
        }

        public Mapping getMapping(String evaluatedString) {
            called=true;
            Mapping mapping = new Mapping();
            ColumnMapping columnMapping;

            columnMapping = new ColumnMapping(1,1,10,"left","first","~");
            mapping.addColumnMapping(columnMapping);
            columnMapping = new ColumnMapping(2,11,20,"left","second","~");
            mapping.addColumnMapping(columnMapping);
            columnMapping = new ColumnMapping(3,21,30,"left","third","~");
            mapping.addColumnMapping(columnMapping);
            columnMapping = new ColumnMapping(4,31,40,"right","fourth","~");
            mapping.addColumnMapping(columnMapping);

            return mapping;
        }
    }

    class MockXMLParserNoEntries implements Parser{

        public Mapping getMapping(String evaluatedString) {
            return new Mapping();
        }
    }
}