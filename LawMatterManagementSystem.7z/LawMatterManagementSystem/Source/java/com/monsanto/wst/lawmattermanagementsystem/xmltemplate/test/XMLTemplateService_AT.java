/*
XMLTemplateSercive_UT was created on Jan 29, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.test;

import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateFactory;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateFactoryImpl;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.XMLTemplateService;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock.MockEmployee;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: XMLTemplateService_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: vrbethi $    	 On:	$Date: 2007-02-13 22:25:02 $
 *
 * @author VRBETHI
 * @version $Revision: 1.7 $
 */
public class XMLTemplateService_AT extends TestCase {

    public XMLTemplateService_AT(String name) {
        super(name);
    }

    //todo rename test
    public void testGetFormattedStringWithFactory() throws Exception {
        String filePath = "com/monsanto/wst/lawmattermanagementsystem/xmltemplate/test/templatetoconvert.xml";
        XMLTemplateFactory xmlTemplateFactory = new XMLTemplateFactoryImpl();
        XMLTemplateService service = xmlTemplateFactory.getXMLTemplateFactoryInstance(filePath);
        MockEmployee employee = new MockEmployee("Ram");
        String formattedString = service.getFormattedString(employee);
        assertEquals("Ram~~~~~~~@@@@@@@@@@@@@tobuild          a new row~~~~~~~~~~~",formattedString.trim());
    }
}