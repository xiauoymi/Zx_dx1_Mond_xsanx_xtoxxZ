/*
XMLTemplateSercive_UT was created on Jan 29, 2007 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.wst.lawmattermanagementsystem.xmltemplate.test;

import com.monsanto.wst.commonutils.template.MessageTemplate;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.*;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.StringBuilder;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock.MockEmployee;
import com.monsanto.wst.lawmattermanagementsystem.xmltemplate.mock.MockParserFactory;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: XMLTemplateService_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rrmall $    	 On:	$Date: 2007-04-23 20:35:12 $
 *
 * @author VRBETHI
 * @version $Revision: 1.10 $
 */
public class XMLTemplateService_UT extends TestCase {

    public XMLTemplateService_UT(String name) {
        super(name);
    }

    public void testCreateTemplateService() throws Exception {
        TemplateFactory templateFactory = new MockFileTemplateFactory("");
        StringBuilder stringBuilder = new MockDOMStringBuilder();
        ParserFactory parserFactory = new MockParserFactory();
        Parser parser = parserFactory.getParser();
        XMLTemplateService service = new XMLTemplateServiceImpl(templateFactory,stringBuilder,parser);
        MockEmployee employee = new MockEmployee("Ram");
        String formattedString = service.getFormattedString(employee);
        assertEquals("this is a test",formattedString.trim());
    }

    class MockFileTemplateFactory implements TemplateFactory{
        public MockFileTemplateFactory(String filePath) {
        }

        public MessageTemplate getMessageTemplate() {
            return new MockMessageTemplate();
        }
    }

    class MockMessageTemplate implements MessageTemplate{

        public String getFormattedMessage(Object object) {
            return "test";
        }
    }

    class MockDOMStringBuilder implements StringBuilder{

        public StringBuffer buildString(String evaluatedString, Parser parser) {
            if(evaluatedString.equalsIgnoreCase("test")){
                return new StringBuffer("this is a test");
            }else{
                return new StringBuffer();
            }
        }
    }
}