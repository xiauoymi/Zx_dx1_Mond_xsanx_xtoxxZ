package com.monsanto.test.core.repository;

import com.monsanto.test.core.domain.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface UserRepository extends CrudRepository<User, Long> {

	User findByUserName(String userName);

	List<User> findByLastName(String lastName);

	@Query("select u from User u where u.firstName = ?")
	List<User> findByFirstName(String firstName);

}
