package com.monsanto.test.core.repository;

import com.monsanto.test.core.domain.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: BSBUON
 * Date: 16/01/14
 * Time: 10:22
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/simple-repository-context_test.xml")
public class JpaUserRepository_UT {


    @Autowired
    private UserRepository userRepository;


    @Test
    public void findSavedUserById() {

        User persisted = new User();
        persisted.setId(1L);
        persisted.setUserName("foobar");
        persisted.setFirstName("firstname");
        persisted.setLastName("lastname");

        persisted = userRepository.save(persisted);

        User founded = userRepository.findOne(persisted.getId());

        assertEquals(persisted, founded);
    }
}
