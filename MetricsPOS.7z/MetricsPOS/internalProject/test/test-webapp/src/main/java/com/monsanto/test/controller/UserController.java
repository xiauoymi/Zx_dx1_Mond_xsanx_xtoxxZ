package com.monsanto.test.controller;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.test.core.domain.User;
import com.monsanto.test.core.repository.UserRepository;
import com.monsanto.test.vo.UserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: BSBUON
 * Date: 16/01/14
 * Time: 11:54
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    /**
     * find all Users
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<UserVO> findAll(){
        Function<User,UserVO> function = new Function<User,UserVO>(){
            @Override
            public UserVO apply(User user) {
                return new UserVO(user);
            }
        };

        return Lists.transform((List<User>) userRepository.findAll(),function);
    }

    /**
     * save or update User
     * @param user
     * @return
     */
    @RequestMapping(value="/{id}", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public void save(@RequestBody UserVO user){
        if(user == null ){
            throw new RuntimeException("USER NULL");
        }
        userRepository.save(user.getUser());
    }

    /**
     * delete user for id
     * @param id
     * @return
     */
    @RequestMapping(value="/{id}", method = RequestMethod.DELETE, produces = "application/json")
    @ResponseBody
    public void delete(@PathVariable Long id) throws RuntimeException{
        User user = userRepository.findOne(id);
        if(user==null){
            throw new RuntimeException("USER DONT EXISTS");
        }

        userRepository.delete(user);
    }

    /**
     * find User by id
     * @param id
     * @return
     */
    @RequestMapping(value="/{id}", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public UserVO findById(@PathVariable Long id){
        User user = userRepository.findOne(id);
        return new UserVO(user);
    }
}
