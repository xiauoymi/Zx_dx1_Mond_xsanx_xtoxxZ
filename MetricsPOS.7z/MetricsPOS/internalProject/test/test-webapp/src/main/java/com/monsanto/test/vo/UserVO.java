package com.monsanto.test.vo;

import com.monsanto.test.core.domain.User;

import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: BSBUON
 * Date: 28/01/14
 * Time: 11:28
 * To change this template use File | Settings | File Templates.
 */
public class UserVO implements Serializable{

    private Long id;
    private String userName;
    private String firstName;
    private String lastName;

    public UserVO(){

    }

    public UserVO(User user){
        this.id = user.getId();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.userName = user.getUserName();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public User getUser(){
        User user = new User();
        user.setId(this.getId());
        user.setUserName(this.getUserName());
        user.setFirstName(this.getFirstName());
        user.setLastName(this.getLastName());
        return user;
    }
}
