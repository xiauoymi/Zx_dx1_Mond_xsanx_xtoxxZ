'use strict';
var app = angular.module('app',['ngRoute', 'ngResource']);

app.config(function ($routeProvider, $locationProvider) {
        $routeProvider
            .when('/', {
                redirectTo: ''
            })
            .when('/user/list', {
                templateUrl: 'user/list.jsp',
                controller: 'userController'
            })
            .otherwise({
                template: '<p>Invalid URL !!</p>',
                controller: "URL Inválida."
            });

        $locationProvider.html5Mode(false).hashPrefix('');
    });

app.controller('mainController', function($scope){
    $scope.version = '0.0.1'
});
