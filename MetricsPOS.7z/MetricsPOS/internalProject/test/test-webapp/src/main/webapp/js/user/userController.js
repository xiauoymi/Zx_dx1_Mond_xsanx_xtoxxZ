app.controller('userController',['userService','$scope',
    function(userService, $scope){

        $scope.current = {};
        $scope.users = {};

        $scope.init = function(){
            $scope.users = userService.query(function(data){
                console.log('founded all.');
                $scope.current = {};
                $scope.users = data;
            });
        }

        $scope.init();

        $scope.save = function(){
            console.log($scope.current);
            $scope.current.id = $scope.current.id ? $scope.current.id : 0;
            userService.save($scope.current, function(response){
                console.log('saved.');
                $scope.current = {};
                $scope.init();
            });
        }

        $scope.delete = function(id){
            userService.delete({id:id}, function(response){
                console.log('deleted.');
                $scope.init();
            });
        }

        $scope.findById = function(id){
            $scope.current = userService.findOne({id:id},function(data){
                console.log('founded.');
                $scope.current = {};
                $scope.current.id  = data.id;
                $scope.current.firstName = data.firstName;
                $scope.current.userName = data.userName;
                $scope.current.lastName = data.lastName;
            });
        }
    }
]);