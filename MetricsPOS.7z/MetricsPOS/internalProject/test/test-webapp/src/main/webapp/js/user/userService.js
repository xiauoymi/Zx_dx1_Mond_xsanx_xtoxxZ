app.factory('userService', ['$resource',
    function ($resource) {
        return $resource('../app/user/:id',{id : '@id'},
            { 'findOne': { method: 'GET', params : {id : '@id'}}, isArray:false },
            { 'delete' : { method: 'DELETE', params : {id : '@id'}}, isArray: false },
            { 'save' : {method: 'POST', params : {id : '@id'}}, isArray: false }
        );
    }
]);
