package com.monsanto.metricspos.batch.jobs;

import com.monsanto.metricspos.core.DataLoader;
import com.monsanto.metricspos.core.MetricsApplication;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * This is a Job that Loads the structural data when it's scheduled, then it loads
 * the data of the tables that are scheduled and lastly it computes all the metric
 * scores.
 *
 * User: PPERA
 */
public class CampaignDataLoadQuartzJob implements Job {

    private DataLoader dataLoader;
    private MetricsApplication metricsApplication;

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        init(jobExecutionContext);
        this.dataLoader.executeBatchLoad();
        this.metricsApplication.executeBatchMetricScoreCompute();
    }

    /**
     * This is required to bind the properties configured in the bean with the instance attributes
     *
     * @param jobExecutionContext in which the job will execute
     */
    private void init(JobExecutionContext jobExecutionContext) {
        this.dataLoader = (DataLoader) jobExecutionContext.getJobDetail().getJobDataMap().get("dataLoader");
        this.metricsApplication = (MetricsApplication) jobExecutionContext.getJobDetail().getJobDataMap().get("metricsApplication");
    }
}
