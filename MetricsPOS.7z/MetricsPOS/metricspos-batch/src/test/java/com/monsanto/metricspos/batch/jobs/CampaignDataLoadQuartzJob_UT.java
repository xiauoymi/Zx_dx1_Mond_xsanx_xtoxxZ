package com.monsanto.metricspos.batch.jobs;

import com.monsanto.metricspos.core.DataLoader;
import com.monsanto.metricspos.core.MetricsApplication;
import org.junit.Before;
import org.junit.Test;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class CampaignDataLoadQuartzJob_UT {
    private CampaignDataLoadQuartzJob campaignDataLoadQuartzJob;
    private DataLoader dataLoader;
    private JobExecutionContext jobExecutionContext;
    private JobDataMap jobDataMap;

    @Before
    public void setUp() {
        this.dataLoader = mock(DataLoader.class);
        MetricsApplication metricsApplication = mock(MetricsApplication.class);
        this.campaignDataLoadQuartzJob = new CampaignDataLoadQuartzJob();

        this.jobExecutionContext = mock(JobExecutionContext.class);
        JobDetail jobDetail = mock(JobDetail.class);
        this.jobDataMap = mock(JobDataMap.class);
        when(this.jobExecutionContext.getJobDetail()).thenReturn(jobDetail);
        when(jobDetail.getJobDataMap()).thenReturn(this.jobDataMap);
        when(this.jobDataMap.get("dataLoader")).thenReturn(this.dataLoader);
        when(this.jobDataMap.get("metricsApplication")).thenReturn(metricsApplication);
    }

    @Test
    public void testExecuteCallsDataLoaderToLoadServiceCentersForCampaignOneAndTwo_WhenExecutingJobsForCampaignsOneAndTwoBothScheduled() throws JobExecutionException {
        this.campaignDataLoadQuartzJob.execute(jobExecutionContext);
        verify(this.jobDataMap, times(1)).get("dataLoader");
    }

    @Test
    public void testExecuteCallsDataLoaderToLoadServiceCentersForCampaignTwo_WhenExecutingJobsForCampaignsTwoAndThreeAndThreeIsNotScheduled() throws JobExecutionException {
        this.campaignDataLoadQuartzJob.execute(jobExecutionContext);
        verify(this.dataLoader, times(1)).executeBatchLoad();
    }
}
