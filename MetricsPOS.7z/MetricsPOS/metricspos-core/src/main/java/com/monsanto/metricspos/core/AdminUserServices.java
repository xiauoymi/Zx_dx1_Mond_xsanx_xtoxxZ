package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.security.AdminUser;

import java.util.List;

/**
 * Admin user CRUD operations
 *
 * User: PPERA
 */
public interface AdminUserServices {
    /**
     * Finds an admin user by username
     *
     * @param userName ussually the name of the user in the domain
     * @return an admin user
     */
    AdminUser findAdminUserByUserName(String userName);

    /**
     * Lists all the admin users in the application
     * @return The list of admin users
     */
    List<AdminUser> listAdminUsers();

    /**
     * Creates a new admin user
     *
     * @param adminUser
     * @return the new admin user
     */
    AdminUser newAdminUser(AdminUser adminUser);

    /**
     * Finds an admin user with a given Id
     *
     * @param adminUserId
     * @return the matching admin user
     */
    AdminUser findAdminUserById(int adminUserId);

    /**
     * Removes an admin user from the application
     *
     * @param adminUser to delete
     */
    void deleteAdminUser(AdminUser adminUser);
}
