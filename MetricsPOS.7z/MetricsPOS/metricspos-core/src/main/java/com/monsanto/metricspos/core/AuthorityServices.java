package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.security.Authority;

import java.util.Collection;
import java.util.List;

/**
 * Authorities CRUD operations
 * <p/>
 * User: PPERA
 */
public interface AuthorityServices {
    /**
     * Finds an authority by it's id
     *
     * @param authorityId of the authority
     * @return the authority
     */
    Authority findAuthorityById(Integer authorityId);

    /**
     * Lists all the possible authorities
     *
     * @return all the authorities of the apllication
     */
    List<Authority> listAuthorities();

    /**
     * finds the role names of all the authorities
     *
     * @return all the role names
     */
    Collection<String> findAllRoleNames();
}
