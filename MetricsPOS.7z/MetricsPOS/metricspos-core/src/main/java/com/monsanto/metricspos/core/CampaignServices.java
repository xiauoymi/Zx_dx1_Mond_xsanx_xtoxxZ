package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.application.vo.CampaignVO;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.CampaignParameter;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.util.List;
import java.util.Map;

/**
 * The CampaignServices object represents the application services to manage campaigns.
 * It's the entry point for all services that do not belong to a specific
 * domain instance.
 *
 * @author CAFAU
 */
public interface CampaignServices {
    /**
     * Lists all the campaigns in the application
     *
     * @return all the campaigns
     */
    public List<Campaign> listAllCampaigns();

    /**
     * Finds a campaign with a given Id
     *
     * @param campaignId to be found
     * @return the campaign with that id
     */
    public Campaign findCampaignById(int campaignId);

    /**
     * Creates a new campaign from the input data
     *
     * @param campaignVO with input data
     * @return the new campaign
     */
    Campaign newCampaign(CampaignVO campaignVO);

    /**
     * Finds a service center of a campaign
     *
     * @param campaign of the service center
     * @param cuit     of the service center
     * @return the service center
     */
    public ServiceCenter findServiceCenterByCampaignIdAndCuit(Campaign campaign, String cuit);

    /**
     * Removes a campaign from the application
     *
     * @param campaign to remove
     */
    public void removeCampaign(Campaign campaign);

    /**
     * Updates a campaign with provided data
     *
     * @param campaign   to be updated
     * @param campaignVO data to use for update
     * @return the updated campaign
     */
    public Campaign updateCampaign(Campaign campaign, CampaignVO campaignVO);

    /**
     * Finds an application parameter
     *
     * @param id of the parameter
     * @return the parameter with that id
     */
    public CampaignParameter findParameterById(int id);

    /**
     * Updates a parameter with input data
     *
     * @param existing the entity to update
     * @param modified the parameter with the updated data
     * @return the updated entity
     */
    public CampaignParameter updateParameter(CampaignParameter existing, CampaignParameter modified);

    /**
     * Finds a page of parameters
     *
     * @param page      the page to be found
     * @param rows      the length of each page
     * @param sort      the property to sort
     * @param direction the direction of the sort
     * @param filter    A map with the properties and the required values of each property to filter
     * @return The parameters in the requested page
     */
    public List<CampaignParameter> getParameters(int page, int rows, String sort, String direction, Map<String, Object> filter);

    /**
     * A count of the parameters matching the filter
     *
     * @param filter A map with the properties and the required values of each property to filter
     * @return the amount of matching parameters
     */
    public long getTotalParametersCount(Map<String, Object> filter);

    /**
     * Finds a parameter by it's key
     *
     * @param name the key of the parameter
     * @return the parameter matching that key
     */
    public CampaignParameter findParameterByName(String name);

    List<Campaign> listAllCampaignsForBatch();
}
