package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryNode;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.util.Collection;

/**
 * Implementers allows to compute the scores for a Matric
 *
 * @author cafau
 */
public interface ComputeManager {

    /**
     * Compute the scores for the given metric.
     * Only outdated scores will be calculated. Scores that are up to date are not
     * recalculated.
     *
     * @param metric to metric to compute its scores
     * @return the number of scores calculated
     */
    long compute(Metric metric);

    /**
     * Compute the scores for the given metric and service center.
     * Only outdated scores will be calculated. Scores that are up to date are not
     * recalculated.
     *
     * @param metric to metric to compute its scores
     * @param serviceCenter to compute
     * @return the number of scores calculated
     */
    long compute(Metric metric, Collection<ServiceCenter> serviceCenter);

    /**
     * Computes the grade of a service center based on the score calculated in the summary
     *
     * @param campaign for which the grade is being computed
     * @param summary  for with the grade is being computes
     * @return The grade obtained by the summary
     */
    String compute(Campaign campaign, ScoreSummaryCampaignNode summary);

    /**
     * Compute the formula for a module associated to a service center
     * @param moduleNode fow which the formula is being computed
     */
    void computeModuleFormula(ScoreSummaryNode moduleNode);


}
