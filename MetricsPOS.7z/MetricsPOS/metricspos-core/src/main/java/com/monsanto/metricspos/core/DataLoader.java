package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.application.vo.CampaignVO;
import com.monsanto.metricspos.core.application.vo.DataTableVO;

/**
 * Provides services to load data from external sources
 *
 * @author cafau
 */
public interface DataLoader {

    /**
     * Execute the process to load the service center for the given Campaign
     */
    public void saveAndExecuteServiceCenterLoad(CampaignVO campaignVO);

    /**
     * Updates a data table and loads it with the updated scripts
     *
     * @param dataTableVO with the updated data
     * @throws Exception
     */
    public void saveAndExecuteTableLoad(DataTableVO dataTableVO) throws Exception;

    /**
     * Updates a campaign and loads it's points of sale with the updated scripts
     *
     * @param campaignVO with the updated data
     */
    public void saveAndExecutePointOfSaleLoad(CampaignVO campaignVO);

    /**
     * Updates a campaign and loads it's employees with the updated scripts
     *
     * @param campaignVO with the updated data
     */
    public void saveAndExecuteEmployeeLoad(CampaignVO campaignVO);

    /**
     * Triggers the load of the structural data and the rows
     */
    public void executeBatchLoad();

    /**
     * Loads all the tables of a campaign
     *
     * @param campaignId
     */
    public void executeAllTablesLoad(int campaignId);
}
