package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.application.vo.DataColumnVO;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;

import java.util.List;

/**
 * DataTable CRUD operations
 * <p/>
 * User: PPERA
 */
public interface DataTableServices {

    /**
     * Creates a new data table
     *
     * @param dataTableVO the data of the table to be created
     * @param campaign    the campaign where the table is to be created
     * @return the new data table
     */
    public DataTable newDataTable(DataTableVO dataTableVO, Campaign campaign);

    /**
     * Finds a data table by it's id
     *
     * @param tableId the id of the table
     * @return the table
     */
    public DataTable findDataTableById(int tableId);

    /**
     * Finds the lis of columns of a table
     *
     * @param tableId the table
     * @return the columns
     */
    public List<DataColumn> findMetadataByDataTable(DataTable tableId);

    /**
     * Finds an specific column
     *
     * @param dataColumnId the column id
     * @return the column with that id
     */
    public DataColumn findDataColumnById(Integer dataColumnId);

    /**
     * Removes a column from the application
     *
     * @param dataColumn the column to remove
     * @return the column removed
     */
    public DataColumn removeDataColumn(DataColumn dataColumn);

    /**
     * Removes a data table from the application
     *
     * @param dataTable to be removes
     * @return the data table that was removed
     */
    public DataTable removeDataTable(DataTable dataTable);

    /**
     * Lists the available providers for the data table
     *
     * @return the list of providers
     */
    public List<DataProvider> listProviders();

    /**
     * Updates a data table with input data
     *
     * @param dataTable   the data table to be updated
     * @param dataTableVO the updated data
     */
    public void updateDataTable(DataTable dataTable, DataTableVO dataTableVO);

    /**
     * Updates the column list of a table
     *
     * @param dataTable     the table whose columns are being updated
     * @param dataColumnVOs the new columns data
     * @return the resulting columns
     */
    public List<DataColumn> updateMetadata(DataTable dataTable, List<DataColumnVO> dataColumnVOs);

    /**
     * Finds a data table by it's name
     *
     * @param campaign  the campaign the table belongs to
     * @param tableName the name of the table
     * @return the matching table
     */
    public DataTable findDataTableByCampaignAndName(Campaign campaign, String tableName);

    /**
     * Finds all the tables of a campaign
     *
     * @param campaign the campaign
     * @return the tables of the campaign
     */
    public List<DataTable> findDataTablesByCampaign(Campaign campaign);

    /**
     * Updates the date of the last successful data load run of the table
     *
     * @param dataTable the table to be updated
     * @param success   the success value of the run
     */
    public void updateLastRun(DataTable dataTable, boolean success);

    /**
     * Finds all the metrics that use a table
     *
     * @param dataTable that is used by metrics
     * @return the metrics that use the table
     */
    public List<Metric> findMetricsByDataTable(DataTable dataTable);
}
