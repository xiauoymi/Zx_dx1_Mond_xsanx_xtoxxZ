package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.application.vo.EmployeeVO;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;

import java.util.List;
import java.util.Map;

/**
 * Employee CRUD operations
 * <p/>
 * User: PPERA
 */
public interface EmployeeServices {
    /**
     * The employees that belong to the campaign
     *
     * @param campaign the campaign
     * @return the employees of the campaign
     */
    List<Employee> listEmployeesForCampaign(Campaign campaign);

    /**
     * Lists the employees of an specific page
     *
     * @param campaign  the campaign that the employees belong to
     * @param groups    All the groups of the application
     * @param page      the desired page
     * @param rows      the amount of rows per page
     * @param sort      the property to use for sort
     * @param direction the direction of the sort
     * @param filter    A map with the properties as keys and the desired values as value
     * @return The employees of the page
     */
    List<Employee> listEmployeesForCampaignAndPage(Campaign campaign, List<Group> groups, int page, int rows, String sort, String direction, Map<String, Object> filter);

    /**
     * Marks records as not loaded prior to executing the batch load
     *
     * @param campaign the campaign to be processed
     * @return the amount of records affected
     */
    public long markAllEmployeesAsNotLoadedInCampaign(Campaign campaign);

    /**
     * Creates a new employee or updates if existent
     *
     * @param employee the employee to persist
     * @return The employee as saved
     */
    public Employee saveOrUpdate(Employee employee);

    /**
     * Removes all records whose loaded flag has not been set to true
     *
     * @param campaign the campaign
     * @return the amount of records affected
     */
    public long removeAllNotLoadedEmployees(Campaign campaign);

    /**
     * Counts the amount of employees matching the filter that exist in the campaign
     *
     * @param filter   the filter
     * @param campaign the campaign
     * @param groups   All the groups in the application
     * @return the amount of employees that match
     */
    public long countEmployeesForCampaign(Map<String, Object> filter, Campaign campaign, List<Group> groups);

    /**
     * Finds an specific employee
     *
     * @param employeeId The Id of the employee
     * @param campaign   the campaign of the employee
     * @return the matching employee
     */
    public Employee findEmployeeByIdAndCampaign(Long employeeId, Campaign campaign);

    /**
     * Finds an employee by it's username
     *
     * @param userName the username of the employee
     * @return The matching employee
     */
    public List<Employee> findEmployeesByUsername(String userName);

    /**
     * Creates a new employee from the input data
     *
     * @param employeeVO the input data
     * @param campaign   the campaign to which the employee will belong to
     * @param groups     All the groups in the application
     * @param metrics    All the metrics in the application
     * @return the employee created
     */
    public Employee newEmployee(EmployeeVO employeeVO, Campaign campaign, List<Group> groups, List<Metric> metrics);

    /**
     * Updates an employee with the input data
     *
     * @param employeeVO the input data
     * @param campaign   the campaign of the employee
     * @param metrics    All the metrics of the application
     */
    public void updateEmployee(EmployeeVO employeeVO, Campaign campaign, List<Metric> metrics);
}
