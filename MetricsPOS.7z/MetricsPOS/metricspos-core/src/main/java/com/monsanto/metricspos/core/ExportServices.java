package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.application.vo.MetricScoreVO;
import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

/**
 *  Exports data to a file
 */
public interface ExportServices {
    /**
     * Exports the metricsPOS summary to a file
     *
     * @param outputStream the output file
     * @param summary the summary info to be exported
     * @param <T> never used
     * @throws IOException
     */
	public <T> void export(OutputStream outputStream, ScoreSummaryCampaignNode summary) throws IOException;

    /**
     * Exports the table's rows to a file
     *
     * @param outputStream the output file
     * @param dataTable that is being exported
     * @param data the rows of the table to be exported
     * @param <T> never used
     * @throws IOException
     */
    public <T> void export(OutputStream outputStream, DataTable dataTable, List<DataRow> data) throws IOException;

    /**
     * Exports the info in the "All Scores" grid
     *
     * @param outputStream the output file
     * @param scoreVOs the data of the scores
     * @param <T> never used
     * @throws IOException
     */
    public <T> void export(OutputStream outputStream, List<MetricScoreVO> scoreVOs) throws IOException;

    /**
     * Export services Centers
     *
     *
     * @param outputStream the out file
     * @param scores
     * @throws Exception
     */
    public <T> void export(List<ScoreSummaryCampaignNode> scores, OutputStream outputStream) throws Exception;

    /**
     * Export services Centers Ranking
     *
     *
     * @param outputStream the out file
     * @param servicesCenters
     * @param campaingId
     * @throws Exception
     */
    public <T> void export(List<ServiceCenter> servicesCenters, OutputStream outputStream, int campaingId) throws Exception;
}
