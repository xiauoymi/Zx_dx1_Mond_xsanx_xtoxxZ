package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.application.vo.GroupVO;
import com.monsanto.metricspos.core.security.Group;

import java.util.List;

/**
 * Groups CRUD operations
 * <p/>
 * User: PPERA
 */
public interface GroupServices {
    /**
     * Lists all the groups defined in the application
     *
     * @return
     */
    List<Group> listGroups();

    /**
     * Finds a group by the given Id
     *
     * @param groupId the id of the group to be found
     * @return the group with matching id
     */
    Group findGroupById(Integer groupId);

    /**
     * Creates a new group from the info in the VO
     *
     * @param groupVO with the info of the group to be created
     * @return the group created
     */
    Group newGroup(GroupVO groupVO);

    /**
     * Updates a group with the VO's data
     *
     * @param groupVO with the updated data
     * @param group   the group to be updated
     */
    void update(GroupVO groupVO, Group group);

    /**
     * Finds a group with the given name
     *
     * @param name
     * @return
     */
    public Group findGroupByName(String name);

    /**
     * Removes a group from the application
     *
     * @param group
     */
    public void deleteGroup(Group group);
}
