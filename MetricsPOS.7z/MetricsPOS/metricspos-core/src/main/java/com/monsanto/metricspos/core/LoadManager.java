package com.monsanto.metricspos.core;

/**
 * This objects will perform the loading process on a given table.
 * The loading process consist on extracting the new data from the external source,
 * executing the load script on each record, and deleting the records present in previous
 * load but not in this one.
 * Manual records will be preserved (but can be overridden)
 *
 * @author cafau
 */
public interface LoadManager {

    /**
     * Executes the load procedure for the following table
     * @param tableAdapter  The adapter to the real table to be loaded
     * @return the number of records loaded or updated
     */
    public long load( TableAdapter tableAdapter );
}
