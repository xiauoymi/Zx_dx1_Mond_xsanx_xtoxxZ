package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.security.ActionLog;
import com.monsanto.metricspos.core.security.AuditLog;

import java.util.List;
import java.util.Map;

/**
 * AuditLog and ActionLog CRUD operations
 * <p/>
 * User: PPERA
 */
public interface LogServices {
    /**
     * Lists a page of audit logs
     *
     * @param page      the page to return
     * @param rows      the amount of logs by page
     * @param sort      the property to sort by
     * @param direction the direction of the sort
     * @param filter    the filter to apply
     * @return the logs in the page
     */
    List<AuditLog> listAuditLogsByPage(int page, int rows, String sort, String direction, Map<String, Object> filter);

    /**
     * The amount of logs matching the filter
     *
     * @param filter the filter to apply
     * @return the amount of matching logs
     */
    long getAuditLogsCount(Map<String, Object> filter);

    /**
     * Lists a page of action logs
     *
     * @param page      the page to return
     * @param rows      the amount of logs by page
     * @param sort      the property to sort by
     * @param direction the direction of the sort
     * @param filter    the filter to apply
     * @return the logs in the page
     */
    List<ActionLog> listActionLogsByPage(int page, int rows, String sort, String direction, Map<String, Object> filter);


    /**
     * The amount of logs matching the filter
     *
     * @param filter the filter to apply
     * @return the amount of matching logs
     */
    long getActionLogsCount(Map<String, Object> filter);
}
