package com.monsanto.metricspos.core;

import javax.mail.internet.MimeMessage;

/**
 * Provides the interface for sending mails
 * <p/>
 * User: PPERA
 */
public interface MailServices<T> {
    /**
     * Sends emails with the input data
     *
     * @param sendable input data
     * @throws Exception
     */
    public void sendSummary(T sendable) throws Exception;

    /**
     * Creates a message from the input data
     *
     * @param sendable the input data
     * @return the message
     * @throws Exception
     */
    public MimeMessage newMail(T sendable) throws Exception;

    /**
     * Sets an email address to send any mail if set
     *
     * @param value the override address value
     */
    public void setOverrideTo(String value);

    /**
     * Sets the subject of all the mails
     *
     * @param subject to use
     */
    public void setSubject(String subject);

    /**
     * The text of every mail
     *
     * @param text
     */
    public void setText(String text);

    /**
     * The name of the attachment xls file
     *
     * @param xlsName
     */
    public void setXlsName(String xlsName);

    /**
     * The name of the pdf attachment
     *
     * @param pdfName
     */
    public void setPdfName(String pdfName);
}
