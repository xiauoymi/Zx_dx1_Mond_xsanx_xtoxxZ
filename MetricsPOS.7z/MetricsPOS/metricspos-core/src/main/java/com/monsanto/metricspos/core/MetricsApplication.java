package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.application.vo.*;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.CampaignParameter;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;

import java.util.List;
import java.util.Map;

/**
 * Business logic layer for Metric-related operations
 * <p/>
 * User: PPERA
 */
public interface MetricsApplication {
    /**
     * Lists all the campaigns
     *
     * @return all the campaigns
     */
    public List<Campaign> listAllCampaigns();

    /**
     * Finds a campaign by a given id
     *
     * @param campaignId of the campaign
     * @return a campaign
     */
    public Campaign findCampaignById(int campaignId);

    /**
     * Finds a campaign by id with it's collection attributes populated
     *
     * @param campaignId   the id of the campaign
     * @param withChildren wheter to load the children or not
     * @return the campaign loaded as requested
     */
    Campaign findCampaignById(int campaignId, boolean withChildren);

    /**
     * Lists all submetrics
     *
     * @return
     */
    public List<Metric> listAllMetrics();

    /**
     * Finds a metric by id
     *
     * @param metricId of the metric
     * @return the metric
     */
    public Metric findMetricById(int metricId);

    /**
     * Finds a metric loading it's children if required
     *
     * @param metricId     of the metric
     * @param withChildren whether to load the children or not
     * @return the metric loaded as specified
     */
    Metric findMetricById(int metricId, boolean withChildren);

    /**
     * Remves a metric from the application
     *
     * @param metricId of the metric to remove
     */
    public void delete(int metricId);

    /**
     * Creates a campaign from the input data
     *
     * @param campaignVO the data from which the campaign is to be created
     * @return the new campaign
     */
    public Campaign newCampaign(CampaignVO campaignVO);

    /**
     * Updates a campaign with input data
     *
     * @param campaignVO the input data with the id of the campaign to update
     * @return the updated campaign
     */
    public Campaign updateCampaign(CampaignVO campaignVO);

    /**
     * Updates a metric with input data
     *
     * @param metricVO the input data
     */
    public void updateMetric(MetricVO metricVO);

    /**
     * Add a metric as a children of the campaign
     *
     * @param campaignId of the campaign
     * @param metricVO   input data to create a metric
     * @return the new metric
     */
    public Metric addMetricToCampaign(int campaignId, MetricVO metricVO);

    /**
     * Adds a metric as a children of a metric
     *
     * @param metricId of the parent
     * @param metricVO input data of the children
     * @return the metric created
     */
    public Metric addMetricToMetric(int metricId, MetricVO metricVO);

    /**
     * Disables a metric
     *
     * @param metricId of the metric to be disabled
     * @return The metric that was disabled
     */
    public Metric disable(int metricId);

    /**
     * Enables a metric
     *
     * @param metricId of the metric to enable
     * @return
     */
    public Metric enable(int metricId);

    /**
     * Finds a service center by campaign and cuit
     *
     * @param campaignId of the campaign
     * @param cuit       of the service center
     * @return the service center
     */
    public ServiceCenter findServiceCenterByCampaignIdAndCuit(int campaignId, String cuit);

    /**
     * Lists the service centers of a campaign
     *
     * @param campaignId of the campaign
     * @return List of service centers in that campaign
     */
    public List<ServiceCenter> listServiceCenters(int campaignId);

    /**
     * Lists the service centers of a campaign with children
     *
     * @param campaignId of the campaign
     * @return List of service centers in that campaign with children
     */
    public List<ServiceCenter> listServiceCenters(int campaignId, boolean withChildren);


    /**
     * Remove a campaign with the given id
     *
     * @param campaignId of the campaign to remove
     */
    public void removeCampaign(int campaignId);

    /**
     * Updates a metric and triggers the computation of it's score
     *
     * @param metricVO with the input data for the update
     */
    public void saveAndCalculateMetricScore(MetricVO metricVO);

    /**
     * Computes a metric's score
     *
     * @param metricId of the metric
     */
    public void calculateMetricScore(int metricId);

    /**
     * Finds the points of sale of a service center matching the campaign id and cuit
     *
     * @param campaignId of the campaign
     * @param cuit       of the service center
     * @return A lists of matching points of sale
     */
    public List<PointOfSale> findPointsOfSaleByCampaignIdAndCuit(int campaignId, String cuit);

    /**
     * Find all the points of sale under a campaign
     *
     * @param campaignId of the campaign
     * @return The list with all the points of sale
     */
    public List<PointOfSale> findPointsOfSaleByCampaignId(int campaignId);

    /**
     * Finds a page of scores of a metric
     *
     * @param metricId    of the metric
     * @param pageRequest contaigning the paging parameters
     * @param filter      the filter parameters
     * @return A page of scores
     */
    public Page<MetricScoreVO> findScoresByMetricIdAndPage(int metricId, PageRequest pageRequest, Map<String, Object> filter);

    /**
     * Generates a score summary for a service center in a campaign
     *
     * @param campaignId of the campaign
     * @param cuit       of the service center
     * @return the summary root node
     */
    public ScoreSummaryCampaignNode generateScoreSummary(int campaignId, String cuit);

    /**
     * Lists service centers of a campaign by page
     *
     * @param campaignId  of the campaign
     * @param pageRequest with the paging parameters
     * @param filter      parameters
     * @return A page of service centers
     */
    public Page<ServiceCenterVO> listServiceCentersByPage(int campaignId, PageRequest pageRequest, Map<String, Object> filter);

    /**
     * Sends an email with the score summary to the mails of the service centers and it's points of sale
     *
     * @param campaignId of the campaign
     * @param cuit       of the service center
     * @throws Exception
     */
    public void sendSummary(int campaignId, String cuit) throws Exception;

    /**
     * Sends every registered service center of the campaign it's score summary by mail
     *
     * @param campaignId
     */
    public void sendAllSummaries(int campaignId);

    /**
     * Lists a page o points of sale
     *
     * @param campaignId  of the campaign
     * @param pageRequest with the paging parameters
     * @param filter      filter parameters
     * @return A page of paoints of sale
     */
    public Page<PointOfSaleVO> listPointsOfSaleByPage(int campaignId, PageRequest pageRequest, Map<String, Object> filter);

    /**
     * Finds a pege of campaign parameters
     *
     * @param pageRequest with the paging parameters
     * @param filter      filter parameters
     * @return a page of CampaignParameters
     */
    public Page<CampaignParameter> findCampaignParametersByPage(PageRequest pageRequest, Map<String, Object> filter);

    /**
     * Updates a Campaign Parameter with input data
     *
     * @param parameter input data
     * @return the updated CampaignParameter
     */
    public CampaignParameter updateCampaignParameter(CampaignParameter parameter);

    /**
     * Lists all the submetrics of a campaign
     *
     * @param campaignId of the campaign
     * @return the list of submetrics
     */
    public List<Metric> listSubmetricsForCampaign(int campaignId);

    /**
     * Runs compute score batch process for all campaigns
     */
    public void executeBatchMetricScoreCompute();

    /**
     * Runs compute score batch process for a single campaign
     *
     * @param campaign to run
     */
    public void executeBatchMetricScoreCompute(Campaign campaign);

    /**
     * Runs compute score batch process for a single campaign
     *
     * @param campaignId of the campaign to process
     */
    public void executeBatchMetricScoreCompute(int campaignId);

    /**
     * Finds a page of scores of a campaign
     *
     * @param campaignId  of the campaign
     * @param pageRequest with the paging parameters
     * @param filter      filter parameters
     * @return a page o metric scores
     */
    public Page<MetricScoreVO> findScoresByCampaignIdAndPage(int campaignId, PageRequest pageRequest, Map<String, Object> filter);

    /**
     * Finds all scores of the current campaign. Used for data export.
     *
     * @param campaignId of the campaign
     * @param sort       property to sort the results
     * @param filter     filter parameters
     * @return
     */
    public List<MetricScoreVO> findAllScoresByCampaignId(int campaignId, Sort sort, Map<String, Object> filter);

    /**
     * set the send flag of a metric
     *
     * @param metricId of the metric to set
     * @param sendValue flag to set
     * @return
     */
    public Metric setSendFlag(int metricId, boolean sendValue);

    /**
     *
     * @param campaignId
     */
    public void changePrivileges(int campaignId);
}
