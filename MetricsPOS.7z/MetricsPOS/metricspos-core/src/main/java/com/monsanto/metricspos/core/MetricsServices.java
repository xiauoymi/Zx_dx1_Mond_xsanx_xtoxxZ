package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.application.vo.MetricVO;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.util.List;

/**
 * The MetricsServices object represents the application services for Metrics.
 * It's the entry point for all services that do not belong to a specific
 * domain instance.
 *
 * @author CAFAU
 */
public interface MetricsServices {
    /**
     * Lists al the submetrics in the application. Not used.
     *
     * @return A list of all the metrics
     */
    public List<Metric> listAllMetrics();

    /**
     * Finds a metric by it's id
     *
     * @param metricId of the metric to find
     * @return the metric with that id
     */
    public Metric findMetricById(int metricId);

    /**
     * Removes a metric from the application
     *
     * @param metric to remove
     */
    public void delete(Metric metric);

    /**
     * Updates a metric with the input data
     *
     * @param metric   to update
     * @param tables   All the tables of the campaign
     * @param metricVO input data
     */
    public void updateMetric(Metric metric, List<DataTable> tables, MetricVO metricVO);

    /**
     * Updates a metric with the input data
     *
     * @param metric   the metric to update
     * @param metricVO the input data
     */
    public void updateMetric(Metric metric, MetricVO metricVO);

    /**
     * Lists all the submetrics in a campaign
     *
     * @param campaign
     * @return The list of submetrics
     */
    public List<Metric> listSubmetricsByCampaign(Campaign campaign);

    /**
     * Sets the value of the dirty flag to all scores of a metric
     *
     * @param metric whose scores are affected
     * @param dirty  the value of the dirty flag to set
     */
    public void markMetricScoresDirtiness(Metric metric, boolean dirty);


    /**
     * Sets the value of the dirty flag to all scores of a metric and a service center
     *
     * @param metric whose scores are affected
     * @param sc the service center
     * @param dirty  the value of the dirty flag to set
     */
    public void markMetricScoresDirtinessByServiceCenter(Metric metric, ServiceCenter sc, boolean dirty);
}
