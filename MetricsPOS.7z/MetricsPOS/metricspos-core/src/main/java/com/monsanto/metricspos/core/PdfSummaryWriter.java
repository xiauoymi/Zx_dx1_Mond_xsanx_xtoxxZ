package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.io.OutputStream;

/**
 * Writes a formatted output of the submetric summary for a given ServiceCenter
 *
 * @author CAFAU
 */
public interface PdfSummaryWriter {
    /**
     * Exports a metric summary as a PDF
     *
     * @param outputStream  of the file
     * @param campaign
     * @param serviceCenter
     * @param summary
     */
    void export(OutputStream outputStream, Campaign campaign, ServiceCenter serviceCenter, ScoreSummaryCampaignNode summary);
}
