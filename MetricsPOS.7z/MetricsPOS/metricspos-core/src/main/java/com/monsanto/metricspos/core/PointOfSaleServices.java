package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.util.List;
import java.util.Map;

/**
 * PointOfSale CRUD operations
 * <p/>
 * User: PPERA
 */
public interface PointOfSaleServices {
    /**
     * Flags all points of sale as not loaded
     *
     * @param campaign
     * @return the amount of points of sale affected
     */
    public long markPointsOfSalesAsNotLoadedForCampaign(Campaign campaign);

    /**
     * Creates a point of sale or updates it if existent
     *
     * @param pointOfSale to create or update input data
     * @return The resulting point of sale
     */
    public PointOfSale saveOrUpdate(PointOfSale pointOfSale);

    /**
     * Removes the point of sales that weren't loaded by the batch process
     *
     * @param campaign
     * @return the amount of point of sales removed
     */
    public long removeUnloadedPointsOfSaleForCampaign(Campaign campaign);

    /**
     * Finds a point of sale by id and campaign
     *
     * @param idSap    of the point of sale
     * @param campaign of the point of sale
     * @return The matching point of sale
     */
    public PointOfSale findPointOfSaleByIdSap(Long idSap, Campaign campaign);

    /**
     * Lists the points of sales of a service center
     *
     * @param serviceCenter
     * @return The points of sale of the service center
     */
    public List<PointOfSale> findPointsOfSaleByServiceCenter(ServiceCenter serviceCenter);

    /**
     * Finds all points of sale of a campaign
     *
     * @param campaign of the points of sale
     * @return All the points of sale of the campaign
     */
    public List<PointOfSale> findPointsOfSaleByCampaign(Campaign campaign);

    /**
     * Lists a page of points of sale of a campaign
     *
     * @param campaign   the campaign
     * @param pageNumber the page
     * @param pageSize   the amount of rows in a page
     * @param sort       the property to sort
     * @param direction  the direction of the sort
     * @param filter     the filter parameters
     * @return The matching point of sale page
     */
    List<PointOfSale> listPointsOfSaleByPage(Campaign campaign, int pageNumber, int pageSize, String sort, String direction, Map<String, Object> filter);

    /**
     * Counts the amount of points of sale in a campaign that match the filter
     *
     * @param campaign of the points of sale
     * @param filter   filter parameter
     * @return the amount of points of sale
     */
    long getPointsOfSaleCount(Campaign campaign, Map<String, Object> filter);
}
