package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.util.List;
import java.util.Map;

/**
 * Implementers offers services to persist metric scores
 *
 * @author cafau
 */
public interface ScoreServices {

    /**
     * Creates a new (persisted) score for the given metric and service center
     *
     * @param metric        The metric this score is computed for
     * @param serviceCenter The service center this score is computed for
     * @return a new empty MetricScore
     */
    MetricScore newMetricScore(Metric metric, ServiceCenter serviceCenter);

    /**
     * Finds a page of scores by metric
     *
     * @param metric    of the score
     * @param page      page to find
     * @param rows      rows in a page
     * @param sort      property to sort
     * @param direction direction of sort
     * @param filter    filter parameters
     * @return A list of scores
     */
    List<MetricScore> findScoresByMetric(Metric metric, int page, int rows, String sort, String direction, Map<String, Object> filter);

    /**
     * Finds a page of scores by campaign
     *
     * @param campaign  of the score
     * @param page      page to find
     * @param rows      rows in a page
     * @param sort      property to sort
     * @param direction direction of sort
     * @param filter    filter parameters
     * @return A list of scores
     */
    List<MetricScore> findScoresByCampaign(Campaign campaign, int page, int rows, String sort, String direction, Map<String, Object> filter);

    /**
     * Finds all the scores computed in a campaign
     *
     * @param campaign  of the scores
     * @param sort      property to sort
     * @param direction direction of sort
     * @param filter    filter parameters
     * @return list of all scores
     */
    List<MetricScore> findAllScoresByCampaign(Campaign campaign, String sort, String direction, Map<String, Object> filter);

    /**
     * Counts the scores of a metric matching a filter
     *
     * @param metric of the scores
     * @param filter filter parameters
     * @return the amount of matching scores
     */
    long getTotalScoresCount(Metric metric, Map<String, Object> filter);

    /**
     * Counts the scores matching a filter in a campaign
     *
     * @param campaign the campaign of the scores
     * @param filter   filter parameters
     * @return the amount of matching scores
     */
    long getTotalCampaignScoresCount(Campaign campaign, Map<String, Object> filter);

    /**
     * Finds a score of a given metric and service center
     *
     * @param metric        of the score
     * @param serviceCenter of the score
     * @return The score
     */
    MetricScore findScoreByMetricAndServiceCenter(Metric metric, ServiceCenter serviceCenter);
}
