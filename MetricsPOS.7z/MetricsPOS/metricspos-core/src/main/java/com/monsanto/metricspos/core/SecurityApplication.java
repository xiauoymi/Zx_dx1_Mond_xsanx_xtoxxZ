package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.application.vo.EmployeeVO;
import com.monsanto.metricspos.core.application.vo.GroupVO;
import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.Authority;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.support.PageRequest;

import java.util.List;
import java.util.Map;

/**
 * Business logic layer related to security operations
 * <p/>
 * User: PPERA
 */
public interface SecurityApplication {

    /**
     * Lists all the groups defined in the application
     *
     * @return all groups
     */
    public List<Group> listGroups();

    /**
     * Lists all the authorities in the application
     *
     * @return all authorities
     */
    public List<Authority> listAuthorities();

    /**
     * Creates a group from input data
     *
     * @param groupVO input data
     * @return The new group
     */
    public Group createGroup(GroupVO groupVO);

    /**
     * Finds a group by id
     *
     * @param groupId of the group
     * @return The matching group
     */
    public Group findGroupById(int groupId);

    /**
     * Updates a group with the input data
     *
     * @param groupVO input data
     */
    public void updateGroup(GroupVO groupVO);

    /**
     * Removes a group from the application
     *
     * @param groupId
     */
    public void deleteGroup(int groupId);

    /**
     * Lists all admin users of the application
     *
     * @return all admin users
     */
    public List<AdminUser> listAdminUsers();

    /**
     * Creates a new admin user from input data
     *
     * @param adminUser input data
     * @return The new admin user
     */
    public AdminUser createAdminUser(AdminUser adminUser);

    /**
     * Finds a page of Employee-Group relationships
     *
     * @param campaignId  of the employee
     * @param pageRequest with paging parameters
     * @param filter      filter parameters
     * @return The page of Employee-Groups relationships
     */
    public Page<Map<String, Object>> findEmployeeGroupsByPage(int campaignId, PageRequest pageRequest, Map<String, Object> filter);

    /**
     * Updates Employee-Groups relationship with input data
     *
     * @param campaignId     of the employee
     * @param employeeGroups input data containing the id of the employee and wether it belongs to a group or not
     */
    public void updateEmployeeGroups(int campaignId, Map<String, Object> employeeGroups);

    /**
     * Lists employees of a campaign
     *
     * @param campaignId of the employees
     * @return All employees of a campaign
     */
    public List<Employee> listEmployees(int campaignId);

    /**
     * Finds employees by campaign and id
     *
     * @param campaignId of the employee
     * @param employeeId of the employee
     * @return The matching employee
     */
    public Employee findEmployeeByCampaignIdAndEmployeeId(int campaignId, long employeeId);

    /**
     * Creates an employee from input data
     *
     * @param employeeVO input data
     * @return The new employee
     */
    public Employee createEmployee(EmployeeVO employeeVO);

    /**
     * Updates an employee from input data
     *
     * @param campaignId of the employee
     * @param employeeVO the input data with the id of the employee
     */
    public void updateEmployee(int campaignId, EmployeeVO employeeVO);

    /**
     * Deletes and admin user by id
     *
     * @param adminUserId of the admin user
     */
    public void deleteAdminUser(int adminUserId);

    /**
     * Finds a page of audit logs
     *
     * @param pageRequest with paging parameters
     * @param filter      filter parameters
     * @return the page of audit logs
     */
    public Page<Map<String, Object>> findAuditLogsByPage(PageRequest pageRequest, Map<String, Object> filter);

    /**
     * Finds a page of action logs
     *
     * @param pageRequest with paging parameters
     * @param filter      filter parameters
     * @return the page of action logs
     */
    public Page<Map<String, Object>> findActionLogsByPage(PageRequest pageRequest, Map<String, Object> filter);
}
