package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.util.List;
import java.util.Map;

/**
 * Objects that implements this offers the services to persist and recover Service Centers
 *
 * @author cafau
 */
public interface ServiceCenterServices {

    /**
     * Set the loaded flag to false for all service centers in the given campaign.
     * This is usually done before a mass load or update to identify records not
     * updated (missing from the source) that can be removed
     *
     * @param campaign The campaign to mark records for
     * @return the number of records marked
     */
    long markAllServiceCentersAsNotLoadedInCampaign(Campaign campaign);

    /**
     * Retrieves from repository the service center with the given id in the given campaign
     *
     * @param cuit
     * @return
     */
    ServiceCenter findServiceCenterByCuit(String cuit, Campaign campaign);

    /**
     * Removed from repository all service centers that have the "loaded" flag in false.
     * This is usually done after a mass load or update with records not loaded or
     * updated (missing from the source)
     *
     * @param campaign the campaign to remove service centers from
     * @return the number of service centers removed
     */
    long removeAllNotLoadedServiceCenters(Campaign campaign);

    /**
     * Saves a service center or updates it if it exists
     *
     * @param serviceCenter to save
     * @return saved service center
     */
    ServiceCenter saveOrUpdate(ServiceCenter serviceCenter);

    /**
     * Finds a list of service centers corresponding a page
     *
     * @param campaign  of the service centers
     * @param page      page to find
     * @param rows      amount of records in the page
     * @param sort      property to sort
     * @param direction sort direction
     * @param filter    filter parameters
     * @return List of matching service centers
     */
    List<ServiceCenter> listServiceCentersByPage(Campaign campaign, int page, int rows, String sort, String direction, Map<String, Object> filter);

    /**
     * Counts the amount of service centers matching a filter in a campaign
     *
     * @param campaign of the service centers
     * @param filter   filter parameters
     * @return amount of matching service centers
     */
    long getServiceCentersCount(Campaign campaign, Map<String, Object> filter);

    /**
     * Lists all service centers of a campaign
     *
     * @param campaign
     * @return
     */
    List<ServiceCenter> listServiceCenters(Campaign campaign);
}
