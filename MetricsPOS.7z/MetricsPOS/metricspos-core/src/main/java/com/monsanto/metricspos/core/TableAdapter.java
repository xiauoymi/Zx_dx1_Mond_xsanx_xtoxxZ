package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.externaldata.DataProvider;

/**
 * Provides the LoadManager with the information needed to load data into
 * the table.
 * Allows to separate tje logic to execute scripts from the source of data for
 * the table
 *
 * @author cafau
 */
public interface TableAdapter<RecordType> {

    /**
     * Returns the provider for the data of this table
     *
     * @return  the DataProvider to access the data of this  table
     */
    DataProvider getProvider();

    /**
     * Returns the text of the script to execute the loading of records into this table
     *
     * @return  the loading script as a String
     */
    String getLoadScript();

    /**
     * Returns the DML (query) to obtain the records from the data source
     *
     * @return  The SQL text to obtain the records from source
     */
    String getLoadSql();

    /**
     * Puts a mark a in all records so they can be distinguished as loaded or not loaded
     * after the process of loading.
     * Note: Records inputted manually will be marked as already loaded. This will prevent this record to be deleted
     * by after load process.
     *
     * @return  the number of records marked
     */
    long markAllRecordsAsNotLoaded();

    /**
     * Merge this data with the existing record or create a new one if none exists
     * @param newRecord the new data for the record
     * @return  the corresponding records or null if there is not match
     */
    RecordType saveOrUpdate(RecordType newRecord);

    /**
     * Marks the given record as loaded
     *
     * @param dataRecord    the record to be marked
     */
    // TODO this method shouldnt be a part of the interface. O this should be an abstract class
    void markAsLoaded( RecordType dataRecord );

    /**
     * Marks the given record as loaded
     *
     * @param dataRecord    the record to be marked
     * @param loaded        true if loaded, false if not
     */
    void markAsLoaded( RecordType dataRecord, boolean loaded);

    /**
     * Delete (remove from repository) all records not already marked as loaded.
     * This records disappear from source, so them must be disappeared from Metrics.
     * Note: Implementors could "logically" delete the records
     *
     * @return the number of records deleted
     */
    long removeAllUnloadedRecords();

    /**
     * Creates a conceptually empty instance of the current record type
     * @return
     */
    RecordType getEmptyRecord();
}
