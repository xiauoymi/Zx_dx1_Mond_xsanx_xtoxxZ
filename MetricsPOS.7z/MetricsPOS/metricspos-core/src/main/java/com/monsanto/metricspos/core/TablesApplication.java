package com.monsanto.metricspos.core;

import com.monsanto.metricspos.core.application.vo.DataColumnVO;
import com.monsanto.metricspos.core.application.vo.DataRowVO;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.externaldata.*;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;

import java.util.List;
import java.util.Map;

/**
 * Business logic layer related to Data Table operations
 * <p/>
 * User: PPERA
 */
public interface TablesApplication {

    public List<DataType> listDataTypes();

    public DataTable findDataTableById(int tableId);

    public List<DataColumn> findMetadataByDataTableId(int tableId);

    public DataTable newDataTable(DataTableVO dataTableVO);

    public void updateDataTable(DataTableVO dataTableVO);

    public List<DataColumn> updateMetadata(int tableId, List<DataColumnVO> columns);

    public DataTable removeDataTable(int tableId);

    public List<DataProvider> listProviders();

    public Page<DataRowVO> findRowsByDataTableIdAndPage(int tableId, PageRequest pageRequest, Map<String, Object> filter);

    public void updateRow(int tableId, Map<String, Object> rowData);

    public void deleteRows(int tableId, List<Integer> rowId);

    public void deleteAllRows(int tableId);

    public List<DataRow> createRows(int tableId, Map<String, Object>[] rows);

    public List<DataRow> findRowsByDataTable(DataTable dataTable, Sort sort, Map<String, Object> filter);

    public List<Metric> findMetricsByDataTable(DataTable dataTable);

    public DataFile findRowDataFile(Integer tableId, Integer rowId);
}
