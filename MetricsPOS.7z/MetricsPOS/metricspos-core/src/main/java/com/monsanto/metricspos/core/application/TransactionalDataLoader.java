package com.monsanto.metricspos.core.application;

import com.monsanto.metricspos.core.*;
import com.monsanto.metricspos.core.application.adapters.DataTableTableAdapter;
import com.monsanto.metricspos.core.application.adapters.EmployeeTableAdapter;
import com.monsanto.metricspos.core.application.adapters.PointOfSaleTableAdapter;
import com.monsanto.metricspos.core.application.adapters.ServiceCenterTableAdapter;
import com.monsanto.metricspos.core.application.vo.CampaignVO;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Facade to loading data from external source
 *
 * @author cafau
 */
@Service("dataLoader")
public class TransactionalDataLoader implements DataLoader {

    @Autowired
    private LoadManager loadManager;

    @Autowired
    private CampaignServices campaignServices;

    @Autowired
    private DataTableServices tableServices;

    @Autowired
    private MetricsServices metricsServices;

    @Autowired
    @Qualifier("serviceCenterProvider")
    private DataProvider serviceCenterProvider;

    @Autowired
    @Qualifier("pointOfSaleProvider")
    private DataProvider pointOfSaleProvider;

    @Autowired
    @Qualifier("tsrProvider")
    private DataProvider tsrProvider;

    @Autowired
    @Qualifier("auditLog")
    private Logger auditLog;

    private Logger log = Logger.getLogger(TransactionalDataLoader.class);

    /**
     * Execute the process to load the service center for the given Campaign
     * Sample Service Center load script:
     * " // receives input and output
     * " if ( input.zone > 15 ) {
     * "   output.cuit = input.cuit;
     * "   output.name = input.name.trim();
     * " } else {
     * "   return SKIP;
     * "}
     *
     * @return the number of records loaded or updated
     */
    @Override
    @Transactional
    public void saveAndExecuteServiceCenterLoad(CampaignVO campaignVO) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignVO.getId());
        this.campaignServices.updateCampaign(campaign, campaignVO);
        this.executeServiceCenterLoad(campaign);
    }

    @Override
    @Transactional
    public void saveAndExecuteTableLoad(DataTableVO dataTableVO) throws Exception {

        DataTable dataTable = this.tableServices.findDataTableById(dataTableVO.getId());
        try {
            this.tableServices.updateDataTable(dataTable, dataTableVO);
            log.debug("Executing data load for table " + dataTableVO.getName());
            this.executeTableLoad(dataTable);
        } catch (Exception e) {
            this.updateLastRun(dataTableVO.getId(), false);
            throw e;
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateLastRun(Integer id, boolean succeed) {
        DataTable dataTable = this.tableServices.findDataTableById(id);
        this.tableServices.updateLastRun(dataTable, succeed);
    }

    @Override
    @Transactional
    public void saveAndExecutePointOfSaleLoad(CampaignVO campaignVO) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignVO.getId());
        this.campaignServices.updateCampaign(campaign, campaignVO);
        this.executePointOfSaleLoad(campaign);
    }

    @Override
    @Transactional
    public void saveAndExecuteEmployeeLoad(CampaignVO campaignVO) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignVO.getId());
        this.campaignServices.updateCampaign(campaign, campaignVO);
        this.executeEmployeeLoad(campaign);
    }

    @Override
    @Transactional
    public void executeBatchLoad() {
        List<Campaign> campaigns = this.campaignServices.listAllCampaignsForBatch();

        for (Campaign campaign : campaigns) {
            this.loadCampaignData(campaign);
        }
    }

    @Override
    @Transactional
    public void executeAllTablesLoad(int campaignId) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        this.loadDataTables(campaign);
    }

    private void loadCampaignData(Campaign campaign) {
        if (campaign.isScheduled()) {
            auditLog.debug("Campaign [" + campaign + "] was scheduled");
            this.loadStructuralData(campaign);
        }
        this.loadDataTables(campaign);
    }

    private void loadDataTables(Campaign campaign) {
        if (hasTables(campaign)) {
            for (DataTable dataTable : campaign.getDataTables()) {
                executeIfScheduled(campaign, dataTable);
            }
        }
    }

    private boolean hasTables(Campaign campaign) {
        return campaign.getDataTables() != null && !campaign.getDataTables().isEmpty();
    }

    private void executeIfScheduled(Campaign campaign, DataTable dataTable) {
        try {
            if (dataTable.isScheduled()) {
                auditLog.debug("Data table [" + dataTable + "] was scheduled");
                this.executeTableLoad(dataTable);
            }
        } catch (Exception e) {
            log.error("An error occurred while updating the data for table [" + dataTable.getName() + "] of campaign [" + campaign.getName() + "]", e);
            // TODO persist somewhere, maybe in the table
        }
    }

    private void loadStructuralData(Campaign campaign) {
        try {
            this.executeServiceCenterLoad(campaign);
            this.executePointOfSaleLoad(campaign);
        } catch (Exception e) {
            log.error("An error occurred while updating the data for the campaign [" + campaign.getName() + "]", e);
            // TODO persist somewhere, maybe in the campaign
        }
    }

    protected void executePointOfSaleLoad(Campaign campaign) {
        PointOfSaleTableAdapter pointOfSaleTableAdapter = new PointOfSaleTableAdapter(campaign, pointOfSaleProvider);
        this.loadManager.load(pointOfSaleTableAdapter);
        this.updateDirtyScores(campaign);
    }

    protected void executeServiceCenterLoad(Campaign campaign) {
        ServiceCenterTableAdapter serviceCenterTableAdapter = new ServiceCenterTableAdapter(campaign, serviceCenterProvider);
        this.loadManager.load(serviceCenterTableAdapter);
    }

    private void executeEmployeeLoad(Campaign campaign) {
        EmployeeTableAdapter employeeTableAdapter = new EmployeeTableAdapter(campaign, tsrProvider);
        this.loadManager.load(employeeTableAdapter);
    }

    protected void executeTableLoad(DataTable dataTable) {
        DataTableTableAdapter tableAdapter = new DataTableTableAdapter(dataTable);
        this.loadManager.load(tableAdapter);
        this.tableServices.updateLastRun(dataTable, true);
        this.updateDirtyScores(dataTable);
    }

    private void updateDirtyScores(DataTable dataTable) {
        // update the scores as dirty
        List<Metric> metrics = this.tableServices.findMetricsByDataTable(dataTable);

        for (Metric metric : metrics) {
            this.metricsServices.markMetricScoresDirtiness(metric, true);
        }

    }

    private void updateDirtyScores(Campaign campaign) {
        // update the scores as dirty
        List<Metric> metrics = this.metricsServices.listSubmetricsByCampaign(campaign);

        for (Metric metric : metrics) {
            this.metricsServices.markMetricScoresDirtiness(metric, true);
        }

    }
}
