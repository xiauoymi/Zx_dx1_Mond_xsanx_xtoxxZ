package com.monsanto.metricspos.core.application;

import com.monsanto.metricspos.core.*;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.*;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.CampaignParameter;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import com.monsanto.metricspos.dao.support.SimplePage;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Implementation of the MetricsApplication interface with support for Transactions
 */
@Service("metricsApplication")
public class TransactionalMetricsApplication implements MetricsApplication {
    @Autowired
    private CampaignServices campaignServices;
    @Autowired
    private DataTableServices tableServices;
    @Autowired
    private MetricsServices metricServices;
    @Autowired
    private ServiceCenterServices serviceCenterServices;
    @Autowired
    private PointOfSaleServices pointOfSaleServices;
    @Autowired
    private ScoreServices scoreServices;

    @Autowired
    private SecurityHolderStrategy securityHolderStrategy;

    @Autowired
    @Qualifier("mailServices")
    private MailServices<ScoreSummaryCampaignNode> mailServices;
    private Logger log = Logger.getLogger(TransactionalMetricsApplication.class);

    @Autowired
    @Qualifier("auditLog")
    private Logger auditLog;

    @Override
    @Transactional
    public List<Campaign> listAllCampaigns() {
        return campaignServices.listAllCampaigns();
    }

    @Override
    @Transactional
    public Campaign findCampaignById(int campaignId) {
        return this.campaignServices.findCampaignById(campaignId);
    }

    @Override
    @Transactional
    public Campaign findCampaignById(int campaignId, boolean withChildren) {
        Campaign campaign = findCampaignById(campaignId);

        if (withChildren) {
            ensuresLoaded(campaign.getMetrics());
            ensuresLoadedDataTables(campaign.getDataTables());
        }

        return campaign;
    }

    @Override
    @Transactional
    public Campaign newCampaign(CampaignVO campaignVO) {
        this.validateCampaign(campaignVO);
        return this.campaignServices.newCampaign(campaignVO);
    }

    @Override
    @Transactional
    public Campaign updateCampaign(CampaignVO campaignVO) {
        if (campaignVO == null) {
            throw new BusinessException(BusinessException.ERROR_VO_CANNOT_BE_NULL, 400);
        }

        this.validateCampaign(campaignVO);

        Campaign campaign = findCampaignById(campaignVO.getId());
        return this.campaignServices.updateCampaign(campaign, campaignVO);
    }

    @Override
    @Transactional
    public void removeCampaign(int campaignId) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        this.campaignServices.removeCampaign(campaign);
        auditLog.debug("Deleting campaign [" + campaign + "]");
    }

    @Override
    @Transactional
    public Metric addMetricToCampaign(int campaignId, MetricVO metricVO) {
        if (metricVO == null) {
            throw new BusinessException(BusinessException.ERROR_VO_CANNOT_BE_NULL, 400);
        }

        this.validateMetric(metricVO);

        Campaign campaign = this.findCampaignById(campaignId);
        return campaign.addMetricDefinition(metricVO.getName(), metricVO.getMaxPoints());
    }

    @Override
    @Transactional
    public ServiceCenter findServiceCenterByCampaignIdAndCuit(int campaignId, String cuit) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        return this.campaignServices.findServiceCenterByCampaignIdAndCuit(campaign, cuit);
    }

    @Override
    @Transactional
    public List<ServiceCenter> listServiceCenters(int campaignId) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        return this.serviceCenterServices.listServiceCenters(campaign);
    }

    @Override
    @Transactional
    public List<ServiceCenter> listServiceCenters(int campaignId, boolean withChildren) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        List<ServiceCenter> servicesCenters = this.serviceCenterServices.listServiceCenters(campaign);

        if (withChildren) {
            ensuresLoadedServiceCenter(servicesCenters);
        }

        return servicesCenters;
    }

    @Override
    @Transactional
    public Page<ServiceCenterVO> listServiceCentersByPage(int campaignId, PageRequest pageRequest, Map<String, Object> filter) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        Sort.Order order = getSortOrder(pageRequest);
        List<ServiceCenter> serviceCenters = this.serviceCenterServices.listServiceCentersByPage(campaign, pageRequest.getPageNumber(), pageRequest.getPageSize(), order.getProperty(), order.getDirection().toString(), filter);
        List<ServiceCenterVO> serviceCenterVOs = ServiceCenterVO.makeServiceCenterVOs(serviceCenters);
        return new SimplePage<ServiceCenterVO>(pageRequest, serviceCenterVOs, this.serviceCenterServices.getServiceCentersCount(campaign, filter));
    }

    @Override
    @Transactional
    public Page<PointOfSaleVO> listPointsOfSaleByPage(int campaignId, PageRequest pageRequest, Map<String, Object> filter) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        Sort.Order order = getSortOrder(pageRequest);
        List<PointOfSale> pointOfSales = this.pointOfSaleServices.listPointsOfSaleByPage(campaign, pageRequest.getPageNumber(), pageRequest.getPageSize(), order.getProperty(), order.getDirection().toString(), filter);
        List<PointOfSaleVO> pointOfSaleVOs = PointOfSaleVO.makePointOfSaleVOs(pointOfSales);
        return new SimplePage<PointOfSaleVO>(pageRequest, pointOfSaleVOs, this.pointOfSaleServices.getPointsOfSaleCount(campaign, filter));
    }

    @Override
    @Transactional
    public List<PointOfSale> findPointsOfSaleByCampaignId(int campaignId) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        return this.pointOfSaleServices.findPointsOfSaleByCampaign(campaign);
    }

    @Override
    @Transactional
    public List<PointOfSale> findPointsOfSaleByCampaignIdAndCuit(int campaignId, String cuit) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        ServiceCenter serviceCenter = this.serviceCenterServices.findServiceCenterByCuit(cuit, campaign);
        return this.pointOfSaleServices.findPointsOfSaleByServiceCenter(serviceCenter);
    }

    @Override
    @Transactional
    public void sendSummary(int campaignId, String cuit) throws Exception {
        this.updateCampaignMailParameters();
        ScoreSummaryCampaignNode scoreSummaryCampaignNode = this.generateScoreSummary(campaignId, cuit);
        log.debug("Successfully calculated score summary for service center Cuit:[" + cuit + "] CampaignId:[" + campaignId + "]");
        this.mailServices.sendSummary(scoreSummaryCampaignNode);
        auditLog.debug("Sent summary to service center [" + cuit + "] campaign [" + campaignId + "]");
        scoreSummaryCampaignNode.getServiceCenter().setLastTimeSent(new Date());
        log.debug("Successfully sent score summary email for service center Cuit:[" + cuit + "] CampaignId:[" + campaignId + "]");
    }

    @Override
    @Transactional
    public void sendAllSummaries(int campaignId) {
        this.updateCampaignMailParameters();
        List<ServiceCenter> serviceCenters = this.listServiceCenters(campaignId);

        for (ServiceCenter serviceCenter : serviceCenters) {
            try {
                this.sendSummary(serviceCenter.getCampaign().getId(), serviceCenter.getCuit());
            } catch (Exception e) {
                auditLog.error("An error ocurred when sending summary of service center Name:[" + serviceCenter.getName() + "] Cuit:[" + serviceCenter.getCuit() + "] CampaignId:[" + campaignId + "]");
                log.error("An error ocurred when sending summary of service center Name:[" + serviceCenter.getName() + "] Cuit:[" + serviceCenter.getCuit() + "] CampaignId:[" + campaignId + "]");
            }
        }
    }

    @Override
    @Transactional
    public ScoreSummaryCampaignNode generateScoreSummary(int campaignId, String cuit) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        ServiceCenter serviceCenter = this.serviceCenterServices.findServiceCenterByCuit(cuit, campaign);
        return new ScoreSummaryCampaignNode(campaign, serviceCenter, this.scoreServices);
    }

    @Override
    @Transactional
    public Page<CampaignParameter> findCampaignParametersByPage(PageRequest pageRequest, Map<String, Object> filter) {
        Sort.Order order = getSortOrder(pageRequest);
        List<CampaignParameter> params = this.campaignServices.getParameters(pageRequest.getPageNumber(), pageRequest.getPageSize(), order.getProperty(), order.getDirection().toString(), filter);
        return new SimplePage<CampaignParameter>(pageRequest, params, this.campaignServices.getTotalParametersCount(filter));
    }

    @Override
    @Transactional
    public CampaignParameter updateCampaignParameter(CampaignParameter parameter) {
        if (parameter.getName() == null || parameter.getName().isEmpty()) {
            throw new BusinessException(BusinessException.MISSING_REQUIRED_FIELD + "[Name]", 400);
        }

        CampaignParameter campaignParameter = this.campaignServices.findParameterById(parameter.getId());
        return this.campaignServices.updateParameter(campaignParameter, parameter);
    }

    @Override
    @Transactional
    public List<Metric> listSubmetricsForCampaign(int campaignId) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        return this.metricServices.listSubmetricsByCampaign(campaign);
    }

    @Override
    @Transactional
    public void executeBatchMetricScoreCompute() {
        List<Campaign> campaigns = this.campaignServices.listAllCampaigns();

        for (Campaign campaign : campaigns) {
            this.executeBatchMetricScoreCompute(campaign);
        }

    }

    @Override
    @Transactional
    public void executeBatchMetricScoreCompute(int campaignId) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        executeBatchMetricScoreCompute(campaign);
    }


    @Override
    @Transactional
    public void executeBatchMetricScoreCompute(Campaign campaign) {
        for (Metric module : campaign.getMetrics()) {
            for (Metric metric : module.getMetrics()) {
                for (Metric submetric : metric.getMetrics()) {
                    if (submetric.isEnabled() && submetric.isScheduled()) {
                        auditLog.debug("Submetric [" + submetric + "] of campaign [" + campaign + "] was scheduled");
                        submetric.compute();
                    }
                }
            }
        }
    }

    @Override
    @Transactional
    public List<Metric> listAllMetrics() {
        return this.metricServices.listAllMetrics();
    }

    @Override
    @Transactional
    public Metric findMetricById(int metricId) {
        Metric metric = this.metricServices.findMetricById(metricId);
        ensuresLoadedDataTables(metric.getTables());
        return metric;
    }

    @Override
    @Transactional
    public Metric findMetricById(int metricId, boolean withChildren) {
        Metric metric = this.metricServices.findMetricById(metricId);

        if (withChildren) {
            ensuresLoaded(metric.getMetrics());
            ensuresLoadedDataTables(metric.getTables());
        }
        return metric;
    }

    @Override
    @Transactional
    public void delete(int metricId) {
        Metric metric = this.findMetricById(metricId);
        this.metricServices.delete(metric);
        auditLog.debug("Deleting metric [" + metric + "]");
    }

    @Override
    @Transactional
    public void updateMetric(MetricVO metricVO) {
        this.validateMetric(metricVO);
        Metric metric = this.findMetricById(metricVO.getId());
        auditLog.debug("Updating metric [" + metric + "]");
        List<DataTable> tables = this.tableServices.findDataTablesByCampaign(metric.getCampaign());
        this.metricServices.updateMetric(metric, tables, metricVO);
    }

    @Override
    @Transactional
    public Metric addMetricToMetric(int metricId, MetricVO metricVO) {
        this.validateMetric(metricVO);
        Metric parent = findMetricById(metricId, true);
        Metric child = parent.addMetricDefinition(metricVO.getName(), metricVO.getMaxPoints());
        child.setEnabled(metricVO.isEnabled() != null && metricVO.isEnabled());
        return child;
    }

    @Override
    @Transactional
    public void saveAndCalculateMetricScore(MetricVO metricVO) {
        if (metricVO.getId() == null) {
            throw new BusinessException(BusinessException.MISSING_REQUIRED_FIELD + "[Id]", 400);
        }

        this.validateMetric(metricVO);
        Metric metric = this.metricServices.findMetricById(metricVO.getId());
        auditLog.debug("Updating metric [" + metric + "]");
        List<DataTable> tables = this.tableServices.findDataTablesByCampaign(metric.getCampaign());
        this.metricServices.updateMetric(metric, tables, metricVO);
        metric.compute();
    }

    @Override
    @Transactional
    public void calculateMetricScore(int metricId) {
        Metric metric = this.metricServices.findMetricById(metricId);
        metric.compute();
    }

    @Override
    @Transactional
    public Page<MetricScoreVO> findScoresByMetricIdAndPage(int metricId, PageRequest pageRequest, Map<String, Object> filter) {
        Metric metric = this.metricServices.findMetricById(metricId);
        Sort.Order order = getSortOrder(pageRequest);
        List<MetricScore> scores = this.scoreServices.findScoresByMetric(metric, pageRequest.getPageNumber(), pageRequest.getPageSize(), order.getProperty(), order.getDirection().toString(), filter);
        List<MetricScoreVO> scoreVOs = MetricScoreVO.makeMetricScoreVOs(scores);
        return new SimplePage<MetricScoreVO>(pageRequest, scoreVOs, this.scoreServices.getTotalScoresCount(metric, filter));
    }

    @Override
    @Transactional
    public Page<MetricScoreVO> findScoresByCampaignIdAndPage(int campaignId, PageRequest pageRequest, Map<String, Object> filter) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        Sort.Order order = getSortOrder(pageRequest);
        List<MetricScore> scores = this.scoreServices.findScoresByCampaign(campaign, pageRequest.getPageNumber(), pageRequest.getPageSize(), order.getProperty(), order.getDirection().toString(), filter);
        List<MetricScoreVO> scoreVOs = MetricScoreVO.makeMetricScoreVOs(scores);
        return new SimplePage<MetricScoreVO>(pageRequest, scoreVOs, this.scoreServices.getTotalCampaignScoresCount(campaign, filter));
    }

    @Override
    @Transactional
    public List<MetricScoreVO> findAllScoresByCampaignId(int campaignId, Sort sort, Map<String, Object> filter) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        Sort.Order order = sort.iterator().next();
        List<MetricScore> scores = this.scoreServices.findAllScoresByCampaign(campaign, order.getProperty(), order.getDirection().toString(), filter);
        return MetricScoreVO.makeMetricScoreVOs(scores);
    }

    @Override
    @Transactional
    public Metric setSendFlag(int metricId, boolean sendValue) {
        Metric metric = this.metricServices.findMetricById(metricId);
        metric.setSend(sendValue);
        return metric;
    }

    @Override
    @Transactional
    public void changePrivileges(int campaignId) {
        //Set currentUser by CampaingId
        securityHolderStrategy.setCurrentUser(campaignId);
    }

    @Override
    @Transactional
    public Metric disable(int metricId) {
        Metric metric = this.metricServices.findMetricById(metricId);
        metric.setEnabled(false);
        return metric;
    }

    @Override
    @Transactional
    public Metric enable(int metricId) {
        Metric metric = this.metricServices.findMetricById(metricId);
        metric.setEnabled(true);
        return metric;
    }

    private void ensuresLoadedDataTables(List<DataTable> dataTables) {
        if (dataTables != null) {
            for (DataTable dataTable : dataTables) {
                ensureDataTableIsLoaded(dataTable);
            }
        }
    }

    private void ensureDataTableIsLoaded(DataTable dataTable) {
        dataTable.getCampaign();
        ensureColumnsAreLoaded(dataTable);
    }

    private void ensureColumnsAreLoaded(DataTable dataTable) {
        if (dataTable.getColumns() != null) {
            for (DataColumn column : dataTable.getColumns()) {
                ensureColumnIsLoaded(column);
            }
        }
    }

    private void ensureColumnIsLoaded(DataColumn column) {
        column.getName();
    }

    /**
     * Ensures all children are fetched. This is done BADLY now, think a better solution
     *
     * @param serviceCenters whose children are to be loaded
     */
    private void ensuresLoadedServiceCenter(List<ServiceCenter> serviceCenters) {
        if (serviceCenters != null) {
            for (ServiceCenter serviceCenter : serviceCenters) {
                ensuresLoadedMetricScore(serviceCenter.getScores());
                serviceCenter.getEmployees();
                serviceCenter.getPointsOfSale();
            }
        }
    }

    /**
     * Ensures all children are fetched. This is done BADLY now, think a better solution
     *
     * @param metrics whose children are to be loaded
     */
    private void ensuresLoadedMetricScore(List<MetricScore> metrics) {
        if (metrics != null) {
            for (MetricScore metric : metrics) {
                metric.getServiceCenter();
            }
        }
    }

    /**
     * Ensures all children are fetched. This is done BADLY now, think a better solution
     *
     * @param metrics whose children are to be loaded
     */
    private void ensuresLoaded(List<Metric> metrics) {
        if (metrics != null) {
            for (Metric metric : metrics) {
                ensuresLoaded(metric.getMetrics());
                ensuresLoadedDataTables(metric.getTables());
            }
        }
    }

    private Sort.Order getSortOrder(PageRequest pageRequest) {
        return pageRequest.getSort().iterator().next();
    }

    private void validateCampaign(CampaignVO campaignVO) {
        if (campaignVO.getName() == null || campaignVO.getName().isEmpty()) {
            throw new BusinessException(BusinessException.MISSING_REQUIRED_FIELD + "[Name]", 400);
        }
        if (campaignVO.getSince() == null) {
            throw new BusinessException(BusinessException.MISSING_REQUIRED_FIELD + "[Since]", 400);
        }
        if (campaignVO.getUntil() == null) {
            throw new BusinessException(BusinessException.MISSING_REQUIRED_FIELD + "[Until]", 400);
        }
    }

    private String getOverrideToParameterValue() {
        CampaignParameter campaignParameter = this.campaignServices.findParameterByName(CampaignParameter.OVERRIDE_TO_PARAMETER);
        return campaignParameter.getValue();
    }

    private String getPdfNameParameterValue() {
        CampaignParameter campaignParameter = this.campaignServices.findParameterByName(CampaignParameter.PDF_NAME_PARAMETER);
        return campaignParameter.getValue();
    }

    private String getXlsNameParameterValue() {
        CampaignParameter campaignParameter = this.campaignServices.findParameterByName(CampaignParameter.XLS_NAME_PARAMETER);
        return campaignParameter.getValue();
    }

    private String getSubjectParameterValue() {
        CampaignParameter campaignParameter = this.campaignServices.findParameterByName(CampaignParameter.SUBJECT_PARAMETER);
        return campaignParameter.getValue();
    }

    private String getTextParameterValue() {
        CampaignParameter campaignParameter = this.campaignServices.findParameterByName(CampaignParameter.TEXT_PARAMETER);
        return campaignParameter.getValue();
    }

    private void validateMetric(MetricVO metricVO) {
        if (metricVO.getName() == null || metricVO.getName().isEmpty()) {
            throw new BusinessException(BusinessException.MISSING_REQUIRED_FIELD + "[Name]", 400);
        }
    }

    private void updateCampaignMailParameters() {
        this.mailServices.setOverrideTo(this.getOverrideToParameterValue());
        this.mailServices.setPdfName(this.getPdfNameParameterValue());
        this.mailServices.setXlsName(this.getXlsNameParameterValue());
        this.mailServices.setSubject(this.getSubjectParameterValue());
        this.mailServices.setText(this.getTextParameterValue());
    }
}
