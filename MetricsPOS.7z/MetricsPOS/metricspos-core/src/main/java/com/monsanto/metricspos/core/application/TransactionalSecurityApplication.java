package com.monsanto.metricspos.core.application;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.*;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.EmployeeVO;
import com.monsanto.metricspos.core.application.vo.GroupVO;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.security.*;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import com.monsanto.metricspos.dao.support.SimplePage;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * Implements the SecurityApplication interface with support for transactions
 *
 * User: PPERA
 */
@Service
public class TransactionalSecurityApplication implements SecurityApplication {

    @Autowired
    private GroupServices groupServices;

    @Autowired
    private AuthorityServices authorityServices;

    @Autowired
    private AdminUserServices adminUserServices;

    @Autowired
    private CampaignServices campaignServices;

    @Autowired
    private EmployeeServices employeeServices;

    @Autowired
    private MetricsServices metricsServices;

    @Autowired
    private LogServices logServices;

    @Autowired
    @Qualifier("auditLog")
    private Logger auditLog;

    @Override
    @Transactional
    public List<Group> listGroups() {
        return this.groupServices.listGroups();
    }

    @Override
    @Transactional
    public List<Authority> listAuthorities() {
        return this.authorityServices.listAuthorities();
    }

    @Override
    @Transactional
    public Group createGroup(GroupVO groupVO) {
        List<Group> existentGroups = this.groupServices.listGroups();
        for (Group group : existentGroups) {
            if (group.getName().equals(groupVO.getName())) {
                throw new BusinessException(BusinessException.DUPLICATE_GROUP_NAME, 409);
            }
        }

        Group group = this.groupServices.newGroup(groupVO);
        ensureAuthoritiesAreLoaded(group);
        return group;
    }

    @Override
    @Transactional
    public Group findGroupById(int groupId) {
        Group group = this.groupServices.findGroupById(groupId);
        ensureAuthoritiesAreLoaded(group);
        return group;
    }

    @Override
    @Transactional
    public void updateGroup(GroupVO groupVO) {
        Group group = this.groupServices.findGroupById(groupVO.getId());
        this.groupServices.update(groupVO, group);
    }

    @Override
    @Transactional
    public void deleteGroup(int groupId) {
         Group group = this.groupServices.findGroupById(groupId);
         this.groupServices.deleteGroup(group);
    }

    @Override
    @Transactional
    public List<AdminUser> listAdminUsers() {
        return this.adminUserServices.listAdminUsers();
    }

    @Override
    @Transactional
    public AdminUser createAdminUser(AdminUser adminUser) {
        return this.adminUserServices.newAdminUser(adminUser);
    }

    @Override
    @Transactional
    public Page<Map<String, Object>> findEmployeeGroupsByPage(int campaignId, PageRequest pageRequest, Map<String, Object> filter) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        Sort.Order order = getSortOrder(pageRequest);
        List<Group> groups = this.groupServices.listGroups();
        List<Employee> employeePage = this.employeeServices.listEmployeesForCampaignAndPage(campaign, groups, pageRequest.getPageNumber(), pageRequest.getPageSize(), order.getProperty(), order.getDirection().toString(), filter);
        return new SimplePage(pageRequest, this.makeEmployeeGroupsMap(employeePage, groups), this.employeeServices.countEmployeesForCampaign(filter, campaign, groups));
    }

    @Override
    @Transactional
    public void updateEmployeeGroups(int campaignId, Map<String, Object> employeeGroups) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        Long employeeId = Long.valueOf((String) employeeGroups.get("id"));
        Employee employee = this.employeeServices.findEmployeeByIdAndCampaign(employeeId, campaign);
        List<Group> groups = this.groupServices.listGroups();
        employee.getGroups().clear();
        auditLog.debug("Employee groups were cleared [" + employee + "]");

        for (Group group : groups) {
            if (employeeGroups.get(group.getName()) != null && Boolean.valueOf((String) employeeGroups.get(group.getName()))) {
                auditLog.debug("Employee [" + employee + "] was added to group [" + group + "]");
                employee.getGroups().add(group);
            }
        }
    }

    @Override
    @Transactional
    public List<Employee> listEmployees(int campaignId) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        List<Employee> employees = this.employeeServices.listEmployeesForCampaign(campaign);

        for (Employee employee : employees) {
            ensureEmployeeGroupsAreLoaded(employee);
            ensureEmployeeMetricsAreLoaded(employee);
            ensureEmployeeServiceCentersAreLoaded(employee);
        }
        return employees;
    }

    @Override
    @Transactional
    public Employee findEmployeeByCampaignIdAndEmployeeId(int campaignId, long employeeId) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        Employee employee = this.employeeServices.findEmployeeByIdAndCampaign(employeeId, campaign);
        ensureEmployeeGroupsAreLoaded(employee);
        ensureEmployeeMetricsAreLoaded(employee);
        ensureEmployeeServiceCentersAreLoaded(employee);
        return employee;
    }

    @Override
    @Transactional
    public Employee createEmployee(EmployeeVO employeeVO) {
        Campaign campaign = this.campaignServices.findCampaignById(employeeVO.getCampaignId());
        List<Group> groups = this.groupServices.listGroups();
        List<Metric> metrics = this.metricsServices.listSubmetricsByCampaign(campaign);
        return this.employeeServices.newEmployee(employeeVO, campaign, groups, metrics);
    }

    @Override
    @Transactional
    public void updateEmployee(int campaignId, EmployeeVO employeeVO) {
        Campaign campaign = this.campaignServices.findCampaignById(campaignId);
        List<Metric> metrics = this.metricsServices.listSubmetricsByCampaign(campaign);
        this.employeeServices.updateEmployee(employeeVO, campaign, metrics);
    }

    @Override
    @Transactional
    public void deleteAdminUser(int adminUserId) {
        AdminUser adminUser = this.adminUserServices.findAdminUserById(adminUserId);
        this.adminUserServices.deleteAdminUser(adminUser);
    }

    @Override
    @Transactional
    public Page<Map<String, Object>> findAuditLogsByPage(PageRequest pageRequest, Map<String, Object> filter) {
        Sort.Order order = getSortOrder(pageRequest);
        List<AuditLog> auditLogPage = this.logServices.listAuditLogsByPage(pageRequest.getPageNumber(), pageRequest.getPageSize(), order.getProperty(), order.getDirection().toString(), filter);
        return new SimplePage(pageRequest, auditLogPage, this.logServices.getAuditLogsCount(filter));
    }

    @Override
    @Transactional
    public Page<Map<String, Object>> findActionLogsByPage(PageRequest pageRequest, Map<String, Object> filter) {
        Sort.Order order = getSortOrder(pageRequest);
        List<ActionLog> actionLogPage = this.logServices.listActionLogsByPage(pageRequest.getPageNumber(), pageRequest.getPageSize(), order.getProperty(), order.getDirection().toString(), filter);
        return new SimplePage(pageRequest, actionLogPage, this.logServices.getActionLogsCount(filter));
    }

    private void ensureEmployeeGroupsAreLoaded(Employee employee) {
        if (employee.getGroups() != null) {
            for (Group group : employee.getGroups()) {
                group.getName();
                ensureAuthoritiesAreLoaded(group);
            }
        }
    }

    private void ensureEmployeeServiceCentersAreLoaded(Employee employee) {
        if (employee.getServiceCenters() != null) {
            for (ServiceCenter serviceCenter : employee.getServiceCenters()) {
                serviceCenter.getCuit();
            }
        }
    }

    private void ensureEmployeeMetricsAreLoaded(Employee employee) {
        if (employee.getMetrics() != null) {
            for (Metric metric : employee.getMetrics()) {
                metric.getName();
            }
        }
    }

    private List<Map<String, Object>> makeEmployeeGroupsMap(List<Employee> employeePage, List<Group> groups) {
        List<Map<String, Object>> result = Lists.newArrayList();

        for (Employee employee : employeePage) {
            Map<String, Object> map = Maps.newHashMap();
            map.put("id", employee.getId());
            map.put("name", employee.getName());
            map.put("username", employee.getUsername());

            for (Group group : groups) {
                map.put(group.getName().replaceAll(" ", "_"), employee.getGroups().contains(group));
            }

            result.add(map);
        }

        return result;
    }

    private void ensureAuthoritiesAreLoaded(Group group) {
        if (group.getAuthorities() != null) {
            for (Authority authority : group.getAuthorities()) {
                authority.getName();
            }
        }
    }

    private Sort.Order getSortOrder(PageRequest pageRequest) {
        return pageRequest.getSort().iterator().next();
    }
}
