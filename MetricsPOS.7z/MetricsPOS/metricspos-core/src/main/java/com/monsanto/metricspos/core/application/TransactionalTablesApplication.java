package com.monsanto.metricspos.core.application;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.CampaignServices;
import com.monsanto.metricspos.core.DataTableServices;
import com.monsanto.metricspos.core.MetricsServices;
import com.monsanto.metricspos.core.TablesApplication;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.DataColumnVO;
import com.monsanto.metricspos.core.application.vo.DataRowVO;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.externaldata.*;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import com.monsanto.metricspos.dao.support.SimplePage;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;

/**
 * Implementation of the TablesApplication interface with support for Transactions
 *
 * User: PPERA
 */
@Service
public class TransactionalTablesApplication implements TablesApplication {
    @Autowired
    private DataTableServices tableServices;
    @Autowired
    private CampaignServices campaignServices;
    @Autowired
    private MetricsServices metricsServices;

    @Autowired
    @Qualifier("auditLog")
    private Logger auditLog;

    @Resource(name = "dataTypeMap")
    private Map<String, DataType> dataTypeMap;

    @Override
    @Transactional
    public List<DataType> listDataTypes() {
        return Lists.newArrayList(this.dataTypeMap.values());
    }

    @Override
    @Transactional
    public List<DataProvider> listProviders() {
        return this.tableServices.listProviders();
    }

    @Override
    @Transactional
    public DataTable findDataTableById(int tableId) {
        DataTable dataTable = this.tableServices.findDataTableById(tableId);
        dataTable.getCampaign().getId();
        ensureMetricsAreLoaded(dataTable);
        return dataTable;
    }

    private void ensureMetricsAreLoaded(DataTable dataTable) {
        if (dataTable.getMetrics() != null) {
            for (Metric metric : dataTable.getMetrics()) {
                metric.getName();
            }
        }
    }

    @Override
    @Transactional
    public DataTable newDataTable(DataTableVO dataTableVO) {
        Campaign campaign = this.campaignServices.findCampaignById(dataTableVO.getCampaignId());

        if (dataTableVO.getName().contains(" ")) {
            throw new BusinessException(BusinessException.TABLE_NAME_CANNOT_HAVE_SPACES, 424);
        }

        if (this.isTableNameInUseForCampaign(dataTableVO.getName(), campaign)) {
            throw new BusinessException(BusinessException.DATA_TABLE_NAME_ALREADY_IN_USE_FOR_THIS_CAMPAIGN, 424);
        }

        return this.tableServices.newDataTable(dataTableVO, campaign);
    }

    @Override
    @Transactional
    public void updateDataTable(DataTableVO dataTableVO) {
        DataTable dataTable = this.tableServices.findDataTableById(dataTableVO.getId());
        this.tableServices.updateDataTable(dataTable, dataTableVO);
    }

    @Override
    @Transactional
    public DataTable removeDataTable(int tableId) {
        DataTable dataTable = this.tableServices.findDataTableById(tableId);
        auditLog.debug("Deleting data table [" + dataTable + "]");
        return this.tableServices.removeDataTable(dataTable);
    }

    @Override
    @Transactional
    public List<DataColumn> findMetadataByDataTableId(int tableId) {
        DataTable dataTable = this.tableServices.findDataTableById(tableId);
        return this.tableServices.findMetadataByDataTable(dataTable);
    }

    @Override
    @Transactional
    public List<DataColumn> updateMetadata(int tableId, List<DataColumnVO> dataColumnVOs) {
        validateColumns(dataColumnVOs);
        DataTable dataTable = this.tableServices.findDataTableById(tableId);
        List<DataColumn> result = this.tableServices.updateMetadata(dataTable, dataColumnVOs);
        this.updateDirtyScores(dataTable);
        return result;

    }

    @Override
    @Transactional
    public Page<DataRowVO> findRowsByDataTableIdAndPage(int tableId, PageRequest pageRequest, Map<String, Object> filter) {
        DataTable dataTable = this.tableServices.findDataTableById(tableId);
        Sort.Order order = getSortOrder(pageRequest);
        List<DataRow> dataRows = dataTable.findRowsByPage(pageRequest.getPageNumber(), pageRequest.getPageSize(), order.getProperty(), order.getDirection().toString(), filter);
        List<DataRowVO> dataRowVOs = DataRowVO.makeDataRowVOs(dataRows);
        return new SimplePage<DataRowVO>(pageRequest, dataRowVOs, dataTable.getTotalRowCount(filter));

    }

    @Override
    @Transactional
    public void updateRow(int tableId, Map<String, Object> rowData) {
        DataTable dataTable = this.tableServices.findDataTableById(tableId);
        DataRow dataRow = dataTable.updateRow(rowData);
        auditLog.debug("Updating data row [" + dataRow + "]");
        updateDirtyScores(dataTable, Lists.<DataRow>newArrayList(dataRow));
    }

    @Override
    @Transactional
    public List<DataRow> createRows(int tableId, Map<String, Object>[] rows) {
        List<DataRow> dataRows = Lists.newArrayListWithExpectedSize(rows.length);
        //DataTable dataTable = this.tableServices.findDataTableById(tableId);
        for (Map<String, Object> row : rows) {
            //dataRows.add(dataTable.newRow(row));
            dataRows.add(this.createRow(tableId, row));
        }
        //updateDirtyScores(dataTable, dataRows);
        updateDirtyScores(tableId, dataRows);

        return dataRows;
    }

    private void updateDirtyScores(DataTable dataTable, List<DataRow> dataRows) {
        // update the scores as dirty
        List<Metric> metrics = this.tableServices.findMetricsByDataTable(dataTable);

        Set<ServiceCenter> serviceCenters = new HashSet<ServiceCenter>();
        // get the list of servicenters contained in each new row
        for (DataRow dataRow : dataRows) {
            serviceCenters.add(dataRow.getServiceCenter());
        }

        for (ServiceCenter serviceCenter : serviceCenters) {
            for (Metric metric : metrics) {
                this.metricsServices.markMetricScoresDirtinessByServiceCenter(metric, serviceCenter, true);
            }
        }
    }

    private void updateDirtyScores(int tableId, List<DataRow> dataRows) {
        // update the scores as dirty
        DataTable dataTable = this.tableServices.findDataTableById(tableId);
        this.updateDirtyScores(dataTable, dataRows);
    }

    private void updateDirtyScores(DataTable dataTable) {
        // update the scores as dirty
        List<Metric> metrics = this.tableServices.findMetricsByDataTable(dataTable);

        for (Metric metric : metrics) {
            this.metricsServices.markMetricScoresDirtiness(metric, true);
        }
    }

    @Override
    @Transactional
    public List<DataRow> findRowsByDataTable(DataTable dataTable, Sort sort, Map<String, Object> filter) {
        Sort.Order order = sort.iterator().next();
        return dataTable.findRows(order.getProperty(), order.getDirection().toString(), filter);
    }

    @Override
    @Transactional
    public List<Metric> findMetricsByDataTable(DataTable dataTable) {
        return this.tableServices.findMetricsByDataTable(dataTable);
    }

    @Override
    @Transactional
    public DataFile findRowDataFile(Integer tableId, Integer rowId) {
        DataTable dataTable = this.tableServices.findDataTableById(tableId);
        DataRow row = dataTable.findRowById(rowId);
        return row.getDataFile();
    }

    @Override
    @Transactional
    public void deleteRows(int tableId, List<Integer> rowIds) {
        DataTable dataTable = this.tableServices.findDataTableById(tableId);
        List<DataRow> dataRows = new ArrayList<DataRow>();
        for (Integer rowId : rowIds) {
            DataRow dataRow = dataTable.findRowById(rowId);
            auditLog.debug("Removing data row [" + dataRow + "]");
            dataTable.remove(dataRow);
            dataRows.add(dataRow);
        }

        // update the scores as dirty.
        updateDirtyScores(dataTable, dataRows);
    }

    @Override
    @Transactional
    public void deleteAllRows(int tableId) {
        DataTable dataTable = this.tableServices.findDataTableById(tableId);
        auditLog.debug("Removing all data from table [" + dataTable.getName() + "]");
        dataTable.removeAllRows();
    }


    private boolean isTableNameInUseForCampaign(final String dataTableName, Campaign campaign) {
        return !(Collections2.filter(campaign.getDataTables(), new Predicate<DataTable>() {
            @Override
            public boolean apply(DataTable input) {
                return input.getName().equals(dataTableName);
            }
        }).isEmpty());
    }

    protected DataRow createRow(int tableId, Map<String, Object> rowData) {
        DataTable dataTable = this.tableServices.findDataTableById(tableId);
        return dataTable.newRow(rowData);
    }

    // TODO move somewhere else
    private void validateColumns(List<DataColumnVO> columns) {
        Map<String, DataColumnVO> nameCounter = Maps.newHashMap();
        int serviceCenterTypesCounter = 0;
        int pointOfSaleTypesCounter = 0;
        int dataFileTypesCounter = 0;

        for (DataColumnVO column : columns) {
            if (!nameCounter.containsKey(column.getName().toLowerCase())) {
                nameCounter.put(column.getName().toLowerCase(), column);
            } else {
                throw new BusinessException(BusinessException.COLUMN_NAMES_MUST_BE_UNIQUE, 409);
            }

            validateColumnName(column);

            serviceCenterTypesCounter = validateServiceCenterTypes(serviceCenterTypesCounter, column);

            pointOfSaleTypesCounter = validatePointOfSaleTypes(pointOfSaleTypesCounter, column);

            dataFileTypesCounter = validateDataFileTypes(dataFileTypesCounter, column);

            validateOptions(column);
        }

        if (serviceCenterTypesCounter != 1) {
            throw new BusinessException(BusinessException.TABLE_MUST_HAVE_ONE_SERVICE_CENTER_COLUMN, 422);
        }
    }

    private void validateColumnName(DataColumnVO column) {
        if (column.getName().contains(" ")) {
            throw new BusinessException(BusinessException.COLUMN_NAMES_CANNOT_HAVE_SPACES, 422);
        }
    }

    private void validateOptions(DataColumnVO column) {
        if (this.dataTypeMap.get(column.getType()).isHasOptions()) {
            if (CollectionUtils.isEmpty(column.getOptions())) {
                throw new BusinessException(BusinessException.OPTION_COLUMN_MUST_HAVE_OPTIONS, 422);
            }
        }
    }

    private int validateDataFileTypes(int dataFileTypesCounter, DataColumnVO column) {
        int result = dataFileTypesCounter;
        if (this.dataTypeMap.get(column.getType()).getInternalType().equals(DataFile.class)) {
            result = ++dataFileTypesCounter;
            if (dataFileTypesCounter > 1) {
                throw new BusinessException(BusinessException.TABLE_MUST_HAVE_ONE_DATA_FILE_COLUMN, 422);
            }
        }
        return result;
    }

    private int validatePointOfSaleTypes(int pointOfSaleTypesCounter, DataColumnVO column) {
        int result = pointOfSaleTypesCounter;
        if (this.dataTypeMap.get(column.getType()).getInternalType().equals(PointOfSale.class)) {
            result = ++pointOfSaleTypesCounter;
            if (pointOfSaleTypesCounter > 1) {
                throw new BusinessException(BusinessException.TABLE_MUST_HAVE_ONE_POINT_OF_SALE_COLUMN_AT_MOST, 422);
            }
        }
        return result;
    }

    private int validateServiceCenterTypes(int serviceCenterTypesCounter, DataColumnVO column) {
        int result = serviceCenterTypesCounter;
        if (this.dataTypeMap.get(column.getType()).getInternalType().equals(ServiceCenter.class)) {
            result = ++serviceCenterTypesCounter;
            if (serviceCenterTypesCounter > 1) {
                throw new BusinessException(BusinessException.TABLE_MUST_HAVE_ONE_SERVICE_CENTER_COLUMN, 422);
            }
        }
        return result;
    }

    private Sort.Order getSortOrder(PageRequest pageRequest) {
        return pageRequest.getSort().iterator().next();
    }

}
