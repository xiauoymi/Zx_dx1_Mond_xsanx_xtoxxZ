package com.monsanto.metricspos.core.application.adapters;

import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.TableAdapter;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.externaldata.DataTable;

/**
 * This adapter provides the the interface required by the ScriptedDataLoader
 * in order to execute the data loading steps for the tables
 *
 * User: PPERA
 */
public class DataTableTableAdapter implements TableAdapter<DataRow>{

    private DataTable dataTable;

    public DataTableTableAdapter(DataTable dataTable){
        this.dataTable = dataTable;
    }

    @Override
    public DataProvider getProvider() {
        return dataTable.getDataProvider();
    }

    @Override
    public String getLoadScript() {
        return dataTable.getLoadScript();
    }

    @Override
    public String getLoadSql() {
        return dataTable.getLoadSql();
    }

    @Override
    public long markAllRecordsAsNotLoaded() {
        return dataTable.markAllRecordsAsNotLoaded();
    }

    @Override
    public DataRow saveOrUpdate(DataRow dataRow) {
        dataTable.saveOrUpdateRow(dataRow);
        return dataRow;
    }

    @Override
    public void markAsLoaded(DataRow dataRow) {
        this.markAsLoaded(dataRow, true);
    }

    @Override
    public void markAsLoaded(DataRow dataRow, boolean loaded) {
        dataRow.setLoaded(loaded);
    }

    @Override
    public long removeAllUnloadedRecords() {
        return dataTable.removeAllNotLoadedRecords();
    }

    @Override
    public DataRow getEmptyRecord() {
        return new DataRow(dataTable, dataTable.getDataRowPersistor().makeRowValues(Maps.<String, Object>newHashMap()));
    }
}
