package com.monsanto.metricspos.core.application.adapters;

import com.monsanto.metricspos.core.EmployeeServices;
import com.monsanto.metricspos.core.TableAdapter;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.Employee;
import org.springframework.beans.factory.annotation.Configurable;

/**
 * This adapter provides the the interface required by the ScriptedDataLoader
 * in order to execute the data loading steps for the Employees
 *
 * User: PPERA
 */
@Configurable
public class EmployeeTableAdapter implements TableAdapter<Employee> {

    private Campaign campaign;
    private DataProvider provider;

    private EmployeeServices employeeServices;

    public EmployeeTableAdapter() {

    }

    public EmployeeTableAdapter(Campaign campaign, DataProvider dataProvider) {
        this.campaign = campaign;
        this.provider = dataProvider;
    }

    public void setEmployeeServices(EmployeeServices employeeServices) {
        this.employeeServices = employeeServices;
    }

    @Override
    public DataProvider getProvider() {
        return this.provider;
    }

    @Override
    public String getLoadScript() {
        return campaign.getEmployeeLoadScript();
    }

    @Override
    public String getLoadSql() {
        return campaign.getEmployeeLoadSql();
    }

    @Override
    public long markAllRecordsAsNotLoaded() {
        return employeeServices.markAllEmployeesAsNotLoadedInCampaign(this.campaign);
    }

    @Override
    public Employee saveOrUpdate(Employee employee) {
        employee.setCampaign(this.campaign);
        return this.employeeServices.saveOrUpdate(employee);
    }

    @Override
    public void markAsLoaded(Employee employee) {
        this.markAsLoaded(employee, true);
    }

    @Override
    public void markAsLoaded(Employee employee, boolean loaded) {
        employee.setLoaded(loaded);
    }

    @Override
    public long removeAllUnloadedRecords() {
        return this.employeeServices.removeAllNotLoadedEmployees(this.campaign);
    }

    @Override
    public Employee getEmptyRecord() {
        Employee employee = new Employee();
        employee.setCampaign(this.campaign);
        return employee;
    }
}
