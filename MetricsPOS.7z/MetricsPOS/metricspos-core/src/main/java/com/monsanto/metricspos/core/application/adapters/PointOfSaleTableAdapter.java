package com.monsanto.metricspos.core.application.adapters;

import com.monsanto.metricspos.core.PointOfSaleServices;
import com.monsanto.metricspos.core.TableAdapter;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.PointOfSale;
import org.springframework.beans.factory.annotation.Configurable;

/**
 * This adapter provides the the interface required by the ScriptedDataLoader
 * in order to execute the data loading steps for the Points of Sale
 * User: PPERA
 */
@Configurable
public class PointOfSaleTableAdapter implements TableAdapter<PointOfSale> {

    private Campaign campaign;
    private DataProvider provider;

    private PointOfSaleServices pointOfSaleServices;

    public PointOfSaleTableAdapter() {

    }

    public PointOfSaleTableAdapter(Campaign campaign, DataProvider provider) {
        this.campaign = campaign;
        this.provider = provider;
    }

    @Override
    public DataProvider getProvider() {
        return provider;
    }

    @Override
    public String getLoadScript() {
        return this.campaign.getPointOfSaleLoadScript();
    }

    @Override
    public String getLoadSql() {
        return campaign.getPointOfSaleLoadSql();
    }

    @Override
    public long markAllRecordsAsNotLoaded() {
        return pointOfSaleServices.markPointsOfSalesAsNotLoadedForCampaign(this.campaign);
    }

    @Override
    public PointOfSale saveOrUpdate(PointOfSale pointOfSale) {
        return this.pointOfSaleServices.saveOrUpdate(pointOfSale);
    }

    @Override
    public void markAsLoaded(PointOfSale pointOfSale) {
        pointOfSale.setLoaded(true);
    }

    @Override
    public void markAsLoaded(PointOfSale pointOfSale, boolean loaded) {
        pointOfSale.setLoaded(loaded);
    }

    @Override
    public long removeAllUnloadedRecords() {
        return this.pointOfSaleServices.removeUnloadedPointsOfSaleForCampaign(this.campaign);
    }

    @Override
    public PointOfSale getEmptyRecord() {
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setCampaign(campaign);
        return pointOfSale;
    }

    public void setPointOfSaleServices(PointOfSaleServices pointOfSaleServices) {
        this.pointOfSaleServices = pointOfSaleServices;
    }
}
