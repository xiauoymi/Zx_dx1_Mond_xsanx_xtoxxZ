package com.monsanto.metricspos.core.application.adapters;

import com.monsanto.metricspos.core.ServiceCenterServices;
import com.monsanto.metricspos.core.TableAdapter;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.springframework.beans.factory.annotation.Configurable;

/**
 * TableAdapter to load Service Centers from external sources.
 *
 * @author cafau
 */
@Configurable
public class ServiceCenterTableAdapter implements TableAdapter<ServiceCenter> {

    private Campaign campaign;
    private DataProvider provider;

    private ServiceCenterServices serviceCenterServices;

    public ServiceCenterTableAdapter(){

    }

    public ServiceCenterTableAdapter(Campaign campaign, DataProvider provider) {
        this.campaign = campaign;
        this.provider = provider;
    }

    @Override
    public DataProvider getProvider() {
        return provider;
    }

    @Override
    public String getLoadScript() {
        return campaign.getServiceCenterLoadScript();
    }

    @Override
    public String getLoadSql() {
        return campaign.getServiceCenterLoadSql();
    }

    @Override
    public long markAllRecordsAsNotLoaded() {
        return serviceCenterServices.markAllServiceCentersAsNotLoadedInCampaign(campaign);
    }

    @Override
    public ServiceCenter saveOrUpdate(ServiceCenter serviceCenter) {
        if ( serviceCenter.getCampaign() == null ) {
            serviceCenter.setCampaign(campaign);
        }
        return serviceCenterServices.saveOrUpdate( serviceCenter );
    }

    @Override
    public void markAsLoaded(ServiceCenter dataRecord) {
        markAsLoaded(dataRecord, true);
    }

    @Override
    public void markAsLoaded(ServiceCenter dataRecord, boolean loaded) {
        dataRecord.setLoaded( loaded );
    }

    @Override
    public long removeAllUnloadedRecords() {
        // TODO Perhaps the records should be marked (logically) as deleted but not physically removed
        return serviceCenterServices.removeAllNotLoadedServiceCenters( campaign );
    }

    @Override
    public ServiceCenter getEmptyRecord() {
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        return serviceCenter;
    }

    public void setServiceCenterServices(ServiceCenterServices serviceCenterServices) {
        this.serviceCenterServices = serviceCenterServices;
    }
}
