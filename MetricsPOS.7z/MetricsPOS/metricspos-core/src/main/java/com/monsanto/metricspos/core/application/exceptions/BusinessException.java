package com.monsanto.metricspos.core.application.exceptions;

/**
 * This exception is thrown when a validation or integrity error related
 * to business logic takes place
 *
 * User: PPERA
 */
public class BusinessException extends RuntimeException {

    // Controller layer messages
    public static final String ERROR_CAMPAIGN_NOT_FOUND = "The requested campaign was not found";
    public static final String ERROR_PARAMETER_CANNOT_BE_NULL = "The parameter cannot be null";
    public static final String ERROR_PARAMETER_ID_CANNOT_BE_NULL = "Parameter Id cannot be null";
    public static final String ERROR_VO_CANNOT_BE_NULL = "The VO cannot be null";
    public static final String ERROR_IN_PROCESS = "An error occurred in the process";

    // Application layer messages (Business validation)
    public static final String MISSING_REQUIRED_FIELD = "Missing required field";
    public static final String COLUMN_NAMES_MUST_BE_UNIQUE = "Column names must be unique";
    public static final String COLUMN_NAMES_CANNOT_HAVE_SPACES = "Column names cannot have spaces";
    public static final String TABLE_MUST_HAVE_ONE_SERVICE_CENTER_COLUMN = "Tables must have one service center column";
    public static final String TABLE_MUST_HAVE_ONE_POINT_OF_SALE_COLUMN_AT_MOST = "Tables cannot have more than one point of sale column";
    public static final String OPTION_COLUMN_MUST_HAVE_OPTIONS = "Column must have at least one option";
    public static final String DATA_TABLE_NAME_ALREADY_IN_USE_FOR_THIS_CAMPAIGN = "The table name is already in use for this campaign.";
    public static final String ERROR_CANNOT_CREATE_TABLE_WITH_NO_COLUMNS = "Cannot create a table with no columns";
    public static final String REQUIRED_COLUMN_CANNOT_BE_EMPTY = "Required field cannot be empty";
    public static final String ENUM_COLUMN_VALUE_MUST_MATCH_OPTIONS = "Enum column value must match options";
    public static final String DUPLICATE_METRIC_NAME = "Campaign already has a metric with given name";
    public static final String START_END_DATE_EXCEPTION = "Start date should be before or at end date";

    // Persistence layer messages (Data validation)
    public static final String ERROR_CANNOT_DELETE_METRIC_WITH_CHILDREN = "Cannot delete a metric with children";
    public static final String CANNOT_DELETE_CAMPAIGN_WITH_CHILDREN = "Cannot delete a campaign that has children";
    public static final String CANNOT_DELETE_CAMPAIGN_WITH_TABLES = "Cannot delete a campaign if it has tables";

    private final int errorCode;
    private final String errorMessage;
    public static final String ERROR_NOT_FOUND = "Not found";
    public static final String DUPLICATE_PRIMARY_KEY = "A row matching the same primary key already exists";
    public static final String ERROR_TOO_MANY_COLUMNS_OF_TYPE = "The limit of columns of this type has been exceeded";
    public static final String TABLE_NAME_CANNOT_HAVE_SPACES = "A table's name cannot contain spaces";
    public static final String DUPLICATE_GROUP_NAME = "Duplicated group name";
    public static final String TABLE_MUST_HAVE_ONE_DATA_FILE_COLUMN = "Tables cannot have more than one file column.";

    public BusinessException(String errorMessage, int errorCode) {
        super(errorMessage);
        this.errorMessage = errorMessage;
        this.errorCode = errorCode;
    }

    public BusinessException(String errorMessage, int errorCode, Throwable t) {
        super(t);
        this.errorMessage = errorMessage;
        this.errorCode = errorCode;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}
