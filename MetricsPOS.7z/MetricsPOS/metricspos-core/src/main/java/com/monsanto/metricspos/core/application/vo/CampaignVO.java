package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.CampaignState;

import java.util.Date;
import java.util.List;

/**
 * @author PPERA
 */
public class CampaignVO {
    private Integer id;
    private String name;
    private Date since;
    private Date until;
    private CampaignState state;
    private List<MetricVO> metrics;
    private List<DataTableVO> tables;
    private String serviceCenterLoadSql;
    private String serviceCenterLoadScript;
    private String pointOfSaleLoadSql;
    private String pointOfSaleLoadScript;
    private String employeeLoadSql;
    private String employeeLoadScript;
    private boolean scheduled;
    private String ratingFormula;
    private String ratingPremiumCategory;

    public CampaignVO(Campaign campaign, boolean withChildren) {
        this.id = campaign.getId();
        this.since = campaign.getSince();
        this.state = campaign.getState();
        this.until = campaign.getUntil();
        this.name = campaign.getName();
        this.serviceCenterLoadSql = campaign.getServiceCenterLoadSql();
        this.serviceCenterLoadScript = campaign.getServiceCenterLoadScript();
        this.pointOfSaleLoadSql = campaign.getPointOfSaleLoadSql();
        this.pointOfSaleLoadScript = campaign.getPointOfSaleLoadScript();
        this.employeeLoadSql = campaign.getEmployeeLoadSql();
        this.employeeLoadScript = campaign.getEmployeeLoadScript();
        this.scheduled = campaign.isScheduled();
        this.ratingFormula = campaign.getRatingFormula();
        this.ratingPremiumCategory = campaign.getRatingPremiumCategory();

        if (withChildren) {
            // remove
            this.metrics = MetricVO.makeMetricVOs(campaign.getMetrics(), true);

            if (campaign.getDataTables() != null) {
                this.tables = DataTableVO.makeDataTableVOs(campaign.getDataTables());
            }
        } else {
            this.metrics = Lists.newArrayList();
        }
    }

    public CampaignVO() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getSince() {
        return since;
    }

    public void setSince(Date since) {
        this.since = since;
    }

    public Date getUntil() {
        return until;
    }

    public void setUntil(Date until) {
        this.until = until;
    }

    public CampaignState getState() {
        return state;
    }

    public void setState(CampaignState state) {
        this.state = state;
    }

    public List<MetricVO> getMetrics() {
        return metrics;
    }

    public void setMetrics(List<MetricVO> metrics) {
        this.metrics = metrics;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public List<DataTableVO> getTables() {
        return tables;
    }

    public void setTables(List<DataTableVO> tables) {
        this.tables = tables;
    }

    public String getServiceCenterLoadSql() {
        return serviceCenterLoadSql;
    }

    public String getServiceCenterLoadScript() {
        return serviceCenterLoadScript;
    }

    public void setServiceCenterLoadSql(String serviceCenterLoadSql) {
        this.serviceCenterLoadSql = serviceCenterLoadSql;
    }

    public void setServiceCenterLoadScript(String serviceCenterLoadScript) {
        this.serviceCenterLoadScript = serviceCenterLoadScript;
    }

    public void setPointOfSaleLoadSql(String pointOfSaleLoadSql) {
        this.pointOfSaleLoadSql = pointOfSaleLoadSql;
    }

    public void setPointOfSaleLoadScript(String pointOfSaleLoadScript) {
        this.pointOfSaleLoadScript = pointOfSaleLoadScript;
    }

    public String getPointOfSaleLoadSql() {
        return pointOfSaleLoadSql;
    }

    public String getPointOfSaleLoadScript() {
        return pointOfSaleLoadScript;
    }

    public void setEmployeeLoadSql(String employeeLoadSql) {
        this.employeeLoadSql = employeeLoadSql;
    }

    public void setEmployeeLoadScript(String employeeLoadScript) {
        this.employeeLoadScript = employeeLoadScript;
    }

    public String getEmployeeLoadSql() {
        return employeeLoadSql;
    }

    public String getEmployeeLoadScript() {
        return employeeLoadScript;
    }

    public void setScheduled(boolean scheduled) {
        this.scheduled = scheduled;
    }

    public boolean isScheduled() {
        return scheduled;
    }

    public String getRatingFormula() {
        return ratingFormula;
    }

    public void setRatingFormula(String ratingFormula) {
        this.ratingFormula = ratingFormula;
    }

    public String getRatingPremiumCategory() {
        return ratingPremiumCategory;
    }

    public void setRatingPremiumCategory(String ratingPremiumCategory) {
        this.ratingPremiumCategory = ratingPremiumCategory;
    }

    public static List<CampaignVO> makeCampaignVOs(List<Campaign> campaigns) {
        return Lists.transform(campaigns, new Function<Campaign, CampaignVO>() {
            @Override
            public CampaignVO apply(Campaign input) {
                return new CampaignVO(input, false);
            }
        });
    }
}
