package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.externaldata.DataColumn;

import java.util.List;

/**
 * User: PPERA
 */
public class DataColumnVO {
    private Integer id;
    private String name;
    private String description;
    private String type;
    private Integer minSize;
    private Integer size;
    private Integer precision;
    private Boolean required;
    private Boolean sortable;
    private Boolean filterable;
    private Boolean hidden;
    private Boolean editable;
    private List<String> options;
    private String format;
    private Boolean primaryKey;
    private Boolean manual;

    private String label;

    public DataColumnVO() {
    }

    public DataColumnVO(DataColumn input) {
        this.id = input.getId();
        this.name = input.getName();
        this.description = input.getDescription();
        this.size = input.getMaxSize();
        this.minSize = input.getMinSize();
        this.precision = input.getPrecision();
        this.sortable = input.isSortable();
        this.required = input.isRequired();
        this.filterable = input.isFilterable();
        this.type = input.getDataType().getCode();
        this.editable = input.isEditable();
        this.format = input.getFormat();
        this.hidden = input.isHidden();
        this.options = input.getOptions();
        this.primaryKey = input.isPrimaryKey();
        this.manual = input.isManual();
        this.label = input.getLabel();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getMinSize() {
        return minSize;
    }

    public void setMinSize(Integer minSize) {
        this.minSize = minSize;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Integer getPrecision() {
        return precision;
    }

    public void setPrecision(Integer precision) {
        this.precision = precision;
    }

    public Boolean getRequired() {
        return required;
    }

    public void setRequired(Boolean required) {
        this.required = required;
    }

    public Boolean getSortable() {
        return sortable;
    }

    public void setSortable(Boolean sortable) {
        this.sortable = sortable;
    }

    public Boolean getFilterable() {
        return filterable;
    }

    public void setFilterable(Boolean filterable) {
        this.filterable = filterable;
    }

    public List<String> getOptions() {
        return options;
    }

    public void setOptions(List<String> options) {
        this.options = options;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public Boolean getEditable() {
        return editable;
    }

    public void setEditable(Boolean editable) {
        this.editable = editable;
    }

    public Boolean getPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(Boolean primaryKey) {
        this.primaryKey = primaryKey;
    }

    public Boolean getHidden() {
        return hidden;
    }

    public void setHidden(Boolean hidden) {
        this.hidden = hidden;
    }

    public void setManual(Boolean manual) {
        this.manual = manual;
    }

    public Boolean isManual() {
        return manual;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public static List<DataColumnVO> makeDataColumnVOs(List<DataColumn> columns) {
        return Lists.transform(columns, new Function<DataColumn, DataColumnVO>() {
            @Override
            public DataColumnVO apply(DataColumn input) {
                return new DataColumnVO(input);
            }
        });
    }
}