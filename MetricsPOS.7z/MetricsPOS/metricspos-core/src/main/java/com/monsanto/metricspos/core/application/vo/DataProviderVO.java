package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.externaldata.DataProvider;

import java.util.List;

/**
 * User: PPERA
 */
public class DataProviderVO {
    private String code;
    private String name;

    public DataProviderVO(DataProvider dataProvider){
        this.code = dataProvider.getCode();
        this.name = dataProvider.getName();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static List<DataProviderVO> makeDataProviderVOs(List<DataProvider> dataProviders) {
        return Lists.transform(dataProviders, new Function<DataProvider, DataProviderVO>() {
            @Override
            public DataProviderVO apply(DataProvider input) {
                return new DataProviderVO(input);
            }
        });
    }
}
