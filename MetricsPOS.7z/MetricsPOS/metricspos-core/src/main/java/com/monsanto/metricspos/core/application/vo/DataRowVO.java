package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataFile;
import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.util.HashMap;
import java.util.List;

/**
 * User: PPERA
 */
public class DataRowVO extends HashMap<String, Object> {
    public static final String ROW_ID_KEY = "mpsInternalId";
    public static final String ROW_MANUAL = "manual";

    public DataRowVO(DataRow dataRow) {
        this.put(ROW_ID_KEY, dataRow.getInternalId());
        this.put(ROW_MANUAL, dataRow.getManual());

        for (DataColumn column : dataRow.getDataTable().getColumns()) {
            if (column.getDataType().getInternalType().equals(ServiceCenter.class)) {
                this.put(column.getName(), dataRow.getServiceCenter().getCuit());
            } else if (column.getDataType().getInternalType().equals(PointOfSale.class)) {
                this.put(column.getName(), dataRow.getPointOfSale() != null ? dataRow.getPointOfSale().getIdSap() : null);
            } else if (column.getDataType().getInternalType().equals(DataFile.class)) {
                this.put(column.getName(), dataRow.getDataFile() != null ?
                    (dataRow.getDataFile().getFileData() != null ?  dataRow.getDataFile().getFileName() : null ) : null);
            } else {
                this.put(column.getName(), dataRow.get(column.getName()));
            }
        }
    }

    public static List<DataRowVO> makeDataRowVOs(List<DataRow> dataRows) {
        return Lists.transform(dataRows, new Function<DataRow, DataRowVO>() {
            @Override
            public DataRowVO apply(DataRow input) {
                return new DataRowVO(input);
            }
        });
    }
}
