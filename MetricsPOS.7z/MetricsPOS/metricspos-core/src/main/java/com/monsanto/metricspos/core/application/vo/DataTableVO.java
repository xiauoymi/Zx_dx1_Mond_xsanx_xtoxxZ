package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.externaldata.DataTable;

import java.util.Date;
import java.util.List;

/**
 * Value object (memento) for DataTable.
 *
 * @author CAFAU
 */
public class DataTableVO {
    private Integer id;
    private String name;
    private String description;
    private String provider;
    private int campaignId;
    private boolean allowRecordCreation;
    private String loadSql;
    private String loadScript;
    private boolean scheduled;
    private List<DataColumnVO> columns;
    private List<MetricVO> metrics;
    private boolean lastRunSucceed;
    private Date lastUpdate;
    private boolean includeData;

    // private Collection<MetricVO> metrics;

    public DataTableVO() {
    }

    public DataTableVO(DataTable dataTable) {
        this.id = dataTable.getId();
        this.description = dataTable.getDescription();
        this.name = dataTable.getName();
        this.provider = dataTable.getDataProvider() != null? dataTable.getDataProvider().getCode() : null;
        this.campaignId = dataTable.getCampaign().getId();
        this.allowRecordCreation = dataTable.getAllowRecordCreation();
        this.loadSql = dataTable.getLoadSql();
        this.loadScript = dataTable.getLoadScript();
        this.scheduled = dataTable.isScheduled();
        this.lastRunSucceed = dataTable.isLastRunSucceed() != null ? dataTable.isLastRunSucceed() : false;
        this.lastUpdate = dataTable.getLastUpdate();
        this.includeData = dataTable.getIncludeData();

        if (dataTable.getColumns() != null) {
            this.columns = DataColumnVO.makeDataColumnVOs(dataTable.getColumns());
        }
    }

    public DataTableVO(DataTable dataTable, boolean withMetrics) {
        this(dataTable);

        if (withMetrics && dataTable.getMetrics() != null) {
            this.metrics = MetricVO.makeMetricVOs(dataTable.getMetrics(), false);
        }
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public int getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(int campaignId) {
        this.campaignId = campaignId;
    }

    public Boolean getAllowRecordCreation() {
        return allowRecordCreation;
    }

    public void setAllowRecordCreation(Boolean allowRecordCreation) {
        this.allowRecordCreation = allowRecordCreation;
    }

    public void setLoadSql(String loadSql) {
        this.loadSql = loadSql;
    }

    public void setLoadScript(String loadScript) {
        this.loadScript = loadScript;
    }

    public String getLoadSql() {
        return loadSql;
    }

    public String getLoadScript() {
        return loadScript;
    }

    public boolean isScheduled() {
        return scheduled;
    }

    public void setScheduled(boolean scheduled) {
        this.scheduled = scheduled;
    }

    public List<DataColumnVO> getColumns() {
        return columns;
    }

    public void setColumns(List<DataColumnVO> columns) {
        this.columns = columns;
    }

    public List<MetricVO> getMetrics() {
        return metrics;
    }

    public void setMetrics(List<MetricVO> metrics) {
        this.metrics = metrics;
    }

    public boolean isLastRunSucceed() {
        return lastRunSucceed;
    }

    public void setLastRunSucceed(boolean lastRunSucceed) {
        this.lastRunSucceed = lastRunSucceed;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public boolean isIncludeData() {
        return includeData;
    }

    public void setIncludeData(boolean includeData) {
        this.includeData = includeData;
    }

    public static List<DataTableVO> makeDataTableVOs(List<DataTable> dataTables) {
        return Lists.transform(dataTables, new Function<DataTable, DataTableVO>() {
            @Override
            public DataTableVO apply(DataTable input) {
                return new DataTableVO(input);
            }
        });
    }
}
