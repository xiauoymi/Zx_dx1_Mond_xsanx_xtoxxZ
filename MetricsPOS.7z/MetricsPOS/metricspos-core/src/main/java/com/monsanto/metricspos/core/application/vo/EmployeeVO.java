package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.structure.Employee;

import java.util.List;

/**
 * User: PPERA
 */
public class EmployeeVO {
    private Long id;
    private Integer campaignId;
    private String name;
    private String username;
    private boolean enabled;
    private List<GroupVO> groups;
    private List<MetricVO> metrics;
    private List<ServiceCenterVO> serviceCenters;

    public EmployeeVO(Employee employee) {
        this.id = employee.getId();
        this.campaignId = employee.getCampaign().getId();
        this.name = employee.getName();
        this.username = employee.getUsername();
        this.enabled = employee.isEnabled();

        if (employee.getGroups() != null) {
            this.groups = GroupVO.makeGroupVOs(employee.getGroups());
        }
        if (employee.getMetrics() != null) {
            this.metrics = MetricVO.makeMetricVOs(employee.getMetrics(), false);
        }
        if (employee.getMetrics() != null) {
            this.serviceCenters = ServiceCenterVO.makeServiceCenterVOs(employee.getServiceCenters());
        }
    }

    public EmployeeVO() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Integer campaignId) {
        this.campaignId = campaignId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public List<GroupVO> getGroups() {
        return groups;
    }

    public void setGroups(List<GroupVO> groups) {
        this.groups = groups;
    }

    public List<MetricVO> getMetrics() {
        return metrics;
    }

    public void setMetrics(List<MetricVO> metrics) {
        this.metrics = metrics;
    }

    public List<ServiceCenterVO> getServiceCenters() {
        return serviceCenters;
    }

    public void setServiceCenters(List<ServiceCenterVO> serviceCenters) {
        this.serviceCenters = serviceCenters;
    }

    public static List<EmployeeVO> makeEmployeeVOs(List<Employee> employees) {
        return Lists.transform(employees, new Function<Employee, EmployeeVO>() {
            @Override
            public EmployeeVO apply(Employee input) {
                return new EmployeeVO(input);
            }
        });
    }

    @Override
    public String toString() {
        return "EmployeeVO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", username='" + username + '\'' +
                ", enabled=" + enabled +
                ", campaignId=" + campaignId +
                '}';
    }
}
