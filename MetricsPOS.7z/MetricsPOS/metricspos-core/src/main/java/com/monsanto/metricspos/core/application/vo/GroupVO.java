package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.security.Authority;
import com.monsanto.metricspos.core.security.Group;

import java.util.List;

/**
 * User: PPERA
 */
public class GroupVO {
    private Integer id;
    private String name;
    private boolean enabled;
    private List<Authority> authorities;

    public GroupVO(Group group) {
        this.id = group.getId();
        this.name = group.getName();
        this.enabled = group.isEnabled();
        this.authorities = group.getAuthorities();
    }

    public GroupVO() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public static List<GroupVO> makeGroupVOs(List<Group> groups) {
        return Lists.transform(groups, new Function<Group, GroupVO>() {
            @Override
            public GroupVO apply(Group group) {
                return new GroupVO(group);
            }
        });
    }

    public List<Authority> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(List<Authority> authorities) {
        this.authorities = authorities;
    }

    @Override
    public String toString() {
        return "GroupVO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", enabled=" + enabled +
                '}';
    }
}
