package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.metrics.MetricScore;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * User: PPERA
 */
public class MetricScoreVO {
    private Integer id;
    private ServiceCenterVO serviceCenter;
    private BigDecimal points;
    private BigDecimal penalty;
    private BigDecimal penaltyFactor;
    private Integer metricId;
    private MetricVO module;
    private MetricVO metric;
    private MetricVO submetric;
    private boolean noData;
    private boolean dirty;
    public static final String SERVICE_CENTER_COLUMN = "serviceCenter";
    private Date lastUpdated;

    // used when exported to excel
    private String serviceCenterName;
    private String serviceCenterCuit;
    private String moduleName;
    private String metricName;
    private String submetricName;

    public MetricScoreVO() {
    }

    public MetricScoreVO(MetricScore input) {
        this.id = input.getId();
        this.metricId = input.getMetric().getId();
        this.submetric = new MetricVO(input.getMetric(), false);
        this.metric = new MetricVO(input.getMetric().getParent(), false);
        this.module = new MetricVO(input.getMetric().getParent().getParent(), false);
        this.noData = input.isNoData();
        this.penalty = input.getPenalty();
        this.penaltyFactor = input.getPenaltyFactor();
        this.points = input.getPoints();
        this.serviceCenter = new ServiceCenterVO(input.getServiceCenter(), false);
        this.lastUpdated = input.getLastUpdated();
        this.dirty = input.isDirty();

        this.serviceCenterName = this.serviceCenter.getName();
        this.serviceCenterCuit = this.serviceCenter.getCuit();
        this.moduleName = this.module.getName();
        this.metricName = this.metric.getName();
        this.submetricName = this.submetric.getName();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public ServiceCenterVO getServiceCenter() {
        return serviceCenter;
    }

    public void setServiceCenter(ServiceCenterVO serviceCenter) {
        this.serviceCenter = serviceCenter;
    }

    public BigDecimal getPoints() {
        return points;
    }

    public void setPoints(BigDecimal points) {
        this.points = points;
    }

    public BigDecimal getPenalty() {
        return penalty;
    }

    public void setPenalty(BigDecimal penalty) {
        this.penalty = penalty;
    }

    public BigDecimal getPenaltyFactor() {
        return penaltyFactor;
    }

    public void setPenaltyFactor(BigDecimal penaltyFactor) {
        this.penaltyFactor = penaltyFactor;
    }

    public Integer getMetricId() {
        return metricId;
    }

    public void setMetricId(Integer metricId) {
        this.metricId = metricId;
    }

    public boolean isNoData() {
        return noData;
    }

    public void setNoData(boolean noData) {
        this.noData = noData;
    }

    public MetricVO getModule() {
        return module;
    }

    public void setModule(MetricVO module) {
        this.module = module;
    }

    public MetricVO getMetric() {
        return metric;
    }

    public void setMetric(MetricVO metric) {
        this.metric = metric;
    }

    public MetricVO getSubmetric() {
        return submetric;
    }

    public void setSubmetric(MetricVO submetric) {
        this.submetric = submetric;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public boolean isDirty() {
        return dirty;
    }

    public void setDirty(boolean dirty) {
        this.dirty = dirty;
    }

    public String getServiceCenterName() {
        return serviceCenterName;
    }

    public String getServiceCenterCuit() {
        return serviceCenterCuit;
    }

    public String getModuleName() {
        return moduleName;
    }

    public String getMetricName() {
        return metricName;
    }

    public String getSubmetricName() {
        return submetricName;
    }

    public static List<MetricScoreVO> makeMetricScoreVOs(List<MetricScore> scores) {
        return Lists.transform(scores, new Function<MetricScore, MetricScoreVO>() {
            @Override
            public MetricScoreVO apply(MetricScore input) {
                return new MetricScoreVO(input);
            }
        });
    }
}
