package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.metrics.Metric;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author ppera
 */
public class MetricVO {
    private Integer id;
    private String name;
    private Boolean enabled;
    private Boolean scheduled;
    private String formula;
    private int campaignId;
    private String moduleFormulaResult;
    private Boolean send;
    private List<DataTableVO> tables;
    private BigDecimal deductions;

    //TODO not tested yet
    private Integer maxPoints;

    private List<MetricVO> metrics;

    private String owner;
    private String explanation;

    private Integer type;

    private Boolean isWeighting;

    public MetricVO(Metric metric, boolean withChildren) {
        this.name = metric.getName();
        this.id = metric.getId();
        this.enabled = metric.isEnabled();
        this.formula = metric.getFormula();
        this.campaignId = metric.getCampaign().getId();
        this.maxPoints = metric.getMaxPoints();
        this.scheduled = metric.isScheduled();
        this.owner = metric.getOwner();
        this.send = metric.getSend();
        this.explanation = metric.getExplanation();
        this.isWeighting = metric.getWeighting();
        this.type = (null != metric.getType()) ? metric.getType() : 0;

        if (withChildren) {
            this.metrics = makeMetricVOs(metric.getMetrics(), true);
        } else {
            this.metrics = Lists.newArrayList();
        }
    }

    public MetricVO() {
    }

    public MetricVO(Metric metric, boolean withChildren, boolean withTables) {
        this(metric, withChildren);
        if (withTables && metric.getTables() != null) {
            this.tables = DataTableVO.makeDataTableVOs(metric.getTables());
        } else {
            this.tables = Lists.newArrayList();
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<MetricVO> getMetrics() {
        return metrics;
    }

    public void setMetrics(List<MetricVO> metrics) {
        this.metrics = metrics;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public Boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public Boolean isScheduled() {
        return scheduled;
    }

    public void setScheduled(Boolean scheduled) {
        this.scheduled = scheduled;
    }

    public int getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(int campaignId) {
        this.campaignId = campaignId;
    }

    public Integer getMaxPoints() {
        return maxPoints;
    }

    public void setMaxPoints(Integer maxPoints) {
        this.maxPoints = maxPoints;
    }

    public List<DataTableVO> getTables() {
        return tables;
    }

    public void setTables(List<DataTableVO> tables) {
        this.tables = tables;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public Boolean getSend() {
        return send;
    }

    public void setSend(Boolean send) {
        this.send = send;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public static List<MetricVO> makeMetricVOs(List<Metric> metrics, final boolean withChildren) {
        if(metrics!= null && !metrics.isEmpty()){
            return Lists.transform(metrics, new Function<Metric, MetricVO>() {
                @Override
                public MetricVO apply(Metric metric) {
                    return new MetricVO(metric, withChildren);
                }
            });
        }else{
            return Lists.newArrayList();
        }

    }


    public String getModuleFormulaResult() {
        return moduleFormulaResult;
    }

    public void setModuleFormulaResult(String result) {
        moduleFormulaResult = result;
    }

    public BigDecimal getDeductions() {
        return deductions;
    }

    public void setDeductions(BigDecimal deductions) {
        this.deductions = deductions;
    }

    public Boolean getIsWeighting() {
        return isWeighting;
    }

    public void setIsWeighting(Boolean weighting) {
        isWeighting = weighting;
    }

    @Override
    public String toString() {
        return "MetricVO{" +
                "maxPoints=" + maxPoints +
                ", campaignId=" + campaignId +
                ", formula='" + formula + '\'' +
                ", scheduled=" + scheduled +
                ", enabled=" + enabled +
                ", name='" + name + '\'' +
                ", id=" + id +
                "}";
    }
}
