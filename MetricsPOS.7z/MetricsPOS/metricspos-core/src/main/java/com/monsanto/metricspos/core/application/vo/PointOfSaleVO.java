package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.structure.PointOfSale;

import java.util.List;

/**
 * User: PPERA
 */
public class PointOfSaleVO {
    public static final String ID_SAP_COLUMN = "idSap";

    private Long idSap;
    private String salesGroup;
    private String region;
    private String type;
    private Long tsrcId;
    private String customer;
    private String locality;
    private String county;
    private String state;
    private String address;
    private String phone;
    private String mail;
    private String serviceCenter;

    public PointOfSaleVO() {

    }

    public PointOfSaleVO(PointOfSale input) {
        this.address = input.getAddress();
        this.county = input.getCounty();
        this.customer = input.getCustomer();
        this.idSap = input.getIdSap();
        this.locality = input.getLocality();
        this.mail = input.getMail();
        this.phone = input.getPhone();
        this.region = input.getRegion();
        this.salesGroup = input.getSalesGroup();
        this.serviceCenter = input.getServiceCenter().getCuit();
        this.state = input.getState();
        this.tsrcId = input.getTsrcId();
        this.type = input.getType();
    }

    public Long getIdSap() {
        return idSap;
    }

    public void setIdSap(Long idSap) {
        this.idSap = idSap;
    }

    public String getSalesGroup() {
        return salesGroup;
    }

    public void setSalesGroup(String salesGroup) {
        this.salesGroup = salesGroup;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Long getTsrcId() {
        return tsrcId;
    }

    public void setTsrcId(Long tsrcId) {
        this.tsrcId = tsrcId;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getServiceCenter() {
        return serviceCenter;
    }

    public void setServiceCenter(String serviceCenter) {
        this.serviceCenter = serviceCenter;
    }

    public static List<PointOfSaleVO> makePointOfSaleVOs(List<PointOfSale> pointOfSales) {
        return Lists.transform(pointOfSales, new Function<PointOfSale, PointOfSaleVO>() {
            @Override
            public PointOfSaleVO apply(PointOfSale input) {
                return new PointOfSaleVO(input);
            }
        });
    }

    @Override
    public String toString() {
        return "PointOfSaleVO{" +
                "idSap=" + idSap +
                ", salesGroup='" + salesGroup + '\'' +
                ", region='" + region + '\'' +
                ", type='" + type + '\'' +
                ", tsrcId=" + tsrcId +
                ", customer='" + customer + '\'' +
                ", locality='" + locality + '\'' +
                ", county='" + county + '\'' +
                ", state='" + state + '\'' +
                ", address='" + address + '\'' +
                ", phone='" + phone + '\'' +
                ", mail='" + mail + '\'' +
                ", serviceCenter='" + serviceCenter + '\'' +
                '}';
    }
}
