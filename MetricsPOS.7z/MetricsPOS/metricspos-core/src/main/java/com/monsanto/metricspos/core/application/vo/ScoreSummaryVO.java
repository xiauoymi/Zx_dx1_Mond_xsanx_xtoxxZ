package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummary;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryNode;

import java.math.BigDecimal;
import java.util.List;

/**
 * User: PPERA
 */
public class ScoreSummaryVO {
    private BigDecimal points;
    private Integer maxPoints;
    private BigDecimal deductions;
    private String percentageIncent;

    private List<ScoreSummaryVO> children;
    private MetricVO metric;
    private Boolean computeError;
    private String rating;

    public ScoreSummaryVO(ScoreSummaryCampaignNode scoreSummaryCampaignNode) {
        this.points = scoreSummaryCampaignNode.getPoints();
        this.maxPoints = scoreSummaryCampaignNode.getMaxPoints();
        this.rating = scoreSummaryCampaignNode.getRating();

        this.children = Lists.transform(scoreSummaryCampaignNode.getChildren(), new Function<ScoreSummaryNode, ScoreSummaryVO>() {
            @Override
            public ScoreSummaryVO apply(ScoreSummaryNode input) {
                return new ScoreSummaryVO(input);
            }
        });
        initializeDeductions(scoreSummaryCampaignNode);
    }

    private void initializeDeductions(ScoreSummary scoreSummaryNode) {
        this.deductions = scoreSummaryNode.getDeductions();
    }

    private ScoreSummaryVO(ScoreSummaryNode scoreSummaryNode) {
        this.points = scoreSummaryNode.getPoints();
        this.maxPoints = scoreSummaryNode.getMaxPoints();
        this.metric = new MetricVO(scoreSummaryNode.getMetric(), false);
        this.computeError = scoreSummaryNode.getComputeError();

        this.children = Lists.transform(scoreSummaryNode.getChildren(), new Function<ScoreSummaryNode, ScoreSummaryVO>() {
            @Override
            public ScoreSummaryVO apply(ScoreSummaryNode input) {
                return new ScoreSummaryVO(input);
            }
        });
        initializeDeductions(scoreSummaryNode);
        scoreSummaryNode.getMetric().computeModuleFormula(scoreSummaryNode);
        this.percentageIncent = scoreSummaryNode.getPercentageIncent();
    }

    public BigDecimal getPoints() {
        return points;
    }

    public void setPoints(BigDecimal points) {
        this.points = points;
    }

    public Integer getMaxPoints() {
        return maxPoints;
    }

    public void setMaxPoints(Integer maxPoints) {
        this.maxPoints = maxPoints;
    }

    public List<ScoreSummaryVO> getChildren() {
        return children;
    }

    public void setChildren(List<ScoreSummaryVO> children) {
        this.children = children;
    }

    public MetricVO getMetric() {
        return metric;
    }

    public Boolean getComputeError() {
        return computeError;
    }

    public String getRating() {
        return rating;
    }

    public BigDecimal getDeductions() {
        return deductions;
    }

    public void setDeductions(BigDecimal deductions) {
        this.deductions = deductions;
    }

    public String getPercentageIncent() {
        return percentageIncent;
    }

}
