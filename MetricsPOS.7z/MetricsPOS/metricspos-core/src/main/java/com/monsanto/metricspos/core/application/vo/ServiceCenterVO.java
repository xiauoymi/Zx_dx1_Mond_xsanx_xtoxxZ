package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.util.Date;
import java.util.List;

/**
 * User: PPERA
 */
public class ServiceCenterVO {
    private String cuit;
    private String name;
    private String mail;
    private Integer campaign;
    private Date lastTimeSent;
    private List<PointOfSaleVO> pointsOfSale;
    public static final String CUIT_COLUMN = "cuit";

    public ServiceCenterVO() {
    }

    public ServiceCenterVO(ServiceCenter serviceCenter, boolean withChildren) {
        this.cuit = serviceCenter.getCuit();
        this.name = serviceCenter.getName();
        this.mail = serviceCenter.getMail();
        this.lastTimeSent = serviceCenter.getLastTimeSent();
        this.campaign = serviceCenter.getCampaign().getId();

        if (withChildren && serviceCenter.getPointsOfSale() != null) {
            this.pointsOfSale = PointOfSaleVO.makePointOfSaleVOs(serviceCenter.getPointsOfSale());
        }
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public Integer getCampaign() {
        return campaign;
    }

    public void setCampaign(Integer campaign) {
        this.campaign = campaign;
    }

    public Date getLastTimeSent() {
        return lastTimeSent;
    }

    public void setLastTimeSent(Date lastTimeSent) {
        this.lastTimeSent = lastTimeSent;
    }

    public List<PointOfSaleVO> getPointsOfSale() {
        return pointsOfSale;
    }

    public void setPointsOfSale(List<PointOfSaleVO> pointsOfSale) {
        this.pointsOfSale = pointsOfSale;
    }

    public static List<ServiceCenterVO> makeServiceCenterVOs(List<ServiceCenter> serviceCenters) {
        return Lists.transform(serviceCenters, new Function<ServiceCenter, ServiceCenterVO>() {
            @Override
            public ServiceCenterVO apply(ServiceCenter input) {
                return new ServiceCenterVO(input, false);
            }
        });
    }
}
