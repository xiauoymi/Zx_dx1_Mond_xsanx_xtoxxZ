package com.monsanto.metricspos.core.application.vo.converter;

import com.monsanto.metricspos.core.application.vo.DataColumnVO;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataType;
import org.springframework.core.convert.converter.Converter;

import javax.annotation.Resource;
import java.util.Map;

/**
 * Converts a DataColumnVO to a DataColumn
 *
 * User: PPERA
 */
public class DataColumnVO2DataColumnConverter implements Converter<DataColumnVO, DataColumn> {
    @Resource(name = "dataTypeMap")
    private Map<String, DataType> dataTypeMap;

    @Override
    public DataColumn convert(DataColumnVO dataColumnVO) {
        DataColumn dataColumn = new DataColumn();

        dataColumn.setId(dataColumnVO.getId());
        dataColumn.setName(dataColumnVO.getName());
        dataColumn.setFilterable(dataColumnVO.getFilterable() != null ? dataColumnVO.getFilterable() : false);
        dataColumn.setSortable(dataColumnVO.getSortable() != null ? dataColumnVO.getSortable() : false);
        dataColumn.setRequired(dataColumnVO.getRequired() != null ? dataColumnVO.getRequired() : false);
        dataColumn.setDescription(dataColumnVO.getDescription());
        dataColumn.setMinSize(dataColumnVO.getMinSize());
        dataColumn.setMaxSize(dataColumnVO.getSize());
        dataColumn.setFormat(dataColumnVO.getFormat());
        dataColumn.setOptions(dataColumnVO.getOptions());
        dataColumn.setPrecision(dataColumnVO.getPrecision());
        dataColumn.setEditable(dataColumnVO.getEditable() != null ? dataColumnVO.getEditable() : false);
        dataColumn.setHidden(dataColumnVO.getHidden() != null ? dataColumnVO.getHidden() : false);
        dataColumn.setPrimaryKey(dataColumnVO.getPrimaryKey() != null ? dataColumnVO.getPrimaryKey() : false);
        dataColumn.setManual(dataColumnVO.isManual() != null ? dataColumnVO.isManual() : false);

        DataType dataType = dataTypeMap.get(dataColumnVO.getType());

        dataColumn.setDataType(dataType);

        dataColumn.setLabel(dataColumnVO.getLabel());
        return dataColumn;
    }

    public void setDataTypeMap(Map<String,DataType> dataTypeMap) {
        this.dataTypeMap = dataTypeMap;
    }
}
