package com.monsanto.metricspos.core.externaldata;

import com.google.common.base.Objects;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.monsanto.metricspos.core.externaldata.restrictions.Restriction;
import org.springframework.beans.factory.annotation.Configurable;

import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * Represents an atomic definition of a fragment of a tabular entity. It holds the name of the attribute
 * and the data-type it holds
 *
 * @author PPERA
 */
@Configurable
public class DataColumn<T>{
    public static final String ERROR_CANNOT_CREATE_COLUMN_WITH_NO_DATA_TYPE = "Cannot create column with no data type";
    public static final String ERROR_CANNOT_CREATE_COLUMN_WITH_NO_NAME = "Cannot create a column with no name";
    public static final String ERROR_SPECIFIED_RESTRICTIONS_CANNOT_BE_NULL = "Specified restrictions cannot be null";

    private Integer id;
    private String name;
    private String description;
    private DataType dataType;

    private Integer minSize;
    private Integer maxSize;
    private Integer precision;
    private boolean required;
    private boolean sortable;
    private boolean filterable;
    private List<String> options;
    private String format;

    private Set<Restriction<T>> restrictions;
    private boolean editable;
    private boolean hidden;
    private boolean primaryKey;
    private String actualColumnName;
    private boolean manual;

    private String label;


    public DataColumn() {

    }

    public DataColumn(String name, DataType dataType, Set<Restriction<T>> restrictions) {
        this(name, dataType);

        if (restrictions == null || restrictions.contains(null)) {
            throw new RuntimeException(ERROR_SPECIFIED_RESTRICTIONS_CANNOT_BE_NULL);
        }

        this.restrictions = restrictions;
    }

    public DataColumn(String name, DataType dataType) {
        if (dataType == null) {
            throw new RuntimeException(ERROR_CANNOT_CREATE_COLUMN_WITH_NO_DATA_TYPE);
        }

        if (name == null) {
            throw new RuntimeException(ERROR_CANNOT_CREATE_COLUMN_WITH_NO_NAME);
        }

        this.dataType = dataType;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    protected Set<Restriction<T>> getRestrictions() {
        return restrictions;
    }

    /**
     * Validates the value to be set in a column against that columns restrictions
     *
     * @param value
     * @return
     */
    boolean passesRestrictions(final T value) {
        Collection<Restriction<T>> passedRestrictions = Collections2.filter(this.getRestrictions(), new Predicate<Restriction<T>>() {
            public boolean apply(Restriction<T> input) {
                return input != null && input.passes(value);
            }
        });

        return passedRestrictions.containsAll(this.getRestrictions());
    }

    boolean hasRestrictions() {
        return restrictions != null && !restrictions.isEmpty();
    }

    public DataType getDataType() {
        return dataType;
    }

    public void setDataType(DataType dataType) {
        this.dataType = dataType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DataColumn that = (DataColumn) o;

        return Objects.equal(this.getDataType(), that.getDataType()) &&
                Objects.equal(name, that.name) &&
                Objects.equal(restrictions, that.restrictions);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, restrictions, this.getDataType());
    }

    public void checkIfAssignable(Object value) {
        if (hasRestrictions() && !passesRestrictions((T) value)) {
            throw new RuntimeException(Restriction.ERROR_RESTRICTION_VIOLATION);
        }
    }


    public void setName(String name) {
        this.name = name;
    }

    public void setMinSize(Integer minSize) {
        this.minSize = minSize;
    }

    public void setMaxSize(Integer maxSize) {
        this.maxSize = maxSize;
    }

    public List<String> getOptions() {
        return options;
    }

    public void setOptions(List<String> options) {
        this.options = options;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public Integer getMaxSize() {
        return maxSize;
    }

    public Integer getMinSize() {
        return minSize;
    }

    public Integer getPrecision() {
        return precision;
    }

    public void setPrecision(Integer precision) {
        this.precision = precision;
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public boolean isSortable() {
        return sortable;
    }

    public void setSortable(boolean sortable) {
        this.sortable = sortable;
    }

    public boolean isFilterable() {
        return filterable;
    }

    public void setFilterable(boolean filterable) {
        this.filterable = filterable;
    }

    public boolean isEditable() {
        return editable;
    }

    public void setEditable(boolean editable) {
        this.editable = editable;
    }

    public boolean isHidden() {
        return hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    public boolean isPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(boolean primaryKey) {
        this.primaryKey = primaryKey;
    }

    public boolean getRequired() {
        return required;
    }

    public String getActualColumnName() {
        return actualColumnName;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setActualColumnName(String actualColumnName) {
        this.actualColumnName = actualColumnName;
    }

    public boolean isManual() {
        return manual;
    }

    public void setManual(boolean manual) {
        this.manual = manual;
    }

    public void merge(DataColumn updated) {
        if (!this.dataType.getCode().equals(updated.getDataType().getCode())) {
            this.actualColumnName = null;
        }

        this.dataType = updated.getDataType();
        this.description = updated.getDescription();
        this.editable = updated.isEditable();
        this.filterable = updated.isFilterable();
        this.format = updated.getFormat();
        this.hidden = updated.isHidden();
        this.maxSize = updated.getMaxSize();
        this.minSize = updated.getMinSize();
        this.name = updated.getName();
        this.options = updated.getOptions();
        this.precision = updated.getPrecision();
        this.primaryKey = updated.isPrimaryKey();
        this.required = updated.isRequired();
        this.sortable = updated.isSortable();
        this.manual = updated.isManual();
        this.label = updated.getLabel();
    }
}
