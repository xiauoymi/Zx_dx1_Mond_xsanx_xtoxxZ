package com.monsanto.metricspos.core.externaldata;

import java.io.Serializable;

/**
 * An auxiliary type that groups the attributes of the file: name and data
 *
 * User: LOSICL
 */
public class DataFile implements Serializable {

    private String fileName;
    private byte[] fileData;

    public DataFile(String fileName, byte[] fileData) {
        this.fileName = fileName;
        this.fileData = fileData;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public byte[] getFileData() {
        return fileData;
    }

    public void setFileData(byte[] fileData) {
        this.fileData = fileData;
    }
}
