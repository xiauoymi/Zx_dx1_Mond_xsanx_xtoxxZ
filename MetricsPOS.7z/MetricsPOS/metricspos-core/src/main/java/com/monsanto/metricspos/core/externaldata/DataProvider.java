package com.monsanto.metricspos.core.externaldata;

import javax.sql.DataSource;

/**
 * Represents a source of data for the data tables
 *
 * User: PPERA
 */
public class DataProvider {
    private String code;
    private String name;
    private DataSource dataSource;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }
}
