package com.monsanto.metricspos.core.externaldata;

import com.google.common.base.Objects;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistor;

import java.util.List;
import java.util.Map;

/**
 * Represents a single row in data table
 *
 * @author PPERA
 */
public class DataRow {
    private final DataTable dataTable;
    private Object rowValues;
    private final DataRowPersistor dataRowPersistor;

    DataRow(DataTable dataTable) {
        this(dataTable, dataTable.getDataRowPersistor().newRowValues());
    }

    public DataRow(DataTable dataTable, Object rowValues) {
        this.dataTable = dataTable;
        this.dataRowPersistor = dataTable.getDataRowPersistor();
        this.rowValues = rowValues;
    }

    public Object getRowValues() {  // TODO Kill me
        return rowValues;
    }

    public DataTable getDataTable() {
        return dataTable;
    }


    /**
     * Sets the provided value to the column with the given defined columnName
     *
     * @param columnName defined by the DataTable
     * @param value      to be set
     */
    public void set(String columnName, Object value) {
        DataColumn column = dataTable.getColumn(columnName);

        column.checkIfAssignable(value);

        dataRowPersistor.set(rowValues, columnName, value); // TODO Should pass "column name" or "column"??
    }

    /**
     * The value to which the column is set
     *
     * @param columnName defined in the DataTable.
     * @return the value of the column for this row.
     */
    public Object get(String columnName) {
        return dataRowPersistor.get(rowValues, columnName);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DataRow dataRow = (DataRow) o;

        return Objects.equal(dataTable, dataRow.dataTable) &&
                Objects.equal(rowValues, dataRow.rowValues);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(dataTable, rowValues);
    }

    public Class<?> getTypeFor(String fieldName) {
        return dataTable.getTypeFor(fieldName);
    }

    public Integer getInternalId() {
        return dataRowPersistor.getInternalId(this.getRowValues());
    }

    public void update(Map<String, Object> rowData) {
        List<String> columnNames = this.dataTable.getColumnNames();

        for (String columnName : columnNames) {
            if (rowData.containsKey(columnName)) {
                this.dataRowPersistor.set(this.getRowValues(), columnName, rowData.get(columnName));
            }
        }
    }

    public boolean getManual() {
        return this.dataRowPersistor.getManual(rowValues);
    }

    public void setManual(boolean manual) {
        dataRowPersistor.setManual(rowValues, manual);
    }

    public void setLoaded(boolean loaded) {
        dataRowPersistor.setLoaded(rowValues, loaded);
    }

    public ServiceCenter getServiceCenter() {
        return this.dataRowPersistor.getServiceCenter(rowValues);
    }

    public void setServiceCenter(ServiceCenter serviceCenter) {
        this.dataRowPersistor.setServiceCenter(rowValues, serviceCenter);
    }

    public PointOfSale getPointOfSale() {
        return dataRowPersistor.getPointOfSale(this.getRowValues());
    }

    public void setPointOfSale(PointOfSale pointOfSale) {
        this.dataRowPersistor.setPointOfSale(this.getRowValues(), pointOfSale);
    }

    public DataFile getDataFile() {
        return dataRowPersistor.getDataFile(this.getRowValues());
    }

    public void merge(DataRow dataRow) {
        for (DataColumn column : this.dataTable.getColumns()) {
            if (!column.isManual()) {
                this.set(column.getName(), dataRow.get(column.getName()));
            }
        }
    }

    public void setDeleted(boolean deleted) {
        dataRowPersistor.setDeleted(this.getRowValues(), deleted);
    }

    @Override
    public String toString() {
        return "DataRow{" +
                "rowValues=" + rowValues +
                ", dataTable=" + dataTable +
                '}';
    }
}
