package com.monsanto.metricspos.core.externaldata;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.DataRowVO;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistor;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import com.monsanto.metricspos.persistence.RowValuesServices;
import org.springframework.beans.factory.annotation.Configurable;

import java.util.*;


/**
 * Represents a dynamically defined tabular entity. It holds columns that can contain a specific Data-Type
 *
 * @author PPERA
 */
@Configurable
public class DataTable {
    /*Entity attributes*/
    private Integer id;
    private String name;
    private String description;

    private Campaign campaign;

    private List<DataColumn> columns;

    private DataProvider dataProvider;
    /**
     * Responsible for providing persistence functionality for the DataTable
     */
    private RowValuesServices rowValuesServices;
    private DataRowPersistor dataRowPersistor;
    private boolean allowRecordCreation;
    private String loadSql;
    private String loadScript;

    private Boolean scheduled = Boolean.FALSE;
    private Date lastUpdate;

    private Boolean lastRunSucceed;
    private Boolean includeData = Boolean.TRUE;

    private List<Metric> metrics;

    /**
     * Constructor for persistence
     */
    public DataTable() {
    }

    /**
     * Returns a data table identified by a name with it's defined columns
     *
     * @param name                    which identifies the DataTable
     * @param columns                 that compose the table
     * @param dataRowPersistorFactory
     */
    public DataTable(String name, List<DataColumn> columns, DataRowPersistorFactory dataRowPersistorFactory) {
        this.name = name;

        this.columns = columns;

        // Should be last
        dataRowPersistor = dataRowPersistorFactory.buildDataRowPersistor(this);
    }

    public void setDataRowPersistorFactory(DataRowPersistorFactory dataRowPersistorFactory) {
        dataRowPersistor = dataRowPersistorFactory.buildDataRowPersistor(this);
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public DataProvider getDataProvider() {
        return dataProvider;
    }

    public void setDataProvider(DataProvider dataProvider) {
        this.dataProvider = dataProvider;
    }

    public DataRowPersistor getDataRowPersistor() {
        return dataRowPersistor;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }


    public List<DataColumn> getColumns() {
        return columns;
    }

    public void setColumns(List<DataColumn> columns) {
        this.columns = columns;
    }

    public void setRowValuesServices(RowValuesServices rowValuesServices) {
        this.rowValuesServices = rowValuesServices;
    }

    /**
     * Finds a column that is contained by this table
     *
     * @param colName to search
     * @return the DataColumn
     */
    public DataColumn getColumn(final String colName) {
        for (DataColumn column : columns) {   // TODO Should a Map be added?
            if (colName.equals(column.getName())) {
                return column;
            }
        }

        throw new MissingColumnException(this, colName);
    }

    /**
     * Creates a row within the table with its corresponding columns.
     *
     * @param rowData
     * @return an empty row accessible through the table
     */
    public DataRow newRow(Map<String, Object> rowData) {

        validateColumns(rowData);

        DataRow dataRow = new DataRow(this, dataRowPersistor.makeRowValues(rowData));

        DataRow existingDataRow = this.rowValuesServices.findByTableAndFilter(this, this.makePkFilterFromRow(dataRow));

        validateExistingDataRow(dataRow, existingDataRow);

        this.addDataRow(dataRow);
        dataRow.setManual(true);
        return dataRow;
    }

    private void validateExistingDataRow(DataRow dataRow, DataRow existingDataRow) {
        if (existingDataRow != null) {
            String mess = "";
            for (DataColumn column : this.getColumns()) {

                mess = (dataRow.get(column.getName()) != null) ? mess + " " + column.getName() + ": "
                        + dataRow.get(column.getName()).toString() + ", "  : mess;
            }

            mess = ("".equals(mess)) ? existingDataRow.toString() : mess;

            throw new BusinessException(mess + " - " + BusinessException.DUPLICATE_PRIMARY_KEY, 409);
        }
    }

    private void validateColumns(Map<String, Object> rowData) {
        for (DataColumn column : this.getColumns()) {

            String message = "Column Name: "  + column.getName() + " ";

            boolean isReqOrPrimary = column.getRequired() || column.isPrimaryKey();
            boolean isContainsData = !rowData.containsKey(column.getName());
            boolean isDataEmpty = rowData.get(column.getName()) == null || rowData.get(column.getName()).toString().isEmpty();

            if ((isReqOrPrimary) && (isContainsData || isDataEmpty)) {

                throw new BusinessException(message + BusinessException.REQUIRED_COLUMN_CANNOT_BE_EMPTY, 422);
            }

            if (column.getOptions() != null && rowData.get(column.getName()) != null
                    && !column.getOptions().contains(rowData.get(column.getName()))) {

                throw new BusinessException(message + BusinessException.ENUM_COLUMN_VALUE_MUST_MATCH_OPTIONS, 422);
            }
        }
    }

    /**
     * Adds a row to the DataTable so that it is accessible through it.
     *
     * @param dataRow to be added
     */
    private void addDataRow(DataRow dataRow) {
        rowValuesServices.add(dataRow.getRowValues());
    }

    public List<String> getColumnNames() {

        if (this.columns != null) {
            return Lists.transform(this.columns, new Function<DataColumn, String>() {
                @Override
                public String apply(DataColumn input) {
                    return input.getName();
                }
            });
        }

        return Collections.emptyList();
    }

    public boolean getAllowRecordCreation() {
        return allowRecordCreation;
    }

    /**
     * Returns the class for the values of the given column
     *
     * @param columnName the column name
     * @return the column value class
     */
    public Class<?> getTypeFor(String columnName) {
        DataColumn column = getColumn(columnName);

        return column.getDataType().getInternalType();
    }

    public void setAllowRecordCreation(boolean allowRecordCreation) {
        this.allowRecordCreation = allowRecordCreation;
    }

    public List<DataRow> findRowsByPage(Integer page, Integer rows, String sort, String direction, Map<String, Object> filter) {
        List<Object> rowValuesList = this.rowValuesServices.findRowsByDataTableAndPage(this, page, rows, this.dataRowPersistor.getActualColumnName(sort), direction, filter);
        return Lists.transform(rowValuesList, new Function<Object, DataRow>() {
            @Override
            public DataRow apply(Object input) {
                return new DataRow(DataTable.this, input);
            }
        });
    }

    public List<DataRow> findRows(String sort, String direction, Map<String, Object> filter) {
        List<Object> rowValuesList = this.rowValuesServices.findRowsByDataTable(this, this.dataRowPersistor.getActualColumnName(sort), direction, filter);
        return Lists.transform(rowValuesList, new Function<Object, DataRow>() {
            @Override
            public DataRow apply(Object input) {
                return new DataRow(DataTable.this, input);
            }
        });
    }

    public DataRow findRowById(int rowId) {
        return this.rowValuesServices.findDataRowByDataTableAndDataRowId(this, rowId);
    }

    public void remove(DataRow dataRow) {
        this.rowValuesServices.remove(dataRow.getRowValues());
    }

    public long getTotalRowCount(Map<String, Object> filter) {
        return this.rowValuesServices.countRows(this, filter);
    }

    public String getLoadSql() {
        return loadSql;
    }

    public void setLoadSql(String loadSql) {
        this.loadSql = loadSql;
    }

    public String getLoadScript() {
        return loadScript;
    }

    public void setLoadScript(String loadScript) {
        this.loadScript = loadScript;
    }

    public DataRow updateRow(Map<String, Object> rowData) {
        DataRow dataRow = this.findRowById(Integer.valueOf((String) rowData.get(DataRowVO.ROW_ID_KEY))); //The id comes as a string
        dataRow.update(rowData);
        return dataRow;
    }

    public long markAllRecordsAsNotLoaded() {
        return this.rowValuesServices.markTableRecordsAsNotLoaded(this);
    }

    public long removeAllNotLoadedRecords() {
        return this.rowValuesServices.removeAllNotLoadedRecordsForTable(this);
    }

    public void saveOrUpdateRow(DataRow dataRow) {
        for (DataColumn column : this.getColumns()) {
            if (column.getRequired() && dataRow.get(column.getName()) == null) {
                throw new BusinessException(BusinessException.REQUIRED_COLUMN_CANNOT_BE_EMPTY, 422);
            }

            if (column.getOptions() != null &&
                    dataRow.get(column.getName()) != null &&
                    !column.getOptions().contains(dataRow.get(column.getName()))) {
                throw new BusinessException(BusinessException.ENUM_COLUMN_VALUE_MUST_MATCH_OPTIONS, 422);
            }
        }

        DataRow persistedDataRow = null;
        if (!this.getPkColumns().isEmpty()) {
            persistedDataRow = this.rowValuesServices.findByTableAndFilterEvenDeleted(this, this.makePkFilterFromRow(dataRow));
        }

        if (persistedDataRow == null) {
            this.rowValuesServices.add(dataRow.getRowValues());
        } else {
            persistedDataRow.merge(dataRow);
            persistedDataRow.setLoaded(true);
            persistedDataRow.setDeleted(false);
            this.rowValuesServices.saveOrUpdate(persistedDataRow.getRowValues());
        }
    }

    protected Map<String, Object> makePkFilterFromRow(DataRow dataRow) {
        Collection<DataColumn> pkColumns = getPkColumns();

        Map<String, Object> filter = Maps.newHashMap();

        for (DataColumn column : pkColumns) {
            filter.put(column.getName(), dataRow.get(column.getName()));
        }

        return filter;
    }

    private Collection<DataColumn> getPkColumns() {
        return Collections2.filter(this.getColumns(), new Predicate<DataColumn>() {
            @Override
            public boolean apply(DataColumn input) {
                return input.isPrimaryKey();
            }
        });
    }

    public Boolean isScheduled() {
        return scheduled;
    }

    public Boolean getScheduled() {
        return isScheduled();
    }

    public void setScheduled(Boolean scheduled) {
        this.scheduled = scheduled;
    }

    public void cleanColumnContents(List<DataColumn> dataColumns) {
        for (DataColumn dataColumn : dataColumns) {
            if (dataColumn.getId() == null && dataColumn.getDataType().getInternalType().equals(PointOfSale.class)) {
                this.rowValuesServices.clearPointsOfSale(this);
            } else if (dataColumn.getId() == null && dataColumn.getDataType().getInternalType().equals(DataFile.class)) {
                this.rowValuesServices.clearFileDataContent(this);
            } else if (dataColumn.getId() == null && !dataColumn.getDataType().getInternalType().equals(ServiceCenter.class)) {
                this.rowValuesServices.cleanColumnContents(this, dataColumn);
            }
        }
    }


    public List<DataRow> findRowsByServiceCenter(ServiceCenter serviceCenter) {
        return rowValuesServices.findRowsByTableAndServiceCenter(this, serviceCenter);
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }


    public void setLastRunSucceed(Boolean lastRunSucceed) {
        this.lastRunSucceed = lastRunSucceed;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public Boolean isLastRunSucceed() {
        return lastRunSucceed;
    }

    public List<Metric> getMetrics() {
        return metrics;
    }

    public void setMetrics(List<Metric> metrics) {
        this.metrics = metrics;
    }

    public Boolean getIncludeData() {
        return includeData;
    }

    public void setIncludeData(Boolean includeData) {
        this.includeData = includeData;
    }

    public void removeAllRows() {
        this.rowValuesServices.removeRowsByTable(this);
    }

    @Override
    public String toString() {
        return "DataTable{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", campaign=" + campaign +
                ", allowRecordCreation=" + allowRecordCreation +
                ", loadSql='" + loadSql + '\'' +
                ", loadScript='" + loadScript + '\'' +
                ", scheduled=" + scheduled +
                '}';
    }

}
