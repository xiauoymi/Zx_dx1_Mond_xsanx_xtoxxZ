package com.monsanto.metricspos.core.externaldata;

/**
 * Describes a column content type
 *
 * User: PPERA
 */
public class DataType {

    private String code;
    private String name;
    private String description;

    private boolean hasSize;
    private boolean hasMinSize;
    private boolean hasPrecision;
    private boolean hasOptions;

    private boolean sortable;
    private boolean filterable;

    private Class<?> internalType;

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public Class<?> getInternalType() {
        return internalType;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setInternalType(Class<?> internalType) {
        this.internalType = internalType;
    }

    public boolean isHasSize() {
        return hasSize;
    }

    public void setHasSize(boolean hasSize) {
        this.hasSize = hasSize;
    }

    public boolean isHasMinSize() {
        return hasMinSize;
    }

    public void setHasMinSize(boolean hasMinSize) {
        this.hasMinSize = hasMinSize;
    }

    public boolean isHasPrecision() {
        return hasPrecision;
    }

    public void setHasPrecision(boolean hasPrecision) {
        this.hasPrecision = hasPrecision;
    }

    public boolean isHasOptions() {
        return hasOptions;
    }

    public void setHasOptions(boolean hasOptions) {
        this.hasOptions = hasOptions;
    }

    public boolean isSortable() {
        return sortable;
    }

    public void setSortable(boolean sortable) {
        this.sortable = sortable;
    }

    public boolean isFilterable() {
        return filterable;
    }

    public void setFilterable(boolean filterable) {
        this.filterable = filterable;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
