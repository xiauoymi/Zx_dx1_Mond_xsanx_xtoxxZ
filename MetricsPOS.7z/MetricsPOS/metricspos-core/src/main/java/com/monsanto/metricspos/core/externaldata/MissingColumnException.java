package com.monsanto.metricspos.core.externaldata;

/**
 * Signals that some operation was required on a column given by name,
 * but there is not column with that name.
 *
 * @author cafau
 */
public class MissingColumnException extends RuntimeException {
    public MissingColumnException(DataTable dataTable, String colName) {
        this( "column '" + colName + "' @ table '" + dataTable.getName() + "'");
    }

    public MissingColumnException() {
    }

    public MissingColumnException(String message) {
        super(message);
    }
}
