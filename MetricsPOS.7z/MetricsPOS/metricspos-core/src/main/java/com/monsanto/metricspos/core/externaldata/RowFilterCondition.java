package com.monsanto.metricspos.core.externaldata;

/**
 * Abstraction used to separate the user filter from the one used by the application
 * to find an specific set of matching rows.
 * <p/>
 * User: PPERA
 */
public class RowFilterCondition {
    private String actualColumnName;
    private DataType dataType;
    private Object value;

    public RowFilterCondition(String actualColumnName, DataType dataType, Object value) {
        this.actualColumnName = actualColumnName;
        this.dataType = dataType;
        this.value = value;
    }

    public String getActualColumnName() {
        return actualColumnName;
    }

    public DataType getDataType() {
        return dataType;
    }

    public Object getValue() {
        return value;
    }
}
