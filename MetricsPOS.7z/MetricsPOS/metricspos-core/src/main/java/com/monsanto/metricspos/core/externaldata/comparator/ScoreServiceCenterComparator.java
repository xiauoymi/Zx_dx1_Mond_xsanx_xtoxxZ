package com.monsanto.metricspos.core.externaldata.comparator;

import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;

/**
 * Created by SHELG on 9/24/2014.
 */
public class ScoreServiceCenterComparator implements Comparator<ServiceCenter> {

    @Override
    public int compare(ServiceCenter serviceCenter, ServiceCenter serviceCenter2) {

        int result = 0;

        List<MetricScore> scores = serviceCenter.getScores();
        List<MetricScore> scores2 = serviceCenter2.getScores();

        if(!CollectionUtils.isEmpty(scores) && !CollectionUtils.isEmpty(scores2)) {

            BigDecimal points = BigDecimal.ZERO;
            for (MetricScore score : scores) {
                if (score.getMetric().getWeighting() == null || !(score.getMetric().getWeighting())) {
                    points = points.add(score.getPoints());
                }
            }

            BigDecimal points2 = BigDecimal.ZERO;
            for (MetricScore score2 : scores2) {
                if (score2.getMetric().getWeighting() == null || !(score2.getMetric().getWeighting())) {
                    points2 = points2.add(score2.getPoints());
                }
            }

            result = points2.compareTo(points);
            result = (result == 0) ? serviceCenter.getName().compareTo(serviceCenter2.getName()) : result;
        }
        return result;
    }
}
