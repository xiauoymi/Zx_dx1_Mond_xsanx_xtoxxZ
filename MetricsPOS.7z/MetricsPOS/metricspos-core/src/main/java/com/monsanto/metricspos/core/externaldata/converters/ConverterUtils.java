package com.monsanto.metricspos.core.externaldata.converters;

import com.google.common.collect.Sets;
import com.monsanto.metricspos.core.metrics.Campaign;
import org.springframework.context.support.ConversionServiceFactoryBean;
import org.springframework.core.convert.ConversionService;

import java.util.Set;

/**
 * This Class is not meant to be instantiated. It provides the service responsible
 * for data conversion from its actual type to an specified one. It uses spring-converter
 * and also some custom converters for Date handling.
 *
 * @author PPERA
 */
public final class ConverterUtils {
    private ConverterUtils() {

    }

    public static ConversionService makeConverterService(Campaign campaign) {
        ConversionServiceFactoryBean conversionServiceFactoryBean = new ConversionServiceFactoryBean();

        Set<?> converters = Sets.newHashSet(new DoubleToStringConverter(),
                                            new DoubleToServiceCenterConverter(campaign),
                                            new DoubleToPointOfSaleConverter(campaign),
                                            new DateToStringConverter(),
                                            new StringToDateConverter(),
                                            new StringToServiceCenterConverter(campaign),
                                            new StringToPointOfSaleConverter(campaign));

        conversionServiceFactoryBean.setConverters(converters);
        conversionServiceFactoryBean.afterPropertiesSet();

        return conversionServiceFactoryBean.getObject();
    }

    public static ConversionService makeConverterService() {
        ConversionServiceFactoryBean conversionServiceFactoryBean = new ConversionServiceFactoryBean();

        Set<?> converters = Sets.newHashSet(new DoubleToStringConverter(),
                                            new DateToStringConverter(),
                                            new StringToDateConverter());

        conversionServiceFactoryBean.setConverters(converters);
        conversionServiceFactoryBean.afterPropertiesSet();

        return conversionServiceFactoryBean.getObject();
    }
}