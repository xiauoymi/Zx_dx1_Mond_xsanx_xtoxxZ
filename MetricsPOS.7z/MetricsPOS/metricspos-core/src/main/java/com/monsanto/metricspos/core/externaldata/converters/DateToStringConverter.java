package com.monsanto.metricspos.core.externaldata.converters;

import org.springframework.core.convert.converter.Converter;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Converter used to map a date to a string formated in a readable way.
 * @author PPERA
 */
public class DateToStringConverter implements Converter<Date, String> {
    private final DateFormat longDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS a");

    public String convert(Date source) {
        return longDateFormat.format(source);
    }
}
