package com.monsanto.metricspos.core.externaldata.converters;

import com.monsanto.metricspos.core.PointOfSaleServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.PointOfSale;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.core.convert.converter.Converter;

import java.text.NumberFormat;

/**
 * Used when data is imported from excel which converts the Sap Id to a double
 *
 * User: PPERA
 */
@Configurable
public class DoubleToPointOfSaleConverter implements Converter<Double, PointOfSale> {
    private PointOfSaleServices pointOfSaleServices;
    private Campaign campaign;

    public DoubleToPointOfSaleConverter() {
    }

    public DoubleToPointOfSaleConverter(Campaign campaign) {
        this.campaign = campaign;
    }

    @Override
    public PointOfSale convert(Double idSap) {
        if(idSap.isNaN()){
            return null;
        }
        NumberFormat format = NumberFormat.getNumberInstance();
        format.setGroupingUsed(false);
        format.setMaximumFractionDigits(0);
        format.setMinimumFractionDigits(0);

        return this.pointOfSaleServices.findPointOfSaleByIdSap(Long.valueOf(format.format(idSap)), this.campaign);
    }

    public void setPointOfSaleServices(PointOfSaleServices pointOfSaleServices) {
        this.pointOfSaleServices = pointOfSaleServices;
    }
}
