package com.monsanto.metricspos.core.externaldata.converters;

import com.monsanto.metricspos.core.ServiceCenterServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.core.convert.converter.Converter;

import java.text.NumberFormat;

/**
 * Used when importing data from excel which converts the cuit to a double
 *
 * User: PPERA
 */
@Configurable
public class DoubleToServiceCenterConverter implements Converter<Double, ServiceCenter> {

    private Campaign campaign;
    private ServiceCenterServices serviceCenterServices;

    public DoubleToServiceCenterConverter(){

    }

    public DoubleToServiceCenterConverter(Campaign campaign){
        this.campaign = campaign;
    }


    @Override
    public ServiceCenter convert(Double source) {
        NumberFormat format = NumberFormat.getNumberInstance();
        format.setGroupingUsed(false);
        format.setMaximumFractionDigits(0);
        format.setMinimumFractionDigits(0);

        return this.serviceCenterServices.findServiceCenterByCuit(format.format(source), campaign);
    }

    public void setServiceCenterServices(ServiceCenterServices serviceCenterServices) {
        this.serviceCenterServices = serviceCenterServices;
    }
}
