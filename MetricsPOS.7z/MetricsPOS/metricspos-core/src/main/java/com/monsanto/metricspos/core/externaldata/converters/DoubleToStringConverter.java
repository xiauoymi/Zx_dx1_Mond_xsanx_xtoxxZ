package com.monsanto.metricspos.core.externaldata.converters;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.core.convert.converter.Converter;

import java.text.NumberFormat;

/**
 * This implementation prevents format issues
 *
 * User: PPERA
 */
@Configurable
public class DoubleToStringConverter implements Converter<Double, String> {

    public DoubleToStringConverter(){

    }

    @Override
    public String convert(Double source) {
        NumberFormat format = NumberFormat.getNumberInstance();
        format.setGroupingUsed(false);
        format.setMaximumFractionDigits(0);
        format.setMinimumFractionDigits(0);

        return format.format(source);
    }

}
