package com.monsanto.metricspos.core.externaldata.converters;

import org.springframework.core.convert.converter.Converter;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Converter used to map a customly formated String (for simplicity pourposes) to a Date.
 *
 * @author PPERA
 */
public class StringToDateConverter implements Converter<String, Date> {
    private final DateFormat shortDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private final DateFormat rowDateFormat = new SimpleDateFormat("dd-MM-yyyy");
    private final DateFormat longDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS a");

    public StringToDateConverter() {
        shortDateFormat.setLenient(false);
        longDateFormat.setLenient(false);
    }

    @Override
    public Date convert(String source) {
        if (source == null || source.trim().isEmpty() || source.trim().length() == 1) {
            return null;
        }

        String trimmedSource = source.trim();
        try {
            return trimmedSource.length() > "yyyy-MM-dd".length()
                    ? longDateFormat.parse(trimmedSource)
                    : trimmedSource.indexOf('-') > 2
                        ? shortDateFormat.parse(trimmedSource)
                        : rowDateFormat.parse(trimmedSource);
        } catch (ParseException e) {
            throw new IllegalArgumentException("Invalid date: [" + source + ']', e);
        }
    }
}
