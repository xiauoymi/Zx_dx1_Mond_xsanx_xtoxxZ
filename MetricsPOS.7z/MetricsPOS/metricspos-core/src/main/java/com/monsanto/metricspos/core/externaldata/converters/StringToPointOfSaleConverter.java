package com.monsanto.metricspos.core.externaldata.converters;

import com.monsanto.metricspos.core.PointOfSaleServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.PointOfSale;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.core.convert.converter.Converter;

/**
 * When an idSap is indicated this class performs the conversion from that string
 * parameter to the PointOfSale it represented
 *
 * User: PPERA
 */
@Configurable
public class StringToPointOfSaleConverter implements Converter<String, PointOfSale> {
    private PointOfSaleServices pointOfSaleServices;
    private Campaign campaign;

    public StringToPointOfSaleConverter() {
    }

    public StringToPointOfSaleConverter(Campaign campaign) {
        this.campaign = campaign;
    }

    @Override
    public PointOfSale convert(String idSap) {
        if(idSap.isEmpty()){
            return null;
        }
        return this.pointOfSaleServices.findPointOfSaleByIdSap(Long.valueOf(idSap), this.campaign);
    }

    public void setPointOfSaleServices(PointOfSaleServices pointOfSaleServices) {
        this.pointOfSaleServices = pointOfSaleServices;
    }
}
