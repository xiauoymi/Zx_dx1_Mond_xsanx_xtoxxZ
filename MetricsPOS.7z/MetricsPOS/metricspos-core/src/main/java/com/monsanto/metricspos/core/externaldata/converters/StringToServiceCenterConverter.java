package com.monsanto.metricspos.core.externaldata.converters;

import com.monsanto.metricspos.core.ServiceCenterServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.core.convert.converter.Converter;

/**
 * When a Cuit is indicated this class performs the conversion from that string
 * parameter to the ServiceCenter it represented
 *
 * User: PPERA
 */
@Configurable
public class StringToServiceCenterConverter implements Converter<String, ServiceCenter> {

    private Campaign campaign;
    private ServiceCenterServices serviceCenterServices;

    public StringToServiceCenterConverter() {

    }

    public StringToServiceCenterConverter(Campaign campaign) {
        this.campaign = campaign;
    }

    @Override
    public ServiceCenter convert(String source) {
        return serviceCenterServices.findServiceCenterByCuit(source, campaign);
    }

    public void setServiceCenterServices(ServiceCenterServices serviceCenterServices) {
        this.serviceCenterServices = serviceCenterServices;
    }
}
