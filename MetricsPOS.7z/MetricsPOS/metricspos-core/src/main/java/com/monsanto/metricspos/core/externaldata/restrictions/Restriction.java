package com.monsanto.metricspos.core.externaldata.restrictions;

/**
 * Represents a constraint on the contents of a column
 * @author PPERA
 */
public interface Restriction<T> {
    public static final String ERROR_RESTRICTION_VIOLATION = "This column restricts the given value";

    public boolean passes(T value);

}
