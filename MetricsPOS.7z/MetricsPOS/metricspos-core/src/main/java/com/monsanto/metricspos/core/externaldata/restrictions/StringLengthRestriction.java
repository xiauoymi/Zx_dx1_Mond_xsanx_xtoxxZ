package com.monsanto.metricspos.core.externaldata.restrictions;

/**
 * Validates that a string's length does not exceed a certain maxLength
 * @author PPERA
 */
public class StringLengthRestriction implements Restriction<String>{
    private final int maxLength;

    public StringLengthRestriction(int maxLength) {
        this.maxLength = maxLength;
    }

    public boolean passes(String value) {
        return value.length() <= maxLength;
    }

}
