package com.monsanto.metricspos.core.metrics;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.ComputeManager;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.springframework.beans.factory.annotation.Configurable;

import java.util.Date;
import java.util.List;

/**
 * Core object of the application. A campaign is the main data a user
 * will work with and almost every other entity is grouped under a campaign
 *
 * @author CAFAU
 */
@Configurable
public class Campaign extends MetricContainer {
    // Required for external identification
    private Integer id;

    private String name;
    private Date since;
    private Date until;
    private CampaignState state;
    private List<ServiceCenter> serviceCenters;
    private List<DataTable> dataTables;

    private MetricFactory factory;
    private List<Metric> metrics;
    private List<Employee> employees;
    private String serviceCenterLoadScript;
    private String serviceCenterLoadSql;
    private String pointOfSaleLoadScript;
    private String pointOfSaleLoadSql;
    private String employeeLoadSql;
    private String employeeLoadScript;
    private Boolean scheduled = Boolean.FALSE;
    private ComputeManager computeManager;
    private String ratingFormula;
    private String ratingPremiumCategory;

    /**
     * Constructor for persistence
     */
    protected Campaign() {
    }

    public Campaign(String name, Date since, Date until) {
        if (since.after(until)) {
            throw new BusinessException(BusinessException.START_END_DATE_EXCEPTION, 422);
        }

        this.name = name;
        this.since = since;
        this.until = until;
        this.state = CampaignState.CREATED;
        this.setMetrics(Lists.<Metric>newArrayList());
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Date getSince() {
        return since;
    }

    public Date getUntil() {
        return until;
    }

    public CampaignState getState() {
        return state;
    }

    public List<ServiceCenter> getServiceCenters() {
        return serviceCenters;
    }

    public void add(ServiceCenter serviceCenter) {
        // NOT SYNCH
        if (serviceCenters == null) {
            serviceCenters = Lists.newArrayList();
        }

        serviceCenters.add(serviceCenter);
    }

    void assertAllowedMetricDefinitionName(String name) {
        if (hasMetricDefinition(name)) {
            throw new BusinessException(BusinessException.DUPLICATE_METRIC_NAME, 422);
        }
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setState(CampaignState state) {
        this.state = state;
    }

    public void setServiceCenters(List<ServiceCenter> serviceCenters) {
        this.serviceCenters = serviceCenters;
    }

    public List<DataTable> getDataTables() {
        return dataTables;
    }

    public void setDataTables(List<DataTable> dataTables) {
        this.dataTables = dataTables;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSince(Date since) {
        this.since = since;
    }

    public void setUntil(Date until) {
        this.until = until;
    }

    public void setFactory(MetricFactory factory) {
        this.factory = factory;
    }

    protected Metric newMetric(String name, Integer maxPoints) {
        return factory.newMetricDefinition(this, name, maxPoints);
    }

    public void setMetrics(List<Metric> metrics) {
        this.metrics = metrics;
    }

    @Override
    protected List<Metric> internalGetMetrics() {
        return metrics;
    }

    public List<Metric> getMetrics() {
        return metrics;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }

    public void addDataTable(DataTable dataTable) {
        if (this.dataTables == null) {
            this.dataTables = Lists.newArrayList();
        }

        this.dataTables.add(dataTable);
    }

    public String getServiceCenterLoadScript() {
        return serviceCenterLoadScript;
    }

    public void setServiceCenterLoadScript(String serviceCenterLoadScript) {
        this.serviceCenterLoadScript = serviceCenterLoadScript;
    }

    public String getServiceCenterLoadSql() {
        return serviceCenterLoadSql;
    }

    public void setServiceCenterLoadSql(String serviceCenterLoadSql) {
        this.serviceCenterLoadSql = serviceCenterLoadSql;
    }

    public String getPointOfSaleLoadScript() {
        return pointOfSaleLoadScript;
    }

    public void setPointOfSaleLoadScript(String pointOfSaleLoadScript) {
        this.pointOfSaleLoadScript = pointOfSaleLoadScript;
    }

    public String getPointOfSaleLoadSql() {
        return pointOfSaleLoadSql;
    }

    public void setPointOfSaleLoadSql(String pointOfSaleLoadSql) {
        this.pointOfSaleLoadSql = pointOfSaleLoadSql;
    }

    public void setEmployeeLoadSql(String employeeLoadSql) {
        this.employeeLoadSql = employeeLoadSql;
    }

    public void setEmployeeLoadScript(String employeeLoadScript) {
        this.employeeLoadScript = employeeLoadScript;
    }


    public String getEmployeeLoadSql() {
        return employeeLoadSql;
    }

    public String getEmployeeLoadScript() {
        return employeeLoadScript;
    }

    public Boolean isScheduled() {
        return scheduled;
    }

    public void setScheduled(boolean scheduled) {
        this.scheduled = scheduled;
    }

    public String computeRating(ScoreSummaryCampaignNode summary) {
        return this.computeManager.compute(this, summary);
    }

    public String getRatingFormula() {
        return ratingFormula;
    }

    public void setRatingFormula(String ratingFormula) {
        this.ratingFormula = ratingFormula;
    }

    public void setComputeManager(ComputeManager computeManager) {
        this.computeManager = computeManager;
    }

    public String getRatingPremiumCategory() {
        return ratingPremiumCategory;
    }

    public void setRatingPremiumCategory(String ratingPremiumCategory) {
        this.ratingPremiumCategory = ratingPremiumCategory;
    }

    @Override
    public String toString() {
        return "Campaign{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", since=" + since +
                ", until=" + until +
                '}';
    }
}
