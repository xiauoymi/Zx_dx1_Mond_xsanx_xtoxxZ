package com.monsanto.metricspos.core.metrics;

/**
 * Configuration parameters used to configure some attributes of the application
 * such as the email address to send the reports, etc.
 * It is defined as key - value pair.
 * It maps with the LDM_PARAMETER table.
 */
public class CampaignParameter {

    private Integer id;
    private String name;
    private String description;
    private String value;
    private String type;
    private boolean visible;
    private boolean modifiable;
    public static final String OVERRIDE_TO_PARAMETER = "sc.reports.mail.override.to";
    public static final String ID = "id";
    public static final String PDF_NAME_PARAMETER = "sc.reports.mail.pdf.name";
    public static final String XLS_NAME_PARAMETER = "sc.reports.mail.xls.name";
    public static final String SUBJECT_PARAMETER = "sc.reports.mail.subject";
    public static final String TEXT_PARAMETER = "sc.reports.mail.text";

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public boolean isModifiable() {
        return modifiable;
    }

    public void setModifiable(boolean modifiable) {
        this.modifiable = modifiable;
    }
}
