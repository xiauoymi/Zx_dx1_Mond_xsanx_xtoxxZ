package com.monsanto.metricspos.core.metrics;

/**
 * Complete please !!
 *
 * @author CAFAU
 */
public enum CampaignState {
    CREATED
}
