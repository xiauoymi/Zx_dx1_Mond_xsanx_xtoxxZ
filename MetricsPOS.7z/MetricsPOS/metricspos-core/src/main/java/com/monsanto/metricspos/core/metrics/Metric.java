package com.monsanto.metricspos.core.metrics;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.metricspos.core.ComputeManager;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryNode;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Set;

/**
 * Could be a module, a metric or a submetric.
 *
 * @author CAFAU
 */
@Configurable
public class Metric extends MetricContainer {
    public static final String INVALID_METRIC_NAME = "Name should be not empty";
    private String name;
    private Integer id;
    private Campaign campaign;

    private Metric parent;
    private List<Metric> metrics;
    private boolean enabled;
    private String formula;
    private Integer maxPoints;
    private List<DataTable> tables;

    private Set<MetricScore> scores;
    private ComputeManager computeManager;
    private boolean scheduled;
    private String owner;
    private String explanation;

    private Integer type;

    private Boolean send;

    private Boolean weighting;

    public Metric getParent() {
        return parent;
    }

    public void setParent(Metric parent) {
        this.parent = parent;
    }

    /**
     * Constructor for persistence
     */
    protected Metric() {
    }

    public Metric(Campaign campaign, String name) {
        this.campaign = campaign;
        setName(name);
        this.send = true;
        this.metrics = Lists.newArrayList();
        this.scores = Sets.newHashSet();
        this.tables = Lists.newArrayList();
        this.weighting = false;
        this.type = 0;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public void setComputeManager(ComputeManager computeManager) {
        this.computeManager = computeManager;
    }

    public void compute() {
        this.computeManager.compute(this);
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public void computeModuleFormula(ScoreSummaryNode moduleNode) {
        if(this.parent==null) {
            this.computeManager.computeModuleFormula(moduleNode);
        }
    }

    public void setName(String name) {
        if (!StringUtils.hasText(name)) {
            throw new IllegalArgumentException(INVALID_METRIC_NAME);
        }

        if (name.equals(this.name)) {
            // Nothing change
            return;
        }

        campaign.assertAllowedMetricDefinitionName(name);

        this.name = name;
    }

    private Campaign getCampaignInternal() {
        if (campaign != null) {
            return campaign;
        }

        return parent == null ? null : parent.getCampaign();
    }

    public void setId(int id) {
        this.id = id;
    }

    protected Metric newMetric(String name, Integer maxPoints) {
        Metric metric = getCampaignInternal().newMetric(name, maxPoints);
        metric.setParent(this);
        return metric;
    }

    @Override
    protected List<Metric> internalGetMetrics() {
        return metrics;
    }

    public void setMetrics(List<Metric> metrics) {
        this.metrics = metrics;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public String getFormula() {
        return formula;
    }

    public Integer getMaxPoints() {
        return maxPoints;
    }

    public void setMaxPoints(Integer maxPoints) {
        this.maxPoints = maxPoints;
    }

    public Set<MetricScore> getScores() {
        return scores;
    }

    public void setScores(Set<MetricScore> scores) {
        this.scores = scores;
    }

    public List<DataTable> getTables() {
        return tables;
    }

    public void setTables(List<DataTable> tables) {
        this.tables = tables;
    }

    public boolean isScheduled() {
        return scheduled;
    }

    public void setScheduled(boolean scheduled) {
        this.scheduled = scheduled;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public Boolean getSend() {
        return send;
    }

    public void setSend(Boolean send) {
        this.send = send;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public boolean isModule(){
        return !isSubMetric() && !isMetric();
    }

    public boolean isSubMetric(){
        return hasParent() && !hasChildren();
    }

    /**
     * Determinate it is a Metric only if it has children and your children haven't children.
     * @return
     */
    public boolean isMetric() {
        for(Metric metric : this.getMetrics()){
            if(metric.hasChildren()) {
                return false;
            }
        }
        return hasChildren();
    }

    public boolean hasChildren(){
        return this.getMetrics().size() > 0;
    }

    public boolean hasParent(){
        return this.getParent() != null;
    }

    public Boolean getWeighting() {
        return weighting;
    }

    public void setWeighting(Boolean weighting) {
        this.weighting = weighting;
    }

    @Override
    public String toString() {
        return "Metric{" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", enabled=" + enabled +
                ", formula='" + formula + '\'' +
                ", maxPoints=" + maxPoints +
                ", scheduled=" + scheduled +
                '}';
    }

    public Boolean addToSend(){
        if(this.send) {
            return true;
        }
        for(Metric oneMetric : this.getMetrics()) {
            if(oneMetric.addToSend()) {
                return true;
            }
        }
        return false;
    }

    public int getQuantityChildren() {
        int i = 0;
        for(Metric metric : getMetrics()){
            i++;
            i = i + metric.getQuantityChildren();
        }
        return i;
    }
}
