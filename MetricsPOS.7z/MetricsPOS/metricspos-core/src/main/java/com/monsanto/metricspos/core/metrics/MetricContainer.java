package com.monsanto.metricspos.core.metrics;

import com.google.common.collect.Lists;

import java.util.List;

/**
 * Abstract class, classic part of a composite with a root and non-root classes.
 *
 * User: PPERA
 */
public abstract class MetricContainer {

    public abstract void setMetrics(List<Metric> metrics);

    public List<Metric> getMetrics() {
        List<Metric> metrics = internalGetMetrics();
        if (metrics == null) {
            metrics = Lists.newArrayList();
            setMetrics(metrics);
        }
        return internalGetMetrics();
    }

    public Metric addMetricDefinition(String name, Integer maxPoints) {
        List<Metric> metrics = getMetrics();
        Metric metric = newMetric(name, maxPoints);
        metrics.add(metric);

        return metric;
    }

    protected abstract Metric newMetric(String name, Integer maxPoints);

    protected boolean hasMetricDefinition(String name) {
        List<Metric> metrics = internalGetMetrics();

        if (metrics != null) {
            for (Metric metric : metrics) {
                if (metric.getName().equalsIgnoreCase(name)) {
                    return true;
                }
            }
        }

        return false;
    }

    public void remove(Metric metricToRemove) {
        List<Metric> metrics = internalGetMetrics();

        if (metrics != null) {
            if (metrics.contains(metricToRemove)) {
                metrics.remove(metricToRemove);
            } else {
                for (Metric metric : metrics) {
                    metric.remove(metricToRemove);
                }
            }
        }
    }

    protected abstract List<Metric> internalGetMetrics();
}
