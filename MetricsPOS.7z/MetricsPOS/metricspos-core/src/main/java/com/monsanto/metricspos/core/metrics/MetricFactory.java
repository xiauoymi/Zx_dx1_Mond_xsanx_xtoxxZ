package com.monsanto.metricspos.core.metrics;

/**
 * A metric factory creates a metric in a coherent final state.
 *
 * User: PPERA
 */
public interface MetricFactory {
    /**
     * Creates and returns a metric that is in an stable state.
     *
     * @param campaign the metric is a part of
     * @param name of the metric
     * @param maxPoints of the metric
     * @return te metric that was created
     */
    public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints);
}
