package com.monsanto.metricspos.core.metrics;

import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * The score computed for a ServiceCenter on a Metric
 *
 * @author CAFAU
 */
public class MetricScore extends Score {

    private Integer id;

    private ServiceCenter serviceCenter;
    private Metric metric;

    private boolean dirty;
    private boolean noData;

    private Date lastUpdated;

    /**
     * For persistence
     */
    protected MetricScore() {
    }

    public MetricScore(Metric metric, ServiceCenter serviceCenter) {
        this.setPoints(BigDecimal.ZERO);
        this.setPenalty(BigDecimal.ZERO);
        this.setPenaltyFactor(BigDecimal.ZERO);
        this.noData = true;
        this.metric = metric;
        this.serviceCenter = serviceCenter;
        this.lastUpdated = new Date();
    }

    public ServiceCenter getServiceCenter() {
        return serviceCenter;
    }

    public boolean isDirty() {
        return dirty;
    }

    public Metric getMetric() {
        return metric;
    }

    public void setMetric(Metric metric) {
        this.metric = metric;
    }

    public void setNoData(boolean hasData) {
        this.noData = hasData;
    }

    public void setDirty(boolean dirty) {
        this.dirty = dirty;
    }

    public Integer getId() {
        return id;
    }

    public boolean isNoData() {
        return noData;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
