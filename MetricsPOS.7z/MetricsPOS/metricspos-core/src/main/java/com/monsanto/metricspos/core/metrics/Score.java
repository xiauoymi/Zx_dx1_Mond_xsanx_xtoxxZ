package com.monsanto.metricspos.core.metrics;

import java.math.BigDecimal;

/**
 * Complete please !!
 *
 * @author cafau
 */
public class Score {
    private BigDecimal points;
    private BigDecimal penalty;
    private BigDecimal penaltyFactor;

    public static Score newEmptyScore() {
        Score baseScore = new Score();
        baseScore.setPoints(BigDecimal.ZERO);
        baseScore.setPenalty(BigDecimal.ZERO);
        baseScore.setPenaltyFactor(BigDecimal.ZERO);
        return baseScore;
    }

    public BigDecimal getPoints() {
        return points;
    }

    public void setPoints(BigDecimal points) {
        this.points = points;
    }

    public BigDecimal getPenalty() {
        return penalty;
    }

    public void setPenalty(BigDecimal penalty) {
        this.penalty = penalty;
    }

    public BigDecimal getPenaltyFactor() {
        return penaltyFactor;
    }

    public void setPenaltyFactor(BigDecimal penaltyFactor) {
        this.penaltyFactor = penaltyFactor;
    }

    public void setScores(Score baseScore) {
        setPoints(baseScore.getPoints());
        setPenalty(baseScore.getPenalty());
        setPenaltyFactor(baseScore.getPenaltyFactor());
    }
}
