package com.monsanto.metricspos.core.metrics.summary;

import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricContainer;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * Behaviour common to any node of the summary tree
 *
 * User: PPERA
 */
public abstract class ScoreSummary {

    protected static Logger log = Logger.getLogger(ScoreSummary.class);

    private List<ScoreSummaryNode> children;
    protected BigDecimal points;
    protected Integer maxPoints;

    private BigDecimal deductions;

    public Integer getMaxPoints() {
        return maxPoints;
    }

    public BigDecimal getPoints() {
        return points;
    }

    public abstract void initializeNode();

    public ScoreSummary(MetricContainer metricContainer, final ServiceCenter serviceCenter, final ScoreServices scoreServices) {
        this.points = BigDecimal.ZERO;
        this.maxPoints = 0;
        this.deductions = BigDecimal.ZERO;
        this.children = new ArrayList<ScoreSummaryNode>();
        for (Metric metric : metricContainer.getMetrics()) {
            this.children.add(ScoreSummaryFactory.getInstance().create(metric,serviceCenter,scoreServices));
        }
    }

    public List<ScoreSummaryNode> getChildren() {
        return children;
    }

    public BigDecimal getChildrenPoints() {
        BigDecimal total = BigDecimal.ZERO;
        for (ScoreSummaryNode node : this.getChildren()) {
            if(!node.getMetric().getWeighting()) {
                total = total.add(node.getPoints());
            }
        }

        return total;
    }

    public BigDecimal getChildrenWeighting() {
        BigDecimal total = BigDecimal.ZERO;
        for (ScoreSummaryNode node : this.getChildren()) {
            if(node.getMetric().getWeighting()) {
                total = total.add(node.getPoints());
            }
        }

        return total;
    }

    public int getNumberOfLeaves() {
        if (this.hasChildren()) {
            Integer total = 0;

            for (ScoreSummaryNode node : this.getChildren()) {
                total += (node.getMetric().addToSend())?node.getNumberOfLeaves():0;
            }

            return total;
        } else {
            return 1;
        }

    }

    public BigDecimal getPointsPercent() {
        if (this.getMaxPoints() > 0) {
            return this.getPoints().divide(BigDecimal.valueOf(this.getMaxPoints()), 4, BigDecimal.ROUND_HALF_UP).multiply(BigDecimal.valueOf(100));
        } else {
            return BigDecimal.ZERO;
        }
    }


    protected boolean hasChildren() {
        return this.getChildren() != null && !this.getChildren().isEmpty();
    }

    public abstract boolean isNoComputed();

    public BigDecimal getDeductions() {
        return deductions;
    }

    public void setDeductions(BigDecimal deductions) {
        this.deductions = deductions;
    }

}
