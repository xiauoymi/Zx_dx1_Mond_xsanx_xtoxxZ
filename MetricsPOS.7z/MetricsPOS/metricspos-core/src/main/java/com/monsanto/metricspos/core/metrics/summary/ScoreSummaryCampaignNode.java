package com.monsanto.metricspos.core.metrics.summary;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.math.BigDecimal;

/**
 * Root node of the summary. Bootstraps the whole tree recursively.
 *
 * User: PPERA
 */
public class ScoreSummaryCampaignNode extends ScoreSummary {

    private Campaign campaign;
    private ServiceCenter serviceCenter;
    private String rating;

    public ScoreSummaryCampaignNode(Campaign campaign, ServiceCenter serviceCenter, ScoreServices scoreServices) {
        super(campaign, serviceCenter, scoreServices);
        this.campaign = campaign;
        this.serviceCenter = serviceCenter;
        this.initializeNode();
    }

    public Campaign getCampaign() {
        return campaign;
    }

    @Override
    public Integer getMaxPoints() {
        return this.maxPoints;
    }

    public String getRating() {
        return rating;
    }

    public ServiceCenter getServiceCenter() {
        return serviceCenter;
    }

    @Override
    public void initializeNode() {
        this.points = this.getChildrenPoints();
        Integer total = 0;

        for (ScoreSummaryNode node : this.getChildren()) {
            total = total + node.getMaxPoints();
        }

        this.maxPoints = total;

        this.rating = campaign.computeRating(this);
    }

    @Override
    public BigDecimal getPointsPercent() {
        return super.getPointsPercent();    //To change body of overridden methods use File | Settings | File Templates.
    }

    @Override
    public boolean isNoComputed() {
        return !Collections2.filter(this.getChildren(), new Predicate<ScoreSummaryNode>() {
            @Override
            public boolean apply(ScoreSummaryNode input) {
                return input.getComputeError();
            }
        }).isEmpty();
    }
}
