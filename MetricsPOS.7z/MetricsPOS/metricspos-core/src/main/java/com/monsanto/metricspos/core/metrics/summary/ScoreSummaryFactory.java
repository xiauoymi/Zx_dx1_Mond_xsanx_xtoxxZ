package com.monsanto.metricspos.core.metrics.summary;

import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.structure.ServiceCenter;

/**
 * Factory class to generate ScoreSummary Objects (Module, Metric or submetric)
 * User: BSBUON
 */
public final class ScoreSummaryFactory {

    private static ScoreSummaryFactory instance;

    private ScoreSummaryFactory(){

    }

    /**
     * singleton
     * @return
     */
    public static ScoreSummaryFactory getInstance(){
        if(instance==null){
            instance = new ScoreSummaryFactory();
        }
        return instance;
    }

    public ScoreSummaryNode create(Metric metric, ServiceCenter service, ScoreServices scoreServices){
        ScoreSummaryNode result = null;

        if(metric.isMetric()){
            result = new ScoreSummaryMetricNode(metric, service, scoreServices);
        }else if(metric.isSubMetric()){
            result = new ScoreSummarySubMetricNode(metric, service, scoreServices);
        }else if(metric.isModule()){
            result = new ScoreSummaryModuleNode(metric, service, scoreServices);
        }

        return result;
    }
}
