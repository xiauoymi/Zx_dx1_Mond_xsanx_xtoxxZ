package com.monsanto.metricspos.core.metrics.summary;

import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.math.BigDecimal;

/**
 * Summary class which represents a SubMetric View.
 * User: BSBUON
 */
public class ScoreSummaryMetricNode extends ScoreSummaryNode {

    public ScoreSummaryMetricNode(Metric metric, ServiceCenter serviceCenter, ScoreServices scoreServices) {
        super(metric, serviceCenter, scoreServices);
    }

    @Override
    public void calculateDeductions(){
        BigDecimal deductionsTotal = BigDecimal.ONE;
        for(ScoreSummaryNode child : this.getChildren()) {
            if(child.getMetric().getWeighting()){
                deductionsTotal = deductionsTotal.multiply(child.getPoints().divide(new BigDecimal(100)));
            }
        }
        this.setDeductions(deductionsTotal);
        //BigDecimal discountPoints = (this.getPoints().multiply(this.getDeductions())).divide(new BigDecimal(100));
        this.points = this.getPoints().multiply(this.getDeductions());
    }

}
