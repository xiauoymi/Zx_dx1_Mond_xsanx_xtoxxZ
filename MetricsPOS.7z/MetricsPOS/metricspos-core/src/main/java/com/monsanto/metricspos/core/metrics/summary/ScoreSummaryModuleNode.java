package com.monsanto.metricspos.core.metrics.summary;

import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.math.BigDecimal;

/**
 * Summary class which represents a Module.
 * User: BSBUON
 */
public class ScoreSummaryModuleNode extends ScoreSummaryNode {

    public ScoreSummaryModuleNode(Metric metric, ServiceCenter serviceCenter, ScoreServices scoreServices) {
        super(metric, serviceCenter, scoreServices);
    }

    @Override
    public void calculateDeductions() {
        BigDecimal deductions = BigDecimal.ZERO;
        setDeductions(deductions);
    }
}
