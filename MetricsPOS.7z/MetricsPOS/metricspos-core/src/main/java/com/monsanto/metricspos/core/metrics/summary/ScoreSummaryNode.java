package com.monsanto.metricspos.core.metrics.summary;

import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.apache.log4j.Logger;

import java.math.BigDecimal;

/**
 * Middle node or leaf of the summary tree. Adds up what it's children return or
 * returns a concrete number if it is a leaf.
 *
 * User: PPERA
 */

public abstract class ScoreSummaryNode extends ScoreSummary {


    private static Logger log = Logger.getLogger(ScoreSummaryNode.class);

    private Metric metric;
    private ServiceCenter serviceCenter;
    private ScoreServices scoreServices;
    private Boolean computeError = Boolean.FALSE;
    private String percentageIncent;
    private String category;

    public ScoreSummaryNode(Metric metric, ServiceCenter serviceCenter, ScoreServices scoreServices) {
        super(metric, serviceCenter, scoreServices);
        this.metric = metric;
        this.serviceCenter = serviceCenter;
        this.scoreServices = scoreServices;
        this.initializeNode();
    }

    protected MetricScore getMetricScore() {
        // TODO this should't be excecuted more that what's extrictly necessary
//        this.metric.compute(serviceCenter);
        return this.scoreServices.findScoreByMetricAndServiceCenter(metric, serviceCenter);
    }


    public Metric getMetric() {
        return metric;
    }


    public Boolean getComputeError() {
        return computeError;
    }

    @Override
    public void initializeNode() {
        this.initializePoints();
        this.calculateDeductions();
        this.initializeMaxPoints();
    }

    private void initializeMaxPoints() {
        if (!this.hasChildren()) {
            this.maxPoints = this.getMetric().getMaxPoints();
            if (this.maxPoints == null) {
                this.maxPoints = 0;
            }

        } else {

            this.maxPoints = this.getChildrenMaxPointsSum();
        }
    }

    
    private Integer getChildrenMaxPointsSum() {
        Integer total = 0;

        for (ScoreSummaryNode node : this.getChildren()) {
            try {
                total = total + node.getMaxPoints();
            } catch (Exception e) {
                this.maxPoints = 0;
                this.computeError = true;
            }
        }

        return total;
    }

    private void initializePoints() {
        if (!this.hasChildren()) {
            try {
                this.points = this.getMetricScore().getPoints();
            } catch (Exception e) {
                this.points = BigDecimal.ZERO;
                this.computeError = true;
            }
        } else {
            this.points = this.getChildrenPoints();
        }
    }

    public boolean isNoComputed() {
        return computeError;
    }

    public ServiceCenter getServiceCenter() {
        return serviceCenter;
    }

    /*
    public boolean containsDeductions(){
        return getDeductions() != null && getDeductions().compareTo(BigDecimal.ZERO) > 0;
    } */
    /**
     * generate ScoreDeduction from the formula in the metric.
     * //@param metric
     * @return
     */
    /*
    protected BigDecimal generateDeductions(Metric metric) {
        if(metric.getFormula()==null || metric.getFormula().isEmpty()) {
            log.debug("Metric: " + metric.getName() + " Doesn't contains formula." );
            return BigDecimal.ZERO;
        }

        metric.computeModuleFormula(this);
        BigDecimal aux = BigDecimal.ZERO;
        if(this.getPercentageIncent()!=null && !this.getPercentageIncent().isEmpty()){
            aux = BigDecimal.valueOf(Long.parseLong(this.getPercentageIncent()));
        }
        return aux;
    }*/

    public abstract void calculateDeductions();


    public String getPercentageIncent() {
        return percentageIncent;
    }

    public void setPercentageIncent(String percentageIncent) {
        this.percentageIncent = percentageIncent;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getQuantityChildren(){
        return metric.getQuantityChildren();
    }
}
