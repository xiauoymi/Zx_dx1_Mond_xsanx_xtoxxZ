package com.monsanto.metricspos.core.security;

import org.apache.log4j.jdbc.JDBCAppender;
import org.apache.log4j.spi.ErrorCode;
import org.springframework.security.Authentication;
import org.springframework.security.context.SecurityContextHolder;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * An extension of a DataBase appender that uses JNDI to get a connection.
 *
 * User: PPERA
 */
public class DataSourceAppender extends JDBCAppender {
    private static final Pattern SQL_VALUE_PATTERN = Pattern.compile("'(.*?)'(?=\\s*[,)])", Pattern.MULTILINE);

    private String jndiDataSource;
    private int dateColumnIndex;
    private static final String USERNAME_PLACEHOLDER = "@u";

    public String getJndiDataSource() {
        return jndiDataSource;
    }

    public void setJndiDataSource(String jndiDataSource) {
        this.jndiDataSource = jndiDataSource;
    }

    public int getDateColumnIndex() {
        return dateColumnIndex;
    }

    public void setDateColumnIndex(int dateColumnIndex) {
        this.dateColumnIndex = dateColumnIndex;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected Connection getConnection() throws SQLException {
        if (jndiDataSource == null) {
            throw new RuntimeException("Cannot find JNDI DataSource property value");
        } else {
            return lookupDataSource().getConnection();
        }
    }

    /**
     * Looks up the datasource in the naming context specified by the
     * {@link #jndiDataSource}.
     *
     * @return the datasource.
     */
    private DataSource lookupDataSource() {
        try {
            Context context = new InitialContext();
            return (DataSource) context.lookup(jndiDataSource);
        } catch (NamingException e) {
            throw new RuntimeException("Cannot find JNDI DataSource: " + jndiDataSource, e);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void closeConnection(Connection con) {
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            errorHandler.error("Failed to close connection", e, ErrorCode.CLOSE_FAILURE);
        }
    }

    /**
     * Executes the specified SQL statement, by parsing its values and turning
     * them into parameters, so that characters that must be escaped in a SQL
     * statement are supported.
     */
    @Override
    protected void execute(String sql) throws SQLException {
        String statement = sql;
        ArrayList<String> args = new ArrayList<String>();
        Matcher m = SQL_VALUE_PATTERN.matcher(sql);
        while (m.find()) {
            args.add(m.group(1));
            statement = statement.replace(m.group(), "?");
        }

        executeStatement(statement, args.toArray(new String[args.size()]));
    }

    /**
     * Executes the statement settings its parameters to the specified arguments.
     *
     * @param statement the statement to execute.
     * @param args      the parameter values.
     */
    protected void executeStatement(String statement, String[] args) throws SQLException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = "BATCHPROCESS";
        if(authentication != null){
            username = ((UserWrapper) authentication.getPrincipal()).getUser().getUsername();
        }
        Connection con = getConnection();
        PreparedStatement stmt = null;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss,SSS");
        try {
            stmt = con.prepareStatement(statement);
            for (int i = 0; i < args.length; i++) {
                if ((i + 1) == dateColumnIndex) {
                    try {
                        stmt.setTimestamp(i + 1, new Timestamp(dateFormat.parse(args[i]).getTime()));
                    } catch (ParseException e) {
                        stmt.setTimestamp(1, new Timestamp(new java.util.Date().getTime()));
                    }
                } else {
                    stmt.setString(i + 1, args[i].replace(USERNAME_PLACEHOLDER, username));
                }
            }
            stmt.executeUpdate();
        } catch (Exception e) {
            throw new SQLException(e);
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            closeConnection(con);
        }
    }
}
