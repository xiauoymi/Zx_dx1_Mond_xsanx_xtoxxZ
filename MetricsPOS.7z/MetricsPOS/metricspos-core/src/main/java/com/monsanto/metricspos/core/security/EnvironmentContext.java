package com.monsanto.metricspos.core.security;

/**
 * Provides information about the environment the application is running.
 *
 * @author CAFAU
 */
public interface EnvironmentContext {
    boolean isLocalEnvironment();

    boolean isDevEnvironment();

    String getEnvironment();
}
