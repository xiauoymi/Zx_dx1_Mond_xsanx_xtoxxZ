package com.monsanto.metricspos.core.security;

import com.monsanto.metricspos.core.structure.Employee;

import java.io.Serializable;
import java.util.List;

/**
 * Represent a group of employees sharing some authorities on application actions.
 *
 * @author Carlos Fau
 */
public class Group implements Serializable {

    private Integer id;

    private String name;

    private List<Authority> authorities;

    private List<Employee> members;

    private boolean enabled;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Authority> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(List<Authority> authorities) {
        this.authorities = authorities;
    }

    public List<Employee> getMembers() {
        return members;
    }

    public void setMembers(List<Employee> members) {
        this.members = members;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public String toString() {
        return "Group{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", enabled=" + enabled +
                '}';
    }
}
