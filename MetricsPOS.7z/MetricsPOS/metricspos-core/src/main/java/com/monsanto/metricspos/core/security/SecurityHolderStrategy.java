package com.monsanto.metricspos.core.security;


/**
 * Strategy to provide access to the security data (user)
 * TODO change this object name
 *
 * @author CAFAU
 */
public interface SecurityHolderStrategy {

    public static final String ALL_SERVICE_CENTERS = "ALL_SERVICE_CENTERS"; // Move this to a proper class

    User getCurrentUser();

    /**
     * Returns true if the user has the required permission.
     * False if not.
     *
     * @param permission the permission to check.
     * @return true is user has the permission
     */
    boolean hasUserPermission(String permission);

    /**
     * @return True if this running environment is for Local Development
     */
    public boolean isLocalEnvironment();

    /**
     * @return True if this running environment is for Development
     */
    public boolean isDevEnvironment();

    /**
     * set the current User from campaignId (for the case of employees)
     * @param campaignId
     */
    public void setCurrentUser(Integer campaignId);
}
