package com.monsanto.metricspos.core.security;

/**
 * User: PPERA
 */
public interface User {
    String getUsername();

    boolean isEnabled();

    boolean isAdmin();
}
