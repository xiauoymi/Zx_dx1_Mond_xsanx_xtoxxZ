package com.monsanto.metricspos.core.security;

/**
 * Allow access to wrapped user
 *
 * @author CAFAU
 */
public interface UserWrapper {
    User getUser();

    public void setCurrentUser(Integer campaignId);
}
