package com.monsanto.metricspos.core.structure;

import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.security.User;

import java.util.List;

/**
 * A regular user that needs permissions to operate the application. There can be
 * many instances by username but each with different campaign.
 *
 * User: PPERA
 */
public class Employee implements User {
    private Campaign campaign;
    private Long id;
    private Boolean loaded = Boolean.FALSE;
    private String name;
    private String username;
    private boolean enabled;
    private List<Group> groups;
    private List<Metric> metrics;
    private List<ServiceCenter> serviceCenters;

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public void setLoaded(boolean loaded) {
        this.loaded = loaded;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public boolean isAdmin() {
        return false;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public List<Group> getGroups() {
        return groups;
    }

    public void setGroups(List<Group> groups) {
        this.groups = groups;
    }

    public List<Metric> getMetrics() {
        return metrics;
    }

    public void setMetrics(List<Metric> metrics) {
        this.metrics = metrics;
    }

    public List<ServiceCenter> getServiceCenters() {
        return serviceCenters;
    }

    public void setServiceCenters(List<ServiceCenter> serviceCenters) {
        this.serviceCenters = serviceCenters;
    }

    public String getUsername() {
        return username;
    }

    public boolean getLoaded() {
        return loaded;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", username='" + username + '\'' +
                ", enabled=" + enabled +
                '}';
    }
}
