package com.monsanto.metricspos.core.structure;

import com.monsanto.metricspos.core.metrics.Campaign;

/**
 *
 * A point of sale of a given service center.
 *
 * User: PPERA
 */
public class PointOfSale {

    private Long idSap;
    private String salesGroup;
    private String region;
    private String type;
    private Long tsrcId;
    private String customer;
    private String locality;
    private String county;
    private String state;
    private String address;
    private String phone;
    private String mail;
    private ServiceCenter serviceCenter;
    private Campaign campaign;
    private Boolean loaded = Boolean.FALSE;
    private Boolean deleted = Boolean.FALSE;

    public Long getIdSap() {
        return idSap;
    }

    public void setIdSap(Long idSap) {
        this.idSap = idSap;
    }

    public String getSalesGroup() {
        return salesGroup;
    }

    public void setSalesGroup(String salesGroup) {
        this.salesGroup = salesGroup;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Long getTsrcId() {
        return tsrcId;
    }

    public void setTsrcId(Long tsrcId) {
        this.tsrcId = tsrcId;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public ServiceCenter getServiceCenter() {
        return serviceCenter;
    }

    public void setServiceCenter(ServiceCenter serviceCenter) {
        this.serviceCenter = serviceCenter;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public void setLoaded(Boolean loaded) {
        this.loaded = loaded;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public Boolean getLoaded() {
        return loaded;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    @Override
    public String toString() {
        return "PointOfSale{" +
                "idSap=" + idSap +
                ", salesGroup='" + salesGroup + '\'' +
                ", region='" + region + '\'' +
                ", type='" + type + '\'' +
                ", tsrcId=" + tsrcId +
                ", customer='" + customer + '\'' +
                ", locality='" + locality + '\'' +
                ", county='" + county + '\'' +
                ", state='" + state + '\'' +
                ", address='" + address + '\'' +
                ", phone='" + phone + '\'' +
                ", mail='" + mail + '\'' +
                '}';
    }
}
