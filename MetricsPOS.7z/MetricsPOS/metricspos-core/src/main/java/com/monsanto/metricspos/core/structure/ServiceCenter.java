package com.monsanto.metricspos.core.structure;

import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.MetricScore;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Represents each service center in a campaign. A ServiceCenter Instance might have the same cuit
 * as another instance but different campaign. This means the data asociated to a service center is
 * also connected to a campaign. A Service Center might exist in one campaign but not in the other.
 *
 * @author CAFAU
 */
public class ServiceCenter implements Serializable {

    private Campaign campaign;
    private String cuit;


    /**
     * Indicates that this record was created or updated in the last process of data loading
     */
    private boolean loaded;

    /**
     * Indicates that this records was created manually and not by the automatic loading process
     */
    private boolean manual;
    private String name;
    private String mail;
    private List<PointOfSale> pointsOfSale;
    private List<Employee> employees;
    private List<MetricScore> scores;
    private boolean deleted;
    private Date lastTimeSent;

    private String rtv;
    private String management;

    public boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public List<PointOfSale> getPointsOfSale() {
        return pointsOfSale;
    }

    public void setPointsOfSale(List<PointOfSale> pointOfSales) {
        this.pointsOfSale = pointOfSales;
    }

    public List<MetricScore> getScores() {
        return scores;
    }

    public void setScores(List<MetricScore> scores) {
        this.scores = scores;
    }

    public void setLoaded(boolean loaded) {
        this.loaded = loaded;
    }

    public boolean isLoaded() {
        return loaded;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public boolean isManual() {
        return manual;
    }

    public void setManual(boolean manual) {
        this.manual = manual;
    }

    @Override
    public String toString() {
        return this.cuit;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }

    public Date getLastTimeSent() {
        return lastTimeSent;
    }

    public void setLastTimeSent(Date lastTimeSent) {
        this.lastTimeSent = lastTimeSent;
    }

    public String getRtv() {
        return rtv;
    }

    public void setRtv(String rtv) {
        this.rtv = rtv;
    }

    public String getManagement() {
        return management;
    }

    public void setManagement(String management) {
        this.management = management;
    }
}
