package com.monsanto.metricspos.persistence;

import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataFile;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.util.List;
import java.util.Map;

/**
 * Persists and retrieves values from an implementation of a DataRow
 *
 * @author CAFAU
 */
public interface DataRowPersistor {
    void set(Object rowValues, String columnName, Object value);

    Object get(Object rowValues, String columnName);

    Object newRowValues();

    String getActualColumnName(String columnName);

    Integer getInternalId(Object rowValues);

    Object makeRowValues(Map<String, Object> rowData);

    boolean getManual(Object dataRow);

    void setManual(Object rowValues, boolean manual);

    void setLoaded(Object rowValues, boolean loaded);

    ServiceCenter getServiceCenter(Object rowValues);

    void setServiceCenter(Object rowValues, ServiceCenter serviceCenter);

    PointOfSale getPointOfSale(Object rowValues);

    void setPointOfSale(Object rowValues, PointOfSale pointOfSale);

    DataFile getDataFile(Object rowValues);

    void assignActualColumnNames(List<DataColumn> dataColumns);

    String getServiceCenterColumnActualName();

    void setDeleted(Object rowValues, boolean deleted);
}
