package com.monsanto.metricspos.persistence;

import com.monsanto.metricspos.core.externaldata.DataTable;

/**
 * Creates a data row persistor for a data table
 *
 * @author CAFAU
 */
public interface DataRowPersistorFactory {
    DataRowPersistor buildDataRowPersistor(DataTable dataTable);
}
