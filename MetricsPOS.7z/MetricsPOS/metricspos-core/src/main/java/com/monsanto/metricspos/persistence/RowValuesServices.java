package com.monsanto.metricspos.persistence;

import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.util.List;
import java.util.Map;

/**
 * The repository is the main search interface with any persistence strategy. It needs to be
 * notified when a new memento is created and when its removed. The update should be handled
 * by the memento itself.
 *
 * @author PPERA
 */
public interface RowValuesServices {
    /**
     * Finds a page of rows of a table
     *
     * @param table     of the rows
     * @param page      page desired
     * @param rows      amount of rows by page
     * @param sort      sort property
     * @param direction direction of sort
     * @param filter    filter parameter
     * @return A list of rows
     */
    public List<Object> findRowsByDataTableAndPage(DataTable table, int page, int rows, String sort, String direction, Map<String, Object> filter);

    /**
     * Adds a row to the table
     *
     * @param rowValues row to add
     */
    void add(Object rowValues);

    /**
     * Remove a row from the application
     *
     * @param rowValues to remove
     */
    void remove(Object rowValues);

    /**
     * Finds a dataRow by id
     *
     * @param table      of the row
     * @param internalId of the row
     * @return the matching row
     */
    DataRow findDataRowByDataTableAndDataRowId(DataTable table, int internalId);

    /**
     * Counts rows matching filter in a table
     *
     * @param dataTable of row
     * @param filter    filter parameters
     * @return amount of matching rows
     */
    long countRows(DataTable dataTable, Map<String, Object> filter);

    /**
     * Marks all rows in a table as not loaded
     *
     * @param table of the row
     * @return amount of rows affected
     */
    long markTableRecordsAsNotLoaded(DataTable table);

    /**
     * Creates a row or updates it if it exists
     *
     * @param rowValues
     */
    void saveOrUpdate(Object rowValues);

    /**
     * Removes all not loaded rows
     *
     * @param dataTable of the rows
     * @return amount of rows deleted
     */
    long removeAllNotLoadedRecordsForTable(DataTable dataTable);

    /**
     * Cleans a physical column so that it can be reused by a different logical column
     *
     * @param dataTable  of the column
     * @param dataColumn new column that will use the physical column
     */
    void cleanColumnContents(DataTable dataTable, DataColumn dataColumn);

    /**
     * Clear the point of sales column so that it can be reused
     *
     * @param dataTable
     */
    void clearPointsOfSale(DataTable dataTable);

    /**
     * Clears the file data columns so that they can be reused
     *
     * @param dataTable
     */
    void clearFileDataContent(DataTable dataTable);

    /**
     * Finds a data row matching a filter in a table
     *
     * @param dataTable of the row
     * @param filter    filter parameters, usually the pk defined for the table
     * @return Single matching data row
     */
    DataRow findByTableAndFilter(DataTable dataTable, Map<String, Object> filter);

    /**
     * Finds a data row even if it is deleted
     *
     * @param dataTable of the row
     * @param filter    filter parameters, usually the pk defined for the table
     * @return Single matching data row
     */
    DataRow findByTableAndFilterEvenDeleted(DataTable dataTable, Map<String, Object> filter);

    /**
     * Finds the data rows of a table and a service center
     *
     * @param dataTable     of the row
     * @param serviceCenter of the service center
     * @return A list of rows
     */
    List<DataRow> findRowsByTableAndServiceCenter(DataTable dataTable, ServiceCenter serviceCenter);

    /**
     * Finds a list of rows sorted by the value of a physical column and filtered
     *
     * @param dataTable        of the row
     * @param actualColumnName property to sort
     * @param direction        direction of sort
     * @param filter           filter parameters
     * @return List of rows
     */
    List<Object> findRowsByDataTable(DataTable dataTable, String actualColumnName, String direction, Map<String, Object> filter);

    /**
     * Remove all the rows of a specific table
     *
     * @param dataTable        table to clear
     */
    void removeRowsByTable(DataTable dataTable);


}
