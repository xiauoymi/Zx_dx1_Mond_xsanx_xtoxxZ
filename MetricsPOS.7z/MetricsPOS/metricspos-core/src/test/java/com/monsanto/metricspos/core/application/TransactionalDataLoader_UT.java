package com.monsanto.metricspos.core.application;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.metricspos.core.*;
import com.monsanto.metricspos.core.application.adapters.DataTableTableAdapter;
import com.monsanto.metricspos.core.application.adapters.EmployeeTableAdapter;
import com.monsanto.metricspos.core.application.adapters.PointOfSaleTableAdapter;
import com.monsanto.metricspos.core.application.adapters.ServiceCenterTableAdapter;
import com.monsanto.metricspos.core.application.vo.CampaignVO;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricFactory;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.InOrder;

import java.util.List;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class TransactionalDataLoader_UT {
    private TransactionalDataLoader transactionalDataLoader;
    private CampaignServices campaignServices;
    private LoadManager loadManager;
    private DataTableServices tableServices;
    private Campaign campaign;
    private Campaign campaign1Scheduled;
    private Campaign campaign2Scheduled;
    private Campaign campaign3NotScheduled;
    private DataTable table1Scheduled;
    private DataTable table2Scheduled;
    private DataTable table3NotScheduled;
    private ServiceCenter serviceCenter;

    @Before
    public void setUp() {
        this.transactionalDataLoader = new TransactionalDataLoader();
        this.campaignServices = mock(CampaignServices.class);
        MetricsServices metricsServices = mock(MetricsServices.class);
        this.tableServices = mock(DataTableServices.class);
        this.loadManager = mock(LoadManager.class);
        DataProvider provider = new DataProvider();

        Logger auditLog = mock(Logger.class);
        field("auditLog").ofType(Logger.class).in(this.transactionalDataLoader).set(auditLog);

        field("loadManager").ofType(LoadManager.class).in(this.transactionalDataLoader).set(this.loadManager);
        field("campaignServices").ofType(CampaignServices.class).in(this.transactionalDataLoader).set(this.campaignServices);
        field("serviceCenterProvider").ofType(DataProvider.class).in(this.transactionalDataLoader).set(provider);
        field("tableServices").ofType(DataTableServices.class).in(this.transactionalDataLoader).set(this.tableServices);
        field("metricsServices").ofType(MetricsServices.class).in(this.transactionalDataLoader).set(metricsServices);

        campaign = new Campaign("Campaign to test", newDate(2011, 4, 1), newDate(2012, 3, 31));
        serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        serviceCenter.setName("Hi");
        campaign.setFactory(new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                final Metric metric = new Metric(campaign, name);
                metric.setId(1);

                metric.setScores(Sets.<MetricScore>newHashSet(new MetricScore(metric, serviceCenter)));
                return metric;
            }
        });

        campaign.setId(1);

        this.campaign1Scheduled = new Campaign("campaign1", newDate(2012, 4, 4), newDate(2013, 5, 8));
        this.campaign1Scheduled.setScheduled(true);
        this.campaign1Scheduled.setServiceCenterLoadSql("a");
        this.campaign1Scheduled.setServiceCenterLoadScript("b");
        this.campaign1Scheduled.setPointOfSaleLoadSql("c");
        this.campaign1Scheduled.setPointOfSaleLoadScript("d");

        this.campaign2Scheduled = new Campaign("campaign2", newDate(2012, 4, 4), newDate(2013, 5, 8));
        this.campaign2Scheduled.setScheduled(true);
        this.campaign2Scheduled.setServiceCenterLoadSql("aa");
        this.campaign2Scheduled.setServiceCenterLoadScript("bb");
        this.campaign2Scheduled.setPointOfSaleLoadSql("cc");
        this.campaign2Scheduled.setPointOfSaleLoadScript("dd");
        this.campaign3NotScheduled = new Campaign("campaign3", newDate(2012, 4, 4), newDate(2013, 5, 8));
        this.campaign3NotScheduled.setScheduled(false);

        List<DataColumn> columns1 = Lists.newArrayList();
        List<DataColumn> columns2 = Lists.newArrayList();
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        this.table1Scheduled = new DataTable("name1", columns1, dataRowPersistorFactory);
        this.table1Scheduled.setScheduled(true);
        this.table1Scheduled.setLoadSql("e");
        this.table1Scheduled.setLoadScript("f");
        this.table2Scheduled = new DataTable("name2", columns2, dataRowPersistorFactory);
        this.table2Scheduled.setScheduled(true);
        this.table2Scheduled.setLoadSql("ee");
        this.table2Scheduled.setLoadScript("ff");
        this.table3NotScheduled = new DataTable("name3", columns2, dataRowPersistorFactory);
        this.table3NotScheduled.setScheduled(false);
        this.table3NotScheduled.setLoadSql("eee");
        this.table3NotScheduled.setLoadScript("fff");
        this.campaign1Scheduled.setDataTables(Lists.<DataTable>newArrayList(this.table1Scheduled, this.table2Scheduled));
        this.campaign2Scheduled.setDataTables(Lists.<DataTable>newArrayList(this.table3NotScheduled));
        this.campaign3NotScheduled.setDataTables(Lists.<DataTable>newArrayList(this.table1Scheduled, this.table2Scheduled));

    }

    @Test
    public void testSaveAndExecuteCampaignLoadCallsUpdateCampaignWithMatchingCampaignAndInputVO_WhenExecutingLoadForCampaignOne() {
        // @Given a CampaignVO
        Campaign campaign = new Campaign("Name", newDate(2012, 1, 1), newDate(2015, 4, 6));
        campaign.setId(1);
        CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName(campaign.getName());
        campaignVO.setSince(campaign.getSince());
        campaignVO.setUntil(campaign.getUntil());
        campaignVO.setId(1);

        when(this.campaignServices.findCampaignById(campaignVO.getId())).thenReturn(campaign);

        // @When saving and executing the load for the table
        this.transactionalDataLoader.saveAndExecuteServiceCenterLoad(campaignVO);

        // @Then tableServices.updateDataTable is called with same VO
        verify(this.campaignServices, times(1)).updateCampaign(campaign, campaignVO);
    }

    @Test
    public void testSaveAndExecuteCampaignLoadCallsLoadManagerWithMatchingServiceCenterTableAdapter_WhenExecutingLoadForCampaignOne() {
        // @Given a CampaignVO
        Campaign campaign = new Campaign("Name", newDate(2012, 1, 1), newDate(2015, 4, 6));
        campaign.setServiceCenterLoadSql("loadSql");
        campaign.setServiceCenterLoadScript("loadScript");
        campaign.setId(1);
        final CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName(campaign.getName());
        campaignVO.setSince(campaign.getSince());
        campaignVO.setUntil(campaign.getUntil());
        campaignVO.setServiceCenterLoadSql(campaign.getServiceCenterLoadSql());
        campaignVO.setServiceCenterLoadScript(campaign.getServiceCenterLoadScript());
        campaignVO.setId(1);

        when(this.campaignServices.findCampaignById(campaignVO.getId())).thenReturn(campaign);

        // @When saving and executing the load for the table
        this.transactionalDataLoader.saveAndExecuteServiceCenterLoad(campaignVO);

        // @Then the updatedCampaign is returned
        verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ServiceCenterTableAdapter &&
                        ((ServiceCenterTableAdapter) argument).getLoadSql().equals(campaignVO.getServiceCenterLoadSql()) &&
                        ((ServiceCenterTableAdapter) argument).getLoadScript().equals(campaignVO.getServiceCenterLoadScript());
            }
        }));
    }

    @Test
    public void testSaveAndExecuteCampaignLoadCallsLoadManagerExecuteWithAMatchingServiceCenterTableAdapter_WhenExecutingLoad() {
        // @Given a CampaignVO with an SQL and a Script
        Campaign campaign = new Campaign("Name", newDate(2012, 1, 1), newDate(2015, 4, 6));
        campaign.setId(1);
        final CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName(campaign.getName());
        campaignVO.setSince(campaign.getSince());
        campaignVO.setUntil(campaign.getUntil());
        campaignVO.setId(1);

        when(this.campaignServices.findCampaignById(campaignVO.getId())).thenReturn(campaign);

        // @When saving and executing the load
        this.transactionalDataLoader.saveAndExecuteServiceCenterLoad(campaignVO);

        // @Then loadManager.execute is called
        this.loadManager.load(argThat(new ArgumentMatcher<ServiceCenterTableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof TableAdapter &&
                        ((TableAdapter) argument).getLoadSql().equals(campaignVO.getServiceCenterLoadSql()) &&
                        ((TableAdapter) argument).getLoadScript().equals(campaignVO.getServiceCenterLoadScript());
            }
        }));
    }

    @Test
    public void testSaveAndExecuteLoadCallsUpdateDataTableWithMatchingDataTableAndInputVO_WhenExecutingLoadForTableOne() throws Exception {
        // @Given a dataTableVo
        DataTableVO dataTableVO = new DataTableVO();
        dataTableVO.setId(1);
        DataTable dataTable = new DataTable();
        dataTable.setCampaign(this.campaign);
        when(this.tableServices.findDataTableById(dataTableVO.getId())).thenReturn(dataTable);

        // @When saving and executing the load for the table
        this.transactionalDataLoader.saveAndExecuteTableLoad(dataTableVO);

        // @Then tableServices.updateDataTable is called with same VO
        verify(this.tableServices, times(1)).updateDataTable(dataTable, dataTableVO);
    }

    @Test
    public void testSaveAndExecuteLoadCallsLoadManagerExecuteWithAMatchingTableAdapter_WhenExecutingLoad() throws Exception {
        // @Given a dataTableVO with an SQL and a Script
        final DataTableVO dataTableVO = new DataTableVO();
        dataTableVO.setId(1);
        dataTableVO.setLoadSql("Select 1;");
        dataTableVO.setLoadScript("return 1;");
        DataTable dataTable = new DataTable();
        dataTable.setCampaign(this.campaign);
        when(this.tableServices.findDataTableById(dataTableVO.getId())).thenReturn(dataTable);

        // @When saving and executing the load
        this.transactionalDataLoader.saveAndExecuteTableLoad(dataTableVO);

        // @Then loadManager.execute is called
        this.loadManager.load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof TableAdapter &&
                        ((TableAdapter) argument).getLoadSql().equals(dataTableVO.getLoadSql()) &&
                        ((TableAdapter) argument).getLoadScript().equals(dataTableVO.getLoadScript());
            }
        }));
    }

    @Test
    public void testSaveAndExecutePointOfSaleLoadCallsUpdateCampaignWithMatchingCampaignAndInputVO_WhenExecutingLoadForCampaignOne() {
        // @Given a CampaignVO
        Campaign campaign = new Campaign("Name", newDate(2012, 1, 1), newDate(2015, 4, 6));
        campaign.setId(1);
        CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName(campaign.getName());
        campaignVO.setSince(campaign.getSince());
        campaignVO.setUntil(campaign.getUntil());
        campaignVO.setId(1);

        when(this.campaignServices.findCampaignById(campaignVO.getId())).thenReturn(campaign);

        // @When saving and executing the load for the table
        this.transactionalDataLoader.saveAndExecutePointOfSaleLoad(campaignVO);

        // @Then tableServices.updateDataTable is called with same VO
        verify(this.campaignServices, times(1)).updateCampaign(campaign, campaignVO);
    }

    @Test
    public void testSaveAndExecutePointOfSaleLoadCallsLoadManagerWithMatchingServiceCenterTableAdapter_WhenExecutingLoadForCampaignOne() {
        // @Given a CampaignVO
        Campaign campaign = new Campaign("Name", newDate(2012, 1, 1), newDate(2015, 4, 6));
        campaign.setPointOfSaleLoadSql("loadSql");
        campaign.setPointOfSaleLoadScript("loadScript");
        campaign.setId(1);
        final CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName(campaign.getName());
        campaignVO.setSince(campaign.getSince());
        campaignVO.setUntil(campaign.getUntil());
        campaignVO.setPointOfSaleLoadSql(campaign.getPointOfSaleLoadSql());
        campaignVO.setPointOfSaleLoadScript(campaign.getPointOfSaleLoadScript());
        campaignVO.setId(1);

        when(this.campaignServices.findCampaignById(campaignVO.getId())).thenReturn(campaign);

        // @When saving and executing the load for the table
        this.transactionalDataLoader.saveAndExecutePointOfSaleLoad(campaignVO);

        // @Then the updatedCampaign is returned
        verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PointOfSaleTableAdapter &&
                        ((PointOfSaleTableAdapter) argument).getLoadSql().equals(campaignVO.getPointOfSaleLoadSql()) &&
                        ((PointOfSaleTableAdapter) argument).getLoadScript().equals(campaignVO.getPointOfSaleLoadScript());
            }
        }));
    }

    @Test
    public void testSaveAndExecutePointOfSaleLoadCallsLoadManagerExecuteWithAMatchingPointOfSaleTableAdapter_WhenExecutingLoad() {
        // @Given a CampaignVO with an SQL and a Script
        Campaign campaign = new Campaign("Name", newDate(2012, 1, 1), newDate(2015, 4, 6));
        campaign.setId(1);
        final CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName(campaign.getName());
        campaignVO.setSince(campaign.getSince());
        campaignVO.setUntil(campaign.getUntil());
        campaignVO.setId(1);

        when(this.campaignServices.findCampaignById(campaignVO.getId())).thenReturn(campaign);

        // @When saving and executing the load
        this.transactionalDataLoader.saveAndExecutePointOfSaleLoad(campaignVO);

        // @Then loadManager.execute is called
        this.loadManager.load(argThat(new ArgumentMatcher<PointOfSaleTableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof TableAdapter &&
                        ((TableAdapter) argument).getLoadSql().equals(campaignVO.getPointOfSaleLoadSql()) &&
                        ((TableAdapter) argument).getLoadScript().equals(campaignVO.getPointOfSaleLoadScript());
            }
        }));
    }

    @Test
    public void testSaveAndExecuteEmployeeLoadCallsUpdateCampaignWithMatchingCampaignAndInputVO_WhenExecutingLoadForCampaignOne() {
        // @Given a CampaignVO
        Campaign campaign = new Campaign("Name", newDate(2012, 1, 1), newDate(2015, 4, 6));
        campaign.setId(1);
        CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName(campaign.getName());
        campaignVO.setSince(campaign.getSince());
        campaignVO.setUntil(campaign.getUntil());
        campaignVO.setId(1);

        when(this.campaignServices.findCampaignById(campaignVO.getId())).thenReturn(campaign);

        // @When saving and executing the load for the table
        this.transactionalDataLoader.saveAndExecuteEmployeeLoad(campaignVO);

        // @Then tableServices.updateDataTable is called with same VO
        verify(this.campaignServices, times(1)).updateCampaign(campaign, campaignVO);
    }

    @Test
    public void testSaveAndExecuteEmployeeLoadCallsLoadManagerWithMatchingServiceCenterTableAdapter_WhenExecutingLoadForCampaignOne() {
        // @Given a CampaignVO
        Campaign campaign = new Campaign("Name", newDate(2012, 1, 1), newDate(2015, 4, 6));
        campaign.setEmployeeLoadSql("loadSql");
        campaign.setEmployeeLoadScript("loadScript");
        campaign.setId(1);
        final CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName(campaign.getName());
        campaignVO.setSince(campaign.getSince());
        campaignVO.setUntil(campaign.getUntil());
        campaignVO.setEmployeeLoadSql(campaign.getEmployeeLoadSql());
        campaignVO.setEmployeeLoadScript(campaign.getEmployeeLoadScript());
        campaignVO.setId(1);

        when(this.campaignServices.findCampaignById(campaignVO.getId())).thenReturn(campaign);

        // @When saving and executing the load for the table
        this.transactionalDataLoader.saveAndExecuteEmployeeLoad(campaignVO);

        // @Then the updatedCampaign is returned
        verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof EmployeeTableAdapter &&
                        ((EmployeeTableAdapter) argument).getLoadSql().equals(campaignVO.getEmployeeLoadSql()) &&
                        ((EmployeeTableAdapter) argument).getLoadScript().equals(campaignVO.getEmployeeLoadScript());
            }
        }));
    }

    @Test
    public void testSaveAndExecuteEmployeeLoadCallsLoadManagerExecuteWithAMatchingEmployeeTableAdapter_WhenExecutingLoad() {
        // @Given a CampaignVO with an SQL and a Script
        Campaign campaign = new Campaign("Name", newDate(2012, 1, 1), newDate(2015, 4, 6));
        campaign.setId(1);
        final CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName(campaign.getName());
        campaignVO.setSince(campaign.getSince());
        campaignVO.setUntil(campaign.getUntil());
        campaignVO.setId(1);

        when(this.campaignServices.findCampaignById(campaignVO.getId())).thenReturn(campaign);

        // @When saving and executing the load
        this.transactionalDataLoader.saveAndExecuteEmployeeLoad(campaignVO);

        // @Then loadManager.execute is called
        this.loadManager.load(argThat(new ArgumentMatcher<EmployeeTableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof TableAdapter &&
                        ((TableAdapter) argument).getLoadSql().equals(campaignVO.getEmployeeLoadSql()) &&
                        ((TableAdapter) argument).getLoadScript().equals(campaignVO.getEmployeeLoadScript());
            }
        }));
    }

    @Test
    public void testExecuteCallsDataLoaderToLoadServiceCentersForCampaignOneAndTwo_WhenExecutingJobsForCampaignsOneAndTwoBothScheduled() {
        // @Given existing campaigns one and two, both scheduled
        when(this.campaignServices.listAllCampaignsForBatch()).thenReturn(Lists.<Campaign>newArrayList(this.campaign1Scheduled, this.campaign2Scheduled));

        // @When executing the CampaignLoadJob
        this.transactionalDataLoader.executeBatchLoad();

        // @Then the service centers are loaded for both campaigns
        verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ServiceCenterTableAdapter &&
                        ((ServiceCenterTableAdapter) argument).getLoadSql().equals(campaign1Scheduled.getServiceCenterLoadSql()) &&
                        ((ServiceCenterTableAdapter) argument).getLoadScript().equals(campaign1Scheduled.getServiceCenterLoadScript());
            }
        }));
        verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ServiceCenterTableAdapter &&
                        ((ServiceCenterTableAdapter) argument).getLoadSql().equals(campaign2Scheduled.getServiceCenterLoadSql()) &&
                        ((ServiceCenterTableAdapter) argument).getLoadScript().equals(campaign2Scheduled.getServiceCenterLoadScript());
            }
        }));
    }

    @Test
    public void testExecuteCallsDataLoaderToLoadServiceCentersForCampaignTwo_WhenExecutingJobsForCampaignsTwoAndThreeAndThreeIsNotScheduled() {
        // @Given existing campaigns one and two, both scheduled
        when(this.campaignServices.listAllCampaignsForBatch()).thenReturn(Lists.<Campaign>newArrayList(this.campaign2Scheduled, this.campaign3NotScheduled));

        // @When executing the CampaignLoadJob
        this.transactionalDataLoader.executeBatchLoad();

        // @Then the service centers are loaded for both campaigns
        verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ServiceCenterTableAdapter &&
                        ((ServiceCenterTableAdapter) argument).getLoadSql().equals(campaign2Scheduled.getServiceCenterLoadSql()) &&
                        ((ServiceCenterTableAdapter) argument).getLoadScript().equals(campaign2Scheduled.getServiceCenterLoadScript());
            }
        }));
        verify(this.loadManager, times(0)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ServiceCenterTableAdapter &&
                        ((ServiceCenterTableAdapter) argument).getLoadSql().equals(campaign3NotScheduled.getServiceCenterLoadSql()) &&
                        ((ServiceCenterTableAdapter) argument).getLoadScript().equals(campaign3NotScheduled.getServiceCenterLoadScript());
            }
        }));
    }

    @Test
    public void testExecuteCallsDataLoaderToLoadPointsOfSaleForCampaignOneAndTwo_WhenExecutingJobsForCampaignsOneAndTwoBothScheduled() {
        // @Given existing campaigns one and two, both scheduled
        when(this.campaignServices.listAllCampaignsForBatch()).thenReturn(Lists.<Campaign>newArrayList(this.campaign1Scheduled, this.campaign2Scheduled));

        // @When executing the CampaignLoadJob
        this.transactionalDataLoader.executeBatchLoad();

        // @Then points of sales are loaded for both campaigns
        verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PointOfSaleTableAdapter &&
                        ((PointOfSaleTableAdapter) argument).getLoadSql().equals(campaign1Scheduled.getPointOfSaleLoadSql()) &&
                        ((PointOfSaleTableAdapter) argument).getLoadScript().equals(campaign1Scheduled.getPointOfSaleLoadScript());
            }
        }));
        verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PointOfSaleTableAdapter &&
                        ((PointOfSaleTableAdapter) argument).getLoadSql().equals(campaign2Scheduled.getPointOfSaleLoadSql()) &&
                        ((PointOfSaleTableAdapter) argument).getLoadScript().equals(campaign2Scheduled.getPointOfSaleLoadScript());
            }
        }));
    }

    @Test
    public void testExecuteCallsDataLoaderToLoadPointsOfSaleForCampaignOne_WhenExecutingJobsForCampaignsOneAndThreeAndThreeIsNotScheduled() {
        // @Given existing campaigns one and two, both scheduled
        when(this.campaignServices.listAllCampaignsForBatch()).thenReturn(Lists.<Campaign>newArrayList(this.campaign1Scheduled, this.campaign3NotScheduled));

        // @When executing the CampaignLoadJob
        this.transactionalDataLoader.executeBatchLoad();

        // @Then points of sales are loaded for both campaigns
        verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PointOfSaleTableAdapter &&
                        ((PointOfSaleTableAdapter) argument).getLoadSql().equals(campaign1Scheduled.getPointOfSaleLoadSql()) &&
                        ((PointOfSaleTableAdapter) argument).getLoadScript().equals(campaign1Scheduled.getPointOfSaleLoadScript());
            }
        }));
        verify(this.loadManager, times(0)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PointOfSaleTableAdapter &&
                        ((PointOfSaleTableAdapter) argument).getLoadSql().equals(campaign3NotScheduled.getPointOfSaleLoadSql()) &&
                        ((PointOfSaleTableAdapter) argument).getLoadScript().equals(campaign3NotScheduled.getPointOfSaleLoadScript());
            }
        }));
    }

    @Test
    public void testExecuteCallsDataLoaderToLoadDataTableForTableOneAndTwo_WhenExecutingJobsForCampaignsOneScheduledContainingTableOneAndTwoBothScheduled() {
        // @Given existing campaigns one which is scheduled and has two tables, both scheduled
        when(this.campaignServices.listAllCampaignsForBatch()).thenReturn(Lists.<Campaign>newArrayList(this.campaign1Scheduled));

        // @When executing the CampaignLoadJob
        this.transactionalDataLoader.executeBatchLoad();

        // @Then table data is loaded for both tables
        verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof DataTableTableAdapter &&
                        ((DataTableTableAdapter) argument).getLoadSql().equals(table1Scheduled.getLoadSql()) &&
                        ((DataTableTableAdapter) argument).getLoadScript().equals(table1Scheduled.getLoadScript());
            }
        }));
        verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof DataTableTableAdapter &&
                        ((DataTableTableAdapter) argument).getLoadSql().equals(table2Scheduled.getLoadSql()) &&
                        ((DataTableTableAdapter) argument).getLoadScript().equals(table2Scheduled.getLoadScript());
            }
        }));
    }

    @Test
    public void testExecuteCallsLoadSCAndPOSAndTablesInThatOrder_WhenExecutingJobsForCampaignsOneScheduledContainingTableOneAndTwoBothScheduled() {
        // @Given existing campaigns one which is scheduled and has two tables, both scheduled
        when(this.campaignServices.listAllCampaignsForBatch()).thenReturn(Lists.<Campaign>newArrayList(this.campaign1Scheduled));

        // @When executing the CampaignLoadJob
        this.transactionalDataLoader.executeBatchLoad();

        // @Then table data is loaded for both tables
        InOrder inOrder = inOrder(this.loadManager);
        inOrder.verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ServiceCenterTableAdapter &&
                        ((ServiceCenterTableAdapter) argument).getLoadSql().equals(campaign1Scheduled.getServiceCenterLoadSql()) &&
                        ((ServiceCenterTableAdapter) argument).getLoadScript().equals(campaign1Scheduled.getServiceCenterLoadScript());
            }
        }));
        inOrder.verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PointOfSaleTableAdapter &&
                        ((PointOfSaleTableAdapter) argument).getLoadSql().equals(campaign1Scheduled.getPointOfSaleLoadSql()) &&
                        ((PointOfSaleTableAdapter) argument).getLoadScript().equals(campaign1Scheduled.getPointOfSaleLoadScript());
            }
        }));
        inOrder.verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof DataTableTableAdapter &&
                        ((DataTableTableAdapter) argument).getLoadSql().equals(table1Scheduled.getLoadSql()) &&
                        ((DataTableTableAdapter) argument).getLoadScript().equals(table1Scheduled.getLoadScript());
            }
        }));
        inOrder.verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof DataTableTableAdapter &&
                        ((DataTableTableAdapter) argument).getLoadSql().equals(table2Scheduled.getLoadSql()) &&
                        ((DataTableTableAdapter) argument).getLoadScript().equals(table2Scheduled.getLoadScript());
            }
        }));
    }

    @Test
    public void testExecuteCallsLoadSCAndPOSAndNotTablesInThatOrder_WhenExecutingJobsForCampaignsTwoScheduledContainingTableThatIsNotScheduled() {
        // @Given existing campaigns one which is scheduled and has two tables, both scheduled
        when(this.campaignServices.listAllCampaignsForBatch()).thenReturn(Lists.<Campaign>newArrayList(this.campaign2Scheduled));

        // @When executing the CampaignLoadJob
        this.transactionalDataLoader.executeBatchLoad();

        // @Then table data is loaded for both tables
        InOrder inOrder = inOrder(this.loadManager);
        inOrder.verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ServiceCenterTableAdapter &&
                        ((ServiceCenterTableAdapter) argument).getLoadSql().equals(campaign2Scheduled.getServiceCenterLoadSql()) &&
                        ((ServiceCenterTableAdapter) argument).getLoadScript().equals(campaign2Scheduled.getServiceCenterLoadScript());
            }
        }));
        inOrder.verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PointOfSaleTableAdapter &&
                        ((PointOfSaleTableAdapter) argument).getLoadSql().equals(campaign2Scheduled.getPointOfSaleLoadSql()) &&
                        ((PointOfSaleTableAdapter) argument).getLoadScript().equals(campaign2Scheduled.getPointOfSaleLoadScript());
            }
        }));
        inOrder.verify(this.loadManager, times(0)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof DataTableTableAdapter &&
                        ((DataTableTableAdapter) argument).getLoadSql().equals(table3NotScheduled.getLoadSql()) &&
                        ((DataTableTableAdapter) argument).getLoadScript().equals(table3NotScheduled.getLoadScript());
            }
        }));
    }

    @Test
    public void testUpdateLastRunCallsTableServicesFindDataTableById1_WhenUpdatingTable1LastRun() {
        // @Given a data table id
        int dataTableId = 1;
        boolean succeed = true;

        // @When updating the table's last run
        this.transactionalDataLoader.updateLastRun(1, succeed);

        // @Then tableServices.findDataTableById 1 is called
        verify(this.tableServices, times(1)).findDataTableById(dataTableId);
    }

    @Test
    public void testUpdateLastRunCallsTableServicesFindDataTableById2_WhenUpdatingTable2LastRun() {
        // @Given a data table id
        int dataTableId = 1;
        boolean succeed = true;

        // @When updating the table's last run
        this.transactionalDataLoader.updateLastRun(1, succeed);

        // @Then tableServices.findDataTableById 1 is called
        verify(this.tableServices, times(1)).findDataTableById(dataTableId);
    }

    @Test
    public void testUpdateLastRunCallsTableServicesUpdateLastRunWithFoundTableAndTrue_WhenUpdatingTable2LastRunSuccessTrue() {
        // @Given a data table id
        int dataTableId = 1;
        boolean succeed = true;
        DataTable dataTable = new DataTable();
        when(this.tableServices.findDataTableById(1)).thenReturn(dataTable);

        // @When updating the table's last run
        this.transactionalDataLoader.updateLastRun(1, succeed);

        // @Then tableServices.findDataTableById 1 is called
        verify(this.tableServices, times(1)).updateLastRun(this.tableServices.findDataTableById(dataTableId), succeed);
    }

    @Test
    public void testUpdateLastRunCallsTableServicesUpdateLastRunWithFoundTableAndFalse_WhenUpdatingTable2LastRunSuccessFalse() {
        // @Given a data table id
        int dataTableId = 1;
        boolean succeed = false;
        DataTable dataTable = new DataTable();
        when(this.tableServices.findDataTableById(1)).thenReturn(dataTable);

        // @When updating the table's last run
        this.transactionalDataLoader.updateLastRun(1, succeed);

        // @Then tableServices.findDataTableById 1 is called
        verify(this.tableServices, times(1)).updateLastRun(this.tableServices.findDataTableById(dataTableId), succeed);
    }

    @Test
    public void testExecuteAllTablesLoadCallsCampaignServicesFindCampaignById1_WhenLoadingAllTablesOfCampaign1() {
        // @Given a campaignId 1
        int campaignId = 1;
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When loading all tables for that campaign
        this.transactionalDataLoader.executeAllTablesLoad(campaignId);

        // @Then campaignServices.findCampaignById 1 is called
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testExecuteAllTablesLoadCallsCampaignServicesFindCampaignById5_WhenLoadingAllTablesOfCampaign5() {
        // @Given a campaignId 5
        int campaignId = 5;
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When loading all tables for that campaign
        this.transactionalDataLoader.executeAllTablesLoad(campaignId);

        // @Then campaignServices.findCampaignById 1 is called
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testExecuteCallsLoadTablesAndNotSCAndPOSInThatOrder_WhenExecutingJobsForCampaignsThreeNotScheduledContainingTableOneAndTwoBothScheduled() {
        // @Given existing campaigns one which is scheduled and has two tables, both scheduled
        when(this.campaignServices.listAllCampaignsForBatch()).thenReturn(Lists.<Campaign>newArrayList(this.campaign3NotScheduled));

        // @When executing the CampaignLoadJob
        this.transactionalDataLoader.executeBatchLoad();

        // @Then table data is loaded for both tables
        InOrder inOrder = inOrder(this.loadManager);
        inOrder.verify(this.loadManager, times(0)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ServiceCenterTableAdapter &&
                        ((ServiceCenterTableAdapter) argument).getLoadSql().equals(campaign3NotScheduled.getServiceCenterLoadSql()) &&
                        ((ServiceCenterTableAdapter) argument).getLoadScript().equals(campaign3NotScheduled.getServiceCenterLoadScript());
            }
        }));
        inOrder.verify(this.loadManager, times(0)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PointOfSaleTableAdapter &&
                        ((PointOfSaleTableAdapter) argument).getLoadSql().equals(campaign3NotScheduled.getPointOfSaleLoadSql()) &&
                        ((PointOfSaleTableAdapter) argument).getLoadScript().equals(campaign3NotScheduled.getPointOfSaleLoadScript());
            }
        }));
        inOrder.verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof DataTableTableAdapter &&
                        ((DataTableTableAdapter) argument).getLoadSql().equals(table1Scheduled.getLoadSql()) &&
                        ((DataTableTableAdapter) argument).getLoadScript().equals(table1Scheduled.getLoadScript());
            }
        }));
        inOrder.verify(this.loadManager, times(1)).load(argThat(new ArgumentMatcher<TableAdapter>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof DataTableTableAdapter &&
                        ((DataTableTableAdapter) argument).getLoadSql().equals(table2Scheduled.getLoadSql()) &&
                        ((DataTableTableAdapter) argument).getLoadScript().equals(table2Scheduled.getLoadScript());
            }
        }));
    }
}
