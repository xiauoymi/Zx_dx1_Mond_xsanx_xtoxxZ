package com.monsanto.metricspos.core.application;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.*;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.CampaignVO;
import com.monsanto.metricspos.core.application.vo.MetricScoreVO;
import com.monsanto.metricspos.core.application.vo.MetricVO;
import com.monsanto.metricspos.core.application.vo.PointOfSaleVO;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.externaldata.DataType;
import com.monsanto.metricspos.core.helpers.CoreTestsHelper;
import com.monsanto.metricspos.core.metrics.*;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import com.monsanto.metricspos.persistence.DataRowPersistor;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import com.monsanto.metricspos.persistence.RowValuesServices;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;

import java.math.BigDecimal;
import java.util.*;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class TransactionalMetricsApplication_UT {

    private TransactionalMetricsApplication transactionalMetricsApplication;
    private CampaignServices campaignServices;
    private MetricsServices metricServices;
    private Campaign campaign;

    private CoreTestsHelper coreTestsHelper;
    private ServiceCenterServices serviceCenterServices;
    private PointOfSaleServices pointOfSaleServices;
    private MailServices<ScoreSummaryCampaignNode> mailServices;
    private ScoreServices scoreServices;
    private DataTableServices tableServices;
    private MetricFactory factory;
    public ComputeManager computeManager;

    @Before
    public void setUp() {
        RowValuesServices rowValuesServices = mock(RowValuesServices.class);
        this.campaignServices = mock(CampaignServices.class);
        this.metricServices = mock(MetricsServices.class);
        this.serviceCenterServices = mock(ServiceCenterServices.class);
        this.pointOfSaleServices = mock(PointOfSaleServices.class);
        this.scoreServices = mock(ScoreServices.class);
        this.mailServices = mock(MailServices.class);
        this.tableServices = mock(DataTableServices.class);

        this.computeManager = mock(ComputeManager.class);

        campaign = new Campaign("Campaign to test", newDate(2011, 4, 1), newDate(2012, 3, 31));
        campaign.setComputeManager(this.computeManager);

        campaign.setFactory(new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                final Metric metric = new Metric(campaign, name);
                metric.setId(1);
                return metric;
            }
        });

        campaign.setId(1);
        campaign.setMetrics(Lists.<Metric>newArrayList());

        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode("CRM");

        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistor.getActualColumnName("aColumn")).thenReturn("TEXT1");
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        coreTestsHelper = new CoreTestsHelper(dataProvider, campaign, dataRowPersistorFactory);
        HashMap<String, DataType> dataTypeMap = Maps.newHashMap();
        dataTypeMap.put(coreTestsHelper.stringDataType().getCode(), coreTestsHelper.stringDataType());
        dataTypeMap.put(coreTestsHelper.serviceCenterDataType().getCode(), coreTestsHelper.serviceCenterDataType());
        dataTypeMap.put(coreTestsHelper.pointOfSaleDataType().getCode(), coreTestsHelper.pointOfSaleDataType());
        dataTypeMap.put(coreTestsHelper.enumDataType().getCode(), coreTestsHelper.enumDataType());
        DataTable dataTable = coreTestsHelper.newDataTable(10, "tableName", "description", Lists.newArrayList(coreTestsHelper.newDataColumn("columnName")), rowValuesServices);
        campaign.addDataTable(dataTable);
        campaign.setMetrics(Lists.<Metric>newArrayList());

        CampaignParameter campaignParameter1 = new CampaignParameter();
        campaignParameter1.setValue("hola@chau.com");
        when(this.campaignServices.findParameterByName(CampaignParameter.OVERRIDE_TO_PARAMETER)).thenReturn(campaignParameter1);

        CampaignParameter campaignParameter2 = new CampaignParameter();
        campaignParameter2.setValue("pdfname");
        when(this.campaignServices.findParameterByName(CampaignParameter.PDF_NAME_PARAMETER)).thenReturn(campaignParameter2);

        CampaignParameter campaignParameter3 = new CampaignParameter();
        campaignParameter3.setValue("xlsname");
        when(this.campaignServices.findParameterByName(CampaignParameter.XLS_NAME_PARAMETER)).thenReturn(campaignParameter3);

        CampaignParameter campaignParameter4 = new CampaignParameter();
        campaignParameter4.setValue("subject");
        when(this.campaignServices.findParameterByName(CampaignParameter.SUBJECT_PARAMETER)).thenReturn(campaignParameter4);

        CampaignParameter campaignParameter5 = new CampaignParameter();
        campaignParameter5.setValue("text");
        when(this.campaignServices.findParameterByName(CampaignParameter.TEXT_PARAMETER)).thenReturn(campaignParameter5);

        this.transactionalMetricsApplication = new TransactionalMetricsApplication();
        field("metricServices").ofType(MetricsServices.class).in(this.transactionalMetricsApplication).set(this.metricServices);
        field("campaignServices").ofType(CampaignServices.class).in(this.transactionalMetricsApplication).set(this.campaignServices);
        field("serviceCenterServices").ofType(ServiceCenterServices.class).in(this.transactionalMetricsApplication).set(this.serviceCenterServices);
        field("pointOfSaleServices").ofType(PointOfSaleServices.class).in(this.transactionalMetricsApplication).set(this.pointOfSaleServices);
        field("scoreServices").ofType(ScoreServices.class).in(this.transactionalMetricsApplication).set(this.scoreServices);
        field("mailServices").ofType(MailServices.class).in(this.transactionalMetricsApplication).set(this.mailServices);
        field("tableServices").ofType(DataTableServices.class).in(this.transactionalMetricsApplication).set(this.tableServices);

        Logger auditLog = mock(Logger.class);
        field("auditLog").ofType(Logger.class).in(this.transactionalMetricsApplication).set(auditLog);

        this.factory = new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                Metric metric = new Metric(campaign, name);
                metric.setMaxPoints(maxPoints);
                metric.setComputeManager(computeManager);
                metric.setScores(new HashSet<MetricScore>());
                return metric;
            }
        };
    }

    @Test
    public void testListAllCampaignsCallsCampaignServicesListAllCampaigns_WhenListingAllCampaigns() {
        // @Given existing campaigns
        List<Campaign> campaigns = Lists.newArrayList(
                coreTestsHelper.newCampaign("Campaign to test 1", newDate(2011, 4, 1), newDate(2012, 3, 31))
                , coreTestsHelper.newCampaign("Campaign to test 2", newDate(2011, 4, 1), newDate(2012, 3, 31))
        );
        when(this.campaignServices.listAllCampaigns()).thenReturn(campaigns);

        // @When requesting for all campaigns
        this.transactionalMetricsApplication.listAllCampaigns();

        // @Then all campaigns are returned
        verify(this.campaignServices, times(1)).listAllCampaigns();
    }

    @Test
    public void testListAllCampaignsReturnsTwoCampaigns_WhenTwoCampaignsExist() {
        // @Given existing campaigns
        List<Campaign> campaigns = Lists.newArrayList(
                coreTestsHelper.newCampaign("Campaign to test 1", newDate(2011, 4, 1), newDate(2012, 3, 31))
                , coreTestsHelper.newCampaign("Campaign to test 2", newDate(2011, 4, 1), newDate(2012, 3, 31))
        );
        when(this.campaignServices.listAllCampaigns()).thenReturn(campaigns);

        // @When requesting for all campaigns
        List<Campaign> campaignList = this.transactionalMetricsApplication.listAllCampaigns();

        // @Then all campaigns are returned
        assertThat(campaignList).isEqualTo(campaigns);
    }

    @Test
    public void testListAllCampaignsReturnsNoCampaigns_WhenNoCampaignExists() {
        // @Given existing campaigns
        List<Campaign> campaigns = Lists.newArrayList();
        when(this.campaignServices.listAllCampaigns()).thenReturn(campaigns);

        // @When requesting for all campaigns
        List<Campaign> campaignList = this.transactionalMetricsApplication.listAllCampaigns();

        // @Then all campaigns are returned
        assertThat(campaignList).isEqualTo(campaigns);
    }

    @Test
    public void testFindCampaignByIdCallsFindCampaignByIdWithIdOne_WhenFindingCampaignOne() {
        // @Given a campaign with id 1
        when(this.campaignServices.findCampaignById(this.campaign.getId())).thenReturn(campaign);

        // @When requesting for that campaign
        this.transactionalMetricsApplication.findCampaignById(this.campaign.getId());

        // @Then the campaign found by the campaignServices is returned
        verify(this.campaignServices, times(1)).findCampaignById(this.campaign.getId());
    }

    @Test
    public void testFindCampaignByIdCallsFindCampaignByIdWithIdSix_WhenFindingCampaignSix() {
        // @Given a campaign with id 1
        this.campaign.setId(6);
        when(this.campaignServices.findCampaignById(this.campaign.getId())).thenReturn(campaign);

        // @When requesting for that campaign
        this.transactionalMetricsApplication.findCampaignById(this.campaign.getId());

        // @Then the campaign found by the campaignServices is returned
        verify(this.campaignServices, times(1)).findCampaignById(this.campaign.getId());
    }

    @Test
    public void testFindCampaignByIdReturnsMatchingCampaignInRepository_WhenCampaignExists() {
        // @Given a campaign with id 1
        when(this.campaignServices.findCampaignById(this.campaign.getId())).thenReturn(campaign);

        // @When requesting for that campaign
        Campaign returnedCampaign = this.transactionalMetricsApplication.findCampaignById(this.campaign.getId());

        // @Then the campaign found by the campaignServices is returned
        assertThat(returnedCampaign.getId()).isEqualTo(campaign.getId());
    }

    //TODO This should call campaignServices.findCampaignById(id, withChildren = true)
    @Test
    public void testFindCampaignByIdReturnsMatchingCampaign_WhenWithChildrenIsTrue() {
        // @Given a campaign with id 1
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);

        // @When requesting for that campaign
        Campaign returnedCampaign = this.transactionalMetricsApplication.findCampaignById(campaign.getId(), true);

        // @Then the campaign found by the campaignServices is returned
        assertThat(returnedCampaign).isEqualTo(campaign);
    }

    @Test
    public void testUpdateCampaignCallsServiceUpdateCampaignWithMatchingCampaignWithIdOneAndInputVO_WhenUpdatingCampaignOne() {
        // @Given a campaignVO with Id one
        CampaignVO campaignVO = coreTestsHelper.newCampaignVO(1, "name", newDate(2011, 5, 8), newDate(2012, 5, 8), CampaignState.CREATED);
        when(this.campaignServices.findCampaignById(this.campaign.getId())).thenReturn(campaign);

        // @When saving the campaign
        this.transactionalMetricsApplication.updateCampaign(campaignVO);

        // @Then campaignServices.updateCampaign is called with campaign one and the VO
        verify(this.campaignServices, times(1)).updateCampaign(this.campaign, campaignVO);
    }

    @Test
    public void testUpdateCampaignReturnsTheUpdatedCampaingReturnedByservices_WhenUpdatingACampaign() {
        // @Given a campaign
        CampaignVO campaignVO = coreTestsHelper.newCampaignVO(1, "name", newDate(2011, 5, 8), newDate(2012, 5, 8), CampaignState.CREATED);
        when(this.campaignServices.findCampaignById(this.campaign.getId())).thenReturn(campaign);
        when(this.campaignServices.updateCampaign(campaign, campaignVO)).thenReturn(campaign);

        // @When saving the campaign
        Campaign returnedCampaign = this.transactionalMetricsApplication.updateCampaign(campaignVO);

        // @Then the campaign updated by the services is returned
        assertThat(returnedCampaign).isSameAs(this.campaignServices.updateCampaign(campaign, campaignVO));
    }

    @Test
    public void testUpdateCampaignThrowsException_WhenUpdatingACampaignWithANulVO() {
        // @Given a campaign
        CampaignVO campaignVO = null;

        // @When saving the campaign
        try {
            this.transactionalMetricsApplication.updateCampaign(campaignVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_VO_CANNOT_BE_NULL);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testListAllMetricsReturnsListOfMetrics_WhenMetricsExists() {
        // @Given existing metrics
        List<Metric> metrics = Lists.newArrayList(coreTestsHelper.newMetric("metric 1"), coreTestsHelper.newMetric("metric 2"));
        when(this.metricServices.listAllMetrics()).thenReturn(metrics);

        // @When requesting for all metrics
        List<Metric> metricList = this.transactionalMetricsApplication.listAllMetrics();

        // @Then all metrics are returned
        assertThat(metricList).isEqualTo(metrics);
    }

    @Test
    public void testFindMetricByIdCallsServicesFindMetricByIdWithIdOne_WhenFindingMetricWithIdOne() {
        // @Given a metric with id 1
        Metric metric = coreTestsHelper.newMetric("metric 1");
        metric.setId(1);
        when(this.metricServices.findMetricById(metric.getId())).thenReturn(metric);

        // @When requesting for that metric
        this.transactionalMetricsApplication.findMetricById(metric.getId());

        // @Then services.findMetricById 1 is called
        verify(this.metricServices, times(1)).findMetricById(metric.getId());
    }

    @Test
    public void testFindMetricByIdCallsServicesFindMetricByIdWithIdSeven_WhenFindingMetricWithIdSeven() {
        // @Given a metric with id 1
        Metric metric = coreTestsHelper.newMetric("metric 1");
        metric.setId(7);
        when(this.metricServices.findMetricById(metric.getId())).thenReturn(metric);

        // @When requesting for that metric
        this.transactionalMetricsApplication.findMetricById(metric.getId());

        // @Then services.findMetricById 1 is called
        verify(this.metricServices, times(1)).findMetricById(metric.getId());
    }

    @Test
    public void testFindMetricByIdReturnsMatchingMetricWithIdOne_WhenMetricWithIdOneExists() {
        // @Given a metric with id 1
        Metric metric = coreTestsHelper.newMetric("metric 1");
        metric.setId(1);
        when(this.metricServices.findMetricById(metric.getId())).thenReturn(metric);

        // @When requesting for that metric
        Metric metricById = this.transactionalMetricsApplication.findMetricById(metric.getId());

        // @Then the metric found by the metricServices is returned
        assertThat(metricById).isEqualTo(metric);
    }

    @Test
    public void testDeleteMetricCallsDeleteInMetricServices_WhenMetricHasNoChildren() {
        // @Given an existing metric with no children
        Metric metric = coreTestsHelper.newMetric("metric 1");
        metric.setId(1);
        when(this.metricServices.findMetricById(metric.getId())).thenReturn(metric);

        // @When deleting the metric
        this.transactionalMetricsApplication.delete(metric.getId());

        // @Then the metricSerices save the metric
        verify(this.metricServices, times(1)).delete(metric);
    }

    @Test
    public void testAddMetricToCampaignReturnsMatchingMetric_WhenCampaignExists() {
        // @Given an existing Campaign
        when(this.campaignServices.findCampaignById(this.campaign.getId())).thenReturn(campaign);
        CampaignVO campaignVO = coreTestsHelper.newCampaignVO(1, "name", newDate(2011, 5, 8), newDate(2012, 5, 8), CampaignState.CREATED);
        MetricVO metricVO = coreTestsHelper.newMetricVO("metric name", 200);

        // @When appending a metric
        Metric metricResponse = this.transactionalMetricsApplication.addMetricToCampaign(campaignVO.getId(), metricVO);

        // @The metric is created and returned
        assertThat(metricResponse.getId()).isNotNull();
        assertThat(metricResponse.getName()).isEqualTo(metricVO.getName());
    }

    @Test
    public void testAddMetricToCampaignThrowsException_WhenMetricVOIsNull() {
        // @Given an existing Campaign
        CampaignVO campaignVO = coreTestsHelper.newCampaignVO(1, "name", newDate(2011, 5, 8), newDate(2012, 5, 8), CampaignState.CREATED);
        MetricVO metricVO = null;

        // @When appending a metric
        try {
            this.transactionalMetricsApplication.addMetricToCampaign(campaignVO.getId(), metricVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_VO_CANNOT_BE_NULL);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testAddMetricToCampaignThrowsException_WhenMetricVOHasNoName() {
        // @Given an existing Campaign
        CampaignVO campaignVO = coreTestsHelper.newCampaignVO(2, "name2", newDate(2013, 5, 8), newDate(2014, 5, 8), CampaignState.CREATED);
        MetricVO metricVO = new MetricVO();

        // @When appending a metric
        try {
            this.transactionalMetricsApplication.addMetricToCampaign(campaignVO.getId(), metricVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.MISSING_REQUIRED_FIELD + "[Name]");
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testAddMetricToMetricReturnsMatchingMetric_WhenParentExists() {
        // @Given an existent module
        Metric module = coreTestsHelper.newMetric("metric 1");
        module.setId(1);
        MetricVO metricVO = coreTestsHelper.newMetricVO("metricName", 458);
        when(this.metricServices.findMetricById(module.getId())).thenReturn(module);

        // @When adding a Metric to the module
        Metric metricResponse = this.transactionalMetricsApplication.addMetricToMetric(module.getId(), metricVO);

        // @The module adds the metric
        assertThat(metricResponse.getName()).isEqualTo(metricVO.getName());
    }

    @Test
    public void testAddMetricToMetricThrowsException_WhenMetricVOHasNoName() {
        // @Given an existent module
        Metric module = coreTestsHelper.newMetric("metric 1");
        module.setId(1);
        MetricVO metricVO = coreTestsHelper.newMetricVO(null, 458);
        when(this.metricServices.findMetricById(module.getId())).thenReturn(module);

        // @When adding a Metric to the module
        try {
            this.transactionalMetricsApplication.addMetricToMetric(module.getId(), metricVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.MISSING_REQUIRED_FIELD + "[Name]");
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testDisableReturnsDisabledMetric_WhenMetricExists() {
        // @Given an existent metric that is enabled
        Metric metric = coreTestsHelper.newMetric("Metric 11");
        metric.setId(1);
        metric.setEnabled(true);
        when(this.metricServices.findMetricById(metric.getId())).thenReturn(metric);

        // @When disable
        Metric metricResponse = this.transactionalMetricsApplication.disable(metric.getId());

        // @Then the metric is disabled
        assertThat(metricResponse.isEnabled()).isFalse();
    }

    @Test
    public void testEnableReturnsEnabledMetric_WhenMetricExists() {
        // @Given an existent metric that is enabled
        Metric metric = coreTestsHelper.newMetric("Metric 11");
        metric.setId(1);
        metric.setEnabled(false);
        when(this.metricServices.findMetricById(metric.getId())).thenReturn(metric);

        // @When enable
        Metric metricResponse = this.transactionalMetricsApplication.enable(metric.getId());

        // @Then the metric is enabled
        assertThat(metricResponse.isEnabled()).isTrue();
    }

    @Test
    public void testFindServiceCenterByCampaignIdAndCuitCallsServicesFindServiceCenterByCampaignAnCuitWithCuitOneAndCampaignIdOne_WhenfindingServiceCenterOneForCampaignOne() {
        // @Given an existing service center associated to a campaign
        String cuit = "1";
        ServiceCenter expectedServiceCenter = coreTestsHelper.newServiceCenter(cuit);
        when(this.campaignServices.findServiceCenterByCampaignIdAndCuit(campaign, cuit)).thenReturn(expectedServiceCenter);
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);

        // @When finding the service center
        this.transactionalMetricsApplication.findServiceCenterByCampaignIdAndCuit(campaign.getId(), cuit);

        // @Then the service center is returned
        verify(this.campaignServices, times(1)).findServiceCenterByCampaignIdAndCuit(campaign, cuit);
    }

    @Test
    public void testFindServiceCenterByCampaignIdAndCuitCallsServicesFindServiceCenterByCampaignAnCuitWithCuitThreeAndCampaignIdEleven_WhenfindingServiceCenterThreeForCampaignEleven() {
        // @Given an existing service center associated to a campaign
        String cuit = "Three";
        this.campaign.setId(11);
        ServiceCenter expectedServiceCenter = coreTestsHelper.newServiceCenter(cuit);
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);
        when(this.campaignServices.findServiceCenterByCampaignIdAndCuit(campaign, cuit)).thenReturn(expectedServiceCenter);

        // @When finding the service center
        this.transactionalMetricsApplication.findServiceCenterByCampaignIdAndCuit(campaign.getId(), cuit);

        // @Then the service center is returned
        verify(this.campaignServices, times(1)).findServiceCenterByCampaignIdAndCuit(campaign, cuit);
    }

    @Test
    public void testFindServiceCenterByCampaignIdAndCuitReturnsMatchingServiceCenter_WhenServiceCenterExistsAndBelongsToTheCampaign() {
        // @Given an existing service center associated to a campaign
        String cuit = "101010101";
        ServiceCenter expectedServiceCenter = coreTestsHelper.newServiceCenter(cuit);
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);
        when(this.campaignServices.findServiceCenterByCampaignIdAndCuit(campaign, cuit)).thenReturn(expectedServiceCenter);

        // @When finding the service center
        ServiceCenter serviceCenter = this.transactionalMetricsApplication.findServiceCenterByCampaignIdAndCuit(campaign.getId(), cuit);

        // @Then the service center is returned
        assertThat(serviceCenter.getCampaign().getId()).isEqualTo(campaign.getId());
        assertThat(serviceCenter.getCuit()).isEqualTo(cuit);
    }

    @Test
    public void testRemoveCampaignCallsFindCampaignByIdWithIdOne_WhenRemovingCampaignWithIdOne() {
        // @Given a campaign with id One
        Campaign campaign = new Campaign("lala", newDate(2012, 5, 5), newDate(2013, 8, 8));
        campaign.setId(1);

        // @When Removing the campaign
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);
        this.transactionalMetricsApplication.removeCampaign(campaign.getId());

        // @Then findCampaignById is called with Id One
        verify(this.campaignServices, times(1)).findCampaignById(campaign.getId());
    }

    @Test
    public void testDeleteCallsApplicationsDeleteCampaignWithIdOne_WhenDeletingAnExistingCampaignWithIdOne() {
        // @Given a campaign with Id One
        Campaign campaign = new Campaign("name", newDate(2011, 5, 5), newDate(2012, 7, 7));
        campaign.setId(1);
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);

        // @When deleting the campaign
        this.transactionalMetricsApplication.removeCampaign(campaign.getId());

        // @Then application.delete is called for id One
        verify(this.campaignServices, times(1)).removeCampaign(campaign);
    }


    @Test
    public void testFindPointsOfSaleByCampaignIdAndCuitCallsCampaignServicesFindCampaignById1_WhenFindingPointsOfSaleForCampaign1AndCuit2() {
        // @Given a campaignId 1 and cuit 2
        int campaignId = 1;
        String cuit = "2";

        // @When finding the matching points of sale
        this.transactionalMetricsApplication.findPointsOfSaleByCampaignIdAndCuit(campaignId, cuit);

        // @Then CampaignServices.findCampaignById is called with campaignId one
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testFindPointsOfSaleByCampaignIdAndCuitCallsSCServicesFindServiceCenterByCuit2AndTheCampaignFoundByTheCamapignService_WhenFindingPointsOfSaleForCampaign1AndCuit2() {
        // @Given a campaignId 1 and cuit 2
        int campaignId = 1;
        String cuit = "2";
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When finding the matching points of sale
        this.transactionalMetricsApplication.findPointsOfSaleByCampaignIdAndCuit(campaignId, cuit);

        // @Then SCServices.findSCByCuit is called with the campaign found by the campaignServices and the cuit 2;
        verify(this.serviceCenterServices, times(1)).findServiceCenterByCuit(cuit, this.campaignServices.findCampaignById(campaignId));
    }

    @Test
    public void testFindPointsOfSaleByCampaignIdAndCuitCallsPOSServicesFindPointsOfSaleByServiceCenterWithSCFoundBySCServices_WhenFindingPointsOfSaleForCampaign1AndCuit2() {
        // @Given a campaignId 1 and cuit 2
        int campaignId = 1;
        String cuit = "2";
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit(cuit);
        serviceCenter.setCampaign(campaign);
        when(this.serviceCenterServices.findServiceCenterByCuit(cuit, campaign)).thenReturn(serviceCenter);

        // @When finding the matching points of sale
        this.transactionalMetricsApplication.findPointsOfSaleByCampaignIdAndCuit(campaignId, cuit);

        // @Then PosServices.findByServiceCenter is called with matching service center
        verify(this.pointOfSaleServices, times(1)).findPointsOfSaleByServiceCenter(this.serviceCenterServices.findServiceCenterByCuit(cuit, this.campaignServices.findCampaignById(campaignId)));
    }

    @Test
    public void testFindPointsOfSaleByCampaignIdAndCuitReturnsPOSListReturnedByPOSServices_WhenFindingPointsOfSaleForCampaign1AndCuit2() {
        // @Given a campaignId 1 and cuit 2
        int campaignId = 1;
        String cuit = "2";
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit(cuit);
        serviceCenter.setCampaign(campaign);
        when(this.serviceCenterServices.findServiceCenterByCuit(cuit, campaign)).thenReturn(serviceCenter);
        PointOfSale pointOfSale1 = new PointOfSale();
        pointOfSale1.setIdSap(22l);
        pointOfSale1.setServiceCenter(serviceCenter);
        PointOfSale pointOfSale2 = new PointOfSale();
        pointOfSale2.setServiceCenter(serviceCenter);
        pointOfSale2.setIdSap(28345l);
        when(this.pointOfSaleServices.findPointsOfSaleByServiceCenter(serviceCenter)).thenReturn(Lists.<PointOfSale>newArrayList(pointOfSale1, pointOfSale2));

        // @When finding the matching points of sale
        List<PointOfSale> pointOfSales = this.transactionalMetricsApplication.findPointsOfSaleByCampaignIdAndCuit(campaignId, cuit);

        // @Then PosServices.findByServiceCenter is called with matching service center
        assertThat(pointOfSales).isSameAs(this.pointOfSaleServices.findPointsOfSaleByServiceCenter(this.serviceCenterServices.findServiceCenterByCuit(cuit, this.campaignServices.findCampaignById(campaignId))));
    }

    @Test
    public void testFindPointsOfSaleByCampaignIdCallsCampaignServicesFindCampaignById1_WhenFindingPointsOfSaleForCampaign1() {
        // @Given a campaignId 1 and cuit 2
        int campaignId = 1;

        // @When finding the matching points of sale
        this.transactionalMetricsApplication.findPointsOfSaleByCampaignId(campaignId);

        // @Then CampaignServices.findCampaignById is called with campaignId one
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testFindPointsOfSaleByCampaignIdReturnsPOSListReturnedByPOSServices_WhenFindingPointsOfSaleForCampaign1AndCuit2() {
        // @Given a campaignId 1 and cuit 2
        int campaignId = 1;
        String cuit = "2";
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit(cuit);
        serviceCenter.setCampaign(campaign);
        PointOfSale pointOfSale1 = new PointOfSale();
        pointOfSale1.setIdSap(22l);
        pointOfSale1.setServiceCenter(serviceCenter);
        PointOfSale pointOfSale2 = new PointOfSale();
        pointOfSale2.setServiceCenter(serviceCenter);
        pointOfSale2.setIdSap(28345l);
        when(this.pointOfSaleServices.findPointsOfSaleByCampaign(campaign)).thenReturn(Lists.<PointOfSale>newArrayList(pointOfSale1, pointOfSale2));

        // @When finding the matching points of sale
        List<PointOfSale> pointOfSales = this.transactionalMetricsApplication.findPointsOfSaleByCampaignId(campaignId);

        // @Then PosServices.findByServiceCenter is called with matching service center
        assertThat(pointOfSales).isSameAs(this.pointOfSaleServices.findPointsOfSaleByCampaign(this.campaignServices.findCampaignById(campaignId)));
    }

    @Test
    public void testSaveAndComputeMetricScoreCallsMetricServicesUpdateMetricWithInputVO_WhenSavingAndCalculatingScore() {
        // @Given a metric vo
        MetricVO metricVO = new MetricVO();
        metricVO.setId(1);
        metricVO.setName("Hi");
        Metric metric = mock(Metric.class);
        List<DataTable> tables = Lists.newArrayList();
        when(metricServices.findMetricById(metricVO.getId())).thenReturn(metric);

        // When savingAndcomputingMetricScore for the VO
        this.transactionalMetricsApplication.saveAndCalculateMetricScore(metricVO);

        // @Then Services.SaveOrUpdate is called with the VO
        verify(this.metricServices, times(1)).updateMetric(metric, tables, metricVO);
    }

    @Test
    public void testSaveAndComputeMetricScoreCallsMetricCompute_WhenSavingAndCalculatingScore() {
        // @Given a metric vo
        MetricVO metricVO = new MetricVO();
        metricVO.setId(1);
        metricVO.setName("Hi");
        Metric metric = mock(Metric.class);
        when(metricServices.findMetricById(metricVO.getId())).thenReturn(metric);

        // When savingAndcomputingMetricScore for the VO
        this.transactionalMetricsApplication.saveAndCalculateMetricScore(metricVO);

        // @Then Services.SaveOrUpdate is called with the VO
        verify(metric, times(1)).compute();
    }

    @Test
    public void testCalculateMetricScoreCallsMetricCompute_WhenCalculatingScore() {
        // @Given a metric vo
        int metricId = 1;
        Metric metric = mock(Metric.class);
        when(metricServices.findMetricById(metricId)).thenReturn(metric);

        // When savingAndcomputingMetricScore for the VO
        this.transactionalMetricsApplication.calculateMetricScore(metricId);

        // @Then Services.SaveOrUpdate is called with the VO
        verify(metric, times(1)).compute();
    }

    @Test
    public void testSaveAndComputeMetricScoreThrowsException_WhenMetricHasNoName() {
        // @Given a metric vo
        MetricVO metricVO = new MetricVO();
        metricVO.setId(1);
        Metric metric = mock(Metric.class);
        when(metricServices.findMetricById(metricVO.getId())).thenReturn(metric);

        // When savingAndcomputingMetricScore for the VO
        try {
            this.transactionalMetricsApplication.saveAndCalculateMetricScore(metricVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.MISSING_REQUIRED_FIELD + "[Name]");
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testSaveAndComputeMetricScoreThrowsException_WhenMetricHasNoId() {
        // @Given a metric vo
        MetricVO metricVO = new MetricVO();
        metricVO.setName("Hi");
        Metric metric = mock(Metric.class);

        // When savingAndcomputingMetricScore for the VO
        try {
            this.transactionalMetricsApplication.saveAndCalculateMetricScore(metricVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.MISSING_REQUIRED_FIELD + "[Id]");
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testUpdateMetricCallsMetricServicesUpdateMetricWithInputVOWithIdOne_WhenUpdatingMetricOne() {
        // @Given a metric VO with id one
        MetricVO metricVO = new MetricVO();
        metricVO.setId(1);
        metricVO.setName("another name");
        Metric metric = new Metric(campaign, "name");
        when(this.metricServices.findMetricById(metricVO.getId())).thenReturn(metric);
        List<DataTable> tables = Lists.newArrayList();
        when(this.tableServices.findDataTablesByCampaign(this.campaign)).thenReturn(tables);

        // @When Updating metric one with that VO
        this.transactionalMetricsApplication.updateMetric(metricVO);

        // @Then Services.updateMetric is called
        verify(this.metricServices, times(1)).updateMetric(metric, tables, metricVO);
    }

    @Test
    public void testUpdateMetricThrowsException_WhenMetricVOHasNoName() {
        // @Given a metric VO with id one
        MetricVO metricVO = new MetricVO();
        metricVO.setId(1);
        Metric metric = new Metric(campaign, "name");
        when(this.metricServices.findMetricById(metricVO.getId())).thenReturn(metric);

        // @When Updating metric one with that VO
        try {
            this.transactionalMetricsApplication.updateMetric(metricVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.MISSING_REQUIRED_FIELD + "[Name]");
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testFindScoresByMetricIdAndPageCallsMetricServicesFindMetricByIdOne_WhenFindingScoresForMetricWithIdOne() {
        // @Given a metric with id one
        Metric metric = coreTestsHelper.newMetric("metric");
        metric.setId(1);
        Sort sort = new Sort(Sort.Direction.ASC, "points");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.metricServices.findMetricById(metric.getId())).thenReturn(metric);

        // @When finding it's scores
        this.transactionalMetricsApplication.findScoresByMetricIdAndPage(metric.getId(), pageRequest, filter);

        // @Then findMetricById is called with id one
        verify(this.metricServices, times(1)).findMetricById(metric.getId());
    }

    @Test
    public void testFindScoresByMetricIdAndPageCallsMetricServicesFindMetricByIdTwo_WhenFindingScoresForMetricWithIdTwo() {
        // @Given a metric with id two
        Metric metric = coreTestsHelper.newMetric("metric");
        metric.setId(2);
        Sort sort = new Sort(Sort.Direction.ASC, "points");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.metricServices.findMetricById(metric.getId())).thenReturn(metric);

        // @When finding it's scores
        this.transactionalMetricsApplication.findScoresByMetricIdAndPage(metric.getId(), pageRequest, filter);

        // @Then findMetricById is called with Id two
        verify(this.metricServices, times(1)).findMetricById(metric.getId());
    }

    @Test
    public void testFindScoresByMetricIdAndPageCallsScoreServicesFindScoresByMetricReturnedByFindMetricByIdOne_WhenFindingScoresForMetricWithIdOne() {
        // @Given a metric with id one
        Metric metric = coreTestsHelper.newMetric("metric");
        metric.setId(1);
        Sort sort = new Sort(Sort.Direction.ASC, "points");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.metricServices.findMetricById(metric.getId())).thenReturn(metric);

        // @When finding it's scores
        this.transactionalMetricsApplication.findScoresByMetricIdAndPage(metric.getId(), pageRequest, filter);

        // @Then ScoreServices.findScoresByMetricId is called
        verify(this.scoreServices, times(1)).findScoresByMetric(eq(metric), eq(1), eq(20), Matchers.<String>any(), Matchers.<String>any(), eq(filter));
    }

    @Test
    public void testFindScoresByMetricIdAndPageReturnsResultOfFindScoresByMetric_WhenFindingScoresByMetricIdAndPage() {
        // @Given a metric with id one
        Metric module = coreTestsHelper.newMetric("module");
        module.setId(2);
        Metric metric = coreTestsHelper.newMetric("metric");
        metric.setId(3);
        Metric submetric = coreTestsHelper.newMetric("submetric");
        submetric.setId(4);
        submetric.setParent(metric);
        metric.setParent(module);
        Sort sort = new Sort(Sort.Direction.ASC, "points");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.metricServices.findMetricById(metric.getId())).thenReturn(metric);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        MetricScore score = new MetricScore(submetric, serviceCenter);
        score.setPoints(BigDecimal.valueOf(10));
        List<MetricScore> expectedResult = Lists.newArrayList(score);
        when(this.scoreServices.findScoresByMetric(eq(metric), eq(1), eq(20), Matchers.<String>any(), Matchers.<String>any(), eq(filter))).thenReturn(expectedResult);

        // @When finding it's scores
        Page<MetricScoreVO> scores = this.transactionalMetricsApplication.findScoresByMetricIdAndPage(metric.getId(), pageRequest, filter);

        // @Then ScoreServices.findScoresByMetricId is called
        assertThat(scores).hasSize(1);
        assertThat(scores.getContent()).onProperty("points").contains(BigDecimal.valueOf(10));
    }

    @Test
    public void testGenerateScoreSummaryCallsCampaignServiceFindById1_WhenGeneratingSummaryForServiceCenter10AndCampaign1() {
        // @Given
        int campaignId = 1;
        String cuit = "10";
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When
        this.transactionalMetricsApplication.generateScoreSummary(campaignId, cuit);

        // @Then
        verify(this.campaignServices).findCampaignById(campaignId);
    }

    @Test
    public void testGenerateScoreSummaryCallsServiceCenterServiceFindByCuit10AndCampaign1_WhenGeneratingSummaryForServiceCenter10AndCampaign1() {
        // @Given
        int campaignId = 1;
        String cuit = "10";
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When
        this.transactionalMetricsApplication.generateScoreSummary(campaignId, cuit);

        // @Then
        verify(this.serviceCenterServices).findServiceCenterByCuit(cuit, campaign);
    }

    @Test
    public void testGenerateScoreSummaryReturnsAScoreSummaryCampaignNodeCreatedFromTheCampaign_WhenGeneratingSummaryForServiceCenter10AndCampaign1() {
        // @Given
        int campaignId = 1;
        String cuit = "10";
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When
        ScoreSummaryCampaignNode scoreSummaryCampaignNode = this.transactionalMetricsApplication.generateScoreSummary(campaignId, cuit);

        // @Then
        assertThat(scoreSummaryCampaignNode.getCampaign()).isEqualTo(campaign);
    }

    @Test
    public void testListServiceCentersByPageCallsCampaignServicesFindByIdOne_WhenListingServiceCentersByPageInCampaignOne() {
        // @Given a campaign id 1
        int campaignId = 1;
        Sort sort = new Sort(Sort.Direction.ASC, "name");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();

        // @When finding the service center page
        this.transactionalMetricsApplication.listServiceCentersByPage(campaignId, pageRequest, filter);

        // @Then findCampaignById is calles with id one
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testListServiceCentersByPageCallsServiceCenterServiceListServiceCentersByPage_WhenListingServiceCentersByPage() {
        // @Given a campaign id 1
        int campaignId = 1;
        Sort sort = new Sort(Sort.Direction.ASC, "name");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When finding the service center page
        this.transactionalMetricsApplication.listServiceCentersByPage(campaignId, pageRequest, filter);

        // @Then findCampaignById is calles with id one
        verify(this.serviceCenterServices, times(1)).listServiceCentersByPage(campaign, 1, 20, "name", "ASC", filter);
    }

    @Test
    public void testSendSummaryCallsMailServiceSendSummaryWithGeneratedSummaryForCampaign1AndSC10_WhenSendingSummaryForCampaign1AndSC10() throws Exception {
        // @Given a campaign id 1 and a service center cuit 10
        int campaignId = 1;
        final String cuit = "10";
        final ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit(cuit);
        when(campaignServices.findCampaignById(campaignId)).thenReturn(this.campaign);
        when(serviceCenterServices.findServiceCenterByCuit(cuit, campaign)).thenReturn(serviceCenter);

        // @When sending a summary
        this.transactionalMetricsApplication.sendSummary(campaignId, cuit);

        // @Then Mail services are called with the result of generating the summary for that sc and that campaign
        verify(this.mailServices, times(1)).sendSummary(argThat(new ArgumentMatcher<ScoreSummaryCampaignNode>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ScoreSummaryCampaignNode &&
                        ((ScoreSummaryCampaignNode) argument).getCampaign().equals(campaign) &&
                        ((ScoreSummaryCampaignNode) argument).getServiceCenter().equals(serviceCenter);
            }
        }));
    }

    @Test
    public void testSendSummarySetsLastTimeSentOfServiceCenter_WhenSendingSummary() throws Exception {
        // @Given a campaign id 1 and a service center cuit 10
        int campaignId = 1;
        final String cuit = "10";
        final ServiceCenter serviceCenter = mock(ServiceCenter.class);
        when(campaignServices.findCampaignById(campaignId)).thenReturn(this.campaign);
        when(serviceCenterServices.findServiceCenterByCuit(cuit, campaign)).thenReturn(serviceCenter);

        // @When sending a summary
        this.transactionalMetricsApplication.sendSummary(campaignId, cuit);

        // @Then Mail services are called with the result of generating the summary for that sc and that campaign
        verify(serviceCenter, times(1)).setLastTimeSent(Matchers.<Date>any());
    }

    @Test
    public void testFindPointsOfSaleByCampaignIdAndPageCallsCampaignServicesFindCampaignByIdOne_WhenFindingPOSForCampaignWithIdOne() {
        // @Given a metric with id one
        Sort sort = new Sort(Sort.Direction.ASC, "idSap");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);

        // @When finding it's scores
        this.transactionalMetricsApplication.listPointsOfSaleByPage(campaign.getId(), pageRequest, filter);

        // @Then findMetricById is called with id one
        verify(this.campaignServices, times(1)).findCampaignById(campaign.getId());
    }

    @Test
    public void testFindPointsOfSaleByCampaignIdAndPageCallsCampaignServicesFindCampaignByIdTwo_WhenFindingPOSForCampaignWithIdTwo() {
        // @Given a metric with id two
        Sort sort = new Sort(Sort.Direction.ASC, "idSap");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);

        // @When finding it's scores
        this.transactionalMetricsApplication.listPointsOfSaleByPage(campaign.getId(), pageRequest, filter);

        // @Then findMetricById is called with Id two
        verify(this.campaignServices, times(1)).findCampaignById(campaign.getId());
    }

    @Test
    public void testFindPointsOfSaleByCampaignIdAndPageCallsScoreServicesFindScoresByMetricReturnedByFindMetricByIdOne_WhenFindingScoresForMetricWithIdOne() {
        // @Given a metric with id one
        Sort sort = new Sort(Sort.Direction.ASC, "points");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);

        // @When finding it's scores
        this.transactionalMetricsApplication.listPointsOfSaleByPage(campaign.getId(), pageRequest, filter);

        // @Then ScoreServices.findScoresByMetricId is called
        verify(this.pointOfSaleServices, times(1)).listPointsOfSaleByPage(eq(campaign), eq(1), eq(20), Matchers.<String>any(), Matchers.<String>any(), eq(filter));
    }

    @Test
    public void testFindPointsOfSaleByCampaignIdAndPageReturnsResultOfFindScoresByMetric_WhenFindingScoresByMetricIdAndPage() {
        // @Given a metric with id one
        Sort sort = new Sort(Sort.Direction.ASC, "idSap");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(10l);
        pointOfSale.setServiceCenter(serviceCenter);
        when(this.pointOfSaleServices.listPointsOfSaleByPage(eq(campaign), eq(1), eq(20), Matchers.<String>any(), Matchers.<String>any(), eq(filter))).thenReturn(Lists.<PointOfSale>newArrayList(pointOfSale));

        // @When finding it's scores
        Page<PointOfSaleVO> scores = this.transactionalMetricsApplication.listPointsOfSaleByPage(campaign.getId(), pageRequest, filter);

        // @Then ScoreServices.findScoresByMetricId is called
        assertThat(scores).hasSize(1);
        assertThat(scores.getContent()).onProperty("idSap").contains((long) 10);
    }

    @Test
    public void testSendAllSummariesCallsCampaignServicesWithCampaignId1_WhenSendingAllSumariesForCampaign1() throws Exception {
        // @Given a campaign with id
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);
        this.campaign.setId(1);

        // @When sending all summaries
        this.transactionalMetricsApplication.sendAllSummaries(this.campaign.getId());

        // @Then listAllServiceCentersIsCalled
        verify(this.serviceCenterServices, times(1)).listServiceCenters(this.campaign);
    }

    @Test
    public void testSendAllSummariesCallsCampaignServicesWithCampaignId1_WhenSendingAllSumariesForCampaign2() throws Exception {
        // @Given a campaign with id
        this.campaign.setId(2);
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);

        // @When sending all summaries
        this.transactionalMetricsApplication.sendAllSummaries(this.campaign.getId());

        // @Then listAllServiceCentersIsCalled
        verify(this.serviceCenterServices, times(1)).listServiceCenters(this.campaign);
    }

    @Test
    public void testSendAllSummariesCallsMailsServicesSendSummary3times_WhenCampaignHas3ServiceCenters() throws Exception {
        // @Given a campaign with id 1 that has 3 service centers
        this.campaign.setId(1);
        final ServiceCenter serviceCenter1 = new ServiceCenter();
        serviceCenter1.setCuit("A");
        serviceCenter1.setCampaign(this.campaign);
        final ServiceCenter serviceCenter2 = new ServiceCenter();
        serviceCenter2.setCuit("B");
        serviceCenter2.setCampaign(this.campaign);
        final ServiceCenter serviceCenter3 = new ServiceCenter();
        serviceCenter3.setCuit("C");
        serviceCenter3.setCampaign(this.campaign);
        when(this.campaignServices.findCampaignById(this.campaign.getId())).thenReturn(this.campaign);
        when(this.serviceCenterServices.findServiceCenterByCuit(serviceCenter1.getCuit(), this.campaign)).thenReturn(serviceCenter1);
        when(this.serviceCenterServices.findServiceCenterByCuit(serviceCenter2.getCuit(), this.campaign)).thenReturn(serviceCenter2);
        when(this.serviceCenterServices.findServiceCenterByCuit(serviceCenter3.getCuit(), this.campaign)).thenReturn(serviceCenter3);
        when(this.serviceCenterServices.listServiceCenters(this.campaign)).thenReturn(Lists.<ServiceCenter>newArrayList(serviceCenter1, serviceCenter2, serviceCenter3));

        // @When sending all summaries
        this.transactionalMetricsApplication.sendAllSummaries(this.campaign.getId());

        // @Then mailServices.sendSummary is called
        verify(this.mailServices, times(1)).sendSummary(argThat(new ArgumentMatcher<ScoreSummaryCampaignNode>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ScoreSummaryCampaignNode && ((ScoreSummaryCampaignNode) argument).getCampaign().equals(campaign) && ((ScoreSummaryCampaignNode) argument).getServiceCenter().equals(serviceCenter1);
            }
        }));
        verify(this.mailServices, times(1)).sendSummary(argThat(new ArgumentMatcher<ScoreSummaryCampaignNode>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ScoreSummaryCampaignNode && ((ScoreSummaryCampaignNode) argument).getCampaign().equals(campaign) && ((ScoreSummaryCampaignNode) argument).getServiceCenter().equals(serviceCenter2);
            }
        }));
        verify(this.mailServices, times(1)).sendSummary(argThat(new ArgumentMatcher<ScoreSummaryCampaignNode>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ScoreSummaryCampaignNode && ((ScoreSummaryCampaignNode) argument).getCampaign().equals(campaign) && ((ScoreSummaryCampaignNode) argument).getServiceCenter().equals(serviceCenter3);
            }
        }));
    }

    @Test
    public void testSendAllSummariesCallsMailsServicesSendSummary1time_WhenCampaignHas3ServiceCenters() throws Exception {
        // @Given a campaign with id 1 that has 1 service centers
        this.campaign.setId(1);
        final ServiceCenter serviceCenter1 = new ServiceCenter();
        serviceCenter1.setCuit("THECUIT");
        serviceCenter1.setCampaign(this.campaign);
        when(this.campaignServices.findCampaignById(this.campaign.getId())).thenReturn(this.campaign);
        when(this.serviceCenterServices.findServiceCenterByCuit(serviceCenter1.getCuit(), this.campaign)).thenReturn(serviceCenter1);
        when(this.serviceCenterServices.listServiceCenters(this.campaign)).thenReturn(Lists.<ServiceCenter>newArrayList(serviceCenter1));

        // @When sending all summaries
        this.transactionalMetricsApplication.sendAllSummaries(this.campaign.getId());

        // @Then mailServices.sendSummary is called
        verify(this.mailServices, times(1)).sendSummary(argThat(new ArgumentMatcher<ScoreSummaryCampaignNode>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof ScoreSummaryCampaignNode && ((ScoreSummaryCampaignNode) argument).getCampaign().equals(campaign) && ((ScoreSummaryCampaignNode) argument).getServiceCenter().equals(serviceCenter1);
            }
        }));
    }

    ////////////////////////////////////////
    @Test
    public void testFindCampaignParametersByPageCallsScoreServicesFindScoresByMetricReturnedByFindMetricByIdOne_WhenFindingScoresForMetricWithIdOne() {
        // @Given
        Sort sort = new Sort(Sort.Direction.ASC, "points");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);

        // @When
        this.transactionalMetricsApplication.findCampaignParametersByPage(pageRequest, filter);

        // @Then
        verify(this.campaignServices, times(1)).getParameters(eq(1), eq(20), Matchers.<String>any(), Matchers.<String>any(), eq(filter));
    }

    @Test
    public void testFindCampaignParametersByPageReturnsResultOfFindScoresByMetric_WhenFindingScoresByMetricIdAndPage() {
        // @Given
        Sort sort = new Sort(Sort.Direction.ASC, "idSap");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);
        CampaignParameter parameter = new CampaignParameter();
        parameter.setValue("Hola");
        when(this.campaignServices.getParameters(eq(1), eq(20), Matchers.<String>any(), Matchers.<String>any(), eq(filter))).thenReturn(Lists.<CampaignParameter>newArrayList(parameter));

        // @When
        Page<CampaignParameter> parameters = this.transactionalMetricsApplication.findCampaignParametersByPage(pageRequest, filter);

        // @Then
        assertThat(parameters).hasSize(1);
        assertThat(parameters.getContent()).onProperty("value").contains("Hola");
    }

    @Test
    public void testUpdateCampaignParameterCallsCampaignServicesFindParameterById1_WhenUpdatingParameterWithId1() {
        // @Given
        CampaignParameter parameter = new CampaignParameter();
        parameter.setId(1);
        CampaignParameter modifiedParameter = new CampaignParameter();
        modifiedParameter.setId(1);
        modifiedParameter.setName("sc.name.a.parameter");
        when(this.campaignServices.findParameterById(parameter.getId())).thenReturn(parameter);

        // @When
        this.transactionalMetricsApplication.updateCampaignParameter(modifiedParameter);

        // @Then
        verify(this.campaignServices, times(1)).findParameterById(parameter.getId());
    }

    @Test
    public void testUpdateCampaignParameterCallsCampaignServicesUpdateParameter_WhenUpdatingParameterWithId1() {
        // @Given
        CampaignParameter parameter = new CampaignParameter();
        parameter.setId(1);
        CampaignParameter modifiedParameter = new CampaignParameter();
        modifiedParameter.setId(1);
        modifiedParameter.setName("sc.name.a.parameter");
        when(this.campaignServices.findParameterById(parameter.getId())).thenReturn(parameter);

        // @When
        this.transactionalMetricsApplication.updateCampaignParameter(modifiedParameter);

        // @Then
        verify(this.campaignServices, times(1)).updateParameter(parameter, modifiedParameter);
    }

    @Test
    public void testUpdateCampaignParameterThrowsException_WhenUpdatedParameterHasNoName() {
        // @Given
        CampaignParameter parameter = new CampaignParameter();
        parameter.setId(1);
        CampaignParameter modifiedParameter = new CampaignParameter();
        modifiedParameter.setId(1);
        when(this.campaignServices.findParameterById(parameter.getId())).thenReturn(parameter);

        // @When
        try {
            this.transactionalMetricsApplication.updateCampaignParameter(modifiedParameter);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.MISSING_REQUIRED_FIELD + "[Name]");
        } catch (Throwable t) {
            fail();
        }

    }

    @Test
    public void testNewCampaignCallsCampaignServicesNewCampaign_WhenCreatingANewCampaign() {
        // @Given
        CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName("Hi");
        campaignVO.setSince(newDate(2011, 7, 7));
        campaignVO.setUntil(newDate(2011, 8, 10));

        // @When
        this.transactionalMetricsApplication.newCampaign(campaignVO);

        // @Then
        verify(this.campaignServices, times(1)).newCampaign(campaignVO);
    }

    @Test
    public void testNewCampaignThrowsException_WhenCreatingANewCampaignWithNoSinceDate() {
        // @Given
        CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName("Hi");
        campaignVO.setUntil(newDate(2011, 8, 10));

        // @When
        try {
            this.transactionalMetricsApplication.newCampaign(campaignVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.MISSING_REQUIRED_FIELD + "[Since]");
        } catch (Throwable e) {
            fail();
        }
    }

    @Test
    public void testNewCampaignThrowsException_WhenCreatingANewCampaignWithNoName() {
        // @Given
        CampaignVO campaignVO = new CampaignVO();
        campaignVO.setSince(newDate(2011, 7, 7));
        campaignVO.setUntil(newDate(2011, 8, 10));

        // @When
        try {
            this.transactionalMetricsApplication.newCampaign(campaignVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.MISSING_REQUIRED_FIELD + "[Name]");
        } catch (Throwable e) {
            fail();
        }
    }

    @Test
    public void testNewCampaignThrowsException_WhenCreatingANewCampaignWithNoUntilDate() {
        // @Given
        CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName("Hi");
        campaignVO.setSince(newDate(2011, 7, 7));

        // @When
        try {
            this.transactionalMetricsApplication.newCampaign(campaignVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.MISSING_REQUIRED_FIELD + "[Until]");
        } catch (Throwable e) {
            fail();
        }
    }

    @Test
    public void testListMetricsForCampaignCallsCampaignServicesFindCampaignById1_WhenListingMetricsForCampaign1() {
        // @Given a campaignId
        int campaignId = 1;
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(this.campaign);

        // @When listing it's metrics
        this.transactionalMetricsApplication.listSubmetricsForCampaign(campaignId);

        // @Then findCampaignById is called
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testListMetricsForCampaignCallsCampaignServicesFindCampaignById3_WhenListingMetricsForCampaign3() {
        // @Given a campaignId
        int campaignId = 3;
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(this.campaign);

        // @When listing it's metrics
        this.transactionalMetricsApplication.listSubmetricsForCampaign(campaignId);

        // @Then findCampaignById is called
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testListMetricsForCampaignCallsMetricServicesListMetricsForCampaign_WhenListingMetricsForCampaign() {
        // @Given a campaignId
        int campaignId = 3;
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(this.campaign);

        // @When listing it's metrics
        this.transactionalMetricsApplication.listSubmetricsForCampaign(campaignId);

        // @Then findCampaignById is called
        verify(this.metricServices, times(1)).listSubmetricsByCampaign(campaign);
    }

    @Test
    public void testExecuteBatchMetricScoreComputeCallsCampaignServicesListAllCampaigns_WhenComputingAllScores() {
        // @When executing a batch score compute
        this.transactionalMetricsApplication.executeBatchMetricScoreCompute();

        // @Then campaignServices.listAllCampaigns is called
        verify(this.campaignServices, times(1)).listAllCampaigns();
    }

    @Test
    public void testExecuteBatchMetricScoreComputeCallsMetricCompute_WhenComputingAllScoresAndMetricIsEnabledAndScheduledAndInAnEnabledCampaign() {
        // @Given a list of campaigns with metrics
        Campaign campaign1 = new Campaign("campaign1", newDate(2010, 1, 1), newDate(2011, 1, 1));

        campaign1.setFactory(this.factory);
        Metric module1 = campaign1.addMetricDefinition("module1", 100);
        Metric metric1 = module1.addMetricDefinition("metric1", 100);
        Metric submetric1 = metric1.addMetricDefinition("submetric1", 100);
        submetric1.setEnabled(true);
        submetric1.setScheduled(true);
        Metric submetric2 = metric1.addMetricDefinition("submetric2", 100);
        submetric2.setEnabled(false);
        submetric2.setScheduled(true);
        Metric submetric3 = metric1.addMetricDefinition("submetric3", 100);
        submetric3.setEnabled(true);
        submetric3.setScheduled(false);

        Campaign campaign2 = new Campaign("campaign2", newDate(2011, 1, 1), newDate(2012, 1, 1));
        campaign2.setFactory(this.factory);
        Metric module2 = campaign2.addMetricDefinition("module2", 100);
        Metric metric2 = module2.addMetricDefinition("metric2", 100);
        Metric submetric4 = metric2.addMetricDefinition("submetric4", 100);
        submetric4.setEnabled(true);
        submetric4.setScheduled(true);
        Metric submetric5 = metric2.addMetricDefinition("submetric5", 100);
        submetric5.setEnabled(true);
        submetric5.setScheduled(true);
        Metric submetric6 = metric2.addMetricDefinition("submetric6", 100);
        submetric6.setEnabled(true);
        submetric6.setScheduled(true);

        Metric metric3 = module2.addMetricDefinition("metric3", 100);
        Metric submetric7 = metric3.addMetricDefinition("submetric7", 100);
        submetric7.setEnabled(true);
        submetric7.setScheduled(true);
        Metric module3 = campaign2.addMetricDefinition("module3", 100);
        Metric metric4 = module3.addMetricDefinition("metric4", 100);
        Metric submetric8 = metric4.addMetricDefinition("submetric8", 100);
        submetric8.setEnabled(true);
        submetric8.setScheduled(true);
        Metric submetric9 = metric4.addMetricDefinition("submetric9", 100);
        submetric9.setEnabled(false);
        submetric9.setScheduled(false);

        List<Campaign> campaigns = Lists.newArrayList(campaign1, campaign2);
        when(this.campaignServices.listAllCampaigns()).thenReturn(campaigns);

        // @When executing a batch score compute
        this.transactionalMetricsApplication.executeBatchMetricScoreCompute();

        // @Then only the metrics that are both enabled and scheduled are computed
        verify(this.computeManager, times(1)).compute(submetric1);
        verify(this.computeManager, times(0)).compute(submetric2);
        verify(this.computeManager, times(0)).compute(submetric3);
        verify(this.computeManager, times(1)).compute(submetric4);
        verify(this.computeManager, times(1)).compute(submetric5);
        verify(this.computeManager, times(1)).compute(submetric6);
        verify(this.computeManager, times(1)).compute(submetric7);
        verify(this.computeManager, times(1)).compute(submetric8);
        verify(this.computeManager, times(0)).compute(submetric9);
    }

    ////////////////////////////////////////////////////////

    @Test
    public void testFindScoresByCampaignIdAndPageCallsMetricServicesFindMetricByIdOne_WhenFindingScoresForMetricWithIdOne() {
        // @Given a metric with id one
        Sort sort = new Sort(Sort.Direction.ASC, "points");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);

        // @When finding it's scores
        this.transactionalMetricsApplication.findScoresByCampaignIdAndPage(campaign.getId(), pageRequest, filter);

        // @Then findMetricById is called with id one
        verify(this.campaignServices, times(1)).findCampaignById(campaign.getId());
    }

    @Test
    public void testFindScoresByCampaignIdAndPageCallsMetricServicesFindMetricByIdTwo_WhenFindingScoresForMetricWithIdTwo() {
        // @Given a metric with id two
        Sort sort = new Sort(Sort.Direction.ASC, "points");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);

        // @When finding it's scores
        this.transactionalMetricsApplication.findScoresByCampaignIdAndPage(campaign.getId(), pageRequest, filter);

        // @Then findMetricById is called with Id two
        verify(this.campaignServices, times(1)).findCampaignById(campaign.getId());
    }

    @Test
    public void testFindScoresByCampaignIdAndPageCallsScoreServicesFindScoresByMetricReturnedByFindMetricByIdOne_WhenFindingScoresForMetricWithIdOne() {
        // @Given a metric with id one
        Sort sort = new Sort(Sort.Direction.ASC, "points");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);

        // @When finding it's scores
        this.transactionalMetricsApplication.findScoresByCampaignIdAndPage(campaign.getId(), pageRequest, filter);

        // @Then ScoreServices.findScoresByMetricId is called
        verify(this.scoreServices, times(1)).findScoresByCampaign(eq(campaign), eq(1), eq(20), Matchers.<String>any(), Matchers.<String>any(), eq(filter));
    }

    @Test
    public void testFindScoresByCampaignIdAndPageReturnsResultOfFindScoresByMetric_WhenFindingScoresByMetricIdAndPage() {
        // @Given a metric with id one
        Metric module = coreTestsHelper.newMetric("module");
        module.setId(2);
        Metric metric = coreTestsHelper.newMetric("metric");
        metric.setId(3);
        Metric submetric = coreTestsHelper.newMetric("submetric");
        submetric.setId(4);
        submetric.setParent(metric);
        metric.setParent(module);
        Sort sort = new Sort(Sort.Direction.ASC, "points");
        PageRequest pageRequest = new PageRequest(1, 20, sort);
        Map<String, Object> filter = Maps.newHashMap();
        when(this.campaignServices.findCampaignById(campaign.getId())).thenReturn(campaign);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        MetricScore score = new MetricScore(submetric, serviceCenter);
        score.setPoints(BigDecimal.valueOf(10));
        List<MetricScore> expectedResult = Lists.newArrayList(score);
        when(this.scoreServices.findScoresByCampaign(eq(campaign), eq(1), eq(20), Matchers.<String>any(), Matchers.<String>any(), eq(filter))).thenReturn(expectedResult);

        // @When finding it's scores
        Page<MetricScoreVO> scores = this.transactionalMetricsApplication.findScoresByCampaignIdAndPage(campaign.getId(), pageRequest, filter);

        // @Then ScoreServices.findScoresByMetricId is called
        assertThat(scores).hasSize(1);
        assertThat(scores.getContent()).onProperty("points").contains(BigDecimal.valueOf(10));
    }
}