package com.monsanto.metricspos.core.application;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.*;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.EmployeeVO;
import com.monsanto.metricspos.core.application.vo.GroupVO;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.Authority;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class TransactionalSecurityApplication_UT {
    private TransactionalSecurityApplication securityApplication;
    private GroupServices groupServices;
    private AuthorityServices authorityServices;
    private AdminUserServices adminUserServices;
    private CampaignServices campaignServices;
    private EmployeeServices employeeServices;
    private MetricsServices metricsServices;

    @Before
    public void setUp() {
        this.securityApplication = new TransactionalSecurityApplication();
        this.groupServices = mock(GroupServices.class);
        this.authorityServices = mock(AuthorityServices.class);
        this.adminUserServices = mock(AdminUserServices.class);
        this.campaignServices = mock(CampaignServices.class);
        this.employeeServices = mock(EmployeeServices.class);
        this.metricsServices = mock(MetricsServices.class);
        Logger auditLog = mock(Logger.class);
        field("auditLog").ofType(Logger.class).in(this.securityApplication).set(auditLog);
        field("groupServices").ofType(GroupServices.class).in(this.securityApplication).set(this.groupServices);
        field("authorityServices").ofType(AuthorityServices.class).in(this.securityApplication).set(this.authorityServices);
        field("adminUserServices").ofType(AdminUserServices.class).in(this.securityApplication).set(this.adminUserServices);
        field("campaignServices").ofType(CampaignServices.class).in(this.securityApplication).set(this.campaignServices);
        field("employeeServices").ofType(EmployeeServices.class).in(this.securityApplication).set(this.employeeServices);
        field("metricsServices").ofType(MetricsServices.class).in(this.securityApplication).set(this.metricsServices);
    }

    @Test
    public void testListGroupsCallsGroupServicesListGroups_WhenListingGroups() {
        // @When Listing groups
        this.securityApplication.listGroups();

        // @Then groupServices.listGroups is called
        verify(this.groupServices, times(1)).listGroups();
    }

    @Test
    public void testListGroupsReturnsGroupsReturnedByGroupServices_WhenListingGroups() {
        // @Given a list of groups
        ArrayList<Group> list = Lists.newArrayList(new Group());
        when(this.groupServices.listGroups()).thenReturn(list);

        // @When Listing groups
        List<Group> groups = this.securityApplication.listGroups();

        // @Then groupServices.listGroups is called
        assertThat(groups).isSameAs(this.groupServices.listGroups());
    }

    @Test
    public void testListAuthoritiesCallsServicesListAuthorities_WhenListingAuthorities() {
        // @When listing authorities
        this.securityApplication.listAuthorities();

        // @Then authorityServices.listAuthorities is called
        verify(this.authorityServices, times(1)).listAuthorities();
    }

    @Test
    public void testListAuthoritiesReturnsServiceListAuthoritiesResult_WhenListingAuthorities() {
        //  @Given a list of authorities
        ArrayList<Authority> list = Lists.newArrayList(new Authority(), new Authority());
        when(this.authorityServices.listAuthorities()).thenReturn(list);

        // @When listing authorities
        List<Authority> authorities = this.securityApplication.listAuthorities();

        // @Then authorityServices.listAuthorities is called
        assertThat(authorities).isSameAs(list);
    }

    @Test
    public void testCreateGroupCallServicesCreateGroupWithGroupVO_WhenCreatingGroupFromVO() {
        // @Given a groupVO
        GroupVO groupVO = new GroupVO();
        Group createdGroup = new Group();
        when(this.groupServices.newGroup(groupVO)).thenReturn(createdGroup);

        // @When creating a group from it
        this.securityApplication.createGroup(groupVO);

        // @Then services newGroup is called with that VO
        verify(this.groupServices, times(1)).newGroup(groupVO);
    }

    @Test
    public void testCreateGroupReturnsGroupCreatedByServices_WhenCreatingGroupFromVO() {
        // @Given a groupVO
        GroupVO groupVO = new GroupVO();
        Group createdGroup = new Group();
        when(this.groupServices.newGroup(groupVO)).thenReturn(createdGroup);

        // @When creating a group from it
        Group group = this.securityApplication.createGroup(groupVO);

        // @Then services newGroup is called with that VO
        assertThat(group).isSameAs(createdGroup);
    }

    @Test
    public void testCreateGroupThrowsException_WhenCreatingGroupWithADuplicateName() {
        // @Given a groupVO
        GroupVO groupVO = new GroupVO();
        groupVO.setName("name");
        Group existentGroup = new Group();
        existentGroup.setName("name");
        Group createdGroup = new Group();
        when(this.groupServices.newGroup(groupVO)).thenReturn(createdGroup);
        when(this.groupServices.listGroups()).thenReturn(Lists.<Group>newArrayList(existentGroup));

        // @When creating a group from it
        try {
            this.securityApplication.createGroup(groupVO);
            fail();
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.DUPLICATE_GROUP_NAME);
        }
    }

    @Test
    public void testFindGroupByIdCallsGroupServicesFindGroupByIdWithId1_WhenFindingGroup1() {
        // @Given a group id 1
        int groupId = 1;
        Group group = new Group();
        when(this.groupServices.findGroupById(groupId)).thenReturn(group);

        // @When finding matching group
        this.securityApplication.findGroupById(groupId);

        // @Then GroupServices.findGroupById is called with 1 as a parameter
        verify(this.groupServices, times(1)).findGroupById(groupId);
    }

    @Test
    public void testFindGroupByIdCallsGroupServicesFindGroupByIdWithId2_WhenFindingGroup2() {
        // @Given a group id 2
        int groupId = 2;
        Group group = new Group();
        when(this.groupServices.findGroupById(groupId)).thenReturn(group);

        // @When finding matching group
        this.securityApplication.findGroupById(groupId);

        // @Then GroupServices.findGroupById is called with 2 as a parameter
        verify(this.groupServices, times(1)).findGroupById(groupId);
    }

    @Test
    public void testFindGroupByIdReturnsServicesFindGroupByIdResult_WhenFindingGroup() {
        // @Given a group id 2
        int groupId = 1;
        Group group = new Group();
        when(this.groupServices.findGroupById(groupId)).thenReturn(group);

        // @When finding matching group
        Group returnedGroup = this.securityApplication.findGroupById(groupId);

        // @Then GroupServices.findGroupById is called with 2 as a parameter
        assertThat(returnedGroup).isSameAs(group);
    }

    @Test
    public void testUpdateGroupCallsGroupServicesFindGroupById1_WhenUpdatingGroup1() {
        // @Given a VO with id 1
        int groupId = 1;
        GroupVO groupVO = new GroupVO();
        groupVO.setId(groupId);

        // @When updating the VO
        this.securityApplication.updateGroup(groupVO);

        // services.findById 1 is called
        verify(this.groupServices, times(1)).findGroupById(groupId);
    }

    @Test
    public void testUpdateGroupCallsGroupServicesFindGroupById7_WhenUpdatingGroup7() {
        // @Given a VO with id 1
        int groupId = 7;
        GroupVO groupVO = new GroupVO();
        groupVO.setId(groupId);

        // @When updating the VO
        this.securityApplication.updateGroup(groupVO);

        // services.findById 1 is called
        verify(this.groupServices, times(1)).findGroupById(groupId);
    }

    @Test
    public void testUpdateGroupCallsGroupServicesUpdateGroupWithInputVOAndGroupFoundById6_WhenUpdatingGroup6() {
        // @Given a VO with id 1
        int groupId = 6;
        GroupVO groupVO = new GroupVO();
        groupVO.setId(groupId);
        Group group = new Group();
        when(this.groupServices.findGroupById(groupId)).thenReturn(group);

        // @When updating the VO
        this.securityApplication.updateGroup(groupVO);

        // services.findById 1 is called
        verify(this.groupServices, times(1)).update(groupVO, group);
    }

    @Test
    public void testUpdateGroupCallsGroupServicesUpdateGroupWithInputVOAndGroupFoundById232_WhenUpdatingGroup232() {
        // @Given a VO with id 1
        int groupId = 232;
        GroupVO groupVO = new GroupVO();
        groupVO.setId(groupId);
        Group group = new Group();
        when(this.groupServices.findGroupById(groupId)).thenReturn(group);

        // @When updating the VO
        this.securityApplication.updateGroup(groupVO);

        // services.findById 1 is called
        verify(this.groupServices, times(1)).update(groupVO, group);
    }

    @Test
    public void testDeleteGroupCallsGroupServicesFindGroupById1_WhenDeletingGroup1() {
        // @Given a VO with id 1
        int groupId = 1;

        // @When updating the VO
        this.securityApplication.deleteGroup(groupId);

        // services.findById 1 is called
        verify(this.groupServices, times(1)).findGroupById(groupId);
    }

    @Test
    public void testDeleteGroupCallsGroupServicesFindGroupById4_WhenDeletingGroup4() {
        // @Given a VO with id 4
        int groupId = 4;

        // @When updating the VO
        this.securityApplication.deleteGroup(groupId);

        // services.findById 4 is called
        verify(this.groupServices, times(1)).findGroupById(groupId);
    }

    @Test
    public void testDeleteGroupCallsGroupServicesDeleteGroupWithFoundGroup_WhenDeletingGroup() {
        // @Given an id 1
        int groupId = 1;
        Group group = new Group();
        when(this.groupServices.findGroupById(groupId)).thenReturn(group);

        // @When deleting the VO
        this.securityApplication.deleteGroup(groupId);

        // services.deleteGroup
        verify(this.groupServices, times(1)).deleteGroup(group);
    }

    @Test
    public void testListAdminUserCallsServicesListAdminUsers_WhenListingAdminUsers() {
        // @When listing admin users
        this.securityApplication.listAdminUsers();

        // @Then adminUserServices.ListAdminUsers is called
        verify(this.adminUserServices, times(1)).listAdminUsers();
    }

    @Test
    public void testListAdminUserReturnsServicesAdminUserList_WhenListingAdminUsers() {
        // @Given an admin user list
        ArrayList<AdminUser> adminUsers = Lists.newArrayList(new AdminUser());
        when(this.adminUserServices.listAdminUsers()).thenReturn(adminUsers);

        // @When listing admin users
        List<AdminUser> adminUserList = this.securityApplication.listAdminUsers();

        // @Then adminUserServices.ListAdminUsers is called
        assertThat(adminUserList).isSameAs(adminUsers);
    }

    @Test
    public void testCreateAdminUserCallsAdminUserServicesNewAdminUserWithInput_WhenCreatingAdminUserFromInput() {
        // @Given admin user info as input
        AdminUser adminUser = new AdminUser();

        // @When creating an Admin user from it
        this.securityApplication.createAdminUser(adminUser);

        // @Then services.newAdminUSer is called with the input
        verify(this.adminUserServices, times(1)).newAdminUser(adminUser);
    }

    @Test
    public void testCreateAdminUserReturnsCreatedAdminUser_WhenCreatingAdminUserFromInput() {
        // @Given admin user info as input
        AdminUser adminUser = new AdminUser();
        when(this.adminUserServices.newAdminUser(adminUser)).thenReturn(adminUser);

        // @When creating an Admin user from it
        AdminUser user = this.securityApplication.createAdminUser(adminUser);

        // @Then services.newAdminUSer is called with the input
        assertThat(user).isSameAs(adminUser);
    }

    @Test
    public void testFindEmployeeGroupsByPageCallsServicesFindCampaignById1_WhenFindingEmployeesGroupsForCampaign1() {
        // @Given a campaign id 1
        int campaignId = 1;
        int page = 1;
        int rows = 25;
        String direction = "asc";
        String sort = "name";
        PageRequest pageRequest = new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sort));
        Map<String, Object> filter = null;
        Campaign campaign = new Campaign("campaingName", newDate(2010, 11, 11), newDate(2011, 5, 5));
        campaign.setId(campaignId);
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When finding employee groups from that campaign
        this.securityApplication.findEmployeeGroupsByPage(campaignId, pageRequest, filter);

        // @Then campaignServices.findCampaignById is called with campaignId 1
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testFindEmployeeGroupsByPageCallsServicesFindCampaignById4_WhenFindingEmployeesGroupsForCampaign4() {
        // @Given a campaign id 4
        int campaignId = 4;
        int page = 1;
        int rows = 25;
        String direction = "asc";
        String sort = "name";
        PageRequest pageRequest = new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sort));
        Map<String, Object> filter = null;
        Campaign campaign = new Campaign("campaingName", newDate(2010, 11, 11), newDate(2011, 5, 5));
        campaign.setId(campaignId);
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When finding employee groups from that campaign
        this.securityApplication.findEmployeeGroupsByPage(campaignId, pageRequest, filter);

        // @Then campaignServices.findCampaignById is called with campaignId 4
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testFindEmployeeGroupsByPageCallsServicesFindEmployeeGroupsByPageWithCampaign1_WhenFindingEmployeesGroupsForCampaign1() {
        // @Given a campaign id 1
        int campaignId = 1;
        int page = 1;
        int rows = 25;
        String direction = "asc";
        String sort = "name";
        PageRequest pageRequest = new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sort));
        Map<String, Object> filter = null;
        Campaign campaign = new Campaign("campaingName", newDate(2010, 11, 11), newDate(2011, 5, 5));
        campaign.setId(campaignId);
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When finding employee groups from that campaign
        this.securityApplication.findEmployeeGroupsByPage(campaignId, pageRequest, filter);

        // @Then services findEmployeesByCampaignAndPage
        verify(this.employeeServices, times(1)).listEmployeesForCampaignAndPage(eq(this.campaignServices.findCampaignById(campaignId)), Matchers.<List<Group>>any(), eq(page), eq(rows), eq(sort), eq(direction), eq(filter));
    }

    @Test
    public void testFindEmployeeGroupsByPageCallsServicesFindEmployeeGroupsByPageWithCampaign4_WhenFindingEmployeesGroupsForCampaign4() {
        // @Given a campaign id 1
        int campaignId = 4;
        int page = 1;
        int rows = 25;
        String direction = "asc";
        String sort = "name";
        PageRequest pageRequest = new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sort));
        Map<String, Object> filter = null;
        Campaign campaign = new Campaign("campaingName", newDate(2010, 11, 11), newDate(2011, 5, 5));
        campaign.setId(campaignId);
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When finding employee groups from that campaign
        this.securityApplication.findEmployeeGroupsByPage(campaignId, pageRequest, filter);

        // @Then services findEmployeesByCampaignAndPage
        verify(this.employeeServices, times(1)).listEmployeesForCampaignAndPage(eq(this.campaignServices.findCampaignById(campaignId)), Matchers.<List<Group>>any(), eq(page), eq(rows), eq(sort), eq(direction), eq(filter));
    }

    @Test
    public void testFindEmployeeGroupsByPageCallsServicesFindEmployeeGroupsByPage1_WhenFindingEmployeesGroupsPage1() {
        // @Given a campaign id 1
        int campaignId = 4;
        int page = 1;
        int rows = 25;
        String direction = "asc";
        String sort = "name";
        PageRequest pageRequest = new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sort));
        Map<String, Object> filter = null;
        Campaign campaign = new Campaign("campaingName", newDate(2010, 11, 11), newDate(2011, 5, 5));
        campaign.setId(campaignId);
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When finding employee groups from that campaign
        this.securityApplication.findEmployeeGroupsByPage(campaignId, pageRequest, filter);

        // @Then services findEmployeesByCampaignAndPage
        verify(this.employeeServices, times(1)).listEmployeesForCampaignAndPage(eq(this.campaignServices.findCampaignById(campaignId)), Matchers.<List<Group>>any(), eq(page), eq(rows), eq(sort), eq(direction), eq(filter));
    }

    @Test
    public void testFindEmployeeGroupsByPageCallsServicesFindEmployeeGroupsByPageWith25Rows_WhenFindingEmployeesGroupsPageWith25Rows() {
        // @Given a campaign id 1
        int campaignId = 4;
        int page = 1;
        int rows = 25;
        String direction = "asc";
        String sort = "name";
        PageRequest pageRequest = new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sort));
        Map<String, Object> filter = null;
        Campaign campaign = new Campaign("campaingName", newDate(2010, 11, 11), newDate(2011, 5, 5));
        campaign.setId(campaignId);
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When finding employee groups from that campaign
        this.securityApplication.findEmployeeGroupsByPage(campaignId, pageRequest, filter);

        // @Then services findEmployeesByCampaignAndPage
        verify(this.employeeServices, times(1)).listEmployeesForCampaignAndPage(eq(this.campaignServices.findCampaignById(campaignId)), Matchers.<List<Group>>any(), eq(page), eq(rows), eq(sort), eq(direction), eq(filter));
    }

    @Test
    public void testFindEmployeeGroupsByPageCallsServicesFindEmployeeGroupsByPageWith43Rows_WhenFindingEmployeesGroupsPageWith43Rows() {
        // @Given a campaign id 1
        int campaignId = 4;
        int page = 1;
        int rows = 43;
        String direction = "asc";
        String sort = "name";
        PageRequest pageRequest = new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sort));
        Map<String, Object> filter = null;
        Campaign campaign = new Campaign("campaingName", newDate(2010, 11, 11), newDate(2011, 5, 5));
        campaign.setId(campaignId);
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When finding employee groups from that campaign
        this.securityApplication.findEmployeeGroupsByPage(campaignId, pageRequest, filter);

        // @Then services findEmployeesByCampaignAndPage
        verify(this.employeeServices, times(1)).listEmployeesForCampaignAndPage(eq(this.campaignServices.findCampaignById(campaignId)), Matchers.<List<Group>>any(), eq(page), eq(rows), eq(sort), eq(direction), eq(filter));
    }

    @Test
    public void testFindEmployeeGroupsByPageCallsServicesFindEmployeeGroupsByPageSortedByUsername_WhenFindingEmployeesGroupsPageSortedByUsername() {
        // @Given a campaign id 1
        int campaignId = 4;
        int page = 1;
        int rows = 43;
        String direction = "asc";
        String sort = "username";
        PageRequest pageRequest = new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sort));
        Map<String, Object> filter = null;
        Campaign campaign = new Campaign("campaingName", newDate(2010, 11, 11), newDate(2011, 5, 5));
        campaign.setId(campaignId);
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When finding employee groups from that campaign
        this.securityApplication.findEmployeeGroupsByPage(campaignId, pageRequest, filter);

        // @Then services findEmployeesByCampaignAndPage
        verify(this.employeeServices, times(1)).listEmployeesForCampaignAndPage(eq(this.campaignServices.findCampaignById(campaignId)), Matchers.<List<Group>>any(), eq(page), eq(rows), eq(sort), eq(direction), eq(filter));
    }

    @Test
    public void testFindEmployeeGroupsByPageCallsServicesFindEmployeeGroupsByPageSortedDesc_WhenFindingEmployeesGroupsPageSortedDesc() {
        // @Given a campaign id 1
        int campaignId = 4;
        int page = 1;
        int rows = 43;
        String direction = "desc";
        String sort = "username";
        PageRequest pageRequest = new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sort));
        Map<String, Object> filter = null;
        Campaign campaign = new Campaign("campaingName", newDate(2010, 11, 11), newDate(2011, 5, 5));
        campaign.setId(campaignId);
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When finding employee groups from that campaign
        this.securityApplication.findEmployeeGroupsByPage(campaignId, pageRequest, filter);

        // @Then services findEmployeesByCampaignAndPage
        verify(this.employeeServices, times(1)).listEmployeesForCampaignAndPage(eq(this.campaignServices.findCampaignById(campaignId)), Matchers.<List<Group>>any(), eq(page), eq(rows), eq(sort), eq(direction), eq(filter));
    }

    @Test
    public void testFindEmployeeGroupsByPageCallsServicesListGroups_WhenFindingEmployeesGroups() {
        // @Given a campaign id 1
        int campaignId = 4;
        int page = 1;
        int rows = 43;
        String direction = "desc";
        String sort = "username";
        PageRequest pageRequest = new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sort));
        Map<String, Object> filter = null;
        Campaign campaign = new Campaign("campaingName", newDate(2010, 11, 11), newDate(2011, 5, 5));
        campaign.setId(campaignId);
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When finding employee groups from that campaign
        this.securityApplication.findEmployeeGroupsByPage(campaignId, pageRequest, filter);

        // @Then services findEmployeesByCampaignAndPage
        verify(this.groupServices, times(1)).listGroups();
    }

    @Test
    public void testFindEmployeeGroupsByPageReturnsAListOfMapsWithABoleanIndicatingTheEmployeeBelongsToAGruopOrNot_WhenFindingEmployeesGroups() {
        // @Given a campaign id 1
        int campaignId = 4;
        int page = 1;
        int rows = 43;
        String direction = "desc";
        String sort = "username";
        PageRequest pageRequest = new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sort));
        Map<String, Object> filter = null;
        Campaign campaign = new Campaign("campaingName", newDate(2010, 11, 11), newDate(2011, 5, 5));
        campaign.setId(campaignId);
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);
        Group group1 = new Group();
        group1.setId(1);
        group1.setEnabled(true);
        group1.setName("GROUP1");
        Group group2 = new Group();
        group2.setId(2);
        group2.setEnabled(true);
        group2.setName("GROUP2");

        Employee employee1 = new Employee();
        employee1.setId(1l);
        employee1.setEnabled(true);
        employee1.setName("Hi");
        employee1.setGroups(Lists.<Group>newArrayList(group1));

        Employee employee2 = new Employee();
        employee2.setId(2l);
        employee2.setEnabled(true);
        employee2.setName("Hi");
        employee2.setGroups(Lists.<Group>newArrayList(group2));

        when(this.employeeServices.listEmployeesForCampaignAndPage(campaign, Lists.<Group>newArrayList(group1, group2), page, rows, sort, "DESC", filter)).thenReturn(Lists.<Employee>newArrayList(employee1, employee2));
        when(this.groupServices.listGroups()).thenReturn(Lists.<Group>newArrayList(group1, group2));

        // @When finding employee groups from that campaign
        Page<Map<String, Object>> employeeGroupsByPage = this.securityApplication.findEmployeeGroupsByPage(campaignId, pageRequest, filter);

        // @Then services findEmployeesByCampaignAndPage
        assertThat(employeeGroupsByPage).hasSize(2);
        assertThat(employeeGroupsByPage.getContent().get(0).get("id")).isEqualTo(employee1.getId());
        assertThat(employeeGroupsByPage.getContent().get(0).get("name")).isEqualTo(employee1.getName());
        assertThat(employeeGroupsByPage.getContent().get(0).get("username")).isEqualTo(employee1.getUsername());
        assertThat(employeeGroupsByPage.getContent().get(0).get("GROUP1")).isEqualTo(employee1.getGroups().contains(group1));
        assertThat(employeeGroupsByPage.getContent().get(0).get("GROUP2")).isEqualTo(employee1.getGroups().contains(group2));

        assertThat(employeeGroupsByPage.getContent().get(1).get("id")).isEqualTo(employee2.getId());
        assertThat(employeeGroupsByPage.getContent().get(1).get("name")).isEqualTo(employee2.getName());
        assertThat(employeeGroupsByPage.getContent().get(1).get("username")).isEqualTo(employee2.getUsername());
        assertThat(employeeGroupsByPage.getContent().get(1).get("GROUP1")).isEqualTo(employee2.getGroups().contains(group1));
        assertThat(employeeGroupsByPage.getContent().get(1).get("GROUP2")).isEqualTo(employee2.getGroups().contains(group2));
    }

    @Test
    public void testUpdateEmployeeGroupsCallsCampaignServicesFindCampaignById1_WhenUpdatingEmployeeGroupsOfEmployeeOfCampaign1() {
        // @Given a campaign id
        int campaignId = 1;
        Map<String, Object> employeeGroups = Maps.newHashMap();
        employeeGroups.put("id", "1");
        Employee employee = new Employee();
        employee.setGroups(Lists.<Group>newArrayList());
        when(this.employeeServices.findEmployeeByIdAndCampaign(Matchers.<Long>any(), Matchers.<Campaign>any())).thenReturn(employee);

        // @When updating employee groups in campaign
        this.securityApplication.updateEmployeeGroups(campaignId, employeeGroups);

        // @Then campaignServices.findCampaignById is called
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testUpdateEmployeeGroupsCallsCampaignServicesFindCampaignById2_WhenUpdatingEmployeeGroupsOfEmployeeOfCampaign2() {
        // @Given a campaign id
        int campaignId = 2;
        Map<String, Object> employeeGroups = Maps.newHashMap();
        employeeGroups.put("id", "1");
        Employee employee = new Employee();
        employee.setGroups(Lists.<Group>newArrayList());
        when(this.employeeServices.findEmployeeByIdAndCampaign(Matchers.<Long>any(), Matchers.<Campaign>any())).thenReturn(employee);

        // @When updating employee groups in campaign
        this.securityApplication.updateEmployeeGroups(campaignId, employeeGroups);

        // @Then campaignServices.findCampaignById is called
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testUpdateEmployeeGroupsCallsServicesFindEmployeeByCampaignAndId1_WhenUpdatingEmployeeGroupsOfEmployee1OfCampaign() {
        // @Given a campaign id
        int campaignId = 1;
        Map<String, Object> employeeGroups = Maps.newHashMap();
        employeeGroups.put("id", "1");
        Campaign campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 2, 2));
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);
        Employee employee = new Employee();
        employee.setGroups(Lists.<Group>newArrayList());
        when(this.employeeServices.findEmployeeByIdAndCampaign(Matchers.<Long>any(), Matchers.<Campaign>any())).thenReturn(employee);

        // @When updating employee groups in campaign
        this.securityApplication.updateEmployeeGroups(campaignId, employeeGroups);

        // @Then campaignServices.findCampaignById is called
        verify(this.employeeServices, times(1)).findEmployeeByIdAndCampaign(Long.valueOf((String) employeeGroups.get("id")), this.campaignServices.findCampaignById(campaignId));
    }

    @Test
    public void testUpdateEmployeeGroupsSetsEmployeeGroupsToThoseThatMatchWithATrueInInputMap_WhenUpdatingEmployeeGroupsOfEmployeeOfCampaign() {
        // @Given a campaign id
        int campaignId = 1;
        long employeeId = 1;
        Group group1 = new Group();
        group1.setName("group1");
        Group group2 = new Group();
        group2.setName("group2");
        Group group3 = new Group();
        group3.setName("group3");
        Group group4 = new Group();
        group4.setName("group4");

        when(this.groupServices.listGroups()).thenReturn(Lists.<Group>newArrayList(group1, group2, group3, group4));

        Map<String, Object> employeeGroups = Maps.newHashMap();
        employeeGroups.put("group1", "true");
        employeeGroups.put("group2", "false");
        employeeGroups.put("group3", "false");
        employeeGroups.put("group4", "false");

        employeeGroups.put("id", "1");
        Campaign campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 2, 2));
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);
        Employee employee = new Employee();
        employee.setGroups(Lists.<Group>newArrayList());
        when(this.employeeServices.findEmployeeByIdAndCampaign(employeeId, campaign)).thenReturn(employee);

        // @When updating employee groups in campaign
        this.securityApplication.updateEmployeeGroups(campaignId, employeeGroups);

        // @Then campaignServices.findCampaignById is called
        assertThat(employee.getGroups()).containsExactly(group1);
    }

    @Test
    public void testListEmployeesCallsCampaignServicesFindCampaignById1_WhenListingEmployeesOfCampaign1() {
        // @Given a campaignId 1
        int campaignId = 1;

        // @When listing it's employees
        this.securityApplication.listEmployees(campaignId);

        // @Then findCampaignById is called
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testListEmployeesCallsCampaignServicesFindCampaignById4_WhenListingEmployeesOfCampaign4() {
        // @Given a campaignId 4
        int campaignId = 4;

        // @When listing it's employees
        this.securityApplication.listEmployees(campaignId);

        // @Then findCampaignById is called
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testListEmployeesCallsEmployeeServicesListEmployeesForCampaignWithMatchingCampaing_WhenListingEmployeesOfCampaign() {
        // @Given a campaignId
        int campaignId = 1;
        Campaign campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 2, 2));
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When listing it's employees
        this.securityApplication.listEmployees(campaignId);

        // @Then findCampaignById is called
        verify(this.employeeServices, times(1)).listEmployeesForCampaign(campaign);
    }

    @Test
    public void testListEmployeesReturnsEmployeeServicesResult_WhenListingEmployeesOfCampaign() {
        // @Given a campaignId
        int campaignId = 1;
        Campaign campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 2, 2));
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);
        Employee employee = new Employee();
        Metric metric = new Metric(campaign, "hi");
        employee.setMetrics(Lists.<Metric>newArrayList(metric));
        Group group = new Group();
        group.setName("Hello");
        Authority authority = new Authority();
        authority.setName("ACCESS");
        group.setAuthorities(Lists.<Authority>newArrayList(authority));
        employee.setGroups(Lists.<Group>newArrayList(group));
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        List<Employee> expected = Lists.newArrayList(employee);
        when(this.employeeServices.listEmployeesForCampaign(campaign)).thenReturn(expected);

        // @When listing it's employees
        List<Employee> employees = this.securityApplication.listEmployees(campaignId);

        // @Then findCampaignById is called
        assertThat(employees).isSameAs(expected);
    }

    @Test
    public void testFindEmployeeByCampaignIdAndEmployeeIdCallsCampaignServicesFindCampaignById1_WhenFindingEmployeeOfCampaign1() {
        // @Given a campaign id
        int campaignId = 1;
        Employee expected = new Employee();
        when(this.employeeServices.findEmployeeByIdAndCampaign(eq(20l), Matchers.<Campaign>any())).thenReturn(expected);

        // @When finding an employee of that campaign
        this.securityApplication.findEmployeeByCampaignIdAndEmployeeId(campaignId, 20l);

        // @Then campaignServices.findCampaignById is called
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testFindEmployeeByCampaignIdAndEmployeeIdCallsCampaignServicesFindCampaignById7_WhenFindingEmployeeOfCampaign7() {
        // @Given a campaign id
        int campaignId = 7;
        Employee expected = new Employee();
        when(this.employeeServices.findEmployeeByIdAndCampaign(eq(20l), Matchers.<Campaign>any())).thenReturn(expected);

        // @When finding an employee of that campaign
        this.securityApplication.findEmployeeByCampaignIdAndEmployeeId(campaignId, 20l);

        // @Then campaignServices.findCampaignById is called
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testFindEmployeeByCampaignIdAndEmployeeIdCallsEmployeeServicesFindEmployeeById1AndCampaign_WhenFindingEmployee2OfCampaign() {
        // @Given a campaign id
        int campaignId = 1;
        long employeeId = 2l;
        Campaign campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 2, 2));
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);
        Employee expected = new Employee();
        when(this.employeeServices.findEmployeeByIdAndCampaign(eq(employeeId), Matchers.<Campaign>any())).thenReturn(expected);

        // @When finding an employee of that campaign
        this.securityApplication.findEmployeeByCampaignIdAndEmployeeId(campaignId, employeeId);

        // @Then employeeServices.findEmployeeByIdAndCampaign is called
        verify(this.employeeServices, times(1)).findEmployeeByIdAndCampaign(employeeId, campaign);
    }

    @Test
    public void testFindEmployeeByCampaignIdAndEmployeeIdCallsEmployeeServicesFindEmployeeById1AndCampaign_WhenFindingEmployee5OfCampaign() {
        // @Given a campaign id
        int campaignId = 1;
        long employeeId = 5l;
        Campaign campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 2, 2));
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);
        Employee expected = new Employee();
        when(this.employeeServices.findEmployeeByIdAndCampaign(eq(employeeId), Matchers.<Campaign>any())).thenReturn(expected);

        // @When finding an employee of that campaign
        this.securityApplication.findEmployeeByCampaignIdAndEmployeeId(campaignId, employeeId);

        // @Then employeeServices.findEmployeeByIdAndCampaign is called
        verify(this.employeeServices, times(1)).findEmployeeByIdAndCampaign(employeeId, campaign);
    }

    @Test
    public void testFindEmployeeByCampaignIdAndEmployeeIdReturnsEmployeeServicesResult_WhenFindingEmployeeOfCampaign() {
        // @Given a campaign id
        int campaignId = 1;
        long employeeId = 5l;
        Campaign campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 2, 2));
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);
        Employee expected = new Employee();
        when(this.employeeServices.findEmployeeByIdAndCampaign(eq(employeeId), Matchers.<Campaign>any())).thenReturn(expected);


        // @When finding an employee of that campaign
        Employee employee = this.securityApplication.findEmployeeByCampaignIdAndEmployeeId(campaignId, employeeId);

        // @Then employeeServices.findEmployeeByIdAndCampaign is called
        assertThat(employee).isSameAs(expected);
    }

    @Test
    public void testCreateEmployeeCallsServiceFindCampaignById1_WhenCreatingAnEmployeeFromTheVOWithCampaignId1() {
        // @Given an employeeVO with campaignId 1
        EmployeeVO employeeVO = new EmployeeVO();
        employeeVO.setCampaignId(1);

        // @When creating an employee
        this.securityApplication.createEmployee(employeeVO);

        // @Then findCampaignById 1 is called
        verify(this.campaignServices, times(1)).findCampaignById(employeeVO.getCampaignId());
    }

    @Test
    public void testCreateEmployeeCallsServiceFindCampaignById7_WhenCreatingAnEmployeeFromTheVOWithCampaignId7() {
        // @Given an employeeVO with campaignId 7
        EmployeeVO employeeVO = new EmployeeVO();
        employeeVO.setCampaignId(7);

        // @When creating an employee
        this.securityApplication.createEmployee(employeeVO);

        // @Then findCampaignById 7 is called
        verify(this.campaignServices, times(1)).findCampaignById(employeeVO.getCampaignId());
    }

    @Test
    public void testCreateEmployeeCallsServiceListGroups_WhenCreatingAnEmployeeFromTheVOWithCampaignId7() {
        // @Given an employeeVO with campaignId 7
        EmployeeVO employeeVO = new EmployeeVO();
        employeeVO.setCampaignId(7);

        // @When creating an employee
        this.securityApplication.createEmployee(employeeVO);

        // @Then findCampaignById 7 is called
        verify(this.groupServices, times(1)).listGroups();
    }

    @Test
    public void testCreateEmployeeCallsServiceNewEmployeeWithInputVOAndMatchingCampaign_WhenCreatingAnEmployeeFromTheVO() {
        // @Given an employeeVO and a matching Campaign
        EmployeeVO employeeVO = new EmployeeVO();
        employeeVO.setCampaignId(1);
        Campaign campaign = new Campaign("Hi", newDate(2008, 5, 5), newDate(2009, 4, 2));
        when(this.campaignServices.findCampaignById(employeeVO.getCampaignId())).thenReturn(campaign);
        List<Group> groups = Lists.newArrayList();
        when(this.groupServices.listGroups()).thenReturn(groups);
        List<Metric> metrics = Lists.newArrayList();
        when(this.metricsServices.listSubmetricsByCampaign(campaign)).thenReturn(metrics);

        // @When creating an employee
        this.securityApplication.createEmployee(employeeVO);

        // @Then employeeServices.newEmployee is called with the VO and the matching campaign
        verify(this.employeeServices, times(1)).newEmployee(employeeVO, campaign, groups, metrics);
    }

    @Test
    public void testCreateEmployeeReturnsCreatedEmployee_WhenCreatingAnEmployeeFromTheVO() {
        // @Given an employeeVO and a matching Campaign
        EmployeeVO employeeVO = new EmployeeVO();
        employeeVO.setCampaignId(1);
        Campaign campaign = new Campaign("Hi", newDate(2008, 5, 5), newDate(2009, 4, 2));
        when(this.campaignServices.findCampaignById(employeeVO.getCampaignId())).thenReturn(campaign);
        Employee expected = new Employee();
        List<Group> groups = Lists.newArrayList();
        when(this.groupServices.listGroups()).thenReturn(groups);
        List<Metric> metrics = Lists.newArrayList();
        when(this.metricsServices.listSubmetricsByCampaign(campaign)).thenReturn(metrics);
        when(this.employeeServices.newEmployee(employeeVO, campaign, groups, metrics)).thenReturn(expected);

        // @When creating an employee
        Employee employee = this.securityApplication.createEmployee(employeeVO);

        // @Then employeeServices.newEmployee is called with the VO and the matching campaign
        assertThat(employee).isSameAs(this.employeeServices.newEmployee(employeeVO, campaign, groups, metrics));
    }

    @Test
    public void testUpdateEmployeeCallsCampaignServicesFindCampaignById1_WhenUpdatingEmployeeOfCampaign1() {
        // @Given a campaignId an employee VO
        int campaignId = 1;
        EmployeeVO employeeVO = new EmployeeVO();

        // @When updatingEmployee
        this.securityApplication.updateEmployee(campaignId, employeeVO);

        // @Then findCampaignById is called
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testUpdateEmployeeCallsCampaignServicesFindCampaignById2_WhenUpdatingEmployeeOfCampaign2() {
        // @Given a campaignId an employee VO
        int campaignId = 2;
        EmployeeVO employeeVO = new EmployeeVO();

        // @When updatingEmployee
        this.securityApplication.updateEmployee(campaignId, employeeVO);

        // @Then findCampaignById is called
        verify(this.campaignServices, times(1)).findCampaignById(campaignId);
    }

    @Test
    public void testUpdateEmployeeCallsMetricServicesListMetricsByCampaign_WhenUpdatingEmployeeOfACampaign() {
        // @Given a campaignId an employee VO
        int campaignId = 1;
        EmployeeVO employeeVO = new EmployeeVO();
        Campaign campaign = new Campaign("campaignName", newDate(2011, 1, 1), newDate(2013, 5, 5));
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);

        // @When updatingEmployee
        this.securityApplication.updateEmployee(campaignId, employeeVO);

        // @Then findCampaignById is called
        verify(this.metricsServices, times(1)).listSubmetricsByCampaign(campaign);
    }

    @Test
    public void testUpdateEmployeeCallsEmployeeServicesUpdateEmployeeWithEmployeeVOAndCampaignAndMetrics_WhenUpdatingEmployeeOfACampaign() {
        // @Given a campaignId an employee VO
        int campaignId = 1;
        EmployeeVO employeeVO = new EmployeeVO();
        Campaign campaign = new Campaign("campaignName", newDate(2011, 1, 1), newDate(2013, 5, 5));
        when(this.campaignServices.findCampaignById(campaignId)).thenReturn(campaign);
        ArrayList<Metric> metrics = Lists.newArrayList();
        when(this.metricsServices.listSubmetricsByCampaign(campaign)).thenReturn(metrics);

        // @When updatingEmployee
        this.securityApplication.updateEmployee(campaignId, employeeVO);

        // @Then findCampaignById is called
        verify(this.employeeServices, times(1)).updateEmployee(employeeVO, campaign, metrics);
    }

    @Test
    public void testDeleteAdminUserCallsServicesFindAdminUserById1_WhenDeletingAdminUser1() {
        // @Given an admin user id 1
        int adminUserId = 1;

        // @When deleting the admin user
        this.securityApplication.deleteAdminUser(adminUserId);

        // @Then services findAdminUserIsCalled
        verify(this.adminUserServices, times(1)).findAdminUserById(adminUserId);
    }

    @Test
    public void testDeleteAdminUserCallsServicesFindAdminUserById2_WhenDeletingAdminUser2() {
        // @Given an admin user id 2
        int adminUserId = 2;

        // @When deleting the admin user
        this.securityApplication.deleteAdminUser(adminUserId);

        // @Then services findAdminUserIsCalled
        verify(this.adminUserServices, times(1)).findAdminUserById(adminUserId);
    }

    @Test
    public void testDeleteAdminUserCallsServicesDeleteAdminUserWithFoundAdminUser_WhenDeletingAdminUser() {
        // @Given an admin user id 2
        int adminUserId = 2;
        AdminUser adminUser = new AdminUser();
        when(this.adminUserServices.findAdminUserById(adminUserId)).thenReturn(adminUser);

        // @When deleting the admin user
        this.securityApplication.deleteAdminUser(adminUserId);

        // @Then services findAdminUserIsCalled
        verify(this.adminUserServices, times(1)).deleteAdminUser(adminUser);
    }
}
