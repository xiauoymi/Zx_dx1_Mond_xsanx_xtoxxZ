package com.monsanto.metricspos.core.application;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.CampaignServices;
import com.monsanto.metricspos.core.ComputeManager;
import com.monsanto.metricspos.core.DataTableServices;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.DataColumnVO;
import com.monsanto.metricspos.core.application.vo.DataRowVO;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.externaldata.*;
import com.monsanto.metricspos.core.helpers.CoreTestsHelper;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.CampaignParameter;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricFactory;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import com.monsanto.metricspos.persistence.DataRowPersistor;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import com.monsanto.metricspos.persistence.RowValuesServices;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class TransactionalTablesApplication_UT {
    private DataTableServices tableServices;
    private RowValuesServices rowValuesServices;
    private CampaignServices campaignServices;
    private HashMap<String, DataType> dataTypeMap;
    private DataProvider dataProvider;
    private TransactionalTablesApplication transactionalTablesApplication;
    private CoreTestsHelper coreTestsHelper;
    private Campaign campaign;

    @Before
    public void setUp() {
        this.rowValuesServices = mock(RowValuesServices.class);
        this.campaignServices = mock(CampaignServices.class);
        this.tableServices = mock(DataTableServices.class);

        campaign = new Campaign("Campaign to test", newDate(2011, 4, 1), newDate(2012, 3, 31));
        ComputeManager computeManager = mock(ComputeManager.class);
        campaign.setComputeManager(computeManager);

        campaign.setFactory(new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                final Metric metric = new Metric(campaign, name);
                metric.setId(1);
                return metric;
            }
        });

        campaign.setId(1);
        campaign.setMetrics(Lists.<Metric>newArrayList());

        dataProvider = new DataProvider();
        dataProvider.setCode("CRM");

        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistor.getActualColumnName("aColumn")).thenReturn("TEXT1");
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        coreTestsHelper = new CoreTestsHelper(dataProvider, campaign, dataRowPersistorFactory);
        dataTypeMap = Maps.newHashMap();
        dataTypeMap.put(coreTestsHelper.stringDataType().getCode(), coreTestsHelper.stringDataType());
        dataTypeMap.put(coreTestsHelper.serviceCenterDataType().getCode(), coreTestsHelper.serviceCenterDataType());
        dataTypeMap.put(coreTestsHelper.pointOfSaleDataType().getCode(), coreTestsHelper.pointOfSaleDataType());
        dataTypeMap.put(coreTestsHelper.enumDataType().getCode(), coreTestsHelper.enumDataType());
        DataTable dataTable = coreTestsHelper.newDataTable(10, "tableName", "description", Lists.newArrayList(coreTestsHelper.newDataColumn("columnName")), rowValuesServices);
        campaign.addDataTable(dataTable);
        campaign.setMetrics(Lists.<Metric>newArrayList());

        CampaignParameter campaignParameter = new CampaignParameter();
        campaignParameter.setValue("hola@chau.com");
        when(this.campaignServices.findParameterByName(CampaignParameter.OVERRIDE_TO_PARAMETER)).thenReturn(campaignParameter);

        this.transactionalTablesApplication = new TransactionalTablesApplication();
        field("campaignServices").ofType(CampaignServices.class).in(this.transactionalTablesApplication).set(this.campaignServices);
        field("tableServices").ofType(DataTableServices.class).in(this.transactionalTablesApplication).set(this.tableServices);
        field("dataTypeMap").ofType(Map.class).in(this.transactionalTablesApplication).set(this.dataTypeMap);

        Logger auditLog = mock(Logger.class);
        field("auditLog").ofType(Logger.class).in(this.transactionalTablesApplication).set(auditLog);
    }


    @Test
    public void testFindDataTableByIdReturnsMatchingTable_WhenTableExists() {
        // @Given an existing DtaTable
        List<DataColumn> columns = Lists.newArrayList(coreTestsHelper.newDataColumn("columnName"));
        DataTable expectedDataTable = coreTestsHelper.newDataTable(1, "tableName", "description", columns, rowValuesServices);
        when(this.tableServices.findDataTableById(expectedDataTable.getId())).thenReturn(expectedDataTable);

        // @When finding the table
        DataTable dataTable = this.transactionalTablesApplication.findDataTableById(expectedDataTable.getId());

        // @Then the table is returned
        assertThat(dataTable.getId()).isEqualTo(expectedDataTable.getId());
        assertThat(dataTable.getName()).isEqualTo("tableName");
    }


    @Test
    public void testFindMetadataBytDataTableIdReturnsListOfColumnsOfTheDataTable_WhenColumnsExist() {
        // @Given an existing DataTable
        DataColumn dataColumn = coreTestsHelper.newDataColumn("columnName", coreTestsHelper.stringDataType(), "Description", 21, 11, 11, true, true, true, true);
        List<DataColumn> columns = Lists.newArrayList(dataColumn);
        DataTable expectedDataTable = coreTestsHelper.newDataTable(1, "tableName", "description", columns, rowValuesServices);
        when(this.tableServices.findMetadataByDataTable(expectedDataTable)).thenReturn(columns);
        when(this.tableServices.findDataTableById(expectedDataTable.getId())).thenReturn(expectedDataTable);

        // @When finding the table's metadata
        List<DataColumn> returnedColumns = this.transactionalTablesApplication.findMetadataByDataTableId(expectedDataTable.getId());

        // @Then the table's columns are returned
        assertThat(returnedColumns).hasSize(1);
        DataColumn column = returnedColumns.get(0);
        assertThat(column.getName()).isEqualTo(dataColumn.getName());
        assertThat(column.getDataType().getName()).isEqualTo(dataColumn.getDataType().getName());
        assertThat(column.getDescription()).isEqualTo(dataColumn.getDescription());
        assertThat(column.getMaxSize()).isEqualTo(dataColumn.getMaxSize());
        assertThat(column.getMinSize()).isEqualTo(dataColumn.getMinSize());
        assertThat(column.getPrecision()).isEqualTo(dataColumn.getPrecision());
        assertThat(column.isRequired()).isEqualTo(dataColumn.isRequired());
        assertThat(column.isSortable()).isEqualTo(dataColumn.isSortable());
    }

    @Test
    public void testNewDataTableReturnsAMatchingDataTable_WhenNameDescriptionExistingCampaignIdAndExistingProviderCodeAreProvided() {
        // @Given an existing campaign and a table name and description
        DataTableVO dataTableVO = new DataTableVO();
        dataTableVO.setCampaignId(campaign.getId());
        dataTableVO.setName("LeTable");
        dataTableVO.setDescription("This is a table");
        dataTableVO.setProvider(dataProvider.getCode());
        DataTable dataTable = coreTestsHelper.newDataTable(dataTableVO.getName(), dataTableVO.getDescription());
        when(this.campaignServices.findCampaignById(this.campaign.getId())).thenReturn(campaign);
        when(this.tableServices.newDataTable(dataTableVO, campaign)).thenReturn(dataTable);

        // @When creating a table
        DataTable returnedDataTable = this.transactionalTablesApplication.newDataTable(dataTableVO);

        // @The table is created with that name and under the given campaign
        assertThat(returnedDataTable).isNotNull();
        assertThat(returnedDataTable.getName()).isEqualTo(dataTableVO.getName());
        assertThat(returnedDataTable.getDescription()).isEqualTo(dataTableVO.getDescription());
        assertThat(returnedDataTable.getCampaign()).isEqualTo(campaign);
    }

    @Test
    public void testNewDataTableThrowsException_WhenNameHasSpaces() {
        // @Given a data table VO of a table with a name that has spaces
        DataTableVO dataTableVO = new DataTableVO();
        dataTableVO.setCampaignId(campaign.getId());
        dataTableVO.setName("Le Table");
        dataTableVO.setDescription("This is a table");
        dataTableVO.setProvider(dataProvider.getCode());
        DataTable dataTable = coreTestsHelper.newDataTable(dataTableVO.getName(), dataTableVO.getDescription());
        when(this.campaignServices.findCampaignById(this.campaign.getId())).thenReturn(campaign);
        when(this.tableServices.newDataTable(dataTableVO, campaign)).thenReturn(dataTable);

        try {
            // @When creating a table
            this.transactionalTablesApplication.newDataTable(dataTableVO);
            fail();
        } catch (BusinessException e) {
            // Then an exception is thrown
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.TABLE_NAME_CANNOT_HAVE_SPACES);
        } catch (Throwable t) {
            fail();
        }

    }

    @Test
    public void testNewDataTableCallsTableServiceNewDataTable_WhenNameDescriptionExistingCampaignIdAndExistingProviderCodeAreProvided() {
        // @Given an existing campaign and a table name and description
        DataTableVO dataTableVO = new DataTableVO();
        dataTableVO.setCampaignId(campaign.getId());
        dataTableVO.setName("LeTable");
        dataTableVO.setDescription("This is a table");
        dataTableVO.setProvider(dataProvider.getCode());
        DataTable dataTable = coreTestsHelper.newDataTable(dataTableVO.getName(), dataTableVO.getDescription());
        when(this.campaignServices.findCampaignById(this.campaign.getId())).thenReturn(campaign);
        when(this.tableServices.newDataTable(dataTableVO, campaign)).thenReturn(dataTable);

        // @When creating a table
        this.transactionalTablesApplication.newDataTable(dataTableVO);

        // @The table is created with that name and under the given campaign
        verify(this.tableServices, times(1)).newDataTable(dataTableVO, campaign);
    }

    @Test
    public void testNewDataTableThrowsException_WhenNameAlreadyInUse() {
        // @Given an existing campaign with a table and a table name and description
        DataTableVO dataTableVO = new DataTableVO();
        dataTableVO.setCampaignId(campaign.getId());
        dataTableVO.setName("tableName");
        dataTableVO.setDescription("This is a table");
        dataTableVO.setProvider(dataProvider.getCode());
        DataTable dataTable = coreTestsHelper.newDataTable(dataTableVO.getName(), dataTableVO.getDescription());
        when(this.campaignServices.findCampaignById(this.campaign.getId())).thenReturn(campaign);
        campaign.setDataTables(Lists.<DataTable>newArrayList(coreTestsHelper.newDataTable(dataTableVO.getName(), "something witty")));
        when(this.tableServices.newDataTable(dataTableVO, campaign)).thenReturn(dataTable);

        // @When creating a table
        try {
            this.transactionalTablesApplication.newDataTable(dataTableVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.DATA_TABLE_NAME_ALREADY_IN_USE_FOR_THIS_CAMPAIGN);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testUpdateDataTableCallsDataTableServicesUpdatedDataTable_WhenUpdatingAdatatable() {
        // @Given an existing table
        DataTableVO dataTableVO = coreTestsHelper.newDataTableVO(1, "a new Name", "a new description");
        DataTable dataTable = coreTestsHelper.newDataTable(1, dataTableVO.getName(), "description", Lists.<DataColumn>newArrayList(), rowValuesServices);
        dataTable.setDescription(dataTableVO.getDescription());
        when(this.tableServices.findDataTableById(dataTableVO.getId())).thenReturn(dataTable);

        // @When updating the table
        this.transactionalTablesApplication.updateDataTable(dataTableVO);

        // @Then updateDataTable is called
        verify(this.tableServices, times(1)).updateDataTable(dataTable, dataTableVO);
    }

    @Test
    public void testRemoveDataTableCallsApplicationsRemoveDataTable_WhenRemovingExistingDataTable() {
        // @Given an existing data table
        DataTable dataTable = new DataTable();
        int tableId = 1;
        dataTable.setId(tableId);
        when(this.tableServices.removeDataTable(dataTable)).thenReturn(dataTable);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);

        // @When removing the data table
        this.transactionalTablesApplication.removeDataTable(tableId);

        // @The application removes the table an returns the removed table VO
        verify(this.tableServices, times(1)).removeDataTable(dataTable);
    }

    @Test
    public void testRemoveDataTableReturnsRemovedDataTable_WhenRemovingExistingDataTable() {
        // @Given an existing data table
        DataTable dataTable = new DataTable();
        int tableId = 1;
        dataTable.setId(tableId);
        when(this.tableServices.removeDataTable(dataTable)).thenReturn(dataTable);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);

        // @When removing the data table
        final DataTable returnedDataTable = this.transactionalTablesApplication.removeDataTable(tableId);

        // @The application removes the table an returns the removed table VO
        assertThat(returnedDataTable).isNotNull();
        assertThat(returnedDataTable.getId()).isEqualTo(tableId);
    }

    @Test
    public void testListProvidersReturnsThreeDataProviders_WhenThreeDataProvidersExist() {
        // @Given existing data providers
        DataProvider dataProvider1 = coreTestsHelper.newDataProvider("Code1", "Name 1");
        DataProvider dataProvider2 = coreTestsHelper.newDataProvider("Code2", "Name 2");
        DataProvider dataProvider3 = coreTestsHelper.newDataProvider("Code3", "Name 3");
        when(this.tableServices.listProviders()).thenReturn(Lists.newArrayList(dataProvider1, dataProvider2, dataProvider3));

        // @When listing the providers
        List<DataProvider> dataProviders = this.transactionalTablesApplication.listProviders();

        // @Then a list of VOs is returned
        assertThat(dataProviders).isNotNull();
        assertThat(dataProviders).isNotEmpty();
        assertThat(dataProviders).onProperty("code").containsExactly(dataProvider1.getCode(), dataProvider2.getCode(), dataProvider3.getCode());
        assertThat(dataProviders).onProperty("name").containsExactly(dataProvider1.getName(), dataProvider2.getName(), dataProvider3.getName());
    }

    @Test
    public void testUpdateMetadataCallsTableServicesUpdatedMetadataWithTwoColumnsIdOneAndNoId_WhenUpdatingColumnOneAndCreatingAnotherOne() {
        // @Given an existing data table with two columns
        int tableId = 1;
        List<DataColumnVO> dataColumnVOs = Lists.newArrayList(
                coreTestsHelper.newDataColumnVO(1, "updatedOne", coreTestsHelper.stringDataType().getCode(), "the column to be updated", 10, 9, 10, true, true, true, true),
                coreTestsHelper.newDataColumnVO("newOne", coreTestsHelper.stringDataType().getCode(), "the column to be created", 11, 12, 13, false, false, false, false),
                coreTestsHelper.newDataColumnVO("serviceCenter2", coreTestsHelper.serviceCenterDataType().getCode(), "the column to be updated", 10, 9, 10, true, true, true, true)
        );

        DataTable dataTable = coreTestsHelper.newDataTable(1, "tableName", "tableDescription",
                Lists.<DataColumn>newArrayList(
                        coreTestsHelper.newDataColumn(1, "toUpdate", dataTypeMap.get(dataColumnVOs.get(0).getType()), "differentDescription", dataColumnVOs.get(0).getSize(), dataColumnVOs.get(0).getMinSize(), dataColumnVOs.get(0).getPrecision(), dataColumnVOs.get(0).getRequired(), dataColumnVOs.get(0).getSortable(), dataColumnVOs.get(0).getEditable(), dataColumnVOs.get(0).getFilterable()),
                        coreTestsHelper.newDataColumn(2, "toRemove", dataTypeMap.get(coreTestsHelper.stringDataType().getCode()), "differentDescription", 1, 1, 1, false, true, true, false)
                ),
                rowValuesServices);

        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);

        // @When Updating the metadata by removing a column, updating another and adding a new one
        this.transactionalTablesApplication.updateMetadata(tableId, dataColumnVOs);

        // @Then tableServices.UpdateMetadata is called with those VOs
        verify(this.tableServices, times(1)).updateMetadata(dataTable, dataColumnVOs);

    }

    @Test
    public void testUpdateMetadataReturnsUpdatedMetadataAsVOs_WhenUpdatingAnExistingTableMetadata() {
        // @Given an existing data table with two columns
        int tableId = 1;
        List<DataColumnVO> dataColumnVOs = Lists.newArrayList(
                coreTestsHelper.newDataColumnVO(1, "updatedOne", coreTestsHelper.stringDataType().getCode(), "the column to be updated", 10, 9, 10, true, true, true, true),
                coreTestsHelper.newDataColumnVO("newOne", coreTestsHelper.serviceCenterDataType().getCode(), "the column to be created", 11, 12, 13, false, false, false, false)
        );
        List<DataColumn> dataColumns = Lists.newArrayList(
                coreTestsHelper.newDataColumn(1, dataColumnVOs.get(0).getName(), dataTypeMap.get(dataColumnVOs.get(0).getType()), dataColumnVOs.get(0).getDescription(), dataColumnVOs.get(0).getSize(), dataColumnVOs.get(0).getMinSize(), dataColumnVOs.get(0).getPrecision(), dataColumnVOs.get(0).getRequired(), dataColumnVOs.get(0).getSortable(), dataColumnVOs.get(0).getEditable(), dataColumnVOs.get(0).getFilterable()),
                coreTestsHelper.newDataColumn(3, dataColumnVOs.get(1).getName(), dataTypeMap.get(dataColumnVOs.get(1).getType()), dataColumnVOs.get(1).getDescription(), dataColumnVOs.get(1).getSize(), dataColumnVOs.get(1).getMinSize(), dataColumnVOs.get(1).getPrecision(), dataColumnVOs.get(1).getRequired(), dataColumnVOs.get(1).getSortable(), dataColumnVOs.get(1).getEditable(), dataColumnVOs.get(1).getFilterable())
        );
        DataTable dataTable = coreTestsHelper.newDataTable(1, "tableName", "tableDescription",
                Lists.<DataColumn>newArrayList(
                        coreTestsHelper.newDataColumn(1, "toUpdate", dataTypeMap.get(dataColumnVOs.get(0).getType()), "differentDescription", dataColumnVOs.get(0).getSize(), dataColumnVOs.get(0).getMinSize(), dataColumnVOs.get(0).getPrecision(), dataColumnVOs.get(0).getRequired(), dataColumnVOs.get(0).getSortable(), dataColumnVOs.get(0).getEditable(), dataColumnVOs.get(0).getFilterable()),
                        coreTestsHelper.newDataColumn(2, "toRemove", dataTypeMap.get(coreTestsHelper.stringDataType().getCode()), "differentDescription", 1, 1, 1, false, true, true, false)
                ),
                rowValuesServices);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);
        when(this.tableServices.updateMetadata(dataTable, dataColumnVOs)).thenReturn(dataColumns);

        // @When Updating the metadata by removing a column, updating another and adding a new one
        List<DataColumn> returnedDataColumns = this.transactionalTablesApplication.updateMetadata(tableId, dataColumnVOs);

        // @Then the metadata is now formed by the updates column and the new one
        assertThat(returnedDataColumns).isSameAs(dataColumns);
    }

    @Test
    public void testUpdateMetadataThrowsExceptionWhenTwoColumnsHaveTheSameName_WhenUpdatingAnExistingTableMetadata() {
        // @Given an existing data table
        int tableId = 1;
        List<DataColumnVO> dataColumnVOs = Lists.newArrayList(
                coreTestsHelper.newDataColumnVO(1, "Name", coreTestsHelper.stringDataType().getCode(), "the column to be updated", 10, 9, 10, true, true, true, true),
                coreTestsHelper.newDataColumnVO("Name", coreTestsHelper.stringDataType().getCode(), "the column to be created", 11, 12, 13, false, false, false, false)
        );
        DataTable dataTable = coreTestsHelper.newDataTable(1, "tableName", "tableDescription",
                Lists.<DataColumn>newArrayList(
                        coreTestsHelper.newDataColumn(1, "toUpdate", dataTypeMap.get(dataColumnVOs.get(0).getType()), "differentDescription", dataColumnVOs.get(0).getSize(), dataColumnVOs.get(0).getMinSize(), dataColumnVOs.get(0).getPrecision(), dataColumnVOs.get(0).getRequired(), dataColumnVOs.get(0).getSortable(), dataColumnVOs.get(0).getEditable(), dataColumnVOs.get(0).getFilterable()),
                        coreTestsHelper.newDataColumn(2, "toRemove", dataTypeMap.get(coreTestsHelper.stringDataType().getCode()), "differentDescription", 1, 1, 1, false, true, true, false)
                ),
                rowValuesServices);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);

        try {
            // @When Updating the metadata with two columns with the same name
            this.transactionalTablesApplication.updateMetadata(tableId, dataColumnVOs);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.COLUMN_NAMES_MUST_BE_UNIQUE);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testUpdateMetadataThrowsExceptionWhenAColumnNameHasSpaces_WhenUpdatingAnExistingTableMetadata() {
        // @Given an existing data table
        int tableId = 1;
        List<DataColumnVO> dataColumnVOs = Lists.newArrayList(
                coreTestsHelper.newDataColumnVO(1, "Na me", coreTestsHelper.stringDataType().getCode(), "the column to be updated", 10, 9, 10, true, true, true, true)
        );
        DataTable dataTable = coreTestsHelper.newDataTable(1, "tableName", "tableDescription",
                Lists.<DataColumn>newArrayList(
                        coreTestsHelper.newDataColumn(1, "toUpdate", dataTypeMap.get(dataColumnVOs.get(0).getType()), "differentDescription", dataColumnVOs.get(0).getSize(), dataColumnVOs.get(0).getMinSize(), dataColumnVOs.get(0).getPrecision(), dataColumnVOs.get(0).getRequired(), dataColumnVOs.get(0).getSortable(), dataColumnVOs.get(0).getEditable(), dataColumnVOs.get(0).getFilterable())
                ),
                rowValuesServices);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);

        try {
            // @When Updating the metadata with two columns with the same name
            this.transactionalTablesApplication.updateMetadata(tableId, dataColumnVOs);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.COLUMN_NAMES_CANNOT_HAVE_SPACES);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testUpdateMetadataThrowsExceptionWhenAColumnHasNoOptions_WhenColumnFlagSaysItHasOptions() {
        // @Given an existing data table
        int tableId = 1;

        List<DataColumnVO> dataColumnVOs = Lists.newArrayList(
                coreTestsHelper.newDataColumnVO(1, "serviceCenter1", coreTestsHelper.serviceCenterDataType().getCode(), "the column to be updated", 10, 9, 10, true, true, true, true),
                coreTestsHelper.newDataColumnVO(2, "Name2", coreTestsHelper.enumDataType().getCode(), "the column to be updated", 11, 10, 11, false, false, false, false)
        );
        DataTable dataTable = coreTestsHelper.newDataTable(1, "tableName", "tableDescription",
                Lists.<DataColumn>newArrayList(
                ),
                rowValuesServices);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);

        try {
            // @When Updating the metadata with two columns with the same name
            this.transactionalTablesApplication.updateMetadata(tableId, dataColumnVOs);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.OPTION_COLUMN_MUST_HAVE_OPTIONS);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testUpdateMetadataThrowsExceptionWhenThereIsMoreThanOneServiceCenterColumn_WhenUpdatingAnExistingTableMetadata() {
        // @Given an existing data table
        int tableId = 1;
        List<DataColumnVO> dataColumnVOs = Lists.newArrayList(
                coreTestsHelper.newDataColumnVO(1, "serviceCenter1", coreTestsHelper.serviceCenterDataType().getCode(), "the column to be updated", 10, 9, 10, true, true, true, true),
                coreTestsHelper.newDataColumnVO(2, "serviceCenter2", coreTestsHelper.serviceCenterDataType().getCode(), "the column to be updated", 10, 9, 10, true, true, true, true)
        );
        DataTable dataTable = coreTestsHelper.newDataTable(1, "tableName", "tableDescription",
                Lists.<DataColumn>newArrayList(
                        coreTestsHelper.newDataColumn(1, "serviceCenter1", dataTypeMap.get(dataColumnVOs.get(0).getType()), "differentDescription", dataColumnVOs.get(0).getSize(), dataColumnVOs.get(0).getMinSize(), dataColumnVOs.get(0).getPrecision(), dataColumnVOs.get(0).getRequired(), dataColumnVOs.get(0).getSortable(), dataColumnVOs.get(0).getEditable(), dataColumnVOs.get(0).getFilterable())
                ),
                rowValuesServices);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);

        try {
            // @When Updating the metadata with two columns with the same name
            this.transactionalTablesApplication.updateMetadata(tableId, dataColumnVOs);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.TABLE_MUST_HAVE_ONE_SERVICE_CENTER_COLUMN);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testUpdateMetadataThrowsExceptionWhenThereIsNoServiceCenterColumn_WhenUpdatingAnExistingTableMetadata() {
        // @Given an existing data table
        int tableId = 1;
        List<DataColumnVO> dataColumnVOs = Lists.newArrayList(
                coreTestsHelper.newDataColumnVO(1, "Name", coreTestsHelper.stringDataType().getCode(), "the column to be updated", 10, 9, 10, true, true, true, true)
        );
        DataTable dataTable = coreTestsHelper.newDataTable(1, "tableName", "tableDescription",
                Lists.<DataColumn>newArrayList(
                        coreTestsHelper.newDataColumn(1, "toUpdate", dataTypeMap.get(dataColumnVOs.get(0).getType()), "differentDescription", dataColumnVOs.get(0).getSize(), dataColumnVOs.get(0).getMinSize(), dataColumnVOs.get(0).getPrecision(), dataColumnVOs.get(0).getRequired(), dataColumnVOs.get(0).getSortable(), dataColumnVOs.get(0).getEditable(), dataColumnVOs.get(0).getFilterable()),
                        coreTestsHelper.newDataColumn(2, "toRemove", dataTypeMap.get(coreTestsHelper.stringDataType().getCode()), "differentDescription", 1, 1, 1, false, true, true, false)
                ),
                rowValuesServices);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);

        try {
            // @When Updating the metadata with two columns with the same name
            this.transactionalTablesApplication.updateMetadata(tableId, dataColumnVOs);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.TABLE_MUST_HAVE_ONE_SERVICE_CENTER_COLUMN);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testUpdateMetadataThrowsExceptionWhenThereIsMoreThanOnePointOfSaleColumn_WhenUpdatingAnExistingTableMetadata() {
        // @Given an existing data table
        int tableId = 1;
        List<DataColumnVO> dataColumnVOs = Lists.newArrayList(
                coreTestsHelper.newDataColumnVO(1, "pos1", coreTestsHelper.pointOfSaleDataType().getCode(), "the column to be updated", 10, 9, 10, true, true, true, true),
                coreTestsHelper.newDataColumnVO(2, "pos2", coreTestsHelper.pointOfSaleDataType().getCode(), "the column to be updated", 10, 9, 10, true, true, true, true),
                coreTestsHelper.newDataColumnVO(3, "serviceCenter1", coreTestsHelper.serviceCenterDataType().getCode(), "the column to be updated", 10, 9, 10, true, true, true, true)
        );
        DataTable dataTable = coreTestsHelper.newDataTable(1, "tableName", "tableDescription",
                Lists.<DataColumn>newArrayList(
                        coreTestsHelper.newDataColumn(1, "serviceCenter1", dataTypeMap.get(coreTestsHelper.serviceCenterDataType()), "differentDescription", dataColumnVOs.get(0).getSize(), dataColumnVOs.get(0).getMinSize(), dataColumnVOs.get(0).getPrecision(), dataColumnVOs.get(0).getRequired(), dataColumnVOs.get(0).getSortable(), dataColumnVOs.get(0).getEditable(), dataColumnVOs.get(0).getFilterable())
                ),
                rowValuesServices);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);

        try {
            // @When Updating the metadata with two columns with the same name
            this.transactionalTablesApplication.updateMetadata(tableId, dataColumnVOs);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.TABLE_MUST_HAVE_ONE_POINT_OF_SALE_COLUMN_AT_MOST);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testViewRowsPageCallsFindDataTableById_WhenAskingForFirstPageAndOnlyOneRowExists() {
        // @Given an existing data table
        DataTable dataTable = coreTestsHelper.newDataTable(2, "tableName", "tableDescription", Lists.<DataColumn>newArrayList(coreTestsHelper.newDataColumn("aColumn")), rowValuesServices);
        dataTable.setRowValuesServices(this.rowValuesServices);
        when(this.tableServices.findDataTableById(dataTable.getId())).thenReturn(dataTable);
        PageRequest pageRequest = new PageRequest(2, 25, new Sort(Sort.getDirection("asc"), "aColumn"));

        // @When seeing the first page of rows
        this.transactionalTablesApplication.findRowsByDataTableIdAndPage(dataTable.getId(), pageRequest, Maps.<String, Object>newHashMap());

        // @Then DataTableServices.findRowsByDataTableAndPage is called
        verify(this.tableServices, times(1)).findDataTableById(dataTable.getId());
    }

    @Test
    public void testViewRowsPageCallsADataTablesFindByPage_WhenAskingForFirstPageAndOnlyOneRowExists() {
        // @Given an existing data table
        DataTable dataTable = mock(DataTable.class);
        when(this.tableServices.findDataTableById(1)).thenReturn(dataTable);
        PageRequest pageRequest = new PageRequest(2, 25, new Sort(Sort.getDirection("asc"), "aColumn"));

        // @When seeing the first page of rows
        this.transactionalTablesApplication.findRowsByDataTableIdAndPage(1, pageRequest, Maps.<String, Object>newHashMap());

        // @Then DataTableServices.findRowsByDataTableAndPage is called
        verify(dataTable, times(1)).findRowsByPage(2, 25, "aColumn", "ASC", Maps.<String, Object>newHashMap());
    }

    @Test
    public void testViewRowsPageCallsADataTablesFindByPageWithFilter_WhenAskingForFirstPageOfFilteredSearch() {
        // @Given an existing data table
        DataTable dataTable = mock(DataTable.class);
        when(this.tableServices.findDataTableById(1)).thenReturn(dataTable);
        PageRequest pageRequest = new PageRequest(2, 25, new Sort(Sort.getDirection("asc"), "aColumn"));

        // @When seeing the first page of rows
        HashMap<String, Object> filter = Maps.newHashMap();
        filter.put("Column", "value");
        this.transactionalTablesApplication.findRowsByDataTableIdAndPage(1, pageRequest, filter);

        // @Then DataTableServices.findRowsByDataTableAndPage is called
        verify(dataTable, times(1)).findRowsByPage(2, 25, "aColumn", "ASC", filter);
    }

    @Test
    public void testUpdateRowCallsTableServiceFindTableByIdWithIdOne_WhenUpdatingRowOfDataTableIdOne() {
        // @Given row data with the Id of an existing row
        DataTable dataTable = coreTestsHelper.newDataTable(1, "tableName", "description", Lists.<DataColumn>newArrayList(), rowValuesServices);
        ServiceCenter sc = new ServiceCenter();
        sc.setCuit("1");
        when(this.tableServices.findDataTableById(dataTable.getId())).thenReturn(dataTable);
        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(DataRowVO.ROW_ID_KEY, "1");
        DataRow dataRow = mock(DataRow.class);
        when(this.rowValuesServices.findDataRowByDataTableAndDataRowId(dataTable, 1)).thenReturn(dataRow);
        when(dataRow.getServiceCenter()).thenReturn(sc);

        // @When updating the row
        this.transactionalTablesApplication.updateRow(dataTable.getId(), rowData);

        // @Then dataTable.updateRow is called
        verify(this.tableServices, times(1)).findDataTableById(dataTable.getId());
    }

    @Test
    public void testUpdateRowCallsTableServiceFindTableByIdWithIdTwo_WhenUpdatingRowOfDataTableIdTwo() {
        // @Given row data with the Id of an existing row
        DataTable dataTable = coreTestsHelper.newDataTable(2, "tableName", "description", Lists.<DataColumn>newArrayList(), rowValuesServices);
        ServiceCenter sc = new ServiceCenter();
        sc.setCuit("1");
        when(this.tableServices.findDataTableById(dataTable.getId())).thenReturn(dataTable);
        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(DataRowVO.ROW_ID_KEY, "1");
        DataRow dataRow = mock(DataRow.class);
        when(this.rowValuesServices.findDataRowByDataTableAndDataRowId(dataTable, 1)).thenReturn(dataRow);
        when(dataRow.getServiceCenter()).thenReturn(sc);

        // @When updating the row
        this.transactionalTablesApplication.updateRow(dataTable.getId(), rowData);

        // @Then dataTable.updateRow is called
        verify(this.tableServices, times(1)).findDataTableById(dataTable.getId());
    }

    @Test
    public void testUpdateRowCallsDataTableFindRowByIdWithIdOne_WhenUpdatingRowWithIdOne() {
        // @Given row data with the Id of an existing row
        DataTable dataTable = mock(DataTable.class);
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        dataTable.setDataRowPersistorFactory(dataRowPersistorFactory);
        ServiceCenter sc = new ServiceCenter();
        sc.setCuit("1");
        when(dataTable.getId()).thenReturn(1);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);

        when(this.tableServices.findDataTableById(dataTable.getId())).thenReturn(dataTable);
        when(dataRowPersistor.getServiceCenter(Matchers.<DataTable>any())).thenReturn(sc);

        when(dataTable.getDataRowPersistor()).thenReturn(dataRowPersistor);
        DataRow dataRow = new DataRow(dataTable, new Object());
        when(dataTable.updateRow(Matchers.<Map<String, Object>>any())).thenReturn(dataRow);

        int rowId = 1;
        when(dataTable.findRowById(rowId)).thenReturn(dataRow);

        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(DataRowVO.ROW_ID_KEY, String.valueOf(rowId));

        // @When updating the row
        this.transactionalTablesApplication.updateRow(dataTable.getId(), rowData);

        // @Then dataTable.updateRow is called
        verify(dataTable, times(1)).updateRow(rowData);
    }

    @Test
    public void testCreateRowsReturnsOneRowForEachDataSet_WhenCreatingThreeRows() {
        // @Given new row data
        DataTable dataTable = coreTestsHelper.newDataTable(1, "tableName", "description", Lists.<DataColumn>newArrayList(), rowValuesServices);
        when(this.tableServices.findDataTableById(dataTable.getId())).thenReturn(dataTable);
        Map<String, Object> rowData1 = Maps.newHashMap();
        Map<String, Object> rowData2 = Maps.newHashMap();
        Map<String, Object> rowData3 = Maps.newHashMap();
        Map[] rowDatas = {rowData1, rowData2, rowData3};

        // @When creating the row
        List<DataRow> rows = this.transactionalTablesApplication.createRows(dataTable.getId(), rowDatas);

        // @Then tableServices.findDataTableById is called with Id 1
        assertThat(rows).hasSize(3);
    }

    @Test
    public void testCreateRowCallsTableServiceFindTableByIdWithIdOne_WhenCreatingRowOfDataTableIdOne() {
        // @Given new row data
        DataTable dataTable = coreTestsHelper.newDataTable(1, "tableName", "description", Lists.<DataColumn>newArrayList(), rowValuesServices);
        when(this.tableServices.findDataTableById(dataTable.getId())).thenReturn(dataTable);
        Map<String, Object> rowData = Maps.newHashMap();

        // @When creating the row
        this.transactionalTablesApplication.createRow(dataTable.getId(), rowData);

        // @Then tableServices.findDataTableById is called with Id 1
        verify(this.tableServices, times(1)).findDataTableById(dataTable.getId());
    }

    @Test
    public void testCreateRowCallsTableServiceFindTableByIdWithIdTwo_WhenCreatingRowOfDataTableIdTwo() {
        // @Given new row data
        DataTable dataTable = coreTestsHelper.newDataTable(2, "tableName", "description", Lists.<DataColumn>newArrayList(), rowValuesServices);
        when(this.tableServices.findDataTableById(dataTable.getId())).thenReturn(dataTable);
        Map<String, Object> rowData = Maps.newHashMap();

        // @When creating the row
        this.transactionalTablesApplication.createRow(dataTable.getId(), rowData);

        // @Then tableServices.findDatatableById is called  with id 2
        verify(this.tableServices, times(1)).findDataTableById(dataTable.getId());
    }

    @Test
    public void testCreateRowCallsDataTableNewRow_WhenCreatingRowDataOfAnExistingRow() {
        // @Given new row data
        DataTable dataTable = mock(DataTable.class);
        DataRow dataRow = mock(DataRow.class);
        when(dataTable.getId()).thenReturn(10);
        when(this.tableServices.findDataTableById(dataTable.getId())).thenReturn(dataTable);
        Map<String, Object> rowData = Maps.newHashMap();
        when(dataTable.newRow(rowData)).thenReturn(dataRow);

        // @When updating the row
        this.transactionalTablesApplication.createRow(dataTable.getId(), rowData);

        // @Then dataTable.newRow is called
        verify(dataTable, times(1)).newRow(rowData);
    }

    @Test
    public void testDeleteRowCallsTableServicesFindDataTableByIdIdTen_WhenDeletingRowOneInTableTen() {
        // @Given a tableId 10
        int tableId = 10;
        DataTable dataTable = mock(DataTable.class);
        when(dataTable.getId()).thenReturn(tableId);
        DataRow dataRow = mock(DataRow.class);
        when(this.tableServices.findDataTableById(dataTable.getId())).thenReturn(dataTable);
        when(dataTable.findRowById(1)).thenReturn(dataRow);

        // @When deleting row with Id 1
        this.transactionalTablesApplication.deleteRows(tableId, Lists.<Integer>newArrayList(1));

        // @Then tableServices.findDataTableById is called with dataRow 1
        verify(this.tableServices, times(1)).findDataTableById(tableId);
    }

    @Test
    public void testDeleteRowCallsDataTableWithIdOneFindDataRowByIdWithIdTen_WhenDeletingRowTenInTableOne() {
        // @Given an existent data table with id 1
        DataTable dataTable = mock(DataTable.class);
        DataRow dataRow = mock(DataRow.class);
        Integer rowId = 10;
        List<Integer> rowIds = Lists.newArrayList(rowId);
        when(dataRow.getInternalId()).thenReturn(rowId);
        when(dataRow.getDataTable()).thenReturn(dataTable);
        when(dataTable.getId()).thenReturn(1);
        when(this.tableServices.findDataTableById(dataTable.getId())).thenReturn(dataTable);
        when(dataTable.findRowById(rowId)).thenReturn(dataRow);

        // @When deleting row with Id 10
        this.transactionalTablesApplication.deleteRows(1, rowIds);

        // @Then dataTable.findRowById is called with dataRow 10
        verify(dataTable, times(1)).findRowById(rowId);
    }

    @Test
    public void testDeleteRowCallsDataTableWithIdOneRemoveWithDataRowWithIdOne_WhenDeletingRowOneInTableOne() {
        // @Given an existent data table with id 1
        DataTable dataTable = mock(DataTable.class);
        DataRow dataRow = mock(DataRow.class);
        when(dataRow.getInternalId()).thenReturn(1);
        when(dataRow.getDataTable()).thenReturn(dataTable);
        when(dataTable.getId()).thenReturn(1);
        when(this.tableServices.findDataTableById(dataTable.getId())).thenReturn(dataTable);
        when(dataTable.findRowById(1)).thenReturn(dataRow);

        // @When deleting row with Id 1
        this.transactionalTablesApplication.deleteRows(1, Lists.<Integer>newArrayList(1));

        // @Then dataTable.remove is called with dataRow 1
        verify(dataTable, times(1)).remove(dataRow);
    }

    @Test
    public void testTablesFindByDataTableWithFilter_WhenAskingForFilteredSearch() {
        // @Given an existing data table
        DataTable dataTable = mock(DataTable.class);
        when(this.tableServices.findDataTableById(1)).thenReturn(dataTable);
        Sort sort = new Sort(Sort.getDirection("asc"), "aColumn");

        // @When seeing the first page of rows
        HashMap<String, Object> filter = Maps.newHashMap();
        filter.put("Column", "value");
        this.transactionalTablesApplication.findRowsByDataTable(dataTable, sort, filter);

        // @Then DataTable.findRows is called
        verify(dataTable, times(1)).findRows("aColumn", "ASC", filter);
    }

    @Test
    public void testFindRowDataFileCallsTableServicesFindDataTableById1_WhenFindingDataFileOfARowInTable1() {
        // @Given a tableId
        int tableId = 1;
        DataTable dataTable = mock(DataTable.class);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);
        DataRow dataRow = mock(DataRow.class);
        when(dataTable.findRowById(1)).thenReturn(dataRow);

        // @When finding the data file of a row in that tableId
        this.transactionalTablesApplication.findRowDataFile(tableId, 1);

        // @Then tableServices.findDataTableById is called
        verify(this.tableServices, times(1)).findDataTableById(tableId);
    }

    @Test
    public void testFindRowDataFileCallsTableServicesFindDataTableById2_WhenFindingDataFileOfARowInTable2() {
        // @Given a tableId
        int tableId = 2;
        DataTable dataTable = mock(DataTable.class);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);
        DataRow dataRow = mock(DataRow.class);
        when(dataTable.findRowById(1)).thenReturn(dataRow);

        // @When finding the data file of a row in that tableId
        this.transactionalTablesApplication.findRowDataFile(tableId, 1);

        // @Then tableServices.findDataTableById is called
        verify(this.tableServices, times(1)).findDataTableById(tableId);
    }

    @Test
    public void testFindRowDataFileCallsDataTableFindRowById1_WhenFindingDataFileOfARow1InTable1() {
        // @Given a tableId
        int tableId = 1;
        int rowId = 1;
        DataTable dataTable = mock(DataTable.class);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);
        DataRow dataRow = mock(DataRow.class);
        when(dataTable.findRowById(rowId)).thenReturn(dataRow);

        // @When finding the data file of a row in that tableId
        this.transactionalTablesApplication.findRowDataFile(tableId, rowId);

        // @Then tableServices.findDataTableById is called
        verify(dataTable, times(1)).findRowById(rowId);
    }

    @Test
    public void testFindRowDataFileCallsDataTableFindRowById5_WhenFindingDataFileOfARow5InTable9() {
        // @Given a tableId
        int tableId = 9;
        int rowId = 5;
        DataTable dataTable = mock(DataTable.class);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);
        DataRow dataRow = mock(DataRow.class);
        when(dataTable.findRowById(rowId)).thenReturn(dataRow);

        // @When finding the data file of a row in that tableId
        this.transactionalTablesApplication.findRowDataFile(tableId, rowId);

        // @Then tableServices.findDataTableById is called
        verify(dataTable, times(1)).findRowById(rowId);
    }

    @Test
    public void testFindRowDataFileReturnsFoundRowDataFile_WhenFindingDataFileOfARowInTable() {
        // @Given a tableId
        int tableId = 1;
        int rowId = 1;
        DataTable dataTable = mock(DataTable.class);
        when(this.tableServices.findDataTableById(tableId)).thenReturn(dataTable);
        DataRow dataRow = mock(DataRow.class);
        when(dataTable.findRowById(rowId)).thenReturn(dataRow);

        // @When finding the data file of a row in that tableId
        DataFile dataFile = this.transactionalTablesApplication.findRowDataFile(tableId, rowId);

        // @Then tableServices.findDataTableById is called
        verify(dataRow, times(1)).getDataFile();
        assertThat(dataFile).isSameAs(dataRow.getDataFile());
    }

    @Test
    public void testRemoveAllRowsInDataTableIsCalled_WhenDeletingAllRows() {
        // @Given an existent data table with id 1
        DataTable dataTable = mock(DataTable.class);
        DataRow dataRow = mock(DataRow.class);
        when(dataRow.getInternalId()).thenReturn(1);
        when(dataRow.getDataTable()).thenReturn(dataTable);
        when(dataTable.getId()).thenReturn(1);
        when(this.tableServices.findDataTableById(dataTable.getId())).thenReturn(dataTable);
        when(dataTable.findRowById(1)).thenReturn(dataRow);

        // @When deleting all rows of the table
        this.transactionalTablesApplication.deleteAllRows(dataTable.getId());

        // @Then dataTable.removeAllRows is called
        verify(dataTable, times(1)).removeAllRows();
    }
}
