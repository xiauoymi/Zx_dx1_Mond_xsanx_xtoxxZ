package com.monsanto.metricspos.core.application.adapters;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.externaldata.*;
import com.monsanto.metricspos.persistence.DataRowPersistor;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class DataTableTableAdapter_UT {

    private DataTable mockDataTable;
    private DataTableTableAdapter dataTableTableAdapterWithMockTable;
    private DataTable dataTable;
    private DataTableTableAdapter dataTableTableAdapterWithActualDataTable;
    private DataRowPersistor dataRowPersistor;

    @Before
    public void setUp() {
        this.mockDataTable = mock(DataTable.class);
        this.dataTableTableAdapterWithMockTable = new DataTableTableAdapter(this.mockDataTable);

        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        this.dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        this.dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        this.dataTable.setDataProvider(new DataProvider());
        this.dataTableTableAdapterWithActualDataTable = new DataTableTableAdapter(this.dataTable);
        this.dataTable.setLoadSql("Load SQL");
        this.dataTable.setLoadScript("Load Script");
    }

    @Test
    public void testGetProviderCallsDataTableGetProvider_WhenGettingTheProvider() {
        // @Given a dataTable with a provider an it's adapter


        // @When getting the provider of the adapter
        this.dataTableTableAdapterWithMockTable.getProvider();

        // @Then the provider of the table is returned
        verify(this.mockDataTable, times(1)).getDataProvider();
    }

    @Test
    public void testGetProviderReturnsDataTableGetProvider_WhenGettingTheProvider() {
        // @Given a dataTable with a provider an it's adapter


        // @When getting the provider of the adapter
        DataProvider provider = this.dataTableTableAdapterWithActualDataTable.getProvider();

        // @Then the provider of the table is returned
        assertThat(provider).isEqualTo(this.dataTable.getDataProvider());
    }

    @Test
    public void testGetLoadSqlCallsDataTableGetLoadSql_WhenGettingTheLoadSql() {
        // @Given a dataTable with a provider an it's adapter


        // @When getting the provider of the adapter
        this.dataTableTableAdapterWithMockTable.getLoadSql();

        // @Then the provider of the table is returned
        verify(this.mockDataTable, times(1)).getLoadSql();
    }

    @Test
    public void testGetLoadSqlReturnsDataTableGetLoadSql_WhenGettingTheLoadSql() {
        // @Given a dataTable with a load sql an it's adapter


        // @When getting the load sql of the adapter
        String sql = this.dataTableTableAdapterWithActualDataTable.getLoadSql();

        // @Then the load sql of the table is returned
        assertThat(sql).isEqualTo(this.dataTable.getLoadSql());
    }

    @Test
    public void testGetLoadScriptCallsDataTableGetLoadScript_WhenGettingTheLoadScript() {
        // @Given a dataTable with a provider an it's adapter


        // @When getting the provider of the adapter
        this.dataTableTableAdapterWithMockTable.getLoadScript();

        // @Then the provider of the table is returned
        verify(this.mockDataTable, times(1)).getLoadScript();
    }

    @Test
    public void testGetLoadScriptReturnsDataTableGetLoadScript_WhenGettingTheLoadScript() {
        // @Given a dataTable with a load script an it's adapter


        // @When getting the load script of the adapter
        String script = this.dataTableTableAdapterWithActualDataTable.getLoadScript();

        // @Then the load script of the table is returned
        assertThat(script).isEqualTo(this.dataTable.getLoadScript());
    }

    @Test
    public void testMarkAllRecordsAsNotLoadedCallsDataTableMarkAllRecordsAsNotLoaded_WhenMarkingRecordsAsNotLoaded() {
        // @Given a dataTable with a provider an it's adapter

        // @When marking all the records as not loaded
        this.dataTableTableAdapterWithMockTable.markAllRecordsAsNotLoaded();

        // @Then dataTable.markAllRecordsAsNotLoaded is called
        verify(this.mockDataTable, times(1)).markAllRecordsAsNotLoaded();
    }

    @Test
    public void testSaveOrUpdateCallsDataTableSaveOrUpdateWithDataRow_WhenSavingOrUpdatingADataRow() {
        // @Given a data row
        DataRow dataRow = new DataRow(this.mockDataTable, new Object());

        // @When saving or updating it
        this.dataTableTableAdapterWithMockTable.saveOrUpdate(dataRow);

        // @Then dataTable save or update is called with that row
        verify(this.mockDataTable, times(1)).saveOrUpdateRow(dataRow);
    }

    @Test
    public void testSaveOrUpdateThrowsException_WhenSavingOrUpdatingADataRowThatHasARequiredColumnThatIsNotSet() {
        // @Given a data row
        Object rowValues = new Object();
        DataRow dataRow = new DataRow(this.dataTable, rowValues);
        DataColumn columnRequired = new DataColumn("requiredColumn", stringDataType());
        columnRequired.setRequired(true);
        this.dataTable.setColumns(Lists.<DataColumn>newArrayList(columnRequired));
        when(this.dataRowPersistor.get(rowValues, "requiredColumn")).thenReturn(null);

        // @When saving or updating it
        try {
            this.dataTableTableAdapterWithActualDataTable.saveOrUpdate(dataRow);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.REQUIRED_COLUMN_CANNOT_BE_EMPTY);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testSaveOrUpdateThrowsException_WhenSavingOrUpdatingADataRowThatIsEnumAndOptionDoesNotMatch() {
        // @Given a data row
        Object rowValues = new Object();
        DataRow dataRow = new DataRow(this.dataTable, rowValues);
        DataColumn columnOption = new DataColumn("enumColumn", enumDataType());
        columnOption.setOptions(Lists.<String>newArrayList("Hola", "Chau"));

        this.dataTable.setColumns(Lists.<DataColumn>newArrayList(columnOption));
        when(this.dataRowPersistor.get(rowValues, "enumColumn")).thenReturn("Si");

        // @When saving or updating it
        try {
            this.dataTableTableAdapterWithActualDataTable.saveOrUpdate(dataRow);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ENUM_COLUMN_VALUE_MUST_MATCH_OPTIONS);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testMarkAsLoadedCallsDataTableSetLoadedWithTrue_WhenMarkingRowAsLoaded() {
        // @Given a row
        Object rowValues = new Object();
        DataRow dataRow = new DataRow(this.dataTable, rowValues);

        // @When marking it as loaded
        this.dataTableTableAdapterWithActualDataTable.markAsLoaded(dataRow);

        // @Then dataTable's dataRowPersistor mark as loaded is called
        verify(this.dataTable.getDataRowPersistor(), times(1)).setLoaded(rowValues, true);
    }

    @Test
    public void testMarkAsLoadedCallsDataTableSetLoadedWithTrue_WhenMarkingRowAsLoadedWithTrue() {
        // @Given a row
        Object rowValues = new Object();
        DataRow dataRow = new DataRow(this.dataTable, rowValues);

        // @When marking it as loaded
        this.dataTableTableAdapterWithActualDataTable.markAsLoaded(dataRow, true);

        // @Then dataTable's dataRowPersistor mark as loaded is called
        verify(this.dataTable.getDataRowPersistor(), times(1)).setLoaded(rowValues, true);
    }

    @Test
    public void testMarkAsLoadedCallsDataTableSetLoadedWithFalse_WhenMarkingRowAsLoadedWithFalse() {
        // @Given a row
        Object rowValues = new Object();
        DataRow dataRow = new DataRow(this.dataTable, rowValues);

        // @When marking it as not loaded
        this.dataTableTableAdapterWithActualDataTable.markAsLoaded(dataRow, false);

        // @Then dataTable's dataRowPersistor mark as loaded is called
        verify(this.dataTable.getDataRowPersistor(), times(1)).setLoaded(rowValues, false);
    }

    @Test
    public void testRemoveAllUnloadedRecordsCallsDataTableRemoveAllNotLoadedRecord_WhenRemovingAllUnloadedRecords() {
        // @Given a dataTable with a provider an it's adapter

        // @When removing all unloaded records
        this.dataTableTableAdapterWithMockTable.removeAllUnloadedRecords();

        // @Then dataTable.removeAllNotLoadedRecord is called
        verify(this.mockDataTable, times(1)).removeAllNotLoadedRecords();
    }

    @Test
    public void testGetEmptyRecordReturnsANewDataRowWithTheTable_WhenGettingAnEmptyRecord() {
        // @Given a dataTable with a provider an it's adapter

        // @When getting an empty record
        DataRow emptyRecord = this.dataTableTableAdapterWithActualDataTable.getEmptyRecord();

        // @Then a new data row with the data table is returned
        assertThat(emptyRecord.getDataTable()).isSameAs(this.dataTable);
    }

    @Test
    public void testGetEmptyRecordCallsTheTablePersistorMakeNewValueWithAnEmptyMap_WhenGettingAnEmptyRecord() {
        // @Given a dataTable with a provider an it's adapter

        // @When getting an empty record
        this.dataTableTableAdapterWithActualDataTable.getEmptyRecord();

        // @Then a new data row with the data table is returned
        verify(this.dataTable.getDataRowPersistor(), times(1)).makeRowValues(Maps.<String, Object>newHashMap());
    }

    private DataType stringDataType() {
        DataType dataType = new DataType();
        dataType.setCode("string");
        dataType.setInternalType(String.class);
        dataType.setName("string");
        return dataType;
    }

    private DataType enumDataType() {
        DataType dataType = new DataType();
        dataType.setCode("enum");
        dataType.setInternalType(String.class);
        dataType.setHasOptions(true);
        dataType.setName("enum");
        return dataType;
    }
}
