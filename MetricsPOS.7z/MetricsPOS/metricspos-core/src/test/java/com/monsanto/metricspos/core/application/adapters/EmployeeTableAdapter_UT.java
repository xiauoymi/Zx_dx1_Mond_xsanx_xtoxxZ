package com.monsanto.metricspos.core.application.adapters;

import com.monsanto.metricspos.core.EmployeeServices;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.Employee;
import org.junit.Before;
import org.junit.Test;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class EmployeeTableAdapter_UT {
    private EmployeeTableAdapter employeeTableAdapter;
    private Campaign campaign;
    private DataProvider dataProvider;
    private EmployeeServices employeeServices;

    @Before
    public void setUp() throws Exception {
        this.dataProvider = new DataProvider();
        this.campaign = new Campaign("CampaignName", newDate(2011, 1, 1), newDate(2012, 2, 2));
        this.employeeTableAdapter = new EmployeeTableAdapter(campaign, dataProvider);
        this.employeeServices = mock(EmployeeServices.class);
        field("employeeServices").ofType(EmployeeServices.class).in(this.employeeTableAdapter).set(this.employeeServices);
    }

    @Test
    public void testGetLoadScriptCallsCampaignGetEmployeeLoadScript_WhenLoadingAScript() {
        // @Given an existing campaign and its service center table adapter
        this.dataProvider = new DataProvider();
        this.campaign = mock(Campaign.class);
        this.employeeTableAdapter = new EmployeeTableAdapter(campaign, dataProvider);

        // @When loading the script
        this.employeeTableAdapter.getLoadScript();

        // @Then the campaign is asked for it's load script
        verify(this.campaign, times(1)).getEmployeeLoadScript();
    }

    @Test
    public void testGetLoadScriptReturnsCampaignGetEmployeeLoadScript_WhenLoadingAScript() {
        // @Given an existing campaign and its service center table adapter
        this.campaign.setEmployeeLoadScript("SCRIPT");

        // @When loading the script
        String loadScript = this.employeeTableAdapter.getLoadScript();

        // @Then the campaign is asked for it's load script
        assertThat(loadScript).isEqualTo(this.campaign.getEmployeeLoadScript());
    }

    @Test
    public void testGetLoadSqlCallsCampaignGetEmployeeLoadSql_WhenLoadingTheSql() {
        // @Given an existing campaign and its service center table adapter
        this.dataProvider = new DataProvider();
        this.campaign = mock(Campaign.class);
        this.employeeTableAdapter = new EmployeeTableAdapter(campaign, dataProvider);

        // @When loading the script
        this.employeeTableAdapter.getLoadSql();

        // @Then the campaign is asked for it's load script
        verify(this.campaign, times(1)).getEmployeeLoadSql();
    }

    @Test
    public void testGetLoadSqlReturnsCampaignGetEmployeeLoadSql_WhenLoadingSql() {
        // @Given an existing campaign and its service center table adapter
        this.campaign.setEmployeeLoadSql("Sql");

        // @When loading the script
        String loadSql = this.employeeTableAdapter.getLoadSql();

        // @Then the campaign is asked for it's load script
        assertThat(loadSql).isEqualTo(this.campaign.getEmployeeLoadSql());
    }

    @Test
    public void testMarkAllRecordsAsNoLoadedCallsEmployeeServicesMarkAsNotLoaded_WhenMarkingAsNotLoaded() {
        // @Given a service center table adapter with a service center services and a campaign configured

        // @When marking service centers as not loaded
        this.employeeTableAdapter.markAllRecordsAsNotLoaded();

        // @Then employeeServices markAsNotLoaded is called for the configured campaign
        verify(this.employeeServices, times(1)).markAllEmployeesAsNotLoadedInCampaign(this.campaign);
    }

    @Test
    public void testSaveOrUpdateCallsServicesSaveOrUpdate_WhenSavingOrUpdatingAEmployee() {
        // @Given a service center
        Employee employee = new Employee();
        employee.setCampaign(this.campaign);

        // @When saving or updating it
        this.employeeTableAdapter.saveOrUpdate(employee);

        // @Then services.saveOrUpdate is called for that service center
        verify(this.employeeServices, times(1)).saveOrUpdate(employee);
    }

    @Test
    public void testSaveOrUpdateSetsTheCampaignToTheEmployee_WhenTheEmployeeHasNoCampaign() {
        // @Given a service center
        Employee employee = mock(Employee.class);

        // @When saving or updating it
        this.employeeTableAdapter.saveOrUpdate(employee);

        // @Then services.saveOrUpdate is called for that service center
        verify(employee, times(1)).setCampaign(this.campaign);
    }

    @Test
    public void testMarkAsLoadedCallsSetLoadedWithTrue_WhenMarkingAEmployeeAsLoaded() throws Exception {
        // @Given a service center
        Employee employee = mock(Employee.class);

        // @When marking it as loaded
        this.employeeTableAdapter.markAsLoaded(employee);

        // @Then the service center's setLoaded(true) is called
        verify(employee, times(1)).setLoaded(true);
    }

    @Test
    public void testMarkAsLoadedWithTrueCallsSetLoadedWithTrue_WhenMarkingAEmployeeAsLoadedTrue() throws Exception {
        // @Given a service center
        Employee employee = mock(Employee.class);

        // @When marking it as loaded
        this.employeeTableAdapter.markAsLoaded(employee, true);

        // @Then the service center's setLoaded(true) is called
        verify(employee, times(1)).setLoaded(true);
    }

    @Test
    public void testMarkAsLoadedWithFalseCallsSetLoadedWithFalse_WhenMarkingAEmployeeAsLoadedFalse() throws Exception {
        // @Given a service center
        Employee employee = mock(Employee.class);

        // @When marking it as loaded
        this.employeeTableAdapter.markAsLoaded(employee, false);

        // @Then the service center's setLoaded(true) is called
        verify(employee, times(1)).setLoaded(false);
    }

    @Test
    public void testRemoveAllUnloadedRecordsCallsServicesRemoveAllUnloadedRecordsWithCampaignParameter_WhenRemovingAllUnloadedRecords() throws Exception {
        // @Given a employeeTableAdapter with a campaign

        // @When removing all unloaded records
        this.employeeTableAdapter.removeAllUnloadedRecords();

        // @employeeServices removeAllUnloadedRecords is called}
        verify(this.employeeServices, times(1)).removeAllNotLoadedEmployees(this.campaign);
    }

    @Test
    public void testGetEmptyRecordReturnsAEmployeeLoadedWithTheCampaignOfAdapter_WhenTheAdapterHasACampaign() {
        // @Given a employeeTableAdapter with a campaign

        // @When removing all unloaded records
        Employee emptyRecord = this.employeeTableAdapter.getEmptyRecord();

        // @employeeServices removeAllUnloadedRecords is called}
        assertThat(emptyRecord.getCampaign()).isNotNull();
        assertThat(emptyRecord.getCampaign()).isEqualTo(this.campaign);
    }

}
