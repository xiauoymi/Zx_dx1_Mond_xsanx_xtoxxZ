package com.monsanto.metricspos.core.application.adapters;

import com.monsanto.metricspos.core.PointOfSaleServices;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.PointOfSale;
import org.junit.Before;
import org.junit.Test;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class PointOfSaleTableAdapter_UT {
    private DataProvider dataProvider;
    private Campaign campaign;
    private PointOfSaleTableAdapter pointOfSaleTableAdapter;
    private PointOfSaleServices pointOfSaleServices;

    @Before
    public void setUp() {
        PointOfSaleTableAdapter pointOfSaleTableAdapter_ = new PointOfSaleTableAdapter();
        pointOfSaleTableAdapter_.setPointOfSaleServices(mock(PointOfSaleServices.class));
        pointOfSaleTableAdapter_.getProvider();
        this.dataProvider = new DataProvider();
        this.campaign = new Campaign("CampaignName", newDate(2011, 1, 1), newDate(2012, 2, 2));
        this.pointOfSaleTableAdapter = new PointOfSaleTableAdapter(campaign, dataProvider);
        this.pointOfSaleServices = mock(PointOfSaleServices.class);
        field("pointOfSaleServices").ofType(PointOfSaleServices.class).in(this.pointOfSaleTableAdapter).set(this.pointOfSaleServices);
    }

    @Test
    public void testGetLoadScriptCallsCampaignGetPointsOfSaleLoadScript_WhenGettingLoadScript() {
        // @Given a pointOfSale adapter with its campaign configured
        this.campaign = mock(Campaign.class);
        this.pointOfSaleTableAdapter = new PointOfSaleTableAdapter(this.campaign, this.dataProvider);

        // @When getting the adapter's load script
        this.pointOfSaleTableAdapter.getLoadScript();

        // @Then Campaign getLoadScript is called
        verify(this.campaign, times(1)).getPointOfSaleLoadScript();
    }

    @Test
    public void testGetLoadScriptReturnsCampaignGetPointsOfSaleLoadScript_WhenGettingLoadScript() {
        // @Given a pointOfSale adapter with its campaign configured and a load script
        this.campaign.setPointOfSaleLoadScript("return output;");

        // @When getting the adapter's load script
        String loadScript = this.pointOfSaleTableAdapter.getLoadScript();

        // @Then Campaign getLoadScript is called
        assertThat(loadScript).isSameAs(this.campaign.getPointOfSaleLoadScript());
    }

    @Test
    public void testGetLoadSqlCallsCampaignGetPointsOfSaleLoadSql_WhenGettingLoadSql() {
        // @Given a pointOfSale adapter with its campaign configured
        this.campaign = mock(Campaign.class);
        this.pointOfSaleTableAdapter = new PointOfSaleTableAdapter(this.campaign, this.dataProvider);

        // @When getting the adapter's load sql
        this.pointOfSaleTableAdapter.getLoadSql();

        // @Then Campaign getLoadSql is called
        verify(this.campaign, times(1)).getPointOfSaleLoadSql();
    }

    @Test
    public void testGetLoadSqlReturnsCampaignGetPointsOfSaleLoadSql_WhenGettingLoadSql() {
        // @Given a pointOfSale adapter with its campaign configured and a load script
        this.campaign.setPointOfSaleLoadSql("return output;");

        // @When getting the adapter's load script
        String loadSql = this.pointOfSaleTableAdapter.getLoadSql();

        // @Then Campaign getLoadSql is called
        assertThat(loadSql).isSameAs(this.campaign.getPointOfSaleLoadSql());
    }

    @Test
    public void testMarkAllRecordsAsNotLoadedCallsPointOfSaleServicesMarkPointOfSalesAsNotLoadedForCampaign_WhenMarkingAllAsNotLoadedForAdapter() {
        // @Given a pointOfSale adapter

        // @When marking all its record as not loaded
        this.pointOfSaleTableAdapter.markAllRecordsAsNotLoaded();

        // @Then the pointOfSaleService.markPointsOfSalesAsNotLoadedForCampaign is called for the adapters campaign
        verify(this.pointOfSaleServices, times(1)).markPointsOfSalesAsNotLoadedForCampaign(campaign);
    }

    @Test
    public void testMarkAllRecordsAsNotLoadedReturns15_WhenMarkingAllAsNotLoadedForAdapterReturns15() {
        // @Given a pointOfSale adapter
        when(this.pointOfSaleServices.markPointsOfSalesAsNotLoadedForCampaign(this.campaign)).thenReturn(15l);

        // @When marking all its record as not loaded
        long result = this.pointOfSaleTableAdapter.markAllRecordsAsNotLoaded();

        // @Then the pointOfSaleService.markPointsOfSalesAsNotLoadedForCampaign is called for the adapters campaign
        assertThat(result).isEqualTo(this.pointOfSaleServices.markPointsOfSalesAsNotLoadedForCampaign(campaign));
    }

    @Test
    public void testMarkAllRecordsAsNotLoadedReturns59_WhenMarkingAllAsNotLoadedForAdapterReturns59() {
        // @Given a pointOfSale adapter
        when(this.pointOfSaleServices.markPointsOfSalesAsNotLoadedForCampaign(this.campaign)).thenReturn(59l);

        // @When marking all its record as not loaded
        long result = this.pointOfSaleTableAdapter.markAllRecordsAsNotLoaded();

        // @Then the pointOfSaleService.markPointsOfSalesAsNotLoadedForCampaign is called for the adapters campaign
        assertThat(result).isEqualTo(this.pointOfSaleServices.markPointsOfSalesAsNotLoadedForCampaign(campaign));
    }

    @Test
    public void testSaveOrUpdate() {
        // @Given a Point of sale to save or update
        PointOfSale pointOfSale = new PointOfSale();

        // @When saving or updating it
        this.pointOfSaleTableAdapter.saveOrUpdate(pointOfSale);

        // @Then point of sale services.saveOrUpdate is called
        verify(this.pointOfSaleServices, times(1)).saveOrUpdate(pointOfSale);
    }

    @Test
    public void testMarkAsLoadedCallsSetLoadedWithTrueOnPointOfSale_WhenMarkingItAsLoaded() {
        // @Given a PointOfSale
        PointOfSale pointOfSale = mock(PointOfSale.class);

        // @When marking it as loaded
        this.pointOfSaleTableAdapter.markAsLoaded(pointOfSale);

        // @Then pointOfSale.setLoaded(true) is called
        verify(pointOfSale, times(1)).setLoaded(true);
    }

    @Test
    public void testMarkAsLoadedCallsSetLoadedWithTrueOnPointOfSale_WhenMarkingItAsLoadedWithTrue() {
        // @Given a PointOfSale
        PointOfSale pointOfSale = mock(PointOfSale.class);

        // @When marking it as loaded
        this.pointOfSaleTableAdapter.markAsLoaded(pointOfSale, true);

        // @Then pointOfSale.setLoaded(true) is called
        verify(pointOfSale, times(1)).setLoaded(true);
    }

    @Test
    public void testMarkAsLoadedCallsSetLoadedWithFalseOnPointOfSale_WhenMarkingItAsLoadedWithFalse() {
        // @Given a PointOfSale
        PointOfSale pointOfSale = mock(PointOfSale.class);

        // @When marking it as loaded
        this.pointOfSaleTableAdapter.markAsLoaded(pointOfSale, false);

        // @Then pointOfSale.setLoaded(true) is called
        verify(pointOfSale, times(1)).setLoaded(false);
    }

    @Test
    public void testRemoveAllUnloadedRecordsCallsServicesRemoveUnloadedForCampaign_WhenRemovingAllFromAdapterWithThatCampaign() {
        // @Given a pointOfSaleTableAdapter

        // @When removingAllUnloadedRecords
        this.pointOfSaleTableAdapter.removeAllUnloadedRecords();

        // @Then pointOfSalesServices.removeUnloadedPointsOfSaleForCampaign is called with the adapters campaign
        verify(this.pointOfSaleServices, times(1)).removeUnloadedPointsOfSaleForCampaign(this.campaign);
    }

    @Test
    public void testRemoveAllUnloadedRecordsReturns21_WhenServicesRemoveUnloadedPOSForCampaignReturns21() {
        // @Given a pointOfSaleTableAdapter
        when(this.pointOfSaleServices.removeUnloadedPointsOfSaleForCampaign(this.campaign)).thenReturn(21l);

        // @When removingAllUnloadedRecords
        long result = this.pointOfSaleTableAdapter.removeAllUnloadedRecords();

        // @Then pointOfSalesServices.removeUnloadedPointsOfSaleForCampaign is called with the adapters campaign
        assertThat(result).isEqualTo(this.pointOfSaleServices.removeUnloadedPointsOfSaleForCampaign(this.campaign));
    }

    @Test
    public void testRemoveAllUnloadedRecordsReturns68_WhenServicesRemoveUnloadedPOSForCampaignReturns68() {
        // @Given a pointOfSaleTableAdapter
        when(this.pointOfSaleServices.removeUnloadedPointsOfSaleForCampaign(this.campaign)).thenReturn(68l);

        // @When removingAllUnloadedRecords
        long result = this.pointOfSaleTableAdapter.removeAllUnloadedRecords();

        // @Then pointOfSalesServices.removeUnloadedPointsOfSaleForCampaign is called with the adapters campaign
        assertThat(result).isEqualTo(this.pointOfSaleServices.removeUnloadedPointsOfSaleForCampaign(this.campaign));
    }

    @Test
    public void testGetEmptyRecord() {
        // @Given a points of sale table adapter with a campaign

        // @When getting an empty record
        PointOfSale emptyRecord = this.pointOfSaleTableAdapter.getEmptyRecord();

        // @Then an empty point of sale is returned
        assertThat(emptyRecord).isNotNull();
        assertThat(emptyRecord.getIdSap()).isNull();
        assertThat(emptyRecord.getServiceCenter()).isNull();
    }
}
