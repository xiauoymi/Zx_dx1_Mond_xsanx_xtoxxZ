package com.monsanto.metricspos.core.application.adapters;

import com.monsanto.metricspos.core.ServiceCenterServices;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.junit.Before;
import org.junit.Test;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class ServiceCenterTableAdapter_UT {
    private ServiceCenterTableAdapter serviceCenterTableAdapter;
    private Campaign campaign;
    private DataProvider dataProvider;
    private ServiceCenterServices serviceCenterServices;

    @Before
    public void setUp() throws Exception {
        this.dataProvider = new DataProvider();
        this.campaign = new Campaign("CampaignName", newDate(2011, 1, 1), newDate(2012, 2, 2));
        this.serviceCenterTableAdapter = new ServiceCenterTableAdapter(campaign, dataProvider);
        this.serviceCenterServices = mock(ServiceCenterServices.class);
        field("serviceCenterServices").ofType(ServiceCenterServices.class).in(this.serviceCenterTableAdapter).set(this.serviceCenterServices);
    }

    @Test
    public void testGetLoadScriptCallsCampaignGetServiceCenterLoadScript_WhenLoadingAScript() {
        // @Given an existing campaign and its service center table adapter
        this.dataProvider = new DataProvider();
        this.campaign = mock(Campaign.class);
        this.serviceCenterTableAdapter = new ServiceCenterTableAdapter(campaign, dataProvider);

        // @When loading the script
        this.serviceCenterTableAdapter.getLoadScript();

        // @Then the campaign is asked for it's load script
        verify(this.campaign, times(1)).getServiceCenterLoadScript();
    }

    @Test
    public void testGetLoadScriptReturnsCampaignGetServiceCenterLoadScript_WhenLoadingAScript() {
        // @Given an existing campaign and its service center table adapter
        this.campaign.setServiceCenterLoadScript("SCRIPT");

        // @When loading the script
        String loadScript = this.serviceCenterTableAdapter.getLoadScript();

        // @Then the campaign is asked for it's load script
        assertThat(loadScript).isEqualTo(this.campaign.getServiceCenterLoadScript());
    }

    @Test
    public void testGetLoadSqlCallsCampaignGetServiceCenterLoadSql_WhenLoadingTheSql() {
        // @Given an existing campaign and its service center table adapter
        this.dataProvider = new DataProvider();
        this.campaign = mock(Campaign.class);
        this.serviceCenterTableAdapter = new ServiceCenterTableAdapter(campaign, dataProvider);

        // @When loading the script
        this.serviceCenterTableAdapter.getLoadSql();

        // @Then the campaign is asked for it's load script
        verify(this.campaign, times(1)).getServiceCenterLoadSql();
    }

    @Test
    public void testGetLoadSqlReturnsCampaignGetServiceCenterLoadSql_WhenLoadingSql() {
        // @Given an existing campaign and its service center table adapter
        this.campaign.setServiceCenterLoadSql("Sql");

        // @When loading the script
        String loadSql = this.serviceCenterTableAdapter.getLoadSql();

        // @Then the campaign is asked for it's load script
        assertThat(loadSql).isEqualTo(this.campaign.getServiceCenterLoadSql());
    }

    @Test
    public void testMarkAllRecordsAsNoLoadedCallsServiceCenterServicesMarkAsNotLoaded_WhenMarkingAsNotLoaded() {
        // @Given a service center table adapter with a service center services and a campaign configured

        // @When marking service centers as not loaded
        this.serviceCenterTableAdapter.markAllRecordsAsNotLoaded();

        // @Then serviceCenterServices markAsNotLoaded is called for the configured campaign
        verify(this.serviceCenterServices, times(1)).markAllServiceCentersAsNotLoadedInCampaign(this.campaign);
    }

    @Test
    public void testSaveOrUpdateCallsServicesSaveOrUpdate_WhenSavingOrUpdatingAServiceCenter() {
        // @Given a service center
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(this.campaign);

        // @When saving or updating it
        this.serviceCenterTableAdapter.saveOrUpdate(serviceCenter);

        // @Then services.saveOrUpdate is called for that service center
        verify(this.serviceCenterServices, times(1)).saveOrUpdate(serviceCenter);
    }

    @Test
    public void testSaveOrUpdateSetsTheCampaignToTheServiceCenter_WhenTheServiceCenterHasNoCampaign() {
        // @Given a service center
        ServiceCenter serviceCenter = mock(ServiceCenter.class);

        // @When saving or updating it
        this.serviceCenterTableAdapter.saveOrUpdate(serviceCenter);

        // @Then services.saveOrUpdate is called for that service center
        verify(serviceCenter, times(1)).setCampaign(this.campaign);
    }

    @Test
    public void testMarkAsLoadedCallsSetLoadedWithTrue_WhenMarkingAServiceCenterAsLoaded() throws Exception {
        // @Given a service center
        ServiceCenter serviceCenter = mock(ServiceCenter.class);

        // @When marking it as loaded
        this.serviceCenterTableAdapter.markAsLoaded(serviceCenter);

        // @Then the service center's setLoaded(true) is called
        verify(serviceCenter, times(1)).setLoaded(true);
    }

    @Test
    public void testMarkAsLoadedWithTrueCallsSetLoadedWithTrue_WhenMarkingAServiceCenterAsLoadedTrue() throws Exception {
        // @Given a service center
        ServiceCenter serviceCenter = mock(ServiceCenter.class);

        // @When marking it as loaded
        this.serviceCenterTableAdapter.markAsLoaded(serviceCenter, true);

        // @Then the service center's setLoaded(true) is called
        verify(serviceCenter, times(1)).setLoaded(true);
    }

    @Test
    public void testMarkAsLoadedWithFalseCallsSetLoadedWithFalse_WhenMarkingAServiceCenterAsLoadedFalse() throws Exception {
        // @Given a service center
        ServiceCenter serviceCenter = mock(ServiceCenter.class);

        // @When marking it as loaded
        this.serviceCenterTableAdapter.markAsLoaded(serviceCenter, false);

        // @Then the service center's setLoaded(true) is called
        verify(serviceCenter, times(1)).setLoaded(false);
    }

    @Test
    public void testRemoveAllUnloadedRecordsCallsServicesRemoveAllUnloadedRecordsWithCampaignParameter_WhenRemovingAllUnloadedRecords() throws Exception {
        // @Given a serviceCenterTableAdapter with a campaign

        // @When removing all unloaded records
        this.serviceCenterTableAdapter.removeAllUnloadedRecords();

        // @serviceCenterServices removeAllUnloadedRecords is called}
        verify(this.serviceCenterServices, times(1)).removeAllNotLoadedServiceCenters(this.campaign);
    }

    @Test
    public void testGetEmptyRecordReturnsAServiceCenterLoadedWithTheCampaignOfAdapter_WhenTheAdapterHasACampaign(){
        // @Given a serviceCenterTableAdapter with a campaign

        // @When removing all unloaded records
        ServiceCenter emptyRecord = this.serviceCenterTableAdapter.getEmptyRecord();

        // @serviceCenterServices removeAllUnloadedRecords is called}
        assertThat(emptyRecord.getCampaign()).isNotNull();
        assertThat(emptyRecord.getCampaign()).isEqualTo(this.campaign);
    }
}
