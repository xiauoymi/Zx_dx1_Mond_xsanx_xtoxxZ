package com.monsanto.metricspos.core.application.vo;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricFactory;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import java.util.List;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class CampaignVO_UT {
    @Test
    public void testCampaignVOSetsAllFieldsExceptForMetricsAndTables_WhenConstructorWithCampaignParameterIsCalledAndWithChildrenIsFalse() {
        // @Given two campaigns
        Campaign campaign1 = new Campaign("campaign1Name", newDate(2010, 1, 1), newDate(2011, 1, 1));
        campaign1.setServiceCenterLoadSql("loadSql1");
        campaign1.setServiceCenterLoadScript("loadScript1");
        campaign1.setPointOfSaleLoadSql("posloadSql1");
        campaign1.setPointOfSaleLoadScript("posloadScript1");
        campaign1.setEmployeeLoadSql("emploadSql1");
        campaign1.setEmployeeLoadScript("emploadScript1");
        campaign1.setScheduled(true);
        campaign1.setRatingFormula("ratingformula1");
        campaign1.setRatingPremiumCategory("PremiumCategory1");
        campaign1.setId(1);
        Campaign campaign2 = new Campaign("campaign2Name", newDate(2011, 2, 2), newDate(2012, 2, 2));
        campaign2.setServiceCenterLoadSql("loadSql2");
        campaign2.setServiceCenterLoadScript("loadScript2");
        campaign2.setPointOfSaleLoadSql("posloadSql2");
        campaign2.setPointOfSaleLoadScript("posloadScript2");
        campaign2.setEmployeeLoadSql("emploadSql2");
        campaign2.setEmployeeLoadScript("emploadScript2");
        campaign2.setScheduled(false);
        campaign2.setRatingFormula("ratingformula2");
        campaign2.setRatingPremiumCategory("PremiumCategory2");
        campaign2.setId(2);

        // @When constructing a CampaignVO for each
        CampaignVO campaign1VO = new CampaignVO(campaign1, false);
        CampaignVO campaign2VO = new CampaignVO(campaign2, false);

        // @Then each Vo's fields are set with the campaigns value
        assertThat(campaign1VO.getId()).isEqualTo(campaign1.getId());
        assertThat(campaign1VO.getName()).isEqualTo(campaign1.getName());
        assertThat(campaign1VO.getSince()).isEqualTo(campaign1.getSince());
        assertThat(campaign1VO.getState()).isEqualTo(campaign1.getState());
        assertThat(campaign1VO.getUntil()).isEqualTo(campaign1.getUntil());
        assertThat(campaign1VO.getServiceCenterLoadSql()).isEqualTo(campaign1.getServiceCenterLoadSql());
        assertThat(campaign1VO.getServiceCenterLoadScript()).isEqualTo(campaign1.getServiceCenterLoadScript());
        assertThat(campaign1VO.getPointOfSaleLoadSql()).isEqualTo(campaign1.getPointOfSaleLoadSql());
        assertThat(campaign1VO.getPointOfSaleLoadScript()).isEqualTo(campaign1.getPointOfSaleLoadScript());
        assertThat(campaign1VO.getEmployeeLoadSql()).isEqualTo(campaign1.getEmployeeLoadSql());
        assertThat(campaign1VO.getEmployeeLoadScript()).isEqualTo(campaign1.getEmployeeLoadScript());
        assertThat(campaign1VO.isScheduled()).isEqualTo(campaign1.isScheduled());
        assertThat(campaign1VO.getRatingFormula()).isEqualTo(campaign1.getRatingFormula());
        assertThat(campaign1VO.getRatingPremiumCategory()).isEqualTo(campaign1.getRatingPremiumCategory());

        assertThat(campaign2VO.getId()).isEqualTo(campaign2.getId());
        assertThat(campaign2VO.getName()).isEqualTo(campaign2.getName());
        assertThat(campaign2VO.getSince()).isEqualTo(campaign2.getSince());
        assertThat(campaign2VO.getState()).isEqualTo(campaign2.getState());
        assertThat(campaign2VO.getUntil()).isEqualTo(campaign2.getUntil());
        assertThat(campaign2VO.getServiceCenterLoadSql()).isEqualTo(campaign2.getServiceCenterLoadSql());
        assertThat(campaign2VO.getServiceCenterLoadScript()).isEqualTo(campaign2.getServiceCenterLoadScript());
        assertThat(campaign2VO.getPointOfSaleLoadSql()).isEqualTo(campaign2.getPointOfSaleLoadSql());
        assertThat(campaign2VO.getPointOfSaleLoadScript()).isEqualTo(campaign2.getPointOfSaleLoadScript());
        assertThat(campaign2VO.getEmployeeLoadSql()).isEqualTo(campaign2.getEmployeeLoadSql());
        assertThat(campaign2VO.getEmployeeLoadScript()).isEqualTo(campaign2.getEmployeeLoadScript());
        assertThat(campaign2VO.isScheduled()).isEqualTo(campaign2.isScheduled());
        assertThat(campaign2VO.getRatingFormula()).isEqualTo(campaign2.getRatingFormula());
        assertThat(campaign2VO.getRatingPremiumCategory()).isEqualTo(campaign2.getRatingPremiumCategory());
    }

    @Test
    public void testCampaignVOSetsAllFields_WhenConstructorWithCampaignParameterIsCalledAndWithChildrenIsTrue() {
        // @Given two campaigns
        MetricFactory metricFactory = new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                return new Metric(campaign, name);
            }
        };

        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode("Code");


        Campaign campaign1 = new Campaign("campaign1Name", newDate(2010, 1, 1), newDate(2011, 1, 1));
        campaign1.setId(1);
        campaign1.setFactory(metricFactory);
        Metric metric1 = campaign1.addMetricDefinition("metric1", 200);
        DataTable dataTable1 = new DataTable();
        dataTable1.setId(1);
        dataTable1.setName("Table1");
        dataTable1.setDataProvider(dataProvider);
        dataTable1.setCampaign(campaign1);
        campaign1.addDataTable(dataTable1);

        Campaign campaign2 = new Campaign("campaign2Name", newDate(2011, 2, 2), newDate(2012, 2, 2));
        campaign2.setId(2);
        campaign2.setFactory(metricFactory);
        Metric metric2 = campaign2.addMetricDefinition("metric2", 200);
        DataTable dataTable2 = new DataTable();
        dataTable2.setId(2);
        dataTable2.setName("Table2");
        dataTable2.setDataProvider(dataProvider);
        dataTable2.setCampaign(campaign2);
        campaign2.addDataTable(dataTable2);

        // @When constructing a CampaignVO for each
        CampaignVO campaign1VO = new CampaignVO(campaign1, true);
        CampaignVO campaign2VO = new CampaignVO(campaign2, true);

        // @Then each Vo's fields are set with the campaigns value
        assertThat(campaign1VO.getId()).isEqualTo(campaign1.getId());
        assertThat(campaign1VO.getName()).isEqualTo(campaign1.getName());
        assertThat(campaign1VO.getSince()).isEqualTo(campaign1.getSince());
        assertThat(campaign1VO.getState()).isEqualTo(campaign1.getState());
        assertThat(campaign1VO.getUntil()).isEqualTo(campaign1.getUntil());
        assertThat(campaign1VO.getMetrics()).onProperty("name").contains(metric1.getName());
        assertThat(campaign1VO.getTables()).onProperty("name").contains(dataTable1.getName());

        assertThat(campaign2VO.getId()).isEqualTo(campaign2.getId());
        assertThat(campaign2VO.getName()).isEqualTo(campaign2.getName());
        assertThat(campaign2VO.getSince()).isEqualTo(campaign2.getSince());
        assertThat(campaign2VO.getState()).isEqualTo(campaign2.getState());
        assertThat(campaign2VO.getUntil()).isEqualTo(campaign2.getUntil());
        assertThat(campaign2VO.getUntil()).isEqualTo(campaign2.getUntil());
        assertThat(campaign2VO.getMetrics()).onProperty("name").contains(metric2.getName());
        assertThat(campaign2VO.getTables()).onProperty("name").contains(dataTable2.getName());
    }

    @Test
    public void testMakeCampaignVOsReturns2VOsWithSameParametersAs2InputCampaigns_WhenMakingVOsFor2Campaigns() {
        // @Given two campaigns
        // @Given two campaigns
        MetricFactory metricFactory = new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                return new Metric(campaign, name);
            }
        };

        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode("Code");


        Campaign campaign1 = new Campaign("campaign1Name", newDate(2010, 1, 1), newDate(2011, 1, 1));
        campaign1.setId(1);
        campaign1.setFactory(metricFactory);
        campaign1.addMetricDefinition("metric1", 200);
        DataTable dataTable1 = new DataTable();
        dataTable1.setId(1);
        dataTable1.setName("Table1");
        dataTable1.setDataProvider(dataProvider);
        dataTable1.setCampaign(campaign1);
        campaign1.addDataTable(dataTable1);

        Campaign campaign2 = new Campaign("campaign2Name", newDate(2011, 2, 2), newDate(2012, 2, 2));
        campaign2.setId(2);
        campaign2.setFactory(metricFactory);
        campaign2.addMetricDefinition("metric2", 200);
        DataTable dataTable2 = new DataTable();
        dataTable2.setId(2);
        dataTable2.setName("Table2");
        dataTable2.setDataProvider(dataProvider);
        dataTable2.setCampaign(campaign2);
        campaign2.addDataTable(dataTable2);

        // @When making VOs from them
        List<CampaignVO> campaignVOs = CampaignVO.makeCampaignVOs(Lists.<Campaign>newArrayList(campaign1, campaign2));

        // @Then VOs for those campaigns are returned
        assertThat(campaignVOs).onProperty("id").contains(1, 2);
        assertThat(campaignVOs).onProperty("name").contains("campaign1Name", "campaign2Name");
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        CampaignVO vo = new CampaignVO();
        tester.testInstance(vo);
    }
}
