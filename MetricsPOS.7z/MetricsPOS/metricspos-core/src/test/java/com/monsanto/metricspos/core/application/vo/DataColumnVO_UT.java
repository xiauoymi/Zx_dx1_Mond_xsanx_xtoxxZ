package com.monsanto.metricspos.core.application.vo;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataType;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class DataColumnVO_UT {
    @Test
    public void testConstructorSetsAllFieldsAsParameterDataColumn_WhenDataColumnIsParameter() {
        // @Given a data column
        DataColumn dataColumn = new DataColumn();
        dataColumn.setDataType(stringDataType());
        dataColumn.setDescription("Description");
        dataColumn.setEditable(true);
        dataColumn.setFilterable(true);
        dataColumn.setFormat("Formamamamamat");
        dataColumn.setId(2);
        dataColumn.setMaxSize(14);
        dataColumn.setMinSize(7);
        dataColumn.setName("nanananame");
        dataColumn.setOptions(Lists.<String>newArrayList());
        dataColumn.setPrecision(4);
        dataColumn.setRequired(true);
        dataColumn.setSortable(true);
        dataColumn.setHidden(true);
        dataColumn.setPrimaryKey(true);
        dataColumn.setManual(true);

        // @When constructing a data column VO with that data column as a parameter
        DataColumnVO dataColumnVO = new DataColumnVO(dataColumn);

        // @Then the data column VO is created with that data column's data
        assertThat(dataColumnVO.getType()).isEqualTo(dataColumn.getDataType().getCode());
        assertThat(dataColumnVO.getDescription()).isEqualTo(dataColumn.getDescription());
        assertThat(dataColumnVO.getEditable()).isEqualTo(dataColumn.isEditable());
        assertThat(dataColumnVO.getFilterable()).isEqualTo(dataColumn.isFilterable());
        assertThat(dataColumnVO.getFormat()).isEqualTo(dataColumn.getFormat());
        assertThat(dataColumnVO.getHidden()).isEqualTo(dataColumn.isHidden());
        assertThat(dataColumnVO.getId()).isEqualTo(dataColumn.getId());
        assertThat(dataColumnVO.getMinSize()).isEqualTo(dataColumn.getMinSize());
        assertThat(dataColumnVO.getName()).isEqualTo(dataColumn.getName());
        assertThat(dataColumnVO.getOptions()).isEqualTo(dataColumn.getOptions());
        assertThat(dataColumnVO.getPrecision()).isEqualTo(dataColumn.getPrecision());
        assertThat(dataColumnVO.getPrimaryKey()).isEqualTo(dataColumn.isPrimaryKey());
        assertThat(dataColumnVO.getRequired()).isEqualTo(dataColumn.isRequired());
        assertThat(dataColumnVO.getSize()).isEqualTo(dataColumn.getMaxSize());
        assertThat(dataColumnVO.getSortable()).isEqualTo(dataColumn.isSortable());
        assertThat(dataColumnVO.isManual()).isEqualTo(dataColumn.isManual());
    }

    @Test
    public void testMakeVOsReturnsTwoMatchingVOs_WhenMakingVOsFrom2DataColumns() {
        // @Given 2 data columns
        DataColumn dataColumn = new DataColumn();
        dataColumn.setDataType(stringDataType());
        dataColumn.setDescription("Description");
        dataColumn.setEditable(true);
        dataColumn.setFilterable(true);
        dataColumn.setFormat("Formamamamamat");
        dataColumn.setId(2);
        dataColumn.setMaxSize(14);
        dataColumn.setMinSize(7);
        dataColumn.setName("nanananame");
        dataColumn.setOptions(Lists.<String>newArrayList());
        dataColumn.setPrecision(4);
        dataColumn.setRequired(true);
        dataColumn.setSortable(true);
        dataColumn.setHidden(true);
        dataColumn.setPrimaryKey(true);
        dataColumn.setManual(true);

        DataColumn dataColumn2 = new DataColumn();
        dataColumn2.setDataType(stringDataType());
        dataColumn2.setDescription("Description2");
        dataColumn2.setEditable(false);
        dataColumn2.setFilterable(false);
        dataColumn2.setFormat("Formamamamamat2");
        dataColumn2.setId(3);
        dataColumn2.setMaxSize(142);
        dataColumn2.setMinSize(72);
        dataColumn2.setName("nanananame2");
        dataColumn2.setOptions(Lists.<String>newArrayList());
        dataColumn2.setPrecision(42);
        dataColumn2.setRequired(false);
        dataColumn2.setSortable(false);
        dataColumn2.setHidden(false);
        dataColumn2.setPrimaryKey(false);
        dataColumn2.setManual(false);

        // @When making VOs from the columns
        List<DataColumnVO> dataColumnVOs = DataColumnVO.makeDataColumnVOs(Lists.<DataColumn>newArrayList(dataColumn, dataColumn2));

        // @Then 2 matching VOs are returned
        assertThat(dataColumnVOs).onProperty("type").contains(dataColumn.getDataType().getCode(), dataColumn2.getDataType().getCode());
        assertThat(dataColumnVOs).onProperty("description").contains(dataColumn.getDescription(), dataColumn2.getDescription());
        assertThat(dataColumnVOs).onProperty("editable").contains(dataColumn.isEditable(), dataColumn2.isEditable());
        assertThat(dataColumnVOs).onProperty("filterable").contains(dataColumn.isFilterable(), dataColumn2.isFilterable());
        assertThat(dataColumnVOs).onProperty("format").contains(dataColumn.getFormat(), dataColumn2.getFormat());
        assertThat(dataColumnVOs).onProperty("hidden").contains(dataColumn.isHidden(), dataColumn2.isHidden());
        assertThat(dataColumnVOs).onProperty("id").contains(dataColumn.getId(), dataColumn2.getId());
        assertThat(dataColumnVOs).onProperty("minSize").contains(dataColumn.getMinSize(), dataColumn2.getMinSize());
        assertThat(dataColumnVOs).onProperty("name").contains(dataColumn.getName(), dataColumn2.getName());
        assertThat(dataColumnVOs).onProperty("options").contains(dataColumn.getOptions(), dataColumn2.getOptions());
        assertThat(dataColumnVOs).onProperty("precision").contains(dataColumn.getPrecision(), dataColumn2.getPrecision());
        assertThat(dataColumnVOs).onProperty("primaryKey").contains(dataColumn.isPrimaryKey(), dataColumn2.isPrimaryKey());
        assertThat(dataColumnVOs).onProperty("required").contains(dataColumn.isRequired(), dataColumn2.isRequired());
        assertThat(dataColumnVOs).onProperty("size").contains(dataColumn.getMaxSize(), dataColumn2.getMaxSize());
        assertThat(dataColumnVOs).onProperty("sortable").contains(dataColumn.isSortable(), dataColumn2.isSortable());
    }


    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        DataColumnVO vo = new DataColumnVO();
        tester.testInstance(vo);
    }

    private DataType stringDataType() {
        DataType dataType = new DataType();
        dataType.setCode("string");
        return dataType;
    }
}
