package com.monsanto.metricspos.core.application.vo;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class DataProviderVO_UT {
    @Test
    public void testConstructorSetsCodeAndName_WhenConstructingFromADataProvider() {
        // @Given 2 data providers
        DataProvider dataProvider1 = new DataProvider();
        dataProvider1.setCode("ONE");
        dataProvider1.setName("One");

        DataProvider dataProvider2 = new DataProvider();
        dataProvider2.setCode("TWO");
        dataProvider2.setName("Two");

        // @When constructing a VO from each
        DataProviderVO dataProvider1VO = new DataProviderVO(dataProvider1);
        DataProviderVO dataProvider2VO = new DataProviderVO(dataProvider2);

        // @Then the VO has the same name and code as the provider it was created from
        assertThat(dataProvider1VO.getCode()).isEqualTo(dataProvider1.getCode());
        assertThat(dataProvider1VO.getName()).isEqualTo(dataProvider1.getName());
        assertThat(dataProvider2VO.getCode()).isEqualTo(dataProvider2.getCode());
        assertThat(dataProvider2VO.getName()).isEqualTo(dataProvider2.getName());
    }

    @Test
    public void testMakeVosReturnsTwoMatchingDataProviders_WhenMakingVosForTwoProviders() {
        // @Given two Data providers
        DataProvider dataProvider1 = new DataProvider();
        dataProvider1.setCode("ONE");
        dataProvider1.setName("One");

        DataProvider dataProvider2 = new DataProvider();
        dataProvider2.setCode("TWO");
        dataProvider2.setName("Two");

        // @When making its VOs
        List<DataProviderVO> dataProviderVOs = DataProviderVO.makeDataProviderVOs(Lists.<DataProvider>newArrayList(dataProvider1, dataProvider2));

        // @Then 2 matching VOS are returned
        assertThat(dataProviderVOs).onProperty("code").contains(dataProvider1.getCode(), dataProvider2.getCode());
        assertThat(dataProviderVOs).onProperty("name").contains(dataProvider1.getName(), dataProvider2.getName());
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        DataProvider dataProvider1 = new DataProvider();
        dataProvider1.setCode("ONE");
        dataProvider1.setName("One");
        DataProviderVO vo = new DataProviderVO(dataProvider1);
        tester.testInstance(vo);
    }
}
