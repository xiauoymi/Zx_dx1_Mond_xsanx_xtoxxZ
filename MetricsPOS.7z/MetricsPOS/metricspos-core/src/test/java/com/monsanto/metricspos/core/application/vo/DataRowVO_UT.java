package com.monsanto.metricspos.core.application.vo;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.externaldata.DataType;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistor;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import org.junit.Test;
import org.mockito.Matchers;

import java.util.List;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * User: PPERA
 */
public class DataRowVO_UT {
    @Test
    public void testConstructorSetsAllColumns_WhenDataRowIsParameter() {
        // @Given a DataRow with data columns
        DataTable dataTable = new DataTable();
        final DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistor.getInternalId(Matchers.<Object>any())).thenReturn(1);
        when(dataRowPersistor.getManual(Matchers.<DataRow>any())).thenReturn(true);
        dataTable.setDataRowPersistorFactory(new DataRowPersistorFactory() {
            @Override
            public DataRowPersistor buildDataRowPersistor(DataTable dataTable) {
                return dataRowPersistor;
            }
        });
        DataColumn column1 = new DataColumn("column1", stringDataType());
        DataColumn column2 = new DataColumn("column2", stringDataType());
        DataColumn column3 = new DataColumn("column3", stringDataType());
        DataColumn column4 = new DataColumn("column4", stringDataType());

        dataTable.setColumns(Lists.newArrayList(column1, column2, column3, column4));
        Map<String, Object> rowValues = Maps.newHashMap();
        rowValues.put(column1.getName(), "A");
        rowValues.put(column2.getName(), "B");
        rowValues.put(column3.getName(), "C");
        rowValues.put(column4.getName(), "D");

        DataRow dataRow = new DataRow(dataTable, rowValues);

        // @When constructing a Data row VO from it
        DataRowVO dataRowVO = new DataRowVO(dataRow);

        // @Then the data row VO has all the values of the data rows in it's respective column
        assertEquals(1, dataRowVO.get(DataRowVO.ROW_ID_KEY));
        assertEquals(true, dataRowVO.get(DataRowVO.ROW_MANUAL));

        for (DataColumn column : dataTable.getColumns()) {
            assertEquals(dataRow.get(column.getName()), dataRowVO.get(column.getName()));
        }
    }

    @Test
    public void testConstructorSetsServiceCenterColumn_WhenDataRowIsParameterAndHasSCColumn() {
        // @Given a DataRow with data columns
        DataTable dataTable = new DataTable();
        final DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistor.getInternalId(Matchers.<Object>any())).thenReturn(1);
        when(dataRowPersistor.getManual(Matchers.<DataRow>any())).thenReturn(true);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        when(dataRowPersistor.getServiceCenter(Matchers.<Object>any())).thenReturn(serviceCenter);
        dataTable.setDataRowPersistorFactory(new DataRowPersistorFactory() {
            @Override
            public DataRowPersistor buildDataRowPersistor(DataTable dataTable) {
                return dataRowPersistor;
            }
        });
        DataColumn columnSC = new DataColumn("columnSC", serviceCenterDataType());

        dataTable.setColumns(Lists.newArrayList(columnSC));
        Map<String, Object> rowValues = Maps.newHashMap();
        rowValues.put(columnSC.getName(), serviceCenter);

        DataRow dataRow = new DataRow(dataTable, rowValues);

        // @When constructing a Data row VO from it
        DataRowVO dataRowVO = new DataRowVO(dataRow);

        // @Then the data row VO has all the values of the data rows in it's respective column
        assertEquals(1, dataRowVO.get(DataRowVO.ROW_ID_KEY));
        assertEquals(true, dataRowVO.get(DataRowVO.ROW_MANUAL));

        assertEquals(dataRowVO.get(columnSC.getName()), dataRow.getServiceCenter().getCuit());
    }

    @Test
    public void testConstructorSetsPointOfSaleColumn_WhenDataRowIsParameterAndHasPOSColumn() {
        // @Given a DataRow with data columns
        DataTable dataTable = new DataTable();
        final DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistor.getInternalId(Matchers.<Object>any())).thenReturn(1);
        when(dataRowPersistor.getManual(Matchers.<DataRow>any())).thenReturn(true);
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(1l);
        when(dataRowPersistor.getPointOfSale(Matchers.<Object>any())).thenReturn(pointOfSale);
        dataTable.setDataRowPersistorFactory(new DataRowPersistorFactory() {
            @Override
            public DataRowPersistor buildDataRowPersistor(DataTable dataTable) {
                return dataRowPersistor;
            }
        });
        DataColumn columnPOS = new DataColumn("columnPOS", pointOfSaleDataType());

        dataTable.setColumns(Lists.newArrayList(columnPOS));
        Map<String, Object> rowValues = Maps.newHashMap();
        rowValues.put(columnPOS.getName(), pointOfSale);

        DataRow dataRow = new DataRow(dataTable, rowValues);

        // @When constructing a Data row VO from it
        DataRowVO dataRowVO = new DataRowVO(dataRow);

        // @Then the data row VO has all the values of the data rows in it's respective column
        assertEquals(1, dataRowVO.get(DataRowVO.ROW_ID_KEY));
        assertEquals(true, dataRowVO.get(DataRowVO.ROW_MANUAL));

        assertEquals(dataRowVO.get(columnPOS.getName()), dataRow.getPointOfSale().getIdSap());
    }

    @Test
    public void testMakeVOsReturns2MatchingVOs_WhenMakingVOsFrom2DataRows() {
        // @Given 2 data rows
        DataTable dataTable = new DataTable();
        final DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistor.getInternalId(Matchers.<Object>any())).thenReturn(1);
        when(dataRowPersistor.getManual(Matchers.<DataRow>any())).thenReturn(true);
        dataTable.setDataRowPersistorFactory(new DataRowPersistorFactory() {
            @Override
            public DataRowPersistor buildDataRowPersistor(DataTable dataTable) {
                return dataRowPersistor;
            }
        });
        DataColumn column1 = new DataColumn("column1", stringDataType());
        DataColumn column2 = new DataColumn("column2", stringDataType());
        DataColumn column3 = new DataColumn("column3", stringDataType());
        DataColumn column4 = new DataColumn("column4", stringDataType());

        dataTable.setColumns(Lists.newArrayList(column1, column2, column3, column4));
        Map<String, Object> rowValues = Maps.newHashMap();
        rowValues.put(column1.getName(), "A");
        rowValues.put(column2.getName(), "B");
        rowValues.put(column3.getName(), "C");
        rowValues.put(column4.getName(), "D");
        Map<String, Object> rowValues2 = Maps.newHashMap();
        rowValues2.put(column1.getName(), "A2");
        rowValues2.put(column2.getName(), "B2");
        rowValues2.put(column3.getName(), "C2");
        rowValues2.put(column4.getName(), "D2");

        DataRow dataRow = new DataRow(dataTable, rowValues);
        DataRow dataRow2 = new DataRow(dataTable, rowValues2);

        // @When Making its VOs
        List<DataRowVO> dataRowVOs = DataRowVO.makeDataRowVOs(Lists.<DataRow>newArrayList(dataRow, dataRow2));

        // @Then 2 matching VOs are returned
        for (DataRowVO dataRowVO : dataRowVOs) {
            assertEquals(1, dataRowVO.get(DataRowVO.ROW_ID_KEY));
            assertEquals(true, dataRowVO.get(DataRowVO.ROW_MANUAL));

            for (DataColumn column : dataTable.getColumns()) {
                assertEquals(dataRow.get(column.getName()), dataRowVO.get(column.getName()));
            }
        }
    }

    private DataType pointOfSaleDataType() {
        DataType dataType = new DataType();
        dataType.setCode("POS");
        dataType.setName("Point of Sale");
        dataType.setInternalType(PointOfSale.class);
        return dataType;
    }

    private DataType serviceCenterDataType() {
        DataType dataType = new DataType();
        dataType.setCode("SC");
        dataType.setName("Service Center");
        dataType.setInternalType(ServiceCenter.class);
        return dataType;
    }

    private DataType stringDataType() {
        DataType dataType = new DataType();
        dataType.setCode("string");
        dataType.setName("String");
        dataType.setInternalType(String.class);
        return dataType;
    }
}
