package com.monsanto.metricspos.core.application.vo;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.externaldata.DataType;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class DataTableVO_UT {
    @Test
    public void testConstructorSetsAllFieldsAsParameterDataTable_WhenDataTableIsParameter() {
        // @Given a data table
        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode("Code");

        Campaign campaign1 = new Campaign("campaign1Name", newDate(2010, 1, 1), newDate(2011, 1, 1));
        campaign1.setId(1);
        DataTable dataTable1 = new DataTable();
        dataTable1.setId(1);
        dataTable1.setName("Table1");
        dataTable1.setDataProvider(dataProvider);
        dataTable1.setCampaign(campaign1);
        dataTable1.setLoadSql("LoadSql1");
        dataTable1.setLoadScript("LoadScript1");
        dataTable1.setScheduled(true);
        campaign1.addDataTable(dataTable1);

        Campaign campaign2 = new Campaign("campaign2Name", newDate(2020, 2, 2), newDate(2022, 2, 2));
        campaign2.setId(2);
        DataTable dataTable2 = new DataTable();
        dataTable2.setId(2);
        dataTable2.setName("Table2");
        dataTable2.setDataProvider(dataProvider);
        dataTable2.setCampaign(campaign2);
        dataTable2.setLoadSql("LoadSql2");
        dataTable2.setLoadScript("LoadScript2");
        dataTable2.setScheduled(false);
        DataColumn column = new DataColumn();
        column.setName("hola");
        column.setDataType(new DataType());
        dataTable2.setColumns(Lists.<DataColumn>newArrayList(column));
        campaign2.addDataTable(dataTable2);

        // @When constructing a data table VO with that data table
        DataTableVO dataTableVO1 = new DataTableVO(dataTable1);
        DataTableVO dataTableVO2 = new DataTableVO(dataTable2);

        // @Then the data table VO is created with the data table's data
        assertThat(dataTableVO1.getId()).isEqualTo(dataTable1.getId());
        assertThat(dataTableVO1.getName()).isEqualTo(dataTable1.getName());
        assertThat(dataTableVO1.getDescription()).isEqualTo(dataTable1.getDescription());
        assertThat(dataTableVO1.getAllowRecordCreation()).isEqualTo(dataTable1.getAllowRecordCreation());
        assertThat(dataTableVO1.getCampaignId()).isEqualTo(dataTable1.getCampaign().getId());
        assertThat(dataTableVO1.getProvider()).isEqualTo(dataTable1.getDataProvider().getCode());
        assertThat(dataTableVO1.getLoadSql()).isEqualTo(dataTable1.getLoadSql());
        assertThat(dataTableVO1.getLoadScript()).isEqualTo(dataTable1.getLoadScript());
        assertThat(dataTableVO1.isScheduled()).isEqualTo(dataTable1.isScheduled());

        assertThat(dataTableVO2.getId()).isEqualTo(dataTable2.getId());
        assertThat(dataTableVO2.getName()).isEqualTo(dataTable2.getName());
        assertThat(dataTableVO2.getDescription()).isEqualTo(dataTable2.getDescription());
        assertThat(dataTableVO2.getAllowRecordCreation()).isEqualTo(dataTable2.getAllowRecordCreation());
        assertThat(dataTableVO2.getCampaignId()).isEqualTo(dataTable2.getCampaign().getId());
        assertThat(dataTableVO2.getProvider()).isEqualTo(dataTable2.getDataProvider().getCode());
        assertThat(dataTableVO2.getLoadSql()).isEqualTo(dataTable2.getLoadSql());
        assertThat(dataTableVO2.getLoadScript()).isEqualTo(dataTable2.getLoadScript());
        assertThat(dataTableVO2.isScheduled()).isEqualTo(dataTable2.isScheduled());
        assertThat(dataTableVO2.getColumns()).onProperty("name").contains(column.getName());
    }

    @Test
    public void testConstructorSetsMetrics_WhenDataTableVOIsConstructedWitMetrics() {
        // @Given a data table
        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode("Code");

        Campaign campaign1 = new Campaign("campaign1Name", newDate(2010, 1, 1), newDate(2011, 1, 1));
        campaign1.setId(1);
        DataTable dataTable1 = new DataTable();
        dataTable1.setId(1);
        dataTable1.setName("Table1");
        dataTable1.setDataProvider(dataProvider);
        dataTable1.setCampaign(campaign1);
        dataTable1.setLoadSql("LoadSql1");
        dataTable1.setLoadScript("LoadScript1");
        dataTable1.setScheduled(true);
        Metric metric = new Metric(campaign1, "Hola");
        dataTable1.setMetrics(Lists.<Metric>newArrayList(metric));
        campaign1.addDataTable(dataTable1);

        Campaign campaign2 = new Campaign("campaign2Name", newDate(2020, 2, 2), newDate(2022, 2, 2));
        campaign2.setId(2);
        DataTable dataTable2 = new DataTable();
        dataTable2.setId(2);
        dataTable2.setName("Table2");
        dataTable2.setDataProvider(dataProvider);
        dataTable2.setCampaign(campaign2);
        dataTable2.setLoadSql("LoadSql2");
        dataTable2.setLoadScript("LoadScript2");
        dataTable2.setScheduled(false);
        DataColumn column = new DataColumn();
        column.setName("hola");
        column.setDataType(new DataType());
        dataTable2.setColumns(Lists.<DataColumn>newArrayList(column));
        campaign2.addDataTable(dataTable2);

        // @When constructing a data table VO with that data table
        DataTableVO dataTableVO1 = new DataTableVO(dataTable1, true);

        // @Then the data table VO is created with the data table's data
        assertThat(dataTableVO1.getId()).isEqualTo(dataTable1.getId());
        assertThat(dataTableVO1.getName()).isEqualTo(dataTable1.getName());
        assertThat(dataTableVO1.getDescription()).isEqualTo(dataTable1.getDescription());
        assertThat(dataTableVO1.getAllowRecordCreation()).isEqualTo(dataTable1.getAllowRecordCreation());
        assertThat(dataTableVO1.getCampaignId()).isEqualTo(dataTable1.getCampaign().getId());
        assertThat(dataTableVO1.getProvider()).isEqualTo(dataTable1.getDataProvider().getCode());
        assertThat(dataTableVO1.getLoadSql()).isEqualTo(dataTable1.getLoadSql());
        assertThat(dataTableVO1.getLoadScript()).isEqualTo(dataTable1.getLoadScript());
        assertThat(dataTableVO1.isScheduled()).isEqualTo(dataTable1.isScheduled());
        assertThat(dataTableVO1.getMetrics()).onProperty("name").contains(metric.getName());
    }


    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        DataTableVO vo = new DataTableVO();
        tester.testInstance(vo);
    }
}
