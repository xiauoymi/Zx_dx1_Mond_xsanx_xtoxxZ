package com.monsanto.metricspos.core.application.vo;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import java.util.List;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */

public class EmployeeVO_UT {
    @Test
    public void testConstructorSetsAllParameters() {
        // @Given an employee
        Employee employee = new Employee();
        Campaign campaign = new Campaign("name", newDate(2012, 1, 1), newDate(2013, 1, 1));
        employee.setCampaign(campaign);
        campaign.setId(3);
        employee.setId(1l);
        Group group = new Group();
        group.setName("group");
        employee.setGroups(Lists.<Group>newArrayList(group));
        employee.setEnabled(true);
        Metric metric = new Metric(campaign, "hi");
        employee.setMetrics(Lists.<Metric>newArrayList(metric));
        employee.setName("john");
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        serviceCenter.setCuit("10");
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        employee.setUsername("jsmith");

        // @When constructing an employeeVO
        EmployeeVO employeeVO = new EmployeeVO(employee);

        // @Then all the parameters are set
        assertThat(employeeVO.getCampaignId()).isEqualTo(employee.getCampaign().getId());
        assertThat(employeeVO.getId()).isEqualTo(employee.getId());
        assertThat(employeeVO.getGroups()).onProperty("name").contains(group.getName());
        assertThat(employeeVO.getMetrics()).onProperty("name").contains(metric.getName());
        assertThat(employeeVO.getServiceCenters()).onProperty("cuit").contains(serviceCenter.getCuit());
        assertThat(employeeVO.getName()).isEqualTo(employee.getName());
        assertThat(employeeVO.getUsername()).isEqualTo(employee.getUsername());
        assertThat(employeeVO.isEnabled()).isEqualTo(employee.isEnabled());
    }

    @Test
    public void testMakeEmployeeVOsReturns2MatchingVos_WhenMakingVosOutOf2Employees() {
        // @Given an employee
        Employee employee = new Employee();
        Campaign campaign = new Campaign("name", newDate(2012, 1, 1), newDate(2013, 1, 1));
        employee.setCampaign(campaign);
        campaign.setId(3);
        employee.setId(1l);
        Group group = new Group();
        group.setName("group");
        employee.setGroups(Lists.<Group>newArrayList(group));
        employee.setEnabled(true);
        Metric metric = new Metric(campaign, "hi");
        employee.setMetrics(Lists.<Metric>newArrayList(metric));
        employee.setName("john");
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        serviceCenter.setCuit("10");
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        employee.setUsername("jsmith");

        Employee employee2 = new Employee();
        employee2.setCampaign(campaign);
        employee2.setId(2l);
        employee2.setGroups(Lists.<Group>newArrayList(group));
        employee2.setEnabled(false);
        employee2.setMetrics(Lists.<Metric>newArrayList(metric));
        employee2.setName("daniel");
        employee2.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        employee2.setUsername("dsmith");

        // @When constructing an employeeVO
        List<EmployeeVO> employeeVOs = EmployeeVO.makeEmployeeVOs(Lists.<Employee>newArrayList(employee, employee2));

        // @Then 2 vos are returned
        assertThat(employeeVOs).onProperty("name").contains(employee.getName(), employee2.getName());
        assertThat(employeeVOs).onProperty("username").contains(employee.getUsername(), employee2.getUsername());
        assertThat(employeeVOs).onProperty("id").contains(employee.getId(), employee2.getId());
        assertThat(employeeVOs).onProperty("enabled").contains(employee.isEnabled(), employee2.isEnabled());
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        EmployeeVO vo = new EmployeeVO();
        tester.testInstance(vo);
    }

    @Test
    public void testToString(){
        Employee employee = new Employee();
        Campaign campaign = new Campaign("name", newDate(2012, 1, 1), newDate(2013, 1, 1));
        employee.setCampaign(campaign);
        campaign.setId(3);
        employee.setId(1l);
        Group group = new Group();
        group.setName("group");
        employee.setGroups(Lists.<Group>newArrayList(group));
        employee.setEnabled(true);
        Metric metric = new Metric(campaign, "hi");
        employee.setMetrics(Lists.<Metric>newArrayList(metric));
        employee.setName("john");
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        serviceCenter.setCuit("10");
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        employee.setUsername("jsmith");
        EmployeeVO employeeVO = new EmployeeVO(employee);
        assertThat(employeeVO.toString()).isEqualTo("EmployeeVO{id=1, name='john', username='jsmith', enabled=true, campaignId=3}");
    }
}
