package com.monsanto.metricspos.core.application.vo;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.security.Authority;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class GroupVO_UT {

    @Test
    public void testConstructorSetsAllAttributes_WhenContructingFromGroup() {
        // @Given a group
        Group group = new Group();
        group.setId(1);
        group.setName("Hi");
        group.setEnabled(true);
        Authority authority = new Authority();
        authority.setName("ACCESS");
        group.setAuthorities(Lists.<Authority>newArrayList(authority));

        // @When constructing a VO from it
        GroupVO groupVO = new GroupVO(group);

        // @All parameters are set
        assertThat(groupVO.getId()).isEqualTo(group.getId());
        assertThat(groupVO.getName()).isEqualTo(group.getName());
        assertThat(groupVO.isEnabled()).isEqualTo(group.isEnabled());
        assertThat(groupVO.getAuthorities()).onProperty("name").contains("ACCESS");
    }

    @Test
    public void testMakeGroupVOsReturns2VOs_WhenMakingVOsFromAListWith2Groups() {
        // @Given two groups
        Group group1 = new Group();
        group1.setId(1);
        Group group2 = new Group();
        group2.setId(2);
        ArrayList<Group> groups = Lists.newArrayList(group1, group2);

        // @When making it's VOS
        List<GroupVO> groupVOs = GroupVO.makeGroupVOs(groups);

        // @Then two VOs are made
        assertThat(groupVOs).hasSize(groups.size());
        assertThat(groupVOs).onProperty("id").contains(group1.getId(), group2.getId());
        assertThat(groupVOs).onProperty("name").contains(group1.getName(), group2.getName());
        assertThat(groupVOs).onProperty("enabled").contains(group1.isEnabled(), group2.isEnabled());
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        GroupVO vo = new GroupVO();
        tester.testInstance(vo);
    }

    @Test
    public void testToString() {
        // @Given a group
        Group group = new Group();
        group.setId(1);
        group.setName("Hi");
        group.setEnabled(true);
        Authority authority = new Authority();
        authority.setName("ACCESS");
        group.setAuthorities(Lists.<Authority>newArrayList(authority));
        GroupVO groupVO = new GroupVO(group);
        assertThat(groupVO.toString()).isEqualTo("GroupVO{id=1, name='Hi', enabled=true}");
    }
}
