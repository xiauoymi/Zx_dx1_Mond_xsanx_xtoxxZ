package com.monsanto.metricspos.core.application.vo;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class MetricScoreVO_UT {
    @Test
    public void testMetricScoresVOConstructorSetsAllFields_WhenCreatingFromMetricScore() {
        // @Given a MetricScore
        Campaign campaign = new Campaign("campaign", newDate(2000, 4, 5), newDate(2013, 5, 5));
        campaign.setId(123);
        Metric module = new Metric(campaign, "module");
        module.setId(2);
        Metric metric = new Metric(campaign, "metric");
        metric.setId(3);
        Metric submetric = new Metric(campaign, "submetric");
        submetric.setId(4);
        submetric.setParent(metric);
        metric.setParent(module);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("12121212");
        serviceCenter.setCampaign(campaign);
        MetricScore metricScore = new MetricScore(submetric, serviceCenter);
        metricScore.setPoints(BigDecimal.valueOf(11));
        metricScore.setPenalty(BigDecimal.valueOf(23));
        metricScore.setPenaltyFactor(BigDecimal.valueOf(45));

        // @When constructing a metricScoreVO from it
        MetricScoreVO metricScoreVO = new MetricScoreVO(metricScore);

        // @Then All fields are set
        assertThat(metricScoreVO.getMetricId()).isEqualTo(metricScore.getMetric().getId());
        assertThat(metricScoreVO.getPenalty()).isEqualTo(metricScore.getPenalty());
        assertThat(metricScoreVO.getPenaltyFactor()).isEqualTo(metricScore.getPenaltyFactor());
        assertThat(metricScoreVO.getPoints()).isEqualTo(metricScore.getPoints());
        assertThat(metricScoreVO.getServiceCenter().getCuit()).isEqualTo(metricScore.getServiceCenter().getCuit());
    }

    @Test
    public void testMakeVOsReturns2Vos_WhenMAkingVosFor2MetricScores() {
        // @Given 2 metric Scores
        Campaign campaign = new Campaign("campaign", newDate(2000, 4, 5), newDate(2013, 5, 5));
        campaign.setId(123);
        Metric module = new Metric(campaign, "name");
        module.setId(67);
        Metric metric = new Metric(campaign, "name");
        metric.setId(68);
        Metric submetric = new Metric(campaign, "name");
        submetric.setId(69);
        submetric.setParent(metric);
        metric.setParent(module);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("12121212");
        serviceCenter.setCampaign(campaign);
        MetricScore metricScore = new MetricScore(submetric, serviceCenter);
        metricScore.setPoints(BigDecimal.valueOf(11));
        metricScore.setPenalty(BigDecimal.valueOf(23));
        metricScore.setPenaltyFactor(BigDecimal.valueOf(45));

        Metric module2 = new Metric(campaign, "name");
        module2.setId(70);
        Metric metric2 = new Metric(campaign, "name");
        metric2.setId(71);
        Metric submetric2 = new Metric(campaign, "name");
        submetric2.setId(72);
        submetric2.setParent(metric2);
        metric2.setParent(module2);
        MetricScore metricScore2 = new MetricScore(submetric2, serviceCenter);
        metricScore2.setPoints(BigDecimal.valueOf(112));
        metricScore2.setPenalty(BigDecimal.valueOf(232));
        metricScore2.setPenaltyFactor(BigDecimal.valueOf(452));

        // @When making vos for them
        List<MetricScoreVO> metricScoreVOs = MetricScoreVO.makeMetricScoreVOs(Lists.<MetricScore>newArrayList(metricScore, metricScore2));

        // @Then 2 metrics are returned
        assertThat(metricScoreVOs).onProperty("points").contains(metricScore.getPoints(), metricScore2.getPoints());
        assertThat(metricScoreVOs).onProperty("penalty").contains(metricScore.getPenalty(), metricScore2.getPenalty());
        assertThat(metricScoreVOs).onProperty("penaltyFactor").contains(metricScore.getPenaltyFactor(), metricScore2.getPenaltyFactor());
        assertThat(metricScoreVOs).onProperty("submetric").onProperty("id").contains(69, 72);
        assertThat(metricScoreVOs).onProperty("metric").onProperty("id").contains(68, 71);
        assertThat(metricScoreVOs).onProperty("module").onProperty("id").contains(67, 70);
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        MetricScoreVO vo = new MetricScoreVO();
        tester.testInstance(vo);
    }
}
