package com.monsanto.metricspos.core.application.vo;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class MetricVO_UT {
    private Campaign campaign;

    @Before
    public void setUp() {
        campaign = new Campaign("campaign", newDate(2011, 1, 1), newDate(2012, 1, 1));
        campaign.setId(1);
    }

    @Test
    public void testConstructorSetsAllParametersExceptSubmetrics_WhenMakingAVOFromAMetricWithChildrenFalse() {
        // @Given a metric
        Metric metric = new Metric(campaign, "metricName");
        metric.setFormula("e=mc2");
        metric.setId(4);
        metric.setMaxPoints(220);
        Metric submetric = new Metric(campaign, "submetricName");
        submetric.setFormula("e=mc2");
        submetric.setExplanation("Explanation 1.");
        submetric.setId(4);
        metric.setMetrics(Lists.<Metric>newArrayList(submetric));
        metric.setScheduled(true);

        // @When making a metricVO
        MetricVO metricVO = new MetricVO(metric, false);

        // @Then all the params are set except submetrics
        assertThat(metricVO.getCampaignId()).isEqualTo(campaign.getId());
        assertThat(metricVO.getFormula()).isEqualTo(metric.getFormula());
        assertThat(metricVO.getId()).isEqualTo(metric.getId());
        assertThat(metricVO.getMaxPoints()).isEqualTo(metric.getMaxPoints());
        assertThat(metricVO.getMetrics()).isEmpty();
        assertThat(metricVO.getName()).isEqualTo(metric.getName());
        assertThat(metricVO.isScheduled()).isEqualTo(metric.isScheduled());
    }

    @Test
    public void testConstructorSetsAllParametersIncludingSubmetrics_WhenMakingAVOFromAMetricWithChildrenTrue() {
        // @Given a metric
        Metric metric = new Metric(campaign, "metricName");
        metric.setFormula("e=mc2");
        metric.setId(4);
        metric.setMaxPoints(220);
        Metric submetric = new Metric(campaign, "submetricName");
        submetric.setFormula("e=mc2");
        submetric.setOwner("Owner1");
        submetric.setExplanation("Explanation1");
        submetric.setId(4);
        metric.setMetrics(Lists.<Metric>newArrayList(submetric));

        // @When making a metricVO
        MetricVO metricVO = new MetricVO(metric, true);

        // @Then all the params are set
        assertThat(metricVO.getCampaignId()).isEqualTo(campaign.getId());
        assertThat(metricVO.getFormula()).isEqualTo(metric.getFormula());
        assertThat(metricVO.getId()).isEqualTo(metric.getId());
        assertThat(metricVO.getMaxPoints()).isEqualTo(metric.getMaxPoints());
        assertThat(metricVO.getMetrics()).onProperty("name").contains("submetricName");
        assertThat(metricVO.getName()).isEqualTo(metric.getName());
        assertThat(metricVO.getMetrics().get(0).getOwner()).isEqualTo(submetric.getOwner());
        assertThat(metricVO.getMetrics().get(0).getExplanation()).isEqualTo(submetric.getExplanation());
    }

    @Test
    public void testMakeMetricVOsReturns2VOs_WhenMakingVOsFromAListOfTwoMetrics() {
        // @Given a metric
        Metric metric = new Metric(campaign, "metricName");
        metric.setFormula("e=mc2");
        metric.setId(4);
        metric.setMaxPoints(220);
        Metric metric2 = new Metric(campaign, "metric2Name");
        metric2.setFormula("e=mc3");
        metric2.setId(5);
        metric2.setMaxPoints(98);

        // @When making a metricVO
        List<MetricVO> metricVOs = MetricVO.makeMetricVOs(Lists.<Metric>newArrayList(metric, metric2), false);

        // @Then all the params are set
        assertThat(metricVOs).onProperty("campaignId").contains(campaign.getId());
        assertThat(metricVOs).onProperty("formula").contains("e=mc2", "e=mc3");
        assertThat(metricVOs).onProperty("id").contains(4, 5);
        assertThat(metricVOs).onProperty("maxPoints").contains(220, 98);
        assertThat(metricVOs).onProperty("name").contains(metric.getName(), metric2.getName());
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        MetricVO vo = new MetricVO();
        tester.testInstance(vo);
    }

    @Test
    public void testToString() {
        Metric metric = new Metric(campaign, "metricName");
        metric.setFormula("e=mc2");
        metric.setId(4);
        metric.setMaxPoints(220);
        Metric submetric = new Metric(campaign, "submetricName");
        submetric.setFormula("e=mc2");
        submetric.setId(4);
        metric.setMetrics(Lists.<Metric>newArrayList(submetric));
        metric.setScheduled(true);
        MetricVO metricVO = new MetricVO(metric, false);
        assertThat(metricVO.toString()).isEqualTo("MetricVO{maxPoints=220, campaignId=1, formula='e=mc2', scheduled=true, enabled=false, name='metricName', id=4}");
    }
}
