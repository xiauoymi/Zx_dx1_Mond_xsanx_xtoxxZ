package com.monsanto.metricspos.core.application.vo;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class PointOfSaleVO_UT {
    @Test
    public void testConstructSetsAllFields_WhenAPointOfSaleIsProvidedAsAParameter() {
        // @Given a point of sale
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(1l);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("A cuit");
        pointOfSale.setServiceCenter(serviceCenter);
        pointOfSale.setAddress("Address");
        pointOfSale.setCounty("asd");
        pointOfSale.setCustomer("jnosdf");
        pointOfSale.setLocality("aslkdf");
        pointOfSale.setMail("dlksfn");
        pointOfSale.setPhone("013289");
        pointOfSale.setRegion("lksdnf");
        pointOfSale.setSalesGroup("lkdnsf");
        pointOfSale.setState("lkndfsg");
        pointOfSale.setTsrcId(23089l);
        pointOfSale.setType("josdf");

        // @When constructing a point of sale VO from it
        PointOfSaleVO pointOfSaleVO = new PointOfSaleVO(pointOfSale);

        // @Then all the fields are set with the original point of sale's values
        assertThat(pointOfSaleVO.getAddress()).isEqualTo(pointOfSale.getAddress());
        assertThat(pointOfSaleVO.getCounty()).isEqualTo(pointOfSale.getCounty());
        assertThat(pointOfSaleVO.getCustomer()).isEqualTo(pointOfSale.getCustomer());
        assertThat(pointOfSaleVO.getIdSap()).isEqualTo(pointOfSale.getIdSap());
        assertThat(pointOfSaleVO.getLocality()).isEqualTo(pointOfSale.getLocality());
        assertThat(pointOfSaleVO.getMail()).isEqualTo(pointOfSale.getMail());
        assertThat(pointOfSaleVO.getPhone()).isEqualTo(pointOfSale.getPhone());
        assertThat(pointOfSaleVO.getRegion()).isEqualTo(pointOfSale.getRegion());
        assertThat(pointOfSaleVO.getSalesGroup()).isEqualTo(pointOfSale.getSalesGroup());
        assertThat(pointOfSaleVO.getServiceCenter()).isEqualTo(pointOfSale.getServiceCenter().getCuit());
        assertThat(pointOfSaleVO.getState()).isEqualTo(pointOfSale.getState());
        assertThat(pointOfSaleVO.getTsrcId()).isEqualTo(pointOfSale.getTsrcId());
        assertThat(pointOfSaleVO.getType()).isEqualTo(pointOfSale.getType());
    }

    @Test
    public void testMakePointOfSaleVOsReturnsTwoVos_WhenMakingVosOfTwoPointsOfSale() {
        // @Given two pointsOfSales
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(1l);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("A cuit");
        pointOfSale.setServiceCenter(serviceCenter);
        pointOfSale.setAddress("Address1");
        pointOfSale.setCounty("county1");
        pointOfSale.setCustomer("customer1");
        pointOfSale.setLocality("locality1");
        pointOfSale.setMail("sth@sth.com");
        pointOfSale.setPhone("1234");
        pointOfSale.setRegion("region1");
        pointOfSale.setSalesGroup("salesGroup1");
        pointOfSale.setState("state1");
        pointOfSale.setTsrcId(1234l);
        pointOfSale.setType("type1");

        PointOfSale pointOfSale2 = new PointOfSale();
        pointOfSale2.setIdSap(1l);
        pointOfSale2.setServiceCenter(serviceCenter);
        pointOfSale.setAddress("Address2");
        pointOfSale.setCounty("county2");
        pointOfSale.setCustomer("customer2");
        pointOfSale.setLocality("locality2");
        pointOfSale.setMail("sth@sth.com");
        pointOfSale.setPhone("1235");
        pointOfSale.setRegion("region2");
        pointOfSale.setSalesGroup("salesGroup2");
        pointOfSale.setState("state2");
        pointOfSale.setTsrcId(1235l);
        pointOfSale.setType("type2");

        // @When making VOs
        List<PointOfSaleVO> pointOfSaleVOs = PointOfSaleVO.makePointOfSaleVOs(Lists.<PointOfSale>newArrayList(pointOfSale, pointOfSale2));

        // @Then 2 Vos with same attributes are returned
        assertThat(pointOfSaleVOs).onProperty("address").contains(pointOfSale.getAddress(), pointOfSale2.getAddress());
        assertThat(pointOfSaleVOs).onProperty("mail").contains(pointOfSale.getMail(), pointOfSale2.getMail());
        assertThat(pointOfSaleVOs).onProperty("county").contains(pointOfSale.getCounty(), pointOfSale2.getCounty());
        assertThat(pointOfSaleVOs).onProperty("customer").contains(pointOfSale.getCustomer(), pointOfSale2.getCustomer());
        assertThat(pointOfSaleVOs).onProperty("idSap").contains(pointOfSale.getIdSap(), pointOfSale2.getIdSap());
        assertThat(pointOfSaleVOs).onProperty("locality").contains(pointOfSale.getLocality(), pointOfSale2.getLocality());
        assertThat(pointOfSaleVOs).onProperty("phone").contains(pointOfSale.getPhone(), pointOfSale2.getPhone());
        assertThat(pointOfSaleVOs).onProperty("region").contains(pointOfSale.getRegion(), pointOfSale2.getRegion());
        assertThat(pointOfSaleVOs).onProperty("salesGroup").contains(pointOfSale.getSalesGroup(), pointOfSale2.getSalesGroup());
        assertThat(pointOfSaleVOs).onProperty("state").contains(pointOfSale.getState(), pointOfSale2.getState());
        assertThat(pointOfSaleVOs).onProperty("tsrcId").contains(pointOfSale.getTsrcId(), pointOfSale2.getTsrcId());
        assertThat(pointOfSaleVOs).onProperty("serviceCenter").contains(pointOfSale.getServiceCenter().getCuit(), pointOfSale2.getServiceCenter().getCuit());
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        PointOfSaleVO vo = new PointOfSaleVO();
        tester.testInstance(vo);
    }

        @Test
    public void testToString(){
        PointOfSaleVO pointOfSaleVO = new PointOfSaleVO();
        assertThat(pointOfSaleVO.toString()).isEqualTo("PointOfSaleVO{idSap=null, salesGroup='null', region='null', type='null', tsrcId=null, customer='null', locality='null', county='null', state='null', address='null', phone='null', mail='null', serviceCenter='null'}");
    }
}
