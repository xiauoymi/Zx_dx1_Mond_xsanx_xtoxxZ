package com.monsanto.metricspos.core.application.vo;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.ComputeManager;
import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricFactory;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryNode;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * User: PPERA
 */
public class ScoreSummaryVO_UT {
    private Campaign campaign;
    private ServiceCenter serviceCenter;
    private ScoreServices scoreServices;
    private ComputeManager computeManager;

    @Before
    public void setUp() {
        this.computeManager = mock(ComputeManager.class);
        this.campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 3, 3));
        this.campaign.setId(1);
        this.campaign.setComputeManager(computeManager);
        MetricFactory factory = new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                Metric metric = new Metric(campaign, name);
                metric.setMaxPoints(maxPoints);
                metric.setComputeManager(computeManager);
                return metric;
            }
        };

        this.campaign.setFactory(factory);

        serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        serviceCenter.setCuit("10");

        Metric module1 = this.campaign.addMetricDefinition("module1", 450);

        Metric metric1 = module1.addMetricDefinition("metric1", 200);
        Metric submetric11 = metric1.addMetricDefinition("submetric11", 200);
        MetricScore metricScore11 = new MetricScore(submetric11, this.serviceCenter);
        metricScore11.setPoints(BigDecimal.valueOf(120));

        Metric metric2 = module1.addMetricDefinition("metric2", 250);
        Metric submetric21 = metric2.addMetricDefinition("submetric21", 50);
        MetricScore metricScore21 = new MetricScore(submetric21, this.serviceCenter);
        metricScore21.setPoints(BigDecimal.valueOf(40));
        Metric submetric22 = metric2.addMetricDefinition("submetric22", 50);
        MetricScore metricScore22 = new MetricScore(submetric22, this.serviceCenter);
        metricScore22.setPoints(BigDecimal.valueOf(30));
        Metric submetric23 = metric2.addMetricDefinition("submetric23", 150);
        MetricScore metricScore23 = new MetricScore(submetric23, this.serviceCenter);
        metricScore23.setPoints(BigDecimal.valueOf(120));

        Metric module2 = this.campaign.addMetricDefinition("module2", 450);
        Metric metric3 = module2.addMetricDefinition("metric3", 100);
        Metric submetric31 = metric3.addMetricDefinition("submetric31", 25);
        MetricScore metricScore31 = new MetricScore(submetric31, this.serviceCenter);
        metricScore31.setPoints(BigDecimal.valueOf(10));
        Metric submetric32 = metric3.addMetricDefinition("submetric32", 75);
        MetricScore metricScore32 = new MetricScore(submetric32, this.serviceCenter);
        metricScore32.setPoints(BigDecimal.valueOf(10));

        Metric metric4 = module2.addMetricDefinition("metric4", 350);
        Metric submetric41 = metric4.addMetricDefinition("submetric41", 350);
        MetricScore metricScore41 = new MetricScore(submetric41, this.serviceCenter);
        metricScore41.setPoints(BigDecimal.valueOf(120));

        this.scoreServices = mock(ScoreServices.class);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric11, serviceCenter)).thenReturn(metricScore11);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric21, serviceCenter)).thenReturn(metricScore21);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric22, serviceCenter)).thenReturn(metricScore22);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric23, serviceCenter)).thenReturn(metricScore23);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric31, serviceCenter)).thenReturn(metricScore31);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric32, serviceCenter)).thenReturn(metricScore32);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric41, serviceCenter)).thenReturn(metricScore41);
    }

    @Test
    public void testScoreSummaryVOMaxPointsIs900_WhenBuiltFromCampaignNodeWhoseMaxPointsIs900() {
        // @Given
        ScoreSummaryCampaignNode scoreSummaryCampaignNode = new ScoreSummaryCampaignNode(this.campaign, this.serviceCenter, this.scoreServices);

        // @When
        ScoreSummaryVO scoreSummaryVO = new ScoreSummaryVO(scoreSummaryCampaignNode);

        // @Then
        assertThat(scoreSummaryVO.getMaxPoints()).isEqualTo(scoreSummaryCampaignNode.getMaxPoints());
    }

    @Test
    public void testScoreSummaryVOPointsIs450_WhenBuiltFromCampaignNodeWhosePointsIs450() {
        // @Given
        ScoreSummaryCampaignNode scoreSummaryCampaignNode = new ScoreSummaryCampaignNode(this.campaign, this.serviceCenter, this.scoreServices);

        // @When
        ScoreSummaryVO scoreSummaryVO = new ScoreSummaryVO(scoreSummaryCampaignNode);

        // @Then
        assertThat(scoreSummaryVO.getPoints()).isEqualTo(scoreSummaryCampaignNode.getPoints());
    }

    @Test
    public void testScoreSummaryVOModuleLevelHasSamePointsAsModules_WhenBuiltFromCampaignNode() {
        // @Given
        ScoreSummaryCampaignNode scoreSummaryCampaignNode = new ScoreSummaryCampaignNode(this.campaign, this.serviceCenter, this.scoreServices);
        List<BigDecimal> moduleLevelPoints = Lists.transform(scoreSummaryCampaignNode.getChildren(), new Function<ScoreSummaryNode, BigDecimal>() {
            @Override
            public BigDecimal apply(ScoreSummaryNode input) {
                return input.getPoints();
            }
        });

        // @When
        ScoreSummaryVO scoreSummaryVO = new ScoreSummaryVO(scoreSummaryCampaignNode);

        // @Then
        assertThat(scoreSummaryVO.getChildren()).onProperty("points").contains(moduleLevelPoints.toArray());
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        ScoreSummaryCampaignNode scoreSummaryCampaignNode = new ScoreSummaryCampaignNode(this.campaign, this.serviceCenter, this.scoreServices);
        ScoreSummaryVO vo = new ScoreSummaryVO(scoreSummaryCampaignNode);
        tester.testInstance(vo);
    }
}
