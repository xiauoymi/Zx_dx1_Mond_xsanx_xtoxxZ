package com.monsanto.metricspos.core.application.vo;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import java.util.Date;
import java.util.List;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class ServiceCenterVO_UT {
    @Test
    public void testConstructorSetsAllFieldsExceptForPointsOfSale_WhenAServiceCenterIsProvidedAsParameterAndWithChildrenIsFalse() {
        // @Given a service center
        Campaign campaign = new Campaign("campaign1Name", newDate(2010, 1, 1), newDate(2011, 1, 1));
        campaign.setId(1);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("a cuit");
        serviceCenter.setCampaign(campaign);
        serviceCenter.setMail("asdasd@sadasd.com");
        serviceCenter.setName("Name");
        Date lastTimeSent = new Date();
        serviceCenter.setLastTimeSent(lastTimeSent);
        List<PointOfSale> pointsOfSale = Lists.newArrayList(new PointOfSale());
        serviceCenter.setPointsOfSale(pointsOfSale);

        // @When constructing a service center VO from that service center
        ServiceCenterVO serviceCenterVO = new ServiceCenterVO(serviceCenter, false);

        // @Then the service center VO's fields are set
        assertThat(serviceCenterVO.getCuit()).isEqualTo(serviceCenter.getCuit());
        assertThat(serviceCenterVO.getCampaign()).isEqualTo(serviceCenter.getCampaign().getId());
        assertThat(serviceCenterVO.getMail()).isEqualTo(serviceCenter.getMail());
        assertThat(serviceCenterVO.getName()).isEqualTo(serviceCenter.getName());
        assertThat(serviceCenterVO.getPointsOfSale()).isNull();
        assertThat(serviceCenterVO.getLastTimeSent()).isEqualTo(serviceCenter.getLastTimeSent());
    }

    @Test
    public void testConstructorSetsAllFields_WhenAServiceCenterIsProvidedAsParameterAndWithChildrenIsTrue() {
        // @Given a service center
        Campaign campaign = new Campaign("campaign1Name", newDate(2010, 1, 1), newDate(2011, 1, 1));
        campaign.setId(1);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("a cuit");
        serviceCenter.setCampaign(campaign);
        serviceCenter.setMail("asdasd@sadasd.com");
        serviceCenter.setName("Name");
        List<PointOfSale> pointsOfSale = Lists.newArrayList(new PointOfSale());
        serviceCenter.setPointsOfSale(pointsOfSale);

        // @When constructing a service center VO from that service center
        ServiceCenterVO serviceCenterVO = new ServiceCenterVO(serviceCenter, true);

        // @Then the service center VO's fields are set
        assertThat(serviceCenterVO.getCuit()).isEqualTo(serviceCenter.getCuit());
        assertThat(serviceCenterVO.getCampaign()).isEqualTo(serviceCenter.getCampaign().getId());
        assertThat(serviceCenterVO.getMail()).isEqualTo(serviceCenter.getMail());
        assertThat(serviceCenterVO.getName()).isEqualTo(serviceCenter.getName());
        assertThat(serviceCenterVO.getPointsOfSale()).hasSize(serviceCenter.getPointsOfSale().size());
    }

    @Test
    public void testMakeVosReturns2MatchingVOs_WhenMakingVosFromTwoServiceCenters() {
        // @Given Two serviceCenters
        Campaign campaign = new Campaign("campaign1Name", newDate(2010, 1, 1), newDate(2011, 1, 1));
        campaign.setId(1);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("a cuit");
        serviceCenter.setCampaign(campaign);
        serviceCenter.setMail("asdasd@sadasd.com");
        serviceCenter.setName("Name");

        ServiceCenter serviceCenter2 = new ServiceCenter();
        serviceCenter2.setCuit("a cuit2");
        serviceCenter2.setCampaign(campaign);
        serviceCenter2.setMail("asdasd@sadasd.com2");
        serviceCenter2.setName("Name2");

        // @When making it's VOs
        List<ServiceCenterVO> serviceCenterVOs = ServiceCenterVO.makeServiceCenterVOs(Lists.<ServiceCenter>newArrayList(serviceCenter, serviceCenter2));

        // @Then two matching VOs are returned
        assertThat(serviceCenterVOs).onProperty("cuit").contains(serviceCenter.getCuit(), serviceCenter2.getCuit());
        assertThat(serviceCenterVOs).onProperty("campaign").contains(serviceCenter.getCampaign().getId(), serviceCenter.getCampaign().getId());
        assertThat(serviceCenterVOs).onProperty("mail").contains(serviceCenter.getMail(), serviceCenter2.getMail());
        assertThat(serviceCenterVOs).onProperty("name").contains(serviceCenter.getName(), serviceCenter2.getName());
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        ServiceCenterVO vo = new ServiceCenterVO();
        tester.testInstance(vo);
    }
}
