package com.monsanto.metricspos.core.application.vo.converter;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.application.vo.DataColumnVO;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataType;
import org.junit.Test;

import java.util.Map;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;

/**
 * User: PPERA
 */
public class DataColumnVO2DataColumnConverter_UT {
    @Test
    public void testConvertSetsAllFields_WhenConvertingAVoToADataColumn() throws Exception {
        DataColumnVO2DataColumnConverter converter = new DataColumnVO2DataColumnConverter();
        Map<String, DataType> dataTypeMap = Maps.newHashMap();
        dataTypeMap.put("string", stringDataType());
        converter.setDataTypeMap(dataTypeMap);

        // @Given a new columns data
        DataColumnVO dataColumnVO = new DataColumnVO();
        dataColumnVO.setType("string");
        dataColumnVO.setName("Name");
        dataColumnVO.setDescription("Description");
        dataColumnVO.setFilterable(true);
        dataColumnVO.setFormat("format");
        dataColumnVO.setMinSize(10);
        dataColumnVO.setPrecision(10);
        dataColumnVO.setRequired(true);
        dataColumnVO.setSize(20);
        dataColumnVO.setSortable(true);
        dataColumnVO.setOptions(Lists.<String>newArrayList());
        dataColumnVO.setEditable(true);
        dataColumnVO.setHidden(true);
        dataColumnVO.setPrimaryKey(true);
        dataColumnVO.setManual(true);

        // @When creating the column
        DataColumn dataColumn = converter.convert(dataColumnVO);

        // @Then the created column has the provided data
        assertThat(dataColumn.getDataType().getCode()).isEqualTo(dataColumnVO.getType());
        assertThat(dataColumn.getName()).isEqualTo(dataColumnVO.getName());
        assertThat(dataColumn.getDescription()).isEqualTo(dataColumnVO.getDescription());
        assertThat(dataColumn.isFilterable()).isEqualTo(dataColumnVO.getFilterable());
        assertThat(dataColumn.getFormat()).isEqualTo(dataColumnVO.getFormat());
        assertThat(dataColumn.getMinSize()).isEqualTo(dataColumnVO.getMinSize());
        assertThat(dataColumn.getPrecision()).isEqualTo(dataColumnVO.getPrecision());
        assertThat(dataColumn.isRequired()).isEqualTo(dataColumnVO.getRequired());
        assertThat(dataColumn.getMaxSize()).isEqualTo(dataColumnVO.getSize());
        assertThat(dataColumn.isSortable()).isEqualTo(dataColumnVO.getSortable());
        assertThat(dataColumn.getOptions()).isEqualTo(dataColumnVO.getOptions());
        assertThat(dataColumn.isEditable()).isEqualTo(dataColumnVO.getEditable());
        assertThat(dataColumn.isHidden()).isEqualTo(dataColumnVO.getHidden());
        assertThat(dataColumn.isPrimaryKey()).isEqualTo(dataColumnVO.getPrimaryKey());
        assertThat(dataColumn.isManual()).isEqualTo(dataColumnVO.isManual());
    }

    private DataType stringDataType() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("string");
        field("internalType").ofType(Class.class).in(dataType).set(String.class);
        return dataType;
    }
}
