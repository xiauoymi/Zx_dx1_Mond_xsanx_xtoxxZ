package com.monsanto.metricspos.core.externaldata;

import com.monsanto.metricspos.core.externaldata.converters.ConverterUtils;
import com.monsanto.metricspos.core.metrics.Campaign;
import org.junit.Before;
import org.junit.Test;
import org.springframework.core.convert.ConversionService;

import java.math.BigDecimal;
import java.util.Date;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;

/**
 * @author PPERA
 */
public class ConverterUtils_UT {

    private ConversionService conversionService;

    @Before
    public void setUp() {
        Campaign campaign = new Campaign("name", newDate(2012, 1, 1), newDate(2015, 2, 3));
        conversionService = ConverterUtils.makeConverterService(campaign);
    }

    @Test
    public void testStringToDate() throws Exception {
        Date date = conversionService.convert("2012-07-20", Date.class);

        assertThat(date).isEqualTo(newDate(2012, 7, 20));
    }

    @Test
    public void testDateToString() throws Exception {
        String stringDate = conversionService.convert(newDate(2012, 7, 20), String.class);

        assertThat(stringDate).isEqualTo("2012-07-20 12:00:00.000 AM");
    }

    @Test
    public void testIntToInteger() throws Exception {
        Integer integer = conversionService.convert("489", Integer.class);

        assertThat(integer).isEqualTo(489);
    }

    @Test
    public void testIntToBigDecimal() throws Exception {
        BigDecimal bigDecimal = conversionService.convert(489, BigDecimal.class);

        assertThat(bigDecimal).isEqualTo(BigDecimal.valueOf(489));
    }
}
