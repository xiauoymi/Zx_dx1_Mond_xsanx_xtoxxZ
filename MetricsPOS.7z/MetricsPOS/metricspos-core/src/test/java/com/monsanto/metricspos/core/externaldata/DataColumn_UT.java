package com.monsanto.metricspos.core.externaldata;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.metricspos.core.externaldata.restrictions.Restriction;
import com.monsanto.metricspos.core.externaldata.restrictions.StringLengthRestriction;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;

/**
 * @author PPERA
 */
public class DataColumn_UT {
    @Test
    public void testCannotCreateAColumnWithNoDataType() {
        String name = "dummyName";

        try {
            new DataColumn(name, null);
            fail();
        } catch (RuntimeException e) {
            assertThat(e.getMessage()).isSameAs(DataColumn.ERROR_CANNOT_CREATE_COLUMN_WITH_NO_DATA_TYPE);
        }
    }

    @Test
    public void testCannotCreateAColumnWithNoName() {
        DataType dataType = new DataType();

        try {
            new DataColumn(null, dataType, null);
            fail();
        } catch (RuntimeException e) {
            assertThat(e.getMessage()).isSameAs(DataColumn.ERROR_CANNOT_CREATE_COLUMN_WITH_NO_NAME);
        }
    }

    @Test
    public void testWhenAColumnIsCreatedWithOneRestrictionItRemembersThatRestriction() {
        String name = "name";
        DataType dataType = new DataType();
        Restriction restriction = new StringLengthRestriction(10);
        HashSet<Restriction> restrictions = Sets.newHashSet(restriction);
        DataColumn dataColumn = new DataColumn(name, dataType, restrictions);

        assertThat(dataColumn.getRestrictions().size()).isSameAs(restrictions.size());
        assertThat(dataColumn.getRestrictions()).isSameAs(restrictions);
    }

    @Test
    public void testWhenAColumnIsCreatedWithMoreThanOneRestrictionItRemembersThoseRestrictions() {
        String name = "name";
        DataType dataType = new DataType();
        Restriction restriction1 = new StringLengthRestriction(10);
        Restriction restriction2 = new StringLengthRestriction(10);
        Set<Restriction> restrictions = Sets.newHashSet(restriction1, restriction2);
        DataColumn dataColumn = new DataColumn(name, dataType, restrictions);

        assertThat(dataColumn.getRestrictions().size()).isSameAs(restrictions.size());
        assertThat(dataColumn.getRestrictions()).isSameAs(restrictions);
    }

    @Test
    public void testCannotCreateAColumnWithSpecifiedRestrictionsThatAreNull() {
        String name = "dummyName";
        DataType dataType = new DataType();

        Restriction restriction = null;
        Set<Restriction> restrictions = Sets.newHashSet(restriction);

        try {
            new DataColumn(name, dataType, restrictions);
            fail();
        } catch (RuntimeException e) {
            assertThat(e.getMessage()).isSameAs(DataColumn.ERROR_SPECIFIED_RESTRICTIONS_CANNOT_BE_NULL);
        }
    }

    @Test
    public void testMergeColumnSetsAllFields_WhenMergingAColumnWithAnother() {
        // @Given a data column and the same column updated
        DataColumn original = new DataColumn("original", stringDataType());
        original.setDescription("originalDescription");
        original.setEditable(true);
        original.setFilterable(true);
        original.setFormat("Format");
        original.setHidden(true);
        original.setActualColumnName("text1");
        original.setMaxSize(20);
        original.setMinSize(10);
        original.setOptions(Lists.<String>newArrayList("option1"));
        original.setPrecision(11);
        original.setRequired(true);
        original.setSortable(true);

        DataColumn updated = new DataColumn("updated", numberDataType());
        updated.setDescription("updatedDescription");
        updated.setEditable(false);
        updated.setFilterable(false);
        updated.setFormat("AnotherFormat");
        updated.setHidden(false);
        updated.setActualColumnName(null);
        updated.setMaxSize(12);
        updated.setMinSize(15);
        updated.setOptions(Lists.<String>newArrayList("option2"));
        updated.setPrecision(16);
        updated.setRequired(false);
        updated.setSortable(false);
        updated.setPrimaryKey(true);

        // @When merging the columns
        original.merge(updated);

        // @Then the first one updates itself with the updated data
        assertThat(original.getName()).isEqualTo(updated.getName());
        assertThat(original.getDataType().getCode()).isEqualTo(updated.getDataType().getCode());
        assertThat(original.getDescription()).isEqualTo(updated.getDescription());
        assertThat(original.getActualColumnName()).isEqualTo(updated.getActualColumnName());
        assertThat(original.getFormat()).isEqualTo(updated.getFormat());
        assertThat(original.getMaxSize()).isEqualTo(updated.getMaxSize());
        assertThat(original.getMinSize()).isEqualTo(updated.getMinSize());
        assertThat(original.getOptions()).isEqualTo(updated.getOptions());
        assertThat(original.getPrecision()).isEqualTo(updated.getPrecision());
        assertThat(original.isEditable()).isEqualTo(updated.isEditable());
        assertThat(original.isFilterable()).isEqualTo(updated.isFilterable());
        assertThat(original.isHidden()).isEqualTo(updated.isHidden());
        assertThat(original.isPrimaryKey()).isEqualTo(updated.isPrimaryKey());
        assertThat(original.isRequired()).isEqualTo(updated.isRequired());
        assertThat(original.isSortable()).isEqualTo(updated.isSortable());

    }

    private DataType stringDataType() {
        DataType dataType = new DataType();
        dataType.setCode("TEXT");
        dataType.setName("Text");
        dataType.setInternalType(String.class);
        return dataType;
    }

    private DataType numberDataType() {
        DataType dataType = new DataType();
        dataType.setCode("NUMBER");
        dataType.setName("Number");
        dataType.setInternalType(BigDecimal.class);
        return dataType;
    }
}
