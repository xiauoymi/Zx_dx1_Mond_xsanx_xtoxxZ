package com.monsanto.metricspos.core.externaldata;

import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

/**
 * User: PPERA
 */
public class DataFile_UT {
    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        DataFile instance = new DataFile("Hi", "lala".getBytes());
        tester.testInstance(instance);
    }
}
