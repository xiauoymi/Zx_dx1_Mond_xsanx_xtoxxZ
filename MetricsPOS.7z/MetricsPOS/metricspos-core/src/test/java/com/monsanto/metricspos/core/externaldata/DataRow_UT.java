package com.monsanto.metricspos.core.externaldata;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.monsanto.metricspos.core.externaldata.restrictions.Restriction;
import com.monsanto.metricspos.core.externaldata.restrictions.StringLengthRestriction;
import com.monsanto.metricspos.core.externaldata.testclasses.SimpleDataRowPersistor;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistor;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import com.monsanto.metricspos.persistence.RowValuesServices;
import org.junit.Test;
import org.mockito.Matchers;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * @author PPERA
 */
public class DataRow_UT {

    @Test
    public void testWhenDataOfADataTableWithOneStringColumnIsCreatedAndItParametersIsSetItRemembersTheValueThatWasSetForThatColumn() {
        DataType stringDataType = stringDataType();
        String columnName = "column1";
        String value = "Hello";
        DataColumn dataColumn = newDataColumn(stringDataType, columnName);

        List<DataColumn> columns = Lists.newArrayList(dataColumn);
        DataTable dataTable = new DataTable("name", columns, newReflectiveDataRowPersistorFactory());
        RowValuesServices rowValuesServices = mock(RowValuesServices.class);
        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());
        dataRow.set(columnName, value);

        assertThat(dataRow.get(columnName)).isSameAs(value);
    }

    @Test
    public void testWhenDataOfADataTableWithTwoStringColumnsIsCreatedAndItsParametersAreBothSetItRemembersTheValuesThatWereSetForEachColumn() {
        DataType stringDataType = stringDataType();
        String columnName = "column1";
        String columnName2 = "column2";
        String value = "Hello";
        String value2 = "Goodbye";
        DataColumn dataColumn = newDataColumn(stringDataType, columnName);
        DataColumn dataColumn2 = newDataColumn(stringDataType, columnName2);

        List<DataColumn> columns = Lists.newArrayList(dataColumn, dataColumn2);
        DataTable dataTable = new DataTable("name", columns, newReflectiveDataRowPersistorFactory());
        RowValuesServices rowValuesServices = mock(RowValuesServices.class);
        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());
        dataRow.set(columnName, value);
        dataRow.set(columnName2, value2);

        assertThat(dataRow.get(columnName)).isSameAs(value);
        assertThat(dataRow.get(columnName2)).isSameAs(value2);
    }

    @Test
    public void testSetAValueForAStringColumnWithARestrictionWhenValuePassesRestrictionTheValueIsSet() {
        DataType stringDataType = stringDataType();
        String columnName = "column1";
        String value = "Hello";

        Restriction restriction = new StringLengthRestriction(5);
        Set<Restriction> restrictions = Sets.newHashSet(restriction);

        DataColumn dataColumn = newDataColumn(stringDataType, columnName, restrictions);

        List<DataColumn> columns = Lists.newArrayList(dataColumn);
        DataTable dataTable = new DataTable("name", columns, newReflectiveDataRowPersistorFactory());
        RowValuesServices rowValuesServices = mock(RowValuesServices.class);
        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());
        dataRow.set(columnName, value);

        assertThat(dataRow.get(columnName)).isSameAs(value);
    }

    @Test
    public void testSetAValueForAStringColumnWithARestrictionWhenValueNotPassesRestrictionTheValueIsNotSet() {
        DataType stringDataType = stringDataType();
        String columnName = "column1";
        String value = "Hello";

        Restriction lengthRestriction = new StringLengthRestriction(2);
        Set<Restriction> restrictions = Sets.newHashSet(lengthRestriction);

        DataColumn dataColumn = newDataColumn(stringDataType, columnName, restrictions);

        List<DataColumn> columns = Lists.newArrayList(dataColumn);
        DataTable dataTable = new DataTable("name", columns, newReflectiveDataRowPersistorFactory());
        RowValuesServices rowValuesServices = mock(RowValuesServices.class);
        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());

        try {
            dataRow.set(columnName, value);
            fail();
        } catch (RuntimeException e) {
            assertThat(e.getMessage()).isSameAs(Restriction.ERROR_RESTRICTION_VIOLATION);
            assertThat(dataRow.get(columnName)).isNull();
        }
    }

    @Test
    public void testUpdateCallsSetForEachColumnOfTheTableThatComesInTheData_WhenUpdatingDataOfRow() {
        // @Given a row and data to update it
        List<DataColumn> columns = Lists.newArrayList(newDataColumn(stringDataType(), "One"), newDataColumn(stringDataType(), "Two"));
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("tableName", columns, dataRowPersistorFactory);
        Object rowValues = new Object();
        DataRow dataRow = new DataRow(dataTable, rowValues);
        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put("One", "Hi");
        rowData.put("Two", "Hello");

        // @When the row is updated
        dataRow.update(rowData);

        // @Then set is called as many times as the amount of columns the table has
        verify(dataRowPersistor, times(2)).set(Matchers.<Object>any(), Matchers.<String>any(), Matchers.<Object>any());
    }

    @Test
    public void testUpdateCallsSetForEachRowDataValue_WhenUpdatingDataOfRowWithAllValidColumns() {
        // @Given a row and data to update it
        List<DataColumn> columns = Lists.newArrayList(newDataColumn(stringDataType(), "One"), newDataColumn(stringDataType(), "Two"));
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("tableName", columns, dataRowPersistorFactory);
        Object rowValues = new Object();
        DataRow dataRow = new DataRow(dataTable, rowValues);
        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put("One", "1");
        rowData.put("Two", "2");

        // @When the row is updated
        dataRow.update(rowData);

        // @Then set is called as many times as the amount of columns the table has
        verify(dataRowPersistor, times(1)).set(rowValues, "One", "1");
        verify(dataRowPersistor, times(1)).set(rowValues, "Two", "2");
    }

    @Test
    public void testRowAcceptsIntegerLongBigDecimalAsValues_WhenSettingNumericColumns() {
        DataColumn dataColumn1 = newDataColumn(numericDatatype(), "numeric1");
        DataColumn dataColumn2 = newDataColumn(numericDatatype(), "numeric2");
        DataColumn dataColumn3 = newDataColumn(numericDatatype(), "numeric3");
        DataColumn dataColumn4 = newDataColumn(numericDatatype(), "numeric4");

        List<DataColumn> columns = Lists.newArrayList(dataColumn1, dataColumn2, dataColumn3, dataColumn4);
        DataTable dataTable = new DataTable("name", columns, newReflectiveDataRowPersistorFactory());
        RowValuesServices rowValuesServices = mock(RowValuesServices.class);
        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());
        Integer integer = 12;
        Long aLong = (long) 98;
        String aString = "100";

        dataRow.set(dataColumn1.getName(), integer);
        BigDecimal bigDecimal = BigDecimal.valueOf(2502, 2);
        dataRow.set(dataColumn2.getName(), aLong);
        dataRow.set(dataColumn3.getName(), bigDecimal);
        dataRow.set(dataColumn4.getName(), aString);

        assertThat(dataRow.get(dataColumn1.getName())).isSameAs(integer);
        assertThat(dataRow.get(dataColumn2.getName())).isSameAs(aLong);
        assertThat(dataRow.get(dataColumn3.getName())).isSameAs(bigDecimal);
        assertThat(dataRow.get(dataColumn3.getName())).isSameAs(bigDecimal);
    }

    @Test
    public void testSetLoadedCallsPersistorSetLoadedWithThisAndTrue_WhenSettingLoadedToTrue() {
        // @Given a data row
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        DataRow dataRow = new DataRow(dataTable);
        boolean loaded = true;

        // @When setting loaded to true
        dataRow.setLoaded(loaded);

        // @The datarowPeristor.setLoaded is called with the row and true as param
        verify(dataRowPersistor, times(1)).setLoaded(dataRow.getRowValues(), loaded);
    }

    @Test
    public void testSetLoadedCallsPersistorSetLoadedWithThisAndFalse_WhenSettingLoadedToFalse() {
        // @Given a data row
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        DataRow dataRow = new DataRow(dataTable);
        boolean loaded = false;

        // @When setting loaded to true
        dataRow.setLoaded(loaded);

        // @The datarowPeristor.setLoaded is called with the row and true as param
        verify(dataRowPersistor, times(1)).setLoaded(dataRow.getRowValues(), loaded);
    }

    @Test
    public void testGetServiceCenterCallsPersistorGetServiceCenterWithRowValues_WhenGettingServiceCenter() {
        // @Given a data row with it's rowValues
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        DataRow dataRow = new DataRow(dataTable);

        // @When getting the service center of the row
        dataRow.getServiceCenter();

        // @Then dataRowPersitor.getServiceCenter(rowValues) is called
        verify(dataRowPersistor, times(1)).getServiceCenter(dataRow.getRowValues());
    }

    @Test
    public void testGetServiceCenterReturnsTheServiceCenterObtainedByThePersistor_WhenGettingTheServiceCenter() {
        // @Given a data row with it's rowValues
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        DataRow dataRow = new DataRow(dataTable);
        ServiceCenter expectedServiceCenter = new ServiceCenter();
        when(dataRowPersistor.getServiceCenter(dataRow.getRowValues())).thenReturn(expectedServiceCenter);

        // @When getting the service center of the row
        ServiceCenter serviceCenter = dataRow.getServiceCenter();

        // @Then dataRowPersitor.getServiceCenter(rowValues) is called
        assertThat(serviceCenter).isSameAs(dataRowPersistor.getServiceCenter(dataRow.getRowValues()));
    }

    @Test
    public void testGetServiceCenterCallsPersistorSetServiceCenterWithRowValues_WhenSettingServiceCenter() {
        // @Given a data row with it's rowValues
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        DataRow dataRow = new DataRow(dataTable);
        ServiceCenter serviceCenter = new ServiceCenter();

        // @When getting the service center of the row
        dataRow.setServiceCenter(serviceCenter);

        // @Then dataRowPersitor.getServiceCenter(rowValues) is called
        verify(dataRowPersistor, times(1)).setServiceCenter(dataRow.getRowValues(), serviceCenter);
    }

    @Test
    public void testGetPointOfSaleCallsPersistorGetPointOfSaleWithRowValues_WhenGettingPointOfSale() {
        // @Given a data row with it's rowValues
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        DataRow dataRow = new DataRow(dataTable);

        // @When getting the pointOfSale of the row
        dataRow.getPointOfSale();

        // @Then dataRowPersitor.getPointOfSale(rowValues) is called
        verify(dataRowPersistor, times(1)).getPointOfSale(dataRow.getRowValues());
    }

    @Test
    public void testGetPointOfSaleCallsPersistorSetPointOfSaleWithRowValues_WhenSettingPointOfSale() {
        // @Given a data row with it's rowValues
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        DataRow dataRow = new DataRow(dataTable);
        PointOfSale pointOfSale = new PointOfSale();

        // @When getting the service center of the row
        dataRow.setPointOfSale(pointOfSale);

        // @Then dataRowPersitor.getPointOfSale(rowValues) is called
        verify(dataRowPersistor, times(1)).setPointOfSale(dataRow.getRowValues(), pointOfSale);
    }

    @Test
    public void testGetPointOfSaleReturnsThePointOfSaleObtainedByThePersistor_WhenGettingThePointOfSale() {
        // @Given a data row with it's rowValues
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        DataRow dataRow = new DataRow(dataTable);
        PointOfSale expectedPointOfSale = new PointOfSale();
        when(dataRowPersistor.getPointOfSale(dataRow.getRowValues())).thenReturn(expectedPointOfSale);

        // @When getting the service center of the row
        PointOfSale PointOfSale = dataRow.getPointOfSale();

        // @Then dataRowPersitor.getPointOfSale(rowValues) is called
        assertThat(PointOfSale).isSameAs(dataRowPersistor.getPointOfSale(dataRow.getRowValues()));
    }

    @Test
    public void testMergeCallsSetOnceForEachColumnThatIsNotManual_WhenMergingRows() {
        // @Given a data table with 4 columns where one is manual
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataColumn column1 = new DataColumn("name1", serviceCenterDataType());
        DataColumn column2 = new DataColumn("name2", pointOfSaleDataType());
        DataColumn column3 = new DataColumn("name3", stringDataType());
        DataColumn columnManual = new DataColumn("name4", stringDataType());
        columnManual.setManual(true);
        DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(column1, column2, column3, columnManual), dataRowPersistorFactory);
        DataRow dataRow = new DataRow(dataTable);
        DataRow dataRow2 = new DataRow(dataTable);

        // @When merging
        dataRow.merge(dataRow2);

        //@Then dataRowPersistor set is called 3 times
        verify(dataRowPersistor, times(3)).set(Matchers.<Object>any(), Matchers.<String>any(), Matchers.<Object>any());
    }

    @Test
    public void testToString() {
        DataTable dataTable = new DataTable();
        final DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistor.getInternalId(Matchers.<Object>any())).thenReturn(1);
        when(dataRowPersistor.getManual(Matchers.<DataRow>any())).thenReturn(true);
        dataTable.setDataRowPersistorFactory(new DataRowPersistorFactory() {
            @Override
            public DataRowPersistor buildDataRowPersistor(DataTable dataTable) {
                return dataRowPersistor;
            }
        });
        DataColumn column1 = new DataColumn("column1", stringDataType());
        DataColumn column2 = new DataColumn("column2", stringDataType());
        DataColumn column3 = new DataColumn("column3", stringDataType());
        DataColumn column4 = new DataColumn("column4", stringDataType());

        dataTable.setColumns(Lists.newArrayList(column1, column2, column3, column4));
        Map<String, Object> rowValues = Maps.newHashMap();
        rowValues.put(column1.getName(), "A");
        rowValues.put(column2.getName(), "B");
        rowValues.put(column3.getName(), "C");
        rowValues.put(column4.getName(), "D");

        DataRow dataRow = new DataRow(dataTable, rowValues);
        assertThat(dataRow.toString()).isEqualTo("DataRow{rowValues={column1=A, column3=C, column2=B, column4=D}, dataTable=DataTable{id=null, name='null', campaign=null, allowRecordCreation=false, loadSql='null', loadScript='null', scheduled=false}}");
    }

    public DataType serviceCenterDataType() {
        DataType dataType = new DataType();
        dataType.setCode("SC");
        dataType.setName("Service Center");
        dataType.setFilterable(true);
        dataType.setHasMinSize(false);
        dataType.setHasOptions(false);
        dataType.setHasPrecision(false);
        dataType.setHasSize(false);
        dataType.setSortable(true);
        dataType.setInternalType(ServiceCenter.class);
        return dataType;
    }

    private DataType pointOfSaleDataType() {
        DataType dataType = new DataType();
        dataType.setCode("POS");
        dataType.setName("Point of Sale");
        dataType.setInternalType(PointOfSale.class);
        return dataType;
    }

    private DataRowPersistorFactory newReflectiveDataRowPersistorFactory() {
        return new DataRowPersistorFactory() {

            @Override
            public DataRowPersistor buildDataRowPersistor(DataTable dataTable) {
                return new SimpleDataRowPersistor(dataTable);
            }
        };
    }

    private DataColumn newDataColumn(DataType stringDataType, String columnName) {
        return new DataColumn(columnName, stringDataType);
    }

    private DataColumn newDataColumn(DataType stringDataType, String columnName, Set<Restriction> restrictions) {
        return new DataColumn(columnName, stringDataType, restrictions);
    }

    private DataType stringDataType() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("string");
        field("internalType").ofType(Class.class).in(dataType).set(String.class);
        return dataType;
    }

    private DataType numericDatatype() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("number");
        field("internalType").ofType(Class.class).in(dataType).set(BigDecimal.class);
        return dataType;
    }
}
