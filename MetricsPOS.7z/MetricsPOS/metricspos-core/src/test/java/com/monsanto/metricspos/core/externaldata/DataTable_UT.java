package com.monsanto.metricspos.core.externaldata;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.DataRowVO;
import com.monsanto.metricspos.core.externaldata.testclasses.SimpleDataRowPersistor;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistor;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import com.monsanto.metricspos.persistence.RowValuesServices;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Matchers;

import java.math.BigDecimal;
import java.util.*;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * @author PPERA
 */
public class DataTable_UT {
    private HashMap<String, DataType> dataTypeMap;
    private RowValuesServices rowValuesServices;
    private DataRowPersistor dataRowPersistor;
    private DataRowPersistorFactory dataRowPersistorFactory;

    @Before
    public void setUp() {
        dataTypeMap = Maps.newHashMap();
        dataTypeMap.put("string", stringDataType());
        dataTypeMap.put("date", dateDataType());
        dataTypeMap.put("bigDecimal", bigDecimalDataType());
        dataTypeMap.put("integer", integerDataType());
        dataTypeMap.put("object", objectDataType());

        dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);

        dataRowPersistor = mock(DataRowPersistor.class);

        rowValuesServices = mock(RowValuesServices.class);
    }

    @Test
    public void testWhenCreateATableWithOneColumnThenTheTableHasTheColumn() {
        String colName1 = "colName1";
        DataType dataType = stringDataType();
        DataColumn dataColumn = newDataColumn(colName1, dataType);

        // When
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn), newDataRowPersistorFactory());

        // Then
        assertThat(dataTable.getColumns()).hasSize(1);
        assertThat(dataTable.getColumn(colName1).getName()).isSameAs(colName1);
    }

    @Test
    public void testWhenCreateATableWithOneColumnThenTheTableHasNotOtherColumn() {
        String colName1 = "colName1";
        DataType dataType = stringDataType();
        DataColumn dataColumn = newDataColumn(colName1, dataType);

        // When
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn), newDataRowPersistorFactory());

        // Then
        assertThat(dataTable.getColumns()).hasSize(1);
        assertThat(dataTable.getColumn(colName1).getName()).isSameAs(colName1);
    }

    @Test
    public void testWhenCreateATableWithColumnThenTheTableHasBothColumns() {
        String colName1 = "colName1";
        DataType dataType1 = stringDataType();
        DataColumn dataColumn = newDataColumn(colName1, dataType1);
        String colName2 = "colName2";
        DataType dataType2 = stringDataType();
        DataColumn dataColumn2 = newDataColumn(colName2, dataType2);

        // When
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), newDataRowPersistorFactory());

        // Then
        assertThat(dataTable.getColumns()).hasSize(2);
        assertThat(dataTable.getColumn(colName1).getName()).isSameAs(colName1);
        assertThat(dataTable.getColumn(colName2).getName()).isSameAs(colName2);
    }


    @Test
    public void testWhenCreateATableWithOneColumnWhoseDataTypeIsIntegerThenTheTableHasAColumnWithADataTypeInteger() {
        String colName1 = "colName1";
        DataColumn integerColumn = newDataColumn(colName1, dataTypeMap.get("string"));

        // When
        DataTable dataTable = new DataTable("name", Lists.newArrayList(integerColumn), newDataRowPersistorFactory());

        // Then
        assertThat(dataTable.getColumns()).hasSize(1);
        assertThat(dataTable.getColumn(colName1).getName()).isSameAs(colName1);
        assertThat(dataTable.getColumn(colName1).getDataType()).isSameAs(dataTypeMap.get("string"));
    }

    @Test
    public void testWhenCreateATableWithTwoColumnWithDifferentDataTypesThenTheTableHasThoseTwoColumns() {
        String colName1 = "colName1";
        DataType dataType = dataTypeMap.get("integer");
        DataColumn integerColumn = newDataColumn(colName1, dataType);

        String colName2 = "colName2";
        DataType dataType2 = dataTypeMap.get("string");
        DataColumn stringColumn = newDataColumn(colName2, dataType2);

        // When
        DataTable dataTable = new DataTable("name", Lists.newArrayList(integerColumn, stringColumn), newDataRowPersistorFactory());

        // Then
        assertThat(dataTable.getColumns()).hasSize(2);
        assertThat(dataTable.getColumn(colName1).getName()).isSameAs(colName1);
        assertThat(dataTable.getColumn(colName1).getDataType()).isSameAs(dataType);
        assertThat(dataTable.getColumn(colName2).getName()).isSameAs(colName2);
        assertThat(dataTable.getColumn(colName2).getDataType()).isSameAs(dataType2);

    }

    @Test
    @Ignore
    public void testCannotCreateATableWithNoColumns() {
        try {
            new DataTable("name", Collections.<DataColumn>emptyList(), newDataRowPersistorFactory());
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).contains(BusinessException.ERROR_CANNOT_CREATE_TABLE_WITH_NO_COLUMNS);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testGivenATableWithColumns_WhenGetColumnNames_ThenAllNamesAreReturned() {
        // @given
        String colName1 = "colName1";
        DataType dataType1 = stringDataType();
        DataColumn dataColumn = newDataColumn(colName1, dataType1);
        String colName2 = "colName2";
        DataType dataType2 = stringDataType();
        DataColumn dataColumn2 = newDataColumn(colName2, dataType2);

        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), newDataRowPersistorFactory());

        // @When
        List<String> columnNames = dataTable.getColumnNames();

        // @Then
        assertThat(columnNames).isNotNull().contains("colName1", "colName2");
    }

    @Test
    public void testGetColumnThrowsException_WhenGettingAColumnByNameThatDoesNotExist() {
        // @Given a data table with columns
        String colName1 = "colName1";
        DataType dataType1 = stringDataType();
        DataColumn dataColumn = newDataColumn(colName1, dataType1);
        String colName2 = "colName2";
        DataType dataType2 = stringDataType();
        DataColumn dataColumn2 = newDataColumn(colName2, dataType2);

        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), newDataRowPersistorFactory());

        // @When getting a column with a non-matching name
        try {
            dataTable.getColumn("Rumpelstinskin");
            fail();
        } catch (Exception e) {
            // @Then an exception is thrown
            assertThat(e).isInstanceOf(MissingColumnException.class);
        }
    }

    @Test
    public void testFindRowsByPageCallsRowValuesRepositoryFindRowsByDataTableAndPageWithCurrentTable_WhenFindingRowsForATable() {
        // @Given a data table
        DataRowPersistorFactory dataRowPersistorFactory = new DataRowPersistorFactory() {

            @Override
            public DataRowPersistor buildDataRowPersistor(DataTable dataTable) {
                return dataRowPersistor;
            }
        };
        DataTable dataTable = new DataTable("name", Lists.newArrayList(newDataColumn("colName1", stringDataType()), newDataColumn("colName2", stringDataType())), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);

        when(dataRowPersistor.getActualColumnName("colName1")).thenReturn("text1");

        // @When finding rows by page
        Map<String, Object> filter = Maps.newHashMap();
        dataTable.findRowsByPage(1, 10, "colName1", "asc", filter);

        // @Then tableRepository.findRowsByDataTableAndPage is called
        verify(rowValuesServices, times(1)).findRowsByDataTableAndPage(dataTable, 1, 10, "text1", "asc", filter);
    }

    @Test
    public void testFindDataRowByIdCallsRowValuesRepositoryFindRowByTableIdAndRowIdWithBothIdsOne_WhenFindingRowWithIdOneForTableOne() {
        // @Given a table with id one containing a row with id one
        String colName1 = "colName1";
        DataType dataType1 = stringDataType();
        DataColumn dataColumn = newDataColumn(colName1, dataType1);
        String colName2 = "colName2";
        DataType dataType2 = stringDataType();
        DataColumn dataColumn2 = newDataColumn(colName2, dataType2);

        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), newDataRowPersistorFactory());
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);
        when(dataRowPersistorFactory.buildDataRowPersistor(dataTable)).thenReturn(dataRowPersistor);
        dataTable.setDataRowPersistorFactory(dataRowPersistorFactory);
        DataRow dataRow = new DataRow(dataTable);
        when(dataRowPersistor.getInternalId(dataRow.getRowValues())).thenReturn(1);

        // @When finding the row in a table
        dataTable.findRowById(dataRow.getInternalId());

        // @Then rowValuesServices.findRowByDataTableIdAndId(1,1) is invoked
        verify(rowValuesServices, times(1)).findDataRowByDataTableAndDataRowId(dataTable, 1);
    }

    @Test
    public void testNewRowCallsRowValuesServices_WhenCreatingANewRow() {
        // @Given a data table and data to create a row
        String colName1 = "colName1";
        DataType dataType1 = stringDataType();
        DataColumn dataColumn = newDataColumn(colName1, dataType1);
        String colName2 = "colName2";
        DataType dataType2 = stringDataType();
        DataColumn dataColumn2 = newDataColumn(colName2, dataType2);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);

        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(colName1, "Hello");

        // @When creating a row from that data
        dataTable.newRow(rowData);

        // @Then dataRowPersistor.makeRowValues is called
        verify(dataRowPersistor, times(1)).makeRowValues(rowData);

    }

    @Test
    public void testNewRowThrowsException_WhenCreatingANewRowWithMissingRequiredFields() {
        // @Given a data table and data to create a row
        DataColumn dataColumn = newDataColumn("colName1", stringDataType());
        dataColumn.setRequired(true);
        DataColumn dataColumn2 = newDataColumn("colName2", stringDataType());
        dataColumn2.setRequired(true);

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);

        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(dataColumn.getName(), "Hello");

        try {
            // @When creating a row from that data
            dataTable.newRow(rowData);
            fail();
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e.getErrorMessage()).contains(BusinessException.REQUIRED_COLUMN_CANNOT_BE_EMPTY);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testNewRowThrowsException_WhenCreatingANewRowWithMissingPKFields() {
        // @Given a data table and data to create a row
        DataColumn dataColumn = newDataColumn("colName1", stringDataType());
        dataColumn.setPrimaryKey(true);
        DataColumn dataColumn2 = newDataColumn("colName2", stringDataType());
        dataColumn2.setPrimaryKey(true);

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);

        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(dataColumn.getName(), "Hello");

        try {
            // @When creating a row from that data
            dataTable.newRow(rowData);
            fail();
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e.getErrorMessage()).contains(BusinessException.REQUIRED_COLUMN_CANNOT_BE_EMPTY);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testNewRowThrowsException_WhenCreatingANewRowWhereRowWithSamePKAlreadyExists() {
        // @Given a data table and data to create a row
        DataColumn dataColumn = newDataColumn("colName1", stringDataType());
        dataColumn.setPrimaryKey(true);
        DataColumn dataColumn2 = newDataColumn("colName2", stringDataType());
        dataColumn2.setPrimaryKey(true);

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);

        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(dataColumn.getName(), "Hello");
        rowData.put(dataColumn2.getName(), "Hello");

        DataRow dataRow = new DataRow(dataTable, new Object());
        when(this.rowValuesServices.findByTableAndFilter(Matchers.<DataTable>any(), Matchers.<Map<String, Object>>any())).thenReturn(dataRow);

        try {
            // @When creating a row from that data
            dataTable.newRow(rowData);
            fail();
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e.getErrorMessage()).contains(BusinessException.DUPLICATE_PRIMARY_KEY);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testNewRowThrowsException_WhenCreatingANewRowWithNullRequiredFields() {
        // @Given a data table and data to create a row
        DataColumn dataColumn = newDataColumn("colName1", stringDataType());
        dataColumn.setRequired(true);
        DataColumn dataColumn2 = newDataColumn("colName2", stringDataType());
        dataColumn2.setRequired(true);

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);

        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(dataColumn.getName(), "Hello");
        rowData.put(dataColumn2.getName(), null);

        try {
            // @When creating a row from that data
            dataTable.newRow(rowData);
            fail();
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e.getErrorMessage()).contains(BusinessException.REQUIRED_COLUMN_CANNOT_BE_EMPTY);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testNewRowThrowsException_WhenCreatingANewRowAndDataDoesNotSpecify() {
        // @Given a data table and data to create a row
        DataColumn dataColumn = newDataColumn("colName1", enumDataType());
        dataColumn.setRequired(true);
        dataColumn.setOptions(Lists.<String>newArrayList("yes", "no"));


        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);

        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(dataColumn.getName(), "Hello");

        try {
            // @When creating a row from that data
            dataTable.newRow(rowData);
            fail();
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e.getErrorMessage()).contains(BusinessException.ENUM_COLUMN_VALUE_MUST_MATCH_OPTIONS);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testNewRowThrowsException_WhenCreatingANewRowAndColumnWithOptionsDoesNotMatchOptions() {
        // @Given a data table and data to create a row
        DataColumn dataColumn = newDataColumn("colName1", enumDataType());
        dataColumn.setRequired(true);
        dataColumn.setOptions(Lists.<String>newArrayList("yes", "no"));


        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);

        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(dataColumn.getName(), "Hello");

        try {
            // @When creating a row from that data
            dataTable.newRow(rowData);
            fail();
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e.getErrorMessage()).contains(BusinessException.ENUM_COLUMN_VALUE_MUST_MATCH_OPTIONS);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testNewRowThrowsException_WhenCreatingANewRowWithEmptyRequiredFields() {
        // @Given a data table and data to create a row
        DataColumn dataColumn = newDataColumn("colName1", stringDataType());
        dataColumn.setRequired(true);
        DataColumn dataColumn2 = newDataColumn("colName2", stringDataType());
        dataColumn2.setRequired(true);


        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);

        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(dataColumn.getName(), "Hello");
        rowData.put(dataColumn2.getName(), "");

        try {
            // @When creating a row from that data
            dataTable.newRow(rowData);
            fail();
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e.getErrorMessage()).contains(BusinessException.REQUIRED_COLUMN_CANNOT_BE_EMPTY);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testNewRowCallsRowValuesServicesAddWithADataRowLoadedWithMappedRowData_WhenCreatingANewRowWithRowData() {
        // @Given a data table and data to create a row
        String colName1 = "colName1";
        DataType dataType1 = stringDataType();
        DataColumn dataColumn = newDataColumn(colName1, dataType1);
        String colName2 = "colName2";
        DataType dataType2 = stringDataType();
        DataColumn dataColumn2 = newDataColumn(colName2, dataType2);

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);

        Map<String, Object> rowData = Maps.newHashMap();
        Object rowValues = new Object();
        when(dataRowPersistor.makeRowValues(rowData)).thenReturn(rowValues);
        rowData.put(colName1, "Hello");

        // @When creating a row from that data
        dataTable.newRow(rowData);

        // @Then dataRowPersistor.makeRowValues is called
        verify(rowValuesServices, times(1)).add(rowValues);
    }

    @Test
    public void testRemoveCallsRowValuesServicesRemoveForRowValues_WhenRemovingRowOwnerOfRowValues() {
        // @Given a table with id one
        String colName1 = "colName1";
        DataType dataType1 = stringDataType();
        DataColumn dataColumn = newDataColumn(colName1, dataType1);
        String colName2 = "colName2";
        DataType dataType2 = stringDataType();
        DataColumn dataColumn2 = newDataColumn(colName2, dataType2);

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);
        DataRow dataRow = new DataRow(dataTable, new Object());
        when(dataRowPersistor.getInternalId(dataRow)).thenReturn(1);

        // @When removing row 1
        dataTable.remove(dataRow);

        // @Then rowValuesServices.remove for the dataRow rowValues
        verify(this.rowValuesServices, times(1)).remove(dataRow.getRowValues());
    }

    @Test
    public void testUpdateDataRowCallsRowOneUpdateWithSameData_WhenUpdatingRowWithIdOne() {
        // @Given rowData
        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(DataRowVO.ROW_ID_KEY, "1");
        DataTable dataTable = buildTableWithTwoColumns();
        DataRow dataRow = mock(DataRow.class);
        when(dataTable.findRowById(Integer.valueOf((String) rowData.get(DataRowVO.ROW_ID_KEY)))).thenReturn(dataRow);

        // @When updating row one with that data
        dataTable.updateRow(rowData);

        // @Then row.update(data) is called
        dataRow.update(rowData);
    }

    @Test
    public void testMarkAllRecordsAsNotLoadedCallsRowValuesServicesMarkTableRecordsAsNotLoadedWithIdOne_WhenMarkingAllRecordsAsNotLoadedForTableOne() {
        // @Given a data table
        DataTable dataTable = new DataTable();
        dataTable.setRowValuesServices(this.rowValuesServices);
        dataTable.setId(1);

        // @When marking all it's records as loaded
        dataTable.markAllRecordsAsNotLoaded();

        // @Then rowValuesServices.markTableRecordsAsNotLoaded is called with the table id
        verify(this.rowValuesServices, times(1)).markTableRecordsAsNotLoaded(dataTable);
    }

    @Test
    public void testMarkAllRecordsAsNotLoadedReturns192_WhenTheResultOfTheServiceMarkTableRecordsAsNotLoadedIs192() {
        // @Given a data table
        DataTable dataTable = new DataTable();
        dataTable.setRowValuesServices(this.rowValuesServices);
        dataTable.setId(1);
        long rowsMarked = 192;
        when(this.rowValuesServices.markTableRecordsAsNotLoaded(dataTable)).thenReturn(rowsMarked);

        // @When marking all it's records as loaded
        long result = dataTable.markAllRecordsAsNotLoaded();

        // @Then rowValuesServices.markTableRecordsAsNotLoaded is called with the table id
        assertThat(result).isEqualTo(rowsMarked);
    }

    @Test
    public void testMarkAllRecordsAsNotLoadedReturns1_WhenTheResultOfTheServiceMarkTableRecordsAsNotLoadedIs1() {
        // @Given a data table
        DataTable dataTable = new DataTable();
        dataTable.setRowValuesServices(this.rowValuesServices);
        dataTable.setId(1);
        long rowsMarked = 1;
        when(this.rowValuesServices.markTableRecordsAsNotLoaded(dataTable)).thenReturn(rowsMarked);

        // @When marking all it's records as loaded
        long result = dataTable.markAllRecordsAsNotLoaded();

        // @Then rowValuesServices.markTableRecordsAsNotLoaded is called with the table id
        assertThat(result).isEqualTo(rowsMarked);
    }

    @Test
    public void testSaveOrUpdateCallsFindByTableAndFilter_WhenSavingOrUpdatingTheDataRowInATableThatHasPK() {
        // @Given a dataRow

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataColumn column = newDataColumn("name", stringDataType());
        column.setActualColumnName("text1");
        column.setPrimaryKey(true);
        DataTable dataTable = new DataTable("tableName", Lists.<DataColumn>newArrayList(column), dataRowPersistorFactory);
        dataTable.setRowValuesServices(this.rowValuesServices);
        DataRow dataRow = new DataRow(dataTable);

        // @When saving or updating the dataRow
        dataTable.saveOrUpdateRow(dataRow);

        // @Then services.saveOrUpdate is called
        verify(this.rowValuesServices, times(1)).findByTableAndFilterEvenDeleted(eq(dataTable), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testSaveOrUpdateCallsRowValuesServicesAdd_WhenSavingOrUpdatingTheDataRowAndTableHasNoPK() {
        // @Given a dataRow

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataColumn column = newDataColumn("name", stringDataType());
        column.setActualColumnName("text1");
        column.setPrimaryKey(true);
        DataTable dataTable = new DataTable("tableName", Lists.<DataColumn>newArrayList(column), dataRowPersistorFactory);
        dataTable.setRowValuesServices(this.rowValuesServices);
        Object rowValues = new Object();
        DataRow dataRow = new DataRow(dataTable, rowValues);

        // @When saving or updating the dataRow
        dataTable.saveOrUpdateRow(dataRow);

        // @Then services.saveOrUpdate is called
        verify(this.rowValuesServices, times(1)).add(rowValues);
    }

    @Test
    public void testSaveOrUpdateCallsRowValuesServicesSaveAndUpdateWithMatchingRow_WhenSavingOrUpdatingTheDataRowAndTableHasPK() {
        // @Given a dataRow

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataColumn column = newDataColumn("name", stringDataType());
        column.setActualColumnName("text1");
        column.setPrimaryKey(true);
        DataTable dataTable = new DataTable("tableName", Lists.<DataColumn>newArrayList(column), dataRowPersistorFactory);
        dataTable.setRowValuesServices(this.rowValuesServices);
        Object rowValues = new Object();
        DataRow dataRow = new DataRow(dataTable, rowValues);
        Object rowValues2 = new Object();
        DataRow dataRow2 = new DataRow(dataTable, rowValues2);
        when(this.rowValuesServices.findByTableAndFilterEvenDeleted(eq(dataTable), Matchers.<Map<String, Object>>any())).thenReturn(dataRow2);

        // @When saving or updating the dataRow
        dataTable.saveOrUpdateRow(dataRow);

        // @Then services.saveOrUpdate is called
        verify(this.rowValuesServices, times(1)).saveOrUpdate(rowValues2);
    }

    @Test
    public void testRemoveAllNotLoadedRecordsCallsRowValuesServicesRemoveNotLoadedRecordsOfTableWithIdOne_WhenRemovingNotLoadedRecordsOfTableOne() {
        // @Given a data table with id one

        DataTable dataTable = new DataTable("tableName", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        dataTable.setRowValuesServices(this.rowValuesServices);
        dataTable.setId(1);

        // @When removing not loaded records
        dataTable.removeAllNotLoadedRecords();

        // then rowValuesServices.removeNotLoadedRecordForTable is called with id one
        verify(this.rowValuesServices, times(1)).removeAllNotLoadedRecordsForTable(dataTable);
    }

    @Test
    public void testRemoveAllNotLoadedRecordsReturnsOne_WhenRemovingNotLoadedRecordsOfTableReturnsOne() {
        // @Given a data table with id one

        DataTable dataTable = new DataTable("tableName", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        dataTable.setRowValuesServices(this.rowValuesServices);
        dataTable.setId(1);
        when(this.rowValuesServices.removeAllNotLoadedRecordsForTable(dataTable)).thenReturn(1l);

        // @When removing not loaded records
        long result = dataTable.removeAllNotLoadedRecords();

        // then rowValuesServices.removeNotLoadedRecordForTable is called with id one
        assertThat(result).isEqualTo(1l);
    }

    @Test
    public void testRemoveAllNotLoadedRecordsReturns152_WhenRemovingNotLoadedRecordsOfTableReturns152() {
        // @Given a data table with id one

        DataTable dataTable = new DataTable("tableName", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        dataTable.setRowValuesServices(this.rowValuesServices);
        dataTable.setId(1);
        when(this.rowValuesServices.removeAllNotLoadedRecordsForTable(dataTable)).thenReturn(152l);

        // @When removing not loaded records
        long result = dataTable.removeAllNotLoadedRecords();

        // then rowValuesServices.removeNotLoadedRecordForTable is called with id one
        assertThat(result).isEqualTo(152l);
    }

    @Test
    public void testMakePkFilterFromRowReturnsOneFilter_WhenOneColumnIsPk() {
        // @Given a row in a table with one pk
        DataColumn dataColumn = newDataColumn("colName1", stringDataType());
        dataColumn.setActualColumnName("text1");
        dataColumn.setPrimaryKey(true);
        DataColumn dataColumn2 = newDataColumn("colName2", stringDataType());
        dataColumn2.setActualColumnName("text2");

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);
        DataRow dataRow = new DataRow(dataTable, new Object());
        when(dataRowPersistor.getInternalId(dataRow)).thenReturn(1);

        // @When making the filter by Pk
        Map<String, Object> filter = dataTable.makePkFilterFromRow(dataRow);

        // @Then one filter is returned
        assertThat(filter).hasSize(1);
        assertThat(filter.get(dataColumn.getName())).isEqualTo(dataRow.get(dataColumn.getName()));
    }

    @Test
    public void testMakePkFilterFromRowReturnsTwoFilter_WhenTwoColumnsArePk() {
        // @Given a row in a table with one pk
        DataColumn dataColumn = newDataColumn("colName1", stringDataType());
        dataColumn.setActualColumnName("text1");
        dataColumn.setPrimaryKey(true);
        DataColumn dataColumn2 = newDataColumn("colName2", stringDataType());
        dataColumn2.setActualColumnName("text2");
        dataColumn2.setPrimaryKey(true);

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);
        DataRow dataRow = new DataRow(dataTable, new Object());
        when(dataRowPersistor.getInternalId(dataRow)).thenReturn(1);

        // @When making the filter by Pk
        Map<String, Object> rowFilterConditions = dataTable.makePkFilterFromRow(dataRow);

        // @Then one filter is returned
        assertThat(rowFilterConditions).hasSize(2);
        assertThat(rowFilterConditions.keySet()).contains(dataColumn.getName(), dataColumn2.getName());
    }

    @Test
    public void testCleanColumnContentsCallsRowValuesServicesCleanColumnContents_WhenColumnTypeIsNotPointOfSale() {
        DataColumn dataColumn = newDataColumn("colName1", stringDataType());
        dataColumn.setActualColumnName("text1");
        dataColumn.setPrimaryKey(true);
        DataColumn dataColumn2 = newDataColumn("colName2", stringDataType());
        dataColumn2.setActualColumnName("text2");
        dataColumn2.setPrimaryKey(true);

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);

        dataTable.cleanColumnContents(Lists.<DataColumn>newArrayList(dataColumn));

        verify(this.rowValuesServices, times(1)).cleanColumnContents(dataTable, dataColumn);
    }

    @Test
    public void testCleanColumnContentsCallsRowValuesServicesClearPointsOfSale_WhenColumnTypeIsPointOfSale() {
        DataColumn dataColumn = newDataColumn("colName1", stringDataType());
        dataColumn.setActualColumnName("text1");
        dataColumn.setPrimaryKey(true);
        DataColumn dataColumn2 = newDataColumn("colName2", pointOfSaleDataType());
        dataColumn2.setActualColumnName("text2");
        dataColumn2.setPrimaryKey(true);

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);

        dataTable.cleanColumnContents(Lists.<DataColumn>newArrayList(dataColumn2));

        verify(this.rowValuesServices, times(1)).clearPointsOfSale(dataTable);
    }

    @Test
    public void testFindRowsCallsRowValuesServicesFindRowsForTableOneAndSC10_WhenFindingAllRowsOfSc10InTableOne() {
        // @Given a data table with id one and a service center with cuit 10
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);

        // @When finding the rows of that SC in the table
        dataTable.findRowsByServiceCenter(serviceCenter);

        // @Then rowValuesServices.findRowsByTableAndServiceCenter is called with Table one and SC 10
        verify(this.rowValuesServices, times(1)).findRowsByTableAndServiceCenter(dataTable, serviceCenter);
    }

    @Test
    public void testFindRowsCallsRowValuesServicesFindRowsForTable5AndSC11_WhenFindingAllRowsOfSc11InTable5() {
        // @Given a data table with id one and a service center with cuit 10
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("11");
        DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(5);

        // @When finding the rows of that SC in the table
        dataTable.findRowsByServiceCenter(serviceCenter);

        // @Then rowValuesServices.findRowsByTableAndServiceCenter is called with Table 5 and SC 11
        verify(this.rowValuesServices, times(1)).findRowsByTableAndServiceCenter(dataTable, serviceCenter);
    }

    @Test
    public void testFindRowsReturnsRowValuesServicesFindRowsForTable5AndSC11_WhenFindingAllRowsOfSc11InTable5() {
        // @Given a data table with id one and a service center with cuit 10
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("11");
        DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        dataTable.setId(5);
        dataTable.setRowValuesServices(rowValuesServices);
        DataRow dataRow = new DataRow(dataTable, new Object());
        when(this.rowValuesServices.findRowsByTableAndServiceCenter(dataTable, serviceCenter)).thenReturn(Lists.<DataRow>newArrayList(dataRow));

        // @When finding the rows of that SC in the table
        List<DataRow> dataRows = dataTable.findRowsByServiceCenter(serviceCenter);

        // @Then rowValuesServices.findRowsByTableAndServiceCenter is called with Table 5 and SC 11
        assertThat(dataRows).isEqualTo(this.rowValuesServices.findRowsByTableAndServiceCenter(dataTable, serviceCenter));
    }

    @Test
    public void testFindRowsCallsRowValuesServicesFindRowsForTable5_WhenFindingAllRowsOfTable5() {
        // @Given a data table
        DataRowPersistorFactory dataRowPersistorFactory = new DataRowPersistorFactory() {

            @Override
            public DataRowPersistor buildDataRowPersistor(DataTable dataTable) {
                return dataRowPersistor;
            }
        };
        DataTable dataTable = new DataTable("name", Lists.newArrayList(newDataColumn("colName1", stringDataType()), newDataColumn("colName2", stringDataType())), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);

        when(dataRowPersistor.getActualColumnName("colName1")).thenReturn("colName1");

        Map<String, Object> filter = Maps.newHashMap();
        // @When finding the rows of the table
        dataTable.findRows("colName1", "asc", filter);

        // @Then rowValuesServices.findRowsByTableAndServiceCenter is called with Table 5 and SC 11
        verify(this.rowValuesServices, times(1)).findRowsByDataTable(dataTable, "colName1", "asc", filter);
    }

    @Test
    public void testToString() {
        DataTable dataTable = new DataTable("name", Lists.newArrayList(newDataColumn("colName1", stringDataType()), newDataColumn("colName2", stringDataType())), dataRowPersistorFactory);
        assertThat(dataTable.toString()).isEqualTo("DataTable{id=null, name='name', campaign=null, allowRecordCreation=false, loadSql='null', loadScript='null', scheduled=false}");
    }


    private DataTable buildTableWithTwoColumns() {
        String colName1 = "colName1";
        DataType dataType1 = stringDataType();
        DataColumn dataColumn = newDataColumn(colName1, dataType1);
        String colName2 = "colName2";
        DataType dataType2 = stringDataType();
        DataColumn dataColumn2 = newDataColumn(colName2, dataType2);

        DataTable dataTable = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(1);
        return dataTable;

    }

    private DataRowPersistorFactory newDataRowPersistorFactory() {
        return new DataRowPersistorFactory() {

            @Override
            public DataRowPersistor buildDataRowPersistor(DataTable dataTable) {
                return new SimpleDataRowPersistor(dataTable);
            }
        };
    }

    private DataType stringDataType() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("string");
        field("internalType").ofType(Class.class).in(dataType).set(String.class);
        return dataType;
    }

    private DataType pointOfSaleDataType() {
        DataType dataType = new DataType();
        dataType.setCode("POS");
        dataType.setInternalType(PointOfSale.class);
        return dataType;
    }

    private DataType integerDataType() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("integer");
        field("internalType").ofType(Class.class).in(dataType).set(Integer.class);
        return dataType;
    }

    private DataType dateDataType() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("date");
        field("internalType").ofType(Class.class).in(dataType).set(Date.class);
        return dataType;
    }

    private DataType bigDecimalDataType() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("bigDecimal");
        field("internalType").ofType(Class.class).in(dataType).set(BigDecimal.class);
        return dataType;
    }

    private DataType objectDataType() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("object");
        field("internalType").ofType(Class.class).in(dataType).set(Object.class);
        return dataType;
    }

    private DataType enumDataType() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("enum");
        field("internalType").ofType(Class.class).in(dataType).set(String.class);
        dataType.setHasOptions(true);
        return dataType;
    }

    private DataColumn newDataColumn(String columnName, DataType dataType) {
        return new DataColumn(columnName, dataType);
    }
}
