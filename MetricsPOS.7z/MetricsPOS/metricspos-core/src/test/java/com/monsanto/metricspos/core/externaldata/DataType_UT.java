package com.monsanto.metricspos.core.externaldata;

import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

/**
 * User: PPERA
 */
public class DataType_UT {
    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        DataType instance = new DataType();
        tester.testInstance(instance);
    }
}
