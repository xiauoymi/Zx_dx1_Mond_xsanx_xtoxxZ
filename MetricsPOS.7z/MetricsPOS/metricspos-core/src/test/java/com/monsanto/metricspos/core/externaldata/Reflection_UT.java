package com.monsanto.metricspos.core.externaldata;

import com.monsanto.metricspos.core.externaldata.testclasses.TestClass;
import org.junit.Test;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Complete please !!
 *
 * @author CAFAU
 */
public class Reflection_UT {

    @Test
    public void testAccessAFiled() throws Exception {
        TestClass testClass = new TestClass();

        String hello = "Hello";
        testClass.setColumn1(hello);

        Field nameField = ReflectionUtils.findField(TestClass.class, "column1");

        ReflectionUtils.makeAccessible(nameField);
        assertThat(ReflectionUtils.getField(nameField, testClass)).isEqualTo(hello);
    }

    @Test
    public void testSetField() throws Exception {
        TestClass testClass = new TestClass();

        Field nameField = ReflectionUtils.findField(TestClass.class, "column1");

        ReflectionUtils.makeAccessible(nameField);
        String hello = "Hello";
        ReflectionUtils.setField(nameField, testClass, hello);

        assertThat(ReflectionUtils.getField(nameField, testClass)).isEqualTo(hello);
    }
}
