package com.monsanto.metricspos.core.externaldata;

import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class RowFilterCondition_UT {
    @Test
    public void testConstructorRemembersActualColumnNameTheDataTypeAndValue_WhenConstructingTheCondition() {
        // @Given an actualColumnName, a dataType and a value
        // @When constructing a condition
        RowFilterCondition stringCondition = new RowFilterCondition("name", stringDataType(), "hi");
        RowFilterCondition numberCondition = new RowFilterCondition("OtherName", numberDataType(), 10);

        // @Then the condition remembers the actualColumnName, the dataType and the value
        assertThat(stringCondition.getActualColumnName()).isEqualTo("name");
        assertThat(stringCondition.getDataType().getCode()).isEqualTo(stringDataType().getCode());
        assertThat(stringCondition.getValue()).isEqualTo("hi");
        assertThat(numberCondition.getActualColumnName()).isEqualTo("OtherName");
        assertThat(numberCondition.getDataType().getCode()).isEqualTo(numberDataType().getCode());
        assertThat(numberCondition.getValue()).isEqualTo(10);
    }

    private DataType numberDataType() {
        DataType dataType = new DataType();
        dataType.setCode("number");
        dataType.setInternalType(Integer.class);
        return dataType;
    }

    private DataType stringDataType() {
        DataType dataType = new DataType();
        dataType.setCode("string");
        dataType.setInternalType(String.class);
        return dataType;
    }


}
