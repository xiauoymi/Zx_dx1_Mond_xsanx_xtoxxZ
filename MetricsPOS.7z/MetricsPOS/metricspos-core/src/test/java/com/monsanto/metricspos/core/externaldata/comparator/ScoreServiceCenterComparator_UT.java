package com.monsanto.metricspos.core.externaldata.comparator;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.ComputeManager;
import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.externaldata.DataType;
import com.monsanto.metricspos.core.externaldata.RowFilterCondition;
import com.monsanto.metricspos.core.metrics.*;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.mock;

/**
 * User: SHELG
 */
public class ScoreServiceCenterComparator_UT {

    private ComputeManager computeManager;

    @Test
    public void testScoreServiceCenterComparator() {


        Campaign campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 3, 3));
        this.computeManager = mock(ComputeManager.class);
        campaign.setComputeManager(computeManager);
        MetricFactory factory = new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                Metric metric = new Metric(campaign, name);
                metric.setMaxPoints(maxPoints);
                metric.setComputeManager(computeManager);
                return metric;
            }
        };

        campaign.setFactory(factory);

        List<MetricScore> scores = Lists.newArrayList();

        ServiceCenter servCenter = new ServiceCenter();
        servCenter.setCampaign(campaign);
        servCenter.setCuit("20123456781");
        servCenter.setName("SCTEST1");

        Metric me = new Metric(campaign, "metric");
        MetricScore ms = new MetricScore(me, servCenter);
        Score s = new Score();
        s.setPoints(BigDecimal.valueOf(10));
        ms.setScores(s);
        Metric me2 = new Metric(campaign, "metric2");
        MetricScore ms2 = new MetricScore(me2, servCenter);
        Score s2 = new Score();
        s2.setPoints(BigDecimal.valueOf(11));
        ms2.setScores(s2);

        scores.add(ms);
        scores.add(ms2);

        servCenter.setScores(scores);

        ServiceCenter servCenter2 = new ServiceCenter();
        servCenter2.setCampaign(campaign);
        servCenter2.setCuit("20123456782");
        servCenter2.setName("SCTEST2");

        List<MetricScore> scores2 = Lists.newArrayList();

        Metric me02 = new Metric(campaign, "metric02");
        MetricScore ms02 = new MetricScore(me02, servCenter2);
        Score s02 = new Score();
        s02.setPoints(BigDecimal.valueOf(18));
        ms02.setScores(s02);
        Metric me022 = new Metric(campaign, "metric022");
        MetricScore ms022 = new MetricScore(me022, servCenter2);
        Score s022 = new Score();
        s022.setPoints(BigDecimal.valueOf(16));
        ms022.setScores(s022);

        scores2.add(ms02);
        scores2.add(ms022);

        servCenter2.setScores(scores2);

        List<ServiceCenter> listSC = new ArrayList<ServiceCenter>();
        listSC.add(servCenter);
        listSC.add(servCenter2);
        listSC.add(mock(ServiceCenter.class));
        listSC.add(mock(ServiceCenter.class));
        listSC.add(mock(ServiceCenter.class));
        listSC.add(mock(ServiceCenter.class));
        listSC.add(mock(ServiceCenter.class));
        listSC.add(mock(ServiceCenter.class));

        assertEquals(servCenter, listSC.get(0));
        ScoreServiceCenterComparator comp = new ScoreServiceCenterComparator();

        Collections.sort(listSC, comp);

        assertEquals(servCenter2, listSC.get(0));

        int compare = comp.compare(servCenter, servCenter2);

        assertFalse(compare == -1);

        int compare2 = comp.compare(servCenter2, servCenter);

        assertFalse(compare2 == 1);
    }

}
