package com.monsanto.metricspos.core.externaldata.converters;

import com.monsanto.metricspos.core.PointOfSaleServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.PointOfSale;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class DoubleToPointOfSaleConverter_UT {
    private DoubleToPointOfSaleConverter converter;
    private PointOfSaleServices pointOfSaleServices;
    private Campaign campaign;

    @Before
    public void setUp() {
        DoubleToPointOfSaleConverter converter_ = new DoubleToPointOfSaleConverter();
        converter_.setPointOfSaleServices(mock(PointOfSaleServices.class));
        this.campaign = new Campaign("name", newDate(2003, 5, 6), newDate(2005, 3, 4));
        this.converter = new DoubleToPointOfSaleConverter(campaign);
        this.pointOfSaleServices = mock(PointOfSaleServices.class);
        field("pointOfSaleServices").ofType(PointOfSaleServices.class).in(this.converter).set(this.pointOfSaleServices);
    }

    @Test
    public void testConvertCallsPointOfSaleServicesFindPointOfSaleWithidSap1813656AndCampaign_WhenConvertingAidSap1813656IntoAPointOfSale() {
        // @Given a idSap "1813656" and a converter with a campaign
        Double idSap = new Double("1813656");

        // @When converting the idSap to a service center
        this.converter.convert(idSap);

        // @Then services.findPointOfSaleByIdSap(idSap, campaign) is called
        verify(this.pointOfSaleServices, times(1)).findPointOfSaleByIdSap(Long.valueOf("1813656"), this.campaign);
    }

    @Test
    public void testConvertDoesNotCallPointOfSaleServicesFindPointOfSaleAndReturnsNull_WhenConvertingIdSapIsEmpty() {
        // @Given a idSap "" and a converter with a campaign
        Double idSap = Double.NaN;

        // @When converting the idSap to a service center
        PointOfSale pointOfSale = this.converter.convert(idSap);

        // @Then services.findPointOfSaleByIdSap(idSap, campaign) is called
        assertThat(pointOfSale).isNull();
        verify(this.pointOfSaleServices, times(0)).findPointOfSaleByIdSap(Matchers.<Long>any(), eq(this.campaign));
    }

}
