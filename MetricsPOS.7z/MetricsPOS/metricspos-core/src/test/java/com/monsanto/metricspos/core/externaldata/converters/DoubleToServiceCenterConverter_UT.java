package com.monsanto.metricspos.core.externaldata.converters;

import com.monsanto.metricspos.core.ServiceCenterServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import org.junit.Before;
import org.junit.Test;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: LOSICL
 * Date: 12/14/12
 * Time: 3:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class DoubleToServiceCenterConverter_UT {

    private DoubleToServiceCenterConverter converter;
    private ServiceCenterServices serviceCenterServices;
    private Campaign campaign;

    @Before
    public void setUp() {
        DoubleToServiceCenterConverter converter_ = new DoubleToServiceCenterConverter();
        converter_.setServiceCenterServices(mock(ServiceCenterServices.class));
        this.campaign = new Campaign("name", newDate(2003, 5, 6), newDate(2005, 3, 4));
        this.converter = new DoubleToServiceCenterConverter(campaign);
        this.serviceCenterServices = mock(ServiceCenterServices.class);
        field("serviceCenterServices").ofType(ServiceCenterServices.class).in(this.converter).set(this.serviceCenterServices);
    }

    @Test
    public void testConvertCallsServiceCenterServicesFindServiceCenterWithCuitTenAndCampaign_WhenConvertingACuitTenIntoAServiceCenter() {
        // @Given a Cuit "10" and a converter with a campaign
        Double cuit = new Double("10");

        // @When converting the cuit to a service center
        this.converter.convert(cuit);

        // @Then services.findServiceCenterBycuit(cuit, campaign) is called
        verify(this.serviceCenterServices, times(1)).findServiceCenterByCuit("10", this.campaign);
    }

    @Test
    public void testConvertCallsServiceCenterServicesFindServiceCenterWithCuitGreaterThan10exp3AndCampaign_WhenConvertingACuitGreaterThan10exp3IntoAServiceCenter() {
        // @Given a Cuit "9876543210" and a converter with a campaign
        Double cuit = new Double("9876543210");

        // @When converting the cuit to a service center
        this.converter.convert(cuit);

        // @Then services.findServiceCenterBycuit(cuit, campaign) is called
        verify(this.serviceCenterServices, times(1)).findServiceCenterByCuit("9876543210", this.campaign);
    }

    @Test
    public void testConvertCallsServiceCenterServicesFindServiceCenterWithCuitAsDoublePrimitiveAndCampaign_WhenConvertingACuitAsDoublePrimitiveIntoAServiceCenter() {
        // @Given a double 9876543210 and a converter with a campaign
        Double cuit = 9876543210d;

        // @When converting the cuit to a service center
        this.converter.convert(cuit);

        // @Then services.findServiceCenterBycuit(cuit, campaign) is called with the cuit in the correct format
        verify(this.serviceCenterServices, times(1)).findServiceCenterByCuit("9876543210", this.campaign);
    }




}
