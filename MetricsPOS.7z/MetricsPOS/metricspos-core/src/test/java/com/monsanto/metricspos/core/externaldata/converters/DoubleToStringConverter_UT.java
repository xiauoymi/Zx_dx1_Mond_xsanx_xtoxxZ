package com.monsanto.metricspos.core.externaldata.converters;

import org.junit.Before;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class DoubleToStringConverter_UT {
    private DoubleToStringConverter converter;

    @Before
    public void setUp() {
        this.converter = new DoubleToStringConverter();
    }

    @Test
    public void testConvertReturnsString1813656_WhenConvertingDouble1813656() {
        Double value = new Double("1813656");
        String result = this.converter.convert(value);

        assertThat(result).isEqualTo("1813656");
    }

}
