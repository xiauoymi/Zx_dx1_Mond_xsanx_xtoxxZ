package com.monsanto.metricspos.core.externaldata.converters;

import org.junit.Before;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

/**
 * User: PPERA
 */
public class StringToDateConverter_UT {
    private StringToDateConverter stringToDateconverter;

    @Before
    public void setUp() {
        stringToDateconverter = new StringToDateConverter();
    }

    @Test
    public void testConvertConvertsStringIntoDate_WhenStringIsDateInLongFormat() throws Exception {
        // @Given a Date in a string in long format
        String dateLong = "2012-06-08 11:22:43.234 AM";

        // @When converting the string
        Date date = this.stringToDateconverter.convert(dateLong);

        // @Then the string is converted into a matching date
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        assertThat(calendar.get(Calendar.DAY_OF_MONTH)).isEqualTo(8);
        assertThat(calendar.get(Calendar.MONTH)).isEqualTo(6 - 1);
        assertThat(calendar.get(Calendar.YEAR)).isEqualTo(2012);
        assertThat(calendar.get(Calendar.HOUR)).isEqualTo(11);
        assertThat(calendar.get(Calendar.MINUTE)).isEqualTo(22);
        assertThat(calendar.get(Calendar.SECOND)).isEqualTo(43);
        assertThat(calendar.get(Calendar.MILLISECOND)).isEqualTo(234);
    }

    @Test
    public void testConvertConvertsStringIntoDate_WhenStringIsDateInShortFormat() throws Exception {
        // @Given a Date in a string in long format
        String dateShort = "2013-01-23";

        // @When converting the string
        Date date = this.stringToDateconverter.convert(dateShort);

        // @Then the string is converted into a matching date
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        assertThat(calendar.get(Calendar.DAY_OF_MONTH)).isEqualTo(23);
        assertThat(calendar.get(Calendar.MONTH)).isEqualTo(0);
        assertThat(calendar.get(Calendar.YEAR)).isEqualTo(2013);
    }

    @Test
    public void testConvertConvertsStringIntoDate_WhenStringIsDateInRowDateFormat() throws Exception {
        // @Given a Date in a string in long format
        String rowDate = "11-05-2015";

        // @When converting the string
        Date date = this.stringToDateconverter.convert(rowDate);

        // @Then the string is converted into a matching date
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        assertThat(calendar.get(Calendar.DAY_OF_MONTH)).isEqualTo(11);
        assertThat(calendar.get(Calendar.MONTH)).isEqualTo(5 - 1);
        assertThat(calendar.get(Calendar.YEAR)).isEqualTo(2015);
    }

    @Test
    public void testConvertThrowsException_WhenStringIsInvalidDate() throws Exception {
        // @Given a Date in a string in long format
        String dateLong = "This is not a date eapp";

        // @When converting the string
        try {
            this.stringToDateconverter.convert(dateLong);
            fail();
        } catch (Exception e) {
            // @Then an exception is thrown
            assertThat(e).hasMessage("Invalid date: [This is not a date eapp]");
        }
    }

    @Test
    public void testConvertReturnsNull_WhenStringIsAnEmptyStringWithSpaces() throws Exception {
        String date = "   ";

        Date dateConverted = this.stringToDateconverter.convert(date);
        assertNull(dateConverted);

    }

    @Test
    public void testConvertReturnsNull_WhenStringLengthEqualsOne() throws Exception {
        String date = "L";

        Date dateConverted = this.stringToDateconverter.convert(date);
        assertNull(dateConverted);

    }
}
