package com.monsanto.metricspos.core.externaldata.converters;

import com.monsanto.metricspos.core.ServiceCenterServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.junit.Before;
import org.junit.Test;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class StringToServiceCenterConverter_UT {
    private StringToServiceCenterConverter converter;
    private ServiceCenterServices serviceCenterServices;
    private Campaign campaign;

    @Before
    public void setUp() {
        StringToServiceCenterConverter converter_ = new StringToServiceCenterConverter();
        converter_.setServiceCenterServices(mock(ServiceCenterServices.class));
        this.campaign = new Campaign("name", newDate(2003, 5, 6), newDate(2005, 3, 4));
        this.converter = new StringToServiceCenterConverter(campaign);
        this.serviceCenterServices = mock(ServiceCenterServices.class);
        field("serviceCenterServices").ofType(ServiceCenterServices.class).in(this.converter).set(this.serviceCenterServices);
    }

    @Test
    public void testConvertCallsServiceCenterServicesFindServiceCenterWithCuitTenAndCampaign_WhenConvertingACuitTenIntoAServiceCenter() {
        // @Given a Cuit "10" and a converter with a campaign
        String cuit = "10";

        // @When converting the cuit to a service center
        this.converter.convert(cuit);

        // @Then services.findServiceCenterBycuit(cuit, campaign) is called
        verify(this.serviceCenterServices, times(1)).findServiceCenterByCuit(cuit, this.campaign);
    }

    @Test
    public void testConvertReturnsTheServiceCenterFoundWhenFindingByCuit11_WhenConvertingACuit11IntoAServiceCenter() {
        // @Given a Cuit "10" and a converter with a campaign
        String cuit = "11";
        ServiceCenter expectedServiceCenter = new ServiceCenter();
        expectedServiceCenter.setCuit("11");
        when(this.serviceCenterServices.findServiceCenterByCuit(cuit, this.campaign)).thenReturn(expectedServiceCenter);

        // @When converting the cuit to a service center
        ServiceCenter serviceCenter = this.converter.convert(cuit);

        // @Then services.findServiceCenterBycuit(cuit, campaign) is called
        assertThat(serviceCenter).isSameAs(expectedServiceCenter);
    }
}
