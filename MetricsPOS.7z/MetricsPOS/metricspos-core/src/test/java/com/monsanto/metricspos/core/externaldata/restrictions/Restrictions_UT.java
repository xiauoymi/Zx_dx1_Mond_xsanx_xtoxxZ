package com.monsanto.metricspos.core.externaldata.restrictions;

import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * @author PPERA
 */
public class Restrictions_UT {
    @Test
    public void testStringLengthRestrictionPass() {
        Restriction<String> restriction = new StringLengthRestriction(10);
        assertThat(restriction.passes("Hi")).isTrue();
    }

    @Test
    public void testStringLengthRestrictionNotPass() {
        Restriction<String> restriction = new StringLengthRestriction(10);
        assertThat(restriction.passes("Well hello sir! How are we doing today!")).isFalse();
    }
}
