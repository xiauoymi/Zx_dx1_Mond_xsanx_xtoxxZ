package com.monsanto.metricspos.core.externaldata.testclasses;

import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataFile;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Simple DataRowPersistor to be used in tests
 */
// TODO get rid of this!!! Whenever posible of course...
public class SimpleDataRowPersistor implements DataRowPersistor {

    private static final String TABLE = "table";

    private DataTable dataTable;

    public SimpleDataRowPersistor(DataTable dataTable) {
        this.dataTable = dataTable;
    }

    @Override
    public void set(Object rowValues, String columnName, Object value) {
        HashMap<String, Object> data = (HashMap<String, Object>) rowValues;

        data.put(columnName, value);
    }

    @Override
    public Object get(Object rowValues, String columnName) {
        HashMap<String, Object> data = (HashMap<String, Object>) rowValues;

        return data.get(columnName);
    }

    @Override
    public Object newRowValues() {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put(TABLE, dataTable);
        return map;
    }

    @Override
    public String getActualColumnName(String columnName) {
        return columnName;
    }

    @Override
    public Integer getInternalId(Object rowValues) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Object makeRowValues(Map<String, Object> rowData) {
        return rowData;
    }

    @Override
    public boolean getManual(Object rowValues) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void setManual(Object rowValues, boolean manual) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void setLoaded(Object rowValues, boolean loaded) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public ServiceCenter getServiceCenter(Object rowValues) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void setServiceCenter(Object rowValues, ServiceCenter serviceCenter) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public PointOfSale getPointOfSale(Object rowValues) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void setPointOfSale(Object rowValues, PointOfSale pointOfSale) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public DataFile getDataFile(Object rowValues) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void assignActualColumnNames(List<DataColumn> dataColumns) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public String getServiceCenterColumnActualName() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void setDeleted(Object rowValues, boolean deleted) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
