package com.monsanto.metricspos.core.externaldata.testclasses;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author PPERA
 */
public class TestClass {
    private int intNum;
    private BigDecimal bigDecimal;
    private Date dateField;

    public String column1;
    private String column2;
    private String column3;
    private String column4;

    public int getIntNum() {
        return intNum;
    }

    public BigDecimal getBigDecimal() {
        return bigDecimal;
    }


    public void setColumn1(String column1) {
        this.column1 = column1;
    }

}
