package com.monsanto.metricspos.core.helpers;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.application.vo.CampaignVO;
import com.monsanto.metricspos.core.application.vo.DataColumnVO;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.application.vo.MetricVO;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.externaldata.DataType;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.CampaignState;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import com.monsanto.metricspos.persistence.RowValuesServices;

import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.mock;

/**
 * User: PPERA
 */
public class CoreTestsHelper {

    private DataProvider dataProvider;
    private Campaign campaign;
    private DataRowPersistorFactory dataRowPersistorFactory;

    public CoreTestsHelper(DataProvider dataProvider, Campaign campaign, DataRowPersistorFactory dataRowPersistorFactory) {
        this.dataProvider = dataProvider;
        this.campaign = campaign;
        this.dataRowPersistorFactory = dataRowPersistorFactory;
    }

    public Metric newMetric(String name) {
        return new Metric(this.campaign, name);
    }

    public MetricVO newMetricVO(String name, Integer maxPoints) {
        MetricVO metricVO = new MetricVO();
        metricVO.setName(name);
        metricVO.setMaxPoints(maxPoints);
        return metricVO;
    }

    public Campaign newCampaign(String name, Date since, Date until) {
        return new Campaign(name, since, until);
    }

    public CampaignVO newCampaignVO(int id, String name, Date since, Date until, CampaignState created) {
        CampaignVO campaignVO = new CampaignVO();
        campaignVO.setId(id);
        campaignVO.setName(name);
        campaignVO.setSince(since);
        campaignVO.setUntil(until);
        campaignVO.setState(created);
        return campaignVO;
    }

    public DataTable newDataTable(String name, String description) {
        return newDataTable(1, name, description, Lists.<DataColumn>newArrayList(), mock(RowValuesServices.class));
    }

    public DataTable newDataTable(int id, String tableName, String description, List<DataColumn> columns, RowValuesServices rowValuesServices) {
        DataTable dataTable = new DataTable(tableName, columns, dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);
        dataTable.setId(id);
        dataTable.setDescription(description);
        dataTable.setCampaign(campaign);
        dataTable.setDataProvider(dataProvider);
        return dataTable;
    }

    public DataTableVO newDataTableVO(Integer id, String name, String description) {
        DataTableVO dataTableVO = new DataTableVO();
        dataTableVO.setId(id);
        dataTableVO.setName(name);
        dataTableVO.setDescription(description);

        return dataTableVO;
    }

    public DataColumn newDataColumn(String columnName) {
        return new DataColumn(columnName, stringDataType());
    }

    public DataColumn newDataColumn(String columnName, DataType dataType, String columnDescription, int size, int minSize, int precision, boolean required, boolean sortable, boolean editable, boolean filterable) {
        DataColumn nameColumn = new DataColumn();
        nameColumn.setName(columnName);
        nameColumn.setDataType(dataType);
        nameColumn.setDescription(columnDescription);
        nameColumn.setMaxSize(size);
        nameColumn.setMinSize(minSize);
        nameColumn.setPrecision(precision);
        nameColumn.setRequired(required);
        nameColumn.setSortable(sortable);
        nameColumn.setEditable(editable);
        nameColumn.setFilterable(filterable);
        return nameColumn;
    }

    public DataColumn newDataColumn(Integer id, String columnName, DataType dataType, String columnDescription, int size, int minSize, int precision, boolean required, boolean sortable, boolean editable, boolean filterable) {
        DataColumn dataColumn = this.newDataColumn(columnName, dataType, columnDescription, size, minSize, precision, required, sortable, editable, filterable);
        dataColumn.setId(id);
        return dataColumn;
    }

    public DataColumnVO newDataColumnVO(String nameColumnName, String dataTypeCode, String columnDescription, int size, int minSize, int precision, boolean required, boolean sortable, boolean editable, boolean filterable) {
        DataColumnVO nameColumn = new DataColumnVO();
        nameColumn.setName(nameColumnName);
        nameColumn.setType(dataTypeCode);
        nameColumn.setDescription(columnDescription);
        nameColumn.setSize(size);
        nameColumn.setMinSize(minSize);
        nameColumn.setPrecision(precision);
        nameColumn.setRequired(required);
        nameColumn.setSortable(sortable);
        nameColumn.setEditable(editable);
        nameColumn.setFilterable(filterable);
        return nameColumn;
    }

    public DataColumnVO newDataColumnVO(Integer id, String nameColumnName, String dataTypeCode, String columnDescription, int size, int minSize, int precision, boolean required, boolean sortable, boolean editable, boolean filterable) {
        DataColumnVO dataColumnVO = newDataColumnVO(nameColumnName, dataTypeCode, columnDescription, size, minSize, precision, required, sortable, editable, filterable);
        dataColumnVO.setId(id);
        return dataColumnVO;
    }

    public ServiceCenter newServiceCenter(String cuit) {
        ServiceCenter expectedServiceCenter = new ServiceCenter();
        expectedServiceCenter.setCampaign(campaign);
        expectedServiceCenter.setCuit(cuit);
        return expectedServiceCenter;
    }

    public DataProvider newDataProvider(String code, String name) {
        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode(code);
        dataProvider.setName(name);
        return dataProvider;
    }

    public DataType stringDataType() {
        DataType dataType = new DataType();
        dataType.setCode("string");
        dataType.setName("Text");
        dataType.setFilterable(true);
        dataType.setHasMinSize(true);
        dataType.setHasOptions(false);
        dataType.setHasPrecision(true);
        dataType.setHasSize(true);
        dataType.setSortable(true);
        dataType.setInternalType(String.class);
        return dataType;
    }

    public DataType serviceCenterDataType() {
        DataType dataType = new DataType();
        dataType.setCode("SC");
        dataType.setName("Service Center");
        dataType.setFilterable(true);
        dataType.setHasMinSize(false);
        dataType.setHasOptions(false);
        dataType.setHasPrecision(false);
        dataType.setHasSize(false);
        dataType.setSortable(true);
        dataType.setInternalType(ServiceCenter.class);
        return dataType;
    }

    public DataType pointOfSaleDataType() {
        DataType dataType = new DataType();
        dataType.setCode("POS");
        dataType.setName("Point of Sale");
        dataType.setInternalType(PointOfSale.class);
        return dataType;
    }

    public DataType enumDataType() {
        DataType dataType = new DataType();
        dataType.setCode("ENUM");
        dataType.setName("Enum");
        dataType.setFilterable(true);
        dataType.setHasMinSize(false);
        dataType.setHasOptions(true);
        dataType.setHasPrecision(false);
        dataType.setHasSize(false);
        dataType.setSortable(true);
        dataType.setInternalType(String.class);
        return dataType;
    }
}
