package com.monsanto.metricspos.core.metrics;

import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

/**
 * User: PPERA
 */
public class CampaignParameter_UT {
        @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        CampaignParameter instance = new CampaignParameter();
        tester.testInstance(instance);
    }
}
