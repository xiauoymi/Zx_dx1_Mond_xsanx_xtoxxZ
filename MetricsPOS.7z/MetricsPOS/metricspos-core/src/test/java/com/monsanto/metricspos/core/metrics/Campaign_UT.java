package com.monsanto.metricspos.core.metrics;


import com.monsanto.metricspos.core.ComputeManager;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import java.util.Collection;
import java.util.Date;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * Test the Metrics Core
 *
 * @author CAFAU
 */
public class Campaign_UT {

    public static final String VALID_METRIC_NAME_1 = "metric 1";
    public static final String VALID_CAMPAIGN_NAME = "campaign name";

    private TestCoreEntitiesFactory coreEntitiesFactory = new TestCoreEntitiesFactory();

    @Test
    public void testWhenCreateANewCampaignThenCampaignIsEmpty() {
        // When
        Date start = new Date();
        Date end = new Date();
        Campaign campaign = new Campaign(VALID_CAMPAIGN_NAME, start, end);

        // Then
        assertThat(campaign.getName()).isEqualTo(VALID_CAMPAIGN_NAME);
        assertThat(campaign.getSince()).isEqualTo(start);
        assertThat(campaign.getUntil()).isEqualTo(end);
    }

    @Test
    public void testWhenCreateANewCampaignThenCampaignStateIsCreated() {
        // When
        Date start = new Date();
        Date end = new Date();
        Campaign campaign = new Campaign(VALID_CAMPAIGN_NAME, start, end);

        // Then
        assertThat(campaign.getState()).isEqualTo(CampaignState.CREATED);
    }

    @Test
    public void testWhenCreateANewCampaignThenCampaignHasNoneMetrics() throws Exception {
        // When
        Date start = new Date();
        Date end = new Date();
        Campaign campaign = new Campaign(VALID_CAMPAIGN_NAME, start, end);

        // Then
        assertThat(campaign.getMetrics()).isEmpty();
    }

    @Test
    public void testGivenNewCampaignWhenAddMetricThenHasNewMetricAlone() throws Exception {
        // Given
        Campaign campaign = coreEntitiesFactory.buildCampaign();

        // Then
        Collection<Metric> metrics = campaign.getMetrics();

        assertThat(metrics).hasSize(1);
        assertThat(metrics).onProperty("name").containsOnly("metric 1");
    }

    @Test
    public void testGivenNewCampaignWith1MetricWhenAddMetricThenHasTheTwoMetrics() throws Exception {
        // Given
        Campaign campaign = coreEntitiesFactory.buildCampaign();

        // When
        campaign.addMetricDefinition("metric 2", 458);

        // Then
        Collection<Metric> metrics = campaign.getMetrics();

        assertThat(metrics).hasSize(2).onProperty("name").containsOnly("metric 1", "metric 2");

    }

    @Test
    public void testGivenACampaignWhenAMetricIsAddedThenTheMetricHasTheCampaignAsReference() throws Exception {
        // Given
        Date start = new Date();
        Date end = new Date();
        Campaign campaign = new Campaign(VALID_CAMPAIGN_NAME, start, end);
        campaign.setFactory(coreEntitiesFactory.getFactory());

        // When
        campaign.addMetricDefinition("metric 1", 200);

        // Then
        Metric metric = campaign.getMetrics().iterator().next();

        assertThat(metric.getCampaign()).isEqualTo(campaign);

    }

    @Test
    public void testGivenACampaignWithMetricXWhenANewMetricIsAddedWithNameXThenCannotBeAdded() throws Exception {
        // Case should bot care
        // Given
        Campaign campaign = coreEntitiesFactory.buildCampaign();
        Metric metric = campaign.getMetrics().iterator().next();

        // When
        try {
            campaign.addMetricDefinition("meTRic 1", 100);
            fail("Campaign with same name cannot be added");
        } catch (BusinessException e) {
            // Then
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.DUPLICATE_METRIC_NAME);
            Collection<Metric> metrics = campaign.getMetrics();
            assertThat(metrics).hasSize(1).containsOnly(metric);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testGivenStartDateIsAfterEndDateWhenCreateCampaignThenCampaignCannotBeCreated() throws Exception {
        // Given
        Date start = newDate(2012, 11, 6);
        Date end = newDate(2012, 11, 5);

        try {
            // When
            new Campaign(VALID_CAMPAIGN_NAME, start, end);
            fail("Cannot create campaign with start date after end date");
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.START_END_DATE_EXCEPTION);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testGivenAnEmptyCampaignWhenAddAServiceCenterThenCampaignContainsOnlyIt() throws Exception {
        // Given
        Campaign campaign = coreEntitiesFactory.buildCampaign();

        ServiceCenter serviceCenter = new ServiceCenter();

        // When
        campaign.add(serviceCenter);

        // Then
        Collection<ServiceCenter> serviceCenters = campaign.getServiceCenters();

        assertThat(serviceCenters).hasSize(1).containsOnly(serviceCenter);
    }

    @Test
    public void testComputeRatingCallsComputeManagerComputeWith10PointsAndTheCampaing_WhenComputingTheRatingFor10Points() {
        // @Given ten points and a campaign
        Campaign campaign = coreEntitiesFactory.buildCampaign();
        ComputeManager computeManager = mock(ComputeManager.class);
        campaign.setComputeManager(computeManager);
        ScoreSummaryCampaignNode summary = mock(ScoreSummaryCampaignNode.class);

        // @When computing the rating for ten points
        campaign.computeRating(summary);

        // @Then teh compute manager is called with the campaign and a 10
        verify(computeManager, times(1)).compute(campaign, summary);
    }

    @Test
    public void testComputeRatingCallsComputeManagerComputeWith34PointsAndTheCampaing_WhenComputingTheRatingFor34Points() {
        // @Given ten points and a campaign
        Campaign campaign = coreEntitiesFactory.buildCampaign();
        ComputeManager computeManager = mock(ComputeManager.class);
        campaign.setComputeManager(computeManager);
        ScoreSummaryCampaignNode summary = mock(ScoreSummaryCampaignNode.class);

        // @When computing the rating for ten points
        campaign.computeRating(summary);

        // @Then teh compute manager is called with the campaign and a 10
        verify(computeManager, times(1)).compute(campaign, summary);
    }

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        Campaign instance = new Campaign();
        tester.testInstance(instance);
    }

    @Test
    public void testToString(){
        Campaign campaign = coreEntitiesFactory.buildCampaign();
        assertThat(campaign.toString()).isEqualTo("Campaign{id=null, name='campaign name', since="+campaign.getSince()+", until="+campaign.getUntil()+"}");
    }
}
