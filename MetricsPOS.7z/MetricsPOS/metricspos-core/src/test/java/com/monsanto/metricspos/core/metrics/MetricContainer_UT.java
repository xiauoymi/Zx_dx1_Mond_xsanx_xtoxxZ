package com.monsanto.metricspos.core.metrics;

import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class MetricContainer_UT {
    private MetricContainer metricContainer;
    private Metric metric;
    private Metric metric2;

    @Before
    public void setUp() {
        metric = new Metric();
        final List<Metric> metrics = Lists.newArrayList(metric);
        metric2 = new Metric();

        metricContainer = new MetricContainer() {

            @Override
            public void setMetrics(List<Metric> metrics) {

            }

            @Override
            protected Metric newMetric(String name, Integer maxPoints) {
                return null;
            }

            @Override
            protected List<Metric> internalGetMetrics() {
                return metrics;
            }
        };

        metric.setMetrics(Lists.newArrayList(metric2));
    }


    @Test
    public void testRemoveRemovesMetric_WhenMetricIsContainedInHere() throws Exception {
        // @Given a metric container with a metric


        // @When the metric is removed
        metricContainer.remove(metric);

        // @Then the metric is remove from the internal list
        assertThat(metric.internalGetMetrics()).excludes(metric);
    }

    @Test
    public void testRemoveRemovesMetricFromContainedMetric_WhenMetricIsContainedInContainedMetric() throws Exception {
        // @Given a metric container with a metric

        // @When the metric is removed
        metricContainer.remove(metric2);

        // @Then the metric is remove from the internal list
        assertThat(metric.getMetrics()).excludes(metric2);
    }
}
