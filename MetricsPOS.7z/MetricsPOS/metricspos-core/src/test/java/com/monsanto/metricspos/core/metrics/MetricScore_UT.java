package com.monsanto.metricspos.core.metrics;

import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

/**
 * User: PPERA
 */
public class MetricScore_UT {
    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        MetricScore instance = new MetricScore();
        tester.testInstance(instance);
    }
}
