package com.monsanto.metricspos.core.metrics;

import com.monsanto.metricspos.core.ComputeManager;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * Complete please !!
 *
 * @author CAFAU
 */
public class Metric_UT {

    private static final String NEW_METRIC_NAME = "new name";
    private static final String REPEATED_NAME = "repeated name";

    private TestCoreEntitiesFactory coreEntitiesFactory = new TestCoreEntitiesFactory();
    private ComputeManager computeManager;

    @Before
    public void setUp() {
        this.computeManager = mock(ComputeManager.class);
    }

    @Test
    public void testGivenAMetricDefInACampaignWhenChangeMetricDefNameThenCanFindMetricDefWithNewName() throws Exception {
        // Given
        Campaign campaign = coreEntitiesFactory.buildCampaign();
        Metric metric = campaign.getMetrics().iterator().next();

        // When
        metric.setName(NEW_METRIC_NAME);

        // Then
        Collection<Metric> metrics = campaign.getMetrics();

        assertThat(metrics).onProperty("name").containsOnly(NEW_METRIC_NAME);
    }

    @Test
    public void testGivenAMetricDefInACampaignWhenChangeMetricDefNameThenCannotFindMetricDefWithOldName() throws Exception {
        // Given
        Campaign campaign = coreEntitiesFactory.buildCampaign();
        Metric metric = campaign.getMetrics().iterator().next();

        // When
        metric.setName(NEW_METRIC_NAME);

        // Then
        Collection<Metric> metrics = campaign.getMetrics();

        assertThat(metrics).onProperty("name").excludes(Campaign_UT.VALID_METRIC_NAME_1);
    }

    @Test
    public void testGivenAMetricInACampaignWitheOtherMetricDefXWhenChangeNameOfMetricToXThenCannotChangeIt() throws Exception {
        // Given
        Campaign campaign = coreEntitiesFactory.buildCampaign();
        Metric metric = campaign.getMetrics().iterator().next();
        campaign.addMetricDefinition(REPEATED_NAME, 369);

        // When

        try {
            metric.setName(REPEATED_NAME);
            fail();
        } catch (BusinessException e) {
            // Then
            assertThat(e).hasMessage(BusinessException.DUPLICATE_METRIC_NAME);

            Collection<Metric> metrics = campaign.getMetrics();

            assertThat(metrics).onProperty("name").containsOnly(Campaign_UT.VALID_METRIC_NAME_1, REPEATED_NAME);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testCannotCreatedMethodDefinitionWithNullName() throws Exception {
        // When
        Campaign campaign = coreEntitiesFactory.buildCampaign();

        // Then
        try {
            campaign.addMetricDefinition(null, 154);
            fail();
        } catch (IllegalArgumentException e) {
            assertThat(e).hasMessage(Metric.INVALID_METRIC_NAME);
        }
    }

    @Test
    public void testCannotCreatedMethodDefinitionWithEmptyName() throws Exception {
        // When
        Campaign campaign = coreEntitiesFactory.buildCampaign();

        // Then
        try {
            campaign.addMetricDefinition(" ", 589);
            fail();
        } catch (IllegalArgumentException e) {
            assertThat(e).hasMessage(Metric.INVALID_METRIC_NAME);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testComputeCallsComputeManagerComputeWithMetricFormula_WhenComputingMetricWithFormula() {
        // @Given a metric with a formula and a script engine
        Campaign campaign = new Campaign("campaignName", newDate(2012, 5, 5), newDate(2015, 7, 8));
        Metric metric = new Metric(campaign, "metricName");
        metric.setFormula("return (1 + 2)");
        field("computeManager").ofType(ComputeManager.class).in(metric).set(this.computeManager);

        // @When computing the metric
        metric.compute();

        // @Then the engine executes the formula
        verify(this.computeManager, times(1)).compute(metric);
    }

    @Test
    public void testAddToSendMetricsAndSubMetricsIntoExport(){
        Campaign campaign = coreEntitiesFactory.buildCampaign();

        Metric metric1 = campaign.addMetricDefinition("met1", 100);
        Metric metric2 = campaign.addMetricDefinition("met2", 200);
        Metric submetric11 = metric1.addMetricDefinition("sub11", 200);
        Metric submetric12 = metric1.addMetricDefinition("sub12", 200);
        Metric submetric21 = metric2.addMetricDefinition("sub21", 200);
        Metric submetric22 = metric2.addMetricDefinition("sub22", 200);
        Metric submetric23 = metric2.addMetricDefinition("sub23", 200);

        metric1.setSend(false);
        metric2.setSend(false);

        submetric11.setSend(false);
        submetric12.setSend(false);

        submetric21.setSend(false);
        submetric22.setSend(false);
        submetric23.setSend(true);

        Assert.assertEquals(metric1.addToSend(), Boolean.FALSE);
        Assert.assertEquals(metric2.addToSend(), Boolean.TRUE);
    }

    @Test
    public void testToString() {
        Campaign campaign = new Campaign("campaignName", newDate(2012, 5, 5), newDate(2015, 7, 8));
        Metric metric = new Metric(campaign, "metricName");
        metric.setFormula("return (1 + 2)");
        assertThat(metric.toString()).isEqualTo("Metric{name='metricName', id=null, enabled=false, formula='return (1 + 2)', maxPoints=null, scheduled=false}");
    }
}
