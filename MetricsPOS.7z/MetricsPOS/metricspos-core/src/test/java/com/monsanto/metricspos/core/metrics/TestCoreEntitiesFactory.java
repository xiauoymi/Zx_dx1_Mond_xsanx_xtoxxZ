package com.monsanto.metricspos.core.metrics;

import com.monsanto.metricspos.core.metrics.test.MetricFactoryStub;

import java.util.Date;

public class TestCoreEntitiesFactory {
    private MetricFactoryStub factory = new MetricFactoryStub();


    public MetricFactoryStub getFactory() {
        return factory;
    }

    public void setFactory(MetricFactoryStub factory) {
        this.factory = factory;
    }

    public Campaign buildCampaign(Date start, Date end) {
        Campaign campaign = new Campaign(Campaign_UT.VALID_CAMPAIGN_NAME, start, end);
        campaign.setFactory(factory);
        campaign.addMetricDefinition(Campaign_UT.VALID_METRIC_NAME_1, 200);
        return campaign;
    }

    public Campaign buildCampaign() {
        Date start = new Date();
        Date end = new Date();
        return buildCampaign(start, end);
    }
}