package com.monsanto.metricspos.core.metrics.test;

import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricFactory;

/**
 * User: PPERA
 */
public class MetricFactoryStub implements MetricFactory {

    @Override
    public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
        return new Metric(campaign, name);
    }
}
