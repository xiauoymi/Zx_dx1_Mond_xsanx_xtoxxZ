package com.monsanto.metricspos.core.security;

import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class AdminUser_UT {
    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        AdminUser instance = new AdminUser();
        tester.testInstance(instance);
    }

    @Test
    public void testToString(){
        AdminUser adminUser = new AdminUser();
        adminUser.setEnabled(true);
        adminUser.setUsername("hi");
        adminUser.setId(1);
        assertThat(adminUser.toString()).isEqualTo("AdminUser{id=1, username='hi', enabled=true}");
    }
}
