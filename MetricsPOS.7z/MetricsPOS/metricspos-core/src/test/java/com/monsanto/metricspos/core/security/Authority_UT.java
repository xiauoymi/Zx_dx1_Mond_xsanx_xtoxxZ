package com.monsanto.metricspos.core.security;

import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

/**
 * User: PPERA
 */
public class Authority_UT {
    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        Authority instance = new Authority();
        tester.testInstance(instance);
    }
}
