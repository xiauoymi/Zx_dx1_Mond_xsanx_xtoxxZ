package com.monsanto.metricspos.core.security;

import com.google.common.collect.Lists;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class Group_UT {
    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        Group instance = new Group();
        tester.testInstance(instance);
    }

    @Test
    public void testToString() {
        Group group = new Group();
        group.setId(1);
        group.setName("Hi");
        group.setEnabled(true);
        Authority authority = new Authority();
        authority.setName("ACCESS");
        group.setAuthorities(Lists.<Authority>newArrayList(authority));
        assertThat(group.toString()).isEqualTo("Group{id=1, name='Hi', enabled=true}");
    }

}
