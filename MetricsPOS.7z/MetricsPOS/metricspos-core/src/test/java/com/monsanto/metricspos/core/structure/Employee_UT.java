package com.monsanto.metricspos.core.structure;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class Employee_UT {
    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        Employee instance = new Employee();
        tester.testInstance(instance);
    }

    @Test
    public void testToString() {
        Employee employee = new Employee();
        Campaign campaign = new Campaign("name", newDate(2012, 1, 1), newDate(2013, 1, 1));
        employee.setCampaign(campaign);
        campaign.setId(3);
        employee.setId(1l);
        Group group = new Group();
        group.setName("group");
        employee.setGroups(Lists.<Group>newArrayList(group));
        employee.setEnabled(true);
        Metric metric = new Metric(campaign, "hi");
        employee.setMetrics(Lists.<Metric>newArrayList(metric));
        employee.setName("john");
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        serviceCenter.setCuit("10");
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        employee.setUsername("jsmith");
        assertThat(employee.toString()).isEqualTo("Employee{id=1, name='john', username='jsmith', enabled=true}");
    }
}
