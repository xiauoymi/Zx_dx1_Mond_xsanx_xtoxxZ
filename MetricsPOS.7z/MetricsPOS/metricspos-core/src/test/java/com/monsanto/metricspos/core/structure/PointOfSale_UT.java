package com.monsanto.metricspos.core.structure;

import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class PointOfSale_UT {

    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        PointOfSale instance = new PointOfSale();
        tester.testInstance(instance);
    }


    @Test
    public void testToString(){
        PointOfSale pointOfSale = new PointOfSale();
        assertThat(pointOfSale.toString()).isEqualTo("PointOfSale{idSap=null, salesGroup='null', region='null', type='null', tsrcId=null, customer='null', locality='null', county='null', state='null', address='null', phone='null', mail='null'}");
    }
}
