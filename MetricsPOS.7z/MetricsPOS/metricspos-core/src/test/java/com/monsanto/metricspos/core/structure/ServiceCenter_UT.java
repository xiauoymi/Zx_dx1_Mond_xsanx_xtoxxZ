package com.monsanto.metricspos.core.structure;

import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Test;

/**
 * User: PPERA
 */
public class ServiceCenter_UT {
    @Test
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        ServiceCenter instance = new ServiceCenter();
        tester.testInstance(instance);
    }
}
