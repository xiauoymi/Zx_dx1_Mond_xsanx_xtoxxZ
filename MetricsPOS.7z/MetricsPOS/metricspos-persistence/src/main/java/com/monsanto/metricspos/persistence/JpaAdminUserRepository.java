package com.monsanto.metricspos.persistence;

import com.monsanto.metricspos.core.AdminUserServices;
import com.monsanto.metricspos.core.security.AdminUser;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * JPA implementation of the admin user services
 * User: PPERA
 */
@Repository("adminUserServices")
public class JpaAdminUserRepository implements AdminUserServices {
    public static final String FIND_BY_USERNAME = "Select au from AdminUser au where au.username = :username";
    public static final String FIND_ALL_ADMIN_USERS = "Select au from AdminUser au ORDER BY au.username";

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public AdminUser findAdminUserByUserName(String userName) {
        Query query = this.entityManager.createQuery(FIND_BY_USERNAME);
        query.setParameter("username", userName);
        try {
            return (AdminUser) query.getSingleResult();
        } catch (EmptyResultDataAccessException e) {
            return null;
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public List<AdminUser> listAdminUsers() {
        Query query = this.entityManager.createQuery(FIND_ALL_ADMIN_USERS);
        return query.getResultList();
    }

    @Override
    public AdminUser newAdminUser(AdminUser adminUser) {
        this.entityManager.persist(adminUser);
        return adminUser;
    }

    @Override
    public AdminUser findAdminUserById(int adminUserId) {
        return this.entityManager.find(AdminUser.class, adminUserId);
    }

    @Override
    public void deleteAdminUser(AdminUser adminUser) {
        this.entityManager.remove(adminUser);
    }
}
