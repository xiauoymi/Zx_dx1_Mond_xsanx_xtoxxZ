package com.monsanto.metricspos.persistence;

import com.monsanto.metricspos.core.AuthorityServices;
import com.monsanto.metricspos.core.security.Authority;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Collection;
import java.util.List;

/**
 * JPA implementation of the authority services
 * User: PPERA
 */
@Repository("authorityServices")
public class JpaAuthoritiesRepository implements AuthorityServices {
    public static final String FIND_ALL_AUTHORITIES_ROLE_NAMES = "Select auth.roleName from Authority auth";
    public static final String FIND_ALL_AUTHORITIES = "Select auth from Authority auth order by auth.name asc";

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Authority findAuthorityById(Integer authorityId) {
        return entityManager.find(Authority.class, authorityId);
    }

    @Override
    public List<Authority> listAuthorities() {
        Query query = this.entityManager.createQuery(FIND_ALL_AUTHORITIES);
        return query.getResultList();
    }

    @Override
    public Collection<String> findAllRoleNames() {
        Query query = this.entityManager.createQuery(FIND_ALL_AUTHORITIES_ROLE_NAMES);
        return query.getResultList();
    }
}
