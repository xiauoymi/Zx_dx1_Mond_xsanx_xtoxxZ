package com.monsanto.metricspos.persistence;

import com.monsanto.metricspos.core.CampaignServices;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.CampaignVO;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.CampaignParameter;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.security.User;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.queries.CampaignParameterQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

/**
 * CampaignRepository implementation with JPA
 *
 * @author CAFAU
 */
@Repository
public class JpaCampaignRepository implements CampaignServices {

    private static final String ALL_CAMPAIGNS = "select c from Campaign c order by c.since";
    public static final String ALL_CAMPAIGNS_OF_EMPLOYEE = "SELECT c FROM Campaign c WHERE :username IN (SELECT employee.username FROM Employee employee WHERE employee.campaign = c) ORDER BY c.since";
    private static final String CAMPAIGN_BY_ID = "select c from Campaign c where c.id = :id";
    public static final String FIND_PARAMETER_BY_NAME = "Select cp from CampaignParameter cp where cp.name = :name";
    public static final String FIND_SERVICE_CENTER_BY_CAMPAIGN_AND_CUIT = "select sc from ServiceCenter sc left join fetch sc.pointsOfSale pos where sc.campaign = :campaign AND sc.cuit = :cuit AND sc.deleted = false";
    public static final String DELETE_SERVICE_CENTERS_OF_CAMPAIGN_NATIVELY = "DELETE FROM MPS.MPS_SERVICE_CENTER WHERE CAMPAIGN_ID = ?";
    public static final String DELETE_POINTS_OF_SALE_OF_CAMPAIGN_NATIVELY = "DELETE FROM MPS.MPS_POINT_OF_SALE WHERE CAMPAIGN_ID = ?";

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private SecurityHolderStrategy securityHolderStrategy;

    /**
     * @return
     */
    @Override
    public List<Campaign> listAllCampaigns() {
        User user = securityHolderStrategy.getCurrentUser();
        Query query = null;

        if (user.isAdmin()) {
            query = entityManager.createQuery(ALL_CAMPAIGNS);
        } else {
            query = entityManager.createQuery(ALL_CAMPAIGNS_OF_EMPLOYEE);
            query.setParameter("username", user.getUsername());
        }

        return query.getResultList();
    }

    @Override
    public Campaign findCampaignById(int campaignId) {
        Query query = entityManager.createQuery(CAMPAIGN_BY_ID);
        query.setParameter("id", campaignId);
        try {
            return (Campaign) query.getSingleResult();
        } catch (NoResultException e) {
            throw new BusinessException(BusinessException.ERROR_CAMPAIGN_NOT_FOUND, 404, e);
        } catch (EmptyResultDataAccessException e) {
            throw new BusinessException(BusinessException.ERROR_CAMPAIGN_NOT_FOUND, 404, e);
        }
    }

    @Override
    public Campaign newCampaign(CampaignVO campaignVO) {
        Campaign campaign = new Campaign(campaignVO.getName(), campaignVO.getSince(), campaignVO.getUntil());
        entityManager.persist(campaign);
        return campaign;
    }

    @Override
    public ServiceCenter findServiceCenterByCampaignIdAndCuit(Campaign campaign, String cuit) {
        Query query = entityManager.createQuery(FIND_SERVICE_CENTER_BY_CAMPAIGN_AND_CUIT);
        query.setParameter("campaign", campaign);
        query.setParameter("cuit", cuit);
        return (ServiceCenter) query.getSingleResult();
    }

    @Override
    public void removeCampaign(Campaign campaign) {
        if ((campaign.getDataTables() != null && !campaign.getDataTables().isEmpty())) {
            throw new BusinessException(BusinessException.CANNOT_DELETE_CAMPAIGN_WITH_TABLES, 409);
        }

        if (campaign.getMetrics() != null && !campaign.getMetrics().isEmpty()) {
            throw new BusinessException(BusinessException.CANNOT_DELETE_CAMPAIGN_WITH_CHILDREN, 409);
        }

        this.removeServiceCentersNatively(campaign);

        entityManager.remove(campaign);
    }

    private void removeServiceCentersNatively(Campaign campaign) {
        this.removePointsOfSalesNatively(campaign);

        Query nativeQuery = entityManager.createNativeQuery(DELETE_SERVICE_CENTERS_OF_CAMPAIGN_NATIVELY);
        nativeQuery.setParameter(1, campaign.getId());
        nativeQuery.executeUpdate();
    }

    private void removePointsOfSalesNatively(Campaign campaign) {
        Query nativeQuery = entityManager.createNativeQuery(DELETE_POINTS_OF_SALE_OF_CAMPAIGN_NATIVELY);
        nativeQuery.setParameter(1, campaign.getId());
        nativeQuery.executeUpdate();
    }

    @Override
    public Campaign updateCampaign(Campaign campaign, CampaignVO campaignVO) {
        campaign.setName(campaignVO.getName());
        campaign.setSince(campaignVO.getSince());
        campaign.setUntil(campaignVO.getUntil());
        campaign.setState(campaignVO.getState());
        campaign.setScheduled(campaignVO.isScheduled());
        campaign.setServiceCenterLoadSql(campaignVO.getServiceCenterLoadSql());
        campaign.setServiceCenterLoadScript(campaignVO.getServiceCenterLoadScript());
        campaign.setPointOfSaleLoadSql(campaignVO.getPointOfSaleLoadSql());
        campaign.setPointOfSaleLoadScript(campaignVO.getPointOfSaleLoadScript());
        campaign.setEmployeeLoadSql(campaignVO.getEmployeeLoadSql());
        campaign.setEmployeeLoadScript(campaignVO.getEmployeeLoadScript());
        campaign.setRatingFormula(campaignVO.getRatingFormula());
        campaign.setRatingPremiumCategory(campaignVO.getRatingPremiumCategory());
        return campaign;
    }

    @Override
    public CampaignParameter findParameterById(int id) {
        return entityManager.find(CampaignParameter.class, id);
    }

    @Override
    public CampaignParameter updateParameter(CampaignParameter existing, CampaignParameter modified) {
        existing.setDescription(modified.getDescription());
        existing.setValue(modified.getValue());
        return existing;
    }

    @Override
    public long getTotalParametersCount(Map<String, Object> filter) {
        CampaignParameterQuery cpQuery = new CampaignParameterQuery(filter, entityManager);
        return cpQuery.getCount();
    }

    @Override
    public CampaignParameter findParameterByName(String name) {
        Query query = entityManager.createQuery(FIND_PARAMETER_BY_NAME);
        query.setParameter("name", name);
        return (CampaignParameter) query.getSingleResult();
    }

    @Override
    public List<Campaign> listAllCampaignsForBatch() {
        Query query = entityManager.createQuery(ALL_CAMPAIGNS);
        return query.getResultList();
    }

    @Override
    public List<CampaignParameter> getParameters(int page, int rows, String sort, String direction, Map<String, Object> filter) {
        CampaignParameterQuery cpQuery = new CampaignParameterQuery(filter, entityManager);
        return cpQuery.getResultList(page, rows, sort, direction);
    }
}
