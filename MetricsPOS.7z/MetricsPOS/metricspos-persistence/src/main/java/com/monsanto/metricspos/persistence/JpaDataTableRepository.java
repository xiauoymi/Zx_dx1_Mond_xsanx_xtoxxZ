package com.monsanto.metricspos.persistence;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.DataTableServices;
import com.monsanto.metricspos.core.application.vo.DataColumnVO;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.application.vo.converter.DataColumnVO2DataColumnConverter;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.externaldata.DataType;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.*;

/**
 * JPA implementation of the table services
 * User: PPERA
 */
@Repository
public class JpaDataTableRepository implements DataTableServices {

    @PersistenceContext
    private EntityManager entityManager;
    private static final String DATA_TABLE_BY_ID = "SELECT dt FROM DataTable dt Join Fetch dt.campaign c WHERE dt.id = :id";
    private static final String DATA_COLUMN_BY_ID = "SELECT dc FROM com.monsanto.metricspos.core.externaldata.DataColumn  dc where dc.id = :id";

    @Resource(name = "dataProvidersMap")
    private Map<String, DataProvider> dataProvidersMap;

    @Resource(name = "dataTypeMap")
    private Map<String, DataType> dataTypeMap;

    @Autowired
    private DataRowPersistorFactory dataRowPersistorFactory;

    @Autowired
    @Qualifier("dataColumnVO2DataColumnConverter")
    private DataColumnVO2DataColumnConverter dataColumnVO2DataColumnConverter;
    private static final String SERVICE_CENTER_COLUMN_DEFAULT_NAME = "SERVICECENTER";
    public static final String FIND_TABLE_BY_NAME_AND_CAMPAIGN = "Select table FROM DataTable table WHERE table.name = :tableName AND table.campaign = :campaign";
    public static final String DELETE_ROWS_OF_TABLE_NATIVELY = "DELETE FROM MPS.MPS_MULTITABLE_ROW WHERE DATA_TABLE_ID = ?";
    public static final String FIND_TABLE_BY_CAMPAIGN = "Select table FROM DataTable table LEFT JOIN FETCH table.columns WHERE table.campaign = :campaign";

    @Override
    public DataTable newDataTable(DataTableVO dataTableVO, Campaign campaign) {
        DataTable dataTable = new DataTable();
        dataTable.setName(dataTableVO.getName());
        dataTable.setDescription(dataTableVO.getDescription());
        dataTable.setDataProvider(dataProvidersMap.get(dataTableVO.getProvider()));
        dataTable.setAllowRecordCreation(dataTableVO.getAllowRecordCreation());
        DataColumn serviceCenterColumn = new DataColumn(SERVICE_CENTER_COLUMN_DEFAULT_NAME, this.serviceCenterDataType());
        serviceCenterColumn.setRequired(true);
        serviceCenterColumn.setActualColumnName(dataRowPersistorFactory.buildDataRowPersistor(dataTable).getServiceCenterColumnActualName());
        dataTable.setColumns(Lists.<DataColumn>newArrayList(serviceCenterColumn));

        dataTable.setCampaign(campaign);
        entityManager.persist(dataTable);

        return dataTable;
    }

    @Override
    public DataTable findDataTableById(int tableId) {
        Query query = entityManager.createQuery(DATA_TABLE_BY_ID);
        query.setParameter("id", tableId);
        return (DataTable) query.getSingleResult();
    }

    @Override
    public List<DataColumn> findMetadataByDataTable(DataTable table) {
        table.getColumns().size();
        return table.getColumns();
    }

    @Override
    public DataColumn findDataColumnById(Integer dataColumnId) {
        Query query = entityManager.createQuery(DATA_COLUMN_BY_ID);
        query.setParameter("id", dataColumnId);
        return (DataColumn) query.getSingleResult();
    }

    @Override
    public DataColumn removeDataColumn(DataColumn dataColumn) {
        entityManager.remove(dataColumn);
        return dataColumn;
    }

    @Override
    public DataTable removeDataTable(DataTable dataTable) {
        Query nativeQuery = entityManager.createNativeQuery(DELETE_ROWS_OF_TABLE_NATIVELY);
        nativeQuery.setParameter(1, dataTable.getId());
        nativeQuery.executeUpdate();

        entityManager.remove(dataTable);
        return dataTable;
    }

    @Override
    public List<DataProvider> listProviders() {
        return Lists.newArrayList(this.dataProvidersMap.values());
    }

    @Override
    public void updateDataTable(DataTable dataTable, DataTableVO dataTableVO) {
        dataTable.setAllowRecordCreation(dataTableVO.getAllowRecordCreation());
        dataTable.setDataProvider(dataProvidersMap.get(dataTableVO.getProvider()));
        dataTable.setDescription(dataTableVO.getDescription());
        dataTable.setName(dataTableVO.getName());
        dataTable.setLoadSql(dataTableVO.getLoadSql());
        dataTable.setLoadScript(dataTableVO.getLoadScript());
        dataTable.setScheduled(dataTableVO.isScheduled());
        dataTable.setLastRunSucceed(dataTableVO.isLastRunSucceed());
        dataTable.setLastUpdate(dataTableVO.getLastUpdate());
        dataTable.setIncludeData(dataTableVO.isIncludeData());
    }

    @Override
    /**
     * Ensures all data columns in list are managed by repository.
     * Only merged existent entities (the ones that have not null id)
     * @param dataColumns   The columns to persist
     */
    public List<DataColumn> updateMetadata(DataTable dataTable, List<DataColumnVO> dataColumnVOs) {
        final List<DataColumn> dataColumns;

        if (dataColumnVOs != null) {
            dataColumns = convertFromVO(dataColumnVOs);
            List<DataColumn> newColumns = extractNewColumns(dataColumns);

            List<DataColumn> columnsToRemove = Lists.newArrayList();
            // http://stackoverflow.com/questions/4725785/stop-hibernate-from-updating-collections-when-they-have-not-changed
            for (DataColumn dataColumn : dataTable.getColumns()) {
                boolean found = false;
                for (DataColumn updated : dataColumns) {
                    if (dataColumn.getId().equals(updated.getId())) {
                        dataColumn.merge(updated);
                        found = true;
                    }
                }

                if (!found) {
                    columnsToRemove.add(dataColumn);
                }
            }

            dataTable.getColumns().removeAll(columnsToRemove);
            dataTable.getColumns().addAll(newColumns);
            Collections.sort(dataTable.getColumns(), new Comparator<DataColumn>() {
                @Override
                public int compare(DataColumn o1, DataColumn o2) {
                    return this.indexOf(o1, dataColumns) - this.indexOf(o2, dataColumns);
                }

                private int indexOf(DataColumn target, List<DataColumn> dataColumns) {
                    for (DataColumn column : dataColumns) {
                        if (column.getName().equals(target.getName())) {
                            return dataColumns.indexOf(column);
                        }
                    }
                    return 0;
                }
            });
            dataTable.getDataRowPersistor().assignActualColumnNames(dataTable.getColumns());
            dataTable.cleanColumnContents(dataColumns);
        }

        return dataTable.getColumns();
    }

    @Override
    public DataTable findDataTableByCampaignAndName(Campaign campaign, String tableName) {
        Query query = entityManager.createQuery(FIND_TABLE_BY_NAME_AND_CAMPAIGN);
        query.setParameter("tableName", tableName);
        query.setParameter("campaign", campaign);
        return (DataTable) query.getSingleResult();
    }

    @Override
    public List<DataTable> findDataTablesByCampaign(Campaign campaign) {
        Query query = entityManager.createQuery(FIND_TABLE_BY_CAMPAIGN);
        query.setParameter("campaign", campaign);
        return query.getResultList();
    }

    @Override
    public void updateLastRun(DataTable dataTable, boolean success) {
        dataTable.setLastUpdate(new Date());
        dataTable.setLastRunSucceed(success);
        entityManager.flush();
    }

    @Override
    public List<Metric> findMetricsByDataTable(DataTable dataTable) {
        if (dataTable.getMetrics() != null){
            dataTable.getMetrics().size();
        }
        return dataTable.getMetrics();
    }

    private List<DataColumn> extractNewColumns(List<DataColumn> dataColumns) {
        List<DataColumn> newColumns = Lists.newArrayList();

        for (DataColumn dataColumn : dataColumns) {
            if (dataColumn.getId() == null) {
                newColumns.add(dataColumn);
            }
        }
        return newColumns;
    }

    /**
     * @param columns
     * @return
     */
    private List<DataColumn> convertFromVO(List<DataColumnVO> columns) {
        List<DataColumn> dataColumns = Lists.newArrayListWithCapacity(columns.size());

        for (DataColumnVO dataColumnVO : columns) {
            dataColumns.add(dataColumnVO2DataColumnConverter.convert(dataColumnVO));
        }

        return dataColumns;
    }

    private DataType serviceCenterDataType() {
        for (DataType dataType : dataTypeMap.values()) {
            if (dataType.getInternalType().equals(ServiceCenter.class)) {
                return dataType;
            }
        }
        throw new RuntimeException("There is no service center type configured");
    }
}
