package com.monsanto.metricspos.persistence;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.EmployeeServices;
import com.monsanto.metricspos.core.application.vo.EmployeeVO;
import com.monsanto.metricspos.core.application.vo.GroupVO;
import com.monsanto.metricspos.core.application.vo.MetricVO;
import com.monsanto.metricspos.core.application.vo.ServiceCenterVO;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.keys.EmployeeKey;
import com.monsanto.metricspos.persistence.queries.EmployeeQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

/**
 * JPA implementation of the employee services
 * User: PPERA
 */
@Repository("employeeServices")
public class JpaEmployeeRepository implements EmployeeServices {

    private static final int BASE_MANUAL_ID = 1000000;
    public static final String MARK_AS_NOT_LOADED_FOR_CAMPAIGN = "update Employee emp set emp.loaded=false where emp.campaign = :campaign";
    public static final String REMOVE_NOT_LOADED_FOR_CAMPAIGN = "delete from Employee emp where emp.loaded=false and emp.campaign = :campaign";
    public static final String FIND_EMPLOYEES_BY_USERNAME = "Select employee from Employee employee where employee.username = :username";

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Employee> findEmployeesByUsername(String userName) {
        Query query = this.entityManager.createQuery(FIND_EMPLOYEES_BY_USERNAME);
        query.setParameter("username", userName);
        return query.getResultList();
    }

    @Override
    public Employee newEmployee(EmployeeVO employeeVO, Campaign campaign, List<Group> groups, List<Metric> metrics) {
        Employee employee = new Employee();
        employee.setId(this.generateManualId(campaign));
        employee.setCampaign(campaign);
        employee.setName(employeeVO.getName());
        employee.setEnabled(employeeVO.isEnabled());
        employee.setLoaded(true);
        employee.setUsername(employeeVO.getUsername());

        mapGroupsFromEmployeeVOToEntity(employeeVO, groups, employee);
        mapMetricsFromEmployeeVOToEntity(employeeVO, metrics, employee);
        mapServiceCentersFromEmployeeVOToEntity(employeeVO, campaign.getServiceCenters(), employee);

        this.entityManager.persist(employee);

        return employee;
    }

    @Override
    public void updateEmployee(EmployeeVO employeeVO, Campaign campaign, List<Metric> metrics) {
        EmployeeKey key = new EmployeeKey(campaign, employeeVO.getId());
        Employee employee = this.entityManager.find(Employee.class, key);
        employee.setName(employeeVO.getName());
        employee.setEnabled(employeeVO.isEnabled());
        employee.setLoaded(true);
        employee.setUsername(employeeVO.getUsername());

        mapMetricsFromEmployeeVOToEntity(employeeVO, metrics, employee);
        mapServiceCentersFromEmployeeVOToEntity(employeeVO, campaign.getServiceCenters(), employee);
    }

    @Override
    public List<Employee> listEmployeesForCampaign(Campaign campaign) {
        EmployeeQuery employeeQuery = new EmployeeQuery(campaign, this.entityManager);
        return employeeQuery.getResultList("name", "ASC");
    }

    @Override
    public List<Employee> listEmployeesForCampaignAndPage(Campaign campaign, List<Group> groups, int page, int rows, String sort, String direction, Map<String, Object> filter) {
        EmployeeQuery employeeQuery = new EmployeeQuery(filter, campaign, groups, this.entityManager);
        return employeeQuery.getResultList(page, rows, sort, direction);
    }

    @Override
    public long markAllEmployeesAsNotLoadedInCampaign(Campaign campaign) {
        Query query = this.entityManager.createQuery(MARK_AS_NOT_LOADED_FOR_CAMPAIGN);
        query.setParameter("campaign", campaign);
        return query.executeUpdate();
    }

    @Override
    public Employee saveOrUpdate(Employee employee) {
        entityManager.merge(employee);
        return employee;
    }

    @Override
    public long removeAllNotLoadedEmployees(Campaign campaign) {
        entityManager.flush();
        Query query = this.entityManager.createQuery(REMOVE_NOT_LOADED_FOR_CAMPAIGN);
        query.setParameter("campaign", campaign);
        return query.executeUpdate();
    }

    @Override
    public long countEmployeesForCampaign(Map<String, Object> filter, Campaign campaign, List<Group> groups) {
        EmployeeQuery employeeQuery = new EmployeeQuery(filter, campaign, groups, this.entityManager);
        return employeeQuery.getCount();
    }

    @Override
    public Employee findEmployeeByIdAndCampaign(Long employeeId, Campaign campaign) {
        EmployeeKey employeeKey = new EmployeeKey(campaign, employeeId);
        return this.entityManager.find(Employee.class, employeeKey);
    }

    private void mapServiceCentersFromEmployeeVOToEntity(EmployeeVO employeeVO, List<ServiceCenter> serviceCenters, Employee employee) {
        this.clearServiceCenters(employee);
        this.mapServiceCentersFromVOs(employeeVO, serviceCenters, employee);
    }

    private void clearServiceCenters(Employee employee) {
        if (employee.getServiceCenters() == null) {
            employee.setServiceCenters(Lists.<ServiceCenter>newArrayList());
        } else {
            employee.getServiceCenters().clear();
        }
    }

    private void mapServiceCentersFromVOs(EmployeeVO employeeVO, List<ServiceCenter> serviceCenters, Employee employee) {
        if (employeeVO.getServiceCenters() != null) {
            for (ServiceCenterVO serviceCenterVO : employeeVO.getServiceCenters()) {
                if (serviceCenters != null) {
                    ServiceCenter result = this.findServiceCenter(serviceCenters, serviceCenterVO);
                    employee.getServiceCenters().add(result);
                }
            }
        }
    }

    private ServiceCenter findServiceCenter(List<ServiceCenter> serviceCenters, ServiceCenterVO serviceCenterVO) {
        ServiceCenter result = null;
        for (ServiceCenter serviceCenter : serviceCenters) {
            if (serviceCenterVO.getCuit().equals(serviceCenter.getCuit())) {
                result = serviceCenter;
            }
        }
        return result;
    }

    private void mapMetricsFromEmployeeVOToEntity(EmployeeVO employeeVO, List<Metric> metrics, Employee employee) {
        this.clearMetrics(employee);
        this.mapMetricsFromVOs(employeeVO, metrics, employee);
    }

    private void mapMetricsFromVOs(EmployeeVO employeeVO, List<Metric> metrics, Employee employee) {
        if (employeeVO.getMetrics() != null) {
            for (MetricVO metricVO : employeeVO.getMetrics()) {
                if (metrics != null) {
                    Metric result = this.findMetric(metrics, metricVO);
                    employee.getMetrics().add(result);
                }
            }
        }
    }

    private void clearMetrics(Employee employee) {
        if (employee.getMetrics() == null) {
            employee.setMetrics(Lists.<Metric>newArrayList());
        } else {
            employee.getMetrics().clear();
        }
    }

    private Metric findMetric(List<Metric> metrics, MetricVO metricVO) {
        Metric result = null;
        for (Metric metric : metrics) {
            if (metricVO.getId().equals(metric.getId())) {
                result = metric;
            }
        }
        return result;
    }

    private Long generateManualId(Campaign campaign) {
        Query query = this.entityManager.createQuery("SELECT max(employee.id) from Employee employee where campaign = :campaign");
        query.setParameter("campaign", campaign);
        Long maxId = (Long) query.getSingleResult();
        return (maxId != null && maxId > BASE_MANUAL_ID ? maxId : BASE_MANUAL_ID) + 1;
    }

    private void mapGroupsFromEmployeeVOToEntity(EmployeeVO employeeVO, List<Group> groups, Employee employee) {
        this.clearGroups(employee);
        this.mapGroupsFromVOs(employeeVO, groups, employee);
    }

    private void mapGroupsFromVOs(EmployeeVO employeeVO, List<Group> groups, Employee employee) {
        if (employeeVO.getGroups() != null) {
            for (GroupVO groupVO : employeeVO.getGroups()) {
                if (groups != null) {
                    Group result = this.findGroup(groups, groupVO);
                    employee.getGroups().add(result);
                }
            }
        }
    }

    private Group findGroup(List<Group> groups, GroupVO groupVO) {
        Group result = null;
        for (Group group : groups) {
            if (group.getId().equals(groupVO.getId())) {
                result = group;
            }
        }
        return result;
    }

    private void clearGroups(Employee employee) {
        if (employee.getGroups() == null) {
            employee.setGroups(Lists.<Group>newArrayList());
        } else {
            employee.getGroups().clear();
        }
    }
}
