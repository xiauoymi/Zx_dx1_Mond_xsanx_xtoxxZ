package com.monsanto.metricspos.persistence;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.AuthorityServices;
import com.monsanto.metricspos.core.GroupServices;
import com.monsanto.metricspos.core.application.vo.GroupVO;
import com.monsanto.metricspos.core.security.Authority;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * JPA implementation of the group services
 * User: PPERA
 */
@Repository("groupServices")
public class JpaGroupRepository implements GroupServices {
    public static final String FIND_ALL_GROUPS = "Select distinct g from Group g left join fetch g.authorities order by g.name asc";
    public static final String FIND_GROUP_BY_NAME = "Select g from Group g where name = :name";

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private AuthorityServices authorityServices;

    @Override
    public List<Group> listGroups() {
        Query query = this.entityManager.createQuery(FIND_ALL_GROUPS);
        return query.getResultList();
    }

    @Override
    public Group findGroupById(Integer groupId) {
        return this.entityManager.find(Group.class, groupId);
    }

    @Override
    public Group newGroup(GroupVO groupVO) {
        Group group = new Group();
        group.setName(groupVO.getName());
        group.setEnabled(groupVO.isEnabled());
        group.setAuthorities(Lists.<Authority>newArrayList());
        group.setMembers(Lists.<Employee>newArrayList());
        entityManager.persist(group);
        return group;
    }

    @Override
    public void update(GroupVO groupVO, Group group) {
        group.setEnabled(groupVO.isEnabled());
        group.setName(groupVO.getName());
        group.getAuthorities().clear();
        for (Authority authority : groupVO.getAuthorities()) {
            Authority authorityEntity = this.authorityServices.findAuthorityById(authority.getId());
            group.getAuthorities().add(authorityEntity);
        }
    }

    @Override
    public Group findGroupByName(String name) {
        Query query = this.entityManager.createQuery(FIND_GROUP_BY_NAME);
        query.setParameter("name", name);
        try {
            return (Group) query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }

    }

    @Override
    public void deleteGroup(Group group) {
        if (group.getMembers() != null) {
            for (Employee employee : group.getMembers()) {
                employee.getGroups().remove(group);
            }
        }

        entityManager.remove(group);
    }
}
