package com.monsanto.metricspos.persistence;

import com.monsanto.metricspos.core.LogServices;
import com.monsanto.metricspos.core.security.ActionLog;
import com.monsanto.metricspos.core.security.AuditLog;
import com.monsanto.metricspos.persistence.queries.ActionLogQuery;
import com.monsanto.metricspos.persistence.queries.AuditLogQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;
import java.util.Map;

/**
 * JPA implementation of the Logs services
 * User: PPERA
 */
@Repository("logServices")
public class JpaLogsRepository implements LogServices {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<AuditLog> listAuditLogsByPage(int page, int rows, String sort, String direction, Map<String, Object> filter) {
        AuditLogQuery auditLogQuery = new AuditLogQuery(filter, entityManager);
        return auditLogQuery.getResultList(page, rows, sort, direction);
    }

    @Override
    public long getAuditLogsCount(Map<String, Object> filter) {
        AuditLogQuery auditLogQuery = new AuditLogQuery(filter, entityManager);
        return auditLogQuery.getCount();
    }

    @Override
    public List<ActionLog> listActionLogsByPage(int page, int rows, String sort, String direction, Map<String, Object> filter) {
        ActionLogQuery actionLogQuery = new ActionLogQuery(filter, entityManager);
        return actionLogQuery.getResultList(page, rows, sort, direction);
    }

    @Override
    public long getActionLogsCount(Map<String, Object> filter) {
        ActionLogQuery actionLogQuery = new ActionLogQuery(filter, entityManager);
        return actionLogQuery.getCount();
    }
}
