package com.monsanto.metricspos.persistence;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.MetricsServices;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.application.vo.MetricVO;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricFactory;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.security.User;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.keys.EmployeeKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;
import java.util.Set;

/**
 * JPA implementation of the metrics services
 * User: PPERA
 */
@Repository("metricsServices")
public class JpaMetricsRepository implements MetricsServices, MetricFactory {

    private static final String ALL_METRICS = "select submetric from Metric submetric join submetric.parent metric join metric.parent module order by submetric.name asc";
    public static final String METRICS_BY_CAMPAIGN = "select submetric from Metric submetric join submetric.parent metric join metric.parent module where submetric.campaign = :campaign order by submetric.name asc";
    private static final String METRIC_BY_ID = "select m from Metric m left join fetch m.metrics join fetch m.campaign c where m.id = :id";
    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private SecurityHolderStrategy securityHolderStrategy;

    @Override
    public List<Metric> listAllMetrics() {
        return entityManager.createQuery(ALL_METRICS).getResultList();
    }

    @Override
    public Metric findMetricById(int metricId) {
        Query query = entityManager.createQuery(METRIC_BY_ID);
        query.setParameter("id", metricId);
        try {
            return (Metric) query.getSingleResult();
        } catch (NoResultException e) {
            throw new BusinessException(BusinessException.ERROR_NOT_FOUND + "[Metric(" + metricId + ")]", 404, e);
        } catch (EmptyResultDataAccessException e) { // Something about aspects in tests messes with the exceptions and translates them
            throw new BusinessException(BusinessException.ERROR_NOT_FOUND + "[Metric(" + metricId + ")]", 404, e);
        }
    }

    @Override
    public void delete(Metric metric) {
        if (metric.getMetrics() != null && !metric.getMetrics().isEmpty()) {
            throw new BusinessException(BusinessException.ERROR_CANNOT_DELETE_METRIC_WITH_CHILDREN, 409);
        }
        entityManager.remove(metric);
    }

    @Override
    public void updateMetric(Metric metric, MetricVO metricVO) {
        metric.setFormula(metricVO.getFormula());

        if(metricVO.isEnabled() != null){
            metric.setEnabled(metricVO.isEnabled());
        }
        if(metricVO.isScheduled() != null){
            metric.setScheduled(metricVO.isScheduled());
        }

        metric.setMaxPoints(metricVO.getMaxPoints());
        metric.setName(metricVO.getName());
        metric.setOwner(metricVO.getOwner());
		metric.setSend(metricVO.getSend());
        metric.setExplanation(metricVO.getExplanation());
        metric.setWeighting(metricVO.getIsWeighting());

        metric.setType(metricVO.getType());

        this.markMetricScoresDirtiness(metric, true);
    }

    @Override
    public void updateMetric(Metric metric, List<DataTable> tables, MetricVO metricVO) {
        this.updateMetric(metric, metricVO);

        metric.getTables().clear();
        if (metricVO.getTables() != null) {
            for (DataTableVO dataTableVO : metricVO.getTables()) {
                metric.getTables().add(this.findTableById(tables, dataTableVO.getId()));
            }
        }
    }

    private DataTable findTableById(List<DataTable> tables, Integer id) {
        if (tables != null) {
            for (DataTable table : tables) {
                if (id.equals(table.getId())) {
                    return table;
                }
            }
        }

        return null;
    }

    @Override
    public List<Metric> listSubmetricsByCampaign(Campaign campaign) {
        User user = securityHolderStrategy.getCurrentUser();
        Query query = null;

        if (user.isAdmin()) {
            query = this.entityManager.createQuery(METRICS_BY_CAMPAIGN);
            query.setParameter("campaign", campaign);
            return query.getResultList();
        } else {
            Employee employee = entityManager.find(Employee.class, new EmployeeKey(campaign, ((Employee) user).getId()));
            if (employee.getMetrics() != null) {
                for (Metric metric : employee.getMetrics()) {
                    metric.getId();
                }
                return employee.getMetrics();
            }
            return Lists.newArrayList();
        }
    }

    @Override
    public void markMetricScoresDirtiness(Metric metric, boolean dirty) {
        // update dirty flag
        Set<MetricScore> scores = metric.getScores();
        for (MetricScore score : scores){
            score.setDirty(dirty);
        }
    }

    @Override
    public void markMetricScoresDirtinessByServiceCenter(Metric metric, ServiceCenter sc, boolean dirty) {
        Set<MetricScore> scores = metric.getScores();
        for (MetricScore score : scores){
            if (sc.getCuit().equals(score.getServiceCenter().getCuit())){
                score.setDirty(dirty);
            }
        }
    }

    @Override
    @Transactional
    public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
        Metric metric = new Metric(campaign, name);
        metric.setMaxPoints(maxPoints);
        metric.setEnabled(true);
        entityManager.persist(metric);

        return metric;
    }
}
