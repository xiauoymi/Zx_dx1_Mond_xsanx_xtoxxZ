package com.monsanto.metricspos.persistence;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.PointOfSaleServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.security.User;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.keys.EmployeeKey;
import com.monsanto.metricspos.persistence.keys.PointOfSaleKey;
import com.monsanto.metricspos.persistence.queries.PointOfSaleQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * JPA implementation of the points of sale services
 * User: PPERA
 */
@Repository("pointOfSaleServices")
public class JpaPointOfSaleRepository implements PointOfSaleServices {

    public static final String FIND_POS_WETHER_DELETED_OR_NOT = "Select pos from PointOfSale pos where pos.idSap = :idSap and campaign = :campaign";
    public static final String UPDATE_SERVICE_CENTER_NATIVELY = "Update MPS.MPS_POINT_OF_SALE Set CUIT = ? where ID_SAP = ? and CAMPAIGN_ID = ?";
    public static final String COUNT_PREVIOUSLY_EXISTING_POS_WITH_SAME_ID_SAP_AND_REFERING_TO_A_DELETED_SC = "Select count(pos.idSap) from PointOfSale pos JOIN pos.serviceCenter sc where pos.idSap = :idSap and pos.campaign = :campaign and sc.deleted = true";
    public static final String FIND_SC_FOR_THIS_POS_THAT_IS_NOT_DELETED = "Select sc from PointOfSale pos Join pos.serviceCenter sc where pos.idSap = :idSap and pos.campaign = :campaign and pos.deleted = false and pos.serviceCenter.deleted = false";
    public static final String FIND_DEPENDENT_ROWS = "Select rows from RowValues rows Join rows.pointOfSale pos where pos.loaded = false and pos.campaign = :campaign";
    public static final String MARK_AS_NOT_LOADED_FOR_CAMPAIGN = "update PointOfSale pos set pos.loaded=false where pos.campaign = :campaign";
    public static final String REMOVE_NOT_LOADED_FOR_CAMPAIGN = "update PointOfSale pos set pos.deleted=true where pos.loaded = false and pos.campaign = :campaign";
    public static final String LIST_POINTS_OF_SALE_FOR_CAMPAIGN = "SELECT distinct pos FROM PointOfSale pos JOIN pos.serviceCenter sc WHERE pos.campaign = :campaign and pos.deleted = false and sc.deleted = false ORDER BY pos.locality, pos.address asc";
    public static final String LIST_POINTS_OF_SALE_FOR_CAMPAIGN_OF_EMPLOYEE = "SELECT distinct pos FROM PointOfSale pos WHERE pos.campaign = :campaign AND pos.id in (:pointsOfSaleIds) ORDER BY pos.locality, pos.address asc";

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private SecurityHolderStrategy securityHolderStrategy;

    @Override
    public long markPointsOfSalesAsNotLoadedForCampaign(Campaign campaign) {
        Query query = this.entityManager.createQuery(MARK_AS_NOT_LOADED_FOR_CAMPAIGN);
        query.setParameter("campaign", campaign);
        return query.executeUpdate();
    }

    @Override
    public PointOfSale saveOrUpdate(PointOfSale pointOfSale) {
        if (isServiceCenterBeingChanged(pointOfSale)) {
            changeServiceCenter(pointOfSale);
        }

        PointOfSale pos = findPersistedPointOfSale(pointOfSale);

        if (pos != null) {
            pos.setDeleted(false);
            pos.setAddress(pointOfSale.getAddress());
            pos.setCounty(pointOfSale.getCounty());
            pos.setCustomer(pointOfSale.getCustomer());
            pos.setLoaded(true);
            pos.setLocality(pointOfSale.getLocality());
            pos.setMail(pointOfSale.getMail());
            pos.setPhone(pointOfSale.getPhone());
            pos.setRegion(pointOfSale.getRegion());
            pos.setSalesGroup(pointOfSale.getSalesGroup());
            pos.setState(pointOfSale.getState());
            pos.setTsrcId(pointOfSale.getTsrcId());
            pos.setType(pointOfSale.getType());
            return pos;
        }

        entityManager.persist(pointOfSale);
        return pointOfSale;
    }

    private PointOfSale findPersistedPointOfSale(PointOfSale pointOfSale) {
        Query query = entityManager.createQuery(FIND_POS_WETHER_DELETED_OR_NOT);
        query.setParameter("idSap", pointOfSale.getIdSap());
        query.setParameter("campaign", pointOfSale.getCampaign());
        PointOfSale pos = null;
        try {
            pos = (PointOfSale) query.getSingleResult();
        } catch (NoResultException e) {
            //TODO this is not really an exception
        }
        return pos;
    }

    private void changeServiceCenter(PointOfSale pointOfSale) {
        Query changeSCQuery = entityManager.createNativeQuery(UPDATE_SERVICE_CENTER_NATIVELY);
        changeSCQuery.setParameter(1, pointOfSale.getServiceCenter().getCuit());
        changeSCQuery.setParameter(2, pointOfSale.getIdSap());
        changeSCQuery.setParameter(3, pointOfSale.getCampaign().getId());
        changeSCQuery.executeUpdate();
        entityManager.flush();
    }

    private boolean isServiceCenterBeingChanged(PointOfSale pointOfSale) {
        Query query = entityManager.createQuery(COUNT_PREVIOUSLY_EXISTING_POS_WITH_SAME_ID_SAP_AND_REFERING_TO_A_DELETED_SC);
        query.setParameter("idSap", pointOfSale.getIdSap());
        query.setParameter("campaign", pointOfSale.getCampaign());
        long count = (Long) query.getSingleResult();
        return count > 0;
    }

    @Override
    public long removeUnloadedPointsOfSaleForCampaign(Campaign campaign) {
        entityManager.flush();
        deleteDependentRowValues(campaign);

        Query query = this.entityManager.createQuery(REMOVE_NOT_LOADED_FOR_CAMPAIGN);
        query.setParameter("campaign", campaign);
        return query.executeUpdate();
    }

    @Override
    public PointOfSale findPointOfSaleByIdSap(Long idSap, Campaign campaign) {
        Query query = entityManager.createQuery(FIND_SC_FOR_THIS_POS_THAT_IS_NOT_DELETED);
        query.setParameter("idSap", idSap);
        query.setParameter("campaign", campaign);
        List<ServiceCenter> resultList = query.getResultList();
        ServiceCenter serviceCenter = resultList.get(0);
        return entityManager.find(PointOfSale.class, new PointOfSaleKey(campaign, idSap, serviceCenter));
    }

    @Override
    public List<PointOfSale> findPointsOfSaleByServiceCenter(ServiceCenter serviceCenter) {
        List<PointOfSale> pointsOfSale = serviceCenter.getPointsOfSale();
        return pointsOfSale != null && !pointsOfSale.isEmpty() ? pointsOfSale : Lists.<PointOfSale>newArrayList();
    }

    @Override
    public List<PointOfSale> findPointsOfSaleByCampaign(Campaign campaign) {
        User user = securityHolderStrategy.getCurrentUser();
        Query query = null;

        if (user.isAdmin()) {
            query = this.entityManager.createQuery(LIST_POINTS_OF_SALE_FOR_CAMPAIGN);
            query.setParameter("campaign", campaign);
        } else {
            Employee employee = entityManager.find(Employee.class, new EmployeeKey(campaign, ((Employee) user).getId()));
            List<PointOfSaleKey> pointsOfSaleIds = new ArrayList<PointOfSaleKey>();
            for (ServiceCenter serviceCenter : employee.getServiceCenters()) {
                for (PointOfSale pos : serviceCenter.getPointsOfSale()) {
                    pointsOfSaleIds.add(new PointOfSaleKey(campaign, pos.getIdSap(), pos.getServiceCenter()));
                }
            }
            query = this.entityManager.createQuery(LIST_POINTS_OF_SALE_FOR_CAMPAIGN_OF_EMPLOYEE);
            query.setParameter("pointsOfSaleIds", pointsOfSaleIds);
            query.setParameter("campaign", campaign);
        }
        return query.getResultList();
    }

    @Override
    public List<PointOfSale> listPointsOfSaleByPage(Campaign campaign, int pageNumber, int pageSize, String sort, String direction, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        PointOfSaleQuery pointOfSaleQuery = new PointOfSaleQuery(entityManager, filter, campaign, user);
        return pointOfSaleQuery.getResultList(pageNumber, pageSize, sort, direction);
    }

    @Override
    public long getPointsOfSaleCount(Campaign campaign, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        PointOfSaleQuery pointOfSaleQuery = new PointOfSaleQuery(entityManager, filter, campaign, user);
        return pointOfSaleQuery.getCount();
    }

    private void deleteDependentRowValues(Campaign campaign) {
        Query query = entityManager.createQuery(FIND_DEPENDENT_ROWS);
        query.setParameter("campaign", campaign);
        List<RowValues> rowValues = query.getResultList();

        for (RowValues rowValue : rowValues) {
            rowValue.setDeleted(true);
        }
    }
}
