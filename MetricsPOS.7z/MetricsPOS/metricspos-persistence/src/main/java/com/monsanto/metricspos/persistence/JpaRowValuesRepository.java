package com.monsanto.metricspos.persistence;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.security.User;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.queries.DataRowQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Implements a RowValuesServices using JPA as a persistence strategy
 *
 * @author PPERA
 */
@Repository("rowValuesServices")
public class JpaRowValuesRepository implements RowValuesServices {
    public static final String ERROR_CANNOT_REMOVE_MEMENTO_THAT_IS_NOT_IN_THE_REPOSITORY = "Cannot remove a row that is not in the repository";
    public static final String FIND_ROWS_OF_TABLE = "select row from RowValues row JOIN row.serviceCenter Where row.table = :table AND row.serviceCenter.deleted = false";
    public static final String MARK_ALL_AS_NOT_LOADED = "UPDATE RowValues r SET loaded = false WHERE loaded = true AND r.table = :table";
    public static final String REMOVE_NOT_LOADED_FROM_TABLE = "UPDATE RowValues r SET deleted = true WHERE loaded = false AND r.table = :table";
    private static final String FIND_ROW_BY_TABLE_AND_ID = "SELECT row FROM RowValues row JOIN row.serviceCenter WHERE row.id = :internalId and row.table = :table AND row.serviceCenter.deleted = false";
    public static final String FIND_ROW_BY_TABLE_AND_SERVICE_CENTER = "Select row from RowValues row where row.serviceCenter = :serviceCenter and row.table = :table";
    public static final String REMOVE_ROWS_BY_TABLE = "DELETE from RowValues row WHERE row.table = :table";
    public static final String RESTORE_DELETED_ROW = "Update MPS.MPS_MULTITABLE_ROW SET DELETED = 0";

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private SecurityHolderStrategy securityHolderStrategy;

    public JpaRowValuesRepository() {
    }

    @Override
    public void add(Object memento) {
        entityManager.persist(memento);
    }

    @Override
    public void remove(Object memento) {
        if (!entityManager.contains(memento)) {
            throw new RuntimeException(ERROR_CANNOT_REMOVE_MEMENTO_THAT_IS_NOT_IN_THE_REPOSITORY);
        }

        this.entityManager.remove(memento);
    }

    @Override
    public DataRow findDataRowByDataTableAndDataRowId(DataTable table, int internalId) {
        Query query = entityManager.createQuery(FIND_ROW_BY_TABLE_AND_ID);
        query.setParameter("internalId", internalId);
        query.setParameter("table", table);
        RowValues rowValues = (RowValues) query.getSingleResult();
        return new DataRow(table, rowValues);
    }

    @Override
    public long countRows(DataTable dataTable, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        DataRowQuery dataRowQuery = new DataRowQuery(filter, dataTable, entityManager, user);
        return dataRowQuery.getCount();
    }

    @Override
    public long markTableRecordsAsNotLoaded(DataTable table) {
        Query query = this.entityManager.createQuery(MARK_ALL_AS_NOT_LOADED);
        query.setParameter("table", table);
        return (long) query.executeUpdate();
    }

    @Override
    public void saveOrUpdate(Object rowValues) {
        if (((RowValues) rowValues).getId() != null) {
            this.entityManager.merge(rowValues);
        }

        this.entityManager.persist(rowValues);
    }

    @Override
    public long removeAllNotLoadedRecordsForTable(DataTable table) {
        entityManager.flush();
        Query query = this.entityManager.createQuery(REMOVE_NOT_LOADED_FROM_TABLE);
        query.setParameter("table", table);
        return (long) query.executeUpdate();
    }

    @Override
    public void cleanColumnContents(DataTable dataTable, DataColumn dataColumn) {
        Query query = this.entityManager.createQuery(this.makeCleanColumnUpdate(dataColumn));
        query.setParameter("table", dataTable);
        query.executeUpdate();
    }

    @Override
    public void clearPointsOfSale(DataTable dataTable) {
        List<RowValues> rows = findRowsOfTable(dataTable);

        for (RowValues row : rows) {
            row.setPointOfSale(null);
        }
    }

    @Override
    public void clearFileDataContent(DataTable dataTable) {
        List<RowValues> rows = findRowsOfTable(dataTable);

        for (RowValues row : rows) {
            row.setDataFile(null);
        }
    }

    private List<RowValues> findRowsOfTable(DataTable dataTable) {
        Query query = this.entityManager.createQuery(FIND_ROWS_OF_TABLE);
        query.setParameter("table", dataTable);
        return query.getResultList();
    }

    @Override
    public DataRow findByTableAndFilterEvenDeleted(DataTable dataTable, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        Query nativeQuery = entityManager.createNativeQuery(RESTORE_DELETED_ROW + makeNativePKFilter(dataTable, filter));
        this.setNativePKParameters(filter, nativeQuery);
        nativeQuery.executeUpdate();

        entityManager.flush();

        DataRowQuery dataRowQuery = new DataRowQuery(filter, dataTable, entityManager, user);
        Object rowValues = dataRowQuery.getSingleResult();
        if (rowValues == null) {
            return null;
        } else {
            return new DataRow(dataTable, rowValues);
        }
    }

    private void setNativePKParameters(Map<String, Object> filter, Query nativeQuery) {
        List<String> keys = Lists.newArrayList(filter.keySet());
        Collections.sort(keys, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o1.compareTo(o2);
            }
        });

        for (String key : keys) {
            Object queryParameter = null;
            Object valueObject = filter.get(key);
            if(valueObject != null && valueObject instanceof ServiceCenter){
                queryParameter = ((ServiceCenter) valueObject).getCuit();
            } else if (valueObject != null && valueObject instanceof PointOfSale){
                queryParameter = ((PointOfSale) valueObject).getIdSap();
            }else {
                queryParameter = valueObject;
            }

            nativeQuery.setParameter(keys.indexOf(key) + 1, queryParameter);
        }
    }

    @Override
    public DataRow findByTableAndFilter(DataTable dataTable, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        DataRowQuery dataRowQuery = new DataRowQuery(filter, dataTable, entityManager, user);
        Object rowValues = dataRowQuery.getSingleResult();
        if (rowValues == null) {
            return null;
        } else {
            return new DataRow(dataTable, rowValues);
        }
    }

    private String makeNativePKFilter(DataTable dataTable, Map<String, Object> filter) {
        StringBuilder sb = new StringBuilder();
        sb.append(" ")
                .append("Where DATA_TABLE_ID = ")
                .append(dataTable.getId());

        List<String> keys = Lists.newArrayList(filter.keySet());
        Collections.sort(keys, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o1.compareTo(o2);
            }
        });

        for (String key : keys) {
            DataColumn column = dataTable.getColumn(key);

            if (ServiceCenter.class.equals(column.getDataType().getInternalType())) {
                sb.append(" AND ")
                        .append("cuit")
                        .append(" = ?");
            } else if (PointOfSale.class.equals(column.getDataType().getInternalType())) {
                sb.append(" AND ")
                        .append("POINT_OF_SALE_ID_SAP")
                        .append(" = ?");
            } else {
                String actualColumnName = dataTable.getDataRowPersistor().getActualColumnName(key);
                sb.append(" AND ")
                        .append(actualColumnName)
                        .append(" = ").append("?");
            }
        }
        return sb.toString();
    }

    @Override
    public List<DataRow> findRowsByTableAndServiceCenter(final DataTable dataTable, ServiceCenter serviceCenter) {
        Query query = this.entityManager.createQuery(FIND_ROW_BY_TABLE_AND_SERVICE_CENTER);
        query.setParameter("table", dataTable);
        query.setParameter("serviceCenter", serviceCenter);
        List<Object> result = (List<Object>) query.getResultList();

        return Lists.transform(result, new Function<Object, DataRow>() {
            @Override
            public DataRow apply(Object input) {
                return new DataRow(dataTable, input);
            }
        });
    }

    private String makeCleanColumnUpdate(DataColumn dataColumn) {
        return "UPDATE RowValues r SET r." + dataColumn.getActualColumnName() + " = NULL WHERE r.table = :table";
    }

    @Override
    public List<Object> findRowsByDataTableAndPage(final DataTable table, int page, int rows, String sort, String direction, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        DataRowQuery dataRowQuery = new DataRowQuery(filter, table, entityManager, user);
        return dataRowQuery.getResultList(page, rows, sort, direction);
    }

    @Override
    public List<Object> findRowsByDataTable(final DataTable table, String sort, String direction, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        DataRowQuery dataRowQuery = new DataRowQuery(filter, table, entityManager, user);
        return dataRowQuery.getResultList(sort, direction);
    }

    @Override
    public void removeRowsByTable(DataTable dataTable) {
        Query query = this.entityManager.createQuery(REMOVE_ROWS_BY_TABLE);
        query.setParameter("table", dataTable);
        query.executeUpdate();
    }
}
