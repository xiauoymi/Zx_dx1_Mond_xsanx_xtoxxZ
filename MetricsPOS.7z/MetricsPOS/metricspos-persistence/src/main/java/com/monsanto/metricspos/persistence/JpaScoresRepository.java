package com.monsanto.metricspos.persistence;

import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.security.User;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.queries.MetricScoreCampaignQuery;
import com.monsanto.metricspos.persistence.queries.MetricScoreQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

/**
 * Provides the services to persist and load metric scores
 *
 * @author cafau
 */
@Repository
public class JpaScoresRepository implements ScoreServices {
    public static final String FIND_SCORE_BY_METRIC_AND_SERVICE_CENTER = "Select score from MetricScore score where score.serviceCenter = :serviceCenter and score.metric = :metric ORDER BY serviceCenter.name";

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private SecurityHolderStrategy securityHolderStrategy;

    @Override
    public MetricScore newMetricScore(Metric metric, ServiceCenter serviceCenter) {
        MetricScore metricScore = new MetricScore(metric, serviceCenter);
        entityManager.persist(metricScore);
        metric.getScores().add(metricScore);
        return metricScore;
    }

    @Override
    public List<MetricScore> findScoresByMetric(Metric metric, int page, int rows, String sort, String direction, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        MetricScoreQuery metricScoreQuery = new MetricScoreQuery(entityManager, filter, metric, user);
        return metricScoreQuery.getResultList(page, rows, sort, direction);
    }

    @Override
    public List<MetricScore> findScoresByCampaign(Campaign campaign, int page, int rows, String sort, String direction, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        MetricScoreCampaignQuery metricScoreCampaignQuery = new MetricScoreCampaignQuery(entityManager, filter, campaign, user);
        return metricScoreCampaignQuery.getResultList(page, rows, sort, direction);
    }

    @Override
    public List<MetricScore> findAllScoresByCampaign(Campaign campaign, String sort, String direction, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        MetricScoreCampaignQuery metricScoreCampaignQuery = new MetricScoreCampaignQuery(entityManager, filter, campaign, user);
        return metricScoreCampaignQuery.getResultList(sort, direction);
    }


    @Override
    public long getTotalScoresCount(Metric metric, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        MetricScoreQuery metricScoreQuery = new MetricScoreQuery(entityManager, filter, metric, user);
        return metricScoreQuery.getCount();
    }

    @Override
    public long getTotalCampaignScoresCount(Campaign campaign, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        MetricScoreCampaignQuery metricScoreCampaignQuery = new MetricScoreCampaignQuery(entityManager, filter, campaign, user);
        return metricScoreCampaignQuery.getCount();
    }

    @Override
    public MetricScore findScoreByMetricAndServiceCenter(Metric metric, ServiceCenter serviceCenter) {
        Query query = this.entityManager.createQuery(FIND_SCORE_BY_METRIC_AND_SERVICE_CENTER);
        query.setParameter("serviceCenter", serviceCenter);
        query.setParameter("metric", metric);
        return (MetricScore) query.getSingleResult();
    }
}
