package com.monsanto.metricspos.persistence;

import com.monsanto.metricspos.core.ServiceCenterServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.security.User;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.keys.EmployeeKey;
import com.monsanto.metricspos.persistence.queries.ServiceCenterQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

/**
 * Provides the Service Center services through JPA
 *
 * @author cafau
 */
@Repository("serviceCenterServices")
public class JpaServiceCenterRepository implements ServiceCenterServices {
    /**
     * Manual loaded records are not considered for deletion while the loading process is executed
     */
    public static final String MARK_ALL_SC_AS_UNLOADED = "update ServiceCenter sc set sc.loaded=false where sc.manual = false and sc.campaign = :campaign";
    public static final String REMOVE_ALL_UNLOADED_SC = "update ServiceCenter sc set sc.deleted=true where sc.loaded = false and sc.manual = false and sc.campaign = :campaign";
    public static final String FIND_SERVICE_CENTER_BY_CAMPAIGN_AND_CUIT = "Select sc from ServiceCenter sc where sc.cuit = :cuit and sc.campaign = :campaign";
    public static final String FIND_DEPENDENT_ROW_VALUES = "Select rows from RowValues rows Join rows.serviceCenter sc where sc.loaded = false and sc.campaign = :campaign";
    public static final String FIND_DEPENDENT_POINTS_OF_SALE = "Select pos from PointOfSale pos Join pos.serviceCenter sc where sc.deleted = false and sc.loaded = false and sc.campaign = :campaign";
    public static final String FIND_ALL_SERVICE_CENTERS = "select sc from ServiceCenter sc where sc.campaign = :campaign AND sc.deleted = false ORDER BY sc.name asc";
    public static final String SELECT_METRIC_SCORES_TO_DELETE = "select ms from MetricScore ms Join ms.serviceCenter sc where sc.loaded= false and sc.campaign= :campaign";

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private SecurityHolderStrategy securityHolderStrategy;

    @Override
    public long markAllServiceCentersAsNotLoadedInCampaign(Campaign campaign) {
        return entityManager.createQuery(MARK_ALL_SC_AS_UNLOADED).setParameter("campaign", campaign).executeUpdate();
    }

    @Override
    public ServiceCenter findServiceCenterByCuit(String cuit, Campaign campaign) {
        Query query = entityManager.createQuery(FIND_SERVICE_CENTER_BY_CAMPAIGN_AND_CUIT);
        query.setParameter("campaign", campaign);
        query.setParameter("cuit", cuit);
        ServiceCenter singleResult = null;
        try {
            singleResult = (ServiceCenter) query.getSingleResult();
        } catch (NoResultException e) {
            //TODO this is not really an exception
        }
        return singleResult;
    }

    @Override
    public long removeAllNotLoadedServiceCenters(Campaign campaign) {
        entityManager.flush();
        deleteDependentScores(campaign);
        deleteDependentPointsOfSales(campaign);
        deleteDependentRowValues(campaign);
        Query removeNotLoadedQuery = entityManager.createQuery(REMOVE_ALL_UNLOADED_SC);
        removeNotLoadedQuery.setParameter("campaign", campaign);
        return removeNotLoadedQuery.executeUpdate();
    }

    private void deleteDependentScores(Campaign campaign) {
        Query query = entityManager.createQuery(SELECT_METRIC_SCORES_TO_DELETE);
        query.setParameter("campaign", campaign);
        List<MetricScore> metricScoreList= query.getResultList();
        for (MetricScore metricScore : metricScoreList) {
            entityManager.remove(metricScore);
        }
        entityManager.flush();
    }

    @Override
    public ServiceCenter saveOrUpdate(ServiceCenter serviceCenter) {
        Query nativeQuery = entityManager.createNativeQuery("UPDATE MPS.MPS_SERVICE_CENTER SET DELETED = 0 WHERE CUIT = ? AND CAMPAIGN_ID = ?");
        nativeQuery.setParameter(1, serviceCenter.getCuit());
        nativeQuery.setParameter(2, serviceCenter.getCampaign().getId());
        nativeQuery.executeUpdate();
        entityManager.flush();

        ServiceCenter center = this.findServiceCenterByCuit(serviceCenter.getCuit(), serviceCenter.getCampaign());
        if (center != null) {
            if(serviceCenter.getName() != null){
                center.setName(serviceCenter.getName());
            }
            if(serviceCenter.getMail() != null){
                center.setMail(serviceCenter.getMail());
            }

            center.setLoaded(serviceCenter.isLoaded());
            return center;
        } else {
            entityManager.persist(serviceCenter);
            return serviceCenter;
        }

    }

    @Override
    public List<ServiceCenter> listServiceCentersByPage(Campaign campaign, int page, int rows, String sort, String direction, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        ServiceCenterQuery serviceCenterQuery = new ServiceCenterQuery(filter, entityManager, campaign, user);
        return serviceCenterQuery.getResultList(page, rows, sort, direction);
    }

    @Override
    public long getServiceCentersCount(Campaign campaign, Map<String, Object> filter) {
        User user = securityHolderStrategy.getCurrentUser();
        ServiceCenterQuery serviceCenterQuery = new ServiceCenterQuery(filter, entityManager, campaign, user);
        return serviceCenterQuery.getCount();
    }

    @Override
    public List<ServiceCenter> listServiceCenters(Campaign campaign) {
        User user = this.securityHolderStrategy.getCurrentUser();

        Query query = null;

        if (user.isAdmin()) {
            query = entityManager.createQuery(FIND_ALL_SERVICE_CENTERS);
            query.setParameter("campaign", campaign);
            return (List<ServiceCenter>) query.getResultList();
        } else {
            EmployeeKey key = new EmployeeKey(campaign, ((Employee) user).getId());
            Employee employee = entityManager.find(Employee.class, key);
            List<ServiceCenter> serviceCenters = employee.getServiceCenters();
            for (ServiceCenter serviceCenter : serviceCenters) {
                serviceCenter.getCuit();
            }
            return serviceCenters;
        }
    }

    private void deleteDependentRowValues(Campaign campaign) {
        Query query = entityManager.createQuery(FIND_DEPENDENT_ROW_VALUES);
        query.setParameter("campaign", campaign);
        List<RowValues> rowValues = query.getResultList();

        for (RowValues rowValue : rowValues) {
            rowValue.setDeleted(true);
        }
    }

    private void deleteDependentPointsOfSales(Campaign campaign) {
        Query query = entityManager.createQuery(FIND_DEPENDENT_POINTS_OF_SALE);
        query.setParameter("campaign", campaign);
        List<PointOfSale> pointsOfSale = query.getResultList();

        for (PointOfSale pointOfSale : pointsOfSale) {
            pointOfSale.setDeleted(true);
        }
    }
}
