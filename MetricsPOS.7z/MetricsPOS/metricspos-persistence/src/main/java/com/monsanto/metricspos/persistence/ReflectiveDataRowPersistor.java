package com.monsanto.metricspos.persistence;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.DataRowVO;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataFile;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import static com.monsanto.metricspos.core.externaldata.converters.ConverterUtils.makeConverterService;

/**
 * DataRowPersistor that use reflection into a RowData object to hold values of DataRows
 */
public class ReflectiveDataRowPersistor implements DataRowPersistor {

    private final DataTable dataTable;

    /**
     * Actual mapping between a DataColumn a a field of the rowValues entity
     */
    private Map<Class, String> classStringMap;
    private List<String> fields;

    public ReflectiveDataRowPersistor(DataTable dataTable, Map<Class, String> classStringMap) {
        this.dataTable = dataTable;
        this.classStringMap = classStringMap;

        this.fields = Lists.transform(Lists.<Field>newArrayList(RowValues.class.getDeclaredFields()), new Function<Field, String>() {
            @Override
            public String apply(Field input) {
                return input.getName();
            }
        });
    }

    public String getActualColumnName(String columnName) {
        if (DataRowVO.ROW_ID_KEY.equals(columnName)) {
            return "id";
        }

        if (!dataTable.getColumnNames().contains(columnName)) {
            return null;
        }

        return dataTable.getColumn(columnName).getActualColumnName();
    }

    @Override
    public Integer getInternalId(Object rowValues) {
        return ((RowValues) rowValues).getId();
    }

    @Override
    public Object makeRowValues(Map<String, Object> rowData) {
        RowValues rowValues = newRowValues();

        List<DataColumn> columns = dataTable.getColumns();

        for (DataColumn column : columns) {
            this.set(rowValues, column.getName(), rowData.get(column.getName()));
        }

        return rowValues;
    }

    @Override
    public boolean getManual(Object rowValues) {
        return ((RowValues) rowValues).getManual();
    }

    @Override
    public void setManual(Object rowValues, boolean manual) {
        ((RowValues) rowValues).setManual(manual);
    }

    @Override
    public void setLoaded(Object rowValues, boolean loaded) {
        ((RowValues) rowValues).setLoaded(loaded);
    }

    @Override
    public ServiceCenter getServiceCenter(Object rowValues) {
        return ((RowValues) rowValues).getServiceCenter();
    }

    @Override
    public void setServiceCenter(Object rowValues, ServiceCenter serviceCenter) {
        ((RowValues) rowValues).setServiceCenter(serviceCenter);
    }

    @Override
    public PointOfSale getPointOfSale(Object rowValues) {
        return ((RowValues) rowValues).getPointOfSale();
    }

    @Override
    public void setPointOfSale(Object rowValues, PointOfSale pointOfSale) {
        ((RowValues) rowValues).setPointOfSale(pointOfSale);
    }

    @Override
    public DataFile getDataFile(Object rowValues) {
        return ((RowValues) rowValues).getDataFile();
    }


    @Override
    public void assignActualColumnNames(List<DataColumn> dataColumns) {
        List<String> fieldInUse = Lists.newArrayList();
        List<DataColumn> unasignedColumns = Lists.newArrayList();

        for (DataColumn dataColumn : dataColumns) {
            if (dataColumn.getActualColumnName() != null) {
                fieldInUse.add(dataColumn.getActualColumnName());
            } else {
                unasignedColumns.add(dataColumn);
            }
        }

        for (DataColumn dataColumn : unasignedColumns) {
            String availableField = this.getFieldWithLowestIndexOfMatchingPrefix(fieldInUse, this.getCorrespondingPrefix(dataColumn));
            validateFieldExists(availableField, dataColumn.getDataType().getCode());
            dataColumn.setActualColumnName(availableField);
            fieldInUse.add(availableField);
        }
    }

    private void validateFieldExists(String availableField, String typeCode) {
        if (!this.fields.contains(availableField)) {
            throw new BusinessException(BusinessException.ERROR_TOO_MANY_COLUMNS_OF_TYPE + "[" + typeCode + "]", 507);
        }
    }

    /**
     * Sets the provided value to the column with the given defined columnName
     *
     * @param rowValues  xx
     * @param columnName defined by the DataTable
     * @param value      to be set
     */
    @Override
    public void set(Object rowValues, String columnName, Object value) {
        if (!(rowValues instanceof RowValues)) {
            throw new RuntimeException();
        }

        DataColumn column = dataTable.getColumn(columnName);

        Field field = ReflectionUtils.findField(RowValues.class, column.getActualColumnName());
        ReflectionUtils.makeAccessible(field);
        ReflectionUtils.setField(field, rowValues, makeConverterService(dataTable.getCampaign()).convert(value, column.getDataType().getInternalType()));
    }

    /**
     * The value to which the column is set
     *
     * @param rowValues  xx
     * @param columnName defined in the DataTable.
     * @return the value of the column for this row.
     */
    @Override
    @SuppressWarnings("unchecked")
    public Object get(Object rowValues, String columnName) {
        if (!(rowValues instanceof RowValues)) {
            throw new RuntimeException();
        }
        DataColumn column = dataTable.getColumn(columnName);
        Field field = ReflectionUtils.findField(RowValues.class, getActualColumnName(columnName));
        ReflectionUtils.makeAccessible(field);
        return makeConverterService(dataTable.getCampaign()).convert(ReflectionUtils.getField(field, rowValues), column.getDataType().getInternalType());
    }

    @Override
    public RowValues newRowValues() {
        return new RowValues(dataTable);
    }

    private String getCorrespondingPrefix(DataColumn dataColumn) {
        return classStringMap.get(dataColumn.getDataType().getInternalType());
    }

    private String getFieldWithLowestIndexOfMatchingPrefix(List<String> fieldInUse, String columnPrefix) {
        if (RowValues.SERVICE_CENTER_COLUMN_PREFIX.equals(columnPrefix) ||
                RowValues.POINT_OF_SALE_COLUMN_PREFIX.equals(columnPrefix) ||
                RowValues.DATA_FILE_COLUMN_PREFIX.equals(columnPrefix)) {
            return columnPrefix;
        }

        int index = 1;

        while (fieldInUse.contains(columnPrefix + index)) {
            index++;
        }

        return columnPrefix + index;
    }

    public String getServiceCenterColumnActualName() {
        return classStringMap.get(ServiceCenter.class);
    }

    @Override
    public void setDeleted(Object rowValues, boolean deleted) {
        ((RowValues) rowValues).setDeleted(deleted);
    }
}