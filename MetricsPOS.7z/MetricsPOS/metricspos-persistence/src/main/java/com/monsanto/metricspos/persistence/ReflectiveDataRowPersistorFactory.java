package com.monsanto.metricspos.persistence;

import com.monsanto.metricspos.core.externaldata.DataTable;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;

/**
 * Factory that builds data row persistors base on reflexion.
 *
 * @author CAFAU
 */
@Component("dataRowPersistorFactory")
public class ReflectiveDataRowPersistorFactory implements DataRowPersistorFactory {

    @Resource(name = "classToPrefixMap")
    private Map<Class, String> classToPrefixMap;

    /**
     * Builds a data row persistor for the given table.
     *
     * @param dataTable
     * @return
     */
    @Override
    public DataRowPersistor buildDataRowPersistor(DataTable dataTable) {
        return new ReflectiveDataRowPersistor(dataTable, classToPrefixMap);
    }
}
