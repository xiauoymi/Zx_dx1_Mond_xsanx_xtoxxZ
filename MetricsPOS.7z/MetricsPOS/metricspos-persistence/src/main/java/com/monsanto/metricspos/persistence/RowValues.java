package com.monsanto.metricspos.persistence;

import com.monsanto.metricspos.core.externaldata.DataFile;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Generic entity meant to actually hold the values of a dynamically defined data for
 * a tabular data format.
 *
 * @author PPERA
 */
public class RowValues {
    public static final String TEXT_COLUMN_PREFIX = "text";
    public static final String DATE_COLUMN_PREFIX = "date";
    public static final String NUMBER_COLUMN_PREFIX = "number";
    public static final String SERVICE_CENTER_COLUMN_PREFIX = "serviceCenter";
    public static final String POINT_OF_SALE_COLUMN_PREFIX = "pointOfSale";
    public static final String DATA_FILE_COLUMN_PREFIX = "dataFile";
    private Integer id;
    /**
     * Identifies a row that was created manually
     */
    private boolean manual;

    /**
     * The table definition
     */
    private DataTable table;          /* ID */

    /**
     * Indicates if the row has been loaded in the latest data load process
     */
    private boolean loaded;
    private boolean deleted;
    private ServiceCenter serviceCenter;
    private PointOfSale pointOfSale;
    /*
        private String pk;
        private boolean manual;     // Flag to indicate the row was created by hand by an user and not loaded from source
        private boolean deleteMe;   // Flag used while loading data to delete missing records in source
     */
    private String text1;
    private String text2;
    private String text3;
    private String text4;
    private String text5;
    private String text6;
    private String text7;
    private String text8;
    private String text9;

    private String text10;
    private String text11;
    private String text12;
    private String text13;
    private String text14;
    private String text15;
    private String text16;
    private String text17;
    private String text18;
    private String text19;
    private String text20;

    private BigDecimal number1;
    private BigDecimal number2;
    private BigDecimal number3;
    private BigDecimal number4;
    private BigDecimal number5;
    private BigDecimal number6;
    private BigDecimal number7;

    private BigDecimal number8;
    private BigDecimal number9;
    private BigDecimal number10;
    private Date date1;
    private Date date2;

    private Date date3;
    private Date date4;
    private Date date5;
    private Boolean boolean1;
    private Boolean boolean2;
    private Boolean boolean3;
    private Boolean boolean4;
    private Boolean boolean5;
    private DataFile dataFile;

    /*
       private String text0, text1, textN;
       private Date date0, date1, dateN;
       private BigDecimal decimal0, decimal1, ...;

    */
    public RowValues() {
    }

    public RowValues(DataTable dataTable) {
        this.table = dataTable;
    }

    public DataTable getTable() {
        return table;
    }

    public void setTable(DataTable table) {
        this.table = table;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public boolean getManual() {
        return manual;
    }

    public void setManual(boolean manual) {
        this.manual = manual;
    }

    public void setLoaded(boolean loaded) {
        this.loaded = loaded;
    }

    public boolean getLoaded() {
        return loaded;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public ServiceCenter getServiceCenter() {
        return serviceCenter;
    }

    public void setServiceCenter(ServiceCenter serviceCenter) {
        this.serviceCenter = serviceCenter;
    }

    public void setPointOfSale(PointOfSale pointOfSale) {
        this.pointOfSale = pointOfSale;
    }

    public PointOfSale getPointOfSale() {
        return pointOfSale;
    }

    public DataFile getDataFile() {
        return dataFile;
    }

    public void setDataFile(DataFile dataFile) {
        this.dataFile = dataFile;
    }

    @Override
    public String toString() {
        return "RowValues{" +
                "id=" + id +
                '}';
    }
}
