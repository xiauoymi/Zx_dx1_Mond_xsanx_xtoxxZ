package com.monsanto.metricspos.persistence.hibernate;

import com.google.common.base.Objects;
import com.monsanto.metricspos.core.externaldata.DataFile;
import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.type.StandardBasicTypes;
import org.hibernate.type.Type;
import org.hibernate.usertype.CompositeUserType;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * Created by IntelliJ IDEA.
 * User: LOSICL
 * Date: 1/28/13
 * Time: 4:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class DataFileType implements CompositeUserType {

    private static final int[] TYPES = {Types.VARCHAR, Types.BLOB};

    public int[] sqlTypes() {
        return TYPES;
    }

    @Override
    public String[] getPropertyNames() {
        return new String[]{"fileName", "fileData"};
    }

    @Override
    public Type[] getPropertyTypes() {
        return new Type[]{StandardBasicTypes.STRING,
                StandardBasicTypes.STRING};
    }

    @Override
    public Object getPropertyValue(Object o, int i) throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void setPropertyValue(Object o, int i, Object o1) throws HibernateException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Class returnedClass() {
        return DataFile.class;
    }

    @Override
    public boolean equals(Object o, Object o1) throws HibernateException {
        if (o == o1) return true;
        if (o == null || o1 == null) return false;

        DataFile file1 = (DataFile) o;
        DataFile file2 = (DataFile) o1;

        return Objects.equal(file1.getFileName(), file2.getFileName());

    }

    @Override
    public int hashCode(Object o) throws HibernateException {
        return o.hashCode();
    }

    @Override
    public Object nullSafeGet(ResultSet resultSet, String[] names, SessionImplementor sessionImplementor, Object o) throws HibernateException, SQLException {

        final String fileName = resultSet.getString(names[0]);
        final byte[] fileData = resultSet.getBytes(names[1]);


        return new DataFile(fileName, fileData);
    }

    @Override
    public void nullSafeSet(PreparedStatement preparedStatement, Object value, int i, SessionImplementor sessionImplementor) throws HibernateException, SQLException {
        if (value == null || ((DataFile) value).getFileName() == null) {
            preparedStatement.setNull(i, TYPES[0]);
        } else {
            preparedStatement.setString(i, ((DataFile) value).getFileName());
        }

        if (value == null || ((DataFile) value).getFileData() == null) {
            preparedStatement.setNull(i + 1, TYPES[1]);
        } else {
            preparedStatement.setBytes(i + 1, ((DataFile) value).getFileData());
        }
    }

    @Override
    public Object deepCopy(Object o) throws HibernateException {
        return o;
    }

    @Override
    public boolean isMutable() {
        return false;
    }

    @Override
    public Serializable disassemble(Object value, SessionImplementor sessionImplementor) throws HibernateException {
        return value == null ? null : ((DataFile) value).getFileName();
    }

    @Override
    public Object assemble(Serializable serializable, SessionImplementor sessionImplementor, Object o) throws HibernateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Object replace(Object o, Object o1, SessionImplementor sessionImplementor, Object o2) throws HibernateException {
        return o;
    }
}
