package com.monsanto.metricspos.persistence.hibernate;

import com.monsanto.metricspos.core.externaldata.DataProvider;
import org.hibernate.HibernateException;
import org.hibernate.usertype.UserType;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

/**
 * User: PPERA
 */
public class DataProviderType implements UserType {
    private static final int SQL_TYPE_FOR_DATA_PROVIDER = Types.VARCHAR;

    private Map<String, DataProvider> dataProviders;

    public void setDataProviders(Map<String, DataProvider> dataProviders) {
        this.dataProviders = dataProviders;
    }

    @Override
    public int[] sqlTypes() {
        return new int[]{SQL_TYPE_FOR_DATA_PROVIDER};
    }

    @Override
    public Class returnedClass() {
        return DataProvider.class;
    }

    @Override
    public boolean equals(Object o1, Object o2) throws HibernateException {
         if (o1 == o2) return true;
         if (o1 == null || o2 == null) return false;

        DataProvider provider1 = (DataProvider) o1;
        DataProvider provider2 = (DataProvider) o2;

        // TODO Could be o1 or o2 null?
        return provider1.getCode().equals(provider2.getCode());
    }

    @Override
    public int hashCode(Object o) throws HibernateException {
        return ((DataProvider) o).getCode().hashCode();
    }

    @Override
    public Object nullSafeGet(ResultSet resultSet, String[] strings, Object o) throws HibernateException, SQLException {
        String code = resultSet.getString(strings[0]);

        return getDataProvider(code);
    }

    private Object getDataProvider(String code) {
        if (dataProviders == null) {
            dataProviders = DataProvidersHolder.getDataProviders();
        }

        if (code == null) {
            return null;
        }

        return dataProviders.get(code);
    }

    @Override
    public void nullSafeSet(PreparedStatement preparedStatement, Object value, int index) throws HibernateException, SQLException {
        if (value == null) {
            preparedStatement.setNull(index, SQL_TYPE_FOR_DATA_PROVIDER);
        } else {
            preparedStatement.setString(index, ((DataProvider) value).getCode());
        }
    }

    @Override
    public Object deepCopy(Object value) throws HibernateException {
        return value;   // Immutable value
    }

    @Override
    public boolean isMutable() {
        return false;
    }

    @Override
    public Serializable disassemble(Object value) throws HibernateException {
        return value == null ? null : ((DataProvider) value).getCode();
    }

    @Override
    public Object assemble(Serializable serializable, Object o) throws HibernateException {
        return getDataProvider(serializable == null ? null : serializable.toString());
    }

    @Override
    public Object replace(Object original, Object target, Object owner) throws HibernateException {
        return original;
    }
}
