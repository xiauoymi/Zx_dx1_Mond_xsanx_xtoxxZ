package com.monsanto.metricspos.persistence.hibernate;

import com.monsanto.metricspos.core.externaldata.DataProvider;

import java.util.Map;

/**
 * User: PPERA
 */
public final class DataProvidersHolder {
    private static Map<String, DataProvider> dataProviders;

    public static Map<String, DataProvider> init(Map<String, DataProvider> configuredDataProviders) {
        DataProvidersHolder.dataProviders = configuredDataProviders;
        return configuredDataProviders;
    }

    public static Map<String, DataProvider> getDataProviders() {
        return dataProviders;
    }
}
