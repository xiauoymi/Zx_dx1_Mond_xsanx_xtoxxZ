package com.monsanto.metricspos.persistence.hibernate;

import com.monsanto.metricspos.core.externaldata.DataType;
import org.hibernate.HibernateException;
import org.hibernate.usertype.UserType;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

/**
 * Hibernate type for the DataType in DataColumn elements.
 *
 * @author cafau
 */
public class DataTypeType implements UserType {
    private static final int SQL_TYPE_FOR_DATA_TYPE = Types.VARCHAR;

    private Map<String, DataType> dataTypes;

    public void setDataTypes(Map<String, DataType> dataTypes) {
        this.dataTypes = dataTypes;
    }

    @Override
    public int[] sqlTypes() {
        return new int[] {SQL_TYPE_FOR_DATA_TYPE};
    }

    @Override
    public Class returnedClass() {
        return DataType.class;
    }

    @Override
    public boolean equals(Object o1, Object o2) throws HibernateException {
        DataType type1 = (DataType) o1;
        DataType type2 = (DataType) o2;

        // TODO Could be o1 or o2 null?
        return type1.getCode().equals( type2.getCode());
    }

    @Override
    public int hashCode(Object o) throws HibernateException {
        return ((DataType)o).getCode().hashCode();
    }

    @Override
    public Object nullSafeGet(ResultSet resultSet, String[] strings, Object o) throws HibernateException, SQLException {
        String code = resultSet.getString(strings[0]);

        return getDataType(code);
    }

    private Object getDataType(String code) {
        if(dataTypes == null){
            dataTypes = DataTypesHolder.getDataTypes();
        }

        if ( code == null ) {
            return null;
        }

        return dataTypes.get( code );
    }

    @Override
    public void nullSafeSet(PreparedStatement preparedStatement, Object value, int index) throws HibernateException, SQLException {
        if ( value == null ) {
            preparedStatement.setNull(index, SQL_TYPE_FOR_DATA_TYPE);
        } else {
            preparedStatement.setString(index, ((DataType) value).getCode());
        }
    }

    @Override
    public Object deepCopy(Object value) throws HibernateException {
        return value;   // Immutable value
    }

    @Override
    public boolean isMutable() {
        return false;
    }

    @Override
    public Serializable disassemble(Object value) throws HibernateException {
        return value == null ? null : ((DataType) value).getCode();
    }

    @Override
    public Object assemble(Serializable serializable, Object o) throws HibernateException {
        return getDataType(serializable == null ? null : serializable.toString());
    }

    @Override
    public Object replace(Object original, Object target, Object owner) throws HibernateException {
        return original;
    }
}
