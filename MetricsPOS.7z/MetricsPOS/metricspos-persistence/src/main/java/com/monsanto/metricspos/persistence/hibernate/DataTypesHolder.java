package com.monsanto.metricspos.persistence.hibernate;

import com.monsanto.metricspos.core.externaldata.DataType;
import org.springframework.beans.factory.annotation.Configurable;

import java.util.Map;

/**
 * This class was our solution to a simple problem. How to provide access to our dataTypes
 * spring beans to the Hibernate data type. The answer: Aspects and a static factory method.
 * User: PPERA
 */
@Configurable
public class DataTypesHolder {
    private static Map<String, DataType> dataTypes;

    public static Map<String, DataType> init( Map<String, DataType> dataTypes ) {
        DataTypesHolder.dataTypes = dataTypes;

        return dataTypes;
    }

    public static Map<String, DataType> getDataTypes() {
        return dataTypes;
    }
}
