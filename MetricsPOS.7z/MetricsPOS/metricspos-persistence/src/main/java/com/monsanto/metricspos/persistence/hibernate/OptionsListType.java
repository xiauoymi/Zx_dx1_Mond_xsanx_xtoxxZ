package com.monsanto.metricspos.persistence.hibernate;

import com.google.common.base.Objects;
import org.codehaus.jackson.map.ObjectMapper;
import org.hibernate.HibernateException;
import org.hibernate.type.SerializationException;
import org.hibernate.usertype.UserType;

import java.io.IOException;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

/**
 * User: PPERA
 */
public class OptionsListType implements UserType {
    private static final int SQL_TYPE_FOR_DATA_TYPE = Types.VARCHAR;

    @Override
    public int[] sqlTypes() {
        return new int[]{SQL_TYPE_FOR_DATA_TYPE};
    }

    @Override
    public Class returnedClass() {
        return Map.class;
    }

    @Override
    public boolean equals(Object x, Object y) throws HibernateException {
        return Objects.equal(x, y);
    }

    @Override
    public int hashCode(Object x) throws HibernateException {
        return Objects.hashCode(x);
    }

    @Override
    public Object nullSafeGet(ResultSet resultSet, String[] names, Object owner) throws HibernateException, SQLException {
        String jsonMap = resultSet.getString(names[0]);
        return jsonMap == null ? null : jsonToList(jsonMap);
    }

    @Override
    public void nullSafeSet(PreparedStatement preparedStatement, Object value, int index) throws HibernateException, SQLException {
        if (value == null) {
            preparedStatement.setNull(index, SQL_TYPE_FOR_DATA_TYPE);
        } else {
            preparedStatement.setString(index, toJson(value));
        }
    }

    @Override
    public Object deepCopy(Object value) throws HibernateException {
        return value;
    }

    @Override
    public boolean isMutable() {
        return false;
    }

    @Override
    public Serializable disassemble(Object value) throws HibernateException {
        return value == null ? null : toJson(value);
    }

    @Override
    public Object assemble(Serializable cached, Object owner) throws HibernateException {
        return cached == null ? null : jsonToList(cached.toString());
    }

    @Override
    public Object replace(Object original, Object target, Object owner) throws HibernateException {
        return original;
    }

    //TODO inject object mapper
    private List<String> jsonToList(String jsonMap) {
        List<String> result;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            result = objectMapper.readValue(jsonMap, List.class);
        } catch (IOException e) {
            throw new SerializationException("Could not retrieve options for column from database", e);
        }
        return result;
    }

    private String toJson(Object value) {
        String json;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            json = objectMapper.writeValueAsString(value);
        } catch (IOException e) {
            throw new SerializationException("Could not write options for column in database", e);
        }
        return json;
    }
}
