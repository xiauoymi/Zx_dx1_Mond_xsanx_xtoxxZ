package com.monsanto.metricspos.persistence.keys;

import com.monsanto.metricspos.core.metrics.Campaign;

import java.io.Serializable;

/**
 * User: PPERA
 */
public class EmployeeKey implements Serializable {

    private long id;
    private Campaign campaign;

    public EmployeeKey() {
    }

    public EmployeeKey(Campaign campaign, long id) {
        this.campaign = campaign;
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }
}
