package com.monsanto.metricspos.persistence.keys;

import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.ServiceCenter;

import java.io.Serializable;

/**
 * User: PPERA
 */
public class PointOfSaleKey implements Serializable{

    private Campaign campaign;
    private Long idSap;
    private ServiceCenter serviceCenter;

    public PointOfSaleKey() {
    }

    public PointOfSaleKey(Campaign campaign, Long idSap, ServiceCenter serviceCenter) {
        this.campaign = campaign;
        this.idSap = idSap;
        this.serviceCenter = serviceCenter;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public ServiceCenter getServiceCenter() {
        return serviceCenter;
    }

    public void setServiceCenter(ServiceCenter serviceCenter) {
        this.serviceCenter = serviceCenter;
    }

    public Long getIdSap() {
        return idSap;
    }

    public void setIdSap(Long idSap) {
        this.idSap = idSap;
    }
}
