package com.monsanto.metricspos.persistence.keys;

import com.google.common.base.Objects;
import com.monsanto.metricspos.core.metrics.Campaign;

import java.io.Serializable;

/**
 * The composite key for a Service Center
 *
 * @author cafau
 */
public class ServiceCenterKey implements Serializable {

    private Campaign campaign;
    private String cuit;

    public ServiceCenterKey() {
    }

    public ServiceCenterKey(Campaign campaign, String cuit) {
        this.campaign = campaign;
        this.cuit = cuit;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    @Override
    public boolean equals(Object o) {
        return Objects.equal(this.campaign.getId(), ((ServiceCenterKey) o).campaign.getId()) &&
                Objects.equal(this.cuit, ((ServiceCenterKey) o).cuit);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.campaign, this.cuit);
    }
}
