package com.monsanto.metricspos.persistence.queries;

import com.monsanto.metricspos.core.security.User;

import javax.annotation.Nullable;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

/**
 * This is an abtract class that contains the common behaviour that takes place
 * when querying the database for certain entities. It's specially useful when
 * a paging, sorting and filtering mechanism is required. It is also able to make
 * a difference when the query is executed by an admin or a regular user.
 * <p/>
 * User: LOSICL
 * Updated: PPERA
 */
public abstract class AbstractQuery<ResultElementType, InputFilterType, TransformedFilterType> {

    private static final String DEF_DIRECTION = "ASC";

    protected EntityManager entityManager;
    protected String alias;
    protected User user;
    protected TransformedFilterType filter;

    public AbstractQuery(EntityManager entityManager, String alias, @Nullable User user) {
        this.entityManager = entityManager;
        this.alias = alias;
        this.user = user;
    }

    /**
     * When the filter is set is previously processed to adapt the content to that which
     * is required by the query.
     *
     * @param filter Filter to process
     */
    protected void setFilter(InputFilterType filter) {
        this.filter = processFilterConditions(filter);
    }

    /**
     * This method should decide what to take from the input filter and make the
     * necessary conversions of the filter values.
     *
     * @param filter the filter to process
     * @return The processed filter
     */
    protected abstract TransformedFilterType processFilterConditions(InputFilterType filter);

    /**
     * The base query might contain a where clause but not an order by or group by clause
     *
     * @return The base query
     */
    protected abstract String getBaseQuery();

    /**
     * Should be like the base query but with a count instead of the fields list.
     *
     * @return The count query
     */
    protected abstract String getCountQuery();

    /**
     * Returns a page using the filter with which the query was created
     *
     * @param page      the desired page
     * @param rows      the amount of rows in the page
     * @param sort      the property of the db to sort by
     * @param direction the sort direction
     * @return The list of result that correspond to the page
     */
    public List<ResultElementType> getResultList(int page, int rows, String sort, String direction) {
        Query query = entityManager.createQuery(this.getQueryStringWithSort(sort, direction));
        setFilterParameters(query, this.filter);
        query.setFirstResult((page - 1) * rows);

        setExtraParametersToQuery(query);

        query.setMaxResults(rows);
        return query.getResultList();
    }

    /**
     * Returns the matching result sorted by the specified db property in the
     * provided direction
     *
     * @param sort      the property of the db to sort by
     * @param direction the sort direction
     * @return The list of result that correspond to the page
     */
    public List<ResultElementType> getResultList(String sort, String direction) {
        Query query = entityManager.createQuery(this.getQueryStringWithSort(sort, direction));
        setFilterParameters(query, this.filter);

        setExtraParametersToQuery(query);

        return query.getResultList();
    }

    /**
     * When the query requires a param every time a query is executed and not
     * because it is in the filter, that param should go here
     *
     * @return A map with the param key and it's value
     */
    protected abstract Map<String, Object> getExtraParameters();

    /**
     * Sets the params in the extraParameters map
     *
     * @param query to set the parameters to
     */
    private void setExtraParametersToQuery(Query query) {
        if (this.getExtraParameters() != null) {
            for (String key : this.getExtraParameters().keySet()) {
                query.setParameter(key, this.getExtraParameters().get(key));
            }
        }
    }

    /**
     * A query might not really change if the user is an admin or not. If it doesn't, then
     * this should return false
     *
     * @return true or false
     */
    protected abstract boolean hasUserParameter();

    /**
     * Returns the total matching elements count
     *
     * @return The total amount of matching elements
     */
    public Long getCount() {
        Query query = entityManager.createQuery(this.getCountBaseQueryString());
        setFilterParameters(query, this.filter);
        setExtraParametersToQuery(query);
        return (Long) query.getSingleResult();
    }

    /**
     * Not all parameters are set the same way. Sometimes a parameter might be compared with an equal
     * and sometimes with a LIKE or an IN, etc... Each query should handle the way the filter params are
     * set here.
     *
     * @param query  tho set the params to
     * @param filter with the filter keys and values
     */
    protected abstract void setFilterParameters(Query query, TransformedFilterType filter);

    /**
     * Returns the query with it's order by clause
     *
     * @param sort      the property to sort
     * @param direction the sort direction
     * @return the query with the order by clause
     */
    private String getQueryStringWithSort(String sort, String direction) {
        return this.getQueryString() + getSortPart(sort, direction);
    }

    /**
     * Gets the corresponding query. If the user is relevant then the return value changes
     * when the user permissions vary.
     *
     * @return a query string with the filter conditions
     */
    private String getQueryString() {
        if (this.hasUserParameter() && !user.isAdmin()) {
            return this.getBaseUserQuery() + getFilterConditions(this.getBaseQuery());
        }
        return this.getBaseQuery() + getFilterConditions(this.getBaseQuery());
    }

    /**
     * The base query to be used if the user is not an admin
     *
     * @return the base user query
     */
    protected abstract String getBaseUserQuery();

    /**
     * Gets the corresponding count query. If the user is relevant then the return value changes
     * when the user permissions vary.
     *
     * @return a query with it's filter conditions
     */
    private String getCountBaseQueryString() {
        if (this.hasUserParameter() && !user.isAdmin()) {
            return this.getCountUserQuery() + getFilterConditions(this.getCountQuery());
        }
        return this.getCountQuery() + getFilterConditions(this.getCountQuery());
    }

    /**
     * The count query to be used if the user is not an admin
     *
     * @return The count user query
     */
    protected abstract String getCountUserQuery();

    /**
     * Not all parameters are set the same way. Sometimes a parameter might be compared with an equal
     * and sometimes with a LIKE or an IN, etc... Each query should handle the way the filter conditions
     * are used here.
     *
     * @param query a string with where conditions. Might contain a where or not depending on the base query
     * @return The filter conditions
     */
    protected abstract String getFilterConditions(String query);

    /**
     * Returns an order by clause for the provided property to be sorted
     *
     * @param sort      The sort property
     * @param direction The direction of the sort
     * @return The sort string including the Order by
     */
    protected String getSortPart(String sort, String direction) {
        if (sort == null || sort.isEmpty()) {
            return "";
        }

        String directionPart = " " + (direction != null ? direction : DEF_DIRECTION);

        if (this.getSpecialSorts() != null && this.getSpecialSorts().containsKey(sort)) {
            return this.getSpecialSorts().get(sort) + directionPart;
        }

        return " ORDER BY " + this.alias + "." + sort + directionPart;
    }

    /**
     * Some sort properties require a preprocessing before building the order by clause.
     * This method maps a sort property to the order by clause that should be used to order.
     *
     * @return A map of properties -> Order by clause
     */
    protected abstract Map<String, String> getSpecialSorts();


    /**
     * Obtains the single result returned by the query. If none found returns null.
     *
     * @return The matching result or null
     */
    public ResultElementType getSingleResult() {
        Query query = entityManager.createQuery(this.getQueryString());
        setFilterParameters(query, this.filter);
        setExtraParametersToQuery(query);
        try {
            return (ResultElementType) query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }
}
