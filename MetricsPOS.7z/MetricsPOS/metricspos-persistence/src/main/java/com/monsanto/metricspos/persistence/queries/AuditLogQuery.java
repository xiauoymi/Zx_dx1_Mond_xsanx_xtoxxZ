package com.monsanto.metricspos.persistence.queries;

import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.externaldata.converters.ConverterUtils;
import com.monsanto.metricspos.core.security.AuditLog;
import org.springframework.core.convert.ConversionService;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

/**
 * Object to query for the audit logs
 * User: PPERA
 */
public class AuditLogQuery extends AbstractQuery<AuditLog, Map<String, Object>, Map<String, Object>> {
    private static final String TABLE_ALIAS = "log";
    public static final String BASE_QUERY = "SELECT log FROM AuditLog log";
    public static final String COUNT_QUERY = "SELECT count(log) FROM AuditLog log";
    private static final String DATE_ATTRIBUTE = "date";
    private static final String CONTEXT_ATTRIBUTE = "context";
    private static final String QUALIFIER_ATTRIBUTE = "qualifier";
    private static final String PRIORITY_ATTRIBUTE = "priority";
    private static final String USERNAME_ATTRIBUTE = "username";
    private static final String MESSAGE_ATTRIBUTE = "message";

    public AuditLogQuery(Map<String, Object> filter, EntityManager entityManager) {
        super(entityManager, TABLE_ALIAS, null);
        this.setFilter(filter);
    }

    @Override
    protected Map<String, Object> processFilterConditions(Map<String, Object> filter) {
        Map<String, Object> transformedFilter = Maps.newHashMap();
        ConversionService conversionService = ConverterUtils.makeConverterService();

        if (filter.containsKey(DATE_ATTRIBUTE)) {
            transformedFilter.put(DATE_ATTRIBUTE, conversionService.convert(filter.get(DATE_ATTRIBUTE), Date.class));
        }
        if (filter.containsKey(CONTEXT_ATTRIBUTE)) {
            transformedFilter.put(CONTEXT_ATTRIBUTE, conversionService.convert(filter.get(CONTEXT_ATTRIBUTE), String.class));
        }
        if (filter.containsKey(QUALIFIER_ATTRIBUTE)) {
            transformedFilter.put(QUALIFIER_ATTRIBUTE, conversionService.convert(filter.get(QUALIFIER_ATTRIBUTE), String.class));
        }
        if (filter.containsKey(PRIORITY_ATTRIBUTE)) {
            transformedFilter.put(PRIORITY_ATTRIBUTE, conversionService.convert(filter.get(PRIORITY_ATTRIBUTE), String.class));
        }
        if (filter.containsKey(USERNAME_ATTRIBUTE)) {
            transformedFilter.put(USERNAME_ATTRIBUTE, conversionService.convert(filter.get(USERNAME_ATTRIBUTE), String.class));
        }
        if (filter.containsKey(MESSAGE_ATTRIBUTE)) {
            transformedFilter.put(MESSAGE_ATTRIBUTE, conversionService.convert(filter.get(MESSAGE_ATTRIBUTE), String.class));
        }

        return transformedFilter;
    }

    @Override
    protected String getBaseQuery() {
        return BASE_QUERY;
    }

    @Override
    protected String getCountQuery() {
        return COUNT_QUERY;
    }

    @Override
    protected Map<String, Object> getExtraParameters() {
        return Maps.newHashMap();
    }

    @Override
    protected boolean hasUserParameter() {
        return false;
    }

    @Override
    protected void setFilterParameters(Query query, Map<String, Object> filter) {
        for (String key : filter.keySet()) {
            if (!(USERNAME_ATTRIBUTE.equals(key) || MESSAGE_ATTRIBUTE.equals(key))) {
                if (DATE_ATTRIBUTE.equals(key)) {
                    Date date = (Date) filter.get(key);
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(date);
                    calendar.set(Calendar.HOUR_OF_DAY, 0);
                    calendar.set(Calendar.MINUTE, 0);
                    calendar.set(Calendar.SECOND, 0);
                    calendar.set(Calendar.MILLISECOND, 0);
                    Date dateLow = calendar.getTime();
                    calendar.add(Calendar.DAY_OF_MONTH, 1);
                    Date dateHigh = calendar.getTime();
                    query.setParameter(key + "low", dateLow);
                    query.setParameter(key + "high", dateHigh);
                } else {
                    query.setParameter(key, filter.get(key));
                }
            }
        }
    }

    @Override
    protected String getBaseUserQuery() {
        return BASE_QUERY;
    }

    @Override
    protected String getCountUserQuery() {
        return COUNT_QUERY;
    }

    @Override
    protected String getFilterConditions(String query) {
        StringBuilder stringBuilder = new StringBuilder();

        for (String key : filter.keySet()) {
            if (stringBuilder.length() <= 0) {
                stringBuilder.append(" WHERE ");
            } else {
                stringBuilder.append(" AND ");
            }


            if (USERNAME_ATTRIBUTE.equals(key) || MESSAGE_ATTRIBUTE.equals(key)) {
                stringBuilder.append(TABLE_ALIAS + ".")
                        .append(key)
                        .append(" LIKE '")
                        .append(filter.get(key))
                        .append("%'");
            } else if (DATE_ATTRIBUTE.equals(key)) {
                stringBuilder
                        .append(TABLE_ALIAS + ".")
                        .append(key)
                        .append(" >= :").append(key).append("low")
                        .append(" AND ")
                        .append(TABLE_ALIAS + ".")
                        .append(key)
                        .append(" <= :").append(key).append("high");

            } else {
                stringBuilder.append(TABLE_ALIAS + ".")
                        .append(key)
                        .append(" = :")
                        .append(key);
            }
        }

        return stringBuilder.toString();
    }

    @Override
    protected Map<String, String> getSpecialSorts() {
        return Maps.newHashMap();
    }
}
