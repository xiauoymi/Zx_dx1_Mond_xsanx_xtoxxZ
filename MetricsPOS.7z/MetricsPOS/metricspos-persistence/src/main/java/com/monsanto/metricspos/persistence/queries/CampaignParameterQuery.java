package com.monsanto.metricspos.persistence.queries;

import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.metrics.CampaignParameter;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.HashMap;
import java.util.Map;

/**
 * Object to query for the campaign parameters
 * User: LOSICL
 * Updated: PPERA
 */
public class CampaignParameterQuery extends AbstractQuery<CampaignParameter, Map<String, Object>, Map<String, Object>> {

    public static final String BASE_QUERY = "select p from CampaignParameter p";
    public static final String COUNT_QUERY = "SELECT count(p) FROM CampaignParameter p";
    private static final String TABLE_ALIAS = "p";
    private static final String ID = "id";
    private static final String NAME = "name";
    private static final String VALUE = "value";
    private static final String DESCRIPTION = "description";

    public CampaignParameterQuery(Map<String, Object> filter, EntityManager entityManager) {
        super(entityManager, TABLE_ALIAS, null);
        this.setFilter(filter);
    }

    @Override
    protected Map<String, Object> processFilterConditions(Map<String, Object> filter) {
        Map<String, Object> transformedFilter = new HashMap();

        if (filter.containsKey(ID)) {
            if (filter.get(ID) instanceof String) {
                transformedFilter.put(ID, Integer.valueOf((String) filter.get(ID)));
            } else if (filter.get(ID) instanceof Number) {
                transformedFilter.put(ID, filter.get(ID));
            }
        }
        if (filter.containsKey(NAME)) {
            transformedFilter.put(NAME, filter.get(NAME));
        }
        if (filter.containsKey(VALUE)) {
            transformedFilter.put(VALUE, filter.get(VALUE));
        }
        if (filter.containsKey(DESCRIPTION)) {
            transformedFilter.put(DESCRIPTION, filter.get(DESCRIPTION));
        }

        return transformedFilter;
    }

    @Override
    protected String getBaseQuery() {
        return BASE_QUERY;
    }

    @Override
    protected void setFilterParameters(Query query, Map<String, Object> filter) {
        for (String key : filter.keySet()) {
            if (!(filter.get(key) instanceof String)) {
                query.setParameter(key, filter.get(key));
            }
        }
    }

    @Override
    protected String getBaseUserQuery() {
        return BASE_QUERY;
    }

    @Override
    protected String getCountUserQuery() {
        return COUNT_QUERY;
    }

    @Override
    protected String getFilterConditions(String query) {
        StringBuilder stringBuilder = new StringBuilder();

        for (String key : this.filter.keySet()) {
            if (!query.toUpperCase().contains("WHERE") && stringBuilder.length() == 0) {
                stringBuilder.append(" WHERE ");
            } else {
                stringBuilder.append(" AND ");
            }
            stringBuilder.append(alias)
                    .append(".")
                    .append(key)
                    .append(getCompareString(key, this.filter.get(key)));
        }

        return stringBuilder.toString();
    }

    @Override
    protected Map<String, String> getSpecialSorts() {
        return Maps.newHashMap();
    }

    private String getCompareString(String key, Object value) {
        if (value instanceof String) {
            return " LIKE '" + value + "%'";
        }

        return " = :" + key;
    }

    @Override
    protected String getCountQuery() {
        return COUNT_QUERY;
    }

    @Override
    protected Map<String, Object> getExtraParameters() {
        return null;
    }

    @Override
    protected boolean hasUserParameter() {
        return false;
    }
}
