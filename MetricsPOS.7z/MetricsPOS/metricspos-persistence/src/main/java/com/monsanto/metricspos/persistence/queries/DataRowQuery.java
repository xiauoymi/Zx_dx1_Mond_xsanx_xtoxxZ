package com.monsanto.metricspos.persistence.queries;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.externaldata.RowFilterCondition;
import com.monsanto.metricspos.core.security.User;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.keys.EmployeeKey;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.monsanto.metricspos.core.externaldata.converters.ConverterUtils.makeConverterService;

/**
 * Object to query for data rows in a data table
 * User: PPERA
 */
public class DataRowQuery extends AbstractQuery<Object, Map<String, Object>, List<RowFilterCondition>> {

    public static final String BASE_QUERY = "SELECT row FROM RowValues row JOIN FETCH row.serviceCenter sc LEFT JOIN FETCH row.pointOfSale WHERE row.table = :table";//TODO  AND row.serviceCenter.deleted = false?
    private static final String COUNT_QUERY = "SELECT count(row) FROM RowValues row JOIN row.serviceCenter WHERE row.table = :table AND row.serviceCenter.deleted = false";
    private static final String TABLE_ALIAS = "row";
    private DataTable dataTable;
    private static final String BASE_USER_QUERY = "SELECT row FROM RowValues row JOIN FETCH row.serviceCenter sc LEFT JOIN FETCH row.pointOfSale WHERE row.table = :table and sc.cuit in (:cuits)";
    private static final String COUNT_USER_QUERY = "SELECT count(row) FROM RowValues row JOIN row.serviceCenter sc WHERE row.table = :table AND row.serviceCenter.deleted = false and sc.cuit in (:cuits)";

    public DataRowQuery(Map<String, Object> filter, DataTable dataTable, EntityManager entityManager, User user) {
        super(entityManager, TABLE_ALIAS, user);
        this.dataTable = dataTable;
        this.setFilter(filter);
    }

    @Override
    protected List<RowFilterCondition> processFilterConditions(Map<String, Object> filter) {
        List<RowFilterCondition> internalFilter = Lists.newArrayList();

        for (String key : filter.keySet()) {
            String actualColumnName = dataTable.getDataRowPersistor().getActualColumnName(key);
            if (actualColumnName != null) {
                internalFilter.add(new RowFilterCondition(actualColumnName, dataTable.getColumn(key).getDataType(), makeConverterService(dataTable.getCampaign()).convert(filter.get(key), dataTable.getColumn(key).getDataType().getInternalType())));
            }
        }

        return internalFilter;
    }

    @Override
    protected String getBaseQuery() {
        return BASE_QUERY;
    }

    @Override
    protected String getCountQuery() {
        return COUNT_QUERY;
    }

    @Override
    protected Map<String, Object> getExtraParameters() {
        Map<String, Object> extraParameters = Maps.newHashMap();
        extraParameters.put("table", this.dataTable);

        if (!user.isAdmin()) {
            Employee employee = entityManager.find(Employee.class, new EmployeeKey(dataTable.getCampaign(), ((Employee) user).getId()));
            List<String> cuits = new ArrayList<String>();

            if (employee.getServiceCenters() != null) {
                for (ServiceCenter serviceCenter : employee.getServiceCenters()) {
                    cuits.add(serviceCenter.getCuit());
                }
            }

            extraParameters.put("cuits", cuits);
        }
        return extraParameters;
    }

    @Override
    protected boolean hasUserParameter() {
        return true;
    }

    @Override
    protected void setFilterParameters(Query query, List<RowFilterCondition> filter) {
        for (RowFilterCondition condition : filter) {
            if (!condition.getDataType().getInternalType().equals(String.class)) {
                query.setParameter(condition.getActualColumnName(), condition.getValue());
            }
        }
    }

    @Override
    protected String getBaseUserQuery() {
        return BASE_USER_QUERY;
    }

    @Override
    protected String getCountUserQuery() {
        return COUNT_USER_QUERY;
    }

    @Override
    protected String getFilterConditions(String query) {
        StringBuilder stringBuilder = new StringBuilder();
        for (RowFilterCondition condition : filter) {
            stringBuilder.append(" AND ");
            stringBuilder.append(TABLE_ALIAS + ".")
                    .append(condition.getActualColumnName())
                    .append(getCompareString(condition));
        }
        return stringBuilder.toString();
    }

    @Override
    protected Map<String, String> getSpecialSorts() {
        Map<String, String> specialSorts = Maps.newHashMap();
        specialSorts.put("serviceCenter", " ORDER BY sc.name");
        return specialSorts;
    }

    private String getCompareString(RowFilterCondition condition) {
        if (condition.getDataType().getInternalType().equals(String.class)) {
            return " LIKE '" + condition.getValue() + "%'";
        }

        return " = :" + condition.getActualColumnName();
    }
}