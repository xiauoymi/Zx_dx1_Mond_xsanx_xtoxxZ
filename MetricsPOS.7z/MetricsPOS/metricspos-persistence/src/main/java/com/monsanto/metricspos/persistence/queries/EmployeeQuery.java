package com.monsanto.metricspos.persistence.queries;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.externaldata.converters.ConverterUtils;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;
import org.springframework.core.convert.ConversionService;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

/**
 * Object to query for the employees of a campaign
 * User: PPERA
 */
public class EmployeeQuery extends AbstractQuery<Employee, Map<String, Object>, Map<String, Object>> {
    public static final String FIND_EMPLOYEES_BY_CAMPAIGN = "Select employee from Employee employee where employee.campaign = :campaign";
    public static final String COUNT_EMPLOYEES_BY_CAMPAIGN = "SELECT count(employee.id) FROM Employee employee where employee.campaign = :campaign";
    private static final String TABLE_ALIAS = "employee";
    private Campaign campaign;
    private List<Group> groups;

    public EmployeeQuery(Map<String, Object> filter, Campaign campaign, List<Group> groups, EntityManager entityManager) {
        super(entityManager, TABLE_ALIAS, null);
        this.campaign = campaign;
        this.groups = groups;
        this.setFilter(filter);
    }

    public EmployeeQuery(Campaign campaign, EntityManager entityManager) {
        super(entityManager, TABLE_ALIAS, null);
        this.campaign = campaign;
        this.setFilter(Maps.<String, Object>newHashMap());
    }

    @Override
    protected Map<String, Object> processFilterConditions(Map<String, Object> filter) {
        Map<String, Object> transformedFilter = Maps.newHashMap();
        ConversionService conversionService = ConverterUtils.makeConverterService(campaign);

        List<String> filterableAttributes = Lists.newArrayList("id", "name", "username", "enabled");

        for (String key : filter.keySet()) {
            if (filterableAttributes.contains(key)) {
                transformedFilter.put(key, conversionService.convert(filter.get(key), String.class));
            } else {
                Group group = this.findGroupByName(key);
                if (group != null) {
                    // The exclamation sign is used to indicate that the filter is employees NOT in that group
                    transformedFilter.put((Boolean.valueOf((String) filter.get(key)) ? "" : "!") + key.replaceAll("_", " "), group);
                }
            }
        }

        return transformedFilter;
    }

    private Group findGroupByName(final String key) {
        List<Group> groupsList = Lists.newArrayList(Collections2.filter(this.groups, new Predicate<Group>() {
            @Override
            public boolean apply(Group input) {
                return key.equals(input.getName());
            }
        }));

        if (!groupsList.isEmpty()) {
            return groupsList.get(0);
        } else {
            return null;
        }
    }

    @Override
    protected String getBaseQuery() {
        return FIND_EMPLOYEES_BY_CAMPAIGN;
    }

    @Override
    protected String getCountQuery() {
        return COUNT_EMPLOYEES_BY_CAMPAIGN;
    }

    @Override
    protected Map<String, Object> getExtraParameters() {
        Map<String, Object> extraParameters = Maps.newHashMap();
        extraParameters.put("campaign", campaign);
        return extraParameters;
    }

    @Override
    protected boolean hasUserParameter() {
        return false;
    }

    @Override
    protected void setFilterParameters(Query query, Map<String, Object> filter) {
        ConversionService conversionService = ConverterUtils.makeConverterService(campaign);
        for (String key : filter.keySet()) {
            if ("id".equals(key)) {
                query.setParameter(key, conversionService.convert(filter.get(key), Long.class));
            } else if ("enabled".equals(key)) {
                query.setParameter(key, conversionService.convert(filter.get(key), Boolean.class));
            } else if (filter.get(key) instanceof Group) {
                query.setParameter(normalizeGroupName(key), filter.get(key));
            } else {
                query.setParameter(key, filter.get(key));

            }
        }
    }

    @Override
    protected String getBaseUserQuery() {
        return FIND_EMPLOYEES_BY_CAMPAIGN;
    }

    @Override
    protected String getCountUserQuery() {
        return COUNT_EMPLOYEES_BY_CAMPAIGN;
    }

    @Override
    protected String getFilterConditions(String query) {
        StringBuilder stringBuilder = new StringBuilder();

        for (String key : filter.keySet()) {
            if (Group.class.equals(filter.get(key).getClass())) {
                stringBuilder.append(" AND ");
                stringBuilder.append(":").append(normalizeGroupName(key));
                if (key.contains("!")) {
                    stringBuilder.append(" NOT");
                }
                stringBuilder.append(" MEMBER OF ")
                        .append(TABLE_ALIAS)
                        .append(".groups");
            } else {
                stringBuilder.append(" AND ");
                stringBuilder.append(TABLE_ALIAS + ".")
                        .append(key)
                        .append(" = :")
                        .append(key);
            }
        }

        return stringBuilder.toString();
    }

    private String normalizeGroupName(String key) {
        return key.replaceAll(" ", "").replaceAll("!", "").toLowerCase();
    }

    @Override
    protected Map<String, String> getSpecialSorts() {
        return Maps.newHashMap();
    }
}
