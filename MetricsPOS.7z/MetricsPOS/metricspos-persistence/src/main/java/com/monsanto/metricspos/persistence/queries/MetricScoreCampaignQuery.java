package com.monsanto.metricspos.persistence.queries;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.externaldata.converters.ConverterUtils;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.security.User;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.springframework.core.convert.ConversionService;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Object to query for scores of a campaign
 * User: PPERA
 */
public class MetricScoreCampaignQuery extends AbstractQuery<MetricScore, Map<String, Object>, Map<String, Object>> {
    public static final String FIND_SCORES_FOR_CAMPAIGN = "SELECT score FROM MetricScore score where score.metric.campaign = :campaign";
    public static final String COUNT_SCORES_BY_CAMPAIGN = "SELECT count(score) FROM MetricScore score Where score.metric.campaign = :campaign";
    public static final String FIND_SCORES_FOR_CAMPAIGN_AND_USER = "SELECT score FROM MetricScore score join score.serviceCenter sc where score.metric.campaign = :campaign and sc.cuit in (:cuits)";
    public static final String COUNT_SCORES_BY_CAMPAIGN_AND_USER = "SELECT count(score) FROM MetricScore score join score.serviceCenter sc where score.metric.campaign = :campaign and sc.cuit in (:cuits)";

    private static final String TABLE_ALIAS = "score";
    private static final String SERVICE_CENTER = "serviceCenter";
    private static final String CUIT = "cuit";
    private static final String MODULE = "module";
    private static final String METRIC = "metric";
    private static final String SUBMETRIC = "submetric";
    private static final String POINTS = "points";
    private static final String PENALTY = "penalty";
    private static final String PENALTY_FACTOR = "penaltyFactor";
    private static final String NO_DATA = "noData";
    private static final String LAST_UPDATED = "lastUpdated";
    private static final String DIRTY = "dirty";
    private Campaign campaign;

    public MetricScoreCampaignQuery(EntityManager entityManager, Map<String, Object> filter, Campaign campaign, User user) {
        super(entityManager, TABLE_ALIAS, user);
        this.campaign = campaign;
        this.setFilter(filter);
    }

    @Override
    protected Map<String, Object> processFilterConditions(Map<String, Object> filter) {
        Map<String, Object> transformedFilter = Maps.newHashMap();
        ConversionService conversionService = ConverterUtils.makeConverterService(campaign);

        if (filter.containsKey(SERVICE_CENTER)) {
            transformedFilter.put(SERVICE_CENTER, conversionService.convert(filter.get(SERVICE_CENTER), ServiceCenter.class));
        }
        if (filter.containsKey(CUIT)) {
            transformedFilter.put(CUIT, conversionService.convert(filter.get(CUIT), ServiceCenter.class));
        }
        if (filter.containsKey(MODULE)) {
            transformedFilter.put(MODULE, conversionService.convert(filter.get(MODULE), String.class));
        }
        if (filter.containsKey(METRIC)) {
            transformedFilter.put(METRIC, conversionService.convert(filter.get(METRIC), String.class));
        }
        if (filter.containsKey(SUBMETRIC)) {
            transformedFilter.put(SUBMETRIC, conversionService.convert(filter.get(SUBMETRIC), String.class));
        }
        if (filter.containsKey(POINTS)) {
            transformedFilter.put(POINTS, conversionService.convert(filter.get(POINTS), BigDecimal.class));
        }
        if (filter.containsKey(PENALTY)) {
            transformedFilter.put(PENALTY, conversionService.convert(filter.get(PENALTY), BigDecimal.class));
        }
        if (filter.containsKey(PENALTY_FACTOR)) {
            transformedFilter.put(PENALTY_FACTOR, conversionService.convert(filter.get(PENALTY_FACTOR), BigDecimal.class));
        }
        if (filter.containsKey(NO_DATA)) {
            transformedFilter.put(NO_DATA, conversionService.convert(filter.get(NO_DATA), Boolean.class));
        }
        if (filter.containsKey(LAST_UPDATED)) {
            transformedFilter.put(LAST_UPDATED, conversionService.convert(filter.get(LAST_UPDATED), Date.class));
        }
        if (filter.containsKey(DIRTY)) {
            transformedFilter.put(DIRTY, conversionService.convert(filter.get(DIRTY), Boolean.class));
        }
        return transformedFilter;
    }

    @Override
    protected String getBaseQuery() {
        return FIND_SCORES_FOR_CAMPAIGN;
    }

    @Override
    protected String getCountQuery() {
        return COUNT_SCORES_BY_CAMPAIGN;
    }

    @Override
    protected Map<String, Object> getExtraParameters() {
        Map<String, Object> extraParameters = Maps.newHashMap();

        if (!user.isAdmin()) {
            final Employee employee = (Employee) user;

            List<String> cuits = Lists.transform(employee.getServiceCenters(), new Function<ServiceCenter, String>() {
                @Override
                public String apply(ServiceCenter input) {
                    return input.getCuit();
                }
            });

            extraParameters.put("cuits", cuits);
        }

        extraParameters.put("campaign", campaign);
        return extraParameters;
    }

    @Override
    protected boolean hasUserParameter() {
        return true;
    }

    @Override
    protected void setFilterParameters(Query query, Map<String, Object> filter) {
        for (String key : filter.keySet()) {
            query.setParameter(key, filter.get(key));
        }
    }

    @Override
    protected String getBaseUserQuery() {
        return FIND_SCORES_FOR_CAMPAIGN_AND_USER;
    }

    @Override
    protected String getCountUserQuery() {
        return COUNT_SCORES_BY_CAMPAIGN_AND_USER;
    }

    @Override
    protected String getFilterConditions(String query) {
        StringBuilder stringBuilder = new StringBuilder();

        for (String key : filter.keySet()) {
            stringBuilder.append(" AND ");
            if (MODULE.equals(key)) {
                stringBuilder.append("score.metric.parent.parent.name")
                        .append(" LIKE :")
                        .append(key);
            } else if (METRIC.equals(key)) {
                stringBuilder.append("score.metric.parent.name")
                        .append(" LIKE :")
                        .append(key);
            } else if (SUBMETRIC.equals(key)) {
                stringBuilder.append("score.metric.name")
                        .append(" LIKE :")
                        .append(key);
            } else if (CUIT.equals(key)) {
                stringBuilder.append("score.serviceCenter")
                        .append(" = :")
                        .append(key);
            } else {
                stringBuilder.append("score.")
                        .append(key)
                        .append(" = :")
                        .append(key);
            }
        }

        return stringBuilder.toString();
    }

    @Override
    protected Map<String, String> getSpecialSorts() {
        Map<String, String> specialSorts = Maps.newHashMap();
        specialSorts.put(CUIT, " ORDER BY score.serviceCenter.cuit");
        specialSorts.put(SERVICE_CENTER, " ORDER BY score.serviceCenter.name");
        specialSorts.put(MODULE, " ORDER BY score.metric.parent.parent.name");
        specialSorts.put(METRIC, " ORDER BY score.metric.parent.name");
        specialSorts.put(SUBMETRIC, " ORDER BY score.metric.name");
        return specialSorts;
    }
}
