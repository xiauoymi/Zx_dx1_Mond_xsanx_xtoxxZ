package com.monsanto.metricspos.persistence.queries;

import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.externaldata.converters.ConverterUtils;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.security.User;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.keys.EmployeeKey;
import com.monsanto.metricspos.persistence.keys.PointOfSaleKey;
import org.springframework.core.convert.ConversionService;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Object to query for the points of sale in a campaign
 * User: PPERA
 */
public class PointOfSaleQuery extends AbstractQuery<PointOfSale, Map<String, Object>, Map<String, Object>> {
    public static final String FIND_POINTS_OF_SALE_BY_CAMPAIGN = "Select pos from PointOfSale pos where pos.campaign = :campaign and pos.deleted = false and pos.serviceCenter.deleted = false";
    public static final String FIND_POINTS_OF_SALE_BY_CAMPAIGN_AND_USER = "SELECT pos FROM PointOfSale pos WHERE pos.campaign = :campaign AND pos.id in (:pointsOfSaleIds)";
    public static final String COUNT_POINT_OF_SALE_BY_CAMPAIGN = "SELECT count(pos.idSap) FROM PointOfSale pos where pos.campaign = :campaign and pos.deleted = false";
    private static final String COUNT_POINT_OF_SALE_BY_CAMPAIGN_AND_USER = "SELECT count(pos.idSap) FROM PointOfSale pos WHERE pos.campaign = :campaign AND pos.id in (:pointsOfSaleIds)";
    private static final String ID_SAP = "idSap";
    private static final String SALES_GROUP = "salesGroup";
    private static final String REGION = "region";
    private static final String TYPE = "type";
    private static final String TSRC_ID = "tsrcId";
    private static final String CUSTOMER = "customer";
    private static final String LOCALITY = "locality";
    private static final String COUNTY = "county";
    private static final String STATE = "state";
    private static final String ADDRESS = "address";
    private static final String PHONE = "phone";
    private static final String MAIL = "mail";
    private static final String SERVICE_CENTER = "serviceCenter";
    private Campaign campaign;
    private static final String TABLE_ALIAS = "pos";

    public PointOfSaleQuery(EntityManager entityManager, Map<String, Object> filter, Campaign campaign, User user) {
        super(entityManager, TABLE_ALIAS, user);
        this.campaign = campaign;
        this.setFilter(filter);
    }

    @Override
    protected Map<String, Object> processFilterConditions(Map<String, Object> filter) {
        Map<String, Object> transformedFilter = Maps.newHashMap();
        ConversionService conversionService = ConverterUtils.makeConverterService(campaign);

        if (filter.containsKey(ID_SAP)) {
            transformedFilter.put(ID_SAP, conversionService.convert(filter.get(ID_SAP), Long.class));
        }
        if (filter.containsKey(SALES_GROUP)) {
            transformedFilter.put(SALES_GROUP, conversionService.convert(filter.get(SALES_GROUP), String.class));
        }
        if (filter.containsKey(REGION)) {
            transformedFilter.put(REGION, conversionService.convert(filter.get(REGION), String.class));
        }
        if (filter.containsKey(TYPE)) {
            transformedFilter.put(TYPE, conversionService.convert(filter.get(TYPE), String.class));
        }
        if (filter.containsKey(TSRC_ID)) {
            transformedFilter.put(TSRC_ID, conversionService.convert(filter.get(TSRC_ID), Long.class));
        }
        if (filter.containsKey(CUSTOMER)) {
            transformedFilter.put(CUSTOMER, conversionService.convert(filter.get(CUSTOMER), String.class));
        }
        if (filter.containsKey(LOCALITY)) {
            transformedFilter.put(LOCALITY, conversionService.convert(filter.get(LOCALITY), String.class));
        }
        if (filter.containsKey(COUNTY)) {
            transformedFilter.put(COUNTY, conversionService.convert(filter.get(COUNTY), String.class));
        }
        if (filter.containsKey(STATE)) {
            transformedFilter.put(STATE, conversionService.convert(filter.get(STATE), String.class));
        }
        if (filter.containsKey(ADDRESS)) {
            transformedFilter.put(ADDRESS, conversionService.convert(filter.get(ADDRESS), String.class));
        }
        if (filter.containsKey(PHONE)) {
            transformedFilter.put(PHONE, conversionService.convert(filter.get(PHONE), String.class));
        }
        if (filter.containsKey(MAIL)) {
            transformedFilter.put(MAIL, conversionService.convert(filter.get(MAIL), String.class));
        }

        if (filter.containsKey(SERVICE_CENTER)) {
            transformedFilter.put(SERVICE_CENTER, conversionService.convert(filter.get(SERVICE_CENTER), ServiceCenter.class));
        }

        return transformedFilter;
    }

    @Override
    protected String getBaseQuery() {
        return FIND_POINTS_OF_SALE_BY_CAMPAIGN;
    }

    @Override
    protected String getCountQuery() {
        return COUNT_POINT_OF_SALE_BY_CAMPAIGN;
    }

    @Override
    protected Map<String, Object> getExtraParameters() {
        Map<String, Object> extraParameters = Maps.newHashMap();

        if (!user.isAdmin()) {
            Employee employee = entityManager.find(Employee.class, new EmployeeKey(campaign, ((Employee) user).getId()));
            List<PointOfSaleKey> pointsOfSaleIds = new ArrayList<PointOfSaleKey>();
            for (ServiceCenter serviceCenter : employee.getServiceCenters()) {
                for (PointOfSale pos : serviceCenter.getPointsOfSale()) {
                    pointsOfSaleIds.add(new PointOfSaleKey(campaign, pos.getIdSap(), pos.getServiceCenter()));
                }
            }

            extraParameters.put("pointsOfSaleIds", pointsOfSaleIds);
        }

        extraParameters.put("campaign", campaign);
        return extraParameters;
    }

    @Override
    protected boolean hasUserParameter() {
        return true;
    }

    @Override
    protected void setFilterParameters(Query query, Map<String, Object> filter) {
        for (String key : filter.keySet()) {
            query.setParameter(key, filter.get(key));
        }
    }

    @Override
    protected String getBaseUserQuery() {
        return FIND_POINTS_OF_SALE_BY_CAMPAIGN_AND_USER;
    }

    @Override
    protected String getCountUserQuery() {
        return COUNT_POINT_OF_SALE_BY_CAMPAIGN_AND_USER;
    }

    @Override
    protected String getFilterConditions(String query) {
        StringBuilder stringBuilder = new StringBuilder();

        for (String key : filter.keySet()) {
            stringBuilder.append(" AND ");
            stringBuilder.append(TABLE_ALIAS + ".")
                    .append(key)
                    .append(" = :")
                    .append(key);
        }

        return stringBuilder.toString();
    }

    @Override
    protected Map<String, String> getSpecialSorts() {
        return Maps.newHashMap();
    }
}
