package com.monsanto.metricspos.persistence.queries;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.externaldata.converters.ConverterUtils;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.security.User;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.springframework.core.convert.ConversionService;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

/**
 * Object to query for the service centers in a campaign
 * User: PPERA
 */
public class ServiceCenterQuery extends AbstractQuery<ServiceCenter, Map<String, Object>, Map<String, Object>> {
    public static final String FIND_SERVICE_CENTERS_BY_CAMPAIGN = "Select sc from ServiceCenter sc where sc.campaign = :campaign";
    public static final String COUNT_SERVICE_CENTER_BY_CAMPAIGN = "SELECT count(sc.cuit) FROM ServiceCenter sc where sc.campaign = :campaign";
    public static final String FIND_SERVICE_CENTERS_BY_CAMPAIGN_AND_USER = "Select sc from ServiceCenter sc where sc.campaign = :campaign and sc.cuit in (:cuits)";
    public static final String COUNT_SERVICE_CENTER_BY_CAMPAIGN_AND_USER = "SELECT count(sc.cuit) FROM ServiceCenter sc where sc.campaign = :campaign and sc.cuit in (:cuits)";
    private static final String CUIT = "cuit";
    private static final String NAME = "name";
    private static final String MAIL = "mail";
    private static final String TABLE_ALIAS = "sc";
    private Campaign campaign;

    public ServiceCenterQuery(Map<String, Object> filter, EntityManager entityManager, Campaign campaign, User user) {
        super(entityManager, TABLE_ALIAS, user);
        this.campaign = campaign;
        this.setFilter(filter);
    }

    @Override
    protected Map<String, Object> processFilterConditions(Map<String, Object> filter) {
        Map<String, Object> transformedFilter = Maps.newHashMap();
        ConversionService conversionService = ConverterUtils.makeConverterService(campaign);

        if (filter.containsKey(CUIT)) {
            transformedFilter.put(CUIT, conversionService.convert(filter.get(CUIT), String.class));
        }
        if (filter.containsKey(NAME)) {
            transformedFilter.put(NAME, conversionService.convert(filter.get(NAME), String.class));
        }
        if (filter.containsKey(MAIL)) {
            transformedFilter.put(MAIL, conversionService.convert(filter.get(MAIL), String.class));
        }

        return transformedFilter;
    }

    @Override
    protected String getBaseQuery() {
        return FIND_SERVICE_CENTERS_BY_CAMPAIGN;
    }

    @Override
    protected String getCountQuery() {
        return COUNT_SERVICE_CENTER_BY_CAMPAIGN;
    }

    @Override
    protected Map<String, Object> getExtraParameters() {
        Map<String, Object> extraParameters = Maps.newHashMap();

        if (!user.isAdmin()) {
            final Employee employee = (Employee) user;

            List<String> cuits = Lists.transform(employee.getServiceCenters(), new Function<ServiceCenter, String>() {
                @Override
                public String apply(ServiceCenter input) {
                    return input.getCuit();
                }
            });

            extraParameters.put("cuits", cuits);
        }

        extraParameters.put("campaign", campaign);
        return extraParameters;
    }

    @Override
    protected boolean hasUserParameter() {
        return true;
    }

    @Override
    protected void setFilterParameters(Query query, Map<String, Object> filter) {
        for (String key : filter.keySet()) {
            query.setParameter(key, filter.get(key));
        }
    }

    @Override
    protected String getBaseUserQuery() {
        return FIND_SERVICE_CENTERS_BY_CAMPAIGN_AND_USER;
    }

    @Override
    protected String getCountUserQuery() {
        return COUNT_SERVICE_CENTER_BY_CAMPAIGN_AND_USER;
    }

    @Override
    protected String getFilterConditions(String query) {
        StringBuilder stringBuilder = new StringBuilder();

        for (String key : filter.keySet()) {
            stringBuilder.append(" AND ");
            stringBuilder.append(TABLE_ALIAS + ".")
                    .append(key)
                    .append(" = :")
                    .append(key);
        }

        return stringBuilder.toString();
    }

    @Override
    protected Map<String, String> getSpecialSorts() {
        return Maps.newHashMap();
    }
}
