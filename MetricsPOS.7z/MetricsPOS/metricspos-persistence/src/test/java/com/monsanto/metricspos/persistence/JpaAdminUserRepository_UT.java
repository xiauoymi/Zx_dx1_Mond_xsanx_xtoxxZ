package com.monsanto.metricspos.persistence;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.security.AdminUser;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class JpaAdminUserRepository_UT {
    private JpaAdminUserRepository repository;
    private EntityManager entityManager;
    private Query query;

    @Before
    public void setUp() {
        this.repository = new JpaAdminUserRepository();
        this.entityManager = mock(EntityManager.class);
        this.query = mock(Query.class);
        when(this.entityManager.createQuery(anyString())).thenReturn(this.query);
        field("entityManager").ofType(EntityManager.class).in(this.repository).set(this.entityManager);
    }

    @Test
    public void testFindAdminUserByUserNameCreatesQueryWithCrashOverrideAsParameterAndExecutesIt_WhenFindingAdminUserByUsernameCrashOverride() {
        // @Given a username
        String username = "crashOverride";

        // @When finding the admin user with that username
        this.repository.findAdminUserByUserName(username);

        // @Then a query to find the user by username is created and executed with the input as parameter
        verify(this.entityManager, times(1)).createQuery(JpaAdminUserRepository.FIND_BY_USERNAME);
        verify(this.query, times(1)).setParameter("username", username);
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testFindAdminUserByUserNameCreatesQueryWithBurnAcidAsParameterAndExecutesIt_WhenFindingAdminUserByUsernameBurnAcid() {
        // @Given a username
        String username = "burnAcid";

        // @When finding the admin user with that username
        this.repository.findAdminUserByUserName(username);

        // @Then a query to find the user by username is created and executed with the input as parameter
        verify(this.entityManager, times(1)).createQuery(JpaAdminUserRepository.FIND_BY_USERNAME);
        verify(this.query, times(1)).setParameter("username", username);
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testFindAdminUserByUserNameReturnsQueryResult_WhenFindingAdminUserByUsername() {
        // @Given a username
        String username = "burnAcid";
        AdminUser adminUser = new AdminUser();
        when(this.query.getSingleResult()).thenReturn(adminUser);

        // @When finding the admin user with that username
        AdminUser userByUserName = this.repository.findAdminUserByUserName(username);

        // @Then a query to find the user by username is created and executed with the input as parameter
        assertThat(userByUserName).isSameAs(this.query.getSingleResult());
    }

    @Test
    public void testListAdminUsersCreatesAQueryToFindAllUsersAndExecutesIt_WhenListingAllAdminUsers() {
        // @When listing all admin users
        this.repository.listAdminUsers();

        // @Then a query is created and executed
        verify(this.entityManager, times(1)).createQuery(JpaAdminUserRepository.FIND_ALL_ADMIN_USERS);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testListAdminUsersReturnsQueryResult_WhenListingAllAdminUsers() {
        // @Given an admin user list returned by the query
        ArrayList<AdminUser> adminUsers = Lists.newArrayList(new AdminUser());
        when(this.query.getResultList()).thenReturn(adminUsers);

        // @When listing all admin users
        List<AdminUser> adminUserList = this.repository.listAdminUsers();

        // @Then the result is the query result
        assertThat(adminUserList).isEqualTo(this.query.getResultList());
    }

    @Test
    public void testNewAdminUserCallsEntityManagerPersistOnInput_WhenCreatingANewAdminUserFromInput() {
        // @Given an input
        AdminUser adminUser = new AdminUser();

        // @When creating a new admin user from it
        this.repository.newAdminUser(adminUser);

        // @Then entityManager.persist is called
        verify(this.entityManager, times(1)).persist(adminUser);
    }

    @Test
    public void testNewAdminUserReturnsInput_WhenCreatingANewAdminUserFromInput() {
        // @Given an input
        AdminUser adminUser = new AdminUser();

        // @When creating a new admin user from it
        AdminUser user = this.repository.newAdminUser(adminUser);

        // @Then entityManager.persist is called
        assertThat(user).isSameAs(adminUser);
    }

    @Test
    public void testFindAdminUserById1CallsEntityManagerFindAdminUser1_WhenFindingAdminUserById1() {
        // @Given an admin user id
        int adminUserId = 1;

        // @When finding admin user by Id
        this.repository.findAdminUserById(adminUserId);

        // @Then entityManager find Admin user.class is 1 is called
        verify(this.entityManager).find(AdminUser.class, adminUserId);
    }

    @Test
    public void testFindAdminUserByIdCallsEntityManagerFindAdminUser2_WhenFindingAdminUserById2() {
        // @Given an admin user id
        int adminUserId = 2;

        // @When finding admin user by Id
        this.repository.findAdminUserById(adminUserId);

        // @Then entityManager find Admin user.class is 2 is called
        verify(this.entityManager).find(AdminUser.class, adminUserId);
    }

    @Test
    public void testFindAdminUserByIdReturnsFoundAdminUser_WhenFindingAdminUserById() {
        // @Given an admin user id
        int adminUserId = 1;
        AdminUser expected = new AdminUser();
        when(this.entityManager.find(AdminUser.class, adminUserId)).thenReturn(expected);

        // @When finding admin user by Id
        AdminUser returned = this.repository.findAdminUserById(adminUserId);

        // @Then found admin user is returned
        assertThat(returned).isSameAs(expected);
    }

    @Test
    public void testDeleteAdminUserCallsEntityManagerRemoveAdminUser_WhenDeletingAdminUser(){
        // @Given an AdminUser
        AdminUser adminUser = new AdminUser();

        // @When deleting the admin user
        this.repository.deleteAdminUser(adminUser);

        // @Then entityManager.remove is called with that admin user
        verify(this.entityManager, times(1)).remove(adminUser);
    }
}
