package com.monsanto.metricspos.persistence;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.security.Authority;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class JpaAuthoritiesRepository_UT {
    private JpaAuthoritiesRepository repository;
    private EntityManager entityManager;
    private Query query;

    @Before
    public void setUp() {
        this.repository = new JpaAuthoritiesRepository();
        this.entityManager = mock(EntityManager.class);
        this.query = mock(Query.class);
        when(this.entityManager.createQuery(anyString())).thenReturn(this.query);
        field("entityManager").ofType(EntityManager.class).in(this.repository).set(this.entityManager);
    }

    @Test
    public void testFindAllCreatesAQueryThatFetchAllAuthoritiesAndExecutesIt_WhenFindingAllAuthorities() {
        // @When finding all authorities
        this.repository.findAllRoleNames();

        // @Then A query is created and executed
        verify(this.entityManager, times(1)).createQuery(JpaAuthoritiesRepository.FIND_ALL_AUTHORITIES_ROLE_NAMES);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindAllReturnsQueryResult_WhenFindingAllAuthorities() {
        // @Given a query result
        when(this.query.getResultList()).thenReturn(Lists.<String>newArrayList());

        // @When finding all authorities
        Collection<String> result = this.repository.findAllRoleNames();

        // @Then the query result is returned
        assertThat(result).isSameAs(this.query.getResultList());
    }

    @Test
    public void testListAuthoritiesCreatesQueryToGetAllAuthoritiesAndExecutesIt_WhenListingAuthorities() {
        // @When listing authorities
        this.repository.listAuthorities();

        // @Then the query is created and executed
        verify(this.entityManager, times(1)).createQuery(JpaAuthoritiesRepository.FIND_ALL_AUTHORITIES);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testListAuthoritiesReturnsQueryResult_WhenListingAuthorities() {
        // @Given a list of authorities
        ArrayList<Authority> list = Lists.newArrayList(new Authority());
        when(this.query.getResultList()).thenReturn(list);

        // @When listing authorities
        List<Authority> authorities = this.repository.listAuthorities();

        // @Then the query is created and executed
        assertThat(authorities).isSameAs(list);
    }

    @Test
    public void testFindAuthorityByIdCallsEntityManagerFindWithId1_WhenFindingAuthority1() {
        // @Given an id 1
        int authorityId = 1;

        // @When finding authority by id
        this.repository.findAuthorityById(authorityId);

        // @Then entityManager.find is called with id 1 from Authority
        verify(this.entityManager, times(1)).find(Authority.class, authorityId);
    }

    @Test
    public void testFindAuthorityByIdCallsEntityManagerFindWithId5_WhenFindingAuthority5() {
        // @Given an id 5
        int authorityId = 5;

        // @When finding authority by id
        this.repository.findAuthorityById(authorityId);

        // @Then entityManager.find is called with id 1 from Authority
        verify(this.entityManager, times(1)).find(Authority.class, authorityId);
    }

    @Test
    public void testFindAuthorityByIdReturnsAuthority5FoundByEntityManager_WhenFindingAuthority5() {
        // @Given an id 5
        int authorityId = 5;
        Authority expectedAuthority = new Authority();
        when(this.entityManager.find(Authority.class, authorityId)).thenReturn(expectedAuthority);

        // @When finding authority by id
        Authority authority = this.repository.findAuthorityById(authorityId);

        // @Then entityManager.find is called with id 1 from Authority
        assertThat(authority).isSameAs(expectedAuthority);
    }
}
