package com.monsanto.metricspos.persistence;

import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.AuthorityServices;
import com.monsanto.metricspos.core.application.vo.GroupVO;
import com.monsanto.metricspos.core.security.Authority;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class JpaGroupRepository_UT {

    private JpaGroupRepository repository;
    private EntityManager entityManager;
    private Query query;
    private AuthorityServices authorityServices;

    @Before
    public void setUp() {
        this.authorityServices = mock(AuthorityServices.class);
        this.repository = new JpaGroupRepository();
        this.entityManager = mock(EntityManager.class);
        this.query = mock(Query.class);
        when(this.entityManager.createQuery(anyString())).thenReturn(this.query);
        field("entityManager").ofType(EntityManager.class).in(this.repository).set(this.entityManager);
        field("authorityServices").ofType(AuthorityServices.class).in(this.repository).set(this.authorityServices);
    }

    @Test
    public void testListGroupsCreateAQueryToFindAllGroupsAndExecutesIt_WhenListingAllGroups() {
        // @When listing groups
        this.repository.listGroups();

        // @Then a query is created and executed
        verify(this.entityManager, times(1)).createQuery(JpaGroupRepository.FIND_ALL_GROUPS);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testListGroupsReturnsQueryResult_WhenListingAllGroups() {
        // @Given a list of groups
        List<Group> groups = Lists.newArrayList(new Group());
        when(this.query.getResultList()).thenReturn(groups);

        // @When listing groups
        List<Group> list = this.repository.listGroups();

        // @Then a query is created and executed
        assertThat(list).isSameAs(groups);
    }

    @Test
    public void testNewGroupCallsEntityManagerPersistWithAGroupWithTheSameAttributesAsTheVO_WhenCreatingANewGroup() {
        // @Given a VO
        final GroupVO groupVO = new GroupVO();
        groupVO.setName("name");
        groupVO.setEnabled(true);

        // @When creating a new group
        this.repository.newGroup(groupVO);

        // @Then a group is returned with the same attributes as the VO
        verify(this.entityManager, times(1)).persist(argThat(new ArgumentMatcher<Group>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof Group &&
                        Objects.equal(groupVO.getName(), ((Group) argument).getName()) &&
                        Objects.equal(groupVO.isEnabled(), ((Group) argument).isEnabled());
            }
        }));
    }

    @Test
    public void testNewGroupReturnsCreatedGroupMatchingVO_WhenCreatingANewGroup() {
        // @Given a VO
        final GroupVO groupVO = new GroupVO();
        groupVO.setName("name");
        groupVO.setEnabled(true);

        // @When creating a new group
        Group group = this.repository.newGroup(groupVO);

        // @Then a group is returned with the same attributes as the VO
        assertThat(group.isEnabled()).isEqualTo(groupVO.isEnabled());
        assertThat(group.getName()).isEqualTo(groupVO.getName());
    }

    @Test
    public void testFindGroupByIdCallsEntityManagerFindWithId1_WhenFindingGroupById1() {
        // @Given a group id 1
        int groupId = 1;

        // @When finding group by that id
        this.repository.findGroupById(groupId);

        // Then entityManager.find is called with that id
        verify(this.entityManager, times(1)).find(Group.class, groupId);
    }

    @Test
    public void testFindGroupByIdCallsEntityManagerFindWithId45_WhenFindingGroupById45() {
        // @Given a group id 45
        int groupId = 45;

        // @When finding group by that id
        this.repository.findGroupById(groupId);

        // Then entityManager.find is called with that id
        verify(this.entityManager, times(1)).find(Group.class, groupId);
    }

    @Test
    public void testFindGroupByIdReturnsGroupFoundByEntityManager_WhenFindingGroupById() {
        // @Given a group id
        int groupId = 234;
        Group group = new Group();
        when(this.entityManager.find(Group.class, groupId)).thenReturn(group);

        // @When finding group by that id
        Group returnedGroup = this.repository.findGroupById(groupId);

        // Then entityManager.find is called with that id
        assertThat(returnedGroup).isSameAs(group);
    }

    @Test
    public void testUpdateGroupSetsAllFieldsOfInputGroupWithInputVosValues_WhenUpdatingAGroupWithAVO1() {
        // @Given a VO and a group
        GroupVO groupVO = new GroupVO();
        groupVO.setId(1);
        groupVO.setEnabled(true);
        groupVO.setName("HI");

        Authority authority1 = new Authority();
        authority1.setId(1);
        authority1.setName("name1");
        authority1.setRoleName("rolename1");
        authority1.setDescription("description1");
        Authority authority2 = new Authority();
        authority2.setId(2);
        authority2.setName("name2");
        authority2.setRoleName("rolename2");
        authority2.setDescription("description2");
        groupVO.setAuthorities(Lists.<Authority>newArrayList(authority1, authority2));

        Group group = new Group();
        group.setId(1);
        group.setEnabled(false);
        group.setName("Bye");
        group.setAuthorities(Lists.<Authority>newArrayList());

        when(this.authorityServices.findAuthorityById(authority1.getId())).thenReturn(authority1);
        when(this.authorityServices.findAuthorityById(authority2.getId())).thenReturn(authority2);

        // @When updating the group with the VO
        this.repository.update(groupVO, group);

        // @Then the attributes of the group are set with the VOs attributes
        assertThat(group.isEnabled()).isEqualTo(groupVO.isEnabled());
        assertThat(group.getName()).isEqualTo(groupVO.getName());
        assertThat(group.getAuthorities()).contains(groupVO.getAuthorities().toArray());
    }

    @Test
    public void testUpdateGroupSetsAllFieldsOfInputGroupWithInputVosValues_WhenUpdatingAGroupWithAVO2() {
        // @Given a VO and a group
        GroupVO groupVO = new GroupVO();
        groupVO.setId(1);
        groupVO.setEnabled(false);
        groupVO.setName("Welcome");

        Authority authority1 = new Authority();
        authority1.setId(1);
        authority1.setName("name1");
        authority1.setRoleName("rolename1");
        authority1.setDescription("description1");
        groupVO.setAuthorities(Lists.<Authority>newArrayList(authority1));

        Group group = new Group();
        group.setId(1);
        group.setEnabled(false);
        group.setName("Bye");
        Authority authority2 = new Authority();
        authority2.setId(2);
        authority2.setName("name2");
        authority2.setRoleName("rolename2");
        authority2.setDescription("description2");
        group.setAuthorities(Lists.<Authority>newArrayList(authority2));

        when(this.authorityServices.findAuthorityById(authority1.getId())).thenReturn(authority1);
        when(this.authorityServices.findAuthorityById(authority2.getId())).thenReturn(authority2);

        // @When updating the group with the VO
        this.repository.update(groupVO, group);

        // @Then the attributes of the group are set with the VOs attributes
        assertThat(group.isEnabled()).isEqualTo(groupVO.isEnabled());
        assertThat(group.getName()).isEqualTo(groupVO.getName());
        assertThat(group.getAuthorities()).contains(groupVO.getAuthorities().toArray());
    }

    @Test
    public void testFindGroupByIdCreatesQuerySetsNameAsParameterAndExecutesIt_WhenFindingGroupByName() {
        // @Given a group name
        String name = "name";

        // @When finding the group with that name
        this.repository.findGroupByName(name);

        // @Then a query is created with name as parameter and it's executed
        verify(this.entityManager, times(1)).createQuery(JpaGroupRepository.FIND_GROUP_BY_NAME);
        verify(this.query, times(1)).setParameter("name", name);
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testFindGroupByIdReturnsQueryResult_WhenFindingGroupByName() {
        // @Given a group name
        String name = "name";
        Group expected = new Group();
        when(this.query.getSingleResult()).thenReturn(expected);

        // @When finding the group with that name
        Group group = this.repository.findGroupByName(name);

        // @Then a query is created with name as parameter and it's executed
        assertThat(group).isSameAs(this.query.getSingleResult());

    }

    @Test
    public void testDeleteGroupCallsEntityManagerRemove_WhenDeletingGroup() {
        // @Given a group
        Group group = new Group();

        // @When deleting the group
        this.repository.deleteGroup(group);

        // @Then entityManager.remove is called with the group
        verify(this.entityManager, times(1)).remove(group);
    }

    @Test
    public void testDeleteGroupRemovesMemberEmployeesMembership_WhenDeletingGroup() {
        // @Given a group
        Group group = new Group();
        Employee employee = new Employee();
        List groups = mock(List.class);
        employee.setGroups(groups);
        group.setMembers(Lists.<Employee>newArrayList(employee));

        // @When deleting the group
        this.repository.deleteGroup(group);

        // @Then entityManager.remove is called with the group
        verify(groups, times(1)).remove(group);
    }
}