package com.monsanto.metricspos.persistence;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.security.ActionLog;
import com.monsanto.metricspos.core.security.AuditLog;
import com.monsanto.metricspos.persistence.queries.ActionLogQuery;
import com.monsanto.metricspos.persistence.queries.AuditLogQuery;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class JpaLogsRepository_UT {

    private JpaLogsRepository repository;
    private EntityManager entityManager;
    private Query query;

    @Before
    public void setUp() {
        this.repository = new JpaLogsRepository();
        entityManager = mock(EntityManager.class);
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);
        query = mock(Query.class);
        when(entityManager.createQuery(anyString())).thenReturn(query);
    }

    @Test
    public void testListAuditLogsByPageCreatesQueryWithPagingParametersAndExecutesIt_WhenListingAuditLogsByPage1Rows25SortedByDateDesc() {
        // @Given a page 1 and a pageSize 25 and sort by date desc
        int page = 1;
        int rows = 25;
        String sort = "date";
        String direction = "DESC";
        Map<String, Object> filter = Maps.newHashMap();

        // @When listing audit logs by page
        this.repository.listAuditLogsByPage(page, rows, sort, direction, filter);

        // @Then the query is created and executed
        verify(this.entityManager).createQuery(AuditLogQuery.BASE_QUERY + " ORDER BY log.date DESC");
        verify(this.query).setMaxResults(rows);
        verify(this.query).setFirstResult((page - 1) * rows);
        verify(this.query).getResultList();
    }

    @Test
    public void testListAuditLogsByPageReturnsQueryResult_WhenListingAuditLogs() {
        // @Given a page 1 and a pageSize 25 and sort by date desc
        int page = 1;
        int rows = 25;
        String sort = "date";
        String direction = "DESC";
        Map<String, Object> filter = Maps.newHashMap();
        List<AuditLog> expected = Lists.newArrayList();
        when(this.query.getResultList()).thenReturn(expected);

        // @When listing audit logs by page
        List<AuditLog> auditLogs = this.repository.listAuditLogsByPage(page, rows, sort, direction, filter);

        // @Then the query is created and executed
        assertThat(auditLogs).isSameAs(this.query.getResultList());
    }

    @Test
    public void testGetAuditLogsCountCreatesCountQueryAndExecutesIt_WhenCountingAuditLogs() {
        // @Given an empty filter
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(1l);

        // @When counting audit logs
        this.repository.getAuditLogsCount(filter);

        // @Then the query is created and executed
        verify(this.entityManager).createQuery(AuditLogQuery.COUNT_QUERY);
        verify(this.query).getSingleResult();
    }

    @Test
    public void testGetAuditLogsCountCreatesCountQueryAndExecutesIt_WhenCountingAuditLogsFilteringByQualifier() {
        // @Given an empty filter
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("qualifier", "com.monsanto");
        when(this.query.getSingleResult()).thenReturn(1l);

        // @When counting audit logs
        this.repository.getAuditLogsCount(filter);

        // @Then the query is created and executed
        verify(this.entityManager).createQuery(AuditLogQuery.COUNT_QUERY + " WHERE log.qualifier = :qualifier");
        verify(this.query).getSingleResult();
    }

    @Test
    public void testListAuditLogsByPageCreatesQueryWithPagingParametersAndExecutesIt_WhenListingAuditLogsByPage2Rows40SortedByUsernameAsc() {
        // @Given a page 1 and a pageSize 25 and sort by date desc
        int page = 2;
        int rows = 40;
        String sort = "username";
        String direction = "ASC";
        Map<String, Object> filter = Maps.newHashMap();

        // @When listing audit logs by page
        this.repository.listAuditLogsByPage(page, rows, sort, direction, filter);

        // @Then the query is created and executed
        verify(this.entityManager).createQuery(AuditLogQuery.BASE_QUERY + " ORDER BY log.username ASC");
        verify(this.query).setMaxResults(rows);
        verify(this.query).setFirstResult((page - 1) * rows);
        verify(this.query).getResultList();
    }

    @Test
    public void testListAuditLogsByPageCreatesQueryWithPagingParametersAndExecutesIt_WhenListingAuditLogsByPage2Rows40SortedByUsernameAscFilterByUsernameMessageContext() {
        // @Given a page 1 and a pageSize 25 and sort by date desc
        int page = 2;
        int rows = 40;
        String sort = "username";
        String direction = "ASC";
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("username", "ppera");
        filter.put("message", "List");
        filter.put("context", "INFO");
        filter.put("priority", "INFO");
        filter.put("date", "2012-01-01 10:11:12.123 AM");

        // @When listing audit logs by page
        this.repository.listAuditLogsByPage(page, rows, sort, direction, filter);

        // @Then the query is created and executed
        verify(this.entityManager).createQuery(AuditLogQuery.BASE_QUERY + " WHERE log.message LIKE 'List%' AND log.username LIKE 'ppera%' AND log.priority = :priority AND log.context = :context AND log.date >= :datelow AND log.date <= :datehigh ORDER BY log.username ASC");
        verify(this.query).setMaxResults(rows);
        verify(this.query).setFirstResult((page - 1) * rows);
        verify(this.query).getResultList();
    }

    @Test
    public void testGetActionLogsCountCreatesCountQueryAndExecutesIt_WhenCountingActionLogs() {
        // @Given an empty filter
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(1l);

        // @When counting audit logs
        this.repository.getActionLogsCount(filter);

        // @Then the query is created and executed
        verify(this.entityManager).createQuery(ActionLogQuery.COUNT_QUERY);
        verify(this.query).getSingleResult();
    }

    @Test
    public void testGetActionLogsCountCreatesCountQueryAndExecutesIt_WhenCountingActionLogsFilteringByQualifier() {
        // @Given an empty filter
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("qualifier", "com.monsanto");
        when(this.query.getSingleResult()).thenReturn(1l);

        // @When counting action logs
        this.repository.getActionLogsCount(filter);

        // @Then the query is created and executed
        verify(this.entityManager).createQuery(ActionLogQuery.COUNT_QUERY + " WHERE log.qualifier = :qualifier");
        verify(this.query).getSingleResult();
    }

    @Test
    public void testListActionLogsByPageCreatesQueryWithPagingParametersAndExecutesIt_WhenListingActionLogsByPage1Rows25SortedByDateDesc() {
        // @Given a page 1 and a pageSize 25 and sort by date desc
        int page = 1;
        int rows = 25;
        String sort = "date";
        String direction = "DESC";
        Map<String, Object> filter = Maps.newHashMap();

        // @When listing action logs by page
        this.repository.listActionLogsByPage(page, rows, sort, direction, filter);

        // @Then the query is created and executed
        verify(this.entityManager).createQuery(ActionLogQuery.BASE_QUERY + " ORDER BY log.date DESC");
        verify(this.query).setMaxResults(rows);
        verify(this.query).setFirstResult((page - 1) * rows);
        verify(this.query).getResultList();
    }

    @Test
    public void testListActionLogsReturnQueryResult_WhenListingActionLogsByPage1Rows25SortedByDateDesc() {
        // @Given a page 1 and a pageSize 25 and sort by date desc
        int page = 1;
        int rows = 25;
        String sort = "date";
        String direction = "DESC";
        Map<String, Object> filter = Maps.newHashMap();

        List<ActionLog> expected = Lists.newArrayList();
        when(this.query.getResultList()).thenReturn(expected);

        // @When listing action logs by page
        List<ActionLog> actionLogs = this.repository.listActionLogsByPage(page, rows, sort, direction, filter);

        // @Then the query is created and executed
        assertThat(actionLogs).isSameAs(this.query.getResultList());
    }

    @Test
    public void testListActionLogsByPageCreatesQueryWithPagingParametersAndExecutesIt_WhenListingActionLogsByPage2Rows40SortedByUsernameAscFilterByUsernameMessageContext() {
        // @Given a page 1 and a pageSize 25 and sort by date desc
        int page = 2;
        int rows = 40;
        String sort = "username";
        String direction = "ASC";
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("username", "ppera");
        filter.put("message", "List");
        filter.put("context", "INFO");
        filter.put("priority", "INFO");
        filter.put("date", "2012-01-01 10:11:12.123 AM");

        // @When listing action logs by page
        this.repository.listActionLogsByPage(page, rows, sort, direction, filter);

        // @Then the query is created and executed
        verify(this.entityManager).createQuery(ActionLogQuery.BASE_QUERY + " WHERE log.message LIKE 'List%' AND log.username LIKE 'ppera%' AND log.priority = :priority AND log.context = :context AND log.date >= :datelow AND log.date <= :datehigh ORDER BY log.username ASC");
        verify(this.query).setMaxResults(rows);
        verify(this.query).setFirstResult((page - 1) * rows);
        verify(this.query).getResultList();
    }
}
