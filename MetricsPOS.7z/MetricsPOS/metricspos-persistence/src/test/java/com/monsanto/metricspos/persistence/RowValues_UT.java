package com.monsanto.metricspos.persistence;

import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class RowValues_UT {
    @Test
    public void testToString() {
        RowValues rowValues = new RowValues();
        rowValues.setId(1);
        assertThat(rowValues.toString()).isEqualTo("RowValues{id=1}");
    }
}
