package com.monsanto.metricspos.persistence.hibernate;

import org.apache.log4j.Logger;
import org.hsqldb.jdbcDriver;

import java.sql.Connection;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 * jdbcDriver to allow the
 * creation of a default Schema
 *
 * @author CAFAU
 */
public class HsqldbInitializingDriver extends jdbcDriver {

    private static final Logger log= Logger.getLogger(HsqldbInitializingDriver.class);

    private boolean needInitialization = true;


    public HsqldbInitializingDriver() {
        super();
        log.info("Creating HsqldbInitializingDriver");

    }

    private void initialize(String s, Properties properties) {
        needInitialization = false;

        // Execute
        Connection connection = null;
        Statement statement = null;
        try {
            connection = super.connect(s, properties);
            statement = connection.createStatement();
            statement.execute("create schema TPS");
        } catch (SQLException e) {
            log.error("Error while initializing with " + s + " and " + properties);
        } finally {
            closeQuietly(statement);
            closeQuietly(connection);
        }
    }

    private void closeQuietly(Statement statement) {
        if ( statement != null ) {
            try {
                statement.close();
            } catch (Exception e) {
                // Nothing to do
            }
        }
    }

    private void closeQuietly(Connection connection) {
        if ( connection != null ) {
            try {
                connection.close();
            } catch (Exception e) {
                // Nothing to do
            }
        }
    }


    @Override
    public Connection connect(String s, Properties properties) throws SQLException {
        log.info("Connecting to " + s);

        if ( needInitialization ) {
            initialize(s, properties);
        }

        return super.connect(s, properties);
    }

    @Override
    public DriverPropertyInfo[] getPropertyInfo(String s, Properties properties) {
        log.info("Getting driver properties on " + s);

        if ( needInitialization ) {
            initialize(s, properties);
        }

        return super.getPropertyInfo(s, properties);    //To change body of overridden methods use File | Settings | File Templates.
    }

}
