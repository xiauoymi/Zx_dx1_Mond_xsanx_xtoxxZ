package com.monsanto.metricspos.persistence.hibernate;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.SessionFactoryObserver;

/**
 * Complete please !!
 *
 * @author CAFAU
 */
public class TestSessionFactoryObserver implements SessionFactoryObserver {
    private static final Logger log= Logger.getLogger(TestSessionFactoryObserver.class);

    @Override
    public void sessionFactoryCreated(SessionFactory factory) {
        log.debug("Session factory created: " + factory );
    }

    @Override
    public void sessionFactoryClosed(SessionFactory factory) {
    }
}
