package com.monsanto.metricspos.persistence.integration;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.MetricFactory;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.JpaCampaignRepository;
import com.monsanto.metricspos.persistence.JpaMetricsRepository;
import com.monsanto.metricspos.persistence.ReflectiveDataRowPersistorFactory;
import com.monsanto.metricspos.persistence.hibernate.DataProvidersHolder;
import com.monsanto.metricspos.persistence.jpa.JpaTransactionCallBack;
import com.monsanto.metricspos.persistence.jpa.JpaTransactionTemplate;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;

/**
 * Test the JpaCampaignRepository class against an in memory database
 *
 * @author CAFAU
 */
@Ignore
public class JpaCampaignRepository_AT {

    private static final Logger log = Logger.getLogger(JpaCampaignRepository_AT.class);

    private MetricFactory factory;

    private JpaTransactionTemplate template;

    @Before
    public void setUp() throws Exception {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("metricsposPU");
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        template = new JpaTransactionTemplate(entityManagerFactory);

        JpaCampaignRepository repository = new JpaCampaignRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);

        factory = new JpaMetricsRepository();
        field("entityManager").ofType(EntityManager.class).in(factory).set(entityManager);
    }

    @Test
    public void testCampaignPersist() {
        // @Given a campaign with all possible data
        final Campaign campaignFirstTransaction = template.execute(new JpaTransactionCallBack<Campaign>() {
            @Override
            public Campaign doInTx(EntityManager em) {
                Campaign campaign = new Campaign("name", newDate(2011, 1, 4), newDate(2012, 2, 3));
                campaign.setScheduled(true);
                campaign.setEmployeeLoadScript("elsc");
                campaign.setEmployeeLoadSql("elsq");
                campaign.setPointOfSaleLoadScript("plsc");
                campaign.setPointOfSaleLoadSql("plsq");
                campaign.setServiceCenterLoadScript("slsc");
                campaign.setServiceCenterLoadSql("slsq");
                campaign.setRatingFormula("rf");
                campaign.setRatingPremiumCategory("rpc");

                em.persist(campaign);
                return campaign;
            }
        });

        final Campaign campaign = template.execute(new JpaTransactionCallBack<Campaign>() {
            @Override
            public Campaign doInTx(EntityManager em) {
                Campaign persistedCampaign = em.find(Campaign.class, campaignFirstTransaction.getId());

                assertThat(persistedCampaign.getName()).isEqualTo(campaignFirstTransaction.getName());
                assertThat(persistedCampaign.getSince().getTime()).isEqualTo(campaignFirstTransaction.getSince().getTime());
                assertThat(persistedCampaign.getUntil().getTime()).isEqualTo(campaignFirstTransaction.getUntil().getTime());
                assertThat(persistedCampaign.getEmployeeLoadSql()).isEqualTo(campaignFirstTransaction.getEmployeeLoadSql());
                assertThat(persistedCampaign.getEmployeeLoadScript()).isEqualTo(campaignFirstTransaction.getEmployeeLoadScript());
                assertThat(persistedCampaign.getPointOfSaleLoadSql()).isEqualTo(campaignFirstTransaction.getPointOfSaleLoadSql());
                assertThat(persistedCampaign.getPointOfSaleLoadScript()).isEqualTo(campaignFirstTransaction.getPointOfSaleLoadScript());
                assertThat(persistedCampaign.getServiceCenterLoadSql()).isEqualTo(campaignFirstTransaction.getServiceCenterLoadSql());
                assertThat(persistedCampaign.getServiceCenterLoadScript()).isEqualTo(campaignFirstTransaction.getServiceCenterLoadScript());
                assertThat(persistedCampaign.isScheduled()).isEqualTo(campaignFirstTransaction.isScheduled());
                assertThat(persistedCampaign.getRatingFormula()).isEqualTo(campaignFirstTransaction.getRatingFormula());
                assertThat(persistedCampaign.getRatingPremiumCategory()).isEqualTo(campaignFirstTransaction.getRatingPremiumCategory());

                persistedCampaign.setFactory(factory);
                field("entityManager").ofType(EntityManager.class).in(factory).set(em);

                DataTable dataTable = new DataTable("table", Lists.<DataColumn>newArrayList(), new ReflectiveDataRowPersistorFactory());
                dataTable.setCampaign(persistedCampaign);
                DataProvider dataProvider = new DataProvider();
                dataProvider.setCode("CODE");
                Map<String, DataProvider> dataProviderMap = Maps.newHashMap();
                dataProviderMap.put(dataProvider.getCode(), dataProvider);
                DataProvidersHolder.init(dataProviderMap);
                dataTable.setDataProvider(dataProvider);
                em.persist(dataTable);

                persistedCampaign.addMetricDefinition("name", 10);
                ServiceCenter serviceCenter = new ServiceCenter();
                serviceCenter.setCuit("11");
                serviceCenter.setName("lala");
                serviceCenter.setCampaign(persistedCampaign);
                em.persist(serviceCenter);
                return persistedCampaign;
            }
        });


        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                // @When persisting and retrieving it from the base
                Campaign persistedCampaign = em.find(Campaign.class, campaign.getId());

                // @Then all the data is retrieved as it was
                assertThat(persistedCampaign.getServiceCenters()).hasSize(1);
                assertThat(persistedCampaign.getDataTables()).hasSize(1);
                assertThat(persistedCampaign.getMetrics()).hasSize(1);
                return null;
            }
        });

    }
}
