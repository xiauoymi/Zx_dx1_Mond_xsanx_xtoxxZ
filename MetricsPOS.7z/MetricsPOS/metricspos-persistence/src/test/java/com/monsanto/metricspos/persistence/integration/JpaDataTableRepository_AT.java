package com.monsanto.metricspos.persistence.integration;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.application.vo.DataColumnVO;
import com.monsanto.metricspos.core.application.vo.converter.DataColumnVO2DataColumnConverter;
import com.monsanto.metricspos.core.externaldata.*;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.*;
import com.monsanto.metricspos.persistence.hibernate.DataProvidersHolder;
import com.monsanto.metricspos.persistence.hibernate.DataTypesHolder;
import com.monsanto.metricspos.persistence.jpa.JpaTransactionCallBack;
import com.monsanto.metricspos.persistence.jpa.JpaTransactionTemplate;
import com.monsanto.metricspos.persistence.unit.JpaCampaignRepository_UT;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.fest.reflect.core.Reflection.staticField;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * User: PPERA
 */
@Ignore
public class JpaDataTableRepository_AT {

    private JpaDataTableRepository repository;

    private JpaTransactionTemplate template;
    private ReflectiveDataRowPersistorFactory dataRowPersistorFactory;
    private RowValuesServices rowValuesServices;

    @Before
    public void setUp() throws Exception {
        Map<String, DataType> dataTypeMap = Maps.newHashMap();
        dataTypeMap.put(stringDataType().getCode(), stringDataType());
        dataTypeMap.put(serviceCenterDataType().getCode(), serviceCenterDataType());

        staticField("dataTypes").ofType(Map.class).in(DataTypesHolder.class).set(dataTypeMap);

        Map<String, DataProvider> dataProvidersMap = Maps.newHashMap();
        dataProvidersMap.put("CRM", crmDataProvider());
        staticField("dataProviders").ofType(Map.class).in(DataProvidersHolder.class).set(dataProvidersMap);


        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("metricsposPU");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        dataRowPersistorFactory = new ReflectiveDataRowPersistorFactory();

        Map<Class, String> classXprefix = Maps.newHashMap();
        classXprefix.put(String.class, RowValues.TEXT_COLUMN_PREFIX);
        classXprefix.put(Integer.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Long.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(BigDecimal.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Number.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Date.class, RowValues.DATE_COLUMN_PREFIX);
        classXprefix.put(ServiceCenter.class, RowValues.SERVICE_CENTER_COLUMN_PREFIX);

        field("classToPrefixMap").ofType(Map.class).in(dataRowPersistorFactory).set(classXprefix);

        template = new JpaTransactionTemplate(entityManagerFactory);

        DataColumnVO2DataColumnConverter dataColumnVO2DataColumnConverter = new DataColumnVO2DataColumnConverter();
        dataColumnVO2DataColumnConverter.setDataTypeMap(dataTypeMap);

        this.rowValuesServices = new JpaRowValuesRepository();

        SecurityHolderStrategy securityHolderStrategy = mock(SecurityHolderStrategy.class);
        when(securityHolderStrategy.getCurrentUser()).thenReturn(new AdminUser());
        field("securityHolderStrategy").ofType(SecurityHolderStrategy.class).in(rowValuesServices).set(securityHolderStrategy);

        repository = new JpaDataTableRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);
        field("dataProvidersMap").ofType(Map.class).in(repository).set(dataProvidersMap);
        field("dataTypeMap").ofType(Map.class).in(repository).set(dataTypeMap);
        field("dataColumnVO2DataColumnConverter").ofType(DataColumnVO2DataColumnConverter.class).in(repository).set(dataColumnVO2DataColumnConverter);
        field("dataRowPersistorFactory").ofType(DataRowPersistorFactory.class).in(repository).set(dataRowPersistorFactory);
    }

    @Test
    public void testPersistDataTable() {
        final Campaign campaign = JpaCampaignRepository_UT.createCampaigns(1).get(0);

        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                em.persist(campaign);
                return null;
            }
        });

        final DataTable dataTable = template.execute(new JpaTransactionCallBack<DataTable>() {
            @Override
            public DataTable doInTx(EntityManager em) {
                DataTable dataTable = new DataTable("name", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
                Campaign persistedCampaign = em.find(Campaign.class, campaign.getId());
                dataTable.setCampaign(persistedCampaign);
                dataTable.setScheduled(true);
                dataTable.setDescription("description");
                dataTable.setLoadScript("loadScript");
                dataTable.setLoadSql("loadSql");
                dataTable.setDataProvider(crmDataProvider());
                dataTable.setAllowRecordCreation(true);
                em.persist(dataTable);
                return dataTable;
            }
        });

        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                DataTable persistedDataTable = em.find(DataTable.class, dataTable.getId());
                assertThat(persistedDataTable.getAllowRecordCreation()).isEqualTo(dataTable.getAllowRecordCreation());
                assertThat(persistedDataTable.getCampaign().getId()).isEqualTo(dataTable.getCampaign().getId());
                assertThat(persistedDataTable.getColumns().size()).isEqualTo(dataTable.getColumns().size());
                assertThat(persistedDataTable.getDataProvider().getCode()).isEqualTo(dataTable.getDataProvider().getCode());
                assertThat(persistedDataTable.getDescription()).isEqualTo(dataTable.getDescription());
                assertThat(persistedDataTable.getLoadScript()).isEqualTo(dataTable.getLoadScript());
                assertThat(persistedDataTable.getLoadSql()).isEqualTo(dataTable.getLoadSql());
                assertThat(persistedDataTable.isScheduled()).isEqualTo(dataTable.isScheduled());
                return null;
            }
        });
    }

    @Test
    public void testFindDataTableById() {
        // @Given an existing data table
        final DataColumn column = createColumn("columnName", "Description", true, 20, 10, 10, true, true, stringDataType(), true, "format", Lists.<String>newArrayList(), true, true);
        List<DataColumn> columns = Lists.newArrayList(column);
        final DataTable dataTable = createDataTable("tableName", columns, true, "Select * from table", "var i = 1; return i;");
        final Integer tableId = dataTable.getId();

        // @When finding the data table
        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                field("entityManager").ofType(EntityManager.class).in(repository).set(em);
                DataTable returnedDataTable = repository.findDataTableById(tableId);

                // @Then the data table is returned
                assertThat(returnedDataTable).isNotNull();
                assertThat(returnedDataTable.getId()).isEqualTo(dataTable.getId());
                assertThat(returnedDataTable.getCampaign().getId()).isEqualTo(dataTable.getCampaign().getId());
                assertThat(returnedDataTable.getAllowRecordCreation()).isEqualTo(dataTable.getAllowRecordCreation());
                assertThat(returnedDataTable.getDescription()).isEqualTo(dataTable.getDescription());
                assertThat(returnedDataTable.getName()).isEqualTo(dataTable.getName());
                assertThat(returnedDataTable.getLoadSql()).isEqualTo(dataTable.getLoadSql());
                assertThat(returnedDataTable.getLoadScript()).isEqualTo(dataTable.getLoadScript());
                assertThat(returnedDataTable.getColumn(column.getName())).isNotNull();
                return null;
            }
        });
    }

    @Test
    public void testFindDataColumnById() {
        // @Given an existing data column
        final DataColumn column = createColumn("columnName", "Description", true, 20, 10, 10, true, true, stringDataType(), true, "format", Lists.<String>newArrayList(), true, true);
        List<DataColumn> columns = Lists.newArrayList(column);
        createDataTable("tableName", columns, true);

        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                // @When finding the data column by id
                DataColumn returnedDataColumn = repository.findDataColumnById(1);

                // @Then the data column with the given id is returned
                assertThat(returnedDataColumn.getId()).isEqualTo(1);
                assertThat(returnedDataColumn.getName()).isEqualTo(column.getName());
                assertThat(returnedDataColumn.getDescription()).isEqualTo(column.getDescription());
                assertThat(returnedDataColumn.isFilterable()).isEqualTo(column.isFilterable());
                assertThat(returnedDataColumn.getMaxSize()).isEqualTo(column.getMaxSize());
                assertThat(returnedDataColumn.getMinSize()).isEqualTo(column.getMinSize());
                assertThat(returnedDataColumn.getPrecision()).isEqualTo(column.getPrecision());
                assertThat(returnedDataColumn.isRequired()).isEqualTo(column.isRequired());
                assertThat(returnedDataColumn.isSortable()).isEqualTo(column.isSortable());
                assertThat(returnedDataColumn.isEditable()).isEqualTo(column.isEditable());
                assertThat(returnedDataColumn.isHidden()).isEqualTo(column.isHidden());
                assertThat(returnedDataColumn.isPrimaryKey()).isEqualTo(column.isPrimaryKey());
                return null;
            }
        });

    }

    @Test
    @Ignore
    public void testErasingColumnWhenDataExistsAndReplacingItWithAnotherOfTheSameTypeDoesNotAffectTheFactThatTheNewColumnIsEmpty() {
        final Campaign campaign = JpaCampaignRepository_UT.createCampaigns(1).get(0);

        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                em.persist(campaign);

                return null;
            }
        });

        final DataTable dataTable = template.execute(new JpaTransactionCallBack<DataTable>() {
            @Override
            public DataTable doInTx(EntityManager em) {
                DataTable dataTable = new DataTable("table", Lists.<DataColumn>newArrayList(), new ReflectiveDataRowPersistorFactory());
                Campaign persistedCampaign = em.find(Campaign.class, campaign.getId());
                dataTable.setCampaign(persistedCampaign);
                dataTable.setScheduled(false);
                dataTable.setAllowRecordCreation(true);
                dataTable.setDescription("Hi");
                dataTable.setDataProvider(crmDataProvider());

                em.persist(dataTable);
                return dataTable;
            }
        });

        final List<DataColumn> firstDataColumns = template.execute(new JpaTransactionCallBack<List<DataColumn>>() {
            @Override
            public List<DataColumn> doInTx(EntityManager em) {
                DataColumnVO dataColumn1VO = newDataColumnVO(null, "column1", "description", 10, 0, 0, true, false, true, stringDataType().getCode(), true, "format", false, Lists.<String>newArrayList(), false);
                DataColumnVO dataColumn2VO = newDataColumnVO(null, "column2", "description", 10, 0, 0, true, false, true, stringDataType().getCode(), true, "format", false, Lists.<String>newArrayList(), false);
                DataColumnVO dataColumnSCVO = newDataColumnVO(null, "serviceCenter", "description", 10, 0, 0, true, false, true, serviceCenterDataType().getCode(), true, "format", false, Lists.<String>newArrayList(), false);

                DataTable persistedDataTable = em.find(DataTable.class, dataTable.getId());
                persistedDataTable.setDataRowPersistorFactory(dataRowPersistorFactory);
                persistedDataTable.setRowValuesServices(rowValuesServices);
                field("entityManager").ofType(EntityManager.class).in(rowValuesServices).set(em);
                return repository.updateMetadata(persistedDataTable, Lists.<DataColumnVO>newArrayList(dataColumn1VO, dataColumn2VO, dataColumnSCVO));
            }
        });

        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                DataTable persistedDataTable = em.find(DataTable.class, dataTable.getId());
                persistedDataTable.setDataRowPersistorFactory(dataRowPersistorFactory);
                persistedDataTable.setRowValuesServices(rowValuesServices);
                field("entityManager").ofType(EntityManager.class).in(rowValuesServices).set(em);
                Map<String, Object> rowData = Maps.newHashMap();
                DataRow dataRow1 = persistedDataTable.newRow(rowData);
                DataRow dataRow2 = persistedDataTable.newRow(rowData);

                Campaign persistedCampaign = em.find(Campaign.class, campaign.getId());
                ServiceCenter serviceCenter = new ServiceCenter();
                serviceCenter.setCuit("10");
                serviceCenter.setName("IAlwaysforget");
                serviceCenter.setCampaign(persistedCampaign);

                em.persist(serviceCenter);

                dataRow1.set("column1", "hello");
                dataRow1.set("column2", "bye");
                dataRow1.set("serviceCenter", serviceCenter);
                dataRow2.set("column1", "laurel");
                dataRow2.set("column2", "hardy");
                dataRow2.set("serviceCenter", serviceCenter);
                return null;
            }
        });

        template.execute(new JpaTransactionCallBack<List<DataColumn>>() {
            @Override
            public List<DataColumn> doInTx(EntityManager em) {
                DataColumnVO dataColumn1VO = newDataColumnVO(firstDataColumns.get(0).getId(), "column1", "description", 10, 0, 0, true, false, true, stringDataType().getCode(), true, "format", false, Lists.<String>newArrayList(), false);
                DataColumnVO dataColumn3VO = newDataColumnVO(null, "column3", "description", 10, 0, 0, true, false, true, stringDataType().getCode(), true, "format", false, Lists.<String>newArrayList(), false);
                DataColumnVO dataColumnSCVO = newDataColumnVO(null, "serviceCenter", "description", 10, 0, 0, true, false, true, serviceCenterDataType().getCode(), true, "format", false, Lists.<String>newArrayList(), false);

                DataTable persistedDataTable = em.find(DataTable.class, dataTable.getId());
                persistedDataTable.setDataRowPersistorFactory(dataRowPersistorFactory);
                persistedDataTable.setRowValuesServices(rowValuesServices);
                field("entityManager").ofType(EntityManager.class).in(rowValuesServices).set(em);
                field("entityManager").ofType(EntityManager.class).in(repository).set(em);
                return repository.updateMetadata(persistedDataTable, Lists.<DataColumnVO>newArrayList(dataColumn1VO, dataColumn3VO, dataColumnSCVO));
            }
        });

        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                DataTable persistedDataTable = em.find(DataTable.class, dataTable.getId());
                persistedDataTable.setDataRowPersistorFactory(dataRowPersistorFactory);
                persistedDataTable.setRowValuesServices(rowValuesServices);
                field("entityManager").ofType(EntityManager.class).in(rowValuesServices).set(em);
                field("entityManager").ofType(EntityManager.class).in(repository).set(em);
                List<DataRow> dataRows = persistedDataTable.findRowsByPage(1, 5, "column3", "asc", Maps.<String, Object>newHashMap());

                assertThat(dataRows.get(0).get("column1")).isEqualTo("hello");
                assertThat(dataRows.get(0).get("column3")).isNull();
                assertThat(dataRows.get(1).get("column1")).isEqualTo("laurel");
                assertThat(dataRows.get(1).get("column3")).isNull();
                return null;
            }
        });
    }

    private DataColumnVO newDataColumnVO(Integer id, String name, String description, Integer size, Integer minSize, Integer precision, Boolean sortable, Boolean required, Boolean filterable, String type, Boolean editable, String format, Boolean hidden, List<String> options, Boolean primaryKey) {
        DataColumnVO dataColumnVO = new DataColumnVO();
        dataColumnVO.setId(id);
        dataColumnVO.setName(name);
        dataColumnVO.setDescription(description);
        dataColumnVO.setSize(size);
        dataColumnVO.setMinSize(minSize);
        dataColumnVO.setPrecision(precision);
        dataColumnVO.setSortable(sortable);
        dataColumnVO.setRequired(required);
        dataColumnVO.setFilterable(filterable);
        dataColumnVO.setType(type);
        dataColumnVO.setEditable(editable);
        dataColumnVO.setFormat(format);
        dataColumnVO.setHidden(hidden);
        dataColumnVO.setOptions(options);
        dataColumnVO.setPrimaryKey(primaryKey);
        return dataColumnVO;
    }


    private DataColumn createColumn(String columnName, String description, boolean filterable, int maxLength, int minLength, int precision, boolean required, boolean sortable, DataType type, boolean editable, String format, List<String> options, boolean hidden, boolean primaryKey) {
        DataColumn column = createColumn(columnName, type);
        column.setDescription(description);
        column.setFilterable(filterable);
        column.setMaxSize(maxLength);
        column.setMinSize(minLength);
        column.setPrecision(precision);
        column.setRequired(required);
        column.setSortable(sortable);
        column.setEditable(editable);
        column.setFormat(format);
        column.setOptions(options);
        column.setHidden(hidden);
        column.setPrimaryKey(primaryKey);
        return column;
    }

    private DataColumn createColumn(final String columnName, final DataType type) {
        return new DataColumn(columnName, type);
    }

    private DataTable createDataTable(final String name, final List<DataColumn> columns, final boolean allowRecordCreation, final String loadSql, final String loadScript) {
        return template.execute(new JpaTransactionCallBack<DataTable>() {
            @Override
            public DataTable doInTx(EntityManager em) {
                DataTable dataTable = new DataTable(name, columns, dataRowPersistorFactory);
                dataTable.setDataProvider(crmDataProvider());
                dataTable.setAllowRecordCreation(allowRecordCreation);
                dataTable.setLoadSql(loadSql);
                dataTable.setLoadScript(loadScript);
                Campaign campaign = new Campaign("campaignName", newDate(2011, 1, 1), newDate(2012, 1, 1));
                em.persist(campaign);
                dataTable.setCampaign(campaign);
                em.persist(dataTable);

                for (DataColumn column : columns) {
                    em.persist(column);
                }

                return dataTable;
            }
        });
    }

    private DataTable createDataTable(final String name, final List<DataColumn> columns, final boolean allowRecordCreation) {
        return template.execute(new JpaTransactionCallBack<DataTable>() {
            @Override
            public DataTable doInTx(EntityManager em) {
                DataTable dataTable = new DataTable(name, columns, dataRowPersistorFactory);
                dataTable.setDataProvider(crmDataProvider());
                dataTable.setAllowRecordCreation(allowRecordCreation);
                Campaign campaign = new Campaign("campaignName", newDate(2011, 1, 1), newDate(2012, 1, 1));
                em.persist(campaign);
                dataTable.setCampaign(campaign);
                em.persist(dataTable);

                for (DataColumn column : columns) {
                    em.persist(column);
                }

                return dataTable;
            }
        });
    }

    private DataProvider crmDataProvider() {
        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode("CRM");
        dataProvider.setName("Client relationship manager");

        return dataProvider;
    }

    private DataType stringDataType() {
        DataType dataType = new DataType();

        field("code").ofType(String.class).in(dataType).set("string");
        field("name").ofType(String.class).in(dataType).set("String");
        field("internalType").ofType(Class.class).in(dataType).set(String.class);

        return dataType;
    }

    private DataType serviceCenterDataType() {
        DataType dataType = new DataType();
        dataType.setInternalType(ServiceCenter.class);
        dataType.setCode("SC");
        return dataType;
    }
}
