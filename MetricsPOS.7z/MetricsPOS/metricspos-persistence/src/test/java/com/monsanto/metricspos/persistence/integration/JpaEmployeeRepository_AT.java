package com.monsanto.metricspos.persistence.integration;

import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.persistence.JpaEmployeeRepository;
import com.monsanto.metricspos.persistence.jpa.JpaTransactionCallBack;
import com.monsanto.metricspos.persistence.jpa.JpaTransactionTemplate;
import com.monsanto.metricspos.persistence.keys.EmployeeKey;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;

/**
 * User: PPERA
 */
@Ignore
public class JpaEmployeeRepository_AT {
    private JpaTransactionTemplate template;

    @Before
    public void setUp() throws Exception {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("metricsposPU");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        template = new JpaTransactionTemplate(entityManagerFactory);
        JpaEmployeeRepository repository = new JpaEmployeeRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);
    }

    @Test
    public void testFindEmployeeOneReturnsEmployeeWithIdOne_WhenEmployeeOneHadBeenPersisted() {
        // @Given a persisted employee
        final Campaign campaign = template.execute(new JpaTransactionCallBack<Campaign>() {
            @Override
            public Campaign doInTx(EntityManager em) {
                Campaign campaign = new Campaign("Name", newDate(2015, 5, 4), newDate(2019, 7, 9));
                em.persist(campaign);
                return campaign;
            }
        });

        final Integer campaignId = campaign.getId();

        final Employee employee = template.execute(new JpaTransactionCallBack<Employee>() {
            @Override
            public Employee doInTx(EntityManager em) {
                Employee employee = new Employee();
                Campaign persistedCampaign = em.find(Campaign.class, campaignId);
                employee.setId(1l);
                employee.setLoaded(true);
                employee.setCampaign(persistedCampaign);
                employee.setName("Name");
                employee.setUsername("name");
                employee.setLoaded(true);
                em.persist(employee);
                return employee;
            }
        });

        final Long employeeId = employee.getId();

        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                // @When finding the employee
                Employee returnedEmployee = em.find(Employee.class, new EmployeeKey(em.find(Campaign.class, campaignId),employeeId));

                // @Then the employee is returned
                assertThat(returnedEmployee).isNotNull();
                assertThat(returnedEmployee.getId()).isEqualTo(employeeId);
                assertThat(returnedEmployee.getCampaign().getId()).isEqualTo(campaignId);
                assertThat(returnedEmployee.getName()).isEqualTo(employee.getName());
                assertThat(returnedEmployee.getLoaded()).isEqualTo(employee.getLoaded());
                assertThat(returnedEmployee.getUsername()).isEqualTo(employee.getUsername());

                return null;
            }
        });
    }
}
