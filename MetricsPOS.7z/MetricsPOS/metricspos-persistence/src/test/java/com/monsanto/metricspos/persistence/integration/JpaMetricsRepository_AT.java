package com.monsanto.metricspos.persistence.integration;

import com.monsanto.metricspos.persistence.JpaMetricsRepository;
import org.junit.Before;
import org.junit.Ignore;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import static org.fest.reflect.core.Reflection.field;

/**
 * User: PPERA
 */
@Ignore
public class JpaMetricsRepository_AT {

    @Before
    public void setUp() throws Exception {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("metricsposPU");
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        JpaMetricsRepository repository = new JpaMetricsRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);
    }


}
