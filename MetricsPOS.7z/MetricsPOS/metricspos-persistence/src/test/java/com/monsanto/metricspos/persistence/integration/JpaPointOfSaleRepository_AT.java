package com.monsanto.metricspos.persistence.integration;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.JpaPointOfSaleRepository;
import com.monsanto.metricspos.persistence.jpa.JpaTransactionCallBack;
import com.monsanto.metricspos.persistence.jpa.JpaTransactionTemplate;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;

/**
 * User: PPERA
 */
@Ignore
public class JpaPointOfSaleRepository_AT {
    private JpaTransactionTemplate template;

    @Before
    public void setUp() throws Exception {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("metricsposPU");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        template = new JpaTransactionTemplate(entityManagerFactory);

        JpaPointOfSaleRepository repository = new JpaPointOfSaleRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);
    }

    @Test
    public void testDeletedServiceCentersAreNotRetrieved_WhenListingAllServiceCenters() {
        final Campaign campaign = new Campaign("campaign", newDate(2012, 1, 1), newDate(2013, 2, 2));

        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                em.persist(campaign);

                final ServiceCenter serviceCenter = new ServiceCenter();
                serviceCenter.setCuit("10");
                serviceCenter.setName("John");
                serviceCenter.setCampaign(campaign);
                PointOfSale pointOfSale = new PointOfSale();
                pointOfSale.setServiceCenter(serviceCenter);
                pointOfSale.setIdSap(1l);
                pointOfSale.setCampaign(campaign);
                serviceCenter.setPointsOfSale(Lists.<PointOfSale>newArrayList(pointOfSale));
                serviceCenter.setDeleted(true);

                final ServiceCenter serviceCenter2 = new ServiceCenter();
                serviceCenter2.setCuit("22");
                serviceCenter2.setName("NotDeleted");
                serviceCenter2.setCampaign(campaign);
                serviceCenter2.setPointsOfSale(Lists.<PointOfSale>newArrayList(pointOfSale));
                serviceCenter2.setDeleted(false);
                em.persist(serviceCenter);
                em.persist(serviceCenter2);
                em.persist(pointOfSale);
                return null;
            }
        });

        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                Campaign persistedCampaign = em.find(Campaign.class, campaign.getId());
                List<ServiceCenter> serviceCenters = persistedCampaign.getServiceCenters();
                assertThat(serviceCenters).hasSize(1);
                assertThat(serviceCenters).onProperty("cuit").contains("22");
                return null;
            }
        });
    }
}
