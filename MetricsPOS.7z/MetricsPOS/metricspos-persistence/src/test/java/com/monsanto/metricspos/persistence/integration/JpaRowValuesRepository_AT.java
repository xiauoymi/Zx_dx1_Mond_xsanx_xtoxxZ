package com.monsanto.metricspos.persistence.integration;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.externaldata.DataType;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import com.monsanto.metricspos.persistence.JpaRowValuesRepository;
import com.monsanto.metricspos.persistence.ReflectiveDataRowPersistorFactory;
import com.monsanto.metricspos.persistence.RowValues;
import com.monsanto.metricspos.persistence.hibernate.DataProvidersHolder;
import com.monsanto.metricspos.persistence.hibernate.DataTypesHolder;
import com.monsanto.metricspos.persistence.jpa.JpaTransactionCallBack;
import com.monsanto.metricspos.persistence.jpa.JpaTransactionTemplate;
import com.monsanto.metricspos.persistence.keys.PointOfSaleKey;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.fest.reflect.core.Reflection.staticField;

/**
 * User: PPERA
 */
@Ignore
public class JpaRowValuesRepository_AT {
    private DataRowPersistorFactory dataRowPersistorFactory;
    private JpaTransactionTemplate template;
    private JpaRowValuesRepository repository;

    @Before
    public void setUp() throws Exception {
        HashMap<String, DataType> dataTypeMap = Maps.newHashMap();
        dataTypeMap.put("string", stringDataType());

        staticField("dataTypes").ofType(Map.class).in(DataTypesHolder.class).set(dataTypeMap);

        Map<String, DataProvider> dataProvidersMap = Maps.newHashMap();
        dataProvidersMap.put("CRM", crmDataProvider());
        staticField("dataProviders").ofType(Map.class).in(DataProvidersHolder.class).set(dataProvidersMap);


        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("metricsposPU");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        dataRowPersistorFactory = new ReflectiveDataRowPersistorFactory();

        Map<Class, String> classXprefix = Maps.newHashMap();
        classXprefix.put(String.class, RowValues.TEXT_COLUMN_PREFIX);
        classXprefix.put(Integer.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Long.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(BigDecimal.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Number.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Date.class, RowValues.DATE_COLUMN_PREFIX);

        field("classToPrefixMap").ofType(Map.class).in(dataRowPersistorFactory).set(classXprefix);

        template = new JpaTransactionTemplate(entityManagerFactory);

        repository = new JpaRowValuesRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);
    }

    @Test
    public void testAddPersistsARowWith20TextValues5Dates5BooleansAnd10Numbers_WhenRowValuesIsLoadedWith20TextValues5Dates5BooleanAnd10Numbers() {
        // @Given rowValues with 10 text values, 5 dates and 5 numbers
        List<DataColumn> columns = Lists.newArrayList(
                createColumn("column1", "column1Description", true, 20, 14, 12, true, true, stringDataType(), true, "format", Lists.<String>newArrayList(), true, true, "text1")
        );

        final Campaign campaign = new Campaign("campaign", newDate(2012, 1, 1), newDate(2013, 2, 2));
        final String cuit = "10";

        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                em.persist(campaign);

                final ServiceCenter serviceCenter = new ServiceCenter();
                serviceCenter.setCuit(cuit);
                serviceCenter.setName("John");
                serviceCenter.setCampaign(campaign);
                PointOfSale pointOfSale = new PointOfSale();
                pointOfSale.setServiceCenter(serviceCenter);
                pointOfSale.setIdSap(1l);
                pointOfSale.setCampaign(campaign);
                serviceCenter.setPointsOfSale(Lists.<PointOfSale>newArrayList(pointOfSale));
                em.persist(serviceCenter);
                em.persist(pointOfSale);
                return null;
            }
        });

        final DataTable dataTable = this.createDataTable("tableName", columns, true);

        final RowValues rowValues = new RowValues();

        // @When adding it to the repository
        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                ServiceCenter serviceCenterKey = new ServiceCenter();
                serviceCenterKey.setCampaign(campaign);
                serviceCenterKey.setCuit(cuit);
                ServiceCenter serviceCenter = em.find(ServiceCenter.class, serviceCenterKey);
                Long idSap = serviceCenter.getPointsOfSale().get(0).getIdSap();
                PointOfSale pointOfSale = em.find(PointOfSale.class, new PointOfSaleKey(campaign, idSap, serviceCenter));

                rowValues.setManual(true);
                rowValues.setServiceCenter(serviceCenter);
                rowValues.setPointOfSale(pointOfSale);
                field("text1").ofType(String.class).in(rowValues).set("Hello1");
                field("text2").ofType(String.class).in(rowValues).set("Hello2");
                field("text3").ofType(String.class).in(rowValues).set("Hello3");
                field("text4").ofType(String.class).in(rowValues).set("Hello4");
                field("text5").ofType(String.class).in(rowValues).set("Hello5");
                field("text6").ofType(String.class).in(rowValues).set("Hello6");
                field("text7").ofType(String.class).in(rowValues).set("Hello7");
                field("text8").ofType(String.class).in(rowValues).set("Hello8");
                field("text9").ofType(String.class).in(rowValues).set("Hello9");
                field("text10").ofType(String.class).in(rowValues).set("Hello10");
                field("text11").ofType(String.class).in(rowValues).set("Hello11");
                field("text12").ofType(String.class).in(rowValues).set("Hello12");
                field("text13").ofType(String.class).in(rowValues).set("Hello13");
                field("text14").ofType(String.class).in(rowValues).set("Hello14");
                field("text15").ofType(String.class).in(rowValues).set("Hello15");
                field("text16").ofType(String.class).in(rowValues).set("Hello16");
                field("text17").ofType(String.class).in(rowValues).set("Hello17");
                field("text18").ofType(String.class).in(rowValues).set("Hello18");
                field("text19").ofType(String.class).in(rowValues).set("Hello19");
                field("text20").ofType(String.class).in(rowValues).set("Hello20");

                field("date1").ofType(Date.class).in(rowValues).set(newDate(2002, 4, 5));
                field("date2").ofType(Date.class).in(rowValues).set(newDate(2003, 5, 6));
                field("date3").ofType(Date.class).in(rowValues).set(newDate(2004, 6, 7));
                field("date4").ofType(Date.class).in(rowValues).set(newDate(2005, 7, 8));
                field("date5").ofType(Date.class).in(rowValues).set(newDate(2006, 8, 9));

                field("number1").ofType(BigDecimal.class).in(rowValues).set(BigDecimal.valueOf(1));
                field("number2").ofType(BigDecimal.class).in(rowValues).set(BigDecimal.valueOf(1.5));
                field("number3").ofType(BigDecimal.class).in(rowValues).set(BigDecimal.valueOf(10000));
                field("number4").ofType(BigDecimal.class).in(rowValues).set(BigDecimal.valueOf(165489));
                field("number5").ofType(BigDecimal.class).in(rowValues).set(BigDecimal.valueOf(141616.9876));
                field("number6").ofType(BigDecimal.class).in(rowValues).set(BigDecimal.valueOf(1435134534));
                field("number7").ofType(BigDecimal.class).in(rowValues).set(BigDecimal.valueOf(134));
                field("number8").ofType(BigDecimal.class).in(rowValues).set(BigDecimal.valueOf(3));
                field("number9").ofType(BigDecimal.class).in(rowValues).set(BigDecimal.valueOf(333.333));
                field("number10").ofType(BigDecimal.class).in(rowValues).set(BigDecimal.valueOf(123456789));

                field("boolean1").ofType(Boolean.class).in(rowValues).set(true);
                field("boolean2").ofType(Boolean.class).in(rowValues).set(true);
                field("boolean3").ofType(Boolean.class).in(rowValues).set(true);
                field("boolean4").ofType(Boolean.class).in(rowValues).set(true);
                field("boolean5").ofType(Boolean.class).in(rowValues).set(true);

                rowValues.setTable(dataTable);

                field("entityManager").ofType(EntityManager.class).in(repository).set(em);
                repository.add(rowValues);
                return null;
            }
        });

        //@Then the row values are contained in the entityManaged
        template.execute(new JpaTransactionCallBack<Void>() {
            @Override
            public Void doInTx(EntityManager em) {
                RowValues persistedRowValues = em.find(RowValues.class, rowValues.getId());
                assertThat(persistedRowValues.getId()).isEqualTo(rowValues.getId());
                assertThat(persistedRowValues.getManual()).isEqualTo(rowValues.getManual());
                assertThat(persistedRowValues.getTable().getId()).isEqualTo(rowValues.getTable().getId());
                assertThat(persistedRowValues.getServiceCenter().getCuit()).isEqualTo(cuit);
                assertThat(persistedRowValues.getPointOfSale()).isNotNull();
                assertThat(persistedRowValues.getPointOfSale().getIdSap()).isEqualTo(rowValues.getPointOfSale().getIdSap());
                assertThat(field("text1").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello1");
                assertThat(field("text2").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello2");
                assertThat(field("text3").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello3");
                assertThat(field("text4").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello4");
                assertThat(field("text5").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello5");
                assertThat(field("text6").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello6");
                assertThat(field("text7").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello7");
                assertThat(field("text8").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello8");
                assertThat(field("text9").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello9");
                assertThat(field("text10").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello10");
                assertThat(field("text11").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello11");
                assertThat(field("text12").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello12");
                assertThat(field("text13").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello13");
                assertThat(field("text14").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello14");
                assertThat(field("text15").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello15");
                assertThat(field("text16").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello16");
                assertThat(field("text17").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello17");
                assertThat(field("text18").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello18");
                assertThat(field("text19").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello19");
                assertThat(field("text20").ofType(String.class).in(persistedRowValues).get()).isEqualTo("Hello20");
                assertThat(field("date1").ofType(Date.class).in(persistedRowValues).get().getTime()).isEqualTo(newDate(2002, 4, 5).getTime());
                assertThat(field("date2").ofType(Date.class).in(persistedRowValues).get().getTime()).isEqualTo(newDate(2003, 5, 6).getTime());
                assertThat(field("date3").ofType(Date.class).in(persistedRowValues).get().getTime()).isEqualTo(newDate(2004, 6, 7).getTime());
                assertThat(field("date4").ofType(Date.class).in(persistedRowValues).get().getTime()).isEqualTo(newDate(2005, 7, 8).getTime());
                assertThat(field("date5").ofType(Date.class).in(persistedRowValues).get().getTime()).isEqualTo(newDate(2006, 8, 9).getTime());
                assertThat(field("number1").ofType(BigDecimal.class).in(persistedRowValues).get()).isEqualTo(BigDecimal.valueOf(1).setScale(4));
                assertThat(field("number2").ofType(BigDecimal.class).in(persistedRowValues).get()).isEqualTo(BigDecimal.valueOf(1.5).setScale(4));
                assertThat(field("number3").ofType(BigDecimal.class).in(persistedRowValues).get()).isEqualTo(BigDecimal.valueOf(10000).setScale(4));
                assertThat(field("number4").ofType(BigDecimal.class).in(persistedRowValues).get()).isEqualTo(BigDecimal.valueOf(165489).setScale(4));
                assertThat(field("number5").ofType(BigDecimal.class).in(persistedRowValues).get()).isEqualTo(BigDecimal.valueOf(141616.9876).setScale(4));
                assertThat(field("number6").ofType(BigDecimal.class).in(persistedRowValues).get()).isEqualTo(BigDecimal.valueOf(1435134534).setScale(4));
                assertThat(field("number7").ofType(BigDecimal.class).in(persistedRowValues).get()).isEqualTo(BigDecimal.valueOf(134).setScale(4));
                assertThat(field("number8").ofType(BigDecimal.class).in(persistedRowValues).get()).isEqualTo(BigDecimal.valueOf(3).setScale(4));
                assertThat(field("number9").ofType(BigDecimal.class).in(persistedRowValues).get()).isEqualTo(BigDecimal.valueOf(333.333).setScale(4));
                assertThat(field("number10").ofType(BigDecimal.class).in(persistedRowValues).get()).isEqualTo(BigDecimal.valueOf(123456789).setScale(4));
                assertThat(field("boolean1").ofType(Boolean.class).in(persistedRowValues).get()).isEqualTo(true);
                assertThat(field("boolean2").ofType(Boolean.class).in(persistedRowValues).get()).isEqualTo(true);
                assertThat(field("boolean3").ofType(Boolean.class).in(persistedRowValues).get()).isEqualTo(true);
                assertThat(field("boolean4").ofType(Boolean.class).in(persistedRowValues).get()).isEqualTo(true);
                assertThat(field("boolean5").ofType(Boolean.class).in(persistedRowValues).get()).isEqualTo(true);

                return null;
            }
        });
    }

    private DataColumn createColumn(String columnName, String description, boolean filterable, int maxLength, int minLength, int precision, boolean required, boolean sortable, com.monsanto.metricspos.core.externaldata.DataType type, boolean editable, String format, List<String> options, boolean hidden, boolean primaryKey, String actualColumnName) {
        DataColumn column = createColumn(columnName, type);
        column.setDescription(description);
        column.setFilterable(filterable);
        column.setMaxSize(maxLength);
        column.setMinSize(minLength);
        column.setPrecision(precision);
        column.setRequired(required);
        column.setSortable(sortable);
        column.setEditable(editable);
        column.setFormat(format);
        column.setOptions(options);
        column.setHidden(hidden);
        column.setPrimaryKey(primaryKey);
        column.setActualColumnName(actualColumnName);
        return column;
    }

    private DataColumn createColumn(final String columnName, final com.monsanto.metricspos.core.externaldata.DataType type) {
        return new DataColumn(columnName, type);
    }

    private DataTable createDataTable(final String name, final List<DataColumn> columns, final boolean allowRecordCreation) {
        return template.execute(new JpaTransactionCallBack<DataTable>() {
            @Override
            public DataTable doInTx(EntityManager em) {
                DataTable dataTable = new DataTable(name, columns, dataRowPersistorFactory);
                dataTable.setDataProvider(crmDataProvider());
                dataTable.setAllowRecordCreation(allowRecordCreation);
                Campaign campaign = new Campaign("campaignName", newDate(2011, 1, 1), newDate(2012, 1, 1));
                em.persist(campaign);
                dataTable.setCampaign(campaign);
                em.persist(dataTable);

                for (DataColumn column : columns) {
                    em.persist(column);
                }

                return dataTable;
            }
        });
    }

    private com.monsanto.metricspos.core.externaldata.DataType stringDataType() {
        com.monsanto.metricspos.core.externaldata.DataType dataType = new com.monsanto.metricspos.core.externaldata.DataType();

        field("code").ofType(String.class).in(dataType).set("string");
        field("name").ofType(String.class).in(dataType).set("String");
        field("internalType").ofType(Class.class).in(dataType).set(String.class);

        return dataType;
    }

    private DataProvider crmDataProvider() {
        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode("CRM");
        dataProvider.setName("Client relationship manager");

        return dataProvider;
    }
}
