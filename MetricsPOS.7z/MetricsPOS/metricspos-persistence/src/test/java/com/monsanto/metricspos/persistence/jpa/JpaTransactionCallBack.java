package com.monsanto.metricspos.persistence.jpa;

import javax.persistence.EntityManager;

import static org.fest.assertions.Fail.fail;

/**
 * User: ppera
 */
public abstract class JpaTransactionCallBack<T> {
    public abstract T doInTx(EntityManager em );

    public void onError(RuntimeException e) {
        fail("Error while executing transaction", e);
    }
}

