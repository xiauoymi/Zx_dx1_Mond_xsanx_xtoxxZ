package com.monsanto.metricspos.persistence.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 * User: ppera
 */
public class JpaTransactionTemplate {
    private EntityManagerFactory emf;

    public JpaTransactionTemplate(EntityManagerFactory emf) {
        this.emf = emf;
    }

    public <T> T execute(JpaTransactionCallBack<T> callback) {
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();

            T result = callback.doInTx(em);

            em.getTransaction().commit();
            return result;

        } catch (RuntimeException e) {
            em.getTransaction().rollback();
            callback.onError(e);
            return null;    // TODO check what to return
        } finally {
            em.close();
        }
    }
}
