package com.monsanto.metricspos.persistence.keys;

import com.monsanto.metricspos.core.metrics.Campaign;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

/**
 * User: SHELG
 */
public class EmployeeKey_UT {
    @Test
    public void testServiceCenterKey() {
        EmployeeKey k = new EmployeeKey();
        Campaign camp = mock(Campaign.class);
        k.setCampaign(camp);
        k.setId(1);

        assertTrue(camp.equals(k.getCampaign()));

        assertTrue(1 == k.getId());
    }

    @Test
    public void testServiceCenterKey_() {
        Campaign camp = mock(Campaign.class);
        EmployeeKey k = new EmployeeKey(camp, 1);

        assertTrue(camp.equals(k.getCampaign()));

        assertTrue(1 == k.getId());
    }
}
