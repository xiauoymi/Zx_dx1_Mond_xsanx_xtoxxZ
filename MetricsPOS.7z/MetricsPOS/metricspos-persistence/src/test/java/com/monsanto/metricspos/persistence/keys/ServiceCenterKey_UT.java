package com.monsanto.metricspos.persistence.keys;

import com.monsanto.metricspos.core.metrics.Campaign;
import org.junit.Test;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

/**
 * User: PPERA
 */
public class ServiceCenterKey_UT {
    @Test
    public void testServiceCenterKey() {
        ServiceCenterKey k = new ServiceCenterKey();
        Campaign camp = mock(Campaign.class);
        k.setCampaign(camp);
        k.setCuit("000000001");

        ServiceCenterKey kk =  new ServiceCenterKey();
        kk.setCampaign(camp);
        kk.setCuit("00");

        assertFalse(k.equals(kk));

        assertTrue(camp.equals(k.getCampaign()));

        assertTrue("000000001".equals(k.getCuit()));
    }

    @Test
    public void testServiceCenterKey_() {
        Campaign camp = mock(Campaign.class);
        ServiceCenterKey k = new ServiceCenterKey(camp, "000000001");

        ServiceCenterKey kk =  new ServiceCenterKey();
        kk.setCampaign(camp);
        kk.setCuit("00");

        assertFalse(k.equals(kk));

        assertFalse(0 == k.hashCode());

        assertTrue(camp.equals(k.getCampaign()));

        assertTrue("000000001".equals(k.getCuit()));
    }
}
