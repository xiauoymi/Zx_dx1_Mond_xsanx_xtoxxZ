package com.monsanto.metricspos.persistence.unit;

import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.CampaignVO;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.CampaignParameter;
import com.monsanto.metricspos.core.metrics.CampaignState;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.JpaCampaignRepository;
import com.monsanto.metricspos.persistence.queries.CampaignParameterQuery;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * Test the JpaCampaignRepository class
 *
 * @author CAFAU
 */
public class JpaCampaignRepository_UT {
    private JpaCampaignRepository repository;

    private EntityManager entityManager;
    private Query query;
    private SecurityHolderStrategy securityHolderStrategy;

    @Before
    public void setUp() {
        entityManager = mock(EntityManager.class);
        query = mock(Query.class);
        when(entityManager.createQuery(anyString())).thenReturn(query);
        this.repository = new JpaCampaignRepository();
        securityHolderStrategy = mock(SecurityHolderStrategy.class);
        when(securityHolderStrategy.getCurrentUser()).thenReturn(new AdminUser());
        field("securityHolderStrategy").ofType(SecurityHolderStrategy.class).in(repository).set(securityHolderStrategy);
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);
    }

    @Test
    public void testGetCampaignsNone() throws Exception {
        // @Given A repository without campaigns
        List<Campaign> expectedCampaigns = createCampaigns(0);

        when(query.getResultList()).thenReturn(expectedCampaigns);

        // @When Get all campaigns
        List<Campaign> campaigns = repository.listAllCampaigns();

        // @Then get an empty list
        assertThat(campaigns).isNotNull().hasSize(0);
    }

    @Test
    public void testListAllCampaignsCreatesAUserQueryAndExecutesIt_WhenListingCampaignsAndLoggedUserIsNotAdmin() throws Exception {
        // @Given a logged user that is not an admin
        Employee employee = new Employee();
        employee.setId(1l);
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);

        // @When listing all the campaigns
        this.repository.listAllCampaigns();

        // @Then a user query is created and executed
        verify(this.entityManager, times(1)).createQuery(JpaCampaignRepository.ALL_CAMPAIGNS_OF_EMPLOYEE);
        verify(this.query, times(1)).setParameter("username", employee.getUsername());
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindCampaignByIdReturnsMatchingCampaign_WhenFindingExistingCampaign() {
        // @Given an existing campaign
        Campaign campaign = createCampaigns(1).get(0);
        campaign.setId(1);
        when(query.getSingleResult()).thenReturn(campaign);

        // @When finding it by Id
        Campaign campaignById = repository.findCampaignById(campaign.getId());

        // @Then the campaign with the provided id is returned
        assertThat(campaignById).isEqualTo(campaign);
    }

    @Test
    public void testFindCampaignByIdThrowsBusinessException_WhenFindingNonExistentCampaign() {
        // @Given an existing campaign
        when(query.getSingleResult()).thenThrow(new NoResultException());

        repository = new JpaCampaignRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);

        // @When finding it by Id
        try {
            repository.findCampaignById(3);
            fail();
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_CAMPAIGN_NOT_FOUND);
        } catch (Throwable e) {
            fail();
        }
    }

    @Test
    public void testUpdateCampaignSetsAllFields_WhenUpdatingACampaign() {
        // @Given a Campaign and a VO with updated data
        Campaign campaign = mock(Campaign.class);
        CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName("Name");
        campaignVO.setSince(newDate(2012, 6, 12));
        campaignVO.setUntil(newDate(2020, 12, 2));
        campaignVO.setState(CampaignState.CREATED);
        campaignVO.setScheduled(true);
        campaignVO.setServiceCenterLoadSql("loadSql");
        campaignVO.setServiceCenterLoadScript("loadScript");
        campaignVO.setPointOfSaleLoadSql("loadSql1");
        campaignVO.setPointOfSaleLoadScript("loadScript1");
        campaignVO.setEmployeeLoadSql("loadSql2");
        campaignVO.setEmployeeLoadScript("loadScript2");
        campaignVO.setRatingFormula("ratingformula");
        campaignVO.setRatingPremiumCategory("ratingPremiumCategory");
        when(query.getResultList()).thenReturn(Lists.newArrayList(campaign));

        // @When updating the campaign
        this.repository.updateCampaign(campaign, campaignVO);

        // @Then all fields are set with the VO's values
        verify(campaign, times(1)).setName(campaignVO.getName());
        verify(campaign, times(1)).setSince(campaignVO.getSince());
        verify(campaign, times(1)).setUntil(campaignVO.getUntil());
        verify(campaign, times(1)).setState(campaignVO.getState());
        verify(campaign, times(1)).setScheduled(campaignVO.isScheduled());
        verify(campaign, times(1)).setServiceCenterLoadSql(campaignVO.getServiceCenterLoadSql());
        verify(campaign, times(1)).setServiceCenterLoadScript(campaignVO.getServiceCenterLoadScript());
        verify(campaign, times(1)).setPointOfSaleLoadSql(campaignVO.getPointOfSaleLoadSql());
        verify(campaign, times(1)).setPointOfSaleLoadScript(campaignVO.getPointOfSaleLoadScript());
        verify(campaign, times(1)).setEmployeeLoadSql(campaignVO.getEmployeeLoadSql());
        verify(campaign, times(1)).setEmployeeLoadScript(campaignVO.getEmployeeLoadScript());
        verify(campaign, times(1)).setRatingFormula(campaignVO.getRatingFormula());
        verify(campaign, times(1)).setRatingPremiumCategory(campaignVO.getRatingPremiumCategory());
    }

    @Test
    public void testUpdateCampaignSetsAllFields2_WhenUpdatingACampaign() {
        // @Given a Campaign and a VO with updated data
        Campaign campaign = mock(Campaign.class);
        CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName("Name2");
        campaignVO.setSince(newDate(2015, 6, 12));
        campaignVO.setUntil(newDate(2022, 12, 2));
        campaignVO.setState(CampaignState.CREATED);
        campaignVO.setScheduled(false);
        campaignVO.setServiceCenterLoadSql("loadSql2");
        campaignVO.setServiceCenterLoadScript("loadScript2");
        campaignVO.setPointOfSaleLoadSql("loadSql12");
        campaignVO.setPointOfSaleLoadScript("loadScript12");
        campaignVO.setEmployeeLoadSql("loadSql22");
        campaignVO.setEmployeeLoadScript("loadScript22");
        campaignVO.setRatingFormula("ratingformula2");
        campaignVO.setRatingPremiumCategory("PremiumCategory2");
        when(query.getResultList()).thenReturn(Lists.newArrayList(campaign));

        // @When updating the campaign
        this.repository.updateCampaign(campaign, campaignVO);

        // @Then all fields are set with the VO's values
        verify(campaign, times(1)).setName(campaignVO.getName());
        verify(campaign, times(1)).setSince(campaignVO.getSince());
        verify(campaign, times(1)).setUntil(campaignVO.getUntil());
        verify(campaign, times(1)).setState(campaignVO.getState());
        verify(campaign, times(1)).setScheduled(campaignVO.isScheduled());
        verify(campaign, times(1)).setServiceCenterLoadSql(campaignVO.getServiceCenterLoadSql());
        verify(campaign, times(1)).setServiceCenterLoadScript(campaignVO.getServiceCenterLoadScript());
        verify(campaign, times(1)).setPointOfSaleLoadSql(campaignVO.getPointOfSaleLoadSql());
        verify(campaign, times(1)).setPointOfSaleLoadScript(campaignVO.getPointOfSaleLoadScript());
        verify(campaign, times(1)).setEmployeeLoadSql(campaignVO.getEmployeeLoadSql());
        verify(campaign, times(1)).setEmployeeLoadScript(campaignVO.getEmployeeLoadScript());
        verify(campaign, times(1)).setRatingFormula(campaignVO.getRatingFormula());
        verify(campaign, times(1)).setRatingPremiumCategory(campaignVO.getRatingPremiumCategory());
    }

    @Test
    public void testUpdateCampaignReturnsTheUpdatedCampaign_WhenUpdatingACampaign() {
        // @Given a Campaign and a VO with updated data
        Campaign campaign = mock(Campaign.class);
        CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName("Name");
        campaignVO.setSince(newDate(2012, 6, 12));
        campaignVO.setUntil(newDate(2020, 12, 2));
        campaignVO.setState(CampaignState.CREATED);
        campaignVO.setServiceCenterLoadSql("loadSql");
        campaignVO.setServiceCenterLoadScript("loadScript");
        when(query.getResultList()).thenReturn(Lists.newArrayList(campaign));

        // @When updating the campaign
        Campaign returnedCampaign = this.repository.updateCampaign(campaign, campaignVO);

        // @Then the returned campaign is the updatedCampaign
        assertThat(returnedCampaign).isSameAs(campaign);
    }

    @Test
    public void testFindServiceCenterByCampaignIdAndCuitCreatesAQueryAndSetsItsParameters_WhenFindingAServiceCenterByCampaignIdAndCuit() {
        // @Given an existing service center corresponding to a campaign
        ServiceCenter expectedServiceCenter = new ServiceCenter();
        Campaign campaign = createCampaigns(1).get(0);
        campaign.setId(1);
        String cuit = "101010101";
        expectedServiceCenter.setCampaign(campaign);
        expectedServiceCenter.setCuit(cuit);
        when(query.getSingleResult()).thenReturn(expectedServiceCenter);

        // @When finding the service center
        this.repository.findServiceCenterByCampaignIdAndCuit(campaign, cuit);

        // @Then the query is created
        verify(this.entityManager, times(1)).createQuery(JpaCampaignRepository.FIND_SERVICE_CENTER_BY_CAMPAIGN_AND_CUIT);
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter("cuit", cuit);
    }

    @Test
    public void testFindServiceCenterByCampaignIdAndCuitReturnsQueryResult_WhenFindingAServiceCenterByCampaignIdAndCuit() {
        // @Given an existing service center corresponding to a campaign
        ServiceCenter expectedServiceCenter = new ServiceCenter();
        Campaign campaign = createCampaigns(1).get(0);
        campaign.setId(1);
        String cuit = "101010101";
        expectedServiceCenter.setCampaign(campaign);
        expectedServiceCenter.setCuit(cuit);
        when(query.getSingleResult()).thenReturn(expectedServiceCenter);

        // @When finding the service center
        ServiceCenter serviceCenter = this.repository.findServiceCenterByCampaignIdAndCuit(campaign, cuit);

        // @Then the query is created
        assertThat(serviceCenter).isSameAs(expectedServiceCenter);
    }

    @Test
    public void testFindServiceCenterByCampaignIdAndCuit() {
        // @Given an existing service center corresponding to a campaign
        ServiceCenter expectedServiceCenter = new ServiceCenter();
        Campaign campaign = createCampaigns(1).get(0);
        campaign.setId(1);
        String cuit = "101010101";
        expectedServiceCenter.setCampaign(campaign);
        expectedServiceCenter.setCuit(cuit);
        when(query.getSingleResult()).thenReturn(expectedServiceCenter);


        // @When finding the service center
        ServiceCenter serviceCenter = this.repository.findServiceCenterByCampaignIdAndCuit(campaign, cuit);

        // @Then the service center is returned
        assertThat(serviceCenter.getCuit()).isEqualTo(cuit);
        assertThat(serviceCenter.getCampaign()).isNotNull();
        assertThat(serviceCenter.getCampaign().getId()).isEqualTo(campaign.getId());
    }

    @Test
    public void testNewCampaign() {
        // @Given valid campaign data
        final CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName("a name");
        campaignVO.setSince(newDate(2000, 1, 5));
        campaignVO.setUntil(newDate(2001, 4, 4));

        EntityManager entityManager = mock(EntityManager.class);
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);

        // @When a campaign is created from that data

        this.repository.newCampaign(campaignVO);

        // @The campaign is persisted by the entityManager
        verify(entityManager, times(1)).persist(argThat(new ArgumentMatcher<Campaign>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof Campaign &&
                        Objects.equal(((Campaign) argument).getName(), campaignVO.getName()) &&
                        Objects.equal(((Campaign) argument).getSince(), campaignVO.getSince()) &&
                        Objects.equal(((Campaign) argument).getUntil(), campaignVO.getUntil());
            }
        }));
    }

    @Test
    public void testRemoveCampaignCallsEntityManagerRemoveWithCampaign_WhenCampaignIsParameter() {
        // @Given a camapaign
        Campaign campaign = createCampaigns(1).get(0);
        Query nativeQuery = mock(Query.class);
        when(entityManager.createNativeQuery(anyString())).thenReturn(nativeQuery);

        // @When removing the campaign
        this.repository.removeCampaign(campaign);

        // @Then the campaign is removed from the entity manager
        verify(entityManager, times(1)).remove(campaign);
    }

    @Test
    public void testRemoveCampaignCreatesNativeQueryToRemoveServiceCentersOfCampaign1_WhenCampaign1IsParameter() {
        // @Given a camapaign
        Campaign campaign = createCampaigns(1).get(0);
        campaign.setId(1);
        Query nativeQuery = mock(Query.class);
        Query nativeQuery2 = mock(Query.class);
        when(entityManager.createNativeQuery(JpaCampaignRepository.DELETE_SERVICE_CENTERS_OF_CAMPAIGN_NATIVELY)).thenReturn(nativeQuery);
        when(entityManager.createNativeQuery(JpaCampaignRepository.DELETE_POINTS_OF_SALE_OF_CAMPAIGN_NATIVELY)).thenReturn(nativeQuery2);

        // @When removing the campaign
        this.repository.removeCampaign(campaign);

        // @Then the campaign is removed from the entity manager
        verify(entityManager, times(1)).createNativeQuery(JpaCampaignRepository.DELETE_SERVICE_CENTERS_OF_CAMPAIGN_NATIVELY);
        verify(nativeQuery, times(1)).setParameter(1, campaign.getId());
        verify(nativeQuery, times(1)).executeUpdate();
    }

    @Test
    public void testRemoveCampaignCreatesQueryToRemovePointsOfSaleOfCampaign1_WhenCampaign1IsParameter() {
        // @Given a camapaign
        Campaign campaign = createCampaigns(1).get(0);
        campaign.setId(1);
        Query nativeQuery = mock(Query.class);
        Query nativeQuery2 = mock(Query.class);
        when(entityManager.createNativeQuery(JpaCampaignRepository.DELETE_POINTS_OF_SALE_OF_CAMPAIGN_NATIVELY)).thenReturn(nativeQuery);
        when(entityManager.createNativeQuery(JpaCampaignRepository.DELETE_SERVICE_CENTERS_OF_CAMPAIGN_NATIVELY)).thenReturn(nativeQuery2);

        // @When removing the campaign
        this.repository.removeCampaign(campaign);

        // @Then the campaign is removed from the entity manager
        verify(entityManager, times(1)).createNativeQuery(JpaCampaignRepository.DELETE_POINTS_OF_SALE_OF_CAMPAIGN_NATIVELY);
        verify(nativeQuery, times(1)).setParameter(1, campaign.getId());
        verify(nativeQuery, times(1)).executeUpdate();
    }

    @Test
    public void testRemoveCampaignThrowsException_WhenCampaignHasChildren() {
        // @Given a camapaign with children
        Campaign campaign = createCampaigns(1).get(0);
        campaign.setId(10);
        Metric metric = new Metric(campaign, "name");
        metric.setId(78);
        campaign.setMetrics(Lists.<Metric>newArrayList(metric));
        campaign.setDataTables(Lists.<DataTable>newArrayList());

        // @When removing the campaign
        try {
            this.repository.removeCampaign(campaign);
            fail();
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.CANNOT_DELETE_CAMPAIGN_WITH_CHILDREN);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testRemoveCampaignThrowsException_WhenCampaignHasTables() {
        // @Given a camapaign with children
        Campaign campaign = createCampaigns(1).get(0);
        campaign.setId(10);
        Metric metric = new Metric(campaign, "name");
        metric.setId(78);
        campaign.setMetrics(Lists.<Metric>newArrayList(metric));
        DataTable dataTable = new DataTable();
        campaign.setDataTables(Lists.<DataTable>newArrayList(dataTable));

        // @When removing the campaign
        try {
            this.repository.removeCampaign(campaign);
            fail();
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.CANNOT_DELETE_CAMPAIGN_WITH_TABLES);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testGetCampaignParameterReturnsAll_WhenNoFilterIsSet() {
        Map<String, Object> filter = Maps.newHashMap();

        // @When getting all the parameters
        int pageSize = 20;
        int page = 1;
        this.repository.getParameters(page, pageSize, null, null, filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(CampaignParameterQuery.BASE_QUERY).toString().trim());
        verify(this.query, times(0)).setParameter(anyString(), anyString());
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testGetCampaignParameterReturnsList_WhenFilterByNameIsSet() {
        String filterByName = "filter.by.name";
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("name", filterByName);

        // @When getting all the parameters
        int pageSize = 20;
        int page = 1;
        this.repository.getParameters(page, pageSize, null, null, filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(CampaignParameterQuery.BASE_QUERY)
                .append(" WHERE p.name LIKE 'filter.by.name%'").toString().trim());
        verify(this.query, times(0)).setParameter(anyString(), anyString());
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testGetCampaignParameterReturnsList_WhenFilterByNameAndIdIsSet() {
        String filterByName = "filter.by.name";
        Integer id = 1;
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("id", id);
        filter.put("name", filterByName);

        // @When getting all the parameters
        int pageSize = 20;
        int page = 1;
        this.repository.getParameters(page, pageSize, "name", null, filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(CampaignParameterQuery.BASE_QUERY)
                .append(" WHERE p.id = :id AND p.name LIKE 'filter.by.name%' ORDER BY p.name ASC").toString().trim());
        verify(this.query, times(1)).setParameter("id", id);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testGetCampaignParameterReturnsList_WhenFilterByIdValueAndDescriptionIsSet() {
        Integer id = 1;
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("id", "1");
        filter.put("value", "hola@chau.com");
        filter.put("description", "un mail");

        // @When getting all the parameters
        int pageSize = 20;
        int page = 1;
        this.repository.getParameters(page, pageSize, "name", null, filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(CampaignParameterQuery.BASE_QUERY)
                .append(" WHERE p.id = :id AND p.description LIKE 'un mail%' AND p.value LIKE 'hola@chau.com%' ORDER BY p.name ASC").toString().trim());
        verify(this.query, times(1)).setParameter("id", id);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testGetCampaignParameterByIdReturnsOne_WhenFilterById() {
        Integer id = 1;

        // @When getting all the parameters
        this.repository.findParameterById(id);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).find(CampaignParameter.class, id);
    }

    @Test
    public void testGetCampaignParameterByIdCreatesQuery_WhenFilterByName() {
        // @When getting all the parameters
        this.repository.findParameterByName("Hi");

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(JpaCampaignRepository.FIND_PARAMETER_BY_NAME);
        verify(this.query, times(1)).setParameter("name", "Hi");
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testGetCampaignParameterByIdReturnsQueryResult_WhenFilterByName() {
        CampaignParameter parameter = new CampaignParameter();
        when(this.query.getSingleResult()).thenReturn(parameter);

        // @When getting all the parameters
        CampaignParameter parameterByName = this.repository.findParameterByName("Hi");

        // @Then a query is created matching the input
        assertThat(parameterByName).isSameAs(parameter);
    }

    @Test
    public void testUpdateCampaignParameterById_SetsDesiredFields() {
        // existing entity
        CampaignParameter existing = mock(CampaignParameter.class);

        // modified entity
        CampaignParameter parameter = new CampaignParameter();
        parameter.setId(1);
        parameter.setName("name.com.mod");
        parameter.setValue("value.com.mod");
        parameter.setDescription("description.com.mod");

        when(query.getResultList()).thenReturn(Lists.newArrayList(existing));

        // @When updating the entity
        this.repository.updateParameter(existing, parameter);

        verify(existing, times(0)).setName(parameter.getName());
        verify(existing, times(1)).setValue(parameter.getValue());
        verify(existing, times(1)).setDescription(parameter.getDescription());
    }

    @Test
    public void testGetTotalCampaignParametersReturns22_WhenQueryReturns22() {
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(22l);

        // @When counting the params configured
        long count = this.repository.getTotalParametersCount(filter);

        // @Then a count query is created
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(CampaignParameterQuery.COUNT_QUERY).toString().trim());
        assertThat(count).isEqualTo((Long) this.query.getSingleResult());
    }

    /**
     * Creates a lists of campaigns to use for test
     *
     * @param quantity
     * @return
     */
    public static List<Campaign> createCampaigns(int quantity) {
        List<Campaign> campaigns = Lists.newArrayList();

        for (int i = 0; i < quantity; i++) {
            campaigns.add(new Campaign("Campaign " + i, newDate(2012 + i - quantity, 4, 1), newDate(2013 + i - quantity, 3, 31)));

        }

        return campaigns;
    }

}
