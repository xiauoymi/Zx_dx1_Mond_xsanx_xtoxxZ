package com.monsanto.metricspos.persistence.unit;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.application.vo.EmployeeVO;
import com.monsanto.metricspos.core.application.vo.GroupVO;
import com.monsanto.metricspos.core.application.vo.MetricVO;
import com.monsanto.metricspos.core.application.vo.ServiceCenterVO;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.JpaEmployeeRepository;
import com.monsanto.metricspos.persistence.JpaRowValuesRepository;
import com.monsanto.metricspos.persistence.RowValuesServices;
import com.monsanto.metricspos.persistence.keys.EmployeeKey;
import com.monsanto.metricspos.persistence.queries.EmployeeQuery;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class JpaEmployeeRepository_UT {
    private EntityManager entityManager;
    private JpaEmployeeRepository repository;
    private Query query;
    private Campaign campaign;

    @Before
    public void setUp() {
        RowValuesServices jpaRowValuesServices = new JpaRowValuesRepository();

        field("entityManager").ofType(EntityManager.class).in(jpaRowValuesServices).set(entityManager);

        entityManager = mock(EntityManager.class);
        repository = new JpaEmployeeRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);

        query = mock(Query.class);
        when(entityManager.createQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), Matchers.any())).thenReturn(query);

        this.campaign = new Campaign("name", newDate(2014, 5, 8), newDate(2016, 7, 3));
        this.campaign.setId(1);
    }

    @Test
    public void testMarkEmployeesAsNotLoadedForCampaignCallsEntityManagerCreateQueryWithAnUpdateQueryThatSetsLoadedToTrueForPOSOfThisCampaign_WhenMarkingPointsOfSaleAsNotLoaded() {
        // @Given a campaign

        // @When marking all of it's employees as not loaded
        this.repository.markAllEmployeesAsNotLoadedInCampaign(this.campaign);

        // @The update query is created and campaign set as parameter
        verify(this.entityManager, times(1)).createQuery(JpaEmployeeRepository.MARK_AS_NOT_LOADED_FOR_CAMPAIGN);
        verify(this.query, times(1)).setParameter("campaign", this.campaign);
        verify(this.query, times(1)).executeUpdate();
    }

    @Test
    public void testMarkEmployeesAsNotLoadedForCampaignReturns12_WhenUpdatedRowsWere12() {
        // @Given a campaign
        when(this.query.executeUpdate()).thenReturn(12);

        // @When marking all of it's employees as not loaded
        long updated = this.repository.markAllEmployeesAsNotLoadedInCampaign(this.campaign);

        // @The update query is created and campaign set as parameter
        assertThat(updated).isEqualTo(this.query.executeUpdate());
    }

    @Test
    public void testMarkEmployeesAsNotLoadedForCampaignReturns587_WhenUpdatedRowsWere587() {
        // @Given a campaign
        when(this.query.executeUpdate()).thenReturn(587);

        // @When marking all of it's employees as not loaded
        long updated = this.repository.markAllEmployeesAsNotLoadedInCampaign(this.campaign);

        // @The update query is created and campaign set as parameter
        assertThat(updated).isEqualTo(this.query.executeUpdate());
    }

    @Test
    public void testSaveOrUpdate() {
        // @Given an employee
        Employee employee = new Employee();

        // @When saving or updating
        this.repository.saveOrUpdate(employee);

        // @Then entityManager.merge is called with that pos
        verify(this.entityManager, times(1)).merge(employee);
    }

    @Test
    public void testRemoveUnloadedPointsOfSaleForCampaign() {
        // @Given a campaign

        // @When removing not loaded for campaign
        this.repository.removeAllNotLoadedEmployees(this.campaign);

        // @Then the delete query is created, the campaign set as a parameter and the query executed
        verify(this.entityManager, times(1)).createQuery(JpaEmployeeRepository.REMOVE_NOT_LOADED_FOR_CAMPAIGN);
        verify(this.query, times(1)).setParameter("campaign", this.campaign);
        verify(this.query, times(1)).executeUpdate();
    }

    @Test
    public void testListEmployeesForCampaignAndPageCreatesAQueryWithParameterCampaignLimitAndOffset_WhenListingEmployeesForCampaignAndPage() {
        // @Given a campaign and paging parameters
        Map<String, Object> filter = Maps.newHashMap();

        // @When listing employees matching
        this.repository.listEmployeesForCampaignAndPage(this.campaign, Lists.<Group>newArrayList(), 1, 25, "name", "ASC", filter);

        // @Then a query is created with max and first result and a campaign as a parameter
        verify(this.entityManager, times(1)).createQuery(EmployeeQuery.FIND_EMPLOYEES_BY_CAMPAIGN + " ORDER BY employee.name ASC");
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setMaxResults(25);
        verify(this.query, times(1)).setFirstResult(0);
    }

    @Test
    public void testListEmployeesForCampaignAndPageCreatesAQueryThatFiltersByIdNameUsernameAndEnabled_WhenListingEmployeesForCampaignAndPageWithFilterByIdNameUsernameAndEnabled() {
        // @Given a campaign and paging parameters
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("id", 1);
        filter.put("enabled", true);
        filter.put("name", "hi");
        filter.put("username", "bye");

        // @When listing employees matching
        this.repository.listEmployeesForCampaignAndPage(this.campaign, Lists.<Group>newArrayList(), 1, 25, "name", "ASC", filter);

        // @Then a query is created with max and first result and a campaign as a parameter
        verify(this.entityManager, times(1)).createQuery(EmployeeQuery.FIND_EMPLOYEES_BY_CAMPAIGN + " AND employee.id = :id AND employee.enabled = :enabled AND employee.username = :username AND employee.name = :name ORDER BY employee.name ASC");
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setMaxResults(25);
        verify(this.query, times(1)).setFirstResult(0);
    }

    @Test
    public void testListEmployeesForCampaignAndPageCreatesAQueryThatFiltersByGroupName_WhenListingEmployeesForCampaignAndPageWithFilterByGroupName() {
        // @Given a campaign and paging parameters
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("GroupName", "true");
        Group group = new Group();
        group.setName("GroupName");

        // @When listing employees matching
        this.repository.listEmployeesForCampaignAndPage(this.campaign, Lists.<Group>newArrayList(group), 1, 25, "name", "ASC", filter);

        // @Then a query is created with max and first result and a campaign as a parameter
        verify(this.entityManager, times(1)).createQuery(EmployeeQuery.FIND_EMPLOYEES_BY_CAMPAIGN + " AND :groupname MEMBER OF employee.groups ORDER BY employee.name ASC");
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter("groupname", group);
        verify(this.query, times(1)).setMaxResults(25);
        verify(this.query, times(1)).setFirstResult(0);
    }

    @Test
    public void testListEmployeesForCampaignAndPageCreatesAQueryThatFiltersByExcludingGroupName_WhenListingEmployeesForCampaignAndPageWithFilterByExcludingGroupName() {
        // @Given a campaign and paging parameters
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("GroupName", "false");
        Group group = new Group();
        group.setName("GroupName");

        // @When listing employees matching
        this.repository.listEmployeesForCampaignAndPage(this.campaign, Lists.<Group>newArrayList(group), 1, 25, "name", "ASC", filter);

        // @Then a query is created with max and first result and a campaign as a parameter
        verify(this.entityManager, times(1)).createQuery(EmployeeQuery.FIND_EMPLOYEES_BY_CAMPAIGN + " AND :groupname NOT MEMBER OF employee.groups ORDER BY employee.name ASC");
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter("groupname", group);
        verify(this.query, times(1)).setMaxResults(25);
        verify(this.query, times(1)).setFirstResult(0);
    }

    @Test
    public void testCountEmployeesForCampaignCreatesAQueryWithParameterCampaign_WhenCountingEmployeesForCampaign() {
        // @Given a campaign and paging parameters
        Map<String, Object> filter = Maps.newHashMap();
        when(query.getSingleResult()).thenReturn(2l);

        // @When listing employees matching
        this.repository.countEmployeesForCampaign(filter, this.campaign, Lists.<Group>newArrayList());

        // @Then a query is created with max and first result and a campaign as a parameter
        verify(this.entityManager, times(1)).createQuery(EmployeeQuery.COUNT_EMPLOYEES_BY_CAMPAIGN);
        verify(this.query, times(1)).setParameter("campaign", campaign);
    }

    @Test
    public void testCountEmployeesForCampaignCreatesAQueryThatFiltersByIdNameUsernameAndEnabled_WhenCountingEmployeesForCampaignWithFilterByIdNameUsernameAndEnabled() {
        // @Given a campaign and paging parameters
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("id", 1);
        filter.put("enabled", true);
        filter.put("name", "hi");
        filter.put("username", "bye");
        when(query.getSingleResult()).thenReturn(2l);

        // @When listing employees matching
        this.repository.countEmployeesForCampaign(filter, this.campaign, Lists.<Group>newArrayList());

        // @Then a query is created with max and first result and a campaign as a parameter
        verify(this.entityManager, times(1)).createQuery(EmployeeQuery.COUNT_EMPLOYEES_BY_CAMPAIGN + " AND employee.id = :id AND employee.enabled = :enabled AND employee.username = :username AND employee.name = :name");
        verify(this.query, times(1)).setParameter("campaign", campaign);
    }

    @Test
    public void testCountEmployeesForCampaignCreatesAQueryThatFiltersByGroupName_WhenCountingEmployeesForCampaignWithFilterByGroupName() {
        // @Given a campaign and paging parameters
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("GroupName", "true");
        Group group = new Group();
        group.setName("GroupName");
        when(query.getSingleResult()).thenReturn(2l);

        // @When listing employees matching
        this.repository.countEmployeesForCampaign(filter, this.campaign, Lists.<Group>newArrayList(group));

        // @Then a query is created with max and first result and a campaign as a parameter
        verify(this.entityManager, times(1)).createQuery(EmployeeQuery.COUNT_EMPLOYEES_BY_CAMPAIGN + " AND :groupname MEMBER OF employee.groups");
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter("groupname", group);
    }


    @Test
    public void testCountEmployeesForCampaignCreatesAQueryThatFiltersByExcludingGroupName_WhenCountingEmployeesForCampaignWithFilterByExcludingGroupName() {
        // @Given a campaign and paging parameters
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("GroupName", "false");
        Group group = new Group();
        group.setName("GroupName");
        when(query.getSingleResult()).thenReturn(2l);

        // @When listing employees matching
        this.repository.countEmployeesForCampaign(filter, this.campaign, Lists.<Group>newArrayList(group));

        // @Then a query is created with max and first result and a campaign as a parameter
        verify(this.entityManager, times(1)).createQuery(EmployeeQuery.COUNT_EMPLOYEES_BY_CAMPAIGN + " AND :groupname NOT MEMBER OF employee.groups");
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter("groupname", group);
    }

    @Test
    public void testListEmployeesFromCampaignCreatesQueryWithCampaignAsParameterAndExecutesIt_WhenFindingEmployeesForCampaign() {
        // @Given a campaign

        // @When finding it's employees
        this.repository.listEmployeesForCampaign(this.campaign);

        // @The a query is created with the campaign as a parameter and then the query is executed
        verify(this.entityManager, times(1)).createQuery("Select employee from Employee employee where employee.campaign = :campaign ORDER BY employee.name ASC");
        verify(query, times(1)).setParameter("campaign", campaign);
        verify(query, times(1)).getResultList();
    }

    @Test
    public void testListEmployeesFromCampaignReturnsQueryResult_WhenFindingEmployeesForCampaign() {
        // @Given a campaign
        List employeeList = Lists.newArrayList();
        when(this.query.getResultList()).thenReturn(employeeList);

        // @When finding it's employees
        List<Employee> employees = this.repository.listEmployeesForCampaign(this.campaign);

        // @Then the query result is returned
        assertThat(employees).isSameAs(this.query.getResultList());
    }

    @Test
    public void testFindEmployeeByIdAndCampaignCallsEntityManagerFindWithMatchingKey_WhenFindingEmployee1OfCampaign() {
        // @Given a campaign and an employee id 1
        final long employeeId = 1l;

        // @When finding the employee
        this.repository.findEmployeeByIdAndCampaign(employeeId, this.campaign);

        // @Then entityManager.find is called with matching id
        verify(this.entityManager, times(1)).find(eq(Employee.class), Matchers.<Object>any());
    }

    @Test
    public void testFindEmployeeByUsernameCreatesQueryWithUsernameAsParameterAndExecutesIt_WhenFindingEmployeeByUsername() {
        // @Given a username
        String username = "username";

        // @When finding matching employees
        this.repository.findEmployeesByUsername(username);

        // @Then a query is created with it's parameters and it's executed
        verify(this.entityManager, times(1)).createQuery(JpaEmployeeRepository.FIND_EMPLOYEES_BY_USERNAME);
        verify(this.query, times(1)).setParameter("username", username);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindEmployeeByUsernameReturnsQueryResult_WhenFindingEmployeeByUsername() {
        // @Given a username
        String username = "username";
        List<Employee> expected = Lists.newArrayList();
        when(this.query.getResultList()).thenReturn(expected);

        // @When finding matching employees
        List<Employee> result = this.repository.findEmployeesByUsername(username);

        // @Then a query is created with it's parameters and it's executed
        assertThat(result).isSameAs(expected);
    }

    @Test
    public void testNewEmployeeCallsEntitiyManagerPersistWithMAtchingNewEmployee_WhenCreatingAnEmployeeFromAVO() {
        // @Given an employeeVO and a campaign
        final EmployeeVO employeeVO = new EmployeeVO();
        employeeVO.setUsername("auser");
        employeeVO.setName("Alfred User");
        GroupVO groupVO = new GroupVO();
        groupVO.setId(1);
        employeeVO.setGroups(Lists.<GroupVO>newArrayList(groupVO));
        MetricVO metricVO = new MetricVO();
        metricVO.setId(1);
        employeeVO.setMetrics(Lists.<MetricVO>newArrayList(metricVO));
        ServiceCenterVO serviceCenterVO = new ServiceCenterVO();
        serviceCenterVO.setCuit("10");
        employeeVO.setServiceCenters(Lists.<ServiceCenterVO>newArrayList(serviceCenterVO));
        final Campaign campaign = new Campaign("campaignName", newDate(2015, 8, 8), newDate(2016, 5, 5));
        campaign.setId(1);
        Metric metric = new Metric(campaign, "Hi");
        metric.setId(1);
        campaign.setMetrics(Lists.<Metric>newArrayList(metric));
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        campaign.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        Group group = new Group();
        group.setId(1);
        List<Group> groups = Lists.newArrayList(group);
        when(this.query.getSingleResult()).thenReturn(1l);
        List<Metric> metrics = Lists.newArrayList();

        // @When creating a new employee
        this.repository.newEmployee(employeeVO, campaign, groups, metrics);

        // @Then entityManager persist is called with matching employee
        verify(this.entityManager, times(1)).persist(argThat(new ArgumentMatcher<Object>() {
            @Override
            public boolean matches(Object argument) {
                if (argument instanceof Employee) {
                    Employee employee = (Employee) argument;

                    return employee.getCampaign().equals(campaign) &&
                            employee.getUsername().equals(employeeVO.getUsername()) &&
                            employee.getName().equals(employeeVO.getName()) &&
                            ((employee.getGroups() == null && employeeVO.getGroups() == null) || employee.getGroups().size() == employeeVO.getGroups().size()) &&
                            ((employee.getMetrics() == null && employeeVO.getMetrics() == null) || employee.getMetrics().size() == employeeVO.getMetrics().size()) &&
                            ((employee.getServiceCenters() == null && employeeVO.getServiceCenters() == null) || employee.getServiceCenters().size() == employeeVO.getServiceCenters().size());
                }
                return false;

            }
        }));
    }

    @Test
    public void testUpdateEmployee1OfCampaign1CallsEntityManagerFind_WhenUpdatingAnEmployee1FromAVO() {
        // @Given an employeeVO, metrics and a campaign
        final EmployeeVO employeeVO = new EmployeeVO();
        employeeVO.setId(1l);
        Employee employee = new Employee();
        when(this.entityManager.find(eq(Employee.class), Matchers.<Object>any())).thenReturn(employee);
        List<Metric> metrics = Lists.newArrayList();

        // @When updating an employee
        this.repository.updateEmployee(employeeVO, campaign, metrics);

        // @Then entity manager find is called with a matching key
        verify(this.entityManager, times(1)).find(eq(Employee.class), argThat(new ArgumentMatcher<Object>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof EmployeeKey &&
                        field("campaign").ofType(Campaign.class).in(argument).get() == campaign;
            }
        }));
    }

    @Test
    public void testUpdateEmployeeSetsAllParametersAsVos_WhenCreatingAnEmployeeFromAVO() {
        // @Given an employeeVO and a campaign
        final EmployeeVO employeeVO = new EmployeeVO();
        employeeVO.setId(1l);
        employeeVO.setUsername("auser");
        employeeVO.setName("Alfred User");
        GroupVO groupVO = new GroupVO();
        groupVO.setId(1);
        employeeVO.setGroups(Lists.<GroupVO>newArrayList(groupVO));
        MetricVO metricVO = new MetricVO();
        metricVO.setId(1);
        employeeVO.setMetrics(Lists.<MetricVO>newArrayList(metricVO));
        ServiceCenterVO serviceCenterVO = new ServiceCenterVO();
        serviceCenterVO.setCuit("10");
        employeeVO.setServiceCenters(Lists.<ServiceCenterVO>newArrayList(serviceCenterVO));
        final Campaign campaign = new Campaign("campaignName", newDate(2015, 8, 8), newDate(2016, 5, 5));
        campaign.setId(1);
        employeeVO.setCampaignId(campaign.getId());
        Metric metric = new Metric(campaign, "Hi");
        metric.setId(1);
        campaign.setMetrics(Lists.<Metric>newArrayList(metric));
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        campaign.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        Group group = new Group();
        group.setId(1);
        List<Group> groups = Lists.newArrayList(group);
        when(this.query.getSingleResult()).thenReturn(1l);
        List<Metric> metrics = Lists.newArrayList();

        Employee employee = new Employee();
        employee.setId(employeeVO.getId());
        employee.setCampaign(campaign);
        when(this.entityManager.find(eq(Employee.class), Matchers.<Object>any())).thenReturn(employee);

        // @When updating employee with that vo
        this.repository.updateEmployee(employeeVO, campaign, metrics);

        // @Then all parameters are set from the VO
        assertThat(employee.getId()).isEqualTo(employeeVO.getId());
        assertThat(employee.getCampaign().getId()).isEqualTo(employeeVO.getCampaignId());
        assertThat(employee.getMetrics().size()).isEqualTo(employeeVO.getMetrics().size());
        assertThat(employee.getServiceCenters().size()).isEqualTo(employeeVO.getServiceCenters().size());
        assertThat(employee.getName()).isEqualTo(employeeVO.getName());
        assertThat(employee.getUsername()).isEqualTo(employeeVO.getUsername());
    }
}
