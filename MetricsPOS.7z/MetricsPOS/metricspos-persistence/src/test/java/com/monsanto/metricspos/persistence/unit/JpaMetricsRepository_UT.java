package com.monsanto.metricspos.persistence.unit;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.application.vo.MetricVO;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricFactory;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import com.monsanto.metricspos.persistence.JpaMetricsRepository;
import com.monsanto.metricspos.persistence.keys.EmployeeKey;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import java.util.List;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class JpaMetricsRepository_UT {
    private JpaMetricsRepository repository;
    private Query query;
    private EntityManager entityManager;
    private SecurityHolderStrategy securityHolderStrategy;

    @Before
    public void setUp() {
        entityManager = mock(EntityManager.class);
        query = mock(Query.class);
        when(entityManager.createQuery(anyString())).thenReturn(query);

        repository = new JpaMetricsRepository();
        securityHolderStrategy = mock(SecurityHolderStrategy.class);
        when(securityHolderStrategy.getCurrentUser()).thenReturn(new AdminUser());
        field("securityHolderStrategy").ofType(SecurityHolderStrategy.class).in(repository).set(securityHolderStrategy);
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);
    }

    @Test
    public void testGetMetricsNone() throws Exception {
        // @Given A repository without metrics
        List<Metric> expectedMetrics = createMetrics(0);

        buildRepository(expectedMetrics);

        // @When Get all metrics
        List<Metric> metrics = repository.listAllMetrics();

        // @Then get an empty list
        assertThat(metrics).isNotNull().hasSize(0);
    }

    @Test
    public void testGetMetricsMany() throws Exception {
        // @Given A repository with some metrics
        List<Metric> expectedMetrics = createMetrics(3);

        buildRepository(expectedMetrics);

        // @When Get all metrics
        List<Metric> metrics = repository.listAllMetrics();

        // @Then get a list with the metrics ordered by start date
        assertThat(metrics).isNotNull().hasSize(3).isEqualTo(expectedMetrics);

    }

    @Test
    public void testFindMetricById() {
        // @Given an existing metric
        Metric metric = createMetrics(1).get(0);

        buildRepository(metric);

        // @When finding it by Id
        Metric metricById = repository.findMetricById(metric.getId());

        // @Then the metric with the provided id is returned
        assertThat(metricById).isEqualTo(metric);
    }

    @Test
    public void testFindMetricByIdThrowsException_WhenNoResultIsFound() {
        // @Given an existing metric
        when(query.getSingleResult()).thenThrow(new NoResultException());

        // @When finding it by Id
        try {
            repository.findMetricById(1);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_NOT_FOUND + "[Metric(" + 1 + ")]");
        } catch (Throwable t) {
            fail();
        }

    }

    @Test
    public void testDeleteMetric() {
        // @Given a metric and a repository with an entityManager
        Metric metric = createMetrics(1).get(0);

        EntityManager entityManager = mock(EntityManager.class);
        repository = new JpaMetricsRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);

        // @When deleting the metric
        repository.delete(metric);

        // @Then the metric is persisted with the entityManager
        verify(entityManager, times(1)).remove(metric);
    }

    @Test
    public void testDeleteMetricWithChildren() {
        // @Given a metric with one children and a repository with an entityManager
        Metric metric = createMetrics(1).get(0);
        metric.addMetricDefinition("child", 120);

        EntityManager entityManager = mock(EntityManager.class);
        repository = new JpaMetricsRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);

        // @When deleting the metric
        try {
            repository.delete(metric);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_CANNOT_DELETE_METRIC_WITH_CHILDREN);
            verify(entityManager, never()).remove(metric);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testNewMetricDefinition() {
        // @Given an existing campaign
        EntityManager entityManager = mock(EntityManager.class);
        repository = new JpaMetricsRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);

        Campaign campaign = new Campaign("campaign name", newDate(2011, 1, 1), newDate(2012, 2, 2));

        // @When creating a metric
        Metric metric = this.repository.newMetricDefinition(campaign, "metricName", 200);

        // @Then the metric is created
        assertThat(metric.getName()).isEqualTo("metricName");
        verify(entityManager, times(1)).persist(argThat(new ArgumentMatcher<Metric>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof Metric && ((Metric) argument).getName().equals("metricName");
            }
        }));
    }

    @Test
    public void testUpdateMetricReturnsMetricAsItWas_WhenValueIsNull() throws Exception {
        // @Given an existing metric
        Metric metric = mock(Metric.class);

        MetricVO metricVO = new MetricVO();
        metricVO.setId(1);
        metricVO.setEnabled(null);

        // @When no new value is provided for enabled
        this.repository.updateMetric(metric, metricVO);

        // @Then the value is NOT changed
        verify(metric, times(0)).setEnabled(anyBoolean());
    }

    @Test
    public void testUpdateMetricReturnsMatchingMetricDisabled_WhenDisablingPreviouslyDisabledMetric() throws Exception {
        // @Given an existing metric
        Metric metric = mock(Metric.class);

        MetricVO metricVO = new MetricVO();
        metricVO.setId(1);
        metricVO.setEnabled(false);

        // @When a new value for enabled
        this.repository.updateMetric(metric, metricVO);

        // @Then the value is changed
        verify(metric, times(1)).setEnabled(false);
    }

    @Test
    public void testUpdateMetricReturnsMetricWithChangedFormula_WhenUpdatingItToThatDifferentValue() {
        // @Given a metric with a formula
        Metric metric = mock(Metric.class);

        MetricVO metricVO = new MetricVO();
        metricVO.setId(1);
        metricVO.setFormula("new formula");

        // @When updating the metric formula
        this.repository.updateMetric(metric, metricVO);

        // @Then the formula is updated
        verify(metric, times(1)).setFormula(anyString());
    }

    @Test
    public void testUpdateMetricSetsAllFields_WhenUpdatingMetric() {
        // @Given a metric with a formula
        Metric metric = mock(Metric.class);

        MetricVO metricVO = new MetricVO();
        metricVO.setId(1);
        metricVO.setMaxPoints(123);
        metricVO.setName("ANameeee");
        metricVO.setFormula("new formula");
        metricVO.setExplanation("Explanation1.");
        metricVO.setEnabled(true);
        metricVO.setScheduled(true);

        // @When updating the metric formula
        this.repository.updateMetric(metric, metricVO);

        // @Then the formula is updated
        verify(metric, times(1)).setEnabled(metricVO.isEnabled());
        verify(metric, times(1)).setFormula(metricVO.getFormula());
        verify(metric, times(1)).setMaxPoints(metricVO.getMaxPoints());
        verify(metric, times(1)).setName(metricVO.getName());
        verify(metric, times(1)).setScheduled(metricVO.isScheduled());
        verify(metric, times(1)).setExplanation(metricVO.getExplanation());
    }

    @Test
    public void testUpdateMetricTablesSetsInputVoTablesAsCurrentTables_WhenUpdatingMetricTables() {
        // @Given a metric and updated tables information
        Campaign campaign = new Campaign("campaign name", newDate(2011, 1, 1), newDate(2012, 2, 2));
        Metric metric = new Metric(campaign, "hi");
        metric.setTables(Lists.<DataTable>newArrayList());

        MetricVO metricVO = new MetricVO();
        metricVO.setId(1);
        metricVO.setMaxPoints(123);
        metricVO.setName("ANameeee");
        metricVO.setFormula("new formula");
        metricVO.setEnabled(true);
        metricVO.setScheduled(false);
        metricVO.setExplanation("Explanation1.");
        DataTableVO dataTable1VO = new DataTableVO();
        dataTable1VO.setId(1);
        metricVO.setTables(Lists.<DataTableVO>newArrayList(dataTable1VO));
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataTable dataTable1 = new DataTable("table1", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        dataTable1.setId(1);
        DataTable dataTable2 = new DataTable("table1", Lists.<DataColumn>newArrayList(), dataRowPersistorFactory);
        dataTable2.setId(2);
        List<DataTable> tables = Lists.newArrayList(dataTable1, dataTable2);

        // @When updating the metric's tables
        this.repository.updateMetric(metric, tables, metricVO);

        // @Then matching tables are set
        assertThat(metric.getTables()).containsExactly(dataTable1);

    }

    @Test
    public void testListMetricsByCampaignCreatesAQueryAndSetsCampaignAsParameter_WhenListingMetricsForACampaign() {
        // @Given a campaign
        Campaign campaign = new Campaign("campaign name", newDate(2011, 1, 1), newDate(2012, 2, 2));

        // @When listing it's metrics
        this.repository.listSubmetricsByCampaign(campaign);

        // @Then a query is created, the campaign is set as a parameter and the query is executed
        verify(this.entityManager, times(1)).createQuery(JpaMetricsRepository.METRICS_BY_CAMPAIGN);
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testListMetricsByCampaignLoggedAsAnEmployeeFindsEmployee_WhenListingMetricsForACampaign() {
        // @Given a campaign
        Campaign campaign = new Campaign("campaign name", newDate(2011, 1, 1), newDate(2012, 2, 2));
        Employee employee = new Employee();
        employee.setId(1l);
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);
        when(this.entityManager.find(eq(Employee.class), Matchers.<Object>any())).thenReturn(employee);

        // @When listing it's metrics
        this.repository.listSubmetricsByCampaign(campaign);

        // @Then a query is created, the campaign is set as a parameter and the query is executed
        verify(this.entityManager, times(1)).find(eq(Employee.class), Matchers.<EmployeeKey>any());
    }

    @Test
    public void testListMetricsByCampaignLoggedAsAnEmployeeReturnsEmployeeMetrics_WhenListingMetricsForACampaign() {
        // @Given a campaign
        Campaign campaign = new Campaign("campaign name", newDate(2011, 1, 1), newDate(2012, 2, 2));
        Employee employee = new Employee();
        employee.setId(1l);
        employee.setMetrics(Lists.<Metric>newArrayList());
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);
        when(this.entityManager.find(eq(Employee.class), Matchers.<Object>any())).thenReturn(employee);

        // @When listing it's metrics
        List<Metric> metrics = this.repository.listSubmetricsByCampaign(campaign);

        // @Then a query is created, the campaign is set as a parameter and the query is executed
        assertThat(metrics).isSameAs(employee.getMetrics());
    }

    @Test
    public void testListMetricsByCampaignReturnsQueryResult_WhenListingMetricsForACampaign() {
        // @Given a campaign
        Campaign campaign = new Campaign("campaign name", newDate(2011, 1, 1), newDate(2012, 2, 2));
        List<Object> result = Lists.newArrayList();
        when(this.query.getResultList()).thenReturn(result);

        // @When listing it's metrics
        List<Metric> metrics = this.repository.listSubmetricsByCampaign(campaign);

        // @Then the query result is returns
        assertThat(metrics).isSameAs(this.query.getResultList());

    }

    @Test
    public void testMarkMetricScoresByServiceCenterSetsMetricsScoresAsDirtyTrueWhenServiceCenterMatches() {
        // @Given a metric with 4 service centers with 2 not dirty scores each
        Campaign campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 1, 1));
        Metric metric = new Metric(campaign, "name");
        ServiceCenter serviceCenter1 = new ServiceCenter();
        serviceCenter1.setCuit("1");
        ServiceCenter serviceCenter2 = new ServiceCenter();
        serviceCenter2.setCuit("2");
        ServiceCenter serviceCenter3 = new ServiceCenter();
        serviceCenter3.setCuit("3");
        ServiceCenter serviceCenter4 = new ServiceCenter();
        serviceCenter4.setCuit("4");
        MetricScore score1 = new MetricScore(metric, serviceCenter1);
        MetricScore score2 = new MetricScore(metric, serviceCenter2);
        MetricScore score3 = new MetricScore(metric, serviceCenter3);
        MetricScore score4 = new MetricScore(metric, serviceCenter4);
        metric.setScores(Sets.<MetricScore>newHashSet(score1, score2, score3, score4));

        // @When marking scores of that metric and one of the service centers as dirty true
        this.repository.markMetricScoresDirtinessByServiceCenter(metric, serviceCenter1, true);

        // @Then the scores of that service center are set to dirty true
        assertThat(score1.isDirty()).isTrue();
        assertThat(score2.isDirty()).isFalse();
        assertThat(score3.isDirty()).isFalse();
        assertThat(score4.isDirty()).isFalse();
    }

    private void buildRepository(List<Metric> expectedMetrics) {
        EntityManager entityManager = mock(EntityManager.class);
        Query query = mock(Query.class);
        when(entityManager.createQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(expectedMetrics);

        repository = new JpaMetricsRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);
    }

    private void buildRepository(Metric expectedMetric) {
        EntityManager entityManager = mock(EntityManager.class);
        Query query = mock(Query.class);
        when(entityManager.createQuery(anyString())).thenReturn(query);
        when(query.getSingleResult()).thenReturn(expectedMetric);

        repository = new JpaMetricsRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);
    }

    /**
     * Creates a lists of metrics to use for test
     *
     * @param quantity
     * @return
     */
    private static List<Metric> createMetrics(int quantity) {
        Campaign campaign = new Campaign("camapaignName", newDate(2011, 1, 1), newDate(2012, 1, 1));
        campaign.setFactory(new MetricFactory() {
            int i = 1;

            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                Metric metric = new Metric(campaign, name);
                metric.setId(i++);
                return metric;
            }
        });
        List<Metric> metrics = Lists.newArrayList();

        for (int i = 0; i < quantity; i++) {
            metrics.add(campaign.addMetricDefinition("metric" + i, 130));
        }

        return metrics;
    }
}
