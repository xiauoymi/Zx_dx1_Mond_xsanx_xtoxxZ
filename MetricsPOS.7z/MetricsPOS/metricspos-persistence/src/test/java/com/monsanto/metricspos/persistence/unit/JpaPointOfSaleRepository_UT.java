package com.monsanto.metricspos.persistence.unit;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.JpaPointOfSaleRepository;
import com.monsanto.metricspos.persistence.JpaRowValuesRepository;
import com.monsanto.metricspos.persistence.RowValues;
import com.monsanto.metricspos.persistence.RowValuesServices;
import com.monsanto.metricspos.persistence.keys.EmployeeKey;
import com.monsanto.metricspos.persistence.keys.PointOfSaleKey;
import com.monsanto.metricspos.persistence.queries.PointOfSaleQuery;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class JpaPointOfSaleRepository_UT {
    private EntityManager entityManager;
    private JpaPointOfSaleRepository repository;
    private Query query;
    private Campaign campaign;
    private SecurityHolderStrategy securityHolderStrategy;

    @Before
    public void setUp() {
        RowValuesServices jpaRowValuesServices = new JpaRowValuesRepository();

        field("entityManager").ofType(EntityManager.class).in(jpaRowValuesServices).set(entityManager);

        entityManager = mock(EntityManager.class);
        repository = new JpaPointOfSaleRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);

        securityHolderStrategy = mock(SecurityHolderStrategy.class);
        when(securityHolderStrategy.getCurrentUser()).thenReturn(new AdminUser());
        field("securityHolderStrategy").ofType(SecurityHolderStrategy.class).in(repository).set(securityHolderStrategy);


        query = mock(Query.class);
        when(entityManager.createQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), Matchers.any())).thenReturn(query);

        this.campaign = new Campaign("name", newDate(2014, 5, 8), newDate(2016, 7, 3));
        this.campaign.setId(1);
    }

    @Test
    public void testMarkPointsOfSalesAsNotLoadedForCampaignCallsEntityManagerCreateQueryWithAnUpdateQueryThatSetsLoadedToTrueForPOSOfThisCampaign_WhenMarkingPointsOfSaleAsNotLoaded() {
        // @Given a campaign

        // @When marking all of it's points of sales as not loaded
        this.repository.markPointsOfSalesAsNotLoadedForCampaign(this.campaign);

        // @The update query is created and campaign set as parameter
        verify(this.entityManager, times(1)).createQuery(JpaPointOfSaleRepository.MARK_AS_NOT_LOADED_FOR_CAMPAIGN);
        verify(this.query, times(1)).setParameter("campaign", this.campaign);
        verify(this.query, times(1)).executeUpdate();
    }

    @Test
    public void testMarkPointsOfSalesAsNotLoadedForCampaignReturns12_WhenUpdatedRowsWere12() {
        // @Given a campaign
        when(this.query.executeUpdate()).thenReturn(12);

        // @When marking all of it's points of sales as not loaded
        long updated = this.repository.markPointsOfSalesAsNotLoadedForCampaign(this.campaign);

        // @The update query is created and campaign set as parameter
        assertThat(updated).isEqualTo(this.query.executeUpdate());
    }

    @Test
    public void testMarkPointsOfSalesAsNotLoadedForCampaignReturns587_WhenUpdatedRowsWere587() {
        // @Given a campaign
        when(this.query.executeUpdate()).thenReturn(587);

        // @When marking all of it's points of sales as not loaded
        long updated = this.repository.markPointsOfSalesAsNotLoadedForCampaign(this.campaign);

        // @The update query is created and campaign set as parameter
        assertThat(updated).isEqualTo(this.query.executeUpdate());
    }

    @Test
    public void testSaveOrUpdateCallsPersist_WhenPointOfSaleIsNew() {
        // @Given a point of sale
        Query countQuery = mock(Query.class);
        Query changeServiceCenterQuery = mock(Query.class);
        Query findPosQuery = mock(Query.class);
        when(entityManager.createQuery(JpaPointOfSaleRepository.COUNT_PREVIOUSLY_EXISTING_POS_WITH_SAME_ID_SAP_AND_REFERING_TO_A_DELETED_SC)).thenReturn(countQuery);
        when(entityManager.createNativeQuery(JpaPointOfSaleRepository.UPDATE_SERVICE_CENTER_NATIVELY)).thenReturn(changeServiceCenterQuery);
        when(entityManager.createQuery(JpaPointOfSaleRepository.FIND_POS_WETHER_DELETED_OR_NOT)).thenReturn(findPosQuery);
        when(countQuery.getSingleResult()).thenReturn(0l);
        when(findPosQuery.getSingleResult()).thenReturn(null);
        PointOfSale pointOfSale = new PointOfSale();

        // @When saving or updating
        this.repository.saveOrUpdate(pointOfSale);

        // @Then entityManager.persist is called with that pos
        verify(this.entityManager, times(1)).persist(pointOfSale);
    }

    @Test
    public void testSaveOrUpdateDoesNotCallPersist_WhenPointOfSaleIsNotNewAndNotDeleted() {
        // @Given a point of sale
        Query countQuery = mock(Query.class);
        Query changeServiceCenterQuery = mock(Query.class);
        PointOfSale existingPos = mock(PointOfSale.class);
        Query findPosQuery = mock(Query.class);
        when(entityManager.createQuery(JpaPointOfSaleRepository.COUNT_PREVIOUSLY_EXISTING_POS_WITH_SAME_ID_SAP_AND_REFERING_TO_A_DELETED_SC)).thenReturn(countQuery);
        when(entityManager.createNativeQuery(JpaPointOfSaleRepository.UPDATE_SERVICE_CENTER_NATIVELY)).thenReturn(changeServiceCenterQuery);
        when(entityManager.createQuery(JpaPointOfSaleRepository.FIND_POS_WETHER_DELETED_OR_NOT)).thenReturn(findPosQuery);
        when(countQuery.getSingleResult()).thenReturn(0l);
        when(findPosQuery.getSingleResult()).thenReturn(existingPos);
        PointOfSale pointOfSale = new PointOfSale();

        // @When saving or updating
        this.repository.saveOrUpdate(pointOfSale);

        // @Then entityManager.persist is called with that pos
        verify(this.entityManager, times(0)).persist(pointOfSale);
        verify(existingPos, times(1)).setAddress(Matchers.<String>any());
    }

    @Test
    public void testSaveOrUpdateChangesServiceCenterNatively_WhenPointOfSaleIsNotNewButServiceCenterWasChanged() {
        // @Given a point of sale
        Query countQuery = mock(Query.class);
        Query changeServiceCenterQuery = mock(Query.class);
        PointOfSale existingPos = mock(PointOfSale.class);
        Query findPosQuery = mock(Query.class);
        when(entityManager.createQuery(JpaPointOfSaleRepository.COUNT_PREVIOUSLY_EXISTING_POS_WITH_SAME_ID_SAP_AND_REFERING_TO_A_DELETED_SC)).thenReturn(countQuery);
        when(entityManager.createNativeQuery(JpaPointOfSaleRepository.UPDATE_SERVICE_CENTER_NATIVELY)).thenReturn(changeServiceCenterQuery);
        when(entityManager.createQuery(JpaPointOfSaleRepository.FIND_POS_WETHER_DELETED_OR_NOT)).thenReturn(findPosQuery);
        when(countQuery.getSingleResult()).thenReturn(1l);
        when(findPosQuery.getSingleResult()).thenReturn(existingPos);
        PointOfSale pointOfSale = new PointOfSale();
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        pointOfSale.setServiceCenter(serviceCenter);
        pointOfSale.setCampaign(this.campaign);

        // @When saving or updating
        this.repository.saveOrUpdate(pointOfSale);

        // @Then entityManager.persist is called with that pos
        verify(changeServiceCenterQuery, times(1)).executeUpdate();
    }

    @Test
    public void testRemoveUnloadedPointsOfSaleForCampaignCreatesQueryThatLogicallyDeletesPosAndExecutesIt_WhenRemovingUnloadedPointsOfSale() {
        // @Given a campaign
        Query findDependentQuery = mock(Query.class);
        when(entityManager.createQuery(JpaPointOfSaleRepository.FIND_DEPENDENT_ROWS)).thenReturn(findDependentQuery);

        // @When removing not loaded for campaign
        this.repository.removeUnloadedPointsOfSaleForCampaign(this.campaign);

        // @Then the delete query is created, the campaign set as a parameter and the query executed
        verify(this.entityManager, times(1)).createQuery(JpaPointOfSaleRepository.REMOVE_NOT_LOADED_FOR_CAMPAIGN);
        verify(this.query, times(1)).setParameter("campaign", this.campaign);
        verify(this.query, times(1)).executeUpdate();
    }

    @Test
    public void testRemoveUnloadedPointsOfSaleForCampaignFindsDependentRows_WhenRemovingUnloadedPointsOfSale() {
        // @Given a campaign
        Query findDependentQuery = mock(Query.class);
        when(entityManager.createQuery(JpaPointOfSaleRepository.FIND_DEPENDENT_ROWS)).thenReturn(findDependentQuery);

        // @When removing not loaded for campaign
        this.repository.removeUnloadedPointsOfSaleForCampaign(this.campaign);

        // @Then the delete query is created, the campaign set as a parameter and the query executed
        verify(this.entityManager, times(1)).createQuery(JpaPointOfSaleRepository.FIND_DEPENDENT_ROWS);
        verify(this.query, times(1)).setParameter("campaign", this.campaign);
        verify(this.query, times(1)).executeUpdate();
    }

    @Test
    public void testRemoveUnloadedPointsOfSaleForCampaignDeletesDependentRowsLogically_WhenRemovingUnloadedPointsOfSale() {
        // @Given a campaign
        Query findDependentQuery = mock(Query.class);
        RowValues row1 = mock(RowValues.class);
        RowValues row2 = mock(RowValues.class);
        when(entityManager.createQuery(JpaPointOfSaleRepository.FIND_DEPENDENT_ROWS)).thenReturn(findDependentQuery);
        when(findDependentQuery.getResultList()).thenReturn(Lists.newArrayList(row1, row2));

        // @When removing not loaded for campaign
        this.repository.removeUnloadedPointsOfSaleForCampaign(this.campaign);

        // @Then the delete query is created, the campaign set as a parameter and the query executed
        verify(row1, times(1)).setDeleted(true);
        verify(row2, times(1)).setDeleted(true);
    }

    @Test
    public void testFindPointOfSaleByIdSapreatesAQueryToFindAServiceCenter_WhenFindingPointOfSale122ForCampaign() {
        // @Given an idSap and the campaign
        final long idSap = 122l;
        final ServiceCenter serviceCenter = new ServiceCenter();
        when(query.getResultList()).thenReturn(Lists.newArrayList(serviceCenter));

        // @When finding the point of sale
        this.repository.findPointOfSaleByIdSap(idSap, this.campaign);

        // @Then entityManager.find is called for PointOfSale Class with a PointOfSaleKey with the idSap and the campaign
        verify(this.entityManager, times(1)).createQuery(JpaPointOfSaleRepository.FIND_SC_FOR_THIS_POS_THAT_IS_NOT_DELETED);
        verify(this.query, times(1)).setParameter("idSap", idSap);
        verify(this.query, times(1)).setParameter("campaign", this.campaign);
    }

    @Test
    public void testFindPointOfSaleByIdSapCallsEntityManagerFindWithPointOfSaleClassAndKeyWithIdSap122AndCampaign_WhenFindingPointOfSale122ForCampaign() {
        // @Given an idSap and the campaign
        final long idSap = 122l;
        final ServiceCenter serviceCenter = new ServiceCenter();
        when(query.getResultList()).thenReturn(Lists.newArrayList(serviceCenter));

        // @When finding the point of sale
        this.repository.findPointOfSaleByIdSap(idSap, this.campaign);

        // @Then entityManager.find is called for PointOfSale Class with a PointOfSaleKey with the idSap and the campaign
        verify(this.entityManager, times(1)).find(eq(PointOfSale.class), argThat(new ArgumentMatcher<Object>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PointOfSaleKey &&
                        field("idSap").ofType(Long.class).in(argument).get().equals(idSap) &&
                        field("campaign").ofType(Campaign.class).in(argument).get().equals(JpaPointOfSaleRepository_UT.this.campaign) &&
                        field("serviceCenter").ofType(ServiceCenter.class).in(argument).get().equals(serviceCenter);
            }
        }));
    }

    @Test
    public void testFindPointsOfSaleByServiceCenterCallsInputServiceCenterGerPointsOfSale_WhenFindingPointsOfSaleForSC() {
        // @Given a Service center
        ServiceCenter serviceCenter = mock(ServiceCenter.class);

        // @When finding its point of sales
        this.repository.findPointsOfSaleByServiceCenter(serviceCenter);

        // @Then getPointOfSales is called
        verify(serviceCenter, times(1)).getPointsOfSale();
    }

    @Test
    public void testFindPointsOfSaleByServiceCenterReturnsInputServiceCenterGerPointsOfSale_WhenSCHasOnePointOfSale() {
        // @Given a Service center
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("alala");
        serviceCenter.setCampaign(this.campaign);
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(213l);
        pointOfSale.setServiceCenter(serviceCenter);
        pointOfSale.setCampaign(this.campaign);
        serviceCenter.setPointsOfSale(Lists.<PointOfSale>newArrayList(pointOfSale));

        // @When finding its point of sales
        List<PointOfSale> pointsOfSale = this.repository.findPointsOfSaleByServiceCenter(serviceCenter);

        // @Then getPointOfSales is called
        assertThat(pointsOfSale).isSameAs(serviceCenter.getPointsOfSale());
    }

    @Test
    public void testFindPointsOfSaleByServiceCenterReturnsInputServiceCenterGerPointsOfSale_WhenSCHasThreePointsOfSale() {
        // @Given a Service center
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("alala");
        serviceCenter.setCampaign(this.campaign);
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(213l);
        pointOfSale.setServiceCenter(serviceCenter);
        pointOfSale.setCampaign(this.campaign);
        PointOfSale pointOfSale2 = new PointOfSale();
        pointOfSale2.setIdSap(5234l);
        pointOfSale2.setServiceCenter(serviceCenter);
        pointOfSale2.setCampaign(this.campaign);
        PointOfSale pointOfSale3 = new PointOfSale();
        pointOfSale3.setIdSap(675l);
        pointOfSale3.setServiceCenter(serviceCenter);
        pointOfSale3.setCampaign(this.campaign);
        serviceCenter.setPointsOfSale(Lists.<PointOfSale>newArrayList(pointOfSale, pointOfSale2, pointOfSale3));

        // @When finding its point of sales
        List<PointOfSale> pointsOfSale = this.repository.findPointsOfSaleByServiceCenter(serviceCenter);

        // @Then getPointOfSales is called
        assertThat(pointsOfSale).isSameAs(serviceCenter.getPointsOfSale());
    }

    @Test
    public void testFindPointsOfSaleByCampaignCallsCreateQueryAndGetResultList_WhenFindingPointsOfSaleForCampaign() {
        // @Given a Service center

        // @When finding its point of sales
        this.repository.findPointsOfSaleByCampaign(campaign);

        // @Then getPointOfSales is called
        verify(this.entityManager, times(1)).createQuery(JpaPointOfSaleRepository.LIST_POINTS_OF_SALE_FOR_CAMPAIGN);
        verify(this.query, times(1)).setParameter("campaign", this.campaign);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindPointsOfSaleByCampaignLoggedAsEmployeeCallsCreateQueryAndGetResultList_WhenFindingPointsOfSaleForCampaign() {
        // @Given a Service center
        Employee employee = new Employee();
        employee.setId(1l);
        ServiceCenter serviceCenter = new ServiceCenter();
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(1l);
        List<PointOfSale> pointOfSales = Lists.newArrayList(pointOfSale);
        serviceCenter.setPointsOfSale(pointOfSales);
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);
        when(this.entityManager.find(eq(Employee.class), Matchers.<EmployeeKey>any())).thenReturn(employee);

        // @When finding its point of sales
        this.repository.findPointsOfSaleByCampaign(campaign);

        // @Then getPointOfSales is called
        verify(this.entityManager, times(1)).createQuery(JpaPointOfSaleRepository.LIST_POINTS_OF_SALE_FOR_CAMPAIGN_OF_EMPLOYEE);
        verify(this.query, times(1)).setParameter("campaign", this.campaign);
        PointOfSaleKey pointOfSaleKey = new PointOfSaleKey(campaign, pointOfSale.getIdSap(), serviceCenter);
        ArrayList list = new ArrayList();
        list.add(pointOfSaleKey);
        verify(this.query, times(1)).setParameter(eq("pointsOfSaleIds"), Matchers.<PointOfSaleKey>any());
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindPointsOfSaleByServiceCenterReturnsTheResultListWithOnePOS_WhenCampaignHasOnePointOfSale() {
        // @Given a Service center
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("alala");
        serviceCenter.setCampaign(this.campaign);
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(213l);
        pointOfSale.setServiceCenter(serviceCenter);
        pointOfSale.setCampaign(this.campaign);
        serviceCenter.setPointsOfSale(Lists.<PointOfSale>newArrayList(pointOfSale));
        when(entityManager.createQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(Lists.newArrayList(pointOfSale));

        // @When finding its point of sales
        List<PointOfSale> pointsOfSale = this.repository.findPointsOfSaleByCampaign(campaign);

        // @Then getPointOfSales is called
        assertThat(pointsOfSale).isSameAs(query.getResultList());
    }

    @Test
    public void testFindPointsOfSaleByCampaignReturnsThreePointsOfSale_WhenQueryFindsThreePointsOfSale() {
        // @Given a Service center
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("alala");
        serviceCenter.setCampaign(this.campaign);
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(213l);
        pointOfSale.setServiceCenter(serviceCenter);
        pointOfSale.setCampaign(this.campaign);
        PointOfSale pointOfSale2 = new PointOfSale();
        pointOfSale2.setIdSap(5234l);
        pointOfSale2.setServiceCenter(serviceCenter);
        pointOfSale2.setCampaign(this.campaign);
        PointOfSale pointOfSale3 = new PointOfSale();
        pointOfSale3.setIdSap(675l);
        pointOfSale3.setServiceCenter(serviceCenter);
        pointOfSale3.setCampaign(this.campaign);
        serviceCenter.setPointsOfSale(Lists.<PointOfSale>newArrayList(pointOfSale, pointOfSale2, pointOfSale3));
        when(entityManager.createQuery(anyString())).thenReturn(query);
        when(query.getResultList()).thenReturn(Lists.<PointOfSale>newArrayList(pointOfSale, pointOfSale2, pointOfSale3));

        // @When finding its point of sales
        List<PointOfSale> pointsOfSale = this.repository.findPointsOfSaleByCampaign(campaign);

        // @Then getPointOfSales is called
        assertThat(pointsOfSale).isSameAs(query.getResultList());
    }

    @Test
    public void testListPointsOfSaleByPageCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenListingThePointsOfSaleOfACampaignWithNoFilter() {
        // @Given a metric and page, filter and sort information
        Map<String, Object> filter = Maps.newHashMap();

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.listPointsOfSaleByPage(campaign, page, pageSize, "address", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(PointOfSaleQuery.FIND_POINTS_OF_SALE_BY_CAMPAIGN).append(" ORDER BY pos.address ASC").toString());
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testListPointsOfSaleByPageCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenListingThePointsOfSaleOfACampaignWithNoFilterAndLoggedAsAnEmployee() {
        // @Given a metric and page, filter and sort information
        Map<String, Object> filter = Maps.newHashMap();
        Employee employee = new Employee();
        employee.setId(1l);
        ServiceCenter serviceCenter = new ServiceCenter();
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(1l);
        List<PointOfSale> pointOfSales = Lists.newArrayList(pointOfSale);
        serviceCenter.setPointsOfSale(pointOfSales);
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);
        when(this.entityManager.find(eq(Employee.class), Matchers.<EmployeeKey>any())).thenReturn(employee);

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.listPointsOfSaleByPage(campaign, page, pageSize, "address", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(PointOfSaleQuery.FIND_POINTS_OF_SALE_BY_CAMPAIGN_AND_USER).append(" ORDER BY pos.address ASC").toString());
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter(eq("pointsOfSaleIds"), Matchers.<Object>any());
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testListPointsOfSaleByPageCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenListingThePointsOfSaleOfACampaignWithFilter() {
        // @Given a metric and page, filter and sort information
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("salesGroup", "10");
        filter.put("address", "hello");
        filter.put("region", "hello");
        filter.put("type", "hello");
        filter.put("tsrcId", 1l);
        filter.put("customer", "hello");
        filter.put("locality", "hello");
        filter.put("county", "hello");
        filter.put("state", "hello");
        filter.put("phone", "hello");
        filter.put("mail", "hello");

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.listPointsOfSaleByPage(campaign, page, pageSize, "address", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(PointOfSaleQuery.FIND_POINTS_OF_SALE_BY_CAMPAIGN).append(" AND pos.region = :region AND pos.mail = :mail AND pos.phone = :phone AND pos.tsrcId = :tsrcId AND pos.address = :address AND pos.county = :county AND pos.state = :state AND pos.locality = :locality AND pos.customer = :customer AND pos.type = :type AND pos.salesGroup = :salesGroup ORDER BY pos.address ASC").toString());
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter("salesGroup", "10");
        verify(this.query, times(1)).setParameter("address", "hello");
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testListPointsOfSaleByPageCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenListingThePointsOfSaleOfACampaignWithFilterAndSortCuit() {
        // @Given a metric and page, filter and sort information
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("salesGroup", "10");
        filter.put("address", "hello");

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.listPointsOfSaleByPage(campaign, page, pageSize, "cuit", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(PointOfSaleQuery.FIND_POINTS_OF_SALE_BY_CAMPAIGN).append(" AND pos.address = :address AND pos.salesGroup = :salesGroup ORDER BY pos.cuit ASC").toString());
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter("salesGroup", "10");
        verify(this.query, times(1)).setParameter("address", "hello");
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testListPointsOfSaleByPageReturnsSameAsQueryGetResultList_WhenListingThePointsOfSale() {
        // @Given a metric and page, filter and sort information
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("cuit", "10");
        filter.put("name", "hello");
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        serviceCenter.setCuit("10");
        serviceCenter.setName("hello");
        when(this.query.getResultList()).thenReturn(Lists.newArrayList(serviceCenter));

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        List<PointOfSale> serviceCenters = this.repository.listPointsOfSaleByPage(campaign, page, pageSize, "cuit", "ASC", filter);

        // @Then a query is created matching the input
        assertThat(serviceCenters).isSameAs(this.query.getResultList());
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////

    @Test
    public void testGetTotalScoresCountCreatesCountQuerySetsParametersAndExecutes() {
        // @Given a metric
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(22l);

        // @When counting the scores calculated for it
        this.repository.getPointsOfSaleCount(campaign, filter);

        // @Then a count query is created where metric = :metric
        verify(this.entityManager, times(1)).createQuery(PointOfSaleQuery.COUNT_POINT_OF_SALE_BY_CAMPAIGN);
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testGetTotalScoresCountReturns22_WhenQueryReturns22() {
        // @Given a metric
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(22l);

        // @When counting the scores calculated for it
        long count = this.repository.getPointsOfSaleCount(campaign, filter);

        // @Then a count query is created where metric = :metric
        assertThat(count).isEqualTo((Long) this.query.getSingleResult());
    }

    @Test
    public void testGetTotalScoresCountReturns13_WhenQueryReturns13() {
        // @Given a metric
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(13l);

        // @When counting the scores calculated for it
        long count = this.repository.getPointsOfSaleCount(campaign, filter);

        // @Then a count query is created where metric = :metric
        assertThat(count).isEqualTo((Long) this.query.getSingleResult());
    }

}
