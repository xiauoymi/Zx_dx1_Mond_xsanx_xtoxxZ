package com.monsanto.metricspos.persistence.unit;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.JpaScoresRepository;
import com.monsanto.metricspos.persistence.queries.MetricScoreCampaignQuery;
import com.monsanto.metricspos.persistence.queries.MetricScoreQuery;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class JpaScoresRepository_UT {
    private ScoreServices repository;
    private Metric metric;
    private ServiceCenter serviceCenter;
    private Campaign campaign;
    private EntityManager entityManager;
    private Query query;
    private SecurityHolderStrategy securityHolderStrategy;

    @Before
    public void setUp() {
        campaign = new Campaign("campaign", newDate(2035, 4, 4), newDate(2036, 7, 7));
        metric = new Metric(campaign, "name");
        this.serviceCenter = new ServiceCenter();
        this.serviceCenter.setCampaign(campaign);
        this.serviceCenter.setCuit("10");
        campaign.setServiceCenters(Lists.<ServiceCenter>newArrayList(this.serviceCenter));
        this.repository = new JpaScoresRepository();
        securityHolderStrategy = mock(SecurityHolderStrategy.class);
        when(securityHolderStrategy.getCurrentUser()).thenReturn(new AdminUser());
        field("securityHolderStrategy").ofType(SecurityHolderStrategy.class).in(repository).set(securityHolderStrategy);
        this.entityManager = mock(EntityManager.class);
        this.query = mock(Query.class);
        when(this.entityManager.createQuery(anyString())).thenReturn(this.query);
        field("entityManager").ofType(EntityManager.class).in(this.repository).set(entityManager);
    }

    @Test
    public void testNewMetricScoreReturnsAnEmptyScore() {
        MetricScore metricScore = this.repository.newMetricScore(metric, serviceCenter);

        assertThat(metricScore.getMetric()).isSameAs(metric);
        assertThat(metricScore.getServiceCenter()).isSameAs(serviceCenter);
    }

    @Test
    public void testFindScoresByMetricCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenFindingScoresByMetricWithNoFilter() {
        // @Given a metric and page, filter and sort information
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.findScoresByMetric(metric, page, pageSize, "points", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(MetricScoreQuery.FIND_SCORES_FOR_METRIC).append(" ORDER BY score.points ASC").toString());
        verify(this.query, times(1)).setParameter("metric", metric);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindScoresByMetricCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenFindingScoresByMetricWithFilter() {
        // @Given a metric and page, filter and sort information
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("serviceCenter", serviceCenter);
        BigDecimal points = BigDecimal.valueOf(10);
        filter.put("points", points);

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.findScoresByMetric(metric, page, pageSize, "points", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(MetricScoreQuery.FIND_SCORES_FOR_METRIC).append(" AND score.serviceCenter = :serviceCenter AND score.points = :points ORDER BY score.points ASC").toString());
        verify(this.query, times(1)).setParameter("metric", metric);
        verify(this.query, times(1)).setParameter("serviceCenter", serviceCenter);
        verify(this.query, times(1)).setParameter("points", points);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindScoresByMetricCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenFindingScoresByMetricWithFilterLoggedAsEnEmployee() {
        // @Given a metric and page, filter and sort information
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("serviceCenter", serviceCenter);
        BigDecimal points = BigDecimal.valueOf(10);
        filter.put("points", points);
        Employee employee = new Employee();
        //ServiceCenter serviceCenter = new ServiceCenter();
        //serviceCenter.setCuit("10");
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.findScoresByMetric(metric, page, pageSize, "points", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(MetricScoreQuery.FIND_SCORES_FOR_METRIC_AND_USER).append(" AND score.serviceCenter = :serviceCenter AND score.points = :points ORDER BY score.points ASC").toString());
        verify(this.query, times(1)).setParameter("metric", metric);
        verify(this.query, times(1)).setParameter("serviceCenter", serviceCenter);
        verify(this.query, times(1)).setParameter("cuits", Lists.<String>newArrayList("10"));
        verify(this.query, times(1)).setParameter("points", points);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindScoresByMetricCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenFindingScoresByMetricWithFilterAndSortIsCuit() {
        // @Given a metric and page, filter and sort information
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("serviceCenter", serviceCenter);
        BigDecimal points = BigDecimal.valueOf(10);
        filter.put("points", points);
        filter.put("penalty", points);
        filter.put("penaltyFactor", points);
        filter.put("noData", false);
        filter.put("lastUpdated", new Date());

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.findScoresByMetric(metric, page, pageSize, "cuit", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(MetricScoreQuery.FIND_SCORES_FOR_METRIC).append(" AND score.lastUpdated = :lastUpdated AND score.noData = :noData AND score.serviceCenter = :serviceCenter AND score.points = :points AND score.penalty = :penalty AND score.penaltyFactor = :penaltyFactor ORDER BY score.serviceCenter.cuit ASC").toString());
        verify(this.query, times(1)).setParameter("metric", metric);
        verify(this.query, times(1)).setParameter("serviceCenter", serviceCenter);
        verify(this.query, times(1)).setParameter("points", points);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindScoresByMetricReturnsSameAsQueryGetResultList_WhenFindingScoresByMetric() {
        // @Given a metric and page, filter and sort information
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("serviceCenter", serviceCenter);
        filter.put("points", BigDecimal.valueOf(10));
        MetricScore metricScore = new MetricScore(metric, serviceCenter);
        when(this.query.getResultList()).thenReturn(Lists.newArrayList(metricScore));

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        List<MetricScore> scores = this.repository.findScoresByMetric(metric, page, pageSize, "points", "ASC", filter);

        // @Then a query is created matching the input
        assertThat(scores).isSameAs(this.query.getResultList());
    }

    @Test
    public void testGetTotalScoresCountCreatesCountQuerySetsParametersAndExecutes() {
        // @Given a metric
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(22l);

        // @When counting the scores calculated for it
        this.repository.getTotalScoresCount(metric, filter);

        // @Then a count query is created where metric = :metric
        verify(this.entityManager, times(1)).createQuery(MetricScoreQuery.COUNT_SCORES_BY_METRIC);
        verify(this.query, times(1)).setParameter("metric", metric);
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testGetTotalScoresCountCreatesCountQuerySetsParametersAndExecutes_WhenLoggedAsAnEmployee() {
        // @Given a metric
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(22l);
        Employee employee = new Employee();
        employee.setId(1l);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);
        when(this.entityManager.find(eq(Employee.class), Matchers.any())).thenReturn(employee);

        // @When counting the scores calculated for it
        this.repository.getTotalScoresCount(metric, filter);

        // @Then a count query is created where metric = :metric
        verify(this.entityManager, times(1)).createQuery(MetricScoreQuery.COUNT_SCORES_BY_METRIC_AND_USER);
        verify(this.query, times(1)).setParameter("metric", metric);
        verify(this.query, times(1)).setParameter(eq("cuits"), Matchers.<Object>any());
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testGetTotalScoresCountReturns22_WhenQueryReturns22() {
        // @Given a metric
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(22l);

        // @When counting the scores calculated for it
        long count = this.repository.getTotalScoresCount(metric, filter);

        // @Then a count query is created where metric = :metric
        assertThat(count).isEqualTo((Long) this.query.getSingleResult());
    }

    @Test
    public void testGetTotalScoresCountReturns13_WhenQueryReturns13() {
        // @Given a metric
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(13l);

        // @When counting the scores calculated for it
        long count = this.repository.getTotalScoresCount(metric, filter);

        // @Then a count query is created where metric = :metric
        assertThat(count).isEqualTo((Long) this.query.getSingleResult());
    }

    @Test
    public void testFindScoresByMetricAndServiceCenterCreatesQueryAndSetsParameters_WhenFindingScoreByMetricAndServiceCenter() {
        // @Given a score of a service center and a metric
        Metric metric = new Metric(campaign, "name");

        // @When finding that score
        this.repository.findScoreByMetricAndServiceCenter(metric, this.serviceCenter);

        // @Then a query with parameters is created and executed
        verify(this.entityManager, times(1)).createQuery(JpaScoresRepository.FIND_SCORE_BY_METRIC_AND_SERVICE_CENTER);
        verify(this.query, times(1)).setParameter("serviceCenter", serviceCenter);
        verify(this.query, times(1)).setParameter("metric", metric);
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testFindScoresByMetricAndServiceCenterReturnsQueryResult_WhenFindingScoreByMetricAndServiceCenter() {
        // @Given a score of a service center and a metric
        Metric metric = new Metric(campaign, "name");
        MetricScore metricScore = new MetricScore(metric, serviceCenter);
        when(this.query.getSingleResult()).thenReturn(metricScore);

        // @When finding that score
        MetricScore result = this.repository.findScoreByMetricAndServiceCenter(metric, this.serviceCenter);

        // @Then a query with parameters is created and executed and the result is returned
        assertThat(result).isEqualTo(this.query.getSingleResult());

    }

    ////////////////////////////////////////////////////

    @Test
    public void testFindScoresByCampaignCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenFindingScoresByMetricWithNoFilter() {
        // @Given a metric and page, filter and sort information
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.findScoresByCampaign(campaign, page, pageSize, "points", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(MetricScoreCampaignQuery.FIND_SCORES_FOR_CAMPAIGN).append(" ORDER BY score.points ASC").toString());
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindScoresByCampaignCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenFindingScoresByMetricWithFilter() {
        // @Given a metric and page, filter and sort information
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("serviceCenter", serviceCenter);
        BigDecimal points = BigDecimal.valueOf(10);
        filter.put("points", points);

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.findScoresByCampaign(campaign, page, pageSize, "points", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(MetricScoreCampaignQuery.FIND_SCORES_FOR_CAMPAIGN).append(" AND score.serviceCenter = :serviceCenter AND score.points = :points ORDER BY score.points ASC").toString());
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter("serviceCenter", serviceCenter);
        verify(this.query, times(1)).setParameter("points", points);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindScoresByCampaignCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenFindingScoresByMetricWithFilterLoggedAsEnEmployee() {
        // @Given a metric and page, filter and sort information
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("serviceCenter", serviceCenter);
        BigDecimal points = BigDecimal.valueOf(10);
        filter.put("points", points);
        Employee employee = new Employee();
        //ServiceCenter serviceCenter = new ServiceCenter();
        //serviceCenter.setCuit("10");
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.findScoresByCampaign(campaign, page, pageSize, "points", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(MetricScoreCampaignQuery.FIND_SCORES_FOR_CAMPAIGN_AND_USER).append(" AND score.serviceCenter = :serviceCenter AND score.points = :points ORDER BY score.points ASC").toString());
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter("serviceCenter", serviceCenter);
        verify(this.query, times(1)).setParameter("cuits", Lists.<String>newArrayList("10"));
        verify(this.query, times(1)).setParameter("points", points);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindScoresByCampaignCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenFindingScoresByMetricWithFilterAndSortIsCuit() {
        // @Given a metric and page, filter and sort information
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("serviceCenter", serviceCenter);
        BigDecimal points = BigDecimal.valueOf(10);
        filter.put("points", points);
        filter.put("penalty", points);
        filter.put("penaltyFactor", points);
        filter.put("noData", false);
        filter.put("lastUpdated", new Date());
        filter.put("module", "name");
        filter.put("metric", "name");
        filter.put("submetric", "name");
        filter.put("dirty", true);

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.findScoresByCampaign(campaign, page, pageSize, "cuit", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(MetricScoreCampaignQuery.FIND_SCORES_FOR_CAMPAIGN).append(" AND score.metric.parent.parent.name LIKE :module AND score.metric.name LIKE :submetric AND score.metric.parent.name LIKE :metric AND score.dirty = :dirty AND score.lastUpdated = :lastUpdated AND score.noData = :noData AND score.serviceCenter = :serviceCenter AND score.points = :points AND score.penalty = :penalty AND score.penaltyFactor = :penaltyFactor ORDER BY score.serviceCenter.cuit ASC").toString());
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter("serviceCenter", serviceCenter);
        verify(this.query, times(1)).setParameter("points", points);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindScoresByCampaignReturnsSameAsQueryGetResultList_WhenFindingScoresByMetric() {
        // @Given a metric and page, filter and sort information
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("serviceCenter", serviceCenter);
        filter.put("points", BigDecimal.valueOf(10));
        MetricScore metricScore = new MetricScore(metric, serviceCenter);
        when(this.query.getResultList()).thenReturn(Lists.newArrayList(metricScore));

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        List<MetricScore> scores = this.repository.findScoresByCampaign(campaign, page, pageSize, "points", "ASC", filter);

        // @Then a query is created matching the input
        assertThat(scores).isSameAs(this.query.getResultList());
    }

    @Test
    public void testGetTotalCampaignScoresCountCreatesCountQuerySetsParametersAndExecutes() {
        // @Given a metric
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(22l);

        // @When counting the scores calculated for it
        this.repository.getTotalCampaignScoresCount(campaign, filter);

        // @Then a count query is created where metric = :metric
        verify(this.entityManager, times(1)).createQuery(MetricScoreCampaignQuery.COUNT_SCORES_BY_CAMPAIGN);
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testGetTotalCampaignScoresCountCreatesCountQuerySetsParametersAndExecutes_WhenLoggedAsAnEmployee() {
        // @Given a metric
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(22l);
        Employee employee = new Employee();
        employee.setId(1l);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);
        when(this.entityManager.find(eq(Employee.class), Matchers.any())).thenReturn(employee);

        // @When counting the scores calculated for it
        this.repository.getTotalCampaignScoresCount(campaign, filter);

        // @Then a count query is created where metric = :metric
        verify(this.entityManager, times(1)).createQuery(MetricScoreCampaignQuery.COUNT_SCORES_BY_CAMPAIGN_AND_USER);
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter(eq("cuits"), Matchers.<Object>any());
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testGetTotalCampaignScoresCountReturns22_WhenQueryReturns22() {
        // @Given a metric
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(22l);

        // @When counting the scores calculated for it
        long count = this.repository.getTotalCampaignScoresCount(campaign, filter);

        // @Then a count query is created where metric = :metric
        assertThat(count).isEqualTo((Long) this.query.getSingleResult());
    }

    @Test
    public void testGetTotalCampaignScoresCountReturns13_WhenQueryReturns13() {
        // @Given a metric
        Metric metric = new Metric(campaign, "name");
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(13l);

        // @When counting the scores calculated for it
        long count = this.repository.getTotalCampaignScoresCount(campaign, filter);

        // @Then a count query is created where metric = :metric
        assertThat(count).isEqualTo((Long) this.query.getSingleResult());
    }

    @Test
    public void testFindAllScoresByCampaignCreatesAQueryAndExecutesItWithCampaignParameter_WhenFindingAllScoresByCampaign() {
        // @Given a campaign
        String sort = "";
        String direction = "";
        Map<String, Object> filter = Maps.newHashMap();

        // @When finding all scores for that campaign
        this.repository.findAllScoresByCampaign(campaign, sort, direction, filter);

        // @A query is created with it's parameters and executed
        verify(this.entityManager, times(1)).createQuery("SELECT score FROM MetricScore score where score.metric.campaign = :campaign");
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindAllScoresByCampaignCreatesAQueryAndExecutesItWithCampaignParameter_WhenFindingAllScoresByCampaignLoggedAsEmployee() {
        // @Given a campaign
        String sort = "";
        String direction = "";
        Map<String, Object> filter = Maps.newHashMap();
        Employee employee = new Employee();
        employee.setServiceCenters(campaign.getServiceCenters());
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);

        // @When finding all scores for that campaign
        this.repository.findAllScoresByCampaign(campaign, sort, direction, filter);

        // @A query is created with it's parameters and executed
        verify(this.entityManager, times(1)).createQuery("SELECT score FROM MetricScore score join score.serviceCenter sc where score.metric.campaign = :campaign and sc.cuit in (:cuits)");
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).getResultList();
    }
}
