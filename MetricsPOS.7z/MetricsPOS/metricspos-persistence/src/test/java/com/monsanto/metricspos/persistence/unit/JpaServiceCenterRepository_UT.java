package com.monsanto.metricspos.persistence.unit;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.JpaServiceCenterRepository;
import com.monsanto.metricspos.persistence.RowValues;
import com.monsanto.metricspos.persistence.keys.EmployeeKey;
import com.monsanto.metricspos.persistence.queries.ServiceCenterQuery;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class JpaServiceCenterRepository_UT {
    private EntityManager entityManager;
    private JpaServiceCenterRepository repository;
    private Query query;
    private Campaign campaign;
    private SecurityHolderStrategy securityHolderStrategy;

    @Before
    public void setUp() {
        entityManager = mock(EntityManager.class);
        repository = new JpaServiceCenterRepository();
        field("entityManager").ofType(EntityManager.class).in(repository).set(entityManager);

        securityHolderStrategy = mock(SecurityHolderStrategy.class);
        when(securityHolderStrategy.getCurrentUser()).thenReturn(new AdminUser());
        field("securityHolderStrategy").ofType(SecurityHolderStrategy.class).in(repository).set(securityHolderStrategy);

        query = mock(Query.class);
        when(entityManager.createQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), Matchers.any())).thenReturn(query);

        this.campaign = new Campaign("name", newDate(2014, 5, 8), newDate(2016, 7, 3));
        this.campaign.setId(1);
    }

    @Test
    public void testMarkPointsOfSalesAsNotLoadedForCampaignCallsEntityManagerCreateQueryWithAnUpdateQueryThatSetsLoadedToTrueForPOSOfThisCampaign_WhenMarkingPointsOfSaleAsNotLoaded() {
        // @Given a campaign

        // @When marking all of it's points of sales as not loaded
        this.repository.markAllServiceCentersAsNotLoadedInCampaign(this.campaign);

        // @The update query is created and campaign set as parameter
        verify(this.entityManager, times(1)).createQuery(JpaServiceCenterRepository.MARK_ALL_SC_AS_UNLOADED);
        verify(this.query, times(1)).setParameter("campaign", this.campaign);
        verify(this.query, times(1)).executeUpdate();
    }

    @Test
    public void testMarkPointsOfSalesAsNotLoadedForCampaignReturns12_WhenUpdatedRowsWere12() {
        // @Given a campaign
        when(this.query.executeUpdate()).thenReturn(12);

        // @When marking all of it's points of sales as not loaded
        long updated = this.repository.markAllServiceCentersAsNotLoadedInCampaign(this.campaign);

        // @The update query is created and campaign set as parameter
        assertThat(updated).isEqualTo(this.query.executeUpdate());
    }

    @Test
    public void testMarkPointsOfSalesAsNotLoadedForCampaignReturns587_WhenUpdatedRowsWere587() {
        // @Given a campaign
        when(this.query.executeUpdate()).thenReturn(587);

        // @When marking all of it's points of sales as not loaded
        long updated = this.repository.markAllServiceCentersAsNotLoadedInCampaign(this.campaign);

        // @The update query is created and campaign set as parameter
        assertThat(updated).isEqualTo(this.query.executeUpdate());
    }

    @Test
    public void testSaveOrUpdate_WhenServiceCenterIsNew() {
        // @Given a point of sale
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        serviceCenter.setCampaign(campaign);
        when(entityManager.createNativeQuery("UPDATE MPS.MPS_SERVICE_CENTER SET DELETED = 0 WHERE CUIT = ? AND CAMPAIGN_ID = ?")).thenReturn(query);

        // @When saving or updating
        this.repository.saveOrUpdate(serviceCenter);

        // @Then entityManager.merge is called with that pos
        verify(this.entityManager, times(1)).persist(serviceCenter);
    }

    @Test
   public void testSaveOrUpdateUpdatesExistentServiceCenterParameters_WhenSavingOrUpdatingAnExistentServiceCenter() {
        // @Given a service center
       final ServiceCenter serviceCenter = new ServiceCenter();
       serviceCenter.setCuit("10");
       serviceCenter.setCampaign(campaign);
       serviceCenter.setName("name");
       serviceCenter.setMail("name.prueba@monsanto.com");
       when(entityManager.createNativeQuery("UPDATE MPS.MPS_SERVICE_CENTER SET DELETED = 0 WHERE CUIT = ? AND CAMPAIGN_ID = ?")).thenReturn(query);
       ServiceCenter existentServiceCenter = mock(ServiceCenter.class);
       when(query.getSingleResult()).thenReturn(existentServiceCenter);

          // @When saving or updating
       this.repository.saveOrUpdate(serviceCenter);

        // @Then
       verify(existentServiceCenter, times(1)).setName(same(serviceCenter.getName()));
       verify(existentServiceCenter, times(1)).setMail(same(serviceCenter.getMail()));
    }



    @Test
    public void testRemoveAllNotLoadedServiceCentersCreatesQueryAndExecutesIt() {
        // @Given a campaign
        Query removeQuery = mock(Query.class);
        when(entityManager.createQuery(JpaServiceCenterRepository.REMOVE_ALL_UNLOADED_SC)).thenReturn(removeQuery);

        Query removeScores = mock(Query.class);
        when(entityManager.createQuery(JpaServiceCenterRepository.SELECT_METRIC_SCORES_TO_DELETE)).thenReturn(removeScores);

        // @When removing not loaded for campaign
        this.repository.removeAllNotLoadedServiceCenters(this.campaign);

        // @Then the delete query is created, the campaign set as a parameter and the query executed
        verify(this.entityManager, times(1)).createQuery(JpaServiceCenterRepository.REMOVE_ALL_UNLOADED_SC);
        verify(removeQuery, times(1)).setParameter("campaign", this.campaign);
        verify(removeQuery, times(1)).executeUpdate();

        verify(removeScores, times(1)).getResultList();
    }

    @Test
    public void testRemoveAllNotLoadedServiceCentersFindsDependentPointsOfSales_WhenRemovingServiceCenters() {
        // @Given a campaign
        Query removeQuery = mock(Query.class);
        when(entityManager.createQuery(JpaServiceCenterRepository.FIND_DEPENDENT_POINTS_OF_SALE)).thenReturn(removeQuery);

        Query removeScores = mock(Query.class);
        when(entityManager.createQuery(JpaServiceCenterRepository.SELECT_METRIC_SCORES_TO_DELETE)).thenReturn(removeScores);

        // @When removing not loaded for campaign
        this.repository.removeAllNotLoadedServiceCenters(this.campaign);

        // @Then the delete query is created, the campaign set as a parameter and the query executed
        verify(this.entityManager, times(1)).createQuery(JpaServiceCenterRepository.FIND_DEPENDENT_POINTS_OF_SALE);
        verify(removeQuery, times(1)).setParameter("campaign", this.campaign);
        verify(removeQuery, times(1)).getResultList();

        verify(removeScores, times(1)).getResultList();
    }

    @Test
    public void testRemoveAllNotLoadedServiceCentersSetsDependentPointsOfSaleAsDeleted_WhenRemovingServiceCenters() {
        // @Given a campaign
        Query removeQuery = mock(Query.class);
        when(entityManager.createQuery(JpaServiceCenterRepository.FIND_DEPENDENT_POINTS_OF_SALE)).thenReturn(removeQuery);

        Query removeScores = mock(Query.class);
        when(entityManager.createQuery(JpaServiceCenterRepository.SELECT_METRIC_SCORES_TO_DELETE)).thenReturn(removeScores);

        PointOfSale pos = mock(PointOfSale.class);
        when(removeQuery.getResultList()).thenReturn(Lists.newArrayList(pos));

        // @When removing not loaded for campaign
        this.repository.removeAllNotLoadedServiceCenters(this.campaign);

        // @Then the delete query is created, the campaign set as a parameter and the query executed
        verify(pos).setDeleted(true);
    }

    @Test
    public void testRemoveAllNotLoadedServiceCentersFindsDependentRowValues_WhenRemovingServiceCenters() {
        // @Given a campaign
        Query removeQuery = mock(Query.class);
        when(entityManager.createQuery(JpaServiceCenterRepository.FIND_DEPENDENT_POINTS_OF_SALE)).thenReturn(removeQuery);

        Query removeScores = mock(Query.class);
        when(entityManager.createQuery(JpaServiceCenterRepository.SELECT_METRIC_SCORES_TO_DELETE)).thenReturn(removeScores);

        // @When removing not loaded for campaign
        this.repository.removeAllNotLoadedServiceCenters(this.campaign);

        // @Then the delete query is created, the campaign set as a parameter and the query executed
        verify(this.entityManager, times(1)).createQuery(JpaServiceCenterRepository.FIND_DEPENDENT_ROW_VALUES);
        verify(removeQuery, times(1)).setParameter("campaign", this.campaign);
        verify(removeQuery, times(1)).getResultList();
    }

    @Test
    public void testRemoveAllNotLoadedServiceCentersSetsDependentRowValuesAsDeleted_WhenRemovingServiceCenters() {
        // @Given a campaign
        Query removeQuery = mock(Query.class);
        when(entityManager.createQuery(JpaServiceCenterRepository.FIND_DEPENDENT_ROW_VALUES)).thenReturn(removeQuery);

        Query removeScores = mock(Query.class);
        when(entityManager.createQuery(JpaServiceCenterRepository.SELECT_METRIC_SCORES_TO_DELETE)).thenReturn(removeScores);

        RowValues rowValues = mock(RowValues.class);
        when(removeQuery.getResultList()).thenReturn(Lists.newArrayList(rowValues));

        // @When removing not loaded for campaign
        this.repository.removeAllNotLoadedServiceCenters(this.campaign);

        // @Then the delete query is created, the campaign set as a parameter and the query executed
        verify(rowValues).setDeleted(true);
    }

    @Test
    public void testFindServiceCenterByCuitCreatesQueryToFindSCByCuitAndCampaign() {
        // @Given an idSap and the campaign
        final String cuit = "122";

        // @When finding the point of sale
        this.repository.findServiceCenterByCuit(cuit, this.campaign);

        // @Then entityManager.find is called for ServiceCenter Class with a ServiceCenterKey with the idSap and the campaign
        verify(this.entityManager, times(1)).createQuery(JpaServiceCenterRepository.FIND_SERVICE_CENTER_BY_CAMPAIGN_AND_CUIT);
        verify(this.query, times(1)).setParameter("campaign", this.campaign);
        verify(this.query, times(1)).setParameter("cuit", cuit);
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testFindServiceCenterByCuitReturnsQueryResult() {
        // @Given an idSap and the campaign
        final String cuit = "122";
        ServiceCenter serviceCenter = new ServiceCenter();
        when(this.query.getSingleResult()).thenReturn(serviceCenter);

        // @When finding the point of sale
        ServiceCenter center = this.repository.findServiceCenterByCuit(cuit, this.campaign);

        // @Then entityManager.find is called for ServiceCenter Class with a ServiceCenterKey with the idSap and the campaign
        assertThat(center).isSameAs(serviceCenter);
    }

    @Test
    public void testGetTotalScoresCountCreatesCountQuerySetsParametersAndExecutes() {
        // @Given a campaign
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(22l);

        // @When counting the scores calculated for it
        this.repository.getServiceCentersCount(campaign, filter);

        // @Then a count query is created where campaign = :campaign
        verify(this.entityManager, times(1)).createQuery(ServiceCenterQuery.COUNT_SERVICE_CENTER_BY_CAMPAIGN);
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testGetTotalScoresCountCreatesCountQuerySetsParametersAndExecutes_WhenLoggedAsAnEmployee() {
        // @Given a campaign
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(22l);
        Employee employee = new Employee();
        employee.setId(1l);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);
        when(this.entityManager.find(eq(Employee.class), Matchers.any())).thenReturn(employee);

        // @When counting the scores calculated for it
        this.repository.getServiceCentersCount(campaign, filter);

        // @Then a count query is created where campaign = :campaign
        verify(this.entityManager, times(1)).createQuery(ServiceCenterQuery.COUNT_SERVICE_CENTER_BY_CAMPAIGN_AND_USER);
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).getSingleResult();
    }

    @Test
    public void testGetTotalScoresCountReturns22_WhenQueryReturns22() {
        // @Given a campaign
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(22l);

        // @When counting the scores calculated for it
        long count = this.repository.getServiceCentersCount(campaign, filter);

        // @Then a count query is created where campaign = :campaign
        assertThat(count).isEqualTo((Long) this.query.getSingleResult());
    }

    @Test
    public void testGetTotalScoresCountReturns13_WhenQueryReturns13() {
        // @Given a campaign
        Map<String, Object> filter = Maps.newHashMap();
        when(this.query.getSingleResult()).thenReturn(13l);

        // @When counting the scores calculated for it
        long count = this.repository.getServiceCentersCount(campaign, filter);

        // @Then a count query is created where campaign = :campaign
        assertThat(count).isEqualTo((Long) this.query.getSingleResult());
    }

    //////////////////////////////////////////////////////////////////////////////////

    @Test
    public void testListServiceCentersByPageCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenListingTheServiceCentersOfACampaignWithNoFilter() {
        // @Given a metric and page, filter and sort information
        Map<String, Object> filter = Maps.newHashMap();

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.listServiceCentersByPage(campaign, page, pageSize, "name", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(ServiceCenterQuery.FIND_SERVICE_CENTERS_BY_CAMPAIGN).append(" ORDER BY sc.name ASC").toString());
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testListServiceCentersByPageCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenListingTheServiceCentersOfACampaignWithNoFilterLoggedAsAnEmployee() {
        // @Given a metric and page, filter and sort information
        Map<String, Object> filter = Maps.newHashMap();
        Employee employee = new Employee();
        employee.setId(1l);
        ServiceCenter serviceCenter = new ServiceCenter();
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);
        when(this.entityManager.find(eq(Employee.class), Matchers.<EmployeeKey>any())).thenReturn(employee);

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.listServiceCentersByPage(campaign, page, pageSize, "name", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(ServiceCenterQuery.FIND_SERVICE_CENTERS_BY_CAMPAIGN_AND_USER).append(" ORDER BY sc.name ASC").toString());
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testListServiceCentersByPageCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenListingTheServiceCentersOfACampaignWithFilter() {
        // @Given a metric and page, filter and sort information
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("cuit", "10");
        filter.put("name", "hello");

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.listServiceCentersByPage(campaign, page, pageSize, "name", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(ServiceCenterQuery.FIND_SERVICE_CENTERS_BY_CAMPAIGN).append(" AND sc.cuit = :cuit AND sc.name = :name ORDER BY sc.name ASC").toString());
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter("cuit", "10");
        verify(this.query, times(1)).setParameter("name", "hello");
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testListServiceCentersByPageCreatesAQuerySetsTheParametersAndGetsTheResultList_WhenListingTheServiceCentersOfACampaignWithFilterAndSortCuit() {
        // @Given a metric and page, filter and sort information
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("cuit", "10");
        filter.put("name", "hello");
        filter.put("mail", "hello@mail.com");

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        this.repository.listServiceCentersByPage(campaign, page, pageSize, "cuit", "ASC", filter);

        // @Then a query is created matching the input
        verify(this.entityManager, times(1)).createQuery(new StringBuilder().append(ServiceCenterQuery.FIND_SERVICE_CENTERS_BY_CAMPAIGN).append(" AND sc.mail = :mail AND sc.cuit = :cuit AND sc.name = :name ORDER BY sc.cuit ASC").toString());
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).setParameter("cuit", "10");
        verify(this.query, times(1)).setParameter("name", "hello");
        verify(this.query, times(1)).setMaxResults(pageSize);
        verify(this.query, times(1)).setFirstResult((page - 1) * pageSize);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testFindServiceCentersByPageReturnsSameAsQueryGetResultList_WhenFindingServiceCentersByPage() {
        // @Given a metric and page, filter and sort information
        Map<String, Object> filter = Maps.newHashMap();
        filter.put("cuit", "10");
        filter.put("name", "hello");
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        serviceCenter.setCuit("10");
        serviceCenter.setName("hello");
        when(this.query.getResultList()).thenReturn(Lists.newArrayList(serviceCenter));

        // @When finding the corresponding scores
        int pageSize = 20;
        int page = 3;
        List<ServiceCenter> serviceCenters = this.repository.listServiceCentersByPage(campaign, page, pageSize, "cuit", "ASC", filter);

        // @Then a query is created matching the input
        assertThat(serviceCenters).isSameAs(this.query.getResultList());
    }

    @Test
    public void testListServiceCenters() {
        // @Given an existing campaign with service centers
        Campaign campaign = createCampaigns(1).get(0);
        campaign.setId(1);
        ServiceCenter expectedServiceCenter = new ServiceCenter();
        String cuit = "101010101";
        expectedServiceCenter.setCampaign(campaign);
        expectedServiceCenter.setCuit(cuit);

        ServiceCenter expectedServiceCenter2 = new ServiceCenter();
        String cuit2 = "101010101";
        expectedServiceCenter2.setCampaign(campaign);
        expectedServiceCenter2.setCuit(cuit2);

        campaign.add(expectedServiceCenter);
        campaign.add(expectedServiceCenter2);

        when(query.getResultList()).thenReturn(campaign.getServiceCenters());

        // @When listing the service centers
        List<ServiceCenter> serviceCenters = this.repository.listServiceCenters(campaign);

        // @The service centers are returned
        assertThat(serviceCenters).onProperty("cuit").contains(cuit, cuit2);

    }

    @Test
    public void testListServiceCentersCreatesAQueryAndSetsAllParameters_WhenListingAllServiceCenters() {
        // @Given an existing campaign with service centers
        Campaign campaign = createCampaigns(1).get(0);
        campaign.setId(1);

        // @When listing the service centers
        this.repository.listServiceCenters(campaign);

        // @The service centers are returned
        verify(this.entityManager, times(1)).createQuery(JpaServiceCenterRepository.FIND_ALL_SERVICE_CENTERS);
        verify(this.query, times(1)).setParameter("campaign", campaign);
        verify(this.query, times(1)).getResultList();
    }

    @Test
    public void testListServiceCentersReturnsEmployeeServiceCenters_WhenListingCampaignsAndLoggedUserIsNotAdmin() throws Exception {
        // @Given a logged user that is not an admin
        Employee employee = new Employee();
        employee.setId(1l);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        employee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter));
        when(this.entityManager.find(eq(Employee.class), Matchers.any())).thenReturn(employee);
        when(securityHolderStrategy.getCurrentUser()).thenReturn(employee);
        Campaign campaign = new Campaign("Hi", newDate(2011, 1, 1), newDate(2012, 5, 5));

        // @When listing all the campaign
        List<ServiceCenter> serviceCenters = this.repository.listServiceCenters(campaign);

        // @Then a user query is created and executed
        assertThat(serviceCenters).isSameAs(employee.getServiceCenters());
    }

    @Test
    public void testListServiceCentersReturnsQueryResult_WhenListingAllServiceCenters() {
        // @Given an existing campaign with service centers
        Campaign campaign = createCampaigns(1).get(0);
        campaign.setId(1);
        when(this.query.getResultList()).thenReturn(Lists.newArrayList());

        // @When listing the service centers
        List<ServiceCenter> serviceCenters = this.repository.listServiceCenters(campaign);

        // @The service centers are returned
        assertThat(serviceCenters).isSameAs(this.query.getResultList());
    }

    /**
     * Creates a lists of campaigns to use for test
     *
     * @param quantity
     * @return
     */
    private static List<Campaign> createCampaigns(int quantity) {
        List<Campaign> campaigns = Lists.newArrayList();

        for (int i = 0; i < quantity; i++) {
            campaigns.add(new Campaign("Campaign " + i, newDate(2012 + i - quantity, 4, 1), newDate(2013 + i - quantity, 3, 31)));

        }

        return campaigns;
    }
}
