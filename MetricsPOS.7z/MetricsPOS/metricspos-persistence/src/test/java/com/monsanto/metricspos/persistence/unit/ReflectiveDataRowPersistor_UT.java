package com.monsanto.metricspos.persistence.unit;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.monsanto.metricspos.core.externaldata.*;
import com.monsanto.metricspos.core.externaldata.restrictions.Restriction;
import com.monsanto.metricspos.core.externaldata.restrictions.StringLengthRestriction;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.*;
import com.monsanto.metricspos.persistence.hibernate.DataTypesHolder;
import org.junit.Before;
import org.junit.Test;
import org.springframework.core.convert.ConversionFailedException;

import java.math.BigDecimal;
import java.util.*;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.fest.reflect.core.Reflection.staticField;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class ReflectiveDataRowPersistor_UT {

    private RowValuesServices rowValuesServices;
    private DataRowPersistorFactory dataRowPersistorFactory;

    @Before
    public void setUp() {
        HashMap<String, DataType> dataTypeMap1 = Maps.newHashMap();
        dataTypeMap1.put("string", stringDataType());
        dataTypeMap1.put("date", dateDataType());

        rowValuesServices = mock(RowValuesServices.class);

        dataRowPersistorFactory = new ReflectiveDataRowPersistorFactory();

        Map<Class, String> classXprefix = Maps.newHashMap();
        classXprefix.put(String.class, RowValues.TEXT_COLUMN_PREFIX);
        classXprefix.put(Integer.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Long.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(BigDecimal.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Number.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Date.class, RowValues.DATE_COLUMN_PREFIX);
        classXprefix.put(ServiceCenter.class, RowValues.SERVICE_CENTER_COLUMN_PREFIX);
        classXprefix.put(PointOfSale.class, RowValues.POINT_OF_SALE_COLUMN_PREFIX);

        field("classToPrefixMap").ofType(Map.class).in(dataRowPersistorFactory).set(classXprefix);

        Map<String, DataType> dataTypeMap = Maps.newHashMap();
        dataTypeMap.put("string", stringDataType());

        staticField("dataTypes").ofType(Map.class).in(DataTypesHolder.class).set(dataTypeMap);
    }

    @Test
    public void testWhenDataOfADataTableWithOneStringColumnIsCreatedAndItParametersIsSetItRemembersTheValueThatWasSetForThatColumn() {
        DataType stringDataType = stringDataType();
        String columnName = "column1";
        String value = "Hello";
        DataColumn dataColumn = newDataColumn(columnName, stringDataType, "text1");
        dataColumn.setActualColumnName("text1");

        List<DataColumn> columns = Lists.newArrayList(dataColumn);
        DataTable dataTable = new DataTable("name", columns, dataRowPersistorFactory);

        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());
        dataRow.set(columnName, value);

        assertThat(dataRow.get(columnName)).isSameAs(value);
    }

    @Test
    public void testDataRowRemembersTheValueThatWasSetForThatColumn_WhenDataOfADataTableWithOneNumericColumnIsCreatedAndItParametersIsSetIt() {
        DataType numberDataType = (numberDataType());
        String columnName = "column1";
        BigDecimal value = BigDecimal.valueOf(1);
        DataColumn dataColumn = newDataColumn(columnName, numberDataType, "number1");


        List<DataColumn> columns = Lists.newArrayList(dataColumn);
        DataTable dataTable = new DataTable("name", columns, dataRowPersistorFactory);

        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());
        dataRow.set(columnName, value);

        assertThat(dataRow.get(columnName)).isSameAs(value);
    }

    @Test
    public void testWhenDataOfADataTableWithTwoStringColumnsIsCreatedAndItsParametersAreBothSetItRemembersTheValuesThatWereSetForEachColumn() {
        DataType stringDataType = stringDataType();
        String columnName = "column1";
        String columnName2 = "column2";
        String value = "Hello";
        String value2 = "Goodbye";
        DataColumn dataColumn = newDataColumn(columnName, stringDataType, "text1");
        DataColumn dataColumn2 = newDataColumn(columnName2, stringDataType, "text2");

        List<DataColumn> columns = Lists.newArrayList(dataColumn, dataColumn2);
        DataTable dataTable = new DataTable("name", columns, dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());
        dataRow.set(columnName, value);
        dataRow.set(columnName2, value2);

        assertThat(dataRow.get(columnName)).isSameAs(value);
        assertThat(dataRow.get(columnName2)).isSameAs(value2);
    }

    @Test
    public void testCannotSetAValueOfAGivenTypeInAColumnOfADifferentType() {
        DataType dateDataType = dateDataType();
        String columnName = "column1";
        String value = "Hello";
        DataColumn dataColumn = newDataColumn(columnName, dateDataType, "text1");

        List<DataColumn> columns = Lists.newArrayList(dataColumn);
        DataTable dataTable = new DataTable("name", columns, dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());

        try {
            dataRow.set(columnName, value);
            fail();
        } catch (RuntimeException e) {
            assertThat(e).isInstanceOf(ConversionFailedException.class);
            assertThat(dataRow.get(columnName)).isNull();
        }
    }

    @Test
    public void testSetAValueForAStringColumnWithARestrictionWhenValuePassesRestrictionTheValueIsSet() {
        DataType stringDataType = stringDataType();
        String columnName = "column1";
        String value = "Hello";

        Restriction restriction = new StringLengthRestriction(5);
        Set<Restriction> restrictions = Sets.newHashSet(restriction);

        DataColumn dataColumn = newDataColumn(columnName, stringDataType, restrictions, "text1");

        List<DataColumn> columns = Lists.newArrayList(dataColumn);
        DataTable dataTable = new DataTable("name", columns, dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());
        dataRow.set(columnName, value);

        assertThat(dataRow.get(columnName)).isSameAs(value);
    }

    @Test
    public void testSetAValueForAStringColumnWithARestrictionWhenValueNotPassesRestrictionTheValueIsNotSet() {
        DataType stringDataType = stringDataType();
        String columnName = "column1";
        String value = "Hello";

        Restriction lengthRestriction = new StringLengthRestriction(2);
        Set<Restriction> restrictions = Sets.newHashSet(lengthRestriction);

        DataColumn dataColumn = newDataColumn(columnName, stringDataType, restrictions, "text1");

        List<DataColumn> columns = Lists.newArrayList(dataColumn);
        DataTable dataTable = new DataTable("name", columns, dataRowPersistorFactory);
        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());

        try {
            dataRow.set(columnName, value);
            fail();
        } catch (RuntimeException e) {
            assertThat(e.getMessage()).isSameAs(Restriction.ERROR_RESTRICTION_VIOLATION);
            assertThat(dataRow.get(columnName)).isNull();
        }
    }

    @Test
    public void testGetInternalIdReturnsRowValueIdOne_WhenRowValueHasIdOne() {
        // @Given a reflectiveDataRowPersistor with RowValues
        List<DataColumn> columns = Lists.newArrayList();
        DataTable dataTable = new DataTable("tableName", columns, new ReflectiveDataRowPersistorFactory());
        RowValues rowValues = new RowValues();
        rowValues.setId(1);
        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();
        DataRow dataRow = new DataRow(dataTable, rowValues);

        // @When getting the internal id
        Integer internalId = dataRowPersistor.getInternalId(dataRow.getRowValues());

        // @Then RowValues.getId is returned
        assertThat(internalId).isNotNull();
        assertThat(internalId).isEqualTo(rowValues.getId());
    }

    @Test
    public void testMakeRowValuesReturnsLoadedRowValuesWithThreeStringValues_WhenMakingOneFromRowDataMapWithThreeTextValues() {
        // @Given row data
        HashMap<String, Object> rowData = Maps.newHashMap();
        rowData.put("aField1", "aValue1");
        rowData.put("aField2", "aValue2");
        rowData.put("aField3", "aValue3");
        List<DataColumn> columns = Lists.newArrayList(
                newDataColumn("aField1", stringDataType(), "text1"),
                newDataColumn("aField2", stringDataType(), "text2"),
                newDataColumn("aField3", stringDataType(), "text3")
        );
        DataTable dataTable = new DataTable("tableName", columns, dataRowPersistorFactory);
        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();

        // @When making row values from that data
        RowValues rowValues = (RowValues) dataRowPersistor.makeRowValues(rowData);

        // @Then rowValues is loaded with rowData data
        String value1 = field("text1").ofType(String.class).in(rowValues).get();
        String value2 = field("text2").ofType(String.class).in(rowValues).get();
        String value3 = field("text3").ofType(String.class).in(rowValues).get();
        assertThat(value1).isEqualTo((String) rowData.get("aField1"));
        assertThat(value2).isEqualTo((String) rowData.get("aField2"));
        assertThat(value3).isEqualTo((String) rowData.get("aField3"));
    }

    @Test
    public void testMakeRowValuesAsInputOfNewDataRowReturnsADataRowWithValuesInColumnsMatchingRowData_WhenMakingOneFromRowDataMapWithThreeTextValues() {
        // @Given row data
        HashMap<String, Object> rowData = Maps.newHashMap();
        rowData.put("aField1", "aValue1");
        rowData.put("aField2", "aValue2");
        rowData.put("aField3", "aValue3");
        List<DataColumn> columns = Lists.newArrayList(
                newDataColumn("aField1", stringDataType(), "text1"),
                newDataColumn("aField2", stringDataType(), "text2"),
                newDataColumn("aField3", stringDataType(), "text3")
        );
        DataTable dataTable = new DataTable("tableName", columns, dataRowPersistorFactory);
        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();

        // @When making row values from that data
        DataRow dataRow = new DataRow(dataTable, dataRowPersistor.makeRowValues(rowData));

        // @Then rowValues is loaded with rowData data
        assertThat(dataRow.get("aField1")).isNotNull();
        assertThat(dataRow.get("aField2")).isNotNull();
        assertThat(dataRow.get("aField3")).isNotNull();
        assertThat(dataRow.get("aField1")).isEqualTo("aValue1");
        assertThat(dataRow.get("aField2")).isEqualTo("aValue2");
        assertThat(dataRow.get("aField3")).isEqualTo("aValue3");
    }

//    @Test
//    public void testTransformFilterReturnsAFilterForRowValues_WhenReceivingAFilterForColumns() {
//        // @Given a reflective persistor
//        List<DataColumn> columns = Lists.newArrayList(
//                newDataColumn("column1", stringDataType(), "text1"),
//                newDataColumn("column2", stringDataType(), "text2"),
//                newDataColumn("column3", stringDataType(), "text3")
//        );
//        DataTable dataTable = new DataTable("tableName", columns, dataRowPersistorFactory);
//        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();
//
//        Map<String, Object> filter = Maps.newHashMap();
//        filter.put("column1", "A");
//        filter.put("column2", "B");
//        filter.put("column3", "C");
//
//        // @When transforming a filter for columns
//        List<RowFilterCondition> transformedFilter = dataRowPersistor.transformFilter(filter);
//
//        // @Mapped column names are returned in a new filter
//        assertThat(transformedFilter).onProperty("actualColumnName").contains("text1", "text2", "text3");
//        assertThat(transformedFilter).onProperty("actualColumnName").excludes("column1", "column2", "column3");
//
//    }

    @Test
    public void testRowAcceptsIntegerLongBigDecimalAsValues_WhenSettingNumericColumns() {
        DataColumn dataColumn1 = newDataColumn("numeric1", numberDataType(), "number1");
        DataColumn dataColumn2 = newDataColumn("numeric2", numberDataType(), "number2");
        DataColumn dataColumn3 = newDataColumn("numeric3", numberDataType(), "number3");

        List<DataColumn> columns = Lists.newArrayList(dataColumn1, dataColumn2, dataColumn3);
        DataTable dataTable = new DataTable("name", columns, dataRowPersistorFactory);
        RowValuesServices rowValuesServices = mock(RowValuesServices.class);
        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());
        Integer integer = 12;
        Long aLong = (long) 98;
        BigDecimal bigDecimal = BigDecimal.valueOf(2502, 2);

        dataRow.set(dataColumn1.getName(), integer);
        dataRow.set(dataColumn2.getName(), aLong);
        dataRow.set(dataColumn3.getName(), bigDecimal);

        assertThat(dataRow.get(dataColumn1.getName()).toString()).isEqualTo(integer.toString());
        assertThat(dataRow.get(dataColumn2.getName()).toString()).isEqualTo(aLong.toString());
        assertThat(dataRow.get(dataColumn3.getName()).toString()).isEqualTo(bigDecimal.toString());
    }

    @Test
    public void testRowAcceptsServiceCenter_WhenSettingServiceCenterColumns() {
        DataColumn dataColumn1 = newDataColumn("SC", serviceCenterDataType(), "serviceCenter");

        List<DataColumn> columns = Lists.newArrayList(dataColumn1);
        DataTable dataTable = new DataTable("name", columns, dataRowPersistorFactory);
        RowValuesServices rowValuesServices = mock(RowValuesServices.class);
        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());
        ServiceCenter serviceCenter = new ServiceCenter();

        dataRow.set(dataColumn1.getName(), serviceCenter);

        assertThat(dataRow.get(dataColumn1.getName())).isSameAs(serviceCenter);
    }

    @Test
    public void testRowAcceptsPointOfSale_WhenSettingPointOfSaleColumns() {
        DataColumn dataColumn1 = newDataColumn("POS", pointOfSaleDataType(), "pointOfSale");

        List<DataColumn> columns = Lists.newArrayList(dataColumn1);
        DataTable dataTable = new DataTable("name", columns, dataRowPersistorFactory);
        RowValuesServices rowValuesServices = mock(RowValuesServices.class);
        dataTable.setRowValuesServices(rowValuesServices);

        DataRow dataRow = dataTable.newRow(Maps.<String, Object>newHashMap());
        PointOfSale pointOfSale = new PointOfSale();

        dataRow.set(dataColumn1.getName(), pointOfSale);

        assertThat(dataRow.get(dataColumn1.getName())).isSameAs(pointOfSale);
    }

    @Test
    public void testSetLoadedCallsRowValueSetLoadedTrue_WhenSettingLoadedToTrue() {
        // @Given a rowValue
        RowValues rowValues = mock(RowValues.class);
        List<DataColumn> columns = Lists.newArrayList();
        DataTable dataTable = new DataTable("tableName", columns, new ReflectiveDataRowPersistorFactory());
        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();

        // @When setting loaded to true with the persistor
        dataRowPersistor.setLoaded(rowValues, true);

        // @The setLoaded is called with true as a parameter
        verify(rowValues, times(1)).setLoaded(true);
    }

    @Test
    public void testSetLoadedCallsRowValueSetLoadedFalse_WhenSettingLoadedToFalse() {
        // @Given a rowValue
        RowValues rowValues = mock(RowValues.class);
        List<DataColumn> columns = Lists.newArrayList();
        DataTable dataTable = new DataTable("tableName", columns, new ReflectiveDataRowPersistorFactory());
        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();

        // @When setting loaded to true with the persistor
        dataRowPersistor.setLoaded(rowValues, true);

        // @The setLoaded is called with true as a parameter
        verify(rowValues, times(1)).setLoaded(true);
    }

    @Test
    public void testGetServiceCenterReturnsRowValuesServiceCenterWithCuitCuit_WhenGettingServiceCenterFromRowValuesWhoseServiceCenterCuitIsCuit() {
        // @Given a rowValues with a service center
        RowValues rowValues = new RowValues();
        List<DataColumn> columns = Lists.newArrayList();
        DataTable dataTable = new DataTable("tableName", columns, new ReflectiveDataRowPersistorFactory());
        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("cuit");
        rowValues.setServiceCenter(serviceCenter);

        // @When getting the service center with the persistor
        ServiceCenter returnedServiceCenter = dataRowPersistor.getServiceCenter(rowValues);

        // @Then the service center from the rowValues is returned
        assertThat(returnedServiceCenter.getCuit()).isEqualTo(serviceCenter.getCuit());
    }

    @Test
    public void testGetPointOfSaleReturnsRowValuesPointOfSaleWithIdSap12_WhenGettingPointOfSaleFromRowValuesWhosePointOfSalesIdSapIs12() {
        // @Given a rowValues with a service center
        RowValues rowValues = new RowValues();
        List<DataColumn> columns = Lists.newArrayList();
        DataTable dataTable = new DataTable("tableName", columns, new ReflectiveDataRowPersistorFactory());
        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(12l);
        rowValues.setPointOfSale(pointOfSale);

        // @When getting the service center with the persistor
        PointOfSale returnedPointOfSale = dataRowPersistor.getPointOfSale(rowValues);

        // @Then the service center from the rowValues is returned
        assertThat(returnedPointOfSale.getIdSap()).isEqualTo(pointOfSale.getIdSap());
    }

    @Test
    public void testGetPointOfSaleReturnsRowValuesPointOfSaleWithIdSap154_WhenGettingPointOfSaleFromRowValuesWhosePointOfSalesIdSapIs154() {
        // @Given a rowValues with a service center
        RowValues rowValues = new RowValues();
        List<DataColumn> columns = Lists.newArrayList();
        DataTable dataTable = new DataTable("tableName", columns, new ReflectiveDataRowPersistorFactory());
        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(154l);
        rowValues.setPointOfSale(pointOfSale);

        // @When getting the service center with the persistor
        PointOfSale returnedPointOfSale = dataRowPersistor.getPointOfSale(rowValues);

        // @Then the service center from the rowValues is returned
        assertThat(returnedPointOfSale.getIdSap()).isEqualTo(pointOfSale.getIdSap());
    }

    @Test
    public void testGetServiceCenterReturnsRowValuesServiceCenterWithCuitOne_WhenGettingServiceCenterFromRowValuesWhoseServiceCenterCuitIsOne() {
        // @Given a rowValues with a service center
        RowValues rowValues = new RowValues();
        List<DataColumn> columns = Lists.newArrayList();
        DataTable dataTable = new DataTable("tableName", columns, new ReflectiveDataRowPersistorFactory());
        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("one");
        rowValues.setServiceCenter(serviceCenter);

        // @When getting the service center with the persistor
        ServiceCenter returnedServiceCenter = dataRowPersistor.getServiceCenter(rowValues);

        // @Then the service center from the rowValues is returned
        assertThat(returnedServiceCenter.getCuit()).isEqualTo(serviceCenter.getCuit());
    }

    @Test
    public void testSetServiceCenterCallsRowValuesSetServiceCenterWithInputServiceCenter_WhenSettingAServiceCenterToRowValues() {
        // @Given a rowValues with a service center
        RowValues rowValues = mock(RowValues.class);
        List<DataColumn> columns = Lists.newArrayList();
        DataTable dataTable = new DataTable("tableName", columns, new ReflectiveDataRowPersistorFactory());
        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("cuit");

        // @When getting the service center with the persistor
        dataRowPersistor.setServiceCenter(rowValues, serviceCenter);

        // @Then the service center from the rowValues is returned
        verify(rowValues, times(1)).setServiceCenter(serviceCenter);
    }

    @Test
    public void testSetPointOfSaleCallsRowValuesSetPointOfSaleWithInputPointOfSale_WhenSettingAPointOfSaleToRowValues() {
        // @Given a rowValues with a service center
        RowValues rowValues = mock(RowValues.class);
        List<DataColumn> columns = Lists.newArrayList();
        DataTable dataTable = new DataTable("tableName", columns, new ReflectiveDataRowPersistorFactory());
        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setIdSap(123l);

        // @When getting the service center with the persistor
        dataRowPersistor.setPointOfSale(rowValues, pointOfSale);

        // @Then the service center from the rowValues is returned
        verify(rowValues, times(1)).setPointOfSale(pointOfSale);
    }

    @Test
    public void testGetDataFileReturnsRowValuesDataFileWithNameFile1_WhenGettingDataFileFromRowValuesWhoseFileNameIsFile1() {
        // @Given a rowValues with a service center
        RowValues rowValues = new RowValues();
        List<DataColumn> columns = Lists.newArrayList();
        DataTable dataTable = new DataTable("tableName", columns, new ReflectiveDataRowPersistorFactory());
        DataRowPersistor dataRowPersistor = dataTable.getDataRowPersistor();
        DataFile expected = new DataFile("File1", "string".getBytes());
        rowValues.setDataFile(expected);

        // @When getting the service center with the persistor
        DataFile dataFile = dataRowPersistor.getDataFile(rowValues);

        // @Then the service center from the rowValues is returned
        assertThat(dataFile).isSameAs(expected);
    }

    private DataType stringDataType() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("string");
        field("internalType").ofType(Class.class).in(dataType).set(String.class);
        return dataType;
    }

    private DataType numberDataType() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("number");
        field("internalType").ofType(Class.class).in(dataType).set(BigDecimal.class);
        return dataType;
    }

    private DataType dateDataType() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("date");
        field("internalType").ofType(Class.class).in(dataType).set(Date.class);
        return dataType;
    }

    private DataType serviceCenterDataType() {
        DataType dataType = new DataType();
        dataType.setCode("SC");
        dataType.setName("Service Center");
        dataType.setInternalType(ServiceCenter.class);
        return dataType;
    }

    private DataType pointOfSaleDataType() {
        DataType dataType = new DataType();
        dataType.setCode("POS");
        dataType.setName("Point of sale");
        dataType.setInternalType(PointOfSale.class);
        return dataType;
    }

    private DataColumn newDataColumn(String columnName, DataType dataType, String actualColumnName) {
        DataColumn dataColumn = new DataColumn(columnName, dataType);
        dataColumn.setActualColumnName(actualColumnName);
        return dataColumn;
    }

    private DataColumn newDataColumn(String columnName, DataType dataType, Set<Restriction> restrictions, String actualColumnName) {
        DataColumn dataColumn = new DataColumn(columnName, dataType, restrictions);
        dataColumn.setActualColumnName(actualColumnName);
        return dataColumn;
    }
}
