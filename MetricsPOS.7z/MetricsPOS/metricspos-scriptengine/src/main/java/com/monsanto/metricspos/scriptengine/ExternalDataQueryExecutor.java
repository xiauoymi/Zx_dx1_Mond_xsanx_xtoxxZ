package com.monsanto.metricspos.scriptengine;

import com.monsanto.metricspos.core.externaldata.DataProvider;

/**
 * Interface provided for objects that allows to execute a query on external data
 *
 * @author cafau
 */
public interface ExternalDataQueryExecutor<T> {

    /**
     * Executes the given query in the context of the provider
     *
     * @param provider  the data source provider of this data
     * @param query     the query that provides the data
     * @return  An iterator on the data read, or null if no records read
     */
    Iterable<T> execute( DataProvider provider, String query );
}
