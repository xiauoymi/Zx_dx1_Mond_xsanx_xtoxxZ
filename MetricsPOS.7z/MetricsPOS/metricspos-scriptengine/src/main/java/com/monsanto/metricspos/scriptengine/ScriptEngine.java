package com.monsanto.metricspos.scriptengine;

import com.monsanto.metricspos.scriptengine.exceptions.ScriptSyntaxException;
import org.apache.commons.jexl2.*;
import org.apache.commons.jexl2.parser.ParseException;

import java.util.Map;

/**
 * Engine to interpret and execute scripts to compute metrics.
 * This is just a generic wrapper over the Jexl. TODO Change for the javax.script.ScriptEngine
 *
 * @author cafau
 */
public class ScriptEngine {

    private Script script;

    /**
     * Creates an engine to execute the given script
     * @param engine                The engine to process the scripts
     * @param scriptSource        The script code to execute
     */
    public ScriptEngine(JexlEngine engine, String scriptSource) {
        try {
            this.script = engine.createScript( scriptSource );
        } catch (JexlException.Parsing e) {

            ParseException pe = (ParseException) e.getCause();

            int line = pe.getLine();
            int column = pe.getColumn();

            String[] lines = scriptSource.split("\r?\n");
            String offendingLine = line >= 1 && line <= lines.length ? lines[line - 1] : scriptSource ;

            offendingLine = "[" + offendingLine.substring( 0, column ) + "]??[" + offendingLine.substring(column) + "]";
            throw new ScriptSyntaxException("Error in " + line + '@' + column + ": " + offendingLine, e);
        }
    }

    /**
     * Executes the given script on a context with the given arguments
     *
     * @param arguments     The arguments to inject in the context. The keys are argument names,
     *                      and the values theirs argument values
     */
    public Object execute(Map<String, Object> arguments) {
        JexlContext context = new MapContext(arguments);

        return script.execute(context); // Catch execution exceptions !!
    }
}
