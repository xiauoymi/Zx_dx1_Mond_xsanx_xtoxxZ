package com.monsanto.metricspos.scriptengine;

/**
 * Complete please !!
 *
 * @author cafau
 */
public interface ScriptEngineFactory {

    /**
     * Builds a Script engine to process the given script
     *
     * @param script
     * @return
     */
    ScriptEngine buildFor(String script);
}
