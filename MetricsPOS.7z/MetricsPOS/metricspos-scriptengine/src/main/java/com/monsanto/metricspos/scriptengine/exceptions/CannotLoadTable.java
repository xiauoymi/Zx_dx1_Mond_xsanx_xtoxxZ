package com.monsanto.metricspos.scriptengine.exceptions;

/**
 * Complete please !!
 *
 * @author cafau
 */
public class CannotLoadTable extends RuntimeException {
    public CannotLoadTable() {
    }

    public CannotLoadTable(String message) {
        super(message);
    }
}
