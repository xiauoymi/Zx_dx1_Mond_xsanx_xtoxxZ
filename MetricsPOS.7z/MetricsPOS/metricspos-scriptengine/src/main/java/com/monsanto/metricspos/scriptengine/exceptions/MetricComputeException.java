package com.monsanto.metricspos.scriptengine.exceptions;

/**
 * Signals that there was an error while computing the score for the metric.
 *
 * @author cafau
 */
public class MetricComputeException extends RuntimeException {
    public MetricComputeException() {
    }

    public MetricComputeException(String message) {
        super(message);
    }
}
