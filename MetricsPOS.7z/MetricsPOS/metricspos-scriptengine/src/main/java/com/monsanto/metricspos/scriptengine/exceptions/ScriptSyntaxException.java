package com.monsanto.metricspos.scriptengine.exceptions;

/**
 * Exception marking an error in the syntax of the script
 *
 * @author cafau
 */
public class ScriptSyntaxException extends RuntimeException {
    public ScriptSyntaxException(String message, Throwable e) {
        super(message, e);
    }
}
