package com.monsanto.metricspos.scriptengine.jexl;

import java.math.BigDecimal;
import java.math.MathContext;

/**
 * @author PPERA
 *         Fecha: 7/23/12
 *         Hora: 12:11 PM
 */
public class DecimalJexlArithmetic extends NarrowerJexlArithmetic {

    public DecimalJexlArithmetic(boolean lenient) {
        super(lenient);
    }

    public DecimalJexlArithmetic(boolean lenient, MathContext bigdContext, int bigdScale) {
        super(lenient, bigdContext, bigdScale);
    }

    public DecimalJexlArithmetic(MathContext metricsMathContext) {
        super(metricsMathContext);
    }

    @Override
    protected Number narrowBigDecimal(Object lhs, Object rhs, BigDecimal bigd) {
        return roundBigDecimal(bigd);
    }
}
