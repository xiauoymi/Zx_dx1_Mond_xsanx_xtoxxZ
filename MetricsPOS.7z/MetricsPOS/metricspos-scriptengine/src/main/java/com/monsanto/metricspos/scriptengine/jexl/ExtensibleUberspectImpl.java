package com.monsanto.metricspos.scriptengine.jexl;

import com.google.common.collect.Lists;
import org.apache.commons.jexl2.JexlInfo;
import org.apache.commons.jexl2.introspection.JexlPropertyGet;
import org.apache.commons.jexl2.introspection.JexlPropertySet;
import org.apache.commons.jexl2.introspection.UberspectImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.lang.reflect.Field;
import java.util.List;

/**
 * UberspectImpl that handle the introspection of several objects.
 * This allows to use objects that does not follow the JavaBean standard
 * inside an Script as data types for variables.
 *
 * @author cafau
 */
public class ExtensibleUberspectImpl extends UberspectImpl {
    private static final Log LOG = LogFactory.getLog(ExtensibleUberspectImpl.class);

    private List<FieldAccessorFactory> accessorFactories = Lists.newArrayList();

    public ExtensibleUberspectImpl() {
        this(LOG);

    }

    public void setAccessorFactories(List<FieldAccessorFactory> accessorFactories) {
        this.accessorFactories = accessorFactories;
    }

    /**
     * Creates a new UberspectImpl.
     *
     * @param runtimeLogger the logger used for all logging needs
     */
    public ExtensibleUberspectImpl(Log runtimeLogger) {
        super(runtimeLogger);
        LOG.debug("Created");
    }

    @Override
    public Field getField(Object obj, String name, JexlInfo info) {
        LOG.debug("getField on " + name);
        return super.getField(obj, name, info);    //To change body of overridden methods use File | Settings | File Templates.
    }

    @Override
    public JexlPropertyGet getPropertyGet(Object obj, Object identifier, JexlInfo info) {
        LOG.debug("getPropertyGet on " + identifier.toString());

        FieldAccessorFactory accessorFactory = findAccessorFactoryFor(obj);

        if (accessorFactory != null) {
            return accessorFactory.accessorFor(obj, identifier.toString());
        }

        return super.getPropertyGet(obj, identifier, info);
    }

    @Override
    public JexlPropertySet getPropertySet(Object obj, Object identifier, Object arg, JexlInfo info) {
        LOG.debug("getPropertySet on " + identifier.toString());

        FieldAccessorFactory accessorFactory = findAccessorFactoryFor(obj);

        if (accessorFactory != null) {
            return accessorFactory.accessorFor(obj, identifier.toString());
        }

        return super.getPropertySet(obj, identifier, arg, info);
    }

    /**
     * Searches the factories for one that handles the given-object class
     * @param obj   the object to search a factory for
     * @return  the factory for this object or null if none
     */
    private FieldAccessorFactory findAccessorFactoryFor(Object obj) {
        for (FieldAccessorFactory factory : accessorFactories) {
            if ( factory.access(obj) ) {
                return factory;
            }
        }
        return null;
    }
}
