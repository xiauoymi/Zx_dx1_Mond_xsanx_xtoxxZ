package com.monsanto.metricspos.scriptengine.jexl;

import org.apache.commons.jexl2.introspection.JexlPropertyGet;
import org.apache.commons.jexl2.introspection.JexlPropertySet;

/**
 * Implementers allows access to properties of objects inside a Jexl script
 *
 * @author cafau
 */
public interface FieldAccessor extends JexlPropertyGet, JexlPropertySet {
}
