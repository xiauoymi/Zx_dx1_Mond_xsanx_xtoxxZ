package com.monsanto.metricspos.scriptengine.jexl;

/**
 * Implementers can create an accessor for the given object class
 *
 * @author cafau
 */
public interface FieldAccessorFactory<T> {

    FieldAccessor accessorFor( T object, String fieldName );

    /**
     * Returns true if this accessor can access the given object class
     * @param object the object to test
     * @return  true if this accessor can access it, false if not
     */
    boolean access(Object object);

}
