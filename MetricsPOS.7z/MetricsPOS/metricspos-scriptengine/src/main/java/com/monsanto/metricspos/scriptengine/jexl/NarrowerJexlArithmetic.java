package com.monsanto.metricspos.scriptengine.jexl;

import org.apache.commons.jexl2.JexlArithmetic;

import java.math.BigDecimal;
import java.math.MathContext;

/**
 * JexlArithmetic that handle correct conversion to BigDecimals
 *
 * @author PPERA
 *         Fecha: 7/23/12
 *         Hora: 12:09 PM
 */
class NarrowerJexlArithmetic extends JexlArithmetic {

    NarrowerJexlArithmetic(boolean lenient) {
        super(lenient);
    }

    NarrowerJexlArithmetic(boolean lenient, MathContext bigdContext, int bigdScale) {
        super(lenient, bigdContext, bigdScale);
    }

    public NarrowerJexlArithmetic(MathContext metricsMathContext) {
        super(false, metricsMathContext, 2);
    }

    /**
     * Given a BigDecimal, attempt to narrow it to an Integer or Long if it fits if
     * one of the arguments is a numberable.
     *
     * @param lhs  the left hand side operand that lead to the bigd result
     * @param rhs  the right hand side operand that lead to the bigd result
     * @param bigd the BigDecimal to narrow
     * @return an Integer or Long if narrowing is possible, a BigDecimal otherwise
     * @since 2.1
     */
    @Override
    protected Number narrowBigDecimal(Object lhs, Object rhs, BigDecimal bigd) {
        BigDecimal back = bigd;
        if (isNumberable(lhs) || isNumberable(rhs)) {
            try {
                long l = back.longValueExact();
                // coerce to int when possible (int being so often used in method params)
                if (l <= Integer.MAX_VALUE && l >= Integer.MIN_VALUE) {
                    return (int) l;
                } else {
                    return l;
                }
            } catch (ArithmeticException xa) {
                // ignore, no exact value possible
                back = roundBigDecimal(back);
            }
        }
        return back;
    }

    @Override
    public Object divide(Object left, Object right) {
        // if either are floating point (double or float) use double
        if (isDecimalNumber(left) || isDecimalNumber(right)) {
            return super.divide(left, right);
        }

        // otherwise treat as integers  NOOOOO, as BigDecimals !!!
        BigDecimal l = toBigDecimal(left);
        BigDecimal r = toBigDecimal(right);
        if (BigDecimal.ZERO.equals(r)) {
            throw new ArithmeticException("/");
        }

        BigDecimal result = l.divide(r, getMathContext());
        return narrowBigDecimal(left, right, result);   // Note: Here we can try to narrow because they were integers !

    }

    private boolean isDecimalNumber(Object operand) {
        return operand == null || isFloatingPointNumber(operand) || operand instanceof BigDecimal;
    }
}
