package com.monsanto.metricspos.scriptengine.jexl;

import com.monsanto.metricspos.scriptengine.ScriptEngine;
import com.monsanto.metricspos.scriptengine.ScriptEngineFactory;
import org.apache.commons.jexl2.JexlEngine;

/**
 * Simple implementation of ScriptEngineFactory that creates a ScriptEngine
 *
 * @author cafau
 */
public class SimpleScriptEngineFactory implements ScriptEngineFactory {

    /**
     * Injected
     */
    private JexlEngine engine;

    public void setEngine(JexlEngine engine) {
        this.engine = engine;
    }

    @Override
    public ScriptEngine buildFor(String script) {
        return new ScriptEngine(engine, script);
    }
}
