package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessor;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessorFactory;

/**
 * Builds a DataRowAccessor for a DataRow object
 *
 * @author cafau
 */
public class DataRowAccessorFactory  implements FieldAccessorFactory<DataRow> {
    @Override
    public FieldAccessor accessorFor(DataRow row, String fieldName ) {
        return new DataRowFieldAccessor(fieldName, row.getTypeFor(fieldName));
    }

    @Override
    public boolean access(Object object) {
        return object instanceof DataRow;
    }
}
