package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessor;
import org.apache.commons.jexl2.internal.AbstractExecutor;
import org.apache.commons.jexl2.internal.introspection.MethodKey;

/**
 * JexlPropertyGet implementation for DataRow objects allowing to use DataRows inside an Script.
 * This class will allow to read and write column values.
 * The data row objects are like a map but with a specialized form of accessing the
 * values. The value keys are the column names.
 * @author cafau
 */
public class DataRowFieldAccessor implements FieldAccessor {
    private static final Object TRY_FAILED = AbstractExecutor.TRY_FAILED;
    private String fieldName;
    private Class<?> clazz;

    public DataRowFieldAccessor(String fieldName, Class<?> clazz) {
        this.fieldName = fieldName;
        this.clazz = clazz;
    }

    public Object invoke(Object obj) throws Exception {
        return ((DataRow) obj).get(fieldName);
    }

    public Object tryInvoke(Object obj, Object key) {
        if (obj instanceof DataRow && fieldName.equals(key) ) {
            try {
                return invoke(obj);
            } catch (Exception e) {
                return TRY_FAILED;
            }
        }
        return TRY_FAILED;
    }

    public Object invoke(Object obj, Object arg) throws Exception {
        ((DataRow) obj).set(fieldName, arg);
        return arg;
    }

    public Object tryInvoke(Object obj, Object key, Object value) {
        if (obj instanceof DataRow
                && fieldName.equals(key)
                && (value == null || MethodKey.isInvocationConvertible(clazz, value.getClass(), false))) {
            try {
                return invoke(obj, value);
            } catch (Exception e) {
                return TRY_FAILED;
            }
        }
        return TRY_FAILED;
    }

    public boolean tryFailed(Object returnedValue) {
            return returnedValue == TRY_FAILED;
    }

    public boolean isCacheable() {
        return true;    // TODO Verify if this can be cacheable or not. The problem could be the clazz property
    }
}
