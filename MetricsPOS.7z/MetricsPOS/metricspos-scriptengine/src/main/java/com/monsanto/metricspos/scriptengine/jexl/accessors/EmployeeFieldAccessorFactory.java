package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessor;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessorFactory;

/**
 * Provides an interface for Jexl to access the properties of an employee
 * User: PPERA
 */
public class EmployeeFieldAccessorFactory implements FieldAccessorFactory<Employee> {
    @Override
    public FieldAccessor accessorFor(Employee object, String fieldName) {
        return new GenericBeanFieldAccessor(fieldName, object.getCampaign(), Employee.class);
    }

    @Override
    public boolean access(Object object) {
        return object instanceof Employee;
    }
}
