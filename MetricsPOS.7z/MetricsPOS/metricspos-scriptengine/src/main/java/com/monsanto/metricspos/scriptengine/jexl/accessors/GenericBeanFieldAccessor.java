package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessor;
import com.monsanto.metricspos.scriptengine.jexl.accessors.utils.ReflectionUtils;
import org.apache.commons.jexl2.internal.AbstractExecutor;

/**
 * Provides access by reflection to the properties of an object.
 * User: PPERA
 */
public class GenericBeanFieldAccessor implements FieldAccessor {
    private static final Object TRY_FAILED = AbstractExecutor.TRY_FAILED;

    private String fieldName;
    private ReflectionUtils reflectionUtils;


    public GenericBeanFieldAccessor(String fieldName, Campaign campaign, Class clazz) {
        this.fieldName = fieldName;
        this.reflectionUtils = new ReflectionUtils(campaign, clazz);
    }

    @Override
    public Object invoke(Object obj) throws Exception {
        return reflectionUtils.getWithReadMethod(obj, fieldName);
    }

    @Override
    public Object tryInvoke(Object obj, Object key) {
        try {
            return reflectionUtils.getWithReadMethod(obj, key.toString());
        } catch (Exception e) {
            return TRY_FAILED;
        }
    }

    @Override
    public Object invoke(Object obj, Object arg) throws Exception {
        reflectionUtils.writeWithWriteMethod(obj, fieldName, arg);
        return arg;
    }

    @Override
    public Object tryInvoke(Object obj, Object key, Object value) {
        try {
            reflectionUtils.writeWithWriteMethod(obj, key.toString(), value);
            return value;
        } catch (Exception e) {
            return TRY_FAILED;
        }
    }

    public boolean tryFailed(Object returnedValue) {
        return returnedValue == TRY_FAILED;
    }

    @Override
    public boolean isCacheable() {
        return false;
    }
}
