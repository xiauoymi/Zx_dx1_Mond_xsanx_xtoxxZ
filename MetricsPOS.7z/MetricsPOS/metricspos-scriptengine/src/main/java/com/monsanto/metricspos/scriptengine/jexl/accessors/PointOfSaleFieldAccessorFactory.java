package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessor;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessorFactory;

/**
 * Provides Jexl access to the properties of a point of sale
 * User: PPERA
 */
public class PointOfSaleFieldAccessorFactory implements FieldAccessorFactory<PointOfSale> {
    @Override
    public FieldAccessor accessorFor(PointOfSale object, String fieldName) {
        return new GenericBeanFieldAccessor(fieldName, object.getCampaign(), PointOfSale.class);
    }

    @Override
    public boolean access(Object object) {
        return object instanceof PointOfSale;
    }
}
