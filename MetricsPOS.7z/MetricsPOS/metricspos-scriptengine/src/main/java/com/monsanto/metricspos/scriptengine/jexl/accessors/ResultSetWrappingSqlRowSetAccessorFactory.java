package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.scriptengine.jexl.FieldAccessor;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessorFactory;
import org.springframework.jdbc.support.rowset.ResultSetWrappingSqlRowSet;

/**
 * Builds accessor for RowSet objects
 *
 * @author cafau
 */
public class ResultSetWrappingSqlRowSetAccessorFactory implements FieldAccessorFactory {
    @Override
    public FieldAccessor accessorFor(Object object, String fieldName) {
        return new ResultSetWrappingSqlRowSetAccessor(fieldName);
    }

    @Override
    public boolean access(Object object) {
        return object instanceof ResultSetWrappingSqlRowSet;
    }
}
