package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.scriptengine.jexl.FieldAccessor;
import org.apache.commons.jexl2.internal.AbstractExecutor;

import javax.naming.OperationNotSupportedException;
import javax.sql.RowSet;

/**
 * Implements tha accessor methods to RowSet objects from JexlScripts
 *
 * @author cafau
 */
public class RowSetAccessor implements FieldAccessor {
    private static final Object TRY_FAILED = AbstractExecutor.TRY_FAILED;
    private String fieldName;

    public RowSetAccessor(String fieldName) {
        this.fieldName = fieldName;
    }

    public Object invoke(Object obj) throws Exception {
        return ((RowSet) obj).getObject(fieldName);
    }

    public Object tryInvoke(Object obj, Object key) {
        if (obj instanceof RowSet && fieldName.equals(key)) {
            try {
                return invoke(obj);
            } catch (Exception e) {
                return TRY_FAILED;
            }
        }
        return TRY_FAILED;
    }

    public Object invoke(Object obj, Object arg) throws Exception {
        throw new OperationNotSupportedException("Cannot write on results from queries");
    }

    public Object tryInvoke(Object obj, Object key, Object value) {
        return TRY_FAILED;
    }

    public boolean tryFailed(Object returnedValue) {
            return returnedValue == TRY_FAILED;
    }

    public boolean isCacheable() {
        return true;
    }
}
