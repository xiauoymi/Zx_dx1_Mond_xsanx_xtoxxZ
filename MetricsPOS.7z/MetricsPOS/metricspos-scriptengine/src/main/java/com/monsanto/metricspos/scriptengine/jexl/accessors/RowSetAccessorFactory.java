package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.scriptengine.jexl.FieldAccessor;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessorFactory;

import javax.sql.RowSet;

/**
 * Builds accessor for RowSet objects
 *
 * @author cafau
 */
public class RowSetAccessorFactory implements FieldAccessorFactory {
    @Override
    public FieldAccessor accessorFor(Object object, String fieldName) {
        return new RowSetAccessor(fieldName);
    }

    @Override
    public boolean access(Object object) {
        return object instanceof RowSet;
    }
}
