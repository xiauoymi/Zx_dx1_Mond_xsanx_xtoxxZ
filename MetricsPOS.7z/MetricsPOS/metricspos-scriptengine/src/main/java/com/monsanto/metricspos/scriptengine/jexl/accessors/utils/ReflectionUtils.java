package com.monsanto.metricspos.scriptengine.jexl.accessors.utils;

import com.monsanto.metricspos.core.externaldata.converters.ConverterUtils;
import com.monsanto.metricspos.core.metrics.Campaign;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * User: PPERA
 */
public class ReflectionUtils {
    private Campaign campaign;
    private Class clazz;

    public ReflectionUtils(Campaign campaign, Class clazz){
        this.campaign = campaign;
        this.clazz = clazz;
    }

    public Method getReadMethod(String fieldName) throws IntrospectionException {
        return this.getPropertyDescriptor(fieldName).getReadMethod();
    }

    public Method getWriteMethod(String fieldName) throws IntrospectionException {
        return this.getPropertyDescriptor(fieldName).getWriteMethod();
    }

    public Class getDeclaringClass(String fieldName) throws IntrospectionException {
        return this.getPropertyDescriptor(fieldName).getPropertyType();
    }

    private PropertyDescriptor getPropertyDescriptor(String fieldName) throws IntrospectionException {
        PropertyDescriptor propertyDescriptor = null;
        BeanInfo beanInfo = Introspector.getBeanInfo(clazz, Object.class);
        for (PropertyDescriptor aPropertyDescriptor : beanInfo.getPropertyDescriptors()) {
            if (aPropertyDescriptor.getName().equals(fieldName)) {
                propertyDescriptor = aPropertyDescriptor;
            }
        }
        return propertyDescriptor;
    }

    public Object getWithReadMethod(Object obj, String fieldName) throws IntrospectionException, InvocationTargetException, IllegalAccessException {
        return this.getReadMethod(fieldName).invoke(obj);
    }

    public void writeWithWriteMethod(Object obj, String fieldName, Object... arg) throws IntrospectionException, InvocationTargetException, IllegalAccessException {
        this.getWriteMethod(fieldName).invoke(obj, ConverterUtils.makeConverterService(campaign).convert(arg, getDeclaringClass(fieldName)));
    }
}
