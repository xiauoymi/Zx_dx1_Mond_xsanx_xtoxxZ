package com.monsanto.metricspos.scriptengine.jexl.functions;

import com.monsanto.metricspos.core.externaldata.DataFile;

/**
 * Fuction to create a Data File from an input. Necessary to assign a file
 * to a data row.
 * User: LOSICL
 */
public class DataFileFunction {

    public DataFile load(String name, byte[]data){
        return new DataFile(name, data);
    }
}
