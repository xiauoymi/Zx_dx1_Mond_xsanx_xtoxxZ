package com.monsanto.metricspos.scriptengine.managers;

import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.ComputeManager;
import com.monsanto.metricspos.core.DataTableServices;
import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.application.vo.ServiceCenterVO;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.metrics.Score;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryNode;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.scriptengine.ScriptEngine;
import com.monsanto.metricspos.scriptengine.ScriptEngineFactory;
import com.monsanto.metricspos.scriptengine.exceptions.MetricComputeException;
import com.monsanto.metricspos.scriptengine.jexl.SimpleScriptEngineFactory;
import com.monsanto.metricspos.scriptengine.queries.JdbcDataTableQueryExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.*;

/**
 * Implements de ComputerManager services by means of scripts
 *
 * @author cafau
 */
public class ScriptedComputeManager implements ComputeManager {
    /**
     * In a script is used to signal that the metric was computed based on existing data
     * It is used a the result of the script.
     */
    private static final String HAS_DATA = "HAS_DATA";

    /**
     * In a script is used to signal that the service center has no data to compute the
     * metric.
     * It is used as the result of the script.
     */
    private static final String NO_DATA = "NO_DATA";
    public static final String SCORE_VARIABLE_NAME = "score";
    private static final String MAX_POINTS_VARIABLE_NAME = "maxPoints";
    private static final String METRIC_NAME_VARIABLE_NAME = "metricName";
    private static final String METRIC_TYPE_VARIABLE_NAME = "metricType";
    private static final String SERVICE_CENTER_VARIABLE_NAME = "serviceCenter";
    private static final String DATA_TABLE_QUERY_EXECUTOR_VARIABLE_NAME = "database";
    private static final String TOTAL_POINTS = "totalPoints";
    private static final String MODULE_VARIABLE_NAME = "module";
    private static final String NOW_YEAR = "now_Year";
    private static final String NOW_MONTH = "now_Month";
    private static final String NOW_DAY = "now_Day";
    private static final String NOW_DATE = "now_Date";

    @Autowired
    private ScoreServices scoreServices;

    @Autowired
    private ScriptEngineFactory scriptEngineFactory;

    @Autowired
    private DataTableServices tableServices;

    private JdbcTemplate jdbcTemplate;
    private static final String SUMMARY = "summary";

    public void setScoreServices(ScoreServices scoreServices) {
        this.scoreServices = scoreServices;
    }

    public void setScriptEngineFactory(SimpleScriptEngineFactory scriptEngineFactory) {
        this.scriptEngineFactory = scriptEngineFactory;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Compute the scores for the given metric
     *
     * @param metric to metric to compute its scores
     * @return the number of scores computed
     * @throws MetricComputeException if metric has defined a formula
     */
    @Override
    public long compute(Metric metric) {
        Campaign campaign = metric.getCampaign();
        Collection<ServiceCenter> serviceCenters = campaign.getServiceCenters();
        return this.compute(metric, serviceCenters);
    }

    /**
     * Computes a metric for a list of service center
     *
     * @param metric         metric to compute its scores
     * @param serviceCenters services centers to compute
     * @return affected scores
     */
    @Override
    public long compute(Metric metric, Collection<ServiceCenter> serviceCenters) {
        if (!StringUtils.hasText(metric.getFormula())) {
            throw new MetricComputeException("The metric " + metric.getName() + " has no formula to compute");
        }

        if (serviceCenters == null || serviceCenters.size() == 0) {
            // No service centers to compute
            return 0;
        }

        Map<ServiceCenter, MetricScore> scoresByServiceCenter = getScoresByServiceCenter(metric);
        ScriptEngine scriptEngine = scriptEngineFactory.buildFor(metric.getFormula());

        return computeScores(scriptEngine, metric, scoresByServiceCenter, serviceCenters);
    }

    /**
     * Computes the grade of a campaign depending on its scores
     *
     * @param campaign for which the grade is being computed
     * @param summary  for with the grade is being computes
     * @return The grade
     */
    @Override
    public String compute(Campaign campaign, ScoreSummaryCampaignNode summary) {
        ScriptEngine scriptEngine = scriptEngineFactory.buildFor(campaign.getRatingFormula());
        Map<String, Object> arguments = Maps.newHashMap();
        arguments.put(TOTAL_POINTS, summary.getPoints());
        arguments.put(SUMMARY, summary);
        return (String) scriptEngine.execute(arguments);
    }


    /**
     * Compute the formula for a module associated to a service center
     * @param moduleNode the node of the module to calculate the formula
     * @return The grade obtained by the module
     */
    @Override
    public void computeModuleFormula(ScoreSummaryNode moduleNode) {
       // String back = null;
        Metric metric = moduleNode.getMetric();
        if (StringUtils.hasText(metric.getFormula())) {
            ScriptEngine scriptEngine = scriptEngineFactory.buildFor(metric.getFormula());
            Map<String, Object> arguments = Maps.newHashMap();
            arguments.put(MODULE_VARIABLE_NAME, moduleNode);
            scriptEngine.execute(arguments);
        }
    }

    /**
     * Compute the given scores
     *
     * @param scriptEngine          the engine to execute the script
     * @param scoresByServiceCenter The already existent scores
     * @param serviceCenters        The service centers to compute
     * @return the number of scores computed
     */
    private long computeScores(ScriptEngine scriptEngine, Metric metric, Map<ServiceCenter, MetricScore> scoresByServiceCenter, Collection<ServiceCenter> serviceCenters) {
        long computedScores = 0;
        for (ServiceCenter serviceCenter : serviceCenters) {
            MetricScore score = scoresByServiceCenter.get(serviceCenter);

            if (score == null) {
                // Service center has no yet a score computed
                score = scoreServices.newMetricScore(metric, serviceCenter);
                score.setDirty(true);
            }

            if (score.isDirty()) {
                // only compute if the score has been flagged as dirty.
                computeScore(metric, scriptEngine, score, serviceCenter);
            }
            computedScores++;
        }

        return computedScores;
    }

    /**
     * Computes the score for a metric on a given service center.
     * Use the provided script from the metric.
     * <br/>
     * The script will perform any required computation and will set the values of the provided score.
     * Only the fields "points", "penalty", and "penaltyFactor" could be modified.
     *
     * @param score         the score to fill with the result of the calculation
     * @param serviceCenter the service center to with the score is calculated (read only)
     */
    private void computeScore(Metric metric, ScriptEngine scriptEngine, MetricScore score, ServiceCenter serviceCenter) {
        Score baseScore = Score.newEmptyScore();

        Map<String, Object> arguments = makeArguments(baseScore, serviceCenter, metric);

        // Execute script !!!
        Object result = scriptEngine.execute(arguments);

        // Process the result
        boolean noData = NO_DATA.equals(result);

        if (noData) {
            // Due to no data is available, ensures the values are empty
            score.setScores(Score.newEmptyScore());
            score.setNoData(true);
        } else {
            score.setScores(baseScore);
            score.setNoData(false);
        }

        score.setDirty(false);
        score.setLastUpdated(new Date());
    }

    /**
     * Builds the list of variables available in the context of the script.
     * <br/>
     * The script will have the following automatic variables available:
     * <ul>
     * <li>metricName: The name of the current metric</li>
     * <li>maxPoints: The maximum points assignable to this metric</li>
     * <li>serviceCenter: The service center you are computing the score for</li>
     * <li>score: The scores to compute: score.points, score.penalty, and score.penaltyFactor</li>
     * <li>HAS_DATA: Constant to return if the metric was computed with available data</li>
     * <li>NO_DATA: Constant to return if no data is available for the service center to compute this metric</li>
     * </ul>
     *
     * @param score         The current score computed. The script will fill its values
     * @param serviceCenter The current service center that is computed
     * @param metric        The current metric
     * @return a map with the predefined variables (context) for the script
     */
    private Map<String, Object> makeArguments(Score score, ServiceCenter serviceCenter, Metric metric) {
        Map<String, Object> arguments = Maps.newHashMap();

        arguments.put(METRIC_NAME_VARIABLE_NAME, metric.getName());
        arguments.put(MAX_POINTS_VARIABLE_NAME, BigDecimal.valueOf((metric.getMaxPoints() == null)?0:metric.getMaxPoints()));
        arguments.put(SERVICE_CENTER_VARIABLE_NAME, new ServiceCenterVO(serviceCenter, true));
        // The script could access the service center and change its values !!
        arguments.put(SCORE_VARIABLE_NAME, score);
        arguments.put(HAS_DATA, HAS_DATA);
        arguments.put(NO_DATA, NO_DATA);
        JdbcDataTableQueryExecutor jdbcDataTableQueryExecutor = new JdbcDataTableQueryExecutor(serviceCenter, metric.getCampaign(), this.tableServices, jdbcTemplate);
        arguments.put(DATA_TABLE_QUERY_EXECUTOR_VARIABLE_NAME, jdbcDataTableQueryExecutor);

        arguments.put(METRIC_TYPE_VARIABLE_NAME, metric.getType());
        Calendar now = Calendar.getInstance();
        arguments.put(NOW_YEAR, now.get(Calendar.YEAR));
        arguments.put(NOW_MONTH, now.get(Calendar.MONTH) + 1);// Month base 0
        arguments.put(NOW_DAY, now.get(Calendar.DAY_OF_MONTH));
        arguments.put(NOW_DATE, now.get(Calendar.MONTH) + "/" + now.get(Calendar.DAY_OF_MONTH) + "/" + now.get(Calendar.YEAR));

        return arguments;
    }

    /**
     * Find all existent scores for the metric as a map
     *
     * @param metric the metric to find the scores for
     * @return a map with the scores indexed by the service center
     */
    private Map<ServiceCenter, MetricScore> getScoresByServiceCenter(Metric metric) {
        Collection<MetricScore> scores = metric.getScores();

        if (scores == null || scores.size() == 0) {
            return Collections.EMPTY_MAP;
        }

        Map<ServiceCenter, MetricScore> scoreByServiceCenter = Maps.newHashMapWithExpectedSize(scores.size());

        for (MetricScore score : scores) {
            scoreByServiceCenter.put(score.getServiceCenter(), score);
        }

        return scoreByServiceCenter;
    }
}
