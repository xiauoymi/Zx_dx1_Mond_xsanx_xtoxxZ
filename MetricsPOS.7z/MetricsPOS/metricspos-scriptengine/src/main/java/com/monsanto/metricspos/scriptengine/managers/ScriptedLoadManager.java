package com.monsanto.metricspos.scriptengine.managers;

import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.LoadManager;
import com.monsanto.metricspos.core.TableAdapter;
import com.monsanto.metricspos.scriptengine.ExternalDataQueryExecutor;
import com.monsanto.metricspos.scriptengine.ScriptEngine;
import com.monsanto.metricspos.scriptengine.ScriptEngineFactory;
import com.monsanto.metricspos.scriptengine.exceptions.CannotLoadTable;
import com.monsanto.metricspos.scriptengine.jexl.functions.DataFileFunction;
import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import java.util.Map;

/**
 * Implements the LoadManager interfaces executing a Script for each record to load
 *
 * @author cafau
 */
public class ScriptedLoadManager implements LoadManager {

    private Logger log = Logger.getLogger(ScriptedLoadManager.class);

    public static final String SKIP = "SKIP";

    private ExternalDataQueryExecutor queryExecutor;

    private ScriptEngineFactory scriptEngineFactory;

    public void setQueryExecutor(ExternalDataQueryExecutor queryExecutor) {
        this.queryExecutor = queryExecutor;
    }

    public void setScriptEngineFactory(ScriptEngineFactory scriptEngineFactory) {
        this.scriptEngineFactory = scriptEngineFactory;
    }

    /**
     * Loads the data structure with the corresponding records
     *
     * @param tableAdapter The adapter to the real table to be loaded
     * @return
     */
    @Override
    public long load(TableAdapter tableAdapter) {

        String loadSql = tableAdapter.getLoadSql();

        if (!StringUtils.hasText(loadSql) || !StringUtils.hasText(tableAdapter.getLoadScript())) {
            // Nothing to do
            throw new CannotLoadTable("Table has no scripts or SQL to perform the load");
        }

        // TODO Pass campaign parameters to query ???
        Iterable externalRows = queryExecutor.execute(tableAdapter.getProvider(), loadSql);

        tableAdapter.markAllRecordsAsNotLoaded();

        long processedRows = 0;

        if (externalRows != null) {
            // Some rows
            processedRows = processRows(tableAdapter, externalRows);
        }

        tableAdapter.removeAllUnloadedRecords();

        return processedRows;
    }

    /**
     * Process the input rows with the current table adapter
     *
     * @param tableAdapter
     * @param externalRows
     * @return
     */
    private long processRows(TableAdapter tableAdapter, Iterable externalRows) {
        ScriptEngine scriptEngine = scriptEngineFactory.buildFor(tableAdapter.getLoadScript());

        long processedRows = 0;

        for (Object record : externalRows) {
            if (processRow(tableAdapter, scriptEngine, record)) {
                processedRows++;
                if (processedRows % 100 == 0) {
                    log.debug("Inserting rows count " + processedRows);
                }
            }
        }

        return processedRows;
    }

    /**
     * Executes the script on the given record. TODO !!!!
     *
     * @param tableAdapter
     * @param scriptEngine
     * @param record
     * @return
     */
    private boolean processRow(TableAdapter tableAdapter, ScriptEngine scriptEngine, Object record) {
        Map<String, Object> arguments = makeArguments(tableAdapter, record);

        Object result = scriptEngine.execute(arguments);

        boolean processed = SKIP != result;

        if (processed) {
            tableAdapter.markAsLoaded(result);
            tableAdapter.saveOrUpdate(result); // TODO Commit or flush???
        }

        return processed;
    }

    /**
     * Makes the input argument map for the Jexl script
     *
     * @param tableAdapter
     * @param record
     * @return
     */
    private Map<String, Object> makeArguments(TableAdapter tableAdapter, Object record) {
        Map<String, Object> arguments = Maps.newHashMap();  // TODO campaña
        arguments.put("input", record);
        arguments.put("output", tableAdapter.getEmptyRecord()); // TODO
        arguments.put(SKIP, SKIP);
        arguments.put("file", new DataFileFunction());
        return arguments;
    }
}
