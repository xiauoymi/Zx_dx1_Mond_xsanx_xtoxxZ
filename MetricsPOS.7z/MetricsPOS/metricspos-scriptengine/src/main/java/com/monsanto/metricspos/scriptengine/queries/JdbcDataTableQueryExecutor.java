package com.monsanto.metricspos.scriptengine.queries;

import com.monsanto.metricspos.core.DataTableServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

/**
 * Executes a query of a data table adapting it to it's physical representation
 * User: PPERA
 */
public class JdbcDataTableQueryExecutor {

    private JdbcTemplate jdbcTemplate;
    private ServiceCenter serviceCenter;
    private Campaign campaign;
    private DataTableServices tableServices;

    public JdbcDataTableQueryExecutor(ServiceCenter serviceCenter, Campaign campaign, DataTableServices tableServices, JdbcTemplate jdbcTemplate) {
        this.serviceCenter = serviceCenter;
        this.campaign = campaign;
        this.tableServices = tableServices;
        this.jdbcTemplate = jdbcTemplate;
    }

    public Iterable<SqlRowSet> query(String rowQuery) {
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(this.transformQuery(rowQuery));
        return new RowSetIterator(rowSet);
    }

    public Long countQuery(String rowQuery) {
        return jdbcTemplate.queryForLong(this.transformQuery(rowQuery));
    }

    private String transformQuery(String rowQuery) {
        RowQueryAdapter rowQueryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, tableServices);
        return rowQueryAdapter.getSqlQuery();
    }
}
