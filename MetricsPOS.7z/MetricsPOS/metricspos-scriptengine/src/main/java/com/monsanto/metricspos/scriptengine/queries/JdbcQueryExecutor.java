package com.monsanto.metricspos.scriptengine.queries;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.scriptengine.ExternalDataQueryExecutor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

/**
 * Implementation of ExternalDataQueryExecutor that performs the query against a JDBC source
 *
 *  TODO SqlRowSet can handle large data sets??
 *
 * @author cafau
 */
public class JdbcQueryExecutor implements ExternalDataQueryExecutor<SqlRowSet> {

    private static final Cache<DataProvider, JdbcTemplate> TEMPLATES =
            CacheBuilder.newBuilder().concurrencyLevel(3).maximumSize(10).build();

    @Override
    public Iterable<SqlRowSet> execute(DataProvider provider, String query) {

        JdbcTemplate template = getTemplate( provider );

        return new RowSetIterator(template.queryForRowSet(query));  // TODO Where the SqlRowSet is closed??
    }

    private JdbcTemplate getTemplate(DataProvider provider) {
        JdbcTemplate template = TEMPLATES.getIfPresent(provider);

        if ( template == null ) {
            if ( provider.getDataSource() == null ) {
                throw new IllegalArgumentException("The provider " + provider.getCode() + ": " + provider.getName() + ", has no data source defined");
            }
            template = newJdbcTemplate(provider);

            TEMPLATES.put(provider, template);
        }
        return template;
    }

    /**
     * Factory method to allow testing
     * @param provider
     * @return
     */
    protected JdbcTemplate newJdbcTemplate(DataProvider provider) {
        return new JdbcTemplate( provider.getDataSource() );
    }
}
